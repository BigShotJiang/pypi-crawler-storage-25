# SPDX-License-Identifier: MIT
"""Tests for scripts/mutation_run.py — task #58 Phase 1.

Pins the scaffold's contract:
- operators produce valid mutations
- file-level mutate_file restores the original on every iteration
- format_report stays stable shape
- CLI args validate
- resolve_targets filters non-Python + nonexistent paths
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import mutation_run


class TestMutateLine:
    def test_flips_return_true(self):
        out = mutation_run._mutate_line("    return True\n", 0)
        assert out == "    return False\n"

    def test_flips_return_false(self):
        out = mutation_run._mutate_line("    return False\n", 1)
        assert out == "    return True\n"

    def test_flips_eq_to_neq(self):
        # Find the index of the == operator in OPERATORS.
        idx = next(i for i, (_, _, d) in enumerate(mutation_run.OPERATORS) if "== → !=" in d)
        out = mutation_run._mutate_line("if x == 1:\n", idx)
        assert "!=" in out

    def test_flips_and_to_or(self):
        idx = next(i for i, (_, _, d) in enumerate(mutation_run.OPERATORS) if "and → or" in d)
        out = mutation_run._mutate_line("if a and b:\n", idx)
        assert " or " in out

    def test_returns_none_when_no_match(self):
        # `return` is in the line but no True/False → no mutation from op 0.
        out = mutation_run._mutate_line("    return value\n", 0)
        assert out is None

    def test_does_not_rewrite_triple_equals(self):
        # We specifically designed the == operator to not touch
        # `===` or `==` inside other operators. Python doesn't have
        # `===` but guard-test ensures lookahead works.
        idx = next(i for i, (_, _, d) in enumerate(mutation_run.OPERATORS) if "== → !=" in d)
        # Operator inside a string literal: still mutated by regex.
        # This is a known limitation of the Phase 1 string-level
        # mutator — AST-based mutation in Phase 2 fixes it.
        out = mutation_run._mutate_line("msg = 'x == y'\n", idx)
        assert out is not None  # Phase 1 limitation documented.


class TestResolveTargets:
    def test_uses_defaults_when_empty(self):
        targets = mutation_run.resolve_targets([])
        assert len(targets) >= 1
        for t in targets:
            assert t.suffix == ".py"
            assert t.is_file()

    def test_skips_nonexistent(self, capsys):
        targets = mutation_run.resolve_targets(["does/not/exist.py"])
        assert targets == []
        err = capsys.readouterr().err
        assert "not found" in err

    def test_skips_non_python(self, tmp_path, capsys):
        # Use a real file that exists but isn't .py.
        targets = mutation_run.resolve_targets(["CHANGELOG.md"])
        assert targets == []
        err = capsys.readouterr().err
        assert "non-Python" in err


class TestStringAndCommentSkip:
    """Phase 3 change: skip mutations inside docstrings + inline
    comments. These produced false-positive ``survivors`` (e.g.,
    ``>=`` in a code comment mutated to ``<=`` — pytest passes
    because the comment doesn't affect behavior)."""

    def test_string_lines_includes_docstring_body(self):
        src = '''def f():
    """Multi-line docstring
    with and/or in prose that should
    never get mutated to or/and."""
    return True
'''
        lines = mutation_run._string_lines(src)
        # Docstring body spans lines 2-4.
        assert 2 in lines
        assert 3 in lines
        assert 4 in lines
        # Line 1 (def) and line 5 (return) are code.
        assert 1 not in lines
        assert 5 not in lines

    def test_string_lines_survives_on_syntax_error(self):
        # Best-effort: malformed source returns empty set, not crash.
        src = "def f(:\n    return\n"
        # tokenize raises on this; the helper returns {} gracefully.
        result = mutation_run._string_lines(src)
        assert isinstance(result, set)

    def test_comment_start_cols_finds_inline_hash(self):
        src = "x = 1  # comment >= 5 chars\n"
        cols = mutation_run._comment_start_cols(src)
        assert 1 in cols
        # The `#` starts at column 7 (after "x = 1  ").
        assert cols[1] == 7

    def test_comment_start_cols_ignores_hash_in_string(self):
        src = 'x = "#notacomment"\n'
        cols = mutation_run._comment_start_cols(src)
        # No comment on the line.
        assert 1 not in cols

    def test_mutate_line_with_comment_col_skips_in_comment_match(self):
        # `>=` appears past the comment column — should not mutate.
        idx = next(i for i, (_, _, d) in enumerate(mutation_run.OPERATORS) if ">= → <=" in d)
        # Line: `x = 1  # limit >= 5`
        line = "x = 1  # limit >= 5\n"
        comment_col = line.index("#")
        out = mutation_run._mutate_line(line, idx, comment_col=comment_col)
        assert out is None

    def test_mutate_line_with_comment_col_mutates_code_match(self):
        # `==` appears before the comment — should mutate.
        idx = next(i for i, (_, _, d) in enumerate(mutation_run.OPERATORS) if "== → !=" in d)
        line = "if x == 1:  # check equality\n"
        comment_col = line.index("#")
        out = mutation_run._mutate_line(line, idx, comment_col=comment_col)
        assert out is not None
        assert "!=" in out


class TestMutateFileRestoresOriginal:
    def test_file_restored_even_when_mutation_survives(self, tmp_path):
        """Load-bearing invariant: mutation_run NEVER leaves the file
        mutated when it returns, even if pytest passes (survivor)."""
        target = tmp_path / "sample.py"
        original = "def f():\n    return True\n"
        target.write_text(original, encoding="utf-8")

        with (
            patch.object(mutation_run, "_run_pytest_against", return_value=(True, "survived")),
            patch.object(mutation_run, "ROOT", tmp_path),
        ):
            mutation_run.mutate_file(target, max_mutations=5)
        assert target.read_text(encoding="utf-8") == original


class TestAllowlist:
    """Phase 3: allowlist + gate semantics."""

    def _make_result(self, file, line, operator):
        return mutation_run.MutationResult(
            file=file,
            line_number=line,
            operator=operator,
            original_line="x",
            mutated_line="y",
            killed=False,
        )

    def _make_report(self, file, survivors):
        r = mutation_run.FileReport(path=file)
        r.total = len(survivors)
        r.survivors = survivors
        return r

    def test_survivor_key_format(self):
        result = self._make_result("core/trust.py", 42, "== → !=")
        assert mutation_run.survivor_key(result) == "core/trust.py:42:== → !="

    def test_parse_allowlist_ignores_comments_and_blanks(self, tmp_path):
        path = tmp_path / "allow.txt"
        path.write_text(
            "# comment\n"
            "\n"
            "core/trust.py:103:or → and\n"
            "  # indented comment not supported (treated as entry)\n"
            "core/trust.py:161:or → and\n"
        )
        # Indented comments are literal — our parse only strips outer
        # whitespace, so "# indented" becomes a "#" line after strip.
        # Verify blank + leading-# get ignored; two real entries remain.
        keys = mutation_run.parse_allowlist(path)
        assert keys == {
            "core/trust.py:103:or → and",
            "core/trust.py:161:or → and",
        }

    def test_parse_allowlist_missing_file_returns_empty(self, tmp_path):
        assert mutation_run.parse_allowlist(tmp_path / "missing.txt") == set()

    def test_parse_allowlist_malformed_raises(self, tmp_path):
        path = tmp_path / "bad.txt"
        path.write_text("not-a-valid-entry\n")
        with pytest.raises(ValueError, match="malformed allowlist"):
            mutation_run.parse_allowlist(path)

    def test_gate_passes_when_all_survivors_allowlisted(self):
        survivor = self._make_result("core/trust.py", 103, "or → and")
        reports = [self._make_report("core/trust.py", [survivor])]
        allowlist = {"core/trust.py:103:or → and"}
        code, msgs = mutation_run.gate_result(reports, allowlist)
        assert code == 0
        assert msgs == []

    def test_gate_fails_on_new_survivor(self):
        new = self._make_result("core/trust.py", 999, "== → !=")
        reports = [self._make_report("core/trust.py", [new])]
        code, msgs = mutation_run.gate_result(reports, allowlist=set())
        assert code == 1
        joined = "\n".join(msgs)
        assert "1 new survivor" in joined
        assert "core/trust.py:999:== → !=" in joined

    def test_gate_reports_progress_on_killed_allowlisted(self):
        # Allowlist expects a survivor that isn't present in this run
        # (i.e., a test now kills it). Gate passes, but reports progress.
        reports: list[mutation_run.FileReport] = []
        allowlist = {"core/trust.py:42:== → !="}
        code, msgs = mutation_run.gate_result(reports, allowlist)
        assert code == 0
        joined = "\n".join(msgs)
        assert "Progress" in joined
        assert "core/trust.py:42:== → !=" in joined

    def test_gate_fails_new_even_when_others_progress(self):
        # Killed one from allowlist, gained a new unallowlisted one.
        # Net result: still fail (new survivor is the blocking signal).
        new = self._make_result("core/universal_http.py", 50, "return False → True")
        reports = [self._make_report("core/universal_http.py", [new])]
        allowlist = {"core/trust.py:103:or → and"}  # not in current run
        code, msgs = mutation_run.gate_result(reports, allowlist)
        assert code == 1
        joined = "\n".join(msgs)
        assert "Progress" in joined  # allowlist entry shown as killed
        assert "FAIL" in joined  # new survivor still fails

    def test_file_restored_even_when_mutation_killed(self, tmp_path):
        """Same invariant on the happy path — killed mutations don't
        get left behind either."""
        target = tmp_path / "sample.py"
        original = "def f():\n    return True\n"
        target.write_text(original, encoding="utf-8")

        with (
            patch.object(mutation_run, "_run_pytest_against", return_value=(False, "killed")),
            patch.object(mutation_run, "ROOT", tmp_path),
        ):
            mutation_run.mutate_file(target, max_mutations=5)
        assert target.read_text(encoding="utf-8") == original

    def test_respects_max_mutations_cap(self, tmp_path):
        """Phase 1 caps mutations per file. A file with many
        mutatable lines must not exceed the cap."""
        target = tmp_path / "sample.py"
        target.write_text(
            "def f():\n"
            "    return True\n"
            "    return True\n"
            "    return True\n"
            "    return True\n"
            "    return True\n",
            encoding="utf-8",
        )

        with (
            patch.object(mutation_run, "_run_pytest_against", return_value=(False, "killed")),
            patch.object(mutation_run, "ROOT", tmp_path),
        ):
            report = mutation_run.mutate_file(target, max_mutations=3)
        assert report.total == 3


class TestFormatReport:
    def test_shape_includes_totals_and_survivors(self):
        r = mutation_run.FileReport(path="core/x.py", total=5, killed=4)
        r.survivors.append(
            mutation_run.MutationResult(
                file="core/x.py",
                line_number=42,
                operator="return True → False",
                original_line="    return True",
                mutated_line="    return False",
                killed=False,
                notes="survived",
            )
        )
        out = mutation_run.format_report([r])
        assert "Mutation testing" in out
        assert "4/5" in out
        assert "SURVIVOR" in out
        assert "line 42" in out

    def test_empty_reports(self):
        out = mutation_run.format_report([])
        assert "0/0" in out


class TestCliValidation:
    def test_rejects_zero_max_per_file(self, monkeypatch):
        monkeypatch.setattr(sys, "argv", ["mutation_run.py", "--max-per-file", "0"])
        assert mutation_run.main() == 2

    def test_rejects_negative_max_per_file(self, monkeypatch):
        monkeypatch.setattr(sys, "argv", ["mutation_run.py", "--max-per-file", "-1"])
        assert mutation_run.main() == 2
