# SPDX-License-Identifier: MIT
"""Tests for scripts/install_hooks.sh — the pre-push Gate A installer.

Pins the installer's contract:
- Idempotent install — re-running leaves the hook exactly as-is
  (sentinel-based ownership detection).
- Operator-managed hooks get backed up, not overwritten silently.
- --uninstall refuses to remove operator-managed hooks (ones
  without the sentinel).
- --status reports the current state truthfully.
- Installed hook is executable + contains the expected check.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ENGINE_ROOT / "scripts" / "install_hooks.sh"
SENTINEL = "# nebula-managed hook — scripts/install_hooks.sh"


@pytest.fixture
def fake_clone(tmp_path):
    """Synthesize a repo-shaped tmp dir the installer will accept."""
    (tmp_path / ".git" / "hooks").mkdir(parents=True)
    # Copy the installer and smoke_run into place so the installed
    # hook references a real file.
    scripts_dir = tmp_path / "scripts"
    scripts_dir.mkdir()
    shutil.copy(INSTALLER, scripts_dir / "install_hooks.sh")
    (scripts_dir / "install_hooks.sh").chmod(0o755)
    # A minimal smoke_run.py stub so the pre-push hook finds it if
    # the install test runs it end-to-end (we don't actually trigger
    # a push here).
    (scripts_dir / "smoke_run.py").write_text("#!/usr/bin/env python3\nprint('ok')\n")
    return tmp_path


def _run_installer(clone_root: Path, *args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["bash", str(clone_root / "scripts" / "install_hooks.sh"), *args],
        capture_output=True,
        text=True,
        cwd=str(clone_root),
        check=False,
    )


class TestInstall:
    def test_installs_pre_push_hook(self, fake_clone):
        r = _run_installer(fake_clone, "install")
        assert r.returncode == 0
        hook = fake_clone / ".git" / "hooks" / "pre-push"
        assert hook.is_file()
        assert hook.stat().st_mode & 0o111  # executable
        content = hook.read_text()
        assert SENTINEL in content
        assert "scripts/smoke_run.py" in content
        assert "Gate A" in content

    def test_install_is_idempotent(self, fake_clone):
        _run_installer(fake_clone, "install")
        hook = fake_clone / ".git" / "hooks" / "pre-push"
        first = hook.read_text()
        _run_installer(fake_clone, "install")
        second = hook.read_text()
        assert first == second

    def test_backs_up_operator_managed_hook(self, fake_clone):
        hook = fake_clone / ".git" / "hooks" / "pre-push"
        hook.write_text("#!/bin/sh\necho 'my custom hook'\n")
        hook.chmod(0o755)
        r = _run_installer(fake_clone, "install")
        assert r.returncode == 0
        # Backup should exist.
        backups = list((fake_clone / ".git" / "hooks").glob("pre-push.pre-nebula.*"))
        assert len(backups) == 1
        assert "my custom hook" in backups[0].read_text()
        # New hook is nebula-managed.
        assert SENTINEL in hook.read_text()


class TestStatus:
    def test_reports_not_installed(self, fake_clone):
        r = _run_installer(fake_clone, "--status")
        assert r.returncode == 0
        assert "pre-push:" in r.stdout
        assert "not installed" in r.stdout

    def test_reports_nebula_managed(self, fake_clone):
        _run_installer(fake_clone, "install")
        r = _run_installer(fake_clone, "--status")
        assert "nebula-managed" in r.stdout

    def test_reports_operator_managed(self, fake_clone):
        hook = fake_clone / ".git" / "hooks" / "pre-push"
        hook.write_text("#!/bin/sh\necho 'custom'\n")
        hook.chmod(0o755)
        r = _run_installer(fake_clone, "--status")
        assert "operator-managed" in r.stdout


class TestUninstall:
    def test_removes_nebula_managed_hook(self, fake_clone):
        _run_installer(fake_clone, "install")
        r = _run_installer(fake_clone, "--uninstall")
        assert r.returncode == 0
        assert not (fake_clone / ".git" / "hooks" / "pre-push").exists()

    def test_refuses_to_remove_operator_managed(self, fake_clone):
        hook = fake_clone / ".git" / "hooks" / "pre-push"
        hook.write_text("#!/bin/sh\necho 'operator'\n")
        hook.chmod(0o755)
        r = _run_installer(fake_clone, "--uninstall")
        assert r.returncode != 0
        # Hook is still there (refused to delete).
        assert hook.is_file()
        assert "operator" in hook.read_text()

    def test_uninstall_missing_hook_is_noop(self, fake_clone):
        r = _run_installer(fake_clone, "--uninstall")
        # No hook to remove → exit 0 (nothing to do).
        assert r.returncode == 0


class TestBadUsage:
    def test_not_a_git_clone_exits_2(self, tmp_path):
        """Running inside a dir without .git/ exits 2."""
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        shutil.copy(INSTALLER, scripts_dir / "install_hooks.sh")
        (scripts_dir / "install_hooks.sh").chmod(0o755)
        r = _run_installer(tmp_path, "install")
        assert r.returncode == 2

    def test_unknown_command_exits_2(self, fake_clone):
        r = _run_installer(fake_clone, "bogus")
        assert r.returncode == 2
