# SPDX-License-Identifier: MIT
"""Tests for core/extensions/mission.py — task #62 anti-fork G2 (partial)."""

from __future__ import annotations

from pathlib import Path

import pytest

from core.extensions.mission import (
    MissionOverrides,
    apply_mission_overrides,
    load_mission_overrides,
    resolve_mission_path,
)

SAMPLE_MISSION = {
    "name": "test",
    "pillars": [
        {"name": "technical_excellence", "weight": 0.25, "priority": 3},
        {"name": "ecosystem_expansion", "weight": 0.18, "priority": 2},
        {"name": "security", "weight": 0.20, "priority": 2},
        {"name": "adoption", "weight": 0.10, "priority": 1},
        {"name": "innovation", "weight": 0.17, "priority": 2},
        {"name": "community", "weight": 0.10, "priority": 1},
    ],
}


class TestResolvePath:
    def test_default_path(self, monkeypatch):
        monkeypatch.delenv("NEBULA_MISSION_PATH", raising=False)
        monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
        p = resolve_mission_path()
        assert p.name == "mission.toml"
        assert p.parent.name == "nebula"

    def test_explicit_override(self, monkeypatch, tmp_path):
        monkeypatch.setenv("NEBULA_MISSION_PATH", str(tmp_path / "mine.toml"))
        assert resolve_mission_path() == tmp_path / "mine.toml"

    def test_xdg_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NEBULA_MISSION_PATH", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        assert resolve_mission_path() == tmp_path / "nebula" / "mission.toml"


class TestLoadMissionOverrides:
    def test_missing_file_returns_empty(self, tmp_path):
        result = load_mission_overrides(tmp_path / "nope.toml")
        assert result.is_empty()
        assert result.warnings == []

    def test_parses_weights(self, tmp_path):
        f = tmp_path / "mission.toml"
        f.write_text("[mission.weights]\ntechnical_excellence = 0.40\nsecurity = 0.30\n")
        result = load_mission_overrides(f)
        assert result.weights == {
            "technical_excellence": 0.40,
            "security": 0.30,
        }

    def test_parses_disabled(self, tmp_path):
        f = tmp_path / "mission.toml"
        f.write_text('[mission.pillars.disable]\necosystem_expansion = "testnet only"\n')
        result = load_mission_overrides(f)
        assert result.disabled == {"ecosystem_expansion": "testnet only"}

    def test_malformed_toml_warns(self, tmp_path):
        f = tmp_path / "mission.toml"
        f.write_text("not valid [[[")
        result = load_mission_overrides(f)
        assert any("parse error" in w for w in result.warnings)

    def test_negative_weight_warns(self, tmp_path):
        f = tmp_path / "mission.toml"
        f.write_text("[mission.weights]\nbad = -0.5\n")
        result = load_mission_overrides(f)
        assert "bad" not in result.weights
        assert any("non-negative" in w for w in result.warnings)


class TestApplyMissionOverrides:
    def test_empty_overrides_returns_unchanged(self):
        result = apply_mission_overrides(SAMPLE_MISSION, MissionOverrides())
        assert result == SAMPLE_MISSION

    def test_weight_override_renormalizes_to_one(self):
        overrides = MissionOverrides(weights={"technical_excellence": 0.60, "security": 0.30})
        result = apply_mission_overrides(SAMPLE_MISSION, overrides)
        total = sum(p["weight"] for p in result["pillars"])
        assert abs(total - 1.0) < 1e-9

    def test_disabled_pillar_removed(self):
        overrides = MissionOverrides(disabled={"ecosystem_expansion": "skip"})
        result = apply_mission_overrides(SAMPLE_MISSION, overrides)
        names = {p["name"] for p in result["pillars"]}
        assert "ecosystem_expansion" not in names
        assert len(result["pillars"]) == len(SAMPLE_MISSION["pillars"]) - 1

    def test_disabled_weights_redistribute(self):
        overrides = MissionOverrides(disabled={"adoption": "skip"})
        result = apply_mission_overrides(SAMPLE_MISSION, overrides)
        total = sum(p["weight"] for p in result["pillars"])
        assert abs(total - 1.0) < 1e-9

    def test_unknown_pillar_warns(self):
        overrides = MissionOverrides(weights={"does_not_exist": 0.5})
        apply_mission_overrides(SAMPLE_MISSION, overrides)
        assert any("unknown pillar" in w for w in overrides.warnings)

    def test_priority_recomputed(self):
        overrides = MissionOverrides(weights={"technical_excellence": 0.50})
        result = apply_mission_overrides(SAMPLE_MISSION, overrides)
        te = next(p for p in result["pillars"] if p["name"] == "technical_excellence")
        # After renormalization, priority should be round(weight * 10).
        assert te["priority"] == round(te["weight"] * 10) or te["priority"] == 1

    def test_input_not_mutated(self):
        original_weights = [p["weight"] for p in SAMPLE_MISSION["pillars"]]
        overrides = MissionOverrides(weights={"security": 0.50})
        apply_mission_overrides(SAMPLE_MISSION, overrides)
        after = [p["weight"] for p in SAMPLE_MISSION["pillars"]]
        assert original_weights == after

    def test_result_marked_as_overridden(self):
        overrides = MissionOverrides(weights={"security": 0.30})
        result = apply_mission_overrides(SAMPLE_MISSION, overrides)
        assert result.get("overrides_applied") is True

    def test_empty_pillars_returns_unchanged(self):
        mission = {"pillars": []}
        overrides = MissionOverrides(weights={"x": 0.5})
        result = apply_mission_overrides(mission, overrides)
        assert result == mission
