# SPDX-License-Identifier: MIT
"""Tests for domains.self_maintenance.engines.readme_truth_auditor (task #74)."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest

from domains.self_maintenance.engines.readme_truth_auditor import (
    MAX_BROKEN_REFS_PER_RUN,
    _classify_drift,
    _classify_forward_claim,
    _extract_first_number,
    _load_claims_yml,
    _run_shell_verifier,
    _scan_changelog_forward_claims,
    _scan_docs_tree_broken_refs,
    run_readme_truth_audit,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_claims_yml(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


YAML_AVAILABLE = False
try:
    import yaml

    YAML_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Number extraction
# ---------------------------------------------------------------------------


class TestExtractFirstNumber:
    def test_simple_int(self):
        assert _extract_first_number("17 domains") == 17.0

    def test_with_comma(self):
        # Comma not part of the regex; first contiguous digits
        assert _extract_first_number("107,480 lines") == 107.0

    def test_decimal(self):
        assert _extract_first_number("3.14 pi") == 3.14

    def test_no_number(self):
        assert _extract_first_number("no digits here") is None

    def test_negative(self):
        assert _extract_first_number("delta -5") == -5.0


# ---------------------------------------------------------------------------
# Shell verifier
# ---------------------------------------------------------------------------


class TestShellVerifier:
    def test_echo_runs(self):
        ok, stdout, stderr = _run_shell_verifier("echo hello")
        assert ok is True
        assert stdout == "hello"
        assert stderr == ""

    def test_failing_command(self):
        ok, _stdout, _stderr = _run_shell_verifier("false")
        assert ok is False

    def test_nonexistent_command(self):
        ok, _, _ = _run_shell_verifier("this_command_does_not_exist_12345")
        assert ok is False


# ---------------------------------------------------------------------------
# Drift classification
# ---------------------------------------------------------------------------


class TestClassifyDrift:
    def _verifier_result(self, *, ran=True, stdout="", stderr="", skipped_reason=None):
        return {
            "ran": ran,
            "stdout": stdout,
            "stderr": stderr,
            "type": "shell",
            "skipped_reason": skipped_reason,
        }

    def test_exact_numerical_match(self):
        claim = {"claim": "17 domains", "status": "verified"}
        result = self._verifier_result(stdout="17")
        c = _classify_drift(claim, result)
        assert c["status"] == "verified"

    def test_small_drift_within_threshold(self):
        claim = {
            "claim": "17 domains",
            "status": "verified",
            "last_verified_value": 17,
        }
        result = self._verifier_result(stdout="18")
        c = _classify_drift(claim, result)
        assert c["status"] == "drift"

    def test_large_drift_is_broken(self):
        claim = {
            "claim": "10 domains",
            "status": "verified",
            "last_verified_value": 10,
        }
        # 100% drift (10 → 20) — beyond DRIFT_PCT_THRESHOLD (10%)
        # AND beyond DRIFT_ABSOLUTE_THRESHOLD (5)
        result = self._verifier_result(stdout="20")
        c = _classify_drift(claim, result)
        assert c["status"] == "broken"

    def test_unverified_when_verifier_fails(self):
        claim = {"claim": "17 domains"}
        result = self._verifier_result(ran=False, stderr="boom")
        c = _classify_drift(claim, result)
        assert c["status"] == "unverified"
        assert "boom" in c["reason"]

    def test_skipped_reason_propagates(self):
        claim = {"claim": "x"}
        result = self._verifier_result(
            ran=False,
            skipped_reason="smoke_test verifiers run via the scenario CI job",
        )
        c = _classify_drift(claim, result)
        assert c["status"] == "skipped"

    def test_substring_match_for_non_numerical(self):
        claim = {"claim": "ProviderRegistry"}
        result = self._verifier_result(stdout="<class ProviderRegistry at ...>")
        c = _classify_drift(claim, result)
        assert c["status"] == "verified"


# ---------------------------------------------------------------------------
# Forward-looking claim detection
# ---------------------------------------------------------------------------


class TestForwardLookingDetection:
    def test_phase_will_ship_pattern(self, tmp_path, monkeypatch):
        changelog = tmp_path / "CHANGELOG.md"
        changelog.write_text(
            "## [0.6.5]\n\nSome content. Phase B will ship as v0.6.7 with X, Y, Z.\nMore text.\n"
        )
        from domains.self_maintenance.engines import readme_truth_auditor

        monkeypatch.setattr(readme_truth_auditor, "CHANGELOG_PATH", changelog)
        detections = _scan_changelog_forward_claims()
        assert len(detections) >= 1
        assert any("v0.6.7" in d["version"] for d in detections)

    def test_task_scheduled_pattern(self, tmp_path, monkeypatch):
        changelog = tmp_path / "CHANGELOG.md"
        changelog.write_text("## [0.6.5]\n\ntask #99 is scheduled for v0.6.10 with cleanup work.\n")
        from domains.self_maintenance.engines import readme_truth_auditor

        monkeypatch.setattr(readme_truth_auditor, "CHANGELOG_PATH", changelog)
        detections = _scan_changelog_forward_claims()
        assert any("99" in d["subject"] and "v0.6.10" in d["version"] for d in detections)

    def test_no_match_on_innocuous_text(self, tmp_path, monkeypatch):
        changelog = tmp_path / "CHANGELOG.md"
        changelog.write_text("## [0.6.5]\n\nShipped today. Tests pass. No future plans here.\n")
        from domains.self_maintenance.engines import readme_truth_auditor

        monkeypatch.setattr(readme_truth_auditor, "CHANGELOG_PATH", changelog)
        detections = _scan_changelog_forward_claims()
        assert detections == []


class TestClassifyForwardClaim:
    def test_task_no_longer_exists_is_stale(self):
        detection = {
            "line_no": 42,
            "raw": "task #999 is scheduled for v0.6.10",
            "version": "v0.6.10",
            "subject": "999",
            "pattern": "",
        }
        # task #999 doesn't exist in tasks dict
        result = _classify_forward_claim(detection, tasks={})
        assert result is not None
        assert result["status"] == "stale_forward_claim"
        assert "does not exist" in result["reason"]

    def test_task_phase_changed_is_stale(self):
        detection = {
            "line_no": 42,
            "raw": "task #5 is scheduled for v0.6.10",
            "version": "v0.6.10",
            "subject": "5",
            "pattern": "",
        }
        tasks = {"5": {"id": 5, "phase": "v0.6.13", "title": "moved task"}}
        result = _classify_forward_claim(detection, tasks)
        assert result is not None
        assert "current plan ships it in v0.6.13" in result["reason"]

    def test_task_phase_matches_is_accurate(self):
        detection = {
            "line_no": 42,
            "raw": "task #5 is scheduled for v0.6.10",
            "version": "v0.6.10",
            "subject": "5",
            "pattern": "",
        }
        tasks = {"5": {"id": 5, "phase": "v0.6.10", "title": "still on track"}}
        result = _classify_forward_claim(detection, tasks)
        assert result is None  # accurate

    def test_x_phase_is_not_flagged(self):
        """Phase 'v0.6.x' is intentionally vague — never flag as stale."""
        detection = {
            "line_no": 42,
            "raw": "task #5 is scheduled for v0.6.10",
            "version": "v0.6.10",
            "subject": "5",
            "pattern": "",
        }
        tasks = {"5": {"id": 5, "phase": "v0.6.x", "title": "vague phase"}}
        result = _classify_forward_claim(detection, tasks)
        assert result is None


# ---------------------------------------------------------------------------
# Engine end-to-end
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not YAML_AVAILABLE, reason="PyYAML required")
class TestEngineEndToEnd:
    def test_runs_on_empty_claims(self, db_path, tmp_path, monkeypatch):
        claims_path = tmp_path / "claims.yml"
        _write_claims_yml(claims_path, "claims: []\n")
        result = run_readme_truth_audit(
            db_path=db_path, claims_path=claims_path, docs_root=tmp_path
        )
        assert result["claims_audited"] == 0
        assert result["findings_persisted"] == 0

    def test_runs_on_a_simple_verifier(self, db_path, tmp_path, monkeypatch):
        claims_path = tmp_path / "claims.yml"
        _write_claims_yml(
            claims_path,
            (
                "claims:\n"
                "  - id: test-echo\n"
                "    category: stats\n"
                '    claim: "17 things"\n'
                "    sources: [test]\n"
                "    verifier:\n"
                "      type: shell\n"
                "      command: 'echo 17'\n"
                "    status: verified\n"
                "    last_verified_value: 17\n"
            ),
        )
        result = run_readme_truth_audit(
            db_path=db_path, claims_path=claims_path, docs_root=tmp_path
        )
        assert result["claims_audited"] == 1
        assert result["verified"] == 1
        assert result["broken"] == 0

    def test_drift_detected_and_persisted(self, db_path, tmp_path):
        claims_path = tmp_path / "claims.yml"
        _write_claims_yml(
            claims_path,
            (
                "claims:\n"
                "  - id: test-drift\n"
                "    category: stats\n"
                '    claim: "17 things"\n'
                "    sources: [test]\n"
                "    verifier:\n"
                "      type: shell\n"
                "      command: 'echo 18'\n"
                "    status: verified\n"
                "    last_verified_value: 17\n"
            ),
        )
        result = run_readme_truth_audit(
            db_path=db_path, claims_path=claims_path, docs_root=tmp_path
        )
        assert result["drift"] == 1
        assert result["findings_persisted"] == 1

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT evidence_type, raw_data FROM evidence WHERE engine = 'readme_truth_auditor'"
            ).fetchone()
        finally:
            conn.close()
        assert row is not None
        assert "drift" in row[0]

    def test_broken_detected_and_persisted(self, db_path, tmp_path):
        claims_path = tmp_path / "claims.yml"
        _write_claims_yml(
            claims_path,
            (
                "claims:\n"
                "  - id: test-broken\n"
                "    category: stats\n"
                '    claim: "10 things"\n'
                "    sources: [test]\n"
                "    verifier:\n"
                "      type: shell\n"
                "      command: 'echo 100'\n"
                "    status: verified\n"
                "    last_verified_value: 10\n"
            ),
        )
        result = run_readme_truth_audit(
            db_path=db_path, claims_path=claims_path, docs_root=tmp_path
        )
        assert result["broken"] == 1

    def test_never_raises_on_bad_claims(self, db_path, tmp_path):
        """Even with garbage claims.yml the engine returns a summary."""
        claims_path = tmp_path / "claims.yml"
        _write_claims_yml(claims_path, "not: valid: yaml: at: all:\n")
        # Should not raise
        result = run_readme_truth_audit(
            db_path=db_path, claims_path=claims_path, docs_root=tmp_path
        )
        assert isinstance(result, dict)

    def test_missing_claims_yml_returns_empty_summary(self, db_path, tmp_path):
        result = run_readme_truth_audit(
            db_path=db_path, claims_path=tmp_path / "nope.yml", docs_root=tmp_path
        )
        assert result["claims_audited"] == 0


# ---------------------------------------------------------------------------
# docs/ tree broken-reference scan (task #85)
# ---------------------------------------------------------------------------


class TestScanDocsTreeBrokenRefs:
    def _make_repo(self, root: Path) -> Path:
        """Build a tiny repo layout: docs/ pages + one real source file."""
        (root / "docs").mkdir()
        (root / "scripts").mkdir()
        (root / "scripts" / "real.py").write_text("# real\n")
        return root

    def test_empty_when_docs_missing(self, tmp_path):
        # No docs/ directory at all
        result = _scan_docs_tree_broken_refs(docs_root=tmp_path / "nonexistent", repo_root=tmp_path)
        assert result == []

    def test_empty_when_all_refs_resolve(self, tmp_path):
        root = self._make_repo(tmp_path)
        (root / "docs" / "a.md").write_text("See `scripts/real.py` for the happy path.\n")
        result = _scan_docs_tree_broken_refs(docs_root=root / "docs", repo_root=root)
        assert result == []

    def test_detects_broken_py_ref(self, tmp_path):
        root = self._make_repo(tmp_path)
        (root / "docs" / "broken.md").write_text("Look at scripts/ghost.py for examples.\n")
        result = _scan_docs_tree_broken_refs(docs_root=root / "docs", repo_root=root)
        assert len(result) == 1
        assert result[0]["broken_ref"] == "scripts/ghost.py"
        assert result[0]["doc_file"] == "docs/broken.md"
        assert result[0]["line_no"] == 1

    def test_detects_broken_md_and_yml_refs(self, tmp_path):
        root = self._make_repo(tmp_path)
        (root / "docs" / "many.md").write_text(
            "See runbooks/ghost.md and config/ghost.yml for setup.\n"
        )
        result = _scan_docs_tree_broken_refs(docs_root=root / "docs", repo_root=root)
        refs = {r["broken_ref"] for r in result}
        assert refs == {"runbooks/ghost.md", "config/ghost.yml"}

    def test_ignores_urls_and_absolute_paths(self, tmp_path):
        root = self._make_repo(tmp_path)
        (root / "docs" / "noise.md").write_text(
            "See https://example.com/foo.py or /Users/alice/bar.py.\nOr /tmp/cache.yml.\n"
        )
        result = _scan_docs_tree_broken_refs(docs_root=root / "docs", repo_root=root)
        assert result == []

    def test_ignores_exact_noise_tokens(self, tmp_path):
        root = self._make_repo(tmp_path)
        (root / "docs" / "noise.md").write_text("Every package has __init__.py and setup.py.\n")
        result = _scan_docs_tree_broken_refs(docs_root=root / "docs", repo_root=root)
        assert result == []

    def test_caps_at_max_per_run(self, tmp_path):
        root = self._make_repo(tmp_path)
        # Generate more broken refs than MAX_BROKEN_REFS_PER_RUN allows
        spam = "\n".join(f"see scripts/ghost{i}.py" for i in range(MAX_BROKEN_REFS_PER_RUN + 10))
        (root / "docs" / "flood.md").write_text(spam + "\n")
        result = _scan_docs_tree_broken_refs(docs_root=root / "docs", repo_root=root)
        assert len(result) == MAX_BROKEN_REFS_PER_RUN

    def test_walks_nested_subdirs(self, tmp_path):
        root = self._make_repo(tmp_path)
        (root / "docs" / "api").mkdir()
        (root / "docs" / "api" / "nested.md").write_text("nested ref: scripts/ghost.py\n")
        result = _scan_docs_tree_broken_refs(docs_root=root / "docs", repo_root=root)
        assert len(result) == 1
        assert result[0]["doc_file"] == "docs/api/nested.md"

    def test_real_nebula_docs_scan_does_not_raise(self):
        """Smoke test: scanning the real Nebula docs/ tree returns a list."""
        result = _scan_docs_tree_broken_refs()
        assert isinstance(result, list)
        # We don't assert a specific count — it drifts with every ship.
        # Just ensure the shape is right.
        for r in result:
            assert "doc_file" in r
            assert "line_no" in r
            assert "broken_ref" in r
            assert "raw" in r


class TestEngineDocsBrokenRefsIntegration:
    def test_summary_includes_docs_broken_refs_key(self, db_path, tmp_path):
        """The engine's summary dict now carries a docs_broken_refs counter."""
        claims_path = tmp_path / "claims.yml"
        _write_claims_yml(claims_path, "claims: []\n")
        result = run_readme_truth_audit(
            db_path=db_path, claims_path=claims_path, docs_root=tmp_path
        )
        assert "docs_broken_refs" in result
        assert isinstance(result["docs_broken_refs"], int)
