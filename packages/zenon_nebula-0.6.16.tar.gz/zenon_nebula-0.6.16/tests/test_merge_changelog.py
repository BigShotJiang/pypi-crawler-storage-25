# SPDX-License-Identifier: MIT
"""Tests for scripts/merge_changelog.py — git merge driver."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "scripts" / "merge_changelog.py"


def _run(base: Path, ours: Path, theirs: Path) -> int:
    """Invoke the driver the way git would."""
    return subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            str(base),
            str(ours),
            str(theirs),
            "CHANGELOG.md",
        ],
        cwd=REPO_ROOT,
        timeout=10,
    ).returncode


def _write(path: Path, body: str) -> Path:
    path.write_text(body, encoding="utf-8")
    return path


def _header(version_section: str = "") -> str:
    return (
        "# Changelog\n\nAll notable changes to Nebula are documented here.\n\n"
        "Format: [Keep a Changelog]\nVersioning: [Semantic Versioning]\n\n" + version_section
    )


class TestStackEntries:
    def test_both_sides_add_in_added_section(self, tmp_path):
        base = _write(
            tmp_path / "base.md",
            _header() + "## [Unreleased]\n\n### Added\n\n- **Baseline.** shared.\n\n## [0.6.9]\n",
        )
        ours = _write(
            tmp_path / "ours.md",
            _header()
            + "## [Unreleased]\n\n### Added\n\n- **Baseline.** shared.\n\n- **Ours new.**\n\n## [0.6.9]\n",
        )
        theirs = _write(
            tmp_path / "theirs.md",
            _header()
            + "## [Unreleased]\n\n### Added\n\n- **Baseline.** shared.\n\n- **Theirs new.**\n\n## [0.6.9]\n",
        )
        assert _run(base, ours, theirs) == 0
        merged = ours.read_text()
        assert "Ours new" in merged
        assert "Theirs new" in merged
        # Baseline should appear once, not twice
        assert merged.count("Baseline") == 1
        assert "<<<<<<<" not in merged

    def test_different_subheadings_both_kept(self, tmp_path):
        base = _write(tmp_path / "base.md", _header() + "## [Unreleased]\n\n## [0.6.9]\n")
        ours = _write(
            tmp_path / "ours.md",
            _header() + "## [Unreleased]\n\n### Added\n\n- **Our feature.**\n\n## [0.6.9]\n",
        )
        theirs = _write(
            tmp_path / "theirs.md",
            _header() + "## [Unreleased]\n\n### Fixed\n\n- **Their bugfix.**\n\n## [0.6.9]\n",
        )
        assert _run(base, ours, theirs) == 0
        merged = ours.read_text()
        assert "Our feature" in merged
        assert "Their bugfix" in merged
        assert "### Added" in merged
        assert "### Fixed" in merged

    def test_identical_entries_dedup(self, tmp_path):
        """Both sides independently added the same entry — dedup to one."""
        entry = "- **Same entry.** both added.\n"
        base = _write(
            tmp_path / "base.md", _header() + "## [Unreleased]\n\n### Added\n\n## [0.6.9]\n"
        )
        ours = _write(
            tmp_path / "ours.md",
            _header() + f"## [Unreleased]\n\n### Added\n\n{entry}\n## [0.6.9]\n",
        )
        theirs = _write(
            tmp_path / "theirs.md",
            _header() + f"## [Unreleased]\n\n### Added\n\n{entry}\n## [0.6.9]\n",
        )
        assert _run(base, ours, theirs) == 0
        assert ours.read_text().count("Same entry") == 1

    def test_entry_deleted_by_ours_stays_deleted(self, tmp_path):
        """If ours intentionally removed a base entry and theirs kept it,
        we honor ours' deletion."""
        base = _write(
            tmp_path / "base.md",
            _header()
            + "## [Unreleased]\n\n### Added\n\n- **To remove.** obsolete.\n\n## [0.6.9]\n",
        )
        ours = _write(
            tmp_path / "ours.md",
            _header() + "## [Unreleased]\n\n### Added\n\n## [0.6.9]\n",
        )
        theirs = _write(
            tmp_path / "theirs.md",
            _header()
            + "## [Unreleased]\n\n### Added\n\n- **To remove.** obsolete.\n\n## [0.6.9]\n",
        )
        assert _run(base, ours, theirs) == 0
        assert "To remove" not in ours.read_text()

    def test_multiline_entry_preserved(self, tmp_path):
        long = (
            "- **Long entry.** first paragraph.\n"
            "\n"
            "  Second paragraph — this is a multi-line bullet.\n"
        )
        base = _write(
            tmp_path / "base.md", _header() + "## [Unreleased]\n\n### Added\n\n## [0.6.9]\n"
        )
        ours = _write(
            tmp_path / "ours.md",
            _header() + f"## [Unreleased]\n\n### Added\n\n{long}\n## [0.6.9]\n",
        )
        theirs = _write(
            tmp_path / "theirs.md",
            _header() + "## [Unreleased]\n\n### Added\n\n- **Short one.**\n\n## [0.6.9]\n",
        )
        assert _run(base, ours, theirs) == 0
        merged = ours.read_text()
        assert "Long entry" in merged
        assert "Second paragraph" in merged
        assert "Short one" in merged


class TestGracefulFallback:
    def test_missing_unreleased_exits_nonzero(self, tmp_path):
        """If neither side has [Unreleased], git should see the conflict."""
        base = _write(tmp_path / "base.md", "# Just a doc\n")
        ours = _write(tmp_path / "ours.md", "# Just a doc\n# Ours\n")
        theirs = _write(tmp_path / "theirs.md", "# Just a doc\n# Theirs\n")
        assert _run(base, ours, theirs) == 1

    def test_only_one_side_has_unreleased(self, tmp_path):
        base = _write(tmp_path / "base.md", "# Changelog\n")
        ours = _write(
            tmp_path / "ours.md",
            _header() + "## [Unreleased]\n\n### Added\n\n- **Ours.**\n",
        )
        theirs = _write(tmp_path / "theirs.md", "# Changelog\n\n## [0.6.9]\n")
        # Returns 1 so git emits default markers — less risky than guessing
        assert _run(base, ours, theirs) == 1
