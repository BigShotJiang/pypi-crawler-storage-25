# SPDX-License-Identifier: MIT
"""Tests for scripts/cgc_audit.py (task #95, v0.6.10).

Validates the allowlist parser, drift detection, staleness check,
and YAML fallback parser. No real CGC subprocess calls — every test
drives `audit()` directly with hand-crafted findings + allowlists.
"""

from __future__ import annotations

import json
import sys
from datetime import date, timedelta
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "scripts"))

import cgc_audit


def _write_allowlist(tmp_path: Path, body: str) -> Path:
    """Write a YAML allowlist into tmp_path and return the path."""
    path = tmp_path / "cgc-ignore.yaml"
    path.write_text(body, encoding="utf-8")
    return path


class TestLoadAllowlistMissingFile:
    def test_missing_file_returns_empty(self, tmp_path):
        al = cgc_audit.load_allowlist(tmp_path / "nope.yaml")
        assert al.version == 1
        assert al.entries == []


class TestLoadAllowlistEmpty:
    def test_empty_entries_list(self, tmp_path):
        path = _write_allowlist(
            tmp_path,
            """\
version: 1
updated: 2026-04-13
entries: []
""",
        )
        al = cgc_audit.load_allowlist(path)
        assert al.version == 1
        assert al.updated == "2026-04-13"
        assert al.entries == []


class TestLoadAllowlistPopulated:
    def test_single_entry(self, tmp_path):
        path = _write_allowlist(
            tmp_path,
            """\
version: 1
updated: 2026-04-13
entries:
  - function: core.foo.bar
    category: dispatch_table
    reason: "Registered in HANDLERS"
    last_reviewed: 2026-04-13
""",
        )
        al = cgc_audit.load_allowlist(path)
        assert len(al.entries) == 1
        e = al.entries[0]
        assert e.function == "core.foo.bar"
        assert e.category == "dispatch_table"
        assert e.reason == "Registered in HANDLERS"
        assert e.last_reviewed == "2026-04-13"

    def test_multiple_entries(self, tmp_path):
        path = _write_allowlist(
            tmp_path,
            """\
version: 1
updated: 2026-04-13
entries:
  - function: core.a.first
    category: dispatch_table
    reason: "r1"
    last_reviewed: 2026-04-01
  - function: core.b.second
    category: library_template
    reason: "r2"
    last_reviewed: 2026-04-02
""",
        )
        al = cgc_audit.load_allowlist(path)
        assert len(al.entries) == 2
        assert al.functions() == {"core.a.first", "core.b.second"}

    def test_by_function_lookup(self, tmp_path):
        path = _write_allowlist(
            tmp_path,
            """\
version: 1
entries:
  - function: core.a.first
    category: dispatch_table
    reason: "r1"
    last_reviewed: 2026-04-01
""",
        )
        al = cgc_audit.load_allowlist(path)
        hit = al.by_function("core.a.first")
        assert hit is not None
        assert hit.reason == "r1"
        assert al.by_function("core.unknown") is None


class TestAllowlistEntryStaleness:
    def test_fresh_not_stale(self):
        today = date.today().isoformat()
        e = cgc_audit.AllowlistEntry(
            function="x", category="dispatch_table", reason="", last_reviewed=today
        )
        assert e.is_stale() is False

    def test_within_cutoff_not_stale(self):
        d = (date.today() - timedelta(days=100)).isoformat()
        e = cgc_audit.AllowlistEntry(
            function="x", category="dispatch_table", reason="", last_reviewed=d
        )
        assert e.is_stale() is False

    def test_beyond_cutoff_stale(self):
        d = (date.today() - timedelta(days=400)).isoformat()
        e = cgc_audit.AllowlistEntry(
            function="x", category="dispatch_table", reason="", last_reviewed=d
        )
        assert e.is_stale() is True

    def test_unparseable_date_treated_as_stale(self):
        e = cgc_audit.AllowlistEntry(
            function="x", category="dispatch_table", reason="", last_reviewed="not-a-date"
        )
        assert e.is_stale() is True


class TestDottedPathFor:
    def test_converts_path_and_fn_name(self):
        finding = {
            "function_name": "_pattern_upstream_breaking",
            "path": str(REPO_ROOT / "core" / "hypotheses" / "engine.py"),
        }
        assert (
            cgc_audit.dotted_path_for(finding)
            == "core.hypotheses.engine._pattern_upstream_breaking"
        )

    def test_strips_dot_py(self):
        finding = {
            "function_name": "foo",
            "path": str(REPO_ROOT / "core" / "bar.py"),
        }
        assert cgc_audit.dotted_path_for(finding) == "core.bar.foo"

    def test_missing_fields_safe(self):
        assert cgc_audit.dotted_path_for({}) == ""
        assert cgc_audit.dotted_path_for({"function_name": "x"}) == "x"


class TestAudit:
    def _mk_finding(self, dotted: str) -> dict:
        """Build a CGC-shaped finding whose dotted path == `dotted`."""
        parts = dotted.split(".")
        fn_name = parts[-1]
        rel_parts = parts[:-1]
        path = REPO_ROOT.joinpath(*rel_parts).with_suffix(".py")
        return {"function_name": fn_name, "path": str(path)}

    def test_no_findings_clean(self, tmp_path):
        al = cgc_audit.Allowlist(version=1, updated="", entries=[])
        code, report = cgc_audit.audit(allowlist=al, findings=[])
        assert code == 0
        assert report["drift"] == []
        assert report["stale"] == []

    def test_flagged_not_allowlisted_is_drift(self, tmp_path):
        al = cgc_audit.Allowlist(version=1, updated="", entries=[])
        finding = self._mk_finding("core.foo.bar")
        code, report = cgc_audit.audit(allowlist=al, findings=[finding])
        assert code == 1
        assert report["drift"] == ["core.foo.bar"]

    def test_flagged_and_allowlisted_is_clean(self, tmp_path):
        today = date.today().isoformat()
        al = cgc_audit.Allowlist(
            version=1,
            updated="",
            entries=[
                cgc_audit.AllowlistEntry(
                    function="core.foo.bar",
                    category="dispatch_table",
                    reason="r",
                    last_reviewed=today,
                )
            ],
        )
        finding = self._mk_finding("core.foo.bar")
        code, report = cgc_audit.audit(allowlist=al, findings=[finding])
        assert code == 0
        assert report["drift"] == []

    def test_drift_sorted_deterministically(self, tmp_path):
        al = cgc_audit.Allowlist(version=1, updated="", entries=[])
        findings = [
            self._mk_finding("core.zeta.one"),
            self._mk_finding("core.alpha.two"),
            self._mk_finding("core.mu.three"),
        ]
        _, report = cgc_audit.audit(allowlist=al, findings=findings)
        assert report["drift"] == sorted(report["drift"])

    def test_strict_mode_flags_stale_entries(self, tmp_path):
        old = (date.today() - timedelta(days=400)).isoformat()
        al = cgc_audit.Allowlist(
            version=1,
            updated="",
            entries=[
                cgc_audit.AllowlistEntry(
                    function="core.foo.bar",
                    category="dispatch_table",
                    reason="r",
                    last_reviewed=old,
                )
            ],
        )
        # Not in findings — but strict mode still flags the stale entry
        code, report = cgc_audit.audit(allowlist=al, findings=[], strict=True)
        assert code == 1
        assert report["stale"] == ["core.foo.bar"]

    def test_non_strict_ignores_stale(self, tmp_path):
        old = (date.today() - timedelta(days=400)).isoformat()
        al = cgc_audit.Allowlist(
            version=1,
            updated="",
            entries=[
                cgc_audit.AllowlistEntry(
                    function="core.foo.bar",
                    category="dispatch_table",
                    reason="r",
                    last_reviewed=old,
                )
            ],
        )
        code, report = cgc_audit.audit(allowlist=al, findings=[], strict=False)
        assert code == 0
        assert report["stale"] == ["core.foo.bar"]  # still reported, but not failing


class TestRunCGCScanFromFile:
    def test_reads_json_file(self, tmp_path):
        path = tmp_path / "findings.json"
        path.write_text(
            json.dumps(
                [
                    {"function_name": "foo", "path": "core/bar.py"},
                ]
            )
        )
        result = cgc_audit.run_cgc_scan(from_file=path)
        assert len(result) == 1
        assert result[0]["function_name"] == "foo"

    def test_empty_list(self, tmp_path):
        path = tmp_path / "empty.json"
        path.write_text("[]")
        assert cgc_audit.run_cgc_scan(from_file=path) == []


class TestStdlibYamlParser:
    def test_parses_empty_entries_list(self):
        text = """\
version: 1
updated: 2026-04-13
entries: []
"""
        result = cgc_audit._stdlib_yaml_parse(text)
        assert result["version"] == 1
        assert result["entries"] == []

    def test_parses_single_entry(self):
        text = """\
version: 1
entries:
  - function: core.a.b
    category: dispatch_table
    reason: "r"
    last_reviewed: 2026-04-13
"""
        result = cgc_audit._stdlib_yaml_parse(text)
        assert len(result["entries"]) == 1
        assert result["entries"][0]["function"] == "core.a.b"
        assert result["entries"][0]["last_reviewed"] == "2026-04-13"

    def test_parses_multiple_entries(self):
        text = """\
entries:
  - function: x.y.z
    category: library_template
    reason: r1
    last_reviewed: 2026-01-01
  - function: a.b.c
    category: reexport_shim
    reason: r2
    last_reviewed: 2026-02-01
"""
        result = cgc_audit._stdlib_yaml_parse(text)
        assert len(result["entries"]) == 2

    def test_skips_comments_and_blanks(self):
        text = """\
# top comment
version: 1

# another
entries:
  # inline
  - function: a.b
    category: dispatch_table
    reason: r
    last_reviewed: 2026-04-13
"""
        result = cgc_audit._stdlib_yaml_parse(text)
        assert result["version"] == 1
        assert len(result["entries"]) == 1


class TestCoerceScalar:
    def test_empty_is_none(self):
        assert cgc_audit._coerce_scalar("") is None
        assert cgc_audit._coerce_scalar("null") is None

    def test_booleans(self):
        assert cgc_audit._coerce_scalar("true") is True
        assert cgc_audit._coerce_scalar("false") is False

    def test_integers(self):
        assert cgc_audit._coerce_scalar("42") == 42

    def test_quoted_strings(self):
        assert cgc_audit._coerce_scalar('"hello"') == "hello"
        assert cgc_audit._coerce_scalar("'world'") == "world"

    def test_unquoted_string(self):
        assert cgc_audit._coerce_scalar("core.foo.bar") == "core.foo.bar"
