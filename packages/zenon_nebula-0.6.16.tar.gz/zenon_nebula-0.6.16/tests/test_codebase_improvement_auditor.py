# SPDX-License-Identifier: MIT
"""Tests for domains/self_maintenance/engines/codebase_improvement_auditor.py.

Task #93 (v0.6.11). Engine audits Nebula's own code for complexity
drift. Tests cover:

- Pure-AST cyclomatic complexity counting (matches the radon
  definition without depending on radon).
- File sampling determinism (same day → same sample).
- Graceful degradation when targets are missing.
- Frozen-dataclass semantics on ``ComplexityFinding``.
- Finding-body shape (WHAT / SO WHAT / NOW WHAT).
- Entry point is zero-required-arg callable for the scheduler.
"""

from __future__ import annotations

import ast
import inspect
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from domains.self_maintenance.engines import codebase_improvement_auditor as cia

# ---------------------------------------------------------------------------
# Import smoke
# ---------------------------------------------------------------------------


class TestImportSmoke:
    def test_module_imports(self):
        assert hasattr(cia, "run_codebase_improvement_auditor")

    def test_entry_point_is_zero_required_arg(self):
        sig = inspect.signature(cia.run_codebase_improvement_auditor)
        required = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.name not in ("self", "db_path")
            and p.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.POSITIONAL_ONLY,
            )
        ]
        assert required == []


# ---------------------------------------------------------------------------
# Cyclomatic complexity counting
# ---------------------------------------------------------------------------


class TestCyclomaticComplexity:
    def _cc(self, source: str) -> int:
        tree = ast.parse(source)
        # Find the first FunctionDef in the tree
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                return cia._cyclomatic_complexity(node)
        raise ValueError("no function in source")

    def test_trivial_function_is_one(self):
        assert self._cc("def f():\n    return 1\n") == 1

    def test_single_if_adds_one(self):
        assert self._cc("def f(x):\n    if x:\n        return 1\n") == 2

    def test_if_else_adds_one(self):
        # Only the `if` counts; the else branch is the not-taken path
        assert (
            self._cc("def f(x):\n    if x:\n        return 1\n    else:\n        return 0\n") == 2
        )

    def test_nested_ifs(self):
        src = "def f(x, y):\n    if x:\n        if y:\n            return 1\n    return 0\n"
        assert self._cc(src) == 3

    def test_for_loop_adds_one(self):
        assert self._cc("def f(xs):\n    for x in xs:\n        pass\n") == 2

    def test_while_loop_adds_one(self):
        assert self._cc("def f():\n    while True:\n        break\n") == 2

    def test_except_handler_adds_one(self):
        src = "def f():\n    try:\n        pass\n    except ValueError:\n        pass\n"
        assert self._cc(src) == 2

    def test_boolean_and_adds_branches(self):
        # `a and b and c` adds 2 (operators beyond the first)
        src = "def f(a, b, c):\n    return a and b and c\n"
        assert self._cc(src) == 3

    def test_ternary_adds_one(self):
        src = "def f(x):\n    return 1 if x else 0\n"
        assert self._cc(src) == 2

    def test_listcomp_with_filter_adds(self):
        src = "def f(xs):\n    return [x for x in xs if x > 0]\n"
        # 1 base + 1 generator + 1 if filter = 3
        assert self._cc(src) == 3

    def test_above_threshold_function(self):
        # Build a function with many branches to exceed threshold 15
        body = "    if x == 0: return 0\n"
        for i in range(1, 20):
            body += f"    if x == {i}: return {i}\n"
        src = f"def f(x):\n{body}    return -1\n"
        assert self._cc(src) > cia.COMPLEXITY_THRESHOLD


# ---------------------------------------------------------------------------
# _audit_file_complexity
# ---------------------------------------------------------------------------


class TestAuditFileComplexity:
    def test_returns_empty_for_simple_file(self, tmp_path):
        f = tmp_path / "simple.py"
        f.write_text("def foo():\n    return 1\n")
        assert cia._audit_file_complexity(f) == []

    def test_flags_complex_function(self, tmp_path):
        f = tmp_path / "complex.py"
        body = "    if x == 0: return 0\n"
        for i in range(1, 20):
            body += f"    if x == {i}: return {i}\n"
        f.write_text(f"def big_branchy(x):\n{body}    return -1\n")
        findings = cia._audit_file_complexity(f)
        assert len(findings) == 1
        assert findings[0].function_name == "big_branchy"
        assert findings[0].complexity > cia.COMPLEXITY_THRESHOLD

    def test_skips_simple_functions_in_mixed_file(self, tmp_path):
        f = tmp_path / "mixed.py"
        body = "    if x == 0: return 0\n"
        for i in range(1, 20):
            body += f"    if x == {i}: return {i}\n"
        f.write_text(
            f"def trivial():\n    return 1\n\n"
            f"def big_branchy(x):\n{body}    return -1\n\n"
            f"def also_trivial():\n    return 2\n"
        )
        findings = cia._audit_file_complexity(f)
        # Only big_branchy should be flagged
        assert len(findings) == 1
        assert findings[0].function_name == "big_branchy"

    def test_handles_syntax_error_silently(self, tmp_path):
        f = tmp_path / "bad.py"
        f.write_text("def foo(:\n    pass\n")
        assert cia._audit_file_complexity(f) == []

    def test_handles_missing_file(self, tmp_path):
        assert cia._audit_file_complexity(tmp_path / "nope.py") == []


# ---------------------------------------------------------------------------
# _sample_audit_targets
# ---------------------------------------------------------------------------


class TestSampleAuditTargets:
    def test_deterministic_per_day(self):
        # Two calls on the same UTC day should return the same sample
        # (the seed is the YYYY-MM-DD string). Use a small sample so
        # the test runs fast against the real Nebula tree.
        a = cia._sample_audit_targets(sample_size=5)
        b = cia._sample_audit_targets(sample_size=5)
        assert a == b

    def test_excludes_test_files(self):
        targets = cia._sample_audit_targets(sample_size=200)
        for t in targets:
            assert not t.name.startswith("test_"), f"test file leaked into sample: {t}"

    def test_only_python_files(self):
        targets = cia._sample_audit_targets(sample_size=200)
        for t in targets:
            assert t.suffix == ".py", f"non-Python file in sample: {t}"

    def test_only_audit_roots(self):
        targets = cia._sample_audit_targets(sample_size=200)
        roots = set(cia.DEFAULT_AUDIT_ROOTS)
        for t in targets:
            try:
                rel = t.relative_to(cia.REPO_ROOT)
            except ValueError:
                pytest.fail(f"target {t} is outside repo root")
            assert rel.parts[0] in roots, f"target {t} outside audit roots {roots}"


# ---------------------------------------------------------------------------
# Finding body shape
# ---------------------------------------------------------------------------


class TestFindingBody:
    def test_format_complexity_finding(self):
        finding = cia.ComplexityFinding(
            file_path=str(cia.REPO_ROOT / "core" / "x.py"),
            function_name="big_function",
            line_number=42,
            complexity=22,
        )
        what, so_what, now_what = cia._format_complexity_finding(finding)
        assert "big_function" in what
        assert "22" in what  # the complexity number
        assert "15" in what  # the threshold
        # SO WHAT explains the consequence
        assert "test" in so_what.lower() or "reason" in so_what.lower()
        # NOW WHAT gives a concrete next step
        assert "Refactor" in now_what or "comment" in now_what.lower()

    def test_uses_relative_path_when_inside_repo(self):
        finding = cia.ComplexityFinding(
            file_path=str(cia.REPO_ROOT / "core" / "foo.py"),
            function_name="x",
            line_number=1,
            complexity=20,
        )
        what, _, _ = cia._format_complexity_finding(finding)
        # Should NOT contain the absolute path
        assert "/Users/" not in what
        assert "core/foo.py" in what


# ---------------------------------------------------------------------------
# ComplexityFinding dataclass
# ---------------------------------------------------------------------------


class TestComplexityFinding:
    def test_is_frozen(self):
        f = cia.ComplexityFinding(
            file_path="/x.py", function_name="f", line_number=1, complexity=20
        )
        from dataclasses import FrozenInstanceError

        with pytest.raises(FrozenInstanceError):
            f.complexity = 99

    def test_threshold_default(self):
        f = cia.ComplexityFinding(
            file_path="/x.py", function_name="f", line_number=1, complexity=20
        )
        assert f.threshold == cia.COMPLEXITY_THRESHOLD


# ---------------------------------------------------------------------------
# run_codebase_improvement_auditor end-to-end
# ---------------------------------------------------------------------------


class TestRunEndToEnd:
    def test_returns_summary_dict(self, db_path):
        result = cia.run_codebase_improvement_auditor(db_path=db_path, sample_size=3)
        assert result["engine"] == "codebase_improvement_auditor"
        assert "files_sampled" in result
        assert "complexity_findings" in result
        assert isinstance(result["files_sampled"], int)
        assert isinstance(result["complexity_findings"], int)

    def test_records_backend_name(self, db_path):
        result = cia.run_codebase_improvement_auditor(db_path=db_path, sample_size=3)
        # Either "cgc" or "grep" — both are valid; it just records which.
        assert result.get("backend") in ("cgc", "grep")
