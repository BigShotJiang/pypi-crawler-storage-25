# SPDX-License-Identifier: MIT
"""Tests for core/extensions/llm_provider.py — task #62 Phase 3/4.

ABC + registry + active-provider resolution. Does NOT exercise the
real XAIProvider.call path (that would require XAI_API_KEY); we
smoke-test the wrapper shape by patching core.llm_provider.call_llm.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from core.extensions.llm_provider import (
    LLMProvider,
    LLMResponse,
    XAIProvider,
    clear_registry,
    get_active_provider,
    get_provider,
    list_providers,
    load_active_provider_name,
    register_provider,
    resolve_llm_config_path,
)


@pytest.fixture(autouse=True)
def _clean_registry():
    """Every test runs against a fresh registry.

    We re-register XAIProvider after clearing, because the module's
    import-time side effect did that once, and we want each test to
    start from the baseline state (one built-in provider)."""
    clear_registry()
    register_provider(XAIProvider())
    yield
    clear_registry()
    register_provider(XAIProvider())


class _FakeProvider(LLMProvider):
    name = "fake"

    def call(
        self, prompt, *, system="", model=None, max_tokens=4000, temperature=1.0, json_output=False
    ):
        return LLMResponse(text=f"echo: {prompt}", model="fake-1", provider="fake")

    def list_models(self):
        return ["fake-1", "fake-2"]

    def default_best(self):
        return "fake-1"

    def default_cheapest(self):
        return "fake-2"


class _EmptyNameProvider(LLMProvider):
    name = ""

    def call(self, prompt, **kw):
        return None

    def list_models(self):
        return []

    def default_best(self):
        return ""

    def default_cheapest(self):
        return ""


class TestRegistry:
    def test_xai_registered_by_default(self):
        assert "xai" in list_providers()
        assert isinstance(get_provider("xai"), XAIProvider)

    def test_register_and_retrieve(self):
        register_provider(_FakeProvider())
        assert "fake" in list_providers()
        assert get_provider("fake").default_best() == "fake-1"

    def test_register_empty_name_rejected(self):
        with pytest.raises(ValueError, match="non-empty"):
            register_provider(_EmptyNameProvider())

    def test_get_unknown_returns_none(self):
        assert get_provider("nonexistent") is None

    def test_list_providers_sorted(self):
        register_provider(_FakeProvider())
        names = list_providers()
        assert names == sorted(names)

    def test_register_replaces_same_name(self):
        class _XAIOverride(XAIProvider):
            def default_best(self):
                return "override-best"

        register_provider(_XAIOverride())
        assert get_provider("xai").default_best() == "override-best"


class TestResolveConfigPath:
    def test_default_path(self, monkeypatch):
        monkeypatch.delenv("NEBULA_LLM_CONFIG_PATH", raising=False)
        monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
        p = resolve_llm_config_path()
        assert p.name == "llm.toml"
        assert p.parent.name == "nebula"

    def test_explicit_override(self, monkeypatch, tmp_path):
        monkeypatch.setenv("NEBULA_LLM_CONFIG_PATH", str(tmp_path / "c.toml"))
        assert resolve_llm_config_path() == tmp_path / "c.toml"

    def test_xdg_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NEBULA_LLM_CONFIG_PATH", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        assert resolve_llm_config_path() == tmp_path / "nebula" / "llm.toml"


class TestLoadActiveProviderName:
    def test_missing_file_defaults_to_xai(self, tmp_path):
        assert load_active_provider_name(tmp_path / "nope.toml") == "xai"

    def test_reads_provider_key(self, tmp_path):
        f = tmp_path / "llm.toml"
        f.write_text('[llm]\nprovider = "fake"\n')
        assert load_active_provider_name(f) == "fake"

    def test_malformed_toml_defaults_to_xai(self, tmp_path):
        f = tmp_path / "llm.toml"
        f.write_text("not valid [[[")
        assert load_active_provider_name(f) == "xai"

    def test_missing_llm_section_defaults_to_xai(self, tmp_path):
        f = tmp_path / "llm.toml"
        f.write_text('[other]\nvalue = "x"\n')
        assert load_active_provider_name(f) == "xai"

    def test_empty_provider_name_rejected(self, tmp_path):
        f = tmp_path / "llm.toml"
        f.write_text('[llm]\nprovider = ""\n')
        assert load_active_provider_name(f) == "xai"


class TestGetActiveProvider:
    def test_default_returns_xai(self, monkeypatch):
        monkeypatch.setenv("NEBULA_LLM_CONFIG_PATH", "/does/not/exist")
        provider = get_active_provider()
        assert isinstance(provider, XAIProvider)

    def test_configured_provider_returned(self, tmp_path, monkeypatch):
        f = tmp_path / "llm.toml"
        f.write_text('[llm]\nprovider = "fake"\n')
        monkeypatch.setenv("NEBULA_LLM_CONFIG_PATH", str(f))
        register_provider(_FakeProvider())
        provider = get_active_provider()
        assert isinstance(provider, _FakeProvider)

    def test_unknown_configured_provider_returns_none(self, tmp_path, monkeypatch):
        f = tmp_path / "llm.toml"
        f.write_text('[llm]\nprovider = "not_registered"\n')
        monkeypatch.setenv("NEBULA_LLM_CONFIG_PATH", str(f))
        provider = get_active_provider()
        assert provider is None


class TestXAIProviderWrapper:
    def test_call_adapts_call_llm_result(self):
        fake_result = {
            "text": "hello",
            "model": "grok-4",
            "input_tokens": 10,
            "output_tokens": 5,
            "cost_usd": 0.001,
            "cached": False,
            "extra_key": "preserved",
        }
        with patch("core.llm_provider.call_llm", return_value=fake_result):
            resp = XAIProvider().call("prompt")
        assert resp is not None
        assert resp.text == "hello"
        assert resp.model == "grok-4"
        assert resp.input_tokens == 10
        assert resp.provider == "xai"
        assert resp.extra == {"extra_key": "preserved"}

    def test_call_returns_none_on_failure(self):
        with patch("core.llm_provider.call_llm", return_value=None):
            assert XAIProvider().call("x") is None

    def test_list_models_includes_known_grok(self):
        models = XAIProvider().list_models()
        assert any("grok" in m for m in models)

    def test_default_best_and_cheapest_nonempty(self):
        p = XAIProvider()
        assert p.default_best()
        assert p.default_cheapest()


class TestABCEnforcement:
    def test_cannot_instantiate_incomplete_subclass(self):
        # Subclass missing every abstractmethod → TypeError on instantiation.
        class Incomplete(LLMProvider):
            name = "incomplete"

        with pytest.raises(TypeError):
            Incomplete()
