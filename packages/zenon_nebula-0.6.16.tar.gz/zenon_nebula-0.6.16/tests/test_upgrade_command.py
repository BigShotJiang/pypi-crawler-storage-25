# SPDX-License-Identifier: MIT
"""Tests for core.upgrade_command — task #50 Track 2 Phase B.

Pins the upgrade/rollback contract:
- pip invocation happens once with the right version pin
- previous-version stamp is written on upgrade, read on rollback, cleared
  after rollback
- failure paths (no update available, pip non-zero, no stamp) return
  ok=False and a readable message
- dry-run never invokes pip
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import upgrade_command as uc
from core.upgrade_check import UpgradeStatus


def _status(current: str, latest: str | None, update: bool) -> UpgradeStatus:
    return UpgradeStatus(
        current_version=current,
        latest_version=latest,
        update_available=update,
        major_bump=False,
        minor_bump=False,
        patch_bump=update,
        checked_at=None,
        cache_hit=False,
        notes=None,
    )


def _pip_ok() -> MagicMock:
    m = MagicMock()
    m.returncode = 0
    m.stdout = "Successfully installed zenon-nebula-0.6.11"
    m.stderr = ""
    return m


def _pip_fail(stderr: str = "ERROR: version not found") -> MagicMock:
    m = MagicMock()
    m.returncode = 1
    m.stdout = ""
    m.stderr = stderr
    return m


class TestUpgradeToLatest:
    def test_no_update_available_returns_noop(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        with patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.10", False)):
            result = uc.upgrade_to_latest()
        assert result.action == "no_op"
        assert result.ok is True
        assert result.from_version == "0.6.10"

    def test_unreachable_pypi_returns_noop_with_message(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        with patch.object(uc, "check_for_update", return_value=_status("0.6.10", None, False)):
            result = uc.upgrade_to_latest()
        assert result.action == "no_op"
        assert result.ok is True
        assert "Could not determine" in result.message

    def test_dry_run_does_not_invoke_pip(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        with (
            patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.11", True)),
            patch.object(uc.subprocess, "run") as run,
        ):
            result = uc.upgrade_to_latest(dry_run=True)
        assert result.action == "dry_run"
        assert result.ok is True
        assert result.to_version == "0.6.11"
        assert run.call_count == 0
        # Stamp must NOT be written in dry-run.
        assert not uc._previous_version_path().exists()

    def test_happy_path_upgrades_and_stamps(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        with (
            patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.11", True)),
            patch.object(uc.subprocess, "run", return_value=_pip_ok()) as run,
        ):
            result = uc.upgrade_to_latest()
        assert result.ok is True
        assert result.action == "upgrade"
        assert result.from_version == "0.6.10"
        assert result.to_version == "0.6.11"
        # pip install --upgrade zenon-nebula==0.6.11
        cmd = run.call_args[0][0]
        assert "--upgrade" in cmd
        assert "zenon-nebula==0.6.11" in cmd
        # Stamp written with the PREVIOUS version so rollback has a target.
        stamp = uc._previous_version_path()
        assert stamp.exists()
        data = json.loads(stamp.read_text())
        assert data["previous_version"] == "0.6.10"

    def test_pip_failure_surfaces_stderr(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        with (
            patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.11", True)),
            patch.object(
                uc.subprocess,
                "run",
                return_value=_pip_fail("ERROR: permission denied"),
            ),
        ):
            result = uc.upgrade_to_latest()
        assert result.ok is False
        assert result.action == "upgrade"
        assert "permission denied" in result.pip_stderr
        # Stamp must NOT be written when upgrade failed — else a later
        # rollback would aim at a version we never actually left.
        assert not uc._previous_version_path().exists()


class TestRollbackToPrevious:
    def test_no_stamp_fails_loudly(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        result = uc.rollback_to_previous()
        assert result.ok is False
        assert result.action == "no_op"
        assert "No previous version stamped" in result.message

    def test_happy_path_rolls_back_and_clears_stamp(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        uc._stamp_previous_version("0.6.9")
        assert uc._previous_version_path().exists()
        with patch.object(uc.subprocess, "run", return_value=_pip_ok()) as run:
            result = uc.rollback_to_previous()
        assert result.ok is True
        assert result.action == "rollback"
        assert result.to_version == "0.6.9"
        # Pinned, no --upgrade flag.
        cmd = run.call_args[0][0]
        assert "zenon-nebula==0.6.9" in cmd
        assert "--upgrade" not in cmd
        # Stamp cleared so double-rollback can't silently drift further back.
        assert not uc._previous_version_path().exists()

    def test_dry_run_does_not_clear_stamp(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        uc._stamp_previous_version("0.6.9")
        with patch.object(uc.subprocess, "run") as run:
            result = uc.rollback_to_previous(dry_run=True)
        assert result.ok is True
        assert result.action == "dry_run"
        assert run.call_count == 0
        assert uc._previous_version_path().exists()

    def test_pip_failure_preserves_stamp(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        uc._stamp_previous_version("0.6.9")
        with patch.object(uc.subprocess, "run", return_value=_pip_fail()):
            result = uc.rollback_to_previous()
        assert result.ok is False
        assert uc._previous_version_path().exists()


class TestPipEnvRouting:
    def test_nebula_pip_args_honored(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        monkeypatch.setenv("NEBULA_PIP_ARGS", "--index-url https://my.mirror/simple")
        with (
            patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.11", True)),
            patch.object(uc.subprocess, "run", return_value=_pip_ok()) as run,
        ):
            uc.upgrade_to_latest()
        cmd = run.call_args[0][0]
        assert "--index-url" in cmd
        assert "https://my.mirror/simple" in cmd

    def test_xdg_cache_home_respected(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "custom"))
        stamp = uc._previous_version_path()
        assert str(stamp).startswith(str(tmp_path / "custom"))
        assert stamp.name == "previous_version.json"


class TestFormatResult:
    def test_ok_result_has_no_stderr_tail(self):
        result = uc.UpgradeResult(
            action="upgrade",
            ok=True,
            from_version="0.6.10",
            to_version="0.6.11",
            message="Upgraded 0.6.10 -> 0.6.11.",
        )
        out = uc.format_result(result)
        assert "Status:   ok" in out
        assert "From:     0.6.10" in out
        assert "To:       0.6.11" in out
        assert "pip stderr" not in out

    def test_failed_result_includes_stderr_tail(self):
        result = uc.UpgradeResult(
            action="upgrade",
            ok=False,
            from_version="0.6.10",
            to_version="0.6.11",
            message="pip install failed.",
            pip_stderr="ERROR: something broke",
        )
        out = uc.format_result(result)
        assert "Status:   FAILED" in out
        assert "pip stderr" in out
        assert "something broke" in out


class TestBrokenVersionGuard:
    """Task #50 follow-up: refuse to upgrade to a known-broken version."""

    def _write_broken_list(self, content: str, tmp_path):
        """Point _is_version_broken at a tmp file for the test."""
        broken_file = tmp_path / "broken_versions.txt"
        broken_file.write_text(content, encoding="utf-8")

        # Patch the Path inside _is_version_broken. The function
        # derives the file path from __file__; monkeypatching the
        # module's Path would be brittle, so we override the whole
        # function-level Path via a lambda wrapper.
        def _wrapped(version: str):
            if not broken_file.is_file():
                return False, ""
            target = version.strip()
            for raw in broken_file.read_text().splitlines():
                if "#" in raw:
                    spec, _, comment = raw.partition("#")
                    spec, comment = spec.strip(), comment.strip()
                else:
                    spec, comment = raw.strip(), ""
                if spec and spec == target:
                    return True, comment or "version listed as broken"
            return False, ""

        return _wrapped

    def test_broken_version_refused_without_force(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        wrapper = self._write_broken_list("0.6.11  # smoke crash\n", tmp_path)
        with (
            patch.object(uc, "_is_version_broken", side_effect=wrapper),
            patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.11", True)),
            patch.object(uc.subprocess, "run") as run,
        ):
            result = uc.upgrade_to_latest()
        assert result.action == "refused"
        assert result.ok is False
        assert "0.6.11" in result.message
        assert "smoke crash" in result.message
        # Critical: pip was never invoked.
        run.assert_not_called()

    def test_broken_version_allowed_with_force(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        wrapper = self._write_broken_list("0.6.11\n", tmp_path)
        with (
            patch.object(uc, "_is_version_broken", side_effect=wrapper),
            patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.11", True)),
            patch.object(uc.subprocess, "run", return_value=_pip_ok()),
        ):
            result = uc.upgrade_to_latest(force=True)
        assert result.action == "upgrade"
        assert result.ok is True

    def test_missing_broken_file_is_no_op(self, tmp_path, monkeypatch):
        """No broken_versions.txt → every upgrade proceeds normally."""
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
        with (
            patch.object(uc, "check_for_update", return_value=_status("0.6.10", "0.6.11", True)),
            patch.object(uc.subprocess, "run", return_value=_pip_ok()),
        ):
            result = uc.upgrade_to_latest()
        # Happy path — not refused. (The real file may or may not
        # exist on disk; the test just confirms the guard doesn't
        # auto-refuse when no match.)
        assert result.ok is True
        assert result.action == "upgrade"

    def test_comment_only_lines_ignored(self, tmp_path):
        """Comments + blanks must not match any version."""
        wrapper = self._write_broken_list(
            "# header comment\n\n# another\n0.6.11  # actually broken\n",
            tmp_path,
        )
        is_broken, reason = wrapper("0.0.0")  # unrelated version
        assert is_broken is False
        is_broken, reason = wrapper("0.6.11")
        assert is_broken is True
        assert reason == "actually broken"
