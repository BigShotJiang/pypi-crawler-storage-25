# SPDX-License-Identifier: MIT
"""Tests for core/extensions/overrides.py — task #61 Phase G1 (partial)."""

from __future__ import annotations

from pathlib import Path

import pytest

from core.domain_registry import EngineDefinition
from core.extensions.overrides import (
    EngineOverrides,
    apply_overrides,
    load_overrides,
    resolve_overrides_path,
)


class TestResolveOverridesPath:
    def test_default_path(self, monkeypatch):
        monkeypatch.delenv("NEBULA_OVERRIDES_PATH", raising=False)
        monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
        p = resolve_overrides_path()
        assert p.name == "overrides.toml"
        assert p.parent.name == "nebula"

    def test_explicit_env_wins(self, monkeypatch, tmp_path):
        monkeypatch.setenv("NEBULA_OVERRIDES_PATH", str(tmp_path / "custom.toml"))
        assert resolve_overrides_path() == tmp_path / "custom.toml"

    def test_xdg_config_home(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NEBULA_OVERRIDES_PATH", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        assert resolve_overrides_path() == tmp_path / "nebula" / "overrides.toml"


class TestLoadOverrides:
    def test_missing_file_returns_empty(self, tmp_path):
        result = load_overrides(tmp_path / "nope.toml")
        assert result.disabled == {}
        assert result.priorities == {}
        assert result.warnings == []

    def test_parses_disable_section(self, tmp_path):
        f = tmp_path / "overrides.toml"
        f.write_text('[engines.disable]\nwhale_watcher = "not useful"\n')
        result = load_overrides(f)
        assert result.disabled == {"whale_watcher": "not useful"}

    def test_parses_priority_section(self, tmp_path):
        f = tmp_path / "overrides.toml"
        f.write_text("[engines.priority]\nadversarial_reviewer = 2\n")
        result = load_overrides(f)
        assert result.priorities == {"adversarial_reviewer": 2}

    def test_malformed_toml_warns(self, tmp_path):
        f = tmp_path / "bad.toml"
        f.write_text("not valid toml [[[")
        result = load_overrides(f)
        assert any("parse error" in w for w in result.warnings)

    def test_priority_non_int_warns(self, tmp_path):
        f = tmp_path / "overrides.toml"
        f.write_text('[engines.priority]\nbad = "not an int"\n')
        result = load_overrides(f)
        assert "bad" not in result.priorities
        assert any("expected int" in w for w in result.warnings)

    def test_combined(self, tmp_path):
        f = tmp_path / "overrides.toml"
        f.write_text(
            '[engines.disable]\nhype_detector = "noise"\n[engines.priority]\nspec_tracker = 1\n'
        )
        result = load_overrides(f)
        assert result.disabled == {"hype_detector": "noise"}
        assert result.priorities == {"spec_tracker": 1}


def _make_engines():
    return [
        EngineDefinition(name="engine_a", description="a", module_path="mod_a", priority=5),
        EngineDefinition(name="engine_b", description="b", module_path="mod_b", priority=7),
        EngineDefinition(name="engine_c", description="c", module_path="mod_c", priority=3),
    ]


class TestApplyOverrides:
    def test_disable_engine(self):
        engines = _make_engines()
        overrides = EngineOverrides(disabled={"engine_b": "not useful"})
        apply_overrides(engines, overrides)
        assert not engines[1].enabled
        assert engines[0].enabled  # others untouched
        assert engines[2].enabled

    def test_reprioritize_engine(self):
        engines = _make_engines()
        overrides = EngineOverrides(priorities={"engine_a": 1})
        apply_overrides(engines, overrides)
        assert engines[0].priority == 1

    def test_unknown_engine_warns(self):
        engines = _make_engines()
        overrides = EngineOverrides(disabled={"nonexistent": "typo"})
        apply_overrides(engines, overrides)
        assert any("unknown engine" in w for w in overrides.warnings)

    def test_combined_disable_and_reprioritize(self):
        engines = _make_engines()
        overrides = EngineOverrides(
            disabled={"engine_c": "skip"},
            priorities={"engine_a": 9},
        )
        apply_overrides(engines, overrides)
        assert not engines[2].enabled
        assert engines[0].priority == 9

    def test_empty_overrides_is_noop(self):
        engines = _make_engines()
        original_states = [(e.enabled, e.priority) for e in engines]
        apply_overrides(engines, EngineOverrides())
        for i, e in enumerate(engines):
            assert (e.enabled, e.priority) == original_states[i]
