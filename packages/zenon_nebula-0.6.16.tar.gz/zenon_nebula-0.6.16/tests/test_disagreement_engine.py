# SPDX-License-Identifier: MIT
"""Tests for domains/self_maintenance/engines/disagreement_engine.py (task #69)."""

from __future__ import annotations

import inspect
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence import connect
from domains.self_maintenance.engines import disagreement_engine as dis


def _ts(seconds_ago: int) -> str:
    t = datetime.now(timezone.utc) - timedelta(seconds=seconds_ago)
    return t.strftime("%Y-%m-%d %H:%M:%S")


def _insert(
    conn,
    *,
    engine: str = "test_engine",
    evidence_type: str = "bug_report",
    finding: str = "WHAT",
    source_repo: str = "repo/a",
    source_file: str = "src/foo.py",
    source_line: int = 42,
    source_commit: str = "abc123" + "0" * 34,
    content_hash: str = "hash_default",
    peer_id: str = "peer_1",
    seconds_ago: int = 3600,
):
    conn.execute(
        """
        INSERT INTO evidence
            (timestamp, domain, engine, evidence_type, finding,
             confidence, source_repo, source_file, source_line,
             source_commit, content_hash, discoverer_peer_id)
        VALUES (?, ?, ?, ?, ?, 0.7, ?, ?, ?, ?, ?, ?)
        """,
        (
            _ts(seconds_ago),
            "test",
            engine,
            evidence_type,
            finding,
            source_repo,
            source_file,
            source_line,
            source_commit,
            content_hash,
            peer_id,
        ),
    )
    conn.commit()


class TestImportSmoke:
    def test_module_imports(self):
        assert hasattr(dis, "run_disagreement_engine")

    def test_entry_point_zero_required_arg(self):
        sig = inspect.signature(dis.run_disagreement_engine)
        required = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.name not in ("self", "db_path")
            and p.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.POSITIONAL_ONLY,
            )
        ]
        assert required == []


class TestDetection:
    def test_empty_db_returns_nothing(self, db_path):
        conn = connect(db_path)
        try:
            d = dis._find_disagreements(conn)
            assert d == []
        finally:
            conn.close()

    def test_single_peer_no_disagreement(self, db_path):
        """Same peer producing different findings at same location
        is NOT a disagreement — it's one peer confused with itself."""
        conn = connect(db_path)
        _insert(conn, content_hash="hash_a", peer_id="peer_1", finding="verdict A")
        _insert(conn, content_hash="hash_b", peer_id="peer_1", finding="verdict B")
        try:
            d = dis._find_disagreements(conn)
            assert d == []
        finally:
            conn.close()

    def test_two_peers_agree_no_disagreement(self, db_path):
        """Same content_hash from two peers = corroboration, not
        disagreement."""
        conn = connect(db_path)
        _insert(conn, content_hash="hash_same", peer_id="peer_1")
        _insert(conn, content_hash="hash_same", peer_id="peer_2")
        try:
            d = dis._find_disagreements(conn)
            assert d == []
        finally:
            conn.close()

    def test_two_peers_disagree_flagged(self, db_path):
        """Two peers, same location, different content_hash → disagreement."""
        conn = connect(db_path)
        _insert(
            conn,
            content_hash="hash_a",
            peer_id="peer_1",
            finding="verdict A",
        )
        _insert(
            conn,
            content_hash="hash_b",
            peer_id="peer_2",
            finding="verdict B",
        )
        try:
            d = dis._find_disagreements(conn)
            assert len(d) == 1
            assert d[0].source_file == "src/foo.py"
            assert d[0].source_line == 42
            assert d[0].detail["distinct_hashes"] == 2
            assert d[0].detail["distinct_peers"] == 2
        finally:
            conn.close()

    def test_skips_rows_without_source_location(self, db_path):
        """Rows lacking source_file/line/commit shouldn't appear in
        grouping even if peers + hashes differ."""
        conn = connect(db_path)
        _insert(
            conn,
            content_hash="hash_a",
            peer_id="peer_1",
            source_file="",  # missing
        )
        _insert(
            conn,
            content_hash="hash_b",
            peer_id="peer_2",
            source_file="",
        )
        try:
            d = dis._find_disagreements(conn)
            assert d == []
        finally:
            conn.close()

    def test_different_locations_each_counted(self, db_path):
        """Two disagreements at different locations should both surface."""
        conn = connect(db_path)
        # Disagreement at foo.py:10
        _insert(
            conn,
            source_file="foo.py",
            source_line=10,
            content_hash="h1",
            peer_id="peer_1",
        )
        _insert(
            conn,
            source_file="foo.py",
            source_line=10,
            content_hash="h2",
            peer_id="peer_2",
        )
        # Disagreement at bar.py:20
        _insert(
            conn,
            source_file="bar.py",
            source_line=20,
            content_hash="h3",
            peer_id="peer_1",
        )
        _insert(
            conn,
            source_file="bar.py",
            source_line=20,
            content_hash="h4",
            peer_id="peer_2",
        )
        try:
            d = dis._find_disagreements(conn)
            assert len(d) == 2
            files = {x.source_file for x in d}
            assert files == {"foo.py", "bar.py"}
        finally:
            conn.close()

    def test_emission_capped_at_max(self, db_path, monkeypatch):
        """Bound emission — don't let a bad peer flood the war room."""
        monkeypatch.setattr(dis, "MAX_DISAGREEMENTS_PER_RUN", 3)
        conn = connect(db_path)
        for i in range(5):
            _insert(
                conn,
                source_file=f"file_{i}.py",
                source_line=i,
                content_hash=f"h{i}a",
                peer_id="peer_1",
            )
            _insert(
                conn,
                source_file=f"file_{i}.py",
                source_line=i,
                content_hash=f"h{i}b",
                peer_id="peer_2",
            )
        try:
            d = dis._find_disagreements(conn)
            assert len(d) == 3
        finally:
            conn.close()


class TestFormatting:
    def test_finding_includes_location_and_counts(self):
        d = dis.Disagreement(
            source_repo="repo/a",
            source_file="src/x.py",
            source_line=99,
            source_commit="deadbeef" + "0" * 32,
            detail={
                "distinct_hashes": 3,
                "distinct_peers": 2,
                "content_hashes": ["h1", "h2", "h3"],
                "peers": ["peer_alice", "peer_bob"],
                "engines": ["e1"],
                "window_days": 30,
            },
        )
        what, so_what, now_what = dis._format_finding(d)
        assert "src/x.py:99" in what
        assert "2 peers" in what
        assert "3 different" in what
        assert "repo/a" in what
        assert "peer_alice" in now_what or "peer_bob" in now_what
        assert "adjudicat" in now_what.lower()
        assert len(so_what) > 40


class TestCooldown:
    def test_cooldown_blocks_second_emission(self, db_path):
        conn = connect(db_path)
        conn.execute(
            """
            INSERT INTO evidence
                (timestamp, domain, engine, evidence_type, finding,
                 confidence, source_file, source_line, source_commit)
            VALUES (?, 'self_maintenance', 'disagreement_engine',
                    'peer_disagreement', 'WHAT', 0.5, 'a.py', 1,
                    'commit_abc' || substr('0000000000000000000000000000000000000000', 1, 34))
            """,
            (_ts(3600),),
        )
        conn.commit()
        assert (
            dis._was_recently_emitted(
                conn,
                "a.py",
                1,
                "commit_abc" + "0" * 34,
            )
            is True
        )
        assert (
            dis._was_recently_emitted(
                conn,
                "b.py",
                1,
                "commit_abc" + "0" * 34,
            )
            is False
        )
        conn.close()


class TestEndToEnd:
    def test_empty_summary_when_no_evidence(self, db_path):
        result = dis.run_disagreement_engine(db_path=db_path)
        assert result["engine"] == "disagreement_engine"
        assert result["disagreements_detected"] == 0
        assert result["findings_persisted"] == 0

    def test_disagreement_produces_finding(self, db_path):
        conn = connect(db_path)
        _insert(
            conn,
            source_file="a.py",
            source_line=10,
            content_hash="h_alice",
            peer_id="peer_alice",
            finding="buffer overflow",
        )
        _insert(
            conn,
            source_file="a.py",
            source_line=10,
            content_hash="h_bob",
            peer_id="peer_bob",
            finding="intentional framing",
        )
        conn.close()

        result = dis.run_disagreement_engine(db_path=db_path)
        assert result["disagreements_detected"] == 1
        assert result["findings_persisted"] == 1

    def test_cooldown_prevents_duplicate_emission(self, db_path):
        conn = connect(db_path)
        _insert(conn, source_file="a.py", source_line=10, content_hash="h_a", peer_id="p_1")
        _insert(conn, source_file="a.py", source_line=10, content_hash="h_b", peer_id="p_2")
        conn.close()

        first = dis.run_disagreement_engine(db_path=db_path)
        second = dis.run_disagreement_engine(db_path=db_path)
        assert first["findings_persisted"] == 1
        assert second["findings_persisted"] == 0


class TestDataclass:
    def test_is_frozen(self):
        d = dis.Disagreement(
            source_repo="r",
            source_file="f.py",
            source_line=1,
            source_commit="c" * 40,
            detail={},
        )
        from dataclasses import FrozenInstanceError

        with pytest.raises(FrozenInstanceError):
            d.source_line = 2
