# SPDX-License-Identifier: MIT
"""Tests for scripts/draft_pr.py — task #89 Phase 1.

Pins the drafter's pure-logic contracts:
- Task ID extraction from commit text (both `task #N` and bare `#N` forms).
- Tier classification heuristic matches branching.md rules.
- PR body rendering includes every required section.
"""

from __future__ import annotations

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import draft_pr


def _summary(
    files: list[str] | None = None,
    commits: list[tuple[str, str]] | None = None,
    additions: int = 0,
    deletions: int = 0,
    task_ids: set[int] | None = None,
) -> draft_pr.DiffSummary:
    return draft_pr.DiffSummary(
        base="main",
        head="HEAD",
        files_changed=files or [],
        commits=commits or [],
        additions=additions,
        deletions=deletions,
        task_ids=task_ids or set(),
    )


class TestTaskIdRegex:
    def test_matches_task_prefix(self):
        matches = list(draft_pr.TASK_ID_RE.finditer("closes task #42"))
        assert len(matches) == 1
        assert matches[0].group(1) == "42"

    def test_matches_bare_hash_form(self):
        matches = list(draft_pr.TASK_ID_RE.finditer("see #99 for details"))
        assert len(matches) == 1
        assert matches[0].group(2) == "99"

    def test_multiple_ids_in_one_string(self):
        found = {
            m.group(1) or m.group(2)
            for m in draft_pr.TASK_ID_RE.finditer("task #1 and task #2 and #3")
        }
        assert found == {"1", "2", "3"}

    def test_no_match_inside_larger_number(self):
        # "task#1234567" is one ID; #1234567 should match, not treat
        # as three separate numbers. Regex captures the whole run.
        matches = list(draft_pr.TASK_ID_RE.finditer("task #1234567"))
        assert len(matches) == 1
        assert matches[0].group(1) == "1234567"

    def test_plain_number_does_not_match(self):
        # "version 42" has no # prefix → not an ID mention.
        matches = list(draft_pr.TASK_ID_RE.finditer("version 42 shipped"))
        assert matches == []


class TestClassifyTier:
    def test_empty_summary_is_tier_zero(self):
        assert draft_pr.classify_tier(_summary()) == 0

    def test_single_code_file_is_tier_one(self):
        s = _summary(files=["core/new_module.py"])
        assert draft_pr.classify_tier(s) == 1

    def test_core_trust_py_is_tier_two(self):
        s = _summary(files=["core/trust.py"])
        assert draft_pr.classify_tier(s) == 2

    def test_release_yml_is_tier_two(self):
        s = _summary(files=[".github/workflows/release.yml"])
        assert draft_pr.classify_tier(s) == 2

    def test_many_files_trips_tier_two(self):
        s = _summary(files=[f"file_{i}.py" for i in range(10)])
        assert draft_pr.classify_tier(s) == 2

    def test_pyproject_touching_is_tier_two(self):
        s = _summary(files=["pyproject.toml"])
        assert draft_pr.classify_tier(s) == 2


class TestRenderPrBody:
    def test_includes_all_sections(self):
        s = _summary(
            files=["core/x.py", "tests/test_x.py"],
            commits=[("abc123", "feat[x]: add widget")],
            additions=50,
            deletions=5,
            task_ids={42},
        )
        body = draft_pr.render_pr_body(s, tier=1)
        assert "## Summary" in body
        assert "## Test plan" in body
        assert "## Attack-vector audit" in body
        assert "## Tier" in body
        assert "feat[x]: add widget" in body
        assert "+50 / -5" in body
        assert "#42" in body
        assert "Tier 1" in body

    def test_title_prepended_as_heading(self):
        s = _summary(files=["x.py"], commits=[("aaa", "subj")])
        body = draft_pr.render_pr_body(s, tier=1, title="My PR Title")
        assert body.splitlines()[0] == "# My PR Title"

    def test_no_task_ids_omits_tasks_section(self):
        s = _summary(files=["x.py"], commits=[("aaa", "subj")])
        body = draft_pr.render_pr_body(s, tier=1)
        assert "Tasks referenced" not in body

    def test_many_commits_summary_truncates_to_five(self):
        commits = [(f"sha{i}", f"subj {i}") for i in range(10)]
        s = _summary(files=["x.py"], commits=commits)
        body = draft_pr.render_pr_body(s, tier=1)
        # First 5 included by number, rest summarized.
        assert "- subj 0" in body
        assert "- subj 4" in body
        # Beyond 5, not present individually — rolled into "and N more".
        assert "- subj 9" not in body
        assert "and 5 more" in body

    def test_tier_description_renders(self):
        s = _summary(files=["x.py"], commits=[("a", "s")])
        for tier in (0, 1, 2, 3):
            body = draft_pr.render_pr_body(s, tier=tier)
            assert f"Tier {tier}" in body


class TestCollectDiffSummaryIntegration:
    """End-to-end: run against the actual repo. The repo always has
    at least HEAD vs HEAD (empty diff); this proves the git plumbing
    works without requiring a specific branch state."""

    def test_empty_range_returns_empty_summary(self):
        s = draft_pr.collect_diff_summary("HEAD", "HEAD")
        assert s.files_changed == []
        assert s.commits == []
        assert s.additions == 0

    def test_summary_dataclass_defaults(self):
        s = draft_pr.DiffSummary(base="a", head="b")
        assert s.files_changed == []
        assert s.commits == []
        assert s.additions == 0
        assert s.deletions == 0
        assert s.task_ids == set()


class TestLlmPolish:
    """Task #89 Phase 2 — LLM polish pass safety invariants."""

    DRAFT = (
        "## Summary\n"
        "\n"
        "- change X\n"
        "- change Y\n"
        "\n"
        "## Test plan\n"
        "\n"
        "- [ ] Full suite\n"
        "\n"
        "## Tier\n"
        "\n"
        "Tier 1\n"
    )

    def test_missing_call_llm_returns_draft(self, monkeypatch):
        """No core.llm_provider → graceful fallback."""
        import sys as _sys

        monkeypatch.setitem(_sys.modules, "core.llm_provider", None)
        polished, meta = draft_pr.llm_polish(self.DRAFT)
        assert polished == self.DRAFT
        assert meta is None

    def test_llm_returns_none_returns_draft(self):
        """LLM stub returning None (no key / degraded) → fallback."""
        from unittest.mock import patch

        with patch("core.llm_provider.call_llm", return_value=None):
            polished, meta = draft_pr.llm_polish(self.DRAFT)
        assert polished == self.DRAFT
        assert meta is None

    def test_llm_exception_returns_draft(self):
        """LLM raises → fallback, no propagation."""
        from unittest.mock import patch

        with patch("core.llm_provider.call_llm", side_effect=RuntimeError("boom")):
            polished, meta = draft_pr.llm_polish(self.DRAFT)
        assert polished == self.DRAFT
        assert meta is None

    def test_empty_polish_returns_draft(self):
        """LLM returns empty text → fallback."""
        from unittest.mock import patch

        with patch("core.llm_provider.call_llm", return_value={"text": "", "cost_usd": 0.0}):
            polished, _meta = draft_pr.llm_polish(self.DRAFT)
        assert polished == self.DRAFT

    def test_polish_dropping_header_is_rejected(self):
        """If the polished output drops a `##` header present in the
        draft, that counts as corruption — return the original."""
        from unittest.mock import patch

        polished_response = (
            "## Summary\n"
            "- change X\n"
            "- change Y\n"
            "\n"
            "## Tier\n"
            "Tier 1\n"
        )  # NOTE: dropped "## Test plan"
        with patch(
            "core.llm_provider.call_llm",
            return_value={"text": polished_response, "cost_usd": 0.001, "model": "x"},
        ):
            polished, meta = draft_pr.llm_polish(self.DRAFT)
        assert polished == self.DRAFT  # rejected
        assert meta is None

    def test_happy_polish_returns_new_text(self):
        """When every header survives, return the polished output."""
        from unittest.mock import patch

        polished_response = self.DRAFT.replace("change X", "change X (improved)")
        with patch(
            "core.llm_provider.call_llm",
            return_value={"text": polished_response, "cost_usd": 0.002, "model": "grok"},
        ):
            polished, meta = draft_pr.llm_polish(self.DRAFT)
        # llm_polish strips whitespace — compare against the stripped
        # response, not the raw one.
        assert polished == polished_response.strip()
        assert meta is not None
        assert meta["cost_usd"] == 0.002

    def test_budget_exceeded_flagged_but_polish_kept(self):
        """When polish cost exceeds the budget, we still return the
        polished text but flag it so operators know."""
        from unittest.mock import patch

        polished_response = self.DRAFT.replace("change X", "change X improved")
        with patch(
            "core.llm_provider.call_llm",
            return_value={"text": polished_response, "cost_usd": 1.00, "model": "grok"},
        ):
            polished, meta = draft_pr.llm_polish(self.DRAFT, budget_usd=0.01)
        assert polished == polished_response.strip()
        assert meta is not None
        assert meta.get("budget_exceeded") is True
