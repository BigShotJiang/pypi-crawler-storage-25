# SPDX-License-Identifier: MIT
"""Tests for distribution-scope gating — .claude/rules/distribution-scope.md.

Pins the contract that four self_maintenance engines (rule_adherence_auditor,
readme_truth_auditor, codebase_improvement_auditor, todo_budget_monitor)
are fork-dev only: end-user installs must NOT fire them, and enabling
NEBULA_DEV_ENGINES=1 must restore them to rotation.
"""

from __future__ import annotations

import pytest

from domains.self_maintenance.domain import SelfMaintenanceDomain

FORK_DEV_ENGINES = {
    "rule_adherence_auditor",
    "readme_truth_auditor",
    "codebase_improvement_auditor",
    "todo_budget_monitor",
}


class TestEngineDefinitions:
    """Verify the four fork-dev engines carry ships_in_wheel=False."""

    def test_fork_dev_engines_marked_non_shipping(self):
        domain = SelfMaintenanceDomain()
        non_shipping = {e.name for e in domain.get_engines() if not e.ships_in_wheel}
        assert non_shipping == FORK_DEV_ENGINES

    def test_operator_facing_engines_marked_shipping(self):
        domain = SelfMaintenanceDomain()
        shipping = {e.name for e in domain.get_engines() if e.ships_in_wheel}
        # These produce value for any Nebula operator, not just us.
        expected_shipping = {
            "engine_health_monitor",
            "config_drift_detector",
            "llm_cost_optimizer",
            "api_awareness",
            "llm_model_watcher",
            "mcp_discovery",
            "disagreement_engine",
        }
        assert expected_shipping.issubset(shipping)
        # No fork-dev engine slipped in.
        assert not (shipping & FORK_DEV_ENGINES)


class TestSchedulerGate:
    """Verify decide_next_action skips fork-dev engines without the env flag."""

    def test_end_user_never_picks_fork_dev_engine(self, monkeypatch):
        monkeypatch.delenv("NEBULA_DEV_ENGINES", raising=False)
        domain = SelfMaintenanceDomain()

        # Exhaust the rotation: keep asking for actions while adding each
        # to the exclude set. Collect every engine picked.
        exclude: set[str] = set()
        picked: list[str] = []
        for _ in range(20):  # more iterations than candidates
            action = domain.decide_next_action({}, exclude=exclude)
            if action is None:
                break
            picked.append(action["engine"])
            exclude.add(f"self_maintenance:{action['action']}")

        # None of the four fork-dev engines should be in the picked list.
        for engine in FORK_DEV_ENGINES:
            assert engine not in picked, (
                f"{engine} should be gated by NEBULA_DEV_ENGINES but was picked"
            )

    def test_dev_env_restores_fork_dev_engines(self, monkeypatch):
        monkeypatch.setenv("NEBULA_DEV_ENGINES", "1")
        domain = SelfMaintenanceDomain()

        exclude: set[str] = set()
        picked: list[str] = []
        for _ in range(20):
            action = domain.decide_next_action({}, exclude=exclude)
            if action is None:
                break
            picked.append(action["engine"])
            exclude.add(f"self_maintenance:{action['action']}")

        # All four fork-dev engines should now be in rotation.
        for engine in FORK_DEV_ENGINES:
            assert engine in picked, (
                f"{engine} should run with NEBULA_DEV_ENGINES=1 but was skipped"
            )

    def test_dev_env_empty_string_treated_as_unset(self, monkeypatch):
        monkeypatch.setenv("NEBULA_DEV_ENGINES", "")
        domain = SelfMaintenanceDomain()
        action = domain.decide_next_action({}, exclude=set())
        # First pick should be a shipping engine, never a fork-dev one.
        assert action is not None
        assert action["engine"] not in FORK_DEV_ENGINES

    def test_dev_env_non_one_value_rejected(self, monkeypatch):
        # "true" / "yes" / "on" are common false-matches. Only "1" counts.
        for bad in ("true", "yes", "on", "enabled", "0"):
            monkeypatch.setenv("NEBULA_DEV_ENGINES", bad)
            domain = SelfMaintenanceDomain()
            picked = []
            exclude: set[str] = set()
            for _ in range(20):
                action = domain.decide_next_action({}, exclude=exclude)
                if action is None:
                    break
                picked.append(action["engine"])
                exclude.add(f"self_maintenance:{action['action']}")
            for engine in FORK_DEV_ENGINES:
                assert engine not in picked, f"NEBULA_DEV_ENGINES={bad!r} must not enable {engine}"


class TestEngineDefinitionDefaults:
    """The field default should be True so every existing caller still ships."""

    def test_default_is_true(self):
        from core.domain_registry import EngineDefinition

        e = EngineDefinition(name="example", description="x", module_path="example.mod")
        assert e.ships_in_wheel is True

    def test_explicit_false_overrides(self):
        from core.domain_registry import EngineDefinition

        e = EngineDefinition(
            name="example",
            description="x",
            module_path="example.mod",
            ships_in_wheel=False,
        )
        assert e.ships_in_wheel is False
