# SPDX-License-Identifier: MIT
"""Tests for domains/self_maintenance/engines/api_awareness.py.

Task #66 (v0.6.11). Engine reads ``api_call_log`` and surfaces four
classes of provider health anomaly: error-rate spikes, latency drift,
schema-hash drift, sudden disappearance.

Tests use the ``db_path`` fixture (already has ``api_call_log``
applied via ``ensure_schema``) plus direct row inserts to simulate
each anomaly class. No real network, no real provider calls.
"""

from __future__ import annotations

import inspect
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence import connect
from domains.self_maintenance.engines import api_awareness as aa


def _ts(seconds_ago: int) -> str:
    """Return an ISO timestamp ``seconds_ago`` seconds in the past."""
    t = datetime.now(timezone.utc) - timedelta(seconds=seconds_ago)
    return t.strftime("%Y-%m-%dT%H:%M:%fZ")


def _insert_call(
    conn,
    *,
    provider: str,
    status: str = "ok",
    latency_ms: int = 100,
    seconds_ago: int = 0,
    schema_hash: str | None = None,
):
    """Insert one row into api_call_log with a controlled timestamp."""
    conn.execute(
        """
        INSERT INTO api_call_log
            (timestamp, provider_name, engine_name, method, latency_ms, status,
             response_bytes, response_schema_hash)
        VALUES (?, ?, 'test_engine', 'test_method', ?, ?, 100, ?)
        """,
        (_ts(seconds_ago), provider, latency_ms, status, schema_hash),
    )
    conn.commit()


# ---------------------------------------------------------------------------
# Import smoke
# ---------------------------------------------------------------------------


class TestImportSmoke:
    def test_module_imports(self):
        assert hasattr(aa, "run_api_awareness")

    def test_entry_point_zero_required_arg(self):
        sig = inspect.signature(aa.run_api_awareness)
        required = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.name not in ("self", "db_path")
            and p.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.POSITIONAL_ONLY,
            )
        ]
        assert required == []


# ---------------------------------------------------------------------------
# Empty / missing data paths
# ---------------------------------------------------------------------------


class TestEmptyData:
    def test_returns_empty_summary_when_table_empty(self, db_path):
        result = aa.run_api_awareness(db_path=db_path)
        assert result["engine"] == "api_awareness"
        assert result["anomalies_detected"] == 0
        assert result["findings_persisted"] == 0


# ---------------------------------------------------------------------------
# Error-rate spike detection
# ---------------------------------------------------------------------------


class TestErrorRateSpike:
    def test_detects_high_recent_errors_low_baseline(self, db_path):
        conn = connect(db_path)
        # Baseline window (10-30 days ago): 100 calls, 1 error = 1% rate
        for i in range(99):
            _insert_call(conn, provider="github", status="ok", seconds_ago=86400 * 15 + i)
        _insert_call(conn, provider="github", status="error", seconds_ago=86400 * 15)
        # Recent window (last 72h): 25 calls, 5 errors = 20% rate
        for i in range(20):
            _insert_call(conn, provider="github", status="ok", seconds_ago=3600 + i)
        for i in range(5):
            _insert_call(conn, provider="github", status="error", seconds_ago=3600 + i)
        conn.close()

        anomalies = aa._detect_error_rate_spikes(connect(db_path))
        assert len(anomalies) == 1
        assert anomalies[0].provider_name == "github"
        assert anomalies[0].anomaly_class == "error_rate"
        assert anomalies[0].detail["recent_rate"] >= 0.10

    def test_skips_low_volume_providers(self, db_path):
        conn = connect(db_path)
        # Recent: only 10 calls, 5 errors = 50% rate but below
        # MIN_RECENT_CALLS so should NOT trigger.
        for _ in range(5):
            _insert_call(conn, provider="rare", status="ok", seconds_ago=3600)
        for _ in range(5):
            _insert_call(conn, provider="rare", status="error", seconds_ago=3600)
        conn.close()

        anomalies = aa._detect_error_rate_spikes(connect(db_path))
        assert anomalies == []

    def test_skips_when_baseline_is_also_high(self, db_path):
        # If baseline is already high, this isn't a spike — it's just
        # a chronically broken provider.
        conn = connect(db_path)
        for i in range(50):
            _insert_call(conn, provider="always_broken", status="error", seconds_ago=86400 * 15 + i)
        for i in range(50):
            _insert_call(conn, provider="always_broken", status="ok", seconds_ago=86400 * 15 + i)
        for i in range(20):
            _insert_call(conn, provider="always_broken", status="error", seconds_ago=3600 + i)
        for i in range(5):
            _insert_call(conn, provider="always_broken", status="ok", seconds_ago=3600 + i)
        conn.close()

        anomalies = aa._detect_error_rate_spikes(connect(db_path))
        assert anomalies == []  # baseline is 50% — not a spike


# ---------------------------------------------------------------------------
# Latency drift detection
# ---------------------------------------------------------------------------


class TestLatencyDrift:
    def test_detects_recent_p95_above_2x_baseline(self, db_path):
        conn = connect(db_path)
        # Baseline: 50 calls, p95 around 100ms
        for i in range(50):
            _insert_call(
                conn,
                provider="explorer",
                status="ok",
                latency_ms=100,
                seconds_ago=86400 * 15 + i,
            )
        # Recent: 25 calls, all 500ms — p95 way above baseline
        for i in range(25):
            _insert_call(
                conn,
                provider="explorer",
                status="ok",
                latency_ms=500,
                seconds_ago=3600 + i,
            )
        conn.close()

        anomalies = aa._detect_latency_drift(connect(db_path))
        assert len(anomalies) == 1
        assert anomalies[0].provider_name == "explorer"
        assert anomalies[0].anomaly_class == "latency"
        assert anomalies[0].detail["factor"] >= aa.LATENCY_DRIFT_FACTOR

    def test_skips_low_volume_recent(self, db_path):
        conn = connect(db_path)
        for i in range(50):
            _insert_call(conn, provider="explorer", latency_ms=100, seconds_ago=86400 * 15 + i)
        for _ in range(5):  # below MIN_RECENT_CALLS
            _insert_call(conn, provider="explorer", latency_ms=500, seconds_ago=3600)
        conn.close()

        anomalies = aa._detect_latency_drift(connect(db_path))
        assert anomalies == []


# ---------------------------------------------------------------------------
# Schema-hash drift detection
# ---------------------------------------------------------------------------


class TestSchemaDrift:
    def test_detects_new_hash_in_recent_window(self, db_path):
        conn = connect(db_path)
        # Baseline: provider returned hash A for 30 days
        for i in range(50):
            _insert_call(
                conn,
                provider="market_data",
                schema_hash="aaaaaaaa",
                seconds_ago=86400 * 10 + i,
            )
        # Recent (last 24h): provider now returns hash B
        for i in range(10):
            _insert_call(
                conn,
                provider="market_data",
                schema_hash="bbbbbbbb",
                seconds_ago=3600 + i,
            )
        conn.close()

        anomalies = aa._detect_schema_drift(connect(db_path))
        assert len(anomalies) == 1
        assert anomalies[0].provider_name == "market_data"
        assert "bbbbbbbb" in anomalies[0].detail["new_hashes"]

    def test_no_drift_when_recent_hash_in_baseline(self, db_path):
        conn = connect(db_path)
        for i in range(20):
            _insert_call(conn, provider="stable", schema_hash="cccccccc", seconds_ago=86400 * 5 + i)
        for i in range(10):
            _insert_call(conn, provider="stable", schema_hash="cccccccc", seconds_ago=3600 + i)
        conn.close()

        anomalies = aa._detect_schema_drift(connect(db_path))
        assert anomalies == []


# ---------------------------------------------------------------------------
# Sudden disappearance detection
# ---------------------------------------------------------------------------


class TestDisappearance:
    def test_detects_active_then_silent(self, db_path):
        conn = connect(db_path)
        # 30 days of consistent activity (~15 calls/day)
        for day in range(2, 30):
            for _ in range(15):
                _insert_call(conn, provider="explorer", seconds_ago=86400 * day)
        # Last 24h: zero calls (no inserts)
        conn.close()

        anomalies = aa._detect_disappearance(connect(db_path))
        assert len(anomalies) == 1
        assert anomalies[0].provider_name == "explorer"
        assert anomalies[0].anomaly_class == "disappearance"
        assert anomalies[0].detail["recent_calls_24h"] == 0

    def test_skips_low_baseline_providers(self, db_path):
        conn = connect(db_path)
        # Baseline below MIN_BASELINE_CALLS_PER_DAY (10)
        for day in range(2, 30):
            _insert_call(conn, provider="rare", seconds_ago=86400 * day)
        conn.close()
        anomalies = aa._detect_disappearance(connect(db_path))
        assert anomalies == []

    def test_skips_still_active_providers(self, db_path):
        conn = connect(db_path)
        for day in range(2, 30):
            for _ in range(15):
                _insert_call(conn, provider="alive", seconds_ago=86400 * day)
        # Recent: still calling
        for _ in range(5):
            _insert_call(conn, provider="alive", seconds_ago=3600)
        conn.close()
        anomalies = aa._detect_disappearance(connect(db_path))
        assert anomalies == []


# ---------------------------------------------------------------------------
# Percentile helper
# ---------------------------------------------------------------------------


class TestPercentile:
    def test_empty_returns_zero(self):
        assert aa._percentile([], 95) == 0.0

    def test_single_value(self):
        assert aa._percentile([42], 95) == 42.0

    def test_p95_of_100_values(self):
        # values 1..100, p95 is around 95
        result = aa._percentile(list(range(1, 101)), 95)
        assert 90 <= result <= 100


# ---------------------------------------------------------------------------
# Format helper
# ---------------------------------------------------------------------------


class TestFormatAnomaly:
    def test_error_rate_finding_shape(self):
        a = aa.Anomaly(
            provider_name="github",
            anomaly_class="error_rate",
            detail={
                "recent_rate": 0.25,
                "baseline_rate": 0.01,
                "recent_calls": 100,
                "recent_errors": 25,
                "window_hours": 72,
            },
        )
        what, _so_what, now_what = aa._format_anomaly(a)
        assert "github" in what
        assert "25%" in what or "25" in what
        assert "providers diagnose" in now_what

    def test_latency_finding_shape(self):
        a = aa.Anomaly(
            provider_name="explorer",
            anomaly_class="latency",
            detail={
                "recent_p95_ms": 500,
                "baseline_p95_ms": 100,
                "factor": 5.0,
                "recent_calls": 50,
            },
        )
        what, _, _ = aa._format_anomaly(a)
        assert "5.0" in what or "5x" in what
        assert "500" in what

    def test_schema_finding_shape(self):
        a = aa.Anomaly(
            provider_name="market_data",
            anomaly_class="schema",
            detail={
                "new_hashes": ["abc12345xyz"],
                "baseline_hash_count": 1,
                "window_hours": 24,
            },
        )
        what, _, _ = aa._format_anomaly(a)
        assert "market_data" in what
        # Hash truncated to 8 chars in output
        assert "abc12345" in what

    def test_disappearance_finding_shape(self):
        a = aa.Anomaly(
            provider_name="explorer",
            anomaly_class="disappearance",
            detail={
                "baseline_calls_per_day": 50.0,
                "recent_calls_24h": 0,
            },
        )
        what, _, _ = aa._format_anomaly(a)
        assert "50" in what
        assert "silent" in what


# ---------------------------------------------------------------------------
# Cooldown
# ---------------------------------------------------------------------------


class TestCooldown:
    def test_cooldown_skips_recently_emitted(self, db_path):
        # Insert a fake recent finding for github+error_rate
        conn = connect(db_path)
        conn.execute(
            """
            INSERT INTO evidence
                (timestamp, domain, engine, evidence_type, finding,
                 confidence, raw_data)
            VALUES (?, 'self_maintenance', 'api_awareness',
                    'api_health_anomaly', 'WHAT...', 0.75, ?)
            """,
            (
                _ts(3600),  # 1h ago
                '{"data": {"provider": "github", "anomaly_class": "error_rate"}, "provenance": "system"}',
            ),
        )
        conn.commit()
        assert aa._was_recently_emitted(conn, "github", "error_rate") is True
        # Different provider — no cooldown
        assert aa._was_recently_emitted(conn, "other", "error_rate") is False
        # Different class — no cooldown
        assert aa._was_recently_emitted(conn, "github", "latency") is False
        conn.close()


# ---------------------------------------------------------------------------
# End-to-end
# ---------------------------------------------------------------------------


class TestEndToEnd:
    def test_persists_findings_for_detected_anomalies(self, db_path):
        # Plant an error-rate spike
        conn = connect(db_path)
        for i in range(50):
            _insert_call(conn, provider="api_x", status="ok", seconds_ago=86400 * 15 + i)
        for i in range(20):
            _insert_call(conn, provider="api_x", status="ok", seconds_ago=3600 + i)
        for i in range(5):
            _insert_call(conn, provider="api_x", status="error", seconds_ago=3600 + i)
        conn.close()

        result = aa.run_api_awareness(db_path=db_path)
        assert result["anomalies_detected"] >= 1
        assert result["findings_persisted"] >= 1
        assert result["by_class"]["error_rate"] >= 1
