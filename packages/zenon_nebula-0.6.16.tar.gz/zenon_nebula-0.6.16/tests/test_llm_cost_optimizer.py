# SPDX-License-Identifier: MIT
"""Tests for domains/self_maintenance/engines/llm_cost_optimizer.py.

Task #94 (v0.6.11). Engine joins cost_tracking + evidence and surfaces
three signal classes: cost outliers, stagnant spend, model arbitrage.

Tests use the ``db_path`` fixture (cost_tracking + evidence tables
already applied via ensure_schema) plus direct row inserts to
simulate each signal class. No real LLM calls.
"""

from __future__ import annotations

import inspect
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence import connect
from domains.self_maintenance.engines import llm_cost_optimizer as lco


def _ts(seconds_ago: int) -> str:
    """Return an ISO timestamp seconds_ago seconds in the past."""
    t = datetime.now(timezone.utc) - timedelta(seconds=seconds_ago)
    return t.strftime("%Y-%m-%d %H:%M:%S")


def _insert_cost(
    conn,
    *,
    module: str,
    cost_usd: float,
    model: str = "grok-4",
    provider: str = "xai",
    domain: str = "intelligence",
    seconds_ago: int = 3600,
):
    conn.execute(
        """
        INSERT INTO cost_tracking
            (timestamp, domain, provider, model, module, tokens_input,
             tokens_output, cost_usd, task_type)
        VALUES (?, ?, ?, ?, ?, 100, 100, ?, 'classify')
        """,
        (_ts(seconds_ago), domain, provider, model, module, cost_usd),
    )
    conn.commit()


def _insert_finding(
    conn,
    *,
    engine: str,
    domain: str = "intelligence",
    seconds_ago: int = 3600,
):
    conn.execute(
        """
        INSERT INTO evidence
            (timestamp, domain, engine, evidence_type, finding, confidence)
        VALUES (?, ?, ?, 'test', 'WHAT...', 0.5)
        """,
        (_ts(seconds_ago), domain, engine),
    )
    conn.commit()


# ---------------------------------------------------------------------------
# Import smoke
# ---------------------------------------------------------------------------


class TestImportSmoke:
    def test_module_imports(self):
        assert hasattr(lco, "run_llm_cost_optimizer")

    def test_entry_point_zero_required_arg(self):
        sig = inspect.signature(lco.run_llm_cost_optimizer)
        required = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.name not in ("self", "db_path")
            and p.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.POSITIONAL_ONLY,
            )
        ]
        assert required == []


# ---------------------------------------------------------------------------
# Empty data
# ---------------------------------------------------------------------------


class TestEmptyData:
    def test_returns_empty_summary_when_no_costs(self, db_path):
        result = lco.run_llm_cost_optimizer(db_path=db_path)
        assert result["engine"] == "llm_cost_optimizer"
        assert result["engines_analyzed"] == 0
        assert result["signals_detected"] == 0


# ---------------------------------------------------------------------------
# Aggregation helpers
# ---------------------------------------------------------------------------


class TestEngineCosts:
    def test_aggregates_by_engine_and_model(self, db_path):
        conn = connect(db_path)
        _insert_cost(conn, module="alpha", cost_usd=0.10, model="grok-4")
        _insert_cost(conn, module="alpha", cost_usd=0.20, model="grok-4")
        _insert_cost(conn, module="alpha", cost_usd=0.05, model="grok-4-fast")
        _insert_cost(conn, module="beta", cost_usd=0.30, model="grok-4")
        result = lco._engine_costs(conn)
        assert "alpha" in result
        assert "beta" in result
        assert result["alpha"]["calls"] == 3
        assert abs(result["alpha"]["cost_usd"] - 0.35) < 1e-9
        assert result["alpha"]["models"] == {"grok-4", "grok-4-fast"}
        assert result["beta"]["calls"] == 1

    def test_unattributed_bucket(self, db_path):
        conn = connect(db_path)
        _insert_cost(conn, module="", cost_usd=0.10)
        result = lco._engine_costs(conn)
        assert "_unattributed" in result


class TestEngineFindingCounts:
    def test_counts_per_engine(self, db_path):
        conn = connect(db_path)
        for _ in range(5):
            _insert_finding(conn, engine="alpha")
        for _ in range(2):
            _insert_finding(conn, engine="beta")
        counts = lco._engine_finding_counts(conn)
        assert counts.get("alpha") == 5
        assert counts.get("beta") == 2


# ---------------------------------------------------------------------------
# Outlier detection
# ---------------------------------------------------------------------------


class TestOutlierDetection:
    def test_flags_engine_with_high_cost_per_finding(self, db_path):
        conn = connect(db_path)
        # Three normal engines: $0.01 per finding each
        for engine in ("normal_a", "normal_b", "normal_c"):
            for _ in range(10):
                _insert_cost(conn, module=engine, cost_usd=0.01)
            for _ in range(10):
                _insert_finding(conn, engine=engine)
        # One outlier: $0.10 per finding (10x median)
        for _ in range(10):
            _insert_cost(conn, module="outlier", cost_usd=0.10)
        for _ in range(10):
            _insert_finding(conn, engine="outlier")
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_outliers(costs, findings)
        names = {s.engine_name for s in signals}
        assert "outlier" in names
        assert all(s.signal_class == "outlier" for s in signals)

    def test_skips_low_volume_engines(self, db_path):
        conn = connect(db_path)
        # Three baseline engines
        for engine in ("a", "b", "c"):
            for _ in range(10):
                _insert_cost(conn, module=engine, cost_usd=0.01)
            for _ in range(10):
                _insert_finding(conn, engine=engine)
        # Outlier with too few calls (below MIN_CALLS_FOR_OUTLIER=5)
        for _ in range(2):
            _insert_cost(conn, module="rare", cost_usd=1.0)
        for _ in range(2):
            _insert_finding(conn, engine="rare")
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_outliers(costs, findings)
        assert all(s.engine_name != "rare" for s in signals)

    def test_returns_empty_when_too_few_engines(self, db_path):
        conn = connect(db_path)
        for _ in range(10):
            _insert_cost(conn, module="alpha", cost_usd=0.01)
            _insert_finding(conn, engine="alpha")
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_outliers(costs, findings)
        # Median needs >=3 engines
        assert signals == []


# ---------------------------------------------------------------------------
# Stagnant spend detection
# ---------------------------------------------------------------------------


class TestStagnantSpend:
    def test_flags_high_cost_zero_findings(self, db_path):
        conn = connect(db_path)
        _insert_cost(conn, module="silent_engine", cost_usd=2.00)
        # No findings inserted for silent_engine
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_stagnant_spend(costs, findings)
        assert len(signals) == 1
        assert signals[0].engine_name == "silent_engine"
        assert signals[0].signal_class == "stagnant"

    def test_skips_low_cost(self, db_path):
        conn = connect(db_path)
        _insert_cost(conn, module="cheap", cost_usd=0.10)  # below 0.50 threshold
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_stagnant_spend(costs, findings)
        assert signals == []

    def test_skips_when_findings_present(self, db_path):
        conn = connect(db_path)
        _insert_cost(conn, module="productive", cost_usd=2.00)
        _insert_finding(conn, engine="productive")
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_stagnant_spend(costs, findings)
        assert all(s.engine_name != "productive" for s in signals)


# ---------------------------------------------------------------------------
# Model arbitrage detection
# ---------------------------------------------------------------------------


class TestModelArbitrage:
    def test_surfaces_cheaper_model(self, db_path):
        conn = connect(db_path)
        # Engine ran on grok-4 (expensive) and grok-4-fast (cheap)
        # Both same call count → findings split 50/50
        for _ in range(10):
            _insert_cost(conn, module="dual", cost_usd=0.20, model="grok-4")
        for _ in range(10):
            _insert_cost(conn, module="dual", cost_usd=0.02, model="grok-4-fast")
        for _ in range(10):
            _insert_finding(conn, engine="dual")
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_model_arbitrage(costs, findings)
        assert len(signals) == 1
        assert signals[0].engine_name == "dual"
        assert signals[0].detail["cheapest_model"] == "grok-4-fast"
        assert signals[0].detail["priciest_model"] == "grok-4"

    def test_skips_single_model_engine(self, db_path):
        conn = connect(db_path)
        for _ in range(10):
            _insert_cost(conn, module="solo", cost_usd=0.10, model="grok-4")
        for _ in range(10):
            _insert_finding(conn, engine="solo")
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_model_arbitrage(costs, findings)
        assert all(s.engine_name != "solo" for s in signals)

    def test_skips_when_factor_too_small(self, db_path):
        conn = connect(db_path)
        # grok-4: 0.10 each, grok-4-fast: 0.08 each — only 1.25x ratio
        for _ in range(10):
            _insert_cost(conn, module="similar", cost_usd=0.10, model="grok-4")
        for _ in range(10):
            _insert_cost(conn, module="similar", cost_usd=0.08, model="grok-4-fast")
        for _ in range(10):
            _insert_finding(conn, engine="similar")
        conn.close()

        conn = connect(db_path)
        costs = lco._engine_costs(conn)
        findings = lco._engine_finding_counts(conn)
        signals = lco._detect_model_arbitrage(costs, findings)
        assert all(s.engine_name != "similar" for s in signals)


# ---------------------------------------------------------------------------
# Format helper
# ---------------------------------------------------------------------------


class TestFormatSignal:
    def test_outlier_finding_shape(self):
        s = lco.CostSignal(
            signal_class="outlier",
            engine_name="expensive_engine",
            detail={
                "cost_per_finding": 0.50,
                "median_cost_per_finding": 0.05,
                "ratio": 10.0,
                "total_cost_usd": 5.00,
                "finding_count": 10,
                "calls": 50,
                "models": ["grok-4"],
                "window_days": 7,
            },
        )
        what, _so_what, now_what = lco._format_signal(s)
        assert "expensive_engine" in what
        assert "10.0" in what or "10x" in what
        assert "model_router" in now_what

    def test_stagnant_finding_shape(self):
        s = lco.CostSignal(
            signal_class="stagnant",
            engine_name="silent",
            detail={
                "cost_usd": 2.50,
                "calls": 25,
                "tokens_input": 5000,
                "tokens_output": 1000,
                "models": ["grok-4"],
                "window_days": 7,
            },
        )
        what, so_what, _ = lco._format_signal(s)
        assert "silent" in what
        assert "2.5" in what
        assert "zero findings" in what
        assert "degrad" in so_what.lower()

    def test_arbitrage_finding_shape(self):
        s = lco.CostSignal(
            signal_class="arbitrage",
            engine_name="dual_runner",
            detail={
                "cheapest_model": "grok-4-fast",
                "cheapest_cost_per_finding": 0.02,
                "priciest_model": "grok-4",
                "priciest_cost_per_finding": 0.20,
                "savings_ratio": 10.0,
                "finding_count": 20,
                "window_days": 7,
            },
        )
        what, _, now_what = lco._format_signal(s)
        assert "grok-4-fast" in what
        assert "10.0" in what or "10x" in what
        assert "grok-4-fast" in now_what


# ---------------------------------------------------------------------------
# Cooldown
# ---------------------------------------------------------------------------


class TestCooldown:
    def test_cooldown_skips_recently_emitted(self, db_path):
        conn = connect(db_path)
        conn.execute(
            """
            INSERT INTO evidence
                (timestamp, domain, engine, evidence_type, finding,
                 confidence, raw_data)
            VALUES (?, 'self_maintenance', 'llm_cost_optimizer',
                    'cost_efficiency_signal', 'WHAT...', 0.70, ?)
            """,
            (
                _ts(3600),
                '{"data": {"engine_name": "alpha", "signal_class": "outlier"}, "provenance": "system"}',
            ),
        )
        conn.commit()
        assert lco._was_recently_emitted(conn, "alpha", "outlier") is True
        assert lco._was_recently_emitted(conn, "beta", "outlier") is False
        assert lco._was_recently_emitted(conn, "alpha", "stagnant") is False
        conn.close()


# ---------------------------------------------------------------------------
# CostSignal dataclass
# ---------------------------------------------------------------------------


class TestCostSignal:
    def test_is_frozen(self):
        s = lco.CostSignal(
            signal_class="outlier",
            engine_name="x",
            detail={"foo": 1},
        )
        from dataclasses import FrozenInstanceError

        with pytest.raises(FrozenInstanceError):
            s.engine_name = "y"


# ---------------------------------------------------------------------------
# End-to-end
# ---------------------------------------------------------------------------


class TestEndToEnd:
    def test_persists_findings_for_detected_signals(self, db_path):
        conn = connect(db_path)
        # Plant a stagnant-spend signal: $1.00 spent, zero findings
        _insert_cost(conn, module="zombie_engine", cost_usd=1.00)
        conn.close()

        result = lco.run_llm_cost_optimizer(db_path=db_path)
        assert result["signals_detected"] >= 1
        assert result["findings_persisted"] >= 1
        assert result["by_class"]["stagnant"] >= 1
