# SPDX-License-Identifier: MIT
"""Tests for ``nebula bootstrap`` CLI — task #73 Phase 2.

Pins the safety rails that matter most for bootstrap:
- Refuses to run when no URL is provided.
- Refuses to layer elder content on a non-empty DB unless --force.
- Accepts URL from env var (``NEBULA_ELDER_URL``).
- Delegates the download to ``sync_from_url`` (we don't re-test the
  HTTP path — it's already covered by core.sync tests).
- Surfaces peer-attribution count when the elder_id field was
  recorded via the task #73 Phase 1 hook.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import nebula_cli

from core.persistence.schema import ensure_schema


@pytest.fixture
def fresh_env(tmp_path, monkeypatch):
    """Redirect DB + env overrides for each test."""
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "engine.db"
    # Re-point module-level DB + DATA_DIR.
    monkeypatch.setattr(nebula_cli, "DATA_DIR", data_dir)
    monkeypatch.setattr(nebula_cli, "DB", db_path)
    monkeypatch.delenv("NEBULA_ELDER_URL", raising=False)
    return db_path


class TestRefuseMissingUrl:
    def test_no_url_and_no_env_exits_2(self, fresh_env, monkeypatch):
        monkeypatch.setattr(sys, "argv", ["nebula", "bootstrap"])
        with pytest.raises(SystemExit) as exc:
            nebula_cli.cmd_bootstrap([])
        assert exc.value.code == 2


class TestEnvFallback:
    def test_env_var_provides_url(self, fresh_env, monkeypatch):
        monkeypatch.setenv("NEBULA_ELDER_URL", "https://elder.example.com/snap.json.gz")
        with patch.object(nebula_cli, "cmd_bootstrap") as _:
            pass  # Just proving we don't short-circuit before fallback.

        with patch(
            "core.sync.sync_from_url",
            return_value={
                "evidence_imported": 1,
                "evidence_skipped": 0,
                "hypotheses_imported": 0,
                "hypotheses_skipped": 0,
            },
        ) as sync:
            nebula_cli.cmd_bootstrap([])
        # sync_from_url was called with the env URL.
        assert sync.call_args.kwargs.get("url") == "https://elder.example.com/snap.json.gz"


class TestExistingDbGuard:
    def test_refuses_to_overwrite_active_db(self, fresh_env):
        # Seed an active DB with evidence rows.
        ensure_schema(str(fresh_env))
        conn = sqlite3.connect(str(fresh_env))
        try:
            conn.execute(
                "INSERT INTO evidence (domain, engine, evidence_type, finding) VALUES (?, ?, ?, ?)",
                ("intelligence", "x", "observation", "existing"),
            )
            conn.commit()
        finally:
            conn.close()

        with pytest.raises(SystemExit) as exc:
            nebula_cli.cmd_bootstrap(["https://elder.example.com/snap.json.gz"])
        assert exc.value.code == 1

    def test_force_flag_overrides_guard(self, fresh_env):
        ensure_schema(str(fresh_env))
        conn = sqlite3.connect(str(fresh_env))
        try:
            conn.execute(
                "INSERT INTO evidence (domain, engine, evidence_type, finding) VALUES (?, ?, ?, ?)",
                ("intelligence", "x", "observation", "existing"),
            )
            conn.commit()
        finally:
            conn.close()

        with patch(
            "core.sync.sync_from_url",
            return_value={
                "evidence_imported": 0,
                "evidence_skipped": 0,
                "hypotheses_imported": 0,
                "hypotheses_skipped": 0,
            },
        ) as sync:
            nebula_cli.cmd_bootstrap(
                [
                    "https://elder.example.com/snap.json.gz",
                    "--force",
                ]
            )
        sync.assert_called_once()


class TestSuccessPath:
    def test_empty_db_bootstraps(self, fresh_env, capsys):
        # No DB file yet — fresh clone scenario.
        assert not fresh_env.exists()

        def _fake_sync(_db_path, *, url):
            # Simulate the import creating the DB + a peer_activity row.
            ensure_schema(_db_path)
            conn = sqlite3.connect(_db_path)
            try:
                conn.execute(
                    "INSERT INTO peer_activity (participant_id) VALUES (?)",
                    ("elder-alice",),
                )
                conn.commit()
            finally:
                conn.close()
            return {
                "evidence_imported": 42,
                "evidence_skipped": 3,
                "hypotheses_imported": 5,
                "hypotheses_skipped": 1,
            }

        with patch("core.sync.sync_from_url", side_effect=_fake_sync):
            nebula_cli.cmd_bootstrap(["https://elder.example.com/snap.json.gz"])
        out = capsys.readouterr().out
        assert "Bootstrap complete" in out
        assert "Evidence: 42" in out
        assert "Elder attribution recorded" in out

    def test_sync_error_exits_1(self, fresh_env):
        with (
            patch(
                "core.sync.sync_from_url",
                return_value={"error": "dns lookup failed"},
            ),
            pytest.raises(SystemExit) as exc,
        ):
            nebula_cli.cmd_bootstrap(["https://elder.example.com/snap.json.gz"])
        assert exc.value.code == 1
