# SPDX-License-Identifier: MIT
"""Tests for scripts/smoke_run.py — Gate A (task #100).

Pins the Gate A contract so the script is provably correct even when
the underlying Nebula runner isn't exercised. We mock the subprocess
and DB layer to verify each assertion gate fires as designed.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import smoke_run


def _make_db_with_actions(tmp_path: Path, n_rows: int) -> Path:
    """Fabricate a tmp SQLite DB with ``actions_log`` containing n rows."""
    db = tmp_path / "engine.db"
    conn = sqlite3.connect(str(db))
    try:
        conn.execute("CREATE TABLE actions_log (id INTEGER PRIMARY KEY, action TEXT, ts TEXT)")
        for i in range(n_rows):
            conn.execute(
                "INSERT INTO actions_log (action, ts) VALUES (?, ?)", (f"a{i}", "2026-04-14")
            )
        conn.commit()
    finally:
        conn.close()
    return db


class TestDbActivityAssertion:
    def test_passes_with_rows(self, tmp_path):
        _make_db_with_actions(tmp_path, 3)
        ok, msg = smoke_run._assert_db_has_activity(tmp_path / "engine.db")
        assert ok is True
        assert "3 row" in msg

    def test_fails_when_db_missing(self, tmp_path):
        ok, msg = smoke_run._assert_db_has_activity(tmp_path / "nonexistent.db")
        assert ok is False
        assert "not created" in msg

    def test_fails_when_actions_log_empty(self, tmp_path):
        _make_db_with_actions(tmp_path, 0)
        ok, msg = smoke_run._assert_db_has_activity(tmp_path / "engine.db")
        assert ok is False
        assert "empty" in msg

    def test_fails_when_actions_log_missing(self, tmp_path):
        # DB exists but has no actions_log table
        db = tmp_path / "engine.db"
        conn = sqlite3.connect(str(db))
        conn.execute("CREATE TABLE unrelated (id INTEGER)")
        conn.commit()
        conn.close()
        ok, msg = smoke_run._assert_db_has_activity(db)
        assert ok is False
        assert "actions_log" in msg


class TestCriticalLogAssertion:
    def test_passes_with_no_critical(self):
        stderr = "[INFO] x\n[WARN] y\n[ERROR] z"
        ok, msg = smoke_run._assert_no_critical_logs(stderr)
        assert ok is True
        assert "no CRITICAL" in msg

    def test_fails_on_critical_bracket_form(self):
        stderr = "[INFO] fine\n[CRITICAL] something exploded"
        ok, msg = smoke_run._assert_no_critical_logs(stderr)
        assert ok is False
        assert "1 CRITICAL" in msg

    def test_fails_on_critical_dash_form(self):
        # logging module default format: "LEVEL - message"
        stderr = "2026-04-14 [core.x] CRITICAL - something broke"
        ok, msg = smoke_run._assert_no_critical_logs(stderr)
        assert ok is False
        assert "1 CRITICAL" in msg

    def test_truncates_message_at_three_lines(self):
        stderr = "\n".join(f"[CRITICAL] err {i}" for i in range(10))
        ok, msg = smoke_run._assert_no_critical_logs(stderr)
        assert ok is False
        assert "10 CRITICAL" in msg
        assert "+7 more" in msg


class TestRunNebulaCycle:
    def test_passes_sandbox_env_vars(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "should-be-cleared")
        captured: dict = {}

        def fake_run(cmd, **kwargs):
            captured["cmd"] = cmd
            captured["env"] = kwargs.get("env", {})
            captured["timeout"] = kwargs.get("timeout")
            m = MagicMock()
            m.returncode = 0
            m.stdout = ""
            m.stderr = ""
            return m

        with patch("smoke_run.subprocess.run", side_effect=fake_run):
            smoke_run._run_nebula_cycle(tmp_path)

        assert "--cycles" in captured["cmd"]
        assert "1" in captured["cmd"]
        assert "--db" in captured["cmd"]
        assert any(str(tmp_path / "engine.db") in str(c) for c in captured["cmd"])
        # Sandbox env: data dir override set, XAI key stripped.
        assert captured["env"]["NEBULA_DATA_DIR"] == str(tmp_path)
        assert "XAI_API_KEY" not in captured["env"]
        # War-room skip for determinism.
        assert captured["env"].get("NEBULA_SKIP_WAR_ROOM") == "1"
        # Timeout bounded.
        assert captured["timeout"] == smoke_run.SMOKE_TIMEOUT_SECONDS

    def test_scopes_to_lightweight_domains(self, tmp_path):
        with patch("smoke_run.subprocess.run") as run:
            run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            smoke_run._run_nebula_cycle(tmp_path)
        cmd = run.call_args[0][0]
        assert "--domains" in cmd
        # Scoped to self-audit domains so the smoke run doesn't need
        # a 160-repo workspace.
        assert smoke_run.SMOKE_DOMAINS in cmd


class TestJsonMode:
    def _patch_happy_cycle(self, tmp_path: Path):
        """Build a patch stack that fakes a successful cycle."""
        # Fake DB that passes the actions_log assertion.
        _make_db_with_actions(tmp_path, 3)
        # Fake proc with exit 0 + no CRITICAL logs.
        proc = MagicMock(returncode=0, stdout="", stderr="[INFO] happy\n")

        def _fake_run_cycle(data_dir, verbose=False):
            # The real _run_nebula_cycle writes engine.db to the dir;
            # we already did that above. Just return the fake proc.
            return proc

        return _fake_run_cycle

    def test_json_mode_emits_single_line_summary(self, tmp_path, monkeypatch, capsys):
        import json

        cycle = self._patch_happy_cycle(tmp_path)
        monkeypatch.setattr(sys, "argv", ["smoke_run.py", "--json"])

        # Patch mkdtemp to return the prepared dir so the DB the
        # helper wrote is the one the assertion reads.
        with (
            patch("smoke_run.tempfile.mkdtemp", return_value=str(tmp_path)),
            patch("smoke_run._run_nebula_cycle", side_effect=cycle),
        ):
            rc = smoke_run.main()

        assert rc == 0
        out = capsys.readouterr().out.strip()
        # JSON mode: ONE line of JSON, nothing else.
        assert "\n" not in out
        payload = json.loads(out)
        assert payload["gate"] == "A"
        assert payload["passed"] is True
        names = {i["name"] for i in payload["invariants"]}
        assert names == {"subprocess_exit_zero", "db_activity", "no_critical_logs"}

    def test_json_mode_exit_1_on_failure(self, tmp_path, monkeypatch, capsys):
        import json

        # Fake cycle that exits non-zero.
        proc = MagicMock(returncode=7, stdout="", stderr="")

        def _fake_run_cycle(data_dir, verbose=False):
            return proc

        monkeypatch.setattr(sys, "argv", ["smoke_run.py", "--json"])
        with (
            patch("smoke_run.tempfile.mkdtemp", return_value=str(tmp_path)),
            patch("smoke_run._run_nebula_cycle", side_effect=_fake_run_cycle),
        ):
            rc = smoke_run.main()
        assert rc == 1
        out = capsys.readouterr().out.strip()
        payload = json.loads(out)
        assert payload["passed"] is False
        # At least one invariant must be False.
        assert any(not inv["passed"] for inv in payload["invariants"])

    def test_human_mode_still_works(self, tmp_path, monkeypatch, capsys):
        cycle = self._patch_happy_cycle(tmp_path)
        monkeypatch.setattr(sys, "argv", ["smoke_run.py"])
        with (
            patch("smoke_run.tempfile.mkdtemp", return_value=str(tmp_path)),
            patch("smoke_run._run_nebula_cycle", side_effect=cycle),
        ):
            rc = smoke_run.main()
        assert rc == 0
        out = capsys.readouterr().out
        # Human mode = multi-line pretty output with checkmarks.
        assert "[OK]" in out
        assert "Gate A: PASSED" in out
