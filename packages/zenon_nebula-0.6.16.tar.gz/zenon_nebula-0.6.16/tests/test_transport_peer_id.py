# SPDX-License-Identifier: MIT
"""Tests for core.transport.get_local_peer_id (task #39 v1)."""

from __future__ import annotations

import core.transport as transport


class TestGetLocalPeerIdEnvVar:
    """ZENON_PEER_ADDRESS env var is the first-layer peer identity."""

    def test_valid_env_address_wins(self, monkeypatch, tmp_path):
        # Real-shape address: "z1" + 38 lowercase alnum chars
        addr = "z1" + "q" * 38
        monkeypatch.setenv("ZENON_PEER_ADDRESS", addr)
        monkeypatch.setattr(transport, "_PEER_ID_CACHE", None)
        monkeypatch.setattr(transport, "_PEER_ID_FILE", tmp_path / "peer_id.txt")
        assert transport.get_local_peer_id() == addr

    def test_invalid_env_address_falls_through(self, monkeypatch, tmp_path, caplog):
        # Garbage env value — should be rejected, warning logged, random fallback used
        monkeypatch.setenv("ZENON_PEER_ADDRESS", "not-a-real-zenon-address")
        monkeypatch.setattr(transport, "_PEER_ID_CACHE", None)
        monkeypatch.setattr(transport, "_PEER_ID_FILE", tmp_path / "peer_id.txt")
        import logging

        with caplog.at_level(logging.WARNING, logger="core.transport"):
            result = transport.get_local_peer_id()
        assert result.startswith("peer:")
        assert any("not look like a Zenon address" in rec.message for rec in caplog.records)

    def test_empty_env_address_falls_through_quietly(self, monkeypatch, tmp_path, caplog):
        # Empty string should NOT log a warning — operator simply didn't set it
        monkeypatch.setenv("ZENON_PEER_ADDRESS", "")
        monkeypatch.setattr(transport, "_PEER_ID_CACHE", None)
        monkeypatch.setattr(transport, "_PEER_ID_FILE", tmp_path / "peer_id.txt")
        import logging

        with caplog.at_level(logging.WARNING, logger="core.transport"):
            result = transport.get_local_peer_id()
        assert result.startswith("peer:")
        assert not any("Zenon address" in rec.message for rec in caplog.records), (
            "empty env var should fall through quietly"
        )

    def test_missing_env_uses_random_fallback(self, monkeypatch, tmp_path):
        monkeypatch.delenv("ZENON_PEER_ADDRESS", raising=False)
        monkeypatch.setattr(transport, "_PEER_ID_CACHE", None)
        monkeypatch.setattr(transport, "_PEER_ID_FILE", tmp_path / "peer_id.txt")
        result = transport.get_local_peer_id()
        assert result.startswith("peer:")
        assert len(result) > len("peer:")

    def test_persisted_random_id_survives_restart(self, monkeypatch, tmp_path):
        peer_file = tmp_path / "peer_id.txt"
        monkeypatch.delenv("ZENON_PEER_ADDRESS", raising=False)
        monkeypatch.setattr(transport, "_PEER_ID_CACHE", None)
        monkeypatch.setattr(transport, "_PEER_ID_FILE", peer_file)

        first = transport.get_local_peer_id()

        # Simulate a restart: clear cache only, file stays
        monkeypatch.setattr(transport, "_PEER_ID_CACHE", None)
        second = transport.get_local_peer_id()

        assert first == second
        assert first.startswith("peer:")

    def test_uppercase_env_address_rejected(self, monkeypatch, tmp_path):
        """Tolerating uppercase would silently canonicalize — force operator
        to fix the typo instead."""
        addr_mixed = "Z1" + "q" * 38  # uppercase prefix
        monkeypatch.setenv("ZENON_PEER_ADDRESS", addr_mixed)
        monkeypatch.setattr(transport, "_PEER_ID_CACHE", None)
        monkeypatch.setattr(transport, "_PEER_ID_FILE", tmp_path / "peer_id.txt")
        result = transport.get_local_peer_id()
        assert result != addr_mixed
        assert result.startswith("peer:")
