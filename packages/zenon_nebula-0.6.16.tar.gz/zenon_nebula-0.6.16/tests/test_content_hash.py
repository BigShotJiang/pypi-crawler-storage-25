# SPDX-License-Identifier: MIT
"""v0.3.3 content-addressing regression tests.

Phase A of the v0.4.0 content-based trust design (task #46): every
finding now gets a canonical SHA-256 content_hash so the same finding
produced by multiple peers resolves to the same hash. This is the
foundation for:

- Anti-funnel trust (v0.4.0) — peer_corroboration merges findings
  from independent source_repos with the same content_hash instead
  of deduping them.
- On-chain reward attribution (task #39 v3) — the nebula_attestation
  embedded contract hashes content_hash into on-chain state.
- Single-source-bias detection (hypothesis hardener) — checks whether
  supporting evidence for a hypothesis all comes from one peer via
  `discoverer_peer_id`.

These tests pin the canonical hashing logic (which is load-bearing
forever once on-chain attestations exist) and the new evidence columns
(`discoverer_peer_id`, `content_hash`, `signature`).
"""

from __future__ import annotations

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.findings import compute_content_hash, persist_finding
from core.persistence.schema import ensure_schema


class TestContentHashCanonical:
    """Pin the canonical hashing logic — load-bearing forever."""

    def test_identical_inputs_produce_identical_hash(self):
        """Same inputs → same hash on every run."""
        h1 = compute_content_hash(
            engine="spec_audit",
            evidence_type="missing_test_vectors",
            finding="WHAT: PTLC spec has 4 ABI methods but 0 test vectors. SO WHAT: ... NOW WHAT: ...",
            source_file="docs/specs/PTLC/ptlc_spec.md",
            source_line=42,
            source_commit="abc123def456",
        )
        h2 = compute_content_hash(
            engine="spec_audit",
            evidence_type="missing_test_vectors",
            finding="WHAT: PTLC spec has 4 ABI methods but 0 test vectors. SO WHAT: ... NOW WHAT: ...",
            source_file="docs/specs/PTLC/ptlc_spec.md",
            source_line=42,
            source_commit="abc123def456",
        )
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex length

    def test_different_source_line_produces_different_hash(self):
        """Finding at line 42 and line 43 are DIFFERENT findings."""
        h1 = compute_content_hash(
            engine="spec_audit",
            evidence_type="untestable_claims",
            finding="same text",
            source_file="same.md",
            source_line=42,
            source_commit="abc",
        )
        h2 = compute_content_hash(
            engine="spec_audit",
            evidence_type="untestable_claims",
            finding="same text",
            source_file="same.md",
            source_line=43,
            source_commit="abc",
        )
        assert h1 != h2

    def test_different_commit_produces_different_hash(self):
        """Same finding at different commits is a different finding."""
        h1 = compute_content_hash(
            engine="spec_audit",
            evidence_type="x",
            finding="same",
            source_file="same.md",
            source_line=1,
            source_commit="commitA",
        )
        h2 = compute_content_hash(
            engine="spec_audit",
            evidence_type="x",
            finding="same",
            source_file="same.md",
            source_line=1,
            source_commit="commitB",
        )
        assert h1 != h2

    def test_none_vs_zero_line_normalized(self):
        """source_line=None and source_line=0 hash to the same value."""
        h1 = compute_content_hash(engine="x", evidence_type="y", finding="z", source_line=None)
        h2 = compute_content_hash(engine="x", evidence_type="y", finding="z", source_line=0)
        assert h1 == h2

    def test_none_vs_empty_string_normalized(self):
        """source_file=None and source_file='' hash to the same value."""
        h1 = compute_content_hash(engine="x", evidence_type="y", finding="z", source_file=None)
        h2 = compute_content_hash(engine="x", evidence_type="y", finding="z", source_file="")
        assert h1 == h2

    def test_hash_is_deterministic_across_dict_order(self):
        """The JSON canonicalization sorts keys — dict order can't leak."""
        # Call compute_content_hash twice with identical inputs; the
        # internal dict construction order is implementation-detail and
        # the test pins that json.dumps(sort_keys=True) is used.
        h1 = compute_content_hash("a", "b", "c", "d", 1, "e")
        h2 = compute_content_hash("a", "b", "c", "d", 1, "e")
        assert h1 == h2


class TestPersistFindingContentHash:
    """persist_finding computes + stores content_hash on every row."""

    def test_content_hash_populated_on_insert(self, tmp_path):
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        row_id = persist_finding(
            db_path=db,
            domain="development",
            engine="spec_audit",
            evidence_type="missing_test_vectors",
            finding="WHAT/SO WHAT/NOW WHAT body",
            confidence=0.9,
            source_file="docs/specs/PTLC/spec.md",
            source_line=42,
            source_commit="deadbeef",
        )
        assert row_id > 0

        import sqlite3

        conn = sqlite3.connect(db)
        row = conn.execute(
            "SELECT content_hash, discoverer_peer_id FROM evidence WHERE id = ?",
            (row_id,),
        ).fetchone()
        conn.close()

        assert row is not None
        assert row[0] is not None and len(row[0]) == 64  # content_hash populated
        assert row[1] is not None  # discoverer_peer_id populated from transport

    def test_same_finding_from_same_source_dedups(self, tmp_path):
        """The canonical v0.3.3 dedup path: same content_hash = same row."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        row_id_1 = persist_finding(
            db_path=db,
            domain="development",
            engine="spec_audit",
            evidence_type="X",
            finding="body",
            confidence=0.7,
            source_file="a.md",
            source_line=1,
            source_commit="c1",
        )
        row_id_2 = persist_finding(
            db_path=db,
            domain="development",
            engine="spec_audit",
            evidence_type="X",
            finding="body",
            confidence=0.7,
            source_file="a.md",
            source_line=1,
            source_commit="c1",
        )
        # Dedup: second persist returns the first row's id
        assert row_id_1 == row_id_2

    def test_same_finding_different_source_does_not_dedup(self, tmp_path):
        """Same finding text at a different file/line is a different finding.

        This is the critical behavior difference vs. the legacy dedup
        key `(engine, type, finding)`: pre-v0.3.3, spec_audit finding
        "missing test vectors" in file A at line 42 and the same text
        in file B at line 99 would dedup (legacy key doesn't include
        file/line). v0.3.3 correctly treats them as distinct.
        """
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        row_a = persist_finding(
            db_path=db,
            domain="development",
            engine="spec_audit",
            evidence_type="X",
            finding="body",
            confidence=0.7,
            source_file="a.md",
            source_line=1,
            source_commit="c1",
        )
        row_b = persist_finding(
            db_path=db,
            domain="development",
            engine="spec_audit",
            evidence_type="X",
            finding="body",
            confidence=0.7,
            source_file="b.md",  # different file
            source_line=99,
            source_commit="c1",
        )
        assert row_a > 0
        assert row_b > 0
        assert row_a != row_b

    def test_discoverer_peer_id_can_be_overridden(self, tmp_path):
        """Caller can pass a specific peer_id (e.g., for peer-imported findings)."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        row_id = persist_finding(
            db_path=db,
            domain="development",
            engine="spec_audit",
            evidence_type="X",
            finding="imported finding",
            confidence=0.7,
            source_file="x.md",
            source_line=1,
            source_commit="cX",
            discoverer_peer_id="peer:deadbeef1234567",
        )
        import sqlite3

        conn = sqlite3.connect(db)
        row = conn.execute(
            "SELECT discoverer_peer_id FROM evidence WHERE id = ?",
            (row_id,),
        ).fetchone()
        conn.close()
        assert row[0] == "peer:deadbeef1234567"

    def test_signature_column_stored(self, tmp_path):
        """signature column accepts and stores the value."""
        db = str(tmp_path / "test.db")
        ensure_schema(db)

        row_id = persist_finding(
            db_path=db,
            domain="development",
            engine="spec_audit",
            evidence_type="X",
            finding="signed finding",
            confidence=0.7,
            source_file="x.md",
            source_line=1,
            source_commit="cX",
            signature="signature_placeholder_hex",
        )
        import sqlite3

        conn = sqlite3.connect(db)
        row = conn.execute(
            "SELECT signature FROM evidence WHERE id = ?",
            (row_id,),
        ).fetchone()
        conn.close()
        assert row[0] == "signature_placeholder_hex"


class TestLocalPeerId:
    """v0.3.3 get_local_peer_id resolution order: env > file > random."""

    def test_env_var_wins(self, tmp_path, monkeypatch):
        """ZENON_PEER_ADDRESS env var is highest priority."""
        from core.transport import get_local_peer_id, reset_peer_id_cache

        reset_peer_id_cache()
        # Valid structural address per task #39 v1 — "z1" + 38 bech32 chars.
        addr = "z1" + "q" * 38
        monkeypatch.setenv("ZENON_PEER_ADDRESS", addr)
        assert get_local_peer_id() == addr
        reset_peer_id_cache()

    def test_random_fallback_when_nothing_set(self, tmp_path, monkeypatch):
        """Without env var and without file, generates a random peer_id."""
        from core.transport import get_local_peer_id, reset_peer_id_cache

        reset_peer_id_cache()
        monkeypatch.delenv("ZENON_PEER_ADDRESS", raising=False)
        # Point peer_id file at tmp to avoid reading the real one
        monkeypatch.setattr("core.transport._PEER_ID_FILE", tmp_path / "peer_id.txt")

        pid = get_local_peer_id()
        assert pid.startswith("peer:")
        assert len(pid) > len("peer:")
        reset_peer_id_cache()

    def test_random_fallback_persists(self, tmp_path, monkeypatch):
        """Second call returns the same random peer_id (persisted)."""
        from core.transport import get_local_peer_id, reset_peer_id_cache

        reset_peer_id_cache()
        monkeypatch.delenv("ZENON_PEER_ADDRESS", raising=False)
        monkeypatch.setattr("core.transport._PEER_ID_FILE", tmp_path / "peer_id.txt")

        pid_1 = get_local_peer_id()
        reset_peer_id_cache()  # simulate process restart
        pid_2 = get_local_peer_id()
        assert pid_1 == pid_2
        reset_peer_id_cache()
