# SPDX-License-Identifier: MIT
"""Tests for the Gate B soak gate wired into scripts/release.py.

Gate B Phase 2 (task #101). Pins:
- ``run_soak_gate`` invokes soak_run.py with the right args
- mock mode passes --mock to soak_run
- real mode doesn't pass --mock
- ``ship`` short-circuits on soak failure
- ``--skip-soak`` makes ship() skip the gate with a warning
- ``soak-check`` subcommand routes to run_soak_gate
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import release


class TestRunSoakGate:
    def test_mock_mode_passes_mock_flag(self):
        with patch("release._run") as run:
            run.return_value = MagicMock(returncode=0)
            rc = release.run_soak_gate(minutes=1, budget=0.01, mock=True)
        assert rc == 0
        cmd = run.call_args[0][0]
        assert "--mock" in cmd
        assert "--minutes" in cmd
        assert "1" in cmd
        assert "--budget" in cmd

    def test_real_mode_omits_mock_flag(self):
        with patch("release._run") as run:
            run.return_value = MagicMock(returncode=0)
            release.run_soak_gate(minutes=1, budget=0.01, mock=False)
        cmd = run.call_args[0][0]
        assert "--mock" not in cmd

    def test_nonzero_exit_propagates(self):
        with patch("release._run") as run:
            run.return_value = MagicMock(returncode=7)
            rc = release.run_soak_gate(minutes=1, budget=0.01, mock=True)
        assert rc == 7

    def test_missing_soak_script_fails_loud(self, monkeypatch, tmp_path):
        # Point ROOT at an empty tmp dir so soak_run.py isn't found.
        monkeypatch.setattr(release, "ROOT", tmp_path)
        rc = release.run_soak_gate(minutes=1, budget=0.01, mock=True)
        assert rc != 0


class TestShipSoakGate:
    def test_skip_soak_bypasses_gate(self):
        with (
            patch("release.validate", return_value=0) as validate,
            patch("release.run_soak_gate") as soak,
            patch("release.check_ci_green_on_main", return_value=0) as ci,
            patch("release.tag_release", return_value=0) as tag,
            patch("release._run") as run,
            patch("release.watch_release_workflow", return_value=0),
            patch("release.read_version_str", return_value="0.6.11"),
        ):
            run.return_value = MagicMock(returncode=0)
            rc = release.ship(skip_soak=True)
        assert rc == 0
        soak.assert_not_called()
        validate.assert_called_once()
        ci.assert_called_once()
        tag.assert_called_once()

    def test_ship_aborts_on_soak_failure(self):
        with (
            patch("release.validate", return_value=0),
            patch("release.run_soak_gate", return_value=1) as soak,
            patch("release.check_ci_green_on_main", return_value=0) as ci,
            patch("release.tag_release") as tag,
            patch("release._run"),
            patch("release.watch_release_workflow"),
            patch.dict("os.environ", {"XAI_API_KEY": "real"}, clear=False),
        ):
            rc = release.ship(skip_soak=False)
        assert rc == 1
        soak.assert_called_once()
        # Downstream gates must NOT run once soak fails.
        ci.assert_not_called()
        tag.assert_not_called()

    def test_ship_runs_soak_mock_when_no_key(self):
        with (
            patch("release.validate", return_value=0),
            patch("release.run_soak_gate", return_value=0) as soak,
            patch("release.check_ci_green_on_main", return_value=0),
            patch("release.tag_release", return_value=0),
            patch("release._run") as run,
            patch("release.watch_release_workflow", return_value=0),
            patch("release.read_version_str", return_value="0.6.11"),
            patch.dict("os.environ", {}, clear=True),
        ):
            run.return_value = MagicMock(returncode=0)
            release.ship()
        # When XAI_API_KEY is unset, soak should be called with mock=True.
        assert soak.call_args.kwargs["mock"] is True

    def test_ship_runs_soak_real_when_key_present(self):
        with (
            patch("release.validate", return_value=0),
            patch("release.run_soak_gate", return_value=0) as soak,
            patch("release.check_ci_green_on_main", return_value=0),
            patch("release.tag_release", return_value=0),
            patch("release._run") as run,
            patch("release.watch_release_workflow", return_value=0),
            patch("release.read_version_str", return_value="0.6.11"),
            patch.dict("os.environ", {"XAI_API_KEY": "real-key"}, clear=False),
        ):
            run.return_value = MagicMock(returncode=0)
            release.ship()
        assert soak.call_args.kwargs["mock"] is False

    def test_ship_soak_uses_override_budget_and_minutes(self):
        with (
            patch("release.validate", return_value=0),
            patch("release.run_soak_gate", return_value=0) as soak,
            patch("release.check_ci_green_on_main", return_value=0),
            patch("release.tag_release", return_value=0),
            patch("release._run") as run,
            patch("release.watch_release_workflow", return_value=0),
            patch("release.read_version_str", return_value="0.6.11"),
            patch.dict("os.environ", {"XAI_API_KEY": "x"}, clear=False),
        ):
            run.return_value = MagicMock(returncode=0)
            release.ship(soak_minutes=5, soak_budget=0.10)
        kwargs = soak.call_args.kwargs
        assert kwargs["minutes"] == 5
        assert kwargs["budget"] == 0.10


class TestValidationOrdering:
    def test_soak_runs_after_validate(self):
        """If validate fails, soak must not run — saves 20 minutes."""
        with (
            patch("release.validate", return_value=1) as validate,
            patch("release.run_soak_gate") as soak,
            patch("release.check_ci_green_on_main") as ci,
        ):
            rc = release.ship()
        assert rc == 1
        validate.assert_called_once()
        soak.assert_not_called()
        ci.assert_not_called()

    def test_soak_runs_before_ci_check(self):
        """If soak fails, ci-check must not run — CI might be flaky
        independently of the soak regression; don't confuse signals."""
        with (
            patch("release.validate", return_value=0),
            patch("release.run_soak_gate", return_value=2),
            patch("release.check_ci_green_on_main") as ci,
            patch.dict("os.environ", {"XAI_API_KEY": "x"}, clear=False),
        ):
            release.ship()
        ci.assert_not_called()
