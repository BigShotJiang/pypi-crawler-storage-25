# SPDX-License-Identifier: MIT
"""Tests for ``core.mission.spec_derivation`` and ``get_active_mission``."""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from core.mission import spec_derivation
from core.mission.definition import FALLBACK_PROVENANCE, get_active_mission
from core.mission.spec_derivation import (
    extract_spec_goals,
    find_spec_directories,
    load_current_mission,
    persist_derived_mission,
    refresh_if_stale,
    synthesize_mission,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_spec_file(
    directory: Path,
    name: str,
    *,
    abstract: str = "",
    motivation: str = "",
    rationale: str = "",
    other: str = "",
) -> Path:
    """Create a fake markdown spec file with the requested sections."""
    directory.mkdir(parents=True, exist_ok=True)
    buf = [f"# {name}\n"]
    if abstract:
        buf.append(f"## Abstract\n\n{abstract}\n")
    if motivation:
        buf.append(f"## 2. Motivation\n\n{motivation}\n")
    if rationale:
        buf.append(f"## Rationale\n\n{rationale}\n")
    if other:
        buf.append(f"## Implementation Details\n\n{other}\n")
    path = directory / name
    path.write_text("\n".join(buf), encoding="utf-8")
    return path


def _git_init(path: Path, *, commit: bool = True) -> str | None:
    """Initialise a tiny git repo so HEAD lookups work; return the HEAD hash."""
    env = {
        **os.environ,
        "GIT_AUTHOR_NAME": "test",
        "GIT_AUTHOR_EMAIL": "test@example.com",
        "GIT_COMMITTER_NAME": "test",
        "GIT_COMMITTER_EMAIL": "test@example.com",
    }
    try:
        subprocess.run(["git", "init", "-q"], cwd=path, check=True, env=env, timeout=5)
    except (OSError, subprocess.SubprocessError):
        pytest.skip("git not available")
        return None
    if not commit:
        return None
    (path / ".placeholder").write_text("x", encoding="utf-8")
    try:
        subprocess.run(["git", "add", "-A"], cwd=path, check=True, env=env, timeout=5)
        subprocess.run(
            ["git", "commit", "-qm", "init"],
            cwd=path,
            check=True,
            env=env,
            timeout=5,
        )
        head = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=path,
            check=True,
            env=env,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        pytest.skip("git commit failed")
        return None
    return head.stdout.strip()


# ---------------------------------------------------------------------------
# find_spec_directories
# ---------------------------------------------------------------------------


def test_find_spec_directories_no_workspace():
    """No workspace configured → empty list, no crash."""
    with patch.object(spec_derivation, "workspace_root", return_value=None):
        assert find_spec_directories() == []


def test_find_spec_directories_finds_developer_commons(tmp_path):
    """A workspace with knowledge/developer-commons/docs/specs is picked up."""
    ws = tmp_path / "fake_ws"
    dc_specs = ws / "knowledge" / "developer-commons" / "docs" / "specs"
    dc_specs.mkdir(parents=True)
    (dc_specs / "PTLC.md").write_text("# PTLC\n", encoding="utf-8")

    # Also add an alternate layout to verify both are detected.
    alt = ws / "core" / "other-repo" / "specs"
    alt.mkdir(parents=True)
    (alt / "x.md").write_text("# x\n", encoding="utf-8")

    with patch.object(spec_derivation, "workspace_root", return_value=ws):
        found = find_spec_directories()

    paths = {str(p) for p in found}
    assert str(dc_specs.resolve()) in paths
    assert str(alt.resolve()) in paths


def test_find_spec_directories_uses_fake_workspace_fixture(fake_workspace):
    """The shared fake_workspace fixture exposes a PTLC spec dir."""
    with patch.object(spec_derivation, "workspace_root", return_value=fake_workspace):
        found = find_spec_directories()

    # fake_workspace sets up .../knowledge/developer-commons/docs/specs/PTLC
    # so the walker should return at least that spec directory.
    assert any("specs" in str(p) for p in found)


# ---------------------------------------------------------------------------
# extract_spec_goals
# ---------------------------------------------------------------------------


def test_extract_spec_goals_parses_headers(tmp_path):
    """Abstract + Motivation + Rationale sections are all extracted."""
    spec_dir = tmp_path / "specs"
    _make_spec_file(
        spec_dir,
        "alpha.md",
        abstract="The alpha contract does X.",
        motivation="We need X because Y.",
        rationale="We chose X over Z because W.",
        other="Unused implementation detail.",
    )

    goals = extract_spec_goals(spec_dir)

    sections = {g["section"] for g in goals}
    assert "abstract" in sections
    assert "motivation" in sections
    assert "rationale" in sections
    # "implementation details" is not a tracked section
    assert not any("implementation" in g["section"] for g in goals)

    # Every goal is tagged with its relative file name.
    assert all(g["file"] == "alpha.md" for g in goals)

    # The text of each section survived extraction.
    abstract = next(g for g in goals if g["section"] == "abstract")
    assert "alpha contract does X" in abstract["text"]


def test_extract_spec_goals_missing_dir_returns_empty(tmp_path):
    """A non-existent spec dir yields an empty list, never raises."""
    assert extract_spec_goals(tmp_path / "does_not_exist") == []


def test_extract_spec_goals_ignores_non_markdown(tmp_path):
    """Non-.md files are never touched."""
    spec_dir = tmp_path / "specs"
    spec_dir.mkdir()
    (spec_dir / "not_a_spec.txt").write_text("## Abstract\nignored\n", encoding="utf-8")
    assert extract_spec_goals(spec_dir) == []


def test_extract_spec_goals_handles_nested_files(tmp_path):
    """Recursion into subdirectories works."""
    spec_dir = tmp_path / "specs"
    nested = spec_dir / "PTLC"
    _make_spec_file(nested, "spec.md", abstract="Nested abstract.")

    goals = extract_spec_goals(spec_dir)
    assert len(goals) >= 1
    # File path is relative to the spec_dir, not the nested dir.
    assert goals[0]["file"].endswith("spec.md")
    assert "PTLC" in goals[0]["file"]


# ---------------------------------------------------------------------------
# synthesize_mission
# ---------------------------------------------------------------------------


def test_synthesize_mission_happy_path_with_mock_llm():
    """A well-formed LLM response produces a valid mission dict."""
    goals = [
        {"file": "PTLC.md", "section": "abstract", "text": "Trustless swaps."},
        {"file": "PTLC.md", "section": "motivation", "text": "Bitcoin interop."},
        {"file": "Portal.md", "section": "rationale", "text": "Bridge design."},
    ]

    fake_response = {
        "text": json.dumps(
            {
                "name": "Zenon trustless BTC interop",
                "one_liner": "Trustless swaps between Bitcoin and Zenon.",
                "pillars": [
                    {
                        "name": "trustless_btc_bridge",
                        "description": "Build a trustless BTC bridge.",
                        "priority": 10,
                        "evidence_files": ["PTLC.md", "Portal.md"],
                    },
                    {
                        "name": "cryptographic_primitives",
                        "description": "Ship PTLC and SPV primitives.",
                        "priority": 8,
                        "evidence_files": ["PTLC.md"],
                    },
                    {
                        "name": "spec_driven_development",
                        "description": "Every feature traces to a spec.",
                        "priority": 7,
                        "evidence_files": ["Portal.md"],
                    },
                ],
            }
        ),
        "cost_usd": 0.001,
        "model": "grok-4.20-0309-reasoning",
        "input_tokens": 100,
        "output_tokens": 200,
    }

    def fake_llm(prompt, system="", model="auto", **_kwargs):
        return fake_response

    mission = synthesize_mission(goals, llm_call=fake_llm)

    assert mission["provenance"] == "synthesized"
    assert mission["name"] == "Zenon trustless BTC interop"
    assert len(mission["pillars"]) == 3
    assert mission["pillars"][0]["name"] == "trustless_btc_bridge"
    assert mission["llm_model"] == "grok-4.20-0309-reasoning"
    assert mission["llm_cost_usd"] == pytest.approx(0.001)
    assert mission["derived_at"]  # non-empty ISO timestamp
    assert mission["raw_synthesis"]


def test_synthesize_mission_empty_goals_returns_empty_provenance():
    """No goals → provenance='empty' and no LLM call."""
    called = []

    def fail_llm(*_args, **_kwargs):
        called.append(True)
        return {"text": "{}"}

    mission = synthesize_mission([], llm_call=fail_llm)
    assert mission["provenance"] == "empty"
    assert mission["pillars"] == []
    assert called == []  # never invoked the LLM


def test_synthesize_mission_falls_back_on_invalid_json():
    """Garbage from the LLM triggers the fallback mission."""
    goals = [
        {"file": "a.md", "section": "abstract", "text": "X"},
        {"file": "b.md", "section": "motivation", "text": "Y"},
    ]

    def bad_llm(*_args, **_kwargs):
        return {"text": "not json at all", "cost_usd": 0.0, "model": "test"}

    mission = synthesize_mission(goals, llm_call=bad_llm)
    assert mission["provenance"] == "fallback"
    assert len(mission["pillars"]) == 1
    assert mission["pillars"][0]["name"] == "spec_corpus_reference"


def test_synthesize_mission_rejects_too_few_pillars():
    """LLM returning only 2 pillars must fail validation and fall back."""
    goals = [{"file": "a.md", "section": "abstract", "text": "X"}]

    def stingy_llm(*_args, **_kwargs):
        return {
            "text": json.dumps(
                {
                    "name": "tiny",
                    "pillars": [
                        {"name": "a", "description": "a"},
                        {"name": "b", "description": "b"},
                    ],
                }
            )
        }

    mission = synthesize_mission(goals, llm_call=stingy_llm)
    assert mission["provenance"] == "fallback"


# ---------------------------------------------------------------------------
# persist + load round-trip
# ---------------------------------------------------------------------------


def test_persist_and_load_round_trip(db_path):
    """persist_derived_mission → load_current_mission yields the same data."""
    now = datetime.now(timezone.utc).isoformat()
    mission = {
        "name": "Test mission",
        "one_liner": "One line",
        "pillars": [
            {"name": "p1", "description": "d1", "priority": 9, "evidence_files": ["f1.md"]},
            {"name": "p2", "description": "d2", "priority": 7, "evidence_files": []},
            {"name": "p3", "description": "d3", "priority": 5, "evidence_files": ["f2.md"]},
        ],
        "source_commit": "abc123",
        "source_repo": "developer-commons",
        "derived_at": now,
        "llm_model": "grok-4.20-0309-reasoning",
        "llm_cost_usd": 0.0042,
        "raw_synthesis": "raw text",
        "provenance": "synthesized",
    }

    row_id = persist_derived_mission(mission, db_path)
    assert row_id > 0

    loaded = load_current_mission(db_path)
    assert loaded is not None
    assert loaded["name"] == "Test mission"
    assert loaded["source_commit"] == "abc123"
    assert loaded["source_repo"] == "developer-commons"
    assert loaded["llm_cost_usd"] == pytest.approx(0.0042)
    assert loaded["provenance"] == "stored"
    assert len(loaded["pillars"]) == 3
    assert loaded["pillars"][0]["name"] == "p1"


def test_load_current_mission_empty_returns_none(db_path):
    """Empty table returns None, not a default dict."""
    assert load_current_mission(db_path) is None


def test_load_current_mission_returns_latest(db_path):
    """When multiple missions exist, the latest insert wins."""
    base = {
        "pillars": [
            {"name": "a", "description": "", "priority": 5, "evidence_files": []},
            {"name": "b", "description": "", "priority": 5, "evidence_files": []},
            {"name": "c", "description": "", "priority": 5, "evidence_files": []},
        ],
        "source_commit": "old",
        "source_repo": "r",
        "derived_at": "2026-01-01T00:00:00+00:00",
        "llm_model": "test",
        "llm_cost_usd": 0.0,
        "raw_synthesis": "",
        "provenance": "synthesized",
    }
    persist_derived_mission({**base, "name": "old"}, db_path)
    persist_derived_mission({**base, "name": "new", "source_commit": "new"}, db_path)

    loaded = load_current_mission(db_path)
    assert loaded is not None
    assert loaded["name"] == "new"
    assert loaded["source_commit"] == "new"


# ---------------------------------------------------------------------------
# refresh_if_stale
# ---------------------------------------------------------------------------


def test_refresh_if_stale_no_workspace_is_noop(db_path):
    """No workspace + no existing mission → no refresh, no crash."""
    with patch.object(spec_derivation, "workspace_root", return_value=None):
        assert refresh_if_stale(db_path) is False
    assert load_current_mission(db_path) is None


def test_refresh_if_stale_skips_when_fresh(db_path):
    """A recently-stored mission does not trigger a refresh."""
    now = datetime.now(timezone.utc).isoformat()
    mission = {
        "name": "fresh",
        "pillars": [
            {"name": "a", "description": "", "priority": 5, "evidence_files": []},
            {"name": "b", "description": "", "priority": 5, "evidence_files": []},
            {"name": "c", "description": "", "priority": 5, "evidence_files": []},
        ],
        "source_commit": "abc",
        "source_repo": "r",
        "derived_at": now,
        "llm_model": "test",
        "llm_cost_usd": 0.0,
        "raw_synthesis": "",
        "provenance": "synthesized",
    }
    persist_derived_mission(mission, db_path)

    # Point at an empty "workspace" so that even if the freshness
    # check somehow slipped, there would be nothing to derive from.
    with patch.object(spec_derivation, "find_spec_directories", return_value=[]):

        def must_not_call(*_a, **_kw):
            raise AssertionError("synthesize_mission must not be called when fresh")

        with patch.object(spec_derivation, "synthesize_mission", side_effect=must_not_call):
            assert refresh_if_stale(db_path, max_age_days=30) is False

    loaded = load_current_mission(db_path)
    assert loaded is not None and loaded["name"] == "fresh"


def test_refresh_if_stale_refreshes_when_old(tmp_path, db_path):
    """An old mission plus a populated spec corpus triggers a re-derivation."""
    # Build a fake workspace with a spec corpus.
    ws = tmp_path / "ws"
    repo = ws / "knowledge" / "developer-commons"
    spec_dir = repo / "docs" / "specs"
    _make_spec_file(
        spec_dir,
        "PTLC.md",
        abstract="Point time-locked contracts.",
        motivation="Trustless atomic swaps.",
        rationale="Point locks beat hash locks for privacy.",
    )
    head = _git_init(repo)
    assert head

    # Seed a very old mission to force the staleness branch.
    stale_ts = (datetime.now(timezone.utc) - timedelta(days=120)).isoformat()
    persist_derived_mission(
        {
            "name": "stale",
            "pillars": [
                {"name": "a", "description": "", "priority": 5, "evidence_files": []},
                {"name": "b", "description": "", "priority": 5, "evidence_files": []},
                {"name": "c", "description": "", "priority": 5, "evidence_files": []},
            ],
            "source_commit": "old-commit",
            "source_repo": "developer-commons",
            "derived_at": stale_ts,
            "llm_model": "test",
            "llm_cost_usd": 0.0,
            "raw_synthesis": "",
            "provenance": "synthesized",
        },
        db_path,
    )

    def fake_llm(prompt=None, system=None, **_kwargs):
        # Return a valid synthesis response so the pipeline completes.
        return {
            "text": json.dumps(
                {
                    "name": "refreshed mission",
                    "one_liner": "Refreshed from specs.",
                    "pillars": [
                        {
                            "name": "trustless_swaps",
                            "description": "From PTLC abstract",
                            "priority": 10,
                            "evidence_files": ["PTLC.md"],
                        },
                        {
                            "name": "atomic_interop",
                            "description": "From PTLC motivation",
                            "priority": 9,
                            "evidence_files": ["PTLC.md"],
                        },
                        {
                            "name": "privacy_preserving",
                            "description": "From PTLC rationale",
                            "priority": 7,
                            "evidence_files": ["PTLC.md"],
                        },
                    ],
                }
            ),
            "cost_usd": 0.002,
            "model": "grok-4.20-0309-reasoning",
        }

    with patch.object(spec_derivation, "workspace_root", return_value=ws):
        refreshed = refresh_if_stale(db_path, max_age_days=30, llm_call=fake_llm)

    assert refreshed is True
    loaded = load_current_mission(db_path)
    assert loaded is not None
    assert loaded["name"] == "refreshed mission"
    assert loaded["source_commit"] == head
    assert len(loaded["pillars"]) == 3


# ---------------------------------------------------------------------------
# get_active_mission
# ---------------------------------------------------------------------------


def test_get_active_mission_returns_fallback_when_db_none():
    """No db_path → hardcoded fallback."""
    mission = get_active_mission(None)
    assert mission["provenance"] == FALLBACK_PROVENANCE
    assert mission["pillars"]  # non-empty
    # The fallback uses the five hardcoded pillar keys.
    names = {p["name"] for p in mission["pillars"]}
    assert "technical_excellence" in names
    assert "security_hardening" in names


def test_get_active_mission_returns_fallback_when_db_empty(db_path):
    """Empty DB → hardcoded fallback."""
    mission = get_active_mission(db_path)
    assert mission["provenance"] == FALLBACK_PROVENANCE
    assert len(mission["pillars"]) == 6


def test_get_active_mission_returns_stored_when_present(db_path):
    """A stored mission beats the fallback."""
    persist_derived_mission(
        {
            "name": "stored mission",
            "pillars": [
                {"name": "x", "description": "", "priority": 5, "evidence_files": []},
                {"name": "y", "description": "", "priority": 5, "evidence_files": []},
                {"name": "z", "description": "", "priority": 5, "evidence_files": []},
            ],
            "source_commit": "c",
            "source_repo": "r",
            "derived_at": datetime.now(timezone.utc).isoformat(),
            "llm_model": "test",
            "llm_cost_usd": 0.0,
            "raw_synthesis": "",
            "provenance": "synthesized",
        },
        db_path,
    )

    active = get_active_mission(db_path)
    assert active["provenance"] == "stored"
    assert active["name"] == "stored mission"
    assert len(active["pillars"]) == 3
