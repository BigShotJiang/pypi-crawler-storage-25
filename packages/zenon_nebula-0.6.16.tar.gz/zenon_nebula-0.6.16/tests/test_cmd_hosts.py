# SPDX-License-Identifier: MIT
"""Tests for ``nebula hosts`` CLI subcommand — task #67 follow-up.

Exercises the add / remove / list / reload subcommands end-to-end
against a tmp allowlist file. Uses the public env override
``NEBULA_ALLOWED_HOSTS_FILE`` so the tests never touch
``data/allowed_api_hosts.txt``.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import nebula_cli


def _reload_universal_http():
    """Force a clean universal_http import so the allowlist cache
    picks up the current env."""
    if "core.universal_http" in sys.modules:
        importlib.reload(sys.modules["core.universal_http"])
    else:
        importlib.import_module("core.universal_http")


@pytest.fixture
def tmp_allowlist(tmp_path, monkeypatch):
    """Yield a tmp allowlist path preconfigured on the env."""
    path = tmp_path / "allowlist.txt"
    path.write_text("seed.example.com\n", encoding="utf-8")
    monkeypatch.setenv("NEBULA_ALLOWED_HOSTS_FILE", str(path))
    _reload_universal_http()
    yield path


def _run_hosts(monkeypatch, *argv_tail):
    """Invoke cmd_hosts with sys.argv = ['nebula', 'hosts', *argv_tail]."""
    monkeypatch.setattr(sys, "argv", ["nebula", "hosts", *argv_tail])
    nebula_cli.cmd_hosts()


class TestList:
    def test_prints_all_hosts(self, tmp_allowlist, capsys, monkeypatch):
        tmp_allowlist.write_text("a.example.com\nb.example.com\n", encoding="utf-8")
        _run_hosts(monkeypatch, "list")
        out = capsys.readouterr().out
        assert "a.example.com" in out
        assert "b.example.com" in out
        assert "2 host(s)" in out

    def test_empty_file_reports_zero(self, tmp_allowlist, capsys, monkeypatch):
        tmp_allowlist.write_text("", encoding="utf-8")
        _run_hosts(monkeypatch, "list")
        assert "No hosts" in capsys.readouterr().out


class TestAdd:
    def test_adds_new_host(self, tmp_allowlist, capsys, monkeypatch):
        _run_hosts(monkeypatch, "add", "new.example.com")
        out = capsys.readouterr().out
        assert "Added" in out
        content = tmp_allowlist.read_text()
        assert "new.example.com" in content
        # Seed preserved.
        assert "seed.example.com" in content

    def test_add_is_idempotent(self, tmp_allowlist, capsys, monkeypatch):
        _run_hosts(monkeypatch, "add", "seed.example.com")
        out = capsys.readouterr().out
        assert "Already listed" in out
        # File still has exactly one "seed.example.com" line.
        assert tmp_allowlist.read_text().count("seed.example.com") == 1

    def test_add_lowercases(self, tmp_allowlist, capsys, monkeypatch):
        _run_hosts(monkeypatch, "add", "MIXED.Example.COM")
        content = tmp_allowlist.read_text()
        assert "mixed.example.com" in content
        assert "MIXED" not in content

    def test_rejects_url_like_input(self, tmp_allowlist, monkeypatch):
        with pytest.raises(SystemExit) as exc:
            _run_hosts(monkeypatch, "add", "https://api.example.com/path")
        assert exc.value.code == 2

    def test_rejects_host_with_space(self, tmp_allowlist, monkeypatch):
        with pytest.raises(SystemExit) as exc:
            _run_hosts(monkeypatch, "add", "has space")
        assert exc.value.code == 2


class TestRemove:
    def test_removes_existing_host(self, tmp_allowlist, capsys, monkeypatch):
        tmp_allowlist.write_text("a.example.com\nb.example.com\nc.example.com\n", encoding="utf-8")
        _run_hosts(monkeypatch, "remove", "b.example.com")
        out = capsys.readouterr().out
        assert "Removed" in out
        content = tmp_allowlist.read_text()
        assert "b.example.com" not in content
        # Others preserved.
        assert "a.example.com" in content
        assert "c.example.com" in content

    def test_remove_missing_host_is_noop(self, tmp_allowlist, capsys, monkeypatch):
        _run_hosts(monkeypatch, "remove", "not-listed.example.com")
        assert "Not listed" in capsys.readouterr().out


class TestReload:
    def test_reload_reports_count(self, tmp_allowlist, capsys, monkeypatch):
        _run_hosts(monkeypatch, "reload")
        out = capsys.readouterr().out
        assert "Reloaded 1 host" in out


class TestUsageErrors:
    def test_no_args_prints_help(self, tmp_allowlist, capsys, monkeypatch):
        _run_hosts(monkeypatch)
        out = capsys.readouterr().out
        assert "list" in out
        assert "add" in out

    def test_unknown_subcommand_exits_2(self, tmp_allowlist, monkeypatch):
        with pytest.raises(SystemExit) as exc:
            _run_hosts(monkeypatch, "bogus")
        assert exc.value.code == 2

    def test_add_without_host_exits_2(self, tmp_allowlist, monkeypatch):
        with pytest.raises(SystemExit) as exc:
            _run_hosts(monkeypatch, "add")
        assert exc.value.code == 2


def teardown_module():
    """Leave universal_http in a clean state for downstream tests."""
    if "core.universal_http" in sys.modules:
        importlib.reload(sys.modules["core.universal_http"])
