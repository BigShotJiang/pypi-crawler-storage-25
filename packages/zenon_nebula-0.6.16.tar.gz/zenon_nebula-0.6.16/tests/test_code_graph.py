# SPDX-License-Identifier: MIT
"""Tests for core/code_graph.py (task #97, v0.6.10).

Pins the CGC-optional contract: the module must always return a
valid list (empty or otherwise) from ``find_callers``, regardless
of whether CGC is installed. Stub functions (``find_dependencies``,
``analyze_impact``) may return ``None`` when no backend can answer;
engines check for None before using the result.

Tests don't invoke the real CGC CLI — we monkeypatch ``shutil.which``
to simulate CGC present/absent and assert both code paths work.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import code_graph


@pytest.fixture(autouse=True)
def _reset_cache():
    """Every test starts with a cold CGC availability cache."""
    code_graph.reset_cache()
    yield
    code_graph.reset_cache()


# ---------------------------------------------------------------------------
# Backend detection
# ---------------------------------------------------------------------------


class TestBackendDetection:
    def test_backend_returns_grep_when_cgc_missing(self, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        result = code_graph.backend()
        assert result.name == "grep"
        assert "CGC not installed" in " ".join(result.notes)

    def test_backend_returns_cgc_when_present(self, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda name: "/usr/bin/cgc" if name == "cgc" else None)

        def _fake_run(cmd, **kwargs):
            class _R:
                returncode = 0
                stdout = "CodeGraphContext 0.4.2\n"
                stderr = ""

            return _R()

        monkeypatch.setattr("subprocess.run", _fake_run)
        code_graph.reset_cache()
        result = code_graph.backend()
        assert result.name == "cgc"
        assert "0.4.2" in result.version


# ---------------------------------------------------------------------------
# find_callers contract
# ---------------------------------------------------------------------------


class TestFindCallersContract:
    def test_short_symbol_returns_empty_list(self):
        # Guard: symbols under 3 chars would match too many false
        # positives. Must return [] not None.
        assert code_graph.find_callers("a") == []
        assert code_graph.find_callers("") == []

    def test_empty_symbol_returns_empty_list(self):
        assert code_graph.find_callers("") == []

    def test_returns_list_not_none_when_cgc_missing(self, monkeypatch, tmp_path):
        # Contract: find_callers NEVER returns None — it always falls
        # back to grep. Only find_dependencies/analyze_impact can return None.
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        result = code_graph.find_callers("nonexistent_symbol_xyz", repo_path=tmp_path)
        assert result == []
        assert isinstance(result, list)

    def test_grep_fallback_finds_matching_line(self, tmp_path, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        code_file = tmp_path / "example.py"
        code_file.write_text(
            "def foo():\n    return my_symbol()\n\nclass Bar:\n    attr = my_symbol\n"
        )
        result = code_graph.find_callers("my_symbol", repo_path=tmp_path)
        assert len(result) == 2
        assert all(cs.backend == "grep" for cs in result)
        # Lines 2 (return my_symbol()) and 5 (attr = my_symbol)
        assert {cs.line for cs in result} == {2, 5}

    def test_grep_respects_word_boundaries(self, tmp_path, monkeypatch):
        # 'validate' must not match 're_validate' or 'validator'
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        code_file = tmp_path / "x.py"
        code_file.write_text(
            "re_validate()\n"
            "validator.check()\n"
            "validate()  # real match\n"
            "x.validate = true  # real match\n"
        )
        result = code_graph.find_callers("validate", repo_path=tmp_path)
        assert {cs.line for cs in result} == {3, 4}

    def test_grep_skips_non_code_files(self, tmp_path, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        (tmp_path / "data.json").write_text('{"my_symbol": 1}')
        (tmp_path / "notes.md").write_text("see my_symbol\n")
        (tmp_path / "code.py").write_text("my_symbol()\n")
        result = code_graph.find_callers("my_symbol", repo_path=tmp_path)
        # Only the .py file counted; .json and .md skipped by default.
        assert len(result) == 1
        assert result[0].file.endswith("code.py")

    def test_grep_skips_node_modules_and_caches(self, tmp_path, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        (tmp_path / "node_modules").mkdir()
        (tmp_path / "node_modules" / "bad.py").write_text("my_symbol()\n")
        (tmp_path / "__pycache__").mkdir()
        (tmp_path / "__pycache__" / "cache.py").write_text("my_symbol()\n")
        (tmp_path / "good.py").write_text("my_symbol()\n")
        result = code_graph.find_callers("my_symbol", repo_path=tmp_path)
        assert len(result) == 1
        assert result[0].file.endswith("good.py")

    def test_max_results_caps_output(self, tmp_path, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        code_file = tmp_path / "many.py"
        lines = ["my_symbol()\n" for _ in range(50)]
        code_file.write_text("".join(lines))
        result = code_graph.find_callers("my_symbol", repo_path=tmp_path, max_results=10)
        assert len(result) == 10


# ---------------------------------------------------------------------------
# find_dependencies / analyze_impact contracts
# ---------------------------------------------------------------------------


class TestGraphStubs:
    def test_find_dependencies_returns_none_without_cgc(self, monkeypatch, tmp_path):
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        assert code_graph.find_dependencies(tmp_path / "whatever.py") is None

    def test_analyze_impact_returns_none_without_cgc(self, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: None)
        code_graph.reset_cache()
        assert code_graph.analyze_impact("foo_symbol") is None


# ---------------------------------------------------------------------------
# CallSite dataclass
# ---------------------------------------------------------------------------


class TestCallSite:
    def test_frozen_dataclass(self):
        cs = code_graph.CallSite(file="/tmp/x.py", line=1, context="foo()", backend="grep")
        # frozen=True dataclass raises FrozenInstanceError on mutation
        from dataclasses import FrozenInstanceError

        with pytest.raises(FrozenInstanceError):
            cs.line = 99

    def test_defaults(self):
        cs = code_graph.CallSite(file="/tmp/x.py", line=5)
        assert cs.context == ""
        assert cs.backend == "grep"
