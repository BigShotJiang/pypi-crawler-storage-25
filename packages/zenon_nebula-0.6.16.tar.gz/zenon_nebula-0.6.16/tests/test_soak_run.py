# SPDX-License-Identifier: MIT
"""Tests for scripts/soak_run.py — Gate B Phase 1 (task #101).

Pins each assertion helper + the subprocess wiring. Each invariant
gets a positive AND negative case so regressions show up immediately.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import soak_run


def _db_with_actions_and_evidence(tmp_path: Path, actions: int, findings: int) -> Path:
    """Build a tmp DB with N actions and M evidence rows + schema."""
    db = tmp_path / "engine.db"
    conn = sqlite3.connect(str(db))
    try:
        conn.execute("CREATE TABLE actions_log (id INTEGER PRIMARY KEY, action TEXT, ts TEXT)")
        conn.execute("CREATE TABLE evidence (id INTEGER PRIMARY KEY, domain TEXT, engine TEXT)")
        for i in range(actions):
            conn.execute(
                "INSERT INTO actions_log (action, ts) VALUES (?, ?)", (f"a{i}", "2026-04-14")
            )
        for i in range(findings):
            conn.execute("INSERT INTO evidence (domain, engine) VALUES (?, ?)", ("x", f"e{i}"))
        conn.commit()
    finally:
        conn.close()
    return db


class TestActionsLogAssertion:
    def test_passes_above_threshold(self, tmp_path):
        _db_with_actions_and_evidence(tmp_path, actions=10, findings=0)
        ok, msg = soak_run._assert_actions_log(tmp_path / "engine.db")
        assert ok is True
        assert "10 row" in msg

    def test_fails_below_threshold(self, tmp_path):
        _db_with_actions_and_evidence(tmp_path, actions=2, findings=0)
        ok, msg = soak_run._assert_actions_log(tmp_path / "engine.db")
        assert ok is False
        assert "2 row" in msg
        assert f"≥{soak_run.MIN_ACTIONS}" in msg

    def test_fails_when_db_missing(self, tmp_path):
        ok, msg = soak_run._assert_actions_log(tmp_path / "nope.db")
        assert ok is False
        assert "not created" in msg

    def test_fails_when_table_missing(self, tmp_path):
        db = tmp_path / "engine.db"
        conn = sqlite3.connect(str(db))
        conn.execute("CREATE TABLE other (id INTEGER)")
        conn.commit()
        conn.close()
        ok, msg = soak_run._assert_actions_log(db)
        assert ok is False
        assert "actions_log" in msg


class TestFindingsAssertion:
    def test_passes_at_exact_threshold(self, tmp_path):
        _db_with_actions_and_evidence(tmp_path, actions=0, findings=10)
        ok, _ = soak_run._assert_findings(tmp_path / "engine.db", 10)
        assert ok is True

    def test_fails_one_short(self, tmp_path):
        _db_with_actions_and_evidence(tmp_path, actions=0, findings=9)
        ok, msg = soak_run._assert_findings(tmp_path / "engine.db", 10)
        assert ok is False
        assert "9 row" in msg

    def test_mock_mode_threshold_is_lower(self):
        # Proves the mode asymmetry — mocked runs pass with 1 finding,
        # real-LLM runs need 10.
        assert soak_run.MIN_FINDINGS_MOCK < soak_run.MIN_FINDINGS_REAL


class TestIntegrityAssertion:
    def test_passes_on_ok_db(self, tmp_path):
        _db_with_actions_and_evidence(tmp_path, 1, 1)
        ok, msg = soak_run._assert_db_integrity(tmp_path / "engine.db")
        assert ok is True
        assert "ok" in msg

    def test_fails_on_unreadable_db(self, tmp_path):
        # A file that isn't a real SQLite db.
        db = tmp_path / "engine.db"
        db.write_bytes(b"not a sqlite file")
        ok, _ = soak_run._assert_db_integrity(db)
        # SQLite will open it but integrity_check will complain, OR
        # the open itself raises. Either way it's False + informative.
        assert ok is False


class TestCriticalLogs:
    def test_passes_with_warn_only(self):
        ok, _ = soak_run._assert_no_critical_logs("[WARN] x\n[INFO] y")
        assert ok is True

    def test_fails_on_critical(self):
        ok, _ = soak_run._assert_no_critical_logs("[CRITICAL] boom")
        assert ok is False


class TestRunNebulaSoak:
    def test_real_mode_aborts_without_api_key(self, tmp_path, monkeypatch):
        monkeypatch.delenv("XAI_API_KEY", raising=False)
        import pytest

        with patch("soak_run.subprocess.run") as run, pytest.raises(SystemExit) as exc:
            soak_run._run_nebula_soak(
                tmp_path,
                minutes=1,
                budget=0.01,
                domains="quality",
                mock=False,
                verbose=False,
            )
        assert exc.value.code == 2
        run.assert_not_called()

    def test_mock_mode_sets_env_and_strips_key(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "should-be-stripped")
        captured: dict = {}

        def fake_run(cmd, **kwargs):
            captured["cmd"] = cmd
            captured["env"] = kwargs.get("env", {})
            m = MagicMock()
            m.returncode = 0
            m.stdout = ""
            m.stderr = ""
            return m

        with patch("soak_run.subprocess.run", side_effect=fake_run):
            proc, _ = soak_run._run_nebula_soak(
                tmp_path,
                minutes=1,
                budget=0.01,
                domains="quality",
                mock=True,
                verbose=False,
            )
        assert proc.returncode == 0
        assert captured["env"].get("NEBULA_MOCK_LLM") == "1"
        assert "XAI_API_KEY" not in captured["env"]
        assert captured["env"]["NEBULA_DATA_DIR"] == str(tmp_path)
        # --max-hours should reflect the minutes conversion.
        assert "--max-hours" in captured["cmd"]
        assert "--domains" in captured["cmd"]
        assert "quality" in captured["cmd"]

    def test_real_mode_preserves_api_key_and_skips_mock_env(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "real-key")
        captured: dict = {}

        def fake_run(cmd, **kwargs):
            captured["env"] = kwargs.get("env", {})
            m = MagicMock()
            m.returncode = 0
            m.stdout = ""
            m.stderr = ""
            return m

        with patch("soak_run.subprocess.run", side_effect=fake_run):
            soak_run._run_nebula_soak(
                tmp_path,
                minutes=1,
                budget=0.01,
                domains="quality",
                mock=False,
                verbose=False,
            )
        assert captured["env"].get("XAI_API_KEY") == "real-key"
        assert "NEBULA_MOCK_LLM" not in captured["env"]


class TestCliArgValidation:
    def test_rejects_zero_minutes(self, monkeypatch, capsys):
        monkeypatch.setattr(sys, "argv", ["soak_run.py", "--minutes", "0", "--mock"])
        assert soak_run.main() == 2

    def test_rejects_negative_budget(self, monkeypatch, capsys):
        monkeypatch.setattr(
            sys, "argv", ["soak_run.py", "--minutes", "1", "--budget", "-1", "--mock"]
        )
        assert soak_run.main() == 2
