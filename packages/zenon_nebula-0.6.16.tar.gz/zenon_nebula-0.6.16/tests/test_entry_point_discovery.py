# SPDX-License-Identifier: MIT
"""Tests for core/extensions/entry_points.py — task #62 Phase 2/4."""

from __future__ import annotations

from unittest.mock import Mock, patch

import pytest

from core.domain_registry import DomainRegistry
from core.extensions.entry_points import (
    HOOK_GROUP,
    PLUGIN_GROUP,
    EntryPointResult,
    discover_entry_point_plugins,
)


class _FakeEP:
    """Stand-in for importlib.metadata.EntryPoint."""

    def __init__(self, name, target, raises=None):
        self.name = name
        self._target = target
        self._raises = raises

    def load(self):
        if self._raises is not None:
            raise self._raises
        return self._target


def _make_valid_plugin_class(name="ep_test_domain"):
    from core.domain_registry import DomainPlugin, EngineDefinition

    class _TestPlugin(DomainPlugin):
        def name(self):
            return name

        def get_description(self):
            return "ep test"

        def get_priority(self):
            return 9

        def get_engines(self):
            return [EngineDefinition(name="ep_engine", description="t", module_path="fake")]

        def decide_next_action(self, context):
            return {"action": "t", "engine": "ep_engine", "priority": 9}

        def get_hypothesis_types(self):
            return []

        def get_aspiration_types(self):
            return []

        def get_collision_signals(self):
            return []

        def get_war_room_contributions(self):
            return []

        def get_self_improvement_metrics(self):
            return {}

        def get_db_schema_sql(self):
            return ""

    return _TestPlugin


def _fresh_registry():
    r = DomainRegistry.__new__(DomainRegistry)
    r._domains = {}
    return r


class TestDiscoverPlugins:
    def test_no_entry_points_returns_zero(self):
        registry = _fresh_registry()
        with patch("core.extensions.entry_points._iter_entry_points", return_value=[]):
            result = discover_entry_point_plugins(registry)
        assert result.plugins_registered == 0
        assert result.hooks_registered == 0

    def test_registers_valid_plugin_class(self):
        registry = _fresh_registry()
        plugin_class = _make_valid_plugin_class()
        ep = _FakeEP("my_plugin", plugin_class)

        def fake_iter(group):
            return [ep] if group == PLUGIN_GROUP else []

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.plugins_registered == 1
        assert result.plugins_failed == 0
        assert registry.get_domain("ep_test_domain") is not None

    def test_load_failure_counted(self):
        registry = _fresh_registry()
        ep = _FakeEP("broken", None, raises=ImportError("no such module"))

        def fake_iter(group):
            return [ep] if group == PLUGIN_GROUP else []

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.plugins_failed == 1
        assert result.plugins_registered == 0

    def test_duplicate_name_skipped_not_failed(self):
        registry = _fresh_registry()
        plugin_class = _make_valid_plugin_class()
        # Pre-register a domain with the same name so the second attempt hits ValueError.
        registry.register(plugin_class())
        ep = _FakeEP("dup", plugin_class)

        def fake_iter(group):
            return [ep] if group == PLUGIN_GROUP else []

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.plugins_registered == 0
        assert result.plugins_failed == 0
        assert any("already registered" in s for s in result.skipped)

    def test_invalid_plugin_target_counted(self):
        registry = _fresh_registry()
        ep = _FakeEP("not_a_plugin", "just_a_string")

        def fake_iter(group):
            return [ep] if group == PLUGIN_GROUP else []

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.plugins_failed == 1


class TestDiscoverHooks:
    def test_hook_callable_invoked(self):
        registry = _fresh_registry()
        hook_callable = Mock()
        ep = _FakeEP("my_hooks", hook_callable)

        def fake_iter(group):
            return [ep] if group == HOOK_GROUP else []

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.hooks_registered == 1
        hook_callable.assert_called_once_with()

    def test_non_callable_hook_counted_as_failure(self):
        registry = _fresh_registry()
        ep = _FakeEP("bad_hook", "not callable")

        def fake_iter(group):
            return [ep] if group == HOOK_GROUP else []

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.hooks_failed == 1
        assert result.hooks_registered == 0

    def test_hook_invocation_exception_counted(self):
        registry = _fresh_registry()

        def boom():
            raise RuntimeError("hook broke")

        ep = _FakeEP("broken_hook", boom)

        def fake_iter(group):
            return [ep] if group == HOOK_GROUP else []

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.hooks_failed == 1


class TestMixed:
    def test_plugins_and_hooks_counted_separately(self):
        registry = _fresh_registry()
        plugin_class = _make_valid_plugin_class()
        hook_callable = Mock()

        def fake_iter(group):
            if group == PLUGIN_GROUP:
                return [_FakeEP("p", plugin_class)]
            return [_FakeEP("h", hook_callable)]

        with patch("core.extensions.entry_points._iter_entry_points", side_effect=fake_iter):
            result = discover_entry_point_plugins(registry)
        assert result.plugins_registered == 1
        assert result.hooks_registered == 1
        hook_callable.assert_called_once_with()
