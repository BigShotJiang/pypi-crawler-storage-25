# SPDX-License-Identifier: MIT
"""Tests for scripts/bench_compare.py — perf regression gate (task #60)."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "scripts"))

import bench_compare as bc


class TestLoadBaselines:
    def test_loads_and_strips_underscore_keys(self, tmp_path):
        f = tmp_path / "baselines.json"
        f.write_text(
            json.dumps(
                {
                    "_comment": "header",
                    "bench_x": {"sc": {"baseline_seconds": 1.0, "tolerance_factor": 2.0}},
                }
            )
        )
        data = bc.load_baselines(f)
        assert "_comment" not in data
        assert "bench_x" in data
        assert data["bench_x"]["sc"]["baseline_seconds"] == 1.0

    def test_real_file_has_expected_shape(self):
        data = bc.load_baselines()
        assert "bench_persist" in data
        assert "persist_1000" in data["bench_persist"]
        entry = data["bench_persist"]["persist_1000"]
        assert "baseline_seconds" in entry


class TestCompare:
    def test_ok_when_under_limit(self):
        measured = {"bench_x": {"sc": 0.5}}
        baselines = {"bench_x": {"sc": {"baseline_seconds": 1.0, "tolerance_factor": 3.0}}}
        records = bc.compare(measured, baselines)
        assert len(records) == 1
        assert records[0]["status"] == "ok"
        assert records[0]["limit_seconds"] == 3.0

    def test_regressed_when_over_limit(self):
        measured = {"bench_x": {"sc": 5.0}}
        baselines = {"bench_x": {"sc": {"baseline_seconds": 1.0, "tolerance_factor": 3.0}}}
        records = bc.compare(measured, baselines)
        assert records[0]["status"] == "regressed"

    def test_missing_baseline_flagged(self):
        measured = {"bench_x": {"new_sc": 0.1}}
        baselines = {"bench_x": {}}
        records = bc.compare(measured, baselines)
        assert records[0]["status"] == "missing_baseline"
        assert records[0]["limit_seconds"] is None

    def test_default_tolerance_when_missing(self):
        measured = {"bench_x": {"sc": 0.5}}
        baselines = {"bench_x": {"sc": {"baseline_seconds": 1.0}}}  # no tolerance_factor
        records = bc.compare(measured, baselines)
        assert records[0]["tolerance_factor"] == bc.DEFAULT_TOLERANCE_FACTOR

    def test_exactly_at_limit_is_ok(self):
        """The limit is inclusive — measured == limit should be ok, not regressed."""
        measured = {"bench_x": {"sc": 3.0}}
        baselines = {"bench_x": {"sc": {"baseline_seconds": 1.0, "tolerance_factor": 3.0}}}
        records = bc.compare(measured, baselines)
        assert records[0]["status"] == "ok"

    def test_multiple_benchmarks(self):
        measured = {
            "bench_a": {"sc1": 0.1, "sc2": 10.0},
            "bench_b": {"sc1": 5.0},
        }
        baselines = {
            "bench_a": {
                "sc1": {"baseline_seconds": 1.0, "tolerance_factor": 3.0},
                "sc2": {"baseline_seconds": 1.0, "tolerance_factor": 3.0},
            },
            "bench_b": {"sc1": {"baseline_seconds": 1.0, "tolerance_factor": 3.0}},
        }
        records = bc.compare(measured, baselines)
        statuses = {(r["benchmark"], r["scenario"]): r["status"] for r in records}
        assert statuses[("bench_a", "sc1")] == "ok"
        assert statuses[("bench_a", "sc2")] == "regressed"
        assert statuses[("bench_b", "sc1")] == "regressed"


class TestFormatRecordLine:
    def test_ok_line_has_ok_marker(self):
        r = {
            "benchmark": "bench_x",
            "scenario": "sc",
            "measured_seconds": 0.5,
            "baseline_seconds": 1.0,
            "tolerance_factor": 3.0,
            "limit_seconds": 3.0,
            "status": "ok",
        }
        line = bc.format_record_line(r)
        assert "[OK " in line
        assert "bench_x::sc" in line

    def test_regressed_line_has_reg_marker(self):
        r = {
            "benchmark": "bench_x",
            "scenario": "sc",
            "measured_seconds": 5.0,
            "baseline_seconds": 1.0,
            "tolerance_factor": 3.0,
            "limit_seconds": 3.0,
            "status": "regressed",
        }
        line = bc.format_record_line(r)
        assert "[REG]" in line

    def test_missing_baseline_line(self):
        r = {
            "benchmark": "bench_x",
            "scenario": "new_sc",
            "measured_seconds": 0.1,
            "baseline_seconds": None,
            "tolerance_factor": None,
            "limit_seconds": None,
            "status": "missing_baseline",
        }
        line = bc.format_record_line(r)
        assert "[?]" in line
        assert "no baseline" in line


class TestUpdateBaselines:
    def test_update_writes_file_preserving_header(self, tmp_path):
        f = tmp_path / "baselines.json"
        initial = {
            "_comment": "do not lose this",
            "bench_x": {"sc": {"baseline_seconds": 9.99, "tolerance_factor": 2.0}},
        }
        f.write_text(json.dumps(initial))
        bc.update_baselines(
            measured={"bench_x": {"sc": 0.123}},
            baselines={"bench_x": {"sc": {"baseline_seconds": 9.99, "tolerance_factor": 2.0}}},
            path=f,
        )
        written = json.loads(f.read_text())
        assert written["_comment"] == "do not lose this"
        assert written["bench_x"]["sc"]["baseline_seconds"] == 0.123
        assert written["bench_x"]["sc"]["tolerance_factor"] == 2.0

    def test_update_adds_new_scenario(self, tmp_path):
        f = tmp_path / "baselines.json"
        f.write_text(json.dumps({"bench_x": {}}))
        bc.update_baselines(
            measured={"bench_x": {"brand_new": 0.5}},
            baselines={"bench_x": {}},
            path=f,
        )
        written = json.loads(f.read_text())
        assert written["bench_x"]["brand_new"]["baseline_seconds"] == 0.5
        assert written["bench_x"]["brand_new"]["tolerance_factor"] == bc.DEFAULT_TOLERANCE_FACTOR


class TestMainCli:
    def test_default_mode_exits_zero_even_on_regression(self, monkeypatch):
        """Warn-only by default — regression must not fail CI."""
        fake_measured = {"bench_persist": {"persist_1000": 999.0}}
        with patch.object(bc, "run_all_benchmarks", return_value=fake_measured):
            assert bc.main([]) == 0

    def test_strict_mode_exits_nonzero_on_regression(self, monkeypatch):
        fake_measured = {"bench_persist": {"persist_1000": 999.0}}
        with patch.object(bc, "run_all_benchmarks", return_value=fake_measured):
            assert bc.main(["--strict"]) == 1

    def test_strict_mode_exits_zero_when_ok(self, monkeypatch):
        fake_measured = {"bench_persist": {"persist_1000": 0.001}}
        with patch.object(bc, "run_all_benchmarks", return_value=fake_measured):
            assert bc.main(["--strict"]) == 0

    def test_json_output(self, monkeypatch, capsys):
        fake_measured = {"bench_persist": {"persist_1000": 0.001}}
        with patch.object(bc, "run_all_benchmarks", return_value=fake_measured):
            bc.main(["--json"])
        out = capsys.readouterr().out
        parsed = json.loads(out)
        assert isinstance(parsed, list)
        assert any(r["benchmark"] == "bench_persist" for r in parsed)

    def test_update_flag_writes_baseline(self, tmp_path, monkeypatch):
        alt = tmp_path / "baselines.json"
        alt.write_text(json.dumps({"bench_persist": {}}))
        monkeypatch.setattr(bc, "BASELINES_PATH", alt)
        fake_measured = {"bench_persist": {"sc": 0.42}}
        with patch.object(bc, "run_all_benchmarks", return_value=fake_measured):
            assert bc.main(["--update"]) == 0
        written = json.loads(alt.read_text())
        assert written["bench_persist"]["sc"]["baseline_seconds"] == 0.42


class TestRealBenchmarks:
    """Sanity check: the real benchmarks fit inside their baselines.

    Marked slow-ish; skipped if bench modules are unimportable (e.g.,
    a fresh clone without the benchmarks/ dir in path).
    """

    def test_full_run_stays_within_limits(self):
        pytest.importorskip("benchmarks.bench_persist")
        measured = bc.run_all_benchmarks()
        baselines = bc.load_baselines()
        records = bc.compare(measured, baselines)
        regressed = [r for r in records if r["status"] == "regressed"]
        # We don't assert zero here because CI runners are noisy — this
        # smoke-tests the round trip but defers to --strict for gating.
        assert isinstance(regressed, list)
