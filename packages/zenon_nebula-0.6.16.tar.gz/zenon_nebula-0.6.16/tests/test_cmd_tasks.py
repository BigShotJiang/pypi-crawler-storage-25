# SPDX-License-Identifier: MIT
"""Tests for ``nebula tasks`` CLI subcommand.

Pins the operator UX contracts:
- Full summary prints status counts + a capped row list.
- Filtering by pending / in_progress / completed works.
- Single-task lookup by numeric arg returns detail.
- Unknown args exit 2.
- Missing YAML exits 2.
- Minimal YAML parser handles comments, indentation, and blank lines.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))
sys.path.insert(0, str(ENGINE_ROOT / "scripts"))

import nebula_cli

YAML_FIXTURE = """\
# top-level comment
version: 1
tasks:
  - id: 1
    title: "first task"
    status: completed
    phase: v0.6.10
    opened: 2026-04-01
    description: |
      Long description that mentions status: wrong-field inside
      but the parser should ignore it (only first occurrence of
      the key wins at the indent level).

  - id: 2
    title: "second task"
    status: in_progress
    phase: v0.6.11
    opened: 2026-04-10

  - id: 3
    title: "third task"
    status: pending
    phase: v0.6.12
    opened: 2026-04-14

  - id: 42
    title: "answer task"
    status: pending
    phase: v0.6.11

# Trailing comment
"""


@pytest.fixture
def fake_tasks_yaml(tmp_path, monkeypatch):
    """Redirect ROOT to a tmp dir with a docs/tasks.yaml fixture."""
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "tasks.yaml").write_text(YAML_FIXTURE, encoding="utf-8")
    monkeypatch.setattr(nebula_cli, "ROOT", tmp_path)
    return tmp_path


class TestFullSummary:
    def test_prints_status_counts(self, fake_tasks_yaml, capsys):
        nebula_cli.cmd_tasks([])
        out = capsys.readouterr().out
        # Counts visible + every task's id.
        assert "4 task(s)" in out
        assert "completed=1" in out
        assert "in_progress=1" in out
        assert "pending=2" in out
        assert "#1" in out
        assert "#42" in out


class TestStatusFilter:
    def test_pending_only(self, fake_tasks_yaml, capsys):
        nebula_cli.cmd_tasks(["pending"])
        out = capsys.readouterr().out
        assert "filtered: status=pending" in out
        assert "2 row(s)" in out
        assert "#3" in out
        assert "#42" in out
        assert "#1" not in out
        assert "#2" not in out

    def test_in_progress_alias(self, fake_tasks_yaml, capsys):
        """Accept both 'in-progress' (operator-friendly) and
        'in_progress' (YAML field value)."""
        nebula_cli.cmd_tasks(["in-progress"])
        out = capsys.readouterr().out
        assert "filtered: status=in_progress" in out
        assert "#2" in out

    def test_completed_filter(self, fake_tasks_yaml, capsys):
        nebula_cli.cmd_tasks(["completed"])
        out = capsys.readouterr().out
        assert "1 row(s)" in out
        assert "#1" in out


class TestPhaseFilter:
    def test_pending_by_phase(self, fake_tasks_yaml, capsys):
        nebula_cli.cmd_tasks(["pending", "--phase", "v0.6.11"])
        out = capsys.readouterr().out
        assert "phase=v0.6.11" in out
        # Only #42 matches pending + v0.6.11.
        assert "#42" in out
        assert "#3" not in out


class TestSingleTaskLookup:
    def test_numeric_arg_shows_detail(self, fake_tasks_yaml, capsys):
        nebula_cli.cmd_tasks(["42"])
        out = capsys.readouterr().out
        assert "#42 — answer task" in out
        assert "status: pending" in out
        assert "phase: v0.6.11" in out

    def test_nonexistent_id_exits_1(self, fake_tasks_yaml):
        with pytest.raises(SystemExit) as exc:
            nebula_cli.cmd_tasks(["999"])
        assert exc.value.code == 1


class TestErrorPaths:
    def test_unknown_arg_exits_2(self, fake_tasks_yaml):
        with pytest.raises(SystemExit) as exc:
            nebula_cli.cmd_tasks(["bogus-arg"])
        assert exc.value.code == 2

    def test_missing_yaml_exits_2(self, tmp_path, monkeypatch):
        # ROOT without docs/tasks.yaml.
        monkeypatch.setattr(nebula_cli, "ROOT", tmp_path)
        with pytest.raises(SystemExit) as exc:
            nebula_cli.cmd_tasks([])
        assert exc.value.code == 2

    def test_help_flag_does_not_exit(self, fake_tasks_yaml, capsys):
        # Help should print and return, not exit.
        nebula_cli.cmd_tasks(["--help"])
        out = capsys.readouterr().out
        assert "docs/tasks.yaml" in out


class TestParserRobustness:
    def test_first_status_key_wins(self, fake_tasks_yaml, capsys):
        """Task #1's description contains 'status: wrong-field' but
        the parser should stick with the real 'status: completed'."""
        nebula_cli.cmd_tasks(["1"])
        out = capsys.readouterr().out
        assert "status: completed" in out
        assert "wrong-field" not in out

    def test_parses_all_tasks_without_crashing(self, tmp_path, monkeypatch):
        """Point ROOT at the real repo and confirm parser doesn't
        crash or drop tasks on the actual production YAML."""
        real_root = Path(__file__).resolve().parents[1]
        monkeypatch.setattr(nebula_cli, "ROOT", real_root)
        import contextlib
        import io

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            nebula_cli.cmd_tasks([])
        out = buf.getvalue()
        # Real YAML has >= 40 tasks; parser must see at least 30 to
        # prove it isn't silently dropping entries.
        import re

        m = re.search(r"(\d+) task\(s\)", out)
        assert m is not None
        assert int(m.group(1)) >= 30
