# SPDX-License-Identifier: MIT
"""Tests for domains.self_maintenance.engines.mcp_discovery — task #66 Phase D.

Covers:
- Parser handles Claude-Code / Cursor / project shapes.
- Transport classification (stdio / http / explicit / unknown).
- Command-fingerprint is stable + never logs the inputs.
- Engine entry point runs to completion against real fixture files.
- OPSEC: env contents + command bodies never reach persisted rows.
- 24h cooldown suppresses repeat findings for the same server.
- Gracefully degrades on missing / malformed / oversize configs.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest

from core.persistence.schema import ensure_schema
from domains.self_maintenance.engines import mcp_discovery

# ---------------------------------------------------------------------------
# Parser helpers
# ---------------------------------------------------------------------------


class TestParser:
    def test_parses_claude_code_shape(self, tmp_path):
        cfg = tmp_path / "settings.json"
        cfg.write_text(
            json.dumps(
                {
                    "mcpServers": {
                        "github": {
                            "command": "npx",
                            "args": ["-y", "@modelcontextprotocol/server-github"],
                            "env": {"GITHUB_TOKEN": "ghp_SECRET"},
                        },
                    }
                }
            )
        )
        scan = mcp_discovery._parse_config(cfg)
        assert scan.skipped_reason is None
        assert len(scan.servers) == 1
        srv = scan.servers[0]
        assert srv.name == "github"
        assert srv.transport == "stdio"
        assert srv.config_path == str(cfg)
        # Fingerprint is a hex prefix, never the command body.
        assert len(srv.command_fingerprint) == 16
        assert "GITHUB_TOKEN" not in srv.command_fingerprint
        assert "ghp_SECRET" not in srv.command_fingerprint

    def test_parses_servers_key_alias(self, tmp_path):
        cfg = tmp_path / "mcp.json"
        cfg.write_text(json.dumps({"servers": {"x": {"command": "foo"}}}))
        scan = mcp_discovery._parse_config(cfg)
        assert len(scan.servers) == 1
        assert scan.servers[0].name == "x"

    def test_classifies_http_transport_via_url(self):
        assert mcp_discovery._classify_transport({"url": "https://x.com"}) == "http"

    def test_classifies_http_transport_via_explicit_type(self):
        assert mcp_discovery._classify_transport({"type": "http"}) == "http"

    def test_classifies_stdio_via_command(self):
        assert mcp_discovery._classify_transport({"command": "python"}) == "stdio"

    def test_classifies_unknown_when_neither(self):
        assert mcp_discovery._classify_transport({}) == "unknown"

    def test_fingerprint_is_deterministic(self):
        a = mcp_discovery._fingerprint_command("npx", ["-y", "pkg"])
        b = mcp_discovery._fingerprint_command("npx", ["-y", "pkg"])
        assert a == b

    def test_fingerprint_differs_on_args(self):
        a = mcp_discovery._fingerprint_command("npx", ["-y", "pkg1"])
        b = mcp_discovery._fingerprint_command("npx", ["-y", "pkg2"])
        assert a != b


# ---------------------------------------------------------------------------
# Degradation paths
# ---------------------------------------------------------------------------


class TestDegradation:
    def test_missing_file_reports_not_found(self, tmp_path):
        scan = mcp_discovery._parse_config(tmp_path / "nope.json")
        assert scan.skipped_reason == "not_found"
        assert scan.servers == []

    def test_malformed_json_reports_parse_failed(self, tmp_path):
        cfg = tmp_path / "bad.json"
        cfg.write_text("{not json")
        scan = mcp_discovery._parse_config(cfg)
        assert scan.skipped_reason is not None
        assert scan.skipped_reason.startswith("parse_failed")
        assert scan.servers == []

    def test_non_object_root_reports_root_not_object(self, tmp_path):
        cfg = tmp_path / "arr.json"
        cfg.write_text("[1, 2, 3]")
        scan = mcp_discovery._parse_config(cfg)
        assert scan.skipped_reason == "root_not_object"

    def test_no_servers_key_reports_missing(self, tmp_path):
        cfg = tmp_path / "plain.json"
        cfg.write_text(json.dumps({"other": "content"}))
        scan = mcp_discovery._parse_config(cfg)
        assert scan.skipped_reason == "no_mcp_servers_key"

    def test_oversize_config_skipped(self, tmp_path, monkeypatch):
        # Use a tiny cap so the test file triggers the size check.
        monkeypatch.setattr(mcp_discovery, "MAX_CONFIG_BYTES", 10)
        cfg = tmp_path / "big.json"
        cfg.write_text(json.dumps({"mcpServers": {"x": {"command": "foo"}}}))
        scan = mcp_discovery._parse_config(cfg)
        assert scan.skipped_reason is not None
        assert scan.skipped_reason.startswith("too_large")


# ---------------------------------------------------------------------------
# End-to-end engine
# ---------------------------------------------------------------------------


class TestRunMcpDiscovery:
    def _setup_db(self, tmp_path):
        db = tmp_path / "engine.db"
        ensure_schema(str(db))
        return str(db)

    def test_no_configs_anywhere_returns_empty_summary(self, tmp_path, monkeypatch):
        db = self._setup_db(tmp_path)
        monkeypatch.setenv("NEBULA_MCP_DISCOVERY_PATHS", "")
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(mcp_discovery, "workspace_root", lambda: None)
        out = mcp_discovery.run_mcp_discovery(db_path=db)
        assert out["engine"] == "mcp_discovery"
        assert out["servers_discovered"] == 0
        assert out["findings_persisted"] == 0
        assert out["reason"] == "no_servers_found"

    def test_discovers_and_persists(self, tmp_path, monkeypatch):
        db = self._setup_db(tmp_path)
        cfg = tmp_path / "mcp.json"
        cfg.write_text(
            json.dumps(
                {
                    "mcpServers": {
                        "alpha": {"command": "python", "args": ["alpha.py"]},
                        "beta": {"url": "https://beta.mcp"},
                    }
                }
            )
        )
        monkeypatch.setenv("NEBULA_MCP_DISCOVERY_PATHS", str(cfg))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(mcp_discovery, "workspace_root", lambda: None)

        out = mcp_discovery.run_mcp_discovery(db_path=db)
        assert out["servers_discovered"] == 2
        assert out["findings_persisted"] == 2

        # Verify each finding, and confirm OPSEC: no command/url/env bytes
        # reach the row.
        with sqlite3.connect(db) as c:
            c.row_factory = sqlite3.Row
            rows = c.execute(
                "SELECT raw_data, finding FROM evidence WHERE engine = 'mcp_discovery'"
            ).fetchall()
        assert len(rows) == 2
        for row in rows:
            body = row["raw_data"] + row["finding"]
            # No secrets / command bodies in the persisted row.
            assert "alpha.py" not in body
            assert "https://beta.mcp" not in body
            # Fingerprint is there, but only as 16 hex chars. persist_finding
            # wraps raw_data under the "data" key.
            payload = json.loads(row["raw_data"])["data"]
            assert payload["server_name"] in {"alpha", "beta"}
            assert payload["transport"] in {"stdio", "http"}
            assert len(payload["command_fingerprint"]) == 16

    def test_cooldown_suppresses_repeat(self, tmp_path, monkeypatch):
        db = self._setup_db(tmp_path)
        cfg = tmp_path / "mcp.json"
        cfg.write_text(json.dumps({"mcpServers": {"alpha": {"command": "foo"}}}))
        monkeypatch.setenv("NEBULA_MCP_DISCOVERY_PATHS", str(cfg))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(mcp_discovery, "workspace_root", lambda: None)

        first = mcp_discovery.run_mcp_discovery(db_path=db)
        assert first["findings_persisted"] == 1
        second = mcp_discovery.run_mcp_discovery(db_path=db)
        assert second["findings_persisted"] == 0
        assert second["servers_discovered"] == 1  # still seen, just not re-emitted

    def test_caps_at_max_findings(self, tmp_path, monkeypatch):
        db = self._setup_db(tmp_path)
        servers = {
            f"srv_{i}": {"command": f"cmd_{i}"}
            for i in range(mcp_discovery.MAX_FINDINGS_PER_CYCLE + 3)
        }
        cfg = tmp_path / "big.json"
        cfg.write_text(json.dumps({"mcpServers": servers}))
        monkeypatch.setenv("NEBULA_MCP_DISCOVERY_PATHS", str(cfg))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(mcp_discovery, "workspace_root", lambda: None)

        out = mcp_discovery.run_mcp_discovery(db_path=db)
        assert out["findings_persisted"] == mcp_discovery.MAX_FINDINGS_PER_CYCLE

    def test_db_error_degrades_gracefully(self, tmp_path, monkeypatch):
        # Point db_path at a non-writable directory to force a connect fail.
        cfg = tmp_path / "mcp.json"
        cfg.write_text(json.dumps({"mcpServers": {"a": {"command": "f"}}}))
        monkeypatch.setenv("NEBULA_MCP_DISCOVERY_PATHS", str(cfg))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        monkeypatch.setattr(mcp_discovery, "workspace_root", lambda: None)

        with patch.object(mcp_discovery, "connect", side_effect=sqlite3.OperationalError("boom")):
            out = mcp_discovery.run_mcp_discovery(db_path="/tmp/unused.db")
        assert out["reason"] == "db_unavailable"
        assert out["findings_persisted"] == 0
