# SPDX-License-Identifier: MIT
"""Tests for domains/intelligence/engines/cross_chain_pattern_finder.py.

Task #98 (v0.6.11+). Engine degrades cleanly across four axes:

- No workspace root → returns "no_workspace" summary, zero findings.
- No go-zenon clone → returns "no_zenon_node".
- No reference chains in the workspace → returns "no_reference_chains"
  plus a hint on what to clone.
- CGC not installed → ``code_graph.find_callers`` falls back to grep,
  so the engine still runs but with lower fidelity. No crash.

Real algorithmic behavior (ranking, finding shape) tested via a
fake workspace with two reference-chain fixtures.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from domains.intelligence.engines import cross_chain_pattern_finder as ccpf

# ---------------------------------------------------------------------------
# Import smoke
# ---------------------------------------------------------------------------


class TestImportSmoke:
    def test_module_imports(self):
        assert hasattr(ccpf, "run_cross_chain_pattern_finder")

    def test_run_callable_with_no_args(self):
        # The scheduler calls engines with only `db_path=`. Ensure the
        # entry point is a zero-required-arg callable.
        import inspect

        sig = inspect.signature(ccpf.run_cross_chain_pattern_finder)
        required = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.name not in ("self", "db_path")
            and p.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.POSITIONAL_ONLY,
            )
        ]
        assert required == []


# ---------------------------------------------------------------------------
# Graceful degradation paths
# ---------------------------------------------------------------------------


class TestGracefulDegradation:
    def test_returns_no_workspace_when_root_missing(self, db_path):
        with patch.object(ccpf, "workspace_root", return_value=None):
            result = ccpf.run_cross_chain_pattern_finder(db_path=db_path)
        assert result["findings"] == 0
        assert result["reason"] == "no_workspace"

    def test_returns_no_zenon_node_when_missing(self, tmp_path, db_path):
        # workspace root exists but no go-zenon inside it
        (tmp_path / "some_other").mkdir()
        with patch.object(ccpf, "workspace_root", return_value=tmp_path):
            result = ccpf.run_cross_chain_pattern_finder(db_path=db_path)
        assert result["findings"] == 0
        assert result["reason"] == "no_zenon_node"

    def test_returns_no_reference_chains(self, tmp_path, db_path):
        # workspace has go-zenon but no reference chains
        (tmp_path / "core").mkdir()
        (tmp_path / "core" / "go-zenon").mkdir()
        (tmp_path / "core" / "go-zenon" / "main.go").write_text(
            "package main\nfunc Validate() {}\n"
        )
        with patch.object(ccpf, "workspace_root", return_value=tmp_path):
            result = ccpf.run_cross_chain_pattern_finder(db_path=db_path)
        assert result["findings"] == 0
        assert result["reason"] == "no_reference_chains"
        assert "hint" in result


# ---------------------------------------------------------------------------
# _find_reference_chain_repos
# ---------------------------------------------------------------------------


class TestFindReferenceChainRepos:
    def test_returns_empty_when_no_workspace(self):
        with patch.object(ccpf, "workspace_root", return_value=None):
            assert ccpf._find_reference_chain_repos() == []

    def test_includes_classified_reference_chain(self, tmp_path):
        # Create a structure that `classify_repo` will tag as btc
        btc_dir = tmp_path / "core" / "bitcoin"
        btc_dir.mkdir(parents=True)
        # classify_repo reads marker files — simulate via patching
        with (
            patch.object(ccpf, "workspace_root", return_value=tmp_path),
            patch.object(
                ccpf,
                "classify_repo",
                side_effect=lambda p: "blockchain_node_btc" if "bitcoin" in p.name else None,
            ),
        ):
            result = ccpf._find_reference_chain_repos()
        names = [p.name for p in result]
        assert "bitcoin" in names

    def test_excludes_zenon_repos(self, tmp_path):
        # go-zenon shouldn't be classified as a reference chain
        go_dir = tmp_path / "core" / "go-zenon"
        go_dir.mkdir(parents=True)
        with (
            patch.object(ccpf, "workspace_root", return_value=tmp_path),
            patch.object(
                ccpf,
                "classify_repo",
                side_effect=lambda p: "node_zenon" if "go-zenon" in p.name else None,
            ),
        ):
            result = ccpf._find_reference_chain_repos()
        assert result == []


# ---------------------------------------------------------------------------
# _sample_zenon_symbols
# ---------------------------------------------------------------------------


class TestSampleZenonSymbols:
    def test_extracts_go_function_names(self, tmp_path):
        zenon = tmp_path / "go-zenon"
        zenon.mkdir()
        (zenon / "a.go").write_text(
            "package main\n"
            "func ValidateSendBlock() {}\n"
            "func (r *Receiver) CheckInputs() {}\n"
            "func b() {}\n"  # lowercase — skipped
            "func c() {}\n"  # lowercase — skipped
        )
        result = ccpf._sample_zenon_symbols(zenon, k=10)
        # Uppercase names ≥ 4 chars — ValidateSendBlock, CheckInputs
        assert "ValidateSendBlock" in result
        assert "CheckInputs" in result

    def test_filters_short_names(self, tmp_path):
        zenon = tmp_path / "go-zenon"
        zenon.mkdir()
        (zenon / "a.go").write_text("func Foo() {}\nfunc LongEnoughName() {}\n")
        result = ccpf._sample_zenon_symbols(zenon, k=10)
        assert "LongEnoughName" in result
        assert "Foo" not in result  # 3 chars — filtered

    def test_handles_nonexistent_dir(self):
        result = ccpf._sample_zenon_symbols(Path("/tmp/nonexistent_xyz_123"), k=5)
        assert result == []

    def test_respects_sample_size(self, tmp_path):
        zenon = tmp_path / "go-zenon"
        zenon.mkdir()
        # Create many function names
        lines = [f"func Function{i}Name() {{}}" for i in range(50)]
        (zenon / "many.go").write_text("package main\n" + "\n".join(lines))
        result = ccpf._sample_zenon_symbols(zenon, k=5)
        assert len(result) == 5


# ---------------------------------------------------------------------------
# _finding_body
# ---------------------------------------------------------------------------


class TestFindingBody:
    def test_finding_body_shape(self):
        pattern = ccpf.CandidatePattern(
            zenon_symbol="ValidateSendBlock",
            zenon_callers=3,
            zenon_file="/tmp/go-zenon/x.go",
            reference_symbol="ValidateSendBlock",
            reference_callers=12,
            reference_file="/tmp/bitcoin/check.cpp",
            reference_repo="bitcoin",
            last_edit_age_days=30,
        )
        what, so_what, now_what = ccpf._finding_body(pattern)
        # WHAT has the caller counts and repo name
        assert "12 callers" in what
        assert "3 callers" in what
        assert "bitcoin" in what
        # SO WHAT explains the battle-testedness angle
        assert "battle-tested" in so_what
        # NOW WHAT includes file references for the reviewer
        assert "check.cpp" in now_what
        assert "research_edge" in now_what

    def test_finding_body_without_age(self):
        pattern = ccpf.CandidatePattern(
            zenon_symbol="Foo",
            zenon_callers=0,
            zenon_file="",
            reference_symbol="Foo",
            reference_callers=5,
            reference_file="/tmp/x.py",
            reference_repo="ref",
            last_edit_age_days=None,
        )
        what, _, _ = ccpf._finding_body(pattern)
        # Should not crash on None age; should just not mention "last edit"
        assert "last edit" not in what


# ---------------------------------------------------------------------------
# CandidatePattern dataclass
# ---------------------------------------------------------------------------


class TestCandidatePattern:
    def test_is_frozen(self):
        p = ccpf.CandidatePattern(
            zenon_symbol="X",
            zenon_callers=0,
            zenon_file="",
            reference_symbol="X",
            reference_callers=1,
            reference_file="",
            reference_repo="",
            last_edit_age_days=None,
        )
        from dataclasses import FrozenInstanceError

        with pytest.raises(FrozenInstanceError):
            p.zenon_callers = 99
