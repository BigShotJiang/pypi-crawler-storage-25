# SPDX-License-Identifier: MIT
"""Tests for the --focus operator directive (task #80, v0.6.10).

Covers:

- ``core.operator_focus.get_focus`` — reading the focus from RunContext.
- ``core.operator_focus.matches_focus`` — keyword matching against text.
- ``RunContext.focus`` field plumbing.
- ``scripts/autonomous.py`` argparse wiring for ``--focus``.

No real engine cycles. Tests drive the helpers directly with a
hand-seeded RunContext singleton.
"""

from __future__ import annotations

import inspect
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.operator_focus import get_focus, matches_focus
from core.run_context import RunContext


@pytest.fixture(autouse=True)
def _reset_run_context():
    """Each test starts with a fresh RunContext singleton."""
    RunContext.reset()
    yield
    RunContext.reset()


# ---------------------------------------------------------------------------
# get_focus
# ---------------------------------------------------------------------------


class TestGetFocus:
    def test_no_context_returns_none(self):
        assert get_focus() is None

    def test_context_without_focus_returns_none(self):
        RunContext.get_current()
        assert get_focus() is None

    def test_context_with_focus_returns_string(self):
        ctx = RunContext.get_current()
        ctx.focus = "PTLC implementation bugs"
        assert get_focus() == "PTLC implementation bugs"

    def test_empty_string_focus_returns_empty(self):
        ctx = RunContext.get_current()
        ctx.focus = ""
        assert get_focus() == ""


# ---------------------------------------------------------------------------
# matches_focus
# ---------------------------------------------------------------------------


class TestMatchesFocus:
    def test_no_focus_returns_false(self):
        assert matches_focus("anything at all") is False

    def test_explicit_focus_matches_keyword(self):
        assert matches_focus("Found a PTLC bug in go-zenon", focus="PTLC bugs") is True

    def test_case_insensitive(self):
        assert matches_focus("found a ptlc bug", focus="PTLC") is True
        assert matches_focus("FOUND A PTLC BUG", focus="ptlc") is True

    def test_no_match_returns_false(self):
        assert matches_focus("staking reward calculation", focus="PTLC bugs") is False

    def test_short_tokens_skipped(self):
        # "of" and "in" are < 3 chars, should be skipped
        assert matches_focus("of in a", focus="of in a") is False

    def test_multi_keyword_any_matches(self):
        assert matches_focus("bridge exploit found", focus="PTLC bridge portal") is True

    def test_empty_text_returns_false(self):
        assert matches_focus("", focus="PTLC bugs") is False

    def test_empty_focus_returns_false(self):
        assert matches_focus("anything", focus="") is False

    def test_punctuation_stripped_from_focus(self):
        # Focus with quotes/punctuation around keywords
        assert matches_focus("found ptlc issue", focus='"PTLC" bugs,') is True

    def test_reads_from_context_when_no_explicit_focus(self):
        ctx = RunContext.get_current()
        ctx.focus = "governance voting"
        assert matches_focus("pillar voting patterns in governance") is True
        assert matches_focus("staking rewards") is False


# ---------------------------------------------------------------------------
# RunContext.focus field
# ---------------------------------------------------------------------------


class TestRunContextFocusField:
    def test_default_is_none(self):
        ctx = RunContext(domain="test", engine="test")
        assert ctx.focus is None

    def test_explicit_value(self):
        ctx = RunContext(domain="test", engine="test", focus="bridge security")
        assert ctx.focus == "bridge security"

    def test_mutation_after_init(self):
        ctx = RunContext(domain="test", engine="test")
        ctx.focus = "PTLC"
        assert ctx.focus == "PTLC"


# ---------------------------------------------------------------------------
# Argparse wiring
# ---------------------------------------------------------------------------


class TestAutonomousArgparse:
    def test_autonomous_main_has_focus_flag(self):
        sys.path.insert(0, str(ENGINE_ROOT / "scripts"))
        import autonomous

        source = inspect.getsource(autonomous.main)
        assert '"--focus"' in source, "autonomous.main() missing --focus flag"

    def test_focus_string_normalization(self):
        # The glue strips whitespace; empty becomes None
        raw = "  PTLC implementation bugs  "
        result = raw.strip() or None
        assert result == "PTLC implementation bugs"

        raw_empty = "   "
        result_empty = raw_empty.strip() or None
        assert result_empty is None
