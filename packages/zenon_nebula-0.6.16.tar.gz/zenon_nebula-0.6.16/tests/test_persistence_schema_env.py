# SPDX-License-Identifier: MIT
"""Tests for NEBULA_DATA_DIR env override in core/persistence/schema.py.

The env var is what lets Gate A (task #100) sandbox its smoke run and
what Gate C (task #102) uses to run two Nebula instances side-by-side.
The default resolution is computed at module import, so these tests
reload the module with different env states to prove both paths.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))


def _reload_schema():
    """Force a fresh import of core.persistence.schema under the
    current process env."""
    if "core.persistence.schema" in sys.modules:
        del sys.modules["core.persistence.schema"]
    return importlib.import_module("core.persistence.schema")


class TestDefaultDbEnvOverride:
    def test_unset_env_falls_back_to_repo_data_dir(self, monkeypatch):
        monkeypatch.delenv("NEBULA_DATA_DIR", raising=False)
        schema = _reload_schema()
        assert schema.DEFAULT_DB.endswith("/data/engine.db")
        # Should point at the repo's own data/ dir.
        assert str(schema.ENGINE_ROOT / "data" / "engine.db") == schema.DEFAULT_DB

    def test_env_set_redirects_default_db(self, tmp_path, monkeypatch):
        monkeypatch.setenv("NEBULA_DATA_DIR", str(tmp_path))
        schema = _reload_schema()
        assert str(tmp_path / "engine.db") == schema.DEFAULT_DB

    def test_empty_env_treated_as_unset(self, monkeypatch):
        monkeypatch.setenv("NEBULA_DATA_DIR", "   ")
        schema = _reload_schema()
        # Whitespace-only should be treated as unset (strip() catches it).
        assert schema.DEFAULT_DB.endswith("/data/engine.db")

    def test_env_expanduser(self, monkeypatch):
        monkeypatch.setenv("NEBULA_DATA_DIR", "~/nebula-test-dir")
        schema = _reload_schema()
        # ~ must be expanded, not left literal.
        assert "~" not in schema.DEFAULT_DB
        assert "nebula-test-dir" in schema.DEFAULT_DB


def teardown_module():
    """Restore the canonical schema import so downstream tests use
    the repo's real DEFAULT_DB, not whatever the last test left."""
    if "core.persistence.schema" in sys.modules:
        del sys.modules["core.persistence.schema"]
    importlib.import_module("core.persistence.schema")
