# SPDX-License-Identifier: MIT
"""Tests for core.diversity — task #72 Phase 1."""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import diversity
from core.persistence.schema import ensure_schema


@pytest.fixture
def fresh_db(tmp_path):
    db = tmp_path / "engine.db"
    ensure_schema(str(db))
    return str(db)


def _seed(db_path: str, rows: list[tuple[str, str, str]]) -> None:
    """rows: list of (engine, source_repo, provenance)."""
    conn = sqlite3.connect(db_path)
    try:
        for engine, repo, prov in rows:
            conn.execute(
                "INSERT INTO evidence (domain, engine, evidence_type, finding, source_repo, provenance) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                ("test", engine, "observation", "some finding", repo, prov),
            )
        conn.commit()
    finally:
        conn.close()


class TestComputeEngineSaturation:
    def test_empty_db_returns_zeros(self, fresh_db):
        stats = diversity.compute_engine_saturation("engine_x", db_path=fresh_db)
        assert stats["finding_count"] == 0
        assert stats["distinct_source_repos"] == 0
        assert stats["distinct_provenances"] == 0

    def test_single_finding_single_repo(self, fresh_db):
        _seed(fresh_db, [("engine_x", "go-zenon", "hypothesis")])
        stats = diversity.compute_engine_saturation("engine_x", db_path=fresh_db)
        assert stats["finding_count"] == 1
        assert stats["distinct_source_repos"] == 1
        assert stats["distinct_provenances"] == 1

    def test_null_and_empty_source_repo_excluded_from_repo_count(self, fresh_db):
        _seed(
            fresh_db,
            [
                ("engine_x", "", "hypothesis"),
                ("engine_x", None, "hypothesis"),
                ("engine_x", "go-zenon", "hypothesis"),
            ],
        )
        stats = diversity.compute_engine_saturation("engine_x", db_path=fresh_db)
        assert stats["finding_count"] == 3
        # Only go-zenon counts — empty + NULL excluded.
        assert stats["distinct_source_repos"] == 1

    def test_multiple_repos_counted_distinctly(self, fresh_db):
        _seed(
            fresh_db,
            [
                ("engine_x", "repo_a", "hypothesis"),
                ("engine_x", "repo_b", "hypothesis"),
                ("engine_x", "repo_c", "imported"),
                ("engine_x", "repo_a", "hypothesis"),  # duplicate, not counted
            ],
        )
        stats = diversity.compute_engine_saturation("engine_x", db_path=fresh_db)
        assert stats["finding_count"] == 4
        assert stats["distinct_source_repos"] == 3
        assert stats["distinct_provenances"] == 2

    def test_other_engines_do_not_leak(self, fresh_db):
        _seed(
            fresh_db,
            [
                ("engine_x", "repo_a", "hypothesis"),
                ("engine_y", "repo_b", "hypothesis"),
                ("engine_y", "repo_c", "hypothesis"),
            ],
        )
        stats = diversity.compute_engine_saturation("engine_x", db_path=fresh_db)
        assert stats["finding_count"] == 1
        assert stats["distinct_source_repos"] == 1

    def test_empty_engine_name_returns_empty(self, fresh_db):
        assert diversity.compute_engine_saturation("", db_path=fresh_db) == {
            "finding_count": 0,
            "distinct_source_repos": 0,
            "distinct_provenances": 0,
        }

    def test_unreachable_db_returns_empty(self, tmp_path):
        # Point at a path that exists as a dir (SQLite will fail to
        # open it as a file).
        bad = tmp_path / "definitely_a_dir"
        bad.mkdir()
        stats = diversity.compute_engine_saturation("x", db_path=str(bad))
        assert stats["finding_count"] == 0


class TestComputeDiversityWeight:
    def test_empty_db_returns_one(self, fresh_db):
        assert diversity.compute_diversity_weight("engine_x", db_path=fresh_db) == 1.0

    def test_at_threshold_returns_one(self, fresh_db):
        # Exactly SATURATION_REPO_THRESHOLD repos — no downweight.
        rows = [
            ("engine_x", f"repo_{i}", "hypothesis")
            for i in range(diversity.SATURATION_REPO_THRESHOLD)
        ]
        _seed(fresh_db, rows)
        assert diversity.compute_diversity_weight("engine_x", db_path=fresh_db) == 1.0

    def test_one_past_threshold_downweights_by_step(self, fresh_db):
        rows = [
            ("engine_x", f"repo_{i}", "hypothesis")
            for i in range(diversity.SATURATION_REPO_THRESHOLD + 1)
        ]
        _seed(fresh_db, rows)
        w = diversity.compute_diversity_weight("engine_x", db_path=fresh_db)
        assert w == pytest.approx(1.0 - diversity.WEIGHT_PER_EXCESS_REPO, abs=0.001)

    def test_saturated_engine_clamps_to_floor(self, fresh_db):
        # 50 distinct repos — way past saturation.
        rows = [("engine_x", f"repo_{i}", "hypothesis") for i in range(50)]
        _seed(fresh_db, rows)
        w = diversity.compute_diversity_weight("engine_x", db_path=fresh_db)
        assert w == diversity.MIN_WEIGHT

    def test_specialized_engine_single_repo_stays_one(self, fresh_db):
        # 100 findings but all from one repo → specialized, no downweight.
        rows = [("engine_x", "single_repo", "hypothesis") for _ in range(100)]
        _seed(fresh_db, rows)
        assert diversity.compute_diversity_weight("engine_x", db_path=fresh_db) == 1.0


class TestConstants:
    def test_min_weight_leaves_room_for_contribution(self):
        # Never silence an engine completely.
        assert diversity.MIN_WEIGHT > 0.5

    def test_threshold_positive(self):
        assert diversity.SATURATION_REPO_THRESHOLD > 0

    def test_decrement_per_repo_positive_and_bounded(self):
        # Must reach the floor within a reasonable number of excess repos.
        assert diversity.WEIGHT_PER_EXCESS_REPO > 0
        # 10 excess repos should bring us to at least the floor.
        drop = diversity.WEIGHT_PER_EXCESS_REPO * 10
        assert 1.0 - drop <= diversity.MIN_WEIGHT
