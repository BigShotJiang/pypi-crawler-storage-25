# SPDX-License-Identifier: MIT
"""Tests for core/workspace_manifest.py (v0.6.10, task #83).

The workspace manifest is the canonical list of Zenon repos a full
Nebula workspace expects. This module loads the manifest, checks
clone status, and supports `./nebula workspace bootstrap` via the
shared helpers. These tests pin the loader schema, the fallback
YAML parser, the status check, and the clone-entry dry-run path.

No real network calls. `clone_entry(dry_run=True)` is used for
command-construction tests; real git is mocked via subprocess.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.workspace_manifest import (
    KNOWN_TIERS,
    Manifest,
    ManifestEntry,
    _coerce_scalar,
    _manifest_from_dict,
    _stdlib_yaml_parse,
    check_status,
    clone_entry,
    load,
)

# ---------------------------------------------------------------------------
# Scalar coercion
# ---------------------------------------------------------------------------


class TestCoerceScalar:
    def test_null_becomes_none(self):
        assert _coerce_scalar("null") is None
        assert _coerce_scalar("~") is None
        assert _coerce_scalar("") is None

    def test_booleans(self):
        assert _coerce_scalar("true") is True
        assert _coerce_scalar("True") is True
        assert _coerce_scalar("yes") is True
        assert _coerce_scalar("false") is False
        assert _coerce_scalar("no") is False

    def test_integers(self):
        assert _coerce_scalar("42") == 42
        assert _coerce_scalar("100") == 100
        assert _coerce_scalar("0") == 0

    def test_quoted_strings(self):
        assert _coerce_scalar('"hello"') == "hello"
        assert _coerce_scalar("'world'") == "world"

    def test_unquoted_strings(self):
        assert _coerce_scalar("go-zenon") == "go-zenon"
        assert _coerce_scalar("https://example.com") == "https://example.com"


# ---------------------------------------------------------------------------
# Stdlib YAML parser
# ---------------------------------------------------------------------------


class TestStdlibYamlParse:
    def test_top_level_scalars(self):
        text = """version: 1
updated: 2026-04-11
"""
        result = _stdlib_yaml_parse(text)
        assert result["version"] == 1
        assert result["updated"] == "2026-04-11"

    def test_list_of_dicts(self):
        text = """version: 1
repos:
  - name: first
    tier: core
    depth: 100
    required: true
  - name: second
    tier: sdk
    depth: 50
    required: false
"""
        result = _stdlib_yaml_parse(text)
        assert result["version"] == 1
        assert len(result["repos"]) == 2
        assert result["repos"][0]["name"] == "first"
        assert result["repos"][0]["tier"] == "core"
        assert result["repos"][0]["depth"] == 100
        assert result["repos"][0]["required"] is True
        assert result["repos"][1]["name"] == "second"
        assert result["repos"][1]["required"] is False

    def test_comments_and_blank_lines_ignored(self):
        text = """# top-level comment
version: 1

# another comment
repos:
  # list comment
  - name: test
    tier: core
"""
        result = _stdlib_yaml_parse(text)
        assert result["version"] == 1
        assert len(result["repos"]) == 1
        assert result["repos"][0]["name"] == "test"

    def test_null_fork_parses_as_none(self):
        text = """repos:
  - name: test
    fork: null
"""
        result = _stdlib_yaml_parse(text)
        assert result["repos"][0]["fork"] is None


# ---------------------------------------------------------------------------
# _manifest_from_dict
# ---------------------------------------------------------------------------


class TestManifestFromDict:
    def _minimal_entry(self, **overrides):
        base = {
            "name": "go-zenon",
            "tier": "core",
            "path": "core/go-zenon",
            "upstream": "https://github.com/zenon-network/go-zenon",
            "fork": "https://github.com/ZenonOrg/go-zenon",
            "signature": "node",
            "depth": 100,
            "required": True,
            "description": "Zenon Go node implementation",
        }
        base.update(overrides)
        return base

    def test_minimal_manifest(self):
        data = {
            "version": 1,
            "updated": "2026-04-11",
            "repos": [self._minimal_entry()],
        }
        manifest = _manifest_from_dict(data)
        assert manifest.version == 1
        assert manifest.updated == "2026-04-11"
        assert len(manifest.repos) == 1
        entry = manifest.repos[0]
        assert entry.name == "go-zenon"
        assert entry.tier == "core"
        assert entry.required is True
        assert entry.depth == 100

    def test_null_fork_becomes_none(self):
        data = {"repos": [self._minimal_entry(fork=None)]}
        manifest = _manifest_from_dict(data)
        assert manifest.repos[0].fork is None

    def test_unknown_tier_warns_but_loads(self):
        data = {"repos": [self._minimal_entry(tier="experimental")]}
        manifest = _manifest_from_dict(data)
        assert manifest.repos[0].tier == "experimental"

    def test_missing_required_field_raises(self):
        bad = self._minimal_entry()
        del bad["upstream"]
        with pytest.raises(KeyError):
            _manifest_from_dict({"repos": [bad]})


# ---------------------------------------------------------------------------
# Manifest query helpers
# ---------------------------------------------------------------------------


def _make_manifest(*, entries: list[dict]) -> Manifest:
    return _manifest_from_dict({"version": 1, "updated": "2026-04-11", "repos": entries})


class TestManifestHelpers:
    def _e(self, name, tier="core", required=True, **kw):
        base = {
            "name": name,
            "tier": tier,
            "path": f"core/{name}",
            "upstream": f"https://example.com/{name}",
            "fork": None,
            "signature": "node",
            "depth": 50,
            "required": required,
            "description": f"{name} repo",
        }
        base.update(kw)
        return base

    def test_by_name_hit(self):
        m = _make_manifest(entries=[self._e("a"), self._e("b"), self._e("c")])
        assert m.by_name("b") is not None
        assert m.by_name("b").name == "b"

    def test_by_name_miss(self):
        m = _make_manifest(entries=[self._e("a")])
        assert m.by_name("nope") is None

    def test_by_tier(self):
        m = _make_manifest(
            entries=[
                self._e("a", tier="core"),
                self._e("b", tier="sdk"),
                self._e("c", tier="core"),
            ]
        )
        core = m.by_tier("core")
        assert len(core) == 2
        assert {e.name for e in core} == {"a", "c"}

    def test_required_filter(self):
        m = _make_manifest(
            entries=[
                self._e("a", required=True),
                self._e("b", required=False),
                self._e("c", required=True),
            ]
        )
        req = m.required()
        assert {e.name for e in req} == {"a", "c"}


# ---------------------------------------------------------------------------
# ManifestEntry
# ---------------------------------------------------------------------------


class TestManifestEntry:
    def _entry(self, fork="https://github.com/ZenonOrg/go-zenon"):
        return ManifestEntry(
            name="go-zenon",
            tier="core",
            path="core/go-zenon",
            upstream="https://github.com/zenon-network/go-zenon",
            fork=fork,
            signature="node",
            depth=100,
            required=True,
            description="Zenon node",
        )

    def test_clone_url_default_is_upstream(self):
        e = self._entry()
        assert e.clone_url() == "https://github.com/zenon-network/go-zenon"

    def test_clone_url_prefer_fork_when_available(self):
        e = self._entry()
        assert e.clone_url(prefer_fork=True) == "https://github.com/ZenonOrg/go-zenon"

    def test_clone_url_falls_back_to_upstream_when_no_fork(self):
        e = self._entry(fork=None)
        assert e.clone_url(prefer_fork=True) == "https://github.com/zenon-network/go-zenon"

    def test_resolve_target(self):
        e = self._entry()
        workspace = Path("/tmp/fakeroot")
        assert e.resolve_target(workspace) == Path("/tmp/fakeroot/core/go-zenon")


# ---------------------------------------------------------------------------
# check_status
# ---------------------------------------------------------------------------


class TestCheckStatus:
    def _entry(self, name="test"):
        return ManifestEntry(
            name=name,
            tier="core",
            path=f"core/{name}",
            upstream=f"https://example.com/{name}",
            fork=None,
            signature="node",
            depth=50,
            required=True,
            description="test",
        )

    def test_missing_target_returns_not_present(self, tmp_path):
        e = self._entry()
        status = check_status(e, tmp_path)
        assert status.present is False
        assert status.head_sha is None
        assert status.state == "missing"

    def test_target_without_git_returns_not_present(self, tmp_path):
        e = self._entry()
        target = tmp_path / "core" / "test"
        target.mkdir(parents=True)
        # No .git subdirectory
        status = check_status(e, tmp_path)
        assert status.present is False

    def test_target_with_git_returns_present(self, tmp_path):
        e = self._entry()
        target = tmp_path / "core" / "test"
        (target / ".git").mkdir(parents=True)
        with patch("core.workspace_manifest._git_command") as mock_git:
            mock_git.side_effect = ["abc123def456", "main"]
            status = check_status(e, tmp_path)
        assert status.present is True
        assert status.head_sha == "abc123def456"
        assert status.branch == "main"
        assert status.state == "cloned"


# ---------------------------------------------------------------------------
# clone_entry (dry-run path, never touches network)
# ---------------------------------------------------------------------------


class TestCloneEntryDryRun:
    def _entry(self):
        return ManifestEntry(
            name="test",
            tier="core",
            path="core/test",
            upstream="https://example.com/test",
            fork="https://fork.example.com/test",
            signature="node",
            depth=42,
            required=True,
            description="test",
        )

    def test_dry_run_returns_command(self, tmp_path):
        e = self._entry()
        ok, msg = clone_entry(e, tmp_path, dry_run=True)
        assert ok is True
        assert "git clone" in msg
        assert "--depth 42" in msg
        assert "https://example.com/test" in msg
        assert str(tmp_path / "core" / "test") in msg

    def test_dry_run_uses_fork_when_requested(self, tmp_path):
        e = self._entry()
        ok, msg = clone_entry(e, tmp_path, prefer_fork=True, dry_run=True)
        assert ok is True
        assert "https://fork.example.com/test" in msg

    def test_already_present_is_noop(self, tmp_path):
        e = self._entry()
        target = tmp_path / "core" / "test"
        (target / ".git").mkdir(parents=True)
        ok, msg = clone_entry(e, tmp_path, dry_run=False)
        assert ok is True
        assert "already present" in msg


# ---------------------------------------------------------------------------
# load() end-to-end
# ---------------------------------------------------------------------------


class TestLoad:
    def test_missing_file_returns_none(self, tmp_path):
        path = tmp_path / "nope.yaml"
        assert load(path) is None

    def test_loads_minimal_manifest(self, tmp_path):
        path = tmp_path / "manifest.yaml"
        path.write_text(
            """version: 1
updated: 2026-04-11
repos:
  - name: test-repo
    tier: core
    path: core/test-repo
    upstream: https://example.com/test-repo
    fork: null
    signature: node
    depth: 50
    required: true
    description: "test entry"
"""
        )
        manifest = load(path)
        assert manifest is not None
        assert manifest.version == 1
        assert len(manifest.repos) == 1
        assert manifest.repos[0].name == "test-repo"
        assert manifest.repos[0].required is True
        assert manifest.repos[0].fork is None

    def test_loads_the_canonical_ship_manifest(self):
        """Smoke test: the manifest shipped at data/workspace-manifest.yaml
        must load cleanly with at least a handful of known Zenon repos."""
        manifest = load()
        assert manifest is not None
        assert manifest.version >= 1
        # Every Nebula install should have at least the core Zenon repos
        # in the manifest — specifically go-zenon + developer-commons
        # which drive the most engines.
        names = {r.name for r in manifest.repos}
        assert "go-zenon" in names
        assert "developer-commons" in names
        # Required repos should include at least go-zenon
        required_names = {r.name for r in manifest.required()}
        assert "go-zenon" in required_names

    def test_every_manifest_entry_has_valid_tier(self):
        """Contract: every ship-manifest entry uses a known tier."""
        manifest = load()
        assert manifest is not None
        for entry in manifest.repos:
            assert entry.tier in KNOWN_TIERS, (
                f"manifest entry {entry.name} uses unknown tier {entry.tier!r}"
            )

    def test_every_manifest_entry_has_unique_name_and_path(self):
        """Contract: no two manifest entries collide on name or path."""
        manifest = load()
        assert manifest is not None
        names = [r.name for r in manifest.repos]
        paths = [r.path for r in manifest.repos]
        assert len(names) == len(set(names)), f"duplicate names: {names}"
        assert len(paths) == len(set(paths)), f"duplicate paths: {paths}"

    def test_every_manifest_entry_has_https_upstream(self):
        """Contract: clone URLs must be https, not git:// or ssh://."""
        manifest = load()
        assert manifest is not None
        for entry in manifest.repos:
            assert entry.upstream.startswith("https://"), (
                f"{entry.name}: upstream {entry.upstream!r} must use https://"
            )
            if entry.fork is not None:
                assert entry.fork.startswith("https://"), (
                    f"{entry.name}: fork {entry.fork!r} must use https://"
                )
