# SPDX-License-Identifier: MIT
"""Tests for reputation-decay integration into mission_alignment.

Task #70 Phase 3 (closes #70). Pins the contract:
- No peer_id → legacy behavior exactly (overall score unchanged,
  multiplier reported as 1.0).
- Unknown peer → multiplier 1.0 (first-contact not penalized).
- Fresh peer → multiplier 1.0 (overall unchanged).
- Decayed peer → overall multiplied by the decay factor (score
  shrinks for inactive peers).
- Trust DB error → multiplier defaults to 1.0 (no poisoning).
- Return shape includes both ``overall`` and
  ``peer_reputation_multiplier`` keys.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import trust
from core.mission import mission_alignment
from core.persistence.schema import ensure_schema


@pytest.fixture
def fresh_trust_db(tmp_path):
    """Fresh DB with schema applied for peer_activity queries."""
    db = tmp_path / "engine.db"
    ensure_schema(str(db))
    return str(db)


class TestBackwardsCompatibility:
    def test_no_peer_id_preserves_legacy_contract(self):
        """Calling without peer_id must yield the same overall as
        before Phase 3. Multiplier key reports 1.0."""
        result = mission_alignment(
            domain="intelligence",
            evidence_text="upstream repo scanner found new commits in go-zenon",
            explicit_pillars=("trustlessness",),
        )
        assert "overall" in result
        assert "peer_reputation_multiplier" in result
        assert result["peer_reputation_multiplier"] == 1.0
        assert 0.0 <= result["overall"] <= 1.0

    def test_unknown_peer_yields_multiplier_1(self, fresh_trust_db):
        """Unknown peer: first-contact is not penalized. The
        DEFAULT_TRUST cap elsewhere handles sandbagging."""
        result = mission_alignment(
            domain="security",
            evidence_text="vuln scanner flagged CVE-2024-X",
            peer_id="never-seen",
            db_path=fresh_trust_db,
        )
        assert result["peer_reputation_multiplier"] == 1.0


class TestDecayAppliedToOverall:
    def test_fresh_peer_multiplier_is_one(self, fresh_trust_db):
        trust.record_peer_activity("alice", db_path=fresh_trust_db)
        result = mission_alignment(
            domain="security",
            evidence_text="vuln scanner found something",
            peer_id="alice",
            db_path=fresh_trust_db,
        )
        # Fresh activity → multiplier 1.0 (small floating point slack)
        assert result["peer_reputation_multiplier"] == pytest.approx(1.0, abs=0.01)

    def test_decayed_peer_shrinks_overall(self, fresh_trust_db, monkeypatch):
        """Patch compute_peer_reputation_multiplier to return 0.5 so
        we can assert the math independently of wall-clock elapsed
        time (avoids test flakiness from a slow CI runner)."""
        import core.mission.definition as defn_mod

        trust.record_peer_activity("bob", db_path=fresh_trust_db)

        # First: get the raw overall without decay.
        baseline = mission_alignment(
            domain="security",
            evidence_text="same finding text here",
        )
        raw_overall = baseline["overall"]

        # Now: import the decay function's name used INSIDE
        # mission_alignment and replace it.
        def fake_multiplier(*_args, **_kwargs):
            return 0.5

        monkeypatch.setattr(
            "core.trust.compute_peer_reputation_multiplier",
            fake_multiplier,
        )

        result = mission_alignment(
            domain="security",
            evidence_text="same finding text here",
            peer_id="bob",
            db_path=fresh_trust_db,
        )
        # overall must be roughly raw_overall * 0.5
        assert result["peer_reputation_multiplier"] == 0.5
        assert result["overall"] == pytest.approx(raw_overall * 0.5, abs=0.001)
        # Individual pillar scores are NOT decayed — decay applies
        # to the aggregate only. Reasoning: a decayed peer's ZNN
        # observation is still a ZNN observation; what decays is how
        # much we let that peer's findings drive prioritization.
        for pillar_key in ("trustlessness", "sovereignty"):
            if pillar_key in baseline:
                assert result[pillar_key] == baseline[pillar_key]


class TestErrorIsolation:
    def test_trust_layer_exception_defaults_to_one(self, monkeypatch):
        """If the trust lookup raises (DB locked, schema drift, etc.)
        the multiplier falls back to 1.0 — mission_alignment must
        never propagate a trust-layer crash to its callers."""

        def _raiser(*_a, **_k):
            raise RuntimeError("simulated trust crash")

        monkeypatch.setattr(
            "core.trust.compute_peer_reputation_multiplier",
            _raiser,
        )
        result = mission_alignment(
            domain="intelligence",
            evidence_text="anything",
            peer_id="alice",
        )
        assert result["peer_reputation_multiplier"] == 1.0
        # overall is the legacy raw_overall (multiplier=1.0 is no-op).
        assert 0.0 <= result["overall"] <= 1.0


class TestReturnShape:
    def test_contains_every_pillar_plus_overall_plus_multiplier(self):
        from core.mission import PILLARS

        result = mission_alignment(
            domain="intelligence",
            evidence_text="x",
        )
        for pillar in PILLARS:
            assert pillar.key in result
        assert "overall" in result
        assert "peer_reputation_multiplier" in result
