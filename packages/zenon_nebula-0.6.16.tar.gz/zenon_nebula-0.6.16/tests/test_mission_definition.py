# SPDX-License-Identifier: MIT
"""Tests for core/mission/definition.py (v0.6.10, task #96).

Pins the 6-pillar contract, weight normalization, and alignment
scoring mechanics. When a future release changes the pillar count
or weights, these tests fail and force an explicit ADR update.
"""

from __future__ import annotations

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.mission.definition import (
    PILLARS,
    MissionPillar,
    mission_alignment,
    pillar_by_key,
)

# ---------------------------------------------------------------------------
# Pillar contract
# ---------------------------------------------------------------------------


class TestPillarContract:
    """The 5 pre-existing pillars + the v0.6.10 innovation pillar."""

    def test_pillar_count_is_six(self):
        assert len(PILLARS) == 6

    def test_weights_sum_to_one(self):
        total = sum(p.weight for p in PILLARS)
        assert abs(total - 1.0) < 1e-9

    def test_all_weights_positive_and_bounded(self):
        for pillar in PILLARS:
            assert 0.0 < pillar.weight <= 0.5, (
                f"{pillar.key}: weight {pillar.weight} outside reasonable range"
            )

    def test_all_keys_unique(self):
        keys = [p.key for p in PILLARS]
        assert len(keys) == len(set(keys)), f"duplicate pillar keys: {keys}"

    def test_all_keys_snake_case(self):
        for pillar in PILLARS:
            assert pillar.key.replace("_", "").isalnum(), f"{pillar.key} is not snake_case ASCII"

    def test_technical_excellence_is_heaviest(self):
        """technical_excellence must remain the highest-weighted pillar.

        Rationale: shipping code beats every other lever. If this ever
        changes, update the ADR before the test.
        """
        weights = {p.key: p.weight for p in PILLARS}
        heaviest = max(weights, key=weights.get)
        assert heaviest == "technical_excellence"


class TestResearchEdgePillar:
    """The v0.6.10 addition specifically."""

    def test_research_edge_exists(self):
        pillar = pillar_by_key("research_edge")
        assert pillar is not None

    def test_research_edge_has_cross_chain_keywords(self):
        pillar = pillar_by_key("research_edge")
        assert pillar is not None
        keywords = set(pillar.signal_keywords)
        # Minimum expected cross-chain vocabulary
        assert {"innovation", "novel", "cross-chain"}.issubset(keywords)

    def test_research_edge_routes_to_cross_chain_domains(self):
        pillar = pillar_by_key("research_edge")
        assert pillar is not None
        expected = {"investigation", "interoperability", "intelligence"}
        actual = set(pillar.relevant_domains)
        assert expected.issubset(actual)

    def test_research_edge_is_frozen_dataclass(self):
        pillar = pillar_by_key("research_edge")
        assert pillar is not None
        assert isinstance(pillar, MissionPillar)


# ---------------------------------------------------------------------------
# Alignment scoring
# ---------------------------------------------------------------------------


class TestMissionAlignment:
    def test_scores_contain_all_pillars_plus_overall(self):
        scores = mission_alignment(domain="security", evidence_text="")
        for pillar in PILLARS:
            assert pillar.key in scores
        assert "overall" in scores

    def test_domain_match_boosts_score(self):
        # An investigation-domain finding should score higher on
        # research_edge than a community-domain finding.
        invest = mission_alignment(
            domain="investigation",
            evidence_text="explored a novel cross-chain pattern",
        )
        community = mission_alignment(
            domain="community",
            evidence_text="explored a novel cross-chain pattern",
        )
        assert invest["research_edge"] > community["research_edge"]

    def test_keyword_match_boosts_score(self):
        with_kw = mission_alignment(
            domain="investigation",
            evidence_text="novel breakthrough pioneering innovation",
        )
        without_kw = mission_alignment(
            domain="investigation",
            evidence_text="just a routine commit",
        )
        assert with_kw["research_edge"] > without_kw["research_edge"]

    def test_explicit_pillar_boosts_score(self):
        baseline = mission_alignment(domain="community", evidence_text="")
        tagged = mission_alignment(
            domain="community",
            evidence_text="",
            explicit_pillars=["research_edge"],
        )
        assert tagged["research_edge"] > baseline["research_edge"]

    def test_overall_is_weighted_average(self):
        scores = mission_alignment(
            domain="security",
            evidence_text="vuln exploit severity cvss",
        )
        # security_hardening should dominate in this case
        assert scores["security_hardening"] > scores["research_edge"]
        # Overall must not exceed 1.0
        assert 0.0 <= scores["overall"] <= 1.0

    def test_empty_input_gives_nonnegative_scores(self):
        scores = mission_alignment(domain="", evidence_text="")
        for pillar in PILLARS:
            assert scores[pillar.key] >= 0.0
        assert scores["overall"] >= 0.0


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


class TestPillarByKey:
    def test_known_key(self):
        assert pillar_by_key("technical_excellence") is not None
        assert pillar_by_key("research_edge") is not None

    def test_unknown_key(self):
        assert pillar_by_key("nonexistent") is None
        assert pillar_by_key("") is None
