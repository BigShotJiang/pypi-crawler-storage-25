# SPDX-License-Identifier: MIT
"""Tests for core/extensions/discovery.py — task #61 Phase G1 (2/3)."""

from __future__ import annotations

from pathlib import Path

import pytest

from core.domain_registry import DomainRegistry
from core.extensions.discovery import (
    discover_user_domains,
    resolve_user_domains_path,
)


class TestResolvePath:
    def test_default_path(self, monkeypatch):
        monkeypatch.delenv("NEBULA_USER_DOMAINS_PATH", raising=False)
        monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
        p = resolve_user_domains_path()
        assert p.name == "domains"
        assert p.parent.name == "nebula"

    def test_explicit_override(self, monkeypatch, tmp_path):
        monkeypatch.setenv("NEBULA_USER_DOMAINS_PATH", str(tmp_path / "custom"))
        assert resolve_user_domains_path() == tmp_path / "custom"

    def test_xdg_config(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NEBULA_USER_DOMAINS_PATH", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        assert resolve_user_domains_path() == tmp_path / "nebula" / "domains"


MINI_DOMAIN = """
from core.domain_registry import DomainPlugin, EngineDefinition

class TestDomain(DomainPlugin):
    def name(self): return "user_test_domain"
    def get_description(self): return "test"
    def get_priority(self): return 9
    def get_engines(self):
        return [EngineDefinition(name="user_test_engine", description="t", module_path="fake")]
    def decide_next_action(self, context):
        return {"action": "test", "engine": "user_test_engine", "priority": 9}
    def get_hypothesis_types(self): return []
    def get_aspiration_types(self): return []
    def get_collision_signals(self): return []
    def get_war_room_contributions(self): return []
    def get_self_improvement_metrics(self): return {}
    def get_db_schema_sql(self): return ""
"""


class TestDiscovery:
    def _fresh_registry(self):
        r = DomainRegistry.__new__(DomainRegistry)
        r._domains = {}
        return r

    def _setup_user_domain(self, tmp_path, name="user_test_domain"):
        domain_dir = tmp_path / name
        domain_dir.mkdir(parents=True)
        (domain_dir / "__init__.py").touch()
        (domain_dir / "domain.py").write_text(MINI_DOMAIN)
        return tmp_path

    def test_registers_valid_user_domain(self, tmp_path):
        root = self._setup_user_domain(tmp_path)
        registry = self._fresh_registry()
        result = discover_user_domains(registry, path=root)
        assert result["registered"] == 1
        assert result["failed"] == 0
        assert registry.get_domain("user_test_domain") is not None

    def test_missing_dir_is_noop(self, tmp_path):
        registry = self._fresh_registry()
        result = discover_user_domains(registry, path=tmp_path / "nonexistent")
        assert result["registered"] == 0
        assert "does not exist" in result["skipped"][0]

    def test_no_domain_py_is_skipped(self, tmp_path):
        (tmp_path / "empty_domain").mkdir()
        registry = self._fresh_registry()
        result = discover_user_domains(registry, path=tmp_path)
        assert result["registered"] == 0
        assert any("no domain.py" in s for s in result["skipped"])

    def test_duplicate_name_skipped_not_crash(self, tmp_path):
        root = self._setup_user_domain(tmp_path)
        registry = self._fresh_registry()
        # Register once via the discovery module.
        discover_user_domains(registry, path=root)
        # Second registration should skip (name already registered).
        result = discover_user_domains(registry, path=root)
        assert result["registered"] == 0
        assert any("already registered" in s for s in result["skipped"])

    def test_sys_path_cleaned_up_after_discovery(self, tmp_path):
        root = self._setup_user_domain(tmp_path)
        registry = self._fresh_registry()
        root_str = str(root)
        assert root_str not in __import__("sys").path
        discover_user_domains(registry, path=root)
        assert root_str not in __import__("sys").path

    def test_hidden_dirs_ignored(self, tmp_path):
        (tmp_path / ".hidden").mkdir()
        (tmp_path / ".hidden" / "domain.py").write_text(MINI_DOMAIN)
        (tmp_path / "_private").mkdir()
        (tmp_path / "_private" / "domain.py").write_text(MINI_DOMAIN)
        registry = self._fresh_registry()
        result = discover_user_domains(registry, path=tmp_path)
        assert result["registered"] == 0

    def test_bad_import_counted_as_failure(self, tmp_path):
        domain_dir = tmp_path / "broken"
        domain_dir.mkdir()
        (domain_dir / "__init__.py").touch()
        (domain_dir / "domain.py").write_text("raise RuntimeError('boom')")
        registry = self._fresh_registry()
        result = discover_user_domains(registry, path=tmp_path)
        assert result["failed"] == 1
        assert result["registered"] == 0
