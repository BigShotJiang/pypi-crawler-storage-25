# SPDX-License-Identifier: MIT
"""Tests for core.universal_http — task #67.

Each test pins one rail. If you add a new rail, add a test here; the
four-rail contract is the whole point of this module.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

import core.universal_http as uh


def _seed_allowlist(tmp_path: Path, hosts: list[str]) -> Path:
    """Write hosts to a tmp allowlist file and point uh at it."""
    allowlist_path = tmp_path / "allowed_api_hosts.txt"
    allowlist_path.write_text("\n".join(hosts) + "\n", encoding="utf-8")
    uh._cache = uh._AllowlistCache(path=allowlist_path)
    return allowlist_path


class TestSanitizeUrl:
    def test_strips_query_string(self):
        out = uh.sanitize_url("https://api.example.com/v1/data?api_key=secret&x=1")
        assert "api_key" not in out
        assert "secret" not in out
        assert out == "https://api.example.com/v1/data"

    def test_strips_userinfo(self):
        out = uh.sanitize_url("https://user:password@api.example.com/v1/data")
        assert "user" not in out
        assert "password" not in out

    def test_preserves_port(self):
        out = uh.sanitize_url("https://api.example.com:8443/v1/data?token=x")
        assert "api.example.com:8443" in out
        assert "token" not in out

    def test_strips_fragment(self):
        out = uh.sanitize_url("https://api.example.com/v1/data#section")
        assert "#" not in out
        assert "section" not in out

    def test_unparseable_url_returns_placeholder(self):
        # urlparse is extremely permissive; use a byte sequence that
        # actually raises ValueError on parse (urllib raises on
        # unescaped square brackets outside IPv6 contexts).
        with patch.object(uh, "urlparse", side_effect=ValueError("bad")):
            assert uh.sanitize_url("anything") == "<unparseable-url>"


class TestAllowlistParsing:
    def test_strips_comments_and_blank_lines(self):
        content = """
        # Top comment
        api.example.com

        # Another comment
        api.other.com  # inline comment
        """
        out = uh._parse_allowlist(content)
        assert out == frozenset({"api.example.com", "api.other.com"})

    def test_lowercases_hosts(self):
        out = uh._parse_allowlist("API.Example.COM\n")
        assert out == frozenset({"api.example.com"})


class TestAllowlistCache:
    def test_missing_file_returns_empty_set(self, tmp_path):
        uh._cache = uh._AllowlistCache(path=tmp_path / "nonexistent.txt")
        assert uh._cache.load() == frozenset()

    def test_reloads_on_mtime_change(self, tmp_path):
        path = _seed_allowlist(tmp_path, ["first.example.com"])
        assert "first.example.com" in uh._cache.load()
        # Rewrite with different hosts and bump mtime.
        import os
        import time

        time.sleep(0.01)
        path.write_text("second.example.com\n", encoding="utf-8")
        new_mtime = uh._cache.mtime + 10
        os.utime(path, (new_mtime, new_mtime))
        assert "second.example.com" in uh._cache.load()
        assert "first.example.com" not in uh._cache.load()


class TestIsAllowed:
    def test_true_for_allowed_https_host(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        assert uh.is_allowed("https://api.example.com/v1/data")

    def test_false_for_http_scheme(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        assert not uh.is_allowed("http://api.example.com/v1/data")

    def test_false_for_unlisted_host(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        assert not uh.is_allowed("https://evil.example.com/v1/data")

    def test_false_for_malformed_url(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        assert not uh.is_allowed("not a url")


class TestCheckRails:
    def test_rejects_non_https_scheme(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        import pytest

        with pytest.raises(uh.SchemeNotAllowedError):
            uh._check_rails("http://api.example.com/v1/data")

    def test_rejects_file_scheme(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        import pytest

        with pytest.raises(uh.SchemeNotAllowedError):
            uh._check_rails("file:///etc/passwd")

    def test_rejects_unlisted_host(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        import pytest

        with pytest.raises(uh.HostNotAllowedError):
            uh._check_rails("https://evil.example.com/data")

    def test_rejects_missing_host(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        import pytest

        with pytest.raises(uh.MalformedURLError):
            uh._check_rails("https:///no-host")

    def test_host_comparison_case_insensitive(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        # Should accept API.EXAMPLE.COM
        _, host = uh._check_rails("https://API.EXAMPLE.COM/v1/data")
        assert host == "api.example.com"


class TestUniversalFetch:
    def test_size_cap_enforced(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        oversized_body = b"x" * 101
        mock_resp = MagicMock()
        mock_resp.read.return_value = oversized_body
        mock_resp.__enter__ = lambda self: self
        mock_resp.__exit__ = lambda *a: False
        import pytest

        with (
            patch.object(uh, "opsec_urlopen", return_value=mock_resp),
            pytest.raises(uh.ResponseTooLargeError),
        ):
            uh.universal_fetch("https://api.example.com/big", max_bytes=100)

    def test_size_cap_allows_exact_boundary(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        body = b"x" * 100
        mock_resp = MagicMock()
        mock_resp.read.return_value = body
        mock_resp.__enter__ = lambda self: self
        mock_resp.__exit__ = lambda *a: False
        with patch.object(uh, "opsec_urlopen", return_value=mock_resp):
            result = uh.universal_fetch("https://api.example.com/ok", max_bytes=100)
        assert result == body

    def test_rails_checked_before_network(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        import pytest

        with patch.object(uh, "opsec_urlopen") as urlopen, pytest.raises(uh.HostNotAllowedError):
            uh.universal_fetch("https://evil.example.com/anything")
        # Critical: network was never touched.
        urlopen.assert_not_called()

    def test_scheme_rejected_before_network(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        import pytest

        with patch.object(uh, "opsec_urlopen") as urlopen, pytest.raises(uh.SchemeNotAllowedError):
            uh.universal_fetch("http://api.example.com/plain")
        urlopen.assert_not_called()

    def test_happy_path_returns_body(self, tmp_path):
        _seed_allowlist(tmp_path, ["api.example.com"])
        body = b'{"ok": true}'
        mock_resp = MagicMock()
        mock_resp.read.return_value = body
        mock_resp.__enter__ = lambda self: self
        mock_resp.__exit__ = lambda *a: False
        with patch.object(uh, "opsec_urlopen", return_value=mock_resp) as urlopen:
            result = uh.universal_fetch("https://api.example.com/v1/data")
        assert result == body
        urlopen.assert_called_once()


class TestEnvOverride:
    def test_nebula_allowed_hosts_file_honored(self, tmp_path, monkeypatch):
        custom = tmp_path / "custom_allowlist.txt"
        custom.write_text("custom.example.com\n", encoding="utf-8")
        monkeypatch.setenv("NEBULA_ALLOWED_HOSTS_FILE", str(custom))
        # Reload forces a re-resolution of the path from env.
        uh.reload_allowlist()
        assert "custom.example.com" in uh._cache.load()
        assert uh._cache.path == custom


def teardown_module():
    """Restore the canonical allowlist cache so downstream tests
    don't see whatever the last test left behind."""
    importlib.reload(uh)
