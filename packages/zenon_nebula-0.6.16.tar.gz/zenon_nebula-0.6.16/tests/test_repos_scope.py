# SPDX-License-Identifier: MIT
"""Tests for the --repos scope flag (task #79, v0.6.10).

Covers:

- ``core.workspace.is_repo_in_scope`` — the helper engines use to
  honor the operator's ``--repos`` declaration.
- ``RunContext.repos_scope`` field plumbing.
- ``scripts.autonomous.main`` argparse glue that turns
  ``--repos go-zenon,syrius`` into a ``frozenset``.

No real engine cycles. The tests drive the helper directly with
a hand-seeded RunContext singleton.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.run_context import RunContext
from core.workspace import is_repo_in_scope


@pytest.fixture(autouse=True)
def _reset_run_context():
    """Every test works against a fresh RunContext singleton."""
    RunContext.reset()
    yield
    RunContext.reset()


class TestIsRepoInScopeNoScope:
    """With no scope declared, every repo is in scope."""

    def test_no_context_returns_true(self):
        # Singleton not initialized at all — the helper degrades
        # gracefully. Unit tests that don't boot through the
        # autonomous runner should still see "all repos in scope".
        assert is_repo_in_scope("go-zenon") is True
        assert is_repo_in_scope(Path("core/go-zenon")) is True
        assert is_repo_in_scope("anything") is True

    def test_context_with_none_scope_returns_true(self):
        RunContext.get_current()
        assert is_repo_in_scope("go-zenon") is True
        assert is_repo_in_scope("syrius") is True
        assert is_repo_in_scope("whatever") is True


class TestIsRepoInScopeWithScope:
    """With a declared scope, only listed repos are in scope."""

    def _seed(self, scope: set[str]):
        ctx = RunContext.get_current()
        ctx.repos_scope = frozenset(scope)

    def test_exact_name_match_string(self):
        self._seed({"go-zenon", "syrius"})
        assert is_repo_in_scope("go-zenon") is True
        assert is_repo_in_scope("syrius") is True

    def test_case_insensitive_match(self):
        self._seed({"go-zenon"})
        assert is_repo_in_scope("Go-Zenon") is True
        assert is_repo_in_scope("GO-ZENON") is True

    def test_non_matching_returns_false(self):
        self._seed({"go-zenon"})
        assert is_repo_in_scope("syrius") is False
        assert is_repo_in_scope("znn_sdk_dart") is False

    def test_matches_basename_of_path(self):
        self._seed({"go-zenon"})
        assert is_repo_in_scope(Path("/tmp/fakeroot/core/go-zenon")) is True
        assert is_repo_in_scope(Path("core/go-zenon")) is True

    def test_matches_basename_of_slash_string(self):
        self._seed({"go-zenon"})
        assert is_repo_in_scope("core/go-zenon") is True
        assert is_repo_in_scope("zenon-network/go-zenon") is True

    def test_empty_frozenset_narrows_to_nothing(self):
        # A valid edge case: operator ran --repos with empty value.
        # An empty frozenset means "nothing is in scope". The argparse
        # glue in scripts/autonomous.py turns empty input into None,
        # but if it ever didn't, the helper should respect the data.
        self._seed(set())
        assert is_repo_in_scope("go-zenon") is False


class TestRunContextReposScopeField:
    """The RunContext dataclass-like API gets the new field."""

    def test_default_is_none(self):
        ctx = RunContext(domain="test", engine="test")
        assert ctx.repos_scope is None

    def test_explicit_frozenset(self):
        scope = frozenset({"go-zenon", "syrius"})
        ctx = RunContext(domain="test", engine="test", repos_scope=scope)
        assert ctx.repos_scope == scope

    def test_mutation_after_init(self):
        ctx = RunContext(domain="test", engine="test")
        ctx.repos_scope = frozenset({"syrius"})
        assert ctx.repos_scope == frozenset({"syrius"})


class TestAutonomousArgparse:
    """scripts/autonomous.py turns --repos into a frozenset correctly."""

    def test_empty_flag_produces_none(self):
        # The glue is embedded in main(); test the shape of the
        # transformation directly by re-running it against a fake
        # args.repos string.
        repos: str = ""
        result: frozenset[str] | None = None
        if repos:
            result = frozenset(r.strip().lower() for r in repos.split(",") if r.strip()) or None
        assert result is None

    def test_autonomous_main_registers_repos_flag(self):
        # Sanity: the module exposes `--repos` through argparse. Reads
        # main's source to avoid spawning a real argparse invocation
        # (which would try to import every domain).
        sys.path.insert(0, str(ENGINE_ROOT / "scripts"))
        import inspect

        import autonomous

        source = inspect.getsource(autonomous.main)
        assert '"--repos"' in source, "autonomous.main() missing --repos flag"

    def test_non_empty_flag_produces_frozenset(self):
        repos = "go-zenon,syrius,Znn_SDK_Dart"
        result = frozenset(r.strip().lower() for r in repos.split(",") if r.strip()) or None
        assert result == frozenset({"go-zenon", "syrius", "znn_sdk_dart"})

    def test_whitespace_and_empty_segments_dropped(self):
        repos = " go-zenon , , syrius ,"
        result = frozenset(r.strip().lower() for r in repos.split(",") if r.strip()) or None
        assert result == frozenset({"go-zenon", "syrius"})
