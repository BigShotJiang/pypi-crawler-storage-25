# SPDX-License-Identifier: MIT
"""Tests for domains/self_maintenance/engines/todo_budget_monitor.py (task #86)."""

from __future__ import annotations

import inspect
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence import connect
from domains.self_maintenance.engines import todo_budget_monitor as tbm

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ts(seconds_ago: int) -> str:
    t = datetime.now(timezone.utc) - timedelta(seconds=seconds_ago)
    return t.strftime("%Y-%m-%d %H:%M:%S")


def _fake_repo(root: Path) -> Path:
    """Build a minimal fake repo for scanning."""
    for d in tbm._TODO_SCOPE_DIRS:
        (root / d).mkdir(parents=True, exist_ok=True)
    (root / "tests").mkdir(parents=True, exist_ok=True)
    return root


# ---------------------------------------------------------------------------
# Import smoke
# ---------------------------------------------------------------------------


class TestImportSmoke:
    def test_module_imports(self):
        assert hasattr(tbm, "run_todo_budget_monitor")

    def test_schema_sql_present(self):
        assert "CREATE TABLE IF NOT EXISTS todo_budget" in tbm.SCHEMA_SQL

    def test_entry_point_zero_required_arg(self):
        sig = inspect.signature(tbm.run_todo_budget_monitor)
        required = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.name not in ("self", "db_path")
            and p.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.POSITIONAL_ONLY,
            )
        ]
        assert required == []


# ---------------------------------------------------------------------------
# TODO scanning
# ---------------------------------------------------------------------------


class TestCountTodos:
    def test_counts_todo_fixme_xxx(self, tmp_path):
        root = _fake_repo(tmp_path)
        (root / "core" / "x.py").write_text(
            "# TODO: fix this\n# FIXME: also this\n# XXX: and this\n# just a comment\n"
        )
        counts = tbm._count_todos(repo_root=root)
        assert counts["todo:core"] == 3

    def test_skips_tests_dir(self, tmp_path):
        root = _fake_repo(tmp_path)
        (root / "tests" / "foo.py").write_text("# TODO: intentional test hole\n")
        counts = tbm._count_todos(repo_root=root)
        assert "todo:tests" not in counts

    def test_empty_dirs_return_zero(self, tmp_path):
        root = _fake_repo(tmp_path)
        counts = tbm._count_todos(repo_root=root)
        for scope in tbm._TODO_SCOPE_DIRS:
            assert counts[f"todo:{scope}"] == 0

    def test_doesnt_match_in_strings(self, tmp_path):
        root = _fake_repo(tmp_path)
        # The word TODO inside a regular string (not followed by : ( or space)
        # shouldn't match. Our regex requires `(` or `:` or whitespace after.
        (root / "core" / "x.py").write_text('MSG = "TODOabc"\n')
        counts = tbm._count_todos(repo_root=root)
        assert counts["todo:core"] == 0

    def test_counts_across_multiple_files(self, tmp_path):
        root = _fake_repo(tmp_path)
        (root / "core" / "a.py").write_text("# TODO: a\n")
        (root / "core" / "b.py").write_text("# TODO: b\n# TODO: c\n")
        (root / "domains" / "d.py").write_text("# FIXME: d\n")
        counts = tbm._count_todos(repo_root=root)
        assert counts["todo:core"] == 3
        assert counts["todo:domains"] == 1


# ---------------------------------------------------------------------------
# Allowlist AST counting
# ---------------------------------------------------------------------------


class TestCountAllowlistMembers:
    def test_set_literal(self, tmp_path):
        f = tmp_path / "foo.py"
        f.write_text('FOO: set[str] = {"a", "b", "c"}\n')
        assert tbm._count_allowlist_members(f, "FOO") == 3

    def test_empty_set_call(self, tmp_path):
        f = tmp_path / "foo.py"
        f.write_text("FOO: set[str] = set()\n")
        assert tbm._count_allowlist_members(f, "FOO") == 0

    def test_list_literal(self, tmp_path):
        f = tmp_path / "foo.py"
        f.write_text('FOO = ["a", "b"]\n')
        assert tbm._count_allowlist_members(f, "FOO") == 2

    def test_frozenset_call(self, tmp_path):
        f = tmp_path / "foo.py"
        f.write_text('FOO = frozenset({"a", "b"})\n')
        assert tbm._count_allowlist_members(f, "FOO") == 2

    def test_missing_variable_returns_none(self, tmp_path):
        f = tmp_path / "foo.py"
        f.write_text('OTHER = {"a"}\n')
        assert tbm._count_allowlist_members(f, "MISSING") is None

    def test_missing_file_returns_none(self, tmp_path):
        assert tbm._count_allowlist_members(tmp_path / "nope.py", "X") is None

    def test_syntax_error_returns_none(self, tmp_path):
        f = tmp_path / "foo.py"
        f.write_text("def broken(:\n")
        assert tbm._count_allowlist_members(f, "FOO") is None

    def test_real_nebula_allowlist_has_members(self):
        """The UNREACHABLE_ENGINES_ALLOWLIST in the real test file is
        readable — the literal is `set()` (empty after task #84)."""
        from domains.self_maintenance.engines.todo_budget_monitor import (
            REPO_ROOT,
            _count_allowlist_members,
        )

        count = _count_allowlist_members(
            REPO_ROOT / "tests" / "test_autonomous_cycle_smoke.py",
            "UNREACHABLE_ENGINES_ALLOWLIST",
        )
        # Could be 0 (empty set after task #84) or non-None; just not None.
        assert count is not None


# ---------------------------------------------------------------------------
# Signal detection
# ---------------------------------------------------------------------------


class TestDetectSignals:
    def test_grew_flagged(self):
        current = {"todo:core": 10}
        history = {"todo:core": [8]}  # second-most-recent was 8
        signals = tbm._detect_signals(current, history)
        assert len(signals) == 1
        assert signals[0].signal_class == "grew"
        assert signals[0].detail["delta"] == 2

    def test_shrank_no_signal(self):
        current = {"todo:core": 5}
        history = {"todo:core": [10]}
        signals = tbm._detect_signals(current, history)
        # Shrinkage is a win — no finding needed
        assert signals == []

    def test_no_history_no_signal(self):
        current = {"todo:core": 10}
        signals = tbm._detect_signals(current, {})
        assert signals == []

    def test_stagnant_flagged_after_threshold(self):
        # Need STAGNATION_THRESHOLD_SNAPSHOTS - 1 history points that
        # all show count >= current (no shrinkage ever)
        thresh = tbm.STAGNATION_THRESHOLD_SNAPSHOTS
        current = {"x": 10}
        history = {"x": [10] * (thresh - 1)}
        signals = tbm._detect_signals(current, history)
        assert any(s.signal_class == "stagnant" for s in signals)

    def test_stagnant_not_flagged_below_threshold(self):
        current = {"x": 10}
        history = {"x": [10]}  # only 1 historical point
        signals = tbm._detect_signals(current, history)
        assert all(s.signal_class != "stagnant" for s in signals)


# ---------------------------------------------------------------------------
# Format helper
# ---------------------------------------------------------------------------


class TestFormatSignal:
    def test_grew_shape(self):
        s = tbm.BudgetSignal(
            signal_class="grew",
            source="todo:core",
            detail={"previous": 10, "current": 12, "delta": 2, "history": [10]},
        )
        what, so_what, now_what = tbm._format_signal(s)
        assert "todo:core" in what
        assert "10" in what and "12" in what
        assert len(so_what) > 20
        assert "task" in now_what.lower() or "iou" in now_what.lower()

    def test_stagnant_shape(self):
        s = tbm.BudgetSignal(
            signal_class="stagnant",
            source="allowlist:UNREACHABLE_ENGINES_ALLOWLIST",
            detail={"current": 47, "history": [47, 47, 47, 47], "snapshots_without_shrink": 5},
        )
        what, so_what, _now_what = tbm._format_signal(s)
        assert "UNREACHABLE_ENGINES_ALLOWLIST" in what
        assert "47" in what
        assert "trend" in so_what.lower() or "shrink" in so_what.lower()

    def test_unknown_class_fallback(self):
        s = tbm.BudgetSignal(signal_class="weird", source="x", detail={})
        what, so_what, now_what = tbm._format_signal(s)
        assert all((what, so_what, now_what))


# ---------------------------------------------------------------------------
# Cooldown
# ---------------------------------------------------------------------------


class TestCooldown:
    def test_cooldown_skips_recently_emitted(self, db_path):
        conn = connect(db_path)
        conn.execute(
            """
            INSERT INTO evidence
                (timestamp, domain, engine, evidence_type, finding,
                 confidence, raw_data)
            VALUES (?, 'self_maintenance', 'todo_budget_monitor',
                    'todo_budget_signal', 'WHAT...', 0.70, ?)
            """,
            (
                _ts(3600),
                '{"data": {"source": "todo:core", "signal_class": "grew"}, "provenance": "system"}',
            ),
        )
        conn.commit()
        assert tbm._was_recently_emitted(conn, "todo:core", "grew") is True
        assert tbm._was_recently_emitted(conn, "todo:core", "stagnant") is False
        assert tbm._was_recently_emitted(conn, "other", "grew") is False
        conn.close()


# ---------------------------------------------------------------------------
# Dataclass
# ---------------------------------------------------------------------------


class TestBudgetSignal:
    def test_is_frozen(self):
        s = tbm.BudgetSignal(signal_class="grew", source="x", detail={})
        from dataclasses import FrozenInstanceError

        with pytest.raises(FrozenInstanceError):
            s.source = "y"


# ---------------------------------------------------------------------------
# End-to-end
# ---------------------------------------------------------------------------


class TestEndToEnd:
    def test_first_run_persists_snapshot_no_findings(self, db_path, tmp_path):
        root = _fake_repo(tmp_path)
        (root / "core" / "x.py").write_text("# TODO: one\n")
        result = tbm.run_todo_budget_monitor(db_path=db_path, repo_root=root)
        assert result["sources_tracked"] >= 1
        # No history on first run → no findings
        assert result["findings_persisted"] == 0

        # But the snapshot was written
        conn = connect(db_path)
        try:
            rows = conn.execute("SELECT source, count FROM todo_budget").fetchall()
            by_source = dict(rows)
            assert by_source.get("todo:core") == 1
        finally:
            conn.close()

    def test_growth_triggers_finding(self, db_path, tmp_path):
        root = _fake_repo(tmp_path)
        (root / "core" / "x.py").write_text("# TODO: one\n")
        # First run records baseline = 1
        tbm.run_todo_budget_monitor(db_path=db_path, repo_root=root)
        # Add a TODO, run again
        (root / "core" / "x.py").write_text("# TODO: one\n# TODO: two\n")
        result = tbm.run_todo_budget_monitor(db_path=db_path, repo_root=root)
        assert result["by_class"]["grew"] >= 1
        assert result["findings_persisted"] >= 1

    def test_no_repo_root_degrades_gracefully(self, db_path, tmp_path):
        # Pass a nonexistent repo — every scope is missing
        result = tbm.run_todo_budget_monitor(db_path=db_path, repo_root=tmp_path / "nope")
        assert result["engine"] == "todo_budget_monitor"
        # All TODO counts are 0 for missing dirs
        assert isinstance(result["sources_tracked"], int)

    def test_cooldown_prevents_duplicate(self, db_path, tmp_path):
        root = _fake_repo(tmp_path)
        (root / "core" / "x.py").write_text("# TODO: a\n")
        tbm.run_todo_budget_monitor(db_path=db_path, repo_root=root)  # baseline
        (root / "core" / "x.py").write_text("# TODO: a\n# TODO: b\n")
        first = tbm.run_todo_budget_monitor(db_path=db_path, repo_root=root)
        # Second run from same growth state — should be blocked by cooldown
        (root / "core" / "x.py").write_text("# TODO: a\n# TODO: b\n# TODO: c\n")
        second = tbm.run_todo_budget_monitor(db_path=db_path, repo_root=root)
        assert first["findings_persisted"] >= 1
        # Second run grows MORE — but the cooldown on (todo:core, grew) blocks
        assert second["findings_persisted"] == 0
