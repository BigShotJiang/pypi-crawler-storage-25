# SPDX-License-Identifier: MIT
"""Tests for peer reputation decay — task #70 Phase 1.

Pins the decay contract:
- fresh peer with recorded activity → multiplier 1.0
- unknown peer → multiplier 1.0 (first-contact not penalized)
- 1 month inactive → 0.95 (5% per month)
- 6 months inactive → 0.70
- >=16 months inactive → 0.20 (floor, never below)
- edge cases: empty id, None, whitespace, future timestamp
- record_peer_activity upserts correctly + increments count
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

import sqlite3

from core import trust
from core.persistence import connect


def _with_row_factory(conn: sqlite3.Connection) -> sqlite3.Connection:
    conn.row_factory = sqlite3.Row
    return conn


from core.persistence.schema import ensure_schema


@pytest.fixture
def fresh_db(tmp_path):
    """Return a path to a fresh DB with schema applied."""
    db = tmp_path / "engine.db"
    # ensure_schema runs the core SCHEMA_SQL plus all registered
    # module-level SCHEMA_SQL declarations (including trust.py's new
    # peer_activity table). If it doesn't, we'd see an error here.
    ensure_schema(str(db))
    return str(db)


class TestRecordPeerActivity:
    def test_inserts_new_row(self, fresh_db):
        trust.record_peer_activity("alice", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            row = conn.execute(
                "SELECT participant_id, activity_count FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()
        finally:
            conn.close()
        assert row is not None
        assert row["activity_count"] == 1

    def test_upserts_increments_count(self, fresh_db):
        trust.record_peer_activity("alice", db_path=fresh_db)
        trust.record_peer_activity("alice", db_path=fresh_db)
        trust.record_peer_activity("alice", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            count = conn.execute(
                "SELECT activity_count FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()["activity_count"]
        finally:
            conn.close()
        assert count == 3

    def test_empty_id_is_noop(self, fresh_db):
        trust.record_peer_activity("", db_path=fresh_db)
        trust.record_peer_activity("   ", db_path=fresh_db)
        trust.record_peer_activity(None, db_path=fresh_db)  # type: ignore[arg-type]
        conn = _with_row_factory(connect(fresh_db))
        try:
            count = conn.execute("SELECT COUNT(*) FROM peer_activity").fetchone()[0]
        finally:
            conn.close()
        assert count == 0

    def test_strips_whitespace(self, fresh_db):
        trust.record_peer_activity("  alice  ", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            row = conn.execute(
                "SELECT participant_id FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()
        finally:
            conn.close()
        assert row is not None


class TestComputePeerReputationMultiplier:
    def test_fresh_activity_returns_one(self, fresh_db):
        trust.record_peer_activity("alice", db_path=fresh_db)
        m = trust.compute_peer_reputation_multiplier("alice", db_path=fresh_db)
        assert m == pytest.approx(1.0, abs=0.01)

    def test_unknown_peer_returns_one(self, fresh_db):
        # Not penalized on first contact — DEFAULT_TRUST is the
        # load-bearing defense for newcomers, not this module.
        m = trust.compute_peer_reputation_multiplier("never-seen", db_path=fresh_db)
        assert m == 1.0

    def test_empty_id_returns_one(self, fresh_db):
        assert trust.compute_peer_reputation_multiplier("", db_path=fresh_db) == 1.0
        assert trust.compute_peer_reputation_multiplier("   ", db_path=fresh_db) == 1.0

    def test_one_month_inactive_gives_0_95(self, fresh_db):
        trust.record_peer_activity("alice", db_path=fresh_db)
        # Peek the recorded timestamp, then pretend "now" is 30 days
        # later — exercises the decay math with a real row.
        conn = _with_row_factory(connect(fresh_db))
        try:
            ts = conn.execute(
                "SELECT strftime('%s', last_activity_ts) FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()[0]
        finally:
            conn.close()
        later = float(ts) + 30 * 24 * 3600
        m = trust.compute_peer_reputation_multiplier("alice", now_ts=later, db_path=fresh_db)
        assert m == pytest.approx(0.95, abs=0.001)

    def test_six_months_inactive_gives_0_70(self, fresh_db):
        trust.record_peer_activity("alice", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            ts = conn.execute(
                "SELECT strftime('%s', last_activity_ts) FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()[0]
        finally:
            conn.close()
        later = float(ts) + 6 * 30 * 24 * 3600
        m = trust.compute_peer_reputation_multiplier("alice", now_ts=later, db_path=fresh_db)
        assert m == pytest.approx(0.70, abs=0.001)

    def test_floor_prevents_below_0_20(self, fresh_db):
        """A peer inactive for 5 years should clamp to the floor, not
        drop to zero — rehabilitation must remain possible."""
        trust.record_peer_activity("alice", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            ts = conn.execute(
                "SELECT strftime('%s', last_activity_ts) FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()[0]
        finally:
            conn.close()
        five_years = float(ts) + 5 * 365 * 24 * 3600
        m = trust.compute_peer_reputation_multiplier("alice", now_ts=five_years, db_path=fresh_db)
        assert m == trust.PEER_DECAY_FLOOR

    def test_future_timestamp_does_not_exceed_one(self, fresh_db):
        """Clock skew: recorded ts in the future → clamp to 1.0, not
        some silly value above 1.0 that would inflate reputation."""
        trust.record_peer_activity("alice", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            ts = conn.execute(
                "SELECT strftime('%s', last_activity_ts) FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()[0]
        finally:
            conn.close()
        past = float(ts) - 60  # "now" is 1 minute before the recorded ts
        m = trust.compute_peer_reputation_multiplier("alice", now_ts=past, db_path=fresh_db)
        assert m == 1.0

    def test_is_pure_no_side_effect(self, fresh_db):
        """Computing the multiplier must not mutate any row."""
        trust.record_peer_activity("alice", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            before = conn.execute(
                "SELECT activity_count, last_activity_ts FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()
        finally:
            conn.close()
        trust.compute_peer_reputation_multiplier("alice", db_path=fresh_db)
        trust.compute_peer_reputation_multiplier("alice", db_path=fresh_db)
        conn = _with_row_factory(connect(fresh_db))
        try:
            after = conn.execute(
                "SELECT activity_count, last_activity_ts FROM peer_activity WHERE participant_id = ?",
                ("alice",),
            ).fetchone()
        finally:
            conn.close()
        assert before["activity_count"] == after["activity_count"]
        assert before["last_activity_ts"] == after["last_activity_ts"]


class TestConstants:
    def test_decay_rate_matches_spec(self):
        assert trust.PEER_DECAY_PER_MONTH == 0.05

    def test_floor_leaves_room_for_rehabilitation(self):
        assert 0.0 < trust.PEER_DECAY_FLOOR < 1.0
