# SPDX-License-Identifier: MIT
"""Elder snapshot Phase 1 tests — task #73.

Pins the contract:
- export_snapshot stamps the producer's NEBULA_PARTICIPANT_ID as
  `elder_id` on the snapshot JSON.
- import_snapshot auto-derives peer_id from `elder_id` when the
  caller doesn't pass an explicit peer_id.
- Explicit peer_id wins over elder_id when both are present.
- Missing / empty / whitespace elder_id is a clean no-op.
"""

from __future__ import annotations

import gzip
import json
import sqlite3
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence.schema import ensure_schema
from core.sync import SNAPSHOT_VERSION, export_snapshot, import_snapshot


def _seed_db(tmp_path: Path) -> Path:
    """Fresh DB with one evidence row so export has content."""
    db = tmp_path / "engine.db"
    ensure_schema(str(db))
    conn = sqlite3.connect(str(db))
    try:
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, finding) VALUES (?, ?, ?, ?)",
            ("intelligence", "seed_engine", "observation", "seed finding"),
        )
        conn.commit()
    finally:
        conn.close()
    return db


def _peer_activity_count(db_path: Path, peer_id: str) -> int:
    """Return activity_count for a peer (0 if no row)."""
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute(
            "SELECT activity_count FROM peer_activity WHERE participant_id = ?",
            (peer_id,),
        ).fetchone()
    finally:
        conn.close()
    return row[0] if row else 0


class TestExportStampsElderId:
    def test_elder_id_written_from_env(self, tmp_path, monkeypatch):
        monkeypatch.setenv("NEBULA_PARTICIPANT_ID", "elder-alice")
        db = _seed_db(tmp_path)
        output = export_snapshot(str(db), str(tmp_path / "snap.json.gz"))

        with gzip.open(output, "rt") as f:
            snap = json.load(f)

        assert snap["elder_id"] == "elder-alice"
        assert snap["version"] == SNAPSHOT_VERSION

    def test_unset_env_writes_empty_string(self, tmp_path, monkeypatch):
        monkeypatch.delenv("NEBULA_PARTICIPANT_ID", raising=False)
        db = _seed_db(tmp_path)
        output = export_snapshot(str(db), str(tmp_path / "snap.json.gz"))

        with gzip.open(output, "rt") as f:
            snap = json.load(f)

        assert snap["elder_id"] == ""

    def test_whitespace_env_stripped(self, tmp_path, monkeypatch):
        monkeypatch.setenv("NEBULA_PARTICIPANT_ID", "  trimmed  ")
        db = _seed_db(tmp_path)
        output = export_snapshot(str(db), str(tmp_path / "snap.json.gz"))

        with gzip.open(output, "rt") as f:
            snap = json.load(f)

        assert snap["elder_id"] == "trimmed"


class TestImportUsesElderIdFallback:
    def _export_with_elder(self, tmp_path: Path, elder: str, monkeypatch) -> Path:
        monkeypatch.setenv("NEBULA_PARTICIPANT_ID", elder)
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        src_db = _seed_db(src_dir)
        return Path(export_snapshot(str(src_db), str(tmp_path / "elder.json.gz")))

    def test_elder_id_drives_peer_activity_when_caller_omits(self, tmp_path, monkeypatch):
        snap = self._export_with_elder(tmp_path, "elder-bob", monkeypatch)
        # Fresh target DB.
        dest_db = tmp_path / "dest.db"
        ensure_schema(str(dest_db))

        # Caller does NOT pass peer_id. Elder should take over.
        import_snapshot(str(dest_db), str(snap))

        assert _peer_activity_count(dest_db, "elder-bob") == 1

    def test_explicit_peer_id_overrides_elder(self, tmp_path, monkeypatch):
        snap = self._export_with_elder(tmp_path, "elder-bob", monkeypatch)
        dest_db = tmp_path / "dest.db"
        ensure_schema(str(dest_db))

        # Caller passes peer_id=override — overrides elder.
        import_snapshot(str(dest_db), str(snap), peer_id="override")

        assert _peer_activity_count(dest_db, "override") == 1
        assert _peer_activity_count(dest_db, "elder-bob") == 0

    def test_empty_elder_id_is_no_op(self, tmp_path, monkeypatch):
        snap = self._export_with_elder(tmp_path, "", monkeypatch)
        dest_db = tmp_path / "dest.db"
        ensure_schema(str(dest_db))

        import_snapshot(str(dest_db), str(snap))

        # No peer_activity rows at all.
        conn = sqlite3.connect(str(dest_db))
        try:
            count = conn.execute("SELECT COUNT(*) FROM peer_activity").fetchone()[0]
        finally:
            conn.close()
        assert count == 0

    def test_legacy_snapshot_without_elder_id_key(self, tmp_path):
        """Snapshots exported before Phase 1 have no elder_id field.
        Import must handle that as cleanly as an empty elder_id."""
        legacy = {
            "version": SNAPSHOT_VERSION,
            "evidence": [],
            "hypotheses": [],
        }
        snap = tmp_path / "legacy.json.gz"
        with gzip.open(snap, "wt", encoding="utf-8") as f:
            json.dump(legacy, f)

        dest_db = tmp_path / "dest.db"
        ensure_schema(str(dest_db))

        # Must not raise. Must not record any peer activity.
        import_snapshot(str(dest_db), str(snap))
        conn = sqlite3.connect(str(dest_db))
        try:
            count = conn.execute("SELECT COUNT(*) FROM peer_activity").fetchone()[0]
        finally:
            conn.close()
        assert count == 0
