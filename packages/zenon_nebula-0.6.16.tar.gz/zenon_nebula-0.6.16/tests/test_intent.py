# SPDX-License-Identifier: MIT
"""Tests for core/intent.py — operator-declared research narrative (task #71)."""

from __future__ import annotations

from pathlib import Path

from core.intent import MAX_INTENT_BYTES, intent_path, load_intent


class TestIntentPath:
    def test_default_uses_home_xdg(self, monkeypatch):
        monkeypatch.delenv("NEBULA_INTENT_PATH", raising=False)
        monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
        path = intent_path()
        assert path.name == "intent.md"
        assert path.parent.name == "nebula"
        assert path.parent.parent.name == ".config"

    def test_xdg_config_home_respected(self, monkeypatch, tmp_path):
        monkeypatch.delenv("NEBULA_INTENT_PATH", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        path = intent_path()
        assert path == tmp_path / "nebula" / "intent.md"

    def test_explicit_override_wins_over_xdg(self, monkeypatch, tmp_path):
        explicit = tmp_path / "elsewhere" / "intent.md"
        monkeypatch.setenv("NEBULA_INTENT_PATH", str(explicit))
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "should-be-ignored"))
        assert intent_path() == explicit

    def test_explicit_override_expands_tilde(self, monkeypatch):
        monkeypatch.setenv("NEBULA_INTENT_PATH", "~/custom/intent.md")
        path = intent_path()
        assert "~" not in str(path)
        assert path.name == "intent.md"

    def test_empty_env_vars_treated_as_unset(self, monkeypatch):
        monkeypatch.setenv("NEBULA_INTENT_PATH", "")
        monkeypatch.setenv("XDG_CONFIG_HOME", "")
        path = intent_path()
        # Falls through to the home default
        assert path.parent.parent.name == ".config"


class TestLoadIntent:
    def test_returns_none_when_missing(self, tmp_path):
        assert load_intent(tmp_path / "nope.md") is None

    def test_reads_file_contents(self, tmp_path):
        f = tmp_path / "intent.md"
        f.write_text("# Research focus\n\nDigging into PTLC adaptor sigs this week.\n")
        result = load_intent(f)
        assert result is not None
        assert "Research focus" in result
        assert "PTLC adaptor sigs" in result

    def test_handles_unicode(self, tmp_path):
        f = tmp_path / "intent.md"
        f.write_text("Investigating breakthroughs — émoji 🚀 ok\n", encoding="utf-8")
        result = load_intent(f)
        assert result is not None
        assert "🚀" in result

    def test_oversized_file_truncated(self, tmp_path):
        f = tmp_path / "intent.md"
        # Write 100KB — well over the 64KB cap
        big = "x" * 100_000
        f.write_text(big)
        result = load_intent(f)
        assert result is not None
        assert len(result) > MAX_INTENT_BYTES  # truncation marker added
        assert "truncated" in result.lower()

    def test_normal_size_not_truncated(self, tmp_path):
        f = tmp_path / "intent.md"
        f.write_text("normal content")
        result = load_intent(f)
        assert result == "normal content"
        assert "truncated" not in (result or "")

    def test_directory_returns_none(self, tmp_path):
        # Path points to a directory, not a file — should fail gracefully
        d = tmp_path / "intent.md"
        d.mkdir()
        assert load_intent(d) is None

    def test_uses_intent_path_when_no_arg(self, monkeypatch, tmp_path):
        f = tmp_path / "via_env.md"
        f.write_text("from env path")
        monkeypatch.setenv("NEBULA_INTENT_PATH", str(f))
        assert load_intent() == "from env path"

    def test_unreadable_file_returns_none(self, tmp_path, monkeypatch):
        """If the file exists but raises OSError on read, return None
        rather than propagating the exception."""
        f = tmp_path / "intent.md"
        f.write_text("ok")

        def boom(*args, **kwargs):
            raise OSError("simulated")

        monkeypatch.setattr(Path, "open", boom)
        assert load_intent(f) is None


# ---------------------------------------------------------------------------
# Structured parsing — 2026-04-15 format decision.
# ---------------------------------------------------------------------------


from datetime import date, datetime, timedelta, timezone

from core.intent import (
    Intent,
    format_intent_for_status,
    load_parsed_intent,
    parse_intent,
)

SAMPLE_INTENT = """---
version: 1
updated: 2026-04-15
active_from: 2026-04-15
summary: BTC bridge + pillar decentralization
---

## Current focus

Looking at Portal relayer bonding.
"""


class TestParseIntent:
    def test_extracts_frontmatter_fields(self):
        intent = parse_intent(SAMPLE_INTENT)
        assert intent.version == 1
        assert intent.updated == date(2026, 4, 15)
        assert intent.active_from == date(2026, 4, 15)
        assert intent.summary == "BTC bridge + pillar decentralization"
        assert "Portal relayer bonding" in intent.body
        assert intent.warnings == []

    def test_no_frontmatter_still_parses(self):
        intent = parse_intent("just some body text\n")
        assert intent.version == 0
        assert intent.updated is None
        assert intent.body == "just some body text\n"
        assert intent.warnings == []

    def test_unterminated_frontmatter_warns(self):
        raw = "---\nversion: 1\nno closing delimiter\n"
        intent = parse_intent(raw)
        assert any("without closing" in w for w in intent.warnings)
        # Body falls back to the full raw content so operator can still read it.
        assert "version: 1" in intent.body

    def test_malformed_yaml_warns(self):
        raw = "---\n: not valid yaml ::\n---\nbody\n"
        intent = parse_intent(raw)
        assert any("yaml parse error" in w for w in intent.warnings)
        assert intent.body.strip() == "body"

    def test_non_mapping_root_warns(self):
        raw = "---\n- 1\n- 2\n---\nbody\n"
        intent = parse_intent(raw)
        assert any("must be a mapping" in w for w in intent.warnings)

    def test_version_coerces_to_int(self):
        raw = '---\nversion: "3"\n---\nbody\n'
        intent = parse_intent(raw)
        assert intent.version == 3

    def test_bad_version_warns_and_defaults_to_zero(self):
        raw = "---\nversion: not-a-number\n---\nbody\n"
        intent = parse_intent(raw)
        assert intent.version == 0
        assert any("version" in w for w in intent.warnings)

    def test_string_date_accepted(self):
        raw = '---\nupdated: "2026-04-01"\n---\nbody\n'
        intent = parse_intent(raw)
        assert intent.updated == date(2026, 4, 1)

    def test_bad_date_warns_and_defaults_to_none(self):
        raw = "---\nupdated: yesterday\n---\nbody\n"
        intent = parse_intent(raw)
        assert intent.updated is None
        assert any("updated" in w for w in intent.warnings)


class TestIntentAge:
    def test_age_days_for_today(self):
        intent = Intent(path=Path("/x"), body="", updated=datetime.now(timezone.utc).date())
        assert intent.age_days() == 0
        assert not intent.is_stale()

    def test_age_days_for_past_date(self):
        three_ago = datetime.now(timezone.utc).date() - timedelta(days=3)
        intent = Intent(path=Path("/x"), body="", updated=three_ago)
        assert intent.age_days() == 3

    def test_is_stale_flags_old_intent(self):
        old = datetime.now(timezone.utc).date() - timedelta(days=60)
        intent = Intent(path=Path("/x"), body="", updated=old)
        assert intent.is_stale()

    def test_missing_date_is_never_stale(self):
        intent = Intent(path=Path("/x"), body="body")
        assert intent.age_days() is None
        assert not intent.is_stale()


class TestLoadParsedIntent:
    def test_missing_file_returns_none(self, tmp_path):
        assert load_parsed_intent(tmp_path / "nope.md") is None

    def test_directory_returns_none(self, tmp_path):
        d = tmp_path / "intent.md"
        d.mkdir()
        assert load_parsed_intent(d) is None

    def test_roundtrips_sample(self, tmp_path):
        f = tmp_path / "intent.md"
        f.write_text(SAMPLE_INTENT)
        intent = load_parsed_intent(f)
        assert intent is not None
        assert intent.path == f
        assert intent.version == 1
        assert intent.summary.startswith("BTC bridge")

    def test_oversize_returns_warning_intent(self, tmp_path, monkeypatch):
        # Force the cap to something tiny so a small file trips it.
        monkeypatch.setattr("core.intent.MAX_INTENT_BYTES", 10)
        f = tmp_path / "intent.md"
        f.write_text(SAMPLE_INTENT)
        intent = load_parsed_intent(f)
        assert intent is not None
        assert intent.body == ""
        assert any("larger than" in w for w in intent.warnings)


class TestFormatForStatus:
    def test_none_returns_empty_string(self):
        assert format_intent_for_status(None) == ""

    def test_fresh_intent_shows_today(self):
        intent = Intent(
            path=Path("/x"),
            body="body",
            version=1,
            updated=datetime.now(timezone.utc).date(),
            summary="focus area",
        )
        out = format_intent_for_status(intent)
        assert "today" in out
        assert "focus area" in out
        assert "stale" not in out

    def test_stale_intent_flagged(self):
        old = datetime.now(timezone.utc).date() - timedelta(days=45)
        intent = Intent(
            path=Path("/x"),
            body="body",
            version=2,
            updated=old,
            summary="old focus",
        )
        out = format_intent_for_status(intent)
        assert "[stale]" in out
        assert "45d ago" in out

    def test_warnings_appear_on_second_line(self):
        intent = Intent(
            path=Path("/x"),
            body="body",
            warnings=["frontmatter: yaml parse error"],
        )
        out = format_intent_for_status(intent)
        assert "warnings:" in out
        assert out.count("\n") >= 1
