# SPDX-License-Identifier: MIT
"""Tests for domains.self_maintenance.engines.api_suggester — task #66 Phase D3."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest

from core.persistence.schema import ensure_schema
from domains.self_maintenance.engines import api_suggester


class TestHelpers:
    def test_parse_suggestions_valid_json(self):
        raw = json.dumps(
            [
                {
                    "suggestion_domain": "market",
                    "api_name": "CoinGecko",
                    "reason": "x",
                    "setup_hint": "y",
                }
            ]
        )
        out = api_suggester._parse_suggestions(raw)
        assert len(out) == 1
        assert out[0]["api_name"] == "CoinGecko"

    def test_parse_suggestions_markdown_fence(self):
        raw = '```json\n[{"suggestion_domain": "rpc", "api_name": "Alchemy"}]\n```'
        out = api_suggester._parse_suggestions(raw)
        assert len(out) == 1

    def test_parse_suggestions_empty_array(self):
        assert api_suggester._parse_suggestions("[]") == []

    def test_parse_suggestions_invalid_json(self):
        assert api_suggester._parse_suggestions("not json at all") == []

    def test_parse_suggestions_caps_at_max(self):
        items = [{"suggestion_domain": f"d{i}", "api_name": f"a{i}"} for i in range(10)]
        out = api_suggester._parse_suggestions(json.dumps(items))
        assert len(out) == api_suggester.MAX_PROPOSALS_PER_CYCLE

    def test_build_prompt_includes_context(self):
        prompt = api_suggester._build_prompt(
            active=["github", "coingecko"],
            failing=[{"name": "broken_api", "total": 10, "errors": 8}],
            starved=["security", "governance"],
        )
        assert "github" in prompt
        assert "broken_api" in prompt
        assert "security" in prompt


class TestRunApiSuggester:
    def _setup_db(self, tmp_path):
        db = tmp_path / "engine.db"
        ensure_schema(str(db))
        return str(db)

    def test_no_api_key_returns_noop(self, tmp_path, monkeypatch):
        monkeypatch.delenv("XAI_API_KEY", raising=False)
        db = self._setup_db(tmp_path)
        out = api_suggester.run_api_suggester(db_path=db)
        assert out["reason"] == "no_api_key"
        assert out["findings_persisted"] == 0

    def test_no_telemetry_returns_noop(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake-key-for-test")
        db = self._setup_db(tmp_path)
        out = api_suggester.run_api_suggester(db_path=db)
        assert out["reason"] == "no_telemetry"

    def test_persists_suggestions_from_llm(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake-key-for-test")
        db = self._setup_db(tmp_path)
        conn = sqlite3.connect(db)
        conn.execute(
            "INSERT INTO api_call_log (provider_name, status) VALUES (?, ?)",
            ("test_provider", "ok"),
        )
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, finding) "
            "VALUES ('security', 'vuln_scanner', 'scan', 'placeholder')"
        )
        conn.commit()
        conn.close()

        fake_response = json.dumps(
            [
                {
                    "suggestion_domain": "blockchain_explorer",
                    "api_name": "Blockstream",
                    "reason": "fills BTC monitoring gap",
                    "setup_hint": "https://blockstream.info/api",
                }
            ]
        )
        with patch("core.llm_provider.call_llm", return_value=fake_response):
            out = api_suggester.run_api_suggester(db_path=db)

        assert out["suggestions_proposed"] == 1
        assert out["findings_persisted"] == 1

        with sqlite3.connect(db) as c:
            rows = c.execute(
                "SELECT raw_data FROM evidence WHERE engine = 'api_suggester'"
            ).fetchall()
        assert len(rows) == 1
        payload = json.loads(rows[0][0])["data"]
        assert payload["api_name"] == "Blockstream"

    def test_cooldown_prevents_repeat(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake-key-for-test")
        db = self._setup_db(tmp_path)
        conn = sqlite3.connect(db)
        conn.execute(
            "INSERT INTO api_call_log (provider_name, status) VALUES (?, ?)",
            ("p1", "ok"),
        )
        conn.commit()
        conn.close()

        fake_response = json.dumps(
            [
                {
                    "suggestion_domain": "market_data",
                    "api_name": "CoinGecko",
                    "reason": "x",
                    "setup_hint": "y",
                }
            ]
        )
        with patch("core.llm_provider.call_llm", return_value=fake_response):
            first = api_suggester.run_api_suggester(db_path=db)
            second = api_suggester.run_api_suggester(db_path=db)

        assert first["findings_persisted"] == 1
        assert second["findings_persisted"] == 0

    def test_db_unavailable_degrades(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake-key-for-test")
        with patch.object(api_suggester, "connect", side_effect=sqlite3.OperationalError("boom")):
            out = api_suggester.run_api_suggester(db_path="/tmp/unused.db")
        assert out["reason"] == "db_unavailable"

    def test_llm_failure_degrades(self, tmp_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake-key-for-test")
        db = self._setup_db(tmp_path)
        conn = sqlite3.connect(db)
        conn.execute("INSERT INTO api_call_log (provider_name, status) VALUES ('p1', 'ok')")
        conn.commit()
        conn.close()

        with patch("core.llm_provider.call_llm", side_effect=RuntimeError("LLM down")):
            out = api_suggester.run_api_suggester(db_path=db)
        assert out["reason"] == "llm_failed"
