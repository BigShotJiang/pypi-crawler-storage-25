# SPDX-License-Identifier: MIT
"""Test the import_snapshot → record_peer_activity hook.

Task #70 Phase 2: importing a snapshot tagged with a peer_id marks
that peer as recently active. Phase 1 shipped the tracking table +
helper functions; this phase wires the first real caller.
"""

from __future__ import annotations

import gzip
import json
import sqlite3
import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core import trust
from core.persistence.schema import ensure_schema
from core.sync import SNAPSHOT_VERSION, import_snapshot


def _make_minimal_snapshot(tmp_path: Path) -> Path:
    """Create a well-formed gzipped snapshot with one evidence row."""
    snapshot = {
        "version": SNAPSHOT_VERSION,
        "evidence": [
            {
                "domain": "intelligence",
                "engine": "test_engine",
                "evidence_type": "observation",
                "finding": "synthetic finding from test",
                "confidence": 0.5,
            }
        ],
        "hypotheses": [],
    }
    path = tmp_path / "snapshot.json.gz"
    with gzip.open(path, "wb") as f:
        f.write(json.dumps(snapshot).encode("utf-8"))
    return path


def _peer_row(db_path: str, peer_id: str) -> tuple[int, str] | None:
    """Return (activity_count, last_activity_ts) for a peer, or None."""
    conn = sqlite3.connect(db_path)
    try:
        row = conn.execute(
            "SELECT activity_count, last_activity_ts FROM peer_activity WHERE participant_id = ?",
            (peer_id,),
        ).fetchone()
    finally:
        conn.close()
    return tuple(row) if row else None


class TestPeerActivityHook:
    def test_import_with_peer_id_records_activity(self, tmp_path):
        db = tmp_path / "engine.db"
        ensure_schema(str(db))
        snap = _make_minimal_snapshot(tmp_path)

        # Before: no row for this peer.
        assert _peer_row(str(db), "alice") is None

        import_snapshot(str(db), str(snap), peer_id="alice")

        # After: activity_count == 1.
        row = _peer_row(str(db), "alice")
        assert row is not None
        assert row[0] == 1

    def test_import_without_peer_id_is_no_op(self, tmp_path):
        db = tmp_path / "engine.db"
        ensure_schema(str(db))
        snap = _make_minimal_snapshot(tmp_path)

        import_snapshot(str(db), str(snap))

        # Table may not even have a row for anonymous — confirm it
        # stays empty, proving no accidental "anonymous" auto-track.
        conn = sqlite3.connect(str(db))
        try:
            count = conn.execute("SELECT COUNT(*) FROM peer_activity").fetchone()[0]
        finally:
            conn.close()
        assert count == 0

    def test_repeat_imports_from_same_peer_accumulate(self, tmp_path):
        db = tmp_path / "engine.db"
        ensure_schema(str(db))
        snap = _make_minimal_snapshot(tmp_path)

        import_snapshot(str(db), str(snap), peer_id="bob")
        import_snapshot(str(db), str(snap), peer_id="bob")
        import_snapshot(str(db), str(snap), peer_id="bob")

        row = _peer_row(str(db), "bob")
        assert row is not None
        assert row[0] == 3

    def test_reputation_multiplier_reflects_recorded_activity(self, tmp_path):
        """End-to-end: import with peer_id → the decay multiplier for
        that peer is 1.0 (fresh). Proves the Phase 1 multiplier and
        Phase 2 hook compose correctly."""
        db = tmp_path / "engine.db"
        ensure_schema(str(db))
        snap = _make_minimal_snapshot(tmp_path)

        import_snapshot(str(db), str(snap), peer_id="charlie")
        multiplier = trust.compute_peer_reputation_multiplier("charlie", db_path=str(db))
        # Approx 1.0 — tiny drift (<1e-6) from the wall-clock delta
        # between insert and compute is expected and harmless.
        assert multiplier == pytest.approx(1.0, abs=0.001)

    def test_trust_layer_error_does_not_break_import(self, tmp_path, monkeypatch):
        """If record_peer_activity raises (e.g., DB lock contention),
        the import must still succeed. Trust tracking is
        best-effort — corrupting the snapshot-import success signal
        would be worse than missing a peer activity record."""
        db = tmp_path / "engine.db"
        ensure_schema(str(db))
        snap = _make_minimal_snapshot(tmp_path)

        def _raiser(*args, **kwargs):
            raise RuntimeError("simulated trust-layer crash")

        monkeypatch.setattr(trust, "record_peer_activity", _raiser)

        stats = import_snapshot(str(db), str(snap), peer_id="dave")
        # The import succeeded — stats reflect the imported row.
        assert stats["evidence_imported"] == 1
