# SPDX-License-Identifier: MIT
"""
Evidence Sync -- Export, import, and sync evidence snapshots.

Allows Nebula instances to share evidence via snapshot files.
Snapshots are gzipped JSON containing evidence and hypotheses rows,
excluding private domains (configurable).

Usage:
    from core.sync import get_evidence_height, export_snapshot, import_snapshot

    height = get_evidence_height(db_path)
    export_snapshot(db_path, "snapshot.json.gz")
    import_snapshot(db_path, "snapshot.json.gz")
"""

import contextlib
import gzip
import json
import logging
import os
import shutil
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from core.http import opsec_urlopen
from core.persist_to_db import DEFAULT_DB, _get_connection, ensure_schema
from core.persistence import connect

logger = logging.getLogger(__name__)

# Domains whose evidence is never exported (private research)
PRIVATE_DOMAINS = frozenset(
    {
        "marketing",
        "investigation",
    }
)

SNAPSHOT_VERSION = 1


def get_evidence_height(db_path: str = DEFAULT_DB) -> int:
    """Return the max evidence ID (the current 'height' of the evidence chain).

    Returns 0 if the database does not exist or has no evidence.
    """
    if not os.path.exists(db_path):
        return 0
    try:
        conn = connect(db_path)
        row = conn.execute("SELECT MAX(id) FROM evidence").fetchone()
        conn.close()
        return row[0] or 0
    except Exception as exc:
        logger.debug("Could not read evidence height: %s", exc)
        return 0


def export_snapshot(
    db_path: str = DEFAULT_DB,
    output_path: str | None = None,
    exclude_domains: frozenset | None = None,
) -> str:
    """Export evidence and hypotheses to a gzipped JSON snapshot.

    Args:
        db_path:         Path to the engine database.
        output_path:     Where to write the snapshot. Defaults to
                         data/snapshot_<height>.json.gz next to the DB.
        exclude_domains: Domains to exclude. Defaults to PRIVATE_DOMAINS.

    Returns:
        The absolute path of the written snapshot file.
    """
    ensure_schema(db_path)
    excluded = exclude_domains if exclude_domains is not None else PRIVATE_DOMAINS

    conn = _get_connection(db_path)
    conn.row_factory = sqlite3.Row
    try:
        # Build domain exclusion clause
        if excluded:
            placeholders = ",".join("?" for _ in excluded)
            domain_filter = f" WHERE domain NOT IN ({placeholders})"
            domain_params = tuple(excluded)
        else:
            domain_filter = ""
            domain_params = ()

        evidence_rows = conn.execute(
            f"SELECT * FROM evidence{domain_filter} ORDER BY id",
            domain_params,
        ).fetchall()

        hypotheses_rows = conn.execute(
            f"SELECT * FROM hypotheses{domain_filter}",
            domain_params,
        ).fetchall()

        evidence = [dict(r) for r in evidence_rows]
        hypotheses = [dict(r) for r in hypotheses_rows]
    finally:
        conn.close()

    # OPSEC: every finding gets deep-sanitized before it leaves the
    # local database. sanitize_for_sharing strips:
    # - Local filesystem paths even inside nested JSON
    # - Participant ID (when set to a real identity)
    # - Git author / committer lines
    # - Exact timestamps (timezone fingerprint)
    # - API keys, wallet keys, SSH keys, emails, IPs
    # Pre-v0.2.6 snapshots were being exported WITHOUT this sanitize
    # step — the docs claimed the sanitizer ran but it wasn't wired
    # up. Fixed in v0.2.7. See docs/SECURITY-OPSEC-AUDIT.md.
    try:
        from core.opsec import OPSECGuard

        participant = os.environ.get("NEBULA_PARTICIPANT_ID", "anonymous")

        def _scrub_row(row: dict) -> dict:
            cleaned = dict(row)
            for text_field in ("finding", "title", "description", "source_file", "raw_data"):
                if text_field in cleaned and isinstance(cleaned[text_field], str):
                    cleaned[text_field] = OPSECGuard.sanitize_for_sharing(
                        cleaned[text_field], participant_id=participant
                    )
            return cleaned

        evidence = [_scrub_row(r) for r in evidence]
        hypotheses = [_scrub_row(r) for r in hypotheses]
    except Exception as exc:
        logger.error(
            "CRITICAL: snapshot sanitize_for_sharing failed (%s). "
            "Refusing to export unsanitized snapshot.",
            exc,
        )
        raise RuntimeError("snapshot sanitization failed — refusing to export") from exc

    height = evidence[-1]["id"] if evidence else 0

    # Task #73 Phase 1 — elder attribution. Stamp the producer's
    # participant ID onto the snapshot so the importer can credit
    # the elder's peer_activity without the caller having to know
    # who sent the file. Empty string / "anonymous" is still a valid
    # value; the importer treats empty as "no elder context."
    elder_id = os.environ.get("NEBULA_PARTICIPANT_ID", "").strip()

    snapshot = {
        "version": SNAPSHOT_VERSION,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "elder_id": elder_id,
        "evidence_height": height,
        "evidence_count": len(evidence),
        "hypotheses_count": len(hypotheses),
        "excluded_domains": sorted(excluded),
        "evidence": evidence,
        "hypotheses": hypotheses,
    }

    if output_path is None:
        db_dir = str(Path(db_path).parent)
        output_path = os.path.join(db_dir, f"snapshot_{height}.json.gz")

    with gzip.open(output_path, "wt", encoding="utf-8") as f:
        json.dump(snapshot, f, default=str)

    logger.info(
        "Exported snapshot: %d evidence, %d hypotheses -> %s",
        len(evidence),
        len(hypotheses),
        output_path,
    )
    return os.path.abspath(output_path)


def import_snapshot(
    db_path: str = DEFAULT_DB,
    snapshot_path: str = "",
    *,
    peer_id: str | None = None,
) -> dict:
    """Import a snapshot file into the database with deduplication.

    Evidence rows are deduped by (engine, evidence_type, finding).
    Hypotheses are deduped by id.

    Args:
        db_path:       Path to the engine database.
        snapshot_path: Path to the gzipped JSON snapshot.
        peer_id:       Optional identifier of the peer who produced
            this snapshot. When provided, ``core.trust.record_peer_activity``
            is called once after a successful import so the peer's
            decay multiplier (task #70) sees them as recently active.
            ``None`` (the default) falls back to the ``elder_id`` field
            inside the snapshot JSON (task #73 Phase 1) — so the
            importer credits the elder without the caller having to
            know who exported it. Empty / missing ``elder_id`` →
            no activity recorded.

    Returns:
        Dict with import stats: evidence_imported, evidence_skipped,
        hypotheses_imported, hypotheses_skipped.
    """
    ensure_schema(db_path)

    with gzip.open(snapshot_path, "rt", encoding="utf-8") as f:
        snapshot = json.load(f)

    version = snapshot.get("version", 0)
    if version != SNAPSHOT_VERSION:
        logger.warning(
            "Snapshot version %d != expected %d; attempting import anyway",
            version,
            SNAPSHOT_VERSION,
        )

    evidence_rows = snapshot.get("evidence", [])
    hypotheses_rows = snapshot.get("hypotheses", [])

    conn = _get_connection(db_path)
    stats = {
        "evidence_imported": 0,
        "evidence_skipped": 0,
        "hypotheses_imported": 0,
        "hypotheses_skipped": 0,
    }

    try:
        # Import evidence with dedup
        for row in evidence_rows:
            existing = conn.execute(
                "SELECT id FROM evidence WHERE engine = ? AND evidence_type = ? AND finding = ?",
                (row.get("engine", ""), row.get("evidence_type", ""), row.get("finding", "")),
            ).fetchone()
            if existing:
                stats["evidence_skipped"] += 1
                continue

            conn.execute(
                """INSERT INTO evidence
                (domain, engine, evidence_type, finding, confidence,
                 supports_hypothesis, contradicts_hypothesis,
                 verification_url, raw_data, provenance, published,
                 run_id, parent_finding_id,
                 source_repo, source_file, source_commit, source_line,
                 reproducible_command)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    row.get("domain", "system"),
                    row.get("engine", ""),
                    row.get("evidence_type", ""),
                    row.get("finding", ""),
                    row.get("confidence", 0.0),
                    row.get("supports_hypothesis"),
                    row.get("contradicts_hypothesis"),
                    row.get("verification_url"),
                    row.get("raw_data"),
                    row.get("provenance", "imported"),
                    row.get("published", False),
                    row.get("run_id"),
                    row.get("parent_finding_id"),
                    row.get("source_repo"),
                    row.get("source_file"),
                    row.get("source_commit"),
                    row.get("source_line"),
                    row.get("reproducible_command"),
                ),
            )
            stats["evidence_imported"] += 1

        # Import hypotheses with dedup
        for row in hypotheses_rows:
            existing = conn.execute(
                "SELECT id FROM hypotheses WHERE id = ?",
                (row.get("id", ""),),
            ).fetchone()
            if existing:
                stats["hypotheses_skipped"] += 1
                continue

            conn.execute(
                """INSERT INTO hypotheses
                (id, domain, title, evidence_for, evidence_against,
                 confidence, status, last_updated, publishable)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    row.get("id", ""),
                    row.get("domain", "system"),
                    row.get("title", ""),
                    row.get("evidence_for", "[]"),
                    row.get("evidence_against", "[]"),
                    row.get("confidence", 0.0),
                    row.get("status", "INVESTIGATING"),
                    row.get("last_updated"),
                    row.get("publishable", False),
                ),
            )
            stats["hypotheses_imported"] += 1

        conn.commit()
    finally:
        conn.close()

    logger.info(
        "Imported snapshot: %d evidence (+%d skipped), %d hypotheses (+%d skipped)",
        stats["evidence_imported"],
        stats["evidence_skipped"],
        stats["hypotheses_imported"],
        stats["hypotheses_skipped"],
    )

    # Task #70 Phase 2 + #73 Phase 1 — record peer activity so the
    # decay multiplier sees this peer as recently active.
    #
    # Resolution order:
    #   1. Explicit peer_id from caller (wins)
    #   2. elder_id field in the snapshot JSON (task #73 Phase 1)
    #   3. No record
    #
    # Wrapped to prevent a trust-layer error from poisoning the
    # import's success signal.
    effective_peer = peer_id or snapshot.get("elder_id", "") or None
    if effective_peer and isinstance(effective_peer, str) and effective_peer.strip():
        try:
            from core.trust import record_peer_activity

            record_peer_activity(effective_peer.strip(), db_path=db_path)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("record_peer_activity failed for peer %s: %s", effective_peer, exc)

    return stats


def sync_from_url(
    db_path: str = DEFAULT_DB,
    url: str | None = None,
) -> dict:
    """Download a snapshot from a URL and import it.

    Args:
        db_path: Path to the engine database.
        url:     URL of the snapshot file. Defaults to NEBULA_SNAPSHOT_URL env var.

    Returns:
        Import stats dict, or {"error": "..."} on failure.
    """
    if url is None:
        url = os.environ.get("NEBULA_SNAPSHOT_URL", "")
    if not url:
        return {"error": "No snapshot URL configured. Set NEBULA_SNAPSHOT_URL in .env"}

    # Defined before the try so the finally cleanup is safe even if
    # tempfile creation itself raises (disk full, permission denied).
    tmp_path: str | None = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".json.gz", delete=False) as tmp:
            tmp_path = tmp.name

        logger.info("Downloading snapshot from %s", url)
        # OPSEC: must go through opsec_urlopen — plain urllib.urlretrieve
        # sends the default Python-urllib/3.x User-Agent, a unique
        # fingerprint that would link every `nebula sync` request from
        # the same operator. opsec_urlopen rotates a real browser UA and
        # strips forbidden identifying headers.
        with opsec_urlopen(url, timeout=60) as resp, open(tmp_path, "wb") as out:
            shutil.copyfileobj(resp, out)

        stats = import_snapshot(db_path, tmp_path)
        return stats
    except Exception as exc:
        logger.error("Sync failed: %s", exc)
        return {"error": str(exc)}
    finally:
        if tmp_path is not None:
            with contextlib.suppress(OSError):
                os.unlink(tmp_path)
