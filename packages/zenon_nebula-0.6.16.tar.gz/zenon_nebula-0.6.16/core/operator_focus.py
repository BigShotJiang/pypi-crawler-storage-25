# SPDX-License-Identifier: MIT
"""Operator focus — read the ``--focus`` directive from RunContext.

Engines and meta-layer modules (Director, War Room, Breakthrough Engine)
call ``get_focus()`` to check whether the operator declared a focus for
this run. When set, findings whose evidence contains focus keywords get
an operator-alignment boost on top of mission-alignment scoring.

Usage::

    from core.operator_focus import get_focus, matches_focus

    focus = get_focus()       # str | None
    if focus and matches_focus(finding_text, focus):
        # boost this finding in the battle plan
        ...

The focus is per-run only (``--focus "PTLC bugs"``). The durable
version is task #71 (``~/.config/nebula/intent.md``).
"""

from __future__ import annotations

import re


def get_focus() -> str | None:
    """Return the operator's ``--focus`` directive, or ``None``.

    Reads from the ``RunContext`` singleton. Degrades gracefully when
    the singleton isn't initialized (unit tests, non-autonomous runs).
    """
    try:
        from core.run_context import RunContext
    except ImportError:
        return None

    ctx = RunContext._current
    if ctx is None:
        return None
    return getattr(ctx, "focus", None)


def matches_focus(text: str, focus: str | None = None) -> bool:
    """Return ``True`` if *text* contains any keyword from the focus.

    Splits the focus string on whitespace, strips punctuation, and
    checks whether any resulting token (length >= 3) appears in *text*
    as a case-insensitive substring. Short tokens (< 3 chars) are
    skipped to avoid false positives on articles and prepositions.

    If *focus* is ``None``, calls ``get_focus()`` to read the current
    directive. Returns ``False`` when no focus is declared — the
    default is "everything is equally relevant."

    Args:
        text: The evidence text, finding summary, or hypothesis body
            to check against the focus.
        focus: Explicit focus string. When omitted, read from the
            RunContext singleton.

    Returns:
        ``True`` when at least one focus keyword appears in *text*.
        ``False`` when no focus is declared or no keyword matches.
    """
    if focus is None:
        focus = get_focus()
    if not focus:
        return False
    if not text:
        return False

    # Tokenize: split on whitespace, strip surrounding punctuation
    tokens = [re.sub(r"^[^\w]+|[^\w]+$", "", t) for t in focus.split()]
    keywords = [t.lower() for t in tokens if len(t) >= 3]
    if not keywords:
        return False

    text_lower = text.lower()
    return any(kw in text_lower for kw in keywords)
