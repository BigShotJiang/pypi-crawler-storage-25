# SPDX-License-Identifier: MIT
"""Diversity pressure — task #72 Phase 1 (anti-monoculture infra).

The collective-intelligence problem: when every peer runs the same
popular engines, the war room gets N copies of the same finding
across peers. That's homogeneous rescans, not divergent exploration.
Operators running unique engine combinations deserve more weight
per finding, not less.

Phase 1 ships the observation layer: a pure function that looks at
the local evidence table and scores how "saturated" each engine is
based on the source_repo spread of its findings. Heuristic stand-in
until Phase 2 ships per-peer engine manifests (which require a
transport-layer protocol change we don't want to rush).

Phase 2 will replace the source_repo heuristic with a real
"fraction of peers running this engine" metric, computed from
peer-shared engine manifests (extends the elder_id concept from
task #73).

**Today's behavior contract (Phase 1):**

- `compute_engine_saturation` returns stats per engine: finding
  count, distinct source_repos contributed, distinct provenance
  types seen.
- `compute_diversity_weight` returns a float in ``[MIN_WEIGHT, 1.0]``
  — 1.0 for specialized or healthy-diversity engines, a modest
  downweight for engines with findings spread across many repos
  (saturation proxy).
- Neither function is wired into any live weighting yet.
  Consumers that want to experiment pass ``use_diversity_weight=True``
  explicitly. When Phase 2 lands, the default wires in.

The design mirrors the reputation-decay Phase 1 → 3 pattern: ship
infra + tests first, flip live behavior last.
"""

from __future__ import annotations

import logging
import sqlite3

from core.persistence.schema import DEFAULT_DB, _get_connection

logger = logging.getLogger(__name__)


# How many distinct source_repos an engine's findings must span
# before we treat it as saturated. Below this threshold, findings
# look specialized — no downweight.
SATURATION_REPO_THRESHOLD = 5

# The maximum downweight we apply, even for heavily-saturated
# engines. Matches the peer-decay floor (task #70) — saturated
# engines aren't silenced, they just carry slightly less weight
# until diversity improves.
MIN_WEIGHT = 0.80

# Per-repo decrement past the threshold. Tuned so that an engine
# with 10 distinct repos (threshold + 5) reaches the floor.
WEIGHT_PER_EXCESS_REPO = 0.04


def compute_engine_saturation(
    engine: str,
    *,
    db_path: str | None = None,
) -> dict:
    """Return saturation stats for ``engine`` from the evidence table.

    Returns:
        Dict with:
          * ``finding_count`` — total evidence rows for this engine.
          * ``distinct_source_repos`` — count of unique source_repo
            values contributing findings. NULL source_repos are
            excluded (those are local / unprovenanced findings).
          * ``distinct_provenances`` — count of unique provenance
            values. Broad provenance mix = mature engine.

    Pure function; never mutates. Missing table / unreachable DB
    returns ``{"finding_count": 0, ...}`` rather than raising — a
    future consumer calling this during aggregation mustn't crash
    because telemetry is missing.
    """
    if not engine or not isinstance(engine, str):
        return _empty_stats()

    path = db_path or DEFAULT_DB
    try:
        conn = _get_connection(path)
    except sqlite3.OperationalError:
        return _empty_stats()
    try:
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS finding_count,
                    COUNT(DISTINCT CASE WHEN source_repo IS NOT NULL
                                        AND source_repo != ''
                                        THEN source_repo END) AS distinct_repos,
                    COUNT(DISTINCT provenance) AS distinct_provenances
                FROM evidence
                WHERE engine = ?
                """,
                (engine,),
            ).fetchone()
        except sqlite3.OperationalError:
            return _empty_stats()
    finally:
        conn.close()

    if row is None:
        return _empty_stats()
    return {
        "finding_count": int(row["finding_count"] or 0),
        "distinct_source_repos": int(row["distinct_repos"] or 0),
        "distinct_provenances": int(row["distinct_provenances"] or 0),
    }


def compute_diversity_weight(
    engine: str,
    *,
    db_path: str | None = None,
) -> float:
    """Return a weight in ``[MIN_WEIGHT, 1.0]`` for the engine.

    Heuristic:
      * Engines whose findings come from < ``SATURATION_REPO_THRESHOLD``
        distinct source_repos → 1.0 (specialized work; don't penalize).
      * Each additional source_repo past the threshold removes
        ``WEIGHT_PER_EXCESS_REPO`` from the weight, floored at
        ``MIN_WEIGHT``.

    Empty DB, missing engine, errors → 1.0 (fail-open — no
    penalty for absence of evidence).

    **This weight is not yet consumed by mission_alignment or the
    war room.** Phase 2 (task #72 follow-up) wires it in after the
    peer-manifest protocol ships. Until then this is observation-only;
    operators can call it explicitly when testing diversity signals.
    """
    stats = compute_engine_saturation(engine, db_path=db_path)
    repos = stats["distinct_source_repos"]
    if repos <= SATURATION_REPO_THRESHOLD:
        return 1.0
    excess = repos - SATURATION_REPO_THRESHOLD
    weight = 1.0 - (excess * WEIGHT_PER_EXCESS_REPO)
    return max(MIN_WEIGHT, weight)


def _empty_stats() -> dict:
    return {
        "finding_count": 0,
        "distinct_source_repos": 0,
        "distinct_provenances": 0,
    }
