# SPDX-License-Identifier: MIT
"""Operator-declared research intent (task #71).

Operators write a free-form prose narrative of their current research
focus to ``~/.config/nebula/intent.md``. The file is plain Markdown
with an optional YAML frontmatter block, and versioned by the
operator (whatever git or backup story they choose) — Nebula reads
but never writes it.

Why this exists: findings-as-task-queue (Phase I) gives Nebula a
machine-actionable to-do list. ``intent.md`` is the human-readable
counterpart — context for *why* the operator cares about the things
they care about, surfaced into ``./nebula status`` so future-self,
peers, and Phase I executor agents have shared narrative ground when
deciding what to work on.

**File format** (per the 2026-04-15 format decision):

::

    ---
    version: 1
    updated: 2026-04-15
    active_from: 2026-04-15
    summary: BTC bridge security + pillar decentralization
    ---

    ## Current focus

    <prose>

The frontmatter gives Nebula cheap metadata hooks (age, one-line
summary, operator-version tag) without parsing prose; the body is
free-form narrative. Files without frontmatter are accepted as
pure-body intent — the module treats missing structured fields
gracefully rather than failing.

**Two entry points:**

- :func:`load_intent` returns the raw string (backwards-compat with
  the v0 surface; used by callers that just want to print the file).
- :func:`load_parsed_intent` returns an :class:`Intent` dataclass
  with structured frontmatter fields + the body. Use this when you
  need age, summary, or version metadata.

Future phases (tracked under task #71):

- Peer-share: opt-in publish of intent.md as part of snapshot export
  so trusted peers see what their counterparts are thinking.
- War-room weighting: nudge the war-room synthesis toward findings
  whose tags overlap with intent keywords (kept opt-in to avoid
  echo-chamber trust drift).
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

# Hard cap on read size. The file is operator-written prose; an operator
# who pastes a 10MB transcript shouldn't melt the status command. The cap
# is generous enough for several pages of dense Markdown.
MAX_INTENT_BYTES = 64 * 1024


def intent_path() -> Path:
    """Return the canonical path to ``intent.md`` for this operator.

    Resolution order, first-hit-wins:

    1. ``$NEBULA_INTENT_PATH`` — explicit override (tests, multi-instance).
    2. ``$XDG_CONFIG_HOME/nebula/intent.md`` — XDG-spec compliant.
    3. ``$HOME/.config/nebula/intent.md`` — POSIX default.

    The path is returned even if the file doesn't exist; callers check
    existence themselves so they can choose to stay quiet vs. nudge the
    operator to create one.
    """
    explicit = os.environ.get("NEBULA_INTENT_PATH", "").strip()
    if explicit:
        return Path(explicit).expanduser()

    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        return Path(xdg).expanduser() / "nebula" / "intent.md"

    return Path.home() / ".config" / "nebula" / "intent.md"


def load_intent(path: Path | None = None) -> str | None:
    """Read the intent.md file. Return its contents, or ``None`` if absent.

    Args:
        path: Optional override (tests). Defaults to :func:`intent_path`.

    Returns:
        The file's contents, trimmed to :data:`MAX_INTENT_BYTES`. ``None``
        when the file doesn't exist or can't be read. Never raises.
    """
    target = path or intent_path()
    if not target.is_file():
        return None
    try:
        # Read up to the cap + 1 so we can detect truncation.
        with target.open("r", encoding="utf-8", errors="replace") as f:
            data = f.read(MAX_INTENT_BYTES + 1)
    except OSError as exc:
        logger.debug("intent.md read failed at %s: %s", target, exc)
        return None
    if len(data) > MAX_INTENT_BYTES:
        # Truncate cleanly at MAX_INTENT_BYTES + a marker line so the
        # operator notices their file is over the cap.
        data = data[:MAX_INTENT_BYTES] + (
            f"\n\n…[truncated; intent.md exceeds {MAX_INTENT_BYTES // 1024}KB cap]"
        )
    return data


# ---------------------------------------------------------------------------
# Structured parsing (2026-04-15 format decision)
# ---------------------------------------------------------------------------


FRONTMATTER_DELIMITER = "---"

# Stale-intent threshold. An intent that hasn't been updated in this
# many days is flagged in `nebula status` so operators re-anchor their
# narrative rather than letting it drift into irrelevance.
STALE_THRESHOLD_DAYS = 30


@dataclass
class Intent:
    """Parsed operator intent.

    ``path`` and ``body`` are always populated when an intent exists
    on disk. Frontmatter-derived fields default to safe values when
    the file has no frontmatter, malformed frontmatter, or individual
    keys missing — a warning is recorded on :attr:`warnings` instead
    of raising.
    """

    path: Path
    body: str
    version: int = 0
    updated: date | None = None
    active_from: date | None = None
    summary: str = ""
    warnings: list[str] = field(default_factory=list)
    loaded_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def age_days(self) -> int | None:
        """Days since ``updated``. ``None`` when the field is missing."""
        if self.updated is None:
            return None
        today = datetime.now(timezone.utc).date()
        return (today - self.updated).days

    def is_stale(self, threshold_days: int = STALE_THRESHOLD_DAYS) -> bool:
        """True when updated > threshold_days ago. Missing-date = not stale."""
        age = self.age_days()
        return age is not None and age > threshold_days


def _coerce_date(value) -> date | None:
    """YAML parses ``2026-04-15`` as a ``date``, but operators sometimes
    write it as a quoted string. Accept both; anything else returns
    ``None`` and the caller records a warning."""
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, str):
        try:
            return date.fromisoformat(value.strip())
        except ValueError:
            return None
    return None


def _split_frontmatter(raw: str) -> tuple[dict, str, list[str]]:
    """Return (frontmatter_dict, body, warnings) for a raw intent string.

    Accepts the standard ``---\\n<yaml>\\n---`` envelope. A file with no
    opening ``---`` returns an empty dict + full content as body.
    Malformed YAML or missing close delimiter records a warning and
    treats the whole file as body (operator can still display it).
    """
    warnings: list[str] = []
    lines = raw.splitlines()
    if not lines or lines[0].strip() != FRONTMATTER_DELIMITER:
        return {}, raw, warnings
    try:
        close_idx = next(
            i for i, line in enumerate(lines[1:], start=1) if line.strip() == FRONTMATTER_DELIMITER
        )
    except StopIteration:
        warnings.append("frontmatter: opening '---' without closing delimiter")
        return {}, raw, warnings
    fm_text = "\n".join(lines[1:close_idx])
    body = "\n".join(lines[close_idx + 1 :]).lstrip("\n")
    try:
        import yaml
    except ImportError:
        warnings.append("frontmatter: pyyaml not installed; ignored")
        return {}, body, warnings
    try:
        data = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        where = f"line {mark.line + 1}" if mark is not None else "?"
        warnings.append(f"frontmatter: yaml parse error at {where}")
        return {}, body, warnings
    if not isinstance(data, dict):
        warnings.append(f"frontmatter: root must be a mapping, got {type(data).__name__}")
        return {}, body, warnings
    return data, body, warnings


def parse_intent(raw: str, path: Path | None = None) -> Intent:
    """Pure parser. Takes a raw string, returns an :class:`Intent`.

    Use this when you already have the file contents (e.g., from a
    peer snapshot) and just need the structured view. Never raises.
    """
    fm, body, warnings = _split_frontmatter(raw)

    version_raw = fm.get("version", 0)
    try:
        version = int(version_raw)
    except (TypeError, ValueError):
        warnings.append(f"version: expected int, got {version_raw!r}")
        version = 0

    updated = _coerce_date(fm.get("updated"))
    if fm.get("updated") is not None and updated is None:
        warnings.append(f"updated: unparseable date {fm.get('updated')!r}")

    active_from = _coerce_date(fm.get("active_from"))
    if fm.get("active_from") is not None and active_from is None:
        warnings.append(f"active_from: unparseable date {fm.get('active_from')!r}")

    summary_raw = fm.get("summary", "")
    summary = str(summary_raw).strip() if summary_raw is not None else ""

    return Intent(
        path=path or Path("<inline>"),
        body=body,
        version=version,
        updated=updated,
        active_from=active_from,
        summary=summary,
        warnings=warnings,
    )


def load_parsed_intent(path: Path | None = None) -> Intent | None:
    """Load the intent file and return the structured :class:`Intent`.

    Returns ``None`` when no file exists at the resolved path (or
    sub-paths like a directory). Oversize / unreadable files return
    an ``Intent`` with populated :attr:`Intent.warnings` and empty
    body so the caller can surface the issue to the operator rather
    than silently dropping the file.
    """
    target = path or intent_path()
    if not target.is_file():
        return None

    try:
        size = target.stat().st_size
    except OSError as exc:
        logger.debug("intent.md stat failed at %s: %s", target, exc)
        return Intent(
            path=target,
            body="",
            warnings=[f"stat failed: {type(exc).__name__}"],
        )
    if size > MAX_INTENT_BYTES:
        return Intent(
            path=target,
            body="",
            warnings=[f"file larger than {MAX_INTENT_BYTES // 1024} KB — not parsed"],
        )

    try:
        raw = target.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        logger.debug("intent.md read failed at %s: %s", target, exc)
        return Intent(
            path=target,
            body="",
            warnings=[f"read failed: {type(exc).__name__}"],
        )

    return parse_intent(raw, path=target)


def format_intent_for_status(intent: Intent | None) -> str:
    """Render an intent as a one-line status header + optional body.

    Returns an empty string when ``intent`` is ``None`` (caller decides
    whether to show a nudge). When present, the header captures the
    age + summary; warnings are appended on a second line.
    """
    if intent is None:
        return ""
    age = intent.age_days()
    if age is None:
        age_str = "undated"
    elif age == 0:
        age_str = "today"
    else:
        age_str = f"{age}d ago"
    stale = " [stale]" if intent.is_stale() else ""
    header = f"v{intent.version}, updated {age_str}{stale}"
    if intent.summary:
        header += f" — {intent.summary}"
    if intent.warnings:
        header += "\n  warnings: " + "; ".join(intent.warnings)
    return header
