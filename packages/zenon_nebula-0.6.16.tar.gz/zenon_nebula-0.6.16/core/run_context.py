# SPDX-License-Identifier: MIT
"""
RunContext -- Execution context for every engine run.

Tracks domain, engine, run_id, timestamp, and budget consumption.
Each run gets a unique ID and environment fingerprint so results
are traceable to a specific code version and machine.
"""

import hashlib
import logging
import platform
import subprocess
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]


@dataclass
class BudgetTracker:
    """Tracks API cost consumption within a run."""

    max_budget_usd: float = 50.0
    total_cost_usd: float = 0.0
    calls_by_model: dict = field(default_factory=dict)

    def record_call(
        self, model: str, input_tokens: int, output_tokens: int, cost_usd: float
    ) -> None:
        """Record an API call's cost."""
        self.total_cost_usd += cost_usd
        if model not in self.calls_by_model:
            self.calls_by_model[model] = {
                "calls": 0,
                "input_tokens": 0,
                "output_tokens": 0,
                "cost_usd": 0.0,
            }
        entry = self.calls_by_model[model]
        entry["calls"] += 1
        entry["input_tokens"] += input_tokens
        entry["output_tokens"] += output_tokens
        entry["cost_usd"] += cost_usd

    @property
    def budget_remaining(self) -> float:
        """Remaining budget in USD."""
        return max(0.0, self.max_budget_usd - self.total_cost_usd)

    @property
    def budget_percent_used(self) -> float:
        """Percentage of budget consumed so far."""
        if self.max_budget_usd <= 0:
            return 100.0
        return (self.total_cost_usd / self.max_budget_usd) * 100.0

    def is_over_budget(self) -> bool:
        """True if total cost has reached or exceeded the budget limit."""
        return self.total_cost_usd >= self.max_budget_usd

    def is_warning(self, threshold_percent: float = 80.0) -> bool:
        """True if budget usage exceeds the warning threshold."""
        return self.budget_percent_used >= threshold_percent


class RunContext:
    """Tracks every execution with domain, engine, environment hash, and run_id.

    Usage::

        ctx = RunContext(domain="marketing", engine="narrative_engine")
        # ... do work ...
        ctx.log_end("processed 42 findings")

    Or use the singleton for the current session::

        ctx = RunContext.get_current()
    """

    _current: Optional["RunContext"] = None

    @classmethod
    def get_current(
        cls, domain: str = "system", engine: str = "unknown", db_path: str | None = None
    ) -> "RunContext":
        """Get or create the current run context singleton."""
        if cls._current is None:
            cls._current = cls(domain=domain, engine=engine, db_path=db_path)
        return cls._current

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton (for testing or new runs)."""
        cls._current = None

    def __init__(
        self,
        domain: str = "system",
        engine: str = "unknown",
        db_path: str | None = None,
        repos_scope: frozenset[str] | None = None,
        focus: str | None = None,
    ):
        self.run_id: str = str(uuid.uuid4())[:8]
        self.domain: str = domain
        self.engine: str = engine
        self.start_time: datetime = datetime.now(timezone.utc)
        self.db_path: str = db_path or str(ENGINE_ROOT / "data" / "engine.db")
        self.env_hash: str = self._compute_env_hash()
        self.budget: BudgetTracker = BudgetTracker()
        self.findings_count: int = 0
        self.actions_count: int = 0
        self.errors: list[str] = []
        # Operator-declared `--repos` scope. `None` means "all repos in
        # the workspace are in scope" (default). A non-None frozenset
        # means only repos matching one of these names are in scope —
        # every workspace-walking engine should honor this via
        # `is_repo_in_scope()`.
        self.repos_scope: frozenset[str] | None = repos_scope
        # Operator-declared `--focus` directive — a free-form string
        # describing what the operator cares about this run. None means
        # no focus is set. When set, the Director's prompt builder
        # injects the focus as a header block, and the breakthrough
        # engine's mission-critical surfacing check boosts findings
        # whose evidence contains focus keywords (operator_alignment
        # alongside mission_alignment). Read via
        # `core.operator_focus.get_focus()`.
        self.focus: str | None = focus

        logger.info(
            "RunContext created: run_id=%s domain=%s engine=%s env=%s",
            self.run_id,
            self.domain,
            self.engine,
            self.env_hash,
        )

    def _compute_env_hash(self) -> str:
        """Compute a hash of the execution environment.

        Combines Python version, OS, architecture, and git commit hash
        into a single 16-char fingerprint.
        """
        env_str = f"{platform.python_version()}|{platform.system()}|{platform.machine()}"
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                cwd=str(ENGINE_ROOT),
                timeout=5,
            )
            if result.returncode == 0:
                env_str += f"|{result.stdout.strip()[:8]}"
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            pass

        return hashlib.sha256(env_str.encode()).hexdigest()[:16]

    def log_end(self, summary: str = "") -> None:
        """Record run completion."""
        elapsed = self.elapsed_seconds
        logger.info(
            "Run %s completed in %.1fs domain=%s engine=%s env=%s "
            "findings=%d actions=%d errors=%d cost=$%.4f %s",
            self.run_id,
            elapsed,
            self.domain,
            self.engine,
            self.env_hash,
            self.findings_count,
            self.actions_count,
            len(self.errors),
            self.budget.total_cost_usd,
            summary,
        )

    def record_error(self, error: str) -> None:
        """Record an error during this run."""
        self.errors.append(error)
        logger.error("Run %s error: %s", self.run_id, error)

    @property
    def elapsed_seconds(self) -> float:
        """Seconds elapsed since run start."""
        return (datetime.now(timezone.utc) - self.start_time).total_seconds()

    def to_dict(self) -> dict:
        """Serialize context for logging/persistence."""
        return {
            "run_id": self.run_id,
            "domain": self.domain,
            "engine": self.engine,
            "start_time": self.start_time.isoformat(),
            "elapsed_seconds": round(self.elapsed_seconds, 2),
            "env_hash": self.env_hash,
            "findings_count": self.findings_count,
            "actions_count": self.actions_count,
            "error_count": len(self.errors),
            "budget_used_usd": round(self.budget.total_cost_usd, 4),
            "budget_remaining_usd": round(self.budget.budget_remaining, 4),
        }

    def __repr__(self) -> str:
        return (
            f"RunContext(run_id={self.run_id!r}, domain={self.domain!r}, "
            f"engine={self.engine!r}, env_hash={self.env_hash!r})"
        )
