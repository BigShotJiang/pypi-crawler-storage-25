# SPDX-License-Identifier: MIT
"""Uniform cross-repo symbol lookup for discovery engines.

Discovery engines (``reference_diff``, ``cross_chain_cve_monitor``,
``btc_spec_tracker``, ``architecture_analyzer``, etc.) routinely need
to answer questions like:

- "Where is this function called across every repo in the workspace?"
- "What does this file depend on?"
- "If I change this symbol, what downstream breaks?"

Historically each engine answered these with its own grep + Python AST
code. That's slow (O(files*repos)), brittle (name collisions inflate
false positives), and categorically unable to answer structural
questions like "are these two call graphs shaped the same?"

This module provides a single abstraction. When CodeGraphContext (CGC)
is installed it delegates to CGC's semantic graph for speed and
structural accuracy. When CGC isn't available it falls back to a
strict-pattern grep. Engines call one API, receive one shape of
result, and don't care which backend answered.

The goal: discovery engines get ~10x faster + structurally smarter
when operators install ``codegraphcontext``, without breaking the
"zero required infra" promise for operators who don't.

See ``docs/runbooks/cgc-audit.md`` for CGC install instructions,
and tasks #97/#98 in ``docs/tasks.yaml`` for the roadmap.
"""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

from core.workspace import workspace_root

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared result shape
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CallSite:
    """One location where a symbol is referenced.

    Returned by ``find_callers``. Engines can treat a list of
    ``CallSite`` instances the same regardless of backend.
    """

    file: str
    line: int
    context: str = ""
    backend: str = "grep"  # "cgc" | "grep"


@dataclass(frozen=True)
class CodeGraphBackend:
    """Describes which backend answered a query.

    Useful for telemetry: engines can record per-finding the backend
    that produced it, so operators can see whether CGC is actually
    helping or whether findings still come from grep.
    """

    name: str  # "cgc" | "grep" | "none"
    version: str = ""
    notes: tuple[str, ...] = field(default_factory=tuple)


# ---------------------------------------------------------------------------
# CGC availability
# ---------------------------------------------------------------------------


@lru_cache(maxsize=1)
def _cgc_cli_path() -> str | None:
    """Return the absolute path to the ``cgc`` CLI, or ``None``.

    Cached: CGC install state doesn't change mid-process. The cache
    can be cleared via ``reset_cache()`` in tests.
    """
    return shutil.which("cgc")


@lru_cache(maxsize=1)
def _cgc_available() -> bool:
    """Return True when CGC is installed and callable."""
    cli = _cgc_cli_path()
    if cli is None:
        return False
    try:
        result = subprocess.run(
            [cli, "--version"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False
    return result.returncode == 0


def backend() -> CodeGraphBackend:
    """Return the active backend descriptor.

    Engines can log this once at startup to record whether they got the
    fast path or the fallback. Never raises.
    """
    if _cgc_available():
        cli = _cgc_cli_path() or "cgc"
        try:
            result = subprocess.run(
                [cli, "--version"],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            version = result.stdout.strip() if result.returncode == 0 else ""
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            version = ""
        return CodeGraphBackend(
            name="cgc",
            version=version,
            notes=("semantic call-graph queries available",),
        )
    return CodeGraphBackend(
        name="grep",
        version="",
        notes=(
            "CGC not installed — discovery engines fall back to grep.",
            "For ~10x faster cross-repo queries: pip install codegraphcontext",
        ),
    )


def reset_cache() -> None:
    """Reset the CGC availability cache.

    Intended for tests that monkeypatch ``shutil.which`` to simulate
    CGC missing/present. Production code should not need this.
    """
    _cgc_cli_path.cache_clear()
    _cgc_available.cache_clear()


# ---------------------------------------------------------------------------
# Grep fallback
# ---------------------------------------------------------------------------


# Files we never grep through even in workspace-wide searches.
_SKIP_DIRS = frozenset(
    {
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        ".mypy_cache",
        ".pytest_cache",
        "dist",
        "build",
        "target",
        "vendor",
        ".hypothesis",
    }
)

# File extensions worth grepping. Everything else is skipped to keep
# the search fast on 160-repo workspaces.
_CODE_EXTENSIONS = frozenset(
    {
        ".py",
        ".go",
        ".rs",
        ".ts",
        ".tsx",
        ".js",
        ".jsx",
        ".dart",
        ".sol",
        ".c",
        ".cpp",
        ".h",
        ".hpp",
        ".java",
        ".kt",
        ".swift",
        ".rb",
        ".php",
    }
)


def _iter_code_files(root: Path):
    """Yield ``Path`` objects for every code file under *root*.

    Skips the directories in ``_SKIP_DIRS`` to avoid walking vendored
    trees and caches. Silently ignores permission errors — a single
    unreadable repo should not poison the whole search.
    """
    try:
        for entry in root.iterdir():
            if entry.is_dir():
                if entry.name in _SKIP_DIRS:
                    continue
                yield from _iter_code_files(entry)
            elif entry.suffix in _CODE_EXTENSIONS:
                yield entry
    except (PermissionError, OSError):
        return


def _grep_find_callers(
    symbol: str,
    *,
    repo_path: Path | None,
    max_results: int,
) -> list[CallSite]:
    """Grep fallback for ``find_callers``.

    Uses a strict word-boundary regex so ``validate`` doesn't match
    ``re_validate``. Returns at most *max_results* sites to keep the
    result bounded for very common names.
    """
    if not symbol:
        return []
    # Word-boundary pattern that works across Go/Python/TS/Dart/Rust.
    # Must match: foo(, .foo(, foo = (assignment), foo\s (symbol ref)
    # Must NOT match: prefixfoo, foobar (token continues).
    pattern = re.compile(r"(?<![A-Za-z0-9_])" + re.escape(symbol) + r"(?![A-Za-z0-9_])")
    root = repo_path or workspace_root()
    if root is None:
        return []

    results: list[CallSite] = []
    for code_file in _iter_code_files(root):
        try:
            text = code_file.read_text(encoding="utf-8", errors="ignore")
        except (OSError, UnicodeDecodeError):
            continue
        for lineno, line in enumerate(text.splitlines(), start=1):
            if pattern.search(line):
                results.append(
                    CallSite(
                        file=str(code_file),
                        line=lineno,
                        context=line.strip()[:200],
                        backend="grep",
                    )
                )
                if len(results) >= max_results:
                    return results
    return results


# ---------------------------------------------------------------------------
# CGC backend (stubs — filled in as CGC CLI coverage lands)
# ---------------------------------------------------------------------------


def _cgc_find_callers(
    symbol: str,
    *,
    repo_path: Path | None,
    max_results: int,
) -> list[CallSite] | None:
    """CGC-backed ``find_callers``.

    Returns ``None`` when CGC can't answer the query (not installed,
    repo not indexed, query shape not yet supported by the CLI). The
    caller then falls back to grep. Never raises on CGC errors — a
    crashed CGC should degrade silently, not bubble up.

    Current state: CGC v0.4.2 does not expose ``find_callers`` via the
    CLI — the equivalent lives behind the MCP ``analyze_code_relationships``
    tool which is not addressable from a normal Python subprocess.
    This function returns ``None`` for now, and engines transparently
    fall back to grep. When CGC ships CLI coverage (tracked upstream)
    or when we add an in-process MCP client, we fill in the query
    here and every engine immediately benefits.
    """
    # Suppress unused-argument warnings — the signature is the API
    # contract, even while the implementation is a stub.
    del symbol, repo_path, max_results
    if not _cgc_available():
        return None
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def find_callers(
    symbol: str,
    *,
    repo_path: str | Path | None = None,
    max_results: int = 500,
) -> list[CallSite]:
    """Return every location that references *symbol*.

    Prefers CGC for semantic accuracy + speed; falls back to strict-
    pattern grep when CGC isn't available or can't answer. Either way,
    the return shape is a list of :class:`CallSite` with the
    ``backend`` field indicating which path answered.

    Args:
        symbol: The exact symbol name (function, class, constant).
            Case-sensitive. Short names (< 3 chars) are rejected to
            avoid returning tens of thousands of false positives.
        repo_path: Restrict search to a single repo. ``None`` searches
            the entire workspace.
        max_results: Hard cap on the number of results returned. The
            default 500 is large enough for most investigation queries
            without blowing up on common names.

    Returns:
        A list of :class:`CallSite`. Empty list when nothing matches.
        Never raises — backend errors degrade to the next backend.
    """
    if not symbol or len(symbol) < 3:
        logger.debug("find_callers: ignoring short/empty symbol %r", symbol)
        return []

    path = Path(repo_path).expanduser().resolve() if repo_path else None

    # Try CGC first
    cgc_result = _cgc_find_callers(symbol, repo_path=path, max_results=max_results)
    if cgc_result is not None:
        return cgc_result

    # Grep fallback
    return _grep_find_callers(symbol, repo_path=path, max_results=max_results)


def find_dependencies(file_path: str | Path) -> list[str] | None:
    """Return the files that *file_path* depends on (imports/includes).

    Returns ``None`` when no backend can answer — callers decide
    whether to degrade to something weaker (e.g., parse the file's
    import statements themselves) or skip.

    Currently a stub: ``codebase_improvement_auditor`` (task #93) is
    the first engine that will exercise this path; filling it in
    before there's a consumer risks shipping dead code.
    """
    del file_path
    if not _cgc_available():
        return None
    return None


def analyze_impact(symbol: str, *, repo_path: str | Path | None = None) -> dict | None:
    """Return a forward dependency cone for *symbol*.

    Answers "if I change this symbol, what files downstream break?"
    Returns ``None`` when CGC isn't available — the query is
    inherently graph-structural and has no grep equivalent.

    Stub: see :func:`find_dependencies` — shipped as a stable API now
    so ``cross_chain_pattern_finder`` (task #98) can build against it.
    """
    del symbol, repo_path
    if not _cgc_available():
        return None
    return None
