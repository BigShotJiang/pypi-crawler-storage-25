# SPDX-License-Identifier: MIT
"""The `./nebula upgrade` implementation — task #50 Track 2 Phase B.

v0.6.0 shipped the **notifier** (detect an update exists and nudge the
operator). This module ships the **action** (apply the update).

The upgrade command's contract:

1. Call ``core.upgrade_check.check_for_update()`` for the current vs
   latest version.
2. If no update available, exit 0 with a "you're up to date" message.
3. Otherwise, run ``pip install --upgrade zenon-nebula==<latest>`` via
   subprocess. Surface stdout/stderr to the operator.
4. On success, stamp the old version into
   ``~/.cache/nebula/previous_version.json`` so ``--rollback`` has a
   target.

Rollback (``./nebula upgrade --rollback``):

1. Read the stamped previous version.
2. ``pip install zenon-nebula==<previous>`` — pin, don't range-match.
3. On success, remove the stamp (don't allow double-rollback to some
   ancient version the operator may not remember).

**Discipline:**

- Subprocess timeout capped at 5 minutes. `pip install` from a cold
  cache can be slow over poor networks; 5 min is a reasonable wall.
- Never modifies the DB, never touches evidence. This is a package
  management operation, not a finding-producing operation.
- ``--dry-run`` flag inspects what would happen without executing
  ``pip``. Useful for operators testing upgrade policies.
- Respects ``PIP_INDEX_URL`` and ``NEBULA_PIP_ARGS`` env vars so
  operators with private mirrors or constrained envs can route the
  install correctly.

Phase C (task #50 Track 2) — scheduled downgrade on CI failure — is
deferred; the mechanical rollback here is the foundation it will build
on.
"""

from __future__ import annotations

import json
import logging
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from core.upgrade_check import check_for_update

logger = logging.getLogger(__name__)


# Where we stamp the old version on upgrade so rollback has a target.
# Lives under XDG_CACHE_HOME if set, else ~/.cache/nebula/.
def _previous_version_path() -> Path:
    """Return the path to the previous-version stamp file."""
    xdg = os.environ.get("XDG_CACHE_HOME", "").strip()
    if xdg:
        return Path(xdg).expanduser() / "nebula" / "previous_version.json"
    return Path.home() / ".cache" / "nebula" / "previous_version.json"


# Pip install timeout. Long enough for a cold cache over a slow link;
# short enough that a stuck install doesn't wedge the operator's
# terminal indefinitely.
PIP_TIMEOUT_SECONDS = 5 * 60


@dataclass
class UpgradeResult:
    """Outcome of an upgrade or rollback attempt."""

    action: str  # "upgrade" | "rollback" | "no_op" | "dry_run"
    ok: bool
    from_version: str | None
    to_version: str | None
    message: str
    pip_stdout: str = ""
    pip_stderr: str = ""

    def to_dict(self) -> dict:
        """JSON-serializable dict of this result."""
        return {
            "action": self.action,
            "ok": self.ok,
            "from_version": self.from_version,
            "to_version": self.to_version,
            "message": self.message,
            "pip_stdout": self.pip_stdout[-2000:] if self.pip_stdout else "",
            "pip_stderr": self.pip_stderr[-2000:] if self.pip_stderr else "",
        }


def _stamp_previous_version(previous: str) -> None:
    """Write the previous version to the rollback stamp file."""
    target = _previous_version_path()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                {
                    "previous_version": previous,
                    "stamped_at": datetime.now(timezone.utc).isoformat(),
                }
            ),
            encoding="utf-8",
        )
    except OSError as exc:
        logger.warning("could not stamp previous version: %s", exc)


def _read_previous_version() -> str | None:
    """Return the stamped previous version, or None if none is recorded."""
    target = _previous_version_path()
    if not target.is_file():
        return None
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    v = data.get("previous_version")
    return v if isinstance(v, str) and v else None


def _clear_previous_version() -> None:
    """Remove the rollback stamp. Used after a successful rollback so
    operators can't silently rollback twice to some ancient version
    they don't remember."""
    target = _previous_version_path()
    try:
        target.unlink(missing_ok=True)
    except OSError as exc:
        logger.debug("could not clear previous version stamp: %s", exc)


def _run_pip(args: list[str]) -> tuple[int, str, str]:
    """Run pip with bounded timeout, return (rc, stdout, stderr)."""
    # Extra args an operator can pass via env (e.g., --index-url,
    # --extra-index-url, --trusted-host). split with shlex so the
    # operator can include spaces correctly.
    extra = os.environ.get("NEBULA_PIP_ARGS", "").strip()
    extra_args = shlex.split(extra) if extra else []
    cmd = [sys.executable, "-m", "pip", "install", *extra_args, *args]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=PIP_TIMEOUT_SECONDS,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        return (
            124,
            exc.stdout or "",
            (exc.stderr or "") + f"\npip install timed out after {PIP_TIMEOUT_SECONDS}s",
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return (1, "", f"pip invocation failed: {exc}")
    return proc.returncode, proc.stdout or "", proc.stderr or ""


def _is_version_broken(version: str) -> tuple[bool, str]:
    """Check if ``version`` is in the local broken-versions list.

    The list lives at ``<repo>/data/broken_versions.txt`` — one
    version per line, # starts a comment, blank lines ignored.
    Missing file = no known-broken versions. This is a local file
    so operators can curate it; a future phase can fetch a
    maintainer-curated list via universal_http.

    Returns (is_broken, reason). ``reason`` carries an inline
    comment if the operator included one on the same line.
    """
    from pathlib import Path as _Path

    broken_file = _Path(__file__).resolve().parents[1] / "data" / "broken_versions.txt"
    if not broken_file.is_file():
        return False, ""
    try:
        content = broken_file.read_text(encoding="utf-8")
    except OSError:
        return False, ""
    target = version.strip()
    for raw_line in content.splitlines():
        # Split comment off but keep it as the reason.
        if "#" in raw_line:
            spec, _, comment = raw_line.partition("#")
            spec = spec.strip()
            comment = comment.strip()
        else:
            spec = raw_line.strip()
            comment = ""
        if not spec:
            continue
        if spec == target:
            return True, comment or "version listed as broken"
    return False, ""


def upgrade_to_latest(*, dry_run: bool = False, force: bool = False) -> UpgradeResult:
    """Upgrade zenon-nebula to the latest PyPI version.

    Args:
        dry_run: When True, show what would happen without invoking pip.
        force: When True, upgrade even if the target version is on
            the local broken-versions list. Use when the operator
            has verified the broken mark is stale or doesn't apply
            to their environment.

    Returns:
        UpgradeResult. Never raises — errors surface via ``ok=False``
        and a message.
    """
    status = check_for_update(force_refresh=True)

    if not status.update_available or status.latest_version is None:
        return UpgradeResult(
            action="no_op",
            ok=True,
            from_version=status.current_version,
            to_version=status.current_version,
            message=(
                f"Already on the latest version ({status.current_version}). Nothing to do."
                if status.latest_version
                else "Could not determine latest version. "
                "Check network / PyPI reachability; retry with "
                "NEBULA_SKIP_UPGRADE_CHECK=0 if the env var is set."
            ),
        )

    target_version = status.latest_version
    from_version = status.current_version

    # Task #50 follow-up: if the target is in the local broken
    # list, refuse the upgrade unless --force. Prevents blind
    # upgrades to a version the maintainer has already flagged.
    if not force:
        is_broken, reason = _is_version_broken(target_version)
        if is_broken:
            return UpgradeResult(
                action="refused",
                ok=False,
                from_version=from_version,
                to_version=target_version,
                message=(
                    f"Refusing to upgrade to {target_version}: "
                    f"listed as broken in data/broken_versions.txt"
                    + (f" ({reason})" if reason else "")
                    + ". Pass --force if the broken mark is stale."
                ),
            )

    if dry_run:
        return UpgradeResult(
            action="dry_run",
            ok=True,
            from_version=from_version,
            to_version=target_version,
            message=(
                f"Would run: pip install --upgrade "
                f"zenon-nebula=={target_version} "
                f"(current: {from_version})"
            ),
        )

    # Real upgrade.
    rc, stdout, stderr = _run_pip(["--upgrade", f"zenon-nebula=={target_version}"])
    if rc != 0:
        return UpgradeResult(
            action="upgrade",
            ok=False,
            from_version=from_version,
            to_version=target_version,
            message=f"pip install failed with exit code {rc}. See stderr below.",
            pip_stdout=stdout,
            pip_stderr=stderr,
        )

    _stamp_previous_version(from_version)
    return UpgradeResult(
        action="upgrade",
        ok=True,
        from_version=from_version,
        to_version=target_version,
        message=(
            f"Upgraded {from_version} -> {target_version}. "
            f"Rollback with `./nebula upgrade --rollback` while the "
            f"stamp at {_previous_version_path()} exists."
        ),
        pip_stdout=stdout,
        pip_stderr=stderr,
    )


def rollback_to_previous(*, dry_run: bool = False) -> UpgradeResult:
    """Pin zenon-nebula back to the version stamped at the last upgrade.

    Args:
        dry_run: When True, show what would happen without invoking pip.

    Returns:
        UpgradeResult. ``ok=False`` when no previous version is stamped
        or the pip call fails.
    """
    previous = _read_previous_version()
    if previous is None:
        return UpgradeResult(
            action="no_op",
            ok=False,
            from_version=None,
            to_version=None,
            message=(
                "No previous version stamped — nothing to roll back to. "
                f"Stamp lives at {_previous_version_path()}; it's only "
                f"written when `./nebula upgrade` succeeds."
            ),
        )

    try:
        from core.version import __version__ as current
    except Exception:
        current = "unknown"

    if dry_run:
        return UpgradeResult(
            action="dry_run",
            ok=True,
            from_version=current,
            to_version=previous,
            message=(f"Would run: pip install zenon-nebula=={previous} (current: {current})"),
        )

    rc, stdout, stderr = _run_pip([f"zenon-nebula=={previous}"])
    if rc != 0:
        return UpgradeResult(
            action="rollback",
            ok=False,
            from_version=current,
            to_version=previous,
            message=f"pip install failed with exit code {rc}. See stderr below.",
            pip_stdout=stdout,
            pip_stderr=stderr,
        )

    _clear_previous_version()
    return UpgradeResult(
        action="rollback",
        ok=True,
        from_version=current,
        to_version=previous,
        message=(
            f"Rolled back {current} -> {previous}. Stamp cleared; "
            f"re-run `./nebula upgrade` to advance again."
        ),
        pip_stdout=stdout,
        pip_stderr=stderr,
    )


def format_result(result: UpgradeResult) -> str:
    """Human-readable single-block output for the CLI."""
    lines = [
        f"Action:   {result.action}",
        f"Status:   {'ok' if result.ok else 'FAILED'}",
    ]
    if result.from_version:
        lines.append(f"From:     {result.from_version}")
    if result.to_version:
        lines.append(f"To:       {result.to_version}")
    lines.append("")
    lines.append(result.message)
    if not result.ok and result.pip_stderr:
        lines.append("")
        lines.append("pip stderr (tail):")
        lines.append(result.pip_stderr[-1000:])
    return "\n".join(lines)
