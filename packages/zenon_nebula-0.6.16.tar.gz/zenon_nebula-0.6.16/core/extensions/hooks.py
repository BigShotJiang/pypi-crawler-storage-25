# SPDX-License-Identifier: MIT
"""Lifecycle hooks — subscribe user code to Nebula events.

Operators can register Python callables that fire at specific points
in Nebula's autonomous cycle. This replaces the fragile pattern of
forking ``scripts/autonomous.py`` to add custom logic.

**Supported events:**

- ``pre_cycle`` — before each autonomous cycle starts.
- ``post_cycle`` — after each cycle completes (receives cycle summary).
- ``pre_finding`` — before a finding is persisted (can modify or veto).
- ``post_finding`` — after a finding is persisted (read-only).
- ``on_collision`` — when a cross-domain collision fires.
- ``on_battle_plan`` — when the war room produces a new plan.

**Registration:**

From user domain code or a startup script::

    from core.extensions.hooks import on

    @on("post_finding")
    def my_handler(finding: dict) -> None:
        # Log to an external system, enrich the finding, etc.
        ...

Or imperatively::

    from core.extensions.hooks import register

    register("pre_cycle", my_callable)

**Contract:**

- Hooks run synchronously in registration order. A slow hook blocks
  the cycle — operators own the performance consequences.
- Hooks that raise are caught, logged, and skipped. One broken hook
  never crashes the scheduler.
- ``pre_finding`` hooks can return ``None`` to veto the finding (it
  won't be persisted). Return the (possibly modified) dict to proceed.
- All other hooks' return values are ignored.
- Hooks are NOT serialized, exported, or shared with peers. They're
  local runtime extensions.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)

VALID_EVENTS = frozenset(
    {
        "pre_cycle",
        "post_cycle",
        "pre_finding",
        "post_finding",
        "on_collision",
        "on_battle_plan",
    }
)

_hooks: dict[str, list[Callable]] = defaultdict(list)


def register(event: str, handler: Callable) -> None:
    """Register a handler for a lifecycle event.

    Args:
        event: One of :data:`VALID_EVENTS`.
        handler: A callable. Signature depends on the event.

    Raises:
        ValueError: If ``event`` is not a recognized lifecycle event.
    """
    if event not in VALID_EVENTS:
        raise ValueError(
            f"Unknown hook event '{event}'. Valid events: {', '.join(sorted(VALID_EVENTS))}"
        )
    _hooks[event].append(handler)
    logger.debug("Hook registered: %s → %s", event, getattr(handler, "__name__", repr(handler)))


def on(event: str) -> Callable:
    """Decorator form of :func:`register`.

    Usage::

        @on("post_cycle")
        def log_cycle(summary: dict) -> None:
            print(summary)
    """

    def decorator(fn: Callable) -> Callable:
        """Register ``fn`` as a handler for the event."""
        register(event, fn)
        return fn

    return decorator


def fire(event: str, **kwargs: Any) -> Any:
    """Fire all handlers for an event.

    For ``pre_finding``, the first handler that returns ``None`` vetoes
    the finding — subsequent handlers are skipped and ``fire`` returns
    ``None``. If all handlers return a dict (or there are no handlers),
    ``fire`` returns the (possibly modified) finding dict.

    For all other events, handlers run in order and return values are
    ignored. ``fire`` returns ``None``.

    Never raises. Handler exceptions are logged and swallowed.
    """
    handlers = _hooks.get(event, [])
    if not handlers:
        return kwargs.get("finding") if event == "pre_finding" else None

    if event == "pre_finding":
        finding = kwargs.get("finding")
        for h in handlers:
            try:
                result = h(finding)
            except Exception as exc:
                logger.warning("Hook %s raised in %s: %s", event, _name(h), exc)
                continue
            if result is None:
                logger.info("Finding vetoed by hook %s", _name(h))
                return None
            finding = result
        return finding

    for h in handlers:
        try:
            h(**kwargs)
        except Exception as exc:
            logger.warning("Hook %s raised in %s: %s", event, _name(h), exc)


def get_hooks(event: str) -> list[Callable]:
    """Return the registered handlers for an event (read-only copy)."""
    return list(_hooks.get(event, []))


def clear(event: str | None = None) -> None:
    """Remove all handlers, or handlers for a specific event.

    Primarily for tests. Production code should not need to clear hooks
    — they're registered once at boot and live for the session.
    """
    if event is None:
        _hooks.clear()
    else:
        _hooks.pop(event, None)


def _name(handler: Callable) -> str:
    return getattr(handler, "__name__", repr(handler))
