# SPDX-License-Identifier: MIT
"""LLMProvider ABC + registry — swappable LLM backends.

Nebula's built-in `core.llm_provider.call_llm` is hardcoded to xAI
Grok. This module introduces an abstract ``LLMProvider`` contract
and a simple registry so operators — or third-party entry-point
plugins — can register alternative providers (Anthropic, OpenAI,
local Ollama, etc.) without editing shipped code.

**Scope of this module:**

- Defines :class:`LLMProvider` ABC.
- Defines :class:`LLMResponse` as the canonical return type.
- Ships an :class:`XAIProvider` reference implementation that wraps
  the existing ``call_llm`` machinery.
- Exposes ``register_provider`` / ``get_provider`` / ``list_providers``
  for plugin registration.
- Loads the active provider from ``~/.config/nebula/llm.toml``
  (``[llm] provider = "xai"``), falling back to xAI when the file is
  absent or malformed.

**What this module does NOT do:**

- It does NOT rewire the existing ``call_llm`` function. Existing
  callers (every engine that imports ``call_llm``) keep the exact
  behavior they have today. Future work can migrate callers to the
  ABC incrementally.
- It does NOT ship Anthropic / OpenAI / Ollama implementations.
  Those are expected to arrive as third-party entry-point plugins
  (group ``zenon_nebula.llm_providers``).

Part of task #62 anti-fork G2.
"""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class LLMResponse:
    """Canonical LLM response shape.

    Providers fill in what they know. ``cost_usd`` should be best-
    effort — local providers can report 0.0; paid APIs should
    compute from token counts.
    """

    text: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    provider: str = ""
    cached: bool = False
    extra: dict[str, Any] = field(default_factory=dict)


class LLMProvider(ABC):
    """Abstract LLM backend.

    Subclasses must implement :meth:`call`, :meth:`list_models`,
    :meth:`default_best`, and :meth:`default_cheapest`. The :attr:`name`
    class attribute must be unique across registered providers.
    """

    name: str = ""

    @abstractmethod
    def call(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str | None = None,
        max_tokens: int = 4000,
        temperature: float = 1.0,
        json_output: bool = False,
    ) -> LLMResponse | None:
        """Invoke the LLM. Return an :class:`LLMResponse` or ``None`` on failure.

        Implementations MUST honor OPSEC — sanitize prompts via
        ``core.opsec.OPSECGuard.sanitize_prompt`` before sending
        anything over the wire.
        """

    @abstractmethod
    def list_models(self) -> list[str]:
        """Return the model IDs this provider can route to."""

    @abstractmethod
    def default_best(self) -> str:
        """Return the provider's current best/flagship model ID."""

    @abstractmethod
    def default_cheapest(self) -> str:
        """Return the provider's cheapest usable model ID."""


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_providers: dict[str, LLMProvider] = {}


def register_provider(provider: LLMProvider) -> None:
    """Register an LLM provider. Later registrations REPLACE earlier ones
    with the same name — this allows operators to override built-ins.

    Raises :class:`ValueError` if ``provider.name`` is empty.
    """
    if not provider.name:
        raise ValueError("LLMProvider.name must be non-empty")
    previous = _providers.get(provider.name)
    _providers[provider.name] = provider
    if previous is not None:
        logger.info("LLM provider '%s' replaced (was %r)", provider.name, type(previous).__name__)
    else:
        logger.debug("LLM provider '%s' registered", provider.name)


def get_provider(name: str) -> LLMProvider | None:
    """Return a registered provider by name, or ``None`` if not found."""
    return _providers.get(name)


def list_providers() -> list[str]:
    """Return the names of all registered providers."""
    return sorted(_providers.keys())


def clear_registry() -> None:
    """Wipe the registry. Primarily for tests."""
    _providers.clear()


# ---------------------------------------------------------------------------
# Active-provider resolution
# ---------------------------------------------------------------------------


def resolve_llm_config_path() -> Path:
    """Return the path to the operator's LLM config file."""
    explicit = os.environ.get("NEBULA_LLM_CONFIG_PATH", "").strip()
    if explicit:
        return Path(explicit).expanduser()
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        return Path(xdg).expanduser() / "nebula" / "llm.toml"
    return Path.home() / ".config" / "nebula" / "llm.toml"


def load_active_provider_name(path: Path | None = None) -> str:
    """Parse ``~/.config/nebula/llm.toml`` and return the selected
    provider name. Defaults to ``"xai"`` when no file or the file
    doesn't specify.
    """
    resolved = path if path is not None else resolve_llm_config_path()
    if not resolved.is_file():
        return "xai"
    try:
        raw = resolved.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return "xai"
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            return "xai"
    try:
        data = tomllib.loads(raw)
    except Exception:
        return "xai"
    llm = data.get("llm", {})
    if isinstance(llm, dict):
        name = llm.get("provider", "xai")
        if isinstance(name, str) and name.strip():
            return name.strip()
    return "xai"


def get_active_provider() -> LLMProvider | None:
    """Return the currently-selected provider, or ``None`` if the
    configured provider isn't registered.

    Resolution:
    1. Name from ``~/.config/nebula/llm.toml`` ``[llm] provider``.
    2. Falls back to ``"xai"`` when the file is missing.
    3. Returns the registered provider with that name, or ``None``.
    """
    name = load_active_provider_name()
    provider = get_provider(name)
    if provider is None:
        logger.warning(
            "Configured LLM provider '%s' is not registered. Registered: %s",
            name,
            list_providers() or "(none)",
        )
    return provider


# ---------------------------------------------------------------------------
# Reference xAI implementation (wraps the existing call_llm)
# ---------------------------------------------------------------------------


class XAIProvider(LLMProvider):
    """Reference implementation that delegates to ``core.llm_provider.call_llm``.

    This keeps the existing xAI code path — with its caching, circuit
    breaker, cost tracking, retries, and OPSEC — as the authoritative
    xAI implementation. The ABC wrapper is a thin translation to/from
    :class:`LLMResponse`.
    """

    name = "xai"

    def call(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str | None = None,
        max_tokens: int = 4000,
        temperature: float = 1.0,
        json_output: bool = False,
    ) -> LLMResponse | None:
        """Dispatch to ``core.llm_provider.call_llm`` and adapt the return shape."""
        from core.llm_provider import call_llm

        result = call_llm(
            prompt=prompt,
            system=system,
            model=model or "auto",
            max_tokens=max_tokens,
            temperature=temperature,
            json_output=json_output,
        )
        if result is None:
            return None
        return LLMResponse(
            text=result.get("text", ""),
            model=result.get("model", "unknown"),
            input_tokens=result.get("input_tokens", 0),
            output_tokens=result.get("output_tokens", 0),
            cost_usd=result.get("cost_usd", 0.0),
            provider="xai",
            cached=bool(result.get("cached", False)),
            extra={
                k: v
                for k, v in result.items()
                if k
                not in {
                    "text",
                    "model",
                    "input_tokens",
                    "output_tokens",
                    "cost_usd",
                    "cached",
                }
            },
        )

    def list_models(self) -> list[str]:
        """Return xAI models known to ``MODEL_PRICING``."""
        from core.llm_provider import MODEL_PRICING

        return sorted(MODEL_PRICING.keys())

    def default_best(self) -> str:
        """Return xAI's current flagship model."""
        from core.llm_provider import DEFAULT_BEST

        return DEFAULT_BEST

    def default_cheapest(self) -> str:
        """Return xAI's cheapest usable model."""
        from core.llm_provider import DEFAULT_CHEAPEST

        return DEFAULT_CHEAPEST


# Register the xAI provider by default so `get_active_provider()` works
# out of the box.
register_provider(XAIProvider())
