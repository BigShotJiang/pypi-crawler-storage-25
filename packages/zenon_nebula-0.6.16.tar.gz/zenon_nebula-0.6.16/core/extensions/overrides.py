# SPDX-License-Identifier: MIT
"""Engine overrides — disable or reprioritize shipped engines without forking.

Operators who ``pip install zenon-nebula`` get 86+ engines out of the
box. Not all are relevant to every workspace. Rather than forking to
comment out an engine's registration, operators drop an
``overrides.toml`` file:

::

    # ~/.config/nebula/overrides.toml

    [engines.disable]
    # Turn off engines that aren't useful for my workspace.
    # Keys are engine names; values are a short reason (for audit trail).
    whale_watcher = "no DEX liquidity to watch on my testnet"
    hype_detector = "noise for a research-only deployment"

    [engines.priority]
    # Shift engine priorities. Lower number = higher priority.
    # Only overrides the engine's default; doesn't override domain priority.
    adversarial_reviewer = 3
    spec_tracker = 2

Path resolution (first match wins):

1. ``$NEBULA_OVERRIDES_PATH`` — explicit override (tests, multi-instance).
2. ``$XDG_CONFIG_HOME/nebula/overrides.toml`` — XDG-spec compliant.
3. ``$HOME/.config/nebula/overrides.toml`` — POSIX default.

The module exposes two functions consumed by ``DomainRegistry``:

- :func:`load_overrides` — parse the TOML file, return an
  :class:`EngineOverrides` dataclass.
- :func:`apply_overrides` — mutate an ``EngineDefinition`` list in
  place: disable engines listed in ``[engines.disable]``, reprioritize
  engines listed in ``[engines.priority]``.

**Safety:** overrides are logged at startup so the operator can audit
why an engine isn't firing. A typo in an engine name (disabling a
non-existent engine) is surfaced as a warning, not silently ignored.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class EngineOverrides:
    """Parsed operator overrides."""

    disabled: dict[str, str] = field(default_factory=dict)
    priorities: dict[str, int] = field(default_factory=dict)
    path: Path | None = None
    warnings: list[str] = field(default_factory=list)


def resolve_overrides_path() -> Path:
    """Return the overrides file path per the three-layer lookup."""
    explicit = os.environ.get("NEBULA_OVERRIDES_PATH", "").strip()
    if explicit:
        return Path(explicit).expanduser()
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        return Path(xdg).expanduser() / "nebula" / "overrides.toml"
    return Path.home() / ".config" / "nebula" / "overrides.toml"


def load_overrides(path: Path | None = None) -> EngineOverrides:
    """Parse the overrides TOML file. Return empty overrides when absent.

    Never raises on malformed input — warnings are recorded on the
    returned :class:`EngineOverrides` so the caller can surface them
    without crashing the startup sequence.
    """
    resolved = path if path is not None else resolve_overrides_path()
    result = EngineOverrides(path=resolved)

    if not resolved.is_file():
        return result

    try:
        raw = resolved.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        result.warnings.append(f"read failed: {type(exc).__name__}")
        return result

    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            result.warnings.append("no TOML parser available (need Python 3.11+ or tomli)")
            return result

    try:
        data = tomllib.loads(raw)
    except Exception as exc:
        result.warnings.append(f"TOML parse error: {exc}")
        return result

    engines = data.get("engines", {})
    if not isinstance(engines, dict):
        result.warnings.append("[engines] must be a table")
        return result

    disable_raw = engines.get("disable", {})
    if isinstance(disable_raw, dict):
        for name, reason in disable_raw.items():
            result.disabled[str(name)] = str(reason) if reason else ""
    elif disable_raw:
        result.warnings.append("[engines.disable] must be a table of name = reason")

    priority_raw = engines.get("priority", {})
    if isinstance(priority_raw, dict):
        for name, val in priority_raw.items():
            if isinstance(val, int):
                result.priorities[str(name)] = val
            else:
                result.warnings.append(
                    f"[engines.priority] {name}: expected int, got {type(val).__name__}"
                )
    elif priority_raw:
        result.warnings.append("[engines.priority] must be a table of name = int")

    return result


def apply_overrides(engines: list, overrides: EngineOverrides) -> None:
    """Mutate a list of ``EngineDefinition`` in place.

    - Engines in ``overrides.disabled`` get ``enabled = False``.
    - Engines in ``overrides.priorities`` get their ``priority`` field
      replaced.

    Logs a warning for override entries that don't match any engine —
    likely typos or stale config.
    """
    engine_names = {e.name for e in engines}

    for name, reason in overrides.disabled.items():
        if name not in engine_names:
            logger.warning(
                "overrides: [engines.disable] '%s' doesn't match any registered engine (typo?)",
                name,
            )
            overrides.warnings.append(f"disable: unknown engine '{name}'")
            continue
        for e in engines:
            if e.name == name:
                e.enabled = False
                logger.info("overrides: disabled engine '%s' — %s", name, reason or "(no reason)")

    for name, prio in overrides.priorities.items():
        if name not in engine_names:
            logger.warning(
                "overrides: [engines.priority] '%s' doesn't match any registered engine (typo?)",
                name,
            )
            overrides.warnings.append(f"priority: unknown engine '{name}'")
            continue
        for e in engines:
            if e.name == name:
                old = e.priority
                e.priority = prio
                logger.info("overrides: reprioritized '%s' from %d to %d", name, old, prio)
