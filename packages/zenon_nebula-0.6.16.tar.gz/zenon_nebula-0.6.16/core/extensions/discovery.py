# SPDX-License-Identifier: MIT
"""User domain discovery — register operator-supplied domains at boot.

Operators who want Nebula to run custom analysis domains can drop
a ``domain.py`` file under ``~/.config/nebula/domains/<name>/`` and
it will be auto-discovered and registered into the same
``DomainRegistry`` as the shipped domains. No fork required.

Layout::

    ~/.config/nebula/domains/
      my_custom/
        domain.py        # DomainPlugin subclass (required)
        engines/
          my_engine.py   # entry-point function (optional, same contract as shipped engines)
        __init__.py      # can be empty

The loader walks the directory, imports ``<name>.domain`` (adding the
user-domains root to ``sys.path`` temporarily), and instantiates the
first class that exposes ``get_engines``. Same discovery logic as the
shipped ``_register_domains`` in ``scripts/autonomous.py`` — the only
difference is the root directory.

Path resolution (first match wins):

1. ``$NEBULA_USER_DOMAINS_PATH`` — explicit override (tests, multi-instance).
2. ``$XDG_CONFIG_HOME/nebula/domains/`` — XDG-spec compliant.
3. ``$HOME/.config/nebula/domains/`` — POSIX default.

**Trust:** user domains run with the same privileges as shipped
engines. Nebula does NOT sandbox them — the operator installed the
code, the operator trusts it. Findings from user domains carry the
same confidence ceilings as shipped engines (capped by the trust
model, not by origin).

**OPSEC:** user domain code is never exported to peers or included
in snapshots. The operator's custom analysis stays local unless they
explicitly publish it.
"""

from __future__ import annotations

import importlib
import logging
import os
import sys
from pathlib import Path

from core.domain_registry import DomainRegistry

logger = logging.getLogger(__name__)


def resolve_user_domains_path() -> Path:
    """Return the user-domains root directory."""
    explicit = os.environ.get("NEBULA_USER_DOMAINS_PATH", "").strip()
    if explicit:
        return Path(explicit).expanduser()
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        return Path(xdg).expanduser() / "nebula" / "domains"
    return Path.home() / ".config" / "nebula" / "domains"


def discover_user_domains(
    registry: DomainRegistry,
    path: Path | None = None,
) -> dict:
    """Walk the user-domains directory and register valid plugins.

    Returns a summary dict::

        {
            "path": str,
            "registered": int,
            "failed": int,
            "skipped": list[str],  # reasons for non-imports
        }

    Never raises. Import errors are logged and counted as failures.
    """
    root = path if path is not None else resolve_user_domains_path()
    summary: dict = {
        "path": str(root),
        "registered": 0,
        "failed": 0,
        "skipped": [],
    }

    if not root.is_dir():
        summary["skipped"].append(f"{root} does not exist")
        return summary

    # Temporarily add root to sys.path so user modules can be imported
    # as top-level packages. Remove after discovery to avoid polluting
    # the namespace for the rest of the session.
    root_str = str(root)
    path_added = root_str not in sys.path
    if path_added:
        sys.path.insert(0, root_str)

    try:
        for domain_dir in sorted(root.iterdir()):
            if not domain_dir.is_dir() or domain_dir.name.startswith(("_", ".")):
                continue
            domain_py = domain_dir / "domain.py"
            if not domain_py.exists():
                summary["skipped"].append(f"{domain_dir.name}: no domain.py")
                continue

            try:
                mod = importlib.import_module(f"{domain_dir.name}.domain")
                found = False
                for attr_name in dir(mod):
                    attr = getattr(mod, attr_name)
                    if (
                        isinstance(attr, type)
                        and hasattr(attr, "get_engines")
                        and attr_name not in ("DomainPlugin", "ABC")
                    ):
                        try:
                            instance = attr()
                            registry.register(instance)
                            summary["registered"] += 1
                            logger.info(
                                "User domain registered: %s (%d engines)",
                                instance.name(),
                                len(instance.get_engines()),
                            )
                            found = True
                            break
                        except ValueError as ve:
                            summary["skipped"].append(f"{domain_dir.name}: {ve}")
                            break
                        except Exception as inner:
                            summary["failed"] += 1
                            logger.warning(
                                "User domain %s/%s instantiation failed: %s",
                                domain_dir.name,
                                attr_name,
                                inner,
                            )
                            break
                if not found and not summary["skipped"]:
                    summary["skipped"].append(f"{domain_dir.name}: no DomainPlugin subclass")
            except Exception as exc:
                summary["failed"] += 1
                logger.warning("User domain %s import failed: %s", domain_dir.name, exc)
    finally:
        if path_added and root_str in sys.path:
            sys.path.remove(root_str)

    return summary
