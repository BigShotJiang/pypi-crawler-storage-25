# SPDX-License-Identifier: MIT
"""Entry-point discovery — register third-party Nebula plugins from PyPI.

Third parties can publish PyPI packages that extend Nebula by declaring
entry points in their ``pyproject.toml``::

    [project.entry-points."zenon_nebula.plugins"]
    my_cool_domain = "my_package.nebula_plugin:MyCoolDomain"

When the operator ``pip install my-package``, Nebula discovers the
plugin via :func:`importlib.metadata.entry_points` at boot and
registers it into the same ``DomainRegistry`` as shipped domains.

**Groups recognized:**

- ``zenon_nebula.plugins`` — domain plugin classes (DomainPlugin subclass)
- ``zenon_nebula.hooks`` — lifecycle hook registration callables that
  run once at boot with no arguments; they register hooks via
  ``core.extensions.hooks.register``.

**Trust contract:**

Entry-point plugins are loaded with the same privileges as core
engines — no sandboxing. The operator installed the package; the
operator trusts it. Findings from entry-point plugins carry the same
confidence ceilings as shipped engines.

**Path order:**

1. Shipped domains (``domains/*``)
2. User domains (``~/.config/nebula/domains/*``)
3. Entry-point plugins (this module)
4. Overrides applied after all three

This order means: a pip-installed plugin cannot replace a shipped
domain with the same name (duplicate-name detection fires); user
directory plugins take precedence over pip plugins with identical
names only in the order the loader runs.

Part of task #62 anti-fork G2.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from core.domain_registry import DomainRegistry

logger = logging.getLogger(__name__)

PLUGIN_GROUP = "zenon_nebula.plugins"
HOOK_GROUP = "zenon_nebula.hooks"


@dataclass
class EntryPointResult:
    """Summary of entry-point discovery."""

    plugins_registered: int = 0
    plugins_failed: int = 0
    hooks_registered: int = 0
    hooks_failed: int = 0
    skipped: list[str] = field(default_factory=list)


def _iter_entry_points(group: str):
    """Return entry points for ``group``. Tolerates both 3.10+ and older APIs.

    Returns an empty iterable when importlib.metadata is unavailable
    (which shouldn't happen on any supported Python, but we degrade
    gracefully anyway).
    """
    try:
        from importlib.metadata import entry_points
    except ImportError:
        return []
    try:
        eps = entry_points(group=group)
    except TypeError:
        # Python 3.9: entry_points() returns a dict, not a filterable object.
        eps = entry_points().get(group, [])
    return eps


def discover_entry_point_plugins(registry: DomainRegistry) -> EntryPointResult:
    """Walk the ``zenon_nebula.plugins`` + ``zenon_nebula.hooks`` entry-point
    groups and register whatever they expose.

    Plugins: each entry point must resolve to a ``DomainPlugin`` subclass
    (or an instance). The loader instantiates and registers it.

    Hooks: each entry point must resolve to a callable taking no arguments.
    The loader calls it once; the callable is expected to register hooks
    via ``core.extensions.hooks.register``.

    Never raises. Per-plugin failures are logged and counted.
    """
    result = EntryPointResult()

    for ep in _iter_entry_points(PLUGIN_GROUP):
        try:
            target = ep.load()
        except Exception as exc:
            result.plugins_failed += 1
            logger.warning("Entry-point plugin %s load failed: %s", ep.name, exc)
            continue

        try:
            instance = target() if isinstance(target, type) else target
            registry.register(instance)
            result.plugins_registered += 1
            logger.info(
                "Entry-point plugin registered: %s (%d engines)",
                instance.name(),
                len(instance.get_engines()),
            )
        except ValueError as ve:
            # Likely duplicate-name registration. Skip + note.
            result.skipped.append(f"{ep.name}: {ve}")
        except Exception as exc:
            result.plugins_failed += 1
            logger.warning("Entry-point plugin %s instantiation/register failed: %s", ep.name, exc)

    for ep in _iter_entry_points(HOOK_GROUP):
        try:
            target = ep.load()
        except Exception as exc:
            result.hooks_failed += 1
            logger.warning("Entry-point hook %s load failed: %s", ep.name, exc)
            continue

        if not callable(target):
            result.hooks_failed += 1
            logger.warning("Entry-point hook %s is not callable", ep.name)
            continue

        try:
            target()
            result.hooks_registered += 1
            logger.info("Entry-point hook invoked: %s", ep.name)
        except Exception as exc:
            result.hooks_failed += 1
            logger.warning("Entry-point hook %s invocation failed: %s", ep.name, exc)

    return result
