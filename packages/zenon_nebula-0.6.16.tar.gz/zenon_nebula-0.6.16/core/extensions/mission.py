# SPDX-License-Identifier: MIT
"""Mission overrides — operator-declared pillar weight adjustments.

Nebula ships a default 6-pillar mission (see ``core/mission/definition.py``)
with weights tuned for the Zenon protocol's trajectory. Different
operators running Nebula against different forks, extension chains,
or research angles may want different pillar weightings without
touching code.

File: ``~/.config/nebula/mission.toml``::

    [mission.weights]
    # Override pillar weights. Keys must be pillar "key" values from PILLARS.
    # Missing pillars keep their default weight. If you provide any
    # override, the full weight set is re-normalized to sum to 1.0 so
    # mission_alignment scoring stays on the same scale.
    technical_excellence = 0.40
    security = 0.30
    ecosystem_expansion = 0.10

    [mission.pillars.disable]
    # Optionally disable entire pillars for this operator. The disabled
    # pillar's weight is redistributed proportionally across the rest.
    # Useful when the pillar doesn't apply to the operator's fork.
    # ecosystem_expansion = "running a research-only testnet"

Path resolution (first match wins):

1. ``$NEBULA_MISSION_PATH`` — explicit override (tests, multi-instance).
2. ``$XDG_CONFIG_HOME/nebula/mission.toml`` — XDG-spec compliant.
3. ``$HOME/.config/nebula/mission.toml`` — POSIX default.

**Safety:**

- Unknown pillar keys are flagged as warnings — typos don't silently
  reweight the wrong pillar.
- Weights are re-normalized to sum to 1.0 after override. The operator
  provides relative weights; the module handles the math.
- Never raises on malformed input. Warnings surface on the returned
  :class:`MissionOverrides` so callers can log them.

Part of task #62 anti-fork G2.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class MissionOverrides:
    """Parsed operator mission overrides."""

    weights: dict[str, float] = field(default_factory=dict)
    disabled: dict[str, str] = field(default_factory=dict)
    path: Path | None = None
    warnings: list[str] = field(default_factory=list)

    def is_empty(self) -> bool:
        """True when no overrides are present."""
        return not self.weights and not self.disabled


def resolve_mission_path() -> Path:
    """Return the mission overrides file path per the three-layer lookup."""
    explicit = os.environ.get("NEBULA_MISSION_PATH", "").strip()
    if explicit:
        return Path(explicit).expanduser()
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        return Path(xdg).expanduser() / "nebula" / "mission.toml"
    return Path.home() / ".config" / "nebula" / "mission.toml"


def load_mission_overrides(path: Path | None = None) -> MissionOverrides:
    """Parse the mission overrides TOML file.

    Returns an empty :class:`MissionOverrides` when the file doesn't
    exist or can't be read. Never raises — malformed input produces
    warnings instead.
    """
    resolved = path if path is not None else resolve_mission_path()
    result = MissionOverrides(path=resolved)

    if not resolved.is_file():
        return result

    try:
        raw = resolved.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        result.warnings.append(f"read failed: {type(exc).__name__}")
        return result

    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            result.warnings.append("no TOML parser available")
            return result

    try:
        data = tomllib.loads(raw)
    except Exception as exc:
        result.warnings.append(f"TOML parse error: {exc}")
        return result

    mission = data.get("mission", {})
    if not isinstance(mission, dict):
        result.warnings.append("[mission] must be a table")
        return result

    weights_raw = mission.get("weights", {})
    if isinstance(weights_raw, dict):
        for key, val in weights_raw.items():
            if isinstance(val, (int, float)) and val >= 0:
                result.weights[str(key)] = float(val)
            else:
                result.warnings.append(
                    f"[mission.weights] {key}: expected non-negative number, got {val!r}"
                )
    elif weights_raw:
        result.warnings.append("[mission.weights] must be a table")

    pillars_raw = mission.get("pillars", {})
    if isinstance(pillars_raw, dict):
        disable_raw = pillars_raw.get("disable", {})
        if isinstance(disable_raw, dict):
            for key, reason in disable_raw.items():
                result.disabled[str(key)] = str(reason) if reason else ""

    return result


def apply_mission_overrides(mission: dict, overrides: MissionOverrides) -> dict:
    """Apply overrides to a mission dict (from ``get_active_mission``).

    Returns a new dict; the input is not mutated. The ``pillars``
    list has its ``weight`` field updated per the overrides, disabled
    pillars are filtered out, and the remaining weights re-normalize
    to sum to 1.0.

    Unknown pillar keys in the overrides are recorded as warnings.
    """
    if overrides.is_empty():
        return mission

    pillars = mission.get("pillars", [])
    if not isinstance(pillars, list) or not pillars:
        return mission

    known_keys = {p.get("name") or p.get("key") for p in pillars}

    # Report unknown keys.
    for name in overrides.weights:
        if name not in known_keys:
            overrides.warnings.append(f"weights: unknown pillar '{name}'")
    for name in overrides.disabled:
        if name not in known_keys:
            overrides.warnings.append(f"disable: unknown pillar '{name}'")

    new_pillars = []
    for p in pillars:
        name = p.get("name") or p.get("key")
        if name in overrides.disabled:
            continue
        new_p = dict(p)
        if name in overrides.weights:
            new_p["weight"] = overrides.weights[name]
        new_pillars.append(new_p)

    total = sum(p.get("weight", 0.0) for p in new_pillars)
    if total > 0:
        for p in new_pillars:
            p["weight"] = p.get("weight", 0.0) / total
            p["priority"] = round(p["weight"] * 10) or 1

    result = dict(mission)
    result["pillars"] = new_pillars
    result["overrides_applied"] = True
    return result
