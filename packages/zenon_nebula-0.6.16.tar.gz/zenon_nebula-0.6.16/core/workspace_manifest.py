# SPDX-License-Identifier: MIT
"""Workspace manifest loader + bootstrap helpers.

v0.6.10 — closes the onboarding gap where ``pip install
zenon-nebula`` leaves new operators with an empty workspace.
Nebula ships ``data/workspace-manifest.yaml`` as the canonical
list of Zenon repos a full workspace expects; this module loads
the manifest and supports ``./nebula workspace`` commands
(list / bootstrap / update / pin / add) that mirror the entries
onto disk under ``$ZENON_WORKSPACE_ROOT``.

Design:

- The manifest is the single source of truth. ``REPO_SIGNATURES``
  in ``core/workspace_discovery.py`` is for classification at
  scan time; this module is for the clone-time catalog.
- Loader is PyYAML-free: uses a tiny stdlib YAML subset parser
  so it works on a fresh ``pip install zenon-nebula`` without
  the optional extras. If PyYAML is available, it's preferred
  (more robust), but the stdlib fallback handles the canonical
  file shape we ship.
- Git operations route through ``subprocess`` with explicit
  timeouts — same discipline every other subprocess call in
  Nebula uses.
- The module is importable without a workspace on disk. Every
  path helper returns None rather than raising when the workspace
  is absent, matching ``core.workspace.workspace_root()``'s
  contract.
"""

from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from core.workspace import workspace_root

logger = logging.getLogger(__name__)


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MANIFEST_PATH = REPO_ROOT / "data" / "workspace-manifest.yaml"

# Sanctioned tiers. Unknown tiers are loaded with a warning but not
# rejected so a future manifest can add a tier without breaking old
# loaders.
KNOWN_TIERS = {"core", "sdk", "infra", "docs", "tooling", "reference"}


@dataclass
class ManifestEntry:
    """One repo the workspace expects.

    Fields mirror the YAML schema 1:1. Used by every workspace
    command (list, bootstrap, update, pin, add).
    """

    name: str
    tier: str
    path: str
    upstream: str
    fork: str | None
    signature: str
    depth: int
    required: bool
    description: str

    def clone_url(self, prefer_fork: bool = False) -> str:
        """Pick the URL to clone from.

        Default: upstream (canonical source of truth). Operators can
        opt into the ZenonOrg fork via ``--use-fork`` on bootstrap
        when they're actively contributing to the repo — that way
        their ``origin`` is the ZenonOrg fork they can push to.
        """
        if prefer_fork and self.fork:
            return self.fork
        return self.upstream

    def resolve_target(self, workspace: Path) -> Path:
        """Return the absolute path this entry should clone into."""
        return workspace / self.path


@dataclass
class Manifest:
    """Parsed workspace manifest.

    Represents a ``data/workspace-manifest.yaml`` file loaded into
    memory. Use ``load()`` to read from a path.
    """

    version: int
    updated: str
    repos: list[ManifestEntry] = field(default_factory=list)

    def by_name(self, name: str) -> ManifestEntry | None:
        """Return the entry with the given name, or None."""
        for repo in self.repos:
            if repo.name == name:
                return repo
        return None

    def by_tier(self, tier: str) -> list[ManifestEntry]:
        """Return every entry in the given tier."""
        return [r for r in self.repos if r.tier == tier]

    def required(self) -> list[ManifestEntry]:
        """Return every entry with required=true."""
        return [r for r in self.repos if r.required]


def load(path: Path | None = None) -> Manifest | None:
    """Load a workspace manifest from disk.

    Args:
        path: Manifest file path. Defaults to
            ``data/workspace-manifest.yaml`` inside the Nebula repo.

    Returns:
        Parsed ``Manifest`` or ``None`` if the file doesn't exist
        or parsing fails. Never raises — degraded state is
        expected when the manifest is missing on a fresh install.
    """
    manifest_path = path or DEFAULT_MANIFEST_PATH
    if not manifest_path.exists():
        logger.debug("workspace manifest not at %s", manifest_path)
        return None

    try:
        raw = manifest_path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning("could not read manifest %s: %s", manifest_path, exc)
        return None

    # Prefer PyYAML when present (handles full YAML spec). Fall back
    # to a tiny stdlib parser that handles the specific shape we ship.
    data = _parse_yaml(raw)
    if data is None:
        logger.warning("could not parse manifest %s", manifest_path)
        return None

    try:
        return _manifest_from_dict(data)
    except (KeyError, TypeError, ValueError) as exc:
        logger.warning("manifest %s has invalid schema: %s", manifest_path, exc)
        return None


def _parse_yaml(text: str) -> dict | None:
    """Parse YAML, preferring PyYAML and falling back to stdlib."""
    try:
        import yaml  # type: ignore[import-untyped]

        return yaml.safe_load(text)
    except ImportError:
        pass
    # Stdlib fallback — minimal YAML subset tailored to the shape
    # data/workspace-manifest.yaml ships in. Handles: top-level
    # key: value, lists of dicts under a key, scalar values, and
    # quoted strings. Doesn't handle anchors, aliases, flow
    # sequences, or complex types. Enough for our canonical file.
    return _stdlib_yaml_parse(text)


def _stdlib_yaml_parse(text: str) -> dict | None:
    """Parse the specific YAML shape data/workspace-manifest.yaml ships in.

    This is a deliberate minimal subset — not a general YAML
    parser. Handles top-level scalar keys, a ``repos:`` list of
    dicts, string/int/bool/null values, and simple quoted strings.
    Comments and blank lines are skipped. Indentation is assumed
    to be 2 spaces.
    """
    result: dict = {}
    current_list: list | None = None
    current_item: dict | None = None
    list_key: str | None = None

    for raw_line in text.splitlines():
        # Strip trailing comments + whitespace
        line = raw_line.rstrip()
        if not line or line.lstrip().startswith("#"):
            continue
        stripped = line.lstrip()
        indent = len(line) - len(stripped)

        # New list item under repos:
        if stripped.startswith("- ") and indent == 2:
            if current_item is not None and current_list is not None:
                current_list.append(current_item)
            current_item = {}
            # The "- name: value" first field
            after_dash = stripped[2:]
            if ":" in after_dash:
                key, _, value = after_dash.partition(":")
                current_item[key.strip()] = _coerce_scalar(value.strip())
            continue

        # Continuation field of a list item
        if current_item is not None and indent == 4 and ":" in stripped:
            key, _, value = stripped.partition(":")
            current_item[key.strip()] = _coerce_scalar(value.strip())
            continue

        # Top-level key: value
        if indent == 0 and ":" in stripped:
            key, _, value = stripped.partition(":")
            value = value.strip()
            if value:
                # Top-level scalar (version: 1, updated: 2026-04-11)
                result[key.strip()] = _coerce_scalar(value)
            else:
                # Start of a list (repos:)
                if current_item is not None and current_list is not None:
                    current_list.append(current_item)
                    current_item = None
                current_list = []
                list_key = key.strip()
                result[list_key] = current_list
            continue

    # Flush trailing item
    if current_item is not None and current_list is not None:
        current_list.append(current_item)

    return result


def _coerce_scalar(value: str):
    """Convert a YAML scalar string to a Python value."""
    if value in ("null", "~", ""):
        return None
    if value in ("true", "True", "yes"):
        return True
    if value in ("false", "False", "no"):
        return False
    if value.startswith('"') and value.endswith('"'):
        return value[1:-1]
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1]
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def _manifest_from_dict(data: dict) -> Manifest:
    """Build a Manifest from a parsed dict."""
    repos_raw = data.get("repos", [])
    repos: list[ManifestEntry] = []
    for raw in repos_raw:
        tier = raw.get("tier", "core")
        if tier not in KNOWN_TIERS:
            logger.warning("manifest entry %s uses unknown tier %r", raw.get("name"), tier)
        repos.append(
            ManifestEntry(
                name=str(raw["name"]),
                tier=str(tier),
                path=str(raw["path"]),
                upstream=str(raw["upstream"]),
                fork=str(raw["fork"]) if raw.get("fork") else None,
                signature=str(raw.get("signature", "")),
                depth=int(raw.get("depth", 50)),
                required=bool(raw.get("required", False)),
                description=str(raw.get("description", "")),
            )
        )
    return Manifest(
        version=int(data.get("version", 1)),
        updated=str(data.get("updated", "")),
        repos=repos,
    )


# ---------------------------------------------------------------------------
# Status + clone helpers
# ---------------------------------------------------------------------------


@dataclass
class RepoStatus:
    """Current status of a manifest entry on the operator's disk."""

    entry: ManifestEntry
    present: bool
    head_sha: str | None
    branch: str | None

    @property
    def state(self) -> str:
        """One-word state for CLI output."""
        return "cloned" if self.present else "missing"


def check_status(entry: ManifestEntry, workspace: Path) -> RepoStatus:
    """Inspect an entry's clone status on disk.

    Never raises. If the target path exists but isn't a git repo,
    or git commands fail, the status is still returned with
    ``present=False`` (treated as missing for bootstrap purposes).
    """
    target = entry.resolve_target(workspace)
    if not target.exists() or not (target / ".git").exists():
        return RepoStatus(entry=entry, present=False, head_sha=None, branch=None)

    head_sha = _git_command(target, ["rev-parse", "HEAD"])
    branch = _git_command(target, ["rev-parse", "--abbrev-ref", "HEAD"])
    return RepoStatus(
        entry=entry,
        present=True,
        head_sha=head_sha,
        branch=branch,
    )


def clone_entry(
    entry: ManifestEntry,
    workspace: Path,
    *,
    prefer_fork: bool = False,
    dry_run: bool = False,
) -> tuple[bool, str]:
    """Clone one manifest entry to its declared path.

    Returns ``(success, message)``. Safe to call when the clone
    already exists — returns ``(True, "already present")`` without
    re-running git. Never raises.

    Args:
        entry: Manifest entry to clone.
        workspace: Absolute path to ZENON_WORKSPACE_ROOT.
        prefer_fork: Use the ZenonOrg fork URL when available.
        dry_run: Don't actually run git. Returns the command that
            would have been run.
    """
    target = entry.resolve_target(workspace)
    if target.exists() and (target / ".git").exists():
        return True, f"{entry.name}: already present at {target}"

    # Ensure the parent directory exists
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return False, f"{entry.name}: could not create parent dir: {exc}"

    url = entry.clone_url(prefer_fork=prefer_fork)
    cmd = [
        "git",
        "clone",
        "--depth",
        str(entry.depth),
        url,
        str(target),
    ]

    if dry_run:
        return True, " ".join(cmd)

    try:
        result = subprocess.run(
            cmd,
            timeout=120,
            capture_output=True,
            text=True,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return False, f"{entry.name}: git clone timed out after 120s"
    except OSError as exc:
        return False, f"{entry.name}: git clone failed: {exc}"

    if result.returncode != 0:
        err = (result.stderr or result.stdout or "").strip()[-200:]
        return False, f"{entry.name}: git clone exit {result.returncode}: {err}"

    return True, f"{entry.name}: cloned {url} → {target}"


def _git_command(cwd: Path, args: list[str]) -> str | None:
    """Run a git command and return stripped stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            timeout=10,
            capture_output=True,
            text=True,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


# ---------------------------------------------------------------------------
# Public convenience
# ---------------------------------------------------------------------------


def get_workspace_root_or_warn() -> Path | None:
    """Return the workspace root or log a warning if absent."""
    root = workspace_root()
    if root is None:
        logger.warning(
            "ZENON_WORKSPACE_ROOT not set or invalid. "
            "Set it to the directory where Nebula should manage sibling repos."
        )
        return None
    return root
