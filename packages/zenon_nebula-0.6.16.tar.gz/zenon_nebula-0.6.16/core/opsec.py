# SPDX-License-Identifier: MIT
"""
OPSECGuard -- Identity sanitization for the Zenon Unified Engine.

Every external communication (LLM prompts, API calls, published content)
MUST pass through OPSECGuard before leaving the system. Ensures no
operator-identifying information ever leaks.

Generalized from the marketing domain's OPSECGuard to work across all domains.
"""

import logging
import os
import random
import re
import time

logger = logging.getLogger(__name__)

# Common, generic User-Agent strings rotated to avoid fingerprinting.
_GENERIC_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:125.0) Gecko/20100101 Firefox/125.0",
]


class OPSECGuard:
    """Enforces anonymity across all system operations.

    Static methods only -- no instance state, no configuration files that
    could themselves leak information.
    """

    # -- Sensitive patterns to detect and strip --
    # These protect ANY operator's identity, not just ours.
    SENSITIVE_PATTERNS: list[tuple[str, str]] = [
        # Local filesystem usernames (any OS)
        (r"/Users/\w+/", "/project/"),
        (r"/home/\w+/", "/project/"),
        (r"C:\\Users\\\w+\\", "C:\\\\project\\\\"),
        # Email addresses (ALL emails — no operator email should ever leak)
        (r"\b[\w.+-]+@[\w.-]+\.\w{2,}\b", "[REDACTED_EMAIL]"),
        # GitHub usernames in URLs (protect operator's GitHub identity)
        (
            r"github\.com/(?!zenon-network/|hypercore-one/|HyperCore-Team/|zenon-red/|zenonhub-io/|TminusZ/)\S+",
            "github.com/[REDACTED_USER]/",
        ),
        # Git author/committer names in log output
        (r"Author:\s*[^<]+<[^>]+>", "Author: [REDACTED] <[REDACTED]>"),
        (r"Committer:\s*[^<]+<[^>]+>", "Committer: [REDACTED] <[REDACTED]>"),
        # GitHub tokens
        (r"ghp_[a-zA-Z0-9]{36}", "[REDACTED_GH_TOKEN]"),
        (r"gho_[a-zA-Z0-9]{36}", "[REDACTED_GH_TOKEN]"),
        # API keys — OpenAI, xAI, Anthropic, generic Bearer tokens
        (r"sk-[a-zA-Z0-9]{20,}", "[REDACTED_API_KEY]"),
        (r"xai-[a-zA-Z0-9]{20,}", "[REDACTED_API_KEY]"),
        (r"sk-ant-[a-zA-Z0-9-]+", "[REDACTED_API_KEY]"),
        (r"Bearer\s+[a-zA-Z0-9._\-]{20,}", "Bearer [REDACTED_TOKEN]"),
        # AWS / GCP / Azure keys
        (r"AKIA[0-9A-Z]{16}", "[REDACTED_AWS_KEY]"),
        (r"AIza[0-9A-Za-z_-]{35}", "[REDACTED_GCP_KEY]"),
        # IP addresses (could reveal location)
        (r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "[REDACTED_IP]"),
        # Hostnames and machine names
        (r"\bhostname[=:]\s*\S+", "hostname=[REDACTED]"),
        (r"\bmachine[=:]\s*\S+", "machine=[REDACTED]"),
        # SSH keys
        (r"ssh-rsa\s+\S+", "[REDACTED_SSH_KEY]"),
        (r"ssh-ed25519\s+\S+", "[REDACTED_SSH_KEY]"),
        (r"ecdsa-sha2-nistp\d+\s+\S+", "[REDACTED_SSH_KEY]"),
        # Wallet private keys / seed phrases (critical). We MUST require a
        # contextual keyword here — a bare 64-char hex string is
        # indistinguishable from a SHA-256 checksum, a Zenon momentum hash,
        # a Bitcoin block hash, or a content hash. The old pattern was
        # r"\b[0-9a-fA-F]{64}\b" which mangled all of those. Engines now
        # reference hashes constantly in findings, so the pattern has to
        # be context-gated.
        (
            r"(private[_\s-]?key|priv[_\s-]?key|secret[_\s-]?key|seed[_\s-]?phrase)"
            r"[\s=:]+\b([0-9a-fA-F]{32,})\b",
            r"\1=[REDACTED_HEX_KEY]",
        ),
    ]

    # Pre-compiled patterns for performance
    _COMPILED_PATTERNS: list[tuple[re.Pattern, str]] = [
        (re.compile(pat, re.IGNORECASE), repl) for pat, repl in SENSITIVE_PATTERNS
    ]

    # Headers that must never appear in outbound HTTP requests
    _FORBIDDEN_HEADERS = frozenset(
        {
            "x-forwarded-for",
            "x-real-ip",
            "x-originating-ip",
            "referer",
            "referrer",
            "x-request-id",
            "x-correlation-id",
            "x-client-id",
        }
    )

    # -- Text sanitization --

    @staticmethod
    def sanitize_prompt(text: str) -> str:
        """Strip all identifying information from text before sending to LLM.

        Call this on EVERY user/system message before it enters an LLM API
        call. Idempotent -- safe to call multiple times.
        """
        if not text:
            return text

        sanitized = text
        for pattern, replacement in OPSECGuard._COMPILED_PATTERNS:
            sanitized = pattern.sub(replacement, sanitized)

        # Extra pass: strip any residual absolute paths that look local
        sanitized = re.sub(
            r"(?<![a-zA-Z0-9])/(?:Users|home|var|tmp)/[^\s\"']+",
            "/project/[REDACTED_PATH]",
            sanitized,
        )

        return sanitized

    # -- HTTP header sanitization --

    @staticmethod
    def sanitize_headers(headers: dict) -> dict:
        """Sanitize HTTP headers for external API calls.

        Replaces User-Agent with a generic browser string, removes
        Referer, X-Forwarded-For, and other identifying headers.
        """
        cleaned: dict[str, str] = {}
        for key, value in headers.items():
            if key.lower() in OPSECGuard._FORBIDDEN_HEADERS:
                logger.debug("OPSEC: stripped header %s", key)
                continue
            if key.lower() == "user-agent":
                cleaned[key] = OPSECGuard.generate_anonymous_user_agent()
                continue
            cleaned[key] = value

        if not any(k.lower() == "user-agent" for k in cleaned):
            cleaned["User-Agent"] = OPSECGuard.generate_anonymous_user_agent()

        return cleaned

    # -- Participant OPSEC for commons sharing --

    @staticmethod
    def sanitize_for_sharing(finding_text: str, participant_id: str = "anonymous") -> str:
        """Deep sanitize a finding before sharing with the community.

        Goes beyond sanitize_prompt — also strips:
        - The participant's own GitHub username
        - The participant's git author name
        - Machine-specific paths even if nested in JSON
        - Any string that looks like a private key or seed phrase
        - Timing data that could fingerprint the participant

        This runs on EVERY finding before it enters commons.
        """
        text = OPSECGuard.sanitize_prompt(finding_text)

        # Strip participant's own identity if they set one
        if participant_id and participant_id != "anonymous":
            text = re.sub(re.escape(participant_id), "[participant]", text, flags=re.IGNORECASE)

        # Strip git author patterns
        text = re.sub(r"author[=:]\s*\S+", "author=[participant]", text, flags=re.IGNORECASE)
        text = re.sub(r"committer[=:]\s*\S+", "committer=[participant]", text, flags=re.IGNORECASE)

        # Strip exact timestamps (could fingerprint timezone)
        text = re.sub(
            r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}",
            "[TIMESTAMP]",
            text,
        )

        # Strip local workspace paths even inside JSON strings
        text = re.sub(r"/[\w/]*(Repos|repos|workspace|projects)/[\w/]+", "/[WORKSPACE]", text)

        return text

    @staticmethod
    def audit_finding_safety(finding_text: str) -> dict:
        """Check if a finding is safe to share. Returns issues found.

        Run this before export. If issues > 0, don't share.
        """
        issues = []

        # Check for local paths
        if re.search(r"/Users/\w+/|/home/\w+/|C:\\Users\\", finding_text):
            issues.append("Contains local filesystem path")

        # Check for API keys
        if re.search(r"sk-[a-zA-Z0-9]{20}|xai-[a-zA-Z0-9]{20}|ghp_|gho_", finding_text):
            issues.append("Contains API key pattern")

        # Check for email addresses
        if re.search(r"\b[\w.+-]+@[\w.-]+\.\w{2,}\b", finding_text):
            issues.append("Contains email address")

        # Check for IP addresses
        if re.search(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", finding_text):
            issues.append("Contains IP address")

        # Check for private keys (64-char hex)
        if re.search(r"\b[0-9a-fA-F]{64}\b", finding_text):
            issues.append("Contains potential private key (64-char hex)")

        # Check for SSH keys
        if re.search(r"ssh-(rsa|ed25519)\s+", finding_text):
            issues.append("Contains SSH key")

        return {
            "safe": len(issues) == 0,
            "issues": issues,
        }

    # -- File metadata scrubbing --

    @staticmethod
    def sanitize_metadata(file_path: str) -> None:
        """Strip metadata from files before sharing externally.

        Handles EXIF data from images, author/creator from PDFs.
        Requires optional dependencies: Pillow for images, pikepdf for PDFs.
        Fails silently if dependencies are missing.
        """
        if not os.path.isfile(file_path):
            logger.warning("OPSEC: file not found for metadata scrub: %s", file_path)
            return

        ext = os.path.splitext(file_path)[1].lower()

        if ext in (".jpg", ".jpeg", ".png", ".tiff", ".tif"):
            OPSECGuard._strip_image_metadata(file_path)
        elif ext == ".pdf":
            OPSECGuard._strip_pdf_metadata(file_path)
        else:
            logger.debug("OPSEC: no metadata scrubber for extension %s", ext)

    @staticmethod
    def _strip_image_metadata(file_path: str) -> None:
        """Remove EXIF and other metadata from image files."""
        try:
            from PIL import Image

            img = Image.open(file_path)
            clean = Image.new(img.mode, img.size)
            clean.putdata(list(img.getdata()))
            clean.save(file_path)
            logger.info("OPSEC: stripped image metadata from %s", file_path)
        except ImportError:
            logger.warning("OPSEC: Pillow not installed, cannot strip image metadata")
        except Exception as exc:
            logger.error("OPSEC: image metadata strip failed: %s", exc)

    @staticmethod
    def _strip_pdf_metadata(file_path: str) -> None:
        """Remove author, creator, and other metadata from PDFs."""
        try:
            import pikepdf

            with pikepdf.open(file_path, allow_overwriting_input=True) as pdf:
                with pdf.open_metadata() as meta:
                    for key in list(meta.keys()):
                        del meta[key]
                pdf.save(file_path)
            logger.info("OPSEC: stripped PDF metadata from %s", file_path)
        except ImportError:
            logger.warning("OPSEC: pikepdf not installed, cannot strip PDF metadata")
        except Exception as exc:
            logger.error("OPSEC: PDF metadata strip failed: %s", exc)

    # -- Content leak detection --

    @staticmethod
    def check_content_for_leaks(content: str) -> list[str]:
        """Scan content for potential identity leaks before publishing.

        Returns list of human-readable descriptions of detected leaks.
        Empty list means content is clean.
        """
        if not content:
            return []

        leaks: list[str] = []
        leak_checks: list[tuple[str, str]] = [
            (r"/Users/\w+/", "macOS username in path"),
            (r"/home/\w+/", "Linux username in path"),
            (r"C:\\Users\\\w+\\", "Windows username in path"),
            (r"\b[\w.+-]+@(?!zenon\.org\b)\S+\.\w+", "non-zenon email address"),
            (r"sk-[a-zA-Z0-9]{20,}", "OpenAI API key"),
            (r"xai-[a-zA-Z0-9]{20,}", "xAI API key"),
            (r"sk-ant-[a-zA-Z0-9-]+", "Anthropic API key"),
            (r"AKIA[0-9A-Z]{16}", "AWS access key"),
            (r"Bearer\s+[a-zA-Z0-9._\-]{20,}", "Bearer token"),
        ]

        for pattern, description in leak_checks:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                leaks.append(f"[LEAK] {description}: {len(matches)} occurrence(s)")

        return leaks

    # -- Timing jitter --

    @staticmethod
    def randomize_timing(base_delay: float = 0) -> float:
        """Add random jitter to action timing to prevent pattern detection.

        Returns a delay in seconds with +/-30% random jitter applied to
        the base delay, plus a small random component (0.1-2.0s).

        Args:
            base_delay: Base delay in seconds before jitter is applied.

        Returns:
            Delay in seconds (always >= 0).
        """
        jitter_factor = 1.0 + random.uniform(-0.3, 0.3)
        jittered = base_delay * jitter_factor
        jittered += random.uniform(0.1, 2.0)
        return max(0.0, jittered)

    @staticmethod
    def sleep_with_jitter(base_delay: float = 0) -> float:
        """Sleep for a jittered duration. Returns actual sleep time."""
        delay = OPSECGuard.randomize_timing(base_delay)
        time.sleep(delay)
        return delay

    # -- Anonymous User-Agent --

    @staticmethod
    def generate_anonymous_user_agent() -> str:
        """Return a common, generic User-Agent string.

        Randomly selected from a pool of popular browser UAs.
        """
        return random.choice(_GENERIC_USER_AGENTS)


# ---------------------------------------------------------------------------
# Zenon address validation — task #39 v1
# ---------------------------------------------------------------------------

# Zenon mainnet addresses are bech32-encoded with the `z1` human-readable
# prefix and a fixed 40-character total length (prefix + 38 data chars).
# bech32's character set excludes `1bio` from the data portion — here we
# settle for the looser structural check (length + prefix + lower-case
# alphanumeric) because v1 of task #39 only needs "does this look
# remotely like a Zenon address?" Full bech32 checksum verification is
# deferred to v2 (the signature path) where we'll already be pulling in
# a dependency capable of verifying signatures against a pubkey derived
# from the address.
_ZENON_ADDRESS_LENGTH = 40
_ZENON_ADDRESS_PREFIX = "z1"
_ZENON_ADDRESS_PATTERN = re.compile(r"^z1[0-9a-z]{38}$")


def validate_zenon_address(candidate: str) -> bool:
    """Return True when ``candidate`` structurally matches a Zenon address.

    Task #39 v1 — structural only. Does NOT verify bech32 checksum; see
    module docstring for the scope rationale. Used by
    ``core.transport.get_local_peer_id`` to decide whether an operator-
    supplied ``ZENON_PEER_ADDRESS`` env var is worth respecting, or
    whether to fall through to the anonymous random peer id.

    Args:
        candidate: The raw string to check. Typically an env var value.

    Returns:
        True when the string is a well-formed Zenon address candidate.
        False on anything else (empty, wrong length, wrong prefix,
        contains uppercase, contains symbols, etc). Never raises.
    """
    if not isinstance(candidate, str):
        return False
    if len(candidate) != _ZENON_ADDRESS_LENGTH:
        return False
    if not candidate.startswith(_ZENON_ADDRESS_PREFIX):
        return False
    return bool(_ZENON_ADDRESS_PATTERN.match(candidate))
