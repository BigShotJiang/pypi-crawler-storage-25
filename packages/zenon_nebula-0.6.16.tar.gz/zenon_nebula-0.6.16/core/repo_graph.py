# SPDX-License-Identifier: MIT
"""
Repo Graph -- cross-repo dependency and fork relationship substrate.

Walks a Nebula workspace and builds a directed graph describing how
repositories depend on each other. Parses the common manifest formats
(``go.mod``, ``pubspec.yaml``, ``package.json``, ``Cargo.toml``,
``requirements.txt``) and, when possible, resolves each declared module
back to another repository inside the workspace — turning isolated
manifests into an actual relationship graph.

Also detects upstream/fork pairs by reading ``git remote -v`` for each
repo and matching ``origin``/``upstream`` remotes.

This module is **core**. It never imports from ``domains.*`` and never
opens a raw sqlite3 connection: every persistence call flows through
``core.persistence`` helpers. The declared ``SCHEMA_SQL`` constant is
auto-applied by ``core.schema_registry`` at boot.

Usage::

    from core.repo_graph import (
        build_dependency_graph,
        find_upstream_forks,
        get_dependents,
        persist_graph,
    )

    graph = build_dependency_graph(workspace_root)  # e.g. $ZENON_WORKSPACE_ROOT
    pairs = find_upstream_forks(workspace_root)
    persist_graph(graph, db_path)
    dependents = get_dependents("go-zenon", db_path)
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schema (picked up by core.schema_registry)
# ---------------------------------------------------------------------------

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS repo_dependencies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    source_repo TEXT NOT NULL,
    target_module TEXT NOT NULL,
    target_repo TEXT,
    ecosystem TEXT,
    version TEXT,
    manifest_file TEXT,
    edge_type TEXT DEFAULT 'depends_on',
    resolved INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_repo_deps_source
    ON repo_dependencies(source_repo);
CREATE INDEX IF NOT EXISTS idx_repo_deps_target_repo
    ON repo_dependencies(target_repo);
CREATE INDEX IF NOT EXISTS idx_repo_deps_ecosystem
    ON repo_dependencies(ecosystem);
"""


# ---------------------------------------------------------------------------
# Manifest parsers
# ---------------------------------------------------------------------------

_MANIFEST_FILES = (
    "go.mod",
    "pubspec.yaml",
    "package.json",
    "Cargo.toml",
    "requirements.txt",
)


def _read_text(path: Path) -> str:
    """Read a file with replacement on decode errors, returning ``""`` on failure."""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _parse_go_mod(path: Path) -> list[dict]:
    """Parse a ``go.mod`` file into a list of dependency dicts."""
    content = _read_text(path)
    deps: list[dict] = []
    in_require = False
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("//") or not line:
            continue
        if line.startswith("require ("):
            in_require = True
            continue
        if in_require and line == ")":
            in_require = False
            continue
        if line.startswith("require "):
            parts = line.split()
            if len(parts) >= 3:
                deps.append(
                    {
                        "name": parts[1],
                        "version": parts[2],
                        "ecosystem": "go",
                        "manifest": str(path),
                    }
                )
        elif in_require:
            parts = line.split()
            if len(parts) >= 2 and not parts[0].startswith("//"):
                deps.append(
                    {
                        "name": parts[0],
                        "version": parts[1],
                        "ecosystem": "go",
                        "manifest": str(path),
                    }
                )
    return deps


_PUBSPEC_DEP_LINE = re.compile(r"^\s{2,}([A-Za-z0-9_]+)\s*:\s*(.+?)\s*$")


def _parse_pubspec_yaml(path: Path) -> list[dict]:
    """Parse a ``pubspec.yaml`` file into dependency dicts.

    Handles scalar-style entries (``znn_sdk_dart: ^1.0.0``) at nested
    indentation. Git dependencies map to the repo name via the URL.
    """
    content = _read_text(path)
    deps: list[dict] = []
    section: str | None = None
    for raw in content.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        stripped = raw.rstrip()
        if not stripped.startswith(" "):
            header = stripped.rstrip(":").strip()
            if header in ("dependencies", "dev_dependencies", "dependency_overrides"):
                section = header
            else:
                section = None
            continue
        if section is None:
            continue
        match = _PUBSPEC_DEP_LINE.match(raw)
        if not match:
            continue
        name = match.group(1)
        rest = match.group(2).strip()
        # Inline map-style entries like "{git: url}" end up on the value
        # side — we still capture the package name and mark version as
        # "git".
        version = rest if rest and not rest.startswith("{") else "git"
        deps.append(
            {
                "name": name,
                "version": version,
                "ecosystem": "dart",
                "manifest": str(path),
            }
        )
    return deps


def _parse_package_json(path: Path) -> list[dict]:
    """Parse a ``package.json`` file into dependency dicts."""
    content = _read_text(path)
    deps: list[dict] = []
    try:
        data = json.loads(content) if content else {}
    except json.JSONDecodeError:
        return deps
    for section in ("dependencies", "devDependencies", "peerDependencies"):
        for name, version in (data.get(section) or {}).items():
            deps.append(
                {
                    "name": name,
                    "version": str(version),
                    "ecosystem": "node",
                    "manifest": str(path),
                }
            )
    return deps


_CARGO_DEP_INLINE = re.compile(
    r'^([A-Za-z0-9_\-]+)\s*=\s*(?:"([^"]+)"|\{[^}]*version\s*=\s*"([^"]+)"[^}]*\})'
)


def _parse_cargo_toml(path: Path) -> list[dict]:
    """Parse a ``Cargo.toml`` file into dependency dicts.

    A tiny hand-rolled parser that handles the two common forms
    (``name = "1.2.3"`` and ``name = { version = "1.2.3" }``). Full TOML
    parsing is intentionally avoided so this module has zero runtime
    dependencies.
    """
    content = _read_text(path)
    deps: list[dict] = []
    in_deps = False
    for raw in content.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            in_deps = line in (
                "[dependencies]",
                "[dev-dependencies]",
                "[build-dependencies]",
                "[workspace.dependencies]",
            )
            continue
        if not in_deps:
            continue
        match = _CARGO_DEP_INLINE.match(line)
        if not match:
            continue
        name = match.group(1)
        version = match.group(2) or match.group(3) or "unknown"
        deps.append(
            {
                "name": name,
                "version": version,
                "ecosystem": "rust",
                "manifest": str(path),
            }
        )
    return deps


def _parse_requirements_txt(path: Path) -> list[dict]:
    """Parse a Python ``requirements.txt``-style file into dependency dicts."""
    content = _read_text(path)
    deps: list[dict] = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        match = re.match(
            r"^([A-Za-z0-9_.\-\[\]]+)\s*([><=~!]=?.*)?$",
            line,
        )
        if not match:
            continue
        name = match.group(1).split("[", 1)[0]
        version_spec = (match.group(2) or "").strip()
        version = re.sub(r"^[^0-9]*", "", version_spec) or "unknown"
        deps.append(
            {
                "name": name,
                "version": version,
                "ecosystem": "python",
                "manifest": str(path),
            }
        )
    return deps


def parse_manifest(path: Path) -> list[dict]:
    """Dispatch a manifest file to the correct parser.

    Args:
        path: Absolute path to the manifest file.

    Returns:
        List of dependency dicts. Each dict has keys ``name``,
        ``version``, ``ecosystem``, ``manifest``. Unknown/unsupported
        manifests return an empty list.
    """
    name = path.name
    if name == "go.mod":
        return _parse_go_mod(path)
    if name == "pubspec.yaml":
        return _parse_pubspec_yaml(path)
    if name == "package.json":
        return _parse_package_json(path)
    if name == "Cargo.toml":
        return _parse_cargo_toml(path)
    if name == "requirements.txt":
        return _parse_requirements_txt(path)
    return []


# ---------------------------------------------------------------------------
# Repo discovery + module -> repo resolution
# ---------------------------------------------------------------------------


def _iter_repos(workspace_root: Path) -> list[Path]:
    """Yield every git repo under ``workspace_root`` (up to 4 levels deep)."""
    found: list[Path] = []
    if not workspace_root.exists():
        return found
    seen: set[Path] = set()
    for depth in range(1, 5):
        pattern = "/".join(["*"] * depth) + "/.git"
        for git_dir in workspace_root.glob(pattern):
            repo_path = git_dir.parent
            if repo_path in seen:
                continue
            seen.add(repo_path)
            found.append(repo_path)
    return found


def _repo_name(repo_path: Path) -> str:
    """Return the stable name for a repo (directory basename)."""
    return repo_path.name


def _go_module_name(repo_path: Path) -> str | None:
    """Read the declared ``module`` line from a repo's ``go.mod``.

    Returns the fully-qualified module path (``github.com/zenon-network/go-zenon``)
    or ``None`` if no go.mod exists or the line is missing.
    """
    go_mod = repo_path / "go.mod"
    if not go_mod.is_file():
        return None
    for line in _read_text(go_mod).splitlines():
        line = line.strip()
        if line.startswith("module "):
            return line.split(None, 1)[1].strip().strip('"')
    return None


def _package_json_name(repo_path: Path) -> str | None:
    """Read the declared ``name`` from a repo's ``package.json``."""
    pkg = repo_path / "package.json"
    if not pkg.is_file():
        return None
    try:
        data = json.loads(_read_text(pkg))
    except json.JSONDecodeError:
        return None
    name = data.get("name")
    return str(name) if name else None


def _pubspec_name(repo_path: Path) -> str | None:
    """Read the declared ``name`` from a repo's ``pubspec.yaml``."""
    pubspec = repo_path / "pubspec.yaml"
    if not pubspec.is_file():
        return None
    for line in _read_text(pubspec).splitlines():
        line = line.rstrip()
        if line.startswith("name:"):
            return line.split(":", 1)[1].strip().strip('"').strip("'")
    return None


def _cargo_package_name(repo_path: Path) -> str | None:
    """Read the declared ``[package] name`` from a repo's ``Cargo.toml``."""
    cargo = repo_path / "Cargo.toml"
    if not cargo.is_file():
        return None
    in_package = False
    for line in _read_text(cargo).splitlines():
        s = line.strip()
        if s == "[package]":
            in_package = True
            continue
        if s.startswith("[") and s != "[package]":
            in_package = False
            continue
        if in_package and s.startswith("name"):
            match = re.match(r'name\s*=\s*"([^"]+)"', s)
            if match:
                return match.group(1)
    return None


def _build_module_index(workspace_root: Path) -> dict[str, str]:
    """Map every declared module/package name to its workspace repo name.

    Covers Go modules, npm package names, Dart package names and Cargo
    crate names. Callers can then resolve a dependency's ``name`` to the
    repo that owns that module.
    """
    index: dict[str, str] = {}
    for repo in _iter_repos(workspace_root):
        name = _repo_name(repo)
        go_mod = _go_module_name(repo)
        if go_mod:
            index[go_mod] = name
        pkg_name = _package_json_name(repo)
        if pkg_name:
            index[pkg_name] = name
        pub_name = _pubspec_name(repo)
        if pub_name:
            index[pub_name] = name
        cargo_name = _cargo_package_name(repo)
        if cargo_name:
            index[cargo_name] = name
        # Also register the bare directory name as a fallback — Dart
        # path deps and local Go replace directives often reference it.
        index.setdefault(name, name)
    return index


def _resolve_target(dep_name: str, module_index: dict[str, str]) -> str | None:
    """Resolve a raw dependency name to a workspace repo name.

    Tries exact match first, then progressively shorter prefixes of Go
    module paths (``github.com/foo/bar/sub`` -> ``github.com/foo/bar``).
    """
    if not dep_name:
        return None
    if dep_name in module_index:
        return module_index[dep_name]
    parts = dep_name.split("/")
    while len(parts) > 1:
        parts.pop()
        candidate = "/".join(parts)
        if candidate in module_index:
            return module_index[candidate]
    return None


# ---------------------------------------------------------------------------
# Graph builder
# ---------------------------------------------------------------------------


def build_dependency_graph(workspace_root: str) -> dict:
    """Build a directed dependency graph for a workspace.

    Walks every git repo under ``workspace_root``, parses the common
    manifest files, and resolves each declared dependency to a target
    repo inside the same workspace when possible.

    Args:
        workspace_root: Absolute path to the workspace to scan. Missing
            or unreadable paths return an empty graph rather than
            raising.

    Returns:
        Dict with three keys:

        - ``workspace_root``: resolved workspace path as a string.
        - ``nodes``: list of ``{"repo_name", "repo_path"}`` dicts.
        - ``edges``: list of dicts with keys ``source``, ``target``,
          ``target_module``, ``ecosystem``, ``version``,
          ``manifest_file``, ``resolved``. ``resolved`` is ``True`` when
          the dependency was matched to another workspace repo.
    """
    root = Path(workspace_root) if workspace_root else None
    if root is None or not root.exists():
        return {
            "workspace_root": str(workspace_root or ""),
            "nodes": [],
            "edges": [],
        }

    repos = _iter_repos(root)
    module_index = _build_module_index(root)

    nodes = [{"repo_name": _repo_name(r), "repo_path": str(r)} for r in repos]
    edges: list[dict] = []

    for repo in repos:
        source_name = _repo_name(repo)
        for manifest_name in _MANIFEST_FILES:
            manifest = repo / manifest_name
            if not manifest.is_file():
                continue
            for dep in parse_manifest(manifest):
                target_repo = _resolve_target(dep["name"], module_index)
                edges.append(
                    {
                        "source": source_name,
                        "target_module": dep["name"],
                        "target": target_repo,
                        "ecosystem": dep["ecosystem"],
                        "version": dep["version"],
                        "manifest_file": dep["manifest"],
                        "resolved": bool(target_repo),
                    }
                )

    return {
        "workspace_root": str(root),
        "nodes": nodes,
        "edges": edges,
    }


# ---------------------------------------------------------------------------
# Fork detection via git remotes
# ---------------------------------------------------------------------------


def _git_remote_v(repo_path: Path, timeout: int = 10) -> str:
    """Run ``git -C <repo_path> remote -v`` and return stdout.

    Returns an empty string on any failure (missing git, non-repo, etc.).
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "remote", "-v"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        logger.debug("git remote -v failed for %s: %s", repo_path, exc)
        return ""
    if result.returncode != 0:
        return ""
    return result.stdout or ""


def _parse_remote_v(output: str) -> dict[str, str]:
    """Parse ``git remote -v`` output into ``{remote_name: fetch_url}``."""
    remotes: dict[str, str] = {}
    for line in output.splitlines():
        parts = line.split()
        if len(parts) >= 3 and parts[-1] == "(fetch)":
            remotes[parts[0]] = parts[1]
    return remotes


def _normalize_remote_url(url: str) -> str:
    """Normalize a git remote URL for comparison.

    Strips protocol, trailing ``.git``, and trailing slashes so that
    ``git@github.com:foo/bar.git`` and ``https://github.com/foo/bar``
    compare equal.
    """
    if not url:
        return ""
    url = url.strip()
    if url.endswith(".git"):
        url = url[: -len(".git")]
    url = url.rstrip("/")
    for prefix in ("https://", "http://", "ssh://", "git://"):
        if url.startswith(prefix):
            url = url[len(prefix) :]
            break
    url = url.replace("git@", "", 1)
    url = url.replace(":", "/", 1)
    return url.lower()


def find_upstream_forks(workspace_root: str) -> list[tuple[str, str]]:
    """Detect upstream/fork pairs inside a workspace.

    A repo is considered a fork when it has both an ``origin`` remote
    and an ``upstream`` remote pointing at a different URL. The returned
    pairs use the local repo name for the fork and the normalized
    upstream URL for the source of truth.

    Args:
        workspace_root: Absolute path to the workspace to scan.

    Returns:
        List of ``(fork_repo_name, upstream_url)`` tuples. Returns an
        empty list when no workspace is available or no forks are
        detected.
    """
    root = Path(workspace_root) if workspace_root else None
    if root is None or not root.exists():
        return []
    pairs: list[tuple[str, str]] = []
    for repo in _iter_repos(root):
        remotes = _parse_remote_v(_git_remote_v(repo))
        if not remotes:
            continue
        origin = remotes.get("origin", "")
        upstream = remotes.get("upstream", "")
        if not upstream:
            continue
        if _normalize_remote_url(origin) == _normalize_remote_url(upstream):
            continue
        pairs.append((_repo_name(repo), upstream))
    return pairs


# ---------------------------------------------------------------------------
# Persistence + queries
# ---------------------------------------------------------------------------


def persist_graph(graph: dict, db_path: str) -> int:
    """Persist a dependency graph into the ``repo_dependencies`` table.

    Clears any existing rows for each source repo before inserting the
    fresh edges so re-scans don't accumulate stale edges.

    Args:
        graph:   Output of :func:`build_dependency_graph`.
        db_path: Target SQLite database path.

    Returns:
        Number of edge rows inserted.
    """
    edges = graph.get("edges") or []
    if not edges:
        return 0
    try:
        from core.persistence.metrics import persist_metric
        from core.persistence.schema import _get_connection, ensure_schema
    except Exception as exc:
        logger.debug("persist_graph skipped (import error): %s", exc)
        return 0

    ensure_schema(db_path)

    # Wipe prior rows for the repos we're about to write so we don't
    # double-count edges after a re-scan.
    sources = sorted({e.get("source", "") for e in edges if e.get("source")})
    if sources:
        try:
            conn = _get_connection(db_path)
            try:
                placeholders = ",".join("?" for _ in sources)
                conn.execute(
                    f"DELETE FROM repo_dependencies WHERE source_repo IN ({placeholders})",
                    sources,
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as exc:
            logger.debug("persist_graph wipe failed: %s", exc)

    inserted = 0
    for edge in edges:
        row = {
            "source_repo": edge.get("source", ""),
            "target_module": edge.get("target_module", ""),
            "target_repo": edge.get("target") or "",
            "ecosystem": edge.get("ecosystem", ""),
            "version": edge.get("version", ""),
            "manifest_file": edge.get("manifest_file", ""),
            "edge_type": edge.get("edge_type", "depends_on"),
            "resolved": 1 if edge.get("resolved") else 0,
        }
        result = persist_metric(db_path=db_path, table="repo_dependencies", data=row)
        if result and result > 0:
            inserted += 1
    return inserted


def get_dependents(repo_name: str, db_path: str) -> list[str]:
    """Return the list of workspace repos that depend on ``repo_name``.

    Reads the ``repo_dependencies`` table (populated by
    :func:`persist_graph`) and filters by resolved ``target_repo``.
    Duplicate source repos are de-duplicated.

    Args:
        repo_name: Name of the repo to look up.
        db_path:   SQLite database path.

    Returns:
        Sorted list of distinct source repo names. Empty list when the
        table does not exist or no dependents are found.
    """
    if not repo_name:
        return []
    try:
        from core.persistence.metrics import query_table
    except Exception as exc:
        logger.debug("get_dependents skipped (import error): %s", exc)
        return []
    rows = query_table(
        db_path=db_path,
        table="repo_dependencies",
        where="target_repo = ?",
        params=(repo_name,),
        limit=0,
    )
    names = {row["source_repo"] for row in rows if row.get("source_repo")}
    return sorted(names)


def graph_summary(graph: dict) -> dict:
    """Return a small summary dict for a graph (node + edge counts, etc.).

    Useful for logging and findings where the full graph is too verbose.
    """
    edges = graph.get("edges") or []
    nodes = graph.get("nodes") or []
    resolved = sum(1 for e in edges if e.get("resolved"))
    by_ecosystem: dict[str, int] = {}
    for edge in edges:
        eco = edge.get("ecosystem", "unknown")
        by_ecosystem[eco] = by_ecosystem.get(eco, 0) + 1
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "nodes": len(nodes),
        "edges": len(edges),
        "resolved_edges": resolved,
        "by_ecosystem": by_ecosystem,
    }


__all__ = [
    "SCHEMA_SQL",
    "build_dependency_graph",
    "find_upstream_forks",
    "get_dependents",
    "graph_summary",
    "parse_manifest",
    "persist_graph",
]
