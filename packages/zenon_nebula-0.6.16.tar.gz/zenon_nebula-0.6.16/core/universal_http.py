# SPDX-License-Identifier: MIT
"""Universal HTTP fetcher — task #67 (Phase E of the API layer).

Gated by four mechanical safety rails so engines can call APIs Nebula
doesn't have a typed wrapper for, without handing them the whole
internet:

1. **Host allowlist** — the destination host must be listed in
   ``data/allowed_api_hosts.txt``. Operators curate this file; a
   request to a non-listed host raises ``HostNotAllowedError`` before
   any network call happens.
2. **Scheme allowlist** — HTTPS only. ``http://``, ``file://``,
   ``ftp://``, etc. are rejected at the gate. No operator opt-in; this
   is non-negotiable for OPSEC (plain HTTP leaks request contents to
   every router on the path).
3. **Response size cap** — 1 MB by default, configurable per call.
   Caller sees ``ResponseTooLargeError`` before any memory blowup.
4. **URL scrub for logs** — every log line referencing a URL strips
   the query string and userinfo so credentials and tokens don't leak
   into rotating log files.

This module does NOT replace ``core/http.py``. That wrapper ships the
OPSEC-safe headers (rotating User-Agent, stripped fingerprint
headers). ``universal_http`` is a *layer on top* that adds the
allowlist + size cap. Engines that need dynamic API reach use
``universal_fetch``; engines using the typed API templates in
``core/api_templates/*`` keep calling those directly.

The allowlist file path defaults to ``<repo>/data/allowed_api_hosts.txt``.
Operators can redirect via ``NEBULA_ALLOWED_HOSTS_FILE`` env, useful
for the peer-net testing scenario (task #102) where two Nebula
instances run with different allowlists on one machine.

The allowlist is reloaded lazily based on file mtime, so operator
edits take effect on the next call without a Nebula restart.
"""

from __future__ import annotations

import logging
import os
import threading
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse, urlunparse

from core.http import opsec_urlopen

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ALLOWLIST_PATH = ENGINE_ROOT / "data" / "allowed_api_hosts.txt"

# Scheme allowlist is compiled in — not operator-configurable. HTTP
# leaks too much to be a knob; file:// and friends are out of scope
# for a network fetcher.
ALLOWED_SCHEMES = frozenset({"https"})

# 1 MB default response cap. Large enough for any sane JSON API
# response; small enough that a runaway endpoint can't OOM the
# operator's box. Callers can override per-call.
DEFAULT_MAX_BYTES = 1 * 1024 * 1024

# Default socket timeout. 30s matches core.http.opsec_urlopen's
# default so this layer doesn't silently extend the budget.
DEFAULT_TIMEOUT_SECONDS = 30


class UniversalHttpError(Exception):
    """Base class for every rail this module enforces."""


class HostNotAllowedError(UniversalHttpError):
    """Destination host is not in the operator's allowlist."""


class SchemeNotAllowedError(UniversalHttpError):
    """URL scheme is not HTTPS."""


class ResponseTooLargeError(UniversalHttpError):
    """Response body exceeded the byte cap."""


class MalformedURLError(UniversalHttpError):
    """URL could not be parsed, or has no host."""


@dataclass
class _AllowlistCache:
    """Memoized allowlist with mtime-based invalidation.

    Thread-safe — calls come from the autonomous cycle's parallel
    engine runner, so concurrent first-loads must not race.
    """

    path: Path
    hosts: frozenset[str] = field(default_factory=frozenset)
    mtime: float = 0.0
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def load(self) -> frozenset[str]:
        """Return the current allowlist, refreshing from disk if mtime
        changed. Missing file = empty allowlist (every fetch fails
        closed)."""
        with self._lock:
            try:
                stat = self.path.stat()
            except FileNotFoundError:
                # Fail closed: no allowlist file = no allowed hosts.
                if self.hosts:
                    logger.warning(
                        "allowlist %s disappeared; treating allowlist as empty",
                        self.path,
                    )
                self.hosts = frozenset()
                self.mtime = 0.0
                return self.hosts

            if stat.st_mtime == self.mtime and self.hosts:
                return self.hosts

            try:
                content = self.path.read_text(encoding="utf-8")
            except OSError as exc:
                logger.warning("could not read allowlist %s: %s", self.path, exc)
                return self.hosts
            hosts = _parse_allowlist(content)
            self.hosts = hosts
            self.mtime = stat.st_mtime
            logger.info("loaded %d allowed host(s) from %s", len(hosts), self.path)
            return hosts


def _parse_allowlist(content: str) -> frozenset[str]:
    """Parse an allowlist file. One host per line; # starts a comment;
    blank lines and inline comments are stripped; hosts are lowercased."""
    hosts: set[str] = set()
    for raw in content.splitlines():
        # Strip inline comments.
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        hosts.add(line.lower())
    return frozenset(hosts)


def _allowlist_path() -> Path:
    """Resolve the active allowlist path, honoring NEBULA_ALLOWED_HOSTS_FILE."""
    override = os.environ.get("NEBULA_ALLOWED_HOSTS_FILE", "").strip()
    if override:
        return Path(override).expanduser()
    return DEFAULT_ALLOWLIST_PATH


# Module-level cache. Path is stable within a process; re-reading the
# env on every call would be unnecessary.
_cache = _AllowlistCache(path=_allowlist_path())


def sanitize_url(url: str) -> str:
    """Return a URL safe for logging: strips the query string and any
    userinfo (user:password@host) component.

    Use this for every log line or persisted record that references an
    outbound URL. Query params frequently carry API keys and tokens —
    one stray log line is enough to leak credentials across every
    rotated log file the operator keeps.
    """
    try:
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return "<unparseable-url>"
    # Strip userinfo by setting netloc to just host[:port].
    host = parsed.hostname or ""
    if parsed.port:
        host = f"{host}:{parsed.port}"
    return urlunparse(
        (
            parsed.scheme,
            host,
            parsed.path,
            "",  # params — rarely used, leak-safe to strip
            "",  # query — strip (likely carries tokens)
            "",  # fragment — safe to strip
        )
    )


def is_allowed(url: str, *, allowlist: frozenset[str] | None = None) -> bool:
    """Return True if the URL passes every rail (scheme + host).

    Pure predicate, never raises, never network-calls. Engines that
    want to degrade gracefully ("skip this API call if it would be
    rejected") can check before calling ``universal_fetch``.
    """
    try:
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return False
    if parsed.scheme not in ALLOWED_SCHEMES:
        return False
    host = (parsed.hostname or "").lower()
    if not host:
        return False
    hosts = allowlist if allowlist is not None else _cache.load()
    return host in hosts


def _check_rails(url: str) -> tuple[str, str]:
    """Enforce every rail, returning ``(scheme, host)``. Raises a
    subclass of ``UniversalHttpError`` on any violation."""
    try:
        parsed = urlparse(url)
    except (ValueError, TypeError) as exc:
        raise MalformedURLError(f"could not parse URL: {exc}") from exc
    scheme = parsed.scheme
    if scheme not in ALLOWED_SCHEMES:
        raise SchemeNotAllowedError(
            f"scheme {scheme!r} not in {sorted(ALLOWED_SCHEMES)} (url: {sanitize_url(url)})"
        )
    host = (parsed.hostname or "").lower()
    if not host:
        raise MalformedURLError(f"URL has no host component (url: {sanitize_url(url)})")
    allowlist = _cache.load()
    if host not in allowlist:
        raise HostNotAllowedError(
            f"host {host!r} not in allowlist at {_cache.path} ({len(allowlist)} host(s) listed)"
        )
    return scheme, host


def universal_fetch(
    url: str,
    *,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
    max_bytes: int = DEFAULT_MAX_BYTES,
    headers: dict | None = None,
) -> bytes:
    """Fetch ``url`` through every rail and return the body bytes.

    Args:
        url: The target URL. Must be https and must have its host in
            the operator's allowlist.
        timeout: Socket timeout in seconds. Passed to ``opsec_urlopen``.
        max_bytes: Maximum bytes to read. Exceeding this raises
            ``ResponseTooLargeError`` after reading exactly
            ``max_bytes + 1`` to confirm the overflow.
        headers: Optional request headers. Routed through
            ``core.http.opsec_request`` for OPSEC safety.

    Returns:
        Response body as bytes.

    Raises:
        SchemeNotAllowedError: scheme is not HTTPS.
        HostNotAllowedError: host is not in the allowlist.
        MalformedURLError: URL does not parse or has no host.
        ResponseTooLargeError: response exceeded ``max_bytes``.
    """
    _check_rails(url)
    logger.info("universal_fetch: %s", sanitize_url(url))
    with opsec_urlopen(url, timeout=timeout) as resp:
        # Read one byte past the cap so we can tell the difference
        # between "exactly max_bytes" (allowed) and "overflowed"
        # (rejected). Reading a bounded number of bytes prevents a
        # runaway endpoint from pinning memory while we decide.
        body = resp.read(max_bytes + 1)
    if len(body) > max_bytes:
        raise ResponseTooLargeError(
            f"response exceeded {max_bytes} bytes (url: {sanitize_url(url)})"
        )
    return body


def reload_allowlist() -> frozenset[str]:
    """Force the next call to re-read the allowlist file from disk.

    Use after editing the allowlist file when you want changes to
    take effect immediately rather than wait for mtime-based lazy
    reload (which can be up to a filesystem-second off on some FS).
    """
    global _cache
    _cache = _AllowlistCache(path=_allowlist_path())
    return _cache.load()
