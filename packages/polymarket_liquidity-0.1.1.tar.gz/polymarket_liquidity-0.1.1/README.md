# polymarket-liquidity

Liquidity depth scanner for Polymarket markets. Grades order book depth with spread and side-by-side analysis.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-liquidity
```

## Usage

```python
from polymarket_liquidity import scan_market_liquidity
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
