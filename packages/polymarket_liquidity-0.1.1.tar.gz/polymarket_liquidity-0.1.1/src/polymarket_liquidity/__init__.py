"""
polymarket-liquidity — Liquidity depth scanner for Polymarket markets.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.liquidity import scan_market_liquidity

__all__ = ["scan_market_liquidity"]
__version__ = "0.1.0"
