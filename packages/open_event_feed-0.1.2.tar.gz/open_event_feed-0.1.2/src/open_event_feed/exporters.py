import datetime
import json

class EventItemJSONEncoder(json.jsonEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime.datetime, date)):
            return obj.isoformat()

        return json.JSONEncoder.default(self, obj)

def xcal_from_event_items(event_item_list):
    # TODO
    pass