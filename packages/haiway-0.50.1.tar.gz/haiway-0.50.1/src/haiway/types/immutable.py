import annotationlib
import inspect
from collections.abc import Mapping, MutableMapping
from typing import (
    Any,
    ClassVar,
    NoReturn,
    Self,
    dataclass_transform,
    get_origin,
    get_type_hints,
)

from haiway.types.default import Default, DefaultValue

__all__ = ("Immutable",)


@dataclass_transform(
    kw_only_default=True,
    frozen_default=True,
    field_specifiers=(Default,),
)
class ImmutableMeta(type):
    __slots__: tuple[str, ...]

    def __new__(
        mcs,
        name: str,
        bases: tuple[type, ...],
        namespace: dict[str, Any],
        **kwargs: Any,
    ) -> type:
        if any(
            isinstance(base, ImmutableMeta) and base.__name__ != "Immutable"
            for base in bases
        ):
            raise TypeError(
                "Immutable subclasses cannot be inherited; inherit directly from Immutable"
            )

        state_type = type.__new__(
            mcs,
            name,
            bases,
            namespace,
            **kwargs,
        )

        state_type.__ATTRIBUTES__ = _collect_attributes(  # pyright: ignore[reportAttributeAccessIssue]
            state_type,
            namespace=namespace,
        )
        state_type.__slots__ = tuple(state_type.__ATTRIBUTES__.keys())  # pyright: ignore[reportAttributeAccessIssue]
        state_type.__match_args__ = state_type.__slots__  # pyright: ignore[reportAttributeAccessIssue]

        return state_type


def _collect_attributes(
    cls: type[Any],
    *,
    namespace: Mapping[str, Any] | None = None,
) -> Mapping[str, DefaultValue | None]:
    attributes: MutableMapping[str, DefaultValue | None] = {}
    annotations: Mapping[str, Any]
    annotate = (
        annotationlib.get_annotate_from_class_namespace(namespace)
        if namespace is not None
        else None
    )
    if annotate is not None:
        annotations = annotationlib.call_annotate_function(
            annotate,
            annotationlib.Format.FORWARDREF,
            owner=cls,
        )

    else:
        annotations = get_type_hints(
            cls,
            localns={cls.__name__: cls},
        )

    for key, annotation in annotations.items():
        if key.startswith("__"):
            continue  # do not dunder specials

        if get_origin(annotation) is ClassVar:
            continue  # do not include ClassVars

        default_value: Any = getattr(cls, key, inspect.Parameter.empty)

        # Create an instance of the default value if any
        if default_value is inspect.Parameter.empty:
            attributes[key] = None

        elif isinstance(default_value, DefaultValue):
            attributes[key] = default_value

        else:
            attributes[key] = DefaultValue(default=default_value)

    return attributes


class Immutable(metaclass=ImmutableMeta):
    """
    Base class for frozen, slot-based Haiway value objects.

    Subclasses declare typed attributes as class annotations. The metaclass
    collects those annotations, derives ``__slots__`` and ``__match_args__``,
    and resolves literal defaults or ``Default(...)`` field markers during
    instance construction.

    Parameters
    ----------
    **kwargs : Any
        Values for declared attributes. Required attributes must be provided;
        optional attributes use their configured defaults.

    Raises
    ------
    AttributeError
        If a required attribute is missing or any mutation is attempted after
        initialization.
    """

    __ATTRIBUTES__: ClassVar[Mapping[str, DefaultValue | None]]

    def __init__(
        self,
        **kwargs: Any,
    ) -> None:
        for name, default in self.__ATTRIBUTES__.items():
            if name in kwargs:
                object.__setattr__(
                    self,
                    name,
                    kwargs[name],
                )

            elif default is not None:
                object.__setattr__(
                    self,
                    name,
                    default(),
                )

            else:
                raise AttributeError(
                    f"Missing required attribute: {name}@{self.__class__.__qualname__}"
                )

    def __setattr__(
        self,
        name: str,
        value: Any,
    ) -> NoReturn:
        raise AttributeError(
            f"Can't modify immutable {self.__class__.__qualname__}"
            f" attribute - '{name}' cannot be modified"
        )

    def __delattr__(
        self,
        name: str,
    ) -> NoReturn:
        raise AttributeError(
            f"Can't modify immutable {self.__class__.__qualname__}"
            f" attribute - '{name}' cannot be deleted"
        )

    def __str__(self) -> str:
        attributes: str = ", ".join(f"{name}: {getattr(self, name)}" for name in self.__slots__)
        return f"{self.__class__.__name__}({attributes})"

    def __repr__(self) -> str:
        return str(self)

    def __copy__(self) -> Self:
        return self  # Immutable, no need to provide an actual copy

    def __deepcopy__(
        self,
        memo: dict[int, Any] | None,
    ) -> Self:
        return self  # Immutable, no need to provide an actual copy
