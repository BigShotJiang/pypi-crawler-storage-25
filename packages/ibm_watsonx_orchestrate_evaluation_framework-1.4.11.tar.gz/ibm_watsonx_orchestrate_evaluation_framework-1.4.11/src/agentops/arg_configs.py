import os
from dataclasses import dataclass, field
from enum import StrEnum
from typing import List, Literal, Optional, Self, Union, get_args

from pydantic import model_validator
from pydantic.dataclasses import dataclass as pydantic_dataclass

from agentops import prompt

DEFAULT_PROVIDER_VENDOR: str = "ibm"

DEFAULT_EVALUATION_MODEL: str = "bedrock/openai.gpt-oss-120b-1:0"

DEFAULT_MAX_USER_TURNS: int = 20

# Convert Traversable paths to strings for compatibility
LLAMA_USER_PROMPT_PATH = str(prompt.LLAMA_USER_PROMPT_PATH)
GPT_USER_PROMPT_PATH = str(prompt.GPT_USER_PROMPT_PATH)
UNIVERSAL_USER_PROMPT_PATH = str(prompt.UNIVERSAL_USER_PROMPT_PATH)
KEYWORDS_GENERATION_PROMPT_PATH = str(prompt.KEYWORDS_GENERATION_PROMPT_PATH)
GPT_SUMMARY_GENERATION_PROMPT_PATH = str(
    prompt.GPT_SUMMARY_GENERATION_PROMPT_PATH
)
GPT_ARG_MATCHING_GENERATION_PROMPT_PATH = str(
    prompt.GPT_ARG_MATCHING_GENERATION_PROMPT_PATH
)
GPT_STORY_GENERATION_PROMPT_PATH = str(prompt.GPT_STORY_GENERATION_PROMPT_PATH)


@dataclass
class AuthConfig:
    url: Optional[str] = None
    tenant_name: str = "local"
    token: str | None = None


@dataclass
class LLMUserConfig:
    model_id: str = field(default="meta-llama/llama-3-3-70b-instruct")
    prompt_config: str = field(default="")
    user_response_style: List[str] = field(default_factory=list)
    personas: List[str] = field(default_factory=list)
    enable_structured_output: bool = False
    version: Literal["v1", "v2"] = "v1"

    def __post_init__(self):
        # Import locally to avoid circular dependency
        from agentops.utils.rich_utils import RichLogger

        logger = RichLogger(__name__)

        # Validate version - extract valid values from Literal type annotation
        version_field = self.__dataclass_fields__["version"]
        valid_versions = set(get_args(version_field.type))
        if self.version not in valid_versions:
            raise ValueError(
                f"Invalid version '{self.version}'. Must be one of: {', '.join(sorted(valid_versions))}"
            )

        # Select prompt_config based on version and model_id if not provided
        if not self.prompt_config:
            if self.version == "v2":
                self.prompt_config = UNIVERSAL_USER_PROMPT_PATH
            elif "llama" in self.model_id.lower():
                self.prompt_config = LLAMA_USER_PROMPT_PATH
            else:
                self.prompt_config = GPT_USER_PROMPT_PATH

        # Log which prompt template is being used
        logger.info(
            f"LLM User ({self.version}) using prompt template: {self.prompt_config}"
        )


@pydantic_dataclass
class ProviderConfig:
    model_id: Optional[str] = None
    provider: str = field(
        default_factory=lambda: (
            "gateway"
            if os.getenv("USE_GATEWAY_MODEL_PROVIDER", "true").lower() == "true"
            else "watsonx"
        )
    )
    embedding_model_id: Optional[str] = field(
        default="sentence-transformers/all-minilm-l6-v2"
    )
    vendor: str = field(default=DEFAULT_PROVIDER_VENDOR)
    referenceless_eval: bool = field(default=False)
    provider_params: dict = field(default_factory=dict)

    @model_validator(mode="after")
    def validate_model_id(self) -> Self:
        if self.model_id is None:
            if self.provider == "gateway":
                self.model_id = "bedrock/openai.gpt-oss-120b-1:0"
            elif self.provider == "watsonx":
                self.model_id = "meta-llama/llama-3-3-70b-instruct"

        return self

    @model_validator(mode="after")
    def log_gateway(self) -> Self:
        # Import locally to avoid circular dependency
        from agentops.utils.rich_utils import RichLogger

        logger = RichLogger(__name__)

        if self.provider == "gateway":
            logger.info(
                f"Default provider set to 'gateway' based on USE_GATEWAY_MODEL_PROVIDER environment variable"
            )

        return self


@dataclass
class CustomMetricsConfig:
    paths: Optional[list[str]] = field(default=None)
    llmaaj_config: ProviderConfig = field(default_factory=ProviderConfig)


@dataclass
class ExtractorsConfig:
    paths: Optional[list[str]] = field(default=None)


@dataclass
class ControllerConfig:
    enable_verbose_logging: bool = True
    enable_manual_user_input: bool = False


@dataclass
class TextMatchConfig:
    semantic_template_path: Optional[str] = None
    keyword_template_path: Optional[str] = None


@dataclass
class TestConfig:
    test_paths: List[str]
    output_dir: str
    auth_config: AuthConfig
    wxo_lite_version: str
    max_user_turns: int = DEFAULT_MAX_USER_TURNS
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)
    llm_user_config: LLMUserConfig = field(default_factory=LLMUserConfig)
    custom_metrics_config: CustomMetricsConfig = field(
        default_factory=CustomMetricsConfig
    )
    extractors_config: ExtractorsConfig = field(
        default_factory=ExtractorsConfig
    )
    text_match_config: TextMatchConfig = field(default_factory=TextMatchConfig)
    skip_available_results: bool = False
    data_annotation_run: bool = False
    num_workers: int = 2
    n_runs: int = 1
    enable_verbose_logging: bool = True
    enable_manual_user_input: bool = False
    similarity_threshold: float = 0.8
    enable_fuzzy_matching: bool = False
    is_strict: bool = True
    enable_recursive_search: bool = False
    tags: list[str] = field(default_factory=list)
    error_keywords: List[str] = field(default_factory=list)
    skip_legacy_evaluation: bool = (
        False  # Skip legacy evaluation and only run user/agent simulations
    )
    collection_name: str = "default-collection"
    operator_configs: dict = None
    metrics: list[str] = field(
        default_factory=lambda: [
            "JourneySuccessMetric",
            "ToolCalling",
            "OrchestrateAgentRoutingAccuracy",
            "StepMetrics",
            "AgentResponseTime",
        ]
    )
    langfuse_enabled: bool = False
    evaluation_model: str = DEFAULT_EVALUATION_MODEL
    # TODO: this is a temporary (internal) flag to allow metric saving to disk
    # it will be removed later
    is_adk: bool = False


@dataclass
class AttackConfig:
    attack_paths: List[str]
    output_dir: str
    auth_config: AuthConfig
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)
    llm_user_config: LLMUserConfig = field(default_factory=LLMUserConfig)
    enable_verbose_logging: bool = True
    enable_manual_user_input: bool = False
    num_workers: int = 2
    skip_available_results: bool = True


@dataclass
class AttackGeneratorConfig:
    attacks_list: Union[List[str], str]
    datasets_path: Union[List[str], str]
    agents_list_or_path: Union[List[str], str]
    target_agent_name: str
    auth_config: AuthConfig
    output_dir: str = None
    max_variants: int = None


# === Run Analyzer ===


class AnalyzeMode(StrEnum):
    default = "default"
    enhanced = "enhanced"


@dataclass
class AnalyzeConfig:
    data_path: str
    tool_definition_path: Optional[str] = None
    mode: str = AnalyzeMode.default
    generate_report: bool = False
    num_workers: int = 10
    run: int = -1
    test_names: Optional[Union[str, List[str]]] = None
    test_pattern: Optional[str] = None
    agent_names: Optional[Union[str, List[str]]] = None


# === Record/generation configs ===
@dataclass
class KeywordsGenerationConfig:
    model_id: str = field(default="meta-llama/llama-3-3-70b-instruct")
    prompt_config: str = field(default=KEYWORDS_GENERATION_PROMPT_PATH)
    enabled: bool = field(default=False)


@dataclass
class SummaryGenerationConfig:
    model_id: str = field(default="bedrock/openai.gpt-oss-120b-1:0")
    prompt_config: str = field(default=GPT_SUMMARY_GENERATION_PROMPT_PATH)


@dataclass
class ArgMatchingGenerationConfig:
    model_id: str = field(default="bedrock/openai.gpt-oss-120b-1:0")
    prompt_config: str = field(default=GPT_ARG_MATCHING_GENERATION_PROMPT_PATH)
    batch_size: int = field(default=1)  # Process individually, parallelized
    max_workers: int = field(default=10)  # Max concurrent LLM calls


@dataclass
class StoryGenerationConfig:
    model_id: str = field(default="bedrock/openai.gpt-oss-120b-1:0")
    prompt_config: str = field(default=GPT_STORY_GENERATION_PROMPT_PATH)


@dataclass
class TestCaseGenerationConfig:
    log_path: str
    seed_data_path: str
    output_dir: str
    keywords_generation_config: KeywordsGenerationConfig = field(
        default_factory=KeywordsGenerationConfig
    )
    enable_verbose_logging: bool = True


@dataclass
class ChatRecordingConfig:
    output_dir: str
    keywords_generation_config: KeywordsGenerationConfig = field(
        default_factory=KeywordsGenerationConfig
    )
    summary_generation_config: SummaryGenerationConfig = field(
        default_factory=SummaryGenerationConfig
    )
    story_generation_config: StoryGenerationConfig = field(
        default_factory=StoryGenerationConfig
    )
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)
    service_url: str = "http://localhost:4321"
    tenant_name: str = "local"
    token: Optional[str] = None
    max_retries: int = 5
    context_variables: Optional[str] = None


@dataclass
class QuickEvalConfig(TestConfig):
    tools_path: Optional[str] = None


@dataclass
class BatchAnnotateConfig:
    allowed_tools: List[str]
    tools_path: str
    stories_path: str
    output_dir: str
    num_variants: int = 2


@dataclass
class CompareRunsConfig:
    reference_benchmark_location: str
    experiment_benchmark_location: str
    generate_failure_report: Optional[bool] = False
    csv_output_dir: Optional[str] = None


# === Eval data analyzer ===


class EvalDataAnalyzeMode(StrEnum):
    quality = "quality"
    complexity = "complexity"


@dataclass
class EvalDataAnalyzerConfig:
    test_paths: List[str]
    output_dir: str = "report/"
    mode: EvalDataAnalyzeMode = EvalDataAnalyzeMode.quality
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)


@dataclass
class TagDataAnalyzerConfig:
    """Configuration for tag-based data analysis.

    Args:
        results_dir: Directory containing both summary_metrics.csv and config.yml
        display_tables: Whether to display Rich tables in console (default: True)
    """

    results_dir: str
    display_tables: bool = True


@dataclass
class ToolParameterDiffConfig:
    """Configuration for tool parameter diff analysis"""

    parent_dir: str = field(
        metadata={
            "help": "Parent directory containing multiple result subdirectories"
        }
    )
    tool_name: str = field(
        metadata={
            "help": "Name of the tool to analyze (e.g., 'update_address')"
        }
    )
