import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Type

import requests
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from agentops.singleton import ThreadSafeSingletonABCMeta
from agentops.type import ChatCompletions


@dataclass
class RetryConfig:
    """Configuration for retry behavior with exponential backoff."""

    max_attempts: int = 3
    min_wait_seconds: int = 1
    max_wait_seconds: int = 60
    multiplier: int = 2

    # Retry on generic network/transport exceptions
    retryable_exceptions: Tuple[Type[BaseException], ...] = (
        ConnectionError,
        TimeoutError,
        requests.exceptions.ConnectionError,
        requests.exceptions.Timeout,
    )


class Provider(ABC, metaclass=ThreadSafeSingletonABCMeta):
    def __init__(
        self,
        logger: Optional[logging.Logger] = None,
        retry_config: Optional[RetryConfig] = None,
    ) -> None:
        self.logger = logger or logging.getLogger(self.__class__.__name__)
        self.retry_config = retry_config or RetryConfig()

    def _is_retryable_exception(self, exception):
        """Check if an exception is worth retrying based on config."""
        # Check HTTPError first for error codes
        if isinstance(exception, requests.exceptions.HTTPError):
            if exception.response is None:
                return False
            status = exception.response.status_code
            return status == 429 or 500 <= status <= 599

        # For non-HTTP errors, check against configured retryable exceptions
        # Note: This will match RequestException but not HTTPError (handled above)
        return isinstance(exception, self.retry_config.retryable_exceptions)

    def _create_retry_decorator(self):
        """Creates a tenacity retry decorator based on retry_config."""
        cfg = self.retry_config

        return retry(
            reraise=True,  # Always re-raise the final exception
            stop=stop_after_attempt(cfg.max_attempts),
            wait=wait_exponential(
                multiplier=cfg.multiplier,
                min=cfg.min_wait_seconds,
                max=cfg.max_wait_seconds,
            ),
            retry=retry_if_exception(self._is_retryable_exception),
            before_sleep=before_sleep_log(self.logger, logging.WARNING),
        )

    def _execute_with_retry(self, func: Callable, *args, **kwargs):
        """
        Executes a function with retry logic based on retry_config.

        Args:
            func: Callable to execute
            *args, **kwargs: Arguments to pass to func

        Returns:
            Result of func execution

        Raises:
            Exception: Re-raises the final exception after all retries exhausted
        """
        retry_decorator = self._create_retry_decorator()

        @retry_decorator
        def wrapped():
            return func(*args, **kwargs)

        try:
            return wrapped()
        except Exception as e:
            self.logger.error(
                f"{self.__class__.__name__} failed after {self.retry_config.max_attempts} attempts: {str(e)}"
            )
            raise

    def chat(
        self,
        messages: Sequence[Dict[str, str]],
        params: Optional[Dict[str, Any]] = None,
    ) -> ChatCompletions:
        """
        Template method for chat completions with automatic retry logic.
        Subclasses should implement _chat_impl() instead of overriding this method.
        """
        return self._execute_with_retry(self._chat_impl, messages, params)

    @abstractmethod
    def _chat_impl(
        self,
        messages: Sequence[Dict[str, str]],
        params: Optional[Dict[str, Any]] = None,
    ) -> ChatCompletions:
        """
        Provider-specific implementation of chat completions.
        This method will be automatically wrapped with retry logic.
        """
        raise NotImplementedError("Not implemented")

    def encode(self, sentences: List[str]) -> List[list]:
        """
        Template method for text encoding with automatic retry logic.
        Subclasses should implement _encode_impl() instead of overriding this method.
        """
        return self._execute_with_retry(self._encode_impl, sentences)

    @abstractmethod
    def _encode_impl(self, sentences: List[str]) -> List[list]:
        """
        Provider-specific implementation of text encoding.
        This method will be automatically wrapped with retry logic.
        Default implementation raises NotImplementedError.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement encode()."
        )

    def query(self, sentence: str) -> ChatCompletions:
        messages = []
        if self.system_prompt is not None:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.append({"role": "user", "content": sentence})
        return self.chat(messages)
