from typing import Dict, List, Optional

import openai
from openai import ChatCompletion

from agentops.service_provider.provider import Provider


class OpenAIProvider(Provider):
    """Simple OpenAI client wrapper for prompt optimization."""

    def __init__(
        self,
        model: str = "gpt-4.1",
        api_key: str | None = None,
    ):
        super().__init__()
        self.model = model
        self.client = openai.OpenAI(api_key=api_key)

    def _chat_impl(
        self,
        messages: List[Dict[str, str]],
        max_tokens: int = 1000,
        params: dict = {},
    ) -> ChatCompletion:
        # Newer models (gpt-5.x, o-series) require max_completion_tokens
        # instead of max_tokens
        token_param = (
            "max_completion_tokens"
            if any(p in self.model for p in ("gpt-5", "o1", "o3", "o4"))
            else "max_tokens"
        )
        return self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            **{token_param: max_tokens},
        )

    def _encode_impl(self, sentences: List[str]) -> List[list]:
        raise NotImplementedError(
            "encode is not implemented for OpenAIProvider"
        )
