import copy
from dataclasses import asdict, dataclass

from agentops.arg_configs import (
    CustomMetricsConfig,
    LLMUserConfig,
    ProviderConfig,
    TestConfig,
)
from agentops.llm_user.base_user import BaseUserSimulator
from agentops.llm_user.llm_user_v1 import LLMUser
from agentops.llm_user.llm_user_v2 import LLMUserV2
from agentops.prompt.template_render import LlamaUserTemplateRenderer
from agentops.resource_map import ResourceMap
from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter
from agentops.service_provider import get_provider
from agentops.service_provider.provider import Provider
from agentops.wxo_client import WXOClient, get_wxo_client


def create_llm_user(
    llm_user_config: LLMUserConfig,
    provider_config: ProviderConfig,
) -> BaseUserSimulator:
    """
    Create the appropriate LLM user simulator based on the version specified in config.

    Args:
        llm_user_config: Configuration for the LLM user
        provider_config: Configuration for the provider

    Returns:
        BaseUserSimulator: Either LLMUser (v1) or LLMUserV2 (v2)
    """
    # Create provider config with LLM user's model_id
    llm_provider_config = ProviderConfig(
        **{
            **asdict(provider_config),
            "model_id": llm_user_config.model_id,
        }
    )

    if llm_user_config.version == "v2":
        return LLMUserV2(
            llm_client=get_provider(config=llm_provider_config),
            user_prompt_path=llm_user_config.prompt_config or None,
            enable_structured_output=llm_user_config.enable_structured_output,
        )
    else:  # Default to v1
        return LLMUser(
            wai_client=get_provider(config=llm_provider_config),
            template=LlamaUserTemplateRenderer(llm_user_config.prompt_config),
            user_response_style=llm_user_config.user_response_style,
        )


@dataclass
class Clients:
    wxo_client: WXOClient
    llmaaj_provider: Provider
    resource_map: ResourceMap
    inference_backend: WXORuntimeAdapter
    llm_user: BaseUserSimulator


def bootstrap_clients(config: TestConfig) -> Clients:
    """
    Bootstrap all clients needed for the evaluation.

    Args:
        config: The test configuration

    Returns:
        A tuple containing:
        - wxo_client: The WXO client
        - llmaaj_provider: The provider for custom metrics
        - resource_map: The resource map
        - inference_backend: The inference backend
        - llm_user: The LLM user
    """
    # Initialize WXO client
    wxo_client = get_wxo_client(
        config.auth_config.url,
        config.auth_config.tenant_name,
        config.auth_config.token,
    )

    # Initialize provider for custom metrics
    original_provider_config = config.provider_config
    provider_config_dict = asdict(original_provider_config)

    provider_kwargs = {
        "config": ProviderConfig(**provider_config_dict),
        "model_id": config.llm_user_config.model_id,
    }

    if provider_config_dict.get("provider", "gateway") == "gateway":
        provider_kwargs.update(
            token_provider=lambda: wxo_client.api_key,
            instance_url=wxo_client.service_url,
        )
        config.auth_config.token = (
            config.auth_config.token or wxo_client.api_key
        )
        config.auth_config.url = (
            config.auth_config.url or wxo_client.service_url
        )

    # Initialize resource map
    resource_map = ResourceMap.from_wxo_client(wxo_client)

    # Initialize inference backend
    inference_backend = WXORuntimeAdapter(wxo_client=wxo_client)

    # Initialize LLM user
    llm_user = create_llm_user(
        llm_user_config=config.llm_user_config,
        provider_config=original_provider_config,
    )

    llamaj_provider_kwargs = copy.deepcopy(provider_kwargs)
    llamaj_config_dict = asdict(llamaj_provider_kwargs["config"])

    if isinstance(config.custom_metrics_config, dict):
        cmc_dict = config.custom_metrics_config
        if isinstance(cmc_dict.get("llmaaj_config"), dict):
            cmc_dict["llmaaj_config"] = ProviderConfig(
                **cmc_dict["llmaaj_config"]
            )
        config.custom_metrics_config = CustomMetricsConfig(**cmc_dict)

    llamaj_config_dict["model_id"] = (
        config.custom_metrics_config.llmaaj_config.model_id
    )
    llamaj_config_dict["embedding_model_id"] = (
        config.custom_metrics_config.llmaaj_config.embedding_model_id
    )
    llamaj_provider_kwargs["config"] = ProviderConfig(**llamaj_config_dict)
    llmaaj_provider = get_provider(**llamaj_provider_kwargs)

    return Clients(
        wxo_client=wxo_client,
        llmaaj_provider=llmaaj_provider,
        resource_map=resource_map,
        inference_backend=inference_backend,
        llm_user=llm_user,
    )
