import getpass
import logging
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

import jwt
import yaml
from ibm_watsonx_orchestrate_clients.common.client import Client
from ibm_watsonx_orchestrate_clients.common.credentials import Credentials
from ibm_watsonx_orchestrate_clients.common.utils import (
    is_cpd_env,
    is_local_dev,
)
from ibm_watsonx_orchestrate_core.utils.config import (
    AUTH_CONFIG_FILE,
    AUTH_CONFIG_FILE_FOLDER,
    AUTH_MCSP_TOKEN_EXPIRY_OPT,
    AUTH_MCSP_TOKEN_OPT,
    AUTH_SECTION_HEADER,
    ENV_AUTH_TYPE,
    ENV_IAM_URL_OPT,
    ENV_WXO_URL_OPT,
    ENVIRONMENTS_SECTION_HEADER,
    PROTECTED_ENV_NAME,
    Config,
)

logger = logging.getLogger(__name__)
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)


def _decode_token(token: str, is_local: bool) -> dict:
    """Taken from ADK. In the future, these functions should be a shared library"""
    try:
        claimset = jwt.decode(token, options={"verify_signature": False})
        data = {AUTH_MCSP_TOKEN_OPT: token}
        if not is_local:
            data[AUTH_MCSP_TOKEN_EXPIRY_OPT] = claimset["exp"]
        return data
    except jwt.DecodeError as e:
        logger.error("Invalid token format")
        raise e


def _login_cpd() -> dict:
    """
    Taken from ibm_watsonx_orchestrate
    """
    username = getpass.getpass("Please enter CPD Username: ")
    apikey = getpass.getpass(
        "Enter CPD API key (or leave blank to use password): "
    )
    password = None
    if not apikey:
        password = getpass.getpass(
            "Enter CPD password (or leave blank if you used API key): "
        )

    if apikey and password:
        logger.error(
            "For CPD, please use either an Apikey or a Password but not both."
        )
        sys.exit(1)

    if not apikey and not password:
        logger.error(
            "For CPD, you must provide either an API key or a password."
        )
        sys.exit(1)

    return username, apikey, password


def _login_remote() -> dict:
    """
    Taken from ibm_watsonx_orchestrate
    """
    apikey = getpass.getpass("Please enter WXO API key: ")
    return apikey


def refresh_env(tenant_name: str):
    cfg = Config()
    auth_cfg = Config(AUTH_CONFIG_FILE_FOLDER, AUTH_CONFIG_FILE)

    env_cfg = cfg.get(ENVIRONMENTS_SECTION_HEADER, tenant_name)
    url = env_cfg.get(ENV_WXO_URL_OPT)
    iam_url = env_cfg.get(ENV_IAM_URL_OPT)
    is_local = tenant_name == PROTECTED_ENV_NAME or is_local_dev(url=url)

    try:
        auth_type = cfg.get(
            ENVIRONMENTS_SECTION_HEADER, tenant_name, ENV_AUTH_TYPE
        )
    except (KeyError, AttributeError):
        auth_type = None

    username = None
    apikey = None
    password = None

    if is_cpd_env(url, auth_type):
        username, apikey, password = _login_cpd()

    if not apikey and not password and not is_local and auth_type != "cpd":
        apikey = _login_remote()

    try:
        creds = Credentials(
            url=url,
            api_key=apikey,
            username=username,
            password=password,
            iam_url=iam_url,
            auth_type=auth_type,
        )
        client = Client(creds)
        token = _decode_token(client.token, is_local)
        auth_cfg.save(
            {
                AUTH_SECTION_HEADER: {tenant_name: token},
            }
        )

        return client.token
    except Exception as e:
        raise e


def get_env_settings(
    tenant_name: str, env_config_path: Optional[str] = None
) -> Dict[str, Any]:
    if env_config_path is None:
        env_config_path = str(
            Path.home() / ".config" / "orchestrate" / "config.yaml"
        )

    try:
        with open(env_config_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    except FileNotFoundError:
        return {}

    tenant_env = (cfg.get("environments") or {}).get(tenant_name) or {}
    cached_user_env = cfg.get("cached_user_env") or {}

    merged = cached_user_env | tenant_env

    return dict(merged)


def apply_env_overrides(
    base: Dict[str, Any],
    tenant_name: str,
    keys: Optional[Iterable[str]] = None,
    env_config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Returns a new dict where base is overridden by tenant-defined values.
    - If keys is None, tries to override any keys present in tenant env.
    - Only overrides when the tenant value is present and not None.
    """
    env = get_env_settings(tenant_name, env_config_path=env_config_path)
    merged = dict(base)
    keys_to_consider = keys if keys is not None else env.keys()

    for k in keys_to_consider:
        if k in env and env[k] is not None:
            merged[k] = env[k]
    return merged


def tenant_setup(
    service_url: Optional[str], tenant_name: str
) -> Tuple[Optional[str], Optional[str], Dict[str, Any]]:
    auth_config_path = (
        Path.home() / ".cache" / "orchestrate" / "credentials.yaml"
    )
    env_config_path = Path.home() / ".config" / "orchestrate" / "config.yaml"

    try:
        with open(auth_config_path, "r", encoding="utf-8") as f:
            auth_config = yaml.safe_load(f) or {}
    except FileNotFoundError:
        auth_config = {}

    try:
        with open(env_config_path, "r", encoding="utf-8") as f:
            env_config = yaml.safe_load(f) or {}
    except FileNotFoundError:
        env_config = {}

    environments = env_config.setdefault("environments", {})
    context = env_config.setdefault("context", {})

    tenant_env = environments.setdefault(tenant_name, {})

    if service_url and str(service_url).strip():
        tenant_env["wxo_url"] = service_url

    resolved_service_url = tenant_env.get("wxo_url")

    context["active_environment"] = tenant_name

    # Ensure parent directories exist so tests (which may run in clean envs)
    # can write these files without raising FileNotFoundError.
    auth_config_path.parent.mkdir(parents=True, exist_ok=True)
    env_config_path.parent.mkdir(parents=True, exist_ok=True)

    with open(auth_config_path, "w") as f:
        yaml.dump(auth_config, f)
    with open(env_config_path, "w") as f:
        yaml.dump(env_config, f)

    token = (
        auth_config.get("auth", {}).get(tenant_name, {}).get("wxo_mcsp_token")
    )

    env_merged = get_env_settings(
        tenant_name, env_config_path=str(env_config_path)
    )

    return token, resolved_service_url, env_merged
