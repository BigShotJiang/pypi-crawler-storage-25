from __future__ import annotations

import json
import logging
import re
from typing import List, Union

from jinja2 import TemplateError

import agentops.prompt
from agentops.llm_user.base_user import BaseUserSimulator
from agentops.llm_user.guardrails import UserSimulatorGuardrails
from agentops.llm_user.models import GoalStatus, SimulatedUserTurn
from agentops.personas.models import PersonaProfile
from agentops.prompt.template_render import UserTemplateRenderer
from agentops.service_provider.watsonx_provider import Provider
from agentops.type import ContentType, Message
from agentops.utils.file_system import get_resource_path

logger = logging.getLogger(__name__)

_MAX_GUARDRAIL_RETRIES = 2


class LLMUserV2(BaseUserSimulator):
    # new LLM user that works with chat completion providers like portkey
    def __init__(
        self,
        llm_client: Provider,
        user_prompt_path: str | None = None,
        enable_structured_output: bool = False,
    ):
        self.llm_client = llm_client
        model_name = getattr(llm_client, "model_id", "")
        self.model_is_gpt = "gpt-oss-120b" in model_name

        if user_prompt_path is None:
            if self.model_is_gpt:
                self.user_prompt_path = get_resource_path(
                    agentops.prompt, "gpt/gpt_user_template_v2.jinja2"
                )
            else:
                self.user_prompt_path = get_resource_path(
                    agentops.prompt, "universal_user_template.jinja2"
                )
        else:
            self.user_prompt_path = user_prompt_path

        self.prompt_template = UserTemplateRenderer(
            template_path=str(self.user_prompt_path)
        )
        self._guardrails = UserSimulatorGuardrails()
        self.enable_structured_output = enable_structured_output

    def _get_system_prompt(
        self,
        user_story: str,
        user_response_style: List[str] | None,
        attack_instructions: str | None = None,
        persona_profile: PersonaProfile | None = None,
        structured_output: bool = False,
        retry_feedback: str | None = None,
    ) -> Message:
        # Get the user system prompt
        try:
            prompt_messages = self.prompt_template.render(
                user_story=user_story,
                user_response_style=user_response_style,
                attack_instructions=attack_instructions,
                persona_profile=persona_profile,
                structured_output=structured_output,
                retry_feedback=retry_feedback,
            )
        except TemplateError as e:
            error_msg = (
                f"The v2 user agent failed to render system prompt template {self.user_prompt_path}.\n"
                f"Error: {str(e)}\n\n"
                f"You probably need to specify a compatible prompt template in your config.yaml, e.g.:\n"
                f"  llm_user_config:\n"
                f"    version: v2\n"
                f"    prompt_config: 'src/agentops/prompt/universal_user_template.jinja2'\n"
            )
            logger.error(error_msg)
            raise ValueError(error_msg) from e

        content = prompt_messages[0]["content"]
        if structured_output and "RESPONSE FORMAT" not in content:
            raise ValueError(
                "structured_output=True but RESPONSE FORMAT section "
                "missing from rendered prompt. First 300 chars: "
                f"{content[:300]}"
            )
        return Message(
            role="system",
            content=content,
            type=ContentType.text,
        )

    def _get_message_dicts(self, messages: List[Message]) -> List[dict]:
        # Convert messages to dictionary format for the llm client
        return [
            message.model_dump(exclude_none=True, exclude={"type"})
            for message in messages
        ]

    def _filter_conversation_history(
        self, conversation_history: List[Message]
    ) -> List[Message]:
        # Keep only messages a real user would see: their own messages
        # and the agent's final text responses.  Strip system prompts,
        # tool-call scaffolding (assistant messages that just invoke
        # tools), and raw tool responses — the user never sees those.
        return [
            message
            for message in conversation_history
            if message.role == "user"
            or (
                message.role == "assistant"
                and message.type == ContentType.text
                and message.content
            )
        ]

    def flip_message_roles(self, messages: List[Message]) -> List[Message]:
        # We flip the roles of messages in conversation history to basically prompt the
        # user simulator with the assistant message as the user input message
        # This helps to get the llm to respond as a natural user with the given story.
        new_messages = []
        for message in messages:
            if message.role == "user":
                new_messages.append(
                    Message(
                        role="assistant",
                        content=message.content,
                        type=ContentType.text,
                    )
                )
            else:
                new_messages.append(
                    Message(
                        role="user",
                        content=message.content,
                        type=ContentType.text,
                    )
                )
        return new_messages

    def generate_user_input(
        self,
        user_story: str,
        conversation_history: List[Message],
        attack_instructions: str | None = None,
        persona_profile: PersonaProfile | None = None,
        enable_structured_output: bool | None = None,
        user_response_style: List[str] | None = None,
        starting_user_input: Message | None = None,
        **kwargs,
    ) -> Union[Message, SimulatedUserTurn]:
        if starting_user_input is not None:
            # If starting user input is provided, return it as is for the initial turn
            return starting_user_input

        # Use instance variable if parameter wasn't explicitly provided
        if enable_structured_output is None:
            enable_structured_output = self.enable_structured_output

        # Structured output path with guardrail retry loop
        if enable_structured_output:
            return self._generate_structured(
                user_story=user_story,
                conversation_history=conversation_history,
                user_response_style=user_response_style,
                attack_instructions=attack_instructions,
                persona_profile=persona_profile,
            )

        # Legacy free-text path
        return self._generate_freetext(
            user_story=user_story,
            conversation_history=conversation_history,
            user_response_style=user_response_style,
            attack_instructions=attack_instructions,
            persona_profile=persona_profile,
        )

    def _generate_freetext(
        self,
        user_story: str,
        conversation_history: List[Message],
        user_response_style: List[str] | None = None,
        attack_instructions: str | None = None,
        persona_profile: PersonaProfile | None = None,
    ) -> Message:
        """Legacy free-text generation path."""
        system_prompt = self._get_system_prompt(
            user_story,
            user_response_style,
            attack_instructions,
            persona_profile=persona_profile,
        )
        conversation_history = self._filter_conversation_history(
            conversation_history
        )

        if len(conversation_history) == 0:
            conversation_history.append(
                Message(
                    role="assistant",
                    content="Hi! How can I help you today?",
                    type=ContentType.text,
                )
            )

        conversation_history = self.flip_message_roles(conversation_history)
        messages = [system_prompt] + conversation_history

        response = self.llm_client.chat(
            messages=self._get_message_dicts(messages)
        )
        return Message(
            role="user",
            content=response.choices[0].message.content,
            type=ContentType.text,
        )

    def _generate_structured(
        self,
        user_story: str,
        conversation_history: List[Message],
        user_response_style: List[str] | None = None,
        attack_instructions: str | None = None,
        persona_profile: PersonaProfile | None = None,
    ) -> SimulatedUserTurn:
        """Structured output path with guardrail validation and retry loop."""
        best_turn: SimulatedUserTurn | None = None
        all_notes: list[str] = []
        retry_feedback: str | None = None

        for attempt in range(_MAX_GUARDRAIL_RETRIES + 1):
            # Build prompt (with retry feedback if applicable)
            system_prompt = self._get_system_prompt(
                user_story,
                user_response_style,
                attack_instructions,
                persona_profile=persona_profile,
                structured_output=True,
                retry_feedback=retry_feedback,
            )

            filtered_history = self._filter_conversation_history(
                list(conversation_history)
            )
            if len(filtered_history) == 0:
                filtered_history.append(
                    Message(
                        role="assistant",
                        content="Hi! How can I help you today?",
                        type=ContentType.text,
                    )
                )
            flipped_history = self.flip_message_roles(filtered_history)
            messages = [system_prompt] + flipped_history

            # Add a format reminder as the last user-role message so the LLM
            # sees it right before generating, overriding any plain-text
            # pattern established by earlier conversation turns.
            messages.append(
                Message(
                    role="user",
                    content=(
                        "Remember: respond with ONLY a raw JSON object in the format "
                        '{"content": "...", "entities": {...}, "goal_status": "..."}'
                    ),
                    type=ContentType.text,
                )
            )

            # Invoke LLM
            response = self.llm_client.chat(
                messages=self._get_message_dicts(messages)
            )
            raw_content = response.choices[0].message.content

            # Handle content being dict or str
            content_str = (
                raw_content
                if isinstance(raw_content, str)
                else str(raw_content)
            )

            # Parse JSON
            logger.debug(
                "Structured output raw response (attempt %d): %s",
                attempt + 1,
                content_str[:500],
            )
            turn = self._parse_structured_response(content_str)
            if turn is None:
                note = (
                    f"Attempt {attempt + 1}: Failed to parse structured output"
                )
                logger.error(
                    f"{note}. Raw (first 500 chars): {content_str[:500]}"
                )
                all_notes.append(note)
                retry_feedback = (
                    "Your response was not valid JSON. "
                    f"Raw output:\n{content_str[:500]}"
                )
                logger.warning(note)
                continue

            best_turn = turn

            # Run guardrails
            result = self._guardrails.check(
                turn=turn,
                story=user_story,
                conversation_history=conversation_history,
            )
            all_notes.extend(result.notes)

            if result.passed:
                final_turn = (
                    result.patched_turn if result.patched_turn else turn
                )
                final_turn.guardrail_notes = all_notes
                return final_turn

            # REJECT — retry with feedback
            retry_feedback = result.retry_feedback
            logger.info(
                f"Guardrail REJECT on attempt {attempt + 1}: {retry_feedback}"
            )

        # Retries exhausted — return best effort
        if best_turn is not None:
            best_turn.guardrail_notes = all_notes
            return best_turn

        # Complete failure — return fallback
        return SimulatedUserTurn(
            content="I'm having trouble understanding. Can you help me?",
            goal_status=GoalStatus.IN_PROGRESS,
            guardrail_notes=all_notes,
        )

    @staticmethod
    def _parse_structured_response(raw: str) -> SimulatedUserTurn | None:
        """Parse LLM response as JSON into a SimulatedUserTurn."""
        text = _extract_json_text(raw.strip())
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            return None

        if not isinstance(data, dict):
            return None

        content = data.get("content")
        if not content or not isinstance(content, str):
            return None

        entities = data.get("entities", {})
        if not isinstance(entities, dict):
            entities = {}

        goal_status_str = data.get("goal_status", "in_progress")
        try:
            goal_status = GoalStatus(goal_status_str)
        except ValueError:
            goal_status = GoalStatus.IN_PROGRESS

        return SimulatedUserTurn(
            content=content,
            entities=entities,
            goal_status=goal_status,
        )


def _extract_json_text(text: str) -> str:
    """Extract JSON from LLM response, handling markdown fences and surrounding prose."""
    # Try to extract from markdown code fences (anywhere in the text)
    fence_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if fence_match:
        return fence_match.group(1).strip()

    # Try to find a JSON object directly (first { to last })
    first_brace = text.find("{")
    last_brace = text.rfind("}")
    if first_brace != -1 and last_brace > first_brace:
        return text[first_brace : last_brace + 1]

    return text
