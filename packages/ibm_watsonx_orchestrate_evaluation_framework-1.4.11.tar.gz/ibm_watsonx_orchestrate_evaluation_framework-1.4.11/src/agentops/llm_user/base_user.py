from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List, Optional, Union

from agentops.type import Message

if TYPE_CHECKING:
    from agentops.llm_user.models import SimulatedUserTurn
    from agentops.personas.models import PersonaProfile


class BaseUserSimulator(ABC):
    """Abstract base class for user simulators."""

    @abstractmethod
    def generate_user_input(
        self,
        user_story: str,
        conversation_history: List[Message],
        attack_instructions: Optional[str] = None,
        persona_profile: Optional[PersonaProfile] = None,
        **kwargs,
    ) -> Union[Message, SimulatedUserTurn]:
        """
        Generate user input based on the user story and conversation history.

        Args:
            user_story: The user's story or goal
            conversation_history: List of previous messages in the conversation
            attack_instructions: Optional attack instructions for red-teaming
            persona_profile: Optional persona profile to shape simulated behavior
            **kwargs: Additional parameters specific to the simulator implementation

        Returns:
            Message or SimulatedUserTurn: The generated user input.
        """
        pass
