"""Deterministic guardrails for the user simulator.

The guardrail pipeline validates structured LLM output (SimulatedUserTurn)
against the story and conversation history to prevent hallucinated entities
and ensure consistency.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from agentops.llm_user.models import SimulatedUserTurn
from agentops.type import Message

logger = logging.getLogger(__name__)


class GuardrailSeverity(StrEnum):
    REJECT = "reject"  # Critical — must retry
    PATCH = "patch"  # Fixable — auto-correct and proceed
    LOG = "log"  # Non-critical — log and proceed


@dataclass
class GuardrailViolation:
    guardrail: str  # e.g. "G1"
    entity: str  # entity name or description
    message: str  # human-readable
    severity: GuardrailSeverity


@dataclass
class GuardrailResult:
    passed: bool
    violations: list[GuardrailViolation] = field(default_factory=list)
    patched_turn: SimulatedUserTurn | None = None

    @property
    def retry_feedback(self) -> str | None:
        """Build retry feedback string from REJECT violations."""
        rejects = [
            v for v in self.violations if v.severity == GuardrailSeverity.REJECT
        ]
        if not rejects:
            return None
        lines = [f"- [{v.guardrail}] {v.message}" for v in rejects]
        return "Your response violated the following guardrails:\n" + "\n".join(
            lines
        )

    @property
    def notes(self) -> list[str]:
        """All violation messages formatted for guardrail_notes."""
        return [f"[{v.guardrail}] {v.message}" for v in self.violations]


def _value_in_text(value: str, text: str) -> bool:
    """Check if a value appears as a substring in text (case-insensitive)."""
    return value.lower() in text.lower()


def _value_in_assistant_messages(
    value: Any, conversation_history: list[Message]
) -> bool:
    """Check if a value appears in any assistant message content."""
    str_value = str(value)
    for msg in conversation_history:
        if msg.role == "assistant":
            content = (
                msg.content
                if isinstance(msg.content, str)
                else str(msg.content)
            )
            if _value_in_text(str_value, content):
                return True
    return False


class UserSimulatorGuardrails:
    """Post-processing guardrail pipeline for SimulatedUserTurn validation.

    G1 — Provenance: every entity value must originate from the story text
    or from prior assistant messages (agent-communicated). This prevents
    the user simulator from hallucinating entity values.
    """

    def check(
        self,
        turn: SimulatedUserTurn,
        story: str,
        conversation_history: list[Message],
    ) -> GuardrailResult:
        """Run all guardrails on a simulated user turn.

        Args:
            turn: The structured output from the user simulator LLM.
            story: The flat story text from the dataset item.
            conversation_history: Full conversation history so far.

        Returns:
            GuardrailResult with pass/fail, violations, and optional patched turn.
        """
        violations: list[GuardrailViolation] = []

        violations.extend(
            self._g1_provenance(turn, story, conversation_history)
        )

        if not violations:
            return GuardrailResult(passed=True)

        has_reject = any(
            v.severity == GuardrailSeverity.REJECT for v in violations
        )

        if has_reject:
            return GuardrailResult(passed=False, violations=violations)

        # Only PATCH / LOG violations — pass with notes
        return GuardrailResult(passed=True, violations=violations)

    @staticmethod
    def _g1_provenance(
        turn: SimulatedUserTurn,
        story: str,
        conversation_history: list[Message],
    ) -> list[GuardrailViolation]:
        """G1: Every entity value must have a legitimate source.

        Legitimate sources:
        1. The story text (substring match)
        2. Prior assistant messages (agent-communicated)

        This is an adapted version that works with flat story text rather
        than structured known_info / unknown_info partitions.
        """
        violations = []

        for entity, value in turn.entities.items():
            str_value = str(value)

            # Skip trivially empty values
            if not str_value.strip():
                continue

            # Source 1: story text
            if _value_in_text(str_value, story):
                continue

            # Source 2: agent-communicated
            if _value_in_assistant_messages(value, conversation_history):
                continue

            violations.append(
                GuardrailViolation(
                    guardrail="G1",
                    entity=entity,
                    message=(
                        f"Entity '{entity}' with value {str_value!r} has no "
                        f"legitimate provenance (not found in story text or "
                        f"agent messages)"
                    ),
                    severity=GuardrailSeverity.REJECT,
                )
            )

        return violations
