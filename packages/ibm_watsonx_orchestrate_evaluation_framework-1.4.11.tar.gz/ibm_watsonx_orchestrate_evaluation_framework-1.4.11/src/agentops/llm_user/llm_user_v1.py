from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from agentops.llm_user.base_user import BaseUserSimulator
from agentops.prompt.template_render import JinjaTemplateRenderer
from agentops.service_provider.watsonx_provider import Provider
from agentops.type import ContentType, Message

if TYPE_CHECKING:
    from agentops.personas.models import PersonaProfile

T = TypeVar("T", bound=JinjaTemplateRenderer)


class LLMUser(BaseUserSimulator):
    # default LLM user that uses the llama template
    def __init__(
        self,
        wai_client: Provider,
        template: T,
        user_response_style: list[str] | None = None,
    ):
        self.wai_client = wai_client
        self.prompt_template = template
        self.user_response_style = (
            [] if user_response_style is None else user_response_style
        )

    def generate_user_input(
        self,
        user_story: str,
        conversation_history: list[Message],
        attack_instructions: str | None = None,
        persona_profile: PersonaProfile | None = None,
        **kwargs,
    ) -> Message:
        # the tool response is already summarized, we don't need that to take over the chat history context window
        prompt_input = self.prompt_template.render(
            conversation_history=[
                entry
                for entry in conversation_history
                if entry.type != ContentType.tool_response
            ],
            user_story=user_story,
            user_response_style=self.user_response_style,
            attack_instructions=attack_instructions,
        )
        response = self.wai_client.chat(prompt_input)
        content = response.choices[0].message.content
        content_str = (
            content.strip()
            if isinstance(content, str)
            else str(content).strip()
        )
        user_input = Message(
            role="user",
            content=content_str,
            type=ContentType.text,
        )
        return user_input
