#!/usr/bin/env python3
"""
CLI tool for generating metrics from test case evaluations.

This tool reads test case ground truth and messages from files/folders
and runs the evaluation to generate metrics results.
"""

import json
from pathlib import Path
from typing import List, Optional

import typer
import yaml
from rich.console import Console
from rich.table import Table

from agentops.arg_configs import AuthConfig, ProviderConfig, TestConfig
from agentops.clients import bootstrap_clients
from agentops.langfuse_evaluation_package import EvaluationRunner, load_metrics
from agentops.type import Message, TestCase
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)
console = Console()

app = typer.Typer(
    name="generate-metrics",
    help="CLI tool for generating metrics from test case evaluations",
    add_completion=False,
)


def load_test_case(test_case_path: str) -> TestCase:
    """Load test case from YAML or JSON file.

    Args:
        test_case_path: Path to the test case file

    Returns:
        TestCase object

    Raises:
        ValueError: If file format is not supported
        FileNotFoundError: If file doesn't exist
    """
    path = Path(test_case_path)
    if not path.exists():
        raise FileNotFoundError(f"Test case file not found: {test_case_path}")

    logger.info(f"Loading test case from: {test_case_path}")

    if path.suffix in [".yaml", ".yml"]:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    elif path.suffix == ".json":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        raise ValueError(
            f"Unsupported file format: {path.suffix}. Use .yaml, .yml, or .json"
        )

    return TestCase(**data)


def load_messages_from_dir(messages_dir: str) -> List[List[Message]]:
    """Load messages from JSON files in a directory.

    Each JSON file should contain a list of messages for one test case.
    Files are loaded in alphabetical order.

    Args:
        messages_dir: Path to directory containing message JSON files

    Returns:
        List of message lists (one per test case)

    Raises:
        FileNotFoundError: If directory doesn't exist
        ValueError: If no valid message files found
    """
    dir_path = Path(messages_dir)
    if not dir_path.exists():
        raise FileNotFoundError(f"Messages directory not found: {messages_dir}")

    logger.info(f"Loading messages from: {messages_dir}")

    message_files = sorted(dir_path.glob("*.json"))
    if not message_files:
        raise ValueError(f"No JSON files found in: {messages_dir}")

    all_messages = []
    for msg_file in message_files:
        logger.info(f"  Loading: {msg_file.name}")
        with open(msg_file, "r", encoding="utf-8") as f:
            messages_data = json.load(f)

        # Convert to Message objects if needed
        if isinstance(messages_data, list):
            messages = [
                Message(**msg) if isinstance(msg, dict) else msg
                for msg in messages_data
            ]
            all_messages.append(messages)
        else:
            logger.warning(f"  Skipping {msg_file.name}: not a list")

    if not all_messages:
        raise ValueError(f"No valid message files loaded from: {messages_dir}")

    logger.info(f"Loaded {len(all_messages)} message file(s)")
    return all_messages


def print_evaluation_results(results, output_dir: str):
    """Print evaluation results in a formatted table.

    Args:
        results: ExperimentResult object containing metrics
        output_dir: Directory where results were saved
    """
    console.print("\n[bold green]Evaluation Complete![/bold green]\n")
    console.print(f"Results saved to: {output_dir}\n")

    # Print aggregate metrics
    if results.aggregate_metrics:
        table = Table(
            title="Aggregate Metrics", show_header=True, header_style="bold"
        )
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="magenta")

        for metric_name, metric_value in results.aggregate_metrics.items():
            if isinstance(metric_value, (int, float)):
                table.add_row(metric_name, f"{metric_value:.4f}")
            else:
                table.add_row(metric_name, str(metric_value))

        console.print(table)

    # Print per-test-case metrics summary
    if results.metrics:
        console.print("\n[bold]Per Test Case Results:[/bold]")
        for idx, test_metrics in enumerate(results.metrics):
            if test_metrics:
                console.print(f"\n  Test Case {idx + 1}:")
                for test_name, metric_list in test_metrics.items():
                    console.print(f"    {test_name}:")
                    for metric in metric_list:
                        console.print(
                            f"      - {metric.eval_name}: {metric.score:.4f}"
                        )


@app.command()
def generate_metrics(
    test_case_path: str = typer.Argument(
        ...,
        help="Path to the test case file (YAML or JSON) containing ground truth",
    ),
    messages_dir: str = typer.Argument(
        ...,
        help="Path to directory containing message files (JSON format)",
    ),
    output_dir: str = typer.Option(
        "./evaluation_results",
        "--output-dir",
        "-o",
        help="Directory to save evaluation results",
    ),
    metrics: List[str] = typer.Option(
        ["JourneySuccessMetric", "ToolCalling", "StepMetrics"],
        "--metric",
        "-m",
        help="Metrics to evaluate (can be specified multiple times)",
    ),
    evaluation_model: str = typer.Option(
        "bedrock/openai.gpt-oss-120b-1:0",
        "--model",
        help="Model to use for evaluation",
    ),
    provider: str = typer.Option(
        "gateway",
        "--provider",
        help="Provider to use (gateway, watsonx, etc.)",
    ),
):
    """Generate metrics from test case evaluations.

    This command loads test case ground truth and messages from files,
    then runs the evaluation pipeline to generate metrics results.

    Example:
        generate-metrics test_case.yaml ./messages_folder
    """
    try:
        # Load test case (ground truth)
        test_case = load_test_case(test_case_path)

        # Load messages
        messages_list = load_messages_from_dir(messages_dir)

        # Create output directory
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Bootstrap clients for LLM evaluation
        logger.info("Initializing LLM clients...")

        # Create provider config
        provider_config = ProviderConfig(provider=provider)

        # Create a minimal TestConfig for client initialization
        test_config = TestConfig(
            test_paths=[],
            output_dir=output_dir,
            auth_config=AuthConfig(),
            wxo_lite_version="v1",
            provider_config=provider_config,
            evaluation_model=evaluation_model,
        )

        clients = bootstrap_clients(test_config)

        # Load metrics
        logger.info(f"Loading metrics: {metrics}")
        evaluators = load_metrics(
            test_config,
            metrics,
            llm_client=clients.llmaaj_provider,
        )

        # Create evaluation runner
        logger.info("Setting up evaluation runner...")

        # Replicate test case for each message set
        test_cases = [test_case] * len(messages_list)

        runner = EvaluationRunner(
            evaluation_name=f"cli-evaluation-{test_case.dataset_name or 'unnamed'}",
            output_dir=output_dir,
            test_cases=test_cases,
            messages=messages_list,
            metrics=evaluators,
            exporters=[],  # Use default disk persistence
        )

        # Run evaluation
        logger.info("Running evaluation...")
        results = runner.evaluate()

        # Print results
        print_evaluation_results(results, output_dir)

        logger.info(
            "[bold green]✓ Evaluation completed successfully![/bold green]"
        )

    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise typer.Exit(code=1)
    except ValueError as e:
        logger.error(f"Invalid input: {e}")
        raise typer.Exit(code=1)
    except Exception as e:
        logger.error(f"Evaluation failed: {e}")
        raise typer.Exit(code=1)


def main():
    """Main entry point for the evaluate CLI."""
    app()


if __name__ == "__main__":
    main()

# Made with Bob
