import os
from threading import Lock
from typing import Any, Dict, Optional

import requests
import urllib3
from ibm_watsonx_orchestrate_clients.common.utils import check_token_validity
from urllib3.exceptions import InsecureRequestWarning

from agentops.service_instance import refresh_env
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)

lock = Lock()


class WXOClient:
    def __init__(
        self,
        service_url,
        api_key,
        env: Optional[Dict[str, Any]] = None,
        tenant_name: Optional[str] = None,
    ):
        self.service_url = service_url
        self.api_key = api_key
        self.tenant_name = tenant_name
        ov = os.getenv("WO_SSL_VERIFY")
        if ov and ov.strip().lower() in ("true", "false"):
            self._verify_ssl = ov.strip().lower() == "true"
        else:
            v, bs = (env.get("verify") if env else None), (
                env.get("bypass_ssl") if env else None
            )
            self._verify_ssl = (
                False
                if (
                    (bs is True)
                    or (isinstance(bs, str) and bs.strip().lower() == "true")
                    or (v is None)
                    or (
                        isinstance(v, str)
                        and v.strip().lower() in {"none", "null"}
                    )
                )
                else (v if isinstance(v, bool) else True)
            )

        if not self._verify_ssl:
            urllib3.disable_warnings(InsecureRequestWarning)

    def _refresh_token(self):
        """
        if two threads call this function at the same time, only one will refresh the token.
        """
        if not check_token_validity(self.api_key):
            with lock:
                if not check_token_validity(self.api_key):
                    logger.info(
                        f"Refreshing token for tenant '[bold]{self.tenant_name}[/bold]'"
                    )
                    token = refresh_env(self.tenant_name)
                    self.api_key = token

    def _get_headers(self) -> dict:
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def post(self, payload: dict, path: str, stream=False):
        self._refresh_token()
        url = f"{self.service_url}/{path}"
        response = requests.post(
            url=url,
            headers=self._get_headers(),
            json=payload,
            stream=stream,
            verify=self._verify_ssl,
        )
        return response

    def post_files(
        self, path: str, files: dict, data: Optional[dict] = None, stream=False
    ):
        self._refresh_token()
        url = f"{self.service_url}/{path}"
        response = requests.post(
            url=url,
            headers=self._get_headers(),
            files=files,
            data=data,
            stream=stream,
            verify=self._verify_ssl,
        )
        return response

    def get(self, path: str, params: Optional[dict] = None):
        self._refresh_token()
        url = f"{self.service_url}/{path}"
        response = requests.get(
            url,
            params=params,
            headers=self._get_headers(),
            verify=self._verify_ssl,
        )
        return response


def get_wxo_client(
    service_url: Optional[str], tenant_name: str, token: Optional[str] = None
) -> WXOClient:

    from agentops.service_instance import tenant_setup

    token, resolved_url, env = tenant_setup(service_url, tenant_name)
    service_url = service_url or resolved_url

    if not (service_url and str(service_url).strip()):
        raise ValueError(
            f"service_url not provided and not found in config for tenant '{tenant_name}'"
        )

    wxo_client = WXOClient(
        service_url=service_url, api_key=token, env=env, tenant_name=tenant_name
    )
    return wxo_client
