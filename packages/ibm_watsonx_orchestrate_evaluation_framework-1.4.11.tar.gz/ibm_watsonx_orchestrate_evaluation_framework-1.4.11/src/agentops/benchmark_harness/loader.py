"""Load harness defaults, discover benchmarks, parse manifests, merge configs."""

from __future__ import annotations

import importlib.util
import inspect
import json
import logging
import os
import sys
from glob import glob
from pathlib import Path
from typing import Any

import yaml

from agentops.benchmark_harness.extension import BenchmarkExtension
from agentops.benchmark_harness.types import (
    AgentSpec,
    BenchmarkConfig,
    MatrixConfig,
    MockEntry,
    ModelMatrix,
    ParamSpec,
    SimConfig,
    ToolSpec,
)
from agentops.type import GoalDetailOrchestrate, TestCase

logger = logging.getLogger(__name__)

OVERRIDE_SUFFIX = "!"
SUPPORTED_PARAM_TYPES = {"string", "integer", "number", "boolean"}


class BenchmarkValidationError(Exception):
    """Raised when a benchmark manifest fails validation."""


def load_harness_defaults(path: Path) -> dict:
    """Load harness_defaults.yaml and return as dict.

    Validates required top-level fields are present.
    """
    if not path.exists():
        raise FileNotFoundError(f"harness defaults not found: {path}")

    with open(path) as f:
        data = yaml.safe_load(f) or {}

    required = {
        "matrix",
        "stories",
        "metrics",
        "runs_per_combo",
        "max_user_turns",
        "workers",
    }
    missing = required - set(data.keys())
    if missing:
        raise BenchmarkValidationError(
            f"harness defaults missing required fields: {sorted(missing)}"
        )

    matrix = data["matrix"]
    for role in ("agent", "user_sim", "eval"):
        models = matrix.get("models", {}).get(role)
        if not models:
            raise BenchmarkValidationError(
                f"harness_defaults.matrix.models.{role} must be a non-empty list"
            )
    if not matrix.get("frameworks"):
        raise BenchmarkValidationError(
            "harness_defaults.matrix.frameworks must be a non-empty list"
        )

    for scalar in ("runs_per_combo", "max_user_turns", "workers"):
        if not isinstance(data[scalar], int) or data[scalar] < 1:
            raise BenchmarkValidationError(
                f"harness_defaults.{scalar} must be an integer >= 1"
            )

    return data


def discover_benchmarks(roots: list[Path]) -> list[Path]:
    """Find all benchmark dirs (containing benchmark.yaml) under roots.

    A root may itself be a benchmark dir, or a parent of benchmark dirs
    (one level deep).
    """
    found: list[Path] = []
    for root in roots:
        if not root.exists():
            logger.warning(f"benchmark root does not exist: {root}")
            continue
        if (root / "benchmark.yaml").exists():
            found.append(root)
            continue
        # Treat as parent dir; scan one level deep
        for child in sorted(root.iterdir()):
            if child.is_dir() and (child / "benchmark.yaml").exists():
                found.append(child)
    return found


def merge_config(base: dict, overlay: dict) -> dict:
    """Deep-merge overlay onto base.

    - Scalars: overlay wins.
    - Lists (no suffix): appended to base list.
    - Lists with '!' suffix: replace base list; '!' is stripped in result.
    - Dicts: recursive deep merge.
    """
    result = _deep_copy_dict(base)
    for raw_key, overlay_val in overlay.items():
        replace = raw_key.endswith(OVERRIDE_SUFFIX)
        key = raw_key[:-1] if replace else raw_key

        if replace:
            if not isinstance(overlay_val, list):
                raise BenchmarkValidationError(
                    f"key '{raw_key}' uses '!' suffix but value is not a list"
                )
            result[key] = list(overlay_val)
            continue

        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(overlay_val, dict)
        ):
            result[key] = merge_config(result[key], overlay_val)
        elif (
            key in result
            and isinstance(result[key], list)
            and isinstance(overlay_val, list)
        ):
            result[key] = list(result[key]) + list(overlay_val)
        else:
            result[key] = overlay_val
    return result


def _deep_copy_dict(d: dict) -> dict:
    """Shallow-recursive copy that preserves nested dict and list structure."""
    out = {}
    for k, v in d.items():
        if isinstance(v, dict):
            out[k] = _deep_copy_dict(v)
        elif isinstance(v, list):
            out[k] = list(v)
        else:
            out[k] = v
    return out


def apply_env_overrides(config: dict) -> dict:
    """Apply AGENT_MODEL, USER_SIM_MODEL, EVAL_MODEL env overrides.

    Each, if set, collapses the corresponding model list to single-element list.
    """
    env_map = {
        "AGENT_MODEL": "agent",
        "USER_SIM_MODEL": "user_sim",
        "EVAL_MODEL": "eval",
    }
    models = config.setdefault("matrix", {}).setdefault("models", {})
    for env_name, role in env_map.items():
        val = os.environ.get(env_name)
        if val:
            models[role] = [val]
    return config


def load_benchmark(
    benchmark_dir: Path,
    defaults: dict,
) -> BenchmarkConfig:
    """Load a single benchmark and produce a fully resolved BenchmarkConfig."""
    manifest_path = benchmark_dir / "benchmark.yaml"
    if not manifest_path.exists():
        raise FileNotFoundError(f"benchmark.yaml not found in {benchmark_dir}")

    with open(manifest_path) as f:
        manifest = yaml.safe_load(f) or {}

    if "name" not in manifest or "description" not in manifest:
        raise BenchmarkValidationError(
            f"{manifest_path}: 'name' and 'description' are required"
        )

    merged = merge_config(defaults, manifest)
    merged = apply_env_overrides(merged)

    # Build typed config objects
    matrix_data = merged["matrix"]
    sim_configs = [_build_sim_config(c) for c in matrix_data["configs"]]
    model_matrix = ModelMatrix(
        agent=list(matrix_data["models"]["agent"]),
        user_sim=list(matrix_data["models"]["user_sim"]),
        eval=list(matrix_data["models"]["eval"]),
    )
    matrix = MatrixConfig(
        configs=sim_configs,
        models=model_matrix,
        frameworks=list(matrix_data["frameworks"]),
    )

    # Load artifacts
    tools_spec = load_tools_spec(benchmark_dir / "tools.yaml")
    tool_names = {t.name for t in tools_spec}
    agent_spec = load_agent_spec(benchmark_dir / "agent.yaml", tool_names)
    stories = load_stories(merged["stories"], benchmark_dir)
    extension = load_extension(benchmark_dir)

    return BenchmarkConfig(
        name=merged["name"],
        description=merged["description"],
        matrix=matrix,
        stories_pattern=merged["stories"],
        metrics=list(merged["metrics"]),
        runs_per_combo=merged["runs_per_combo"],
        max_user_turns=merged["max_user_turns"],
        workers=merged["workers"],
        benchmark_dir=benchmark_dir,
        tools_spec=tools_spec,
        agent_spec=agent_spec,
        stories=stories,
        extension=extension,
    )


def _build_sim_config(d: dict) -> SimConfig:
    if "name" not in d:
        raise BenchmarkValidationError(
            f"matrix.configs entry missing 'name': {d}"
        )
    return SimConfig(
        name=d["name"],
        structured_output=bool(d.get("structured_output", False)),
        guardrails=bool(d.get("guardrails", False)),
        persona=d.get("persona"),
    )


def load_tools_spec(path: Path) -> list[ToolSpec]:
    """Parse tools.yaml into list of ToolSpec."""
    if not path.exists():
        raise FileNotFoundError(f"tools.yaml not found: {path}")

    with open(path) as f:
        data = yaml.safe_load(f) or {}

    raw_tools = data.get("tools", [])
    if not isinstance(raw_tools, list):
        raise BenchmarkValidationError(f"{path}: 'tools' must be a list")

    seen_names: set[str] = set()
    tools: list[ToolSpec] = []
    for t in raw_tools:
        name = t.get("name")
        if not name:
            raise BenchmarkValidationError(f"{path}: tool entry missing 'name'")
        if name in seen_names:
            raise BenchmarkValidationError(
                f"{path}: duplicate tool name '{name}'"
            )
        seen_names.add(name)

        params: dict[str, ParamSpec] = {}
        for pname, pspec in (t.get("parameters") or {}).items():
            ptype = (pspec or {}).get("type", "string")
            if ptype not in SUPPORTED_PARAM_TYPES:
                raise BenchmarkValidationError(
                    f"{path}: tool '{name}' parameter '{pname}' has "
                    f"unsupported type '{ptype}' (supported: "
                    f"{sorted(SUPPORTED_PARAM_TYPES)})"
                )
            params[pname] = ParamSpec(
                type=ptype,
                description=(pspec or {}).get("description", ""),
            )

        returns = None
        if "returns" in t and t["returns"]:
            rtype = t["returns"].get("type", "string")
            if rtype not in SUPPORTED_PARAM_TYPES:
                raise BenchmarkValidationError(
                    f"{path}: tool '{name}' returns has unsupported "
                    f"type '{rtype}'"
                )
            returns = ParamSpec(
                type=rtype,
                description=t["returns"].get("description", ""),
            )

        mocks: list[MockEntry] = []
        for m in t.get("mocks") or []:
            mock_input = m.get("input") or {}
            unknown = set(mock_input.keys()) - set(params.keys())
            if unknown:
                raise BenchmarkValidationError(
                    f"{path}: tool '{name}' mock references "
                    f"unknown parameters: {sorted(unknown)}"
                )
            mocks.append(
                MockEntry(
                    input={k: str(v) for k, v in mock_input.items()},
                    output=str(m.get("output", "")),
                )
            )

        tools.append(
            ToolSpec(
                name=name,
                description=t.get("description", ""),
                parameters=params,
                mocks=mocks,
                returns=returns,
                default_error=t.get(
                    "default_error", "Error: unrecognized input"
                ),
            )
        )
    return tools


def load_agent_spec(path: Path, tool_names: set[str]) -> AgentSpec:
    """Parse agent.yaml; validate that all referenced tools exist."""
    if not path.exists():
        raise FileNotFoundError(f"agent.yaml not found: {path}")

    with open(path) as f:
        data = yaml.safe_load(f) or {}

    for required in ("name", "description", "instructions", "tools"):
        if required not in data:
            raise BenchmarkValidationError(
                f"{path}: missing required field '{required}'"
            )

    declared_tools = data["tools"]
    if not isinstance(declared_tools, list):
        raise BenchmarkValidationError(f"{path}: 'tools' must be a list")

    missing = set(declared_tools) - tool_names
    if missing:
        raise BenchmarkValidationError(
            f"{path}: agent references undeclared tools: {sorted(missing)}"
        )

    return AgentSpec(
        name=data["name"],
        description=data["description"],
        instructions=data["instructions"],
        tools=list(declared_tools),
    )


def load_stories(pattern: str, benchmark_dir: Path) -> list[TestCase]:
    """Load all story JSON files matching the glob pattern."""
    full_pattern = str(benchmark_dir / pattern)
    paths = sorted(glob(full_pattern))
    if not paths:
        raise BenchmarkValidationError(
            f"no stories found matching: {full_pattern}"
        )

    stories: list[TestCase] = []
    for p in paths:
        with open(p) as f:
            data = json.load(f)
        story = _build_test_case(data, source=p)
        # Stash the file name so the planner can label runs
        story.dataset_name = Path(p).stem
        stories.append(story)
    return stories


def _build_test_case(data: dict, source: str) -> TestCase:
    """Convert a story JSON dict into a TestCase with goal_details parsed."""
    if "story" not in data:
        raise BenchmarkValidationError(
            f"{source}: missing required field 'story'"
        )

    goal_details = []
    for gd in data.get("goal_details") or []:
        try:
            goal_details.append(GoalDetailOrchestrate(**gd))
        except Exception as e:
            raise BenchmarkValidationError(
                f"{source}: invalid goal_detail entry {gd}: {e}"
            )

    return TestCase(
        story=data["story"],
        starting_sentence=data.get("starting_sentence"),
        agent=data.get("agent"),
        goals=data.get("goals", {}),
        goal_details=goal_details,
    )


def load_extension(benchmark_dir: Path) -> BenchmarkExtension | None:
    """Import benchmark_ext.py if present and return an instance."""
    ext_path = benchmark_dir / "benchmark_ext.py"
    if not ext_path.exists():
        return None

    module_name = f"_benchmark_ext_{benchmark_dir.name}"
    spec = importlib.util.spec_from_file_location(module_name, ext_path)
    if spec is None or spec.loader is None:
        logger.warning(f"could not load extension spec from {ext_path}")
        return None

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        logger.warning(f"extension import failed for {ext_path}: {e}")
        return None

    for _name, obj in inspect.getmembers(module, inspect.isclass):
        if (
            issubclass(obj, BenchmarkExtension)
            and obj is not BenchmarkExtension
            and obj.__module__ == module_name
        ):
            return obj()

    logger.warning(f"{ext_path}: no BenchmarkExtension subclass found")
    return None
