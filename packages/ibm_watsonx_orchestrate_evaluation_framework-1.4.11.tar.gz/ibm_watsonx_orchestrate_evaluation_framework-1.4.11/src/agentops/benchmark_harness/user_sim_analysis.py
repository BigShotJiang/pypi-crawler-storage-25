"""Universal user-simulator diagnostic analysis.

These analyses apply to any benchmark that uses LLMUserV2 — they are not
domain-specific. They run automatically for every RunResult after the
core metric pipeline, before the benchmark's extension hook.

Four pieces:
  1. Entity hallucination audit (LLM-judged provenance check).
  2. PersonaBehaviorEvaluation (run-context-dependent metric).
  3. Journey failure diagnosis (deterministic, reads metric_results).
  4. Role-switch detection (deterministic, derives agent-only facts
     from tools.yaml mock outputs).

All are best-effort: failures are captured into result.custom under
*_error keys but do not block the run.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any, Iterable

from agentops.benchmark_harness.types import RunResult, ToolSpec
from agentops.type import ContentType

if TYPE_CHECKING:
    from agentops.service_provider.provider import Provider

logger = logging.getLogger(__name__)

# Heuristic threshold: a user message must contain at least this many
# distinct agent-only values to be flagged as a role switch.
_ROLE_SWITCH_MIN_FACTS = 2

# Skip values shorter than this when extracting agent-only facts —
# tokens like "0", "a" are too noisy to be useful signal.
_MIN_FACT_LENGTH = 2


@dataclass
class HallucinationDetail:
    entity: str
    value: str
    user_utterance: str
    reason: str


@dataclass
class RoleSwitchFlag:
    """A single role-switch detection — user message contained
    multiple values that originated only in tool outputs."""

    matched_facts: list[str]  # ["Sunny", "25", ...]
    fact_origins: list[str]  # ["weather", "temperature_celsius", ...]
    user_utterance: str


def run_user_sim_analysis(
    result: RunResult,
    tools_spec: list[ToolSpec],
    eval_provider: "Provider",
) -> None:
    """Run all universal user-sim analyses and populate result.custom.

    Adds these keys to result.custom (as applicable):
      - hallucination_details: list[dict] (always)
      - hallucination_error: str (only on failure)
      - goal_interference, behavioral_realism, entity_integrity: float
      - persona_behavior_error: str (only on failure)
      - journey_failure_reason: str (only when journey_success is False)
      - role_switch_flags: list[dict] (always; empty when none detected)
    """
    # 1. Entity hallucination audit
    try:
        details = detect_entity_hallucinations(
            result.messages,
            result.spec.story.story,
            eval_provider,
        )
        result.custom["hallucination_details"] = [asdict(d) for d in details]
    except Exception as e:
        logger.warning(f"hallucination audit failed: {e}")
        result.custom["hallucination_error"] = str(e)
        result.custom["hallucination_details"] = []

    # 2. PersonaBehaviorEvaluation — labelled by sim config name
    try:
        scores = evaluate_persona_behavior(result, eval_provider)
        result.custom.update(scores)
    except Exception as e:
        logger.warning(f"persona behavior evaluation failed: {e}")
        result.custom["persona_behavior_error"] = str(e)

    # 3. Journey failure diagnosis (only when journey actually failed)
    if not result.journey_success:
        try:
            result.custom["journey_failure_reason"] = diagnose_journey_failure(
                result
            )
        except Exception as e:
            logger.warning(f"journey failure diagnosis failed: {e}")

    # 4. Role-switch detection from declared mock outputs
    try:
        flags = detect_role_switch(result.messages, tools_spec)
        result.custom["role_switch_flags"] = [asdict(f) for f in flags]
    except Exception as e:
        logger.warning(f"role-switch detection failed: {e}")
        result.custom["role_switch_flags"] = []


def evaluate_persona_behavior(
    result: RunResult,
    eval_provider: "Provider",
) -> dict[str, float]:
    """Run PersonaBehaviorEvaluation for one conversation.

    Imports are deferred to avoid pulling in the full metrics package
    at module load time (mirrors the same concern as METRIC_REGISTRY in
    metrics_runner).
    """
    from agentops.benchmark_harness.metrics_runner import run_metrics
    from agentops.metrics.persona_behavior_evaluation import (
        PersonaBehaviorEvaluation,
    )

    behavior = PersonaBehaviorEvaluation(
        llm_client=eval_provider,
        config={
            "persona_id": result.spec.config.name,
            "termination_reason": result.termination_reason,
        },
    )
    ctx = run_metrics([behavior], result.messages, result.spec.story)
    out: dict[str, float] = {}
    for op_metrics in ctx.get("metric", {}).values():
        for eval_name, m in op_metrics.items():
            if eval_name in (
                "goal_interference",
                "behavioral_realism",
                "entity_integrity",
            ):
                out[eval_name] = float(m.value)
    return out


def diagnose_journey_failure(result: RunResult) -> str:
    """Build a human-readable explanation of why journey_success is False.

    Reads from result.metric_results (flattened) and the story DAG.
    """
    ground_truth = result.spec.story
    all_graph_nodes = set(ground_truth.goals.keys())
    for children in ground_truth.goals.values():
        all_graph_nodes.update(children)

    correct_tools = set(
        result.metric_results.get("correct_tool_calls", []) or []
    )
    matched_text: set[str] = set()
    text_match_value = result.metric_results.get("text_match")

    achieved = correct_tools | matched_text
    missing = all_graph_nodes - achieved

    if not missing:
        return "tool call ordering violated dependency graph"

    tool_goals = {
        gd.name
        for gd in ground_truth.goal_details
        if gd.type == ContentType.tool_call
    }
    text_goals = {
        gd.name
        for gd in ground_truth.goal_details
        if gd.type == ContentType.text
    }
    missing_tools = missing & tool_goals
    missing_text = missing & text_goals

    parts = []
    if missing_tools:
        parts.append(f"missing/wrong tool calls: {sorted(missing_tools)}")
    if missing_text:
        parts.append(
            f"text match failed for: {sorted(missing_text)} "
            f"(text_match={text_match_value!r})"
        )
    return "; ".join(parts) if parts else "unknown failure mode"


def detect_entity_hallucinations(
    messages,
    story: str,
    eval_provider: "Provider",
) -> list[HallucinationDetail]:
    """Post-hoc entity hallucination check via LLM-as-judge.

    Detects two categories of hallucination in user-simulator output:
      1. Fabricated values: entity values not in the story or agent
         messages.
      2. Entity type misattribution: a story value labelled with the
         wrong entity type (e.g., username said as employee ID).

    The user story is treated as a valid provenance source — any value
    that appears in it is known to the user and is not a hallucination.
    """
    user_messages = [m.content for m in messages if m.role == "user"]
    agent_text = [m.content for m in messages if m.role == "assistant"]
    if not user_messages:
        return []

    transcript = "\n".join(f"User: {m}" for m in user_messages)
    agent_context = "\n".join(agent_text)

    prompt = [
        {
            "role": "system",
            "content": (
                "You are an entity provenance auditor. Detect ENTITY "
                "hallucinations in user messages.\n\n"
                "An entity value is a concrete, factual identifier: a "
                "name, username, employee ID, assignment ID, date, "
                "number, or similar structured value.\n\n"
                "## CRITICAL: The user story is a VALID provenance source\n"
                "Any value in the user story is known to the user and "
                "is NEVER a hallucination.\n\n"
                "## Flag ONLY these two categories\n"
                "1. Fabricated value: user provides an entity value NOT "
                "in the story AND NOT communicated by the agent.\n"
                "2. Entity type misattribution: user takes a value from "
                "the story but labels it as a DIFFERENT entity type.\n\n"
                "## Only audit values the user ACTUALLY SAID\n"
                "Ignore values that don't appear in any user message.\n\n"
                "Respond ONLY with JSON: "
                '{"hallucinated_entities": [{"entity": "...", '
                '"value": "...", "user_utterance": "...", '
                '"reason": "..."}]}'
            ),
        },
        {
            "role": "user",
            "content": (
                f"## User Story (values here are KNOWN to the user)\n"
                f"{story}\n\n"
                f"## Agent Messages\n{agent_context}\n\n"
                f"## User Messages (check these for hallucinations)\n"
                f"{transcript}"
            ),
        },
    ]

    resp = eval_provider.chat(prompt)
    text = resp.choices[0].message.content.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1] if "\n" in text else text[3:]
    if text.endswith("```"):
        text = text[:-3]
    data = json.loads(text.strip())
    return [
        HallucinationDetail(
            entity=h.get("entity", ""),
            value=h.get("value", ""),
            user_utterance=h.get("user_utterance", ""),
            reason=h.get("reason", ""),
        )
        for h in data.get("hallucinated_entities", [])
    ]


# ---------------------------------------------------------------------------
# Role-switch detection
# ---------------------------------------------------------------------------
def detect_role_switch(
    messages,
    tools_spec: list[ToolSpec],
) -> list[RoleSwitchFlag]:
    """Detect role-switch in user messages by matching against the set
    of values that only the tools could provide.

    Algorithm:
      1. Build the agent-only fact set from tools.yaml mock outputs:
         for each mock, every leaf value in `output` that does NOT
         appear in `input` is "agent-only knowledge" (the user could
         only know it by getting it from a tool via the agent).
      2. For each user message, count how many distinct agent-only
         facts appear (case-insensitive substring match).
      3. If >= _ROLE_SWITCH_MIN_FACTS distinct facts match, flag the
         message as a role switch.

    The user simulator should never originate these values — the agent
    is supposed to deliver them in response to user requests.
    """
    fact_origins = _extract_agent_only_facts(tools_spec)
    if not fact_origins:
        return []

    flags: list[RoleSwitchFlag] = []
    for msg in messages:
        if msg.role != "user":
            continue
        content = str(msg.content)
        content_lower = content.lower()
        matches: list[tuple[str, str]] = []  # (value, origin_key)
        seen_values: set[str] = set()
        for fact, origin in fact_origins:
            fact_lower = fact.lower()
            if fact_lower in seen_values:
                continue
            if fact_lower in content_lower:
                matches.append((fact, origin))
                seen_values.add(fact_lower)
        if len(matches) >= _ROLE_SWITCH_MIN_FACTS:
            flags.append(
                RoleSwitchFlag(
                    matched_facts=[v for v, _ in matches],
                    fact_origins=[o for _, o in matches],
                    user_utterance=content[:300],
                )
            )
    return flags


def _extract_agent_only_facts(
    tools_spec: list[ToolSpec],
) -> list[tuple[str, str]]:
    """Return list of (value, origin_key) pairs for every leaf value in
    mock outputs that does not also appear in mock inputs.

    `origin_key` is the JSON key the value came from (or the tool name
    if the output isn't structured).
    """
    facts: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for tool in tools_spec:
        for mock in tool.mocks:
            input_values = {str(v).strip().lower() for v in mock.input.values()}
            parsed = _try_parse_json(mock.output)
            for value, origin in _walk_leaves(parsed, fallback_key=tool.name):
                value_str = str(value).strip()
                if not _is_useful_fact(value_str, input_values):
                    continue
                key = (value_str.lower(), origin)
                if key in seen:
                    continue
                seen.add(key)
                facts.append((value_str, origin))
    return facts


def _try_parse_json(text: str) -> Any:
    """Attempt to parse text as JSON; return the raw string on failure."""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text


def _walk_leaves(
    obj: Any,
    fallback_key: str,
    parent_key: str | None = None,
) -> Iterable[tuple[Any, str]]:
    """Yield (leaf_value, origin_key) pairs from a nested JSON structure."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _walk_leaves(v, fallback_key, parent_key=k)
    elif isinstance(obj, list):
        for item in obj:
            yield from _walk_leaves(item, fallback_key, parent_key=parent_key)
    else:
        yield obj, parent_key or fallback_key


def _is_useful_fact(value: str, input_values: set[str]) -> bool:
    """Filter out noise: short tokens, pure punctuation, values that
    appear in mock inputs, common-English fragments."""
    if not value:
        return False
    if len(value) < _MIN_FACT_LENGTH:
        return False
    lower = value.lower().strip()
    if lower in input_values:
        return False
    # Skip values that are entirely punctuation/whitespace
    if not re.search(r"[A-Za-z0-9]", value):
        return False
    # Skip pure common boolean/null tokens
    if lower in {"true", "false", "null", "yes", "no", "n/a"}:
        return False
    return True
