"""Render human-readable conversation logs from a harness results.json.

Works on JSON produced by
`python -m agentops.benchmark_harness --include-conversations`, which
carries per-run `messages` and `spec.story`.

Usage:
    # Print to stdout
    python -m agentops.benchmark_harness.render_conversations \\
        results/hr_sample/results.json

    # Write to a file
    python -m agentops.benchmark_harness.render_conversations \\
        results/hr_sample/results.json \\
        -o results/hr_sample/conversations.log

Output format mirrors the per-run log blocks the standalone benchmarks
used to print, with a header (run label + story), the conversation
body, and a summary line including role-switch / hallucination flags
when applicable.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

BLOCK_HEADER = "=" * 70


def render(
    results_json_path: Path,
    output_path: Path | None = None,
) -> None:
    with open(results_json_path) as f:
        data = json.load(f)

    if not data.get("include_conversations"):
        print(
            f"ERROR: {results_json_path} was written without the "
            "--include-conversations flag; no message history or "
            "story text available. Re-run with "
            "`--include-conversations` and try again.",
            file=sys.stderr,
        )
        sys.exit(2)

    results = data.get("results", [])
    total = len(results)
    blocks: list[str] = []

    header = [
        f"Benchmark: {data.get('benchmark', '?')}",
        f"Timestamp: {data.get('timestamp', '?')}",
        f"Runs:      {total}",
        "",
    ]
    blocks.append("\n".join(header))

    for i, r in enumerate(results, 1):
        blocks.append(_render_run(i, total, r))

    text = "\n".join(blocks)
    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            f.write(text)
        print(f"Wrote: {output_path}")
    else:
        sys.stdout.write(text)
        sys.stdout.write("\n")


def _render_run(idx: int, total: int, r: dict) -> str:
    spec = r.get("spec", {})
    lines: list[str] = []
    label = (
        f"[{idx}/{total}] {spec.get('story_name', '?')} | "
        f"{spec.get('config_name', '?')} | "
        f"run {spec.get('run_index', 0) + 1}"
    )
    lines.append(BLOCK_HEADER)
    lines.append(f"  {label}")
    if "story" in spec:
        story_oneline = " ".join(spec["story"].split())
        lines.append(f"  Story: {story_oneline}")
    if "starting_sentence" in spec and spec["starting_sentence"]:
        lines.append(f"  Start: {spec['starting_sentence']}")
    lines.append(BLOCK_HEADER)

    messages = r.get("messages", [])
    lines.append(_format_conversation(messages))

    lines.append(_render_summary(r))
    lines.append("")
    return "\n".join(lines)


def _format_conversation(messages: list[dict]) -> str:
    """Pretty-print a conversation thread.

    Mirrors the format of _format_conversation() in the standalone
    benchmarks: User / Agent / Tool-call → result lines.
    """
    lines: list[str] = []
    pending_calls: dict[str, str] = {}
    for msg in messages:
        role = msg.get("role")
        content = msg.get("content") or ""
        if role == "user":
            lines.append(f"\U0001f464 User: {content}")
        elif role == "assistant":
            tool_calls = msg.get("tool_calls")
            if tool_calls:
                for tc in tool_calls:
                    tcid = tc.get("id") or ""
                    fn = tc.get("function") or {}
                    fn_name = fn.get("name", "?")
                    fn_args = fn.get("arguments", "")
                    pending_calls[tcid] = f"{fn_name}({fn_args})"
            elif str(content).strip():
                lines.append(f"\U0001f916 Agent: {content}")
        elif role == "tool":
            tcid = msg.get("tool_call_id", "")
            sig = pending_calls.pop(tcid, None)
            if sig:
                lines.append(f"\U0001f527 {sig} -> {content}")
            else:
                lines.append(f"\U0001f527 Tool: {content}")
    return "\n".join(lines)


def _render_summary(r: dict) -> str:
    custom = r.get("custom", {}) or {}
    parts = [
        f"  -> journey_success={r.get('journey_success')}",
        f"steps={r.get('total_steps', 0)}",
        f"user_turns={r.get('user_turns', 0)}",
        f"termination={r.get('termination_reason', '?')}",
        f"guardrail_hits={len(r.get('guardrail_notes') or [])}",
    ]
    summary = ", ".join(parts)

    extras: list[str] = []
    if custom.get("journey_failure_reason"):
        extras.append(
            f"  -> FAILURE REASON: {custom['journey_failure_reason']}"
        )
    rs_flags = custom.get("role_switch_flags") or []
    if rs_flags:
        extras.append(
            f"  -> ROLE SWITCH DETECTED ({len(rs_flags)} occurrence"
            f"{'s' if len(rs_flags) != 1 else ''})"
        )
        for flag in rs_flags:
            facts = ", ".join(
                f"{v} (from {k})"
                for v, k in zip(
                    flag.get("matched_facts") or [],
                    flag.get("fact_origins") or [],
                )
            )
            extras.append(f"     [{facts}]")
    halluc = custom.get("hallucination_details") or []
    if halluc:
        extras.append(f"  -> HALLUCINATIONS ({len(halluc)} detected)")
        for h in halluc:
            extras.append(
                f"     entity={h.get('entity')!r} "
                f"value={h.get('value')!r} "
                f"reason={h.get('reason')!r}"
            )
    if "goal_interference" in custom:
        extras.append(
            f"  -> persona scores: "
            f"goal_interference={custom.get('goal_interference'):.2f} "
            f"behavioral_realism={custom.get('behavioral_realism'):.2f} "
            f"entity_integrity={custom.get('entity_integrity'):.2f}"
        )

    if extras:
        summary = summary + "\n" + "\n".join(extras)
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m agentops.benchmark_harness.render_conversations",
        description=(
            "Render human-readable conversation logs from a harness "
            "results.json produced with --include-conversations."
        ),
    )
    parser.add_argument(
        "results_json",
        help="Path to results.json written by the harness.",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help=(
            "Output path for the rendered log. Defaults to stdout. "
            "Suggested convention: results/<benchmark>/conversations.log."
        ),
    )
    args = parser.parse_args(argv)
    render(
        Path(args.results_json),
        Path(args.output) if args.output else None,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
