"""Data models for the benchmark harness."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from agentops.type import Message, TestCase

if TYPE_CHECKING:
    from agentops.benchmark_harness.extension import BenchmarkExtension


@dataclass
class ParamSpec:
    type: str  # "string" | "integer" | "number" | "boolean"
    description: str = ""


@dataclass
class MockEntry:
    input: dict[str, str]
    output: str


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, ParamSpec]
    mocks: list[MockEntry] = field(default_factory=list)
    returns: ParamSpec | None = None
    default_error: str = "Error: unrecognized input"


@dataclass
class AgentSpec:
    name: str
    description: str
    instructions: str
    tools: list[str]


@dataclass
class SimConfig:
    name: str
    structured_output: bool = False
    guardrails: bool = False
    persona: str | None = None


@dataclass
class ModelMatrix:
    agent: list[str]
    user_sim: list[str]
    eval: list[str]


@dataclass
class MatrixConfig:
    configs: list[SimConfig]
    models: ModelMatrix
    frameworks: list[str]


@dataclass
class BenchmarkConfig:
    name: str
    description: str
    matrix: MatrixConfig
    stories_pattern: str
    metrics: list[str]
    runs_per_combo: int
    max_user_turns: int
    workers: int
    benchmark_dir: Path
    tools_spec: list[ToolSpec]
    agent_spec: AgentSpec
    stories: list[TestCase]
    extension: "BenchmarkExtension | None" = None


@dataclass
class RunSpec:
    benchmark_name: str
    story: TestCase
    story_name: str
    config: SimConfig
    agent_model: str
    user_sim_model: str
    eval_model: str
    framework: str
    run_index: int
    max_user_turns: int
    service_url: str = ""


@dataclass
class RunResult:
    spec: RunSpec
    journey_success: bool = False
    total_steps: int = 0
    user_turns: int = 0
    termination_reason: str = "max_turns"
    guardrail_notes: list[str] = field(default_factory=list)
    metric_results: dict[str, Any] = field(default_factory=dict)
    messages: list[Message] = field(default_factory=list)
    # Extension-provided custom data (intentionally untyped)
    custom: dict[str, Any] = field(default_factory=dict)
