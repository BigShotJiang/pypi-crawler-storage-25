"""BenchmarkExtension base class."""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from agentops.benchmark_harness.types import AgentSpec, RunResult, ToolSpec
    from agentops.metrics.evaluations import Evaluation
    from agentops.runtime_adapter.runtime_adapter import RuntimeAdapter
    from agentops.service_provider.provider import Provider


class BenchmarkExtension:
    """Base class for benchmark extensions. All hooks are no-ops.

    Override only the hooks your benchmark needs.
    """

    def create_agent(
        self,
        tools: list[Callable],
        agent_spec: "AgentSpec",
        model: str,
        framework: str,
    ) -> "RuntimeAdapter | None":
        """Override agent construction. Return None to fall back to default."""
        return None

    def create_tools(
        self,
        tools_spec: "list[ToolSpec]",
        framework: str,
    ) -> "list[Callable] | None":
        """Override tool construction. Return None to fall back to default."""
        return None

    def post_run(
        self,
        result: "RunResult",
        eval_provider: "Provider",
    ) -> None:
        """Called after each conversation run. Mutate result.custom."""
        pass

    def custom_metrics(
        self,
        eval_provider: "Provider",
    ) -> "list[Evaluation]":
        """Return additional Evaluation instances."""
        return []

    def post_report(self, all_results: "list[RunResult]") -> None:
        """Called after standard report is printed."""
        pass
