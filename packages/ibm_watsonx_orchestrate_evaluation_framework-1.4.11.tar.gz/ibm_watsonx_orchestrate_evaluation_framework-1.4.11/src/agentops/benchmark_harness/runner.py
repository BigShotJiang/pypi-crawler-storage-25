"""Benchmark runner functionality for benchmark harness."""

from __future__ import annotations

import sys
from pathlib import Path

from rich.console import Console

# Exit codes
EXIT_OK = 0
EXIT_VALIDATION = 1
EXIT_IO = 2
EXIT_FRAMEWORK = 3
EXIT_EVALUATION = 4
from agentops.benchmark_harness.executor import execute_runs
from agentops.benchmark_harness.loader import (
    BenchmarkValidationError,
    discover_benchmarks,
    load_benchmark,
    load_harness_defaults,
)
from agentops.benchmark_harness.planner import plan_runs
from agentops.benchmark_harness.reporting import (
    report_benchmark,
    report_cross_benchmark,
)


def run_benchmarks(
    paths: list[str],
    defaults: str,
    output_dir: str,
    include_conversations: bool = False,
    framework: str | None = None,
) -> int:
    """Run benchmark harness with the given configuration.

    Args:
        paths: List of benchmark directories or parent directory
        defaults: Path to harness defaults YAML file
        output_dir: Base output directory for reports
        include_conversations: Whether to include full conversation transcripts

    Returns:
        Exit code (0 for success, non-zero for errors)
    """
    output_path = Path(output_dir)
    defaults_path = Path(defaults)

    try:
        harness_defaults = load_harness_defaults(defaults_path)
    except FileNotFoundError as e:
        print(f"[red]ERROR: {e}[/red]")
        return EXIT_IO
    except BenchmarkValidationError as e:
        print(f"[red]ERROR: invalid harness defaults: {e}[/red]")
        return EXIT_VALIDATION

    if framework is not None:
        harness_defaults["matrix"]["frameworks"] = framework

    try:
        benchmark_dirs = discover_benchmarks([Path(p) for p in paths])
    except Exception as e:
        print(f"[red]ERROR: benchmark discovery failed: {e}[/red]")
        return EXIT_IO

    if not benchmark_dirs:
        print("No benchmarks found.")
        return EXIT_OK

    print(f"Discovered {len(benchmark_dirs)} benchmark(s):")
    for d in benchmark_dirs:
        print(f"  - {d}")

    seen_names: set[str] = set()
    benchmark_results: dict[str, list] = {}

    for benchmark_dir in benchmark_dirs:
        try:
            cfg = load_benchmark(benchmark_dir, harness_defaults)
        except (FileNotFoundError,) as e:
            print(f"[red]ERROR: missing file in {benchmark_dir}: {e}[/red]")
            return EXIT_IO
        except BenchmarkValidationError as e:
            print(
                f"[red]ERROR: validation failed for {benchmark_dir}: {e}[/red]"
            )
            return EXIT_VALIDATION

        if cfg.name in seen_names:
            print(
                f"[red]ERROR: duplicate benchmark name '{cfg.name}' "
                f"(in {benchmark_dir})[/red]"
            )
            return EXIT_VALIDATION
        seen_names.add(cfg.name)

        try:
            specs = plan_runs(cfg)
            print(
                f"\n[{cfg.name}] planned {len(specs)} runs across "
                f"{len(cfg.stories)} stories x "
                f"{len(cfg.matrix.configs)} configs"
            )
            results = execute_runs(specs, cfg)
        except KeyError as e:
            print(
                f"[red]ERROR: framework or metric resolution failed "
                f"for {cfg.name}: {e}[/red]"
            )
            return EXIT_FRAMEWORK
        except Exception as e:
            print(f"[red]ERROR: execution failed for {cfg.name}: {e}[/red]")
            return EXIT_FRAMEWORK

        report_benchmark(
            cfg.name,
            results,
            cfg,
            output_path,
            include_conversations=include_conversations,
        )
        benchmark_results[cfg.name] = results

    if len(benchmark_results) > 1:
        report_cross_benchmark(benchmark_results)

    return EXIT_OK


# Made with Bob
