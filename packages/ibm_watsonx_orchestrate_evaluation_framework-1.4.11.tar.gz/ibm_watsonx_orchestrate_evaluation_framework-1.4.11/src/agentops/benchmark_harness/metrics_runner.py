"""Resolve metric names, build instances, run them in dependency order."""

from __future__ import annotations

from collections import defaultdict, deque
from typing import TYPE_CHECKING, Any

from agentops.extractors.extractor_base import Extractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.journey_success import JourneySuccessMetric
from agentops.metrics.persona_behavior_evaluation import (
    PersonaBehaviorEvaluation,
)
from agentops.metrics.steps import StepMetrics
from agentops.operator.operator_base import OperatorBase
from agentops.type import Message, TestCase

if TYPE_CHECKING:
    from agentops.benchmark_harness.extension import BenchmarkExtension
    from agentops.service_provider.provider import Provider


# Built-in metric registry — names map to classes that take (llm_client=...)
METRIC_REGISTRY: dict[str, type[Evaluation]] = {
    "JourneySuccessMetric": JourneySuccessMetric,
    "StepMetrics": StepMetrics,
    "PersonaBehaviorEvaluation": PersonaBehaviorEvaluation,
}


def resolve_metrics(
    metric_names: list[str],
    eval_provider: "Provider",
    extension: "BenchmarkExtension | None" = None,
) -> list[Evaluation]:
    """Build Evaluation instances from metric identifiers.

    - Plain name (e.g., "JourneySuccessMetric"): look up in METRIC_REGISTRY.
    - "benchmark_ext:ClassName": look up attribute on extension module.

    Note: Static instantiation only. Run-context-dependent metrics
    (e.g., PersonaBehaviorEvaluation needing per-run config) should
    be added by the extension's post_run() hook.
    """
    metrics: list[Evaluation] = []
    for name in metric_names:
        if name.startswith("benchmark_ext:"):
            if extension is None:
                raise KeyError(
                    f"metric '{name}' requires an extension module, none loaded"
                )
            cls_name = name.split(":", 1)[1]
            ext_module = type(extension).__module__
            import sys

            module = sys.modules.get(ext_module)
            if module is None:
                raise KeyError(
                    f"extension module not found in sys.modules: {ext_module}"
                )
            cls = getattr(module, cls_name, None)
            if cls is None:
                raise KeyError(
                    f"extension module has no attribute '{cls_name}'"
                )
            metrics.append(cls(llm_client=eval_provider))
        else:
            cls = METRIC_REGISTRY.get(name)
            if cls is None:
                raise KeyError(
                    f"unknown metric '{name}' "
                    f"(known: {sorted(METRIC_REGISTRY.keys())})"
                )
            # JourneySuccessMetric needs is_strict=False to match the
            # behavior of the existing benchmarks
            if cls is JourneySuccessMetric:
                metrics.append(cls(is_strict=False, llm_client=eval_provider))
            elif cls is StepMetrics:
                metrics.append(cls())
            else:
                metrics.append(cls(llm_client=eval_provider))
    return metrics


def run_metrics(
    metrics: list[Evaluation],
    messages: list[Message],
    ground_truth: TestCase,
) -> dict[str, Any]:
    """Execute metrics in dependency order. Returns context dict.

    Algorithm (from existing benchmarks):
      1. BFS to gather all transitive dependencies via op.dependencies.
      2. Topological sort via Kahn's algorithm.
      3. Execute in order; each operator receives accumulated context.
    """
    op_mapping: dict[Any, Any] = {}
    queue: deque = deque(list(metrics))
    while queue:
        op = queue.popleft()
        key = OperatorBase.key(op)
        if key in op_mapping:
            continue
        op_mapping[key] = op
        for dep in op.dependencies:
            if OperatorBase.key(dep) not in op_mapping:
                queue.append(dep)

    eval_dag: dict[Any, list] = defaultdict(list)
    in_degree: dict[Any, int] = defaultdict(int)
    for op in op_mapping.values():
        for dep in op.dependencies:
            eval_dag[OperatorBase.key(dep)].append(OperatorBase.key(op))
            in_degree[OperatorBase.key(op)] += 1
        if OperatorBase.key(op) not in in_degree:
            in_degree[OperatorBase.key(op)] = 0

    ordering: list[Any] = []
    q: deque = deque(k for k, v in in_degree.items() if v == 0)
    while q:
        k = q.popleft()
        ordering.append(k)
        for child in eval_dag[k]:
            in_degree[child] -= 1
            if in_degree[child] == 0:
                q.append(child)

    context: dict[str, dict] = {"extractor": {}, "metric": {}}
    for key in ordering:
        op = op_mapping[key]
        if isinstance(op, Extractor):
            op.extract(
                messages=messages,
                ground_truth=ground_truth,
                metadata={},
                extracted_context=context,
            )
        elif isinstance(op, Evaluation):
            op.evaluate(
                messages,
                ground_truth,
                metadata={},
                extracted_context=context,
            )
    return context
