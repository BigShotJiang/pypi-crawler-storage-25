"""Provision tools and agents on Watson Orchestrate for benchmark runs."""

from __future__ import annotations

import atexit
import logging
import shutil
import subprocess
import tempfile
import textwrap
import threading
from pathlib import Path
from typing import TYPE_CHECKING

import yaml

from agentops.utils.utils import is_saas_url

if TYPE_CHECKING:
    from agentops.benchmark_harness.types import AgentSpec, ToolSpec
    from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter

logger = logging.getLogger(__name__)

_WXO_TYPE_MAP: dict[str, str] = {
    "string": "str",
    "integer": "int",
    "number": "float",
    "boolean": "bool",
}

_provisioned: dict[str, "WXORuntimeAdapter"] = {}
_provisioners: dict[str, "WXOProvisioner"] = {}
_lock = threading.Lock()


class WXOProvisioningError(Exception):
    """Raised when WXO provisioning fails."""


class WXOProvisioner:
    """Provisions tools and agents on a Watson Orchestrate instance."""

    def __init__(
        self,
        service_url: str,
        api_key: str,
        wxo_llm: str,
    ) -> None:
        self.service_url = service_url
        self.api_key = api_key
        self.wxo_llm = wxo_llm
        self._is_local = not is_saas_url(service_url)
        self._tool_names: list[str] = []
        self._tmp_dir = Path(tempfile.mkdtemp(prefix="agentops_wxo_"))
        self._env_name: str | None = None
        atexit.register(self._atexit_cleanup)

    def provision(
        self,
        agent_spec: "AgentSpec",
        tools_spec: "list[ToolSpec]",
    ) -> "WXORuntimeAdapter":
        """Generate files, import tools/agent, deploy, return adapter."""
        self._tool_names = [spec.name for spec in tools_spec]
        try:
            self._setup_environment(agent_spec.name)
            self._pre_clean(agent_spec.name)

            tool_files = self._generate_tool_files(tools_spec)
            for tf in tool_files:
                self._import_tool(tf)

            agent_yaml = self._generate_agent_yaml(agent_spec)
            self._import_agent(agent_yaml)
            if not self._is_local:
                self._deploy_agent(agent_spec.name)

            return self._create_runtime_adapter()
        except Exception:
            logger.exception("WXO provisioning failed — attempting cleanup")
            self.cleanup(agent_spec.name)
            raise

    def cleanup(self, agent_name: str) -> None:
        """Best-effort removal of agent/tools, env, and temp files."""
        # 1. Undeploy the agent first (not supported on Developer Edition)
        if not self._is_local:
            try:
                self._run_cli(
                    ["orchestrate", "agents", "undeploy", "-n", agent_name],
                    check=False,
                )
            except Exception:
                logger.debug(
                    "agent undeploy failed (may not exist)", exc_info=True
                )

        # 2. Remove the agent (--kind native is required)
        try:
            self._run_cli(
                [
                    "orchestrate",
                    "agents",
                    "remove",
                    "-n",
                    agent_name,
                    "-k",
                    "native",
                ],
                check=False,
            )
        except Exception:
            logger.debug("agent cleanup failed (may not exist)", exc_info=True)

        # 3. Remove each provisioned tool
        for tool_name in getattr(self, "_tool_names", []):
            try:
                self._run_cli(
                    ["orchestrate", "tools", "remove", "-n", tool_name],
                    check=False,
                )
            except Exception:
                logger.debug(
                    "tool cleanup failed for %s", tool_name, exc_info=True
                )

        # 4. Remove the environment (skip for Developer Edition's built-in "local")
        if self._env_name and not self._is_local:
            try:
                self._run_cli(
                    ["orchestrate", "env", "remove", "-n", self._env_name],
                    check=False,
                )
            except Exception:
                logger.debug(
                    "env cleanup failed (may not exist)", exc_info=True
                )

        if self._tmp_dir.exists():
            shutil.rmtree(self._tmp_dir, ignore_errors=True)

    def _pre_clean(self, agent_name: str) -> None:
        """Remove stale agent/tools from a prior run (best-effort)."""
        self._run_cli(
            [
                "orchestrate",
                "agents",
                "remove",
                "-n",
                agent_name,
                "-k",
                "native",
            ],
            check=False,
        )
        for tool_name in self._tool_names:
            self._run_cli(
                ["orchestrate", "tools", "remove", "-n", tool_name],
                check=False,
            )

    # ------------------------------------------------------------------
    # Environment setup
    # ------------------------------------------------------------------

    def _setup_environment(self, agent_name: str) -> None:
        if self._is_local:
            self._env_name = "local"
            self._run_cli(["orchestrate", "env", "activate", "local"])
            return

        env_name = f"harness-{agent_name}"
        self._env_name = env_name

        self._run_cli(
            [
                "orchestrate",
                "env",
                "add",
                "-n",
                env_name,
                "-u",
                self.service_url,
                "--type",
                "ibm_iam",
            ],
            check=False,
        )

        self._run_cli(
            [
                "orchestrate",
                "env",
                "activate",
                env_name,
                "--api-key",
                self.api_key,
            ],
        )

    # ------------------------------------------------------------------
    # Tool file generation
    # ------------------------------------------------------------------

    def _generate_tool_files(self, tools_spec: "list[ToolSpec]") -> list[Path]:
        """Generate one Python @tool() file per ToolSpec."""
        files: list[Path] = []
        for spec in tools_spec:
            source = self._render_tool_source(spec)
            path = self._tmp_dir / f"{spec.name}_tool.py"
            path.write_text(source, encoding="utf-8")
            files.append(path)
        return files

    def _render_tool_source(self, spec: "ToolSpec") -> str:
        """Render a single ToolSpec as a Python source file."""
        params = []
        for pname, pspec in spec.parameters.items():
            py_type = _WXO_TYPE_MAP.get(pspec.type, "str")
            params.append(f"{pname}: {py_type}")
        ret_type = "str"
        if spec.returns:
            ret_type = _WXO_TYPE_MAP.get(spec.returns.type, "str")
        sig = ", ".join(params)

        # Docstring
        doc_lines = [f'    """{spec.description}']
        if spec.parameters:
            doc_lines.append("")
            doc_lines.append("    Args:")
            for pname, pspec in spec.parameters.items():
                py_type = _WXO_TYPE_MAP.get(pspec.type, "str")
                desc = pspec.description or pname
                doc_lines.append(f"        {pname} ({py_type}): {desc}")
        doc_lines.append('    """')
        docstring = "\n".join(doc_lines)

        # Mock dispatch body
        body_lines: list[str] = []
        if spec.mocks:
            mocks_repr = ", ".join(
                f"({repr(m.input)}, {repr(m.output)})" for m in spec.mocks
            )
            kw_items = ", ".join(
                f"{repr(pname)}: str({pname})" for pname in spec.parameters
            )
            body_lines.append(
                textwrap.dedent(
                    f"""\
                _mocks = [{mocks_repr}]
                _kwargs = {{{kw_items}}}
                _best_score, _best_output = -1, None
                for _mock_input, _mock_output in _mocks:
                    _score, _matched = 0, True
                    for _key, _expected in _mock_input.items():
                        if _key not in _kwargs or str(_kwargs[_key]) != str(_expected):
                            _matched = False
                            break
                        _score += 1
                    if _matched and _score > _best_score:
                        _best_score, _best_output = _score, _mock_output
                if _best_output is not None:
                    return _best_output"""
                )
            )

        body_lines.append(f"return {repr(spec.default_error)}")
        body = textwrap.indent("\n".join(body_lines), "    ")

        return (
            f"from ibm_watsonx_orchestrate.agent_builder.tools import tool\n"
            f"\n"
            f"\n"
            f"@tool()\n"
            f"def {spec.name}({sig}) -> {ret_type}:\n"
            f"{docstring}\n"
            f"{body}\n"
        )

    # ------------------------------------------------------------------
    # Agent YAML generation
    # ------------------------------------------------------------------

    def _generate_agent_yaml(self, agent_spec: "AgentSpec") -> Path:
        """Generate a WXO-format agent.yaml."""
        data = {
            "spec_version": "v1",
            "kind": "native",
            "name": agent_spec.name,
            "description": agent_spec.description,
            "llm": self.wxo_llm,
            "style": "default",
            "instructions": agent_spec.instructions,
            "tools": list(agent_spec.tools),
            "collaborators": [],
        }
        path = self._tmp_dir / "agent.yaml"
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
        return path

    # ------------------------------------------------------------------
    # CLI operations
    # ------------------------------------------------------------------

    def _import_tool(self, tool_file: Path) -> None:
        self._run_cli(
            [
                "orchestrate",
                "tools",
                "import",
                "-f",
                str(tool_file),
                "-k",
                "python",
            ],
        )

    def _import_agent(self, agent_yaml: Path) -> None:
        self._run_cli(
            ["orchestrate", "agents", "import", "-f", str(agent_yaml)],
        )

    def _deploy_agent(self, agent_name: str) -> None:
        self._run_cli(
            ["orchestrate", "agents", "deploy", "-n", agent_name],
        )

    def _run_cli(
        self,
        args: list[str],
        check: bool = True,
        timeout: int | None = None,
    ) -> subprocess.CompletedProcess:
        if timeout is None:
            timeout = 120 if self._is_local else 300
        logger.info("wxo-cli: %s", " ".join(args))
        try:
            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=timeout,
                input="Y\n",
            )
        except FileNotFoundError:
            raise WXOProvisioningError(
                "orchestrate CLI not found. "
                "Install with: pip install 'ibm-watsonx-orchestrate>=2.1.0'"
            )
        except subprocess.TimeoutExpired:
            raise WXOProvisioningError(
                f"orchestrate CLI timed out after {timeout}s: "
                f"{' '.join(args)}"
            )

        if check and result.returncode != 0:
            raise WXOProvisioningError(
                f"orchestrate CLI failed (exit {result.returncode}):\n"
                f"  command: {' '.join(args)}\n"
                f"  stdout: {result.stdout.strip()}\n"
                f"  stderr: {result.stderr.strip()}"
            )
        return result

    # ------------------------------------------------------------------
    # Runtime adapter creation
    # ------------------------------------------------------------------

    def _create_runtime_adapter(self) -> "WXORuntimeAdapter":
        from agentops.runtime_adapter.wxo_runtime_adapter import (
            WXORuntimeAdapter,
        )
        from agentops.wxo_client import get_wxo_client

        wxo_client = get_wxo_client(
            service_url=self.service_url,
            tenant_name=self._env_name or "local",
        )
        return WXORuntimeAdapter(wxo_client=wxo_client)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _atexit_cleanup(self) -> None:
        if self._tmp_dir.exists():
            shutil.rmtree(self._tmp_dir, ignore_errors=True)


# ------------------------------------------------------------------
# Module-level caching (thread-safe)
# ------------------------------------------------------------------


def get_or_provision(
    agent_spec: "AgentSpec",
    tools_spec: "list[ToolSpec]",
    service_url: str,
    api_key: str,
    wxo_llm: str,
) -> "WXORuntimeAdapter":
    """Return a cached WXORuntimeAdapter, provisioning on first call.

    Provisioning is serialized under a lock because the orchestrate CLI
    writes to a shared config file (~/.config/orchestrate/config.yaml)
    that corrupts under concurrent access.
    """
    key = agent_spec.name
    with _lock:
        if key in _provisioned:
            return _provisioned[key]

        provisioner = WXOProvisioner(
            service_url=service_url,
            api_key=api_key,
            wxo_llm=wxo_llm,
        )
        adapter = provisioner.provision(agent_spec, tools_spec)
        _provisioned[key] = adapter
        _provisioners[key] = provisioner
        return adapter


def cleanup_all() -> None:
    """Clean up all provisioned WXO agents. Called after benchmark runs."""
    with _lock:
        for name, provisioner in _provisioners.items():
            try:
                provisioner.cleanup(name)
            except Exception:
                logger.debug("cleanup failed for %s", name, exc_info=True)
        _provisioned.clear()
        _provisioners.clear()
