"""Aggregation, table output, JSON serialization."""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agentops.benchmark_harness.types import BenchmarkConfig, RunResult, RunSpec
from agentops.type import Message

logger = logging.getLogger(__name__)


def report_benchmark(
    benchmark_name: str,
    results: list[RunResult],
    config: BenchmarkConfig,
    output_dir: Path,
    include_conversations: bool = False,
) -> None:
    """Write report to stdout and JSON to output_dir.

    When `include_conversations=True`, the JSON payload additionally
    carries the full message history and story text for each run,
    enabling the `render_conversations` utility to produce a
    human-readable conversation log.
    """
    if not results:
        print(f"\n[{benchmark_name}] no results")
        return

    print(f"\n{'=' * 80}")
    print(f"Benchmark: {benchmark_name} — {len(results)} runs")
    print(f"  {config.description}")
    print(f"  {datetime.now(timezone.utc).isoformat()}")
    print(f"{'=' * 80}\n")

    by_config = aggregate_by_config(results)
    _print_table_by_config(by_config)

    by_complexity = aggregate_by_complexity(results)
    if by_complexity:
        print("\nBy story complexity:")
        _print_table_by_key(by_complexity, key_label="Complexity")

    by_model = aggregate_by_model(results)
    if len(by_model) > 1:
        print("\nBy model combo (agent | user_sim | eval):")
        _print_table_by_key(by_model, key_label="Models")

    # Universal user-sim diagnostic sections — auto-skipped when not
    # applicable. These pair with run_user_sim_analysis() in executor.
    _print_before_after(results)
    _print_persona_criteria(results)
    _print_hallucination_details(results)
    _print_role_switch_summary(results)

    # Extension-provided report section
    if config.extension is not None:
        try:
            config.extension.post_report(results)
        except Exception as e:
            logger.warning(f"extension.post_report failed: {e}")

    # JSON output
    out_dir = output_dir / benchmark_name
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "results.json"
    payload = _build_json_payload(
        benchmark_name,
        results,
        config,
        include_conversations=include_conversations,
    )
    with open(out_path, "w") as f:
        json.dump(payload, f, indent=2, default=_json_default)
    print(f"\nWrote: {out_path}")


def report_cross_benchmark(
    benchmark_results: dict[str, list[RunResult]],
) -> None:
    """Print cross-benchmark summary table — journey success % by config."""
    if len(benchmark_results) < 2:
        return

    # Collect all config names across benchmarks (preserve discovery order)
    seen: set[str] = set()
    config_order: list[str] = []
    for results in benchmark_results.values():
        for r in results:
            if r.spec.config.name not in seen:
                seen.add(r.spec.config.name)
                config_order.append(r.spec.config.name)

    print(f"\n{'=' * 80}")
    print("Cross-Benchmark Summary — journey_success %")
    print(f"{'=' * 80}")

    header = f"{'Benchmark':<20} " + " ".join(f"{c:>14}" for c in config_order)
    print(header)
    print("-" * len(header))

    for bench_name, results in benchmark_results.items():
        row = f"{bench_name:<20} "
        grouped: dict[str, list[RunResult]] = defaultdict(list)
        for r in results:
            grouped[r.spec.config.name].append(r)
        for cfg in config_order:
            runs = grouped.get(cfg, [])
            if not runs:
                row += f"{'-':>14} "
            else:
                pct = (
                    sum(1 for r in runs if r.journey_success) / len(runs) * 100
                )
                row += f"{pct:>13.0f}% "
        print(row)
    print("=" * 80)


def aggregate_by_config(results: list[RunResult]) -> dict[str, dict[str, Any]]:
    """Group by sim config name; compute success %, avg steps, guardrail hits."""
    grouped: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        grouped[r.spec.config.name].append(r)

    out: dict[str, dict[str, Any]] = {}
    for name, runs in grouped.items():
        out[name] = {
            "runs": len(runs),
            "journey_success_pct": _success_pct(runs),
            "avg_steps": _avg([r.total_steps for r in runs]),
            "avg_user_turns": _avg([r.user_turns for r in runs]),
            "guardrail_hits": sum(len(r.guardrail_notes) for r in runs),
            "terminations": _termination_counts(runs),
        }
    return out


def aggregate_by_complexity(
    results: list[RunResult],
) -> dict[str, dict[str, Any]]:
    """Group by spec.story.complexity (skipped if all stories lack the field)."""
    grouped: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        # The story is a TestCase — complexity may be absent
        complexity = getattr(r.spec.story, "complexity", None)
        if complexity is None:
            continue
        grouped[str(complexity)].append(r)

    if not grouped:
        return {}

    return {
        name: {
            "runs": len(runs),
            "journey_success_pct": _success_pct(runs),
            "avg_steps": _avg([r.total_steps for r in runs]),
        }
        for name, runs in grouped.items()
    }


def aggregate_by_model(
    results: list[RunResult],
) -> dict[str, dict[str, Any]]:
    """Group by (agent, user_sim, eval) tuple as a single string key."""
    grouped: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        key = (
            f"{r.spec.agent_model} | "
            f"{r.spec.user_sim_model} | "
            f"{r.spec.eval_model}"
        )
        grouped[key].append(r)

    if len(grouped) <= 1:
        return {}

    return {
        key: {
            "runs": len(runs),
            "journey_success_pct": _success_pct(runs),
            "avg_steps": _avg([r.total_steps for r in runs]),
        }
        for key, runs in grouped.items()
    }


def format_conversation(messages: list[Message]) -> str:
    """Pretty-print a conversation thread."""
    lines: list[str] = []
    pending_calls: dict[str, str] = {}
    for msg in messages:
        if msg.role == "user":
            lines.append(f"\U0001f464 User: {msg.content}")
        elif msg.role == "assistant":
            if getattr(msg, "tool_calls", None):
                for tc in msg.tool_calls:
                    fn = tc.function
                    pending_calls[tc.id] = f"{fn.name}({fn.arguments})"
            elif msg.content and str(msg.content).strip():
                lines.append(f"\U0001f916 Agent: {msg.content}")
        elif msg.role == "tool":
            sig = pending_calls.pop(getattr(msg, "tool_call_id", ""), None)
            if sig:
                lines.append(f"\U0001f527 {sig} -> {msg.content}")
            else:
                lines.append(f"\U0001f527 Tool: {msg.content}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Universal user-sim diagnostic report sections
# ---------------------------------------------------------------------------
def _print_before_after(results: list[RunResult]) -> None:
    """BEFORE vs AFTER comparison — only when both legacy and structured
    configs are present.
    """
    grouped: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        grouped[r.spec.config.name].append(r)
    legacy_runs = grouped.get("legacy", [])
    structured_runs = grouped.get("structured", [])
    if not (legacy_runs and structured_runs):
        return

    print("\nBEFORE vs AFTER (legacy vs structured + guardrails)")
    print("-" * 60)
    print(
        f"  Journey success:  legacy={_success_pct(legacy_runs):.1f}%  "
        f"structured={_success_pct(structured_runs):.1f}%"
    )
    legacy_steps = _avg([r.total_steps for r in legacy_runs])
    struct_steps = _avg([r.total_steps for r in structured_runs])
    print(
        f"  Avg steps:        legacy={legacy_steps:.1f}  "
        f"structured={struct_steps:.1f}"
    )
    legacy_goal_term = sum(
        1
        for r in legacy_runs
        if r.termination_reason in ("satisfied", "failed")
    )
    struct_goal_term = sum(
        1
        for r in structured_runs
        if r.termination_reason in ("satisfied", "failed")
    )
    print(
        f"  Goal-aware termination: "
        f"legacy={legacy_goal_term}/{len(legacy_runs)}  "
        f"structured={struct_goal_term}/{len(structured_runs)}"
    )
    struct_gr = sum(len(r.guardrail_notes) for r in structured_runs)
    print(
        f"  Guardrail activations: {struct_gr}  "
        f"(only available with structured output)"
    )
    legacy_h = sum(
        len(r.custom.get("hallucination_details", [])) for r in legacy_runs
    )
    struct_h = sum(
        len(r.custom.get("hallucination_details", [])) for r in structured_runs
    )
    print(
        f"  Entity hallucinations: " f"legacy={legacy_h}  structured={struct_h}"
    )


def _print_persona_criteria(results: list[RunResult]) -> None:
    """Persona pass/fail criteria — only when persona configs are present.

    Uses 'structured' as the reference baseline if present, else 'legacy'.
    """
    grouped: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        grouped[r.spec.config.name].append(r)

    persona_names = {"cooperative", "confused", "adversarial"}
    present_personas = persona_names & set(grouped.keys())
    if not present_personas:
        return

    ref_runs = grouped.get("structured") or grouped.get("legacy") or []
    ref_s = _success_pct_fraction(ref_runs)
    ref_steps = _avg([r.total_steps for r in ref_runs])

    print("\nPERSONA SUCCESS CRITERIA")
    print("-" * 60)
    if not ref_runs:
        print("  (no reference runs — skipping comparison)")
        return

    for persona in ("cooperative", "confused", "adversarial"):
        runs = grouped.get(persona, [])
        if not runs:
            continue
        s = _success_pct_fraction(runs)
        gi = _avg_custom(runs, "goal_interference")
        steps = _avg([r.total_steps for r in runs])
        if persona == "cooperative":
            ok = s >= ref_s * 0.8 and steps <= ref_steps * 1.3
            print(
                f"  {persona}: success={s:.0%} (~ref {ref_s:.0%}), "
                f"steps={steps:.1f} (~ref {ref_steps:.1f}) "
                f"-> {'PASS' if ok else 'FAIL'}"
            )
        elif persona == "confused":
            ok = s >= ref_s * 0.5 and gi >= 0.5
            print(
                f"  {persona}: success={s:.0%} "
                f"(>=50% of ref {ref_s:.0%}), "
                f"goal_interference={gi:.2f} (>=0.5) "
                f"-> {'PASS' if ok else 'FAIL'}"
            )
        elif persona == "adversarial":
            ok = s > 0 and gi >= 0.3
            print(
                f"  {persona}: success={s:.0%} (>0%), "
                f"goal_interference={gi:.2f} (>=0.3) "
                f"-> {'PASS' if ok else 'FAIL'}"
            )


def _print_hallucination_details(results: list[RunResult]) -> None:
    """Per-run hallucination details — only when any were detected."""
    all_h = []
    for r in results:
        for h in r.custom.get("hallucination_details", []):
            all_h.append((r.spec.config.name, r.spec.story_name, h))
    if not all_h:
        return

    print(f"\nENTITY HALLUCINATION DETAILS ({len(all_h)} total)")
    print("-" * 80)
    for i, (cfg, story, h) in enumerate(all_h, 1):
        print(f"  [{i}] {cfg} | {story}")
        print(f"      Entity: {h.get('entity')}  Value: {h.get('value')}")
        print(f"      Reason: {h.get('reason')}")
        print(f"      Utterance: {h.get('user_utterance')}")


def _print_role_switch_summary(results: list[RunResult]) -> None:
    """Role-switch summary — only when any user message contained
    multiple values that originated only in tool outputs.
    """
    grouped: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        grouped[r.spec.config.name].append(r)

    has_any = any(r.custom.get("role_switch_flags") for r in results)
    if not has_any:
        return

    print("\nROLE-SWITCH OCCURRENCE BY CONFIG")
    print("-" * 60)
    for cfg_name in sorted(grouped.keys()):
        runs = grouped[cfg_name]
        n_with_flags = sum(1 for r in runs if r.custom.get("role_switch_flags"))
        print(
            f"  {cfg_name:<14} {n_with_flags}/{len(runs)} runs "
            f"exhibited role switch"
        )

    all_flags = []
    for r in results:
        for flag in r.custom.get("role_switch_flags", []):
            all_flags.append((r.spec.config.name, r.spec.story_name, flag))

    print(f"\nROLE-SWITCH DETAILS ({len(all_flags)} total)")
    print("-" * 80)
    for i, (cfg, story, flag) in enumerate(all_flags, 1):
        facts = ", ".join(
            f"{v} (from {k})"
            for v, k in zip(
                flag.get("matched_facts", []),
                flag.get("fact_origins", []),
            )
        )
        utterance = flag.get("user_utterance", "")
        print(f"  [{i}] {cfg} | {story}")
        print(f"      Tool-only facts in user message: {facts}")
        print(f"      Utterance: {utterance}")


def _success_pct_fraction(runs: list[RunResult]) -> float:
    """Success rate as 0.0..1.0 (the persona criteria comparisons want
    fractions, not percentages)."""
    if not runs:
        return 0.0
    return sum(1 for r in runs if r.journey_success) / len(runs)


def _avg_custom(runs: list[RunResult], key: str) -> float:
    """Average of result.custom[key] across runs, ignoring missing entries."""
    vals = [r.custom.get(key, 0.0) for r in runs if key in r.custom]
    if not vals:
        return 0.0
    return sum(vals) / len(vals)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _success_pct(runs: list[RunResult]) -> float:
    if not runs:
        return 0.0
    return round(sum(1 for r in runs if r.journey_success) / len(runs) * 100, 1)


def _avg(values: list[float]) -> float:
    if not values:
        return 0.0
    return round(sum(values) / len(values), 2)


def _termination_counts(runs: list[RunResult]) -> dict[str, int]:
    counts: dict[str, int] = defaultdict(int)
    for r in runs:
        counts[r.termination_reason] += 1
    return dict(counts)


def _print_table_by_config(by_config: dict[str, dict[str, Any]]) -> None:
    headers = (
        "Config",
        "Runs",
        "Success%",
        "Steps",
        "UTurns",
        "GR Hits",
        "Terminations",
    )
    print(
        f"{headers[0]:<14} {headers[1]:>5} {headers[2]:>9} "
        f"{headers[3]:>7} {headers[4]:>7} {headers[5]:>8}  "
        f"{headers[6]:<40}"
    )
    print("-" * 100)
    for name, agg in by_config.items():
        terms = " ".join(
            f"{k}:{v}" for k, v in sorted(agg["terminations"].items())
        )
        print(
            f"{name:<14} {agg['runs']:>5} "
            f"{agg['journey_success_pct']:>8.1f}% "
            f"{agg['avg_steps']:>7.1f} "
            f"{agg['avg_user_turns']:>7.1f} "
            f"{agg['guardrail_hits']:>8}  "
            f"{terms:<40}"
        )


def _print_table_by_key(
    grouped: dict[str, dict[str, Any]],
    key_label: str,
) -> None:
    print(f"{key_label:<60} {'Runs':>5} {'Success%':>9} {'Steps':>7}")
    print("-" * 90)
    for key, agg in grouped.items():
        print(
            f"{key:<60} {agg['runs']:>5} "
            f"{agg['journey_success_pct']:>8.1f}% "
            f"{agg['avg_steps']:>7.1f}"
        )


def _build_json_payload(
    benchmark_name: str,
    results: list[RunResult],
    config: BenchmarkConfig,
    include_conversations: bool = False,
) -> dict:
    return {
        "benchmark": benchmark_name,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "config": {
            "metrics": list(config.metrics),
            "runs_per_combo": config.runs_per_combo,
            "max_user_turns": config.max_user_turns,
            "workers": config.workers,
        },
        "include_conversations": include_conversations,
        "results": [
            _serialize_result(r, include_conversations=include_conversations)
            for r in results
        ],
        "summary": {
            "by_config": aggregate_by_config(results),
            "by_complexity": aggregate_by_complexity(results),
            "by_model": aggregate_by_model(results),
        },
    }


def _serialize_result(
    r: RunResult,
    include_conversations: bool = False,
) -> dict:
    out = {
        "spec": _serialize_spec(
            r.spec, include_conversations=include_conversations
        ),
        "journey_success": r.journey_success,
        "total_steps": r.total_steps,
        "user_turns": r.user_turns,
        "termination_reason": r.termination_reason,
        "guardrail_notes": list(r.guardrail_notes),
        "metric_results": dict(r.metric_results),
        "custom": dict(r.custom),
    }
    if include_conversations:
        # Serialize via model_dump() to get clean dicts for Message
        # (handled by _json_default, but explicit here for clarity
        # of what the conversations block contains).
        out["messages"] = [
            m.model_dump() if hasattr(m, "model_dump") else m
            for m in r.messages
        ]
    return out


def _serialize_spec(
    s: RunSpec,
    include_conversations: bool = False,
) -> dict:
    out = {
        "benchmark_name": s.benchmark_name,
        "story_name": s.story_name,
        "config_name": s.config.name,
        "agent_model": s.agent_model,
        "user_sim_model": s.user_sim_model,
        "eval_model": s.eval_model,
        "framework": s.framework,
        "run_index": s.run_index,
        "service_url": s.service_url,
    }
    if include_conversations:
        # Story text + starting sentence make the JSON self-contained
        # for rendering — no need to cross-reference the original
        # stories/*.json files.
        story = s.story
        out["story"] = story.story
        out["starting_sentence"] = story.starting_sentence
        complexity = getattr(story, "complexity", None)
        if complexity is not None:
            out["complexity"] = complexity
    return out


def _json_default(obj: Any) -> Any:
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if hasattr(obj, "__dict__"):
        return obj.__dict__
    return str(obj)
