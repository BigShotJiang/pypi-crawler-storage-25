"""CLI entry point for the benchmark harness."""

from __future__ import annotations

import logging
from typing import List

import typer
from dotenv import load_dotenv

from agentops.benchmark_harness.evaluate_evals import (
    MetricsGeneratorConfig,
    generate_metrics,
)
from agentops.benchmark_harness.runner import (
    EXIT_EVALUATION,
    EXIT_FRAMEWORK,
    EXIT_IO,
    EXIT_OK,
    EXIT_VALIDATION,
    run_benchmarks,
)
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)

app = typer.Typer(
    name="benchmark-harness",
    help="Benchmark features of AgentOps evaluation",
    add_completion=False,
)

load_dotenv()
logging.basicConfig(level=logging.WARNING)
logging.getLogger("agentops").setLevel(logging.WARNING)


@app.command(help="Generate trajectories and run benchmark")
def run(
    paths: List[str] = typer.Argument(
        None,
        help="Benchmark dirs or parent dir (default: benchmarks/)",
    ),
    defaults: str = typer.Option(
        "benchmarks/harness_defaults.yaml",
        "--defaults",
        help="Path to harness defaults YAML",
    ),
    output_dir: str = typer.Option(
        "results/",
        "--output-dir",
        help="Base output directory for reports",
    ),
    include_conversations: bool = typer.Option(
        False,
        "--include-conversations",
        help=(
            "Include full conversation transcripts and story text in "
            "the JSON output. Off by default. Use with the companion "
            "`python -m agentops.benchmark_harness.render_conversations` "
            "tool to produce human-readable conversation logs."
        ),
    ),
    framework: str = typer.Option(
        None,
        "--framework",
        help=(
            "Override the frameworks list from harness_defaults.yaml. "
            "E.g. --framework langgraph, --framework wxo, "
            "or --framework langgraph wxo."
        ),
    ),
):
    """Run benchmark harness (default command)."""

    # Default paths if none provided
    if not paths:
        paths = ["benchmarks/"]

    exit_code = run_benchmarks(
        paths=paths,
        defaults=defaults,
        output_dir=output_dir,
        include_conversations=include_conversations,
    )

    if exit_code != EXIT_OK:
        raise typer.Exit(code=exit_code)


@app.command(help="Evaluate agent evaluators")
def evaluate_evals(
    config_path: str = typer.Argument(
        ...,
        help="Path to configuration file (YAML or JSON)",
    ),
):
    """Generate metrics from trajectories and evalute the metric results

    Example:
        python -m agentops.benchmark_harness evalute-evals config.yaml

    Config file example (YAML):
        test_case_path: benchmarks/trajectory_metrics/test_cases/
        messages_dir: benchmarks/trajectory_metrics/messages/
        output_dir: ./evaluation_results
        metrics:
          - JourneySuccessMetric
          - ToolCalling
          - StepMetrics
        evaluation_model: bedrock/openai.gpt-oss-120b-1:0
        provider: gateway
        wxo_lite_version: v1
    """

    try:
        logger.info(f"Loading configuration from: {config_path}")
        config = MetricsGeneratorConfig.from_file(config_path)
        generate_metrics(config)

    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise typer.Exit(code=EXIT_IO)
    except ValueError as e:
        logger.error(f"Invalid input: {e}")
        raise typer.Exit(code=EXIT_VALIDATION)
    except Exception as e:
        logger.error(f"Evaluation failed: {e}")
        raise typer.Exit(code=EXIT_EVALUATION)


if __name__ == "__main__":
    app()

# Made with Bob
