"""Expand a BenchmarkConfig into the full cartesian product of RunSpecs."""

from __future__ import annotations

import os

from agentops.benchmark_harness.types import BenchmarkConfig, RunSpec

_WXO_DEFAULT_LLM = "groq/openai/gpt-oss-120b"


def plan_runs(config: BenchmarkConfig) -> list[RunSpec]:
    """Expand variability matrix into RunSpec instances.

    Expansion order (outer to inner):
      stories x configs x models.agent x models.user_sim
              x models.eval x frameworks x range(runs_per_combo)
    """
    matrix = config.matrix
    wxo_llm = os.environ.get("WXO_LLM", _WXO_DEFAULT_LLM)
    wxo_service_url = os.environ.get("WXO_SERVICE_URL", "")
    specs: list[RunSpec] = []
    for story in config.stories:
        story_name = (
            story.dataset_name
            if story.dataset_name
            else (story.starting_sentence or "story")[:32]
        )
        for sim_cfg in matrix.configs:
            for agent_model in matrix.models.agent:
                for user_sim_model in matrix.models.user_sim:
                    for eval_model in matrix.models.eval:
                        for framework in matrix.frameworks:
                            effective_agent_model = (
                                wxo_llm if framework == "wxo" else agent_model
                            )
                            for run_index in range(config.runs_per_combo):
                                specs.append(
                                    RunSpec(
                                        benchmark_name=config.name,
                                        story=story,
                                        story_name=story_name,
                                        config=sim_cfg,
                                        agent_model=effective_agent_model,
                                        user_sim_model=user_sim_model,
                                        eval_model=eval_model,
                                        framework=framework,
                                        run_index=run_index,
                                        max_user_turns=config.max_user_turns,
                                        service_url=(
                                            wxo_service_url
                                            if framework == "wxo"
                                            else ""
                                        ),
                                    )
                                )
    return specs
