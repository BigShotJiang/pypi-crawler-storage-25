"""Registry of framework-specific agent factories."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Callable

from agentops.benchmark_harness.types import AgentSpec
from agentops.utils.utils import is_saas_url

if TYPE_CHECKING:
    from agentops.benchmark_harness.extension import BenchmarkExtension
    from agentops.benchmark_harness.types import ToolSpec
    from agentops.runtime_adapter.runtime_adapter import RuntimeAdapter

_FACTORIES: dict[str, Callable] = {}


def register_framework(name: str, factory: Callable) -> None:
    """Register a framework factory."""
    _FACTORIES[name] = factory


def create_agent(
    agent_spec: AgentSpec,
    tools: list[Callable],
    model: str,
    framework: str,
    extension: BenchmarkExtension | None = None,
    tools_spec: list[ToolSpec] | None = None,
) -> RuntimeAdapter:
    """Create an agent runtime adapter.

    Resolution order:
      1. extension.create_agent(...) -> RuntimeAdapter wins if not None.
      2. Otherwise dispatch to _FACTORIES[framework].
    """
    if extension is not None:
        adapter = extension.create_agent(
            tools=tools,
            agent_spec=agent_spec,
            model=model,
            framework=framework,
        )
        if adapter is not None:
            return adapter

    if framework not in _FACTORIES:
        raise KeyError(
            f"unknown framework '{framework}' "
            f"(registered: {sorted(_FACTORIES.keys())})"
        )
    return _FACTORIES[framework](
        agent_spec, tools, model, tools_spec=tools_spec
    )


def _langgraph_factory(
    agent_spec: AgentSpec,
    tools: list[Callable],
    model: str,
    **kwargs,
) -> RuntimeAdapter:
    """LangGraph v1 factory.

    Mirrors the create_agent(...) call used by the existing benchmarks.
    """
    # Lazy imports — these dependencies are only needed when the
    # langgraph framework is actually requested
    from langchain.agents import create_agent as lc_create_agent
    from langchain_openai import ChatOpenAI
    from langgraph.checkpoint.memory import MemorySaver

    from agentops.runtime_adapter.langgraph_runtime_adapter import (
        LanggraphRuntimeAdapter,
    )

    agent = lc_create_agent(
        tools=tools,
        model=ChatOpenAI(model=model),
        system_prompt=agent_spec.instructions,
        checkpointer=MemorySaver(),
    )
    return LanggraphRuntimeAdapter(agent)


def _wxo_factory(
    agent_spec: AgentSpec,
    tools: list[Callable],
    model: str,
    *,
    tools_spec: list[ToolSpec] | None = None,
    **kwargs,
) -> RuntimeAdapter:
    """Watson Orchestrate (WXO) factory.

    Provisions tools and an agent on a WXO instance (remote or Developer
    Edition), then returns a WXORuntimeAdapter connected to that instance.

    Requires env vars:
      WXO_SERVICE_URL - WXO instance base URL (or http://localhost:4321
                        for Developer Edition)
      WO_API_KEY      - IBM Cloud IAM API key (not needed for localhost)

    Optional env vars:
      WXO_LLM - WXO agent LLM (default: groq/openai/gpt-oss-120b)
    """
    # Lazy: avoid importing wxo_provisioner (and its deps) for langgraph-only use
    from agentops.benchmark_harness.wxo_provisioner import get_or_provision

    _WXO_DEFAULT_LLM = "groq/openai/gpt-oss-120b"

    service_url = os.environ.get("WXO_SERVICE_URL")
    api_key = os.environ.get("WO_API_KEY", "")
    wxo_llm = os.environ.get("WXO_LLM", _WXO_DEFAULT_LLM)

    if not service_url:
        raise RuntimeError(
            "WXO_SERVICE_URL environment variable is required "
            "for the wxo framework"
        )
    if not api_key and is_saas_url(service_url):
        raise RuntimeError(
            "WO_API_KEY environment variable is required "
            "for remote WXO (set WXO_SERVICE_URL to localhost "
            "for Developer Edition without an API key)"
        )
    if tools_spec is None:
        raise RuntimeError(
            "tools_spec is required for the wxo framework "
            "(passed from benchmark_config.tools_spec)"
        )

    return get_or_provision(
        agent_spec=agent_spec,
        tools_spec=tools_spec,
        service_url=service_url,
        api_key=api_key,
        wxo_llm=wxo_llm,
    )


# Register default factories at import time
register_framework("langgraph", _langgraph_factory)
register_framework("wxo", _wxo_factory)
