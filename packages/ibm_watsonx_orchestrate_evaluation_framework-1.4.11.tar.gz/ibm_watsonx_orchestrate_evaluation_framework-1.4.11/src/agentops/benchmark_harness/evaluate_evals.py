"""Metrics generation functionality for benchmark harness."""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml
from pydantic import BaseModel, Field
from rich.console import Console
from rich.table import Table

from agentops.arg_configs import AuthConfig, ProviderConfig, TestConfig
from agentops.clients import bootstrap_clients
from agentops.langfuse_evaluation_package import EvaluationRunner, load_metrics
from agentops.type import Message, TestCase
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)
console = Console()


class MetricStats(BaseModel):
    """Statistics for a single metric evaluation."""

    precision: float
    recall: float
    f1: float
    tp: int
    fp: int
    fn: int


class MetricsGeneratorConfig(BaseModel):
    """Configuration for metrics generation.

    Attributes:
        test_case_path: Path to test case file or directory
        messages_dir: Path to directory containing message files
        metrics: List of metrics to evaluate
        evaluation_model: Model to use for evaluation
        provider: Provider to use (gateway, watsonx, etc.)
        wxo_lite_version: WXO lite version (default: v1)
        max_tests: Maximum number of tests to run (default: None for all tests)
        actual_metrics_dir: Path to directory containing actual/expected metrics for comparison
        show_evaluation_results: Whether to print evaluation results table (default: False)
        show_per_test_results: Whether to print per-test-case results (default: False)
        show_metric_comparison: Whether to print metric comparison table (default: False)
        show_precision_recall_f1: Whether to print precision/recall/F1 table (default: True)
        precision_recall_f1_metrics: List of metric names to calculate precision/recall/F1 for (default: semantic_match, is_success, text_match, tool_match_success)
    """

    test_case_path: str
    messages_dir: str
    metrics: List[str] = Field(
        default_factory=lambda: [
            "JourneySuccessMetric",
            "ToolCalling",
            "StepMetrics",
            "SemanticMatchMetric",
            "KeywordMatchMetric",
        ]
    )
    evaluation_model: str = "bedrock/openai.gpt-oss-120b-1:0"
    provider: str = "gateway"
    wxo_lite_version: str = "v1"
    max_tests: Optional[int] = None
    actual_metrics_dir: Optional[str] = None
    show_evaluation_results: bool = False
    show_per_test_results: bool = False
    show_metric_comparison: bool = False
    show_precision_recall_f1: bool = True
    precision_recall_f1_metrics: List[str] = Field(
        default_factory=lambda: [
            "semantic_match",
            "is_success",
            "text_match",
            "tool_match_success",
        ]
    )

    @classmethod
    def from_yaml(cls, config_path: str) -> "MetricsGeneratorConfig":
        """Load configuration from YAML file.

        Args:
            config_path: Path to YAML configuration file

        Returns:
            MetricsGeneratorConfig instance
        """
        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        return cls(**data)

    @classmethod
    def from_json(cls, config_path: str) -> "MetricsGeneratorConfig":
        """Load configuration from JSON file.

        Args:
            config_path: Path to JSON configuration file

        Returns:
            MetricsGeneratorConfig instance
        """
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(**data)

    @classmethod
    def from_file(cls, config_path: str) -> "MetricsGeneratorConfig":
        """Load configuration from file (auto-detect format).

        Args:
            config_path: Path to configuration file (YAML or JSON)

        Returns:
            MetricsGeneratorConfig instance
        """
        path = Path(config_path)
        if path.suffix in [".yaml", ".yml"]:
            return cls.from_yaml(config_path)
        elif path.suffix == ".json":
            return cls.from_json(config_path)
        else:
            raise ValueError(
                f"Unsupported config format: {path.suffix}. Use .yaml, .yml, or .json"
            )


def load_test_case(test_case_path: str) -> TestCase:
    """Load test case from YAML or JSON file, or recursively search directory.

    Args:
        test_case_path: Path to the test case file or directory to search recursively

    Returns:
        TestCase object (first valid test case found if directory)

    Raises:
        ValueError: If file format is not supported or no valid files found
        FileNotFoundError: If file/directory doesn't exist
    """
    path = Path(test_case_path)
    if not path.exists():
        raise FileNotFoundError(f"Test case file not found: {test_case_path}")

    # If it's a directory, search recursively for test case files
    if path.is_dir():
        # Search for YAML and JSON files recursively
        test_files = (
            list(path.rglob("*.yaml"))
            + list(path.rglob("*.yml"))
            + list(path.rglob("*.json"))
        )

        if not test_files:
            raise ValueError(
                f"No test case files (.yaml, .yml, .json) found in: {test_case_path}"
            )

        # Use the first valid test case file found
        test_case_path = str(test_files[0])
        path = test_files[0]

    if path.suffix in [".yaml", ".yml"]:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    elif path.suffix == ".json":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        raise ValueError(
            f"Unsupported file format: {path.suffix}. Use .yaml, .yml, or .json"
        )

    return TestCase(**data)


def load_messages_from_dir(
    messages_dir: str, filter_pattern: str = "*.json"
) -> List[List[Message]]:
    """Load messages from JSON files in a directory recursively.

    Each JSON file should contain a list of messages for one test case.
    Files are loaded in alphabetical order, searching recursively through subdirectories.

    Args:
        messages_dir: Path to directory containing message JSON files
        filter_pattern: Glob pattern to filter message files (default: "*.json")

    Returns:
        List of message lists (one per test case)

    Raises:
        FileNotFoundError: If directory doesn't exist
        ValueError: If no valid message files found
    """
    dir_path = Path(messages_dir)
    if not dir_path.exists():
        raise FileNotFoundError(f"Messages directory not found: {messages_dir}")

    # Use the filter pattern to find message files
    message_files = sorted(dir_path.rglob(filter_pattern))
    if not message_files:
        raise ValueError(
            f"No files matching '{filter_pattern}' found in: {messages_dir}"
        )

    all_messages = []
    for msg_file in message_files:
        with open(msg_file, "r", encoding="utf-8") as f:
            messages_data = json.load(f)

        # Convert to Message objects if needed
        if isinstance(messages_data, list):
            messages = [
                Message(**msg) if isinstance(msg, dict) else msg
                for msg in messages_data
            ]
            all_messages.append(messages)
        else:
            logger.warning(
                f"  Skipping {msg_file.relative_to(dir_path)}: not a list"
            )

    if not all_messages:
        raise ValueError(f"No valid message files loaded from: {messages_dir}")

    return all_messages


def load_paired_test_cases_and_messages(
    test_case_dir: str,
    messages_dir: str,
) -> tuple[List[TestCase], List[List[Message]]]:
    """Load paired test case and message files from separate directories.

    Matches files by name:
    - test_case_dir/test_name.json (test case)
    - messages_dir/test_name.messages.json (messages)

    Args:
        test_case_dir: Path to directory containing test case files
        messages_dir: Path to directory containing message files

    Returns:
        Tuple of (test_cases, messages_list)

    Raises:
        FileNotFoundError: If directories don't exist
        ValueError: If no valid pairs found
    """
    test_case_path = Path(test_case_dir)
    messages_path = Path(messages_dir)

    if not test_case_path.exists():
        raise FileNotFoundError(
            f"Test case directory not found: {test_case_dir}"
        )
    if not messages_path.exists():
        raise FileNotFoundError(f"Messages directory not found: {messages_dir}")

    # Find all test case files (non-.messages.json files)
    test_case_files = sorted(test_case_path.rglob("*.json"))
    test_case_files = [
        f for f in test_case_files if not f.name.endswith(".messages.json")
    ]

    if not test_case_files:
        raise ValueError(f"No test case files found in: {test_case_dir}")

    test_cases = []
    messages_list = []

    for test_case_file in test_case_files:
        # Derive the message file name
        base_name = test_case_file.stem  # e.g., "test_get_tokyo_weather"
        msg_file_name = f"{base_name}.messages.json"

        # Search for the message file in the messages directory
        msg_files = list(messages_path.rglob(msg_file_name))

        if not msg_files:
            logger.warning(
                f"  Skipping {test_case_file.name}: no matching message file {msg_file_name}"
            )
            continue

        msg_file = msg_files[0]  # Use first match

        # Load test case
        try:
            with open(test_case_file, "r", encoding="utf-8") as f:
                test_case_data = json.load(f)
            # Use the source filename as dataset_name so generated metrics
            # align with paired message/metric filenames.
            test_case_data["dataset_name"] = base_name
            test_case = TestCase(**test_case_data)
        except Exception as e:
            logger.warning(
                f"  Skipping {test_case_file.name}: failed to load ({e})"
            )
            continue

        # Load messages
        try:
            with open(msg_file, "r", encoding="utf-8") as f:
                messages_data = json.load(f)

            if not isinstance(messages_data, list):
                logger.warning(f"  Skipping {msg_file.name}: not a list")
                continue

            messages = [
                Message(**msg) if isinstance(msg, dict) else msg
                for msg in messages_data
            ]
        except Exception as e:
            logger.warning(f"  Skipping {msg_file.name}: failed to load ({e})")
            continue

        test_cases.append(test_case)
        messages_list.append(messages)

    if not test_cases:
        raise ValueError(f"No valid test case/message pairs found")

    return test_cases, messages_list


def normalize_metric_value(value: Any) -> Any:
    """Normalize metric values for display and comparison."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return float(value)
    return value


def load_actual_metrics_from_dir(
    metrics_dir: Optional[str],
) -> Dict[str, Dict[str, Any]]:
    """Load expected/actual metrics from a metrics directory."""
    if not metrics_dir:
        return {}

    dir_path = Path(metrics_dir)
    if not dir_path.exists():
        raise FileNotFoundError(f"Metrics directory not found: {metrics_dir}")

    metric_files = sorted(
        [
            file_path
            for file_path in dir_path.rglob("*.json")
            if not file_path.name.endswith(".messages.json")
            and not file_path.name.endswith(".messages.analyze.json")
        ]
    )

    if not metric_files:
        raise ValueError(f"No metrics JSON files found in: {metrics_dir}")

    metrics_by_dataset: Dict[str, Dict[str, Any]] = {}
    for metric_file in metric_files:
        with open(metric_file, "r", encoding="utf-8") as f:
            metric_data = json.load(f)

        if not isinstance(metric_data, dict):
            logger.warning(
                f"  Skipping {metric_file.relative_to(dir_path)}: not a JSON object"
            )
            continue

        dataset_name = metric_data.get("dataset_name")
        if not dataset_name:
            dataset_name = metric_file.name.removesuffix(
                ".metrics.json"
            ).removesuffix(".json")

        metrics_by_dataset[dataset_name] = metric_data

    if not metrics_by_dataset:
        raise ValueError(f"No valid metrics files loaded from: {metrics_dir}")

    return metrics_by_dataset


def extract_generated_metrics(
    results, test_cases: List[TestCase]
) -> Dict[str, Dict[str, Any]]:
    """Extract generated metrics into a test-case-name keyed mapping."""
    generated_metrics: Dict[str, Dict[str, Any]] = {}

    if not hasattr(results, "metrics") or not results.metrics:
        return generated_metrics

    for idx, test_metrics in enumerate(results.metrics):
        if not test_metrics:
            continue

        test_case_name = f"test_case_{idx + 1}"
        if idx < len(test_cases):
            dataset_name = getattr(test_cases[idx], "dataset_name", None)
            if isinstance(dataset_name, str) and dataset_name:
                test_case_name = dataset_name

        metrics_items = (
            test_metrics.items() if hasattr(test_metrics, "items") else []
        )
        dataset_metrics: Dict[str, Any] = {"dataset_name": test_case_name}

        for _, metric_list in metrics_items:
            for metric in metric_list:
                metric_name = getattr(
                    metric, "eval_name", getattr(metric, "display_name", None)
                )
                metric_value = getattr(metric, "value", None)
                if metric_value is None:
                    metric_value = getattr(metric, "display_value", None)
                if metric_name is not None:
                    dataset_metrics[metric_name] = normalize_metric_value(
                        metric_value
                    )

        generated_metrics[test_case_name] = dataset_metrics

    return generated_metrics


def filter_metrics_by_dataset_names(
    metrics_by_dataset: Dict[str, Dict[str, Any]],
    dataset_names: List[str],
) -> Dict[str, Dict[str, Any]]:
    """Filter metrics mapping to the specified dataset names, preserving order."""
    dataset_name_set = set(dataset_names)
    return {
        dataset_name: metric_values
        for dataset_name, metric_values in metrics_by_dataset.items()
        if dataset_name in dataset_name_set
    }


def compare_metrics(
    generated_metrics: Dict[str, Dict[str, Any]],
    actual_metrics: Dict[str, Dict[str, Any]],
) -> List[Tuple[str, str, Any, Any, bool]]:
    """Compare generated metrics with actual metrics."""
    comparisons: List[Tuple[str, str, Any, Any, bool]] = []

    for dataset_name, expected_values in actual_metrics.items():
        generated_values = generated_metrics.get(dataset_name, {})
        metric_names = sorted(
            {
                metric_name
                for metric_name in set(expected_values) | set(generated_values)
                if metric_name != "dataset_name"
            }
        )

        for metric_name in metric_names:
            expected_value = normalize_metric_value(
                expected_values.get(metric_name)
            )
            generated_value = normalize_metric_value(
                generated_values.get(metric_name)
            )
            matches = generated_value == expected_value
            if not matches:
                print(
                    f"Non-match in test case: {dataset_name} (metric: {metric_name})"
                )
            comparisons.append(
                (
                    dataset_name,
                    metric_name,
                    generated_value,
                    expected_value,
                    matches,
                )
            )

    return comparisons


def print_metric_comparison(
    comparisons: List[Tuple[str, str, Any, Any, bool]]
) -> None:
    """Print generated vs actual metric comparisons."""
    if not comparisons:
        return

    console.print("\n[bold]Metric Comparison:[/bold]")
    table = Table(show_header=True, header_style="bold")
    table.add_column("Dataset", style="cyan")
    table.add_column("Metric", style="cyan")
    table.add_column("Generated", style="magenta")
    table.add_column("Actual", style="magenta")
    table.add_column("Match", style="green")

    for (
        dataset_name,
        metric_name,
        generated_value,
        expected_value,
        matches,
    ) in comparisons:
        status = "✓" if matches else "✗"
        table.add_row(
            dataset_name,
            metric_name,
            str(generated_value),
            str(expected_value),
            status,
        )

    console.print(table)


def is_positive(value):
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return not (math.isnan(value) or value == 0)
    return True  # For strings, consider non-empty as positive


def calculate_precision_recall_f1(
    generated_metrics: Dict[str, Dict[str, Any]],
    actual_metrics: Dict[str, Dict[str, Any]],
    target_metric_names: Optional[List[str]] = None,
) -> Dict[str, MetricStats]:
    """Calculate precision, recall, and F1 score per metric across all test cases.

    For each metric:
    - True Positives (TP): Generated and actual both have the same non-zero/true value
    - False Positives (FP): Generated has non-zero/true value but actual doesn't match
    - False Negatives (FN): Actual has non-zero/true value but generated doesn't match
    - True Negatives (TN): Both have zero/false value (not typically used in these calculations)

    Args:
        generated_metrics: Dictionary mapping dataset names to generated metric values
        actual_metrics: Dictionary mapping dataset names to actual/expected metric values
        target_metric_names: Optional list of metric names to calculate for. If None, calculates for all metrics.

    Returns:
        Dictionary mapping metric names to their precision, recall, and F1 scores
    """
    # Only calculate metrics for specified target metrics (if provided)
    target_metrics = set(target_metric_names) if target_metric_names else None

    # Collect all metric names across all datasets
    all_metric_names = set()
    for metrics_dict in list(generated_metrics.values()) + list(
        actual_metrics.values()
    ):
        all_metric_names.update(
            k for k in metrics_dict.keys() if k != "dataset_name"
        )

    # Filter to only target metrics if specified
    if target_metrics is not None:
        filtered_metric_names = all_metric_names & target_metrics
    else:
        filtered_metric_names = all_metric_names

    metric_stats: Dict[str, MetricStats] = {}

    for metric_name in sorted(filtered_metric_names):
        tp = 0  # True positives
        fp = 0  # False positives
        fn = 0  # False negatives

        # Get all dataset names from both generated and actual
        all_datasets = set(generated_metrics.keys()) | set(
            actual_metrics.keys()
        )

        for dataset_name in all_datasets:
            generated_value = generated_metrics.get(dataset_name, {}).get(
                metric_name
            )
            actual_value = actual_metrics.get(dataset_name, {}).get(metric_name)

            # Normalize values for comparison
            generated_value = normalize_metric_value(generated_value)
            actual_value = normalize_metric_value(actual_value)

            # Skip if both values are None/missing
            if generated_value is None and actual_value is None:
                continue

            # Determine if values are "positive" (non-zero, true, or present)

            generated_positive = is_positive(generated_value)
            actual_positive = is_positive(actual_value)

            # Calculate TP, FP, FN based on whether values match
            if actual_positive:
                if generated_value == actual_value:
                    tp += 1
                else:
                    fn += 1  # Should have predicted correctly but didn't
                    print(
                        f"Non-match (FN) in test case: {dataset_name} (metric: {metric_name})"
                    )
            else:
                if generated_positive:
                    fp += (
                        1  # Predicted positive when it should be negative/zero
                    )
                    print(
                        f"Non-match (FP) in test case: {dataset_name} (metric: {metric_name})"
                    )

        # Calculate precision, recall, and F1
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = (
            (2 * precision * recall) / (precision + recall)
            if (precision + recall) > 0
            else 0.0
        )

        metric_stats[metric_name] = MetricStats(
            precision=round(precision, 4),
            recall=round(recall, 4),
            f1=round(f1, 4),
            tp=tp,
            fp=fp,
            fn=fn,
        )

    return metric_stats


def print_precision_recall_f1(metric_stats: Dict[str, MetricStats]) -> None:
    """Print precision, recall, and F1 scores per metric.

    Args:
        metric_stats: Dictionary mapping metric names to their statistics
    """
    if not metric_stats:
        return

    console.print("\n[bold]Precision, Recall, and F1 per Metric:[/bold]")
    table = Table(show_header=True, header_style="bold")
    table.add_column("Metric", style="cyan")
    table.add_column("Precision", style="magenta", justify="right")
    table.add_column("Recall", style="magenta", justify="right")
    table.add_column("F1 Score", style="green", justify="right")
    table.add_column("TP/FP/FN", style="yellow", justify="center")

    for metric_name, stats in sorted(metric_stats.items()):
        tp_fp_fn = f"{stats.tp}/{stats.fp}/{stats.fn}"
        table.add_row(
            metric_name,
            f"{stats.precision:.4f}",
            f"{stats.recall:.4f}",
            f"{stats.f1:.4f}",
            tp_fp_fn,
        )

    console.print(table)


def print_evaluation_results(
    results, show_aggregate: bool = True, show_per_test: bool = True
):
    """Print evaluation results in a formatted table.

    Args:
        results: ExperimentResult object containing metrics
        show_aggregate: Whether to print aggregate metrics table (shows averages)
        show_per_test: Whether to print per-test-case results
    """
    console.print("\n[bold green]Evaluation Complete![/bold green]\n")

    # Print aggregate metrics (as averages)
    if (
        show_aggregate
        and hasattr(results, "aggregate_metrics")
        and results.aggregate_metrics
    ):
        table = Table(
            title="Aggregate Metrics (Averages)",
            show_header=True,
            header_style="bold",
        )
        table.add_column("Metric", style="cyan")
        table.add_column("Average", style="magenta")

        aggregate_values = getattr(
            results.aggregate_metrics, "overall", results.aggregate_metrics
        )
        metrics_items = (
            aggregate_values.items()
            if hasattr(aggregate_values, "items")
            else []
        )

        # First pass: get the number of runs
        num_runs = None
        for metric_name, metric_value in metrics_items:
            if metric_name == "Runs" and isinstance(metric_value, (int, float)):
                num_runs = metric_value
                break

        # Second pass: display metrics (calculate averages for non-Runs metrics)
        for metric_name, metric_value in metrics_items:
            if isinstance(metric_value, (int, float)):
                # For "Runs", show the count as-is
                if metric_name == "Runs":
                    table.add_row(metric_name, f"{metric_value:.0f}")
                # For other metrics, calculate average if we have num_runs
                elif num_runs and num_runs > 0:
                    avg_value = metric_value / num_runs
                    table.add_row(metric_name, f"{avg_value:.4f}")
                else:
                    # Fallback if Runs not found
                    table.add_row(metric_name, f"{metric_value:.4f}")
            else:
                table.add_row(metric_name, str(metric_value))

        console.print(table)

    # Print per-test-case metrics summary
    if show_per_test and hasattr(results, "metrics") and results.metrics:
        console.print("\n[bold]Per Test Case Results:[/bold]")
        for idx, test_metrics in enumerate(results.metrics):
            if test_metrics:
                console.print(f"\n  Test Case {idx + 1}:")
                # Handle both dict and object with items() method
                metrics_items = (
                    test_metrics.items()
                    if hasattr(test_metrics, "items")
                    else []
                )
                for test_name, metric_list in metrics_items:
                    console.print(f"    {test_name}:")
                    for metric in metric_list:
                        metric_value = normalize_metric_value(
                            getattr(
                                metric,
                                "display_value",
                                getattr(metric, "value", None),
                            )
                        )
                        value_str = (
                            f"{metric_value:.4f}"
                            if isinstance(metric_value, float)
                            else str(metric_value)
                        )
                        metric_name = getattr(
                            metric,
                            "display_name",
                            getattr(metric, "eval_name", "unknown"),
                        )
                        console.print(f"      - {metric_name}: {value_str}")


def generate_metrics(config: MetricsGeneratorConfig) -> None:
    """Generate metrics from test case evaluations.

    Args:
        config: MetricsGeneratorConfig containing all configuration parameters

    Raises:
        FileNotFoundError: If test case or messages directory not found
        ValueError: If invalid input provided
        Exception: If evaluation fails
    """
    test_case_path_obj = Path(config.test_case_path)
    messages_dir_obj = Path(config.messages_dir)

    # Check if both are directories - if so, load paired files from separate directories
    if test_case_path_obj.is_dir() and messages_dir_obj.is_dir():
        test_cases, messages_list = load_paired_test_cases_and_messages(
            config.test_case_path, config.messages_dir
        )
    else:
        # Original behavior: single test case file, multiple message files
        test_case = load_test_case(config.test_case_path)
        messages_list = load_messages_from_dir(
            config.messages_dir, filter_pattern="*.messages.json"
        )
        test_cases = [test_case] * len(messages_list)

    # Apply max_tests limit if specified
    if config.max_tests is not None and config.max_tests > 0:
        original_count = len(test_cases)
        test_cases = test_cases[: config.max_tests]
        messages_list = messages_list[: config.max_tests]
        logger.info(
            f"Limiting tests to {config.max_tests} out of {original_count} available tests"
        )

    actual_metrics = load_actual_metrics_from_dir(config.actual_metrics_dir)
    selected_dataset_names: List[str] = [
        test_case.dataset_name
        for test_case in test_cases
        if test_case.dataset_name is not None
    ]
    actual_metrics = filter_metrics_by_dataset_names(
        actual_metrics, selected_dataset_names
    )

    # Bootstrap clients for LLM evaluation
    # Create provider config
    provider_config = ProviderConfig(provider=config.provider)

    # Create auth config - use environment variables or defaults
    # The tenant_setup in service_instance.py will handle reading from
    # ~/.config/orchestrate/config.yaml if tenant_name is provided
    auth_config = AuthConfig(
        url=os.getenv("WO_INSTANCE"),
        tenant_name=os.getenv("WO_TENANT", "local"),
        token=os.getenv("WO_TOKEN"),
    )

    # Create a minimal TestConfig for client initialization
    test_config = TestConfig(
        test_paths=[],
        output_dir="./evaluation_results",
        auth_config=auth_config,
        wxo_lite_version=config.wxo_lite_version,
        provider_config=provider_config,
        evaluation_model=config.evaluation_model,
    )

    clients = bootstrap_clients(test_config)

    # Load metrics
    evaluators = load_metrics(
        test_config,
        config.metrics,
        llm_client=clients.llmaaj_provider,
    )

    # Create evaluation runner
    # Use first test case for naming, ensure it's always a string
    dataset_name = (
        test_cases[0].dataset_name
        if test_cases and test_cases[0].dataset_name
        else "unnamed"
    )

    runner = EvaluationRunner(
        evaluation_name=f"cli-evaluation-{dataset_name}",
        output_dir="./evaluation_results",
        test_cases=test_cases,
        messages=messages_list,
        metrics=evaluators,
        exporters=[],  # Use default disk persistence
    )

    # Run evaluation
    results = runner.evaluate()

    generated_metrics = extract_generated_metrics(results, test_cases)

    # Print results based on config flags
    print_evaluation_results(
        results,
        show_aggregate=config.show_evaluation_results,
        show_per_test=config.show_per_test_results,
    )

    # Print metric comparison if enabled and actual metrics are available
    if config.show_metric_comparison and actual_metrics:
        comparisons = compare_metrics(generated_metrics, actual_metrics)
        print_metric_comparison(comparisons)

    # Calculate and print precision, recall, and F1 per metric if enabled
    if config.show_precision_recall_f1 and actual_metrics:
        metric_stats = calculate_precision_recall_f1(
            generated_metrics,
            actual_metrics,
            target_metric_names=config.precision_recall_f1_metrics,
        )
        print_precision_recall_f1(metric_stats)

    logger.info("[bold green]✓ Evaluation completed successfully![/bold green]")


def generate_metrics_from_args(
    test_case_path: str,
    messages_dir: str,
    metrics: List[str],
    evaluation_model: str,
    provider: str,
    max_tests: Optional[int] = None,
    actual_metrics_dir: Optional[str] = None,
) -> None:
    """Generate metrics from test case evaluations (legacy function for CLI compatibility).

    Args:
        test_case_path: Path to the test case file (YAML or JSON)
        messages_dir: Path to directory containing message files (JSON format)
        metrics: List of metrics to evaluate
        evaluation_model: Model to use for evaluation
        provider: Provider to use (gateway, watsonx, etc.)
        max_tests: Maximum number of tests to run (default: None for all tests)

    Raises:
        FileNotFoundError: If test case or messages directory not found
        ValueError: If invalid input provided
        Exception: If evaluation fails
    """
    config = MetricsGeneratorConfig(
        test_case_path=test_case_path,
        messages_dir=messages_dir,
        metrics=metrics,
        evaluation_model=evaluation_model,
        provider=provider,
        max_tests=max_tests,
        actual_metrics_dir=actual_metrics_dir,
    )
    generate_metrics(config)


# Made with Bob
