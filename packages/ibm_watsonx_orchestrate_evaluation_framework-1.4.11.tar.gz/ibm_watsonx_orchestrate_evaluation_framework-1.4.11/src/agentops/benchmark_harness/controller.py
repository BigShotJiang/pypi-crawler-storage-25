"""InstrumentedController — extracted from the existing benchmarks."""

from __future__ import annotations

from agentops.evaluation_controller.evaluation_controller import (
    EvaluationController,
)
from agentops.llm_user.models import GoalStatus, SimulatedUserTurn


class InstrumentedController(EvaluationController):
    """EvaluationController with observation hooks for benchmarking.

    Adds:
      - guardrail_notes: list[str] collected across turns from
        SimulatedUserTurn.guardrail_notes.
      - termination_reason: str set when _is_end returns True.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.guardrail_notes: list[str] = []
        self.termination_reason: str = "max_turns"

    def run(self, *args, **kwargs):
        # Reset per-conversation state
        self.guardrail_notes = []
        self.termination_reason = "max_turns"
        return super().run(*args, **kwargs)

    def _is_end(self, current_user_input):
        if isinstance(current_user_input, SimulatedUserTurn):
            self.guardrail_notes.extend(current_user_input.guardrail_notes)
            if current_user_input.goal_status == GoalStatus.SATISFIED:
                self.termination_reason = "satisfied"
                return True
            if current_user_input.goal_status == GoalStatus.FAILED:
                self.termination_reason = "failed"
                return True

        content = current_user_input.content.strip()
        if "END" in content:
            self.termination_reason = "legacy_END"
            return True

        if self.repeating_output_detection:
            if self._is_looping(self.recent_user_messages) or self._is_looping(
                self.recent_assistant_messages
            ):
                self.termination_reason = "repeating_loop"
                return True

        return False
