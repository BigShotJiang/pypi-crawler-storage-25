"""Parallel execution of RunSpec instances."""

from __future__ import annotations

import logging
import os
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING

import agentops.prompt
from agentops.arg_configs import ControllerConfig
from agentops.benchmark_harness.agent_factory import create_agent
from agentops.benchmark_harness.controller import InstrumentedController
from agentops.benchmark_harness.metrics_runner import (
    resolve_metrics,
    run_metrics,
)
from agentops.benchmark_harness.tool_factory import generate_tools
from agentops.benchmark_harness.types import BenchmarkConfig, RunResult, RunSpec
from agentops.benchmark_harness.user_sim_analysis import run_user_sim_analysis
from agentops.llm_user.llm_user_v2 import LLMUserV2
from agentops.personas.models import Persona
from agentops.personas.registry import get_persona_profile
from agentops.service_provider import get_provider
from agentops.service_provider.openai_provider import OpenAIProvider
from agentops.utils.file_system import get_resource_path

if TYPE_CHECKING:
    from agentops.personas.models import PersonaProfile
    from agentops.service_provider.provider import Provider

logger = logging.getLogger(__name__)

_provider_cache_lock = threading.Lock()


def execute_runs(
    run_specs: list[RunSpec],
    benchmark_config: BenchmarkConfig,
) -> list[RunResult]:
    """Execute all run specs in parallel. Returns results in spec order."""
    results: list[RunResult | None] = [None] * len(run_specs)
    # Two caches — user_sim uses get_provider() (gateway / watsonx /
    # OpenAI auto-routing), eval always uses OpenAIProvider directly
    # to match the existing benchmark behavior.
    user_provider_cache: dict[str, "Provider"] = {}
    eval_provider_cache: dict[str, "Provider"] = {}

    has_wxo = any(s.framework == "wxo" for s in run_specs)
    if has_wxo and not os.environ.get("WXO_SERVICE_URL"):
        raise RuntimeError(
            "WXO_SERVICE_URL environment variable is required "
            "for the wxo framework"
        )
    workers = max(1, benchmark_config.workers)

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            future_to_idx = {
                ex.submit(
                    _run_single,
                    spec,
                    benchmark_config,
                    user_provider_cache,
                    eval_provider_cache,
                ): idx
                for idx, spec in enumerate(run_specs)
            }
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    results[idx] = future.result()
                except Exception as e:
                    # Defensive — _run_single has its own try/except,
                    # but ensure no future leaks an exception
                    logger.exception(f"run {idx} crashed: {e}")
                    results[idx] = _build_failed_result(
                        run_specs[idx], f"executor exception: {e}"
                    )
    finally:
        if has_wxo:
            from agentops.benchmark_harness.wxo_provisioner import cleanup_all

            cleanup_all()

    # All slots should be filled; if any are None, replace with failure
    for i, r in enumerate(results):
        if r is None:
            results[i] = _build_failed_result(
                run_specs[i], "no result captured"
            )

    return results  # type: ignore[return-value]


def _run_single(
    spec: RunSpec,
    benchmark_config: BenchmarkConfig,
    user_provider_cache: dict[str, "Provider"],
    eval_provider_cache: dict[str, "Provider"],
) -> RunResult:
    """Execute one conversation run."""
    try:
        # 1. Tools — extension override or default factory
        tools = None
        if benchmark_config.extension is not None:
            tools = benchmark_config.extension.create_tools(
                benchmark_config.tools_spec, spec.framework
            )
        if tools is None:
            tools = generate_tools(benchmark_config.tools_spec, spec.framework)

        # 2. Agent runtime
        runtime = create_agent(
            agent_spec=benchmark_config.agent_spec,
            tools=tools,
            model=spec.agent_model,
            framework=spec.framework,
            extension=benchmark_config.extension,
            tools_spec=benchmark_config.tools_spec,
        )

        # 3. User simulator
        user_provider = _get_user_provider(
            user_provider_cache, spec.user_sim_model
        )
        universal_template = str(
            get_resource_path(agentops.prompt, "universal_user_template.jinja2")
        )
        llm_user = LLMUserV2(
            llm_client=user_provider,
            user_prompt_path=universal_template,
            enable_structured_output=spec.config.structured_output,
        )

        # 4. Controller
        controller = InstrumentedController(
            runtime=runtime,
            llm_user=llm_user,
            config=ControllerConfig(enable_verbose_logging=False),
        )

        # 5. Run conversation
        # WXO manages its own thread IDs server-side; passing a local
        # session label would cause a 400.  LangGraph uses the label
        # as a MemorySaver key, so keep it there.
        if spec.framework == "wxo":
            session_id = None
        else:
            session_id = (
                f"{spec.benchmark_name}-{spec.story_name}-"
                f"{spec.config.name}"
                f"-{spec.run_index}-{uuid.uuid4().hex[:8]}"
            )
        persona_profile = _resolve_persona(spec.config.persona)
        messages, _, _, _ = controller.run(
            task_n=(
                f"{spec.benchmark_name}-{spec.story_name}-"
                f"{spec.config.name}-{spec.run_index}"
            ),
            story=spec.story.story,
            agent_name=(spec.story.agent or benchmark_config.agent_spec.name),
            starting_user_input=spec.story.starting_sentence,
            persona_profile=persona_profile,
            enable_structured_output=spec.config.structured_output,
            session_id=session_id,
            max_user_turns=spec.max_user_turns,
        )

        user_turns = sum(1 for m in messages if m.role == "user")

        result = RunResult(
            spec=spec,
            termination_reason=controller.termination_reason,
            guardrail_notes=list(controller.guardrail_notes),
            user_turns=user_turns,
            messages=list(messages),
        )

        # 6. Metrics — resolved + run for this conversation
        eval_provider = _get_eval_provider(eval_provider_cache, spec.eval_model)
        try:
            metrics = resolve_metrics(
                benchmark_config.metrics,
                eval_provider,
                benchmark_config.extension,
            )
            ctx = run_metrics(metrics, messages, spec.story)
            result.metric_results = _flatten_metric_results(ctx)
            result.journey_success = bool(
                result.metric_results.get("is_success", False)
            )
            if "total_steps" in result.metric_results:
                result.total_steps = int(result.metric_results["total_steps"])
        except Exception as e:
            logger.warning(
                f"metric pipeline failed for run "
                f"{spec.benchmark_name}/{spec.config.name}/{spec.run_index}: {e}"
            )

        # 7. Universal user-sim analysis (hallucination, persona
        # behavior, failure diagnosis, role-switch). Runs for every
        # benchmark — these diagnostics are not domain-specific.
        # Role-switch detection derives "agent-only knowledge" from
        # tools.yaml mock outputs, so we pass tools_spec.
        try:
            run_user_sim_analysis(
                result,
                benchmark_config.tools_spec,
                eval_provider,
            )
        except Exception as e:
            logger.warning(
                f"user_sim_analysis failed for run "
                f"{spec.benchmark_name}/{spec.config.name}/"
                f"{spec.run_index}: {e}"
            )

        # 8. Extension post-run hook (benchmark-specific analysis on top)
        if benchmark_config.extension is not None:
            try:
                benchmark_config.extension.post_run(result, eval_provider)
            except Exception as e:
                logger.warning(
                    f"extension.post_run failed for run "
                    f"{spec.benchmark_name}/{spec.config.name}/"
                    f"{spec.run_index}: {e}"
                )

        return result

    except Exception as e:
        logger.exception(f"run failed: {e}")
        return _build_failed_result(spec, f"exception: {e}")


def _build_failed_result(spec: RunSpec, reason: str) -> RunResult:
    return RunResult(
        spec=spec,
        journey_success=False,
        termination_reason=reason,
    )


def _flatten_metric_results(ctx: dict) -> dict:
    """Flatten the nested {extractor|metric: {op_key: {eval_name: Metric}}}
    structure into a {eval_name: value} dict that's easy to consume.
    """
    out: dict[str, object] = {}
    for op_metrics in ctx.get("metric", {}).values():
        for eval_name, metric in op_metrics.items():
            value = getattr(metric, "value", metric)
            out[eval_name] = value
    return out


def _get_user_provider(
    cache: dict[str, "Provider"],
    model: str,
) -> "Provider":
    """Cached user-sim provider — uses get_provider() for auto-routing
    (gateway / watsonx / OpenAI).
    """
    with _provider_cache_lock:
        if model not in cache:
            cache[model] = get_provider(model_id=model)
        return cache[model]


def _get_eval_provider(
    cache: dict[str, "Provider"],
    model: str,
) -> "Provider":
    """Cached eval provider — always OpenAIProvider directly.

    Mirrors the existing benchmark's _make_eval_provider() which goes
    direct to OpenAI and avoids watsonx routing.
    """
    with _provider_cache_lock:
        if model not in cache:
            cache[model] = OpenAIProvider(
                model=model, api_key=os.getenv("OPENAI_API_KEY")
            )
        return cache[model]


def _resolve_persona(name: str | None) -> "PersonaProfile | None":
    if not name:
        return None
    try:
        persona_enum = Persona(name)
    except ValueError as e:
        raise ValueError(
            f"unknown persona '{name}' (known: "
            f"{[p.value for p in Persona]})"
        ) from e
    return get_persona_profile(persona_enum)
