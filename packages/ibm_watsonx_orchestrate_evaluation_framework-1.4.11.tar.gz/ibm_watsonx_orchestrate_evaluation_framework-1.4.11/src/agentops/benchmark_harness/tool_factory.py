"""Build framework-specific tool callables from ToolSpec."""

from __future__ import annotations

from typing import Any, Callable

from agentops.benchmark_harness.types import MockEntry, ToolSpec

_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
}


def generate_tools(
    tools_spec: list[ToolSpec],
    framework: str,
) -> list[Callable]:
    """Build framework-specific tool callables from specs."""
    if framework == "wxo":
        return []

    if framework != "langgraph":
        raise ValueError(
            f"unsupported framework for tool generation: {framework!r} "
            f"(supported: 'langgraph', 'wxo')"
        )

    # Lazy import so the harness doesn't require langchain unless used
    from langchain.tools import tool as langchain_tool

    tools: list[Callable] = []
    for spec in tools_spec:
        callable_ = _build_mock_callable(spec)
        tools.append(langchain_tool(callable_))
    return tools


def _build_mock_callable(spec: ToolSpec) -> Callable:
    """Construct a callable with name/docstring/annotations from spec."""
    param_names = list(spec.parameters.keys())

    def fn(**kwargs: Any) -> str:
        return _dispatch_mocks(spec, kwargs)

    annotations = {}
    for pname, pspec in spec.parameters.items():
        py_type = _TYPE_MAP.get(pspec.type)
        if py_type is None:
            raise KeyError(
                f"tool '{spec.name}' parameter '{pname}' has unsupported "
                f"type '{pspec.type}'"
            )
        annotations[pname] = py_type
    annotations["return"] = str

    fn.__name__ = spec.name
    fn.__qualname__ = spec.name
    fn.__doc__ = _format_docstring(spec)
    fn.__annotations__ = annotations

    # Build a real signature so langchain @tool can introspect it
    import inspect

    parameters = [
        inspect.Parameter(
            name=pname,
            kind=inspect.Parameter.KEYWORD_ONLY,
            annotation=annotations[pname],
        )
        for pname in param_names
    ]
    fn.__signature__ = inspect.Signature(
        parameters=parameters, return_annotation=str
    )
    return fn


def _format_docstring(spec: ToolSpec) -> str:
    lines = [spec.description.strip()]
    if spec.parameters:
        lines.append("")
        for pname, pspec in spec.parameters.items():
            desc = pspec.description.strip() if pspec.description else ""
            lines.append(f":param {pname}: {desc}")
    return "\n".join(lines)


def _dispatch_mocks(spec: ToolSpec, call_kwargs: dict[str, Any]) -> str:
    """Mock dispatch: highest-scoring matching mock wins, ties by order."""
    best_score = -1
    best_output: str | None = None
    for mock in spec.mocks:
        score, matched = _score_mock(mock, call_kwargs)
        if matched and score > best_score:
            best_score = score
            best_output = mock.output
    if best_output is not None:
        return best_output
    return spec.default_error


def _score_mock(
    mock: MockEntry,
    call_kwargs: dict[str, Any],
) -> tuple[int, bool]:
    """Return (score, matched).

    Matched is True iff every key in mock.input matches str(call_kwargs[key]).
    Score is the count of matched keys.
    """
    score = 0
    for key, expected in mock.input.items():
        if key not in call_kwargs:
            return 0, False
        if str(call_kwargs[key]) != str(expected):
            return 0, False
        score += 1
    return score, True
