import ast
import csv
import json
import os
from pathlib import Path

from jsonargparse import CLI

from agentops import __file__
from agentops.arg_configs import BatchAnnotateConfig
from agentops.prompt.template_render import (
    BatchTestCaseGeneratorTemplateRenderer,
)
from agentops.service_provider import get_provider

root_dir = os.path.dirname(__file__)
BATCH_TEST_CASE_GENERATOR_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "batch_testcase_prompt.jinja2"
)
EXAMPLE_PATH = os.path.join(root_dir, "prompt", "examples", "data_simple.json")


def parse_tools_with_filter(
    agent_name: str, tools_path: Path, allowed_tool_names: list[str]
) -> tuple[dict, list[dict]]:

    tool_data = []
    files_to_parse = []

    # Handle both single file and directory cases
    if tools_path.is_file():
        files_to_parse.append(tools_path)
    elif tools_path.is_dir():
        files_to_parse.extend(tools_path.glob("**/*.py"))
    else:
        raise ValueError(
            f"Tools path {tools_path} is neither a file nor directory"
        )

    for file_path in files_to_parse:
        try:
            with file_path.open("r", encoding="utf-8") as f:
                tools_code = f.read()

            parsed_code = ast.parse(tools_code)

            # Process only module-level functions
            for node in parsed_code.body:
                if isinstance(node, ast.FunctionDef):
                    tool_data.append(
                        {
                            "Function Name": node.name,
                            "Arguments": [arg.arg for arg in node.args.args],
                            "Docstring": ast.get_docstring(node),
                        }
                    )

        except Exception as e:
            print(f"Warning: Failed to parse {file_path}: {str(e)}")
            continue

    # Filter tools based on allowed names when provided, otherwise include all tools
    filtered_tools = (
        [
            tool
            for tool in tool_data
            if tool["Function Name"] in allowed_tool_names
        ]
        if allowed_tool_names
        else tool_data
    )

    if not filtered_tools:
        if allowed_tool_names:
            print(
                f"Warning: No matching tools found. Available tools: {[t['Function Name'] for t in tool_data]}"
            )
        else:
            print("Warning: No tools found to use for batch annotation.")

    return {"name": agent_name}, filtered_tools


# Step 2: Extract tool input/output examples from snapshot
def extract_inputs_from_snapshot(snapshot_path: Path) -> dict:
    with snapshot_path.open("r", encoding="utf-8") as f:
        snapshot = json.load(f)
    return snapshot.get("input_output_examples", {})


# Step 3: Load a single example test case just for structure
def load_example(example_path: Path):
    with example_path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return data


# Step 4: Prompt builder for N test cases from a given story
def build_prompt_for_story(
    agent,
    tools,
    tool_inputs,
    example_case: dict,
    story: str,
    num_variants: int = 2,
):
    renderer = BatchTestCaseGeneratorTemplateRenderer(
        BATCH_TEST_CASE_GENERATOR_PROMPT_PATH
    )

    tool_blocks = "\n".join(
        f"- Tool: {t['Function Name']}\n  Description: {t['Docstring']}\n  Args: {', '.join(t['Arguments']) or 'None'}"
        for t in tools
    )

    prompt = renderer.render(
        agent_name=agent["name"],
        tool_blocks=tool_blocks,
        tool_inputs_str=json.dumps(tool_inputs, indent=2),
        story=story,
        num_variants=num_variants,
        example_str=json.dumps(example_case, indent=2),
    )
    return prompt


# Step 5: Send prompt to LLM and save test cases
def generate_multiple_in_one(
    prompt,
    output_dir,
    starting_index,
    model_id="meta-llama/llama-3-3-70b-instruct",
    # model_id="gpt-4o",
):
    output_dir.mkdir(parents=True, exist_ok=True)

    # Legacy provider (e.g., watsonx)
    provider = get_provider(
        model_id=model_id,
        params={
            "min_new_tokens": 50,
            "decoding_method": "greedy",
            "max_new_tokens": 3000,
        },
    )
    response = provider.chat(prompt)

    try:
        raw_text = response.choices[0].message.content
        json_start = raw_text.find("[")
        json_end = raw_text.rfind("]") + 1
        json_block = raw_text[json_start:json_end].strip()

        test_cases = json.loads(json_block)
        assert isinstance(test_cases, list), "Expected list of test cases"

        for i, case in enumerate(test_cases, start=starting_index):
            out_file = output_dir / f"synthetic_test_case_{i}.json"
            with out_file.open("w", encoding="utf-8") as f:
                json.dump(case, f, indent=2)
            print(f"✅ Test case {i} written to {out_file}")

    except Exception as e:
        print("⚠️ Failed to parse or validate test case output.")
        print("Raw text:\n", raw_text)
        print("Error:", str(e))


def generate_test_cases_from_stories(
    agent_name: str,
    stories: list[str],
    tools_path: Path,
    snapshot_path: Path,
    output_dir: Path,
    allowed_tools: list[str],
    num_variants: int = 2,
):
    agent, tools = parse_tools_with_filter(
        agent_name, tools_path, allowed_tools
    )
    tool_inputs = extract_inputs_from_snapshot(snapshot_path)
    example_json = load_example(Path(EXAMPLE_PATH))

    # Load the snapshot to get the list of successful stories
    with snapshot_path.open("r", encoding="utf-8") as f:
        snapshot_data = json.load(f)

    successful_stories_from_snapshot = snapshot_data.get(
        "successful_stories", []
    )

    # Filter stories: only process ones that succeeded in tool planning
    stories_with_examples = []
    skipped_stories = []

    for story in stories:
        if story in successful_stories_from_snapshot:
            stories_with_examples.append(story)
        else:
            skipped_stories.append(story)
            print(f"⏭️ Skipping story (failed during tool planning): {story}")

    test_case_counter = 1
    failed_stories = []
    successful_stories = []

    for idx, story in enumerate(stories_with_examples, start=1):
        print(
            f"📝 Generating test cases for story {idx}/{len(stories_with_examples)}: {story}"
        )

        try:
            prompt = build_prompt_for_story(
                agent,
                tools,
                tool_inputs,
                example_json,
                story,
                num_variants=num_variants,
            )

            generate_multiple_in_one(
                prompt=prompt,
                output_dir=output_dir,
                starting_index=test_case_counter,
            )

            successful_stories.append(story)
            test_case_counter += num_variants

        except Exception as e:
            print(f"Error generating test cases for story '{story}': {e}")
            failed_stories.append({"story": story, "error": str(e)})
            continue

    # Print summary
    separator_line = f"\n{'='*60}"
    total_failed = len(skipped_stories) + len(failed_stories)
    print(separator_line)
    print("📊 Test Case Generation Summary:")
    print(f"  ✅ Successful stories: {len(successful_stories)}/{len(stories)}")
    print(f"  ❌ Failed stories: {total_failed}/{len(stories)}")

    if skipped_stories or failed_stories:
        print(separator_line)
        print("❌ Failed Stories:")
        idx = 1
        for story in skipped_stories:
            print(f"{idx}. {story} (failed during tool planning)")
            idx += 1
        for failure in failed_stories:
            print(f"{idx}. {failure['story']} (failed during test generation)")
            print(f"   Error: {failure['error']}")
            idx += 1

        # Overwrite failed stories CSV with failures from both tool planning and test generation
        failed_stories_path = (
            output_dir.parent / f"{agent_name}_failed_stories.csv"
        )
        with failed_stories_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["story", "agent", "error"])
            writer.writeheader()
            for story in skipped_stories:
                writer.writerow(
                    {
                        "story": story,
                        "agent": agent_name,
                        "error": "failed during tool planning",
                    }
                )
            for failure in failed_stories:
                writer.writerow(
                    {
                        "story": failure["story"],
                        "agent": agent_name,
                        "error": failure["error"],
                    }
                )

    # Show tip if there are any failed stories (from either stage)
    if skipped_stories or failed_stories:
        failed_stories_path = (
            output_dir.parent / f"{agent_name}_failed_stories.csv"
        )
        if failed_stories_path.exists():
            try:
                relative_path = failed_stories_path.relative_to(Path.cwd())
            except ValueError:
                # If path is not relative to cwd, use absolute path
                relative_path = failed_stories_path.resolve()
            print(
                f"\n💡 Tip: Failed stories have been saved to {relative_path}"
            )
            print(f"   You can re-run with: --stories-path {relative_path}")


def main(config: BatchAnnotateConfig):
    stories_path = Path(config.stories_path)

    stories = []
    agent_name = None
    with stories_path.open("r", encoding="utf-8", newline="") as f:
        csv_reader = csv.DictReader(f)
        for row in csv_reader:
            stories.append(row["story"])
            if agent_name is None:
                agent_name = row["agent"]

    tools_path = Path(config.tools_path)
    snapshot_path = stories_path.parent / f"{agent_name}_snapshot_llm.json"
    output_dir = Path(config.output_dir) / f"{agent_name}_test_cases"

    generate_test_cases_from_stories(
        agent_name,
        stories,
        tools_path,
        snapshot_path,
        output_dir,
        config.allowed_tools,
        num_variants=config.num_variants,
    )


if __name__ == "__main__":
    main(CLI(BatchAnnotateConfig, as_positional=False))
