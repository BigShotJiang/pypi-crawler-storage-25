from typing import Any, List, Mapping, Optional, Union

from agentops.extractors.agent_resp_extractor import AgentResponseExtractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData, Metric
from agentops.operator.operator_base import OperatorBase
from agentops.prompt import GPT_KEYWORD_MATCHING_PROMPT_PATH
from agentops.prompt.template_render import KeywordMatchingTemplateRenderer
from agentops.type import ChatCompletions, Message, TestCase


class KeywordMatchMetric(Evaluation):
    """Performs keyword matching."""

    def __init__(
        self, llm_client=None, prompt_path=GPT_KEYWORD_MATCHING_PROMPT_PATH
    ):
        super().__init__(llm_client)
        self.keyword_template = KeywordMatchingTemplateRenderer(prompt_path)
        self.dependencies = [AgentResponseExtractor()]

    def _keyword_match(self, keywords: list[str], text: str) -> bool:
        if not keywords or len(keywords) == 0:
            keyword_match = True
        else:
            keywords_text = "\n".join(keywords)
            prompt = self.keyword_template.render(
                keywords_text=keywords_text, response_text=text
            )
            output: ChatCompletions = self.llm_client.chat(prompt)
            output_str: str = output.choices[0].message.content
            keyword_match = output_str.strip().lower().startswith("true")
        return keyword_match

    def do_evaluate(
        self,
        messages: List[Message],
        ground_truth: Optional[TestCase] = None,
        metadata: Mapping[str, Any] = None,
        **kwargs,
    ) -> Union[Optional[Metric], List[Optional[Metric]]]:

        extracted_context = kwargs.get("extracted_context", {})
        # Get extracted text match data
        extractor_context = extracted_context.get("extractor", {})
        agent_response_extractor = extractor_context.get(
            OperatorBase.key(self.dependencies[0])
        )
        text_goals = agent_response_extractor.get("text_goals").value
        text_responses = agent_response_extractor.get("text_responses").value

        # keep track of keyword matches
        keyword_matches: list[Optional[bool]] = []

        for message in text_responses:
            for goal_detail in text_goals:
                keywords: list[str] = goal_detail.keywords

                keyword_match = False
                # failed llm call shouldn't break evaluation
                try:
                    keyword_match = self._keyword_match(
                        keywords=keywords, text=message.content
                    )
                except Exception:
                    pass
                keyword_matches.append(keyword_match)

        # Store extracted data
        metadata = metadata or {}
        metadata.update({"keyword_matches": keyword_matches})

        return EvaluatorData(
            eval_name="keyword_match",
            display_name="Keyword Match",
            value=any(keyword_matches),
            metadata=metadata,
        )
