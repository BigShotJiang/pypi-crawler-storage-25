import json
from importlib.abc import Traversable
from typing import Any, Dict, List, Mapping, Optional, Union

from pydantic import BaseModel

from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.prompt import RUBRIC_EVALUATION_PROMPT_PATH
from agentops.prompt.template_render import JinjaTemplateRenderer
from agentops.service_provider.provider import Provider
from agentops.type import ContentType, Message, TestCase
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)


class CriterionResult(BaseModel):
    """Result for a single evaluation criterion."""

    score: float
    reasoning: str


class RubricEvaluationResult(BaseModel):
    """Full result from the rubric-based evaluation."""

    custom_criteria: Dict[str, CriterionResult]
    overall_score: float
    summary: str


class RubricEvaluation(Evaluation):
    """
    LLM-as-a-Judge rubric-based evaluation with binary (pass/fail) scoring.

    Supports two types of ground truth:
    1. Gold answer - exact expected response in goal_details[].response
    2. Answer description - high-level criteria describing what the answer should contain

    Custom rubrics must be provided via config for evaluation dimensions.
    Each rubric is evaluated as pass (1) or fail (0). The overall_score is the average
    of all rubric scores.

    Example:
        # With custom rubrics (each gets a separate score)
        metric = RubricEvaluation(
            llm_client=provider,
            custom_criteria={
                "correctness": "Does the answer match the expected answer/description?",
                "policy_adherence": "Did the agent follow proper procedures?",
                "source_citations": "Response must include references to official policy documents",
                "date_format": "All dates must be in ISO format (YYYY-MM-DD)",
                "completeness": "Must cover PTO accrual, eligibility, and procedures"
            }
        )

        # Disable tool call inclusion
        metric = RubricEvaluation(
            llm_client=provider,
            custom_criteria={"correctness": "Does the answer match expected?"},
            include_tool_calls=False
        )
    """

    def __init__(
        self,
        llm_client: Optional[Provider] = None,
        custom_criteria: dict[str, str] | None = None,
        prompt_path: str | Traversable = RUBRIC_EVALUATION_PROMPT_PATH,
        include_tool_calls: bool = True,
    ):
        """
        Initialize the RubricEvaluation.

        Args:
            llm_client: LLM provider for evaluation
            custom_criteria: Required dict of custom evaluation rubrics
                e.g. {"source_citations": "Must include references to docs"}
            prompt_path: Path to the prompt template
            include_tool_calls: Whether to include tool call sequence in evaluation (default: True)
        """
        super().__init__(llm_client)
        if custom_criteria is None:
            raise ValueError("custom_criteria is required for RubricEvaluation")
        self.renderer = JinjaTemplateRenderer(str(prompt_path))
        self.custom_criteria = custom_criteria
        self.include_tool_calls = include_tool_calls

    def _extract_conversation_context(
        self, messages: List[Message]
    ) -> tuple[str, str]:
        """
        Extract conversation context, user request, and agent answer from messages.

        Returns:
            Tuple of (full_conversation, first_user_request)
        """
        # Build conversation transcript, optionally filtering tool calls
        conversation_parts = []
        for msg in messages:
            if msg.type == ContentType.text:
                content = (
                    msg.content
                    if isinstance(msg.content, str)
                    else str(msg.content)
                )
                conversation_parts.append(f"{msg.role}: {content}")
            elif msg.type == ContentType.tool_call:
                if self.include_tool_calls:
                    conversation_parts.append(
                        f"{msg.role}: [tool_call] {msg.content}"
                    )
            elif msg.type == ContentType.tool_response:
                if self.include_tool_calls:
                    conversation_parts.append(f"tool: {msg.content}")

        # Get first user request
        user_request = ""
        for msg in messages:
            if msg.role == "user" and msg.type == ContentType.text:
                user_request = (
                    msg.content
                    if isinstance(msg.content, str)
                    else str(msg.content)
                )
                break

        full_conversation = (
            "\n".join(conversation_parts)
            if conversation_parts
            else "No conversation"
        )
        return full_conversation, user_request

    def _get_expected_answer(self, ground_truth: Optional[TestCase]) -> str:
        """
        Get the expected answer from ground truth.

        Looks for text-type goal_details with a response field.
        """
        if not ground_truth or not ground_truth.goal_details:
            return ""

        expected_parts = []
        for goal_detail in ground_truth.goal_details:
            if goal_detail.type == ContentType.text and goal_detail.response:
                expected_parts.append(
                    f"**{goal_detail.name}**: {goal_detail.response}"
                )

        return "\n".join(expected_parts) if expected_parts else ""

    def _to_binary_score(self, score: float) -> float:
        """Convert any score to binary (0.0 or 1.0).

        Args:
            score: The raw score from the LLM (typically 0.0-1.0)

        Returns:
            float: 1.0 if score >= 0.5 (PASS), 0.0 otherwise (FAIL)
        """
        return 1.0 if score >= 0.5 else 0.0

    def _parse_llm_response(
        self, response_text: str, custom_criteria_keys: List[str]
    ) -> RubricEvaluationResult:
        """Parse the LLM response into structured result with binary scores."""
        try:
            response_text = response_text.strip()
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]

            data = json.loads(response_text.strip())

            # Parse custom criteria results with binary normalization
            custom_results = {}
            if not data.get("custom_criteria"):
                logger.error(
                    "Rubric evaluation metric: LLM failed to return results for custom criteria"
                )
            else:
                for key in custom_criteria_keys:
                    if key in data["custom_criteria"]:
                        criterion_data = data["custom_criteria"][key]
                        custom_results[key] = CriterionResult(
                            score=self._to_binary_score(
                                criterion_data.get("score", 0)
                            ),
                            reasoning=criterion_data.get("reasoning", ""),
                        )
                    else:
                        logger.warning(
                            f"Rubric evaluation metric: Missing criterion '{key}' in LLM response"
                        )

            # Calculate overall score as average of all rubric scores
            all_scores = [c.score for c in custom_results.values()]
            overall_score = (
                sum(all_scores) / len(all_scores) if all_scores else 0.0
            )

            return RubricEvaluationResult(
                custom_criteria=custom_results,
                overall_score=overall_score,
                summary=data.get("summary", ""),
            )
        except (json.JSONDecodeError, KeyError, TypeError) as e:
            return RubricEvaluationResult(
                custom_criteria={},
                overall_score=0.0,
                summary=f"Evaluation failed: {e}",
            )

    def do_evaluate(
        self,
        messages: List[Message],
        ground_truth: Optional[TestCase] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        **kwargs,
    ) -> Union[EvaluatorData, List[EvaluatorData]]:
        """
        Evaluate the agent's answer using custom rubric criteria.

        Args:
            messages: Conversation messages
            ground_truth: Ground truth data containing expected answers
            metadata: Additional metadata

        Returns:
            List of EvaluatorData with scores for each criterion
        """
        conversation_context, user_request = self._extract_conversation_context(
            messages
        )

        expected_answer = self._get_expected_answer(ground_truth)

        custom_criteria_keys = list(self.custom_criteria.keys())

        prompt_messages = self.renderer.render(
            conversation_context=conversation_context,
            user_request=user_request,
            expected_answer=expected_answer,
            custom_criteria=self.custom_criteria,
        )

        response = self.llm_client.chat(prompt_messages)
        response_text = response.choices[0].message.content

        result = self._parse_llm_response(response_text, custom_criteria_keys)

        # Add individual custom criteria metrics
        metrics = []
        for name, criterion_result in result.custom_criteria.items():
            metrics.append(
                EvaluatorData(
                    eval_name=name,
                    value=criterion_result.score,
                    comment=criterion_result.reasoning,
                    metadata={
                        **(dict(metadata) if metadata else {}),
                        "criterion": name,
                    },
                )
            )

        # Add overall score (average of all rubric scores)
        metrics.append(
            EvaluatorData(
                eval_name="overall_score",
                value=result.overall_score,
                comment=result.summary,
                metadata={
                    **(dict(metadata) if metadata else {}),
                    "criterion": "overall",
                },
            )
        )

        return metrics


if __name__ == "__main__":
    from agentops.service_provider import get_provider

    llm_client = get_provider(model_id="openai/gpt-oss-120b")
    metric = RubricEvaluation(llm_client)
    messages = [
        Message(
            role="user",
            content="What is Labcorp's annual leave policy?",
            type=ContentType.text,
        ),
        Message(
            role="assistant",
            content="I'm not sure about the specific policy. You should check with HR.",
            type=ContentType.text,
        ),
    ]

    from agentops.type import GoalDetailOrchestrate

    gt = TestCase(
        story="User wants to know about annual leave policy",
        starting_sentence="What is Labcorp's annual leave policy?",
        goals={"explain_policy": []},
        goal_details=[
            GoalDetailOrchestrate(
                name="explain_policy",
                type=ContentType.text,
                response="""PTO accrual is 15 days for 0-2 years, 20 days for 3-5 years, and 25 days for 6+ years.
    Full-time employees are eligible after 90 days. Requests must be submitted 2 weeks in advance through the HR portal.""",
            )
        ],
    )
    output = metric.evaluate(messages=messages, ground_truth=gt)

    for metric in output["metric"]["RubricEvaluation"]:
        print(metric)
