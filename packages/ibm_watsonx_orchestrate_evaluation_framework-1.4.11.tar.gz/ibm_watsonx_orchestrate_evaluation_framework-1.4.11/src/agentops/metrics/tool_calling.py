from typing import List, Union
from venv import logger

from agentops.extractors import ExpectedToolExtractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData, ToolCallAndRoutingMetrics
from agentops.operator.operator_base import OperatorBase
from agentops.type import ContentType
from agentops.utils.gold_label import get_gold_tool_calls


class ToolCalling(Evaluation):
    def __init__(self, llm_client=None):
        super().__init__(llm_client)
        self.dependencies = [ExpectedToolExtractor(llm_client=llm_client)]

    def do_evaluate(
        self,
        messages,
        ground_truth=None,
        metadata=None,
        **kwargs,
    ) -> Union[EvaluatorData, List[EvaluatorData]]:
        extractor_context = kwargs.get("extracted_context", {}).get(
            "extractor", {}
        )
        expected_tool_extractor = extractor_context.get(
            OperatorBase.key(self.dependencies[0])
        )
        expected_tools = expected_tool_extractor.get("correct_tool_calls").value
        incorrect_param_tool_idx = expected_tool_extractor.get(
            "incorrect_param_tool_idx"
        ).value
        relevant_tool_call_idx = expected_tool_extractor.get(
            "relevant_tool_call_idx"
        ).value

        dataset_name = kwargs.get("dataset", "")

        tool_dictionary = get_gold_tool_calls(ground_truth=ground_truth)
        total_tool_calls = len(
            [
                message
                for message in messages
                if message.type == ContentType.tool_call
            ]
        )
        num_relevant_tool_calls = len(relevant_tool_call_idx)
        tool_calls_with_incorrect_parameter = len(incorrect_param_tool_idx)
        correct_tool_calls = len(expected_tools)

        # missed tool calls are tools that were not called by the agent
        # an agent may have called a relevant tool but with incorrect params, this is not a missed tool call
        # a missed tool call is a tool in the ground truth that was not called at all by the agent
        relevant_tool_calls = [
            message
            for i, message in enumerate(messages)
            if i in relevant_tool_call_idx
        ]
        relevant_tool_call_names = set()
        for message in relevant_tool_calls:
            if len(message.tool_calls) > 0:
                tool_name = message.tool_calls[0].function.name
                relevant_tool_call_names.add(tool_name)
            else:
                logger.warning("Relevant tool call message has no tool calls")

        missed_tool_call_count = len(
            set(tool_dictionary.keys()) - relevant_tool_call_names
        )

        tool_match_success = (len(tool_dictionary) - correct_tool_calls) == 0

        # When there are no expected tool calls, set count metrics to NaN
        expected_tool_calls_count = len(tool_dictionary)
        if expected_tool_calls_count == 0:
            correct_tool_calls = float("nan")
            tool_calls_with_incorrect_parameter = float("nan")

        tool_call_metrics = ToolCallAndRoutingMetrics(
            dataset_name=dataset_name,
            total_tool_calls=total_tool_calls,
            expected_tool_calls=expected_tool_calls_count,
            correct_tool_calls=correct_tool_calls,
            relevant_tool_calls=num_relevant_tool_calls,
            missed_tool_calls=missed_tool_call_count,
            tool_calls_with_incorrect_parameter=tool_calls_with_incorrect_parameter,
            tool_match_success=tool_match_success,
        )
        tool_call_metrics = tool_call_metrics.model_dump()

        metrics = []
        tools = {
            "total_tool_calls": "Total Tool Calls",
            "expected_tool_calls": "Expected Tool Calls",
            "correct_tool_calls": "Correct Tool Calls",
            "missed_tool_calls": "Missed Tool Calls",
            "relevant_tool_calls": "Relevant Tool Calls",
            "tool_calls_with_incorrect_parameter": "Tool Calls with Incorrect Parameters",
            "tool_call_recall": "Tool Call Recall",
            "tool_call_precision": "Tool Call Precision",
            "tool_match_success": "Tool Match Success",
        }
        for tool, display_name in tools.items():
            metric = EvaluatorData(
                eval_name=tool,
                display_name=display_name,
                value=tool_call_metrics.get(tool),
                metadata=metadata,
            )
            metrics.append(metric)

        return metrics
