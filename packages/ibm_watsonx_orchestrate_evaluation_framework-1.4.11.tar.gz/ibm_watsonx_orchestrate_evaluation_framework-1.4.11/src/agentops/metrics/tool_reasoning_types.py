from enum import StrEnum


class ToolReasoningType(StrEnum):
    IRRELEVANT_TOOL_CALL = "irrelevant tool call"
    INCORRECT_PARAMETERS = "incorrect parameter"
    MISSING_TOOL_CALL = "missing tool call"
    RUNTIME_ERROR = "runtime error"
