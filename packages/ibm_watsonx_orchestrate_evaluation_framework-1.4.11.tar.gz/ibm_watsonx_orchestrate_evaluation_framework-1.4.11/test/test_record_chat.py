import tempfile
import pytest
import json
from unittest.mock import MagicMock
from agentops.record.record_chat import (
    get_recent_runs,
    annotate_messages,
    has_messages_changed,
    record_chats,
    generate_story,
    extract_tool_interactions,
)
from agentops.type import Message, ContentType
from agentops.arg_configs import (
    ChatRecordingConfig,
    KeywordsGenerationConfig,
)


@pytest.fixture
def dummy_messages():
    return [Message(role="user", content="hi", type="text")]


@pytest.fixture
def dummy_keyword_config():
    return KeywordsGenerationConfig()

@pytest.fixture
def dummy_chat_recording_config():
    return ChatRecordingConfig(output_dir="")


@pytest.fixture
def dummy_backend():
    class DummyBackend:
        def get_messages(self, thread_id):
            return [Message(role="user", content="hi", type="text")]

        def get_agent_name_from_thread_id(self, thread_id):
            return "agent"

    return DummyBackend


@pytest.fixture
def dummy_annotator():
    class DummyAnnotator:
        def __init__(self, messages, keywords_generation_config, summary_generation_config, provider_config, config=None):
            self.messages = messages
            self.keywords_generation_config = keywords_generation_config
            self.summary_generation_config = summary_generation_config
            self.provider_config = provider_config
            self.config = config

        def generate(self, config=None):
            return {"goals": {}, "goal_details": [], "starting_sentence": "start"}

    return DummyAnnotator


dummy_annotated_data = {
    "goals": {},
    "goal_details": [],
    "starting_sentence": "start",
    "agent": "agent",
    "story": "story",
}


def test_get_recent_runs():
    class DummyWXOClient:
        def __init__(self, service_url):
            self.service_url = service_url
            self._calls = []

        def get(self, path, params):
            self._calls.append((path, params))
            # Simulate a paginated response
            if params["offset"] == 0:
                return MagicMock(
                    json=lambda: {
                        "total": 2,
                        "data": [
                            {
                                "thread_id": "t1",
                                "completed_at": "2024-07-08T10:00:00.000Z",
                                "started_at": "2024-07-08T09:59:00.000Z",
                            },
                            {
                                "thread_id": "t2",
                                "completed_at": None,
                                "started_at": "2024-07-08T09:58:00.000Z",
                            },
                        ],
                    }
                )
            else:
                return MagicMock(json=lambda: {"data": []})

    client = DummyWXOClient("http://localhost")
    runs = get_recent_runs(client)
    assert len(runs) == 2
    assert runs[0]["thread_id"] == "t1"
    assert runs[1]["thread_id"] == "t2"
    # Check that the client was called with correct params
    assert client._calls[0][0] == "v1/orchestrate/runs"
    assert client._calls[0][1]["offset"] == 0


def test_get_recent_runs_empty():
    class DummyWXOClient:
        def __init__(self, service_url):
            self.service_url = service_url

        def get(self, path, params):
            return MagicMock(json=lambda: {"total": 0, "data": []})

    client = DummyWXOClient("http://localhost")
    runs = get_recent_runs(client)
    assert runs == []


def test_get_recent_runs_missing_completed_at():
    class DummyWXOClient:
        def __init__(self, service_url):
            self.service_url = service_url

        def get(self, path, params):
            return MagicMock(
                json=lambda: {
                    "total": 1,
                    "data": [
                        {"thread_id": "t1", "started_at": "2024-07-08T09:59:00.000Z"}
                    ],
                }
            )

    client = DummyWXOClient("http://localhost")
    runs = get_recent_runs(client)
    assert runs[0]["thread_id"] == "t1"


def test_has_messages_changed(dummy_messages):
    prev = {}
    assert has_messages_changed("tid", dummy_messages, prev)
    assert not has_messages_changed("tid", dummy_messages, prev)


def test_has_messages_changed_multiple_threads():
    messages1 = [Message(role="user", content="hi", type="text")]
    messages2 = [Message(role="user", content="bye", type="text")]
    prev = {}
    assert has_messages_changed("tid1", messages1, prev)
    assert has_messages_changed("tid2", messages2, prev)
    assert not has_messages_changed("tid1", messages1, prev)
    assert not has_messages_changed("tid2", messages2, prev)


def test_has_messages_changed_content_change():
    messages1 = [Message(role="user", content="hi", type="text")]
    messages2 = [Message(role="user", content="bye", type="text")]
    prev = {}
    assert has_messages_changed("tid", messages1, prev)
    assert has_messages_changed("tid", messages2, prev)


def test_annotate_messages(monkeypatch, dummy_messages, dummy_chat_recording_config, dummy_annotator):
    monkeypatch.setattr(
        "agentops.record.record_chat.generate_story",
        lambda annotated_data, story_config=None, provider_config=None: "story"
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.DataAnnotator", dummy_annotator
    )
    result = annotate_messages("agent", dummy_messages, dummy_chat_recording_config)
    assert result == {
        "goals": {},
        "goal_details": [],
        "starting_sentence": "start",
        "agent": "agent",
        "story": "story",
    }


def test_annotate_messages_no_agent(
    monkeypatch, dummy_messages, dummy_chat_recording_config, dummy_annotator
):
    monkeypatch.setattr(
        "agentops.record.record_chat.generate_story",
        lambda annotated_data, story_config=None, provider_config=None: "story"
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.DataAnnotator", dummy_annotator
    )
    result = annotate_messages(agent_name=None, messages=dummy_messages, chat_recording_config=dummy_chat_recording_config)
    assert result == {
        "goals": {},
        "goal_details": [],
        "starting_sentence": "start",
        "story": "story",
    }

def test_generate_story(monkeypatch):
    class DummyRenderer:
        def __init__(self, path):
            self.path = path

        def render(self, input_data):
            return "prompt"

    class DummyProvider:
        class _Message:
            def __init__(self, content):
                self.content = content

        class _Choice:
            def __init__(self, content):
                self.message = DummyProvider._Message(content)

        class _Response:
            def __init__(self, content):
                self.choices = [DummyProvider._Choice(content)]

        def __init__(self, **kwargs):
            pass

        def chat(self, prompt):
            return DummyProvider._Response(" result\n")

    monkeypatch.setattr(
        "agentops.record.record_chat.StoryGenerationTemplateRenderer",
        DummyRenderer,
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_provider",
        lambda **kwargs: DummyProvider(),
    )

    res = generate_story(dummy_annotated_data)
    assert res == "result"


def test_generate_story_provider_exception(monkeypatch):
    class DummyRenderer:
        def __init__(self, path):
            self.path = path

        def render(self, input_data):
            return "prompt"

    class DummyProvider:
        class _Message:
            def __init__(self, content):
                self.content = content

        class _Choice:
            def __init__(self, content):
                self.message = DummyProvider._Message(content)

        class _Response:
            def __init__(self, content):
                self.choices = [DummyProvider._Choice(content)]

        def __init__(self, **kwargs):
            pass

        def chat(self, prompt):
            raise Exception("provider error")

    monkeypatch.setattr(
        "agentops.record.record_chat.StoryGenerationTemplateRenderer",
        DummyRenderer,
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_provider",
        lambda **kwargs: DummyProvider(),
    )
    with pytest.raises(Exception):
        generate_story(dummy_annotated_data)


def test_record_chats(monkeypatch, dummy_keyword_config, dummy_backend):
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs",
        lambda client: [
            {
                "thread_id": "tid",
                "started_at": "2099-01-01T00:00:00.000Z",
                "completed_at": "2099-01-01T00:01:00.000Z",
            }
        ],
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.WXORuntimeAdapter",
        lambda wxo_client: dummy_backend,
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.annotate_messages",
        lambda agent, messages, config: {
            "goals": {},
            "agent": agent,
            "story": "story",
        },
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.has_messages_changed",
        lambda tid, msgs, prev: True,
    )
    monkeypatch.setattr(
        "agentops.service_instance.tenant_setup", lambda url, tenant: ("token", url, {})
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_wxo_client",
        lambda url, tenant, token: MagicMock(service_url=url),
    )
    monkeypatch.setattr("time.sleep", lambda x: None)
    call_count = {"count": 0}

    def get_recent_runs_once(client):
        if call_count["count"] == 0:
            call_count["count"] += 1
            return [
                {
                    "thread_id": "tid",
                    "started_at": "2099-01-01T00:00:00.000Z",
                    "completed_at": "2099-01-01T00:01:00.000Z",
                }
            ]
        raise KeyboardInterrupt()

    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs", get_recent_runs_once
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        config = ChatRecordingConfig(
            service_url="http://localhost",
            tenant_name="tenant",
            output_dir=tmpdir,
            keywords_generation_config=dummy_keyword_config,
        )
        record_chats(config)


def test_record_skips_missing_thread_id(monkeypatch, dummy_keyword_config, dummy_backend):
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs",
        lambda client: [
            {
                "started_at": "2099-01-01T00:00:00.000Z",
                "completed_at": "2099-01-01T00:01:00.000Z",
            }
        ],
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.WXORuntimeAdapter",
        lambda wxo_client: dummy_backend,
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.annotate_messages",
        lambda agent, messages, config: {
            "goals": {},
            "agent": agent,
            "story": "story",
        },
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.has_messages_changed",
        lambda tid, msgs, prev: True,
    )
    monkeypatch.setattr(
        "agentops.service_instance.tenant_setup", lambda url, tenant: ("token", url, {})
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_wxo_client",
        lambda url, tenant, token: MagicMock(service_url=url),
    )
    monkeypatch.setattr("time.sleep", lambda x: None)
    call_count = {"count": 0}

    def get_recent_runs_once(client):
        if call_count["count"] == 0:
            call_count["count"] += 1
            return [
                {
                    "started_at": "2099-01-01T00:00:00.000Z",
                    "completed_at": "2099-01-01T00:01:00.000Z",
                }
            ]
        raise KeyboardInterrupt()

    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs", get_recent_runs_once
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        config = ChatRecordingConfig(
            service_url="http://localhost",
            tenant_name="tenant",
            output_dir=tmpdir,
            keywords_generation_config=dummy_keyword_config,
        )
        record_chats(config)


def test_record_skips_missing_started_at(monkeypatch, dummy_keyword_config, dummy_backend):
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs",
        lambda client: [
            {"thread_id": "tid", "completed_at": "2099-01-01T00:01:00.000Z"}
        ],
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.WXORuntimeAdapter",
        lambda wxo_client: dummy_backend,
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.annotate_messages",
        lambda agent, messages, config: {
            "goals": {},
            "agent": agent,
            "story": "story",
        },
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.has_messages_changed",
        lambda tid, msgs, prev: True,
    )
    monkeypatch.setattr(
        "agentops.service_instance.tenant_setup", lambda url, tenant: ("token", url, {})
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_wxo_client",
        lambda url, tenant, token: MagicMock(service_url=url),
    )
    monkeypatch.setattr("time.sleep", lambda x: None)
    call_count = {"count": 0}

    def get_recent_runs_once(client):
        if call_count["count"] == 0:
            call_count["count"] += 1
            return [{"thread_id": "tid", "completed_at": "2099-01-01T00:01:00.000Z"}]
        raise KeyboardInterrupt()

    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs", get_recent_runs_once
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        config = ChatRecordingConfig(
            service_url="http://localhost",
            tenant_name="tenant",
            output_dir=tmpdir,
            keywords_generation_config=dummy_keyword_config,
        )
        record_chats(config)


def test_record_agent_name_exception(monkeypatch, dummy_keyword_config):
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs",
        lambda client: [
            {
                "thread_id": "tid",
                "started_at": "2099-01-01T00:00:00.000Z",
                "completed_at": "2099-01-01T00:01:00.000Z",
            }
        ],
    )

    class DummyBackend:
        def get_messages(self, thread_id):
            return [Message(role="user", content="hi", type="text")]

        def get_agent_name_from_thread_id(self, thread_id):
            raise Exception("fail")

    monkeypatch.setattr(
        "agentops.record.record_chat.WXORuntimeAdapter",
        lambda wxo_client: DummyBackend(),
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.annotate_messages",
        lambda agent, messages, config: {
            "goals": {},
            "agent": agent,
            "story": "story",
        },
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.has_messages_changed",
        lambda tid, msgs, prev: True,
    )
    monkeypatch.setattr(
        "agentops.service_instance.tenant_setup", lambda url, tenant: ("token", url, {})
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_wxo_client",
        lambda url, tenant, token: MagicMock(service_url=url),
    )
    monkeypatch.setattr("time.sleep", lambda x: None)
    call_count = {"count": 0}

    def get_recent_runs_once(client):
        if call_count["count"] == 0:
            call_count["count"] += 1
            return [
                {
                    "thread_id": "tid",
                    "started_at": "2099-01-01T00:00:00.000Z",
                    "completed_at": "2099-01-01T00:01:00.000Z",
                }
            ]
        raise KeyboardInterrupt()

    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs", get_recent_runs_once
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        config = ChatRecordingConfig(
            service_url="http://localhost",
            tenant_name="tenant",
            output_dir=tmpdir,
            keywords_generation_config=dummy_keyword_config,
        )
        record_chats(config)


def test_record_chats_max_retries(monkeypatch, dummy_keyword_config):
    # Patch get_recent_runs to return a valid thread only the first time, then raise KeyboardInterrupt to stop the loop
    call_count = {"count": 0}

    def get_recent_runs_once(client):
        if call_count["count"] == 0:
            call_count["count"] += 1
            return [
                {
                    "thread_id": "tid",
                    "started_at": "2099-01-01T00:00:00.000Z",
                    "completed_at": "2099-01-01T00:01:00.000Z",
                }
            ]
        raise KeyboardInterrupt()

    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs",
        get_recent_runs_once,
    )
    # Patch backend to raise on get_messages, simulating a processing failure
    msg_call_count = {"count": 0}

    class FailingBackend:
        def get_messages(self, thread_id):
            msg_call_count["count"] += 1
            raise Exception("fail")

        def get_agent_name_from_thread_id(self, thread_id):
            return "agent"

    monkeypatch.setattr(
        "agentops.record.record_chat.WXORuntimeAdapter",
        lambda wxo_client: FailingBackend(),
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.annotate_messages",
        lambda agent, messages, config: {
            "goals": {},
            "agent": agent,
            "story": "story",
        },
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.has_messages_changed",
        lambda tid, msgs, prev: True,
    )
    monkeypatch.setattr(
        "agentops.service_instance.tenant_setup", lambda url, tenant: ("token", url, {})
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_wxo_client",
        lambda url, tenant, token: MagicMock(service_url=url),
    )
    monkeypatch.setattr("time.sleep", lambda x: None)

    with tempfile.TemporaryDirectory() as tmpdir:
        config = ChatRecordingConfig(
            service_url="http://localhost",
            tenant_name="tenant",
            output_dir=tmpdir,
            keywords_generation_config=dummy_keyword_config,
            max_retries=3,  # Should not matter for failed threads
        )
        try:
            record_chats(config)
        except KeyboardInterrupt:
            pass
        # Only one attempt should be made for a failed thread
        assert (
            msg_call_count["count"] == 1
        ), f"Expected 1 attempt for failed thread, got {msg_call_count['count']}"



def test_extract_tool_interactions():
    """Test the extract_tool_interactions function with JSON parsing"""
    
    # Create sample messages with tool calls and responses
    messages = [
        # User message
        Message(
            role="user",
            content="Search for quarterly reports",
            type=ContentType.text
        ),
        # Tool call 1
        Message(
            role="assistant",
            content=json.dumps({
                "type": "tool_call",
                "tool_call_id": "call_abc123",
                "name": "search_documents",
                "args": {"query": "quarterly reports", "limit": 5}
            }),
            type=ContentType.tool_call
        ),
        # Tool response 1 (success) - JSON string that will be parsed
        Message(
            role="assistant",
            content=json.dumps({
                "type": "tool_response",
                "tool_call_id": "call_abc123",
                "output": '[{"title": "Q1 Report", "id": "doc1"}]'
            }),
            type=ContentType.tool_response
        ),
        # Tool call 2
        Message(
            role="assistant",
            content=json.dumps({
                "type": "tool_call",
                "tool_call_id": "call_def456",
                "name": "send_email",
                "args": {"to": "user@example.com", "subject": "Report Summary"}
            }),
            type=ContentType.tool_call
        ),
        # Tool response 2 (error)
        Message(
            role="assistant",
            content=json.dumps({
                "type": "tool_response",
                "tool_call_id": "call_def456",
                "output": "Error: Invalid email address"
            }),
            type=ContentType.tool_response
        ),
        # Final assistant response
        Message(
            role="assistant",
            content="I found the quarterly reports but encountered an error sending the email.",
            type=ContentType.text
        )
    ]
    
    # Extract tool interactions
    interactions = extract_tool_interactions(messages)
    
    # Verify results
    assert len(interactions) == 2, f"Expected 2 interactions, got {len(interactions)}"
    
    # Check first interaction (successful) - response should be parsed as list
    interaction1 = interactions[0]
    assert interaction1['tool_call_id'] == "call_abc123"
    assert interaction1['tool_name'] == "search_documents"
    assert interaction1['tool_args'] == {"query": "quarterly reports", "limit": 5}
    # Response should be parsed from JSON string to list
    assert isinstance(interaction1['tool_response'], list), "Response should be parsed as list"
    assert interaction1['tool_response'] == [{"title": "Q1 Report", "id": "doc1"}]
    assert interaction1['success'] is True
    
    # Check second interaction (failed)
    interaction2 = interactions[1]
    assert interaction2['tool_call_id'] == "call_def456"
    assert interaction2['tool_name'] == "send_email"
    assert interaction2['tool_args'] == {"to": "user@example.com", "subject": "Report Summary"}
    assert interaction2['tool_response'] == "Error: Invalid email address"
    assert interaction2['success'] is False  # Should detect "Error" keyword


def test_nested_json_parsing():
    """Test recursive JSON parsing for nested JSON strings"""
    
    messages = [
        # Tool call
        Message(
            role="assistant",
            content=json.dumps({
                "type": "tool_call",
                "tool_call_id": "call_nested",
                "name": "process_data",
                "args": {"data": "test"}
            }),
            type=ContentType.tool_call
        ),
        # Tool response with nested JSON (double-encoded)
        Message(
            role="assistant",
            content=json.dumps({
                "type": "tool_response",
                "tool_call_id": "call_nested",
                "output": '{"response": "{\\"nested\\": \\"value\\"}"}'
            }),
            type=ContentType.tool_response
        ),
    ]
    
    interactions = extract_tool_interactions(messages)
    
    assert len(interactions) == 1
    interaction = interactions[0]
    
    # Should be recursively parsed to nested dict
    assert isinstance(interaction['tool_response'], dict), "Should be parsed as dict"
    assert "response" in interaction['tool_response']
    assert isinstance(interaction['tool_response']['response'], dict), "Nested value should also be parsed"
    assert interaction['tool_response']['response'] == {"nested": "value"}


def test_extract_tool_interactions_no_tools():
    """Test extract_tool_interactions with no tool calls"""
    messages = [
        Message(role="user", content="Hello", type=ContentType.text),
        Message(role="assistant", content="Hi there!", type=ContentType.text)
    ]
    
    interactions = extract_tool_interactions(messages)
    assert len(interactions) == 0


def test_extract_tool_interactions_unmatched_response():
    """Test extract_tool_interactions with tool response but no matching call"""
    messages = [
        Message(
            role="assistant",
            content=json.dumps({
                "type": "tool_response",
                "tool_call_id": "call_orphan",
                "output": "orphaned response"
            }),
            type=ContentType.tool_response
        ),
    ]
    
    interactions = extract_tool_interactions(messages)
    # Should not create an interaction for orphaned response
    assert len(interactions) == 0


def test_context_variables_valid_json(monkeypatch, dummy_keyword_config, dummy_backend):
    """Test that valid context_variables JSON is parsed and added to annotated data"""
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs",
        lambda client: [
            {
                "thread_id": "tid",
                "started_at": "2099-01-01T00:00:00.000Z",
                "completed_at": "2099-01-01T00:01:00.000Z",
            }
        ],
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.WXORuntimeAdapter",
        lambda wxo_client: dummy_backend(),
    )
    
    # Track what annotate_messages returns
    def mock_annotate(agent, messages, config):
        return {
            "goals": {},
            "agent": agent,
            "story": "story",
        }
    
    monkeypatch.setattr(
        "agentops.record.record_chat.annotate_messages",
        mock_annotate,
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.has_messages_changed",
        lambda tid, msgs, prev: True,
    )
    monkeypatch.setattr(
        "agentops.service_instance.tenant_setup", lambda url, tenant: ("token", url, {})
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_wxo_client",
        lambda url, tenant, token: MagicMock(service_url=url),
    )
    monkeypatch.setattr("time.sleep", lambda x: None)
    
    call_count = {"count": 0}
    
    def get_recent_runs_once(client):
        if call_count["count"] == 0:
            call_count["count"] += 1
            return [
                {
                    "thread_id": "tid",
                    "started_at": "2099-01-01T00:00:00.000Z",
                    "completed_at": "2099-01-01T00:01:00.000Z",
                }
            ]
        raise KeyboardInterrupt()
    
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs", get_recent_runs_once
    )
    
    with tempfile.TemporaryDirectory() as tmpdir:
        config = ChatRecordingConfig(
            service_url="http://localhost",
            tenant_name="tenant",
            output_dir=tmpdir,
            keywords_generation_config=dummy_keyword_config,
            context_variables='{"user_id": "123", "environment": "production"}',
        )
        record_chats(config)
        
        # Read the output file and verify context_variables was added
        import os
        annotation_file = os.path.join(tmpdir, "tid_annotated_data.json")
        assert os.path.exists(annotation_file), "Annotation file should exist"
        
        with open(annotation_file, "r") as f:
            data = json.load(f)
        
        assert "context_variables" in data, "context_variables should be in output"
        assert data["context_variables"]["user_id"] == "123"
        assert data["context_variables"]["environment"] == "production"


def test_context_variables_invalid_json(monkeypatch, dummy_keyword_config, dummy_backend, capsys):
    """Test that invalid context_variables JSON triggers warning but doesn't crash"""
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs",
        lambda client: [
            {
                "thread_id": "tid",
                "started_at": "2099-01-01T00:00:00.000Z",
                "completed_at": "2099-01-01T00:01:00.000Z",
            }
        ],
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.WXORuntimeAdapter",
        lambda wxo_client: dummy_backend(),
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.annotate_messages",
        lambda agent, messages, config: {
            "goals": {},
            "agent": agent,
            "story": "story",
        },
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.has_messages_changed",
        lambda tid, msgs, prev: True,
    )
    monkeypatch.setattr(
        "agentops.service_instance.tenant_setup", lambda url, tenant: ("token", url, {})
    )
    monkeypatch.setattr(
        "agentops.record.record_chat.get_wxo_client",
        lambda url, tenant, token: MagicMock(service_url=url),
    )
    monkeypatch.setattr("time.sleep", lambda x: None)
    
    call_count = {"count": 0}
    
    def get_recent_runs_once(client):
        if call_count["count"] == 0:
            call_count["count"] += 1
            return [
                {
                    "thread_id": "tid",
                    "started_at": "2099-01-01T00:00:00.000Z",
                    "completed_at": "2099-01-01T00:01:00.000Z",
                }
            ]
        raise KeyboardInterrupt()
    
    monkeypatch.setattr(
        "agentops.record.record_chat.get_recent_runs", get_recent_runs_once
    )
    
    with tempfile.TemporaryDirectory() as tmpdir:
        config = ChatRecordingConfig(
            service_url="http://localhost",
            tenant_name="tenant",
            output_dir=tmpdir,
            keywords_generation_config=dummy_keyword_config,
            context_variables='{"invalid": json}',  # Invalid JSON
        )
        record_chats(config)
        
        # Read the output file and verify context_variables was NOT added
        import os
        annotation_file = os.path.join(tmpdir, "tid_annotated_data.json")
        assert os.path.exists(annotation_file), "Annotation file should exist"
        
        with open(annotation_file, "r") as f:
            data = json.load(f)
        
        assert "context_variables" not in data, "context_variables should NOT be in output for invalid JSON"


