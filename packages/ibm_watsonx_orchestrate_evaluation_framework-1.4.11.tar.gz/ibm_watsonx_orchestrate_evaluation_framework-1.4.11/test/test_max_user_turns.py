"""
Core tests for max_user_turns feature.

Tests the max_user_turns functionality at multiple levels:
1. Edge cases (0, 1, negative values)
2. Fallback logic between test case and config
3. Conversation history validation
"""

from unittest.mock import Mock, patch
import pytest
from agentops.evaluation_controller.evaluation_controller import EvaluationController
from agentops.llm_user.llm_user_v1 import LLMUser
from src.agentops.runner import get_max_user_turns_info
from agentops.type import ContentType, Message, TestCase


@pytest.fixture
def mock_config():
    """Mock configuration for tests."""
    mock = Mock()
    mock.enable_verbose_logging = False
    mock.enable_manual_user_input = False
    return mock


@pytest.fixture
def mock_llm_user():
    """Mock LLM user that generates user inputs."""
    mock = Mock(spec=LLMUser)
    mock.generate_user_input.return_value = Message(
        role="user",
        content="Generated user input",
        type=ContentType.text,
    )
    return mock


@pytest.fixture
def mock_wxo_inference_backend():
    """Mock inference backend that simulates agent responses."""
    mock = Mock()
    message = Message(
        role="assistant",
        content="Assistant response",
        type=ContentType.text,
    )
    # Mock the return value as a tuple matching EvaluationController expectations
    mock.run.return_value = Mock(
        messages=[message],
        thread_id="test-thread-id",
        context={"conversational_search_data": ""}
    )
    mock.extract_box_folder_url.return_value = None
    return mock


class TestMaxUserTurnsEdgeCases:
    """Test edge cases for max_user_turns parameter."""

    def test_max_user_turns_zero(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that max_user_turns=0 results in no conversation turns."""
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=0,
            )

        assert mock_wxo_inference_backend.run.call_count == 0

    def test_max_user_turns_one(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that max_user_turns=1 results in exactly one turn."""
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=1,
            )

        assert mock_wxo_inference_backend.run.call_count == 1

    def test_max_user_turns_negative_value(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that negative max_user_turns is handled gracefully (treated as 0)."""
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=-1,
            )

        # Should not run any turns with negative value
        assert mock_wxo_inference_backend.run.call_count == 0


class TestGetMaxUserTurnsInfo:
    """Test source resolution for max_user_turns in runner.py."""

    def test_returns_test_case_value(self, mock_config):
        """Test that test case value takes precedence."""
        evaluation_data = TestCase.model_construct(max_user_turns=5)

        max_user_turns = get_max_user_turns_info(
            evaluation_data, mock_config
        )

        assert max_user_turns == 5

    def test_returns_config_value_when_test_case_none(self, mock_config):
        """Test that config value is used when test case value is None."""
        evaluation_data = TestCase.model_construct(max_user_turns=None)
        mock_config.max_user_turns = 7

        max_user_turns = get_max_user_turns_info(
            evaluation_data, mock_config
        )

        assert max_user_turns == 7

    def test_returns_config_value_when_both_unset(self, mock_config):
        """Test that config value is used when both test case and config values are None."""
        evaluation_data = TestCase.model_construct(max_user_turns=None)
        mock_config.max_user_turns = None

        max_user_turns = get_max_user_turns_info(
            evaluation_data, mock_config
        )

        assert max_user_turns is None


class TestMaxUserTurnsFallbackLogic:
    """Test the fallback logic in runner.py between test case and config level max_user_turns."""

    def test_fallback_logic_case_overrides_config(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that case-level max_user_turns takes precedence over config-level.
        
        This simulates the logic in runner.py:
        max_user_turns=(
            evaluation_data.max_user_turns
            if evaluation_data.max_user_turns is not None
            else config.max_user_turns
        )
        """
        # Simulate case-level max_user_turns
        case_max_turns = 5
        config_max_turns = 10
        
        # The fallback logic should use case_max_turns
        effective_max_turns = (
            case_max_turns if case_max_turns is not None else config_max_turns
        )
        
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=effective_max_turns,
            )

        # Should use case-level value (5)
        assert mock_wxo_inference_backend.run.call_count == 5

    def test_fallback_logic_config_used_when_case_none(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that config-level max_user_turns is used when case-level is None."""
        case_max_turns = None
        config_max_turns = 7
        
        # The fallback logic should use config_max_turns
        effective_max_turns = (
            case_max_turns if case_max_turns is not None else config_max_turns
        )
        
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=effective_max_turns,
            )

        # Should use config-level value (7)
        assert mock_wxo_inference_backend.run.call_count == 7

    def test_fallback_logic_case_zero_overrides_config(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that case-level max_user_turns=0 overrides config value."""
        case_max_turns = 0
        config_max_turns = 10
        
        # The fallback logic should use case_max_turns even if it's 0
        effective_max_turns = (
            case_max_turns if case_max_turns is not None else config_max_turns
        )
        
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=effective_max_turns,
            )

        # Should use case-level value (0)
        assert mock_wxo_inference_backend.run.call_count == 0


class TestMaxUserTurnsConversationHistory:
    """Test that conversation history respects max_user_turns."""

    def test_conversation_history_length_matches_max_turns(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that the conversation history length matches max_user_turns."""
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        max_turns = 3
        with patch.object(EvaluationController, "_is_end", return_value=False):
            history, _, _, _ = controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=max_turns,
            )

        # Should have exactly max_turns agent responses
        assert mock_wxo_inference_backend.run.call_count == max_turns

    def test_early_termination_produces_shorter_history(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that early termination produces shorter conversation history."""
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        # Terminate after 2 turns
        with patch.object(
            EvaluationController,
            "_is_end",
            side_effect=[False, False, True]
        ):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                max_user_turns=10,  # Set high but terminate early
            )

        # Should have terminated after 2 turns
        assert mock_wxo_inference_backend.run.call_count == 2

# Made with Bob
