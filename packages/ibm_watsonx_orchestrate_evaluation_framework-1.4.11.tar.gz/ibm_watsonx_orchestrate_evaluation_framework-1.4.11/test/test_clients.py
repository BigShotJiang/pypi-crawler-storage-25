"""Tests for clients.py, specifically the create_llm_user factory function."""

import pytest
from unittest.mock import Mock, patch
from jinja2 import UndefinedError

from agentops.arg_configs import (
    LLMUserConfig,
    ProviderConfig,
    LLAMA_USER_PROMPT_PATH,
    GPT_USER_PROMPT_PATH,
    UNIVERSAL_USER_PROMPT_PATH,
)
from agentops.clients import create_llm_user
from agentops.llm_user.llm_user_v1 import LLMUser
from agentops.llm_user.llm_user_v2 import LLMUserV2


class TestCreateLLMUser:
    """Test suite for the create_llm_user factory function."""

    @patch("agentops.clients.get_provider")
    @patch("agentops.clients.LlamaUserTemplateRenderer")
    def test_creates_v1_user_by_default(self, mock_renderer_cls, mock_get_provider):
        """Test that LLMUser (v1) is created when version is not explicitly set."""
        mock_provider = Mock()
        mock_get_provider.return_value = mock_provider
        mock_renderer_cls.return_value = Mock()

        # Create config without explicitly setting version (should default to v1)
        llm_user_config = LLMUserConfig(model_id="test-model")
        provider_config = ProviderConfig()

        result = create_llm_user(llm_user_config, provider_config)

        # Should create LLMUser (v1) by default
        assert isinstance(result, LLMUser)

    @patch("agentops.clients.get_provider")
    @patch("agentops.clients.LlamaUserTemplateRenderer")
    def test_creates_v1_user_when_version_is_v1(
        self, mock_renderer_cls, mock_get_provider
    ):
        """Test that LLMUser (v1) is created when version is explicitly set to v1."""
        mock_provider = Mock()
        mock_get_provider.return_value = mock_provider
        mock_renderer_cls.return_value = Mock()

        llm_user_config = LLMUserConfig(
            model_id="test-model",
            version="v1",
        )
        provider_config = ProviderConfig()

        result = create_llm_user(llm_user_config, provider_config)

        # Should create LLMUser (v1)
        assert isinstance(result, LLMUser)

    @patch("agentops.clients.get_provider")
    def test_creates_v2_user_when_version_is_v2(self, mock_get_provider):
        """Test that LLMUserV2 is created when version is set to v2."""
        mock_provider = Mock()
        mock_provider.model_id = "test-model"
        mock_get_provider.return_value = mock_provider

        llm_user_config = LLMUserConfig(
            model_id="test-model",
            version="v2",
        )
        provider_config = ProviderConfig()

        result = create_llm_user(llm_user_config, provider_config)

        # Should create LLMUserV2
        assert isinstance(result, LLMUserV2)


class TestLLMUserConfig:
    """Test suite for the LLMUserConfig dataclass"""

    def test_rejects_invalid_version(self):
        """Test that LLMUserConfig raises ValueError for invalid version values."""
        with pytest.raises(ValueError, match="Invalid version 'v3'. Must be one of: v1, v2"):
            LLMUserConfig(
                model_id="test-model",
                version="v3",  # type: ignore - intentionally passing invalid value
            )

    def test_v1_uses_llama_prompt_for_llama_models(self):
        """Test that v1 uses llama prompt template for llama models."""
        config = LLMUserConfig(
            model_id="meta-llama/llama-3-3-70b-instruct",
            version="v1",
        )
        assert config.prompt_config == LLAMA_USER_PROMPT_PATH

    def test_v1_uses_gpt_prompt_for_non_llama_models(self):
        """Test that v1 uses GPT prompt template for non-llama models."""
        config = LLMUserConfig(
            model_id="gpt-4",
            version="v1",
        )
        assert config.prompt_config == GPT_USER_PROMPT_PATH

    def test_v2_uses_universal_prompt_by_default(self):
        """Test that v2 uses universal user template by default regardless of model."""
        # Test with llama model
        config_llama = LLMUserConfig(
            model_id="meta-llama/llama-3-3-70b-instruct",
            version="v2",
        )
        assert config_llama.prompt_config == UNIVERSAL_USER_PROMPT_PATH

        # Test with GPT model
        config_gpt = LLMUserConfig(
            model_id="gpt-4",
            version="v2",
        )
        assert config_gpt.prompt_config == UNIVERSAL_USER_PROMPT_PATH

    def test_custom_prompt_config_overrides_default(self):
        """Test that explicitly setting prompt_config overrides version-based defaults."""
        custom_path = "/custom/path/to/prompt.jinja2"

        # v1 with custom path
        config_v1 = LLMUserConfig(
            model_id="meta-llama/llama-3-3-70b-instruct",
            version="v1",
            prompt_config=custom_path,
        )
        assert config_v1.prompt_config == custom_path

        # v2 with custom path
        config_v2 = LLMUserConfig(
            model_id="meta-llama/llama-3-3-70b-instruct",
            version="v2",
            prompt_config=custom_path,
        )
        assert config_v2.prompt_config == custom_path


class TestLLMUserV2TemplateError:
    """Test suite for LLMUserV2 template error handling."""

    @patch("agentops.clients.get_provider")
    def test_raises_helpful_error_on_incompatible_template(self, mock_get_provider):
        """Test that LLMUserV2 raises a helpful error when template rendering fails."""
        mock_provider = Mock()
        mock_provider.model_id = "test-model"
        mock_get_provider.return_value = mock_provider

        # Create a v2 user with a custom (incompatible) prompt path
        llm_user_config = LLMUserConfig(
            model_id="test-model",
            version="v2",
        )
        provider_config = ProviderConfig()

        llm_user = create_llm_user(llm_user_config, provider_config)

        # Mock the template renderer to raise a TemplateError
        with patch.object(
            llm_user.prompt_template,
            "render",
            side_effect=UndefinedError("undefined variable: structured_output"),
        ):
            # Try to generate user input, which should trigger template rendering
            with pytest.raises(ValueError):
                llm_user.generate_user_input(
                    user_story="Test story",
                    conversation_history=[],
                )
