"""
Unit tests for story generation functionality in tool_planner and batch_annotate.
"""
import json
import tempfile
from pathlib import Path

import pytest

from agentops.tool_planner import extract_first_json_list, load_tools_module
from agentops.batch_annotate import parse_tools_with_filter, extract_inputs_from_snapshot


class TestToolPlanner:
    """Tests for tool_planner.py functions"""

    def test_extract_first_json_list_success(self):
        """SUCCESS: Should extract valid tool call list from LLM response"""
        raw_response = """
        Here's the plan:
        [
            {"tool_name": "get_user", "inputs": {"id": 123}},
            {"tool_name": "update_user", "inputs": {"id": 123, "name": "John"}}
        ]
        """
        result = extract_first_json_list(raw_response)
        
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["tool_name"] == "get_user"
        assert result[0]["inputs"]["id"] == 123
        assert result[1]["tool_name"] == "update_user"

    def test_extract_first_json_list_failure(self):
        """FAILURE: Should return empty list when JSON is invalid or missing tool_name"""
        # Test with no JSON
        assert extract_first_json_list("Just plain text") == []
        
        # Test with JSON but no tool_name field
        assert extract_first_json_list('[{"name": "test", "value": 123}]') == []
        
        # Test with malformed JSON
        assert extract_first_json_list('[{"tool_name": "test", invalid}]') == []

    def test_load_tools_module_success(self):
        """SUCCESS: Should load and execute functions from Python file"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write("""
def add_numbers(a, b):
    return a + b

def greet(name):
    return f"Hello, {name}!"
""")
            f.flush()
            tools_path = Path(f.name)

        try:
            result = load_tools_module(tools_path)
            
            # Check functions are loaded
            assert "add_numbers" in result
            assert "greet" in result
            assert callable(result["add_numbers"])
            assert callable(result["greet"])
            
            # Test that functions actually work
            assert result["add_numbers"](5, 3) == 8
            assert result["greet"]("World") == "Hello, World!"
        finally:
            tools_path.unlink()


class TestBatchAnnotate:
    """Tests for batch_annotate.py functions"""

    def test_parse_tools_with_filter_success(self):
        """SUCCESS: Should filter and return only allowed tools with their metadata"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('''
def get_user(user_id):
    """Fetch user by ID"""
    return {"id": user_id}

def delete_user(user_id):
    """Delete user"""
    pass

def create_user(name, email):
    """Create new user"""
    pass
''')
            f.flush()
            tools_path = Path(f.name)

        try:
            agent_info, filtered_tools = parse_tools_with_filter(
                agent_name="TestAgent",
                tools_path=tools_path,
                allowed_tool_names=["get_user", "create_user"]
            )
            
            # Check agent info
            assert agent_info == {"name": "TestAgent"}
            
            # Check only allowed tools are returned
            assert len(filtered_tools) == 2
            tool_names = [t["Function Name"] for t in filtered_tools]
            assert "get_user" in tool_names
            assert "create_user" in tool_names
            assert "delete_user" not in tool_names
            
            # Verify tool metadata is preserved
            get_user_tool = next(t for t in filtered_tools if t["Function Name"] == "get_user")
            assert get_user_tool["Arguments"] == ["user_id"]
            assert "Fetch user by ID" in get_user_tool["Docstring"]
        finally:
            tools_path.unlink()

            # Check all tools returned when tool list is empty
    def test_parse_tools_with_empty_allowed_tool_names(self):
        """SUCCESS: Should filter and return only allowed tools with their metadata"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write('''
def get_user(user_id):
    """Fetch user by ID"""
    return {"id": user_id}

def delete_user(user_id):
    """Delete user"""
    pass

def create_user(name, email):
    """Create new user"""
    pass
''')
            f.flush()
            tools_path = Path(f.name)

        try:
            agent_info, filtered_tools = parse_tools_with_filter(
                agent_name="TestAgent",
                tools_path=tools_path,
                allowed_tool_names=[]
            )
            
            # Check agent info
            assert agent_info == {"name": "TestAgent"}
            
            # Check only allowed tools are returned
            assert len(filtered_tools) == 3
            tool_names: list[str] = [t["Function Name"] for t in filtered_tools]
            assert "get_user" in tool_names
            assert "create_user" in tool_names
            assert "delete_user" in tool_names

            # Verify tool metadata is preserved
            get_user_tool = next(t for t in filtered_tools if t["Function Name"] == "get_user")
            assert get_user_tool["Arguments"] == ["user_id"]
            assert "Fetch user by ID" in get_user_tool["Docstring"]

            get_create_user_tool = next(t for t in filtered_tools if t["Function Name"] == "create_user")
            assert get_create_user_tool["Arguments"] == ["name", "email"]
            assert "Create new user" in get_create_user_tool["Docstring"]
        finally:
            tools_path.unlink()


    def test_parse_tools_with_filter_failure(self):
        """FAILURE: Should raise error for empty allowed list and return empty for no matches"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write("def test_func(): pass")
            f.flush()
            tools_path = Path(f.name)

        try:

            #No matching tools should return empty list
            agent_info, filtered_tools = parse_tools_with_filter(
                agent_name="TestAgent",
                tools_path=tools_path,
                allowed_tool_names=["nonexistent_tool"]
            )
            assert filtered_tools == []
        finally:
            tools_path.unlink()

    def test_extract_inputs_from_snapshot_success(self):
        """SUCCESS: Should extract tool examples from snapshot preserving all data"""
        snapshot_data = {
            "input_output_examples": {
                "get_user": [
                    {
                        "inputs": {"user_id": 123},
                        "output": {"id": 123, "name": "Alice", "email": "alice@example.com"}
                    },
                    {
                        "inputs": {"user_id": 456},
                        "output": {"id": 456, "name": "Bob", "email": "bob@example.com"}
                    }
                ],
                "create_user": [
                    {
                        "inputs": {"name": "Charlie", "email": "charlie@example.com"},
                        "output": {"id": 789, "success": True}
                    }
                ]
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(snapshot_data, f)
            f.flush()
            snapshot_path = Path(f.name)

        try:
            result = extract_inputs_from_snapshot(snapshot_path)
            
            # Check all tools are extracted
            assert "get_user" in result
            assert "create_user" in result
            
            # Check multiple examples are grouped correctly
            assert len(result["get_user"]) == 2
            assert result["get_user"][0]["inputs"]["user_id"] == 123
            assert result["get_user"][1]["inputs"]["user_id"] == 456
            
            # Check data is preserved exactly
            assert result["get_user"][0]["output"]["name"] == "Alice"
            assert result["create_user"][0]["output"]["success"] is True
        finally:
            snapshot_path.unlink()

# Made with Bob
