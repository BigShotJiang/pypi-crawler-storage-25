from unittest.mock import Mock

import pytest

from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter
from agentops.type import (
    ContentType,
    ConversationalSearch,
    ConversationalSearchCitations,
    ConversationalSearchResultMetadata,
    ConversationalSearchResults,
    ConversationSearchMetadata,
)


@pytest.fixture
def wxo_adapter():
    """Create a WXORuntimeAdapter instance with a mocked client."""
    mock_client = Mock()
    mock_client.service_url = "http://test.example.com"
    return WXORuntimeAdapter(mock_client)


@pytest.fixture
def base_conversational_search_data():
    """Base conversational search response data."""
    return {
        "response_type": ContentType.conversational_search,
        "text": "Test response text",
        "citations_title": "Test Citations",
        "response_length_option": "concise",
        "confidence_scores": {
            "response_confidence": 0.95,
            "response_confidence_threshold": 0.8,
            "retrieval_confidence": 0.9,
            "retrieval_confidence_threshold": 0.7,
        },
        "citations": [
            {
                "url": "https://example.com/doc1",
                "body": "Citation body text",
                "text": "Citation text",
                "title": "Citation Title",
                "range_start": 0,
                "range_end": 100,
                "search_result_idx": 0,
            }
        ],
    }


@pytest.fixture
def metadata():
    """Create test metadata."""
    return ConversationSearchMetadata(
        tool_call_id="test-tool-call-id",
    )


def test_parse_conversational_search_with_valid_metadata(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Test parsing conversational search response with valid result_metadata."""
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result body text",
            "title": "Result Title",
            "result_metadata": {
                "score": 0.95,
                "document_retrieval_source": "vector_search",
            },
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert isinstance(result, ConversationalSearch)
    assert len(result.search_results) == 1

    search_result = result.search_results[0]
    assert isinstance(search_result, ConversationalSearchResults)
    assert search_result.url == "https://example.com/result1"
    assert search_result.body == "Result body text"
    assert search_result.title == "Result Title"

    # Verify metadata is properly parsed
    assert search_result.result_metadata is not None
    assert isinstance(
        search_result.result_metadata, ConversationalSearchResultMetadata
    )
    assert search_result.result_metadata.score == 0.95
    assert (
        search_result.result_metadata.document_retrieval_source
        == "vector_search"
    )


def test_parse_conversational_search_without_metadata(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Test parsing conversational search response when result_metadata is missing."""
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result body text",
            "title": "Result Title",
            # No result_metadata field
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert isinstance(result, ConversationalSearch)
    assert len(result.search_results) == 1

    search_result = result.search_results[0]
    assert isinstance(search_result, ConversationalSearchResults)
    assert search_result.url == "https://example.com/result1"
    assert search_result.body == "Result body text"
    assert search_result.title == "Result Title"

    # Verify metadata is None when not provided
    assert search_result.result_metadata is None


def test_parse_conversational_search_with_empty_metadata(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Test parsing conversational search response when result_metadata is an empty dict."""
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result body text",
            "title": "Result Title",
            "result_metadata": {},  # Empty dict
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert isinstance(result, ConversationalSearch)
    assert len(result.search_results) == 1

    search_result = result.search_results[0]
    assert isinstance(search_result, ConversationalSearchResults)

    # Verify metadata is None when empty dict is provided
    assert search_result.result_metadata is None


def test_parse_conversational_search_with_none_metadata(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Test parsing conversational search response when result_metadata is explicitly None."""
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result body text",
            "title": "Result Title",
            "result_metadata": None,  # Explicitly None
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert isinstance(result, ConversationalSearch)
    assert len(result.search_results) == 1

    search_result = result.search_results[0]
    assert isinstance(search_result, ConversationalSearchResults)

    # Verify metadata is None when explicitly None
    assert search_result.result_metadata is None


def test_parse_conversational_search_with_partial_metadata(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Test parsing conversational search response with partial metadata (only score)."""
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result body text",
            "title": "Result Title",
            "result_metadata": {
                "score": 0.85,
                # Missing document_retrieval_source
            },
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert isinstance(result, ConversationalSearch)
    assert len(result.search_results) == 1

    search_result = result.search_results[0]
    assert isinstance(search_result, ConversationalSearchResults)

    # Verify metadata is created even with partial data
    assert search_result.result_metadata is not None
    assert search_result.result_metadata.score == 0.85
    assert search_result.result_metadata.document_retrieval_source is None


def test_parse_conversational_search_with_multiple_results(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Test parsing conversational search response with multiple search results."""
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result 1 body",
            "title": "Result 1",
            "result_metadata": {
                "score": 0.95,
                "document_retrieval_source": "vector_search",
            },
        },
        {
            "url": "https://example.com/result2",
            "body": "Result 2 body",
            "title": "Result 2",
            # No metadata
        },
        {
            "url": "https://example.com/result3",
            "body": "Result 3 body",
            "title": "Result 3",
            "result_metadata": {
                "score": 0.75,
                "document_retrieval_source": "keyword_search",
            },
        },
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert isinstance(result, ConversationalSearch)
    assert len(result.search_results) == 3

    # First result has metadata
    assert result.search_results[0].result_metadata is not None
    assert result.search_results[0].result_metadata.score == 0.95

    # Second result has no metadata
    assert result.search_results[1].result_metadata is None

    # Third result has metadata
    assert result.search_results[2].result_metadata is not None
    assert result.search_results[2].result_metadata.score == 0.75


def test_parse_conversational_search_preserves_other_fields(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Test that parsing preserves all other fields correctly."""
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result body",
            "title": "Result Title",
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    # Verify all top-level fields are preserved
    assert result.text == "Test response text"
    assert result.citations_title == "Test Citations"
    assert result.response_length_option == "concise"
    assert result.response_type == ContentType.conversational_search
    assert len(result.citations) == 1
    assert result.confidence_scores.response_confidence == 0.95


def test_parse_conversational_search_with_null_citation_url(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Milvus knowledge bases without a configured URL return null in the
    citation's url field. Parsing must accept this without raising."""
    base_conversational_search_data["citations"] = [
        {
            "url": None,
            "body": "Citation body text",
            "text": "Citation text",
            "title": "Citation Title",
            "range_start": 0,
            "range_end": 100,
            "search_result_idx": 0,
        }
    ]
    base_conversational_search_data["search_results"] = [
        {
            "url": "https://example.com/result1",
            "body": "Result body",
            "title": "Result Title",
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert len(result.citations) == 1
    citation = result.citations[0]
    assert isinstance(citation, ConversationalSearchCitations)
    assert citation.url is None
    assert citation.body == "Citation body text"


def test_parse_conversational_search_with_null_search_result_url(
    wxo_adapter, base_conversational_search_data, metadata
):
    """Same milvus-no-URL scenario for the search_results payload."""
    base_conversational_search_data["search_results"] = [
        {
            "url": None,
            "body": "Result body",
            "title": "Result Title",
        }
    ]

    result = wxo_adapter.parse_conversational_search_response(
        base_conversational_search_data, metadata
    )

    assert len(result.search_results) == 1
    search_result = result.search_results[0]
    assert isinstance(search_result, ConversationalSearchResults)
    assert search_result.url is None
    assert search_result.body == "Result body"


# Made with Bob
