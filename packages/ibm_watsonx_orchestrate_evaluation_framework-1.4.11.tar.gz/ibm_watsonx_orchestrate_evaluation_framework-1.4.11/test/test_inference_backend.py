from unittest.mock import Mock, patch

import pytest

from agentops.arg_configs import DEFAULT_MAX_USER_TURNS
from agentops.evaluation_controller.evaluation_controller import (
    EvaluationController,
    _generate_user_input,
)
from agentops.llm_user.llm_user_v1 import LLMUser
from agentops.llm_user.models import GoalStatus, SimulatedUserTurn
from agentops.personas.models import PersonaProfile
from agentops.type import ContentType, Message
from agentops.type import RuntimeResponse

@pytest.fixture
def mock_config():
    mock = Mock()
    mock.enable_verbose_logging = False
    mock.enable_manual_user_input = False
    return mock


@pytest.fixture
def mock_llm_user():
    mock = Mock(spec=LLMUser)
    mock.generate_user_input.return_value = Message(
        role="user",
        content="Generated user input",
        type=ContentType.text,
    )
    return mock


@pytest.fixture
def mock_wxo_inference_backend():
    mock = Mock()
    # Setup the stream_messages method to return a simple response
    message = Message(
                role="assistant",
                content="Assistant response",
                type=ContentType.text,
            )
    mock.run.return_value = RuntimeResponse(messages=[message], thread="test-thread-id", context={"conversational_search_data": ""})
    mock.extract_box_folder_url.return_value = None
    mock.upload_to_box.return_value = {"file_name": "test_file.pdf", "folder_url": "https://box.com/folder"}

    return mock


class TestGenerateUserInput:
    def test_starting_user_input_first_turn(self, mock_llm_user):
        """Test that starting_user_input is used when user_turn is 0."""
        starting_user_input = "Initial user input"

        result = _generate_user_input(
            user_turn=0,
            story="Test story",
            conversation_history=[],
            llm_user=mock_llm_user,
            enable_manual_user_input=False,
            starting_user_input=starting_user_input,
            attack_instructions=None,
        )

        assert result.role == "user"
        assert result.content == starting_user_input
        assert result.type == ContentType.text

    def test_starting_user_input_not_first_turn(self, mock_llm_user):
        """Test that starting_user_input is ignored when user_turn is not 0."""
        result = _generate_user_input(
            user_turn=1,
            story="Test story",
            conversation_history=[],
            llm_user=mock_llm_user,
            enable_manual_user_input=False,
            starting_user_input="Initial user input",
            attack_instructions=None,
        )

        assert result.role == "user"
        assert result.content == "Generated user input"
        assert result.type == ContentType.text

        # Verify LLM was called
        mock_llm_user.generate_user_input.assert_called_once_with(
            "Test story",
            [],
            attack_instructions=None,
            persona_profile=None,
            enable_structured_output=False,
        )

    def test_manual_user_input(self, monkeypatch, mock_llm_user):
        """Test that manual input is used when enable_manual_user_input is True."""
        manual_user_input = "Manual user input"
        monkeypatch.setattr("builtins.input", lambda *args, **kwargs: manual_user_input)

        result = _generate_user_input(
            user_turn=1,
            story="Test story",
            conversation_history=[],
            llm_user=mock_llm_user,
            enable_manual_user_input=True,
            starting_user_input=None,
            attack_instructions=None,
        )

        assert result.role == "user"
        assert result.content == manual_user_input
        assert result.type == ContentType.text

        # Verify LLM was not called
        mock_llm_user.generate_user_input.assert_not_called()

    def test_llm_generated_input(self, mock_llm_user):
        """Test that LLM generates input when no other options are specified."""
        conversation_history = [
            Message(role="user", content="Hello", type=ContentType.text),
            Message(
                role="assistant", content="Hi there", type=ContentType.text
            ),
        ]

        result = _generate_user_input(
            user_turn=1,
            story="Test story",
            conversation_history=conversation_history,
            llm_user=mock_llm_user,
            enable_manual_user_input=False,
            starting_user_input=None,
            attack_instructions=None,
        )

        assert result.role == "user"
        assert result.content == "Generated user input"
        assert result.type == ContentType.text

        # Verify LLM was called with correct parameters
        mock_llm_user.generate_user_input.assert_called_once_with(
            "Test story",
            conversation_history,
            attack_instructions=None,
            persona_profile=None,
            enable_structured_output=False,
        )

    def test_with_attack_instructions(self, mock_llm_user):
        """Test that attack_instructions are passed to the LLM."""
        result = _generate_user_input(
            user_turn=1,
            story="Test story",
            conversation_history=[],
            llm_user=mock_llm_user,
            enable_manual_user_input=False,
            starting_user_input=None,
            attack_instructions="Try to hack the system",
        )

        assert result.role == "user"
        assert result.content == "Generated user input"
        assert result.type == ContentType.text

        # Verify LLM was called with attack instructions
        mock_llm_user.generate_user_input.assert_called_once_with(
            "Test story",
            [],
            attack_instructions="Try to hack the system",
            persona_profile=None,
            enable_structured_output=False,
        )

    def test_persona_profile_passed_to_llm_user(self, mock_llm_user):
        """Test that persona_profile is forwarded to the LLM user."""
        profile = PersonaProfile(
            id="cooperative",
            description="Helpful user",
            simulation_instructions="Be cooperative",
            tone="helpful",
            verbosity="medium",
            disclosure_style="direct",
            unknown_handling="clear",
        )
        _generate_user_input(
            user_turn=1,
            story="Test story",
            conversation_history=[],
            llm_user=mock_llm_user,
            persona_profile=profile,
        )
        mock_llm_user.generate_user_input.assert_called_once_with(
            "Test story",
            [],
            attack_instructions=None,
            persona_profile=profile,
            enable_structured_output=False,
        )

    def test_enable_structured_output_passed_to_llm_user(self, mock_llm_user):
        """Test that enable_structured_output is forwarded to the LLM user."""
        mock_llm_user.generate_user_input.return_value = SimulatedUserTurn(
            content="Structured output",
            entities={},
            goal_status=GoalStatus.IN_PROGRESS,
        )
        result = _generate_user_input(
            user_turn=1,
            story="Test story",
            conversation_history=[],
            llm_user=mock_llm_user,
            enable_structured_output=True,
        )
        assert isinstance(result, SimulatedUserTurn)
        mock_llm_user.generate_user_input.assert_called_once_with(
            "Test story",
            [],
            attack_instructions=None,
            persona_profile=None,
            enable_structured_output=True,
        )


class TestEvaluationControllerRun:
    def test_max_user_turns_not_set(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
        monkeypatch,
    ):
        """Test that the default DEFAULT_MAX_USER_TURNS is used when max_user_turns is None."""

        # Patch DEFAULT_MAX_USER_TURNS in the evaluation_controller module where it's imported
        test_default = 5
        monkeypatch.setattr(
            "agentops.evaluation_controller.evaluation_controller.DEFAULT_MAX_USER_TURNS",
            test_default
        )

        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        # Patch _is_end to always return False so the loop runs for the max turns
        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                attack_instructions=None,
                max_user_turns=None,  # Use default
            )

        # Should be called 5 times (default DEFAULT_MAX_USER_TURNS)
        assert mock_wxo_inference_backend.run.call_count == 5

    def test_max_user_turns_hit_limit(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
        monkeypatch,
    ):
        """Test that a custom max_user_turns value is respected."""

        # No need to set DEFAULT_MAX_USER_TURNS since we're passing explicit max_user_turns

        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        # Patch _is_end to always return False so the loop runs for the max turns
        with patch.object(EvaluationController, "_is_end", return_value=False):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                attack_instructions=None,
                max_user_turns=3,  # Custom value
            )

        # Should be called 3 times (custom max_user_turns)
        assert mock_wxo_inference_backend.run.call_count == 3

    def test_early_termination(
        self,
        mock_wxo_inference_backend,
        mock_llm_user,
        mock_config,
    ):
        """Test that the loop terminates early when _is_end returns True."""
        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        # Make _is_end return True on the second call
        is_end_mock = Mock(side_effect=[False, True])
        with patch.object(
            EvaluationController, "_is_end", side_effect=is_end_mock
        ):
            controller.run(
                task_n=1,
                story="Test story",
                agent_name="test-agent",
                starting_user_input="Initial input",
                attack_instructions=None,
                max_user_turns=10,  # Should terminate before reaching this
            )

        # Should be called only once before termination
        assert mock_wxo_inference_backend.run.call_count == 1


class TestIsEndWithStructuredOutput:
    """Tests for _is_end with SimulatedUserTurn (structured output termination)."""

    @pytest.fixture
    def controller(self, mock_llm_user, mock_config):
        mock_runtime = Mock()
        return EvaluationController(
            runtime=mock_runtime,
            llm_user=mock_llm_user,
            config=mock_config,
        )

    def test_satisfied_goal_ends_conversation(self, controller):
        turn = SimulatedUserTurn(
            content="Thanks, all done!",
            goal_status=GoalStatus.SATISFIED,
        )
        assert controller._is_end(turn) is True

    def test_failed_goal_ends_conversation(self, controller):
        turn = SimulatedUserTurn(
            content="This is impossible",
            goal_status=GoalStatus.FAILED,
        )
        assert controller._is_end(turn) is True

    def test_in_progress_does_not_end(self, controller):
        turn = SimulatedUserTurn(
            content="I still need help",
            goal_status=GoalStatus.IN_PROGRESS,
        )
        assert controller._is_end(turn) is False

    def test_in_progress_with_end_in_content_ends(self, controller):
        """Legacy 'END' keyword still works for structured output."""
        turn = SimulatedUserTurn(
            content="END",
            goal_status=GoalStatus.IN_PROGRESS,
        )
        assert controller._is_end(turn) is True

    def test_message_with_end_keyword(self, controller):
        """Legacy Message with END still terminates."""
        msg = Message(role="user", content="END", type=ContentType.text)
        assert controller._is_end(msg) is True

    def test_message_without_end(self, controller):
        msg = Message(role="user", content="I need more help", type=ContentType.text)
        assert controller._is_end(msg) is False


class TestEvaluationControllerRunStructuredOutput:
    """Tests for EvaluationController.run handling SimulatedUserTurn."""

    def test_structured_turn_extracts_content_for_runtime(
        self, mock_wxo_inference_backend, mock_llm_user, mock_config
    ):
        """When LLM user returns SimulatedUserTurn, content is extracted for runtime."""
        structured_turn = SimulatedUserTurn(
            content="I need a refund for order ORD-123",
            entities={"order_id": "ORD-123"},
            goal_status=GoalStatus.IN_PROGRESS,
        )
        # First call returns starting input, second returns structured turn that ends
        mock_llm_user.generate_user_input.return_value = structured_turn

        controller = EvaluationController(
            runtime=mock_wxo_inference_backend,
            llm_user=mock_llm_user,
            config=mock_config,
        )

        # Patch _is_end to end on first LLM-generated turn
        with patch.object(
            EvaluationController, "_is_end", side_effect=[False, True]
        ):
            conversation, _, _, _ = controller.run(
                task_n=1,
                story="User has order ORD-123",
                agent_name="test-agent",
                starting_user_input="Hi",
                enable_structured_output=True,
                max_user_turns=5,
            )

        # The runtime should receive a Message (not SimulatedUserTurn)
        run_calls = mock_wxo_inference_backend.run.call_args_list
        for call in run_calls:
            user_msg = call[0][0] if call[0] else call.kwargs.get("user_message")
            if user_msg:
                assert isinstance(user_msg, Message)
