<div align="center">
  <img src="doc/assets/logo.png" alt="AgentOps Framework Logo" width="150">
</div>

# Agent Ops Core

## Overview
The Agent Ops Framework SDK provides **the core building blocks for testing, evaluating, and improving agentic AI systems**. It enables rigorous agent evaluation through **build-time metrics**, which leverage automated evaluation data generation to create reproducible test scenarios, and **runtime metrics** such as LLM-as-a-Judge, drift detection, and behavioral diagnostics to measure agent behavior during live interactions.
 The SDK also supports **closed-loop optimization** techniques, including prompt optimization, that systematically improve agent performance over time. See the [Workflow Overview](#workflow-overview) for more details.

**The Agent Ops SDK serves as IBM’s upstream repository for experimentation, evaluation, and optimization research in agentic AI**. It is the central contribution point for AI research teams, internal collaborators, and product incubation efforts exploring new simulation tools, evaluation methodologies, and performance-improvement techniques. The package is developed as a standalone, upstream library that product teams can directly integrate and downstream into enterprise-grade production systems. 

## Table of Contents
- [Core Features](#core-features)
- [Agent Runtime Support](#agent-runtime-support)
- [Setup Guide](#setup-guide)
- [Quick Start](#quick-start)
- [How to setup tracing](#how-to-setup-tracing)
- [Provider Selection Guide](#provider-selection-guide)
- [Contribution Guide](#contribution-guide)
- [How to report a bug](#how-to-report-a-bug)
- [How to add a new metric](#how-to-add-a-new-metric)
- [Pre-deployment Workflow Overview](#pre-deployment-workflow-overview)
- [Community Scrum and Office Hours](#community-scrum-and-office-hours)
- [Support](#support)
- [Orchestrate Users](#orchestrate-users)

## Core Features

### Observability
- Integrations with observability platforms ([Langfuse](https://langfuse.com), [Arize Phoenix](https://phoenix.arize.com))
- Trace ingestion + [OpenTelemetry](https://opentelemetry.io) parsing across multiple agent frameworks

### Evaluation
- **Build-time Evaluation**: Automated testing during development
  - Automatic evaluation dataset generation from user stories and tool specs
  - Simulation-based testing (LLM user + runtime adapters) for reproducible runs
  - Core metrics: journey success, tool calling/routing accuracy, retrieval quality
  - Safety + robustness evaluation, including red teaming workflows
  - Extensible custom metrics + extractors
- **Runtime Evaluation**: Live assessment using traces from observability platforms
  - Integrates with platforms like Langfuse/Phoenix to evaluate live sessions and production traces
  - Referenceless evaluation (no labeled ground truth): function selection, hallucination checks
  - LLM-as-a-Judge scoring for faithfulness, relevance, off-topic/derailment, and safety

### Optimization
- Closed-loop agent improvement
  - Optimize system prompts using evaluation traces + scores.
  - More optimizations coming soon

## Agent Runtime Support
Runtime adapters supported by `agentops-core`:

| Agent framework | Runtime adapter | Notes |
|---|---|---|
| LangGraph | `LanggraphRuntimeAdapter` (`src/agentops/runtime_adapter/langgraph_runtime_adapter.py`) | Runs a compiled graph via `invoke()` |
| LangFlow | `LangflowRuntimeAdapter` (`src/agentops/runtime_adapter/langflow_runtime_adapter.py`) | Calls a LangFlow endpoint (supports `LANGFLOW_API_KEY`) |
| CrewAI | `CrewAIRuntimeAdapter` (`src/agentops/runtime_adapter/crewai_runtime_adapter.py`) | Runs a CrewAI `Agent` via `kickoff()` |
| Claude | `ClaudeRuntimeAdapter` (`src/agentops/runtime_adapter/claude_runtime_adapter.py`) | Uses the Claude Agent SDK with MCP tools; streams responses; parses tool calls/results; propagates OpenTelemetry context |
| PydanticAI | `PydanticAIRuntimeAdapter` (`src/agentops/runtime_adapter/pydanticai_runtime_adapter.py`) | Uses `Agent.run_sync()` and persists message history in context |
| watsonx Orchestrate | `WXORuntimeAdapter` (`src/agentops/runtime_adapter/wxo_runtime_adapter.py`) | Streams Orchestrate events; captures tool calls + conversational search traces |

## Setup Guide

### Installing `agentops-core`
First, you will need to install `uv` which is a fast Python package installer. 

<details>
    <summary><b>Install uv</b></summary>
  
**macOS/Linux:**
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```
or, if you already have `homeberw`,
```
brew install uv 
```

**Windows:**
```bash
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

**Using pip:**
```bash
pip install uv
```

</details>

Use `uv` to make a virtual environment, activate your virtual environment, install the `agentops` package, and install jupyter, 
```bash
git clone git@github.ibm.com:AgentOps/agentops-core.git
cd agentops-core
uv venv
source .venv/bin/activate
uv pip install -e .
uv pip install jupyter
```
Thats it! You have now installed **agent-ops SDK**!

Let's also quickly install Langfuse so you can start tracing your agents. You will need docker to be installed on your system.
<details>
  <summary><b>Install Docker</b></summary>

#### MacOS
Colima is an open-source tool that provides a lightweight and performant way to run container runtimes, such as Docker, on macOS and Linux. 

If you don't have homebrew installed, install it first:
```bash 
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

Install Docker, Docker Compose, and Colima. Then start Colima:
```bash 
brew install docker docker-compose colima
colima start --memory 10
```

After Colima starts, verify Docker is working:
```bash
docker --version
docker-compose --version
```

#### Windows

Install **Rancher Desktop for Windows**:  
https://rancherdesktop.io/

To enable support for `docker` and `docker-compose`, switch Rancher Desktop to the Docker engine:

1. Open **Rancher Desktop**
2. Click the **⚙** (settings icon) in the upper-right corner
3. Select **Container Engine** from the left sidebar
4. Choose **moby (dockerd)** as the container runtime
5. Apply and restart when prompted
</details>

<details>
  <summary><b>Install Langfuse</b></summary>

**important: Make sure to install Docker before installing Langfuse.**

Langfuse is an open-source LLM engineering platform that helps teams debug, analyze, and improve applications built with large language models. 

You can launch Langfuse (on http://localhost:3000) as shown below:
```bash
git clone https://github.com/langfuse/langfuse.git
cd langfuse
docker-compose up # or docker compose up
```
#### Set Up Langfuse

1. Go to http://localhost:3000.
2. If you don't have an account, sign up for one.
3. If you don't have an organization or project, you will need to create both of these. 
4. Navigate to your project and then to Settings → API Keys.
5. If you do not have any API keys, create new API keys.
6. Copy your Public Key, Secret Key, and your Host URL.
</details>


## Quick Start

### Evaluate your Agent with Build-time Metrics
<details>
  <summary><b>LangFlow Demo</b></summary>

This demo shows you how to evaluate a LangFlow-built HR assistant by generating ground-truth data, generating ground-truth user interactions, and computing performance metrics.

To run the end-to-end LangFlow demo, launch JupyterLab with:
```bash
jupyter lab
```
Then open the notebook at `demos/agentops-langflow-demo.ipynb`. Here's a link to the [notebook](demos/agentops-langflow-demo.ipynb).

**📹 Watch the demo video:**

[![LangFlow Demo Video](demos/assets/langflow-demo-thumbnail.png)](https://share.descript.com/view/HKVHyNbSRPW)
</details>

<details>
  <summary><b>Claude Agent SDK Demo</b></summary>

This demo shows you how to evaluate an HR assistant built with the Claude Agent SDK by generating ground-truth data, running LLM-powered user interactions, and computing performance metrics.

To run the end-to-end Claude Agent SDK demo, launch JupyterLab with:
```bash
jupyter lab
```
Then open the notebook at `demos/agentops-claude-agent-demo.ipynb`. Here's a link to the [notebook](demos/agentops-claude-agent-demo.ipynb).
</details>

<details>
  <summary><b>LangGraph Demo</b></summary>
  
This demo shows you how to evaluate a LangGraph-built HR assistant by generating ground-truth data, generating ground-truth user interactions, and computing performance metrics.

#### 1. Navigate to the root directory and install extra packages

```bash
cd /path/to/agentops
uv pip install -e ".[demo]"
```

#### 2. Export environment variables

```bash
export OPENAI_API_KEY="your-openai-api-key"
export LANGFUSE_PUBLIC_KEY="your-langfuse-public-key"
export LANGFUSE_SECRET_KEY="your-langfuse-secret-key"
export LANGFUSE_HOST="http://localhost:3000"
```

#### 3. Run the demo

```bash
python demos/langgraph/langgraph_agent_evaluation_demo.py
```

#### Configuration

You can customize the following values in `demos/langgraph/langgraph_agent_evaluation_demo.py`:

```python
DATASET_NAME = "default-collection"
DATASET_DESCRIPTION = "default-collection-description"

EXPERIMENT_NAME = "default-experiment-name"
EXPERIMENT_DESCRIPTION = "default-experiment-description"

EVALUATION_NAME = "default-evaluation-name"
RUN_ID = "default-run-id"
```

#### Notes
- The demo will create traces visible in your Langfuse dashboard under the configured project
- Notebook version coming soon

</details>

<details>
  <summary><b>Orchestrate ADK Demo</b></summary>

This demo demonstrates how to set up Langfuse telemetry in Orchestrate and run simulations on your Orchestrate agents to evaluate their performance.

#### 1. Navigate to the root directory

```bash
cd /path/to/agentops-core
```

#### 3. Enable Langfuse telemetry
To enable Langfuse telemetry, start your Orchestrate server with the `-l` flag:

```bash
orchestrate server start --env-file <ENV FILE> -l
```

After the server starts, you can access your local Langfuse dashboard at [http://localhost:3010](http://localhost:3010)

Your Langfuse username and password will appear in the terminal. Use these credentials to log in to the dashboard.

#### 2. Configure environment variables

Once logged in, create a public and secret key in the dashboard by going to [http://localhost:3010/project/orchestrate-lite/settings/api-keys](http://localhost:3010/project/orchestrate-lite/settings/api-keys) and selecting "Create new API keys".

Next, export the public and secret keys as shown below:

```bash
export LANGFUSE_PUBLIC_KEY="your-langfuse-public-key"
export LANGFUSE_SECRET_KEY="your-langfuse-secret-key"
export LANGFUSE_HOST="http://localhost:3010"
```

#### 3. Run the demo

```bash
python demos/wxo_adk_agent_evaluation_demo.py
```

#### Configuration

You can customize the following values in `demos/wxo_adk_agent_evaluation_demo.py`:

```python
DATASET_NAME = "default-collection"
DATASET_DESCRIPTION = "default-collection-description"

EXPERIMENT_NAME = "default-experiment-name"
EXPERIMENT_DESCRIPTION = "default-experiment-description"

EVALUATION_NAME = "default-evaluation-name"
RUN_ID = "default-run-id"
```

#### Notes
- The demo will create traces visible in your Langfuse dashboard under the configured project

</details>

### Live Monitoring with Runtime Metrics
**Demos coming soon**. In the meantime, you can use [Langfuse's LLM-as-Judge (LLMaaJ) guide](https://langfuse.com/docs/evaluation/evaluation-methods/llm-as-a-judge) to build and deploy LLMaaJ to evaluate your agent sessions in real-time.


## How to setup tracing
This section covers how to configure tracing for each supported agent framework.

#### PydanticAI
<details>
For pydantic AI, we rely on open inference for tracing. 
Make sure you install the following packages:

```
"openinference-instrumentation-pydantic-ai",
"opentelemetry-sdk",
"opentelemetry-exporter-otlp",
"pydantic_ai"
```

And initialize the Agent in the following way:

```
from pydantic_ai.models.instrumented import InstrumentationSettings
from pydantic_ai import Agent
from agentops.utils.tracer_setup import setup_pydantic_ai_tracer
instrumentation = InstrumentationSettings()
setup_pydantic_ai_tracer()
agent = Agent(
    'openai:gpt-4.1',
    system_prompt=system_prompt,
   instrument=instrumentation
)
```

</details>

#### CrewAI
<details>
For CrewAI tracing make sure you install the following packages:

```
"openinference-instrumentation-crewai",
"opentelemetry-sdk",
"opentelemetry-exporter-otlp",
"crewai"
```

And initialize the tracer in the following way:
```python
from agentops.utils.tracer_setup import setup_crewai_tracer

setup_crewai_tracer()
```

Now create and run your CrewAI agents. The tracer will automatically capture all agent interactions.
</details>

#### Langfuse
<details>
Guidance coming soon
</details>

#### langgraph 
<details>
Guidance coming soon
</details>

#### Orchestrate
<details>
Guidance coming soon
</details>

## Provider Selection Guide

The AgentOps SDK supports multiple LLM providers. The `get_provider()` function automatically selects the appropriate provider based on environment variables and parameters. Here's when to use each:

- GatewayProvider (Default): Used for IBM Orchestrate agents. This is the default provider when no specific environment variables are set.
- WatsonXProvider: Automatically selected when `WATSONX_APIKEY` and `WATSONX_SPACE_ID` environment variables are set.
- ModelProxyProvider: Automatically selected when `WO_API_KEY` and `WO_INSTANCE` environment variable is set.
- PortkeyProvider: Used for external LLM vendors such as OpenAI, Azure OpenAI, Anthropic, etc. Specify the `vendor` parameter in `get_provider()` (e.g., `vendor="openai"`).
- OllamaProvider: Specify `provider="ollama"` in the config when using local Ollama models.

## Contribution Guide
Please carefully read this guide before creating PR and Issues.

### Secret Detection
This project uses [detect-secrets](https://github.com/ibm/detect-secrets) with a pre-commit hook to prevent secrets from being committed.

**First-time setup** (after cloning the repo):
```bash
make install-hooks
```

To manually scan all files or if your PR build fails on `tekton/code-detect-secrets`, run:
```bash
make detect-secrets
```
Audit the findings, mark them as real secrets (remove them!) or false positives, then commit the updated `.secrets.baseline` file.

<details>
  <summary><b>Contributor Responsibility</b></summary>


- Adhere to standards: Follow the project's specific [coding standards and conventions](CONTRIBUTING.md). 
- Write quality code: Ensure the code is clean, readable, and doesn't break existing functionality.
- Test thoroughly: Create and run automated tests, providing test cases for new features or fixes. You must ensure existing tests pass or that any new failures were not caused by your contribution. 
- Document clearly: Write clear and concise documentation for the code and provide informative commit messages. 
- Communicate effectively: Inform the project team about any limiting assumptions, possible code conflicts, or issues that prevent you from achieving a goal. 
- Participate in reviews: Be responsive to feedback and be prepared to make changes based on code reviews. 
- Code of conduct: Be respectful to others and follow our [code of conduct](CODE_OF_CONDUCT.md).

</details>

<details>
  <summary><b>Maintainer Responsibility</b></summary>

Maintainers are contributors who have demonstrated consistent, high-quality work and a commitment to the project's long-term health. They have special permissions, such as the ability to review and merge code changes from other contributors. Their responsibilities include:
  - Reviewing PRs in less than 24 hours & provide timely feedback
  - Responding and addressing issues.
  - Ensuring the project stays true to its core vision.

</details>

<details>
  <summary><b>How to propose a new change</b></summary>

1. Create an [issue](https://github.ibm.com/AgentOps/agentops-core/issues/5#issue-56495035) describing:
   - the intention and motivation behind the change,
   - the problem or gap it addresses (if applicable),
   - any relevant context, examples, or screenshots.

2. Tag the project owners for review and discussion.

3. After alignment, a contributor (you or someone else) can open a PR linked to the issue.

4. Use the issue to track updates, design decisions, and any changes in scope.

</details>

<details>
  <summary><b>Pull Request Guidelines</b></summary>

Before opening a PR, please review the [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidance on our development workflow and coding standards.

To ensure your changes meet project requirements:

1. **Run the full pre-submit checks**  
   Use the following command to verify formatting, linting, and tests all pass:
   ```bash
   make all
2. **Link the PR to its corresponding issue**  
   This provides context and makes the review process smoother.
3. **Keep the PR focused and well-scoped**  
   Avoid combining unrelated changes. Smaller, focused PRs are easier to review.
4. **Ensure code and documentation are consistent**  
   Update any relevant docs, examples, or type hints if your change introduces new behavior.
</details>

## How to report a bug
Found a bug? Please read our [bug reporting guidelines](BUG_REPORT.md) before submitting an issue.


## How to add a new metric
To introduce a new metric (e.g., a metric that evaluates the quality of a conversation), follow this pattern.

All metrics must live in the agentops/metrics directory.
Add your new metric as:

```bash
agentops/metrics/conversation_quality_score.py
```

Below is an example implementation:
```python
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
import json

class ConversationQualityScore(Evaluation):
    def __init__(self, llm_client=None, config=None):
        super().__init__(llm_client, config)

    def do_evaluate(
            self,
            messages,
            extracted_context,
            ground_truth=None,
            metadata=None,
    ):
        # add the custom logic here
        history = "\n".join([msg.role + ": " + msg.content for msg in messages])
        prompt = "What's the quality of the conversation {} \n give me a score of 1 if everything looks right or 0 otherwise. " \
                 "output in {{\"conversation_quality_score\": 0}}".format(history)
        output = self.llm_client.query(prompt)
        try:
            score = json.loads(output)["conversation_quality_score"]
        except:
            score = 0

        return EvaluatorData(
            eval_name="conversation_quality_score",
            value=score,
            metadata=metadata,
            data_type="NUMERIC",
        )
```

Your metric must follow these requirements:

1. **Subclass `Evaluation`.**  
   Your metric must extend the `Evaluation` base class so it can run inside the Agent Ops
   evaluation pipeline and access the shared LLM client.

2. **Override the `do_evaluate()` method.**  
   This method is where you implement the logic for computing your metric. Inside `do_evaluate()`, you can:
   - inspect the conversation messages,
   - use `ground_truth` or `metadata` if needed,
   - call the LLM to score or classify,
   - compute any custom logic.

Your `do_evaluate()` function must write the resulting value into `EvaluatorData` object.  
The value can be **scalar**, **boolean**, or **categorical (string)**.

```python
EvaluatorData(
    eval_name=<metric_key>,
    value=<metric_value>,  # scalar, boolean, or categorical category
    metadata=metadata,
    data_type="NUMERIC",
)
```

Now that you have built a custom Evaluator, you can add it to the `EvaluationRunner` to run it on a session of data.

```python

from agentops.langfuse_evaluation_package import (
    EvaluationRunner,
    default_aggregator,
)
from agentops.service_provider import get_provider

llm_client = get_provider(
    vendor="openai",
    model_id="gpt-4o-mini",
    api_key=<your-open-ai-api-key>,
)
conversation_quality = ConversationQualityScore(llm_client)
run = EvaluationRunner(
    evaluation_name="sample evaluation",
    run_name="sample run",
    session_ids=session_ids,
    collection=None,
    metrics=[conversation_quality],
    aggregator=default_aggregator,
)

experiment_results = run.evaluate()
```


## Pre-deployment Workflow Overview

**📹 Watch the pre-deployment workflow overview video:**

[Introducing the Agent Ops SDK: Architecture and User Story Insights 🚀 - Watch Video](https://www.loom.com/share/3c5e6f15baf9420697970114e9ad272d)

[![Pre-deployment Workflow Overview Video](https://cdn.loom.com/sessions/thumbnails/3c5e6f15baf9420697970114e9ad272d-612046be390c8c51-full-play.gif#t=0.1)](https://www.loom.com/share/3c5e6f15baf9420697970114e9ad272d)

The diagram below outlines the pre-deployment workflow for evaluating and improving AI agents:

1. Test Data Generation — Create Realistic Scenarios - Define tasks, user goals, prompts, and edge cases. This produces structured, reproducible evaluation data that reflects real enterprise workflows.

2. Simulation — Run Agents Through the Scenarios - Agents execute full journeys against the generated test data. Every action, tool call, and message is recorded to produce rich, replayable traces.

3. Metric Computation — Score Outcomes and Failures - Compute journey success, task correctness, error categories, and behavioral metrics from the traces. This gives a quantitative view of reliability.

4. Optimization & Inference-Time Scaling — Improve Performance - Use evaluation results to update prompts, tools, schemas, retrieval, or models. Apply inference-time scaling strategies (best-of-n, reranking, majority vote) to increase robustness. Re-run the loop to validate improvements.

![Workflow Overview](doc/assets/end-2-end-diagram.svg)

### How everything works under the hood?
<details>
  <summary><b>Test Data Generation</b></summary>

1. Prepare the Dataset

Provide a CSV file containing:
User Stories:
The task a user wants to accomplish and additional context such as usernames, dates, or identifiers

Tool Specifications
Each tool spec defines: Tool name, Input parameters, Output structure

These two inputs form the foundations for producing grounded tool-execution plans.

2. Generate a Tool Plan  
Feed the tool specification and user story to the planner:
Example user story: 
I want to look up my time-off schedule from 2025-01-01 to 2025-12-31.
My username is nwaters.
```
[
  {
    "tool_name": "fetch_assignment_id",
    "inputs": {
      "username": "nwaters"
    }
  },
  {
    "tool_name": "retrieve_timeoff_schedule",
    "inputs": {
      "assignment_id": "$fetch_assignment_id",
      "start_date": "2025-01-01",
      "end_date": "2025-12-31"
    }
  }
]
```
How the planner fills in the fields:

"username" is taken from the story’s context.

"start_date" and "end_date" are extracted directly from the story.


"$fetch_assignment_id" → “use the output of the previous step.”

3. Validate the Plan (Iterative Placeholder Resolution)

After generating the plan, the user agent validates each tool call by interacting with the target agent.

Step 1: Validate the first tool call

The user agent asks:

“Can you call fetch_assignment_id with username = nwaters?”

If successful, suppose the tool returns:
```
abc1123
```
Step 2: Propagate the returned values

The system then substitutes the placeholder in the next step:
```
{
  "tool_name": "retrieve_timeoff_schedule",
  "inputs": {
    "assignment_id": "abc1123",
    "start_date": "2025-01-01",
    "end_date": "2025-12-31"
  }
}
```
Step 3: Iterate until all placeholders are resolved

If all steps validate successfully, the plan becomes fully resolved.

If any validation fails, the entire plan is rejected.
</details>

## Community Scrum and Office Hours
**Office hours** cover getting started with the SDK, integration and workflow questions, debugging issues, demos of new features, and general Q&A. The **Community Scrum** is a round-table discussion for developers working with the SDK. For a detailed description of the Community Scrum, see [this discussion](https://github.ibm.com/AgentOps/agentops-core/discussions/118).

| Day | Event | Time | Enrollment |
|-----|-------|------|------------|
| Monday | Community Scrum | 10:00am EST | [Enrollment link](https://ec.yourlearning.ibm.com/w3/event/10545130) |
| Wednesday | Office Hours | 10:00am EST | [Enrollment link](https://ec.yourlearning.ibm.com/w3/event/10542814) |
| Friday | Office Hours | 4:00pm EST | [Enrollment link](https://ec.yourlearning.ibm.com/w3/event/10545131) |

**Hosted by Core AI Team:**   
• Haode Qi   
• Pratyush Singh   
• Reza Fazeli   
• Cole Hurwitz   
• Akash Srivastava   

## Support

**Slack channel: #agent-ops-sdk**

To ensure predictable, scalable support as Agent Ops adoption grows across IBM, we establish a structured, multi-layer support model:   
• Core maintainers provide primary support during the early phase    
• A dedicated Technical PM for triaging and coordination   
• Extended support comes from ADK, Domains, Consulting, and xGov teams   
• A 24-hour SLA governs all responses   
• Slack ↔ GitHub mapping ensures traceability for every request   

### 👥 Support Structure    
**Core Maintainers (Primary Layer)**  

Core maintainers from the AgentOps team handle:  
• Triaging and resolution  
• Architectural guidance and code review  
• Maintaining quality + consistency of contributions  
• Ensuring SLA compliance  

**Technical PM (InnerSource)**  

A dedicated Technical PM is responsible for:  
• Monitoring the Slack support channel and providing resolutions where possible  
• Routing questions to the right team with tags  
• Creating GitHub issues for Slack asks (if requester doesn’t)  
• Tracking SLA metrics and escalating when needed  
• Supporting onboarding for new InnerSource contributors  

**Extended Support Contributors**  

As more teams adopt AgentOps, extended support includes:  
• ADK team  
• Domains team  
• Consulting / Expert Labs  
• xGov  

These contributors provide:  
• Domain-specific expertise   
• Fixes and enhancements in their respective areas  
• Additional eyes/coverage as the community grows  

### ⏱ SLA: Response Time Commitment
All Slack questions and GitHub issues must receive an initial response within 24 hours.

“Response” = acknowledgment + initial triage.

The TPM monitors all SLA compliance.

### 🏷 Slack Tagging System & Github Issues
To route issues efficiently, we define team tags:

@agentops-core  
@adk-support  
@domains-support    
@consulting-support  
@xgov-support  

**Urgency Tags**

We mirror GitHub priorities using Slack keywords:  
- P0 – Critical: breakage, customer blockers, production issues  
- P1 – High: major functionality impacted  
- P2 – Normal: standard bugs/features/questions  
- P3 – Low: non-urgent or nice-to-have asks  

**GitHub Issues Are Mandatory**  
Every Slack request must map to a GitHub issue.

Rules:  
• Slack → GitHub issue created by requester  
• Issue must include:  
• priority label (P0, P1, etc.)  
• team ownership label   
• link back to the Slack thread  
• All technical discussion + resolution must happen in GitHub  
• Slack remains for clarification, not canonical state  


## Orchestrate Users  
If you're using the Orchestrate ADK, please refer to the dedicated guide in [README_wxo.md](README_wxo.md).



