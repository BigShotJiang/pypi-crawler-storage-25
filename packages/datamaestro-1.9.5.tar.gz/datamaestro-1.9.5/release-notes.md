## [1.9.5] - 2026-04-03

### Bug Fixes
- Do not mark a download done if failed ([d47034d](https://github.com/experimaestro/experimaestro-python/commit/d47034d1213b10724856d2b7bbb28edc62d90f16))

