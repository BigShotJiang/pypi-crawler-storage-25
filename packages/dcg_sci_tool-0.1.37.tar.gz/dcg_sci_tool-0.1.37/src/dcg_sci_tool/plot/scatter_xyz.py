from typing import List, Tuple, Union, Optional
from dcg_sci_tool.plot.float_to_viridis_rgb import float_to_viridis_rgb


def scatter_xyz(x_list:list, y_list:list, z_list:list, color_list:list, vmin, vmax, max_color = None):
    """
    将三维数据点按照color_list中的值映射到Viridis色阶的颜色，并将结果保存为plot.xyz文件

    Args:
        x_list: x坐标列表
        y_list: y坐标列表
        z_list: z坐标列表
        color_list: 用于颜色映射的数值列表
        vmin: 可选的最小值，用于归一化。如果为None，将使用输入数组的最小值
        vmax: 可选的最大值，用于归一化。如果为None，将使用输入数组的最大值
        max_color: 可选的最大颜色值，用于超出范围时的颜色，如果为None，将使用黄色


    """
    Lattice_side = 100.0
    N_atoms = len(x_list)

    range_x = max(x_list) - min(x_list)
    range_y = max(y_list) - min(y_list)
    range_z = max(z_list) - min(z_list)

    colors = float_to_viridis_rgb(color_list, vmin=vmin, vmax=vmax, max_color=max_color)

    with open("plot.xyz", "w", newline='', encoding='utf-8') as xyz_file:
        xyz_file.write(f"{N_atoms}\n")
        xyz_file.write(f'Lattice="{Lattice_side} 0.0 0.0 0.0 {Lattice_side} 0.0 0.0 0.0 {Lattice_side}" Properties=pos:R:3:color:R:3\n')

        for x, y, z, color in zip(x_list, y_list, z_list, colors):
            x = x/range_x * Lattice_side
            y = y/range_y * Lattice_side
            z = z/range_z * Lattice_side

            xyz_file.write(f"{x:.3f} {y:.3f} {z:.3f} {color[0]:.3f} {color[1]:.3f} {color[2]:.3f}\n")
