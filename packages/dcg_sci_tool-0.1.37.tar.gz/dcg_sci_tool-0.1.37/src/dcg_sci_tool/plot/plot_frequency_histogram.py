import numpy as np
import matplotlib.pyplot as plt
from typing import List, Tuple, Dict, Union
import matplotlib.ticker as ticker

def plot_frequency_histogram(
    data: Union[List[float], np.ndarray],
    n_bins: int,
    title: str = 'Frequency Distribution Histogram',
    xlabel: str = 'Value',
    ylabel: str = 'Frequency',
    show_table: bool = True,
) -> Dict:
    """
    Manually implement frequency distribution histogram: 
    Divide data into n_bins intervals and count the frequency of each interval
    
    Args:
        data: Input data list or array
        n_bins: Number of bins on x-axis
        title: Chart title
        xlabel: x-axis label
        ylabel: y-axis label
        show_table: Whether to show frequency distribution table
    
    Returns:
        Dictionary containing frequency statistics
    """
    # Convert to numpy array for calculation
    data = np.asarray(data)
    
    # Calculate data range

    data_min = np.min(data)

    data_max = np.max(data)

    
    # Calculate bin edges (equal spacing)
    bin_edges = np.linspace(data_min, data_max, n_bins + 1)
    bin_width = bin_edges[1] - bin_edges[0]
    
    # Calculate the midpoint of each bin
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    
    # Manually calculate frequencies
    frequencies = np.zeros(n_bins, dtype=int)
    
    for value in data:
        # Find the bin index for the value
        bin_idx = int((value - data_min) / (data_max - data_min) * n_bins)
        
        # Handle boundary case: maximum value falls in the last bin
        if bin_idx == n_bins:
            bin_idx = n_bins - 1
        
        # Increment the count for the corresponding bin
        frequencies[bin_idx] += 1
    
    # Verify the sum of frequencies
    total_count = np.sum(frequencies)
    
    # Create a single figure
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Draw frequency distribution histogram
    bars = ax.bar(bin_centers, frequencies, 
                  width=bin_width * 1.0,  # Bar width is 100% of bin width
                  align='center',
                  color=plt.cm.Blues(np.linspace(0.4, 0.8, n_bins)),
                  edgecolor='black',
                  linewidth=1)
    
    # Display frequency above each bar
    for bar, freq in zip(bars, frequencies):
        if freq > 0:  # Only display non-zero frequencies
            ax.text(bar.get_x() + bar.get_width()/2, 
                   bar.get_height(),
                   str(freq),
                   ha='center', va='bottom',
                   fontsize=9, fontweight='bold')
    
    # Set chart properties
    ax.set_title(title, fontsize=16, pad=20)
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.grid(True, alpha=0.3, linestyle='--')
    
    # Set x-axis ticks
    ax.set_xticks(bin_edges)
    ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
    
    # Add density curve
    # try:
    #     from scipy.stats import gaussian_kde
    #     if len(data) > 1:
    #         kde = gaussian_kde(data)
    #         x_smooth = np.linspace(data_min, data_max, 1000)
    #         y_smooth = kde(x_smooth) * total_count * bin_width
    #         ax.plot(x_smooth, y_smooth, 'r-', linewidth=2, label='Probability Density Curve')
    #         ax.legend()
    # except ImportError:
    #     print("Note: scipy not installed, cannot draw density curve")
    
    # Prepare statistical information
    stats_dict = {
        'bin_edges': bin_edges,
        'frequencies': frequencies,
        'bin_centers': bin_centers,
        'total_count': total_count,
        'data_min': data_min,
        'data_max': data_max,
        'data_mean': np.mean(data),
        'data_std': np.std(data)
    }
    
    # Create statistical information text
    stats_text = f"Statistical Summary:\n"
    stats_text += f"Sample Size: {total_count}\n"
    stats_text += f"Min Value: {data_min:.2f}\n"
    stats_text += f"Max Value: {data_max:.2f}\n"
    stats_text += f"Mean: {np.mean(data):.2f}\n"
    stats_text += f"Std Dev: {np.std(data):.2f}"
    
    # Add statistical information box
    # ax.text(0.02, 0.98, stats_text,
    #        transform=ax.transAxes,
    #        verticalalignment='top',
    #        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8),
    #        fontsize=9,
    #        fontfamily='monospace')
    
    plt.tight_layout()
    plt.show()
    
    return stats_dict


# Example usage
if __name__ == "__main__":
    # Generate sample data
    np.random.seed(42)
    sample_data = np.random.normal(0, 1, 1000)
    
    # Plot histogram
    stats = plot_frequency_histogram(
        data=sample_data,
        n_bins=20,
        title="Normal Distribution Histogram",
        xlabel="Value",
        ylabel="Frequency"
    )
    
    print("Statistics summary:")
    print(f"Data range: {stats['data_min']:.4f} to {stats['data_max']:.4f}")
    print(f"Mean: {stats['data_mean']:.4f}, Std Dev: {stats['data_std']:.4f}")
    print(f"Total data points: {stats['total_count']}")