import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker

def create_categorical_heatmap(
    data_tuples, 
    x_label_index, 
    y_label_index, 
    value_index,
    x_labels_order=None,  # 新增：横轴标签顺序
    y_labels_order=None,  # 新增：纵轴标签顺序
    title="Categorical Heatmap",
    xlabel=None,
    ylabel=None,
    cmap="YlGn",
    cbarlabel="Value",
    figsize=(10, 8)
):
    """
    从元组列表创建分类热力图（支持指定标签顺序）
    使用方法：执行完此函数后，执行plt.show()命令，即可将图片展示出来
    
    Args:

        data_tuples (list of tuples): 输入数据，每个元组包含：横轴标签、纵轴标签、数值
        x_label_index (int): 元组中横轴标签的索引位置
        y_label_index (int): 元组中纵轴标签的索引位置
        value_index (int): 元组中数值的索引位置
        x_labels_order (list, optional): 横轴标签的排列顺序
        y_labels_order (list, optional): 纵轴标签的排列顺序
        title (str, optional): 热力图的标题
        xlabel (str, optional): 横轴标签
        ylabel (str, optional): 纵轴标签
        cmap (str, optional): 颜色映射
        cbarlabel (str, optional): 颜色条标签
        figsize (tuple, optional): 图形大小
    
    Returns:
        tuple: 包含创建的图形、坐标轴对象和数据矩阵
            fig (matplotlib.figure.Figure): 创建的图形
            ax (matplotlib.axes.Axes): 坐标轴对象
            data_matrix (numpy.ndarray): 热力图数据矩阵
    """
    
    # 修改prepare_heatmap_data函数以支持指定顺序
    data_matrix, x_labels, y_labels = prepare_heatmap_data_ordered(
        data_tuples, 
        x_label_index, 
        y_label_index, 
        value_index,
        x_labels_order,
        y_labels_order
    )
    
    # 创建图形
    fig, ax = plt.subplots(figsize=figsize)
    
    # 绘制热力图
    im = ax.imshow(data_matrix, cmap=cmap, aspect='auto')
    
    # 设置坐标轴标签
    ax.set_xticks(range(len(x_labels)))
    ax.set_yticks(range(len(y_labels)))
    ax.set_xticklabels(x_labels, rotation=45, ha="right", rotation_mode="anchor")
    ax.set_yticklabels(y_labels)
    
    # 添加数值标注
    for i in range(len(y_labels)):
        for j in range(len(x_labels)):
            value = data_matrix[i, j]
            if not np.isnan(value):
                # 格式化显示：如果是整数显示整数，否则显示两位小数
                if value.is_integer():
                    text = f"{int(value)}"
                else:
                    text = f"{value:.2f}"
                ax.text(j, i, text, ha="center", va="center", 
                       color="w" if value > np.nanmax(data_matrix)/2 else "black")
    
    # 添加颜色条
    cbar = fig.colorbar(im, ax=ax)
    cbar.ax.set_ylabel(cbarlabel, rotation=-90, va="bottom")
    
    # 设置标题和轴标签
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=18)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=18)
    
    # 调整布局
    fig.tight_layout()
    
    return fig, ax, data_matrix


def create_categorical_heatmap_advanced(
    data_tuples, 
    x_label_index, 
    y_label_index, 
    value_index,
    x_labels_order=None,  # 新增：横轴标签顺序
    y_labels_order=None,  # 新增：纵轴标签顺序
    title="Categorical Heatmap",
    cmap="YlGn",
    cbarlabel="Value",
    figsize=(12, 10),
    annotate=True,
    valfmt="{x:.2f}",
    threshold=None,
    textcolors=("black", "white"),
    grid_visible=True
):
    """
    增强版的分类热力图创建函数（支持指定标签顺序）
    使用方法：执行完此函数后，执行plt.show()命令，即可将图片展示出来
    
    Args:
        data_tuples (list of tuples): 输入数据，每个元组包含：横轴标签、纵轴标签、数值
        x_label_index (int): 元组中横轴标签的索引位置
        y_label_index (int): 元组中纵轴标签的索引位置
        value_index (int): 元组中数值的索引位置
        x_labels_order (list): 横轴标签的排列顺序
        y_labels_order (list): 纵轴标签的排列顺序
        y_labels_order (list, optional): 纵轴标签的排列顺序
        annotate (bool, optional): 是否在方格中添加数值标注
        valfmt (str, optional): 数值格式化字符串
        threshold (float, optional): 文本颜色切换的阈值
        textcolors (tuple, optional):  用于阈值上下方的文本颜色
        grid_visible (bool, optional):  是否显示网格线

    """
    data_matrix, x_labels, y_labels = prepare_heatmap_data_ordered(
        data_tuples, 
        x_label_index, 
        y_label_index, 
        value_index,
        x_labels_order,
        y_labels_order
    )
    
    # 处理NaN值（用0或其他默认值替换）
    data_matrix_filled = np.nan_to_num(data_matrix, nan=0.0)
    
    # 创建图形
    fig, ax = plt.subplots(figsize=figsize)
    
    # 绘制热力图
    im = ax.imshow(data_matrix_filled, cmap=cmap, aspect='auto')
    
    # 设置坐标轴
    ax.set_xticks(range(len(x_labels)))
    ax.set_yticks(range(len(y_labels)))
    ax.set_xticklabels(x_labels, rotation=-30, ha="right", rotation_mode="anchor")
    ax.set_yticklabels(y_labels)
    
    # 在顶部显示横轴标签
    ax.tick_params(top=True, bottom=False, labeltop=True, labelbottom=False)
    
    # 添加网格线
    if grid_visible:
        ax.set_xticks(np.arange(data_matrix_filled.shape[1] + 1) - 0.5, minor=True)
        ax.set_yticks(np.arange(data_matrix_filled.shape[0] + 1) - 0.5, minor=True)
        ax.grid(which="minor", color="w", linestyle='-', linewidth=2)
        ax.tick_params(which="minor", bottom=False, left=False)
    
    # 隐藏边框
    ax.spines[:].set_visible(False)
    
    # 添加数值标注
    if annotate:
        # 确定阈值
        if threshold is None:
            threshold = np.nanmax(data_matrix_filled) / 2
        
        # 格式化器
        if isinstance(valfmt, str):
            valfmt_func = matplotlib.ticker.StrMethodFormatter(valfmt)
        else:
            valfmt_func = valfmt
        
        # 添加文本标注
        for i in range(data_matrix_filled.shape[0]):
            for j in range(data_matrix_filled.shape[1]):
                value = data_matrix_filled[i, j]
                if not np.isnan(value) and value != 0:  # 跳过NaN和0值
                    # 根据阈值选择文本颜色
                    text_color = textcolors[1] if value > threshold else textcolors[0]
                    
                    # 格式化文本
                    if isinstance(valfmt_func, matplotlib.ticker.StrMethodFormatter):
                        text = valfmt_func.format_data(value)
                    else:
                        text = str(int(value)) if value.is_integer() else f"{value:.2f}"
                    
                    ax.text(j, i, text, ha="center", va="center", 
                           color=text_color, fontweight='bold')
    
    # 添加颜色条
    cbar = fig.colorbar(im, ax=ax)
    cbar.ax.set_ylabel(cbarlabel, rotation=-90, va="bottom")
    
    # 设置标题
    ax.set_title(title, fontsize=16, fontweight='bold', pad=20)
    
    # 调整布局
    fig.tight_layout()
    
    return fig, ax, data_matrix_filled


def prepare_heatmap_data_ordered(
    data_tuples, 
    x_index, 
    y_index, 
    value_index,
    x_labels_order=None,
    y_labels_order=None
):
    """
    从元组列表准备热力图数据（支持指定标签顺序）。

    
    Args:

        data_tuples (list of tuples): 原始数据元组列表

        x_index (int): 横轴标签索引

        y_index (int): 纵轴标签索引

        value_index (int): 数值索引

        x_labels_order (list, optional): 横轴标签的排列顺序

        y_labels_order (list, optional): 纵轴标签的排列顺序
    
    Returns:
        tuple : (data_matrix, x_labels, y_labels)
        数据矩阵，横轴标签列表，纵轴标签列表
    """
    # 从数据中提取所有唯一标签
    all_x_labels = set(tup[x_index] for tup in data_tuples if len(tup) > x_index)
    all_y_labels = set(tup[y_index] for tup in data_tuples if len(tup) > y_index)
    
    # 确定最终的标签顺序
    if x_labels_order is None:
        # 如果没有指定顺序，使用排序后的标签
        x_labels = sorted(all_x_labels)
    else:
        # 如果指定了顺序，使用指定顺序，但要过滤掉不存在的标签
        x_labels = [label for label in x_labels_order if label in all_x_labels]
        # 添加可能缺失的标签（按照字母顺序）
        missing_x = sorted(all_x_labels - set(x_labels))
        x_labels.extend(missing_x)
    
    if y_labels_order is None:
        y_labels = sorted(all_y_labels)
    else:
        y_labels = [label for label in y_labels_order if label in all_y_labels]
        missing_y = sorted(all_y_labels - set(y_labels))
        y_labels.extend(missing_y)
    
    # 创建映射
    x_label_to_idx = {label: idx for idx, label in enumerate(x_labels)}
    y_label_to_idx = {label: idx for idx, label in enumerate(y_labels)}
    
    # 创建数据矩阵（初始化为NaN）
    data_matrix = np.full((len(y_labels), len(x_labels)), np.nan, dtype=float)
    
    # 填充数据
    for tup in data_tuples:
        if len(tup) > max(x_index, y_index, value_index):
            x_label = tup[x_index]
            y_label = tup[y_index]
            value = tup[value_index]
            
            if x_label in x_label_to_idx and y_label in y_label_to_idx:
                i = y_label_to_idx[y_label]
                j = x_label_to_idx[x_label]
                data_matrix[i, j] = float(value)
    
    return data_matrix, x_labels, y_labels