from dcg_sci_tool.csv.csv_to_tuples import csv_to_tuples
from dcg_sci_tool.plot.scatter_xyz import scatter_xyz
import numpy as np



def csv2xyz(input_file: str, x_col: int, y_col: int, z_col: int, color_col: int, vmin=None, vmax=None, max_color=None):
    """
    将.csv文件中指定列的数据绘制成三维散点图，并将结果保存为plot.xyz文件
    Args:
        input_file: 输入的CSV文件路径
        x_col: 用于x坐标的列索引
        y_col: 用于y坐标的列索引
        z_col: 用于z坐标的列索引
        color_col: 用于颜色映射的数值列索引
        vmin: 可选的最小值，用于归一化。如果为None，将使用输入数组的最小值。
        vmax: 可选的最大值，用于归一化。如果为None，将使用输入数组的最大值。
        max_color: 可选的最大颜色值，用于超出范围时的颜色，如果为None，将使用黄色
    """
    data_list = csv_to_tuples(input_file, has_header=True)

    data_list = np.array(data_list)
    x = data_list[:, x_col].astype(float)
    y = data_list[:, y_col].astype(float)
    z = data_list[:, z_col].astype(float)
    colors = data_list[:, color_col].astype(float)

    scatter_xyz(x, y, z, colors, vmin=vmin, vmax=vmax, max_color=max_color)
    