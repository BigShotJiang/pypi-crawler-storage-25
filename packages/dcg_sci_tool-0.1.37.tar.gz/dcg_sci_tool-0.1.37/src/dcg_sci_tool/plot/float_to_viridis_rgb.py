import numpy as np
from typing import List, Tuple, Union, Optional


def float_to_viridis_rgb(float_array: Union[List[float], np.ndarray],
                                        vmin: Optional[float] = None,
                                        vmax: Optional[float] = None,
                                        max_color: Optional[Tuple[float, float, float]] = None
                                        ) -> List[Tuple[int, int, int]]:
    """
    将浮点数数组映射到Viridis色阶的RGB颜色列表，使用接近matplotlib Viridis的色阶

    Args:
        float_array: 输入的浮点数数组，可以是列表或numpy数组
        vmin: 可选的最小值，用于归一化。如果为None，将使用输入数组的最小值。
        vmax: 可选的最大值，用于归一化。如果为None，将使用输入数组的最大值。
        max_color: 可选的最大颜色值，用于超出范围时的颜色。如果为None，将使用黄色。

    """
    arr = np.array(float_array, dtype=float)
    
    if vmin is None:
        vmin = arr.min()
    if vmax is None:
        vmax = arr.max()

    if vmax == vmin:
        vmax = vmin + 1
    
    normalized = (arr - vmin) / (vmax - vmin)

    if max_color is None:
        # 将值限制在0到1之间，当输入值超出范围时，使用边界颜色
        normalized = np.clip(normalized, 0.0, 1.0)
    
    # Viridis色阶的预定义控制点（来自matplotlib）
    viridis_data = np.array([
        [0.267004, 0.004874, 0.329415],  # 深紫色
        [0.275191, 0.194905, 0.496005],  # 紫色
        [0.212395, 0.359683, 0.551710],  # 蓝紫色
        [0.153364, 0.497000, 0.557724],  # 蓝色
        [0.122312, 0.633153, 0.530398],  # 青蓝色
        [0.288921, 0.758397, 0.428397],  # 蓝绿色
        [0.626579, 0.854645, 0.223353],  # 绿色
        [0.993248, 0.906157, 0.143936]   # 黄色
    ])
    
    rgb_colors = []
    
    for t in normalized:
        if t <= 1.0:
            # 将t映射到控制点索引
            idx = t * (len(viridis_data) - 1)
            idx_floor = int(np.floor(idx))
            idx_ceil = int(np.ceil(idx))

            if idx_floor == idx_ceil:
                # 正好在控制点上
                r, g, b = viridis_data[idx_floor]
            else:
                # 线性插值
                weight = idx - idx_floor
                r = viridis_data[idx_floor, 0] * (1 - weight) + viridis_data[idx_ceil, 0] * weight
                g = viridis_data[idx_floor, 1] * (1 - weight) + viridis_data[idx_ceil, 1] * weight
                b = viridis_data[idx_floor, 2] * (1 - weight) + viridis_data[idx_ceil, 2] * weight
        else:
            r, g, b = max_color[0], max_color[1], max_color[2]  # 超出范围时使用最后一个颜色（黄色）
            
        rgb_colors.append((r, g, b))
    
    return rgb_colors