import csv

def get_unique_values_csv(csv_file, column_input, has_header=True):
    """
    使用csv模块获取CSV文件中指定列的唯一值列表
    
    Args:

        csv_file (str): CSV文件路径

        column_input (str or int): 列标识，可以是列名（字符串）或列索引（从0开始的整数）
    
        has_header (bool): 是否有表头，默认True
    """
    unique_values = set()
    
    try:
        with open(csv_file, 'r', encoding='utf-8') as file:
            csv_reader = csv.reader(file)
            
            if has_header:
                header = next(csv_reader)
                header_dict = {name: idx for idx, name in enumerate(header)}
                
                # 确定列索引
                if isinstance(column_input, int):
                    column_index = column_input
                else:
                    if column_input in header_dict:
                        column_index = header_dict[column_input]
                    else:
                        print(f"错误：列名 '{column_input}' 在文件中不存在。")
                        print(f"可用列名: {', '.join(header)}")
                        return []
                
                # 检查列索引是否有效
                if column_index >= len(header) or column_index < 0:
                    print(f"错误：列索引 {column_index} 超出范围。")
                    return []
            else:
                # 如果没有表头，列输入必须是整数索引
                if not isinstance(column_input, int):
                    print("错误：当CSV文件没有表头时，必须使用列索引（整数）。")
                    return []
                column_index = column_input
            
            # 读取数据并收集唯一值
            for row_num, row in enumerate(csv_reader, start=2 if has_header else 1):
                if column_index < len(row):
                    value = row[column_index].strip()
                    if value:  # 跳过空值
                        unique_values.add(value)
                else:
                    print(f"警告：第{row_num}行列数不足，跳过")
    
    except FileNotFoundError:
        print(f"错误：文件 '{csv_file}' 未找到。")
        return []
    except Exception as e:
        print(f"读取文件时出错: {e}")
        return []
    
    return list(unique_values)