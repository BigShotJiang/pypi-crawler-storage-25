import csv

def csv_to_tuples(csv_file: str, has_header: bool = True) -> list:
    """
    将CSV文件转换为元组列表。
    注意：元组列表中每个元素都是字符串类型
    
    Args:
        csv_file (str): CSV文件路径
        has_header (bool): 是否包含表头
    
    Returns:
        list: 元组列表
    """
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        
        if has_header:
            next(reader)  # 跳过表头
        
        return [tuple(row) for row in reader]