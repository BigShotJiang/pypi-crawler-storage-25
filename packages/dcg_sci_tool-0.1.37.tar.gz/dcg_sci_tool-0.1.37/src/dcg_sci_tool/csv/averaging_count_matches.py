from typing import List, Tuple, Any

def averaging_count_matches(
    list_src: List[Tuple[Any, ...]], 
    list_target: List[Tuple[Any, ...]],
    index_a: int = 3,
    index_b: int = 4
) -> List[Tuple[Any, ...]]:
    """
    统计list_src中元组的指定元素在list_target中的出现次数，并计算其他元素的平均值
    
    Args:
        list_src (List[Tuple[Any, ...]]): 源元组列表
        list_target (List[Tuple[Any, ...]]): 目标元组列表
        index_a (int): 要统计第一个元素的索引
        index_b (int): 要统计第二个元素的索引
    
    Returns:
        List[Tuple[Any, ...]]: 更新后的list_target，每个元组末尾添加了计数和平均值
    """
    if not list_src or not list_target:
        return [(item + (0, 0)) for item in list_target] if list_target else []
    
    # 创建字典用于快速查找
    lookup_dict = {}
    for idx, tup in enumerate(list_target):
        if len(tup) >= 2:  # 确保至少有前两个元素用于匹配
            key = tup[:2]  # 取前两个元素作为匹配键
            lookup_dict[key] = idx
    
    # 创建计数列表
    counts = [0] * len(list_target)
    sums = [0] * len(list_target)
    
    # 遍历list_a进行匹配
    for tup_a in list_src:
        if len(tup_a) >= index_b + 1:
            key = (tup_a[index_a], tup_a[index_b]) 
            if key in lookup_dict:
                idx = lookup_dict[key]
                counts[idx] += 1
                sums[idx] += float(tup_a[1])
    # 创建结果列表
    result = []
    for tup_b, count, sum in zip(list_target, counts, sums):
        result.append(tup_b + (count, 0 if count == 0 else sum/count))
    
    return result