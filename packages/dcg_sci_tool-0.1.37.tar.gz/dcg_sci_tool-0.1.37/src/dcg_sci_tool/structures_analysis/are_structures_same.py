import numpy as np
from ovito.io import import_file
from collections import defaultdict

def are_structures_same(file1, file2, tolerance=1e-6, verbose=False):
    """
    判断两个结构文件是否相同，原子顺序可以不同
    
    参数:
        file1, file2: 结构文件路径
        tolerance: 原子位置比较的容差，默认单位为Å，默认值为1e-6
        verbose: 是否输出详细信息，默认为False
        
    返回:
        bool: True表示结构相同
    """
    
    def load_structure(filepath):
        """加载结构文件"""
        try:
            pipeline = import_file(filepath)
            data = pipeline.compute()
            return data
        except Exception as e:
            if verbose:
                print(f"错误加载 {filepath}: {e}")
            return None
    
    # 1. 加载结构
    data1 = load_structure(file1)
    data2 = load_structure(file2)
    
    if data1 is None or data2 is None:
        return False
    
    p1, p2 = data1.particles, data2.particles
    
    # 2. 检查原子数量
    if p1.count != p2.count:
        if verbose:
            print(f"原子数量不同: {p1.count} != {p2.count}")
        return False
    
    # 3. 检查晶胞
    cell1 = data1.cell.matrix if data1.cell else None
    cell2 = data2.cell.matrix if data2.cell else None
    
    if cell1 is not None and cell2 is not None:
        if not np.allclose(cell1, cell2, atol=tolerance):
            if verbose:
                print("晶胞不同")
            return False
    
    # 4. 按原子类型分组比较
    return compare_with_types(p1, p2, tolerance, verbose)


def compare_with_types(p1, p2, tolerance, verbose):
    """有原子类型信息的比较"""
    
    # 按原子类型分组
    type_to_pos1 = defaultdict(list)
    type_to_pos2 = defaultdict(list)
    
    for i in range(p1.count):
        t1 = p1.particle_types[i]
        t2 = p2.particle_types[i]
        type_to_pos1[t1].append(p1.positions[i])
        type_to_pos2[t2].append(p2.positions[i])
    
    # 检查原子类型组成
    if set(type_to_pos1.keys()) != set(type_to_pos2.keys()):
        if verbose:
            print("原子类型集合不同")
        return False
    
    # 比较每种原子类型
    for atom_type in type_to_pos1:
        positions1 = np.array(type_to_pos1[atom_type])
        positions2 = np.array(type_to_pos2[atom_type])
        
        if len(positions1) != len(positions2):
            if verbose:
                print(f"类型 {atom_type} 原子数量不同")
            return False
        
        # 简单距离匹配
        if not match_positions(positions1, positions2, tolerance, verbose):
            if verbose:
                print(f"类型 {atom_type} 原子位置不匹配")
            return False
    
    if verbose:
        print("✓ 结构相同")
    return True



def match_positions(pos1, pos2, tolerance, verbose):
    """匹配两组原子位置"""
    n = len(pos1)
    
    if n == 0:
        return True
    
    # 中心化
    center1 = np.mean(pos1, axis=0)
    center2 = np.mean(pos2, axis=0)
    pos1_centered = pos1 - center1
    pos2_centered = pos2 - center2
    
    # 计算距离矩阵
    dist_matrix = np.linalg.norm(pos1_centered[:, np.newaxis] - pos2_centered, axis=2)
    
    # 贪心匹配
    matched = set()
    for i in range(n):
        min_idx = np.argmin(dist_matrix[i])
        
        if dist_matrix[i, min_idx] > tolerance:
            if verbose:
                print(f"  位置{i}不匹配: 最小距离={dist_matrix[i, min_idx]:.6f}")
            return False
        
        if min_idx in matched:
            # 如果已经匹配过，找下一个最小的
            row = dist_matrix[i].copy()
            row[list(matched)] = np.inf
            min_idx = np.argmin(row)
            if row[min_idx] > tolerance:
                if verbose:
                    print(f"  位置{i}无唯一匹配")
                return False
        
        matched.add(min_idx)
    
    return True