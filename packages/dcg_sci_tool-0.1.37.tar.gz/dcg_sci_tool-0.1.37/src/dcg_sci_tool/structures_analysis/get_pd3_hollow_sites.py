
from ovito.io import import_file
from dcg_sci_tool.structures_analysis.find_cluster_surface_hollow_sites import find_cluster_surface_hollow_sites
from dcg_sci_tool.extract_atom_types import extract_atom_types
from dcg_sci_tool.indexes2expression import indexes2expression

def get_pd3_hollow_sites(input_file, max_triangle_side=4.0, cutoff=3.5, CN_threshold=12):
    """
    从输入结构中提取Pd原子组成的表面Hollow位点。
    默认处理对象为致密、严格对称的结构（如代码生成的PdAu标准正二十面体团簇），
    对于MD或者MD帧优化得到的结构，建议调整cutoff和CN_threshold参数以适用更广泛的情况。
    
    Args:
        input_file: 输入结构文件路径 (支持.xyz, .data, .dump等格式)
        max_triangle_side: Hollow位点三角形最大边长(Å)，默认4.0
        cutoff: 配位数计算截断距离(Å)，默认3.5
        CN_threshold: 体相配位数阈值，默认12
        
    Returns:
        list: 包含Hollow位点信息的列表，每个元素是包含三个Pd原子序号的元组
    """
    
    # 1. 使用OVITO导入结构文件
    print(f"正在加载结构文件: {input_file}")
    try:
        pipeline = import_file(input_file)
        data = pipeline.compute()
    except Exception as e:
        print(f"错误: 无法加载结构文件 {input_file}")
        print(f"错误详情: {e}")
        return []
    
    # 2. 获取原子类型顺序

    type_names_order = extract_atom_types(input_file)
    
    print(f"总原子数: {data.particles.count if data.particles else 0}")
    
    # 3. 查找表面Hollow位点
    print("正在搜索表面Hollow位点...")
    print(f"参数: max_triangle_side={max_triangle_side}Å, cutoff={cutoff}Å, CN_threshold={CN_threshold}")
    
    try:
        hollow_sites = find_cluster_surface_hollow_sites(
            data=data,
            type_names_order=type_names_order
        )
    except Exception as e:
        print(f"错误: 在查找Hollow位点时发生异常")
        print(f"错误详情: {e}")
        return []
    
    # 4. 验证结果
    if not hollow_sites:
        print("警告: 未找到任何表面Hollow位点")
        print("可能原因:")
        print("  1. 结构中没有Pd原子")
        print("  2. 参数设置不合适(如max_triangle_side太小)")
        print("  3. 原子类型顺序(type_names_order)不正确")
        print("  4. 结构不是致密对称的PdAu团簇")
        return []
    
    # 5. 筛选出仅由Pd原子组成的Hollow位点
    pd_hollow_sites = []
    for site in hollow_sites:
        # 验证位点中的原子是否都是Pd
        all_pd = True
        for atom_idx in site:
            # 获取原子类型
            if data.particles and data.particles.particle_types:
                atom_type_id = data.particles.particle_types[atom_idx]
                atom_type_name = type_names_order[atom_type_id - 1]  # OVITO中类型从1开始
                if atom_type_name != 'Pd':
                    all_pd = False
                    break
        
        if all_pd:
            pd_hollow_sites.append(site)
    
    return pd_hollow_sites