from ovito.data import CutoffNeighborFinder
import numpy as np

def detect_O2_coordinating_to_PdAu(data, type_names_order, o2_molecules, o_pd_cutoff=2.5, o_au_cutoff=2.5):
    """
    识别输入帧中与Pd或Au配位的O2分子，返回与Pd/Au配位的O2数量、总O2分子数，以及与Pd/Au配位的O2分子详情列表。
    考虑了周期性边界条件。

    Args:
        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号
        
        o2_molecules (list): 所有O2分子列表，每个元素是一个元组，包含第一个O原子序号和第二个O原子序号
            (例如：[(o1_index1, o2_index1), (o1_index2, o2_index2), ...])
        
        o_pd_cutoff (float): O原子与Pd配位的距离阈值，单位为Å，默认为2.5 Å
        
        o_au_cutoff (float): O原子与Au配位的距离阈值，单位为Å，默认为2.5 Å

    Returns:
        tuple: O2分子信息
            o2_pdau_count (int): 与Pd或Au配位的O2分子数量
            
            total_o2 (int): 总O2分子数量
            
            o2_pdau_details (list): 与Pd或Au配位的O2分子详情列表，每个元素是一个字典，
                包含以下键：
                - 'o2' (tuple): O2分子的原子序号元组 (o1_index, o2_index)
                - 'o1_pd_neighbors' (list): 第一个O原子与Pd配位的邻居列表
                - 'o1_au_neighbors' (list): 第一个O原子与Au配位的邻居列表
                - 'o2_pd_neighbors' (list): 第二个O原子与Pd配位的邻居列表
                - 'o2_au_neighbors' (list): 第二个O原子与Au配位的邻居列表
    """
    particles = data.particles
    if particles is None or not o2_molecules:
        return 0, 0, []
    
    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    
    # 创建邻居查找器
    finder_o_pd = CutoffNeighborFinder(o_pd_cutoff, data)
    finder_o_au = CutoffNeighborFinder(o_au_cutoff, data)
    
    num_atoms = particles.count
    neighbors_o_pd = {i: [] for i in range(num_atoms)}
    neighbors_o_au = {i: [] for i in range(num_atoms)}
    
    # 生成邻居列表
    for i in range(num_atoms):
        # O原子与Pd的邻居列表
        for neighbor in finder_o_pd.find(i):
            neighbors_o_pd[i].append(neighbor.index)
        # O原子与Au的邻居列表
        for neighbor in finder_o_au.find(i):
            neighbors_o_au[i].append(neighbor.index)
    
    # 计算与Pd或Au配位的O2分子
    o2_pdau_count = 0
    o2_pdau_details = []
    
    for o1_index, o2_index in o2_molecules:
        # 检查第一个O原子是否与Pd或Au配位
        o1_coordinating_pds = []
        o1_coordinating_aus = []
        for neighbor_index in neighbors_o_pd[o1_index]:
            if symbols[neighbor_index] == 'Pd':
                o1_coordinating_pds.append(neighbor_index)
        for neighbor_index in neighbors_o_au[o1_index]:
            if symbols[neighbor_index] == 'Au':
                o1_coordinating_aus.append(neighbor_index)
        
        # 检查第二个O原子是否与Pd或Au配位
        o2_coordinating_pds = []
        o2_coordinating_aus = []
        for neighbor_index in neighbors_o_pd[o2_index]:
            if symbols[neighbor_index] == 'Pd':
                o2_coordinating_pds.append(neighbor_index)
        for neighbor_index in neighbors_o_au[o2_index]:
            if symbols[neighbor_index] == 'Au':
                o2_coordinating_aus.append(neighbor_index)
        
        # 如果O1或O2与Pd或Au配位，则计为与PdAu配位的O2分子
        if (o1_coordinating_pds or o2_coordinating_pds or 
            o1_coordinating_aus or o2_coordinating_aus):
            o2_pdau_count += 1
            o2_pdau_details.append({
                'o2': (o1_index, o2_index),
                'o1_pd_neighbors': o1_coordinating_pds,
                'o1_au_neighbors': o1_coordinating_aus,
                'o2_pd_neighbors': o2_coordinating_pds,
                'o2_au_neighbors': o2_coordinating_aus
            })
    
    total_o2 = len(o2_molecules)
    return o2_pdau_count, total_o2, o2_pdau_details