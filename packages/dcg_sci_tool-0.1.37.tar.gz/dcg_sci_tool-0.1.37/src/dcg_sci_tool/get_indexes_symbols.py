
from ovito.io import import_file
from dcg_sci_tool import extract_atom_types

def get_indexes_symbols(input_file,indexes):
    """
    获取指定索引的原子符号列表
    Args:
        input_file (str): 输入文件路径
        indexes (list): 原子索引列表
    Returns:
        symbols (list): 原子符号列表
    """
    pipeline = import_file(input_file)
    data = pipeline.compute(0)
    type_names_order = extract_atom_types(input_file)
    particle_types = data.particles.particle_types[...]
    symbols = [type_names_order[pt - 1] for pt in particle_types[indexes]]
    return symbols