from dcg_sci_tool import *
import numpy as np

def detect_gas_molecules_for_deletion(data, type_names_order):
    """
    识别需要删除的气态分子：所有CO2，气态O2（即未与Pd/Au配位的O2），气态CO（即未与Pd配位的CO，包括C/O配位）。
    返回需要删除的气态分子原子索引列表。

    Args:

        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号

    Returns:

        gas_atoms_to_delete (list): 需要删除的气态分子原子索引列表
            
    """
    particles = data.particles
    if particles is None:
        return []
    
    # 使用检测函数
    N_O2, O2_indices, o2_molecules = detect_O2_molecules(data, type_names_order)
    N_CO, N_CO2, CO_list, CO2_list, co_molecules, co2_molecules = detect_CO_CO2_molecules(data, type_names_order)
    N_single_O, single_O_indices = detect_single_adsorbed_O(data, type_names_order)
    co_pdau_count, total_co, co_pd_details = detect_CO_coordinating_to_PdAu(data, 
                                                                    type_names_order, 
                                                                    co_molecules,
                                                                    c_pd_cutoff=3.0, 
                                                                    o_pd_cutoff=2.5,
                                                                    )
    o2_pdau_count, total_o2, o2_pdau_details = detect_O2_coordinating_to_PdAu(data, 
                                                                    type_names_order, 
                                                                    o2_molecules,
                                                                    o_pd_cutoff=2.5,
                                                                    o_au_cutoff=2.5,
                                                                    )
    
    # 需要删除的气态分子原子索引
    gas_atoms_to_delete = set()
    
    # 1. 只删除未与Pd配位的O2分子（气态O2）
    adsorbed_O2_indexes = set()
    # gas_atoms_to_delete.update(O2_indices)
    for detail in o2_pdau_details:
        o1_idx, o2_idx = detail['o2']
        adsorbed_O2_indexes.update([o1_idx, o2_idx])
    
    # 删除未与Pd配位的O2分子（气态O2）
    for o_idx in O2_indices:
        if o_idx not in adsorbed_O2_indexes:  # 这是气态O2
            gas_atoms_to_delete.update([o_idx])
    
    # 2. 只删除未与Pd配位的CO分子（气态CO）
    # 找出所有与Pd配位的CO分子（吸附态CO，需要保留）
    adsorbed_CO_indexes = set()
    for detail in co_pd_details:
        c_idx, o_idx = detail['co']
        adsorbed_CO_indexes.update([c_idx, o_idx])
    
    # 删除未与Pd配位的CO分子（气态CO）
    for c_idx, o_idx in co_molecules:
        if c_idx not in adsorbed_CO_indexes:  # 这是气态CO
            gas_atoms_to_delete.update([c_idx, o_idx])
    
    # 3. 所有CO2分子都视为气态
    gas_atoms_to_delete.update(CO2_list)
    
    # 4. 保留所有单个吸附O原子
    # 5. 保留所有金属原子
    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    for i in range(particles.count):
        if symbols[i] in ['Pd', 'Au']:
            if i in gas_atoms_to_delete:
                gas_atoms_to_delete.remove(i)
    
    return list(gas_atoms_to_delete)