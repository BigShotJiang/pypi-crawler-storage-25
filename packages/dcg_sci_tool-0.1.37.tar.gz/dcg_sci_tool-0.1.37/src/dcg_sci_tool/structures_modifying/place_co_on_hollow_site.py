from ase import Atoms
import numpy as np
from dcg_sci_tool import get_pdau_cluster_center
from ovito.io import import_file
from dcg_sci_tool.extract_atom_types import extract_atom_types
from ase.io import read

def place_co_on_hollow_site(cluster_file, hollow_atom_indices):
    """
    在PdAu团簇的hollow位点上放置CO分子
    
    Args:
        cluster_file (str): PdAu团簇结构文件路径
        hollow_atom_indices (list): 构成hollow位点的三个原子序号列表 [atom1, atom2, atom3]
    """
    
    # 1. 读取团簇结构
    atoms = read(cluster_file)
    print(f"已读取团簇结构: {cluster_file}")
    print(f"总原子数: {len(atoms)}")
    print(f"Hollow位点原子序号: {hollow_atom_indices}")
    
    # 2. 计算团簇中心
    # 创建OVITO数据对象
    pipeline = import_file(cluster_file)
    data = pipeline.compute()
    
    # 获取原子类型顺序
    type_names_order = extract_atom_types(cluster_file)
    
    # 使用API函数计算团簇中心
    cluster_center = get_pdau_cluster_center(data, type_names_order)
    print(f"团簇中心坐标: {cluster_center}")
    
    # 3. 计算hollow位点的中心位置
    pos1 = atoms.positions[hollow_atom_indices[0]]
    pos2 = atoms.positions[hollow_atom_indices[1]]
    pos3 = atoms.positions[hollow_atom_indices[2]]
    
    # 计算三个原子的中心位置（hollow位点中心）
    hollow_center = (pos1 + pos2 + pos3) / 3.0
    print(f"Hollow位点中心坐标: {hollow_center}")
    
    # 4. 计算从团簇中心指向hollow中心的方向向量
    direction_vector =  hollow_center - cluster_center
    direction_norm = np.linalg.norm(direction_vector)
    
    if direction_norm < 1e-10:
        print("警告: Hollow位点中心与团簇中心几乎重合, 使用默认方向(0,0,1)")
        direction = np.array([0, 0, 1])
    else:
        direction = direction_vector / direction_norm
        print(f"方向向量: {direction}")
    
    # 5. 设置CO分子的键长和位置
    # CO键长: 约1.15 Å
    co_bond_length = 1.15
    
    # C-Pd/Au键长: 约2.0 Å
    c_metal_bond_length = 2.0
    
    # 计算C原子位置: 在hollow中心沿着方向向量向外移动c_metal_bond_length距离
    c_position = hollow_center + direction * c_metal_bond_length
    
    # 计算O原子位置: 在C原子位置基础上继续沿着方向向量移动CO键长
    o_position = c_position + direction * co_bond_length
    
    # 6. 创建CO分子
    co_atoms = Atoms('CO', positions=[c_position, o_position])
    
    # 7. 将CO分子添加到团簇中
    new_atoms = atoms + co_atoms
    
    
    # 9. 验证几何关系
    # 计算C原子到三个Pd/Au原子的距离
    for i, idx in enumerate(hollow_atom_indices):
        dist = np.linalg.norm(c_position - atoms.positions[idx])
        print(f"C原子到原子{idx}的距离: {dist:.3f} Å")
    
    # 计算C-O键长
    co_dist = np.linalg.norm(o_position - c_position)
    print(f"C-O键长: {co_dist:.3f} Å")
    
    # 验证三点共线
    # 计算从C到O的向量和从C到团簇中心的向量是否平行
    c_to_o = o_position - c_position
    c_to_center = cluster_center - c_position
    
    # 计算夹角
    dot_product = np.dot(c_to_o, c_to_center)
    norm_product = np.linalg.norm(c_to_o) * np.linalg.norm(c_to_center)
    
    if norm_product > 1e-10:
        cos_angle = dot_product / norm_product
        angle = np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))
        print(f"C-O向量与C-中心向量的夹角: {angle:.2f}度")
        
        if angle < 1.0:  # 夹角小于1度认为是共线
            print("✓ C、O和团簇中心基本在一条直线上")
        else:
            print(f"注意: C、O和团簇中心不在一条直线上")
    
    return new_atoms