from ase.io import read, write
from dcg_sci_tool.find_matching_files import find_matching_files
from dcg_sci_tool.structures_analysis.are_structures_same import are_structures_same
import os


def find_o2_dissociation_origin(frames_to_check):
    """
    用于查询ini.xyz中指定帧的结构是否与O2_dissociated_frame[0-9]+_O2_[0-9]+to[0-9]+_focused_colored.xyz中的某个结构相同，并输出匹配结果。
    Args:
        frames_to_check (list): 需要检查的 ini.xyz 集合中帧的索引列表。
    """

    structs = read("ini.xyz", index=":")
    search_files = find_matching_files(directory="./", pattern="O2_dissociated_frame[0-9]+_O2_[0-9]+to[0-9]+_focused_colored.xyz")

    for frame in frames_to_check:
        write('temp.xyz', structs[frame])
        for target_file in search_files:
            is_same = are_structures_same('temp.xyz', target_file)
            if is_same:
                print(f"{frame}-{target_file}")
                break
        os.remove('temp.xyz')
