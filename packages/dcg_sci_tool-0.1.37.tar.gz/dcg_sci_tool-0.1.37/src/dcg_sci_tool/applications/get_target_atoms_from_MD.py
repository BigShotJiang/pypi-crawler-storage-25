from ase import Atoms
from typing import List, Tuple
from dcg_sci_tool import *
from ase.io import read

def get_bonded_co_pairs(atom_indices: List[int],atoms: Atoms) -> List[Tuple[int, int]]:
    """
    内部函数：使用ASE库计算考虑PBC的成键C-O对
    
    Args:
        atom_indices: 包含3个原子索引的列表
        atoms: ASE Atoms对象，包含坐标、元素、晶胞和PBC信息
    
    Returns:
        成键的(C, O)原子对列表
    """

    bond_threshold = 1.5 # 成键阈值
    if len(atom_indices) != 3:
        raise ValueError(f"需要3个原子索引，但提供了{len(atom_indices)}个")
    
    # 获取元素符号
    symbols = atoms.get_chemical_symbols()
    
    # 分离C和O原子
    c_indices = []
    o_indices = []
    
    for idx in atom_indices:
        if symbols[idx] == 'C':
            c_indices.append(idx)
        elif symbols[idx] == 'O':
            o_indices.append(idx)
        else:
            raise ValueError(f"原子{idx}不是C或O元素")
    
    if len(c_indices) != 1 or len(o_indices) != 2:
        raise ValueError("需要1个C原子和2个O原子")
    
    c_idx = c_indices[0]
    
    result_indexes = []
    for o_idx in o_indices:
        # 使用ASE的get_distance方法，自动考虑PBC
        distance = atoms.get_distance(c_idx, o_idx, mic=True)  # mic=True表示最小镜像约定
        
        if distance <= bond_threshold:
            print(distance)
            result_indexes.append(c_idx)
            result_indexes.append(o_idx)
           
    return result_indexes

def get_target_atoms_from_MD(input_file: str, mode: str = 'oxidation'):
    """

    根据MD中截取的反应初态，找到指定的mode（氧化或离解）对应的目标原子序号；
    如果是氧化模式，则输出要耦合的C和O原子的序号
    如果是离解模式，则输出解离的两个原子的序号

    Args:
        input_file (str): MD中截取反应的轨迹地址
        mode (str): 模式，'oxidation'或'dissociation'，默认值为'oxidation'

    Returns:

        target_atoms (list): 目标原子（要耦合的C和O原子）的序号列表

    """
    if mode == 'oxidation':
        target_color = [0, 1, 1] # 兰色
    elif mode == 'dissociation':
        target_color = [1, 0, 1] # 洋红色
    else:
        raise ValueError(f"mode {mode} not supported")
    
    target_color_atom_list = get_atoms_with_specific_color(xyz_file=f"{input_file}", target_color=target_color)
    atoms = read(f"{input_file}", index = 0)
    target_atoms = []
    if mode == 'oxidation':
        bonded_c_o = get_bonded_co_pairs(target_color_atom_list, atoms)

        target_atoms.append(bonded_c_o[0])

        for i in target_color_atom_list:
            if i not in bonded_c_o:
                target_atoms.append(i)
                break
        print(f"兰色原子序号列表：{target_atoms}")
    elif mode == 'dissociation':
        target_atoms =  target_color_atom_list.copy()
        print(f"洋红色原子序号列表：{target_atoms}")
    return target_atoms