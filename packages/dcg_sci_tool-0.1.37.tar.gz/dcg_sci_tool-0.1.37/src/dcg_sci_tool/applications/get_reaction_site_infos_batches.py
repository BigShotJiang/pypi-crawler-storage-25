from dcg_sci_tool import *
from ovito.data import *
from dcg_sci_tool.reaction.get_reaction_site_infos import get_reaction_site_infos
import csv  # 导入csv模块
import pandas as pd  # 导入pandas模块
import os  # 导入os模块

def get_reaction_site_infos_batches():
    """
    批量获取neb轨迹初始帧的反应位点的结构信息，并将结果保存到csv文件中
    """

    if os.path.exists("reaction_site_infos.csv"):
        os.remove("reaction_site_infos.csv")

    if os.path.exists("reaction_site_infos.xlsx"):
        os.remove("reaction_site_infos.xlsx")

    pattern = "[0-9]+-[0-9]+_-?[0-9]\.[0-9]+_-?[0-9]\.[0-9]+_[0-9]+_[0-9]+_focused\.xyz"
    target_files = find_matching_files("./", pattern)
    print("Found files:", target_files)

    # 使用csv模块写入CSV文件
    with open("reaction_site_infos.csv", "w", newline='', encoding='utf-8') as csvfile:
        # 创建csv写入器
        csv_writer = csv.writer(csvfile)

        # 写入表头
        csv_writer.writerow(["File", "N_hollow_sites", "N_hollow_sites_Au_atoms", "N_surface_neighbors", "N_surface_Au_neighbors", "N_subsurface_neighbors", "N_subsurface_Au_neighbors", "Au_Disperation", "Barrier"])

        for file in target_files:
            print(f"开始处理文件: {file}")
            N_hollow_sites, N_hollow_sites_Au_atoms, N_surface_neighbors,N_surface_Au_neighbors,N_subsurface_neighbors, N_subsurface_Au_neighbors, Au_Disperation, Barrier = get_reaction_site_infos(file)
    
            # 将数据写入CSV文件
            csv_writer.writerow([
                file, 
                N_hollow_sites, 
                N_hollow_sites_Au_atoms, 
                N_surface_neighbors, 
                N_surface_Au_neighbors, 
                N_subsurface_neighbors, 
                N_subsurface_Au_neighbors, 
                Au_Disperation,
                Barrier
            ])
            # 同时在控制台输出（可选）
            print(f"{file}\t{N_hollow_sites}\t{N_hollow_sites_Au_atoms}\t{N_surface_neighbors}\t{N_surface_Au_neighbors}\t{N_subsurface_neighbors}\t{N_subsurface_Au_neighbors}\t{Au_Disperation}\t{Barrier}")

    print(f"数据已保存到 reaction_sites_infos.csv")
    df = pd.read_csv('reaction_site_infos.csv')
    df.to_excel('reaction_site_infos.xlsx', index=False)
