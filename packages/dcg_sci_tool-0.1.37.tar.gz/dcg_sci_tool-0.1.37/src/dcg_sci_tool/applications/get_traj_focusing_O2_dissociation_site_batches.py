from dcg_sci_tool.find_matching_files import find_matching_files
from dcg_sci_tool.get_atoms_with_specific_color import get_atoms_with_specific_color
from dcg_sci_tool.structures_modifying.get_traj_focusing_local2atoms import get_traj_focusing_local2atoms
from ase.io import write
from dcg_sci_tool.structures_analysis.paint_atoms import color_atoms_in_trajectory
import os



def get_traj_focusing_O2_dissociation_site_batches():
    """
    批量处理当下目录下从MD轨迹文件中提取的O2 dissociation 事件轨迹，聚焦O2 dissociation site的局部结构，并对裂解的O2染色
    """
    # 初始化错误日志列表
    error_messages = []

    files = find_matching_files(directory='./', pattern='O2_dissociated_frame[0-9]+_O2_[0-9]+to[0-9]+.xyz')
    for file in files:
        try:
            target_atoms = get_atoms_with_specific_color(file, target_color=[1,0,1])
            focused_traj, new_indexes = get_traj_focusing_local2atoms(file, atom1_index=target_atoms[0], atom2_index=target_atoms[1],target_vector=[0, -1, 0], new_cell=[20,20,20])
            focused_file = file.replace(".xyz", "_focused.xyz")
            write(focused_file, focused_traj)
            color_atoms_in_trajectory(focused_file, atom_indices=new_indexes, rgb_color=[1,0,1])
            os.remove(focused_file)
        except Exception as e:
            print(f"ERROR: {file}: {e}")
            error_messages.append(f"{file}: {e}")
    print(error_messages)
    if error_messages:
        try:
            with open('error.log', 'w') as f:
                for msg in error_messages:
                    f.write(msg + "\n")
            print(f"错误已写入 error.log")
        except Exception as e:
            print(f"写入错误日志失败: {e}")