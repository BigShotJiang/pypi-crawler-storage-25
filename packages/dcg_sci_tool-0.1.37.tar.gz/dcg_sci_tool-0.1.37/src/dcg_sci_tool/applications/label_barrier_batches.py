from dcg_sci_tool import *
from ovito.data import *
import os
from dcg_sci_tool.append_key_value_pairs_to_extxyz import append_key_value_pairs_to_extxyz
from dcg_sci_tool.reaction.parse_nebTraj_file_name import parse_nebTraj_file_name

def label_barrier_batches():
    """
    给所有的.xyz格式的neb轨迹文件添加上能垒注释
    """
    pattern = "[0-9]+-[0-9]+_-?[0-9].[0-9]+_-?[0-9].[0-9]+_[0-9]+_[0-9]+_focused.xyz"
    target_files = find_matching_files("./", pattern)
    print("Found files:", target_files)
    for file in target_files:
        _, Ea, _, _, _ = parse_nebTraj_file_name(file)
        append_key_value_pairs_to_extxyz(file, [("energy barrier", str(Ea))],  os.path.splitext(file)[0]+"_labelled.xyz")
        
