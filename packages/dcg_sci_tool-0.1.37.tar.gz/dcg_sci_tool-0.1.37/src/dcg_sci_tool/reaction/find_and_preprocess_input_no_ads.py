
from dcg_sci_tool.reaction.neb_post_process import *
from ase.io import write
import os


def find_and_preprocess_input_no_ads():
    """
    对于计算没有其他吸附物存在时，在自动截取MD轨迹的算能垒的自动化流程中，查找并预处理输入文件
    包括查找neb优化轨迹文件，删除反应中心附近一定范围内的吸附物，保存清理后的结构轨迹文件，获取CO2生成的序号
    Returns:
        tuple:
        no_pre_ads_atoms: 清理反应中心附近吸附物后的结构原子对象

        target_atom_list: 目标原子列表

        neb_traj_file: neb 优化轨迹文件路径
        
        co2_indexes: CO2生成的序号列表
    """
    neb_traj_files = find_matching_files(".", r'^[0-9]+-[0-9]+_[0-9]\.[0-9]+_-?[0-9]\.[0-9]+_[0-9]+_[0-9]+\.xyz$')
    if not neb_traj_files:
        raise FileNotFoundError("未找到符合模式 r'^[0-9]+-[0-9]+_[0-9]\.[0-9]+_-?[0-9]\.[0-9]+_[0-9]+_[0-9]+\.xyz$' 的 neb 优化轨迹文件")
    
    neb_traj_file = neb_traj_files[0]
    print(f"找到 neb 优化后的轨迹文件: {neb_traj_file}")
    
    # 获取CO2生成的序号
    co2_indexes, _, _, c_idx, o_idx = parse_nebTraj_file_name(neb_traj_file)
    
    os.rename(neb_traj_file, "original_neb_traj.xyz")
    neb_traj_file = "original_neb_traj.xyz"


    # 预处理：删除气体原子
    cleaned_atoms, target_atom_list = pre_del_gases(
        input_file=neb_traj_file,
        old_indexes_to_transfer=[c_idx, o_idx]
    )

    write("cleaned_neb_traj.xyz", images=cleaned_atoms, format="extxyz")
    print(f"已保存去除气体原子后的结构到: cleaned_neb_traj.xyz")

    # 预处理：删除反应中心附近一定范围内的吸附物
    no_pre_ads_atoms, target_atom_list = pre_del_ads(
        input_file="cleaned_neb_traj.xyz",
        c_idx=target_atom_list[0],
        o_idx=target_atom_list[1],
        cutoff=6.0
    )
    
    # 保存清理后的结构
    write("preprocessed.xyz", images=no_pre_ads_atoms, format="extxyz")
    print(f"已保存去除预吸附的结构到: preprocessed.xyz")
    print(f"目标原子列表: {target_atom_list}")
    
    return no_pre_ads_atoms, target_atom_list, neb_traj_file, co2_indexes