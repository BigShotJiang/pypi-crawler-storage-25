from ovito.data import DataCollection
import numpy as np
from dcg_sci_tool import *
from typing import List

def get_hollowSite_outer_surface_neighbors(data: DataCollection, type_names_order: list, hollow_site_atom_indexes: list) -> List[int]:
    """
    获取hollow位点外围表面邻居原子
    
    Args:
        data (DataCollection): 结构的ovito数据集合
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号
        hollow_site_atom_indexes (list): hollow位点原git 子索引列表
    Returns:
        surface_neighbors (list): hollow位点外围表面邻居原子索引列表
    
    
    """

    surface_neighbor_cutoff = 4.0       # 表面原子邻居截断半径(Å)
    positions = data.particles.positions[...]

    # 获取所有表面原子
    surface_pdau_atoms = get_pdau_surface_atoms(data, type_names_order)
    
    all_neighbors = set()

    # 为每个Hollow位原子获取邻居（只考虑表面原子）
    for atom_idx in hollow_site_atom_indexes:
        for neighbor_idx in surface_pdau_atoms:
            if neighbor_idx in hollow_site_atom_indexes:
                continue
                
            pos1 = positions[atom_idx]
            pos2 = positions[neighbor_idx]
            distance = np.linalg.norm(pos1 - pos2)
            
            if distance <= surface_neighbor_cutoff:
                all_neighbors.add(neighbor_idx)
    
    # 转换为列表并限制最多9个最近的表面邻居原子
    neighbors_list = list(all_neighbors)
    if len(neighbors_list) > 9:
        # 按距离排序，取最近的9个
        distances = []
        for neighbor_idx in neighbors_list:
            min_distance = float('inf')
            for triangle_idx in hollow_site_atom_indexes:
                dist = np.linalg.norm(positions[neighbor_idx] - positions[triangle_idx])
                if dist < min_distance:
                    min_distance = dist
            distances.append((neighbor_idx, min_distance))
        
        distances.sort(key=lambda x: x[1])
        neighbors_list = [idx for idx, dist in distances[:9]]
    
    # 验证所有邻居原子都是表面原子
    surface_neighbors = []
    for neighbor_idx in neighbors_list:
        if neighbor_idx in surface_pdau_atoms:
            surface_neighbors.append(neighbor_idx)
        else:
            print(f"警告: 原子 {neighbor_idx} 被识别为邻居但不是表面原子，已过滤")
    
    return surface_neighbors


def get_hollowSite_outer_neighbors_with_subsurface(data: DataCollection, type_names_order: list, hollow_site_atom_indexes: list) -> List[int]:
    """
    获取hollow位点外围邻居原子，包括次表层原子。
    
    Args:
        data (DataCollection): 结构的ovito数据集合
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号
        hollow_site_atom_indexes (list): hollow位点原子索引列表
    Returns:
        surface_neighbors (list): hollow位点外围表面邻居原子索引列表
    
    
    """

    neighbor_cutoff = 3.5

    particles = data.particles
    positions = particles.positions[...]
    types = particles.particle_types[...] # 序号从1开始

    all_neighbors = set()

    # 为每个Hollow位原子获取邻居（考虑次表层原子）
    for atom_idx in hollow_site_atom_indexes:
        for neighbor_idx in range(len(positions)):
            if neighbor_idx in hollow_site_atom_indexes:
                continue
            if type_names_order[types[neighbor_idx] - 1] not in ['Pd', 'Au']:
                continue
            
            pos1 = positions[atom_idx]
            pos2 = positions[neighbor_idx]
            distance = np.linalg.norm(pos1 - pos2)
            
            if distance <= neighbor_cutoff:
                all_neighbors.add(neighbor_idx)

    neighbors_list = list(all_neighbors)
     
    return neighbors_list

def get_hollowSite_subsurface_neighbors(data: DataCollection, type_names_order: list, hollow_site_atom_indexes: list) -> List[int]:
    """
    获取hollow位点次表层原子
    
    Args:
        data (DataCollection): 结构的ovito数据集合
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号
        hollow_site_atom_indexes (list): hollow位点原子索引列表
    Returns:
        subsurface_neighbors (list): hollow位点次表层原子索引列表
    
    
    """
    total_neighbors = get_hollowSite_outer_neighbors_with_subsurface(data, type_names_order, hollow_site_atom_indexes)
    surface_neighbors = get_hollowSite_outer_surface_neighbors(data, type_names_order, hollow_site_atom_indexes)
    subsurface_neighbors = [idx for idx in total_neighbors if idx not in surface_neighbors]
    return subsurface_neighbors