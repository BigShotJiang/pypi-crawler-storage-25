from dcg_sci_tool.reaction.run_initial_state_minimization import run_initial_state_minimization
from dcg_sci_tool.reaction.find_and_preprocess_input import find_and_preprocess_input
from dcg_sci_tool.structures_modifying.get_traj_focusing_local2atoms import get_traj_focusing_local2atoms
from ase.io import write
from dcg_sci_tool.structures_analysis.paint_atoms import color_atoms_in_trajectory
import os

def onekey_run_dissociation_IS_min():
    """
    运行O2离解的初态结构优化
    """
    cleaned_atoms, target_atom_list, md_snapshot_file, o2_indexes = find_and_preprocess_input(mode='dissociation')
    minimized_is_path = run_initial_state_minimization()
    print(f"minimized_is_path值：{minimized_is_path}")
    focused_traj, new_indexes = get_traj_focusing_local2atoms(minimized_is_path, atom1_index=target_atom_list[0], atom2_index=target_atom_list[1],target_vector=[0, -1, 0], new_cell=[20,20,20])
    focused_file = md_snapshot_file.replace(".xyz", "_focused.xyz")
    write(focused_file, focused_traj)
    color_atoms_in_trajectory(focused_file, atom_indices=new_indexes, rgb_color=[1,0,1])
    os.remove(focused_file)