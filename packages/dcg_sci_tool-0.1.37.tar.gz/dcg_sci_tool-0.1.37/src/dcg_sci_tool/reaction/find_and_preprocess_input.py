from dcg_sci_tool.reaction.neb_post_process import *
from ase.io import write
from dcg_sci_tool.applications.get_target_atoms_from_MD import get_target_atoms_from_MD
from dcg_sci_tool.structures_modifying.pre_del_gases import pre_del_gases
from dcg_sci_tool.find_matching_files import find_matching_files


def find_and_preprocess_input(mode: str = 'oxidation'):
    """
    自动截取MD轨迹，查找并预处理输入文件
    
    Args:
        mode (str): 反应模式，'oxidation'或'dissociation'
    
    Returns:
        cleaned_atoms (ase.Atoms): 清理气体分子后的原子结构
        target_atom_list (list): 预处理后的目标原子列表
        md_snapshot_file (str): MD 快照文件路径
        molecule_indexes (list): CO2生成或O2离解的序号列表（非原子序号）
    """
    if mode == 'oxidation':
        md_files = find_matching_files(".", r'^CO2_formation_frame.*\.xyz$')
        if not md_files:
            raise FileNotFoundError("未找到符合模式 'CO2_formation_frame*.xyz' 的 MD 快照文件")
    elif mode == 'dissociation':
        md_files = find_matching_files(".", r'^O2_dissociated_frame.*\.xyz$')
        if not md_files:
            raise FileNotFoundError("未找到符合模式 'O2_dissociated_frame*.xyz' 的 MD 快照文件")
    
    md_snapshot_file = md_files[0]
    
    # 获取CO2生成或O2离解的序号
    molecule_indexes = md_snapshot_file.split('.')[0].split('_')[4].split('to')
    print(f"找到 MD 快照文件: {md_snapshot_file}")
    
    # 获取目标原子列表
    print("获取目标原子列表...")
    old_target_atom_list = get_target_atoms_from_MD(input_file=md_snapshot_file, mode=mode)
    
    # 预处理：删除气体原子
    cleaned_atoms, target_atom_list = pre_del_gases(
        input_file=md_snapshot_file,
        old_indexes_to_transfer=old_target_atom_list
    )
    
    # 保存清理后的结构
    write("preprocessed.xyz", images=cleaned_atoms, format="extxyz")
    print(f"已保存清理后的结构到: preprocessed.xyz")
    print(f"目标原子列表: {target_atom_list}")
    
    return cleaned_atoms, target_atom_list, md_snapshot_file, molecule_indexes