import os
from typing import List, Tuple

def append_key_value_pairs_to_extxyz(
    input_file: str, 
    key_value_pairs: List[Tuple[str, str]],
    output_file: str
) -> str:
    """
    在.extxyz格式轨迹文件的每一帧注释行追加键值对
    
    Args:

        input_file (str):
            输入的.extxyz格式轨迹文件路径
        key_value_pairs (List[Tuple[str, str]]):
            要追加的键值对列表，每个元组格式为(键, 值)
        output_file (str, optional):
            输出文件路径，如果为None则自动生成
        
    Returns:
        output_file (str):
            输出文件路径
    """
    
    # 如果没有指定输出文件，自动生成
    if output_file is None:
        base, ext = os.path.splitext(input_file)
        output_file = f"{base}_modified{ext}"
    
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        while True:
            # 读取第一行：原子数量
            atoms_line = infile.readline()
            if not atoms_line:  # 文件结束
                break
            
            # 写入原子数量行
            outfile.write(atoms_line)
            
            # 读取第二行：注释行（包含键值对）
            comment_line = infile.readline()
            if not comment_line:
                break
            
            # 移除行尾换行符
            comment_line = comment_line.rstrip('\n')
            
            # 在注释行末尾追加键值对
            if comment_line.strip():  # 如果注释行非空
                # 如果注释行不是以空格结尾，添加一个空格
                if comment_line and not comment_line.endswith(' '):
                    comment_line += ' '
            else:
                # 如果注释行为空，从第一个键值对开始
                comment_line = ''
            
            # 添加键值对
            for key, value in key_value_pairs:
                comment_line += f'{key}={value} '
            
            # 移除最后一个多余的空格并添加换行符
            comment_line = comment_line.rstrip() + '\n'
            
            # 写入修改后的注释行
            outfile.write(comment_line)
            
            # 获取原子数量
            try:
                num_atoms = int(atoms_line.strip())
            except ValueError:
                raise ValueError(f"无法解析原子数量: {atoms_line.strip()}")
            
            # 读取并写入原子坐标行
            for _ in range(num_atoms):
                atom_line = infile.readline()
                if not atom_line:
                    raise ValueError("文件格式错误：原子坐标行数量不足")
                outfile.write(atom_line)
    
    print(f"处理完成！输出文件: {output_file}")
    return output_file