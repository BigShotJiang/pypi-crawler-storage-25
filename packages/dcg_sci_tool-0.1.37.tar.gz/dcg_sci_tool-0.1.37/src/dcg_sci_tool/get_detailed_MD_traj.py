import os, tarfile, sys
from dcg_sci_tool.structures_analysis.paint_atoms import color_atoms_in_trajectory
from dcg_sci_tool.fast_extract_frames import fast_extract_frames

def get_detailed_MD_traj(frame_index_in_4w: int, atom_indexes: list):
    """
    从MD轨迹文件中提取详细信息，包括指定原子的轨迹文件, 并生成指定原子上色后的轨迹文件
    Args:
        frame_index_in_4w (int): 在合并的dump_locate.xyz轨迹中的帧索引，在0-39999之间
        atom_indexes (list): 要上色的原子索引列表
    """
    len_dump_locate_xyz= 400
    part_index = int(frame_index_in_4w/len_dump_locate_xyz) + 1
    frame_index = (frame_index_in_4w % len_dump_locate_xyz) * 50
    start_frame = frame_index - 250
    if start_frame < 0: start_frame = 0
    end_frame = frame_index + 250
    if end_frame > 39999: end_frame = 39999
    if os.path.exists("dump.xyz"): os.remove("dump.xyz")
    with tarfile.open(f"dump{part_index}.xyz.tgz", "r:gz") as tar: tar.extractall()
    fast_extract_frames(f"dump.xyz", 
                        f"dump{start_frame}-{end_frame}.xyz", 
                        start_frame, 
                        end_frame)

    color_atoms_in_trajectory(f"dump{start_frame}-{end_frame}.xyz", 
                              [0.0, 1.0, 1.0], 
                              atom_indexes, 
                              output_file=f"dump{start_frame}-{end_frame}_colored.xyz")
    os.remove(f"dump{start_frame}-{end_frame}.xyz")
    os.remove("dump.xyz")
    print(f"已生成 {f'dump{start_frame}-{end_frame}_colored.xyz'} 文件")    

    

   
   