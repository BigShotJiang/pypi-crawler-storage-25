# Changelog

## [0.1.37] - 2026-04-14
### Added
- 新增 `are_structures_same` 方法，用于判断两个结构文件是否相同，原子顺序可以不同
- 新增 `onekey_run_dissociation_IS_min` 方法，用于运行O2离解的初态结构优化
- 新增 `sub_min_batches` 方法，用于批量处理O2离解的初态结构优化



### Fixed
- 修复 `get_traj_focusing_O2_dissociation_site_batches` 方法中无法生成错误日志的问题
- 重构 `find_and_preprocess_input` 方法，添加 `mode` 参数，用于指定处理类型
- 修改 `onekey_run_neb_normal` 方法，添加 `mode` 参数，用于指定处理类型
- 修改 `onekey_run_neb_zbl` 方法，添加 `mode` 参数，用于指定处理类型


## [0.1.36] - 2026-04-13
### Added
- 新增 `plot_frequency_histogram` 方法，用于绘制频率直方图
- 新增 `get_traj_focusing_O2_dissociation_site_batches` 方法，用于批量处理O2 dissociation 事件轨迹，聚焦O2 dissociation site的局部结构，并对裂解的O2染色

### Changed
- 将 `get_traj_focusing_reaction_site` 方法重命名为 `get_traj_focusing_local2atoms` 
- 将 `get_traj_focusing_reaction_site_batches` 方法重命名为 `get_traj_focusing_oxidation_site_batches` 

## [0.1.35] - 2026-04-08
### Added
- 新增 `get_pd3_hollow_sites` 方法，用于获取团簇表面Pd3位点原子序号
- 新增 `place_co_on_hollow_site` 方法，用于将CO2分子放置团簇团簇表面Pd3位点

### Changed
- API文档去除了源代码，方便大模型读取

## [0.1.34] - 2026-04-07
### Added
- 新增 `csv2xyz` 方法
- 新增 `float_to_viridis_rgb` 方法
- 新增 `scatter_xyz` 方法

## [0.1.33] - 2026-04-05
### Added
- 新增 `get_reaction_site_infos_batches` 方法，用于批量获取neb轨迹初始帧的反应位点的结构信息
- 新增 `cli`命令 `get_reaction_site_infos_batches`
- 新增 `cli`命令 `label_barrier_batches`
- 新增 `label_barrier_batches` 方法，用于批量给neb轨迹文件添加能垒注释
- 新增 `append_key_value_pairs_to_extxyz` 方法，用于给xyz文件添加键值对注释


### Fixed
- 调整 `get_reaction_site_infos` 方法，使能够返回Barrier值
- 在 `get_reaction_site_infos_batches` 方法和 `get_reactants_ad_config_batches` 方法添加将.csv文件转换为.xlsx文件的功能，同时初始执行时检查是否存在.csv和.xlsx文件

## [0.1.32] - 2026-04-04
### Added
- 新增 `get_indexes_symbols` 方法，用于获取指定索引的原子符号列表
- 新增 `get_hollowSite_subsurface_neighbors` 方法，用于获取反应中心的次表面原子索引列表
- 新增 `get_reaction_site_infos` 方法，用于获取反应中心的结构信息
### Fixed
- 调整 `get_OC_bonded_metal_atoms` 方法，使O与Pd/Au成键的默认键长值都为2.5 Å

## [0.1.31] - 2026-04-04
### Fixed
- 调整 `get_reactants_ad_config` 方法和 `get_reactants_ad_config_batches` 方法中的O与Pd/Au成键的默认键长值，使所有值都为2.5 Å

## [0.1.30] - 2026-04-03
### Added
- 新增 `csv_to_tuples` 方法，用于将CSV文件转换为元组列表
- 新增 `averaging_count_matches` 方法，用于统计list_src中元组的指定元素在list_target中的出现次数，并计算其他元素的平均值
- 新增 `plot_categorical_heatmap` 方法，用于绘制分类热力图


## [0.1.29] - 2026-04-03
### Added
- 新增 `neb_post_process` 方法，用于后处理neb轨迹文件
- 新增 `cli`命令 `neb_post_process`
- 新增 `cli`命令 `collect_pattern_files`
- 新增 `cli`命令 `get_detailed_MD_traj`命令 `get_detailed_MD_traj`
- 新增 `detect_O2_coordinating_to_PdAu` 方法，用于识别O2配位到Pd/Au的原子索引
- 新增 `cli`命令 `get_reactants_ad_config_batches`
- 新增 `get_unique_values_csv` 方法，用于获取CSV文件中指定列的唯一值列表

### Fixed
- 更新 `sub_neb_batches` 方法中的复制文件列表
- 修改 `collect_pattern_files_command` 方法，使能够指定文件模式和目标目录
- 修改 `find_and_preprocess_input_no_ads` 方法，使能够自动重命名neb轨迹文件为 `original_neb_traj.xyz`
- 修改 `detect_gas_molecules_for_deletion` 方法，使对于O2，只删除未配位到Pd/Au的O2分子
- 修改 `get_detailed_MD_traj` 方法，使当start_frame为负数时，自动调整为0，当end_frame为39999时，自动调整为39999
- 修改 `find_and_preprocess_input_no_ads` 方法，使能够处理气体原子还没有除去的neb轨迹文件



## [0.1.28] - 2026-03-28
### Added
- 增加包的 `banner` 界面

### Fixed
- 修改`cli.py`，使命令行可以接收多个参数



## [0.1.27] - 2026-03-27
### Added
- 新增 `cli`命令 `merge_xyz`
- 新增 `cli`命令 `manual_name_xyz_png_at_nebdir`



## [0.1.26] - 2026-03-27
### Added
- 新增 `manual_name_xyz_png_at_nebdir` 方法
- 新增 `get_Ea_dH_from_file` 方法
- 新增 `get_target_atoms_from_file` 方法
- 新增 `get_detailed_MD_traj` 方法
- 新增 `fast_extract_frames` 方法
- 新增 `getEachfromXYZ` 方法

### Fixed
- 使 `neb_post_process` 模块中相关函数能够获得neb是否收敛的信息，
并相应调整`run_no_ads_neb_from_opted_neb` 和 
`run_neb_from_MD_snapshot` 函数，使能够输出neb收敛信息到日志
- 补充 `get_detailed_MD_traj` 方法中输出的轨迹的后缀名，并自动删除不必要的文件
- `get_detailed_MD_traj` 方法中part_index 正确赋值
- `get_target_atoms_from_MD` 方法中，输出兰色原子序号列表
- `auto_neb_refine` 方法添加新参数 `lammps_in_file`，用于指定LAMMPS输入文件地址

### Changed
- 重大重构，剥离出 `construct_final_state`, `find_and_preprocess_input_no_ads`, `find_and_preprocess_input`, `run_each_neb_calculation`, `run_initial_state_minimization`, `run_neb_calculation_normal`, `run_neb_calculation_zbl`, `onekey_run_neb_normal`, `onekey_run_neb_zbl` 方法


### Deprecated
- 废弃 `manual_name_xyz_png` 方法 


## [0.1.25] - 2026-03-23
### Added
- 新增 `collect_pattern_files` 方法

### Fixed
- 修改 `sub_neb_batches.py` 方法，使可以选择性地进行有无吸附物时的neb计算

## [0.1.24] - 2026-03-22
### Added
- 新增 `pre_del_ads` 方法
- 新增 `run_no_ads_neb_from_opted_neb` 方法

### Fixed
- 修改 `find_matching_files` 方法，只是用更严谨的正则表达式，不适用Shell通配符
- 修改 `run_neb_from_MD_snapshot` 和 `run_no_ads_neb_from_opted_neb` 中的相应方法，使用正则表达式匹配文件
- 修改 `parse_nebTraj_file_name` 方法，使能返回生成的CO2历史序号，并修改相应的调用函数
- 修改 `run_no_ads_neb_from_opted_neb` 方法，使能够在生成的neb轨迹中命名CO2生成的历史序号
- 修改 `run_neb_from_MD_snapshot` 和 `run_no_ads_neb_from_opted_neb` 中的第一次neb即单峰时，final_neb_dir变量的值，使包含主目录


## [0.1.23] - 2026-03-22
### Added
- 新增 `ovito2atoms` 方法
- 新增 `detect_nearby_ads_for_deletion` 方法
- 新增 `_get_version` 方法，自动通过pyproject.toml文件获取版本号

### Fixed
- 修改 `run_neb_from_MD_snapshot` 方法中的import命令，使相关函数能明确指出
- 修改 `run_neb_from_MD_snapshot` 方法中的复制函数相关语句，保证路径正确
- 修改 `plot_neb_graph` 方法，使返回能垒和焓变元组
- 剥离 `auto_neb_refine` 方法中的判断初始neb是否单峰的功能
- 修改 `run_neb_calculation` 方法，使能够自动命名最后的neb轨迹文件和能量图

## [0.1.22] - 2026-03-21
### Added
- 新增 `ovito2atoms` 方法
- 新增 `detect_nearby_ads_for_deletion` 方法


## [0.1.22.beta7] - 2026-03-19
### Added
- 新增 `atoms2lmps_resultData` 方法
- 新增 `neb_post_process` 模块
- 新增 `plot_basic_graph` 方法
- 新增 `auto_neb_refine` 方法

### Fixed
- 修改 `plot_basic_graph` 方法，使读取neb_mep数据文件时，可跳过注释行
- 修改 `plot_neb_graph` 方法，使读取neb_mep数据文件时，可跳过注释行
- 在__init__.py中开放 `auto_neb_refine` 接口
- `auto_neb_refine`补充上一轮地址的更新

## [0.1.21] - 2026-03-19
### Fixed
- 修改 `resultData2extxyz` 方法，保留原子排序信息

## [0.1.20] - 2026-03-19
### Fixed
- 修改 `construct_CO2_formation_FS` 方法


## [0.1.19] - 2026-03-19
### Fixed
- 修改 `find_matching_files` 方法，使能够适应shell的通配符

## [0.1.18.beta2] - 2026-03-19
### Added
- 新增 `mpirun_lammps` 方法

## [0.1.17] - 2026-03-18
### Fixed
- 修复 `get_target_atoms_from_MD` 方法

## [0.1.16] - 2026-03-18
### Added
- 新增 `get_atoms_with_specific_color` 方法
- 新增 `get_target_atoms_from_MD` 方法

### Changed
- `construct_CO2_formation_FS` 方法中atoms = read(input_file)改为atoms = read(input_file, index = 0)

## [0.1.15] - 2026-03-18
### Added
- 新增 `get_local_minima_sides_of_peak` 方法
- 新增 `resultData2extxyz` 方法
- 新增 `traj2iniData` 方法

### Changed
- `construct_CO2_formation_FS` 方法中min_to_pdau_distance初始值改为float('inf')
- specific文件夹改为applications



## [0.1.14] - 2026-03-18
### Added

- 新增 `find_elements_exclusively_frames` 方法
- 新增 `mark_special_points` 方法
- 新增 `split_xyz_by_elements` 方法
- 新增 `get_xyz_prop_columns` 方法
- 新增 `pre_del_gases` 方法
- 新增 `construct_CO2_formation_FS` 方法

### Changed

- `plot_scatter_color` 方法中添加`mark_special_points`功能
- `create_filtered_structure` 方法中保留原始晶胞信息
- `extract_atom_types` 方法添加自动确定.xyz文件中元素信息所在的列功能


## [0.1.13] - 2026-03-16
### Added

- 新增 `add_config_to_xyz` 方法
- 新增 `plot_scatter_color` 方法

## [0.1.12] - 2026-03-13

### Added

- 新增 `get_hollowSite_outer_neighbors_with_subsurface` 方法
- 新增 `get_hollowSite_Au_Disperation` 方法
- 新增 `find_cluster_surface_hollow_sites` 方法

### Changed

- 文件目录结构重整
- 增加`get_pdau_surface_atoms.py`中的相关注释，提示对于高度标准的`PdAu`团簇，需要改变相关入参值

## [0.1.11] - 2026-03-10

### Added

- 新增 `get_reactants_ad_config_batches` 方法
- 新增 `get_pdau_surface_atoms` 方法
- 新增 `get_OC_bonded_metal_atoms` 方法
- 新增 `find_nearest_hollow_site` 方法
- 新增 `get_outer_surface_neighbors` 方法

### Changed

- 调整 `specific` 目录下的脚本
- 修改 `indexes2expression` 方法

## [0.1.10] - 2026-03-04

### Added

- 新增 `get_reactants_ad_config` 方法

### Changed

- 修改 `detect_CO_coordinating_to_Pd` 函数，使之同时分析与Au配位的CO分子，并更名为 `detect_CO_coordinating_to_PdAu`
- 修改 `create_filtered_structure` 函数，使入参包含 `old_indexes` ：要获得新序号的原始结构中原子的索引的列表，返回参数包含 `new_indexes` ：旧索引 `old_indexes` 对应的新的原子索引列表，并修改调用函数 `get_traj_focusing_reaction_site` 和 `get_traj_focusing_reaction_site_batches`

## [0.1.9] - 2026-03-02

### Added

- 新增 `get_traj_focusing_reaction_site` 方法
- 新增 `parse_nebTraj_file_name` 方法
- 新增 `find_matching_files` 方法
- 新增 `get_traj_focusing_reaction_site_batches` 方法

### Changed

- 调整 `create_filtered_structure` 方法参数列表排序
- 建立 `specific` 文件夹，用于存放粒度较大的代码，并相应调整 `init.py` 文件
- `init.py` 文件格式规范化

## [0.1.8] - 2026-03-02

### Added

- 新增 `get_pdau_cluster_center` 方法
- 新增 `indexes2expression` 方法
- 新增 `rotate_v1_around_p_to_v2` 方法
- 新增 `translate_structure_center` 方法
- 新增 `create_filtered_structure` 方法
- 新增 `get_struct_focusing_reaction_site` 方法

### Changed

- 将 `get_reaction_local_structure` 改名为 `get_reaction_local_atoms_list`
- 将 `identify_gas_molecules_to_delete` 函数改名为 `detect_gas_molecules_for_deletion`
- 将API html、deprecated文件夹（放一些可能有用的代码）放至 `.gitignore` 文件中

## [0.1.7] - 2026-03-01

### Added

- 新增 `identify_gas_molecules_to_delete` 方法
- 新增 `get_reaction_local_structure` 方法

### Changed

- 规范化各个库函数的解释文本

## [0.1.6] - 2026-03-01

### Added

- 新增 `detect_single_adsorbed_O` 方法

## [0.1.5] - 2026-02-28

### Added

- 新增 `detect_CO_coordinating_to_Pd` 方法

### Changed

- 恢复各函数返回分子元组的功能

## [0.1.4] - 2026-02-28

### Changed

- 删除相关函数冗余入参`frame`

## [0.1.3] - 2026-02-25

### Fixed

- 修复导出问题

## [0.1.2] - 2026-02-25

### Added

- 新增 `detect_O2_molecules` 方法
- 新增 `detect_CO_CO2_molecules` 方法

## [0.1.1] - 2026-02-24

### Added

- 新增 `extract_atom_types` 方法
- 新增 `sum_to_n` 方法
