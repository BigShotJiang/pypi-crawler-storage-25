# validators/northamerica/validator_ca.py
# Canadian banking validators
# Standards: Payments Canada — routing number specification

import re


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def _digits_only(value: str) -> str:
    """Strip any non-digit characters from a string."""
    return re.sub(r"\D", "", value)


def _response(valid: bool, error: str = None, **extra) -> dict:
    """Standard response format."""
    result = {"valid": valid, "error": error if not valid else None}
    if valid and extra:
        result.update(extra)
    return result


# ---------------------------------------------------------------------------
# CANADIAN INSTITUTION NUMBERS
# ---------------------------------------------------------------------------

_INSTITUTIONS = {
    "001": "Bank of Montreal (BMO)",
    "002": "Scotiabank",
    "003": "Royal Bank of Canada (RBC)",
    "004": "Toronto-Dominion Bank (TD)",
    "006": "National Bank of Canada",
    "010": "CIBC",
    "016": "HSBC Canada",
    "039": "Laurentian Bank",
    "219": "ATB Financial",
    "260": "Citibank Canada",
    "307": "Industrial Alliance",
    "326": "PC Financial",
    "338": "Canadian Tire Bank",
    "540": "Manulife Bank",
    "614": "Tangerine Bank",
    "809": "Credit Union Central of Canada",
    "815": "Desjardins",
    "828": "Central 1 Credit Union",
    "837": "Meridian Credit Union",
    "865": "Alterna Savings",
}


# ---------------------------------------------------------------------------
# CANADIAN ROUTING NUMBER VALIDATOR
# ---------------------------------------------------------------------------

def validate_ca_routing(routing: str) -> dict:
    """
    Validates a Canadian routing number (transit + institution).

    Structure:
        Paper format     (9 digits): 0 TTTTT III
        Electronic format (8 digits):  TTTTT III

        TTTTT = transit number (5 digits) — identifies the branch
        III   = institution number (3 digits) — identifies the bank

    Args:
        routing: Routing string — 8 or 9 digits
                 e.g. "000110011" (paper) or "00011001" (electronic)

    Returns:
        dict: {
            "valid":       bool,
            "bank":        str | None,
            "institution": str,
            "transit":     str,
            "error":       str | None
        }

    Example:
        >>> validate_ca_routing("000011001")
        {"valid": True, "bank": "Bank of Montreal (BMO)", "institution": "001", "transit": "00001", "error": None}
    """
    routing = _digits_only(routing)

    # Accept 9 digits (paper format: 0TTTTTIII)
    if len(routing) == 9:
        if routing[0] != "0":
            return _response(False, "9-digit Canadian routing must start with 0")
        routing = routing[1:]  # strip leading zero → 8 digits

    if len(routing) != 8:
        return _response(False, "Canadian routing number must be 8 digits (TTTTTIII)")

    # Extract components — transit first 5, institution last 3
    transit     = routing[:5]
    institution = routing[5:8]

    bank_name = _INSTITUTIONS.get(institution)

    return _response(
        True,
        bank=bank_name,
        institution=institution,
        transit=transit,
    )


# ---------------------------------------------------------------------------
# CANADIAN ACCOUNT NUMBER VALIDATOR
# ---------------------------------------------------------------------------

def validate_ca_account(account: str) -> dict:
    """
    Validates a Canadian bank account number format.

    Args:
        account: Account number string — 7 to 12 digits

    Returns:
        dict: {"valid": bool, "error": str | None}

    Example:
        >>> validate_ca_account("1234567")
        {"valid": True, "error": None}
    """
    account = _digits_only(account)

    if not (7 <= len(account) <= 12):
        return _response(False, "Canadian account number must be between 7 and 12 digits")

    return _response(True)