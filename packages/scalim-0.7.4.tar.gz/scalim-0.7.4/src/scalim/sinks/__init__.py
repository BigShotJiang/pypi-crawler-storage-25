"""`sinks` 包.

该包提供执行/运行时层使用的输出端(`sink`).

实现细节位于 `scalim.sinks._internal` (非公共契约).
"""

from .api import (
    BaseColumnSink,
    BaseRowSink,
    BaseSink,
    BlockColumnCSVSink,
    ColumnBatch,
    ColumnCSVSink,
    ColumnData,
    ColumnExcelSink,
    ColumnValues,
    CSVSink,
    ExcelSink,
    ExcelWorkbookSink,
    IColumnSink,
    InMemoryColumnSink,
    InMemoryCsv,
    InMemoryCsvSink,
    InMemoryListSink,
    InMemoryRowSink,
    IRowSink,
    ISink,
    PandasColumnSink,
    PandasRowSink,
)

__all__ = (
    "BaseColumnSink",
    "BaseRowSink",
    "BaseSink",
    "BlockColumnCSVSink",
    "CSVSink",
    "ColumnBatch",
    "ColumnCSVSink",
    "ColumnData",
    "ColumnExcelSink",
    "ColumnValues",
    "ExcelSink",
    "ExcelWorkbookSink",
    "IColumnSink",
    "IRowSink",
    "ISink",
    "InMemoryColumnSink",
    "InMemoryCsv",
    "InMemoryCsvSink",
    "InMemoryListSink",
    "InMemoryRowSink",
    "PandasColumnSink",
    "PandasRowSink",
)
