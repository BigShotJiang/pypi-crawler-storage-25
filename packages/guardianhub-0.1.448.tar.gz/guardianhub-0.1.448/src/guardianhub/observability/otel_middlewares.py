from typing import Optional

from fastapi import Request
from opentelemetry import baggage, propagate, context
from opentelemetry.context import Context
from opentelemetry.sdk.trace import SpanProcessor
from opentelemetry.trace import Span
from opentelemetry import trace

from guardianhub import get_logger

logger = get_logger(__name__)


from guardianhub.observability.context_utils import build_sovereign_context
from opentelemetry import context
from opentelemetry import baggage as otel_baggage, context as otel_context


async def sovereign_identity_middleware(request: Request, call_next):
    # 1. Extract from physical headers again (Safety)
    logger.info(f"Found URL in sovereign_identity_middleware Middleware {request.url}")
    if request.url.path.startswith("/mcp"):
        return await call_next(request)

    tenant_id = request.headers.get("X-Tenant-ID")
    user_id = request.headers.get("X-User-Email")

    # 2. Seed the Spirit World
    ctx = otel_context.get_current()
    if user_id: ctx = otel_baggage.set_value("user_id", user_id, ctx)
    if tenant_id: ctx = otel_baggage.set_value("tenant_id", tenant_id, ctx)

    # 3. Secure Attachment
    token = otel_context.attach(ctx)
    try:
        request.state.tenant_id = tenant_id
        return await call_next(request)
    finally:
        otel_context.detach(token)  # 🎯 This prevents Identity Bleed



class SovereignContextProcessor(SpanProcessor):
    """
    Principled Observer: Stays 'dumb' to logic, only maps 'Spirit World' (OTel)
    values to 'Physical' attributes for Langfuse visibility.
    """
    PROPAGATION_KEYS = ("user_id", "tenant_id", "access_token", "mission_id", "session_id")

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        # 🎯 FIX 1: Use the parent_context explicitly if provided, fallback to current.
        # This is the "Immutable Link" principle.

        ctx = parent_context if parent_context is not None else context.get_current()

        # 🎯 FIX 2: Ensure we check standard baggage AND our promoted keys
        for key in self.PROPAGATION_KEYS:
            value = baggage.get_baggage(key, ctx)

            if value and value is not None:
                # Stamp generic OTel attribute
                span.set_attribute(f"ctx.{key}", str(value))

                # Map to Langfuse specialized fields
                if key == "user_id":
                    span.set_attribute("langfuse.user.id", str(value))
                elif key == "session_id":
                    span.set_attribute("langfuse.session.id", str(value))
                elif key == "tenant_id":
                    # For Vault integration: this ensures every span knows its owner
                    span.set_attribute("langfuse.trace.metadata.tenant", str(value))

                logger.debug(f"Stamping {key}={value} on span {span.name}")

    def on_end(self, span: Span) -> None:
        pass