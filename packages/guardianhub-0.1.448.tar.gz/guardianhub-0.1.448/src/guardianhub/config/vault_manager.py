import httpx
import hvac
from guardianhub import get_logger
from guardianhub.clients.langfuse.manager import LangfuseManager
from guardianhub.config.settings import CoreSettings
from guardianhub.config.settings import settings
from guardianhub import DEFAULT_SYSTEM_TENANT_ID



logger = get_logger(__name__)


def mask_secrets(data: dict) -> dict:
    """Mask sensitive values for logging. Shows full keys, masks values."""
    if not data:
        return {}
    return {key: "***MASKED***" for key in data.keys()}


class VaultManager:
    def __init__(self):
        self.client = httpx.Client(
            base_url=settings.endpoints.VAULT_MANAGER_URL,
            timeout=120.0
        )

    async def fetch_tenant_secrets(self, tenant_id) -> dict:
        """
        Fetch tenant-specific secrets from HashiCorp Vault.
        Merges Postgres, Langfuse, Neo4j, ChromaDB, and LLM credentials.
        """
        try:
            import hvac
            vault_url = settings.vault.url
            vault_token = settings.vault.token

            if not vault_token:
                logger.warning("⚠️ No Vault token found, cannot fetch tenant secrets")
                return {}

            client = hvac.Client(url=vault_url, token=vault_token)
            if not client.is_authenticated():
                logger.error("❌ Failed to authenticate with Vault")
                return {}

            secrets = {}
            namespace = "yantramops/tenants"

            def get_vault_data(sub_path: str):
                """Helper to attempt tenant-specific fetch with fallback to master."""
                full_path = f"{namespace}/{tenant_id}/{sub_path}"
                try:
                    res = client.secrets.kv.v2.read_secret_version(path=full_path)
                    return res['data']['data'], full_path
                except Exception:
                    fallback_path = f"{namespace}/master/{sub_path}"
                    try:
                        res = client.secrets.kv.v2.read_secret_version(path=fallback_path)
                        return res['data']['data'], fallback_path
                    except Exception:
                        return None, None

            # 1. Fetch Postgres
            pg_data, pg_actual_path = get_vault_data("core/postgres_cred")
            if pg_data:
                logger.info(f"✅ Loaded Postgres from {pg_actual_path}")
                secrets.update({k: pg_data[k] for k in
                                ['DB_USERNAME', 'DB_PASSWORD', 'DB_HOST', 'DB_PORT', 'MASTER_TENANT_DB', 'TENANT_DB'] if
                                k in pg_data})
                db_name = pg_data.get('TENANT_DB') or pg_data.get('MASTER_TENANT_DB', 'db_guardian_tenant_master')
                secrets['POSTGRES_URL'] = f"postgresql+asyncpg://{pg_data.get('DB_USERNAME', 'adminuser')}:{pg_data.get('DB_PASSWORD', '')}@{pg_data.get('DB_HOST', 'guardianhub')}:{pg_data.get('DB_PORT', '5432')}/{db_name}"

            # 2. Fetch Langfuse
            lf_data, lf_actual_path = get_vault_data("observability/langfuse")
            if lf_data:
                logger.info(f"✅ Loaded Langfuse from {lf_actual_path}")
                secrets.update({k: lf_data[k] for k in
                                ['LANGFUSE_PUBLIC_KEY', 'LANGFUSE_SECRET_KEY', 'LANGFUSE_PROJECT_ID', 'LANGFUSE_HOST']
                                if k in lf_data})

            # 3. Fetch Neo4j (from core/neo4j)
            n4j_data, n4j_actual_path = get_vault_data("core/neo4j")
            if n4j_data:
                logger.info(f"✅ Loaded Neo4j from {n4j_actual_path}")
                # Map Neo4j keys to avoid collision with Postgres 'DB_' keys if necessary,
                # but usually handled via prefixing or specific container injection
                secrets.update({
                    'NEO4J_HOST': n4j_data.get('DB_HOST'),
                    'GRAPH_DB_URL': n4j_data.get('DB_HOST'),
                    'NEO4J_PORT': n4j_data.get('DB_PORT'),
                    'NEO4J_USER': n4j_data.get('DB_USERNAME'),
                    'NEO4J_PASSWORD': n4j_data.get('DB_PASSWORD')
                })

            # 4. Fetch ChromaDB (from core/chromadb)
            vector_data, vector_actual_path = get_vault_data("core/chromadb")
            if vector_data:
                logger.info(f"✅ Loaded ChromaDB from {vector_actual_path}")
                secrets.update({
                    'VECTOR_COLLECTION_NAME': vector_data.get('VECTOR_COLLECTION_NAME'),
                    'VECTOR_SERVICE_URL': vector_data.get('VECTOR_SERVICE_URL')
                })


            # 5. Fetch LLM Aura (from llm/aura)
            llm_data, llm_actual_path = get_vault_data("llm/aura")
            if llm_data:
                logger.info(f"✅ Loaded LLM Aura from {llm_actual_path}")
                secrets['LLM_URL'] = llm_data.get('LLM_URL')

            # 5. Fetch LLM Aura (from llm/aura)
            temporal_data, temporal_actual_path = get_vault_data("core/temporal")
            if temporal_data:
                logger.info(f"✅ Loaded Temporal from {temporal_actual_path}")
                secrets['TEMPORAL_HOST_URL'] = temporal_data.get('TEMPORAL_HOST_URL')
                secrets['TEMPORAL_TASK_QUEUE'] = temporal_data.get('TEMPORAL_TASK_QUEUE')
                secrets.update({
                    'TEMPORAL_HOST_URL': temporal_data.get('TEMPORAL_HOST_URL'),
                    'TEMPORAL_TASK_QUEUE': temporal_data.get('TEMPORAL_TASK_QUEUE')
                })

            # List of sub-directories to crawl under the 'yantram' namespace
            # Based on your blueprint: yantram_core, yantram_agents, yantram_external
            yantram_sub_paths = ["yantram_core", "yantram_agents", "yantram_external"]

            for sub_path in yantram_sub_paths:
                # 1. Attempt Tenant Path
                tenant_path = f"{namespace}/{tenant_id}/yantram/{sub_path}"
                # 2. Attempt Master Fallback Path
                system_path = f"{namespace}/{DEFAULT_SYSTEM_TENANT_ID}/yantram/{sub_path}"

                data = None
                actual_path = ""

                try:
                    # Try Tenant Specific
                    res = client.secrets.kv.v2.read_secret_version(path=tenant_path)
                    data = res['data']['data']
                    actual_path = tenant_path
                except Exception:
                    try:
                        # Fallback to Master
                        res = client.secrets.kv.v2.read_secret_version(path=system_path)
                        data = res['data']['data']
                        actual_path = system_path
                    except Exception:
                        logger.debug(f"ℹ️ No secrets found for {system_path} in tenant or master.")
                        continue

                if data:
                    logger.info(f"✅ Loaded {len(data)} keys from {actual_path}")
                    secrets.update(data)

            return secrets

        except ImportError:
            logger.error("❌ hvac library not found.")
            return {}
        except Exception as e:
            logger.error(f"❌ Failed to fetch tenant secrets: {e}")
            return {}

    def populate_session_tenant(self, tenant_secrets: dict):
        """
        Injects tenant-specific secrets into the global settings singleton
         and resets dependent service managers.
        """
        if not tenant_secrets:
            logger.warning("[VaultManager] No secrets provided to populate session.")
            return

        try:
            logger.info(f"[VaultManager] Received Tenant Secrets: {mask_secrets(tenant_secrets)}")

            # 1. Dynamic Injection into Settings Singleton
            for key, value in tenant_secrets.items():
                # Normalize key to uppercase for credentials
                upper_key = key.upper()

                # Update Endpoints if the attribute exists (e.g., LANGFUSE_HOST, POSTGRES_URL)
                if hasattr(settings.endpoints, upper_key):
                    setattr(settings.endpoints, upper_key, value)
                elif hasattr(settings.endpoints, key):  # Check lowercase/original
                    setattr(settings.endpoints, key, value)

                # Inject into Credentials vault (Always uppercase for GH_CREDENTIALS)
                setattr(settings.credentials, upper_key, value)

            logger.info("✅ Global settings singleton successfully updated for current tenant.")

            # 2. Reset Dependent Managers
            # We must wipe existing singletons so they re-read the updated 'self.settings'
            LangfuseManager.reset()

            # 3. Final Verification Log
            # This call triggers the 'get_instance' logic we just updated,
            # which will now see the new host in self.settings.
            new_client = LangfuseManager.get_instance()
            current_host = getattr(LangfuseManager, '_current_host', 'N/A')
            logger.info(f"🚀 Langfuse reset complete. Client now targeting: {current_host}")

        except Exception as e:
            logger.error(f"❌ Failed to populate tenant settings: {e}", exc_info=True)
            raise