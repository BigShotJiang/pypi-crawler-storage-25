"""Platform Commons — shared libraries for AI Development Platform."""

from .auth_middleware import AuthContext, DualAuthMiddleware
from .jwt_middleware import JWKSClient, JWTValidator, require_scopes
from .jwt_models import JWTClaims
from .scope_hierarchy import SCOPE_HIERARCHY, expand_scopes
from .scope_middleware import CapabilityScopeMiddleware, ScopeRegistry

__all__ = [
    "SCOPE_HIERARCHY",
    "AuthContext",
    "CapabilityScopeMiddleware",
    "DualAuthMiddleware",
    "JWKSClient",
    "JWTClaims",
    "JWTValidator",
    "ScopeRegistry",
    "expand_scopes",
    "require_scopes",
]
