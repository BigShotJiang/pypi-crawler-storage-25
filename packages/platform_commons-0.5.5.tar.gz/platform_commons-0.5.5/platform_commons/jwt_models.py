"""JWT claims model for platform services."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class JWTClaims:
    """Parsed and validated JWT claims."""

    iss: str
    aud: str
    sub: str
    scopes: list[str] = field(default_factory=list)
    exp: int = 0
    iat: int = 0
    jti: str = ""
    # Capability token fields (Phase 2, optional)
    org_id: str | None = None
    membership_id: str | None = None
    task_id: str | None = None
    agent_role: str | None = None
