"""Scope hierarchy for capability token validation.

SYNC WARNING: This is the server-side copy of scope hierarchy.
The SDK has an identical copy at SDK/platform_sdk/scope/namespace.py.
Both MUST stay in sync. Any change here MUST be mirrored there.
"""

from __future__ import annotations

SCOPE_HIERARCHY: dict[str, list[str]] = {
    "rag.decisions.write": ["rag.decisions.read"],
    "rag.artifacts.write": ["rag.artifacts.read"],
    "pl.versions.write": ["pl.versions.read"],
    "pl.versions.promote": ["pl.versions.write", "pl.versions.read"],
}


def expand_scopes(granted: list[str]) -> frozenset[str]:
    """Expand scope list with implied scopes from hierarchy."""
    expanded: set[str] = set(granted)
    for scope in granted:
        if scope in SCOPE_HIERARCHY:
            expanded.update(SCOPE_HIERARCHY[scope])
    return frozenset(expanded)
