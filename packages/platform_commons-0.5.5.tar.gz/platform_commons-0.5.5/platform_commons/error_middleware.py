"""Unified error middleware — PLATFORM_CONTRACT_STANDARD §4.

Catches PlatformError and unhandled exceptions, returns unified JSON:
{
    "error": {
        "code": "<ERROR_CODE>",
        "message": "<human-readable>",
        "details": {<structured>},
        "trace_id": "<from X-Trace-Id>"
    }
}

Usage:
    from platform_commons.error_middleware import setup_error_handling
    setup_error_handling(app)
"""

from __future__ import annotations

import logging
import uuid

from fastapi import FastAPI, HTTPException, Request
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse, Response

from .exceptions import PlatformError

logger = logging.getLogger(__name__)


def _generate_trace_id() -> str:
    return f"trace_{uuid.uuid4().hex[:12]}"


def _get_trace_id(request: Request) -> str:
    return (
        request.headers.get("x-trace-id")
        or getattr(request.state, "trace_id", None)
        or _generate_trace_id()
    )


def _error_response(
    status_code: int, code: str, message: str, details: dict[str, object], trace_id: str
) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": details,
                "trace_id": trace_id,
            }
        },
        headers={"X-Trace-Id": trace_id},
    )


class PlatformErrorMiddleware(BaseHTTPMiddleware):
    """Unified error handling middleware.

    1. Extracts trace_id from X-Trace-Id header (or generates one)
    2. Catches PlatformError → structured JSON response
    3. Catches unhandled Exception → 500 INTERNAL_ERROR
    4. Always includes trace_id in response header

    Note: HTTPException is handled by FastAPI exception handlers registered
    via setup_error_handling(), not by this middleware.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        trace_id = _get_trace_id(request)
        request.state.trace_id = trace_id

        try:
            return await call_next(request)

        except PlatformError as exc:
            logger.warning(
                "PlatformError: %s [%s] trace_id=%s path=%s",
                exc.code,
                exc.status_code,
                trace_id,
                request.url.path,
            )
            return _error_response(exc.status_code, exc.code, exc.message, exc.details, trace_id)

        except Exception:
            logger.exception(
                "Unhandled exception trace_id=%s path=%s",
                trace_id,
                request.url.path,
            )
            return _error_response(500, "INTERNAL_ERROR", "Internal server error", {}, trace_id)


def setup_error_handling(app: FastAPI) -> None:
    """Register PlatformErrorMiddleware + exception handlers on a FastAPI app.

    This is the recommended single entry point. It:
    1. Adds PlatformErrorMiddleware (catches PlatformError + unhandled)
    2. Registers exception_handler for HTTPException (standard format)
    3. Registers exception_handler for PlatformError (fallback for
       exceptions raised in dependencies/middleware that bypass dispatch)
    """
    app.add_middleware(PlatformErrorMiddleware)

    @app.exception_handler(HTTPException)
    async def _handle_http_exception(request: Request, exc: HTTPException) -> JSONResponse:
        trace_id = _get_trace_id(request)

        # If detail is already a dict with "code"/"message", use it directly
        # (supports services that already pass structured error dicts)
        details: dict[str, object]
        if isinstance(exc.detail, dict) and "code" in exc.detail:
            code = exc.detail["code"]
            message = exc.detail.get("message", str(exc.detail))
            details = {k: v for k, v in exc.detail.items() if k not in ("code", "message")}
        else:
            code = f"HTTP_{exc.status_code}"
            message = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
            details = {}

        logger.warning(
            "HTTPException: %s [%d] trace_id=%s path=%s",
            code,
            exc.status_code,
            trace_id,
            request.url.path,
        )
        return _error_response(exc.status_code, code, message, details, trace_id)

    @app.exception_handler(PlatformError)
    async def _handle_platform_error(request: Request, exc: PlatformError) -> JSONResponse:
        trace_id = _get_trace_id(request)
        logger.warning(
            "PlatformError (handler): %s [%s] trace_id=%s path=%s",
            exc.code,
            exc.status_code,
            trace_id,
            request.url.path,
        )
        return _error_response(exc.status_code, exc.code, exc.message, exc.details, trace_id)
