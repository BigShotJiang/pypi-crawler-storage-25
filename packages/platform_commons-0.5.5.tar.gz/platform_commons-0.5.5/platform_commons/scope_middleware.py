"""Scope enforcement middleware for capability tokens.

Runs AFTER DualAuthMiddleware. Checks that capability tokens have the
required scope for the requested endpoint. Service tokens and X-Service-Key
requests bypass scope checks (trusted inter-service calls).
"""

from __future__ import annotations

import logging
import re
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from .scope_hierarchy import expand_scopes

logger = logging.getLogger(__name__)

ScopeRoute = tuple[str, str, str]

_CAPABILITY_ISSUER = "auth-rbac.platform.local"


class ScopeRegistry:
    """Maps (HTTP method, URL path) to required scope.

    First match wins — order routes from most specific to least specific.
    """

    def __init__(self, routes: list[ScopeRoute]) -> None:
        seen: set[tuple[str, str]] = set()
        for method, pattern, scope in routes:
            key = (method, pattern)
            if key in seen:
                logger.warning(
                    "Duplicate scope route: (%s, %s) -> %s",
                    method,
                    pattern,
                    scope,
                )
            seen.add(key)

        self._routes: list[tuple[str, re.Pattern[str], str]] = [
            (method, re.compile(pattern), scope) for method, pattern, scope in routes
        ]

    def get_required_scope(self, method: str, path: str) -> str | None:
        """Return required scope for this request, or None if unrestricted."""
        for method_pattern, path_pattern, scope in self._routes:
            if method_pattern not in ("*", method):
                continue
            if path_pattern.match(path):
                return scope
        return None


class CapabilityScopeMiddleware(BaseHTTPMiddleware):
    """Enforce scope-based authorization for capability tokens.

    Only applies to requests authenticated via capability tokens
    (detected by issuer). Service token and X-Service-Key requests
    are trusted and bypass scope checks.
    """

    def __init__(self, app: Any, scope_registry: ScopeRegistry) -> None:
        super().__init__(app)
        self._registry = scope_registry

    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        auth_context = getattr(request.state, "auth_context", None)

        if auth_context is None:
            return await call_next(request)

        claims = getattr(auth_context, "claims", None)
        if claims is None or getattr(claims, "iss", "") != _CAPABILITY_ISSUER:
            return await call_next(request)

        required_scope = self._registry.get_required_scope(
            request.method,
            request.url.path,
        )
        if required_scope is None:
            return await call_next(request)

        token_scopes: list[str] = getattr(claims, "scopes", [])
        expanded = expand_scopes(token_scopes)

        if required_scope in expanded:
            return await call_next(request)

        trace_id = getattr(request.state, "trace_id", "")
        logger.warning(
            "Scope violation: %s requires %s, token has %s (task=%s, role=%s)",
            request.url.path,
            required_scope,
            sorted(token_scopes),
            getattr(claims, "task_id", ""),
            getattr(claims, "agent_role", ""),
        )
        return JSONResponse(
            status_code=403,
            content={
                "error": {
                    "code": "INSUFFICIENT_SCOPE",
                    "message": f"This operation requires scope '{required_scope}'",
                    "details": {
                        "required_scope": required_scope,
                        "available_scopes": sorted(token_scopes),
                        "expanded_scopes": sorted(expanded),
                    },
                    "trace_id": trace_id,
                },
            },
        )
