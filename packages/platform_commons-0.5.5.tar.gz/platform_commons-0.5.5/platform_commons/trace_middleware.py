"""Unified trace context middleware — PLATFORM_CONTRACT_STANDARD §5.

Extracts/generates X-Trace-Id and X-Request-Id, stores in request.state
and contextvars for logging and outgoing HTTP propagation.
"""

from __future__ import annotations

import uuid
from contextvars import ContextVar
from dataclasses import dataclass

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response


@dataclass(frozen=True)
class TraceContext:
    """Immutable trace context propagated via contextvars."""

    trace_id: str
    request_id: str


trace_context: ContextVar[TraceContext] = ContextVar("trace_context")


def get_trace_context() -> TraceContext | None:
    """Get current trace context from contextvars."""
    return trace_context.get(None)


def _generate_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


class PlatformTracingMiddleware(BaseHTTPMiddleware):
    """Extract/generate trace headers, propagate through request lifecycle.

    - X-Trace-Id: preserved from incoming request or generated.
      SAME across entire call chain (ADM -> Router -> WM -> Worker).
    - X-Request-Id: preserved from incoming or generated.
      New per hop for outgoing calls.
    - Also extracts context headers into request.state.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        trace_id = request.headers.get("x-trace-id") or _generate_id("trace")
        request_id = request.headers.get("x-request-id") or _generate_id("req")

        # Store in request.state
        request.state.trace_id = trace_id
        request.state.request_id = request_id

        # Extract context headers
        request.state.execution_id = request.headers.get("x-execution-id") or ""
        request.state.task_id = request.headers.get("x-task-id") or ""
        request.state.org_id = request.headers.get("x-org-id") or ""
        request.state.membership_id = request.headers.get("x-membership-id") or ""
        request.state.workflow_instance_id = request.headers.get("x-workflow-instance-id") or ""

        # Store in contextvars for outgoing HTTP calls
        ctx = TraceContext(trace_id=trace_id, request_id=request_id)
        token = trace_context.set(ctx)

        # Optional structlog binding (if available)
        try:
            import structlog  # type: ignore[import-not-found]  # noqa: PLC0415

            structlog.contextvars.clear_contextvars()
            bind_kwargs: dict[str, str] = {"trace_id": trace_id}
            if request.state.workflow_instance_id:
                bind_kwargs["workflow_instance_id"] = request.state.workflow_instance_id
            if request.state.task_id:
                bind_kwargs["task_id"] = request.state.task_id
            structlog.contextvars.bind_contextvars(**bind_kwargs)
        except ImportError:
            pass

        try:
            response = await call_next(request)
            response.headers["X-Trace-Id"] = trace_id
            response.headers["X-Request-Id"] = request_id
            return response
        finally:
            trace_context.reset(token)
