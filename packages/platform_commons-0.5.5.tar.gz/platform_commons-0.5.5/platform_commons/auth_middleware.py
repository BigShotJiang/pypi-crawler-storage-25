"""Dual authentication middleware — Phase B migration.

Accepts both Bearer JWT (preferred) and X-Service-Key (legacy, deprecated).
Migration path per auth_rbac_jwks.md:
  Phase A: X-Service-Key only (legacy)
  Phase B: Both accepted, X-Service-Key emits deprecation warning (THIS)
  Phase C: Bearer JWT only
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from .exceptions import PlatformError
from .jwt_middleware import JWTValidator, _extract_bearer_token
from .jwt_models import JWTClaims

logger = logging.getLogger(__name__)

_deprecated_auth_count: int = 0


def get_deprecated_auth_count() -> int:
    """Return count of deprecated X-Service-Key authentications."""
    return _deprecated_auth_count


@dataclass(frozen=True)
class AuthContext:
    """Unified authentication context — result of either auth method."""

    method: str  # "jwt" or "service_key"
    subject: str  # service identity (e.g., "service:adm" or "adm")
    scopes: list[str] = field(default_factory=list)
    claims: JWTClaims | None = None  # Only set for JWT auth
    raw_service_key: str | None = None  # Only set for service_key auth


# Async callable: takes key string, returns (service_name, scopes) or raises PlatformError
ServiceKeyValidator = Callable[[str], Awaitable[tuple[str, list[str]]]]


class DualAuthMiddleware(BaseHTTPMiddleware):
    """Middleware that accepts Bearer JWT or X-Service-Key.

    Bearer JWT is preferred. X-Service-Key emits deprecation warning.
    If both are present, Bearer JWT takes precedence.
    Unauthenticated requests (no auth header) -> 401.

    Public paths can be excluded from auth via ``exclude_paths``.
    """

    def __init__(
        self,
        app: Any,
        jwt_validator: JWTValidator,
        service_key_validator: ServiceKeyValidator | None = None,
        exclude_paths: list[str] | None = None,
    ) -> None:
        super().__init__(app)
        self._jwt_validator = jwt_validator
        self._service_key_validator = service_key_validator
        self._exclude_paths = set(exclude_paths or [])

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if request.url.path in self._exclude_paths:
            return await call_next(request)

        try:
            auth_context = await self._authenticate(request)
            request.state.auth_context = auth_context
            if auth_context.claims is not None:
                request.state.jwt_claims = auth_context.claims
        except PlatformError as exc:
            return JSONResponse(
                status_code=exc.status_code,
                content={
                    "error": {
                        "code": exc.code,
                        "message": exc.message,
                        "details": exc.details,
                        "trace_id": getattr(request.state, "trace_id", ""),
                    }
                },
            )

        return await call_next(request)

    async def _authenticate(self, request: Request) -> AuthContext:
        global _deprecated_auth_count  # noqa: PLW0603

        bearer = request.headers.get("authorization")
        service_key = request.headers.get("x-service-key")

        # Prefer Bearer JWT if present
        if bearer and bearer.lower().startswith("bearer "):
            token = _extract_bearer_token(bearer)
            claims = await self._jwt_validator.validate(token)
            return AuthContext(
                method="jwt",
                subject=claims.sub,
                scopes=claims.scopes,
                claims=claims,
            )

        if service_key and self._service_key_validator is not None:
            _deprecated_auth_count += 1
            logger.warning(
                "deprecated_auth_method: X-Service-Key used on %s (count=%d)",
                request.url.path,
                _deprecated_auth_count,
            )
            service_name, scopes = await self._service_key_validator(service_key)
            return AuthContext(
                method="service_key",
                subject=service_name,
                scopes=scopes,
                raw_service_key=service_key,
            )

        raise PlatformError(
            code="AUTH_MISSING",
            message="Authentication required: provide Bearer JWT or X-Service-Key",
            status_code=401,
        )
