"""JWT validation middleware and FastAPI dependencies.

Implements auth_rbac_jwks.md section 5 — 9-step JWT validation:
  1. Extract token from Authorization: Bearer header
  2. Decode JWT header -> extract kid
  3. Lookup kid in cached JWKS
     a. If kid not found -> refresh JWKS (one retry)
     b. If still not found -> 401
  4. Validate RS256 signature with public key
  5. Validate claims: iss == "auth-rbac", aud contains service name, exp > now
  6. Extract scopes
  7. Check required scope for endpoint
  8. Extract org_id, membership_id for tenant context
  9. Set request.state.jwt_claims
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import Any

import httpx
import jwt as pyjwt
from fastapi import Depends, Request
from jwt import PyJWK

from .exceptions import ForbiddenError, PlatformError
from .jwt_models import JWTClaims

logger = logging.getLogger(__name__)

_JWKS_CACHE_TTL = 300  # 5 minutes per contract


class JWKSClient:
    """Fetches and caches JWKS from Auth/RBAC.

    Cache TTL: 300 seconds (per auth_rbac_jwks.md section 4.1).
    On kid miss: one forced refresh before rejecting.
    On JWKS unavailable: fail-closed (reject all tokens).
    """

    def __init__(self, jwks_url: str) -> None:
        self._jwks_url = jwks_url
        self._keys: dict[str, dict[str, Any]] = {}
        self._cached_at: float = 0.0

    def _is_cache_valid(self) -> bool:
        return bool(self._keys) and (time.monotonic() - self._cached_at) < _JWKS_CACHE_TTL

    async def _fetch_jwks(self) -> None:
        """Fetch JWKS from Auth/RBAC. On failure, clear cache (fail-closed)."""
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(self._jwks_url)
                response.raise_for_status()
                data = response.json()

            self._keys = {}
            for key_data in data.get("keys", []):
                kid = key_data.get("kid")
                if kid:
                    self._keys[kid] = key_data
            self._cached_at = time.monotonic()
            logger.debug("JWKS refreshed: %d keys", len(self._keys))
        except Exception:
            logger.warning("Failed to fetch JWKS from %s — fail-closed", self._jwks_url)
            self._keys = {}
            self._cached_at = 0.0

    async def get_signing_key(self, kid: str) -> PyJWK:
        """Get signing key by kid. Refreshes JWKS if needed.

        Raises PlatformError(401) if key not found after refresh.
        """
        if self._is_cache_valid() and kid in self._keys:
            return PyJWK(self._keys[kid])

        await self._fetch_jwks()

        if kid in self._keys:
            return PyJWK(self._keys[kid])

        raise PlatformError(
            code="AUTH_INVALID_TOKEN",
            message="Token signing key not found in JWKS",
            status_code=401,
            details={"kid": kid},
        )


class JWTValidator:
    """Validates JWT tokens per auth_rbac_jwks.md section 5."""

    def __init__(
        self,
        jwks_client: JWKSClient,
        accepted_audiences: list[str],
        accepted_issuers: list[str] | None = None,
    ) -> None:
        self._jwks_client = jwks_client
        self._accepted_audiences = accepted_audiences
        self._accepted_issuers = accepted_issuers or ["auth-rbac"]

    async def validate(self, token: str) -> JWTClaims:
        """Validate JWT and return parsed claims.

        Raises PlatformError(401) on any validation failure.
        """
        try:
            header = pyjwt.get_unverified_header(token)
        except pyjwt.exceptions.DecodeError as exc:
            raise PlatformError(
                code="AUTH_INVALID_TOKEN",
                message="Malformed JWT",
                status_code=401,
            ) from exc

        kid = header.get("kid")
        if not kid:
            raise PlatformError(
                code="AUTH_INVALID_TOKEN",
                message="JWT header missing kid",
                status_code=401,
            )

        signing_key = await self._jwks_client.get_signing_key(kid)

        try:
            payload: dict[str, Any] = pyjwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=self._accepted_audiences,
                options={
                    "require": ["exp", "iat", "iss", "aud", "sub"],
                    "verify_iss": False,  # Manual check for multi-issuer support
                },
            )
        except pyjwt.ExpiredSignatureError as exc:
            raise PlatformError(
                code="AUTH_TOKEN_EXPIRED",
                message="Token has expired",
                status_code=401,
            ) from exc
        except pyjwt.InvalidAudienceError as exc:
            raise PlatformError(
                code="AUTH_INVALID_AUDIENCE",
                message="Token audience mismatch",
                status_code=401,
            ) from exc
        except pyjwt.PyJWTError as exc:
            raise PlatformError(
                code="AUTH_INVALID_TOKEN",
                message="JWT validation failed",
                status_code=401,
            ) from exc

        # Manual issuer check (supports multiple issuers)
        token_iss = payload.get("iss", "")
        if token_iss not in self._accepted_issuers:
            raise PlatformError(
                code="AUTH_INVALID_ISSUER",
                message="Token issuer mismatch",
                status_code=401,
                details={"issuer": token_iss},
            )

        return JWTClaims(
            iss=payload.get("iss", ""),
            aud=payload.get("aud", ""),
            sub=payload.get("sub", ""),
            scopes=payload.get("scopes", []),
            exp=payload.get("exp", 0),
            iat=payload.get("iat", 0),
            jti=payload.get("jti", ""),
            org_id=payload.get("org_id"),
            membership_id=payload.get("membership_id"),
            task_id=payload.get("task_id"),
            agent_role=payload.get("agent_role"),
        )


def _extract_bearer_token(authorization: str | None) -> str:
    """Extract token from 'Bearer <token>' header.

    Raises PlatformError(401) if missing or malformed.
    """
    if not authorization:
        raise PlatformError(
            code="AUTH_MISSING_TOKEN",
            message="Authorization header required",
            status_code=401,
        )
    parts = authorization.split(" ", 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise PlatformError(
            code="AUTH_INVALID_TOKEN",
            message="Authorization header must be 'Bearer <token>'",
            status_code=401,
        )
    return parts[1]


def create_jwt_validator_dependency(
    validator: JWTValidator,
) -> Callable[..., Any]:
    """Create a FastAPI dependency that validates JWT and returns claims."""

    async def get_jwt_claims(request: Request) -> JWTClaims:
        token = _extract_bearer_token(request.headers.get("authorization"))
        claims = await validator.validate(token)
        request.state.jwt_claims = claims
        return claims

    return get_jwt_claims


def require_scopes(*scopes: str) -> Any:
    """FastAPI dependency that validates JWT AND checks required scopes.

    Usage:
        @router.get("/endpoint")
        async def handler(claims: JWTClaims = require_scopes("scope.read")):
            ...

    The JWT validator must be set at app startup via app.state.jwt_validator.
    """

    async def dependency(request: Request) -> JWTClaims:
        token = _extract_bearer_token(request.headers.get("authorization"))
        validator: JWTValidator = request.app.state.jwt_validator
        claims = await validator.validate(token)

        missing = [s for s in scopes if s not in claims.scopes]
        if missing:
            raise ForbiddenError(
                code="AUTH_INSUFFICIENT_SCOPE",
                message=f"Missing required scopes: {', '.join(missing)}",
                required_scopes=list(scopes),
                missing_scopes=missing,
            )

        request.state.jwt_claims = claims
        return claims

    return Depends(dependency)
