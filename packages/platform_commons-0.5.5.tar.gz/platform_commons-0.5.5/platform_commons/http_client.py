"""Platform HTTP client with automatic trace header propagation.

Usage:
    from platform_commons.http_client import get_trace_headers

    # In any outgoing HTTP call:
    headers = {**existing_headers, **get_trace_headers()}
    await httpx_client.post(url, json=data, headers=headers)
"""

from __future__ import annotations

import uuid
from typing import Any

import httpx

from .trace_middleware import get_trace_context


def _generate_request_id() -> str:
    return f"req_{uuid.uuid4().hex[:12]}"


def get_trace_headers() -> dict[str, str]:
    """Get trace headers for outgoing HTTP requests.

    X-Trace-Id: same as incoming (preserved through chain)
    X-Request-Id: NEW for each outgoing call (unique per hop)
    """
    ctx = get_trace_context()
    headers: dict[str, str] = {"X-Request-Id": _generate_request_id()}
    if ctx:
        headers["X-Trace-Id"] = ctx.trace_id
    return headers


class PlatformHTTPClient:
    """httpx.AsyncClient wrapper with automatic trace propagation."""

    def __init__(self, base_url: str = "", timeout: float = 30.0, **kwargs: Any) -> None:
        self._client = httpx.AsyncClient(base_url=base_url, timeout=timeout, **kwargs)

    async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        headers: dict[str, str] = dict(kwargs.pop("headers", None) or {})
        headers.update(get_trace_headers())
        return await self._client.request(method, url, headers=headers, **kwargs)

    async def get(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("POST", url, **kwargs)

    async def put(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("PUT", url, **kwargs)

    async def delete(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("DELETE", url, **kwargs)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> PlatformHTTPClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
