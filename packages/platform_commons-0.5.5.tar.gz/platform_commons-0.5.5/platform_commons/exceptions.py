"""Platform-standard exception hierarchy.

All exceptions follow PLATFORM_CONTRACT_STANDARD §4:
  {error: {code, message, details, trace_id}}
"""

from __future__ import annotations


class PlatformError(Exception):
    """Base exception for all platform services.

    Caught by PlatformErrorMiddleware and rendered as:
    {
        "error": {
            "code": self.code,
            "message": self.message,
            "details": self.details,
            "trace_id": <from X-Trace-Id header>
        }
    }
    """

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 400,
        details: dict[str, object] | None = None,
    ):
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        super().__init__(message)


class NotFoundError(PlatformError):
    """Resource not found (404)."""

    def __init__(self, resource: str, resource_id: str, **extra_details: object):
        super().__init__(
            code=f"{resource.upper()}_NOT_FOUND",
            message=f"{resource} {resource_id} not found",
            status_code=404,
            details={"resource": resource, "id": resource_id, **extra_details},
        )


class ValidationError(PlatformError):
    """Invalid request payload (400)."""

    def __init__(self, code: str, message: str, **extra_details: object):
        super().__init__(
            code=code,
            message=message,
            status_code=400,
            details=dict(extra_details),
        )


class ConflictError(PlatformError):
    """State conflict or duplicate (409)."""

    def __init__(self, code: str, message: str, **extra_details: object):
        super().__init__(
            code=code,
            message=message,
            status_code=409,
            details=dict(extra_details),
        )


class ForbiddenError(PlatformError):
    """Insufficient permissions (403)."""

    def __init__(
        self,
        code: str = "SCOPE_INSUFFICIENT",
        message: str = "Insufficient permissions",
        **extra_details: object,
    ):
        super().__init__(
            code=code,
            message=message,
            status_code=403,
            details=dict(extra_details),
        )


class ServiceUnavailableError(PlatformError):
    """Downstream service unavailable (503)."""

    def __init__(
        self,
        service: str,
        message: str | None = None,
        **extra_details: object,
    ):
        super().__init__(
            code="SERVICE_UNAVAILABLE",
            message=message or f"{service} is temporarily unavailable",
            status_code=503,
            details={"service": service, **extra_details},
        )
