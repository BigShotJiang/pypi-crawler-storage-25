"""Tests for PlatformErrorMiddleware."""

from __future__ import annotations

import pytest
from fastapi import FastAPI, HTTPException
from httpx import ASGITransport, AsyncClient

from platform_commons.error_middleware import setup_error_handling
from platform_commons.exceptions import (
    ConflictError,
    ForbiddenError,
    NotFoundError,
    PlatformError,
    ServiceUnavailableError,
    ValidationError,
)


def _create_test_app() -> FastAPI:
    """Create a minimal FastAPI app with error-triggering routes."""
    app = FastAPI()
    setup_error_handling(app)

    @app.get("/ok")
    async def ok() -> dict:
        return {"status": "ok"}

    @app.get("/platform-error")
    async def platform_error() -> None:
        raise PlatformError(
            code="TEST_ERROR",
            message="Something went wrong",
            status_code=418,
            details={"key": "value"},
        )

    @app.get("/not-found")
    async def not_found() -> None:
        raise NotFoundError("task", "task_01J2M9T4A2")

    @app.get("/validation-error")
    async def validation_error() -> None:
        raise ValidationError(
            code="DISPATCH_VALIDATION_FAILED",
            message="Invalid task_type",
            field="task_type",
            value="unknown",
        )

    @app.get("/conflict")
    async def conflict() -> None:
        raise ConflictError(
            code="DISPATCH_ALREADY_RUNNING",
            message="Task already running",
            task_id="task_01J",
        )

    @app.get("/forbidden")
    async def forbidden() -> None:
        raise ForbiddenError(org_id="org_acme")

    @app.get("/service-unavailable")
    async def service_unavailable() -> None:
        raise ServiceUnavailableError("vault")

    @app.get("/http-exception")
    async def http_exception() -> None:
        raise HTTPException(status_code=422, detail="Unprocessable entity")

    @app.get("/unhandled")
    async def unhandled() -> None:
        raise RuntimeError("unexpected crash")

    return app


@pytest.fixture
def app() -> FastAPI:
    return _create_test_app()


@pytest.fixture
async def client(app: FastAPI) -> AsyncClient:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


async def test_success_returns_ok(client: AsyncClient) -> None:
    resp = await client.get("/ok", headers={"X-Trace-Id": "trace_test123"})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


async def test_success_does_not_duplicate_trace_header(client: AsyncClient) -> None:
    """PlatformErrorMiddleware only sets trace_id on error responses.
    Success responses rely on per-service tracing middleware."""
    resp = await client.get("/ok")
    assert resp.status_code == 200


async def test_platform_error(client: AsyncClient) -> None:
    resp = await client.get("/platform-error", headers={"X-Trace-Id": "trace_pe01"})
    assert resp.status_code == 418
    body = resp.json()
    assert body["error"]["code"] == "TEST_ERROR"
    assert body["error"]["message"] == "Something went wrong"
    assert body["error"]["details"] == {"key": "value"}
    assert body["error"]["trace_id"] == "trace_pe01"
    assert resp.headers["x-trace-id"] == "trace_pe01"


async def test_not_found_error(client: AsyncClient) -> None:
    resp = await client.get("/not-found")
    assert resp.status_code == 404
    body = resp.json()
    assert body["error"]["code"] == "TASK_NOT_FOUND"
    assert "task_01J2M9T4A2" in body["error"]["message"]
    assert body["error"]["details"]["resource"] == "task"
    assert body["error"]["details"]["id"] == "task_01J2M9T4A2"


async def test_validation_error(client: AsyncClient) -> None:
    resp = await client.get("/validation-error")
    assert resp.status_code == 400
    body = resp.json()
    assert body["error"]["code"] == "DISPATCH_VALIDATION_FAILED"
    assert body["error"]["details"]["field"] == "task_type"


async def test_conflict_error(client: AsyncClient) -> None:
    resp = await client.get("/conflict")
    assert resp.status_code == 409
    body = resp.json()
    assert body["error"]["code"] == "DISPATCH_ALREADY_RUNNING"
    assert body["error"]["details"]["task_id"] == "task_01J"


async def test_forbidden_error(client: AsyncClient) -> None:
    resp = await client.get("/forbidden")
    assert resp.status_code == 403
    body = resp.json()
    assert body["error"]["code"] == "SCOPE_INSUFFICIENT"
    assert body["error"]["details"]["org_id"] == "org_acme"


async def test_service_unavailable_error(client: AsyncClient) -> None:
    resp = await client.get("/service-unavailable")
    assert resp.status_code == 503
    body = resp.json()
    assert body["error"]["code"] == "SERVICE_UNAVAILABLE"
    assert body["error"]["details"]["service"] == "vault"


async def test_http_exception_wrapped(client: AsyncClient) -> None:
    resp = await client.get("/http-exception", headers={"X-Trace-Id": "trace_http01"})
    assert resp.status_code == 422
    body = resp.json()
    assert body["error"]["code"] == "HTTP_422"
    assert body["error"]["message"] == "Unprocessable entity"
    assert body["error"]["trace_id"] == "trace_http01"


async def test_unhandled_exception_returns_500(client: AsyncClient) -> None:
    resp = await client.get("/unhandled", headers={"X-Trace-Id": "trace_crash01"})
    assert resp.status_code == 500
    body = resp.json()
    assert body["error"]["code"] == "INTERNAL_ERROR"
    assert body["error"]["message"] == "Internal server error"
    assert body["error"]["trace_id"] == "trace_crash01"


async def test_trace_id_present_in_all_error_responses(
    client: AsyncClient,
) -> None:
    """Every error response must include trace_id in body and header."""
    for path in [
        "/platform-error",
        "/not-found",
        "/http-exception",
        "/unhandled",
    ]:
        resp = await client.get(path, headers={"X-Trace-Id": "trace_check"})
        assert "trace_id" in resp.json()["error"]
        assert resp.headers["x-trace-id"] == "trace_check"
