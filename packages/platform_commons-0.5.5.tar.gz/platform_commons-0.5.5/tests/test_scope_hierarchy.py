"""Tests for scope hierarchy expansion."""

from __future__ import annotations

from platform_commons.scope_hierarchy import SCOPE_HIERARCHY, expand_scopes


def test_expand_no_hierarchy() -> None:
    result = expand_scopes(["rag.decisions.read"])
    assert result == frozenset({"rag.decisions.read"})


def test_expand_write_implies_read() -> None:
    result = expand_scopes(["rag.decisions.write"])
    assert "rag.decisions.read" in result
    assert "rag.decisions.write" in result


def test_expand_promote_implies_all() -> None:
    result = expand_scopes(["pl.versions.promote"])
    assert "pl.versions.promote" in result
    assert "pl.versions.write" in result
    assert "pl.versions.read" in result


def test_expand_multiple() -> None:
    result = expand_scopes(["rag.decisions.write", "pl.versions.promote"])
    assert "rag.decisions.read" in result
    assert "pl.versions.write" in result
    assert "pl.versions.read" in result


def test_expand_empty() -> None:
    assert expand_scopes([]) == frozenset()


def test_hierarchy_matches_expected() -> None:
    """Full cross-validation — both keys AND values."""
    expected = {
        "rag.decisions.write": ["rag.decisions.read"],
        "rag.artifacts.write": ["rag.artifacts.read"],
        "pl.versions.write": ["pl.versions.read"],
        "pl.versions.promote": ["pl.versions.write", "pl.versions.read"],
    }
    assert expected == SCOPE_HIERARCHY
