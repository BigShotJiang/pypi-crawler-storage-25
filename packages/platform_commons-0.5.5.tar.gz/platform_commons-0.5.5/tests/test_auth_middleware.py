"""Tests for DualAuthMiddleware — Phase B dual validation."""

from __future__ import annotations

import base64
import time
from typing import Any

import jwt as pyjwt
import pytest
from fastapi import FastAPI, Request
from httpx import ASGITransport, AsyncClient

from platform_commons.auth_middleware import (
    AuthContext,
    DualAuthMiddleware,
    get_deprecated_auth_count,
)
from platform_commons.exceptions import PlatformError
from platform_commons.jwt_middleware import JWKSClient, JWTValidator


def _generate_keypair() -> Any:
    from cryptography.hazmat.primitives.asymmetric import rsa  # noqa: PLC0415

    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def _b64url(val: int) -> str:
    bl = (val.bit_length() + 7) // 8
    return base64.urlsafe_b64encode(val.to_bytes(bl, "big")).rstrip(b"=").decode()


def _make_jwk(pk: Any, kid: str) -> dict[str, str]:
    pub = pk.public_key().public_numbers()
    return {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": kid,
        "n": _b64url(pub.n),
        "e": _b64url(pub.e),
    }


class FakeJWKSClient(JWKSClient):
    def __init__(self, keys: dict[str, dict[str, str]]) -> None:
        super().__init__("http://fake/auth/jwks")
        self._keys = keys  # type: ignore[assignment]
        self._cached_at = time.monotonic()

    async def _fetch_jwks(self) -> None:
        self._cached_at = time.monotonic()


def _sign_token(pk: Any, claims: dict[str, Any], kid: str) -> str:
    return pyjwt.encode(claims, pk, algorithm="RS256", headers={"kid": kid})


KID = "key_dual_test"


async def _test_service_key_validator(key: str) -> tuple[str, list[str]]:
    valid_keys: dict[str, tuple[str, list[str]]] = {
        "sk_test_001": ("adm", ["workflow.read"]),
        "sk_test_002": ("router", ["execution.write"]),
    }
    if key not in valid_keys:
        raise PlatformError(
            code="AUTH_INVALID_SERVICE_KEY",
            message="Unknown service key",
            status_code=401,
        )
    return valid_keys[key]


@pytest.fixture
def rsa_keypair() -> Any:
    return _generate_keypair()


@pytest.fixture
def jwt_validator(rsa_keypair: Any) -> JWTValidator:
    jwk = _make_jwk(rsa_keypair, KID)
    client = FakeJWKSClient({KID: jwk})
    return JWTValidator(client, accepted_audiences=["ai-platform"])


@pytest.fixture
def valid_token(rsa_keypair: Any) -> str:
    now = int(time.time())
    claims = {
        "iss": "auth-rbac",
        "aud": "ai-platform",
        "sub": "service:adm",
        "scopes": ["workflow.read", "workflow.write"],
        "iat": now,
        "exp": now + 3600,
        "jti": "jwt_dual_test",
    }
    return _sign_token(rsa_keypair, claims, KID)


@pytest.fixture
async def client(jwt_validator: JWTValidator) -> AsyncClient:
    app = FastAPI()
    app.add_middleware(
        DualAuthMiddleware,
        jwt_validator=jwt_validator,
        service_key_validator=_test_service_key_validator,
        exclude_paths=["/health", "/ready", "/auth/jwks"],
    )

    @app.get("/api/v1/test")
    async def test_endpoint(request: Request) -> dict[str, Any]:
        ctx: AuthContext = request.state.auth_context
        return {"method": ctx.method, "subject": ctx.subject, "scopes": ctx.scopes}

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


class TestBearerJWT:
    async def test_valid_jwt_authenticates(self, client: AsyncClient, valid_token: str) -> None:
        r = await client.get("/api/v1/test", headers={"Authorization": f"Bearer {valid_token}"})
        assert r.status_code == 200
        data = r.json()
        assert data["method"] == "jwt"
        assert data["subject"] == "service:adm"
        assert "workflow.read" in data["scopes"]

    async def test_expired_jwt_returns_401(self, client: AsyncClient, rsa_keypair: Any) -> None:
        claims = {
            "iss": "auth-rbac",
            "aud": "ai-platform",
            "sub": "service:x",
            "scopes": [],
            "iat": int(time.time()) - 200,
            "exp": int(time.time()) - 100,
            "jti": "x",
        }
        token = _sign_token(rsa_keypair, claims, KID)
        r = await client.get("/api/v1/test", headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 401
        assert r.json()["error"]["code"] == "AUTH_TOKEN_EXPIRED"


class TestServiceKey:
    async def test_valid_service_key_authenticates(self, client: AsyncClient) -> None:
        r = await client.get("/api/v1/test", headers={"X-Service-Key": "sk_test_001"})
        assert r.status_code == 200
        data = r.json()
        assert data["method"] == "service_key"
        assert data["subject"] == "adm"

    async def test_invalid_service_key_returns_401(self, client: AsyncClient) -> None:
        r = await client.get("/api/v1/test", headers={"X-Service-Key": "sk_invalid"})
        assert r.status_code == 401

    async def test_deprecation_counter_increments(self, client: AsyncClient) -> None:
        before = get_deprecated_auth_count()
        await client.get("/api/v1/test", headers={"X-Service-Key": "sk_test_001"})
        assert get_deprecated_auth_count() > before


class TestNoAuth:
    async def test_no_auth_returns_401(self, client: AsyncClient) -> None:
        r = await client.get("/api/v1/test")
        assert r.status_code == 401
        assert r.json()["error"]["code"] == "AUTH_MISSING"


class TestPreference:
    async def test_both_present_prefers_jwt(self, client: AsyncClient, valid_token: str) -> None:
        r = await client.get(
            "/api/v1/test",
            headers={
                "Authorization": f"Bearer {valid_token}",
                "X-Service-Key": "sk_test_001",
            },
        )
        assert r.status_code == 200
        assert r.json()["method"] == "jwt"


class TestExcludePaths:
    async def test_health_excluded(self, client: AsyncClient) -> None:
        r = await client.get("/health")
        assert r.status_code == 200

    async def test_protected_path_requires_auth(self, client: AsyncClient) -> None:
        r = await client.get("/api/v1/test")
        assert r.status_code == 401
