"""Tests for JWT validation middleware."""

from __future__ import annotations

import base64
import time
from typing import Any

import jwt as pyjwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from jwt import PyJWK

from platform_commons.exceptions import PlatformError
from platform_commons.jwt_middleware import (
    JWKSClient,
    JWTValidator,
    _extract_bearer_token,
)
from platform_commons.jwt_models import JWTClaims


def _generate_test_keypair() -> Any:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def _b64url(val: int) -> str:
    bl = (val.bit_length() + 7) // 8
    return base64.urlsafe_b64encode(val.to_bytes(bl, "big")).rstrip(b"=").decode()


def _make_jwk(private_key: Any, kid: str) -> dict[str, str]:
    pub = private_key.public_key()
    numbers = pub.public_numbers()
    return {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": kid,
        "n": _b64url(numbers.n),
        "e": _b64url(numbers.e),
    }


def _sign_token(private_key: Any, claims: dict[str, Any], kid: str) -> str:
    return pyjwt.encode(claims, private_key, algorithm="RS256", headers={"kid": kid})


class FakeJWKSClient(JWKSClient):
    """JWKSClient that uses local keys instead of HTTP fetch."""

    def __init__(self, keys: dict[str, dict[str, str]]) -> None:
        super().__init__("http://fake/auth/jwks")
        self._keys = keys  # type: ignore[assignment]
        self._cached_at = time.monotonic()

    async def _fetch_jwks(self) -> None:
        self._cached_at = time.monotonic()


@pytest.fixture
def rsa_keypair() -> Any:
    return _generate_test_keypair()


@pytest.fixture
def kid() -> str:
    return "key_test_001"


@pytest.fixture
def jwks_client(rsa_keypair: Any, kid: str) -> FakeJWKSClient:
    jwk = _make_jwk(rsa_keypair, kid)
    return FakeJWKSClient({kid: jwk})


@pytest.fixture
def validator(jwks_client: FakeJWKSClient) -> JWTValidator:
    return JWTValidator(jwks_client, accepted_audiences=["ai-platform"])


@pytest.fixture
def valid_claims() -> dict[str, Any]:
    now = int(time.time())
    return {
        "iss": "auth-rbac",
        "aud": "ai-platform",
        "sub": "service:adm",
        "scopes": ["router.executions.create", "router.executions.read"],
        "iat": now,
        "exp": now + 3600,
        "jti": "jwt_test001",
    }


class TestExtractBearerToken:
    def test_valid_bearer(self) -> None:
        assert _extract_bearer_token("Bearer abc123") == "abc123"

    def test_missing_header(self) -> None:
        with pytest.raises(PlatformError, match="Authorization header required"):
            _extract_bearer_token(None)

    def test_malformed_header(self) -> None:
        with pytest.raises(PlatformError, match="Bearer"):
            _extract_bearer_token("Basic abc123")


class TestJWTValidator:
    async def test_valid_token(
        self, validator: JWTValidator, rsa_keypair: Any, valid_claims: dict[str, Any], kid: str
    ) -> None:
        token = _sign_token(rsa_keypair, valid_claims, kid)
        claims = await validator.validate(token)
        assert claims.iss == "auth-rbac"
        assert claims.sub == "service:adm"
        assert claims.scopes == ["router.executions.create", "router.executions.read"]

    async def test_expired_token(
        self, validator: JWTValidator, rsa_keypair: Any, valid_claims: dict[str, Any], kid: str
    ) -> None:
        valid_claims["exp"] = int(time.time()) - 100
        token = _sign_token(rsa_keypair, valid_claims, kid)
        with pytest.raises(PlatformError) as exc_info:
            await validator.validate(token)
        assert exc_info.value.status_code == 401
        assert exc_info.value.code == "AUTH_TOKEN_EXPIRED"

    async def test_wrong_audience(
        self, validator: JWTValidator, rsa_keypair: Any, valid_claims: dict[str, Any], kid: str
    ) -> None:
        valid_claims["aud"] = "wrong-service"
        token = _sign_token(rsa_keypair, valid_claims, kid)
        with pytest.raises(PlatformError) as exc_info:
            await validator.validate(token)
        assert exc_info.value.status_code == 401
        assert exc_info.value.code == "AUTH_INVALID_AUDIENCE"

    async def test_wrong_issuer(
        self, validator: JWTValidator, rsa_keypair: Any, valid_claims: dict[str, Any], kid: str
    ) -> None:
        valid_claims["iss"] = "wrong-issuer"
        token = _sign_token(rsa_keypair, valid_claims, kid)
        with pytest.raises(PlatformError) as exc_info:
            await validator.validate(token)
        assert exc_info.value.status_code == 401
        assert exc_info.value.code == "AUTH_INVALID_ISSUER"

    async def test_unknown_kid(self, rsa_keypair: Any, valid_claims: dict[str, Any]) -> None:
        empty_client = FakeJWKSClient({})
        v = JWTValidator(empty_client, accepted_audiences=["ai-platform"])
        token = _sign_token(rsa_keypair, valid_claims, "key_unknown")
        with pytest.raises(PlatformError) as exc_info:
            await v.validate(token)
        assert exc_info.value.status_code == 401
        assert exc_info.value.code == "AUTH_INVALID_TOKEN"

    async def test_malformed_token(self, validator: JWTValidator) -> None:
        with pytest.raises(PlatformError) as exc_info:
            await validator.validate("not.a.jwt")
        assert exc_info.value.status_code == 401

    async def test_returns_jwt_claims_dataclass(
        self, validator: JWTValidator, rsa_keypair: Any, valid_claims: dict[str, Any], kid: str
    ) -> None:
        token = _sign_token(rsa_keypair, valid_claims, kid)
        claims = await validator.validate(token)
        assert isinstance(claims, JWTClaims)
        assert claims.jti == "jwt_test001"


class TestJWKSCache:
    async def test_cache_hit(self, jwks_client: FakeJWKSClient, kid: str) -> None:
        key1 = await jwks_client.get_signing_key(kid)
        key2 = await jwks_client.get_signing_key(kid)
        assert isinstance(key1, PyJWK)
        assert isinstance(key2, PyJWK)

    async def test_cache_expired(self, jwks_client: FakeJWKSClient) -> None:
        jwks_client._cached_at = time.monotonic() - 400
        assert not jwks_client._is_cache_valid()


class TestMultiIssuer:
    """Tests for accepted_issuers support in JWTValidator."""

    async def test_valid_capability_token(
        self,
        jwks_client: FakeJWKSClient,
        rsa_keypair: Any,
        kid: str,
    ) -> None:
        v = JWTValidator(
            jwks_client,
            accepted_audiences=["ai-platform", "workers.platform.local"],
            accepted_issuers=["auth-rbac", "auth-rbac.platform.local"],
        )
        now = int(time.time())
        claims = {
            "iss": "auth-rbac.platform.local",
            "aud": ["workers.platform.local"],
            "sub": "task_001",
            "task_id": "task_001",
            "agent_role": "analyst",
            "org_id": "org_1",
            "membership_id": "mbr_1",
            "scopes": ["rag.decisions.read"],
            "iat": now,
            "exp": now + 3600,
            "jti": "cap_001",
        }
        token = _sign_token(rsa_keypair, claims, kid)
        result = await v.validate(token)
        assert result.iss == "auth-rbac.platform.local"
        assert result.task_id == "task_001"
        assert result.agent_role == "analyst"

    async def test_accepted_issuers_backward_compat(
        self,
        jwks_client: FakeJWKSClient,
        rsa_keypair: Any,
        valid_claims: dict[str, Any],
        kid: str,
    ) -> None:
        v = JWTValidator(jwks_client, accepted_audiences=["ai-platform"])
        token = _sign_token(rsa_keypair, valid_claims, kid)
        result = await v.validate(token)
        assert result.iss == "auth-rbac"

    async def test_capability_token_rejected_by_old_validator(
        self,
        jwks_client: FakeJWKSClient,
        rsa_keypair: Any,
        kid: str,
    ) -> None:
        v = JWTValidator(
            jwks_client,
            accepted_audiences=["ai-platform", "workers.platform.local"],
        )
        now = int(time.time())
        claims = {
            "iss": "auth-rbac.platform.local",
            "aud": ["workers.platform.local"],
            "sub": "task_001",
            "scopes": [],
            "iat": now,
            "exp": now + 3600,
            "jti": "cap_002",
        }
        token = _sign_token(rsa_keypair, claims, kid)
        with pytest.raises(PlatformError) as exc_info:
            await v.validate(token)
        assert exc_info.value.code == "AUTH_INVALID_ISSUER"
