"""Tests for platform HTTP client with trace propagation."""

from __future__ import annotations

from platform_commons.http_client import get_trace_headers
from platform_commons.trace_middleware import TraceContext, trace_context


def test_get_trace_headers_without_context() -> None:
    """Without active trace context, only X-Request-Id is generated."""
    headers = get_trace_headers()
    assert "X-Request-Id" in headers
    assert headers["X-Request-Id"].startswith("req_")
    assert "X-Trace-Id" not in headers


def test_get_trace_headers_with_context() -> None:
    """With active trace context, both headers are present."""
    ctx = TraceContext(trace_id="trace_test1", request_id="req_orig")
    token = trace_context.set(ctx)
    try:
        headers = get_trace_headers()
        assert headers["X-Trace-Id"] == "trace_test1"
        assert headers["X-Request-Id"].startswith("req_")
        # Request-Id should be NEW (not the original)
        assert headers["X-Request-Id"] != "req_orig"
    finally:
        trace_context.reset(token)


def test_get_trace_headers_generates_unique_request_ids() -> None:
    """Each call generates a unique X-Request-Id."""
    ctx = TraceContext(trace_id="trace_uniq", request_id="req_orig")
    token = trace_context.set(ctx)
    try:
        ids = {get_trace_headers()["X-Request-Id"] for _ in range(10)}
        assert len(ids) == 10  # All unique
    finally:
        trace_context.reset(token)
