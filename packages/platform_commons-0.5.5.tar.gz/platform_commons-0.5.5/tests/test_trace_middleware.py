"""Tests for PlatformTracingMiddleware."""

from __future__ import annotations

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from platform_commons.trace_middleware import (
    PlatformTracingMiddleware,
    get_trace_context,
)


def _create_app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(PlatformTracingMiddleware)

    @app.get("/echo")
    async def echo() -> dict:
        ctx = get_trace_context()
        return {
            "trace_id": ctx.trace_id if ctx else None,
            "request_id": ctx.request_id if ctx else None,
        }

    return app


@pytest.fixture
async def client() -> AsyncClient:
    app = _create_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


async def test_generates_trace_id_when_absent(client: AsyncClient) -> None:
    resp = await client.get("/echo")
    assert resp.status_code == 200
    assert resp.headers["x-trace-id"].startswith("trace_")
    assert resp.json()["trace_id"].startswith("trace_")


async def test_preserves_incoming_trace_id(client: AsyncClient) -> None:
    resp = await client.get("/echo", headers={"X-Trace-Id": "trace_incoming"})
    assert resp.headers["x-trace-id"] == "trace_incoming"
    assert resp.json()["trace_id"] == "trace_incoming"


async def test_generates_request_id_when_absent(client: AsyncClient) -> None:
    resp = await client.get("/echo")
    assert resp.status_code == 200
    assert resp.headers["x-request-id"].startswith("req_")
    assert resp.json()["request_id"].startswith("req_")


async def test_preserves_incoming_request_id(client: AsyncClient) -> None:
    resp = await client.get("/echo", headers={"X-Request-Id": "req_incoming"})
    assert resp.headers["x-request-id"] == "req_incoming"
    assert resp.json()["request_id"] == "req_incoming"


async def test_context_headers_in_request_state() -> None:
    """Context headers are extracted into request.state."""
    app = FastAPI()
    app.add_middleware(PlatformTracingMiddleware)

    @app.get("/state-check")
    async def state_check() -> dict[str, bool]:
        return {"ok": True}

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        resp = await c.get(
            "/state-check",
            headers={
                "X-Trace-Id": "trace_t1",
                "X-Execution-Id": "exec_e1",
                "X-Task-Id": "task_t1",
                "X-Org-Id": "org_o1",
            },
        )
    assert resp.status_code == 200
    assert resp.headers["x-trace-id"] == "trace_t1"


async def test_contextvars_set_during_request(client: AsyncClient) -> None:
    """TraceContext is available via get_trace_context() during request."""
    resp = await client.get(
        "/echo",
        headers={"X-Trace-Id": "trace_cv1", "X-Request-Id": "req_cv1"},
    )
    body = resp.json()
    assert body["trace_id"] == "trace_cv1"
    assert body["request_id"] == "req_cv1"


async def test_contextvars_reset_after_request() -> None:
    """TraceContext is reset after request completes."""
    assert get_trace_context() is None
