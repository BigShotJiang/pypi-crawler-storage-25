"""Tests for CapabilityScopeMiddleware and ScopeRegistry."""

from __future__ import annotations

import base64
import logging
import time
from typing import Any

import jwt as pyjwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from httpx import ASGITransport, AsyncClient

from platform_commons.auth_middleware import DualAuthMiddleware
from platform_commons.jwt_middleware import JWKSClient, JWTValidator
from platform_commons.scope_middleware import CapabilityScopeMiddleware, ScopeRegistry


def _generate_test_keypair() -> Any:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def _b64url(val: int) -> str:
    bl = (val.bit_length() + 7) // 8
    return base64.urlsafe_b64encode(val.to_bytes(bl, "big")).rstrip(b"=").decode()


def _make_jwk(private_key: Any, kid: str) -> dict[str, str]:
    pub = private_key.public_key()
    numbers = pub.public_numbers()
    return {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": kid,
        "n": _b64url(numbers.n),
        "e": _b64url(numbers.e),
    }


def _sign_token(private_key: Any, claims: dict[str, Any], kid: str) -> str:
    return pyjwt.encode(claims, private_key, algorithm="RS256", headers={"kid": kid})


class _FakeJWKS(JWKSClient):
    def __init__(self, keys: dict[str, dict[str, str]]) -> None:
        super().__init__("http://fake/jwks")
        self._keys = keys  # type: ignore[assignment]
        self._cached_at = time.monotonic()

    async def _fetch_jwks(self) -> None:
        self._cached_at = time.monotonic()


def _capability_token(pk: Any, kid: str, scopes: list[str]) -> str:
    now = int(time.time())
    return _sign_token(
        pk,
        {
            "iss": "auth-rbac.platform.local",
            "aud": ["workers.platform.local"],
            "sub": "task_001",
            "task_id": "task_001",
            "agent_role": "analyst",
            "org_id": "org_t",
            "membership_id": "mbr_t",
            "scopes": scopes,
            "iat": now,
            "exp": now + 3600,
            "jti": "cap_001",
        },
        kid,
    )


def _service_token(pk: Any, kid: str) -> str:
    now = int(time.time())
    return _sign_token(
        pk,
        {
            "iss": "auth-rbac",
            "aud": "ai-platform",
            "sub": "service:router",
            "scopes": ["workflow.read"],
            "iat": now,
            "exp": now + 3600,
            "jti": "svc_001",
        },
        kid,
    )


def _test_app(pk: Any, kid: str) -> FastAPI:
    app = FastAPI()
    jwk = _make_jwk(pk, kid)
    jwks = _FakeJWKS({kid: jwk})
    validator = JWTValidator(
        jwks,
        accepted_audiences=["ai-platform", "workers.platform.local"],
        accepted_issuers=["auth-rbac", "auth-rbac.platform.local"],
    )
    registry = ScopeRegistry(
        [
            ("GET", r"/api/v1/decisions(/.*)?$", "rag.decisions.read"),
            ("POST", r"/api/v1/decisions(/.*)?$", "rag.decisions.write"),
            ("PUT", r"/api/v1/versions/[^/]+/promote$", "pl.versions.promote"),
            ("PUT", r"/api/v1/versions(/.*)?$", "pl.versions.write"),
            ("GET", r"/api/v1/processes(/.*)?$", "pl.processes.read"),
        ]
    )
    app.add_middleware(CapabilityScopeMiddleware, scope_registry=registry)
    app.add_middleware(
        DualAuthMiddleware,
        jwt_validator=validator,
        service_key_validator=None,
        exclude_paths=["/health"],
    )

    @app.get("/health")
    async def health() -> JSONResponse:
        return JSONResponse({"status": "ok"})

    @app.get("/api/v1/decisions")
    async def get_decisions(request: Request) -> JSONResponse:
        return JSONResponse({"items": []})

    @app.post("/api/v1/decisions")
    async def post_decision(request: Request) -> JSONResponse:
        return JSONResponse({"id": "d1"}, status_code=201)

    @app.put("/api/v1/versions/v1/promote")
    async def promote(request: Request) -> JSONResponse:
        return JSONResponse({"status": "promoted"})

    @app.put("/api/v1/versions/v1")
    async def update_version(request: Request) -> JSONResponse:
        return JSONResponse({"status": "updated"})

    @app.get("/api/v1/processes")
    async def get_processes(request: Request) -> JSONResponse:
        return JSONResponse({"items": []})

    @app.get("/api/v1/unregistered")
    async def unregistered(request: Request) -> JSONResponse:
        return JSONResponse({"ok": True})

    return app


@pytest.fixture()
def _keys() -> tuple[Any, str]:
    return _generate_test_keypair(), "key_scope_test"


@pytest.fixture()
async def client(_keys: tuple[Any, str]) -> AsyncClient:  # type: ignore[misc]
    pk, kid = _keys
    app = _test_app(pk, kid)
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c


# ── ScopeRegistry ────────────────────────────────────────────────────


def test_registry_exact_match() -> None:
    reg = ScopeRegistry([("GET", r"/api/v1/decisions$", "rag.decisions.read")])
    assert reg.get_required_scope("GET", "/api/v1/decisions") == "rag.decisions.read"


def test_registry_regex_match() -> None:
    reg = ScopeRegistry([("GET", r"/api/v1/decisions(/.*)?$", "rag.decisions.read")])
    assert reg.get_required_scope("GET", "/api/v1/decisions/123") == "rag.decisions.read"


def test_registry_method_mismatch() -> None:
    reg = ScopeRegistry([("POST", r"/api/v1/decisions$", "rag.decisions.write")])
    assert reg.get_required_scope("GET", "/api/v1/decisions") is None


def test_registry_wildcard_method() -> None:
    reg = ScopeRegistry([("*", r"/api/v1/anything$", "test.scope")])
    assert reg.get_required_scope("DELETE", "/api/v1/anything") == "test.scope"


def test_registry_no_match() -> None:
    reg = ScopeRegistry([("GET", r"/api/v1/decisions$", "rag.decisions.read")])
    assert reg.get_required_scope("GET", "/api/v1/unknown") is None


def test_registry_first_match_wins() -> None:
    reg = ScopeRegistry(
        [
            ("PUT", r"/api/v1/versions/[^/]+/promote$", "pl.versions.promote"),
            ("PUT", r"/api/v1/versions(/.*)?$", "pl.versions.write"),
        ]
    )
    assert reg.get_required_scope("PUT", "/api/v1/versions/v1/promote") == "pl.versions.promote"


def test_registry_duplicate_warning(caplog: pytest.LogCaptureFixture) -> None:
    with caplog.at_level(logging.WARNING):
        ScopeRegistry(
            [
                ("GET", r"/api/v1/test$", "scope.a"),
                ("GET", r"/api/v1/test$", "scope.b"),
            ]
        )
    assert "Duplicate scope route" in caplog.text


def test_registry_empty() -> None:
    reg = ScopeRegistry([])
    assert reg.get_required_scope("GET", "/api/v1/anything") is None


# ── CapabilityScopeMiddleware integration ────────────────────────────


async def test_capability_token_valid_scope_passes(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _capability_token(pk, kid, ["rag.decisions.read"])
    r = await client.get("/api/v1/decisions", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200


async def test_capability_token_insufficient_scope_403(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _capability_token(pk, kid, ["rag.decisions.read"])
    r = await client.post("/api/v1/decisions", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 403
    body = r.json()
    assert body["error"]["code"] == "INSUFFICIENT_SCOPE"
    assert body["error"]["details"]["required_scope"] == "rag.decisions.write"


async def test_capability_token_hierarchy_expansion(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _capability_token(pk, kid, ["rag.decisions.write"])
    r = await client.get("/api/v1/decisions", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200


async def test_service_token_bypasses_scope(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _service_token(pk, kid)
    r = await client.post("/api/v1/decisions", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 201


async def test_no_scope_required_passes(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _capability_token(pk, kid, ["rag.decisions.read"])
    r = await client.get("/api/v1/unregistered", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200


async def test_public_route_bypasses_all(client: AsyncClient) -> None:
    r = await client.get("/health")
    assert r.status_code == 200


async def test_403_includes_expanded_scopes(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _capability_token(pk, kid, ["rag.artifacts.read"])
    r = await client.post("/api/v1/decisions", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 403
    details = r.json()["error"]["details"]
    assert "required_scope" in details
    assert "available_scopes" in details
    assert "expanded_scopes" in details


async def test_promote_scope_hierarchy(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _capability_token(pk, kid, ["pl.versions.promote"])
    r = await client.put("/api/v1/versions/v1", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200


async def test_promote_does_not_grant_process_read(
    client: AsyncClient,
    _keys: tuple[Any, str],
) -> None:
    pk, kid = _keys
    token = _capability_token(pk, kid, ["pl.versions.promote"])
    r = await client.get("/api/v1/processes", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 403


async def test_missing_auth_401(client: AsyncClient) -> None:
    r = await client.get("/api/v1/decisions")
    assert r.status_code == 401
