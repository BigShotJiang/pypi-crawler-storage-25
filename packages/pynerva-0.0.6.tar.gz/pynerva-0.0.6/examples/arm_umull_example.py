#!/usr/bin/env python3
"""
UMULL Instruction Example

This example demonstrates the use of the UMULL (Unsigned Multiply Long) instruction
in ARM assembly. UMULL multiplies two 32-bit unsigned values and produces a 64-bit result.

Syntax: UMULL RdLo, RdHi, Rn, Rm
Where:
  - RdLo: Destination register for the lower 32 bits of the result
  - RdHi: Destination register for the upper 32 bits of the result
  - Rn: First 32-bit operand
  - Rm: Second 32-bit operand
  
Result: {RdHi, RdLo} = Rn * Rm (unsigned 64-bit result)
"""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.generic import UMULL
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture


def umull_example():
    """Example function that uses UMULL to compute a 64-bit multiplication result."""
    print("=== UMULL (Unsigned Multiply Long) Example ===\n")
    
    # Function arguments: two 32-bit unsigned integers
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("multiply_64bit", 
                 (a_arg, b_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        # Load arguments into registers
        (a, b, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Perform unsigned multiply long
        # This multiplies two 32-bit values (a and b) and produces a 64-bit result
        # The lower 32 bits go to r4, the upper 32 bits go to r5
        UMULL(r4, r5, a, b)
        
        # Store the lower 32 bits of the result
        STR(r4, [result_low_ptr])
        
        # Store the upper 32 bits of the result
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print("Generated GAS (GNU Assembler) format:\n")
    print(function.assembly)
    print("\n" + "="*60 + "\n")
    
    return function


def umull_multiple_example():
    """Example showing multiple UMULL operations."""
    print("=== Multiple UMULL Operations Example ===\n")
    
    # Function to compute a*b + c*d (64-bit result)
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    c_arg = Argument(uint32_t, name='c')
    d_arg = Argument(uint32_t, name='d')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("multiply_and_add_64bit",
                 (a_arg, b_arg, c_arg, d_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        # Load arguments
        (a, b, c, d, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Compute a * b (64-bit result in r6:r4)
        UMULL(r4, r6, a, b)
        
        # Compute c * d (64-bit result in r7:r5)
        UMULL(r5, r7, c, d)
        
        # Add the two 64-bit results
        # Add lower 32-bit parts
        ADDS(r4, r4, r5)
        
        # Add upper 32-bit parts with carry
        ADC(r6, r6, r7)
        
        # Store results
        STR(r4, [result_low_ptr])
        STR(r6, [result_high_ptr])
        
        RETURN()
    
    print("Generated GAS (GNU Assembler) format:\n")
    print(function.assembly)
    print("\n" + "="*60 + "\n")
    
    return function


def main():
    """Run all UMULL examples."""
    print("\n" + "="*60)
    print("ARM UMULL (Unsigned Multiply Long) Instruction Examples")
    print("="*60 + "\n")
    
    # Example 1: Basic UMULL usage
    umull_example()
    
    # Example 2: Multiple UMULL operations
    umull_multiple_example()
    
    print("Examples completed successfully!")
    print("\nNote: UMULL is available in ARMv4 and later architectures.")
    print("It's useful for computing large products without overflow.")


if __name__ == "__main__":
    main()
