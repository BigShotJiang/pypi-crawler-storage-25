#!/usr/bin/env python3
"""
Example: Using ConstantData for automatic .data section generation

This demonstrates the new ConstantData class that automatically generates
.data sections for constants in NervaPy ARM functions.
"""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.constant_data import ConstantData, install_constant_data_support

# Enable automatic .data section generation
install_constant_data_support()

# Define function that uses constants
result_arg = Argument(ptr(uint32_t), name='result')

with Function("use_constants", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as function:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Create constants - they automatically register with the function
    magic_number = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")
    buffer_size = ConstantData.uint32(256, name="BUFFER_SIZE")
    lookup_table = ConstantData.uint32x4(100, 200, 300, 400, name="LOOKUP_TABLE")
    
    print(f"Created constant '{magic_number.get_label()}' with value 0x{magic_number.data[0]:08X}")
    print(f"Created constant '{buffer_size.get_label()}' with value {buffer_size.data[0]}")
    print(f"Created array '{lookup_table.get_label()}' with {len(lookup_table.data)} elements")
    
    # Use the values in code
    # Note: We build 0x11111111 with instructions (more efficient than loading)
    MOV(r0, 0x11)
    ORR(r0, r0, r0.LSL(8))
    ORR(r0, r0, r0.LSL(16))
    
    # Add buffer size
    MOV(r1, buffer_size.data[0])
    ADD(r0, r0, r1)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

# Print generated assembly with automatic .data section
print("\nGenerated Assembly:")
print("=" * 70)
print(function.assembly)
print("=" * 70)

# Save to file
with open("use_constants.s", "w") as f:
    f.write(function.assembly)
print("\n✓ Saved to use_constants.s")

# Show how to use from C
print("\nTo use from C code:")
print("-" * 70)
print("""
// C code (test.c)
#include <stdio.h>
#include <stdint.h>

extern void use_constants(uint32_t *result);
extern uint32_t MAGIC_NUMBER;
extern uint32_t BUFFER_SIZE;
extern uint32_t LOOKUP_TABLE[];

int main() {
    uint32_t result;
    
    use_constants(&result);
    printf("Result: 0x%08X\\n", result);
    
    printf("Magic: 0x%08X\\n", MAGIC_NUMBER);
    printf("Buffer Size: %u\\n", BUFFER_SIZE);
    printf("Lookup[0]: %u\\n", LOOKUP_TABLE[0]);
    
    return 0;
}

// Compile:
// arm-linux-gnueabihf-gcc -c use_constants.s -o use_constants.o
// arm-linux-gnueabihf-gcc test.c use_constants.o -o test
// qemu-arm ./test
""")
