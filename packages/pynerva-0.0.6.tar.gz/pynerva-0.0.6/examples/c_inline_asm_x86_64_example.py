#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
x86-64 C Inline Assembly Generation Example

Demonstrates how to generate inline assembly for x86-64 that can be directly
embedded into C functions, avoiding function call overhead.

Supports:
- GCC/Clang (AT&T syntax)
- MSVC (note: MSVC x64 doesn't support inline asm, provides guidance)
"""

import sys
sys.path.insert(0, '/home/kris/repos/NervaPy')

from nervapy import *
from nervapy.x86_64 import *


def generate_vector_add_sse():
    """Generate SSE vector addition kernel."""
    x_arg = Argument(ptr(const_double_))
    y_arg = Argument(ptr(const_double_))
    z_arg = Argument(ptr(double_))
    n_arg = Argument(size_t)

    with Function("vector_add_sse", (x_arg, y_arg, z_arg, n_arg)) as asm_function:
        # Load function arguments
        x_ptr = GeneralPurposeRegister64()
        y_ptr = GeneralPurposeRegister64()
        z_ptr = GeneralPurposeRegister64()
        n = GeneralPurposeRegister64()

        LOAD.ARGUMENT(x_ptr, x_arg)
        LOAD.ARGUMENT(y_ptr, y_arg)
        LOAD.ARGUMENT(z_ptr, z_arg)
        LOAD.ARGUMENT(n, n_arg)

        # Process 2 doubles at a time with SSE
        with Loop() as loop:
            x_vec = XMMRegister()
            y_vec = XMMRegister()

            MOVUPD(x_vec, [x_ptr])
            MOVUPD(y_vec, [y_ptr])
            ADDPD(x_vec, y_vec)  # x_vec += y_vec
            MOVUPD([z_ptr], x_vec)

            ADD(x_ptr, 16)
            ADD(y_ptr, 16)
            ADD(z_ptr, 16)
            SUB(n, 2)
            JNZ(loop.begin)

        RETURN()

    # Bind to System V ABI (Linux, macOS, *BSD)
    from nervapy.x86_64.abi import system_v_x86_64_abi
    return asm_function.finalize(system_v_x86_64_abi)


def print_gcc_example(func):
    """Print complete C example with GCC inline assembly."""
    print("\n" + "=" * 70)
    print("GCC/Clang Inline Assembly (x86-64 AT&T Syntax)")
    print("=" * 70)
    print("""
/* example_gcc_x64.c */
#include <stddef.h>

/* Function with inline assembly - no function call overhead! */
void {func_name}_inline(const double *x, const double *y, double *z, size_t n) {{
{inline_asm}
}}

/* Usage example */
int main(void) {{
    double x[100], y[100], z[100];
    size_t n = 100;
    
    /* Initialize arrays... */
    
    /* Inline version - no call overhead */
    {func_name}_inline(x, y, z, n);
    
    return 0;
}}

/* Compile with: */
/* gcc -msse2 -O2 example_gcc_x64.c -o example */
/* or for AVX: gcc -mavx2 -mfma -O2 example_gcc_x64.c -o example */
""".format(func_name=func.name, inline_asm=func.c_inline_asm_gcc))


def print_msvc_note(func):
    """Print MSVC inline assembly note."""
    print("\n" + "=" * 70)
    print("MSVC Inline Assembly Note (x86-64)")
    print("=" * 70)
    print("""
/* example_msvc_x64.c */
""")
    print(func.c_inline_asm_msvc)
    print("""
/* Instead, create a separate {func_name}.asm file and add to project */
""".format(func_name=func.name))


def compare_formats():
    """Compare inline assembly vs regular assembly."""
    print("\n" + "=" * 70)
    print("Performance Comparison: x86-64")
    print("=" * 70)
    print("""
Function Call Overhead (x86-64):
---------------------------------
- CALL instruction: ~5-15 cycles (depending on pipeline)
- Register saving (PUSH): 1-2 cycles per register
- Stack frame setup: 2-5 cycles
- Register restoration (POP): 1-2 cycles per register  
- RET instruction: ~5-15 cycles

Total: ~20-50 cycles per call (depending on complexity)

For a loop running 1000 times: 20,000-50,000 wasted cycles!

When to Use Inline Assembly (x86-64):
--------------------------------------
✅ Inner loops in performance-critical code
✅ SIMD operations (SSE, AVX) where overhead matters
✅ Crypto/hash algorithms
✅ Audio/video processing kernels

When to Use Regular Assembly Functions:
---------------------------------------
✅ Complex algorithms
✅ Code reused across multiple functions
✅ Easier debugging needed
✅ Call overhead is negligible

Note for MSVC:
--------------
MSVC x64 does NOT support inline assembly.
Alternatives:
1. Use compiler intrinsics (#include <immintrin.h>)
2. Create separate .asm files
3. Use GCC/Clang if possible
""")


if __name__ == "__main__":
    print("NervaPy - x86-64 C Inline Assembly Generation")
    print("=" * 70)
    print("Generate inline assembly for x86-64 processors")
    print("Supports GCC/Clang (MSVC requires separate .asm files)")
    
    print("\n\nGenerating SSE vector addition kernel...")
    vec_add = generate_vector_add_sse()
    
    # Show examples
    print_gcc_example(vec_add)
    print_msvc_note(vec_add)
    
    # Performance comparison
    compare_formats()
    
    print("\n" + "=" * 70)
    print("Examples completed successfully!")
    print("=" * 70)
    print("\nYou can now:")
    print("1. Copy the inline assembly into your C functions (GCC/Clang)")
    print("2. Adjust input/output constraints as needed")
    print("3. For MSVC, use separate .asm files or intrinsics")
    print("4. Compile with appropriate SIMD flags (-msse2, -mavx2, etc.)")
