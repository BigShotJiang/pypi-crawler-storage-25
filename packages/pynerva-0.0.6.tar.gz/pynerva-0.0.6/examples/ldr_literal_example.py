#!/usr/bin/env python3
"""
Example: Using LDR =label pseudo-instruction in NervaPy

This demonstrates the new LDR_LITERAL instruction that implements
the ARM assembler pseudo-instruction: LDR rd, =value

Features:
- Load 32-bit constants that can't be encoded in MOV
- Automatic literal pool generation
- Integration with ConstantData for .data section
- Works with both GAS and ARMCC formats
"""

import sys
sys.path.insert(0, '/home/kris/repos/NervaPy')

from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.constant_data import ConstantData, install_constant_data_support

# Enable ConstantData support
install_constant_data_support()

print("=" * 80)
print("LDR =label Pseudo-Instruction Examples")
print("=" * 80)
print()

# Example 1: Basic literal load
print("Example 1: Load a 32-bit constant")
print("-" * 80)

result_arg = Argument(ptr(uint32_t), name='result')

with Function("load_constant", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load 0x11111111 using LDR_LITERAL
    LDR_LITERAL(r0, 0x11111111)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

# Example 2: Multiple literals with deduplication
print("Example 2: Multiple literals (with automatic deduplication)")
print("-" * 80)

with Function("multiple_literals", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load different constants
    LDR_LITERAL(r0, 0x12345678)
    LDR_LITERAL(r1, 0xDEADBEEF)
    LDR_LITERAL(r2, 0x12345678)  # Same as r0 - will be deduplicated
    LDR_LITERAL(r3, 0xCAFEBABE)
    
    # Add them
    ADD(r0, r0, r1)
    ADD(r0, r0, r2)
    ADD(r0, r0, r3)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

# Example 3: Integration with ConstantData
print("Example 3: Load from ConstantData .data section")
print("-" * 80)

with Function("load_from_data", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Create constant in .data section
    MAGIC = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")
    CONFIG = ConstantData.uint32(0xC0FFEE00, name="CONFIG_VALUE")
    
    # Load from .data section using LDR_LITERAL
    LDR_LITERAL(r0, MAGIC)
    LDR_LITERAL(r1, CONFIG)
    
    # XOR them
    EOR(r0, r0, r1)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

# Example 4: Complex computation with literals
print("Example 4: Complex computation with multiple literals")
print("-" * 80)

with Function("complex_compute", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load constants
    LDR_LITERAL(r0, 0x11111111)  # Pattern
    LDR_LITERAL(r1, 0xFFFF0000)  # Mask
    LDR_LITERAL(r2, 0x22222222)  # Another pattern
    
    # Compute: (pattern & mask) | pattern2
    AND(r3, r0, r1)              # r3 = pattern & mask
    ORR(r0, r3, r2)              # r0 = r3 | r2
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

# Example 5: ARMCC format
print("Example 5: ARMCC format output")
print("-" * 80)

with Function("armcc_example", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.ARMCC,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load constant
    LDR_LITERAL(r0, 0xABCD1234)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

print("=" * 80)
print("Summary:")
print("  ✓ LDR_LITERAL(rd, value) generates LDR rd, =label")
print("  ✓ Automatic literal pool creation and management")
print("  ✓ Deduplication of identical literal values")
print("  ✓ Integration with ConstantData for .data section")
print("  ✓ Support for both GAS and ARMCC formats")
print("  ✓ Alias: LDRL() for convenience")
print("=" * 80)
