#!/usr/bin/env python3
"""
Example demonstrating ARMv7-M stack alignment validation.

This script shows how NervaPy validates 8-byte stack alignment
before BL and BLX instructions on ARMv7-M architecture.
"""

from nervapy.arm import Function, BL, BLX, BX, PUSH, POP, MOV
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.pseudo import IMPORT
from nervapy.arm.registers import r0, r4, r5, lr


def example_misaligned_stack():
    """Example showing misaligned stack error."""
    print("\n" + "=" * 70)
    print("Example 1: Misaligned Stack (Will Fail)")
    print("=" * 70)
    
    try:
        with Function("misaligned_example", (), None,
                      target=Microarchitecture.CortexM4,
                      abi=arm_gnueabi,
                      assembly_format=AssemblyFormat.GAS,
                      report_generation=False) as func:
            
            printf_func = IMPORT.FUNCTION("printf")
            
            # Prologue will push {r3, r4} = 8 bytes (aligned)
            # Push two registers = +8 bytes, total 16 (still aligned)
            PUSH((r4, r5))
            # Push one more register = +4 bytes, total 20 (MISALIGNED!)
            PUSH((r0,))
            
            # This will fail validation
            BL(printf_func)
            
            POP((r0,))
            POP((r4, r5))
            BX(lr)
        
        print("❌ ERROR: Should have failed validation!")
        
    except ValueError as e:
        print("✓ Validation correctly detected misalignment:")
        print(f"  {str(e)[:150]}...")


def example_aligned_stack():
    """Example showing properly aligned stack."""
    print("\n" + "=" * 70)
    print("Example 2: Aligned Stack (Will Pass)")
    print("=" * 70)
    
    try:
        with Function("aligned_example", (), None,
                      target=Microarchitecture.CortexM4,
                      abi=arm_gnueabi,
                      assembly_format=AssemblyFormat.GAS,
                      report_generation=False) as func:
            
            printf_func = IMPORT.FUNCTION("printf")
            
            # Prologue will push {r3, r4} = 8 bytes (aligned)
            # This pushes 8 more bytes = 16 bytes total (ALIGNED!)
            PUSH((r4, r5))
            
            # This will pass validation
            BL(printf_func)
            
            POP((r4, r5))
            BX(lr)
        
        print("✓ Validation passed! Generated assembly:")
        print()
        for line in func.assembly.split('\n'):
            if line.strip() and not line.startswith('.') and not line.startswith('L'):
                print(f"  {line}")
        
    except ValueError as e:
        print(f"❌ Unexpected error: {e}")


def example_blx_alignment():
    """Example showing BLX alignment validation."""
    print("\n" + "=" * 70)
    print("Example 3: BLX Alignment")
    print("=" * 70)
    
    try:
        with Function("blx_example", (), None,
                      target=Microarchitecture.CortexM4,
                      abi=arm_gnueabi,
                      assembly_format=AssemblyFormat.GAS,
                      report_generation=False) as func:
            
            # Load function pointer into r0
            MOV(r0, 0x1000)
            
            # Push even number of registers
            PUSH((r4, r5))
            
            # Call via register - must be aligned
            BLX(r0)
            
            POP((r4, r5))
            BX(lr)
        
        print("✓ BLX with aligned stack passed validation")
        
    except ValueError as e:
        print(f"❌ Unexpected error: {e}")


def example_multiple_calls():
    """Example with multiple function calls."""
    print("\n" + "=" * 70)
    print("Example 4: Multiple Function Calls")
    print("=" * 70)
    
    try:
        with Function("multi_call_example", (), None,
                      target=Microarchitecture.CortexM4,
                      abi=arm_gnueabi,
                      assembly_format=AssemblyFormat.GAS,
                      report_generation=False) as func:
            
            func1 = IMPORT.FUNCTION("function1")
            func2 = IMPORT.FUNCTION("function2")
            
            # First call - stack is aligned
            BL(func1)
            
            # Push 8 bytes - maintains alignment
            PUSH((r4, r5))
            
            # Second call - still aligned
            BL(func2)
            
            POP((r4, r5))
            BX(lr)
        
        print("✓ Multiple calls with proper alignment passed")
        
    except ValueError as e:
        print(f"❌ Unexpected error: {e}")


def example_non_armv7m():
    """Example showing validation is skipped for non-ARMv7M."""
    print("\n" + "=" * 70)
    print("Example 5: Non-ARMv7M Architecture (Validation Skipped)")
    print("=" * 70)
    
    try:
        # Cortex-A8 is ARMv7-A, not ARMv7-M
        with Function("cortex_a8_example", (), None,
                      target=Microarchitecture.CortexA8,
                      abi=arm_gnueabi,
                      assembly_format=AssemblyFormat.GAS,
                      report_generation=False) as func:
            
            func1 = IMPORT.FUNCTION("some_function")
            
            # This would fail on ARMv7-M, but not on ARMv7-A
            PUSH((r4,))
            BL(func1)
            POP((r4,))
            BX(lr)
        
        print("✓ Validation skipped for Cortex-A8 (ARMv7-A)")
        print("  Stack alignment is still recommended but not enforced")
        
    except ValueError as e:
        print(f"ℹ Note: {e}")


if __name__ == "__main__":
    print("\n╔══════════════════════════════════════════════════════════════════════╗")
    print("║       ARMv7-M Stack Alignment Validation Examples                    ║")
    print("╚══════════════════════════════════════════════════════════════════════╝")
    
    example_misaligned_stack()
    example_aligned_stack()
    example_blx_alignment()
    example_multiple_calls()
    example_non_armv7m()
    
    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)
    print("✓ ARMv7-M requires 8-byte stack alignment before BL/BLX")
    print("✓ NervaPy automatically validates this requirement")
    print("✓ Fix misalignment by pushing even numbers of registers")
    print("✓ Validation only applies to ARMv7-M (Cortex-M3/M4/M7)")
    print()
