#!/usr/bin/env python3
"""
ARM Multiply Instructions Example

This example demonstrates various ARM multiply instructions:
- Basic multiply: MUL, MLA, MLS
- DSP halfword multiply: SMULTBEQ, SMLABBNE, SMLABT
- Most Significant Word: SMMUL, SMMLA, SMMLS
- SIMD dual multiply: SMLAD, SMLSD, SMLALD, SMLSLD
- WMMX instructions: MIA, MIAPH
"""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.generic import (MUL, MLA, MLS, SMULTBEQ, SMLABBNE, SMLABT,
                                  SMMUL, SMMLA, SMMLS, SMLAD, SMLSD,
                                  SMLALD, SMLSLD, MIA, MIAPH)
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture


def test_basic_multiply():
    """Test MUL, MLA, MLS - Basic 32-bit multiply instructions"""
    print("=== Basic Multiply Instructions ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    c_arg = Argument(uint32_t, name='c')
    result_arg = Argument(ptr(uint32_t), name='result')
    
    with Function("test_basic_multiply",
                 (a_arg, b_arg, c_arg, result_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, c, result_ptr) = LOAD.ARGUMENTS()
        
        # MUL: r4 = a * b
        MUL(r4, a, b)
        STR(r4, [result_ptr])
        
        # MLA: r5 = (a * b) + c
        MLA(r5, a, b, c)
        STR(r5, [result_ptr, 4])
        
        # MLS: r6 = c - (a * b)
        MLS(r6, a, b, c)
        STR(r6, [result_ptr, 8])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_dsp_halfword_multiply():
    """Test DSP halfword multiply instructions"""
    print("=== DSP Halfword Multiply Instructions ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    c_arg = Argument(uint32_t, name='c')
    result_arg = Argument(ptr(uint32_t), name='result')
    
    with Function("test_dsp_multiply",
                 (a_arg, b_arg, c_arg, result_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, c, result_ptr) = LOAD.ARGUMENTS()
        
        # Set condition flags for conditional instructions
        CMP(a, b)
        
        # SMULTBEQ: if EQ, r4 = a[31:16] * b[15:0] (signed, top×bottom)
        SMULTBEQ(r4, a, b)
        STR(r4, [result_ptr])
        
        # SMLABBNE: if NE, r5 = (a[15:0] * b[15:0]) + c (signed, bottom×bottom)
        SMLABBNE(r5, a, b, c)
        STR(r5, [result_ptr, 4])
        
        # SMLABT: r6 = (a[15:0] * b[31:16]) + c (signed, bottom×top)
        SMLABT(r6, a, b, c)
        STR(r6, [result_ptr, 8])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_msw_multiply():
    """Test Most Significant Word multiply instructions"""
    print("=== MSW Multiply Instructions ===\n")
    
    a_arg = Argument(int32_t, name='a')
    b_arg = Argument(int32_t, name='b')
    c_arg = Argument(int32_t, name='c')
    result_arg = Argument(ptr(uint32_t), name='result')
    
    with Function("test_msw_multiply",
                 (a_arg, b_arg, c_arg, result_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, c, result_ptr) = LOAD.ARGUMENTS()
        
        # SMMUL: r4 = (a * b)[63:32] (top 32 bits of signed product)
        SMMUL(r4, a, b)
        STR(r4, [result_ptr])
        
        # SMMLA: r5 = ((a * b)[63:32]) + c
        SMMLA(r5, a, b, c)
        STR(r5, [result_ptr, 4])
        
        # SMMLS: r6 = c - ((a * b)[63:32])
        SMMLS(r6, a, b, c)
        STR(r6, [result_ptr, 8])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_simd_dual_multiply():
    """Test SIMD dual multiply instructions"""
    print("=== SIMD Dual Multiply Instructions ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    c_arg = Argument(uint32_t, name='c')
    result_arg = Argument(ptr(uint32_t), name='result')
    
    with Function("test_simd_multiply",
                 (a_arg, b_arg, c_arg, result_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, c, result_ptr) = LOAD.ARGUMENTS()
        
        # SMLAD: r4 = (a[15:0] * b[15:0]) + (a[31:16] * b[31:16]) + c
        SMLAD(r4, a, b, c)
        STR(r4, [result_ptr])
        
        # SMLSD: r5 = (a[15:0] * b[15:0]) - (a[31:16] * b[31:16]) + c
        SMLSD(r5, a, b, c)
        STR(r5, [result_ptr, 4])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_simd_long_multiply():
    """Test SIMD long dual multiply instructions"""
    print("=== SIMD Long Dual Multiply Instructions ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    acc_low_arg = Argument(uint32_t, name='acc_low')
    acc_high_arg = Argument(uint32_t, name='acc_high')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_simd_long_multiply",
                 (a_arg, b_arg, acc_low_arg, acc_high_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, acc_low, acc_high, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Initialize accumulators
        MOV(r4, acc_low)
        MOV(r5, acc_high)
        
        # SMLALD: r5:r4 += (a[15:0] * b[15:0]) + (a[31:16] * b[31:16])
        SMLALD(r4, r5, a, b)
        
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        # Reset accumulators
        MOV(r6, acc_low)
        MOV(r7, acc_high)
        
        # SMLSLD: r7:r6 += (a[15:0] * b[15:0]) - (a[31:16] * b[31:16])
        SMLSLD(r6, r7, a, b)
        
        STR(r6, [result_low_ptr, 4])
        STR(r7, [result_high_ptr, 4])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_combined_example():
    """Example combining multiple multiply types"""
    print("=== Combined Example: FIR Filter Using Multiple Multiply Types ===\n")
    
    x_arg = Argument(uint32_t, name='x')
    y_arg = Argument(uint32_t, name='y')
    coeff_arg = Argument(uint32_t, name='coeff')
    result_arg = Argument(ptr(uint32_t), name='result')
    
    with Function("fir_filter_example",
                 (x_arg, y_arg, coeff_arg, result_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (x, y, coeff, result_ptr) = LOAD.ARGUMENTS()
        
        # Basic multiply for coefficient
        MUL(r4, x, coeff)
        
        # Multiply-accumulate for second term
        MLA(r5, y, coeff, r4)
        
        # Dual multiply for packed samples
        MOV(r6, 0)
        SMLAD(r7, x, y, r6)
        
        # Combine results
        ADD(r8, r5, r7)
        
        STR(r8, [result_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def main():
    """Run all multiply instruction examples"""
    print("\n" + "="*60)
    print("ARM Multiply Instructions Examples")
    print("="*60 + "\n")
    
    test_basic_multiply()
    test_dsp_halfword_multiply()
    test_msw_multiply()
    test_simd_dual_multiply()
    test_simd_long_multiply()
    test_combined_example()
    
    print("\nAll multiply instructions implemented successfully!")
    print("\nInstruction Categories:")
    print("  Basic:    MUL, MLA, MLS")
    print("  DSP:      SMULTBEQ, SMLABBNE, SMLABT")
    print("  MSW:      SMMUL, SMMLA, SMMLS")
    print("  SIMD:     SMLAD, SMLSD, SMLALD, SMLSLD")
    print("  WMMX:     MIA, MIAPH")


if __name__ == "__main__":
    main()
