#!/usr/bin/env python3
"""
Long Multiply Instructions Example

This example demonstrates all the long multiply instructions in ARM assembly:
- UMULL - Unsigned Multiply Long
- UMLAL - Unsigned Multiply Accumulate Long
- SMULL - Signed Multiply Long
- SMLAL - Signed Multiply Accumulate Long
- UMAAL - Unsigned Multiply Accumulate Accumulate Long
- UMAALGE - Conditional UMAAL (Greater or Equal)
"""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.generic import UMULL, UMLAL, SMULL, SMLAL, UMAAL, UMAALGE
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture


def test_umull():
    """Test UMULL - Unsigned Multiply Long"""
    print("=== UMULL (Unsigned Multiply Long) ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_umull", (a_arg, b_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # UMULL: r1:r0 = a * b (unsigned)
        UMULL(r4, r5, a, b)
        
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_umlal():
    """Test UMLAL - Unsigned Multiply Accumulate Long"""
    print("=== UMLAL (Unsigned Multiply Accumulate Long) ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    acc_low_arg = Argument(uint32_t, name='acc_low')
    acc_high_arg = Argument(uint32_t, name='acc_high')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_umlal", 
                 (a_arg, b_arg, acc_low_arg, acc_high_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, acc_low, acc_high, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Move accumulators to r4:r5
        MOV(r4, acc_low)
        MOV(r5, acc_high)
        
        # UMLAL: r5:r4 += a * b (unsigned)
        UMLAL(r4, r5, a, b)
        
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_smull():
    """Test SMULL - Signed Multiply Long"""
    print("=== SMULL (Signed Multiply Long) ===\n")
    
    a_arg = Argument(int32_t, name='a')
    b_arg = Argument(int32_t, name='b')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_smull", (a_arg, b_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # SMULL: r5:r4 = a * b (signed)
        SMULL(r4, r5, a, b)
        
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_smlal():
    """Test SMLAL - Signed Multiply Accumulate Long"""
    print("=== SMLAL (Signed Multiply Accumulate Long) ===\n")
    
    a_arg = Argument(int32_t, name='a')
    b_arg = Argument(int32_t, name='b')
    acc_low_arg = Argument(uint32_t, name='acc_low')
    acc_high_arg = Argument(uint32_t, name='acc_high')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_smlal", 
                 (a_arg, b_arg, acc_low_arg, acc_high_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, acc_low, acc_high, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Move accumulators to r4:r5
        MOV(r4, acc_low)
        MOV(r5, acc_high)
        
        # SMLAL: r5:r4 += a * b (signed)
        SMLAL(r4, r5, a, b)
        
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_umaal():
    """Test UMAAL - Unsigned Multiply Accumulate Accumulate Long"""
    print("=== UMAAL (Unsigned Multiply Accumulate Accumulate Long) ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    acc1_arg = Argument(uint32_t, name='acc1')
    acc2_arg = Argument(uint32_t, name='acc2')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_umaal", 
                 (a_arg, b_arg, acc1_arg, acc2_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, acc1, acc2, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Move accumulators to r4:r5
        MOV(r4, acc1)
        MOV(r5, acc2)
        
        # UMAAL: r5:r4 = (a * b) + r4 + r5 (unsigned)
        UMAAL(r4, r5, a, b)
        
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_umaalge():
    """Test UMAALGE - Conditional UMAAL (Greater or Equal)"""
    print("=== UMAALGE (Conditional UMAAL) ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    c_arg = Argument(uint32_t, name='c')
    acc1_arg = Argument(uint32_t, name='acc1')
    acc2_arg = Argument(uint32_t, name='acc2')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_umaalge", 
                 (a_arg, b_arg, c_arg, acc1_arg, acc2_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, c, acc1, acc2, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Move accumulators to r4:r5
        MOV(r4, acc1)
        MOV(r5, acc2)
        
        # Compare a with c
        CMP(a, c)
        
        # UMAALGE: if (a >= c) then r5:r4 = (a * b) + r4 + r5 (unsigned)
        UMAALGE(r4, r5, a, b)
        
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_combined_example():
    """Example combining multiple long multiply instructions"""
    print("=== Combined Example: Computing (a*b + c*d) using UMULL and UMLAL ===\n")
    
    a_arg = Argument(uint32_t, name='a')
    b_arg = Argument(uint32_t, name='b')
    c_arg = Argument(uint32_t, name='c')
    d_arg = Argument(uint32_t, name='d')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("combined_multiply",
                 (a_arg, b_arg, c_arg, d_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, c, d, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # First multiply: r5:r4 = a * b
        UMULL(r4, r5, a, b)
        
        # Second multiply with accumulate: r5:r4 += c * d
        UMLAL(r4, r5, c, d)
        
        # Store results
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def main():
    """Run all long multiply instruction examples"""
    print("\n" + "="*60)
    print("ARM Long Multiply Instructions Examples")
    print("="*60 + "\n")
    
    test_umull()
    test_umlal()
    test_smull()
    test_smlal()
    test_umaal()
    test_umaalge()
    test_combined_example()
    
    print("\nAll long multiply instructions implemented successfully!")
    print("\nInstructions:")
    print("  UMULL   - Unsigned Multiply Long")
    print("  UMLAL   - Unsigned Multiply Accumulate Long")
    print("  SMULL   - Signed Multiply Long")
    print("  SMLAL   - Signed Multiply Accumulate Long")
    print("  UMAAL   - Unsigned Multiply Accumulate Accumulate Long (ARMv6+)")
    print("  UMAALGE - Conditional UMAAL (Greater or Equal)")


if __name__ == "__main__":
    main()
