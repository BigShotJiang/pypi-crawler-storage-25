#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Example: Using PRESERVE8 directive with ARMCC assembly format.

The PRESERVE8 directive informs the assembler that the code preserves
8-byte stack alignment, which is required by the ARM EABI (Embedded ABI).
This is particularly important for ARMv7-M (Cortex-M) processors.
"""

import sys
import os
# Ensure we're using the local development version
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture


def example_without_preserve8():
    """Generate function without PRESERVE8 directive."""
    print("=== Example 1: Without PRESERVE8 (default) ===\n")
    
    input_arg = Argument(ptr(const_uint32_t))
    output_arg = Argument(ptr(uint32_t))
    
    with Function("add_one", (input_arg, output_arg),
                 target=Microarchitecture.CortexM3,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.ARMCC,
                 report_generation=False) as func:
        
        (input_ptr, output_ptr) = LOAD.ARGUMENTS()
        value = GeneralPurposeRegister()
        LDR(value, [input_ptr])
        ADD(value, value, 1)
        STR(value, [output_ptr])
        RETURN()
    
    print(func.assembly)
    print("Note: No PRESERVE8 directive present.\n")


def example_with_preserve8():
    """Generate function with PRESERVE8 directive."""
    print("=== Example 2: With PRESERVE8 enabled ===\n")
    
    input_arg = Argument(ptr(const_uint32_t))
    output_arg = Argument(ptr(uint32_t))
    
    with Function("multiply_two", (input_arg, output_arg),
                 target=Microarchitecture.CortexM3,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.ARMCC,
                 preserve8=True,  # Enable PRESERVE8 directive
                 report_generation=False) as func:
        
        (input_ptr, output_ptr) = LOAD.ARGUMENTS()
        value = GeneralPurposeRegister()
        LDR(value, [input_ptr])
        LSL(value, value, 1)  # Multiply by 2 using left shift
        STR(value, [output_ptr])
        RETURN()
    
    print(func.assembly)
    print("Note: PRESERVE8 directive is present after the AREA directive.\n")


def example_complex_function_with_preserve8():
    """Generate a more complex function with PRESERVE8."""
    print("=== Example 3: Complex function with PRESERVE8 ===\n")
    
    a_arg = Argument(ptr(const_uint32_t))
    b_arg = Argument(ptr(const_uint32_t))
    result_arg = Argument(ptr(uint32_t))
    count_arg = Argument(size_t)
    
    with Function("add_arrays", (a_arg, b_arg, result_arg, count_arg),
                 target=Microarchitecture.CortexM4,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.ARMCC,
                 preserve8=True,  # Enable PRESERVE8
                 report_generation=False) as func:
        
        (a_ptr, b_ptr, result_ptr, count) = LOAD.ARGUMENTS()
        
        with Loop() as add_loop:
            val_a = GeneralPurposeRegister()
            val_b = GeneralPurposeRegister()
            result = GeneralPurposeRegister()
            
            LDR(val_a, [a_ptr], 4)
            LDR(val_b, [b_ptr], 4)
            ADD(result, val_a, val_b)
            STR(result, [result_ptr], 4)
            
            SUBS(count, count, 4)
            BNE(add_loop.begin)
        
        RETURN()
    
    print(func.assembly)
    print("Note: PRESERVE8 ensures proper stack alignment for function calls.\n")


def example_gas_format_preserve8():
    """Demonstrate that PRESERVE8 only applies to ARMCC format."""
    print("=== Example 4: PRESERVE8 with GAS format (ignored) ===\n")
    
    input_arg = Argument(ptr(const_uint32_t))
    output_arg = Argument(ptr(uint32_t))
    
    with Function("subtract_one", (input_arg, output_arg),
                 target=Microarchitecture.CortexM3,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,  # GAS format
                 preserve8=True,  # This will be ignored for GAS
                 report_generation=False) as func:
        
        (input_ptr, output_ptr) = LOAD.ARGUMENTS()
        value = GeneralPurposeRegister()
        LDR(value, [input_ptr])
        SUB(value, value, 1)
        STR(value, [output_ptr])
        RETURN()
    
    print(func.assembly)
    print("Note: PRESERVE8 is not present because GAS format doesn't use it.\n")


def main():
    print("=" * 70)
    print("PRESERVE8 Directive Examples for ARMCC Assembly Format")
    print("=" * 70)
    print()
    print("The PRESERVE8 directive is an ARMCC-specific directive that indicates")
    print("the code maintains 8-byte stack alignment as required by ARM EABI.")
    print()
    print("Usage: Function(..., assembly_format=AssemblyFormat.ARMCC, preserve8=True)")
    print()
    print("=" * 70)
    print()
    
    example_without_preserve8()
    example_with_preserve8()
    example_complex_function_with_preserve8()
    example_gas_format_preserve8()
    
    print("=" * 70)
    print("Summary:")
    print("- Use preserve8=True to add PRESERVE8 directive to ARMCC assembly")
    print("- Default is preserve8=False (no directive)")
    print("- PRESERVE8 only applies to ARMCC format, not GAS format")
    print("- Useful for ensuring EABI compliance in embedded systems")
    print("=" * 70)


if __name__ == "__main__":
    main()
