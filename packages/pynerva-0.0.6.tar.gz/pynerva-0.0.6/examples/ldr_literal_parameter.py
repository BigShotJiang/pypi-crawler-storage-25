#!/usr/bin/env python3
"""
Comprehensive example demonstrating LDR with literal parameter

This shows how to use LDR(register, literal=value) which implements
the ARM pseudo-instruction: LDR rd, =value
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.constant_data import ConstantData, install_constant_data_support

# Enable ConstantData support
install_constant_data_support()

print("=" * 80)
print("Comprehensive LDR literal Parameter Example")
print("=" * 80)
print()

# Example: Computing CRC32 with magic constants
print("Example: CRC32 computation using LDR literal parameter")
print("-" * 80)

data_arg = Argument(ptr(uint32_t), name='data')
result_arg = Argument(ptr(uint32_t), name='result')

with Function("crc32_compute", (data_arg, result_arg),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (data_ptr, result_ptr) = LOAD.ARGUMENTS()
    
    # Load input data
    LDR(r0, [data_ptr])
    
    # Load CRC32 polynomial using literal parameter
    LDR(r1, literal=0xEDB88320)  # CRC32 polynomial
    
    # Load initial value
    LDR(r2, literal=0xFFFFFFFF)  # Initial CRC value
    
    # XOR with initial value
    EOR(r0, r0, r2)
    
    # Simple computation (simplified for demonstration)
    # In real CRC32, you'd loop over bits
    EOR(r0, r0, r1)
    
    # Finalize: XOR with 0xFFFFFFFF
    LDR(r3, literal=0xFFFFFFFF)
    EOR(r0, r0, r3)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

# Example with ConstantData for shared constants
print("Example: Using ConstantData with LDR literal parameter")
print("-" * 80)

with Function("crypto_init", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Define cryptographic constants in .data section
    AES_RCON = ConstantData.uint32(0x01000000, name="AES_RCON_1")
    SHA256_K = ConstantData.uint32(0x428a2f98, name="SHA256_K_0")
    MD5_INIT = ConstantData.uint32(0x67452301, name="MD5_INIT_A")
    
    # Load constants using literal parameter
    LDR(r0, literal=AES_RCON)
    LDR(r1, literal=SHA256_K)
    LDR(r2, literal=MD5_INIT)
    
    # Combine them
    ADD(r0, r0, r1)
    ADD(r0, r0, r2)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

# Example showing backward compatibility
print("Example: Backward compatibility - normal LDR still works")
print("-" * 80)

with Function("mixed_operations", (data_arg, result_arg),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (data_ptr, result_ptr) = LOAD.ARGUMENTS()
    
    # Normal memory load (unchanged syntax)
    LDR(r0, [data_ptr])
    LDR(r1, [data_ptr, 4])
    
    # Literal load (new syntax with literal parameter)
    LDR(r2, literal=0x12345678)
    
    # Mixed operations
    ADD(r0, r0, r1)
    ADD(r0, r0, r2)
    
    # Normal memory store
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

# Example: ARMCC format
print("Example: ARMCC format output")
print("-" * 80)

with Function("armcc_format", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.ARMCC,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load multiple constants
    LDR(r0, literal=0xAAAAAAAA)
    LDR(r1, literal=0xBBBBBBBB)
    LDR(r2, literal=0xCCCCCCCC)
    
    # Compute
    ADD(r0, r0, r1)
    ADD(r0, r0, r2)
    
    # Store
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

print("=" * 80)
print("Summary of Changes:")
print()
print("✓ LDR now accepts 'literal' parameter: LDR(rd, literal=value)")
print("✓ Generates ARM pseudo-instruction: LDR rd, =label")
print("✓ Automatic literal pool management and generation")
print("✓ Deduplication of identical literal values")
print("✓ Integration with ConstantData for .data section constants")
print("✓ Full backward compatibility - normal LDR syntax unchanged")
print("✓ Supports both GAS and ARMCC assembly formats")
print()
print("Alternative syntax (still available):")
print("  - LDR_LITERAL(rd, value)  - Dedicated function")
print("  - LDRL(rd, value)         - Short alias")
print("=" * 80)
