#!/usr/bin/env python3
"""
Example: Using LDR with custom literal labels

This example demonstrates how to use custom labels for literal pool entries
when using the LDR pseudo-instruction.
"""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

# Create a function that uses named literals
with Function("process_data", tuple(),
             target=Microarchitecture.CortexA9,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as function:
    
    # Load constants with meaningful names using LDR
    LDR(r0, literal=0xDEADBEEF, label="ERROR_CODE")
    LDR(r1, literal=0x12345678, label="VERSION_NUMBER")
    LDR(r2, literal=0xCAFEBABE, label="MAGIC_COOKIE")
    
    # Load a constant without a label (auto-generated name)
    LDR(r3, literal=0x11111111)
    
    # Alternative syntax using LDR_LITERAL (imported from nervapy.arm)
    LDR_LITERAL(r4, 0xAAAAAAAA, label="PATTERN_A")
    LDR_LITERAL(r5, 0x55555555)  # No label
    
    # Some operations
    ADD(r0, r0, r1)
    EOR(r2, r2, r3)
    ORR(r4, r4, r5)
    
    # Return
    BX(lr)

# Print the generated assembly
print("Generated Assembly with Named Literals:")
print("=" * 80)
print(function.assembly)
print("=" * 80)

# Demonstrate how labels make the code more readable
print("\nNotice how named literals are much easier to identify:")
print("  - ERROR_CODE instead of literal_12345678901234")
print("  - VERSION_NUMBER instead of literal_98765432109876")
print("  - MAGIC_COOKIE instead of literal_11223344556677")
print("\nThis makes debugging and understanding the assembly output much easier!")
