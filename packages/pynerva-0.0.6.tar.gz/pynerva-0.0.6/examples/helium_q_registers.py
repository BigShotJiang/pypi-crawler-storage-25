#!/usr/bin/env python
"""
Example: Using Q0-Q7 registers with Cortex-M55 target.

This demonstrates that Q registers are ready for Helium MVE use.
Note: MVE-specific instructions (VLDRW, VADD, etc.) will be added in future phases.
"""

from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.registers import q0, q1, q2, q3, q4, q5, q6, q7, r0, r1, r2

print("=" * 70)
print("Helium MVE Q Register Example")
print("=" * 70)

# Display Q register properties
print("\nAvailable Q Registers for Helium MVE (Cortex-M55):")
print("-" * 70)
for i, qreg in enumerate([q0, q1, q2, q3, q4, q5, q6, q7]):
    saved = "callee-saved" if i >= 4 else "caller-saved"
    print(f"  {str(qreg):3} - {qreg.size:2} bytes (128 bits) - {saved}")
    print(f"       ├─ Low:  {str(qreg.low_part):3}  (lower 64 bits)")
    print(f"       └─ High: {str(qreg.high_part):3} (upper 64 bits)")

print("\n" + "=" * 70)
print("Q Registers Successfully Verified!")
print("=" * 70)

# Q registers are ready - MVE instructions can be added in next phase
print(f"\n✅ Q0-Q7 are available for Helium MVE!")
print(f"   Each register: {q0.size} bytes (128 bits)")
print(f"   Target microarchitecture: Cortex-M55")
print(f"   Extension: MVE (M-Profile Vector Extension)")

# In future, MVE instructions will be used like:
print("\n   Example MVE pseudo-code (instructions coming soon):")
print("      VLDRW.U32  q0, [r0]     ; Load vector from memory")
print("      VLDRW.U32  q1, [r1]     ; Load vector from memory")
print("      VADD.I32   q2, q0, q1   ; Vector addition")
print("      VMUL.I32   q3, q0, q1   ; Vector multiplication")
print("      VSTRW.U32  q2, [r2]     ; Store result")

print("\n" + "=" * 70)
print("Register Usage Guidelines for Helium MVE")
print("=" * 70)
print("""
When writing Helium MVE code:

1. **Use Q0-Q3 freely** (caller-saved)
   - No need to preserve across function calls
   - Best for temporary computations

2. **Q4-Q7 must be saved/restored** (callee-saved)
   - If your function uses these, save them on entry
   - Restore them before return
   - Use for values that persist across calls

3. **Each Q register holds:**
   - 16 × 8-bit values (bytes)
   - 8 × 16-bit values (halfwords)
   - 4 × 32-bit values (words)
   - 2 × 64-bit values (doublewords)

4. **Next Steps:**
   - Implement P0-P7 predicate registers
   - Add MVE instruction encodings
   - Create MVE instruction classes
""")

print("=" * 70)
print("✅ Q0-Q7 registers are ready for Helium MVE!")
print("=" * 70)
