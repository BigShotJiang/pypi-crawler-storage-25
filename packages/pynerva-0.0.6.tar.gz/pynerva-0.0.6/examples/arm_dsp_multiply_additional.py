#!/usr/bin/env python3
"""
Additional ARM DSP Multiply Instructions Example

This example demonstrates additional DSP halfword multiply instructions:
- Word×Halfword: SMULWB, SMULWT, SMLAWB, SMLAWT
- Long accumulate variants: SMLALBB, SMLALBT, SMLALTT, SMLALTB
- Dual multiply: SMUAD, SMUSD, SMUSDXNE
"""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.generic import (SMULWB, SMULWT, SMLAWT, SMLAWB,
                                  SMLALBB, SMLALBT, SMLALTT, SMLALTB,
                                  SMUAD, SMUSD, SMUSDXNE)
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture


def test_word_halfword_multiply():
    """Test Word×Halfword multiply instructions"""
    print("=== Word×Halfword Multiply Instructions ===\n")
    
    a_arg = Argument(int32_t, name='a')
    b_arg = Argument(int32_t, name='b')
    c_arg = Argument(int32_t, name='c')
    result_arg = Argument(ptr(uint32_t), name='result')
    
    with Function("test_word_halfword",
                 (a_arg, b_arg, c_arg, result_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, c, result_ptr) = LOAD.ARGUMENTS()
        
        # SMULWB: r4 = (a * b[15:0])[47:16] (word by bottom halfword)
        SMULWB(r4, a, b)
        STR(r4, [result_ptr])
        
        # SMULWT: r5 = (a * b[31:16])[47:16] (word by top halfword)
        SMULWT(r5, a, b)
        STR(r5, [result_ptr, 4])
        
        # SMLAWB: r6 = ((a * b[15:0])[47:16]) + c
        SMLAWB(r6, a, b, c)
        STR(r6, [result_ptr, 8])
        
        # SMLAWT: r7 = ((a * b[31:16])[47:16]) + c
        SMLAWT(r7, a, b, c)
        STR(r7, [result_ptr, 12])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_long_accumulate_variants():
    """Test long accumulate halfword multiply variants"""
    print("=== Long Accumulate Halfword Multiply Variants ===\n")
    
    a_arg = Argument(int32_t, name='a')
    b_arg = Argument(int32_t, name='b')
    acc_low_arg = Argument(uint32_t, name='acc_low')
    acc_high_arg = Argument(uint32_t, name='acc_high')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("test_long_accumulate",
                 (a_arg, b_arg, acc_low_arg, acc_high_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, acc_low, acc_high, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # SMLALBB: r5:r4 += a[15:0] * b[15:0]
        MOV(r4, acc_low)
        MOV(r5, acc_high)
        SMLALBB(r4, r5, a, b)
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        # SMLALBT: r7:r6 += a[15:0] * b[31:16]
        MOV(r6, acc_low)
        MOV(r7, acc_high)
        SMLALBT(r6, r7, a, b)
        STR(r6, [result_low_ptr, 4])
        STR(r7, [result_high_ptr, 4])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_dual_multiply():
    """Test dual multiply instructions"""
    print("=== Dual Multiply Instructions ===\n")
    
    a_arg = Argument(int32_t, name='a')
    b_arg = Argument(int32_t, name='b')
    result_arg = Argument(ptr(uint32_t), name='result')
    
    with Function("test_dual_multiply",
                 (a_arg, b_arg, result_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (a, b, result_ptr) = LOAD.ARGUMENTS()
        
        # SMUAD: r4 = (a[15:0] * b[15:0]) + (a[31:16] * b[31:16])
        SMUAD(r4, a, b)
        STR(r4, [result_ptr])
        
        # SMUSD: r5 = (a[15:0] * b[15:0]) - (a[31:16] * b[31:16])
        SMUSD(r5, a, b)
        STR(r5, [result_ptr, 4])
        
        # Set condition for SMUSDXNE
        CMP(a, b)
        
        # SMUSDXNE: if NE, r6 = (a[15:0] * b[31:16]) - (a[31:16] * b[15:0])
        SMUSDXNE(r6, a, b)
        STR(r6, [result_ptr, 8])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def test_combined_dsp_example():
    """Example combining multiple DSP multiply types for audio processing"""
    print("=== Combined DSP Example: Audio Filter ===\n")
    
    sample_arg = Argument(int32_t, name='sample')
    coeff_arg = Argument(int32_t, name='coeff')
    acc_low_arg = Argument(uint32_t, name='acc_low')
    acc_high_arg = Argument(uint32_t, name='acc_high')
    result_low_arg = Argument(ptr(uint32_t), name='result_low')
    result_high_arg = Argument(ptr(uint32_t), name='result_high')
    
    with Function("audio_filter",
                 (sample_arg, coeff_arg, acc_low_arg, acc_high_arg, result_low_arg, result_high_arg),
                 target=Microarchitecture.ARM11,
                 abi=arm_gnueabihf,
                 assembly_format=AssemblyFormat.GAS,
                 report_generation=False) as function:
        
        (sample, coeff, acc_low, acc_high, result_low_ptr, result_high_ptr) = LOAD.ARGUMENTS()
        
        # Initialize 64-bit accumulator
        MOV(r4, acc_low)
        MOV(r5, acc_high)
        
        # Process two 16-bit audio samples with two coefficients
        # Using SMLALBB for bottom halfwords
        SMLALBB(r4, r5, sample, coeff)
        
        # Using SMLALTT for top halfwords
        SMLALTT(r4, r5, sample, coeff)
        
        # Add dual multiply result
        SMUAD(r6, sample, coeff)
        ADD(r4, r4, r6)
        
        # Store 64-bit result
        STR(r4, [result_low_ptr])
        STR(r5, [result_high_ptr])
        
        RETURN()
    
    print(function.assembly)
    print("\n" + "="*60 + "\n")


def main():
    """Run all DSP multiply instruction examples"""
    print("\n" + "="*60)
    print("Additional ARM DSP Multiply Instructions Examples")
    print("="*60 + "\n")
    
    test_word_halfword_multiply()
    test_long_accumulate_variants()
    test_dual_multiply()
    test_combined_dsp_example()
    
    print("\nAll DSP multiply instructions implemented successfully!")
    print("\nInstruction Categories:")
    print("  Word×HW:  SMULWB, SMULWT, SMLAWB, SMLAWT")
    print("  Long Acc: SMLALBB, SMLALBT, SMLALTT, SMLALTB")
    print("  Dual:     SMUAD, SMUSD, SMUSDXNE")


if __name__ == "__main__":
    main()
