# Barrel Shifter Usage Guide

## Combining Operations with Barrel Shifter

In ARM assembly, the barrel shifter allows you to combine shift operations with arithmetic/logical operations in a single instruction.

### Your Example: Combining AND with LSL

**Original two operations:**
```python
AND(tr2, tr2, tm)        # Mask for C2
LSL(tr2, tr2, 1)         # Shift left by 1
```

**Combined into one operation:**
```python
AND(tr2, tm.LSL(1))      # Mask AND shift in one instruction
```

### Generated Assembly
```assembly
AND r12, r12, r3, LSL #1
```

### Barrel Shifter Methods

All general-purpose registers in NervaPy support these barrel shifter methods:

- **`.LSL(shift)`** - Logical Shift Left (shift: 0-31)
- **`.LSR(shift)`** - Logical Shift Right (shift: 1-32)
- **`.ASR(shift)`** - Arithmetic Shift Right (shift: 1-32)
- **`.ROR(shift)`** - Rotate Right (shift: 1-31)
- **`.RRX()`** - Rotate Right with Extend

### Usage with Other Instructions

The barrel shifter works with most data processing instructions:

```python
# ADD with shift
ADD(r0, r1.LSL(2))          # r0 = r0 + (r1 << 2)

# SUB with shift
SUB(r0, r1, r2.LSR(3))      # r0 = r1 - (r2 >> 3)

# ORR with shift
ORR(r0, r1.ASR(4))          # r0 = r0 | (r1 >> 4, arithmetic)

# EOR with shift
EOR(r0, r1, r2.ROR(8))      # r0 = r1 ^ (r2 rotated right by 8)

# CMP with shift
CMP(r0, r1.LSL(1))          # Compare r0 with (r1 << 1)
```

### Benefits

1. **Reduces instruction count** - Two operations become one
2. **Improves performance** - Single instruction executes faster
3. **No temporary registers** - Shift result doesn't need storage
4. **Free operation** - Barrel shifter has no performance cost on most ARM cores

### Complete Example

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat

with Function("barrel_shifter_example", (), 
              abi=arm_gnueabihf,
              assembly_format=AssemblyFormat.GAS,
              report_generation=False) as func:
    
    r0 = GeneralPurposeRegister()
    r1 = GeneralPurposeRegister()
    r2 = GeneralPurposeRegister()
    
    # Load test values
    MOV(r0, 0x10)
    MOV(r1, 0x04)
    
    # Combine AND with LSL
    AND(r2, r0, r1.LSL(2))    # r2 = r0 & (r1 << 2) = 0x10 & 0x10 = 0x10
    
    # Combine ADD with LSR
    ADD(r2, r0, r1.LSR(1))    # r2 = r0 + (r1 >> 1) = 0x10 + 0x02 = 0x12
    
    RETURN()

print(func.assembly)
```

### Output Assembly
```assembly
AND r2, r0, r1, LSL #2
ADD r2, r0, r1, LSR #1
```
