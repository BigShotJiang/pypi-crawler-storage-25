# Register Allocation Error Messages - Line Number Support

## Overview

When register allocation fails, NervaPy now provides detailed information about where the maximum register pressure occurs, helping you identify which part of your code needs optimization.

## Error Message Information

The register allocation error now shows:

1. **Instruction index** (always shown): The position in the generated instruction sequence
2. **Python source location** (when `collect_origin=True`): File name and line number
3. **Source code** (when `collect_origin=True`): The actual Python line that generated the instruction
4. **Live virtual registers**: Which registers are in use at the problematic point

## Example Without collect_origin

```
Max register pressure at instruction #25 (index in generated code)
Hint: Enable collect_origin=True in Function() to see Python source line numbers.
Instruction with max pressure: UMLAL gp-vreg<15>, gp-vreg<16>, gp-vreg<4>, gp-vreg<11>
Live virtual registers: gp-vreg<10>, gp-vreg<11>, gp-vreg<14>, gp-vreg<15>, ...
```

## Example With collect_origin=True

```
Max register pressure at File: /path/to/your/file.py, Line: 98
Instruction with max pressure: UMLAL gp-vreg<15>, gp-vreg<16>, gp-vreg<4>, gp-vreg<11>
Source code: UMLAL(tr3, tr4, t0, t7)  # P(0, 3)
Live virtual registers: gp-vreg<10>, gp-vreg<11>, gp-vreg<14>, gp-vreg<15>, ...
```

## How to Enable Source Line Tracking

Add `collect_origin=True` when creating your Function:

```python
from nervapy.arm import *

f = Function("my_function", (arg1, arg2),
            target=Microarchitecture.CortexM33,
            abi=arm_gnueabihf,
            collect_origin=True)  # Enable source tracking

with f:
    # Your assembly code here
    UMLAL(r0, r1, r2, r3)
    # ...
```

## Performance Note

Enabling `collect_origin=True` adds a small overhead during code generation as it tracks the Python call stack for each instruction. For normal development, this overhead is negligible and highly recommended for better debugging.

## Use Cases

This feature is particularly helpful when:
- Debugging register allocation failures
- Optimizing code to reduce register pressure
- Understanding which parts of your algorithm are most register-intensive
- Reordering operations to improve register allocation
