# AND.W and EOR.W Implementation Summary

## Overview
Added support for `AND.W` and `EOR.W` instructions with 32-bit modified immediate encoding in NervaPy.

## Background
In Thumb-2, the `.W` suffix forces a 32-bit instruction encoding. For logical instructions like `AND` and `EOR`, this enables the use of modified immediate constants that support special patterns, including:
- Repeating byte patterns (e.g., `0x11111111` = repeat `0x11` in all 4 bytes)
- Other Thumb-2 modified immediate patterns

This is similar to `MOV.W` which already existed in NervaPy.

## Changes Made

### 1. Added New Functions in `nervapy/arm/generic.py`

Added two new instruction wrapper functions:

- **`AND_W(destination, source_x, source_y=None)`** at line ~5497
  - Generates `AND.W` instruction
  - Supports 3-operand form: `AND_W(rd, rn, imm)`
  - Supports 2-operand form: `AND_W(rd, imm)` (destination = destination AND imm)

- **`EOR_W(destination, source_x, source_y=None)`** at line ~7320
  - Generates `EOR.W` instruction  
  - Supports 3-operand form: `EOR_W(rd, rn, imm)`
  - Supports 2-operand form: `EOR_W(rd, imm)` (destination = destination XOR imm)

### 2. Updated `ArithmeticInstruction` Class

Modified the `allowed_instructions` list in `ArithmeticInstruction.__init__()` to include:
- `"AND.W"` (added after `"ANDLE"`)
- `"EOR.W"` (added after `"EORLE"`)

### 3. Updated Exports in `nervapy/arm/__init__.py`

Added `AND_W` and `EOR_W` to the module exports so they're available when importing from `nervapy.arm`.

## Usage Examples

```python
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture

f = Function("example", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f:
    # Three-operand form
    AND_W(r0, r1, 0x11111111)  # r0 = r1 & 0x11111111
    EOR_W(r2, r3, 0x22222222)  # r2 = r3 ^ 0x22222222
    
    # Two-operand form (destination is also source)
    AND_W(r4, 0xFFFFFFFF)      # r4 = r4 & 0xFFFFFFFF
    EOR_W(r5, 0x12121212)      # r5 = r5 ^ 0x12121212
    
    BX(lr)
```

### Generated Assembly

```asm
AND.W r0, r1, #286331153      ; 0x11111111
AND.W r2, r3, #572662306      ; 0x22222222  
AND.W r4, r4, #4294967295     ; 0xFFFFFFFF
AND.W r5, r6, #2880154539     ; 0xABABABAB
EOR.W r0, r1, #858993459      ; 0x33333333
EOR.W r2, r3, #1145324612     ; 0x44444444
```

## Notes on MOVW vs MOV.W

As clarified during implementation:
- **MOVW** is a separate 16-bit immediate instruction (`MOVW rd, #imm16`)
- **MOV.W** is the 32-bit encoding of MOV with modified immediate support
- Both are valid ARM instructions with different purposes
- NervaPy correctly implements both as separate functions

## Testing

Created `test_and_w_eor_w.py` which verifies:
- ✓ AND.W with repeating byte patterns
- ✓ EOR.W with repeating byte patterns  
- ✓ Both 2-operand and 3-operand forms
- ✓ Mixed usage of both instructions
- ✓ Generated assembly is syntactically correct

## Files Modified

1. `/home/kris/repos/NervaPy/nervapy/arm/generic.py`
   - Added `AND_W()` function
   - Added `EOR_W()` function
   - Updated `ArithmeticInstruction` allowed list

2. `/home/kris/repos/NervaPy/nervapy/arm/__init__.py`
   - Exported `AND_W`
   - Exported `EOR_W`

3. `/home/kris/repos/NervaPy/test_and_w_eor_w.py` (new)
   - Test suite for new instructions
