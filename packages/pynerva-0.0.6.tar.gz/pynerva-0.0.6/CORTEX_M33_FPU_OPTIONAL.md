# Cortex-M33 FPU Optional Support

## Summary

Fixed Cortex-M33 and Cortex-M35P microarchitecture definitions to correctly reflect that FPU is **optional** on these processors. FPU directives (`.fpu`) are now only emitted when FPU/VFP instructions are actually used in the code.

## Changes Made

### 1. Updated Microarchitecture Definitions

**File:** `nervapy/arm/microarchitecture.py`

Removed `Extension.VFP4` from the default extensions for:
- `Microarchitecture.CortexM33`
- `Microarchitecture.CortexM35P`

**Before:**
```python
Microarchitecture.CortexM33 = Microarchitecture(
    "Cortex M33",
    [
        Extension.V8MMain,
        Extension.Thumb2,
        Extension.DSP,
        Extension.VFP4,  # ← Incorrectly included by default
        Extension.TrustZone,
    ],
)
```

**After:**
```python
Microarchitecture.CortexM33 = Microarchitecture(
    "Cortex M33",
    [
        Extension.V8MMain,
        Extension.Thumb2,
        Extension.DSP,
        Extension.TrustZone,
    ],
)
```

### 2. Updated Tests

**File:** `tests/arm/test_cortex_m33_fpu.py`

Updated test expectations to verify that:
- FPU directives are NOT emitted for integer-only code
- FPU directives ARE emitted when FPU instructions are used (when implemented)

## Behavior

### Integer-Only Code (No FPU)

```python
with Function(
    'test_int',
    (source_arg, destination_arg),
    target=Microarchitecture.CortexM33,
    ...
) as test_func:
    x = GeneralPurposeRegister()
    LDR(x, [source])
    ADD(x, x, 1)
    STR(x, [destination])
    RETURN()
```

**Generated Assembly:**
```asm
	.syntax unified
	.arch armv8-m.main
	
	.text

.global test_int
.type test_int, %function
test_int:
	LDR r12, [r0]
	ADD r12, r12, #1
	STR r12, [r1]
	BX lr
```

Note: **No `.fpu` directive** is present.

### Code Using FPU Instructions

When FPU instructions are added to a function, the appropriate `.fpu fpv5-sp-d16` directive will be automatically included.

## Technical Details

The FPU directive generation logic in `nervapy/arm/function.py` already correctly handles this:

```python
@property
def gnu_fpu_spec(self):
    from nervapy.arm.isa import Extension
    
    isa_extensions = self.isa_extensions
    # ARMv8-M (Cortex-M33, M35P, etc.) uses FPv5-SP
    if Extension.V8MMain in isa_extensions or Extension.V8MBase in isa_extensions:
        if Extension.MVE in isa_extensions:
            return ".fpu mve"
        elif Extension.VFP4 in isa_extensions or Extension.VFP3 in isa_extensions:
            # ARMv8-M has FPv5 single-precision FPU
            return ".fpu fpv5-sp-d16"
        else:
            return None  # ← No FPU directive when VFP not in isa_extensions
```

The `isa_extensions` set is dynamically populated when instructions are added. Since VFP4 is no longer in the default Cortex-M33 extensions, it will only be added to `isa_extensions` when an FPU instruction is actually used.

## Verification

Run the test suite:
```bash
python -m pytest tests/arm/test_cortex_m33_fpu.py -v
```

Or run the demo script:
```bash
python test_m33_fpu_optional.py
```

## ARM Documentation Reference

From ARM Cortex-M33 Technical Reference Manual:
> "The Cortex-M33 processor includes an **optional** Floating Point Unit (FPU) that supports single-precision floating-point operations."

The FPU is a configurable option when implementing Cortex-M33, not a required feature.
