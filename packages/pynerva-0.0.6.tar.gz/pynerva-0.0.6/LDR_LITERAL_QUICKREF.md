# LDR Literal Parameter - Quick Reference

## Quick Start

```python
from nervapy.arm import *

# Load a 32-bit constant using literal parameter
LDR(r0, literal=0x11111111)
```

## Common Use Cases

### 1. Load Any 32-bit Constant

```python
# Values that can't fit in MOV immediate
LDR(r0, literal=0x11111111)
LDR(r1, literal=0x12345678)
LDR(r2, literal=0xDEADBEEF)
```

### 2. Load from ConstantData

```python
from nervapy.constant_data import ConstantData, install_constant_data_support

install_constant_data_support()

MAGIC = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")
LDR(r0, literal=MAGIC)
```

### 3. Backward Compatible

```python
# Normal LDR still works
LDR(r0, [r1])        # Memory load
LDR(r0, [r1, 4])     # With offset

# New literal syntax
LDR(r0, literal=0x11111111)  # Literal load
```

## Comparison

### Old Way (Multiple Instructions)

```python
# Had to split into two instructions
MOV(r0, 0x1111)      # Low 16 bits
MOVT(r0, 0x1111)     # High 16 bits
```

### New Way (Single Instruction)

```python
# Single instruction, cleaner code
LDR(r0, literal=0x11111111)
```

## Generated Assembly

### Input
```python
LDR(r0, literal=0x11111111)
```

### Output (GAS)
```assembly
LDR r0, =literal_12345678

.align 4
literal_12345678:
    .word 0x11111111
```

### Output (ARMCC)
```assembly
LDR r0, =literal_12345678

ALIGN 4
literal_12345678    DCD    0x11111111
```

## Features

| Feature | Status |
|---------|--------|
| 32-bit constants | ✓ |
| Automatic deduplication | ✓ |
| ConstantData integration | ✓ |
| GAS format | ✓ |
| ARMCC format | ✓ |
| Backward compatible | ✓ |

## Alternative Syntax

All three methods are equivalent:

```python
# Method 1: New literal parameter (RECOMMENDED)
LDR(r0, literal=0x11111111)

# Method 2: Dedicated function
from nervapy.arm.literal_pool import LDR_LITERAL
LDR_LITERAL(r0, 0x11111111)

# Method 3: Short alias
from nervapy.arm.literal_pool import LDRL
LDRL(r0, 0x11111111)
```

## Complete Example

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

result_arg = Argument(ptr(uint32_t), name='result')

with Function("example", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load constant using literal parameter
    LDR(r0, literal=0x11111111)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
```

## Tips

1. **Use for constants > 16 bits**: MOV can handle 0-65535, use LDR literal for larger values
2. **Automatic deduplication**: Same values reuse pool entries
3. **Named constants**: Use ConstantData for global, named constants
4. **PC-relative range**: Keep functions reasonable size (literal pool typically within 4KB)

## See Also

- Full documentation: `LDR_LITERAL_INTEGRATION.md`
- Examples: `examples/ldr_literal_parameter.py`
- ConstantData: `nervapy/constant_data.py`
