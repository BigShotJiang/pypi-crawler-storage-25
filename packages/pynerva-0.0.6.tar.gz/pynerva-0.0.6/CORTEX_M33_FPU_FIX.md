# Cortex-M33 FPU Directive Fix

## Problem

When generating assembly for Cortex-M33, NervaPy was incorrectly emitting:
```assembly
.fpu neon-vfpv4
```

This is incorrect because:
- Cortex-M33 does NOT support NEON (NEON is only for Cortex-A series)
- Cortex-M33 has an optional FPv5 single-precision FPU
- The correct directive should be `.fpu fpv5-sp-d16`

## Solution

Modified `nervapy/arm/function.py` in the `gnu_fpu_spec` property to:

1. **Check for ARMv8-M architecture first** (V8MMain or V8MBase extensions)
2. **For ARMv8-M processors**:
   - If MVE extension present → `.fpu mve`
   - If VFP4/VFP3 present → `.fpu fpv5-sp-d16`
   - Otherwise → No FPU directive

3. **For ARMv8.1-M processors** (like future Cortex-M55 with Helium):
   - If MVE extension present → `.fpu mve`
   - If VFP4/VFP3 present → `.fpu fpv5-sp-d16`
   - Otherwise → No FPU directive

4. **For other ARM processors** (Cortex-A series, etc.):
   - Check for NEON2 or (VFP4 + NEON) → `.fpu neon-vfpv4`
   - Continue with existing logic for NEONHP, NEON, VFPHP, VFP3, etc.

## Verification

### Before Fix
```assembly
.arch armv8-m.main
.fpu neon-vfpv4    # ❌ WRONG - Cortex-M33 doesn't have NEON
```

### After Fix
```assembly
.arch armv8-m.main
.fpu fpv5-sp-d16   # ✅ CORRECT - FPv5 single-precision
```

## ARM Cortex-M FPU Reference

| Processor   | Architecture | FPU                    | Correct Directive    | NEON? |
|-------------|--------------|------------------------|----------------------|-------|
| Cortex-M0   | ARMv6-M      | None                   | (none)               | No    |
| Cortex-M3   | ARMv7-M      | None                   | (none)               | No    |
| Cortex-M4   | ARMv7E-M     | Optional FPv4-SP       | `.fpu fpv4-sp-d16`   | No    |
| Cortex-M7   | ARMv7E-M     | Optional FPv5-DP       | `.fpu fpv5-d16`      | No    |
| Cortex-M33  | ARMv8-M Main | Optional FPv5-SP       | `.fpu fpv5-sp-d16`   | No    |
| Cortex-M55  | ARMv8.1-M    | Optional FPv5 + Helium | `.fpu mve`           | No    |

**Note**: None of the Cortex-M processors support NEON. NEON is only available on Cortex-A (application) processors.

## Testing

All existing tests pass:
```bash
pytest tests/arm/test_armv7m.py -v
# 3 passed
```

Cortex-A15 (which has NEON) still correctly generates `.fpu neon-vfpv4`.

## Future Improvements

1. **Conditional FPU directive**: Only emit `.fpu` when FP registers/instructions are actually used
2. **MVE support**: When MVE instructions are added, ensure `.fpu mve` is emitted correctly
3. **Cortex-M55 support**: Add Cortex-M55 microarchitecture with V8_1MMain and MVE extensions
