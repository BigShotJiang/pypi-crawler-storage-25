# Quick Reference: AND.W and EOR.W

## Synopsis

```python
AND_W(rd, rn, imm)  # rd = rn & imm
AND_W(rd, imm)      # rd = rd & imm

EOR_W(rd, rn, imm)  # rd = rn ^ imm
EOR_W(rd, imm)      # rd = rd ^ imm
```

## Purpose

Force 32-bit Thumb-2 encoding of AND/EOR instructions with modified immediate constants.

## When to Use

- When you need to use 32-bit immediate patterns like `0x11111111`, `0x22222222`, etc.
- When you need precise control over instruction encoding (e.g., for timing)
- When the immediate doesn't fit in standard 8-bit + rotation encoding

## Supported Immediate Patterns

Thumb-2 modified immediates support several patterns:

| Pattern | Example | Description |
|---------|---------|-------------|
| `0x000000XY` | `0x000000AB` | 8-bit value |
| `0x00XY00XY` | `0x00AB00AB` | Repeat in 16-bit words |
| `0xXY00XY00` | `0xAB00AB00` | Repeat in high bytes |
| `0xXYXYXYXY` | `0xABABABAB` | Repeat in all bytes |

## Examples

### Basic Usage

```python
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture

f = Function("example", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f:
    # Three-operand form
    AND_W(r0, r1, 0x11111111)   # r0 = r1 & 0x11111111
    EOR_W(r2, r3, 0xFFFFFFFF)   # r2 = r3 ^ 0xFFFFFFFF
    
    # Two-operand form
    AND_W(r4, 0x22222222)       # r4 = r4 & 0x22222222
    EOR_W(r5, 0x00FF00FF)       # r5 = r5 ^ 0x00FF00FF
    
    BX(lr)
```

### Generated Assembly

```asm
AND.W r0, r1, #286331153      ; 0x11111111
EOR.W r2, r3, #4294967295     ; 0xFFFFFFFF
AND.W r4, r4, #572662306      ; 0x22222222
EOR.W r5, r5, #16711935       ; 0x00FF00FF
```

## Comparison with Regular AND/EOR

| Instruction | Encoding | When to Use |
|-------------|----------|-------------|
| `AND(r0, r1, imm)` | Assembler chooses 16 or 32-bit | General case |
| `AND_W(r0, r1, imm)` | Forces 32-bit | Need specific pattern or encoding |
| `EOR(r0, r1, imm)` | Assembler chooses 16 or 32-bit | General case |
| `EOR_W(r0, r1, imm)` | Forces 32-bit | Need specific pattern or encoding |

## Related Instructions

- `MOV_W(rd, imm)` - Move with 32-bit modified immediate
- `MOVW(rd, imm)` - Move 16-bit immediate (different instruction!)
- `ORR(rd, rn, imm)` - Bitwise OR (also supports modified immediates)
- `BIC(rd, rn, imm)` - Bit clear (AND with inverted immediate)

## Notes

1. The `.W` suffix is a directive to the assembler, not part of the mnemonic
2. Modified immediate encoding is validated by the ARM instruction set
3. Not all 32-bit values are valid modified immediates
4. The assembler will show decimal values, but the pattern is what matters
5. These instructions are part of Thumb-2 (ARMv7-M and later)

## See Also

- `AND_W_EOR_W_IMPLEMENTATION.md` - Full implementation details
- `test_and_w_eor_w.py` - Test suite
- `demo_and_w_eor_w.py` - Usage examples
