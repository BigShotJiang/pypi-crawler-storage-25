#!/usr/bin/env python
"""Demo: How to check if a register is live at any point in code.

Live register analysis happens AFTER code generation completes, during the 
__exit__ phase of the Function context. To inspect live registers, you need
to either:
1. Set report_live_registers=True in Function constructor
2. Access instruction.live_registers after the function is generated
"""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.abi import arm_gnueabihf

print("Example 1: Using report_live_registers flag")
print("=" * 60)

# This will automatically analyze and report live registers
with Function("test_func", (Argument(uint32_t, "a"), Argument(uint32_t, "b")), 
              target=Microarchitecture.CortexM33,
              abi=arm_gnueabihf,
              report_live_registers=True):  # Enable live register reporting
    
    t0 = GeneralPurposeRegister()
    t1 = GeneralPurposeRegister()
    t2 = GeneralPurposeRegister()
    
    ADD(t0, r0, r1)
    MUL(t1, t0, r1)
    ADD(t2, t1, t0)
    MOV(r0, t2)
    RETURN()

print("\n" + "=" * 60)
print("Example 2: Manually checking live registers after generation")
print("=" * 60)

# Store the function object to inspect it later
func = Function("check_regs", (Argument(uint32_t, "x"),), 
                target=Microarchitecture.CortexM33,
                abi=arm_gnueabihf)

with func:
    t0 = GeneralPurposeRegister()
    t1 = GeneralPurposeRegister()
    t2 = GeneralPurposeRegister()
    
    # t0 = x + 5
    ADD(t0, r0, 5)
    
    # t1 = t0 * 2
    LSL(t1, t0, 1)
    
    # t2 = t1 + t0
    ADD(t2, t1, t0)
    
    # return t2
    MOV(r0, t2)
    RETURN()

# After the function is generated, live registers are computed
# Let's inspect which registers were live at each instruction
from nervapy.arm.instructions import Instruction

print("\nLive registers at each instruction:")
print("-" * 60)
for i, instr in enumerate(func.instructions):
    if isinstance(instr, Instruction):
        live_regs = instr.live_registers
        if live_regs:
            # Separate by register type
            gp_regs = [r for r in live_regs if hasattr(r, 'regtype') and 
                      hasattr(r, 'GPType') and r.regtype == r.GPType]
            
            reg_str = ", ".join(str(r) for r in sorted(gp_regs, 
                               key=lambda x: (x.id, x.mask))) if gp_regs else "none"
            print(f"  [{i:2d}] {str(instr):40s} | Live: {reg_str}")
        else:
            print(f"  [{i:2d}] {str(instr):40s} | Live: none")

print("\n" + "=" * 60)
print("Example 3: Check if a specific register is live")
print("=" * 60)

def is_register_live_at(func, register_id, instruction_index):
    """Check if a virtual register is live at a specific instruction."""
    from nervapy.arm.instructions import Instruction
    
    if instruction_index >= len(func.instructions):
        return False
    
    instr = func.instructions[instruction_index]
    if not isinstance(instr, Instruction):
        return False
    
    for live_reg in instr.live_registers:
        if live_reg.id == register_id:
            return True
    return False

# Check if t0 (virtual register) is still live at different points
# Note: We can't directly get the virtual register ID from outside,
# but we can inspect the instructions

print("To check if a register is live:")
print("1. After generation, inspect func.instructions[i].live_registers")
print("2. Each live_register has an 'id' attribute (virtual register ID)")
print("3. Live registers are computed backwards from function exit")
print("\nA register is live if its value will be used by a later instruction.")
