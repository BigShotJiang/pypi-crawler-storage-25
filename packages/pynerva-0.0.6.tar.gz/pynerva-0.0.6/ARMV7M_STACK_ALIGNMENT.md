# ARMv7-M Stack Alignment for BL/BLX Instructions

## Overview

This document describes the stack alignment requirement for ARMv7-M architecture and how NervaPy validates it.

## ARM Architecture Requirement

According to the **ARM Architecture Reference Manual ARMv7-M** and **AAPCS (ARM Architecture Procedure Call Standard)**:

1. **The stack pointer (SP) must be 8-byte aligned at any public interface (function calls)**
2. This requirement applies to:
   - `BL` (Branch with Link) instructions
   - `BLX` (Branch with Link and Exchange) instructions
3. This is mandatory for:
   - ARMv7-M architecture (Cortex-M3, Cortex-M4, Cortex-M7)
   - Compliance with AAPCS

### References

- ARM Architecture Reference Manual ARMv7-M, Section B1.5.7
- ARM Cortex-M Programming Guide, Section 3.1.2
- AAPCS (IHI0042F), Section 5.2.1.2 "Stack constraints at a public interface"

## Why This Matters

### Correctness
- Some ARMv7-M implementations can enable the STKALIGN bit in the CCR register
- When enabled, misaligned stacks at function calls can cause **hard faults**
- Even when not enforced by hardware, it violates the AAPCS

### Performance
- 8-byte aligned stacks enable more efficient memory access
- Some instructions (like LDRD/STRD) require or benefit from aligned access

### Interoperability
- Code must be compatible with other AAPCS-compliant code
- External libraries and OS calls expect 8-byte alignment

## NervaPy Implementation

### Validation

NervaPy automatically validates stack alignment before `BL` and `BLX` instructions when targeting ARMv7-M architectures. The validation:

1. **Tracks stack pointer changes** through:
   - `PUSH`/`POP` instructions
   - `PUSH.W`/`POP.W` instructions
   - `STMDB`/`LDMIA` instructions (with SP writeback)
   - `SUB sp, sp, #imm` and `ADD sp, sp, #imm` instructions

2. **Validates alignment** before each `BL`/`BLX` instruction
   - Stack offset must be a multiple of 8 bytes
   - Raises `ValueError` if misaligned

3. **Only applies to ARMv7-M**
   - Cortex-M3 (ARMv7-M)
   - Cortex-M4 (ARMv7-M)
   - Cortex-M7 (ARMv7-M)
   - Does NOT apply to ARMv7-A (e.g., Cortex-A8, Cortex-A9)

### Example: Misaligned Stack (ERROR)

```python
from nervapy.arm import Function, BL, BX, PUSH, POP
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.pseudo import IMPORT
from nervapy.arm.registers import r4, lr

# This will raise ValueError
with Function("bad_example", (), None,
              target=Microarchitecture.CortexM4,
              abi=arm_gnueabi) as func:
    external_func = IMPORT.FUNCTION("printf")
    
    # Prologue pushes r3, r4 (8 bytes) - stack is aligned
    PUSH((r4,))  # Push 4 more bytes - stack is now MISALIGNED (12 bytes)
    
    # ERROR: Stack is not 8-byte aligned!
    BL(external_func)
    
    POP((r4,))
    BX(lr)
```

**Error Message:**
```
ValueError: Stack is not 8-byte aligned before BL instruction.
Current stack offset: 12 bytes (misaligned by 4 bytes).
ARMv7-M requires 8-byte stack alignment at function calls (AAPCS requirement).
Add a dummy register to PUSH instructions or adjust stack manually to maintain alignment.
```

### Example: Aligned Stack (CORRECT)

```python
from nervapy.arm import Function, BL, BX, PUSH, POP
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.pseudo import IMPORT
from nervapy.arm.registers import r4, r5, lr

# This is correct
with Function("good_example", (), None,
              target=Microarchitecture.CortexM4,
              abi=arm_gnueabi) as func:
    external_func = IMPORT.FUNCTION("printf")
    
    # Prologue pushes r3, r4 (8 bytes) - stack is aligned
    PUSH((r4, r5))  # Push 8 more bytes - stack is ALIGNED (16 bytes)
    
    # OK: Stack is 8-byte aligned
    BL(external_func)
    
    POP((r4, r5))
    BX(lr)
```

## How to Fix Alignment Issues

### Solution 1: Add Dummy Registers

If you need to push an odd number of registers, add a dummy register:

```python
# Bad: Odd number of registers
PUSH((r4,))          # 4 bytes - misaligns stack

# Good: Even number of registers
PUSH((r4, r5))       # 8 bytes - maintains alignment
```

### Solution 2: Use Register Pairing

Combine multiple PUSH operations:

```python
# Bad: Separate odd pushes
PUSH((r4,))
PUSH((r5,))

# Good: Single even push
PUSH((r4, r5))
```

### Solution 3: Manual Stack Adjustment

For complex cases, manually adjust the stack:

```python
from nervapy.arm import SUB, ADD

# Allocate 12 bytes, but round up to 16 for alignment
SUB(sp, sp, 16)    # Maintains 8-byte alignment
# ... use 12 bytes ...
BL(external_func)   # Stack is aligned
ADD(sp, sp, 16)
```

### Solution 4: Disable Validation During Development

If you need to disable the check temporarily during development:

```python
with Function("my_func", (), None,
              target=Microarchitecture.CortexM4,
              abi=arm_gnueabi,
              validate_stack_alignment=False) as func:  # Disable validation
    # Your code here - validation will not run
    PUSH((r4,))  # Would normally fail, but validation is off
    BL(external_func)
    POP((r4,))
```

**⚠️ Warning:** Disabling validation may result in code that crashes at runtime on ARMv7-M. Only use this for development/testing.

## Implementation Details

### Code Location

- **Validation function**: `nervapy/arm/function.py` - `validate_stack_alignment()` method
- **Called during**: Function code generation (after prologue generation)
- **Instruction classes**: `nervapy/arm/generic.py` - `BranchWithLinkInstruction`, `BranchLinkExchangeInstruction`

### Stack Offset Tracking

The validator maintains a running `stack_offset` counter:

1. **Initial state**: 0 (prologue ensures 8-byte alignment)
2. **PUSH/PUSH.W**: `stack_offset += num_registers * 4`
3. **POP/POP.W**: `stack_offset -= num_registers * 4`
4. **STMDB sp!, {...}**: `stack_offset += num_registers * 4`
5. **LDMIA sp!, {...}**: `stack_offset -= num_registers * 4`
6. **SUB sp, sp, #N**: `stack_offset += N`
7. **ADD sp, sp, #N**: `stack_offset -= N`

Before each BL/BLX, the validator checks: `stack_offset % 8 == 0`

## Testing

Comprehensive tests are available in `tests/arm/test_stack_alignment.py`:

```bash
python3 -m pytest tests/arm/test_stack_alignment.py -v
```

Tests cover:
- Misaligned BL detection
- Misaligned BLX detection
- Aligned BL/BLX acceptance
- Multiple PUSH/POP tracking
- Different Cortex-M variants (M3, M4, M7)
- Non-ARMv7M architectures (validation skipped)

## Summary

✓ **ARMv7-M requires 8-byte stack alignment at function calls**  
✓ **NervaPy automatically validates this requirement**  
✓ **Clear error messages guide you to fix alignment issues**  
✓ **Only applies to ARMv7-M (Cortex-M), not ARMv7-A**  
✓ **Ensures AAPCS compliance and prevents hard faults**
