# Helium MVE Q Registers - Implementation Complete

## Summary

✅ **Q0-Q7 registers are ready for Helium MVE use!**

The 128-bit vector registers Q0-Q7 required for ARM Helium (MVE) are already fully implemented in NervaPy and ready to use.

## Q Register Details

### Available Registers
- **Q0-Q7**: 128-bit (16 byte) vector registers
- Defined in: `nervapy/arm/registers.py`
- Exported from: `nervapy/arm/__init__.py`
- Compatible with: Cortex-M55 (Helium MVE)

### Register Properties
```python
from nervapy.arm.registers import q0, q1, q2, q3, q4, q5, q6, q7

# Each Q register has:
# - size: 16 bytes (128 bits)
# - number: Unique identifier (0xF0, 0x10F0, 0x20F0, ...)
# - type: Register.VFPType
# - is_extended: Property indicating if Q8-Q15 range
```

## Usage Example

```python
from nervapy.arm import Function
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.registers import q0, q1, q2, q3, r0, r1

# Create function targeting Cortex-M55 with Helium
with Function("vector_example", (r0, r1), None,
              target=Microarchitecture.CortexM55) as func:
    
    # Q registers are available for use
    # (MVE instructions will be added in next phase)
    
    # Example of what will be possible:
    # VLDRW.U32(q0, [r0])      # Load vector
    # VADD.I32(q2, q0, q1)     # Vector add
    # VSTRW.U32(q2, [r0])      # Store vector
    pass
```

## Register Relationships

Q registers relate to D registers (64-bit) and S registers (32-bit):

```python
# Q0 = D0:D1 (lower and upper 64-bit halves)
# Q1 = D2:D3
# Q2 = D4:D5
# Q3 = D6:D7
# Q4 = D8:D9
# Q5 = D10:D11
# Q6 = D12:D13
# Q7 = D14:D15

# Access D register parts
q0.low_part   # Returns D0 (lower 64 bits)
q0.high_part  # Returns D1 (upper 64 bits)
```

## Register Encoding

Internal encoding follows ARM specifications:
- **Q0**: 0x000F0
- **Q1**: 0x010F0
- **Q2**: 0x020F0
- **Q3**: 0x030F0
- **Q4**: 0x040F0
- **Q5**: 0x050F0
- **Q6**: 0x060F0
- **Q7**: 0x070F0

The encoding scheme:
- Bits [15:12]: Register ID
- Bits [7:4]: 0xF indicates Q register
- Mask: 0x0F0

## Helium MVE Specifics

### Cortex-M55 Q Register Support
- **Available**: Q0-Q7 (8 registers × 128 bits)
- **Not available on Cortex-M55**: Q8-Q15 (those are for Cortex-A with Advanced SIMD)

### Calling Convention (AAPCS)
- **Caller-saved**: Q0-Q3 (D0-D7, S0-S15)
- **Callee-saved**: Q4-Q7 (D8-D15, S16-S31)
  
Functions using Q4-Q7 must preserve their values.

## Testing

Run the included test to verify Q register availability:

```bash
python test_mve_qregs.py
```

Expected output:
```
Testing Q0-Q7 registers for Helium MVE:
  q0 - number: 0xf0, size: 16 bytes
  q1 - number: 0x10f0, size: 16 bytes
  q2 - number: 0x20f0, size: 16 bytes
  q3 - number: 0x30f0, size: 16 bytes
  q4 - number: 0x40f0, size: 16 bytes
  q5 - number: 0x50f0, size: 16 bytes
  q6 - number: 0x60f0, size: 16 bytes
  q7 - number: 0x70f0, size: 16 bytes

✅ All Q0-Q7 registers are properly defined!
```

## Integration with Existing Code

Q registers are fully integrated with NervaPy's register allocation system:

```python
from nervapy.arm.registers import Register, QRegister

# Create virtual Q register (auto-allocated)
qreg = QRegister()  # Allocates next available Q register

# Physical Q register access
from nervapy.arm.registers import q0, q1, q2

# Type checking
assert isinstance(q0, QRegister)
assert q0.type == Register.VFPType
assert q0.size == 16
```

## Next Steps for MVE

Now that Q registers are ready, the next phase is:

1. **Predicate Registers** (P0-P7, VPR)
   - For MVE predication/masking
   - Used with conditional vector operations

2. **MVE Instructions** (`nervapy/arm/mve.py`)
   - VLDRW/VSTRW (vector load/store)
   - VADD/VSUB/VMUL (vector arithmetic)
   - VMULLB/VMULLT (widening multiply)
   - VMLAL/VMLSL (multiply-accumulate)
   - And many more...

3. **Testing & Examples**
   - Unit tests for each instruction
   - Post-quantum crypto examples
   - Performance benchmarks

## References

- ARM®v8-M Architecture Reference Manual (DDI 0553)
- ARM Cortex-M55 Technical Reference Manual
- ARM Helium Technology Programmer's Guide
- NervaPy source: `nervapy/arm/registers.py` (lines 1215-1360)

## Status

| Component | Status |
|-----------|--------|
| Q0-Q7 registers | ✅ Complete |
| Q8-Q15 (Advanced SIMD) | ✅ Complete (not used for MVE) |
| P0-P7 predicate registers | ⏳ TODO |
| VPR register | ⏳ TODO |
| MVE instructions | ⏳ TODO |

---

**Updated**: April 6, 2026  
**Component**: Helium MVE Phase 1 - Q Registers  
**Status**: ✅ COMPLETE
