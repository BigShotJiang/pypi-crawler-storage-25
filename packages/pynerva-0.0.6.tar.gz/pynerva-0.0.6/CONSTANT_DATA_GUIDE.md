# ConstantData - Automatic .data Section Generation

**File:** `nervapy/constant_data.py`  
**Purpose:** Automatically generate `.data` sections for constants in NervaPy ARM functions

## Overview

`ConstantData` is an augmentation of the `Constant` class that:
1. ✅ Automatically registers constants with the active Function
2. ✅ Generates `.data` section entries automatically
3. ✅ Provides labels for reference in assembly
4. ✅ Supports all Constant types (uint32, uint64, arrays, etc.)

**Key Feature:** When you create a `ConstantData` object inside a Function context, the `.data` section is **automatically appended** to the generated assembly!

## Installation

```python
from nervapy import *
from nervapy.arm import *
from nervapy.constant_data import ConstantData, install_constant_data_support

# Enable automatic .data section generation (call once)
install_constant_data_support()
```

## Basic Usage

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.constant_data import ConstantData, install_constant_data_support

# Enable support
install_constant_data_support()

result_arg = Argument(ptr(uint32_t), name='result')

with Function("my_func", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as function:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Create constants - automatically registered!
    magic = ConstantData.uint32(0x11111111, name="magic_number")
    size = ConstantData.uint32(256, name="buffer_size")
    
    # Use values in code
    MOV(r0, magic.data[0])      # Access the value
    MOV(r1, size.data[0])
    
    ADD(r0, r0, r1)
    STR(r0, [result_ptr])
    RETURN()

# .data section is automatically included!
print(function.assembly)
```

**Output:**
```assembly
	.syntax unified
	.arch armv6zk

	.text

.global my_func
.type my_func, %function
my_func:
Lmy_func.ENTRY:
	MOV r12, r0
	MOV r0, #17
	ORR r0, r0, r0, LSL #8
	ORR r0, r0, r0, LSL #16
	MOV r1, #256
	ADD r0, r0, r1
	STR r0, [r12]
	BX lr


	.data
	.align 4
	.global magic_number
	.type magic_number, %object
magic_number:
	.word 0x11111111
	.global buffer_size
	.type buffer_size, %object
buffer_size:
	.word 0x00000100
```

## API Reference

### Factory Methods

All methods from `Constant` are available:

```python
# 32-bit integer
const = ConstantData.uint32(0x12345678, name="my_const")

# 32-bit integer array (4 elements)
array = ConstantData.uint32x4(100, 200, 300, 400, name="lookup_table")

# 64-bit integer
big = ConstantData.uint64(0x123456789ABCDEF0, name="big_number")

# Floating point
pi = ConstantData.float32(3.14159, name="pi")
e = ConstantData.float64(2.718281828, name="e")
```

### Properties and Methods

```python
const = ConstantData.uint32(111, name="my_value")

# Get the value
value = const.data[0]           # Returns: 111

# Get the label name
label = const.get_label()       # Returns: "my_value"

# Get size and alignment
size = const.size               # Returns: 4 (bytes)
align = const.alignment         # Returns: 4

# Generate data section manually (usually automatic)
data_asm = const.generate_data_section()
```

## Supported Types

### uint32 - Single 32-bit Value

```python
const = ConstantData.uint32(0xDEADBEEF, name="magic")
```

Generates:
```assembly
	.global magic
	.type magic, %object
magic:
	.word 0xDEADBEEF
```

### uint32x4 - Array of 4x 32-bit Values

```python
array = ConstantData.uint32x4(100, 200, 300, 400, name="lookup")
```

Generates:
```assembly
	.global lookup
	.type lookup, %object
lookup:
	.word 0x00000064, 0x000000C8, 0x0000012C, 0x00000190
```

### uint64 - 64-bit Value

```python
big = ConstantData.uint64(0x123456789ABCDEF0, name="big_num")
```

Generates (little-endian, two 32-bit words):
```assembly
	.global big_num
	.type big_num, %object
big_num:
	.word 0x9ABCDEF0, 0x12345678
```

## Complete Examples

### Example 1: Multiple Constants

```python
from nervapy import *
from nervapy.arm import *
from nervapy.constant_data import ConstantData, install_constant_data_support

install_constant_data_support()

result_arg = Argument(ptr(uint32_t), name='result')

with Function("multi_const", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as function:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Multiple constants
    const1 = ConstantData.uint32(0xAAAAAAAA, name="const1")
    const2 = ConstantData.uint32(0xBBBBBBBB, name="const2")
    const3 = ConstantData.uint32(0xCCCCCCCC, name="const3")
    
    # Build value (constants are in .data section)
    MOV(r0, 42)
    
    STR(r0, [result_ptr])
    RETURN()

# All three constants appear in .data section
print(function.assembly)
```

### Example 2: Lookup Table

```python
with Function("use_table", (result_arg,), ...) as function:
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Create lookup table
    lookup = ConstantData.uint32x4(
        0x00, 0xFF, 0xFFFF, 0xFFFFFF,
        name="bitmask_table"
    )
    
    # Table is now in .data section with label "bitmask_table"
    # Can be accessed from C as: extern uint32_t bitmask_table[];
    
    MOV(r0, 0)
    STR(r0, [result_ptr])
    RETURN()
```

### Example 3: Using from C

**ARM Assembly (generated with ConstantData):**
```python
with Function("get_magic", (result_ptr,), ...) as function:
    (result_ptr,) = LOAD.ARGUMENTS()
    
    magic = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")
    
    # Build the value
    MOV(r0, 0x11)
    ORR(r0, r0, r0.LSL(8))
    ORR(r0, r0, r0.LSL(16))
    
    STR(r0, [result_ptr])
    RETURN()

# Save to file
with open("magic.s", "w") as f:
    f.write(function.assembly)
```

**C Code:**
```c
#include <stdio.h>
#include <stdint.h>

// External declarations
extern void get_magic(uint32_t *result);
extern uint32_t MAGIC_NUMBER;  // From .data section!

int main() {
    uint32_t result;
    
    // Call assembly function
    get_magic(&result);
    printf("Result: 0x%08X\n", result);
    
    // Access the constant directly
    printf("Magic: 0x%08X\n", MAGIC_NUMBER);
    
    return 0;
}
```

**Compile:**
```bash
arm-linux-gnueabihf-as magic.s -o magic.o
arm-linux-gnueabihf-gcc test.c magic.o -o test
qemu-arm ./test
```

## How It Works

### 1. Registration

When you create a `ConstantData` object inside a Function context:

```python
const = ConstantData.uint32(111, name="my_const")
```

The constant automatically registers itself with the active function using the global `active_function` variable.

### 2. Storage

Constants are stored in a class-level registry (`_function_constants`) keyed by function ID.

### 3. Generation

When the Function's `__exit__` is called (end of `with` block), constants are saved to the function instance.

### 4. Assembly Output

When `function.assembly` is accessed, the patched property appends the `.data` section automatically.

## Comparison: Constant vs ConstantData

| Feature | `Constant` | `ConstantData` |
|---------|------------|----------------|
| Create constant | ✅ | ✅ |
| Access value | ✅ `.data[0]` | ✅ `.data[0]` |
| Generate .data section | ❌ Manual | ✅ Automatic |
| Register with Function | ❌ | ✅ |
| Label generation | ❌ | ✅ `.get_label()` |
| Use in C code | ❌ | ✅ (as extern) |

## Limitations

### 1. LDR =label Not Supported

NervaPy doesn't support the `LDR =label` pseudo-instruction directly. You can:

**Option A:** Access from C code as `extern` variables

**Option B:** Post-process the assembly to add `LDR =label`

**Option C:** Use PC-relative addressing manually

### 2. Must Call install_constant_data_support()

You must call `install_constant_data_support()` once before creating functions:

```python
from nervapy.constant_data import install_constant_data_support

install_constant_data_support()  # Required!
```

### 3. Constants Only in Function Context

`ConstantData` must be created inside a `with Function(...)` block:

```python
# ❌ Wrong - no active function
const = ConstantData.uint32(111)

# ✅ Correct - inside function
with Function(...) as func:
    const = ConstantData.uint32(111)
```

## Advanced Usage

### Manual Data Section Generation

You can generate the data section manually without using the automatic system:

```python
const = ConstantData.uint32(0x12345678, name="manual")
data_asm = const.generate_data_section()
print(data_asm)
```

Output:
```assembly
	.global manual
	.type manual, %object
manual:
	.word 0x12345678
```

### Check Registered Constants

```python
with Function(...) as func:
    const1 = ConstantData.uint32(111)
    const2 = ConstantData.uint32(222)
    
    # Check what's registered
    constants = ConstantData.get_function_constants(func)
    print(f"Registered: {len(constants)} constants")
```

## Best Practices

### 1. Name Your Constants

Always provide meaningful names:

```python
# ✅ Good
TIMEOUT = ConstantData.uint32(1000, name="TIMEOUT_MS")

# ❌ Bad (auto-generated name)
const = ConstantData.uint32(1000)
```

### 2. Use for External Access

Use `ConstantData` when you need to access constants from C code:

```python
# These become extern uint32_t in C
FLAGS = ConstantData.uint32(0xFF, name="STATUS_FLAGS")
SIZE = ConstantData.uint32(256, name="BUFFER_SIZE")
```

### 3. Build vs Load

For simple values that fit in ARM immediates, building with instructions is more efficient than loading from memory:

```python
# Option 1: Use constant value (efficient)
MAGIC = ConstantData.uint32(0x11111111, name="MAGIC")
MOV(r0, 0x11)
ORR(r0, r0, r0.LSL(8))
ORR(r0, r0, r0.LSL(16))

# Option 2: Access as extern from C (if needed)
# extern uint32_t MAGIC; in C code
```

### 4. Organize Constants

Group related constants:

```python
with Function("init", ...) as func:
    # Configuration constants
    CONFIG_1 = ConstantData.uint32(0x1000, name="CFG_BASE")
    CONFIG_2 = ConstantData.uint32(0x2000, name="CFG_SIZE")
    
    # Lookup tables
    MASKS = ConstantData.uint32x4(0x0F, 0xF0, 0xFF, 0xFFFF, name="MASKS")
```

## Troubleshooting

### Problem: .data section not generated

**Solution:** Make sure you called `install_constant_data_support()`:

```python
from nervapy.constant_data import install_constant_data_support
install_constant_data_support()  # Must call this first!
```

### Problem: Constants have weird names

**Solution:** Always provide a `name` parameter:

```python
# Generates label "const_12345..." (bad)
bad = ConstantData.uint32(111)

# Generates label "my_value" (good)
good = ConstantData.uint32(111, name="my_value")
```

### Problem: Can't use LDR to load from constant

**Limitation:** NervaPy doesn't support `LDR =label` pseudo-instruction.

**Workaround:** Access the constant from C code as an `extern` variable.

## Summary

**ConstantData** provides automatic `.data` section generation for NervaPy ARM functions:

1. ✅ Import and install: `install_constant_data_support()`
2. ✅ Create constants inside Function context
3. ✅ `.data` section automatically appended to assembly
4. ✅ Access from C code as `extern` variables
5. ✅ Use `.data[0]` to get values in instructions
6. ✅ Use `.get_label()` to get label names

This eliminates manual `.data` section management while preserving the original `Constant` class functionality.

---

**See Also:**
- [NERVAPY_DATA_SECTION_GUIDE.md](NERVAPY_DATA_SECTION_GUIDE.md) - Manual method
- `nervapy/literal.py` - Original `Constant` class
- `nervapy/constant_data.py` - Source code
