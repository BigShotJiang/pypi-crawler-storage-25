# LDR =label Pseudo-Instruction Support

## Overview

NervaPy now supports the ARM assembler pseudo-instruction `LDR rd, =value` through the `LDR_LITERAL()` function. This allows you to load 32-bit constants that cannot be encoded directly in MOV instructions.

## Quick Start

```python
from nervapy.arm import LDR_LITERAL

with Function("my_func", ...) as func:
    # Load a 32-bit constant
    LDR_LITERAL(r0, 0x11111111)
    
    # Use it
    STR(r0, [r1])
    RETURN()
```

## Features

✅ **Automatic Literal Pool** - Literals are automatically placed in a pool after function code  
✅ **Deduplication** - Identical values share the same pool entry  
✅ **ConstantData Integration** - Works with `.data` section constants  
✅ **Both Formats** - GAS and ARMCC assembly formats supported  
✅ **Clean Syntax** - Simple, intuitive API  

## API Reference

### LDR_LITERAL(register, value)

Load a literal value into a register using the literal pool.

**Parameters:**
- `register` - Destination general-purpose register (r0-r12, lr, etc.)
- `value` - Literal value to load:
  - Integer (32-bit or 64-bit)
  - `ConstantData` object (references .data section)
  - Float (future support)

**Returns:** `LiteralLoadInstruction` object

**Alias:** `LDRL()` - shorter alternative

**Examples:**

```python
# Basic usage
LDR_LITERAL(r0, 0x12345678)

# Load large constant
LDR_LITERAL(r1, 0xDEADBEEF)

# Load from ConstantData
magic = ConstantData.uint32(0x11111111, name="MAGIC")
LDR_LITERAL(r2, magic)

# Use shorter alias
LDRL(r3, 0xCAFEBABE)
```

## How It Works

### 1. During Code Generation

When you call `LDR_LITERAL(r0, 0x11111111)`, NervaPy:

1. Creates a `LiteralPoolEntry` with the value
2. Adds it to the function's literal pool
3. Generates the instruction: `LDR r0, =literal_XXXX`

### 2. During Assembly Generation

When generating assembly, NervaPy:

1. Emits the function code
2. Appends the literal pool at the end
3. Each literal gets a label and `.word` directive

### Generated Assembly (GAS format):

```assembly
    .text
.global my_func
.type my_func, %function
my_func:
    LDR r0, =literal_12345678
    BX lr
    
    .align 4
literal_12345678:
    .word 0x11111111
```

### Generated Assembly (ARMCC format):

```assembly
    AREA    ||.text||, CODE, READONLY
my_func    PROC
    EXPORT  my_func
    LDR r0, =literal_12345678
    BX lr
    
    ALIGN 4
literal_12345678    DCD    0x11111111
    ENDP
    END
```

## Usage Examples

### Example 1: Basic Constant Loading

```python
from nervapy import *
from nervapy.arm import *

with Function("load_magic", (result_arg,), ...) as func:
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load 0x11111111 - can't be encoded in MOV
    LDR_LITERAL(r0, 0x11111111)
    
    STR(r0, [result_ptr])
    RETURN()
```

**Why use LDR_LITERAL?**
- `MOV r0, 0x11111111` → ❌ Error! Value not encodable
- `LDR_LITERAL(r0, 0x11111111)` → ✅ Works!

### Example 2: Multiple Constants

```python
with Function("compute", ...) as func:
    # Load multiple constants
    LDR_LITERAL(r0, 0x12345678)
    LDR_LITERAL(r1, 0xDEADBEEF)
    LDR_LITERAL(r2, 0x12345678)  # Automatic deduplication!
    
    # Use them
    ADD(r0, r0, r1)
    ADD(r0, r0, r2)
    RETURN()
```

**Deduplication:** r0 and r2 load the same value, so only one literal pool entry is created.

### Example 3: Integration with ConstantData

```python
from nervapy.constant_data import ConstantData, install_constant_data_support

install_constant_data_support()

with Function("use_config", ...) as func:
    # Define constant in .data section
    CONFIG = ConstantData.uint32(0x11111111, name="CONFIG_VALUE")
    
    # Load it using LDR_LITERAL
    LDR_LITERAL(r0, CONFIG)
    
    # Use it
    CMP(r1, r0)
    RETURN()
```

**Generated Assembly:**
```assembly
    .text
my_func:
    LDR r0, =CONFIG_VALUE
    CMP r1, r0
    BX lr
    
    .data
    .align 4
    .global CONFIG_VALUE
    .type CONFIG_VALUE, %object
CONFIG_VALUE:
    .word 0x11111111
```

### Example 4: Complex Algorithm

```python
with Function("hash_data", (data_arg, result_arg), ...) as func:
    (data_ptr, result_ptr) = LOAD.ARGUMENTS()
    
    # Load hash constants
    LDR_LITERAL(r2, 0x5A827999)  # SHA-1 constant K1
    LDR_LITERAL(r3, 0x6ED9EBA1)  # SHA-1 constant K2
    
    # Load data
    LDR(r0, [data_ptr])
    
    # Mix with constants
    EOR(r0, r0, r2)
    ADD(r0, r0, r3)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()
```

## Comparison with Alternatives

### Method 1: Build with MOV/ORR

```python
# Old way - build value with instructions
MOV(r0, 0x11)
ORR(r0, r0, r0.LSL(8))
ORR(r0, r0, r0.LSL(16))
# Result: 0x11111111 in 3 instructions
```

**Pros:** No literal pool, no memory access  
**Cons:** 3 instructions, complex for arbitrary values

### Method 2: LDR_LITERAL (NEW!)

```python
# New way - use literal pool
LDR_LITERAL(r0, 0x11111111)
# Result: 0x11111111 in 1 instruction
```

**Pros:** Simple, 1 instruction, works for ANY 32-bit value  
**Cons:** Requires memory access (but cached)

### Which to Use?

| Scenario | Recommended Method | Why |
|----------|-------------------|-----|
| Value < 256 | `MOV(r0, value)` | Direct encoding |
| Value encodable as MOV | `MOV(r0, value)` | Fastest |
| Large/complex value | `LDR_LITERAL(r0, value)` | Simplest |
| Many constants | `LDR_LITERAL` | Deduplication |
| Shared with C | `ConstantData + LDR_LITERAL` | Single source |

## Advanced Features

### 64-bit Values (Future)

```python
# Load 64-bit value into r0:r1 pair (planned)
LDR_LITERAL(r0, 0x123456789ABCDEF0, size=64)
```

### Conditional Loading (Planned)

```python
# Conditional literal load (planned)
LDR_LITERALEQ(r0, 0x11111111)  # Load if EQ flag set
```

### Float Support (Planned)

```python
# Load float constant (planned)
LDR_LITERAL(s0, 3.14159, float=True)
```

## Implementation Details

### Class Hierarchy

```
Instruction
    └── LiteralLoadInstruction
            └── Manages literal value
            └── References LiteralPoolEntry

LiteralPool
    └── Manages collection of LiteralPoolEntry objects
    └── Handles deduplication
    └── Generates assembly

LiteralPoolEntry
    └── Represents single literal value
    └── Generates label and .word directive
```

### Literal Pool Placement

The literal pool is placed:
- **After** the function code
- **Before** the ENDP/END directive
- **Aligned** to 4-byte boundary

This ensures:
- PC-relative addressing works (within ±4KB range)
- No instruction cache conflicts
- Efficient memory layout

### Label Generation

Labels are generated as:
- For raw values: `literal_<id>` (e.g., `literal_12345678`)
- For ConstantData: Uses the specified name (e.g., `MAGIC_NUMBER`)

### Deduplication Logic

```python
# These create ONE literal pool entry:
LDR_LITERAL(r0, 0x12345678)
LDR_LITERAL(r1, 0x12345678)  # Reuses existing entry

# These create TWO entries:
LDR_LITERAL(r0, 0x12345678)
LDR_LITERAL(r1, 0x87654321)  # Different value
```

## Limitations

1. **Range Limit**: Literals must be within PC-relative range (±4KB on ARMv7)
   - **Solution**: Function code should be < 4KB
   - **Future**: Support for literal islands in large functions

2. **No Conditional Support Yet**: Can't do `LDR_LITERALEQ`
   - **Workaround**: Use regular conditional instructions after load

3. **32-bit Values Only**: No 64-bit support yet
   - **Workaround**: Use two 32-bit loads

4. **No Float Support Yet**: Only integer values
   - **Workaround**: Load as integer, use VMOV to float register

## FAQ

### Q: Why use LDR_LITERAL instead of MOV?

**A:** MOV can only encode specific values (12-bit immediate + 4-bit rotation). LDR_LITERAL works for ANY 32-bit value.

### Q: Is LDR_LITERAL slower than MOV?

**A:** Slightly - it requires a memory load. But:
- The literal pool is in code space (usually cached)
- It's still very fast (1-2 cycles with cache)
- It's much simpler than multi-instruction sequences

### Q: Can I control the literal pool location?

**A:** Not currently. It's automatically placed after function code. This works for functions < 4KB.

### Q: Does deduplication work across functions?

**A:** No. Each function has its own literal pool. This is by design - functions are independent.

### Q: Can I use LDR_LITERAL with Thumb mode?

**A:** Yes! The assembler handles the encoding automatically.

## Troubleshooting

### Error: "literal pool out of range"

**Cause:** Function code is > 4KB, exceeding PC-relative range.

**Solution:**
1. Split into smaller functions
2. Use explicit data section (ConstantData)
3. Use GOT/PLT for large offsets (future feature)

### Error: "undefined reference to literal_XXXX"

**Cause:** Literal pool wasn't generated (bug in NervaPy).

**Solution:**
1. Check that function has `literal_pool` attribute
2. Ensure Function.assembly() is called properly
3. Report as a bug

### Warning: "duplicate literal labels"

**Cause:** Multiple literals with same name (shouldn't happen).

**Solution:**
1. Use unique names for ConstantData
2. Let auto-generated labels handle raw values

## Examples

See `examples/ldr_literal_example.py` for comprehensive examples including:
- Basic literal loading
- Multiple literals with deduplication
- Integration with ConstantData
- Complex computations
- ARMCC format output

## See Also

- `CONSTANT_DATA_GUIDE.md` - ConstantData class documentation
- `ANSWER_LDR_CONSTANT.md` - Why MOV doesn't work for all constants
- `NERVAPY_DATA_SECTION_GUIDE.md` - Manual .data section creation
- ARM Architecture Reference Manual - LDR pseudo-instruction

## Credits

Implemented in response to user request: "Can you add support for the LDR =label pseudo-instruction?"

**Features added:**
- `nervapy/arm/literal_pool.py` - Literal pool implementation
- `LDR_LITERAL()` and `LDRL()` functions
- Automatic pool generation in Function class
- Integration with ConstantData
- Support for both GAS and ARMCC formats
- Comprehensive examples and documentation
