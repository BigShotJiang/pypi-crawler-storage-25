# Answer: ARMCC External Function Import Support

## Question
> "For ARMCC when assembly uses external function (i.e. does "BL func") the compilation unit must include import statement that specifies the function."

## Answer: ✅ DONE

Support for ARMCC IMPORT directives has been successfully added to NervaPy!

**Important Note:** IMPORT directives are **only generated for ARMCC format**, not for GAS. GAS format doesn't require IMPORT declarations - the linker handles external symbols automatically.

## How to Use

### Basic Usage

```python
from nervapy.arm import Function, IMPORT, BL, BX, MOV
from nervapy.arm import r0, lr
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

with Function("my_function", (), None,
              target=Microarchitecture.CortexM4,
              abi=arm_gnueabi,
              assembly_format=AssemblyFormat.ARMCC) as func:
    
    # Step 1: Declare external function
    printf_func = IMPORT.FUNCTION("printf")
    
    # Step 2: Use it with BL
    MOV(r0, 0x100)
    BL(printf_func)
    BX(lr)
```

### Generated Assembly (ARMCC Format)

```assembly
        AREA    ||.text||, CODE, READONLY
        REQUIRE VFPv4

        IMPORT  printf        ← Automatically generated!

my_function    PROC
        EXPORT  my_function
my_function_ENTRY
        MOV r0, #256
        BL printf             ← Uses function directly
        BX lr
        ENDP
        END
```

## Key Features

✅ **Automatic IMPORT Generation (ARMCC only)** - IMPORT directives automatically added for ARMCC format  
✅ **Format-Aware** - Only generates IMPORT for ARMCC, not for GAS  
✅ **Multiple Imports** - Handles multiple external functions, sorted alphabetically  
✅ **Deduplication** - Same function referenced multiple times = one IMPORT  
✅ **Type-Safe** - ExternalFunction objects prevent typos  

**Important:** IMPORT directives are **only generated for ARMCC format**. GAS format doesn't need them.  

## Examples

### Example 1: C Standard Library Functions

```python
malloc_func = IMPORT.FUNCTION("malloc")
memcpy_func = IMPORT.FUNCTION("memcpy")
free_func = IMPORT.FUNCTION("free")

# Allocate
MOV(r0, 256)
BL(malloc_func)

# Copy
MOV(r1, r0)
MOV(r0, r1)
MOV(r2, 256)
BL(memcpy_func)

# Free
MOV(r0, r1)
BL(free_func)
```

Generates:
```assembly
    IMPORT  free
    IMPORT  malloc
    IMPORT  memcpy
```

### Example 2: Conditional External Call

```python
from nervapy.arm import CMP, BEQ, Label, LABEL

error_handler = IMPORT.FUNCTION("handle_error")

CMP(r0, 0)
skip = Label("skip")
BEQ(skip)

BL(error_handler)  # Only called if r0 != 0

LABEL(skip)
BX(lr)
```

Generates:
```assembly
    IMPORT  handle_error

    CMP r0, #0
    BEQ my_function_skip
    BL handle_error
my_function_skip
    BX lr
```

## Quick Reference

| Task | Code |
|------|------|
| Declare external function | `func = IMPORT.FUNCTION("name")` |
| Call external function | `BL(func)` |
| Multiple functions | Call `IMPORT.FUNCTION()` for each |
| Check generated imports | Look at `func.assembly` output |

## Common External Functions

```python
# Memory management
malloc = IMPORT.FUNCTION("malloc")
free = IMPORT.FUNCTION("free")
memcpy = IMPORT.FUNCTION("memcpy")
memset = IMPORT.FUNCTION("memset")

# I/O
printf = IMPORT.FUNCTION("printf")
sprintf = IMPORT.FUNCTION("sprintf")

# Math
sin = IMPORT.FUNCTION("sin")
cos = IMPORT.FUNCTION("cos")
sqrt = IMPORT.FUNCTION("sqrt")

# String
strlen = IMPORT.FUNCTION("strlen")
strcmp = IMPORT.FUNCTION("strcmp")
strcpy = IMPORT.FUNCTION("strcpy")
```

## Implementation Details

### What Changed

1. **New `ExternalFunction` class** - Represents external function references
2. **New `IMPORT.FUNCTION()` method** - Declares external functions
3. **Function tracking** - `Function.external_functions` set tracks all imports
4. **Assembly generation** - ARMCC format now outputs IMPORT directives
5. **Operand support** - `Operand` class handles `ExternalFunction` objects
6. **BL instruction** - Updated to work with external functions

### Where IMPORT Directives Appear

In ARMCC assembly, IMPORT directives are placed:
1. After the AREA declaration
2. After any REQUIRE directives
3. Before the PROC declaration
4. Sorted alphabetically

Example:
```assembly
        AREA    ||.text||, CODE, READONLY
        REQUIRE VFPv4
        
        IMPORT  func1        ← All imports here
        IMPORT  func2
        IMPORT  func3
        
my_function    PROC
        EXPORT  my_function
        ...
```

## Testing

All tests pass:

```
✓ Simple external function call
✓ Multiple external functions
✓ Conditional external calls
✓ IMPORT directives generated in correct location
✓ Functions sorted alphabetically
✓ Deduplication works
✓ GAS format (no IMPORT needed) works
✓ ARMCC format (with IMPORT) works
```

## Files Modified/Created

**Modified:**
- `nervapy/arm/pseudo.py` - Added `ExternalFunction` and `IMPORT` classes
- `nervapy/arm/function.py` - Added import tracking and generation
- `nervapy/arm/instructions.py` - Added `ExternalFunction` support
- `nervapy/arm/generic.py` - Updated `BL` instruction
- `nervapy/arm/__init__.py` - Exported new classes

**Created:**
- `examples/arm_import_external_functions.py` - Complete examples
- `docs/ARM_IMPORT_EXTERNAL_FUNCTIONS.md` - Full documentation

## Complete Working Example

```python
from nervapy.arm import (Function, IMPORT, BL, BX, MOV, CMP, BEQ,
                         r0, r1, lr, Label, LABEL)
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

with Function("process_request", (), None,
              target=Microarchitecture.CortexM4,
              abi=arm_gnueabi,
              assembly_format=AssemblyFormat.ARMCC) as func:
    
    # Declare external functions
    validate = IMPORT.FUNCTION("validate_input")
    process = IMPORT.FUNCTION("process_data")
    error = IMPORT.FUNCTION("handle_error")
    
    # Validate input
    BL(validate)
    CMP(r0, 0)
    error_label = Label("error")
    BEQ(error_label)
    
    # Process if valid
    BL(process)
    BX(lr)
    
    # Handle error
    LABEL(error_label)
    BL(error)
    BX(lr)

# Print generated assembly
print(func.assembly)
```

Output:
```assembly
        AREA    ||.text||, CODE, READONLY
        REQUIRE VFPv4

        IMPORT  handle_error
        IMPORT  process_data
        IMPORT  validate_input

process_request    PROC
        EXPORT  process_request
process_request_ENTRY
        BL validate_input
        CMP r0, #0
        BEQ process_request_error
        BL process_data
        BX lr
process_request_error
        BL handle_error
        BX lr
        ENDP
        END
```

## Summary

✅ **ARMCC IMPORT directive support is fully implemented and working!**

You can now:
- Declare external functions with `IMPORT.FUNCTION("name")`
- Call them with `BL(external_func)`
- Generate correct ARMCC assembly with IMPORT directives
- Use with any external C library or custom functions
