# NervaPy Data Section Guide

**Date:** April 6, 2026  
**Topic:** How to create `.data` sections in NervaPy-generated ARM assembly

## Overview

NervaPy focuses on **instruction generation (.text section)**, not complete assembly files with data sections. To add constants/data, you must **manually append** a `.data` section as a string.

## Table of Contents

1. [Quick Start](#quick-start)
2. [Manual Method](#manual-method)
3. [Helper Function](#helper-function)
4. [Complete Examples](#complete-examples)
5. [Assembly and Testing](#assembly-and-testing)
6. [Best Practices](#best-practices)

---

## Quick Start

```python
from nervapy import *
from nervapy.arm import *

# 1. Generate your function
with Function("my_func", ...) as function:
    MOV(r0, 0x11)
    ORR(r0, r0, r0.LSL(8))
    ORR(r0, r0, r0.LSL(16))
    RETURN()

# 2. Append data section
data = """
\t.data
\t.align 4
my_constant:
\t.word 0x11111111
"""

# 3. Combine and save
complete = function.assembly + data
with open("output.s", "w") as f:
    f.write(complete)
```

---

## Manual Method

### Step-by-Step Process

#### Step 1: Generate NervaPy Function

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

result_arg = Argument(ptr(uint32_t), name='result')

with Function("compute_value", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as function:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Build 0x11111111
    MOV(r0, 0x11)
    ORR(r0, r0, r0.LSL(8))
    ORR(r0, r0, r0.LSL(16))
    
    STR(r0, [result_ptr])
    RETURN()

# Get generated code
code = function.assembly
```

#### Step 2: Create Data Section String

```python
data_section = """
\t.data
\t.align 4
\t.global my_constant
\t.type my_constant, %object
my_constant:
\t.word 0x11111111

\t.global my_array
\t.type my_array, %object
my_array:
\t.word 0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC, 0xDDDDDDDD

\t.global my_string
\t.type my_string, %object
my_string:
\t.asciz "Hello, ARM!"
\t.align 4
"""
```

#### Step 3: Combine Code and Data

```python
complete_assembly = code + data_section
```

#### Step 4: Save to File

```python
with open("output.s", "w") as f:
    f.write(complete_assembly)
```

### Data Section Syntax

#### Single Word Constant

```assembly
.data
.align 4
.global my_constant
.type my_constant, %object
my_constant:
    .word 0x11111111
```

#### Array of Words

```assembly
.data
.align 4
.global my_array
.type my_array, %object
my_array:
    .word 0x11111111, 0x22222222, 0x33333333, 0x44444444
```

#### String Constant

```assembly
.data
.align 4
.global my_string
.type my_string, %object
my_string:
    .asciz "Hello, World!"
    .align 4
```

---

## Helper Function

### Helper Module: `nervapy_data_helper.py`

Create a reusable helper file:

```python
#!/usr/bin/env python3
"""Helper module for adding .data sections to NervaPy-generated ARM assembly"""

def add_data_section(function_assembly, constants_dict):
    """Add .data section to NervaPy-generated assembly
    
    Args:
        function_assembly (str): Assembly code from NervaPy function.assembly
        constants_dict (dict): Dictionary of constants to add to .data section
            Keys are constant names (labels)
            Values can be:
                - int: Single 32-bit word
                - list of ints: Array of 32-bit words
                - str: Null-terminated string
    
    Returns:
        str: Complete assembly with .data section appended
    
    Example:
        constants = {
            "my_constant": 0x11111111,
            "my_array": [0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC],
            "my_string": "Hello, ARM!"
        }
        
        complete = add_data_section(func.assembly, constants)
    """
    data_lines = ["\n\t.data", "\t.align 4"]
    
    for name, value in constants_dict.items():
        data_lines.append(f"\t.global {name}")
        data_lines.append(f"\t.type {name}, %object")
        data_lines.append(f"{name}:")
        
        if isinstance(value, list):
            # Array of values
            words = ", ".join(
                f"0x{v:08X}" if v >= 0 else str(v) 
                for v in value
            )
            data_lines.append(f"\t.word {words}")
        elif isinstance(value, str):
            # String constant
            data_lines.append(f'\t.asciz "{value}"')
            data_lines.append("\t.align 4")
        elif isinstance(value, int):
            # Single value
            if value >= 0:
                data_lines.append(f"\t.word 0x{value:08X}")
            else:
                data_lines.append(f"\t.word {value}")
        else:
            raise TypeError(f"Unsupported value type for '{name}': {type(value)}")
    
    return function_assembly + "\n".join(data_lines) + "\n"


def save_with_data(filename, function_assembly, constants_dict=None):
    """Save assembly to file with optional .data section
    
    Args:
        filename (str): Output filename (.s extension recommended)
        function_assembly (str): Assembly from NervaPy
        constants_dict (dict, optional): Constants to add to .data section
    
    Returns:
        str: Path to saved file
    """
    if constants_dict:
        complete = add_data_section(function_assembly, constants_dict)
    else:
        complete = function_assembly
    
    with open(filename, 'w') as f:
        f.write(complete)
    
    return filename
```

### Using the Helper

```python
from nervapy_data_helper import add_data_section, save_with_data

# After generating your function
with Function("my_func", ...) as func:
    # ... your code ...
    pass

# Define constants
constants = {
    "my_constant": 0x11111111,
    "my_array": [0xAA, 0xBB, 0xCC, 0xDD],
    "my_string": "Hello, ARM!",
    "multiplier": 42
}

# Option 1: Get complete assembly string
complete = add_data_section(func.assembly, constants)
print(complete)

# Option 2: Save directly to file
save_with_data("output.s", func.assembly, constants)
```

---

## Complete Examples

### Example 1: Basic Constant

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

result_arg = Argument(ptr(uint32_t), name='result')

# Generate function
with Function("load_constant", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as function:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Build 0x11111111 in code
    MOV(r0, 0x11)
    ORR(r0, r0, r0.LSL(8))
    ORR(r0, r0, r0.LSL(16))
    
    STR(r0, [result_ptr])
    RETURN()

# Add data section
data = """
\t.data
\t.align 4
\t.global my_constant
my_constant:
\t.word 0x11111111
"""

# Combine and save
with open("example1.s", "w") as f:
    f.write(function.assembly + data)
```

### Example 2: Using Helper with Multiple Constants

```python
from nervapy import *
from nervapy.arm import *
from nervapy_data_helper import save_with_data

result_arg = Argument(ptr(uint32_t), name='result')

with Function("process_data", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as function:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    MOV(r0, 0)
    STR(r0, [result_ptr])
    RETURN()

# Define multiple constants
constants = {
    "magic_number": 0x11111111,
    "lookup_table": [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77],
    "message": "NervaPy Data Section",
    "multiplier": 42,
    "flags": [0xDEADBEEF, 0xCAFEBABE]
}

# Save with data section
save_with_data("example2.s", function.assembly, constants)
```

### Example 3: Function That Uses Data (Manual Assembly)

For functions that actually load from the data section, you need to manually craft the assembly:

```assembly
\t.syntax unified
\t.arch armv6zk

\t.text

.global load_constant_from_data
.type load_constant_from_data, %function
load_constant_from_data:
\tPUSH {r4, lr}
\tMOV r4, r0          // Save result pointer
\t
\t// Load address of constant
\tLDR r0, =my_constant
\t// Load the value
\tLDR r0, [r0]
\t
\t// Store to result
\tSTR r0, [r4]
\t
\tPOP {r4, pc}

.global sum_array_from_data
.type sum_array_from_data, %function
sum_array_from_data:
\tPUSH {r4, r5, r6, lr}
\tMOV r6, r0          // Save result pointer
\t
\t// Load address of array
\tLDR r4, =my_array
\t
\t// Load 4 elements and sum them
\tLDR r0, [r4, #0]
\tLDR r1, [r4, #4]
\tLDR r2, [r4, #8]
\tLDR r5, [r4, #12]
\t
\tADD r0, r0, r1
\tADD r0, r0, r2
\tADD r0, r0, r5
\t
\t// Store result
\tSTR r0, [r6]
\t
\tPOP {r4, r5, r6, pc}

\t.data
\t.align 4
my_constant:
\t.word 0x11111111

my_array:
\t.word 100, 200, 300, 400
```

---

## Assembly and Testing

### Assemble the File

```bash
# Using GNU assembler
arm-linux-gnueabihf-as output.s -o output.o

# Or using GCC (which calls as internally)
arm-linux-gnueabihf-gcc -c output.s -o output.o
```

### Create C Test Program

```c
#include <stdio.h>
#include <stdint.h>

// External declarations
extern void compute_value(uint32_t *result);
extern uint32_t my_constant;
extern uint32_t my_array[];
extern char my_string[];

int main() {
    uint32_t result;
    
    // Call assembly function
    compute_value(&result);
    printf("Result: 0x%08X\n", result);
    
    // Access data section
    printf("Constant: 0x%08X\n", my_constant);
    printf("Array[0]: 0x%08X\n", my_array[0]);
    printf("String: %s\n", my_string);
    
    return 0;
}
```

### Compile and Link

```bash
# Compile C file
arm-linux-gnueabihf-gcc -c test.c -o test.o

# Link together
arm-linux-gnueabihf-gcc test.o output.o -o program

# Or in one step
arm-linux-gnueabihf-gcc test.c output.o -o program
```

### Run (with QEMU)

```bash
qemu-arm ./program
```

---

## Best Practices

### 1. When to Use Data Sections

**Use data sections when:**
- ✅ You need to share constants with C/C++ code
- ✅ Constants are large (many values)
- ✅ String data is needed
- ✅ Data needs to be mutable (writable memory)

**Don't use data sections when:**
- ❌ Building values with instructions is simple (e.g., 0x11111111)
- ❌ Values are ARM-encodable immediates
- ❌ You want position-independent code

### 2. Building vs Loading Constants

For the specific case of loading `0x11111111`:

**Option A: Build with instructions (RECOMMENDED)**
```python
MOV(r0, 0x11)
ORR(r0, r0, r0.LSL(8))
ORR(r0, r0, r0.LSL(16))
```
- ✅ 3 instructions (12 bytes)
- ✅ No memory access
- ✅ Position-independent
- ✅ Works in NervaPy directly

**Option B: Load from data section**
```assembly
LDR r0, =my_constant
LDR r0, [r0]
.data
my_constant: .word 0x11111111
```
- ✅ Only 2 instructions in code
- ❌ Requires 4 bytes of data memory
- ❌ Memory access (slower)
- ❌ Requires manual assembly editing

**Recommendation:** Use **Option A** for simple constants like 0x11111111.

### 3. Alignment

Always align data properly:
```assembly
.data
.align 4        # Align to 4-byte boundary for words
my_data:
    .word 0x11111111
```

For strings, align after:
```assembly
my_string:
    .asciz "Hello"
    .align 4    # Align after string
```

### 4. Global vs Local Labels

Make labels global if accessing from C:
```assembly
.global my_constant    # Accessible from C
.type my_constant, %object
my_constant:
    .word 0x11111111
```

### 5. Naming Conventions

Use clear, descriptive names:
```python
constants = {
    "TIMER_FREQUENCY": 1000000,
    "BUFFER_SIZE": 256,
    "ERROR_CODES": [1, 2, 3, 4],
    "VERSION_STRING": "v1.0.0"
}
```

---

## Summary

### Key Points

1. **NervaPy generates instructions only** - No automatic .data section generation
2. **Append data manually** - Use string concatenation
3. **Use helper functions** - Simplify the process with `add_data_section()`
4. **Save to .s file** - Write complete assembly to file
5. **Assemble normally** - Use arm-as or gcc
6. **Building > Loading** - For simple constants, build with instructions

### Workflow

```
┌─────────────────┐
│ Generate with   │
│ NervaPy         │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Define          │
│ constants dict  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ add_data_       │
│ section()       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Save to .s file │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Assemble & Link │
└─────────────────┘
```

### Files and Resources

- **Helper module:** Create `nervapy_data_helper.py` with helper functions
- **Examples:** See examples in this guide
- **Test files:** Check `/tmp/nervapy_with_data.s` for complete example

### Related Topics

- [ARM Multiply Instructions](MULTIPLY_INSTRUCTIONS_SUMMARY.md)
- [LDR Instruction Usage](README.md)
- ARM immediate encoding limitations

---

## Appendix: Complete Helper Module

Save this as `nervapy_data_helper.py`:

```python
#!/usr/bin/env python3
"""
Helper module for adding .data sections to NervaPy-generated ARM assembly

Usage:
    from nervapy_data_helper import add_data_section, save_with_data
    
    # Generate your function with NervaPy
    with Function(...) as func:
        ...
    
    # Add data section
    constants = {
        "my_const": 0x11111111,
        "my_array": [1, 2, 3, 4],
        "my_string": "Hello"
    }
    
    complete_asm = add_data_section(func.assembly, constants)
    
    # Or save directly
    save_with_data("output.s", func.assembly, constants)
"""

def add_data_section(function_assembly, constants_dict):
    """Add .data section to NervaPy-generated assembly
    
    Args:
        function_assembly (str): Assembly code from NervaPy function.assembly
        constants_dict (dict): Dictionary of constants to add to .data section
            Keys are constant names (labels)
            Values can be:
                - int: Single 32-bit word
                - list of ints: Array of 32-bit words
                - str: Null-terminated string
    
    Returns:
        str: Complete assembly with .data section appended
    
    Example:
        constants = {
            "my_constant": 0x11111111,
            "my_array": [0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC],
            "my_string": "Hello, ARM!"
        }
        
        complete = add_data_section(func.assembly, constants)
    """
    data_lines = ["\n\t.data", "\t.align 4"]
    
    for name, value in constants_dict.items():
        data_lines.append(f"\t.global {name}")
        data_lines.append(f"\t.type {name}, %object")
        data_lines.append(f"{name}:")
        
        if isinstance(value, list):
            # Array of values
            words = ", ".join(
                f"0x{v:08X}" if v >= 0 else str(v) 
                for v in value
            )
            data_lines.append(f"\t.word {words}")
        elif isinstance(value, str):
            # String constant
            data_lines.append(f'\t.asciz "{value}"')
            data_lines.append("\t.align 4")
        elif isinstance(value, int):
            # Single value
            if value >= 0:
                data_lines.append(f"\t.word 0x{value:08X}")
            else:
                data_lines.append(f"\t.word {value}")
        else:
            raise TypeError(f"Unsupported value type for '{name}': {type(value)}")
    
    return function_assembly + "\n".join(data_lines) + "\n"


def save_with_data(filename, function_assembly, constants_dict=None):
    """Save assembly to file with optional .data section
    
    Args:
        filename (str): Output filename (.s extension recommended)
        function_assembly (str): Assembly from NervaPy
        constants_dict (dict, optional): Constants to add to .data section
    
    Returns:
        str: Path to saved file
    
    Example:
        save_with_data(
            "output.s",
            func.assembly,
            {"my_const": 0x11111111}
        )
    """
    if constants_dict:
        complete = add_data_section(function_assembly, constants_dict)
    else:
        complete = function_assembly
    
    with open(filename, 'w') as f:
        f.write(complete)
    
    return filename


def create_test_c_program(asm_functions, output_filename="test.c"):
    """Generate a C test program for assembly functions
    
    Args:
        asm_functions (list): List of function names to test
        output_filename (str): C file output name
    
    Returns:
        str: C code as string
    
    Example:
        create_test_c_program(
            ["my_func", "another_func"],
            "test.c"
        )
    """
    includes = """#include <stdio.h>
#include <stdint.h>

"""
    
    # External declarations
    externs = "\n".join(
        f"extern void {func}(uint32_t *result);"
        for func in asm_functions
    )
    
    # Main function
    main = """

int main() {
    uint32_t result;
    
"""
    
    for func in asm_functions:
        main += f"""    {func}(&result);
    printf("{func}: 0x%08X (%u)\\n", result, result);
    
"""
    
    main += """    return 0;
}
"""
    
    c_code = includes + externs + main
    
    with open(output_filename, 'w') as f:
        f.write(c_code)
    
    return c_code


if __name__ == "__main__":
    # Example usage
    print("Example usage of nervapy_data_helper:")
    print()
    print("from nervapy_data_helper import add_data_section, save_with_data")
    print()
    print("# After generating your NervaPy function:")
    print("constants = {")
    print('    "my_constant": 0x11111111,')
    print('    "my_array": [1, 2, 3, 4],')
    print('    "my_string": "Hello, World!"')
    print("}")
    print()
    print("# Option 1: Get complete assembly")
    print("complete = add_data_section(func.assembly, constants)")
    print()
    print("# Option 2: Save directly to file")
    print('save_with_data("output.s", func.assembly, constants)')
```

---

**End of Guide**
