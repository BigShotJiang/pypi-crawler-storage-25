# Register Allocation Error Messages - Implementation Summary

## Problem
When code allocates too many registers, NervaPy previously threw a cryptic assertion error:
```
assert self.allocation_options[virtual_register_id]
```

This provided no information about:
- Which virtual register failed
- What type of register was needed
- How many registers are available
- Why allocation failed

**UPDATE**: After the initial fix, a new issue was discovered where the register count shown in error messages was inflated (e.g., showing 322 instead of 19 actual registers).

## Solution
Enhanced the register allocation error handling in `nervapy/arm/function.py` to provide informative error messages with accurate register counts.

### Changes Made

1. **Added helper methods** to `Function` class:
   - `_get_register_type_name(register_type)`: Returns human-readable register type names
   - `_get_available_registers_info(register_type)`: Returns information about available registers for each type
   - `_count_virtual_registers_by_type(register_type)`: Counts unique virtual registers (UPDATED to fix count inflation)

2. **Replaced assertions with informative RuntimeErrors**:
   - For register lists (line ~1351)
   - For individual registers (line ~1379)

3. **Fixed register count inflation** (NEW):
   - Save snapshot of `unallocated_registers` at start of allocation
   - Count unique register IDs instead of list entries
   - Handles duplicate entries caused by liveness tracking

### Example Error Messages

Before initial fix:
```
AssertionError
```

After initial fix (but with inflated count):
```
RuntimeError: Register allocation failed: No available physical registers for virtual register #78 (type: general-purpose). 
Your code uses 322 virtual general-purpose registers, but only ~13 physical registers are available.
Available general-purpose registers: r0-r12 (13 registers available for allocation)
```

After count fix:
```
RuntimeError: Register allocation failed: No available physical registers for virtual register #78 (type: general-purpose). 
Your code uses 19 virtual general-purpose registers, but only ~13 physical registers are available.
Available general-purpose registers: r0-r12 (13 registers available for allocation)
```

### Register Type Information Provided

- **General-purpose registers**: r0-r12 (13 registers available for allocation)
- **VFP/NEON registers**: s0-s31 or d0-d31 or q0-q15 (depending on instruction)
- **WMMX registers**: wr0-wr15 (16 registers)

### Testing

- All existing tests pass (3 ARMv7-M tests)
- Error message verified with test cases that allocate excessive virtual registers
- Count accuracy verified: shows 19 instead of previous inflated 322

### Benefits

1. **Immediate feedback**: Users know exactly which virtual register failed
2. **Clear guidance**: Shows register type and available count
3. **Accurate counts**: Shows actual number of unique registers used (not inflated by liveness tracking)
4. **Better debugging**: Users can quickly identify if they're using too many registers
5. **Professional UX**: Helpful error messages instead of cryptic assertions

## Technical Details

### Why Count Was Inflated

The `unallocated_registers` list in `determine_register_relations()` appends each virtual register once per instruction where it's live. This is necessary for conflict tracking but meant a register live in 20 instructions appeared 20 times in the list.

### The Fix

1. Save a snapshot: `self._all_virtual_registers = list(self.unallocated_registers)`
2. Count unique IDs: Use a set to deduplicate register IDs
3. Use snapshot: Read from `_all_virtual_registers` instead of the modified `unallocated_registers`

## Files Modified

- `nervapy/arm/function.py`: 
  - Added `_get_register_type_name()` method (line ~1204)
  - Added `_get_available_registers_info()` method (line ~1217)
  - Added `_count_virtual_registers_by_type()` method (line ~1232) - UPDATED to count unique IDs
  - Added `_get_max_physical_registers()` method (line ~1240)
  - Replaced assertions with informative RuntimeErrors (lines ~1351, ~1379)
  - Save register snapshot at allocation start (line ~1263)
  - Improved error handling for untracked registers (lines ~1409, ~1420)
