# MOV.W 32-bit Immediate Support - Implementation Summary

## What Was Added

Added `MOV_W()` function to NervaPy for explicit 32-bit Thumb-2 MOV.W instruction generation.

## Implementation

### Changes Made

1. **File**: `nervapy/arm/generic.py`
   - Added `MOV_W(destination, source)` function after the existing `MOV()` function
   - Creates a `MovInstruction` with name "MOV.W"
   - Follows the same pattern as other instruction wrappers

### Existing Infrastructure Used

The implementation leverages existing NervaPy infrastructure:

1. **Instruction Class**: `MovInstruction` already supported "MOV.W" in its allowed instructions list
2. **Validation**: `is_modified_immediate12()` already implements Thumb-2 modified immediate patterns including:
   - Pattern 0b00: `0x000000XY` - Simple 8-bit values
   - Pattern 0b01: `0x00XY00XY` - Byte in positions 0 and 2
   - Pattern 0b10: `0xXY00XY00` - Byte in positions 1 and 3
   - Pattern 0b11: `0xXYXYXYXY` - Same byte repeated 4 times (e.g., 0x11111111)
   - Rotated patterns for other valid encodings

## Usage Examples

### Basic Usage

```python
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture

f = Function("example", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f:
    MOV_W(r0, 0x11111111)  # Explicit 32-bit encoding
    MOV(r1, 0x22222222)    # Assembler chooses encoding
    BX(lr)
```

### Generated Assembly

```assembly
MOV.W r0, #286331153    @ 0x11111111
MOV   r1, #572662306    @ 0x22222222
```

### Verified Encoding

```
$ arm-none-eabi-objdump -d test_mov_w.o
00000000 <verify>:
   0:   f04f 3011       mov.w   r0, #286331153  @ 0x11111111
```

## Why This Works

The key insight is that `0x11111111` fits the Thumb-2 modified immediate encoding scheme:
- It matches pattern 0b11 (repeat same byte 4 times)
- The byte value `0x11` is encoded in the instruction
- The assembler reconstructs `0x11111111` at decode time

This is **not** a simple 12-bit immediate, but uses the special "modified immediate" encoding that allows certain 32-bit patterns to be represented in the instruction encoding.

## Comparison with Alternatives

| Method | Instructions | Literal Pool | Notes |
|--------|-------------|--------------|-------|
| `MOV_W(r0, 0x11111111)` | 1 | No | Only for modified immediates |
| `MOVW + MOVT` | 2 | No | Works for any 32-bit value |
| `LDR with literal` | 1 | Yes | Works for any 32-bit value |

## Valid Values

The following types of 32-bit values work with `MOV_W`:
- `0x11111111`, `0x22222222`, ..., `0xFFFFFFFF` (byte repetition)
- `0xFF00FF00`, `0x00FF00FF` (alternating bytes)
- `0x000000AB`, `0x000000CD` (simple 8-bit values)
- Various rotated patterns

## Files Created

1. **`MOV_W_32BIT_IMMEDIATE.md`** - User documentation
2. **`test_mov_w_32bit.py`** - Test and demonstration script
3. **`MOV_W_32BIT_SUPPORT.md`** - This implementation summary

## Testing

Run the test script:
```bash
python3 test_mov_w_32bit.py
```

Expected output shows:
- ✓ MOV_W generates correct assembly with .W suffix
- ✓ MOV also works with modified immediates
- ✓ Various patterns (repeated bytes, alternating, etc.) work correctly
- ✓ Assembly verifies to correct encoding (0x11111111)
