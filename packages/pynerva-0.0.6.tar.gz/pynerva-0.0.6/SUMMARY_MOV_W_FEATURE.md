# Summary: MOV.W 32-bit Immediate Support

## Overview

Added support for `MOV_W()` instruction in NervaPy to explicitly use the 32-bit Thumb-2 `MOV.W` encoding with modified immediate constants.

## The Problem

User asked: "how to do MOV.W lr, 0x11111111"

The answer is that `MOV.W #0x11111111` **is valid** in Thumb-2, because:
- Thumb-2 supports "modified immediate" encoding
- 0x11111111 fits the "repeat byte in all 4 positions" pattern (0xXYXYXYXY)
- The assembler recognizes this pattern automatically

## The Solution

1. **Added**: `MOV_W(destination, source)` function in `nervapy/arm/generic.py`
2. **Leveraged**: Existing `MovInstruction` class already supported "MOV.W"
3. **Leveraged**: Existing `is_modified_immediate12()` already validates byte patterns

## Code Change

**File**: `nervapy/arm/generic.py` (after line 8494)

```python
def MOV_W(destination, source):
    origin = (
        inspect.stack() if nervapy.arm.function.active_function.collect_origin else None
    )
    instruction = MovInstruction(
        "MOV.W", Operand(destination), Operand(source), origin=origin
    )
    if nervapy.stream.active_stream is not None:
        nervapy.stream.active_stream.add_instruction(instruction)
    return instruction
```

## Usage

```python
from nervapy.arm import *

# Explicit 32-bit encoding with .W suffix
MOV_W(lr, 0x11111111)

# Or let assembler choose
MOV(lr, 0x11111111)
```

## Generated Assembly

```assembly
MOV.W lr, #286331153    @ 0x11111111
```

## Verified Binary

```
$ arm-none-eabi-objdump -d
   0:   f04f 3011       mov.w   r0, #286331153  @ 0x11111111
```

## Testing

All tests pass:
- ✓ `MOV_W(r0, 0x11111111)` works
- ✓ `MOV(r0, 0x11111111)` works  
- ✓ Various patterns work (0x22222222, 0xFF00FF00, etc.)
- ✓ Invalid patterns correctly rejected (0x12345678)

## Documentation

Created:
1. **QUICKREF_MOV_W.md** - Quick reference guide
2. **MOV_W_32BIT_IMMEDIATE.md** - Full user documentation
3. **MOV_W_32BIT_SUPPORT.md** - Implementation details
4. **test_mov_w_32bit.py** - Test and demo script
5. **SUMMARY_MOV_W_FEATURE.md** - This summary

## Key Insight

The magic is in the Thumb-2 ISA itself:
- Modified immediate encoding supports special patterns
- Pattern 0b11: `0xXYXYXYXY` (repeat same byte 4 times)
- This makes `0x11111111`, `0x22222222`, etc. valid immediates
- NervaPy already supported this - we just added a convenient wrapper!

## Result

Users can now use `MOV_W()` for explicit 32-bit MOV instructions with modified immediates, providing a cleaner API than MOVW+MOVT for values that fit the encoding patterns.
