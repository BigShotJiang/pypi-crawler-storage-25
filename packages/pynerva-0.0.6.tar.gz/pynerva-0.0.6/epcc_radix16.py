#!/usr/bin/env python
# -*- coding: utf-8 -*-

# SPDX-FileCopyrightText: 2026 PQShield Ltd.
# SPDX-License-Identifier: LicenseRef-Proprietary
# SPDX-FileComment: Internal use only. Not for redistribution.
# SPDX-FileContributor: Kris Kwiatkowski <kris@pqshield.com>
#
# Proprietary and confidential.
#
# The code below require the Nervapy v0.0.5.

import argparse
from nervapy import Argument, ptr, const_uint32_t, uint32_t, uint64_t
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.registers import *
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.generic import UMULL, UMLAL
from nervapy import *
from nervapy.arm.literal_pool import Literal

def radix16(ret, a, b):
    """
    Brief: ,
  
    Parameters:
        - ret0 : 
        - ret1 : 
        - x   : 
        - y   : 

    Preconditions:
        - 
    
    Returns
        - out :
    """
    t0 = GeneralPurposeRegister() # a0
    t1 = GeneralPurposeRegister() # a1
    t2 = GeneralPurposeRegister() # a2
    t3 = GeneralPurposeRegister() # a3
    t4 = GeneralPurposeRegister() # b0
    t5 = GeneralPurposeRegister() # b1
    t6 = GeneralPurposeRegister() # b2
    t7 = GeneralPurposeRegister() # b3
    tm = lr # MASK
    tr0 = GeneralPurposeRegister()
    tr1 = GeneralPurposeRegister()
    tr2 = GeneralPurposeRegister()
    tr3 = GeneralPurposeRegister()
    tr4 = GeneralPurposeRegister()
    tr5 = GeneralPurposeRegister()
    tr6 = GeneralPurposeRegister()
    tr7 = GeneralPurposeRegister()

    # Notation: P(x,y) = a[x] * b[y]

    MOV_W(tm, 0x11111111)

    # C0
    AND(t0, tm, a)          # a[0] = (a >> 0) & 0x11111111
    AND(t4, tm, b)          # b[0] = (b >> 0) & 0x11111111
    UMULL(tr0, tr1, t0, t4) # P(0,0)
    AND(tr0, tr0, tm)       # Mask for C0 and store c0 in tr0

    # C1
    AND(t6, tm, b.LSR(1))    # b[2] = (b >> 1) & 0x11111111
    UMULL(tr2, tr3, t0, t6)  # P(0,2)
    AND(t5, tm, b.LSR(2))    # b[1] = (b >> 2) & 0x11111111
    UMLAL(tr1, tr2, t0, t5)  # P(0,1)
    AND(tr1, tr1, tm)        #   next: 7 + 8 + 8 = 23
    AND(t1, tm, a.LSR(2))    # a[1] = (a >> 2) & 0x11111111
    AND(tr2, tr2, tm)        #   next: 8 + 7 + 7 = 22
    UMLAL(tr1, tr2, t1, t4)  # P(1,0)
    AND(tr1, tr1, tm)        # final mask for C1
    EOR_W(tr0, tr0, tr1.LSL(2))
    print_live_registers("After ADD")

    # C2
    AND(t7, tm, b.LSR(3))    # b[3] = (b >> 3) & 0x11111111
    UMULL(tr4, tr5, t1, t7)  # P(1, 3)

    #for key,val in enumerate([tm, t0, t4, tr0, tr1, t1, t6, tr2, tr3, t5, t7, tr4, tr5, a, b, ret]):
    #    print(key, val)

    UMLAL(tr3, tr4, t0, t7)  # P(0, 3)
    AND(tr3, tr3, tm)        #   next: 7 + 8 + 7 = 22
    AND(tr2, tr2, tm)        #   next: 1 + 7 + 8 = 16
    UMLAL(tr2, tr3, t1, t5)  # P(1, 1)
    AND(tr3, tr3, tm)        #   next: 1 + 7 + 8 = 16
    AND(tr4, tr4, tm)        #   next: 8 + 7 + 7 = 22
    UMLAL(tr3, tr4, t1, t6)  # P(1, 2)
    AND(tr3, tr3, tm)        #   next: 1 + 8 + 7 = 16
    AND(tr2, tr2, tm)        #   next: 1 + 8 + 8 = 17
    AND(t2, tm, a.LSR(1))    # a[2] = (a >> 1) & 0x11111111
    UMLAL(tr2, tr3, t2, t4)  # P(2, 0)
    AND(tr2, tr2, tm)        # Mask for C2
    EOR_W(tr0, tr0, tr2.LSL(1))

    # C3
    AND(t3, tm, a.LSR(3))   # a[3] = (a >> 3) & 0x11111111
    AND(tr3, tr3, tm)        #    next: 1 + 7 + 8 = 16
    UMLAL(tr3, tr4, t2, t5)  # P(2, 1)
    AND(tr4, tr4, tm)        #    next: 1 + 7 + 7 + 8 = 23
    UMLAL(tr4, tr5, t2, t6)  # P(2, 2)
    AND(tr3, tr3, tm)        #    next: 1 + 8 + 8 = 17
    AND(tr4, tr4, tm)        #    next: 1 + 8 + 7 = 16
    UMLAL(tr3, tr4, t3, t4)  # P(3, 0)
    AND(tr3, tr3, tm)
    EOR_W(tr0, tr0, tr3.LSL(3))

    # C4, C5, C6, C7
    UMULL(tr6,tr7,t3,t7)     # P(3, 3)
    AND(tr5, tr5, tm)        #    next: 7 + 7 + 8 = 22
    UMLAL(tr5,tr6,t2,t7)     # P(2, 3)
    AND(tr5, tr5, tm)        #    next: 1 + 8 + 7 = 16
    AND(tr4, tr4, tm)        #    next: 1 + 7 + 8 = 16
    UMLAL(tr4, tr5, t3, t5)  # P(3, 1)
    AND(tr4, tr4, tm)        # Mask for C4
    AND(tr5, tr5, tm)        #    next: 1 + 7 + 8 = 16
    AND(tr6, tr6, tm)        #    next: 8 + 7 + 7 = 22
    UMLAL(tr5,tr6,t3,t6)     # P(3, 2)
    AND(tr6, tr6, tm)        # Mask for C6
    AND(tr7, tr7, tm)        # Mask for C7
    AND(tr5, tr5, tm)
    EOR_W(tr4, tr4, tr5.LSL(2))
    EOR_W(tr4, tr4, tr6.LSL(1))
    EOR_W(tr4, tr4, tr7.LSL(3))

    STR(tr0, [ret])          # Finalize C3
    STR(tr4, [ret, 4])

def run_generator(func_name, asm_format = AssemblyFormat.GAS):
    # Define function arguments
    out_arg = Argument(ptr(uint32_t))       # Output buffer
    x_arg = Argument(uint32_t)        # Input buffer
    y_arg = Argument(uint32_t)        # Input buffer

    # Configure the output function to be generated.
    f = Function(func_name, (out_arg, x_arg, y_arg,),
                target=Microarchitecture.CortexM33,
                abi=arm_gnueabihf,
                collect_origin=True)
    f.assembly_format = asm_format
    f.is_thumb = True
    f.alignment = 2                     # Set instruction alignment to 4 bytes for ARM/Thumb code
    f.validate_stack_alignment = True   # Validate stack alignment
    f.preserve8 = True                  # Ensure 8-byte stack alignment in ARMCC
    f.report_live_registers=True

    with f:
        ret = GeneralPurposeRegister()
        x = GeneralPurposeRegister()
        y = GeneralPurposeRegister()

        LOAD.ARGUMENT(ret, out_arg)
        LOAD.ARGUMENT(x, x_arg)
        LOAD.ARGUMENT(y, y_arg)

        f.preserve(lr)
        radix16(ret, x, y)
        RETURN()

    return f.assembly


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('format', choices=['gas', 'armcc'],
                       help='Assembly format: gas (GNU AS) or armcc (ARM Compiler)')
    args = parser.parse_args()

    asm_format = AssemblyFormat.GAS if args.format == 'gas' else AssemblyFormat.ARMCC
    asm = run_generator("epcc_radix16_asm", asm_format)
    with open("epcc_radix16_armv8m_{0}.s".format(asm_format.name.lower()), "w") as asm_file:
        asm_file.write(asm)