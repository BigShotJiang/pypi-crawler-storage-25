# Register Allocation Error Message Fix (v2)

## Problem

When register allocation failed, the error message showed **incorrect** counts of virtual registers used. Examples:

```
Your code uses 0 virtual general-purpose registers, but only ~13 physical registers are available.
```

or

```
Your code uses 271 virtual general-purpose registers, but only ~13 physical registers are available.
```

When in reality, the code might use 16 unique virtual registers.

## Root Cause

The `_count_virtual_registers_by_type()` method had multiple issues:

1. **Wrong data structure**: Attempted to decode register type from `allocation_options` keys, but these are simple register IDs (65, 66, 67...) without type information encoded
2. **Incorrect bit masking**: Tried to extract type bits using `reg_id & 0xFFF == 0x001`, but the IDs in `allocation_options` are just counters
3. **Duplicate entries**: `unallocated_registers` contains duplicates (each register appears once per instruction where it's live), requiring deduplication

## Solution (December 2024)

Rewrote `_count_virtual_registers_by_type()` to:

1. **Use correct data**: Count from `self.unallocated_registers` which contains tuples of `(virtual_register_id, virtual_register_type)`
2. **Use type directly**: Compare `virtual_register_type` directly instead of decoding from IDs
3. **Handle duplicates**: Use a set to track unique register IDs
4. **Handle register lists**: Properly count tuple registers (used for VFP/NEON operations)

```python
def _count_virtual_registers_by_type(self, register_type):
    """Count how many virtual registers of a given type are actually being allocated (after optimization)."""
    from nervapy.arm.registers import Register
    
    # Count unique registers in unallocated_registers that match the given type
    # This list has already been filtered by liveness analysis
    # Use a set to avoid counting duplicates
    unique_ids = set()
    for virtual_register_id, virtual_register_type in self.unallocated_registers:
        if isinstance(virtual_register_id, tuple):
            # Register list - all registers in the list should be the same type
            if virtual_register_type == register_type:
                unique_ids.update(virtual_register_id)
        else:
            # Single register
            if virtual_register_type == register_type:
                unique_ids.add(virtual_register_id)
    return len(unique_ids)
```

## Results

### Before Fix
```
RuntimeError: Register allocation failed: No available physical registers for virtual register #78 (type: general-purpose).
Your code uses 0 virtual general-purpose registers, but only ~13 physical registers are available.
```

### After Fix
```
RuntimeError: Register allocation failed: No available physical registers for virtual register #78 (type: general-purpose).
Your code uses 16 virtual general-purpose registers, but only ~13 physical registers are available.
Available general-purpose registers: r0-r12 (13 registers available for allocation)
To fix: reduce the number of registers used in your Python code.
```

## Testing

- ✓ All existing ARM tests pass (52 tests)
- ✓ All register-related tests pass (28 tests)
- ✓ Manual verification with test cases confirms accurate counts

## Impact

- Users now get **accurate** register counts in error messages
- Easier to debug register allocation failures
- Better understanding of code optimization opportunities
