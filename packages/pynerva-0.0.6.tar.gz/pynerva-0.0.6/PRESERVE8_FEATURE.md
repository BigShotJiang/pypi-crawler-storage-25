# PRESERVE8 Directive Support

## Overview

NervaPy now supports the optional `PRESERVE8` directive for ARMCC assembly output. The PRESERVE8 directive informs the ARM assembler (armasm) that the code maintains 8-byte stack alignment, as required by the ARM Embedded ABI (EABI).

## Usage

Add the `preserve8=True` parameter when creating a `Function` object with ARMCC assembly format:

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

input_arg = Argument(ptr(const_uint32_t))
output_arg = Argument(ptr(uint32_t))

with Function("my_function", (input_arg, output_arg),
             target=Microarchitecture.CortexM3,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.ARMCC,
             preserve8=True,  # Enable PRESERVE8 directive
             report_generation=False) as func:
    
    (input_ptr, output_ptr) = LOAD.ARGUMENTS()
    value = GeneralPurposeRegister()
    LDR(value, [input_ptr])
    STR(value, [output_ptr])
    RETURN()

print(func.assembly)
```

## Generated Assembly

### Without PRESERVE8 (default):
```assembly
        AREA    ||.text||, CODE, READONLY

my_function    PROC
        EXPORT  my_function
        ...
        ENDP
        END
```

### With PRESERVE8 enabled:
```assembly
        AREA    ||.text||, CODE, READONLY
        PRESERVE8

my_function    PROC
        EXPORT  my_function
        ...
        ENDP
        END
```

## Notes

- **Default behavior**: `preserve8=False` (no PRESERVE8 directive)
- **Format specific**: The PRESERVE8 directive only applies to ARMCC assembly format, not GAS format
- **Stack alignment**: The directive indicates that the code maintains 8-byte stack alignment as required by ARM EABI
- **Use case**: Particularly useful for ARMv7-M (Cortex-M) embedded systems requiring EABI compliance

## Example

See `examples/armcc_preserve8_example.py` for a complete working example.

## Testing

Run the PRESERVE8 tests:
```bash
python test_preserve8.py
```

## Related Features

- Stack alignment validation: `validate_stack_alignment` parameter
- High register handling: `high_register_strategy` parameter
- Assembly formats: `AssemblyFormat.GAS` and `AssemblyFormat.ARMCC`
