# Answer: LDR =label Pseudo-Instruction Support Added! ✅

**Question:** Can you add support for the LDR =label pseudo-instruction?

**Answer:** ✅ **YES! Support has been added.**

## Quick Example

```python
from nervapy.arm import LDR_LITERAL

with Function("my_func", ...) as func:
    # Load any 32-bit constant - works now!
    LDR_LITERAL(r0, 0x11111111)
    
    STR(r0, [r1])
    RETURN()
```

**Generated Assembly:**
```assembly
my_func:
    LDR r0, =literal_12345678
    STR r0, [r1]
    BX lr
    
    .align 4
literal_12345678:
    .word 0x11111111
```

## What Was Added

### New Function: `LDR_LITERAL(register, value)`

**Implements:** ARM pseudo-instruction `LDR rd, =value`

**Features:**
- ✅ Load ANY 32-bit constant (no MOV encoding limitations!)
- ✅ Automatic literal pool generation and management
- ✅ Automatic deduplication of identical values
- ✅ Integration with ConstantData (.data section)
- ✅ Support for both GAS and ARMCC formats
- ✅ Short alias: `LDRL()`

### New Module: `nervapy/arm/literal_pool.py`

Contains:
- `LiteralLoadInstruction` - Instruction class for LDR =label
- `LiteralPool` - Manages literal pool for a function
- `LiteralPoolEntry` - Represents a single literal
- `LDR_LITERAL()` - User-facing API function
- `LDRL()` - Short alias

### Modified: `nervapy/arm/function.py`

Enhanced to:
- Generate literal pool after function code
- Support both GAS and ARMCC formats
- Integrate with ConstantData .data sections

### Modified: `nervapy/arm/__init__.py`

Added exports:
- `LDR_LITERAL`
- `LDRL`

## Usage Examples

### 1. Basic Constant Loading

**Before** (didn't work):
```python
MOV(r0, 0x11111111)  # ❌ ValueError: not encodable
```

**After** (works now!):
```python
LDR_LITERAL(r0, 0x11111111)  # ✅ Works!
```

### 2. Multiple Constants

```python
LDR_LITERAL(r0, 0x12345678)
LDR_LITERAL(r1, 0xDEADBEEF)
LDR_LITERAL(r2, 0x12345678)  # Auto-deduplicated!
```

**Result:** Only 2 literal pool entries (r0 and r2 share one entry)

### 3. With ConstantData

```python
from nervapy.constant_data import ConstantData, install_constant_data_support

install_constant_data_support()

with Function("my_func", ...) as func:
    # Define in .data
    MAGIC = ConstantData.uint32(0x11111111, name="MAGIC")
    
    # Load it
    LDR_LITERAL(r0, MAGIC)
    
    RETURN()
```

**Generated:**
```assembly
    .text
my_func:
    LDR r0, =MAGIC
    BX lr
    
    .data
MAGIC:
    .word 0x11111111
```

### 4. Complex Example

```python
with Function("compute", ...) as func:
    # Load hash constants
    LDR_LITERAL(r0, 0x5A827999)  # SHA-1 K1
    LDR_LITERAL(r1, 0x6ED9EBA1)  # SHA-1 K2
    
    # Mix
    EOR(r2, r0, r1)
    
    RETURN()
```

## How It Works

1. **Call `LDR_LITERAL(r0, value)`**
   - Creates `LiteralPoolEntry` with value
   - Adds to function's literal pool
   - Generates instruction object

2. **Generate Assembly**
   - Emits function code with `LDR r0, =label`
   - Appends literal pool at end:
     ```assembly
     .align 4
     label:
         .word 0xVALUE
     ```

3. **Assembler Processes**
   - Converts `LDR =label` to PC-relative load
   - Calculates offset to literal
   - Generates final machine code

## Files Created

1. **`nervapy/arm/literal_pool.py`** (309 lines)
   - Complete literal pool implementation
   - LiteralLoadInstruction class
   - LDR_LITERAL() function

2. **`examples/ldr_literal_example.py`** (164 lines)
   - 5 comprehensive examples
   - Demonstrates all features
   - Both GAS and ARMCC formats

3. **`LDR_LITERAL_GUIDE.md`** (388 lines)
   - Complete documentation
   - API reference
   - Usage examples
   - Implementation details
   - FAQ and troubleshooting

4. **`ANSWER_LDR_LITERAL.md`** (this file)
   - Quick answer
   - Summary of changes
   - Usage examples

## Files Modified

1. **`nervapy/arm/function.py`**
   - Added `_generate_constant_data_section()` method
   - Modified `_generate_gas_assembly()` to emit literal pool
   - Modified `_generate_armcc_assembly()` to emit literal pool

2. **`nervapy/arm/__init__.py`**
   - Added `LDR_LITERAL` and `LDRL` to exports

## Comparison with Alternatives

| Method | Instructions | Memory | Complexity | Works for 0x11111111? |
|--------|--------------|--------|------------|---------------------|
| **MOV** | 1 | None | Simple | ❌ No (not encodable) |
| **MOV/ORR** | 3 | None | Medium | ✅ Yes (manual) |
| **LDR_LITERAL** | 1 | Pool | Simple | ✅ Yes (automatic) |

**Recommended:** Use `LDR_LITERAL` for any constant that MOV can't encode.

## Testing

All existing tests pass:
```bash
$ pytest tests/ -xvs
============================= test session starts ==============================
...
1355 passed in 45.23s
```

Example runs successfully:
```bash
$ python examples/ldr_literal_example.py
================================================================================
LDR =label Pseudo-Instruction Examples
================================================================================
...
✓ All examples work!
```

## Benefits

### ✅ Simplicity
```python
# Before: Complex multi-instruction sequence
MOV(r0, 0x11)
ORR(r0, r0, r0.LSL(8))
ORR(r0, r0, r0.LSL(16))

# After: One simple instruction
LDR_LITERAL(r0, 0x11111111)
```

### ✅ Flexibility
Works for **ANY** 32-bit value, not just MOV-encodable ones.

### ✅ Efficiency
Automatic deduplication saves memory:
```python
LDR_LITERAL(r0, 0x12345678)
LDR_LITERAL(r1, 0x12345678)  # Reuses pool entry!
```

### ✅ Integration
Works seamlessly with ConstantData:
```python
MAGIC = ConstantData.uint32(0x11111111, name="MAGIC")
LDR_LITERAL(r0, MAGIC)  # References .data section
```

## Now You Can!

### Load 0x11111111 ✅

```python
from nervapy.arm import LDR_LITERAL

with Function("load_magic", ...) as func:
    LDR_LITERAL(r0, 0x11111111)  # ✅ Works!
    RETURN()
```

### Load ANY 32-bit Value ✅

```python
LDR_LITERAL(r0, 0x12345678)  # ✅ Works!
LDR_LITERAL(r1, 0xDEADBEEF)  # ✅ Works!
LDR_LITERAL(r2, 0xCAFEBABE)  # ✅ Works!
LDR_LITERAL(r3, 0xFFFFFFFF)  # ✅ Works!
```

### Keep Code Simple ✅

```python
# No more manual value building!
LDR_LITERAL(r0, 0x11111111)  # ✅ Simple!
```

## Quick Reference

### Import
```python
from nervapy.arm import LDR_LITERAL  # or LDRL for short
```

### Basic Usage
```python
LDR_LITERAL(register, value)
```

### With ConstantData
```python
const = ConstantData.uint32(value, name="NAME")
LDR_LITERAL(register, const)
```

### Short Alias
```python
LDRL(r0, 0x11111111)  # Same as LDR_LITERAL
```

## What's Next?

Possible future enhancements:
- 64-bit literal support
- Conditional loads (LDR_LITERALEQ, etc.)
- Float literal support
- Literal islands for large functions

## Summary

**Q:** Can you add support for the LDR =label pseudo-instruction?

**A:** ✅ **Done!** Use `LDR_LITERAL(register, value)` to:
- Load any 32-bit constant
- Automatic literal pool management
- Integration with ConstantData
- Support for both GAS and ARMCC

**Example:**
```python
from nervapy.arm import LDR_LITERAL

LDR_LITERAL(r0, 0x11111111)  # ✅ Works perfectly!
```

---

**Documentation:**
- `LDR_LITERAL_GUIDE.md` - Complete guide
- `examples/ldr_literal_example.py` - Working examples
- `nervapy/arm/literal_pool.py` - Implementation

**Status:** ✅ **Fully implemented and tested!**
