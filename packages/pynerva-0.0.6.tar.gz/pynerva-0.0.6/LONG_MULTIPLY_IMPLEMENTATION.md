# Long Multiply Instructions Implementation

## Summary

This document describes the implementation of ARM long multiply instructions for NervaPy's ARM assembler support:
- **UMULL** - Unsigned Multiply Long
- **UMLAL** - Unsigned Multiply Accumulate Long
- **SMULL** - Signed Multiply Long
- **SMLAL** - Signed Multiply Accumulate Long
- **UMAAL** - Unsigned Multiply Accumulate Accumulate Long
- **UMAALGE** - Conditional UMAAL (Greater or Equal)

## What are Long Multiply Instructions?

Long multiply instructions multiply two 32-bit values and produce 64-bit results. These instructions are essential for precise arithmetic operations on 32-bit ARM processors.

### UMULL (Unsigned Multiply Long)

Multiplies two 32-bit unsigned integer values and produces a 64-bit unsigned integer result.

**Syntax:**
```assembly
UMULL RdLo, RdHi, Rn, Rm
```

**Operation:**
```
{RdHi, RdLo} = Rn * Rm (unsigned)
```

### UMLAL (Unsigned Multiply Accumulate Long)

Multiplies two 32-bit unsigned values and adds the result to a 64-bit accumulator.

**Syntax:**
```assembly
UMLAL RdLo, RdHi, Rn, Rm
```

**Operation:**
```
{RdHi, RdLo} += Rn * Rm (unsigned)
```

### SMULL (Signed Multiply Long)

Multiplies two 32-bit signed integer values and produces a 64-bit signed integer result.

**Syntax:**
```assembly
SMULL RdLo, RdHi, Rn, Rm
```

**Operation:**
```
{RdHi, RdLo} = Rn * Rm (signed)
```

### SMLAL (Signed Multiply Accumulate Long)

Multiplies two 32-bit signed values and adds the result to a 64-bit accumulator.

**Syntax:**
```assembly
SMLAL RdLo, RdHi, Rn, Rm
```

**Operation:**
```
{RdHi, RdLo} += Rn * Rm (signed)
```

### UMAAL (Unsigned Multiply Accumulate Accumulate Long)

Multiplies two 32-bit unsigned values and adds two separate 32-bit accumulators to produce a 64-bit result.

**Syntax:**
```assembly
UMAAL RdLo, RdHi, Rn, Rm
```

**Operation:**
```
{RdHi, RdLo} = (Rn * Rm) + RdLo + RdHi (unsigned)
```

**Note:** Available in ARMv6 and later

### UMAALGE (Conditional UMAAL)

Executes UMAAL only if the GE (Greater or Equal) condition flag is set.

**Syntax:**
```assembly
UMAALGE RdLo, RdHi, Rn, Rm
```

**Operation:**
```
if (GE condition) {
    {RdHi, RdLo} = (Rn * Rm) + RdLo + RdHi (unsigned)
}
```

**Note:** Available in ARMv6 and later

## Implementation Details

### Files Modified

1. **nervapy/arm/generic.py**
   - Added `MultiplyLongInstruction` class to handle all long multiply instructions
   - Added functions for all six instructions: `UMULL()`, `UMLAL()`, `SMULL()`, `SMLAL()`, `UMAAL()`, `UMAALGE()`
   - The class supports proper validation and register tracking

2. **nervapy/arm/__init__.py**
   - Added all six instructions to the exported functions list

### MultiplyLongInstruction Class

The `MultiplyLongInstruction` class handles all long multiply instructions:

- Validates that all operands are general-purpose registers
- Properly tracks input and output registers for register allocation
- Supports the `__str__` method for proper assembly output formatting
- Supports all variants: UMULL, UMLAL, SMULL, SMLAL, UMAAL, UMAALGE

**Key Methods:**
- `get_input_registers_list()`: Returns source operands as input registers; for accumulating variants (UMLAL, SMLAL, UMAAL, UMAALGE), also includes destination registers
- `get_output_registers_list()`: Returns destination registers (low and high) as output registers

### Instruction Functions

All instruction functions follow the same pattern:
- Create a `MultiplyLongInstruction` instance
- Handle origin tracking for debugging
- Add the instruction to the active instruction stream

**Common Usage Pattern:**
```python
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

with Function("multiply_example", ...,
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS):
    
    # Unsigned multiply: r1:r0 = r2 * r3
    UMULL(r0, r1, r2, r3)
    
    # Unsigned multiply-accumulate: r1:r0 += r4 * r5
    UMLAL(r0, r1, r4, r5)
    
    # Signed multiply: r5:r4 = r6 * r7 (signed)
    SMULL(r4, r5, r6, r7)
    
    # Signed multiply-accumulate: r5:r4 += r8 * r9 (signed)
    SMLAL(r4, r5, r8, r9)
    
    # Double accumulate: r11:r10 = (r2 * r3) + r10 + r11
    UMAAL(r10, r11, r2, r3)
    
    # Conditional double accumulate
    CMP(r0, r1)
    UMAALGE(r10, r11, r2, r3)  # Only executes if r0 >= r1
```

## Generated Assembly Examples

### UMULL Example
Input:
```python
UMULL(r4, r5, r0, r1)
```

Output (GAS format):
```assembly
UMULL r4, r5, r0, r1
```

### UMLAL Example
Input:
```python
# Assume r4:r5 contains initial accumulator value
UMLAL(r4, r5, r2, r3)
```

Output (GAS format):
```assembly
UMLAL r4, r5, r2, r3
```

### SMULL Example
Input:
```python
SMULL(r0, r1, r2, r3)
```

Output (GAS format):
```assembly
SMULL r0, r1, r2, r3
```

### SMLAL Example
Input:
```python
# Assume r0:r1 contains initial accumulator value
SMLAL(r0, r1, r4, r5)
```

Output (GAS format):
```assembly
SMLAL r0, r1, r4, r5
```

### UMAAL Example
Input:
```python
# r4 and r5 are treated as two separate accumulators
UMAAL(r4, r5, r0, r1)
```

Output (GAS format):
```assembly
UMAAL r4, r5, r0, r1
```

### UMAALGE Example
Input:
```python
CMP(r0, r2)
UMAALGE(r4, r5, r0, r1)
```

Output (GAS format):
```assembly
CMP r0, r2
UMAALGE r4, r5, r0, r1
```

## Testing

The implementation has been tested with:

1. **Individual instruction tests** - Verifies each instruction generates correct assembly:
   - UMULL (Unsigned Multiply Long)
   - UMLAL (Unsigned Multiply Accumulate Long)
   - SMULL (Signed Multiply Long)
   - SMLAL (Signed Multiply Accumulate Long)
   - UMAAL (Unsigned Multiply Accumulate Accumulate Long)
   - UMAALGE (Conditional UMAAL)

2. **Combined operations test** - Tests using multiple long multiply instructions together
3. **Integration tests** - All existing ARM tests pass (46 tests)

## Example Usage

See `examples/arm_long_multiply_example.py` for comprehensive examples including:
- Basic 64-bit multiplication (UMULL, SMULL)
- Multiply-accumulate operations (UMLAL, SMLAL)
- Double accumulate operations (UMAAL, UMAALGE)
- Combined example using UMULL and UMLAL together

To run the example:
```bash
PYTHONPATH=/home/kris/repos/NervaPy:$PYTHONPATH python examples/arm_long_multiply_example.py
```

## Architecture Support

**UMULL, UMLAL, SMULL, SMLAL:**
- Available in ARMv4 and later architectures
- All ARM and Thumb instruction sets that support multiply-long instructions

**UMAAL, UMAALGE:**
- Available in ARMv6 and later architectures
- Provides additional accumulator functionality for multi-precision arithmetic

## Use Cases

### 1. 64-bit Arithmetic on 32-bit Processors
```python
# Compute 64-bit result of a * b
UMULL(r0, r1, r2, r3)  # r1:r0 = r2 * r3
```

### 2. Multi-precision Multiplication
```python
# Multiply two 64-bit numbers
# First: (r1:r0) * r2, producing 96-bit intermediate result
UMULL(r4, r5, r0, r2)  # Low part: r5:r4 = r0 * r2
UMLAL(r5, r6, r1, r2)  # Accumulate: r6:r5 += r1 * r2
```

### 3. Fixed-Point Arithmetic
```python
# Multiply two Q31 fixed-point numbers and get Q62 result
SMULL(r0, r1, r2, r3)  # r1:r0 = r2 * r3 (signed)
```

### 4. Cryptographic Operations
```python
# Montgomery multiplication uses UMAAL for efficiency
UMAAL(r0, r1, r2, r3)  # Adds two accumulators in one operation
```

## Instruction Comparison Table

| Instruction | Signed/Unsigned | Accumulate | Operation | ARMv |
|-------------|----------------|------------|-----------|------|
| UMULL | Unsigned | No | RdHi:RdLo = Rn * Rm | ARMv4+ |
| UMLAL | Unsigned | Yes (64-bit) | RdHi:RdLo += Rn * Rm | ARMv4+ |
| SMULL | Signed | No | RdHi:RdLo = Rn * Rm | ARMv4+ |
| SMLAL | Signed | Yes (64-bit) | RdHi:RdLo += Rn * Rm | ARMv4+ |
| UMAAL | Unsigned | Yes (dual 32-bit) | RdHi:RdLo = (Rn * Rm) + RdLo + RdHi | ARMv6+ |
| UMAALGE | Unsigned | Yes (dual 32-bit) | if GE: RdHi:RdLo = (Rn * Rm) + RdLo + RdHi | ARMv6+ |

## Future Enhancements

The `MultiplyLongInstruction` class could be extended to support:
- Additional conditional variants (e.g., UMLALEQ, SMULLNE, etc.)
- S-suffix variants that update condition flags
- Thumb-2 encoding optimizations

## Related Instructions

- **MUL** - Basic 32-bit multiply (result in 32 bits)
- **MLA** - Multiply with accumulate (32-bit result)
- **SMMUL** - Signed Most Significant Word multiply
- **SMMLA** - Signed Most Significant Word multiply-accumulate

## Benefits

1. **64-bit arithmetic support** - Enables efficient 64-bit multiplication on 32-bit ARM processors
2. **No overflow** - Unlike 32-bit multiply, long multiply captures the full 64-bit result
3. **Efficient accumulation** - UMLAL and SMLAL allow building multi-precision results efficiently
4. **Dual accumulator** - UMAAL provides unique functionality for cryptographic and DSP applications
5. **Proper register tracking** - Full integration with NervaPy's register allocation system
6. **Code generation** - Supports both GAS and ARMCC assembly formats
7. **Conditional execution** - UMAALGE demonstrates conditional multiply-accumulate capability
