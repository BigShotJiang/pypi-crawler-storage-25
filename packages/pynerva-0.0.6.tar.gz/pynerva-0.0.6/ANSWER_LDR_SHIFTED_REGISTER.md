# Answer: Can LDR_W Generate `ldr.w r2, [r6, r5, lsl #2]`?

## YES! ✓

NervaPy **already supports** generating the instruction `ldr.w r2, [r6, r5, lsl #2]` using the `LDR_W` function.

## How to Generate This Instruction

```python
from nervapy.arm.registers import r2, r5, r6, ShiftedGeneralPurposeRegister
from nervapy.arm.generic import LDR_W

# Create a shifted register (r5 left-shifted by 2)
shifted_r5 = ShiftedGeneralPurposeRegister(r5, 'LSL', 2)

# Generate the instruction: ldr.w r2, [r6, r5, lsl #2]
instruction = LDR_W(r2, [r6, shifted_r5])

print(instruction)  # Output: LDR.W r2, [r6, r5, LSL #2]
```

## Quick Reference

### The Three Steps
1. Import `ShiftedGeneralPurposeRegister` from `nervapy.arm.registers`
2. Create a shifted register with the desired shift type and amount
3. Pass it as the second element in the memory address list to `LDR_W`

### Complete Working Example
```python
from nervapy.arm.registers import r2, r5, r6, ShiftedGeneralPurposeRegister
from nervapy.arm.generic import LDR_W
import nervapy.arm.function
import nervapy.stream

# Setup (required for instruction generation)
class MockFunction:
    collect_origin = False

nervapy.arm.function.active_function = MockFunction()
nervapy.stream.active_stream = None

# Create the shifted register
shifted_r5 = ShiftedGeneralPurposeRegister(r5, 'LSL', 2)

# Generate: ldr.w r2, [r6, r5, lsl #2]
instruction = LDR_W(r2, [r6, shifted_r5])
print(instruction)
```

**Output:**
```
LDR.W r2, [r6, r5, LSL #2]
```

## Supported Shift Types

| Shift | Description | Range | Example |
|-------|-------------|-------|---------|
| LSL | Logical Shift Left | 1-31 | `ShiftedGeneralPurposeRegister(r5, 'LSL', 2)` |
| LSR | Logical Shift Right | 1-32 | `ShiftedGeneralPurposeRegister(r5, 'LSR', 4)` |
| ASR | Arithmetic Shift Right | 1-32 | `ShiftedGeneralPurposeRegister(r5, 'ASR', 3)` |
| ROR | Rotate Right | 1-31 | `ShiftedGeneralPurposeRegister(r5, 'ROR', 8)` |

## All Supported Instructions

This addressing mode works with:
- **Load:** `LDR_W`, `LDRH_W`, `LDRSH_W`, `LDRB_W`, `LDRSB_W`
- **Store:** `STR_W`, `STRH_W`, `STRB_W`
- **Also works with non-wide variants:** `LDR`, `LDRH`, `LDRB`, `STR`, `STRH`, `STRB`

## Why Use Shifted Register Addressing?

This addressing mode is essential for efficient array access:

```python
# Array element access: array[index]
# For 32-bit (4-byte) elements, multiply index by 4
shifted = ShiftedGeneralPurposeRegister(index_reg, 'LSL', 2)
LDR_W(value_reg, [array_base_reg, shifted])

# Equivalent to: value = array[index]
# Generates: ldr.w value_reg, [array_base_reg, index_reg, lsl #2]
```

## Additional Resources

- **Example Script:** `examples/arm_ldr_shifted_register.py`
- **Documentation:** `docs/ARM_SHIFTED_REGISTER_ADDRESSING.md`
- **Implementation:** `nervapy/arm/registers.py` (ShiftedGeneralPurposeRegister class)
- **Validation:** `nervapy/arm/generic.py` (LoadStoreInstruction class)

## Verification

The feature has been tested and verified to work correctly:

```
✓ LDR.W with LSL #2
✓ STR.W with LSL #2
✓ LDRH.W with LSL #1
✓ LDR.W with LSR #4
✓ LDR.W with ASR #3
✓ LDR.W with ROR #4
```

All tests pass successfully!
