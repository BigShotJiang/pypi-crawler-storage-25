# Helium/MVE Phase 1 - Quick Reference

## ✅ Status: COMPLETE

## New Registers Available

### Predicate Registers (P0-P7)
```python
from nervapy.arm import p0, p1, p2, p3, p4, p5, p6, p7

# Properties
p0.size  # 2 (bytes) = 16 bits
str(p0)  # "p0"
```

### Vector Predicate Register (VPR)
```python
from nervapy.arm import vpr

# Properties
vpr.size  # 4 (bytes) = 32 bits
str(vpr)  # "vpr"
```

### Q Registers (Already Existed)
```python
from nervapy.arm import q0, q1, q2, q3, q4, q5, q6, q7

# Properties
q0.size  # 16 (bytes) = 128 bits
str(q0)  # "q0"
```

## Register Classes

```python
from nervapy.arm import PRegister, VPRRegister, QRegister

# Create virtual registers (within function context)
virtual_p = PRegister()  # Virtual predicate register
virtual_q = QRegister()  # Virtual Q register
```

## Implementation Details

### Register Numbering
- P0: 0x30001
- P1: 0x31001
- ...
- P7: 0x37001
- VPR: 0x40001

### Register Types
- PRegister.MVEPredicateType = 4
- VPRRegister.MVEVectorPredicateType = 5
- Register.VFPType = 3 (for Q registers)

## Files Modified
- `nervapy/arm/registers.py` - Added PRegister, VPRRegister classes
- `nervapy/arm/function.py` - Added allocate_p_register()
- `nervapy/arm/__init__.py` - Exported new registers

## Testing
```bash
# Run Phase 1 test
python test_helium_phase1.py

# Run all tests
python -m pytest tests/ -v
```

## Next Phase
**Phase 2**: Core Load/Store MVE instructions
- VLDRW.U32, VSTRW.U32
- VLDRB/H/D, VSTRB/H/D variants
