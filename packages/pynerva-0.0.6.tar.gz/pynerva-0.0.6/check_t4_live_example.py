#!/usr/bin/env python
"""Example: How to check if a specific register (like t4) is live at any point."""

from nervapy import *
from nervapy.arm import *
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.instructions import Instruction

print("=" * 70)
print("Example: Checking if specific virtual registers are live")
print("=" * 70)

# Create a function with several virtual registers
func = Function("example_func", 
                (Argument(uint32_t, "x"), Argument(uint32_t, "y")),
                target=Microarchitecture.CortexM33,
                abi=arm_gnueabihf)

with func:
    # Create virtual registers
    t0 = GeneralPurposeRegister()  # Will be vreg 0
    t1 = GeneralPurposeRegister()  # Will be vreg 1
    t2 = GeneralPurposeRegister()  # Will be vreg 2
    t3 = GeneralPurposeRegister()  # Will be vreg 3
    t4 = GeneralPurposeRegister()  # Will be vreg 4
    
    # Store the virtual register IDs for later checking
    t0_id = t0.id
    t1_id = t1.id
    t2_id = t2.id
    t3_id = t3.id
    t4_id = t4.id
    
    # Do some operations
    ADD(t0, r0, r1)        # t0 = x + y
    ADD(t1, t0, t0)        # t1 = t0 + t0
    ADD(t1, t1, t0)        # t1 = t1 + t0 (approx t0 * 3)
    LSL(t2, t1, 2)         # t2 = t1 << 2
    
    # t4 is defined here
    MOV(t4, r1)            # t4 = r1
    
    # t3 uses t2 and t4
    ADD(t3, t2, t4)        # t3 = t2 + t4
    
    # More operations where t4 is NOT used anymore
    ADD(t0, t3, 10)        # t0 = t3 + 10
    
    # Return result
    MOV(r0, t0)
    RETURN()

print(f"\nVirtual register IDs:")
print(f"  t0 = vreg {t0_id}")
print(f"  t1 = vreg {t1_id}")
print(f"  t2 = vreg {t2_id}")
print(f"  t3 = vreg {t3_id}")
print(f"  t4 = vreg {t4_id}")

print(f"\n{'Instruction':<50s} | t4 live?")
print("-" * 70)

# Check at each instruction if t4 is live
for i, instr in enumerate(func.instructions):
    if isinstance(instr, Instruction):
        # Check if t4_id is in the live registers
        t4_is_live = any(reg.id == t4_id for reg in instr.live_registers 
                        if hasattr(reg, 'id'))
        
        status = "YES" if t4_is_live else "no"
        print(f"[{i:2d}] {str(instr):<45s} | {status}")

print("\n" + "=" * 70)
print("Analysis:")
print("=" * 70)

# Find where t4 becomes live and dies
first_live = None
last_live = None

for i, instr in enumerate(func.instructions):
    if isinstance(instr, Instruction):
        if any(reg.id == t4_id for reg in instr.live_registers if hasattr(reg, 'id')):
            if first_live is None:
                first_live = i
            last_live = i

if first_live is not None:
    print(f"\nt4 (vreg {t4_id}) is live from instruction {first_live} to {last_live}")
    print(f"  First live at: {func.instructions[first_live]}")
    print(f"  Last live at:  {func.instructions[last_live]}")
    print(f"\nThis means t4's value is needed from when it's defined")
    print(f"until the last instruction that uses it.")
else:
    print(f"\nt4 (vreg {t4_id}) is NEVER live!")
    print(f"This means it's dead code - the value is computed but never used.")

print("\n" + "=" * 70)
print("How to use this in your code:")
print("=" * 70)
print("""
# After generating a function:
func = Function(...)
with func:
    t4 = GeneralPurposeRegister()
    t4_id = t4.id  # Save the ID
    # ... your code ...

# Check if t4 is live at any instruction:
for instr in func.instructions:
    if isinstance(instr, Instruction):
        is_live = any(r.id == t4_id for r in instr.live_registers if hasattr(r, 'id'))
        if is_live:
            print(f"t4 is live at: {instr}")
""")
