# Improved Register Allocation Error Messages

## Summary

Enhanced the register allocation failure error messages to provide more actionable debugging information when the allocator cannot find a valid register assignment.

## Changes Made

### Enhanced Error Diagnostics in `nervapy/arm/function.py`

When register allocation fails, the error message now includes:

1. **Register Pressure Analysis**: Shows the maximum number of simultaneously live registers vs. available physical registers
2. **Critical Instruction**: Identifies the specific instruction where maximum register pressure occurs
3. **Live Register List**: Lists all virtual registers that are live at the point of maximum pressure
4. **Contextual Advice**: Provides different guidance based on whether the issue is:
   - Register pressure at the limit (manageable but allocator made suboptimal choices)
   - Register pressure exceeding available registers (code needs restructuring)

## Error Message Format

### Before
```
RuntimeError: Register allocation failed: No available physical registers for virtual register #81 (type: general-purpose).
Your code uses 17 virtual general-purpose registers, but only ~13 physical registers are available.
Available general-purpose registers: r0-r12 (13 registers available for allocation)
To fix: reduce the number of registers used in your Python code.
```

### After
```
RuntimeError: Register allocation failed: No available physical registers for virtual register #81 (type: general-purpose).
Your code uses 17 virtual general-purpose registers, but only ~13 physical registers are available.
Available general-purpose registers: r0-r12 (13 registers available for allocation)
To fix: reduce the number of registers used in your Python code.

DEBUG: Max simultaneous live general-purpose registers: 13
Physical registers available: 13
The register pressure (13/13) should be manageable, but the allocator
couldn't find a valid allocation due to conflicting constraints.
Instruction with max pressure: UMLAL gp-vreg<15>, gp-vreg<16>, gp-vreg<4>, gp-vreg<11>
Live virtual registers: gp-vreg<10>, gp-vreg<11>, gp-vreg<14>, gp-vreg<15>, gp-vreg<16>, gp-vreg<17>, gp-vreg<1>, gp-vreg<2>, gp-vreg<4>, gp-vreg<5>, gp-vreg<6>, gp-vreg<8>, gp-vreg<9>

This suggests the greedy allocator made suboptimal early choices.
Try reordering your code or reducing temporary register usage.
```

## Key Insights

### Understanding the Issue

The improved error message reveals that:
- The original count of "17 virtual registers" refers to the total number of unique virtual registers in the function
- These 17 registers are NOT all live simultaneously
- At the critical point, only 13 registers are live (exactly matching the available physical registers)
- The greedy register allocator's allocation order caused it to run out of valid options for register #81

### Why Allocation Can Fail at 13/13 Pressure

When register pressure is exactly at the limit (13/13), the greedy allocator must make perfect allocation choices. If it:
1. Allocates an early register to a physical register that's needed later
2. Creates conflicts that block allocation of later registers
3. Reaches a register with no remaining valid allocation options

Then allocation fails, even though mathematically there might be a valid allocation if different choices were made earlier.

## Recommendations for Users

When you see register pressure at or near the limit:

1. **Identify the Critical Section**: Look at the instruction with max pressure and the surrounding code
2. **Reduce Temporary Register Usage**: 
   - Reuse registers more aggressively
   - Store intermediate results to memory if needed
   - Break complex expressions into simpler ones that don't accumulate live values
3. **Reorder Operations**: Sometimes changing the order of operations allows registers to be freed earlier
4. **Split the Function**: Consider breaking the function into smaller pieces

## Technical Details

The debug information is computed by:
1. Scanning all instructions after liveness analysis
2. Counting virtual registers of the target type that are live at each instruction
3. Tracking the instruction with maximum live register count
4. Reporting this information when allocation fails

This helps distinguish between:
- Code that truly needs more registers than available (max_live > available)
- Code where the allocator made suboptimal choices (max_live <= available)
