# Barrel Shifter Test Fix

## Problem

The file `tests/arm/test_barrel_shifter.py` was failing because:
1. It contained code that executed at module import time (not in test functions)
2. One of these module-level statements (`AND(tr2, tr2.LSL(1), tm.LSL(1))`) raised a `ValueError`
3. This prevented pytest from collecting any tests from the file

## Solution

Converted the script-style test file into a proper unittest test suite:
- Wrapped all test code in unittest test methods
- Added proper error handling with `self.assertRaises()` for invalid operations
- Converted print-based validation to assertion-based tests
- Added additional tests for other barrel shifter operations (LSR, ASR, ROR)

## Changes Made

### Before
- Script-style file with `print()` statements
- Tests executed at module import time
- Unhandled exception in test 6 caused collection failure

### After
- Proper unittest.TestCase class with 8 test methods
- All code runs within test functions
- Proper assertions and error checking
- Tests for both valid and invalid barrel shifter usage

## Tests Added

1. **test_and_with_shifted_source** - Tests `AND(tr2, tm.LSL(1))`
2. **test_and_with_explicit_destination_and_shifted** - Tests `AND(tr2, tr2, tm.LSL(1))`
3. **test_and_with_shifted_destination_raises_error** - Verifies shifting destination raises error
4. **test_and_with_both_operands_shifted_raises_error** - Verifies shifting both operands raises error
5. **test_and_then_shift_separate_instructions** - Tests `AND` followed by `LSL`
6. **test_barrel_shifter_with_lsr** - Tests LSR (logical shift right)
7. **test_barrel_shifter_with_asr** - Tests ASR (arithmetic shift right)
8. **test_barrel_shifter_with_ror** - Tests ROR (rotate right)

## Test Results

```
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_and_then_shift_separate_instructions PASSED
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_and_with_both_operands_shifted_raises_error PASSED
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_and_with_explicit_destination_and_shifted PASSED
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_and_with_shifted_destination_raises_error PASSED
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_and_with_shifted_source PASSED
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_barrel_shifter_with_asr PASSED
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_barrel_shifter_with_lsr PASSED
tests/arm/test_barrel_shifter.py::TestBarrelShifter::test_barrel_shifter_with_ror PASSED

8 passed in 0.11s
```

## ARM Test Suite Summary

Total ARM tests: **98 tests** (all passing)
- 34 multiply instruction tests
- 52 other ARM tests  
- 8 barrel shifter tests (newly fixed)
- 4 preserve8 tests (from other files in tests/arm/)

## Key Features Tested

✓ Barrel shifter with LSL (logical shift left)
✓ Barrel shifter with LSR (logical shift right)
✓ Barrel shifter with ASR (arithmetic shift right)
✓ Barrel shifter with ROR (rotate right)
✓ Valid shift operations (source operand only)
✓ Invalid shift operations (destination or multiple operands)
✓ Proper error handling for unsupported ARM instruction patterns

## Verification

✓ All 8 barrel shifter tests pass
✓ No regressions - all 98 ARM tests pass
✓ Proper unittest structure
✓ Tests both valid and invalid barrel shifter usage
