# Answer: How to do MOV.W lr, 0x11111111

## Quick Answer

```python
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture

f = Function("example", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f:
    MOV_W(lr, 0x11111111)  # ✓ This works!
    BX(lr)

print(f.assembly)
```

**Output:**
```assembly
MOV.W lr, #286331153    @ 0x11111111
```

## Why This Works

`MOV.W #0x11111111` is **valid** in Thumb-2, contrary to what you might expect.

Thumb-2's 32-bit MOV instruction uses "modified immediate" encoding that supports special patterns:
- **Pattern 0b11**: Repeat the same byte in all 4 positions (`0xXYXYXYXY`)
- `0x11111111` is encoded as "repeat 0x11 in every byte"

The assembler recognizes this pattern and generates the correct encoding automatically.

## Verified with Real Assembler

```bash
$ arm-none-eabi-objdump -d test.o
00000000 <example>:
   0:   f04f 3011       mov.w   lr, #286331153  @ 0x11111111
   4:   4770            bx      lr
```

## Other Values That Work

The following 32-bit values also work with MOV_W:

```python
MOV_W(r0, 0x11111111)  # All bytes = 0x11
MOV_W(r1, 0x22222222)  # All bytes = 0x22
MOV_W(r2, 0xFFFFFFFF)  # All bytes = 0xFF
MOV_W(r3, 0xFF00FF00)  # Alternating pattern
MOV_W(r4, 0x00FF00FF)  # Alternating pattern
MOV_W(r5, 0x000000AB)  # Simple 8-bit value
```

## Alternative: Using Regular MOV

You can also use regular `MOV()` and let the assembler choose the encoding:

```python
MOV(lr, 0x11111111)  # Also works - assembler chooses encoding
```

This generates:
```assembly
MOV lr, #286331153    @ 0x11111111
```

## For Arbitrary 32-bit Values

If your value doesn't fit the modified immediate pattern (e.g., `0x12345678`), use:

**Option 1: MOVW + MOVT** (2 instructions, no literal pool)
```python
MOVW(lr, 0x5678)
MOVT(lr, 0x1234)
```

**Option 2: LDR with literal** (1 instruction, uses literal pool)
```python
LDR(lr, literal=Literal(0x12345678))
```

## Summary

✓ **Use `MOV_W(lr, 0x11111111)`** - it's valid and generates a single instruction!

The key insight: Not all 32-bit immediates work, but repeating byte patterns like 0x11111111 do work because of Thumb-2's modified immediate encoding scheme.
