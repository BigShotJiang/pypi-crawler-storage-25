# Register Names in Error Messages - Implementation Summary

## Overview
Enhanced register allocation error messages to include Python variable names alongside virtual register IDs, making debugging significantly easier.

## Changes Made

### Modified File: `nervapy/arm/function.py`

**Location:** Lines 1508-1526 (in the `allocate_registers` method)

**Change:** Modified the code that collects live registers to include variable names from the `_register_names` dictionary.

**Before:**
```python
max_live_regs = [str(r) for r in live_regs]
```

**After:**
```python
# Include variable names in the register representation
max_live_regs = []
for r in live_regs:
    reg_str = str(r)
    var_name = self._register_names.get(r.number, None)
    if var_name:
        reg_str = f"{reg_str}, {var_name}"
    max_live_regs.append(reg_str)
```

## How It Works

1. The function already tracks register names in the `self._register_names` dictionary (mapping register number → variable name)
2. When building the error message, we now look up each register's name in this dictionary
3. If a name exists, it's appended to the register representation

## Example Output

### Before:
```
Live virtual registers: gp-vreg<10>, gp-vreg<11>, gp-vreg<12>, gp-vreg<13>
```

### After:
```
Live virtual registers: gp-vreg<10, t6>, gp-vreg<11, t7>, gp-vreg<12, tr0>, gp-vreg<13, tr1>
```

## Full Error Message Example

```
Register allocation failed: No available physical registers for virtual register #81 (type: general-purpose).
Your code uses 17 virtual general-purpose registers, but only ~13 physical registers are available.
Available general-purpose registers: r0-r12 (13 registers available for allocation)
To fix: reduce the number of registers used in your Python code.

Physical registers available: 13
The register pressure (13/13) should be manageable, but the allocator
couldn't find a valid allocation due to conflicting constraints.
Max register pressure at File: /home/kris/repos/ams/hqc-c/src/hqc/src/epcc_radix16.py, Line: 92
Instruction with max pressure: UMLAL gp-vreg<3>, gp-vreg<2>, gp-vreg<4>, gp-vreg<11>
Source code: UMLAL(tr3, tr1, t0, t7)  # P(0, 3)
Live virtual registers: gp-vreg<10, t6>, gp-vreg<11, t7>, gp-vreg<12, tr0>, gp-vreg<13, tr1>, gp-vreg<15, tr3>, gp-vreg<17, tr5>, gp-vreg<1, ret>, gp-vreg<2, x>, gp-vreg<3, y>, gp-vreg<4, t0>, gp-vreg<5, t1>, gp-vreg<8, t4>, gp-vreg<9, t5>
```

## Benefits

1. **Easier Debugging:** Developers can immediately see which Python variables are causing register pressure
2. **Better Context:** Variable names provide semantic meaning (e.g., `t6` vs just `gp-vreg<10>`)
3. **Faster Problem Resolution:** No need to manually correlate virtual register IDs with variable names

## Testing

Tested with `epcc_radix16.py` which shows proper output when using `print_live_registers()`:
```
Live registers After ADD:
  GP (13): lr, gp-vreg<1, ret>, gp-vreg<2, x>, gp-vreg<3, y>, gp-vreg<4, t0>, gp-vreg<5, t1>, gp-vreg<8, t4>, gp-vreg<9, t5>, gp-vreg<10, t6>, gp-vreg<12, tr0>, gp-vreg<13, tr1>, gp-vreg<14, tr2>, gp-vreg<15, tr3>
```

## Notes

- Variable names are only shown if they were tracked (requires `collect_origin=True` or automatic tracking)
- If a register has no associated name, only the virtual register ID is shown
- This change is backward compatible - the format simply adds more information
