# C Inline Assembly Feature - Implementation Summary

## Overview

Added support for generating inline assembly for C that can be directly embedded into C functions, avoiding function call overhead. This feature supports both **ARM** and **x86-64** architectures with their respective compilers.

## Supported Platforms

### ARM Architecture
- **GCC/Clang** (GNU ARM Embedded Toolchain, Clang ARM) - ARM assembly syntax
- **ARMCC** (ARM Compiler 5/6) - ARM assembly syntax

### x86-64 Architecture  
- **GCC/Clang** - AT&T syntax (standard for both compilers)
- **MSVC** - Note provided (MSVC x64 doesn't support inline assembly)

## Changes Made

### 1. Core Implementation

#### ARM (`nervapy/arm/function.py`)

Added properties and helper methods to the `Function` class:

**New Properties:**
- **`c_inline_asm_gcc`** - Generates GCC-style extended inline assembly
- **`c_inline_asm_armcc`** - Generates ARMCC-style inline assembly

**New Helper Methods:**
- **`_generate_c_inline_asm(compiler)`** - Main dispatcher for inline asm generation
- **`_generate_gcc_inline_asm(instructions)`** - Generates GCC-specific syntax
- **`_generate_armcc_inline_asm(instructions)`** - Generates ARMCC-specific syntax

#### x86-64 (`nervapy/x86_64/function.py`)

Added properties and helper methods to the `ABIFunction` class:

**New Properties:**
- **`c_inline_asm_gcc`** - Generates GCC/Clang inline assembly (AT&T syntax)
- **`c_inline_asm_msvc`** - Generates MSVC note (x64 doesn't support inline asm)

**New Helper Methods:**
- **`_generate_c_inline_asm(compiler)`** - Main dispatcher for inline asm generation
- **`_generate_gcc_inline_asm_x86_64(instructions)`** - Generates AT&T syntax for GCC
- **`_generate_msvc_inline_asm_x86_64(instructions)`** - Generates MSVC guidance

### 2. Key Features

- **Function call overhead elimination**: Inline assembly removes the overhead of BL/BX, PUSH/POP instructions
- **Compiler-specific syntax**: Proper syntax for both GCC and ARMCC compilers
- **Clean integration**: Works alongside existing `assembly` and `global_asm` properties
- **Prologue/epilogue filtering**: Automatically excludes function setup/teardown code that's not needed in inline context

### 3. Example Usage

```python
from nervapy import *
from nervapy.arm import *

# Generate function
with Function("vector_add", args, ...) as f:
    # ... function body ...
    pass

# Get different output formats:
gcc_inline = f.c_inline_asm_gcc      # For GCC compiler
armcc_inline = f.c_inline_asm_armcc  # For ARM compiler
regular_asm = f.assembly              # Regular .s file
rust_asm = f.global_asm               # Rust global_asm!()
```

### 4. Example Output

#### GCC Format:
```c
/* GCC inline assembly for function: copy_words */
__asm__ volatile(
    ".Lcopy_words_loop_begin:\n\t"
    "LDR r12, [r0], #4\n\t"
    "STR r12, [r1], #4\n\t"
    "SUBS r2, r2, #1\n\t"
    "BNE .Lcopy_words_loop_begin\n\t"
    : /* outputs */
    : /* inputs */
    : "memory" /* clobbers */
);
```

#### ARMCC Format:
```c
/* ARMCC inline assembly for function: copy_words */
__asm {
copy_words_loop_begin
    LDR r12, [r0], #4
    STR r12, [r1], #4
    SUBS r2, r2, #1
    BNE copy_words_loop_begin
}
```

## Files Added/Modified

### Modified:
- **`nervapy/arm/function.py`**:
  - Added `@property c_inline_asm_gcc`
  - Added `@property c_inline_asm_armcc`
  - Added `_generate_c_inline_asm()` method
  - Added `_generate_gcc_inline_asm()` method
  - Added `_generate_armcc_inline_asm()` method

- **`nervapy/x86_64/function.py`**:
  - Added `@property c_inline_asm_gcc`
  - Added `@property c_inline_asm_msvc`
  - Added `_generate_c_inline_asm()` method
  - Added `_generate_gcc_inline_asm_x86_64()` method
  - Added `_generate_msvc_inline_asm_x86_64()` method

### Added:
- **`examples/c_inline_asm_example.py`** - ARM inline assembly examples:
  - Vector addition kernel
  - Array sum kernel
  - Array scaling kernel
  - Complete C code examples for both GCC and ARMCC
  - Performance comparison notes
  
- **`examples/c_inline_asm_x86_64_example.py`** - x86-64 inline assembly examples:
  - SSE vector addition kernel
  - Complete C code examples for GCC/Clang
  - MSVC guidance and alternatives
  - Performance comparison notes
  
- **`tests/arm/test_c_inline_asm.py`** - ARM test suite with 9 tests:
  - Property existence
  - GCC/ARMCC syntax validation
  - Prologue/epilogue filtering
  - Loop constructs
  - Multi-target compatibility

- **`tests/x86_64/test_c_inline_asm.py`** - x86-64 test suite with 8 tests:
  - Property existence
  - GCC/MSVC handling
  - AT&T syntax validation
  - Return instruction filtering
  - SSE instruction support
  
- **`C_INLINE_ASM_FEATURE.md`** - Documentation including:
  - Feature overview
  - Usage examples
  - Performance benefits
  - When to use inline vs regular assembly
  - Complete API reference

- **`C_INLINE_ASM_TESTS.md`** - Test documentation including:
  - Test descriptions
  - Test results
  - Coverage details

## Performance Benefits

### Typical Function Call Overhead (Cortex-M):
- BL instruction: 1-3 cycles
- PUSH (save registers): 1 cycle × N registers
- POP (restore registers): 1 cycle × N registers  
- BX lr (return): 1-3 cycles
- **Total**: ~8-12 cycles per call

### Impact:
For an inner loop executed 1000 times, eliminating function call overhead saves 8,000-12,000 cycles!

## Use Cases

### When to Use Inline Assembly:
✅ Inner loops where every cycle counts  
✅ Tight DSP kernels (filters, convolution)  
✅ Performance-critical signal processing  
✅ When profiling shows function call overhead matters  

### When to Use Regular Assembly Functions:
✅ Large, complex functions  
✅ Code reused across multiple C functions  
✅ When debugging is important  
✅ When function call overhead is negligible  

## Testing

### Automated Test Suite

#### ARM Tests (`tests/arm/test_c_inline_asm.py`)
- 9 comprehensive tests covering:
  - Property existence verification
  - GCC inline assembly syntax validation
  - ARMCC inline assembly syntax validation
  - Dual format generation from same function
  - Prologue/epilogue filtering
  - Loop construct handling
  - Multi-target compatibility (CortexM3, M4, M7)

**Test Results**: 9/9 passed ✓

#### x86-64 Tests (`tests/x86_64/test_c_inline_asm.py`)
- 8 comprehensive tests covering:
  - Property existence verification
  - GCC/Clang inline assembly (AT&T syntax) validation
  - MSVC handling (warning message generation)
  - Dual format generation from same function
  - Return instruction filtering
  - Loop construct handling
  - SSE instruction support

**Test Results**: 8/8 passed ✓

### Total Test Coverage
- **17 tests** across both architectures
- **17 passed**, 0 failed
- No regressions in existing tests

### Manual Testing
The features have also been manually tested with:
- ARM: Vector operations (addition, scaling, sum), register allocation
- x86-64: SSE operations, loop constructs, AT&T syntax
- Both GCC and ARMCC output formats (ARM)
- GCC/Clang AT&T syntax (x86-64)
- Integration with existing `assembly` and `global_asm` properties

See `C_INLINE_ASM_TESTS.md` for detailed test documentation.

## Compatibility

- **Rust support**: Already existed via `global_asm` property (unchanged)
- **C support - ARM**: Now added via `c_inline_asm_gcc` and `c_inline_asm_armcc` properties (NEW)
- **C support - x86-64**: Now added via `c_inline_asm_gcc` and `c_inline_asm_msvc` properties (NEW)
- **Regular assembly**: Still supported via `assembly` property (unchanged)

All existing functionality remains intact and backward compatible.

**Platform Support:**
- ✅ ARM (GCC, Clang, ARMCC)
- ✅ x86-64 (GCC, Clang with AT&T syntax, MSVC guidance)

## Running the Examples

```bash
# ARM inline assembly
PYTHONPATH=. python examples/c_inline_asm_example.py

# x86-64 inline assembly  
PYTHONPATH=. python examples/c_inline_asm_x86_64_example.py
```

## Notes for Users

1. **GCC inline assembly**: May need to adjust input/output constraints based on actual usage
2. **Register assumptions**: Generated code assumes parameters are in r0-r3 per ARM ABI
3. **Testing recommended**: Always verify generated code works correctly in your context
4. **Compiler optimization**: Inline assembly interacts with compiler optimization differently than regular functions

## Future Enhancements

Potential improvements for future versions:
- Automatic constraint generation for GCC based on function arguments
- Detection and handling of return values
- Support for more complex calling conventions
- Better integration with C parameter passing

## Summary

This feature provides a powerful way to eliminate function call overhead in performance-critical code while maintaining the benefits of NervaPy's high-level assembly generation. It complements the existing Rust `global_asm!()` support and regular assembly file generation, giving users maximum flexibility in how they integrate generated code into their projects.
