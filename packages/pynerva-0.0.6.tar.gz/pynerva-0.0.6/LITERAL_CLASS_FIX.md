# Literal Class Format Fix

## Problem
When using `LDR(r0, literal=Literal(0x11111111, label="MASK"))`, a `TypeError` was raised:
```
TypeError: unsupported format string passed to Literal.__format__
```

## Root Cause
The `LiteralLoadInstruction.__init__` was passing the `Literal` object directly to `LiteralPoolEntry`, which then tried to format it as an integer using `:08X` format specifier. The `Literal` class didn't implement `__format__`, causing the error.

## Solution
Modified `LiteralLoadInstruction.__init__` in `nervapy/arm/literal_pool.py` to:
1. Check if the value is a `Literal` object
2. Extract the numeric value using `value.get_value()`
3. Extract the label using `value.get_label()` if no explicit label is provided
4. Pass the numeric value (not the Literal object) to `LiteralPoolEntry`

## Usage Examples

### 1. Literal with custom label
```python
from nervapy.arm.literal_pool import Literal

LDR(r0, literal=Literal(0x11111111, label="MASK"))
```
Generates:
```assembly
LDR r0, =MASK
...
MASK:
    .word 0x11111111
```

### 2. Literal without label (auto-generated)
```python
LDR(r1, literal=Literal(0x22222222))
```
Generates:
```assembly
LDR r1, =literal_123456789
...
literal_123456789:
    .word 0x22222222
```

### 3. Direct integer (backward compatibility)
```python
LDR(r2, literal=0x33333333)
```
Still works as before.

### 4. ConstantData
```python
magic = ConstantData.uint32(0x44444444, name="MAGIC")
LDR(r3, literal=magic)
```
Works seamlessly - references the .data section label.

## Changes Made

### File: `nervapy/arm/literal_pool.py`

1. **`Literal` class docstring** - Updated with clearer examples
2. **`LiteralLoadInstruction.__init__`** - Added extraction logic for `Literal` objects
3. **Module docstring** - Updated examples to show proper `Literal` usage

### File: `nervapy/arm/generic.py`

1. **`LDR` function docstring** - Added comprehensive documentation for literal parameter usage

## Testing
All existing tests pass. The fix maintains backward compatibility while adding support for the `Literal` wrapper class.
