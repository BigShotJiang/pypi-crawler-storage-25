# C Inline Assembly Generation for NervaPy

## Overview

NervaPy now supports generating inline assembly that can be directly embedded into C functions, avoiding function call overhead. This is particularly useful for performance-critical inner loops where every cycle counts.

## Supported Compilers

- **GCC** (GNU ARM Embedded Toolchain) - Extended inline assembly syntax
- **ARMCC** (ARM Compiler 5/6) - Native inline assembly syntax

## Usage

### Generate Functions

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture

# Define your kernel
with Function("vector_add", (a_arg, b_arg, c_arg, n_arg),
              target=Microarchitecture.CortexM4,
              abi=arm_gnueabihf) as f:
    (a_ptr, b_ptr, c_ptr, n) = LOAD.ARGUMENTS()
    
    with Loop() as loop:
        val_a = GeneralPurposeRegister()
        val_b = GeneralPurposeRegister()
        result = GeneralPurposeRegister()
        
        LDR(val_a, [a_ptr], 4)
        LDR(val_b, [b_ptr], 4)
        ADD(result, val_a, val_b)
        STR(result, [c_ptr], 4)
        SUBS(n, n, 1)
        BNE(loop.begin)
    
    RETURN()
```

### Get Output Formats

```python
# 1. Regular assembly file (for separate compilation)
assembly_code = f.assembly

# 2. Rust global_asm!() macro
rust_code = f.global_asm

# 3. GCC inline assembly (NEW!)
gcc_inline = f.c_inline_asm_gcc

# 4. ARMCC inline assembly (NEW!)
armcc_inline = f.c_inline_asm_armcc
```

### Embed in C Code

#### GCC Example

```c
#include <stdint.h>
#include <stddef.h>

void vector_add_inline(uint32_t *a, uint32_t *b, uint32_t *c, size_t n) {
    /* GCC inline assembly for function: vector_add */
    __asm__ volatile(
        ".Lvector_add_loop_begin:\n\t"
        "LDR r12, [r0], #4\n\t"
        "LDR r4, [r1], #4\n\t"
        "ADD r12, r12, r4\n\t"
        "STR r12, [r2], #4\n\t"
        "SUBS r3, r3, #1\n\t"
        "BNE .Lvector_add_loop_begin\n\t"
        : /* outputs */
        : /* inputs */
        : "memory" /* clobbers - adjust based on registers used */
    );
}
```

#### ARMCC Example

```c
#include <stdint.h>
#include <stddef.h>

void vector_add_inline(uint32_t *a, uint32_t *b, uint32_t *c, size_t n) {
    /* ARMCC inline assembly for function: vector_add */
    __asm {
    vector_add_loop_begin
        LDR r12, [r0], #4
        LDR r4, [r1], #4
        ADD r12, r12, r4
        STR r12, [r2], #4
        SUBS r3, r3, #1
        BNE vector_add_loop_begin
    }
}
```

## Performance Benefits

### Function Call Overhead (Cortex-M)

- BL instruction: 1-3 cycles
- PUSH (save registers): 1 cycle per register
- POP (restore registers): 1 cycle per register
- BX lr (return): 1-3 cycles

**Total**: ~8-12 cycles per call

For a loop that runs 1000 times, that's 8,000-12,000 wasted cycles!

### When to Use Inline Assembly

✅ Inner loops where every cycle counts  
✅ Tight DSP kernels (filters, convolution, etc.)  
✅ Performance-critical signal processing  
✅ When profiling shows function call overhead matters  

### When to Use Regular Assembly Functions

✅ Large, complex functions  
✅ Code reused across multiple C functions  
✅ When debugging is important  
✅ When function call overhead is negligible  

## Example Script

See `examples/c_inline_asm_example.py` for a complete demonstration including:
- Vector addition
- Array summation
- Array scaling
- Complete C code examples
- Performance comparisons

## Run the Example

```bash
# From the NervaPy root directory
PYTHONPATH=. python examples/c_inline_asm_example.py
```

## Notes

- The inline assembly skips function prologue/epilogue (PUSH, POP, BX lr)
- For GCC, you may need to adjust input/output constraints based on your usage
- The generated code assumes parameters are already in the correct registers (r0-r3)
- Test thoroughly and compare with compiler-generated code for your use case

## See Also

- `examples/arm_rust_integration.py` - Rust `global_asm!()` integration
- `examples/arm_cortex_m_example.py` - Regular assembly file generation
