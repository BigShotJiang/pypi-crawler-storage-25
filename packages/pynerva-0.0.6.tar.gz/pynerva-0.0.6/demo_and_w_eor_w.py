#!/usr/bin/env python3
"""
Demonstration of AND.W and EOR.W vs regular AND and EOR

This shows the difference between using the .W suffix (32-bit encoding)
and letting the assembler choose the encoding automatically.
"""

import sys
sys.path.insert(0, '/home/kris/repos/NervaPy')

from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture

print("=" * 70)
print("Comparison: AND vs AND.W, EOR vs EOR.W")
print("=" * 70)
print()

print("Use Case: Loading 0x11111111 with logical operations")
print("-" * 70)
print()

# Example 1: Regular AND/EOR (assembler chooses encoding)
print("1. Regular AND/EOR (assembler chooses encoding):")
f1 = Function("regular_ops", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f1:
    AND(r0, r1, 0xFF)        # Small immediate - will use 16-bit encoding
    EOR(r2, r3, 0x100)       # Might use 16 or 32-bit encoding
    BX(lr)

print(f1.assembly)
print()

# Example 2: Explicit .W suffix (forces 32-bit encoding)
print("2. AND.W/EOR.W (forces 32-bit encoding with modified immediate):")
f2 = Function("wide_ops", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f2:
    AND_W(r0, r1, 0x11111111)  # Repeating byte pattern
    EOR_W(r2, r3, 0x22222222)  # Another repeating pattern
    AND_W(r4, 0xFFFFFFFF)      # All ones pattern
    EOR_W(r5, 0xABABABAB)      # Repeating 0xAB
    BX(lr)

print(f2.assembly)
print()

print("Key Points:")
print("-" * 70)
print("• AND/EOR: Assembler chooses 16-bit or 32-bit encoding")
print("• AND.W/EOR.W: Forces 32-bit encoding with modified immediate")
print("• Modified immediates support special patterns like 0x11111111")
print("• Useful when you need specific encoding (e.g., for timing)")
print()
print("✓ Both forms are valid and work correctly!")
