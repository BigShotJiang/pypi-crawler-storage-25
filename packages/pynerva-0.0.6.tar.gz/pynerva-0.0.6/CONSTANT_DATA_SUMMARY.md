# ConstantData - Summary

## What Is It?

`ConstantData` is a new class that **extends** `Constant` to automatically generate `.data` sections in NervaPy ARM functions.

## Key Feature

When you create a `ConstantData` object inside a Function, the `.data` section is **automatically added** to the generated assembly!

## Quick Example

```python
from nervapy import *
from nervapy.arm import *
from nervapy.constant_data import ConstantData, install_constant_data_support

# Enable support (call once)
install_constant_data_support()

with Function("my_func", ...) as func:
    # Create constant - automatically added to .data!
    magic = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")
    
    # Use value in code
    MOV(r0, magic.data[0])
    RETURN()

# .data section automatically included!
print(func.assembly)
```

**Output:**
```assembly
	.text
.global my_func
my_func:
	MOV r0, #17
	ORR r0, r0, r0, LSL #8
	ORR r0, r0, r0, LSL #16
	BX lr

	.data
	.align 4
	.global MAGIC_NUMBER
MAGIC_NUMBER:
	.word 0x11111111
```

## Usage

1. Import and install:
   ```python
   from nervapy.constant_data import ConstantData, install_constant_data_support
   install_constant_data_support()
   ```

2. Create constants inside Function:
   ```python
   with Function(...) as func:
       const = ConstantData.uint32(111, name="my_const")
   ```

3. Access values:
   ```python
   value = const.data[0]      # Get value
   label = const.get_label()   # Get label name
   ```

4. `.data` section automatically appended to `func.assembly`

## Supported Types

- `ConstantData.uint32(value, name="...")`
- `ConstantData.uint32x4(v1, v2, v3, v4, name="...")`
- `ConstantData.uint64(value, name="...")`
- `ConstantData.float32(value, name="...")`
- `ConstantData.float64(value, name="...")`

## Files

- **Implementation:** `nervapy/constant_data.py`
- **Full Guide:** `CONSTANT_DATA_GUIDE.md`
- **Example:** `examples/constant_data_example.py`
- **Original Manual Method:** `NERVAPY_DATA_SECTION_GUIDE.md`

## Comparison

| Feature | Manual Method | ConstantData |
|---------|---------------|--------------|
| Create .data section | ❌ Manual string concat | ✅ Automatic |
| Define constants | ✅ Plain dict | ✅ Type-safe objects |
| Labels | ❌ Manual | ✅ Automatic |
| Registration | ❌ Manual | ✅ Automatic |
| Access from C | ✅ extern | ✅ extern |

## Benefits

✅ **No manual .data section writing**  
✅ **Type-safe constant definitions**  
✅ **Automatic label generation**  
✅ **Clean, readable code**  
✅ **Compatible with existing Constant API**  
✅ **Non-invasive** - doesn't modify original `Constant` class  

## Example Use Cases

### 1. Configuration Constants

```python
TIMEOUT = ConstantData.uint32(1000, name="TIMEOUT_MS")
BUFFER = ConstantData.uint32(256, name="BUFFER_SIZE")
```

### 2. Lookup Tables

```python
masks = ConstantData.uint32x4(0x0F, 0xF0, 0xFF, 0xFFFF, name="BITMASKS")
```

### 3. Shared with C Code

```python
# ARM assembly
FLAGS = ConstantData.uint32(0xFF, name="STATUS_FLAGS")

# C code
extern uint32_t STATUS_FLAGS;
printf("Flags: 0x%08X\n", STATUS_FLAGS);
```

## Limitations

⚠️ Must call `install_constant_data_support()` first  
⚠️ Constants must be created inside `with Function(...)` block  
⚠️ `LDR =label` pseudo-instruction not directly supported  
⚠️ For loading from .data, access via C extern or post-process assembly  

## Next Steps

- Read full guide: `CONSTANT_DATA_GUIDE.md`
- Try example: `python examples/constant_data_example.py`
- Compare with manual method: `NERVAPY_DATA_SECTION_GUIDE.md`

---

**Status:** ✅ Implemented, tested, documented  
**Date:** 2026-04-06
