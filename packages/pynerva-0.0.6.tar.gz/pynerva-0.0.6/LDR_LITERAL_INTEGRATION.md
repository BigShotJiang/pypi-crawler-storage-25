# LDR Literal Pseudo-Instruction Support

## Overview

The LDR instruction now supports the ARM assembler pseudo-instruction `LDR rd, =value` through the `literal` parameter. This allows loading 32-bit constants that cannot be encoded directly in MOV instructions.

## Usage

### Basic Syntax

```python
# Load a 32-bit literal value
LDR(register, literal=value)
```

### Examples

#### 1. Loading Simple Constants

```python
from nervapy.arm import *

# Load a 32-bit constant that can't be encoded in MOV
LDR(r0, literal=0x11111111)

# Multiple literals
LDR(r1, literal=0x12345678)
LDR(r2, literal=0xDEADBEEF)
```

#### 2. Integration with ConstantData

```python
from nervapy.constant_data import ConstantData, install_constant_data_support

# Enable ConstantData support
install_constant_data_support()

# Create constant in .data section
MAGIC = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")

# Load from .data section
LDR(r0, literal=MAGIC)
```

#### 3. Complete Example

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.constant_data import ConstantData, install_constant_data_support

install_constant_data_support()

result_arg = Argument(ptr(uint32_t), name='result')

with Function("example", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Load literal using LDR with literal parameter
    LDR(r0, literal=0x11111111)
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
```

Output:
```assembly
	.syntax unified
	.arch armv6zk

	.text

.global example
.type example, %function
example:
Lexample.ENTRY:
	MOV r12, r0
	LDR r0, =literal_12345678
	STR r0, [r12]
	BX lr

	.align 4
literal_12345678:
	.word 0x11111111
```

## Features

### Automatic Literal Pool Management

The assembler automatically:
- Creates a literal pool after the function
- Generates PC-relative LDR instructions
- Places literals in the .text section or .rodata

### Deduplication

Identical literal values are automatically deduplicated:

```python
LDR(r0, literal=0x12345678)
LDR(r1, literal=0x12345678)  # Reuses the same pool entry
```

### ConstantData Integration

When using ConstantData objects:
- References the .data section label
- No duplication in literal pool
- Supports global named constants

### Backward Compatibility

Normal LDR memory loads still work as before:

```python
# Memory load (unchanged)
LDR(r0, [r1])
LDR(r0, [r1, 4])
LDR(r0, [r1, r2])

# Literal load (new)
LDR(r0, literal=0x11111111)
```

## Alternative Syntax

For convenience, the original `LDR_LITERAL` function is still available:

```python
from nervapy.arm.literal_pool import LDR_LITERAL, LDRL

# These are equivalent:
LDR(r0, literal=0x11111111)
LDR_LITERAL(r0, 0x11111111)
LDRL(r0, 0x11111111)
```

## Implementation Details

### How It Works

1. When `LDR(register, literal=value)` is called:
   - A `LiteralLoadInstruction` is created
   - The value is added to the function's literal pool
   - Deduplication is performed automatically

2. During assembly generation:
   - The instruction emits: `LDR register, =label`
   - The literal pool is appended after the function
   - Each entry generates the appropriate `.word` directive

### Literal Pool Structure

For GAS format:
```assembly
	.align 4
literal_label:
	.word 0xVALUE
```

For ARMCC format:
```assembly
        ALIGN 4
literal_label    DCD    0xVALUE
```

### ConstantData vs Literal Pool

| Feature | Literal Pool | ConstantData |
|---------|-------------|--------------|
| Section | .text | .data |
| Scope | Function-local | Global |
| Naming | Auto-generated | User-defined |
| When to use | Local constants | Shared constants |

## Advantages Over Manual Constants

### Before (Manual):

```python
# Had to use MOV tricks or manual assembly
MOV(r0, 0x1111)      # Only works for limited values
MOVT(r0, 0x1111)     # Two instructions needed
```

### After (Automatic):

```python
# Single instruction, any 32-bit value
LDR(r0, literal=0x11111111)
```

## Supported Formats

- ✓ GAS (GNU Assembler Syntax)
- ✓ ARMCC (ARM Compiler)

## Limitations

1. The literal pool is placed after the function code
2. PC-relative addressing limits apply (typically ±4KB range)
3. Large functions may need manual pool placement (future enhancement)

## Future Enhancements

Possible improvements:
- Manual literal pool placement with `LTORG` pseudo-instruction
- Optimization to use MOV/MVN when possible
- Support for 64-bit literals (LDRD)
- Cross-reference analysis for optimal placement

## See Also

- `ConstantData` - For .data section constants
- `MOV` / `MOVT` - For immediate values
- ARM Architecture Reference Manual - LDR pseudo-instruction
