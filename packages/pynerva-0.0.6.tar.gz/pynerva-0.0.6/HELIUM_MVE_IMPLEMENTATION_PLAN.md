# Helium (MVE) Implementation Plan for NervaPy

## Overview
This document outlines the implementation plan for adding ARM Helium (M-Profile Vector Extension) support to NervaPy, targeting Cortex-M55 for post-quantum cryptography applications.

## Implementation Status

### ✅ Completed
1. Added ISA extensions: `Extension.V8M`, `Extension.MVE`, `Extension.MVE_FP`
2. Updated extension prerequisites in `isa.py`

### 🔄 In Progress
None

### 📋 TODO

#### Phase 1: Foundation (High Priority)
1. **Add Cortex-M55 Microarchitecture** (`microarchitecture.py`)
   ```python
   CortexM55 = Microarchitecture('Cortex-M55', 
                                 extensions=[V8M, MVE, MVE_FP, DSP, Thumb2])
   ```

2. **Add Q Registers** (`registers.py`)
   - Q0-Q7 (128-bit vector registers)
   - Relationship with D registers (Q = D[n:n+1])
   - Register allocation support

3. **Add Predicate Registers** (`registers.py`)
   - P0-P7 (predicate/mask registers)
   - VPR (Vector Predicate Register)

#### Phase 2: Load/Store Instructions (High Priority for Crypto)
**File**: `nervapy/arm/mve.py` (new file)

```python
# Vector Load/Store
class MVELoadStoreInstruction(Instruction):
    """Base class for MVE load/store operations"""
    pass

# Instructions to implement:
- VLDRB.U8, VLDRB.S8, VLDRB.U16, VLDRB.S16, VLDRB.U32, VLDRB.S32
- VLDRH.U16, VLDRH.S16, VLDRH.U32, VLDRH.S32  
- VLDRW.U32
- VLDRD.U64
- VSTRB.8, VSTRB.16, VSTRB.32
- VSTRH.16, VSTRH.32
- VSTRW.32
- VSTRD.64
```

#### Phase 3: Arithmetic Instructions (Critical for Crypto)
```python
# Basic Arithmetic
- VADD.I8, VADD.I16, VADD.I32
- VSUB.I8, VSUB.I16, VSUB.I32
- VMUL.I8, VMUL.I16, VMUL.I32
- VMLA.I8, VMLA.I16, VMLA.I32  (multiply-accumulate)
- VMLS.I8, VMLS.I16, VMLS.I32  (multiply-subtract)

# Widening Multiply (important for crypto)
- VMULLB.U8, VMULLB.U16, VMULLB.U32  (bottom half)
- VMULLT.U8, VMULLT.U16, VMULLT.U32  (top half)
- VMULLB.S8, VMULLB.S16, VMULLB.S32
- VMULLT.S8, VMULLT.S16, VMULLT.S32

# Long Multiply-Accumulate (for large integer arithmetic)
- VMLAL[B/T].U8/.U16/.U32
- VMLSL[B/T].U8/.U16/.U32

# Saturating Arithmetic
- VQADD.U8/.U16/.U32, VQADD.S8/.S16/.S32
- VQSUB.U8/.U16/.U32, VQSUB.S8/.S16/.S32
- VQDMULH.S8/.S16/.S32  (saturating doubling multiply high)
- VQRDMULH.S8/.S16/.S32 (saturating rounding doubling multiply high)

# Halving Arithmetic
- VHADD.U8/.U16/.U32, VHADD.S8/.S16/.S32
- VHSUB.U8/.U16/.U32, VHSUB.S8/.S16/.S32

# Absolute/Negate
- VABS.S8/.S16/.S32
- VNEG.S8/.S16/.S32
```

#### Phase 4: Logical Operations
```python
- VAND
- VBIC  (bit clear)
- VEOR  (XOR)
- VORR  (OR)
- VORN  (OR NOT)
- VMVN  (NOT)
- VBSL  (bit select - useful for constant-time crypto)
```

#### Phase 5: Shift Operations (Critical for Crypto)
```python
# Logical Shifts
- VSHL.I8/.I16/.I32   (shift left)
- VSHR.U8/.U16/.U32   (logical shift right)
- VSHR.S8/.S16/.S32   (arithmetic shift right)

# Widening Shifts
- VSHLL[B/T].U8/.U16  (shift left long)

# Rounding Shifts
- VRSHL.U8/.U16/.U32, VRSHL.S8/.S16/.S32
- VRSHR.U8/.U16/.U32, VRSHR.S8/.S16/.S32

# Saturating Shifts
- VQSHL.U8/.U16/.U32, VQSHL.S8/.S16/.S32
- VQSHLU.S8/.S16/.S32  (shift left unsigned result)

# Shift and Insert
- VSLI.8/.16/.32  (shift left and insert)
- VSRI.8/.16/.32  (shift right and insert)
```

#### Phase 6: Comparison Operations
```python
# Comparisons (produce predicate masks)
- VCMP.I8/.I16/.I32
- VCMPEQ.I8/.I16/.I32
- VCMPNE.I8/.I16/.I32
- VCMPGT.U8/.U16/.U32, VCMPGT.S8/.S16/.S32
- VCMPGE.U8/.U16/.U32, VCMPGE.S8/.S16/.S32
- VCMPLT.U8/.U16/.U32, VCMPLT.S8/.S16/.S32
- VCMPLE.U8/.U16/.U32, VCMPLE.S8/.S16/.S32

# Predication Setup
- VPST   (vector predicate then)
- VPTE   (vector predicate then-else)
- VPTT   (vector predicate then-then)
```

#### Phase 7: Reduction Operations (Important for Crypto)
```python
# Sum Reductions
- VADDV.U8/.U16/.U32, VADDV.S8/.S16/.S32
- VADDVA.U8/.U16/.U32, VADDVA.S8/.S16/.S32  (accumulating)
- VADDLV.U32, VADDLV.S32  (long)

# Min/Max Reductions
- VMAXV.U8/.U16/.U32, VMAXV.S8/.S16/.S32
- VMINV.U8/.U16/.U32, VMINV.S8/.S16/.S32

# Multiply-Accumulate Reductions (very useful for crypto)
- VMLADAV.U8/.U16/.U32, VMLADAV.S8/.S16/.S32
- VMLSDAV.S8/.S16/.S32
- VMLALDAV.U16/.U32, VMLALDAV.S16/.S32  (long accumulate)
- VMLSLDAV.S16/.S32
```

#### Phase 8: CRC Operations (Crypto-Related)
```python
- VCRC32B.U8  (CRC32 byte)
- VCRC32H.U16 (CRC32 halfword)
- VCRC32W.U32 (CRC32 word)
- VCRC32CB.U8  (CRC32C byte)
- VCRC32CH.U16 (CRC32C halfword)
- VCRC32CW.U32 (CRC32C word)
```

## Register Implementation

### Q Registers (128-bit vectors)
```python
# In registers.py
class QRegister(Register):
    """128-bit vector register for Helium/MVE"""
    def __init__(self, number, name=None):
        if not 0 <= number <= 7:
            raise ValueError(f"Q register number must be 0-7, got {number}")
        super().__init__(name if name else f"q{number}")
        self.number = number
        self.size = 16  # 128 bits = 16 bytes
    
    def get_low_d(self):
        """Get lower 64-bit D register"""
        return DRegister(self.number * 2)
    
    def get_high_d(self):
        """Get upper 64-bit D register"""
        return DRegister(self.number * 2 + 1)

# Create instances
q0 = QRegister(0)
q1 = QRegister(1)
q2 = QRegister(2)
q3 = QRegister(3)
q4 = QRegister(4)
q5 = QRegister(5)
q6 = QRegister(6)
q7 = QRegister(7)
```

### Predicate Registers
```python
class PredicateRegister(Register):
    """Predicate register for MVE predication"""
    def __init__(self, number, name=None):
        if not 0 <= number <= 7:
            raise ValueError(f"P register number must be 0-7, got {number}")
        super().__init__(name if name else f"p{number}")
        self.number = number
        self.size = 2  # 16 bits

# Create instances
p0 = PredicateRegister(0)
p1 = PredicateRegister(1)
p2 = PredicateRegister(2)
p3 = PredicateRegister(3)
p4 = PredicateRegister(4)
p5 = PredicateRegister(5)
p6 = PredicateRegister(6)
p7 = PredicateRegister(7)

# VPR - Vector Predicate Register
vpr = PredicateRegister(15, "VPR")  # Special register
```

## Usage Example (Target)

```python
from nervapy.arm import Function, VLDRW, VSTRW, VADD, VMUL, VMLAL
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.registers import q0, q1, q2, q3, r0, r1

# Post-quantum crypto: polynomial multiplication example
with Function("poly_mul_kyber", (r0, r1), None,
              target=Microarchitecture.CortexM55,
              abi=arm_gnueabi) as func:
    
    # Load 4x 32-bit coefficients into Q registers
    VLDRW(q0, [r0])      # Load from first polynomial
    VLDRW(q1, [r1])      # Load from second polynomial
    
    # Widening multiply (32-bit -> 64-bit)
    VMULLB.U32(q2, q0, q1)  # Bottom half
    VMULLT.U32(q3, q0, q1)  # Top half
    
    # Accumulate results
    VMLAL.U32(q2, q0, q1)
    
    # Store results
    VSTRD(q2, [r0])
```

## Testing Strategy

### Unit Tests
1. **Register Tests** (`tests/arm/test_mve_registers.py`)
   - Q register creation and properties
   - P register creation
   - D/Q register relationships

2. **Instruction Tests** (`tests/arm/test_mve_instructions.py`)
   - Each instruction category
   - Operand validation
   - Encoding verification

3. **Integration Tests** (`tests/arm/test_mve_crypto.py`)
   - Full crypto operations
   - Kyber polynomial ops
   - Dilithium NTT
   - SPHINCS+ hashing

### Performance Tests
- Benchmark vs scalar code
- Verify vector utilization

## Documentation

### Files to Create
1. `HELIUM_MVE_REFERENCE.md` - Complete instruction reference
2. `examples/arm_helium_crypto.py` - Crypto examples
3. Update `ARMV7M_STACK_ALIGNMENT.md` - Note MVE considerations

## Priority Order for Post-Quantum Crypto

### Must Have (Week 1)
1. Q registers (Q0-Q7)
2. VLDRW, VSTRW (load/store)
3. VADD, VSUB, VMUL (basic arithmetic)
4. VMULLB, VMULLT (widening multiply)
5. VMLAL, VMLSL (multiply-accumulate)

### Should Have (Week 2)
1. VQADD, VQSUB (saturating arithmetic)
2. VSHL, VSHR (shifts)
3. VAND, VEOR, VORR (logical)
4. VADDV (reduction)
5. Predicate registers

### Nice to Have (Week 3)
1. All comparison operations
2. CRC32 instructions
3. Advanced reductions
4. Full predication support

## Notes

### ARMv8.1-M Specifics
- Stack still must be 8-byte aligned (existing validation applies)
- MVE has additional lazy stacking for Q registers
- Q registers are callee-saved: Q4-Q7 (via D8-D15)

### Assembly Syntax
```asm
VLDRW.32    q0, [r0]          # Load word
VADD.I32    q2, q0, q1        # Vector add
VMULLB.U32  q3, q0, q1        # Widening multiply bottom
VMLAL.U32   q2, q0, q1        # Multiply-accumulate long
VADDV.U32   r0, q0            # Reduce to scalar
```

## References
1. ARM®v8-M Architecture Reference Manual
2. ARM Cortex-M55 Technical Reference Manual
3. ARM C Language Extensions for MVE
4. Arm Helium Technology M-Profile Vector Extension (MVE)

## Implementation Estimate
- **Phase 1 (Foundation)**: 2-3 days
- **Phase 2-4 (Core Instructions)**: 1 week
- **Phase 5-7 (Advanced)**: 1 week  
- **Phase 8 (CRC)**: 2 days
- **Testing**: 3-4 days
- **Documentation**: 2-3 days

**Total**: 3-4 weeks for complete implementation

## Next Steps
1. Create `nervapy/arm/mve.py` with base classes
2. Add Q and P registers to `registers.py`
3. Add CortexM55 to `microarchitecture.py`
4. Implement Phase 2 (Load/Store) instructions
5. Add tests for each phase
