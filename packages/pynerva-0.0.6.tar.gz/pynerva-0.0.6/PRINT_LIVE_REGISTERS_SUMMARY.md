# print_live_registers() - Summary

## Issue
`print_live_registers()` showed only 2 registers as live when there were actually 10+ registers live at that point in the code.

## Root Cause
The function was performing immediate liveness analysis during code generation, before all instructions were emitted. It couldn't see future uses of registers, so registers appeared dead when they were actually still needed.

## Fix
Changed to a **deferred marker-based approach**:
- During code generation: `print_live_registers(label)` stores a marker
- After all instructions generated: Full liveness analysis runs
- After liveness analysis: Reports live registers at each marked point

## Result
**Before**: Showed 2 registers (incorrect)
```
Live registers After ADD:
  GP (2): gp-vreg<12>, gp-vreg<13>
```

**After**: Shows 13 registers (correct)
```
Live registers After ADD:
  GP (13): lr, gp-vreg<1>, gp-vreg<2>, gp-vreg<3>, gp-vreg<4>, gp-vreg<5>, 
           gp-vreg<8>, gp-vreg<9>, gp-vreg<10>, gp-vreg<12>, gp-vreg<13>, 
           gp-vreg<14>, gp-vreg<15>
```

## Implementation
- Added `_live_register_markers` list to track markers
- Modified `print_live_registers()` to store markers instead of analyzing immediately
- Added `_report_live_registers_at_markers()` to report after liveness analysis
- Integrated into `Function.__exit__()` after `determine_live_registers()`

## Files Changed
- `nervapy/arm/function.py`

## Usage
```python
with Function(...):
    t0 = GeneralPurposeRegister()
    ADD(t0, r0, r1)
    print_live_registers("after ADD")  # Mark for later analysis
    # Results appear after all code is generated
```

See `PRINT_LIVE_REGISTERS_CORRECT_FIX.md` for detailed implementation.
