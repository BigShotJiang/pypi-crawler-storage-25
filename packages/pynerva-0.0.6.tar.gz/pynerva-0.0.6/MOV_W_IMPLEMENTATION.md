# MOV.W Instruction Implementation

## Summary

Added support for the `MOV.W` instruction in NervaPy, which allows loading 32-bit immediate values using ARM's modified immediate encoding.

## Changes Made

### 1. Enhanced Modified Immediate Detection

Updated `is_modified_immediate12()` in `nervapy/arm/instructions.py` to support all ARM modified immediate patterns:

- **Pattern 0b00**: `0x000000XY` - Simple 8-bit value
- **Pattern 0b01**: `0x00XY00XY` - Byte replicated in positions 0 and 2
- **Pattern 0b10**: `0xXY00XY00` - Byte replicated in positions 1 and 3
- **Pattern 0b11**: `0xXYXYXYXY` - Byte replicated in all 4 positions
- **Rotation patterns**: Original rotation-based encoding (for values with high bit set)

### 2. Added MOV.W Instruction Support

- Added `"MOV.W"` to the allowed instructions list in `MovInstruction` class
- Created `MOV_W()` function as a Python wrapper for the instruction
- Exported `MOV_W` from `nervapy.arm` module

## Usage

### Basic MOV with 32-bit Immediates

After the fix, regular `MOV` instruction now accepts more 32-bit immediate values:

```python
from nervapy.arm import *

MOV(r0, 0x11111111)  # Works now - Pattern 0xXYXYXYXY
MOV(r1, 0x00220022)  # Works - Pattern 0x00XY00XY
MOV(r2, 0x33003300)  # Works - Pattern 0xXY00XY00
```

### Explicit Wide Encoding with MOV.W

Use `MOV_W()` to explicitly request the wide (32-bit) instruction encoding:

```python
from nervapy.arm import *

MOV_W(r0, 0x11111111)  # Generates: MOV.W r0, #286331153
MOV_W(r1, 0xFF)        # Generates: MOV.W r1, #255
```

### Example

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf

with Function('test', (), target=Microarchitecture.CortexM4, 
              abi=arm_gnueabihf, report_generation=False) as f:
    # Both of these work:
    MOV(r0, 0x11111111)       # Generates: MOV r0, #286331153
    MOV_W(r1, 0x11111111)     # Generates: MOV.W r1, #286331153
    
    BX(lr)

print(f.assembly)
```

## Valid Modified Immediate Values

Examples of valid 32-bit immediate values for MOV/MOV.W:

- `0x11111111` - Pattern 3: byte 0x11 replicated 4 times
- `0x22222222` - Pattern 3: byte 0x22 replicated 4 times
- `0x00330033` - Pattern 1: byte 0x33 in positions 0 and 2
- `0x44004400` - Pattern 2: byte 0x44 in positions 1 and 3
- `0x000000FF` - Pattern 0: simple 8-bit value
- `0xFF000000` - Rotation pattern: 0xFF rotated left
- `0x80000000` - Rotation pattern: 0x80 rotated left

## Invalid Values

Values that cannot be encoded as modified immediates will still fail:

```python
MOV(r0, 0x12345678)  # ERROR: Not a valid modified immediate pattern
```

For such values, use:
- `MOVW` + `MOVT` for arbitrary 32-bit values
- `LDR` with literal pool: `LDR(r0, literal=Literal(0x12345678))`

## Difference Between MOV, MOV.W, and MOVW

- **MOV**: Standard move, assembler chooses encoding (16-bit or 32-bit)
- **MOV.W**: Forces 32-bit wide encoding, accepts modified immediate or register
- **MOVW**: Loads 16-bit immediate into lower half (bits 0-15) of register

## Technical Details

### Modified Immediate Encoding

ARM Thumb-2 modified immediate constants are encoded as 12 bits (i:imm3:imm8) and expanded to 32 bits based on a pattern:

| Pattern (i:imm3) | Encoding | Example |
|------------------|----------|---------|
| 0b0000 | `0x000000XY` | 0x000000FF |
| 0b0001 | `0x00XY00XY` | 0x00FF00FF |
| 0b0010 | `0xXY00XY00` | 0xFF00FF00 |
| 0b0011 | `0xXYXYXYXY` | 0xFFFFFFFF |
| 0b01nn | ROR #(nn*2) of `0x80...XY` | Various rotations |

### Assembly Output

The generated assembly shows decimal values in comments:

```asm
MOV.W r0, #286331153    @ This is 0x11111111
MOV.W r1, #255          @ This is 0xFF
```

## See Also

- ARM Architecture Reference Manual (ARM ARM) Section A5.3.2
- `MOVW` instruction for 16-bit immediates
- `LDR` with literal pool for arbitrary 32-bit constants
