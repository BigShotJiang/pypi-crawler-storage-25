# print_live_registers() Fix

## Summary
Fixed the `print_live_registers()` function to display live virtual registers at any point during code generation. Previously it always showed "None".

## Problem
The `print_live_registers()` function tried to access the `live_registers` attribute before liveness analysis had run, so it always showed "None" or empty results.

## Solution
Modified `print_live_registers()` to perform its own backward liveness analysis on the current instruction stream, allowing it to work during code generation before the full compilation pipeline runs.

## Usage
```python
from nervapy.arm import *

with Function("my_func", args, ...):
    t0 = GeneralPurposeRegister()
    t1 = GeneralPurposeRegister()
    
    ADD(t0, x, y)
    print_live_registers("After ADD")  # Shows which virtual regs are live
    
    MUL(t1, t0, z)
    print_live_registers("After MUL")
```

## Output Example
```
Live registers After ADD:
  GP (3): gp-vreg<2>, gp-vreg<3>, gp-vreg<4>

Live registers After MUL:
  GP (1): gp-vreg<5>
```

## How It Works
1. Finds the last instruction in the current instruction stream
2. Performs backward liveness analysis from the end to the beginning
3. Captures the live register set after the last instruction
4. Converts register IDs back to Register objects for display
5. Groups and displays by register type (GP, S, D, Q)

## Key Points
- Shows **virtual** registers (e.g., gp-vreg<N>), not physical registers (r0-r12, lr, sp)
- Physical register references (like `tm = lr`) won't appear in the output
- The analysis reflects register liveness at the current point in code generation
- Useful for understanding register pressure and optimizing register usage

## Example Output
See `example_print_live_registers.py` for a complete working example showing how live registers change as instructions are added.

## Changes Made
**File: `nervapy/arm/function.py`**
- `Function.print_live_registers()` method:
  - Added inline backward liveness analysis
  - Fixed register type filtering to use `isinstance()` for GeneralPurposeRegister, SRegister, DRegister, and QRegister
  - Properly handles checkpoint of live registers after the last instruction
