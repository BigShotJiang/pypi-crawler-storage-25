# Print Live Registers with Variable Names

## Feature Summary

The `print_live_registers()` function now displays variable names alongside virtual register IDs, making it easier to debug register allocation and understand which Python variables are live at any point.

## Implementation

### Automatic Name Capture

The register allocation methods (`allocate_general_purpose_register()`, `allocate_q_register()`) now use Python frame inspection to automatically capture variable names when registers are created:

```python
t0 = GeneralPurposeRegister()  # Automatically captures "t0" as the name
q_vec = QRegister()             # Automatically captures "q_vec" as the name
```

### Enhanced Output Format

Before:
```
Live registers After ADD:
  GP (13): lr, gp-vreg<1>, gp-vreg<2>, gp-vreg<3>, gp-vreg<4>, ...
```

After:
```
Live registers After ADD:
  GP (13): lr, gp-vreg<1, ret>, gp-vreg<2, x>, gp-vreg<3, y>, gp-vreg<4, t0>, ...
```

The format is `{type}-vreg<{id}, {name}>` where:
- `type` is the register type (gp, q, s, d)
- `id` is the virtual register number
- `name` is the Python variable name (if captured)

## Example Usage

```python
from nervapy import Argument, uint32_t
from nervapy.arm import *
from nervapy.arm.registers import *

def example():
    with Function(...) as f:
        x = GeneralPurposeRegister()
        y = GeneralPurposeRegister()
        result = GeneralPurposeRegister()
        
        ADD(result, x, y)
        
        print_live_registers("After ADD")
        # Output: GP (3): gp-vreg<1, x>, gp-vreg<2, y>, gp-vreg<3, result>
```

## Benefits

1. **Easier Debugging**: Immediately see which Python variables correspond to which virtual registers
2. **Better Understanding**: Understand register pressure by seeing actual variable names
3. **Faster Development**: Quickly identify which variables are consuming registers at any point

## Implementation Details

### Files Modified
- `nervapy/arm/function.py`:
  - Added `_register_names` dictionary to track register number → variable name mappings
  - Enhanced `allocate_general_purpose_register()` to capture variable names using frame inspection
  - Enhanced `allocate_q_register()` to capture variable names using frame inspection
  - Updated `_report_live_registers_at_markers()` to format register names with variable names

### Technical Approach

The implementation uses Python's `inspect` module to examine the calling frame and extract variable names from the source code line. This is a best-effort approach:
- Works for simple assignments: `var = GeneralPurposeRegister()`
- Gracefully degrades if name capture fails (shows only register ID)
- No performance impact if name capture fails

## Supported Register Types

- ✅ General Purpose Registers (GP)
- ✅ Q Registers (128-bit vector)
- ⚠️ S Registers (can be added if needed)
- ⚠️ D Registers (can be added if needed)
- ⚠️ P Registers (can be added if needed)

## Notes

- Physical registers (like `r0`, `lr`, `q0`) are shown with their standard names
- Only virtual registers show the variable name mapping
- If name capture fails for any reason, the register is shown without a name (e.g., `gp-vreg<5>`)
