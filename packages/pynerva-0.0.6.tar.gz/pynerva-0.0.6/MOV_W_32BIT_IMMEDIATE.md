# MOV.W with 32-bit Modified Immediates

## Overview

In NervaPy, you can now use `MOV` and `MOV_W` instructions to load 32-bit immediate values that fit the Thumb-2 modified immediate encoding scheme.

## Background

Thumb-2's 32-bit `MOV.W` instruction supports "modified immediate" encoding that goes beyond simple 12-bit values. It supports several special patterns, including:

1. **Simple 8-bit values**: `0x000000XY`
2. **Repeated in upper/lower**: `0x00XY00XY`
3. **Repeated in odd bytes**: `0xXY00XY00`
4. **Repeated in all bytes**: `0xXYXYXYXY` ← This is what enables `0x11111111`

The assembler automatically recognizes these patterns. For example, `0x11111111` is encoded as "repeat 0x11 in every byte".

## Usage

### Option 1: Using MOV_W (Explicit)

```python
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture

f = Function("example", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f:
    MOV_W(r0, 0x11111111)  # Explicit 32-bit encoding
    MOV_W(r1, 0x22222222)
    MOV_W(r2, 0xFF00FF00)
    BX(lr)
```

### Option 2: Using MOV (Let Assembler Choose)

```python
f = Function("example", (), abi=arm_gnueabihf, target=Microarchitecture.CortexM4)
with f:
    MOV(r0, 0x11111111)  # Assembler will use appropriate encoding
    MOV(r1, 0x22222222)
    BX(lr)
```

## Generated Assembly

```assembly
MOV.W r0, #286331153    ; 0x11111111
MOV.W r1, #572662306    ; 0x22222222
MOV.W r2, #4278255360   ; 0xFF00FF00
```

## Valid Modified Immediate Patterns

The following 32-bit values can be encoded:
- `0x000000XY` - Any 8-bit value
- `0x00XY00XY` - Same byte in positions 0 and 2
- `0xXY00XY00` - Same byte in positions 1 and 3
- `0xXYXYXYXY` - Same byte repeated 4 times (e.g., `0x11111111`, `0x22222222`)
- Rotated 8-bit values (e.g., `0x000000FF` rotated right by even amounts)

## When to Use MOV_W vs Alternatives

1. **Use MOV/MOV_W**: When the value fits modified immediate encoding (single instruction)
2. **Use MOVW + MOVT**: For any 32-bit value (two instructions, no literal pool)
3. **Use LDR with literal pool**: For any 32-bit value (single instruction, requires literal pool)

Example comparing approaches:

```python
# If value fits modified immediate (e.g., 0x11111111)
MOV_W(r0, 0x11111111)  # ✓ Best - single instruction, no literal pool

# If value doesn't fit (e.g., 0x12345678)
MOVW(r0, 0x5678)
MOVT(r0, 0x1234)       # ✓ Two instructions, no literal pool

# OR
LDR(r0, literal=Literal(0x12345678))  # ✓ Single instruction, uses literal pool
```

## Implementation Details

- NervaPy's `is_modified_immediate12()` function automatically validates the encoding
- Both `MOV` and `MOV.W` instruction names are supported
- The validation happens at instruction creation time
- Invalid values will raise a `ValueError` with a clear error message
