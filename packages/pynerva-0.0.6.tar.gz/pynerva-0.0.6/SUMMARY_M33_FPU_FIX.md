# Summary: Cortex-M33 FPU Directive Fix

## Issue
When generating assembly for Cortex-M33, NervaPy was incorrectly emitting `.fpu neon-vfpv4`. This is wrong because:
- Cortex-M33 does NOT support NEON (NEON is only for Cortex-A application processors)
- Cortex-M33 has an optional FPv5 single-precision floating-point unit
- The correct FPU directive is `.fpu fpv5-sp-d16`

## Root Cause
In `nervapy/arm/function.py`, the `gnu_fpu_spec` property checked for `Extension.VFP4` and immediately returned `.fpu neon-vfpv4` without first checking if the target is an ARMv8-M processor (which doesn't support NEON).

## Fix Applied
Modified `nervapy/arm/function.py` to check for ARMv8-M and ARMv8.1-M architectures BEFORE checking for VFP4:

```python
@property
def gnu_fpu_spec(self):
    from nervapy.arm.isa import Extension

    isa_extensions = self.isa_extensions
    # ARMv8-M (Cortex-M33, M35P, etc.) uses FPv5-SP
    if Extension.V8MMain in isa_extensions or Extension.V8MBase in isa_extensions:
        if Extension.MVE in isa_extensions:
            return ".fpu mve"
        elif Extension.VFP4 in isa_extensions or Extension.VFP3 in isa_extensions:
            # ARMv8-M has FPv5 single-precision FPU
            return ".fpu fpv5-sp-d16"
        else:
            return None
    # ARMv8.1-M (Cortex-M55, etc.) with Helium MVE
    elif Extension.V8_1MMain in isa_extensions:
        if Extension.MVE in isa_extensions:
            return ".fpu mve"
        elif Extension.VFP4 in isa_extensions or Extension.VFP3 in isa_extensions:
            return ".fpu fpv5-sp-d16"
        else:
            return None
    # Rest of the logic for Cortex-A processors with NEON...
```

## Results

### Before Fix ❌
```assembly
.arch armv8-m.main
.fpu neon-vfpv4    # WRONG - M33 doesn't have NEON
```

### After Fix ✅
```assembly
.arch armv8-m.main
.fpu fpv5-sp-d16   # CORRECT - FPv5 single-precision
```

## Testing
- Created new test file: `tests/arm/test_cortex_m33_fpu.py`
- All 49 ARM tests pass
- Verified Cortex-A15 still correctly generates `.fpu neon-vfpv4`
- Verified Cortex-M33 now correctly generates `.fpu fpv5-sp-d16`

## Documentation
- Created `CORTEX_M33_FPU_FIX.md` with detailed explanation
- Includes ARM Cortex-M FPU reference table
- Lists future improvements

## Verification
```bash
pytest tests/arm/ -v
# 49 passed
```

✅ **Fix complete and verified**
