# Live Registers Guide for NervaPy

This guide explains how to inspect and debug live registers in NervaPy.

## What are Live Registers?

A register is "live" at a particular point in code if its value is used later in the program. Live register analysis is crucial for:
- Register allocation optimization
- Understanding register pressure
- Debugging register allocation failures

## How to Check Live Registers

### Method 1: Enable Live Register Tracking (Recommended)

Set `report_live_registers=True` when creating a Function:

```python
from nervapy.arm.function import Function
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

with Function(
    "my_function",
    [],
    target=Microarchitecture.CortexM33,
    abi=arm_gnueabi,
    assembly_format=AssemblyFormat.GAS,
    report_live_registers=True,  # Enable live register tracking
) as f:
    # Your code here
    pass

# After the function context exits, inspect live registers
for i, instr in enumerate(f.instructions):
    from nervapy.arm.instructions import Instruction
    if isinstance(instr, Instruction):
        live_regs = sorted(map(str, list(instr.live_registers)))
        print(f"{i}: {str(instr):40s} Live: {live_regs}")
```

### Method 2: Use dump_intermediate_assembly

Set `dump_intermediate_assembly=True` to automatically write live register information to a file:

```python
with Function(
    "my_function",
    [],
    target=Microarchitecture.CortexM33,
    abi=arm_gnueabi,
    assembly_format=AssemblyFormat.GAS,
    dump_intermediate_assembly=True,  # Dump intermediate assembly with live registers
) as f:
    # Your code here
    pass
```

This creates a file `my_function.intermediate.s` with live register information.

## Helper Functions

### Print Live Registers at Any Point

NervaPy now provides a built-in `print_live_registers()` function:

```python
from nervapy.arm import *

with Function("my_func", args, ...):
    t0 = GeneralPurposeRegister()
    ADD(t0, r0, r1)
    
    # Print live registers at this point
    print_live_registers("after ADD")
    
    MUL(t1, t0, r1)
    print_live_registers("after MUL")
```

**Note:** Live registers are computed AFTER the function context exits, so during code generation this will show "None". To see actual live registers, inspect after generation:

```python
func = Function("my_func", args, ...)
with func:
    # ... your code ...
    pass

# Now inspect
for i, instr in enumerate(func.instructions):
    from nervapy.arm.instructions import Instruction
    if isinstance(instr, Instruction):
        live_regs = sorted(map(str, list(instr.live_registers)))
        print(f"{i}: {str(instr):40s} Live: {live_regs}")
```

### Check if a Specific Register is Live

```python
def is_register_live(register):
    """Check if a register is currently live."""
    if active_function is None:
        return False
    
    if not active_function.instructions:
        return False
    
    last_instruction = active_function.instructions[-1]
    
    if isinstance(last_instruction, Instruction) and hasattr(last_instruction, 'live_registers'):
        for live_reg in last_instruction.live_registers:
            if str(live_reg) == str(register):
                return True
    
    return False
```

## Understanding Live Register Output

When you inspect live registers, you'll see output like:

```
Live registers at each instruction:
============================================================
  1: MOV r12, #42         Live: []
  2: MOV r1, #100         Live: [gp-vreg<0>]
  3: ADD r2, r12, r1      Live: [gp-vreg<0>, gp-vreg<1>]
  4: MOV r0, r2           Live: [gp-vreg<2>]
```

- `gp-vreg<N>` = General-purpose virtual register N (before allocation)
- `r0, r1, ...` = Physical registers (after allocation)
- `[]` = No registers are live at this point

## Complete Example

```python
from nervapy.arm.function import Function
from nervapy.arm.abi import arm_gnueabi
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.registers import GeneralPurposeRegister, r0
from nervapy.arm.generic import MOV, ADD, MUL
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.instructions import Instruction

# Create function with live register tracking enabled
with Function(
    "example",
    [],
    target=Microarchitecture.CortexM33,
    abi=arm_gnueabi,
    assembly_format=AssemblyFormat.GAS,
    report_live_registers=True,
) as f:
    a = GeneralPurposeRegister()
    b = GeneralPurposeRegister()
    c = GeneralPurposeRegister()
    
    MOV(a, 42)
    MOV(b, 100)
    ADD(c, a, b)
    MOV(r0, c)  # Return value

# Inspect live registers
print("\nLive registers at each instruction:")
for i, instr in enumerate(f.instructions):
    if isinstance(instr, Instruction):
        live_regs = sorted(map(str, list(instr.live_registers)))
        print(f"{i:3d}: {str(instr):40s} Live: {live_regs}")
```

## Common Use Cases

### 1. Debugging Register Allocation Errors

If you get an error like "No available physical registers for virtual register #81", use live register tracking to find where register pressure is highest:

```python
with Function(..., report_live_registers=True) as f:
    # Your code
    pass

# Find instruction with most live registers
max_live = 0
max_instr_idx = -1
for i, instr in enumerate(f.instructions):
    if isinstance(instr, Instruction):
        num_live = len(instr.live_registers)
        if num_live > max_live:
            max_live = num_live
            max_instr_idx = i

print(f"Max live registers: {max_live} at instruction {max_instr_idx}")
print(f"Instruction: {f.instructions[max_instr_idx]}")
```

### 2. Checking Register Availability

To see which physical registers are available at each point:

```python
with Function(..., dump_intermediate_assembly=True) as f:
    # Your code
    pass

# Check the .intermediate.s file for "Available registers:" lines
```

### 3. Understanding Register Lifetimes

Trace when a register becomes live and when it dies:

```python
def trace_register_lifetime(function, virtual_reg_name):
    """Trace when a virtual register is live."""
    first_live = -1
    last_live = -1
    
    for i, instr in enumerate(function.instructions):
        if isinstance(instr, Instruction):
            for reg in instr.live_registers:
                if virtual_reg_name in str(reg):
                    if first_live == -1:
                        first_live = i
                    last_live = i
    
    if first_live != -1:
        print(f"Register {virtual_reg_name} is live from instruction {first_live} to {last_live}")
    else:
        print(f"Register {virtual_reg_name} is never live")
```

## Tips

1. **Enable report_live_registers=True** when debugging register allocation issues
2. **Use dump_intermediate_assembly=True** for detailed per-instruction register information
3. **Live registers are computed backward** - from the end of the function to the beginning
4. **Virtual registers** (gp-vreg<N>) are converted to physical registers during allocation
5. **Empty live register set** at an instruction means all previous computations were dead code

## See Also

- `test_live_registers.py` - Example script demonstrating live register inspection
- `REGISTER_ALLOCATION_*.md` - Documentation on register allocation
- `nervapy/arm/function.py` - `determine_live_registers()` implementation
