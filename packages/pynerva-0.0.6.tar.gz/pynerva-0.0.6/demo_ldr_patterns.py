#!/usr/bin/env python3
"""
Demonstration of all LDR usage patterns in NervaPy

This script shows:
1. Normal LDR memory loads (existing functionality)
2. LDR with literal parameter (new functionality)
3. Alternative literal load functions
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.literal_pool import LDR_LITERAL, LDRL

print("=" * 80)
print("LDR Usage Patterns in NervaPy")
print("=" * 80)
print()

result_arg = Argument(ptr(uint32_t), name='result')
data_arg = Argument(ptr(uint32_t), name='data')

# Example 1: Normal LDR (memory loads)
print("1. Normal LDR - Memory Loads")
print("-" * 80)

with Function("normal_ldr", (data_arg, result_arg),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (data_ptr, result_ptr) = LOAD.ARGUMENTS()
    
    # Standard memory load patterns
    LDR(r0, [data_ptr])              # Basic load
    LDR(r1, [data_ptr, 4])           # With immediate offset
    
    ADD(r0, r0, r1)
    STR(r0, [result_ptr])
    RETURN()

print("✓ LDR(rd, [address])")
print("✓ LDR(rd, [address, offset])")
print()

# Example 2: LDR with literal parameter (NEW)
print("2. LDR with Literal Parameter (NEW)")
print("-" * 80)

with Function("ldr_with_literal", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # New literal parameter syntax
    LDR(r0, literal=0x11111111)      # Load constant
    LDR(r1, literal=0x22222222)      # Another constant
    
    ADD(r0, r0, r1)
    STR(r0, [result_ptr])
    RETURN()

print("✓ LDR(rd, literal=value)")
print("  - Clean, intuitive syntax")
print("  - Integrated into main LDR function")
print("  - Automatic literal pool management")
print()

# Example 3: LDR_LITERAL function (alternative)
print("3. LDR_LITERAL Function (Alternative)")
print("-" * 80)

with Function("ldr_literal_func", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Dedicated function syntax
    LDR_LITERAL(r0, 0x11111111)
    LDR_LITERAL(r1, 0x22222222)
    
    ADD(r0, r0, r1)
    STR(r0, [result_ptr])
    RETURN()

print("✓ LDR_LITERAL(rd, value)")
print("  - Dedicated function")
print("  - Explicit about literal loading")
print()

# Example 4: LDRL alias (alternative)
print("4. LDRL Alias (Alternative)")
print("-" * 80)

with Function("ldrl_alias", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Short alias syntax
    LDRL(r0, 0x11111111)
    LDRL(r1, 0x22222222)
    
    ADD(r0, r0, r1)
    STR(r0, [result_ptr])
    RETURN()

print("✓ LDRL(rd, value)")
print("  - Short and concise")
print("  - For quick literal loads")
print()

# Example 5: Mixed usage
print("5. Mixed Usage (All patterns together)")
print("-" * 80)

with Function("mixed_usage", (data_arg, result_arg),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (data_ptr, result_ptr) = LOAD.ARGUMENTS()
    
    # Mix different LDR patterns
    LDR(r0, [data_ptr])              # Memory load
    LDR(r1, literal=0x11111111)      # Literal with parameter
    LDR_LITERAL(r2, 0x22222222)      # Literal with function
    LDRL(r3, 0x33333333)             # Literal with alias
    
    ADD(r0, r0, r1)
    STR(r0, [result_ptr])
    RETURN()

print(func.assembly)
print()

print("=" * 80)
print("Summary of LDR Patterns:")
print()
print("Memory Loads (Existing):")
print("  LDR(rd, [address])")
print("  LDR(rd, [address, offset])")
print()
print("Literal Loads (New/Existing):")
print("  LDR(rd, literal=value)    ← RECOMMENDED (new parameter)")
print("  LDR_LITERAL(rd, value)    ← Alternative (dedicated function)")
print("  LDRL(rd, value)           ← Alternative (short alias)")
print()
print("All methods generate: LDR rd, =label")
print("All methods use the same literal pool infrastructure")
print("=" * 80)
