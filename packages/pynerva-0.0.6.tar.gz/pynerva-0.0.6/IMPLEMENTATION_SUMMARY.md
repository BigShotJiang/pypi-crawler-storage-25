# Implementation Summary: ARMv7-M Stack Alignment Validation

## Overview

This implementation adds automatic validation of 8-byte stack alignment before `BL` (Branch with Link) and `BLX` (Branch with Link and Exchange) instructions for ARMv7-M architecture, as required by the ARM Architecture Reference Manual and AAPCS (ARM Architecture Procedure Call Standard).

## Verification

**✓ The requirement is CORRECT**: ARMv7-M does require 8-byte stack alignment before function calls (BL/BLX instructions).

### References:
- ARM Architecture Reference Manual ARMv7-M, Section B1.5.7
- ARM Cortex-M Programming Guide, Section 3.1.2  
- AAPCS (IHI0042F), Section 5.2.1.2 "Stack constraints at a public interface"

## Changes Made

### 1. Core Implementation (`nervapy/arm/function.py`)

Added `validate_stack_alignment()` method to the `Function` class:

- **Location**: Line 1041-1120 in `nervapy/arm/function.py`
- **Called**: During code generation, after prologue generation (line 177)
- **Functionality**:
  - Tracks stack pointer offset throughout function
  - Validates 8-byte alignment before each BL/BLX instruction
  - Only enforces for ARMv7-M architecture (Cortex-M3, M4, M7)
  - Raises `ValueError` with clear error message when misalignment detected

#### Stack Tracking Logic:
```python
# Tracks these stack-modifying instructions:
PUSH/PUSH.W:     stack_offset += num_registers * 4
POP/POP.W:       stack_offset -= num_registers * 4  
STMDB sp!, {...}: stack_offset += num_registers * 4
LDMIA sp!, {...}: stack_offset -= num_registers * 4
SUB sp, sp, #N:  stack_offset += N
ADD sp, sp, #N:  stack_offset -= N

# Validates before:
BL/BLX:          if stack_offset % 8 != 0: raise ValueError
```

### 2. Test Suite (`tests/arm/test_stack_alignment.py`)

Comprehensive test coverage with 9 test cases:

1. **test_misaligned_bl_detected** - Verifies BL misalignment is caught
2. **test_aligned_bl_accepted** - Verifies aligned BL is accepted
3. **test_misaligned_blx_detected** - Verifies BLX misalignment is caught
4. **test_aligned_blx_accepted** - Verifies aligned BLX is accepted
5. **test_multiple_pushes_tracked** - Tests complex PUSH/POP sequences
6. **test_push_pop_balance** - Tests PUSH/POP balance tracking
7. **test_cortex_m3_alignment** - Validates for Cortex-M3
8. **test_cortex_m7_alignment** - Validates for Cortex-M7
9. **test_non_armv7m_skipped** - Validates non-ARMv7M skips check

**Test Results**: All 9 tests pass ✓

### 3. Documentation

Created comprehensive documentation:

- **`ARMV7M_STACK_ALIGNMENT.md`**: Full technical documentation
  - Architecture requirement explanation
  - Why it matters (correctness, performance, interoperability)
  - Implementation details
  - How to fix alignment issues
  - Code examples

- **`examples/arm_stack_alignment_example.py`**: Interactive examples
  - 5 different scenarios demonstrated
  - Shows both passing and failing cases
  - Clear output explaining what's happening

### 4. Error Messages

Clear, actionable error messages guide users to fix issues:

```
ValueError: Stack is not 8-byte aligned before BL instruction.
Current stack offset: 20 bytes (misaligned by 4 bytes).
ARMv7-M requires 8-byte stack alignment at function calls (AAPCS requirement).
Add a dummy register to PUSH instructions or adjust stack manually to maintain alignment.
```

## Testing Results

### Existing Tests
All existing ARM tests continue to pass:
```bash
$ python3 -m pytest tests/arm/ -v
================================================
17 passed in 0.19s
================================================
```

### New Tests
All new stack alignment tests pass:
```bash
$ python3 -m pytest tests/arm/test_stack_alignment.py -v
================================================
9 passed in 0.12s
================================================
```

## Usage Examples

### Misaligned Stack (ERROR)
```python
from nervapy.arm import Function, BL, PUSH, POP
from nervapy.arm.microarchitecture import Microarchitecture

with Function("example", (), None, target=Microarchitecture.CortexM4) as func:
    PUSH((r4, r5))  # +8 bytes (aligned)
    PUSH((r0,))     # +4 bytes (MISALIGNED!)
    BL(external_func)  # ValueError raised here
```

### Aligned Stack (CORRECT)
```python
with Function("example", (), None, target=Microarchitecture.CortexM4) as func:
    PUSH((r4, r5))     # +8 bytes (aligned)
    PUSH((r0, r1))     # +8 bytes (still aligned)
    BL(external_func)  # OK
```

## Architecture Scope

### Applies To:
- ARMv7-M (Cortex-M3, Cortex-M4, Cortex-M7)

### Does NOT Apply To:
- ARMv7-A (Cortex-A8, Cortex-A9, etc.)
- Other ARM architectures

This is checked via: `Extension.V7M in self.target.extensions`

## Impact Assessment

### Benefits:
1. **Prevents Runtime Errors**: Catches misalignment at code generation time
2. **AAPCS Compliance**: Ensures generated code follows ARM standards
3. **Clear Guidance**: Error messages explain how to fix issues
4. **Zero Performance Cost**: Validation only at generation time
5. **Backward Compatible**: Only enforces for ARMv7-M targets

### Risk:
- **Low**: Validation is conservative and well-tested
- **None for existing code**: Non-ARMv7M targets unaffected
- **Positive for new code**: Catches bugs early

## Files Modified

1. `nervapy/arm/function.py` - Added validation method and call
2. `tests/arm/test_stack_alignment.py` - New test file (9 tests)
3. `ARMV7M_STACK_ALIGNMENT.md` - New documentation
4. `examples/arm_stack_alignment_example.py` - New example script

## Summary

✓ **Requirement Verified**: ARMv7-M does require 8-byte stack alignment before BL/BLX  
✓ **Implementation Complete**: Validation working and tested  
✓ **All Tests Pass**: 17/17 ARM tests pass (9 new + 8 existing)  
✓ **Documentation**: Comprehensive docs and examples provided  
✓ **Error Messages**: Clear, actionable guidance for users  
✓ **Scope**: Only applies to ARMv7-M architecture  
✓ **Backward Compatible**: No impact on existing code for other architectures
