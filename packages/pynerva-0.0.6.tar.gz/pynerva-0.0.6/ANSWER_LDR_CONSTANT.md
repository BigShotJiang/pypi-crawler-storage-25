# Answer: Can I use LDR with 0x11111111?

**Question:** Can I now use LDR with 0x11111111?

**Answer:** ❌ **No, not directly** - but here are 3 solutions:

## Why Not?

1. **NervaPy doesn't support `LDR =label` pseudo-instruction**
   - The assembler syntax `LDR r0, =MAGIC_NUMBER` is not implemented
   - This is a limitation of NervaPy's ARM instruction set

2. **ConstantData creates .data section but can't load from it**
   - `ConstantData` puts values in `.data`
   - But NervaPy has no way to generate `LDR` from that label

## Solution 1: Build the Value with Instructions ✅ RECOMMENDED

**Best for most cases** - No memory access, just 3 fast instructions:

```python
from nervapy import *
from nervapy.arm import *

with Function(...) as func:
    # Build 0x11111111 in register
    MOV(r0, 0x11)              # r0 = 0x00000011
    ORR(r0, r0, r0.LSL(8))     # r0 = 0x00001111
    ORR(r0, r0, r0.LSL(16))    # r0 = 0x11111111
    
    # Use r0 with 0x11111111
```

**Generated Assembly:**
```assembly
MOV r0, #17
ORR r0, r0, r0, LSL #8
ORR r0, r0, r0, LSL #16
```

**Pros:**
- ✅ 3 instructions, no memory access
- ✅ Works in NervaPy
- ✅ Fast execution
- ✅ No .data section needed

**Cons:**
- ⚠️ Takes 3 instructions vs 1 LDR

---

## Solution 2: Use ConstantData + Access from C ✅ GOOD

**Best when interfacing with C code** - Share constant between ARM and C:

### Python (NervaPy):
```python
from nervapy.constant_data import ConstantData, install_constant_data_support

install_constant_data_support()

with Function("my_func", ...) as func:
    # Create in .data - accessible from C
    MAGIC = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")
    
    # In ARM code, build the value
    MOV(r0, 0x11)
    ORR(r0, r0, r0.LSL(8))
    ORR(r0, r0, r0.LSL(16))
    RETURN()
```

### C Code:
```c
// Access the constant from C
extern uint32_t MAGIC_NUMBER;

void test() {
    printf("Magic: 0x%08X\n", MAGIC_NUMBER);  // Uses LDR in C!
}
```

**Pros:**
- ✅ Constant accessible from both ARM and C
- ✅ Single source of truth
- ✅ Good for configuration values

**Cons:**
- ⚠️ Still can't use LDR in NervaPy code
- ⚠️ Constant sits in .data but unused by ARM

---

## Solution 3: Post-Process Assembly (Manual) ⚠️ ADVANCED

**Best for special cases** - Manually add LDR after generation:

```python
from nervapy.constant_data import ConstantData, install_constant_data_support

install_constant_data_support()

with Function("my_func", ...) as func:
    MAGIC = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")
    
    # Placeholder - we'll replace this
    MOV(r0, 0)  # Marker instruction
    RETURN()

# Get assembly
asm = func.assembly

# Manually replace MOV with LDR pseudo-instruction
# WARNING: Fragile! Breaks if code changes!
asm = asm.replace(
    "MOV r0, #0",
    "LDR r0, =MAGIC_NUMBER  @ Load from .data"
)

# Save modified assembly
with open("output.s", "w") as f:
    f.write(asm)
```

**Generated Assembly:**
```assembly
.text
my_func:
LDR r0, =MAGIC_NUMBER  @ Load from .data
BX lr

.data
MAGIC_NUMBER:
.word 0x11111111
```

**Pros:**
- ✅ Uses actual `LDR =label`
- ✅ Single instruction to load value
- ✅ Value in .data section

**Cons:**
- ❌ Manual string manipulation
- ❌ Fragile - breaks if code changes
- ❌ Not type-safe
- ❌ Requires careful markers

---

## Comparison

| Method | Instructions | Memory | NervaPy Native | Complexity |
|--------|--------------|--------|----------------|------------|
| **Build with MOV/ORR** | 3 | None | ✅ Yes | ⭐ Simple |
| **ConstantData + C** | 3 in ARM | .data | ✅ Yes | ⭐⭐ Medium |
| **Post-process** | 1 | .data | ❌ No | ⭐⭐⭐ Hard |

---

## Recommended Approach

### For Pure ARM Code:
Use **Solution 1** (MOV/ORR):
```python
MOV(r0, 0x11)
ORR(r0, r0, r0.LSL(8))
ORR(r0, r0, r0.LSL(16))
```

### For ARM + C Mixed:
Use **Solution 2** (ConstantData + C extern):
```python
# ARM
MAGIC = ConstantData.uint32(0x11111111, name="MAGIC_NUMBER")

# C
extern uint32_t MAGIC_NUMBER;
```

### For Special Cases:
Use **Solution 3** (Post-process) only if:
- You need a single LDR instruction
- Performance is critical
- You're willing to maintain fragile code

---

## Complete Working Example

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

result_arg = Argument(ptr(uint32_t), name='result')

with Function("load_magic", (result_arg,),
             target=Microarchitecture.ARM11,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS,
             report_generation=False) as func:
    
    (result_ptr,) = LOAD.ARGUMENTS()
    
    # Build 0x11111111 (RECOMMENDED)
    MOV(r0, 0x11)              # r0 = 0x00000011
    ORR(r0, r0, r0.LSL(8))     # r0 = 0x00001111  
    ORR(r0, r0, r0.LSL(16))    # r0 = 0x11111111
    
    # Store result
    STR(r0, [result_ptr])
    RETURN()

# Save
with open("load_magic.s", "w") as f:
    f.write(func.assembly)

print("✓ Generated load_magic.s")
```

---

## Why This Limitation Exists

NervaPy is a **code generation library**, not a full assembler:
- It generates assembly instructions
- It doesn't implement assembler pseudo-instructions like `LDR =label`
- `LDR =label` requires the assembler to:
  1. Create a literal pool
  2. Calculate PC-relative offsets
  3. Insert the literal value
  
This is beyond NervaPy's scope.

---

## Summary

**Q:** Can I use LDR with 0x11111111?

**A:** Not directly in NervaPy. Use one of:

1. **MOV/ORR** (3 instructions) ← **RECOMMENDED**
2. **ConstantData + access from C** ← Good for mixed code
3. **Post-process assembly** ← Advanced/fragile

For 0x11111111 specifically:
```python
MOV(r0, 0x11)
ORR(r0, r0, r0.LSL(8))
ORR(r0, r0, r0.LSL(16))
```

This is the **best solution** - fast, native, and reliable.

---

**Files:**
- This answer: `ANSWER_LDR_CONSTANT.md`
- ConstantData guide: `CONSTANT_DATA_GUIDE.md`
- Manual .data guide: `NERVAPY_DATA_SECTION_GUIDE.md`
