# How to Check Live Registers in NervaPy - Quick Reference

## Quick Answer

To check which registers are live at any point:

1. **Set `report_live_registers=True` when creating the Function**, OR
2. **After the function context exits, inspect `instruction.live_registers`**, OR
3. **Use the `print_live_registers()` helper function**

## Example 1: Automatic Reporting

```python
from nervapy.arm.function import Function
from nervapy.arm.instructions import Instruction

with Function(..., report_live_registers=True) as f:
    # Your code here
    pass

# Print live registers at each instruction
for i, instr in enumerate(f.instructions):
    if isinstance(instr, Instruction):
        live_regs = sorted(map(str, list(instr.live_registers)))
        print(f"{i}: {instr} -> Live: {live_regs}")
```

## Example 2: Using print_live_registers() Helper

```python
from nervapy.arm import *

with Function(...):
    t0 = GeneralPurposeRegister()
    ADD(t0, r0, r1)
    
    # This will print live registers (note: computed after generation)
    print_live_registers("after ADD")
```

**Note:** Live register info is computed AFTER `__exit__`, so `print_live_registers()` during generation shows limited info. Use post-generation inspection for accurate results.

## Alternative: Use Intermediate Assembly Dump

```python
with Function(..., dump_intermediate_assembly=True) as f:
    # Your code here
    pass

# Check the generated .intermediate.s file
# It contains:
# - Live registers for each instruction
# - Available registers
# - Consumed/produced registers
```

## Check if a Register is Live (After function generation)

```python
def is_register_live(function, instruction_index, register_name):
    """Check if a register is live at a specific instruction."""
    instr = function.instructions[instruction_index]
    if isinstance(instr, Instruction):
        for reg in instr.live_registers:
            if register_name in str(reg):
                return True
    return False
```

## Find Maximum Register Pressure

```python
with Function(..., report_live_registers=True) as f:
    # Your code
    pass

# Find where you have the most live registers
max_pressure = 0
max_instr = None
for instr in f.instructions:
    if isinstance(instr, Instruction):
        if len(instr.live_registers) > max_pressure:
            max_pressure = len(instr.live_registers)
            max_instr = instr

print(f"Max pressure: {max_pressure} registers at {max_instr}")
```

## Important Notes

- **Live registers are only computed AFTER** the function context exits (when `__exit__` is called)
- Live registers represent **virtual registers** before allocation, **physical registers** after
- An empty live register set `[]` means all previous values are dead (not used later)
- Live register analysis runs backward from function exit to entry

## Files

- `LIVE_REGISTERS_GUIDE.md` - Comprehensive guide
- `test_live_registers.py` - Working example
- `nervapy/arm/function.py` - Implementation (see `determine_live_registers()`)
