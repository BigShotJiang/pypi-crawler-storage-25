# MOV.W Feature - Documentation Index

## Quick Start

**Question**: How to do `MOV.W lr, 0x11111111` in NervaPy?

**Answer**: 
```python
MOV_W(lr, 0x11111111)  # ✓ Works!
```

## Documentation Files

### 1. Quick Reference
- **QUICKREF_MOV_W.md** - Quick reference card (start here)
- **ANSWER_MOV_W_0x11111111.md** - Direct answer to the question

### 2. Complete Documentation  
- **MOV_W_COMPLETE_SUMMARY.md** - Complete summary (recommended)
- **MOV_W_32BIT_IMMEDIATE.md** - Full user documentation
- **MOV_W_32BIT_SUPPORT.md** - Implementation details
- **SUMMARY_MOV_W_FEATURE.md** - Feature summary

### 3. Code Examples
- **test_mov_w_32bit.py** - Executable test and demonstration script

## Key Points

✓ `MOV.W #0x11111111` is **valid** in Thumb-2  
✓ Works because of byte repetition pattern encoding  
✓ Generates single instruction with no literal pool  
✓ Also works: 0x22222222, 0xFF00FF00, 0x000000AB  
✗ Doesn't work for arbitrary values like 0x12345678  

## Implementation

**File Modified**: `nervapy/arm/generic.py`  
**Function Added**: `MOV_W(destination, source)`  
**Lines Changed**: 11 lines added  

## Usage Examples

```python
from nervapy.arm import *

# Explicit .W suffix
MOV_W(lr, 0x11111111)

# Let assembler choose
MOV(lr, 0x11111111)

# Both generate: MOV.W lr, #286331153
```

## Testing

```bash
python3 test_mov_w_32bit.py
```

Expected output: All tests pass ✓

## See Also

- Existing features: MOVW, MOVT, LDR with literals
- Related: Modified immediate encoding in ARM ARM A5.3.2
