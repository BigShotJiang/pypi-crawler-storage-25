# Helium MVE - Quick Reference

## Q Registers (✅ Available)

### Import
```python
from nervapy.arm.registers import q0, q1, q2, q3, q4, q5, q6, q7
```

### Properties
- **Size**: 128 bits (16 bytes)
- **Count**: 8 registers (Q0-Q7)
- **Type**: Vector registers for Helium MVE

### Register Layout
```
Q0-Q3: Caller-saved (volatile)
Q4-Q7: Callee-saved (must preserve)

Q0 = D0:D1  (d0 = lower 64, d1 = upper 64)
Q1 = D2:D3
Q2 = D4:D5
Q3 = D6:D7
Q4 = D8:D9
Q5 = D10:D11
Q6 = D12:D13
Q7 = D14:D15
```

### Element Interpretation
Each Q register can hold:
- 16 × 8-bit integers (bytes)
- 8 × 16-bit integers (halfwords)
- 4 × 32-bit integers (words)
- 2 × 64-bit integers (doublewords)

## Cortex-M55 Target

```python
from nervapy.arm.microarchitecture import Microarchitecture

# Use Cortex-M55 for Helium MVE support
target = Microarchitecture.CortexM55
# Includes: ARMv8-M, MVE, MVE_FP, DSP, Thumb-2
```

## Example Usage (Pseudo-code)

```python
# Future MVE instructions will look like:

from nervapy.arm.mve import VLDRW, VSTRW, VADD, VMUL  # Coming soon
from nervapy.arm.registers import q0, q1, q2, r0, r1

# Vector load from memory
VLDRW.U32(q0, [r0])       # Load 4x 32-bit values into q0

# Vector arithmetic  
VADD.I32(q2, q0, q1)      # q2 = q0 + q1 (4x parallel adds)
VMUL.I32(q2, q0, q1)      # q2 = q0 * q1 (4x parallel muls)

# Vector store to memory
VSTRW.U32(q2, [r0])       # Store 4x 32-bit values from q2
```

## Status Dashboard

| Component | Status | Notes |
|-----------|--------|-------|
| Q0-Q7 registers | ✅ DONE | Ready to use |
| P0-P7 predicates | ⏳ TODO | For masking |
| VPR register | ⏳ TODO | Vector predicate |
| Load/Store (VLDR/VSTR) | ⏳ TODO | Phase 2 |
| Arithmetic (VADD/VMUL) | ⏳ TODO | Phase 3 |
| Logical (VAND/VEOR) | ⏳ TODO | Phase 4 |
| Shifts (VSHL/VSHR) | ⏳ TODO | Phase 5 |
| Reductions (VADDV) | ⏳ TODO | Phase 7 |

## Testing

```bash
# Verify Q registers work
python test_mve_qregs.py

# See example usage
python examples/helium_q_registers.py
```

## Use Cases

### Post-Quantum Cryptography
- **Kyber**: Polynomial arithmetic with VMUL/VMLAL
- **Dilithium**: NTT operations with vector arithmetic
- **SPHINCS+**: Hash operations with vector processing

### Performance Benefits
- 4x speedup for 32-bit operations
- 8x speedup for 16-bit operations
- 16x speedup for 8-bit operations
- Compared to scalar ARM code

## Next Phase

**To add MVE instructions:**

1. Create `nervapy/arm/mve.py`
2. Implement instruction encodings
3. Add instruction classes (VLDRW, VADD, etc.)
4. Write tests
5. Add examples

## Resources

- `HELIUM_MVE_Q_REGISTERS.md` - Detailed Q register reference
- `HELIUM_MVE_STATUS.md` - Implementation status
- `HELIUM_MVE_IMPLEMENTATION_PLAN.md` - Full plan
- `nervapy/arm/registers.py` - Source code

---

**Quick Start**: Q registers are ready! Import and use q0-q7. MVE instructions coming soon.
