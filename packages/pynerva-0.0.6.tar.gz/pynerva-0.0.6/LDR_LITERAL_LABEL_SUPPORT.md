# LDR Literal Label Support

## Overview

NervaPy now supports custom labels for literal pool entries when using the `LDR` pseudo-instruction with the `literal` parameter.

## Usage

### LDR with Custom Label

You can now specify a custom label for literal values:

```python
from nervapy.arm import *

# LDR with literal and custom label
LDR(r0, literal=0x11111111, label="my_magic_number")

# LDR with literal but no label (auto-generated)
LDR(r1, literal=0x22222222)
```

### LDR_LITERAL Function

The `LDR_LITERAL` function also supports custom labels:

```python
from nervapy.arm import *

# LDR_LITERAL with custom label
LDR_LITERAL(r2, 0x33333333, label="another_constant")

# LDR_LITERAL without label (auto-generated)
LDR_LITERAL(r3, 0x44444444)
```

## Generated Assembly

The above code generates:

```assembly
LDR r0, =my_magic_number
LDR r1, =literal_130513757329440
LDR r2, =another_constant
LDR r3, =literal_130513762475696
BX lr

.align 4
my_magic_number:
    .word 0x11111111
literal_130513757329440:
    .word 0x22222222
another_constant:
    .word 0x33333333
literal_130513762475696:
    .word 0x44444444
```

## Benefits

- **Readable Assembly**: Custom labels make the generated assembly much more readable
- **Debugging**: Named literals are easier to identify when debugging
- **Documentation**: Meaningful names serve as inline documentation
- **Backwards Compatible**: Existing code without labels continues to work with auto-generated names

## API Reference

### LDR Function

```python
LDR(register, address=None, increment=None, literal=None, label=None)
```

**Parameters:**
- `register`: Destination register
- `address`: Memory address (for normal LDR)
- `increment`: Address increment/offset
- `literal`: Literal value to load (activates pseudo-instruction mode)
- `label`: Optional custom label name for the literal (only used with `literal`)

### LDR_LITERAL Function

```python
LDR_LITERAL(register, value, label=None)
```

**Parameters:**
- `register`: Destination register
- `value`: Literal value to load (int, float, or ConstantData)
- `label`: Optional custom label name for the literal

## Implementation Details

- Custom labels are stored in `LiteralPoolEntry` objects
- Auto-generated labels use the format `literal_{id(entry)}`
- Labels for `ConstantData` objects are managed by the `ConstantData` class itself
- Deduplication still works for literals without custom labels
- Custom labels prevent deduplication to ensure each named literal is preserved

## Example

```python
from nervapy import *
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.formats import AssemblyFormat
from nervapy.arm.microarchitecture import Microarchitecture

with Function("example", tuple(),
             target=Microarchitecture.CortexA9,
             abi=arm_gnueabihf,
             assembly_format=AssemblyFormat.GAS):
    
    # Load magic numbers with meaningful labels
    LDR(r0, literal=0x11111111, label="MAGIC_PATTERN")
    LDR(r1, literal=0xDEADBEEF, label="DEBUG_MARKER")
    LDR(r2, literal=0x12345678, label="VERSION_ID")
    
    BX(lr)
    
print(function.assembly)
```
