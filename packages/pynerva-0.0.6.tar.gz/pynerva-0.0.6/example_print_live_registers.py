#!/usr/bin/env python
"""
Example demonstrating print_live_registers() functionality.

This shows how to use print_live_registers() to inspect which virtual
registers are live at any point during code generation.
"""

from nervapy import Argument, ptr, uint32_t
from nervapy.arm import *
from nervapy.arm.abi import arm_gnueabihf
from nervapy.arm.microarchitecture import Microarchitecture
from nervapy.arm.registers import *
from nervapy.arm.formats import AssemblyFormat

def example_live_registers():
    """Example showing live register tracking"""
    
    x_arg = Argument(uint32_t)
    y_arg = Argument(uint32_t)
    z_arg = Argument(uint32_t)

    f = Function("example", (x_arg, y_arg, z_arg),
                target=Microarchitecture.CortexM33,
                abi=arm_gnueabihf)
    f.assembly_format = AssemblyFormat.GAS
    f.is_thumb = True

    with f:
        x = GeneralPurposeRegister()
        y = GeneralPurposeRegister()
        z = GeneralPurposeRegister()
        
        t0 = GeneralPurposeRegister()
        t1 = GeneralPurposeRegister()
        t2 = GeneralPurposeRegister()
        
        LOAD.ARGUMENT(x, x_arg)
        LOAD.ARGUMENT(y, y_arg)
        LOAD.ARGUMENT(z, z_arg)
        
        # All three inputs are still live
        print_live_registers("After loading arguments")
        
        # Compute t0 = x + y
        ADD(t0, x, y)
        # x and y have been consumed, but z and t0 are live
        print_live_registers("After first ADD")
        
        # Compute t1 = t0 + z  
        ADD(t1, t0, z)
        # t0 and z have been consumed, but t1 is live
        print_live_registers("After second ADD")
        
        # Compute t2 = t1 * 2
        LSL(t2, t1, 1)
        # t1 has been consumed, t2 is live
        print_live_registers("After LSL")
        
        # Return t2
        MOV(r0, t2)
        
        RETURN()

    print("\n=== Generated Assembly ===")
    print(f.assembly)
    
    return f.assembly

if __name__ == "__main__":
    print("=" * 60)
    print("Example: Tracking Live Registers During Code Generation")
    print("=" * 60)
    print()
    example_live_registers()
