def main():
    print("Hello from nervapy!")


if __name__ == "__main__":
    main()
