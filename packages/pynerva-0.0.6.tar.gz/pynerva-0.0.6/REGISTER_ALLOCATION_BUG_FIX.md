# Register Allocation Bug Fix

## Problem

When virtual registers were used as outputs of instructions but never read afterwards (dead code), they weren't tracked for register allocation, causing a `RuntimeError`:

```
RuntimeError: Internal error: Virtual register #X used in instruction 
but was not tracked for allocation. This may indicate a bug in register tracking.
```

## Root Cause

The liveness analysis algorithm in `determine_live_registers()` only tracks registers that are "live" - meaning they are written and later read. It uses backward dataflow analysis:

1. Starts from function exit points
2. Walks backwards through instructions
3. Marks registers as live when they are read (inputs)
4. Removes registers from live set when they are written (outputs)

However, registers that are written but never read (dead outputs) are never added to the `live_registers` set.

The `determine_register_relations()` function only processed registers from `instruction.live_registers`, so dead output registers were never added to `allocation_options`. When `allocate_registers()` tried to allocate them, they were missing from the tracking system.

## Solution

Modified `determine_register_relations()` in `/nervapy/arm/function.py` (around line 896) to also track output registers that may not be in `live_registers`:

```python
# Track all virtual registers used in the instruction (both live and outputs)
virtual_live_registers = [
    register
    for register in instruction.live_registers
    if register.is_virtual
]
# Also include output registers that may not be in live_registers
# (e.g., dead code outputs that are written but never read)
for output_reg in instruction.get_output_registers_list():
    if output_reg.is_virtual and output_reg not in virtual_live_registers:
        virtual_live_registers.append(output_reg)
```

## Improved Error Message

Also improved the error message in `allocate_registers()` to show ALL untracked registers at once and provide clearer guidance:

```python
if untracked_registers:
    raise RuntimeError(
        f"Internal error: Virtual registers {sorted(untracked_registers)} used in instructions "
        f"but were not tracked for allocation. This indicates a bug where registers were created "
        f"after liveness analysis or were not properly added to live_registers."
    )
```

## Test Case

The bug was triggered by simple code like:

```python
with Function('test', (source_arg,), abi=arm_gnueabihf) as f:
    src = LOAD.ARGUMENTS()[0]
    r = GeneralPurposeRegister()
    LDR(r, [src])  # r is written but never used - dead output
    RETURN()
```

This now works correctly, with `r` being properly allocated even though it's dead code.
