# print_live_registers() Correct Fix - Accurate Live Register Reporting

## Problem
`print_live_registers()` was showing incorrect results (only 2 registers instead of 10+) because it was performing backward liveness analysis from the current instruction point during code generation, without knowing about future uses of registers.

## Root Cause
When `print_live_registers("After ADD")` is called:
1. It tries to analyze liveness immediately
2. Only instructions generated **so far** are in the instruction stream
3. Future instructions that will **use** those registers haven't been added yet
4. Result: registers appear dead when they're actually still needed

Example:
```python
ADD(t0, r0, r1)
print_live_registers("after ADD")  # t0 looks dead here
# ... 50 more instructions not yet generated ...
MUL(t1, t0, r2)  # t0 is used here, but print_live_registers didn't know
```

## Solution
Changed to a **deferred analysis** approach:

1. **During code generation**: `print_live_registers(label)` stores a reference to the current instruction object
2. **After all instructions generated**: Perform full liveness analysis on complete instruction stream  
3. **Then report**: Show live registers at each marked instruction with correct information

## Implementation

### Added to `Function.__init__`:
```python
self._live_register_markers = []  # List of (instruction_object, label) tuples
```

### Modified `Function.print_live_registers`:
```python
def print_live_registers(self, label=""):
    """Mark this point for live register analysis."""
    # Find the last actual instruction object
    instr_obj = None
    for i in range(len(self.instructions) - 1, -1, -1):
        if isinstance(self.instructions[i], Instruction):
            instr_obj = self.instructions[i]
            break
    # Store reference to instruction object (not index - indices can change!)
    self._live_register_markers.append((instr_obj, label))
```

### New method `Function._report_live_registers_at_markers`:
```python
def _report_live_registers_at_markers(self):
    """Report live registers at all marked points."""
    for instr_obj, label in self._live_register_markers:
        if instr_obj is None:
            print(f"Live registers {label}: No instructions yet")
            continue
        # Use live_registers computed by determine_live_registers()
        live_regs = instr_obj.live_registers
        # Format and print
```

### Integrated in `Function.__exit__`:
```python
self.determine_live_registers(exclude_parameter_loads=True)

# Report live registers at marked points
if self._live_register_markers:
    self._report_live_registers_at_markers()
```

## Key Design Decision
Store **instruction object references** instead of indices because:
- Instruction indices can change during compilation (decomposition, optimization, etc.)
- Object references remain stable and directly point to the marked instruction
- Simpler and more reliable

## Results
Before fix (incorrect):
```
Live registers After ADD:
  GP (2): gp-vreg<12>, gp-vreg<13>
```

After fix (correct):
```
Live registers After ADD:
  GP (13): lr, gp-vreg<1>, gp-vreg<2>, gp-vreg<3>, gp-vreg<4>, gp-vreg<5>, 
           gp-vreg<8>, gp-vreg<9>, gp-vreg<10>, gp-vreg<12>, gp-vreg<13>, 
           gp-vreg<14>, gp-vreg<15>
```

Example with progression showing registers being freed:
```
Live registers After first ADD:
  GP (4): r0, r1, r2, lr

Live registers After MUL:
  GP (3): r2, lr, gp-vreg<1>

Live registers After second ADD:
  GP (3): lr, gp-vreg<1>, gp-vreg<2>
```

## Usage
```python
with Function(...):
    t0 = GeneralPurposeRegister()
    ADD(t0, r0, r1)
    print_live_registers("after ADD")  # Mark for analysis
    # ... more instructions ...
    print_live_registers("before STR")  # Another marker
    # Results printed after liveness analysis completes
```

## Files Changed
- `nervapy/arm/function.py`: Modified `print_live_registers()`, added `_report_live_registers_at_markers()`, integrated marker reporting in `__exit__`

