# Quick Reference: MOV.W with 32-bit Immediates

## TL;DR

```python
from nervapy.arm import *

# Use MOV_W for explicit 32-bit encoding
MOV_W(r0, 0x11111111)  # ✓ Works - generates: MOV.W r0, #286331153

# Or use regular MOV (assembler chooses)
MOV(r0, 0x11111111)    # ✓ Also works - generates: MOV r0, #286331153
```

## Why 0x11111111 Works

`MOV.W #0x11111111` is valid because Thumb-2 supports "modified immediate" encoding with byte repetition patterns. The value 0x11111111 is encoded as "repeat 0x11 four times".

## When It Works

✓ **Works** (modified immediate patterns):
- `0x11111111`, `0x22222222`, ..., `0xFFFFFFFF`
- `0xFF00FF00`, `0x00FF00FF`
- `0x000000AB` (any 8-bit value)
- `0x00CD00CD`, `0xEF00EF00`

✗ **Doesn't Work** (use MOVW+MOVT or LDR instead):
- `0x12345678` (arbitrary values)
- `0xABCDEF12` (no pattern)

## Alternatives for Arbitrary Values

```python
# Option 1: MOVW + MOVT (2 instructions, no literal pool)
MOVW(r0, 0x5678)
MOVT(r0, 0x1234)

# Option 2: LDR with literal (1 instruction, uses literal pool)
LDR(r0, literal=Literal(0x12345678))
```

## See Also

- `MOV_W_32BIT_IMMEDIATE.md` - Full documentation
- `test_mov_w_32bit.py` - Working examples
- `MOV_W_32BIT_SUPPORT.md` - Implementation details
