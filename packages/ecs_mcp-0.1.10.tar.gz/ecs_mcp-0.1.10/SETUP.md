## 1. Install Claude Desktop and open Cowork

## 2. Enable Gmail Connector (Customize -> Connectors -> + -> Browse Connectors)

## 3. Enable Affinity and ECS MCP servers
1. Open terminal and install uv
```curl -LsSf https://astral.sh/uv/install.sh | sh```
2. Get the uv path (this will be plugged into “your_uv_path” in the config below)
```which uvx```
3. Open Claude Desktop
Go to Settings -> Developer -> Edit Config
Copy and paste the “mcpServers” section:
```
{
  "mcpServers": {
    "affinity-mcp": {
      "command": "<your uv path>",
      "args": [
        "affinity-mcp"
      ],
      "env": {
        "AFFINITY_API_KEY": "<your Affinity API key>"
      }
    },
    "ecs-mcp": {
      "command": "<your uv path>",
      "args": [
        "ecs-mcp@0.1.10"
      ],
      "env": {
        "AFFINITY_API_KEY": "<your Affinity API key>"
      }
    }
  },
  "preferences": {
    "coworkScheduledTasksEnabled": true,
    "ccdScheduledTasksEnabled": true,
    "sidebarMode": "task",
    "coworkWebSearchEnabled": true
  }
}
```

## 4. Restart Claude Desktop and verify that “affinity-mcp” and "ecs-mcp" exists under “Connectors”.
Example prompts for `affinity-mcp`
* In Affinity, find all companies I first emailed in Q1 2026.
* In Affinity, show me people I haven’t spoken to since last year.
* Show me the deals in “new” status in the “ALL DEALS ECS” opportunity list in Affinity.

Note: The Affinity MCP is read-only

## 5. Setup schedule tasks for /tasks
