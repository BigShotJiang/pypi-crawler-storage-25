# ECS-MCP
This is an MCP server tool for the ECS company.

## Requirements
Must be Claude Desktop compatible with the ability to be configure via `claude_desktop_config.json` like below.
```
{
  "mcpServers": {
    "ecs-mcp": {
      "command": "your-uvx-path-here",
      "args": ["ecs-mcp"],
      "env": {
        "AFFINITY_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

Prerequisites:
* An Affinity account with API access (Scale, Advanced, or Enterprise)
* UV Python package manager
* An MCP-compatible AI assistant (e.g., Claude Desktop, GitHub Copilot, Gemini CLI)
* An Affinity API key — see the Authentication page for help obtaining one

## Tools
### Affinity
Create Affinity CRM tool that is a facade of its API:
https://api-docs.affinity.co/?utm_source=chatgpt.com#introduction-to-api-v1

Only create functions in the Affinity tool listed below.
Do not create any additional ones that are not listed below.

#### Create a new deal
Create a new deal on an existing list that's provided as a parameter (e.g. "ALL DEALS ECS").
Make sure to parse and populate the following data for each company:
* list_name: required - Affinity list to add to
* organization_name: required - Company name
* domain: optional - Company website (e.g. acme.com)
* contact_name: optional - Contact person's full names
* contact_email: optional - Contact person's email
* note: optional - Opportunity context from the email
* owner_email: optional - Email of the internal ECS person who owns this deal (from the email's To/CC fields)
