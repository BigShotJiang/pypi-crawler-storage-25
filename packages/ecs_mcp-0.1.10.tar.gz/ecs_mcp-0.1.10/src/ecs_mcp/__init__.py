"""ECS MCP Server — Affinity CRM integration."""

from importlib.metadata import version
from mcp.server.fastmcp import FastMCP

__version__ = version("ecs-mcp")

# Shared FastMCP instance — imported by server.py and all tool modules
mcp = FastMCP("ecs-mcp")
mcp._mcp_server.version = __version__
