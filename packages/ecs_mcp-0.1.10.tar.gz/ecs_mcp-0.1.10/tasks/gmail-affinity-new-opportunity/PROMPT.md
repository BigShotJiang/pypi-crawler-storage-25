**Gmail → Affinity CRM: New Opportunity Intake**

Scan Gmail for emails with the label `opportunity` and add any new companies to the **ALL DEALS ECS** list in Affinity CRM.

> **Tool routing:** Use **ecs-mcp** tools (`search_opportunities`, `create_deal`) for this entire workflow. Do not use affinity-mcp tools — they are for ad-hoc Affinity lookups, not bulk deal intake.

---

1. **Fetch emails:** Search Gmail with `label:opportunity`. Read the full body of each message.

2. **Extract opportunity data** from each email:
   - The **target company name** (the actual business being acquired/partnered with — not the broker/intermediary)
   - The **target company domain** — only if explicitly stated in the email (e.g. `acmebehavioralhealth.com`). Leave blank if undisclosed or unknown. **Never derive domain from the broker's email address.**
   - Broker/intermediary contact name and email
   - Key deal context: revenue, EBITDA, deal type, industry, location, growth metrics
   - The owner email: An email address of the ECS team member that's most actively engaged in the email (the internal person managing this deal)

3. **Determine the deal name** using this priority order:
   - **First choice — real company name:** If the target company's actual name is disclosed, use it (e.g. *"Acme Behavioral Health"*)
   - **Second choice — project code name:** If the real name is undisclosed but a code name exists, use it as-is (e.g. *"Project Atlas"*)
   - **Third choice — descriptive name:** If neither is available, construct one from business type + geography (e.g. *"Adolescent Psychiatric RTF – Mid-Atlantic"*)
   - **Never use** the broker/intermediary name as the deal name

4. **Check for duplicates** before adding anything. Run both searches in parallel using `ecs-mcp`:
   - `search_opportunities(term="<deal name>", list_id=339920)`
   - `search_opportunities(term="<1-2 distinctive keywords>", list_id=339920)`
   - If either returns a match, skip — do not duplicate

5. **Add new entries** using `create_deal` (ecs-mcp):
   - `list_name`: `ALL DEALS ECS`
   - `organization_name`: deal name per rule above
   - `domain`: target company's website domain — **leave empty if undisclosed or unknown**
   - `contact_name`, `contact_email`: broker/intermediary contact
   - `note`: concise deal summary — revenue, EBITDA, deal type, location, broker name, real company name if known
   - `owner_email`: The email addres of the internal ECS person managing this deal

6. **Report results** in a table:

| Deal Name | Action | Reason |
|---|---|---|
| Project Atlas | ⏭️ Skipped | Already exists in ALL DEALS ECS |
| Acme Behavioral Health | ✅ Added | New — not found in CRM |

---

**Known context:**
- ALL DEALS ECS list ID: `339920` (opportunity-type list)
- `domain` = the **target company's** website — empty string if company is undisclosed. The broker's email domain (e.g. `mertztaggart.com`) must never be used here.
- The broker/intermediary belongs only in `contact_name`, `contact_email`, and `note` — never as `organization_name` or `domain`
