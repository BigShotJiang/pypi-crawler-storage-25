import json
from pathlib import Path
from typing import Annotated, Any, cast

import typer
from rich.markup import escape

from hayhooks.cli.utils import (
    get_console,
    get_server_url,
    make_request,
    padded_output,
    show_error_and_abort,
    show_success,
    show_warning,
    upload_files_with_progress,
    with_progress_spinner,
)

pipeline = typer.Typer(rich_markup_mode="rich")


def _pname(name: str) -> str:
    """Wrap a pipeline name in Rich markup, escaping user-supplied chars."""
    return f"[pipeline.name]{escape(name)}[/pipeline.name]"


def _deploy_with_progress(ctx: typer.Context, name: str, endpoint: str, payload: dict) -> None:
    """Handle deployment with progress spinner and response handling."""
    response = cast(
        dict[str, Any],
        with_progress_spinner(
            f"Deploying pipeline '{name}'...",
            make_request,
            host=ctx.obj["host"],
            port=ctx.obj["port"],
            endpoint=endpoint,
            method="POST",
            json=payload,
            use_https=ctx.obj["use_https"],
            disable_ssl=ctx.obj["disable_ssl"],
            stream=False,
        ),
    )

    if response.get("name") == name:
        show_success(f"Pipeline {_pname(name)} successfully deployed!")
    else:
        show_error_and_abort(f"Pipeline {_pname(name)} already exists!")


@pipeline.command(name="deploy-yaml")
def deploy_yaml(  # noqa: PLR0913
    ctx: typer.Context,
    pipeline_file: Path = typer.Argument(  # noqa: B008
        help="The path to the YAML pipeline file to deploy."
    ),
    name: Annotated[str | None, typer.Option("--name", "-n", help="The name of the pipeline to deploy.")] = None,
    overwrite: Annotated[
        bool, typer.Option("--overwrite", "-o", help="Whether to overwrite the pipeline if it already exists.")
    ] = False,
    description: Annotated[
        str | None, typer.Option("--description", help="Optional description for the pipeline.")
    ] = None,
    skip_mcp: Annotated[
        bool, typer.Option("--skip-mcp", help="If set, skip MCP integration for this pipeline.")
    ] = False,
    save_file: Annotated[
        bool,
        typer.Option(
            "--save-file/--no-save-file",
            help="Whether to save the YAML under pipelines/{name}.yml on the server.",
        ),
    ] = True,
) -> None:
    """Deploy a YAML pipeline using the /deploy-yaml endpoint."""
    with padded_output():
        if not pipeline_file.exists():
            show_error_and_abort("Pipeline file does not exist.", str(pipeline_file))

        if name is None:
            name = pipeline_file.stem

        payload = {
            "name": name,
            "source_code": pipeline_file.read_text(encoding="utf-8"),
            "overwrite": overwrite,
            "description": description,
            "save_file": save_file,
            "skip_mcp": skip_mcp,
        }

        _deploy_with_progress(ctx=ctx, name=name, endpoint="deploy-yaml", payload=payload)


@pipeline.command()
def deploy_files(
    ctx: typer.Context,
    name: Annotated[str | None, typer.Option("--name", "-n", help="The name of the pipeline to deploy.")],
    pipeline_dir: Path = typer.Argument(  # noqa: B008
        help="The path to the directory containing the pipeline files to deploy."
    ),
    overwrite: Annotated[
        bool, typer.Option("--overwrite", "-o", help="Whether to overwrite the pipeline if it already exists.")
    ] = False,
    skip_saving_files: Annotated[
        bool, typer.Option("--skip-saving-files", "-s", help="Whether to skip saving the files to the server.")
    ] = False,
) -> None:
    """Deploy all pipeline files from a directory to the Hayhooks server."""
    with padded_output():
        if not pipeline_dir.exists():
            show_error_and_abort("Directory does not exist.", str(pipeline_dir))

        # Lazy import to avoid importing heavy server dependencies on CLI startup
        from hayhooks.server.utils.deploy_utils import read_pipeline_files_from_dir

        files_dict = read_pipeline_files_from_dir(pipeline_dir)

        if not files_dict:
            show_warning("No valid pipeline files found in the specified directory.")
            raise typer.Abort()

        if name is None:
            name = pipeline_dir.stem

        payload = {"name": name, "files": files_dict, "save_files": not skip_saving_files, "overwrite": overwrite}
        _deploy_with_progress(ctx=ctx, name=name, endpoint="deploy_files", payload=payload)


@pipeline.command(name="deploy", context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
def deploy(_ctx: typer.Context) -> None:
    """Removed command; use 'deploy-yaml' or 'deploy-files' instead."""
    with padded_output():
        show_warning(
            "`hayhooks pipeline deploy` has been removed.\n"
            "  Use `hayhooks pipeline deploy-yaml <pipeline.yml>` for YAML-based deployments or\n"
            "  `hayhooks pipeline deploy-files <pipeline_dir>` for PipelineWrapper-based deployments."
        )


@pipeline.command()
def undeploy(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="The name of the pipeline to undeploy.")],
) -> None:
    """Undeploy a pipeline from the Hayhooks server."""
    with padded_output():
        response = cast(
            dict[str, Any],
            with_progress_spinner(
                f"Undeploying pipeline '{name}'...",
                make_request,
                host=ctx.obj["host"],
                port=ctx.obj["port"],
                endpoint=f"undeploy/{name}",
                method="POST",
                use_https=ctx.obj["use_https"],
                disable_ssl=ctx.obj["disable_ssl"],
            ),
        )

        if response and response.get("success"):
            show_success(f"Pipeline {_pname(name)} successfully undeployed!")
        else:
            error_message = (
                response.get("detail", f"Failed to undeploy pipeline '{name}'")
                if response
                else f"Pipeline '{name}' not found"
            )
            show_error_and_abort(error_message)


@pipeline.command()
def run(  # noqa: PLR0912, C901, PLR0913
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="The name of the pipeline to run.")],
    file: Annotated[
        list[Path] | None, typer.Option("--file", "-f", help="Files to upload (can be specified multiple times)")
    ] = None,
    directory: Annotated[
        list[Path] | None,
        typer.Option("--dir", "-d", help="Directories to upload (all files within will be uploaded)"),
    ] = None,
    param: Annotated[
        list[str] | None,
        typer.Option("--param", "-p", help="Parameters in format key=value (value can be string or JSON)"),
    ] = None,
    stream: Annotated[
        bool,
        typer.Option("--stream", "-s", help="Enable streaming mode to display tokens as they arrive"),
    ] = False,
) -> None:
    """Run a pipeline with the given files and parameters."""
    with padded_output():
        files_to_upload = {}
        params_dict = {}

        if param:
            for p in param:
                if "=" not in p:
                    show_error_and_abort(f"Invalid parameter format: {p}. Use key=value")

                key, value = p.split("=", 1)

                try:
                    if (
                        (value.startswith("{") and value.endswith("}"))
                        or (value.startswith("[") and value.endswith("]"))
                        or value.lower() in ("true", "false", "null")
                        or (value.replace(".", "", 1).isdigit())
                    ):
                        params_dict[key] = json.loads(value)
                    else:
                        params_dict[key] = value
                except json.JSONDecodeError:
                    params_dict[key] = value

        if file:
            for f in file:
                if not f.exists():
                    show_error_and_abort(f"File {f} does not exist")
                if f.is_file():
                    files_to_upload[f.name] = f
                else:
                    show_error_and_abort(f"{f} is not a file")

        if directory:
            for dir_path in directory:
                if not dir_path.exists():
                    show_error_and_abort(f"Directory {dir_path} does not exist")
                if not dir_path.is_dir():
                    show_error_and_abort(f"{dir_path} is not a directory")

                for file_path in dir_path.rglob("*"):
                    if file_path.is_file() and not file_path.name.startswith("."):
                        rel_path = file_path.relative_to(dir_path)
                        files_to_upload[str(rel_path)] = file_path

        run_pipeline_with_files(ctx=ctx, pipeline_name=name, files=files_to_upload, params=params_dict, stream=stream)


def _run_with_files(ctx: typer.Context, pipeline_name: str, files: dict[str, Path], params: dict[str, Any]) -> dict:
    """Execute pipeline with file uploads."""
    server_url = get_server_url(host=ctx.obj["host"], port=ctx.obj["port"], https=ctx.obj["use_https"])
    endpoint = f"{server_url}/{pipeline_name}/run"

    form_data = {}
    for key, value in params.items():
        if isinstance(value, (dict, list)):
            form_data[key] = json.dumps(value)
        else:
            form_data[key] = str(value)

    get_console().print(f"[muted]Running pipeline[/muted] {_pname(pipeline_name)}[muted]...[/muted]")
    result, _ = upload_files_with_progress(
        url=endpoint, files=files, form_data=form_data, verify_ssl=not ctx.obj["disable_ssl"]
    )
    return result


def _run_with_streaming(ctx: typer.Context, pipeline_name: str, params: dict[str, Any]) -> None:
    """Execute pipeline in streaming mode."""
    console = get_console()
    console.print(f"[muted]Running pipeline[/muted] {_pname(pipeline_name)}[muted] in streaming mode...[/muted]")
    console.print("\n[accent.bold]Streaming output:[/accent.bold]")

    response = make_request(
        host=ctx.obj["host"],
        port=ctx.obj["port"],
        endpoint=f"{pipeline_name}/run",
        method="POST",
        json=params,
        disable_ssl=ctx.obj["disable_ssl"],
        use_https=ctx.obj["use_https"],
        stream=True,
    )

    if hasattr(response, "iter_content"):
        for chunk in response.iter_content(chunk_size=None, decode_unicode=True):
            if chunk:
                console.print(chunk, end="")

    console.print()
    show_success(f"Pipeline {_pname(pipeline_name)} executed successfully!")


def _run_regular(ctx: typer.Context, pipeline_name: str, params: dict[str, Any]) -> dict[str, Any]:
    """Execute pipeline in regular (non-streaming) mode."""
    return cast(
        dict[str, Any],
        with_progress_spinner(
            f"Running pipeline '{pipeline_name}'...",
            make_request,
            host=ctx.obj["host"],
            port=ctx.obj["port"],
            endpoint=f"{pipeline_name}/run",
            method="POST",
            json=params,
            disable_ssl=ctx.obj["disable_ssl"],
            use_https=ctx.obj["use_https"],
        ),
    )


def _display_result(result: dict) -> None:
    """Display pipeline execution result."""
    console = get_console()
    if "result" in result:
        console.print("\n[accent.bold]Result:[/accent.bold]")
        if isinstance(result["result"], (dict, list)):
            console.print_json(json.dumps(result["result"]))
        else:
            console.print(result["result"])
    else:
        console.print_json(json.dumps(result))


def run_pipeline_with_files(
    ctx: typer.Context, pipeline_name: str, files: dict[str, Path], params: dict[str, Any], stream: bool = False
) -> None:
    """Run a pipeline with files and parameters."""
    if files:
        if stream:
            show_warning("Streaming mode is not supported with file uploads. Running without streaming.")
        result = _run_with_files(ctx, pipeline_name, files, params)
    elif stream:
        _run_with_streaming(ctx, pipeline_name, params)
        return
    else:
        result = _run_regular(ctx, pipeline_name, params)

    show_success(f"Pipeline {_pname(pipeline_name)} executed successfully!")
    _display_result(result)
