from server import PromptServer


class ProgressController:
    def __init__(self, local_prompt_id):
        self.local_prompt_id = local_prompt_id
        self.remote_prompt_id = None

        self.server = PromptServer.instance

    def set_remote_prompt_id(self, remote_prompt_id):
        self.remote_prompt_id = remote_prompt_id

    def forward_websocket_event(self, event_data):
        event_type = event_data.get("type")
        data = event_data.get("data", {})

        if "prompt_id" in data:
            data["prompt_id"] = self.local_prompt_id

        if "nodes" in data and isinstance(data["nodes"], dict):
            for node_id, node_info in data["nodes"].items():
                if isinstance(node_info, dict) and "prompt_id" in node_info:
                    node_info["prompt_id"] = self.local_prompt_id

        self.server.send_sync(event_type, data)
