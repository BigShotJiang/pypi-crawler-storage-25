import json
import logging
import re
import urllib.request
from typing import Any, Dict, List, Set

logger = logging.getLogger(__name__)

# Fallback widget names (from BizyDraft/runWorkflowHandler.js SUPPLEMENT)
WIDGET_NAMES_SUPPLEMENT = [
    "clip_name",
    "clip_name1",
    "clip_name2",
    "clip_name3",
    "clip_name4",
    "ckpt_name",
    "lora_name",
    "name",
    "lora",
    "lora_01",
    "lora_02",
    "lora_03",
    "lora_04",
    "lora_1_name",
    "lora_2_name",
    "lora_3_name",
    "lora_4_name",
    "lora_5_name",
    "lora_6_name",
    "lora_7_name",
    "lora_8_name",
    "lora_9_name",
    "lora_10_name",
    "lora_11_name",
    "lora_12_name",
    "model_name",
    "control_net_name",
    "ipadapter_file",
    "unet_name",
    "vae_name",
    "model",
    "instantid_file",
    "pulid_file",
    "style_model_name",
    "yolo_model",
    "face_model",
    "bbox_model_name",
    "sam_model_name",
    "model_path",
    "upscale_model",
    "supir_model",
    "sdxl_model",
    "upscale_model_1",
    "upscale_model_2",
    "upscale_model_3",
    "sam_model",
    "sam2_model",
    "grounding_dino_model",
]

CONFIG_URL = "https://storage.bizyair.cn/config/comfyagent_node_config.json"


def get_possible_widget_names() -> Set[str]:
    """Get widget names from remote config, merged with supplement."""
    names = set(WIDGET_NAMES_SUPPLEMENT)
    try:
        with urllib.request.urlopen(CONFIG_URL, timeout=5) as response:
            config = json.loads(response.read().decode())
            weight_nodes = config.get("weight_load_nodes", {})
            for node_config in weight_nodes.values():
                inputs = node_config.get("inputs", {})
                if isinstance(inputs, dict):
                    names.update(inputs.keys())
    except Exception as e:
        logger.debug(f"Failed to fetch config, using supplement: {e}")
    return names


def build_process_transform(prompt_dict: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Build process_transform array from prompt dict.

    Identifies nodes with model_version_id and extracts transform info
    for backend model resolution.

    Args:
        prompt_dict: ComfyUI prompt dictionary with node_id -> node_data mapping

    Returns:
        List of process_transform entries
    """
    possible_widget_names = get_possible_widget_names()
    process_transform = []

    for node_id, node_data in prompt_dict.items():
        if not isinstance(node_data, dict):
            continue

        inputs = node_data.get("inputs", {})
        if not inputs or "model_version_id" not in inputs:
            continue

        class_type = node_data.get("class_type", "")

        # Skip BizyAir nodes
        if "bizyair" in class_type.lower():
            continue

        if class_type == "Power Lora Loader (rgthree)":
            # Handle Power Lora Loader with array model_version_id
            entries = _handle_power_lora_loader(
                node_id, node_data, inputs, class_type
            )
            process_transform.extend(entries)
        else:
            # Standard nodes
            entries = _handle_standard_node(
                node_id, node_data, inputs, class_type, possible_widget_names
            )
            process_transform.extend(entries)

    return process_transform


def _handle_power_lora_loader(
    node_id: str,
    node_data: Dict[str, Any],
    inputs: Dict[str, Any],
    class_type: str,
) -> List[Dict[str, Any]]:
    """Handle Power Lora Loader (rgthree) with array model_version_id."""
    results = []

    lora_keys = sorted([k for k in inputs if k.startswith("lora_")])
    raw = inputs.get("model_version_id")

    # Handle proxy object: {"__value__": [id1, id2, ...]}
    version_ids = []
    if isinstance(raw, dict) and "__value__" in raw:
        version_ids = raw["__value__"]
    elif isinstance(raw, list):
        version_ids = raw

    for lora_key in lora_keys:
        lora_val = inputs.get(lora_key)
        # Skip if lora is disabled (on === false)
        if isinstance(lora_val, dict) and lora_val.get("on") is False:
            continue

        # Parse index from lora_XX format
        m = re.search(r"\d+", lora_key)
        idx = int(m.group()) - 1 if m else 0

        val = version_ids[idx] if idx < len(version_ids) else 0

        results.append(
            {
                "node_id_str": node_id,
                "field_name": lora_key,
                "node_type": class_type,
                "class_type": class_type,
                "field_value": val,
            }
        )

    return results


def _handle_standard_node(
    node_id: str,
    node_data: Dict[str, Any],
    inputs: Dict[str, Any],
    class_type: str,
    possible_widget_names: Set[str],
) -> List[Dict[str, Any]]:
    """Handle standard nodes with model_version_id fields."""
    results = []

    # Find widget names in inputs
    widget_keys = [k for k in inputs if k in possible_widget_names]
    # Find model_version_id fields (sorted for consistent ordering)
    mv_keys = sorted([k for k in inputs if "model_version_id" in k])

    for idx, widget_key in enumerate(widget_keys):
        # Get corresponding model_version_id by index
        mv_key = mv_keys[idx] if idx < len(mv_keys) else "model_version_id"
        field_value = inputs.get(mv_key)

        if field_value:
            results.append(
                {
                    "node_id_str": node_id,
                    "field_name": widget_key,
                    "node_type": class_type,
                    "class_type": class_type,
                    "field_value": field_value,
                }
            )

    return results
