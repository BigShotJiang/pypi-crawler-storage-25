from enum import Enum


class TaskStatus(str, Enum):
    DONE = "[DONE]"
    QUEUING = "Queuing"
    PREPARING = "Preparing"
    SUCCESS = "Success"
    FAILED = "Failed"
    TASK_STATUS_CHANGED = "TASK_STATUS_CHANGED"
    QUEUED_CHANGED = "QUEUED_CHANGED"
