import asyncio
import json

import websockets
import logging as logger

from ..client.scx_client import SCXBaseClient
from .io_types import TaskStatus


class TaskMonitor:
    """Monitors the execution progress of a single task via WebSocket."""

    def __init__(self, client: SCXBaseClient):
        self.client = client

    async def listen(self, task_ws_url: str, result_queue: asyncio.Queue):
        endpoint_url = self.client.build_task_ws_url(task_ws_url)
        logger.debug(f"DEBUG: Task endpoint_url={endpoint_url}", flush=True)

        is_completed = False

        try:
            async with self.client.connect_ws(endpoint_url) as ws:
                logger.debug(f"DEBUG: Connected to Task WS: {ws}", flush=True)
                try:
                    async for payload in ws:
                        logger.debug(f"DEBUG: Task payload={payload}", flush=True)

                        if payload == TaskStatus.DONE:
                            is_completed = True
                            await result_queue.put(payload)
                            break
                        parsed_data = await self._parse_payload(payload)
                        if parsed_data:
                            await result_queue.put(parsed_data)
                except websockets.exceptions.ConnectionClosed:
                    logger.debug(
                        "WARNING: Task WS connection closed unexpectedly.", flush=True
                    )
        except asyncio.CancelledError:
            if not is_completed:
                raise

    async def _parse_payload(self, payload: str):
        """Helper method to handle JSON parsing and queueing."""
        return json.loads(payload)
