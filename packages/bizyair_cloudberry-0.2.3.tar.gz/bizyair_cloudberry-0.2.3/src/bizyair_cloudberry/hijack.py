import json
import os
import uuid
from copy import deepcopy

from server import PromptServer  # comfyui.server


def setup_prompt_hijack():
    prompt_server = PromptServer.instance

    prompt_server.add_on_prompt_handler(process_prompt)


def process_prompt(json_data):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cache_dir = os.path.join(script_dir, ".cache")
    os.makedirs(cache_dir, exist_ok=True)
    json_file_path = os.path.join(cache_dir, "json_data.json")
    modified_file_path = os.path.join(cache_dir, "modified_json_data.json")
    with open(json_file_path, "w") as f:
        json.dump(json_data, f, indent=2)

    workflow = (
        json_data.get("extra_data", {}).get("extra_pnginfo", {}).get("workflow", {})
    )
    is_cloudberry_mode = workflow.get("extra", {}).get("cloudberry_mode", False)

    if not is_cloudberry_mode:
        return json_data

    modified_data = deepcopy(json_data)

    if "prompt" not in modified_data:
        return json_data

    prompt = modified_data["prompt"]

    if not isinstance(prompt, dict) or len(prompt) == 0:
        return json_data

    original_prompt = deepcopy(prompt)

    prompt_json = json.dumps(original_prompt)

    cloudberry_prompt_id = str(json_data.get("prompt_id", uuid.uuid4()))

    extra_data = modified_data.get("extra_data", {})

    modified_data["prompt_id"] = cloudberry_prompt_id

    new_prompt = {
        "cloudberry_wrapper": {
            "class_type": "CloudBerrySubgraphNode",
            "inputs": {
                "input": prompt_json,
                "prompt_id": cloudberry_prompt_id,
                "extra_data": json.dumps(extra_data),
            },
        }
    }

    modified_data["prompt"] = new_prompt

    with open(modified_file_path, "w") as f:
        json.dump(modified_data, f, indent=2)
    return modified_data
