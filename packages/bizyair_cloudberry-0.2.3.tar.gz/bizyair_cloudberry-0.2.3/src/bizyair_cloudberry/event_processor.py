import os
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import unquote, urlparse

import requests


class EventType(str, Enum):
    EXECUTED = "executed"
    EXECUTION_SUCCESS = "execution_success"
    EXECUTION_ERROR = "execution_error"
    INTERNAL_ERROR = "internal_error"
    LOAD_START = "load_start"
    LOAD_END = "load_end"
    LOAD_PROGRESS = "load_progress"
    PROGRESS_STATE = "progress_state"
    CANCELLED = "cancelled"


class EventProcessor:
    SKIP_FORWARD_EVENTS: Set[str] = {
        "status",
        "SiliconFlow.metrics.executed",
        "SiliconFlow.metrics.execution_end",
        "crystools.monitor",
        "execution_start",
        "execution_success",
        "execution_cached",
    }

    def __init__(self, output_dir: str, temp_dir: str, progress_controller: Any):
        self.output_dir = output_dir
        self.temp_dir = temp_dir
        self.progress_controller = progress_controller
        self.url_to_local_file: Dict[str, Dict[str, Any]] = {}

        for directory in [self.output_dir, self.temp_dir]:
            if not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)

    def process_event(
        self,
        event_type: str,
        event_data: Dict[str, Any],
        cached_outputs: List[Dict[str, Any]],
    ) -> None:
        """
        Process an event and return any error that should terminate execution.

        Returns:
            None if processing should continue, Exception if execution should stop.
        """
        if self._should_skip_event(event_type):
            return
        processed_data, error = self._preprocess_event(event_type, event_data)
        self.progress_controller.forward_websocket_event(processed_data)

        if error:
            raise error

        if event_type == "executed":
            cached_outputs.append(event_data)

    def _should_skip_event(self, event_type: str) -> bool:
        return event_type in self.SKIP_FORWARD_EVENTS

    def _preprocess_event(
        self, event_type: str, event_data: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], Optional[Exception]]:
        if event_type == EventType.EXECUTED.value:
            data = event_data.get("data", {})
            if "output" in data and data["output"]:
                data["output"] = self._localize_output_urls(data["output"])
                event_data["data"] = data
            return event_data, None

        if event_type == EventType.LOAD_START.value:
            prev_data = event_data.get("data", {})
            node_progress = {
                "display_node_id": prev_data.get("node"),
                "max": 100,
                "node_id": prev_data.get("node"),
                "parent_node_id": "null",
                "prompt_id": self.progress_controller.local_prompt_id,
                "real_node_id": prev_data.get("node"),
                "state": "running",
                "value": 0,
            }
            event_data["data"] = {
                "nodes": {prev_data.get("node"): node_progress},
                "prompt_id": self.progress_controller.local_prompt_id,
            }
            event_data["type"] = EventType.PROGRESS_STATE.value
            return event_data, None

        if event_type == EventType.LOAD_PROGRESS.value:
            prev_data = event_data.get("data", {})
            percent = int(prev_data.get("percent", 0))
            node_progress = {
                "display_node_id": prev_data.get("node"),
                "max": 100,
                "node_id": prev_data.get("node"),
                "parent_node_id": "null",
                "prompt_id": self.progress_controller.local_prompt_id,
                "real_node_id": prev_data.get("node"),
                "state": "running",
                "value": percent,
            }
            event_data["data"] = {
                "nodes": {prev_data.get("node"): node_progress},
                "prompt_id": self.progress_controller.local_prompt_id,
            }
            event_data["type"] = EventType.PROGRESS_STATE.value
            return event_data, None

        if event_type == EventType.LOAD_END.value:
            prev_data = event_data.get("data", {})
            node_progress = {
                "display_node_id": prev_data.get("node"),
                "max": 100,
                "node_id": prev_data.get("node"),
                "parent_node_id": "null",
                "prompt_id": self.progress_controller.local_prompt_id,
                "real_node_id": prev_data.get("node"),
                "state": "finished",
                "value": 100,
            }
            event_data["data"] = {
                "nodes": {prev_data.get("node"): node_progress},
                "prompt_id": self.progress_controller.local_prompt_id,
            }
            event_data["type"] = EventType.PROGRESS_STATE.value
            return event_data, None

        if event_type == EventType.EXECUTION_ERROR.value:
            error_msg = event_data.get("data", {}).get(
                "exception_message", "Unknown execution error"
            )
            return event_data, Exception(error_msg)

        if event_type == EventType.INTERNAL_ERROR.value:
            error_msg = event_data.get("data", {}).get(
                "exception_message", "Internal error"
            )
            event_data["type"] = EventType.EXECUTION_ERROR.value
            return event_data, Exception(error_msg)

        return event_data, None

    def _localize_output_urls(self, obj: Any) -> Any:
        if isinstance(obj, list):
            return [self._localize_output_urls(item) for item in obj]

        if not isinstance(obj, dict):
            return obj

        filename_value = obj.get("filename")
        if isinstance(filename_value, str):
            parsed = urlparse(filename_value)
            if parsed.scheme in ("http", "https"):
                file_type_value = obj.get("type", "temp")
                file_type = (
                    file_type_value if isinstance(file_type_value, str) else "temp"
                )

                subfolder_value = obj.get("subfolder", "")
                subfolder = subfolder_value if isinstance(subfolder_value, str) else ""

                cache_key = f"{file_type}:{subfolder}:{filename_value}"
                cached = self.url_to_local_file.get(cache_key)
                if isinstance(cached, dict):
                    return cached

                local_path = self._download_single_file(
                    filename_value, file_type, subfolder
                )

                local_info = dict(obj)
                local_info["filename"] = os.path.basename(local_path)
                local_info["subfolder"] = subfolder
                local_info["type"] = file_type

                self.url_to_local_file[cache_key] = local_info
                return local_info

        return {k: self._localize_output_urls(v) for k, v in obj.items()}

    def _download_single_file(
        self, url: str, file_type: str, subfolder: str = ""
    ) -> str:
        if file_type == "output":
            base_dir = self.output_dir
        else:
            base_dir = self.temp_dir

        if subfolder:
            target_dir = os.path.join(base_dir, subfolder)
        else:
            target_dir = base_dir

        if not os.path.exists(target_dir):
            os.makedirs(target_dir, exist_ok=True)

        parsed_url = urlparse(url)
        filename = unquote(os.path.basename(parsed_url.path))

        local_path = os.path.join(target_dir, filename)
        if os.path.exists(local_path):
            return local_path

        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()

        with open(local_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)

        return local_path

    def _process_history_event(self, history_data: Dict[str, Any]) -> Dict[str, Any]:
        result: Dict[str, List[Any]] = {}

        data_outputs = history_data.get("outputs", {})

        for node_id, node_output in data_outputs.items():
            if not isinstance(node_output, dict):
                continue

            for output_key, output_value in node_output.items():
                if not isinstance(output_value, list):
                    continue

                if output_key not in result:
                    result[output_key] = []

                processed_values_any = self._localize_output_urls(output_value)
                if not isinstance(processed_values_any, list):
                    continue
                processed_values = processed_values_any
                result[output_key].extend(processed_values)

        return result

    def collect_outputs(self, executed_events: List[Dict[str, Any]]) -> Dict[str, Any]:
        result: Dict[str, List[Dict[str, Any]]] = {}

        for event_data in executed_events:
            data = event_data.get("data", {})
            output = data.get("output", {})

            if not output:
                continue

            for output_key, output_value in output.items():
                if not isinstance(output_value, list):
                    continue

                if output_key not in result:
                    result[output_key] = []

                result[output_key].extend(output_value)

        return result
