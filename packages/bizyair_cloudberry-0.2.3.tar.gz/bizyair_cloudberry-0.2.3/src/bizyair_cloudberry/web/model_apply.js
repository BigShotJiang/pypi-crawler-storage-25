/**
 * CloudBerry 模型选择入口文件
 * 基于 BizyDraft hookLoadModel.js 移植
 */

import { app } from "../../scripts/app.js";
import {
  getNodeConfig,
  hijackNode,
  unhijackNode,
  reconcileNodeOnLoad,
} from "./modules/model.js";

import "./bizyair_cloudberry_ui.js";

const SETTING_ID = "BizyAir.BizyAirPlus.enabled";

let _pinia = null;
let _storesWrapped = false;

function isEnabled() {
  return app.extensionManager.setting.get(SETTING_ID);
}

function getPinia() {
  if (_pinia) return _pinia;
  const vueApp = document.querySelector("#vue-app")?.__vue_app__;
  if (vueApp) {
    _pinia = vueApp.config.globalProperties.$pinia;
  }
  return _pinia;
}

/**
 * Wrap executionErrorStore.surfaceMissingModels and missingModelStore.setMissingModels
 * to suppress missing model warnings when CloudBerry mode is active, since all models
 * are resolved on the cloud side.
 *
 * Compatible with both old (Toast-based) and new (Errors Tab) ComfyUI frontends.
 * Returns true if at least one store was successfully wrapped.
 */
function tryWrapErrorStores(pinia) {
  if (_storesWrapped || !pinia) return false;

  let wrapped = false;

  const executionErrorStore = pinia._s.get("executionError");
  if (executionErrorStore?.surfaceMissingModels) {
    const original = executionErrorStore.surfaceMissingModels;
    executionErrorStore.surfaceMissingModels = function (models) {
      if (isEnabled()) {
        console.log(
          "[CloudBerry] Suppressed missing models in Error Tab:",
          models.length
        );
        return;
      }
      return original.call(this, models);
    };
    wrapped = true;
  }

  const missingModelStore = pinia._s.get("missingModel");
  if (missingModelStore?.setMissingModels) {
    const original = missingModelStore.setMissingModels;
    missingModelStore.setMissingModels = function (models) {
      if (isEnabled()) {
        return original.call(this, []);
      }
      return original.call(this, models);
    };
    wrapped = true;
  }

  if (wrapped) {
    _storesWrapped = true;
    console.log("[CloudBerry] Error store interceptors activated!");
  }
  return wrapped;
}

function clearMissingModelState() {
  const pinia = getPinia();
  if (!pinia) return;

  const missingModelStore = pinia._s.get("missingModel");
  if (missingModelStore?.clearMissingModels) {
    missingModelStore.clearMissingModels();
    console.log("[CloudBerry] Cleared missing model state");
  }

  const executionErrorStore = pinia._s.get("executionError");
  if (executionErrorStore?.dismissErrorOverlay && !executionErrorStore.hasNodeError &&
      !executionErrorStore.hasExecutionError && !executionErrorStore.hasPromptError) {
    executionErrorStore.dismissErrorOverlay();
  }
}

function cloneStructuredWidgetValues(widgets = []) {
  return widgets.map((widget) => ({
    name: widget.name,
    type: widget.type,
    value:
      widget.value && typeof widget.value === "object"
        ? JSON.parse(JSON.stringify(widget.value))
        : widget.value,
  }));
}

function walkGraph(graph, callback) {
  for (const node of graph._nodes ?? graph.nodes ?? []) {
    callback(node, graph);
    if (node.subgraph) walkGraph(node.subgraph, callback);
  }
}

/**
 * CloudBerry 模式切换时遍历所有节点，执行劫持或恢复
 * @param {boolean} enabled - 是否启用 CloudBerry 模式
 */
export function handleCloudBerryToggle(enabled) {
  if (!app.graph) return;

  if (enabled) {
    clearMissingModelState();
  }

  walkGraph(app.graph, (node) => {
    if (enabled && !node._cloudberryHijacked && node._cloudberryNodeConfig) {
      hijackNode(node, node._cloudberryNodeConfig);
    } else if (!enabled && node._cloudberryHijacked) {
      unhijackNode(node);
    }
  });
}

// 注册 ComfyUI 扩展
app.registerExtension({
  name: "bizyair.cloudberry.model.select",

  async beforeRegisterNodeDef(nodeType, nodeData, app) {
    const nodeConfig = await getNodeConfig(nodeData.name);

    if (nodeConfig) {
      const onNodeCreated = nodeType.prototype.onNodeCreated;
      nodeType.prototype.onNodeCreated = function () {
        try {
          this._cloudberryNodeConfig = nodeConfig;
          return onNodeCreated?.apply(this, arguments);
        } catch (error) {
          console.error("[CloudBerry] Error in node creation:", error);
        }
      };
    }
  },

  async nodeCreated(node) {
    const nodeConfig = await getNodeConfig(node?.comfyClass || node?.type);

    if (nodeConfig) {
      node._cloudberryNodeConfig = nodeConfig;
      console.log("[CloudBerry][nodeCreated]", {
        nodeId: node.id,
        nodeType: node.comfyClass || node.type,
        enabled: isEnabled(),
        existingWidgetValues: cloneStructuredWidgetValues(node.widgets),
      });

      if (isEnabled()) {
        hijackNode(node, nodeConfig);
      } else if (node._cloudberryHijacked) {
        unhijackNode(node);
      }
    }
  },

  async afterConfigureGraph() {
    console.log("[CloudBerry][afterConfigureGraph]", {
      enabled: isEnabled(),
      nodeCount: app.graph?._nodes?.length ?? 0,
    });

    const enabled = isEnabled();
    handleCloudBerryToggle(enabled);

    if (!enabled && app.graph) {
      walkGraph(app.graph, (node) => {
        if (node._cloudberryNodeConfig && !node._cloudberryHijacked) {
          reconcileNodeOnLoad(node, node._cloudberryNodeConfig);
        }
      });
    }

  },

  async setup() {
    const pinia = getPinia();
    if (!pinia) return;

    // Legacy: disable old missing models warning dialog (no-op on newer frontends)
    const settingStore = pinia._s.get("setting");
    await settingStore?.set("Comfy.Workflow.ShowMissingModelsWarning", false);

    // Legacy: filter Toast messages for older ComfyUI frontends
    const toastStore = pinia._s.get("toast");
    if (toastStore) {
      const originalAdd = toastStore.add;
      toastStore.add = function (message) {
        const detail = (message.detail || "").toLowerCase();
        const summary = (message.summary || "").toLowerCase();
        const text = `${summary} ${detail}`;

        const blockedKeywords = [
          "missing dependencies",
          "comfyui logs",
          "comfyullogs",
          "refer to the comfyui",
          "you may be missing",
        ];

        const shouldBlock = blockedKeywords.some((keyword) =>
          text.includes(keyword.toLowerCase())
        );

        if (shouldBlock) {
          console.log("[CloudBerry] Blocked toast:", message);
          return;
        }

        return originalAdd.call(this, message);
      };
      console.log("[CloudBerry] Toast blocker activated!");
    }

    // New: intercept Errors Tab / Error Overlay path (newer ComfyUI frontends)
    if (!tryWrapErrorStores(pinia)) {
      const retryDelays = [500, 1500, 3000];
      for (const delay of retryDelays) {
        setTimeout(() => tryWrapErrorStores(pinia), delay);
      }
    }
  },
});
