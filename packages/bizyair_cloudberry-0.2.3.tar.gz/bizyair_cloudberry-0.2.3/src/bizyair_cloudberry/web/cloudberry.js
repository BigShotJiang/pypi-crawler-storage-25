/**
 * BizyAir-CloudBerry Frontend Extension
 * Refactored into modules
 */

import { app } from "../../scripts/app.js";
import { setupInterception } from "./modules/logic.js";
import { setupUI, updateVisuals, showApiKeyDialog } from "./modules/ui.js";
import { handleCloudBerryToggle } from './model_apply.js';
import { t } from "./modules/i18n.js";

async function checkApiKey() {
  try {
    const res = await fetch("/bizyair/apikey/check");
    const data = await res.json();
    return data?.data;
  } catch (e) {
    console.error("[CloudBerry] API Key 检查失败", e);
    return null;
  }
}

app.registerExtension({
  name: "BizyAir.CloudBerry",

  settings: [
    {
      id: "BizyAir.BizyAirPlus.enabled",
      name: t("setting_enabled"),
      type: "boolean",
      defaultValue: false,
      onChange: async (newVal) => {
        if (newVal) {
          const keyData = await checkApiKey();
          if (!keyData || !keyData.has_key) {
            app.extensionManager.setting.set("BizyAir.BizyAirPlus.enabled", false);
            showApiKeyDialog();
            return;
          }
        }
        updateVisuals(newVal);
        handleCloudBerryToggle(newVal);
      },
    },
    {
      id: "BizyAir.BizyAirPlus.apikey",
      name: t("setting_apikey"),
      type: "text",
      defaultValue: "",
      onChange: async (newVal) => {
        if (newVal) {
          try {
            await fetch("/bizyair/apikey/save", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ api_key: newVal })
            });
            setTimeout(() => {
              app.extensionManager.setting.set("BizyAir.BizyAirPlus.apikey", newVal);
            }, 100);
          } catch (e) {
            console.error("[CloudBerry] API Key 保存失败", e);
          }
        }
      },
    }
  ],

  async setup() {
    setupInterception(app);

    checkApiKey().then(keyData => {
      if (keyData && keyData.has_key) {
        const currentKey = app.extensionManager.setting.get("BizyAir.BizyAirPlus.apikey");
        if (!currentKey || currentKey !== keyData.key_value) {
          app.extensionManager.setting.set("BizyAir.BizyAirPlus.apikey", keyData.key_value);
        }
      }
    });

    const initUI = () => {
      setupUI();
    };

    if (document.readyState === "complete") {
      initUI();
    } else {
      window.addEventListener("load", initUI);
    }
  },
});
