// UI 处理模块
import { app } from "../../../scripts/app.js";
import { t } from "./i18n.js";

const SETTING_ID = "BizyAir.BizyAirPlus.enabled";
const BIZYAIRPLUS_ICON_CLASS = "icon-[lucide--play]";
let originalQueueButtonText = null;
let iconBeforeBizyAirPlus = null;
let labelObserver = null;

function isEnabled() {
  return app.extensionManager.setting.get(SETTING_ID);
}

function isRunButtonText(text = "") {
  const trimmed = text.trim();
  return /^(Run|Queue|运行)(\s*\(.*\))?$/.test(trimmed);
}

function tagRoot(el) {
  if (el && !el.classList.contains("comfyui-queue-button")) {
    el.classList.add("comfyui-queue-button");
  }
  return el;
}

function findQueueButtonRoot() {
  const existing = document.querySelector(".comfyui-queue-button");
  if (existing) return existing;

  const queueBtn = document.querySelector('[data-testid="queue-button"]');
  if (queueBtn) {
    return tagRoot(queueBtn.closest(".queue-button-group") || queueBtn.parentElement);
  }

  const splitBtn = document.querySelector(".p-splitbutton");
  if (splitBtn) return tagRoot(splitBtn);

  const buttons = Array.from(document.querySelectorAll("button"));
  const runButton = buttons.find((b) => isRunButtonText(b.textContent || ""));
  if (!runButton) return null;
  return tagRoot(runButton.closest(".p-splitbutton") || runButton.parentElement);
}

function getMainQueueButton(queueButton = findQueueButtonRoot()) {
  if (!queueButton) return null;
  return (
    queueButton.querySelector('[data-testid="queue-button"]') ||
    queueButton.querySelector(".p-splitbutton-button") ||
    Array.from(queueButton.querySelectorAll("button")).find((b) =>
      isRunButtonText(b.textContent || "")
    ) ||
    null
  );
}

function getButtonLabelElement(queueButton = findQueueButtonRoot()) {
  if (!queueButton) return null;

  const primeLabel = queueButton.querySelector(
    ".p-splitbutton-button .p-button-label"
  );
  if (primeLabel) return primeLabel;

  const mainBtn = getMainQueueButton(queueButton);
  if (!mainBtn) return null;

  const existingLabel = mainBtn.querySelector(".cb-label");
  if (existingLabel) return existingLabel;

  for (const child of mainBtn.childNodes) {
    if (child.nodeType === Node.TEXT_NODE && child.textContent.trim()) {
      const span = document.createElement("span");
      span.className = "cb-label";
      span.textContent = child.textContent.trim();
      child.replaceWith(span);
      return span;
    }
  }

  return mainBtn;
}

function injectStyles() {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.type = "text/css";
  link.href = new URL("../cloudberry.css", import.meta.url).href;
  document.head.appendChild(link);
}

export function setupUI() {
  injectStyles();

  waitForQueueButton();
  setupMenuObservers();
  setupOtherMenuClicksObserver();
}

export function updateVisuals(enabled) {
  const queueButton = findQueueButtonRoot();
  if (queueButton) {
    queueButton.classList.toggle("cloudberry-active", enabled);
    if (enabled) {
      captureOriginalButtonState(queueButton);
      startButtonOverrideWatch(queueButton);
    } else {
      stopButtonOverrideWatch();
      if (originalQueueButtonText) {
        updateMainButtonLabel(originalQueueButtonText, false);
      }
      restoreIconBeforeBizyAirPlus(queueButton);
    }
  }

  const cloudBerryItems = document.querySelectorAll(".cloudberry-menu-item");
  cloudBerryItems.forEach((item) => {
    item.setAttribute("data-p-active", enabled ? "true" : "false");
    const button = item.querySelector("button") || item;
    updateButtonStyles(button, enabled);
  });
}

function getButtonIcon(queueButton) {
  const mainButton = getMainQueueButton(queueButton);
  return (
    mainButton?.querySelector?.('i[class*="icon-"]') ||
    queueButton?.querySelector?.('i[class*="icon-"]') ||
    null
  );
}

function setButtonIcon(queueButton, iconClass) {
  const icon = getButtonIcon(queueButton);
  if (icon instanceof HTMLElement) {
    icon.className = iconClass;
  }
}

function captureOriginalButtonState(queueButton) {
  if (!originalQueueButtonText) {
    const label = getButtonLabelElement(queueButton);
    if (label && label.textContent !== t("run_btn")) {
      originalQueueButtonText = label.textContent;
    }
  }
  const icon = getButtonIcon(queueButton);
  if (icon) {
    iconBeforeBizyAirPlus = icon.className;
  }
}

function restoreIconBeforeBizyAirPlus(queueButton) {
  if (iconBeforeBizyAirPlus) {
    const icon = getButtonIcon(queueButton);
    if (icon) {
      icon.className = iconBeforeBizyAirPlus;
    }
  }
}

function updateMainButtonLabel(label, isActivating = false) {
  const mainButton = getButtonLabelElement();
  if (mainButton) {
    mainButton.textContent = label;
  }
}

function startButtonOverrideWatch(queueButton) {
  stopButtonOverrideWatch();
  const mainButton = getMainQueueButton(queueButton);
  if (!mainButton) return;

  const applyOverride = () => {
    const label = getButtonLabelElement(queueButton);
    if (label && label.textContent !== t("run_btn")) {
      label.textContent = t("run_btn");
    }
    const icon = getButtonIcon(queueButton);
    if (icon && icon.className !== BIZYAIRPLUS_ICON_CLASS) {
      icon.className = BIZYAIRPLUS_ICON_CLASS;
    }
  };

  applyOverride();

  labelObserver = new MutationObserver(() => {
    if (!isEnabled()) return;
    applyOverride();
  });

  labelObserver.observe(mainButton, {
    childList: true,
    characterData: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class"],
  });
}

function stopButtonOverrideWatch() {
  if (labelObserver) {
    labelObserver.disconnect();
    labelObserver = null;
  }
}

function waitForQueueButton() {
  const check = () => {
    const queueButton = findQueueButtonRoot();
    if (queueButton) {
      captureOriginalButtonState(queueButton);
      updateVisuals(isEnabled());
    } else {
      setTimeout(check, 100);
    }
  };
  check();
}

function setupMenuObservers() {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType !== 1) return;

        if (
          node.getAttribute?.("role") === "menu" ||
          node.querySelector?.('[role="menu"]')
        ) {
          const menu =
            node.getAttribute("role") === "menu"
              ? node
              : node.querySelector('[role="menu"]');
          if (menu) {
            injectCloudBerryOption(menu);
            updateMenuSelectionState(menu);
          }
        }

        if (
          node.classList &&
          (node.classList.contains("p-splitbutton-panel") ||
            node.classList.contains("p-tieredmenu-overlay") ||
            node.classList.contains("p-tieredmenu") ||
            node.classList.contains("p-menu"))
        ) {
          injectCloudBerryOption(node);
          updateMenuSelectionState(node);
        }

        const menuLists = node.querySelectorAll?.(
          ".p-tieredmenu-root-list, .p-menu-list"
        );
        menuLists?.forEach((list) => {
          setTimeout(() => {
            injectCloudBerryOption(list);
            updateMenuSelectionState(list);
          }, 10);
        });
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

function isInsideQueueMenu(element) {
  if (element.closest('[role="menu"]')) {
    const root = document.querySelector(".comfyui-queue-button");
    const trigger = root?.querySelector(
      '[data-testid="queue-mode-menu-trigger"][data-state="open"], ' +
      '[data-testid="queue-mode-menu-trigger"][aria-expanded="true"]'
    );
    if (trigger) return true;
  }
  const primeMenu = element.closest(".p-tieredmenu-overlay, .p-splitbutton-panel");
  if (primeMenu) {
    const queueRoot = document.querySelector(".comfyui-queue-button, .p-splitbutton");
    if (queueRoot?.contains(primeMenu) || queueRoot?.nextElementSibling === primeMenu) return true;
  }
  return false;
}

function setupOtherMenuClicksObserver() {
  document.addEventListener(
    "click",
    (e) => {
      const rekaItem = e.target.closest('[role="menuitem"]');
      if (rekaItem && !rekaItem.classList.contains("cloudberry-menu-item")) {
        if (!isInsideQueueMenu(rekaItem)) return;
        const text = rekaItem.textContent || "";
        if (
          (text.includes("Run") ||
            text.includes("运行") ||
            text.includes("Queue")) &&
          isEnabled()
        ) {
          app.extensionManager.setting.set(SETTING_ID, false);
        }
        return;
      }

      const menuItem = e.target.closest(".p-tieredmenu-item");
      if (menuItem && !menuItem.classList.contains("cloudberry-menu-item")) {
        if (!isInsideQueueMenu(menuItem)) return;
        const button = menuItem.querySelector("button");
        if (
          button &&
          (button.textContent.includes("运行") ||
            button.textContent.includes("Run") ||
            button.textContent.includes("Queue"))
        ) {
          if (isEnabled()) {
            app.extensionManager.setting.set(SETTING_ID, false);
          }
        }
      }
    },
    true
  );
}

function injectCloudBerryOption(menuElement) {
  if (menuElement.getAttribute?.("role") === "menu") {
    if (menuElement.querySelector(".cloudberry-menu-item")) return;
    const hasRunOptions =
      menuElement.textContent?.includes("运行") ||
      menuElement.textContent?.includes("Run");
    if (!hasRunOptions) return;
    const item = createCloudBerryMenuItemReka(menuElement);
    menuElement.appendChild(item);
    return;
  }

  let menuList = null;

  if (menuElement.classList?.contains("p-tieredmenu-root-list")) {
    menuList = menuElement;
  } else {
    menuList =
      menuElement.querySelector(".p-tieredmenu-root-list") ||
      menuElement.querySelector(".p-menu-list") ||
      menuElement.querySelector('ul[role="menubar"]');
  }

  if (!menuList) {
    return;
  }

  if (menuList.querySelector(".cloudberry-menu-item")) {
    return;
  }

  const hasRunOptions =
    menuList.textContent?.includes("运行") ||
    menuList.textContent?.includes("Run");

  if (!hasRunOptions) {
    return;
  }

  const cloudBerryItem = createCloudBerryMenuItemPrime(menuList);

  menuList.appendChild(cloudBerryItem);

  updateAriaProperties(menuList);
}

function createCloudBerryMenuItemReka(menuContainer) {
  const button = document.createElement("button");
  button.className = "cloudberry-menu-item cloudberry-btn";
  button.setAttribute("role", "menuitem");
  button.setAttribute("tabindex", "-1");
  button.setAttribute("title", t("tooltip"));
  button.type = "button";
  button.textContent = t("menu_label");

  const refItem = menuContainer.querySelector(
    '[role="menuitem"]:not(.cloudberry-menu-item)'
  );
  if (refItem) {
    const refClasses = Array.from(refItem.classList).filter(
      (c) => !c.startsWith("cloudberry")
    );
    if (refClasses.length) {
      button.classList.add(...refClasses);
    }
  }

  updateButtonStyles(button, isEnabled());

  button.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    app.extensionManager.setting.set(SETTING_ID, !isEnabled());
    closeMenu();
  });

  return button;
}

function updateAriaProperties(menuList) {
  const items = menuList.querySelectorAll(".p-tieredmenu-item");
  const setSize = items.length;

  items.forEach((item, index) => {
    item.setAttribute("aria-setsize", setSize);
    item.setAttribute("aria-posinset", index + 1);
  });
}

function createCloudBerryMenuItemPrime(menuList) {
  const li = document.createElement("li");
  li.className = "p-tieredmenu-item cloudberry-menu-item";

  const baseId = menuList.id || "pv_id_cloudberry";
  li.id = `${baseId}_cloudberry_item`;

  li.setAttribute("role", "menuitem");
  li.setAttribute("aria-label", t("menu_label"));
  li.setAttribute("aria-level", "1");
  li.setAttribute("data-pc-section", "item");
  li.setAttribute("data-p-active", isEnabled() ? "true" : "false");
  li.setAttribute("data-p-focused", "false");

  const contentDiv = document.createElement("div");
  contentDiv.className = "p-tieredmenu-item-content";
  contentDiv.setAttribute("data-pc-section", "itemcontent");

  const button = document.createElement("button");
  button.className = "cloudberry-btn";
  updateButtonStyles(button, isEnabled());

  const referenceLi = menuList?.querySelector(
    ".p-tieredmenu-item:not(.cloudberry-menu-item)"
  );
  let scopedId = "";

  if (referenceLi) {
    const refBtn = referenceLi.querySelector("button");
    if (refBtn) {
      for (const attr of refBtn.attributes) {
        if (attr.name.startsWith("data-v-")) {
          scopedId = attr.name;
          break;
        }
      }
    }
  }

  if (scopedId) {
    button.setAttribute(scopedId, "");
  }

  button.setAttribute("data-pd-tooltip", "true");
  button.setAttribute("title", t("tooltip"));
  button.type = "button";

  const text = document.createTextNode(t("menu_label"));

  button.appendChild(text);
  contentDiv.appendChild(button);
  li.appendChild(contentDiv);

  button.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();

    app.extensionManager.setting.set(SETTING_ID, !isEnabled());

    const menuList = li.closest(".p-tieredmenu-root-list");
    if (menuList) {
      updateMenuSelectionState(menuList.parentElement);
    }

    closeMenu();
  });

  return li;
}

function updateButtonStyles(button, enabled) {
  if (enabled) {
    button.classList.add("primary");
    button.classList.remove("secondary");
  } else {
    button.classList.add("secondary");
    button.classList.remove("primary");
  }
}

function updateMenuSelectionState(menuElement) {
  if (menuElement.getAttribute?.("role") === "menu") {
    const allItems = menuElement.querySelectorAll('[role="menuitem"]');
    const cbItem = menuElement.querySelector(".cloudberry-menu-item");
    if (isEnabled() && cbItem) {
      allItems.forEach((item) => {
        if (!item.classList.contains("cloudberry-menu-item")) {
          if (!item.classList.contains("cloudberry-btn")) {
            item.classList.add("cloudberry-btn", "secondary");
            item.classList.remove("primary");
          } else {
            updateButtonStyles(item, false);
          }
        }
      });
      updateButtonStyles(cbItem, true);
    } else if (cbItem) {
      updateButtonStyles(cbItem, false);
    }
    return;
  }

  const menuList =
    menuElement.querySelector?.(".p-tieredmenu-root-list") || menuElement;
  if (!menuList) return;

  const allMenuItems = menuList.querySelectorAll(".p-tieredmenu-item");
  const cloudBerryItem = menuList.querySelector(".cloudberry-menu-item");

  if (isEnabled() && cloudBerryItem) {
    allMenuItems.forEach((item) => {
      if (!item.classList.contains("cloudberry-menu-item")) {
        const button = item.querySelector("button");
        if (button) {
          if (!button.classList.contains("cloudberry-btn")) {
            button.className = "cloudberry-btn secondary";
          } else {
            updateButtonStyles(button, false);
          }
        }
      }
    });

    const cloudBerryButton = cloudBerryItem.querySelector("button");
    if (cloudBerryButton) {
      updateButtonStyles(cloudBerryButton, true);
    }
  } else if (cloudBerryItem) {
    const cloudBerryButton = cloudBerryItem.querySelector("button");
    if (cloudBerryButton) {
      updateButtonStyles(cloudBerryButton, false);
    }
  }
}

function closeMenu() {
  setTimeout(() => {
    document.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Escape", bubbles: true })
    );

    const overlays = document.querySelectorAll(
      ".p-tieredmenu-overlay, .p-splitbutton-panel, .p-component-overlay"
    );
    overlays.forEach((overlay) => {
      if (overlay && overlay.style) {
        overlay.style.display = "none";
      }
    });
  }, 100);
}

export function showApiKeyDialog() {
  const dialog = document.createElement("dialog");
  dialog.className = "cloudberry-apikey-dialog";
  dialog.style.cssText = "padding: 20px; border-radius: 8px; border: 1px solid #ccc; box-shadow: 0 4px 6px rgba(0,0,0,0.1); background: var(--bg-color, #222); color: var(--fg-color, #fff); max-width: 400px; z-index: 10000;";
  
  const title = document.createElement("h3");
  title.textContent = "配置 BizyAir API Key";
  title.style.marginTop = "0";
  
  const desc = document.createElement("p");
  desc.innerHTML = '您需要配置 BizyAir API Key 才能使用云端加速服务。请访问 <a href="https://bizyair.cn" target="_blank" style="color: #4CAF50;">bizyair.cn</a> 获取您的 API Key。';
  
  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "sk-xxxxxxxxxxxxxxxx";
  input.style.cssText = "width: 100%; padding: 8px; margin: 10px 0; box-sizing: border-box; background: var(--comfy-input-bg, #111); color: var(--comfy-input-fg, #fff); border: 1px solid var(--border-color, #444); border-radius: 4px;";
  
  const buttonContainer = document.createElement("div");
  buttonContainer.style.cssText = "display: flex; justify-content: flex-end; gap: 10px; margin-top: 15px;";
  
  const cancelBtn = document.createElement("button");
  cancelBtn.textContent = "取消";
  cancelBtn.className = "p-button p-component p-button-secondary";
  cancelBtn.style.cssText = "padding: 8px 16px; cursor: pointer; border-radius: 4px; background: transparent; border: 1px solid #666; color: inherit;";
  
  const saveBtn = document.createElement("button");
  saveBtn.textContent = "保存";
  saveBtn.className = "p-button p-component";
  saveBtn.style.cssText = "padding: 8px 16px; cursor: pointer; border-radius: 4px; background: #4CAF50; border: none; color: white;";
  
  cancelBtn.onclick = () => {
    dialog.close();
    dialog.remove();
  };
  
  saveBtn.onclick = async () => {
    const key = input.value.trim();
    if (!key) {
      alert("请输入 API Key");
      return;
    }
    
    saveBtn.disabled = true;
    saveBtn.textContent = "保存中...";
    
    try {
      const res = await fetch("/bizyair/apikey/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_key: key })
      });
      const data = await res.json();
      
      if (data.code === 20000) {
        dialog.close();
        dialog.remove();
        app.extensionManager.setting.set("BizyAir.BizyAirPlus.apikey", key);
        app.extensionManager.setting.set(SETTING_ID, true);
      } else {
        alert("保存失败：" + (data.message || "未知错误"));
        saveBtn.disabled = false;
        saveBtn.textContent = "保存";
      }
    } catch (e) {
      alert("网络错误：" + e.message);
      saveBtn.disabled = false;
      saveBtn.textContent = "保存";
    }
  };
  
  buttonContainer.appendChild(cancelBtn);
  buttonContainer.appendChild(saveBtn);
  
  dialog.appendChild(title);
  dialog.appendChild(desc);
  dialog.appendChild(input);
  dialog.appendChild(buttonContainer);
  
  document.body.appendChild(dialog);
  dialog.showModal();
}
