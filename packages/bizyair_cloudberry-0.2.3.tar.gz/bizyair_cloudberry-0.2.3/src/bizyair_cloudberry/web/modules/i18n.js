const LOCALE_MAP = {
  "zh-CN": {
    "run_btn": "运行 (BizyAirPlus)",
    "menu_label": "运行 (BizyAirPlus)",
    "tooltip": "BizyAirPlus云端执行模式",
    "setting_enabled": "启用 BizyAirPlus 模式",
    "setting_apikey": "BizyAir API Key"
  },
  "en-US": {
    "run_btn": "Run (BizyAirPlus)",
    "menu_label": "Run (BizyAirPlus)",
    "tooltip": "BizyAirPlus Cloud Execution Mode",
    "setting_enabled": "Enable BizyAirPlus Mode",
    "setting_apikey": "BizyAir API Key"
  }
};

function getLanguage() {
  const lang = navigator.language || document.documentElement.lang || "en-US";
  return lang;
}

export function t(key) {
  const lang = getLanguage();
  const locale = lang.startsWith("zh") ? "zh-CN" : "en-US";
  
  const dict = LOCALE_MAP[locale] || LOCALE_MAP["en-US"];
  return dict[key] || key;
}
