// 逻辑劫持模块

export function setupInterception(app) {
  const originalGraphToPrompt = app.graphToPrompt.bind(app);

  // 一次性替换为带状态检查的版本
  app.graphToPrompt = async function (...gArgs) {
    const result = await originalGraphToPrompt(...gArgs);

    // 只在启用时注入
    const enabled = app.extensionManager.setting.get("BizyAir.BizyAirPlus.enabled");
    if (enabled && result?.workflow) {
      if (!result.workflow.extra) {
        result.workflow.extra = {};
      }
      result.workflow.extra.cloudberry_mode = true;
    }

    return result;
  };
}
