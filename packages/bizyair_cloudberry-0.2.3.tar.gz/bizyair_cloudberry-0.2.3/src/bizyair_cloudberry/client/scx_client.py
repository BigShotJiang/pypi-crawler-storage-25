import asyncio
import contextlib
from contextlib import asynccontextmanager
from enum import Enum
from typing import Any, AsyncIterator, Dict, Optional
from urllib.parse import urlencode
import logging as logger

import aiohttp
from websockets.asyncio.client import ClientConnection, connect


class MsgType(str, Enum):
    PING = "ping"
    PONG = "pong"


class SCXBaseClient:
    def __init__(
        self, base_endpoint: str, api_key: str, *, user_id: Optional[str] = None
    ):
        self.base_endpoint = base_endpoint.rstrip("/")
        self.api_key = api_key
        self._user_id = user_id

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    @asynccontextmanager
    async def connect_ws(
        self,
        url: str,
        interval: float = 10,
        timeout: float = 10,
    ) -> AsyncIterator[ClientConnection]:
        # ref: https://websockets.readthedocs.io/en/stable/reference/asyncio/client.html#using-a-connection

        async with connect(url) as ws:
            pong_event = asyncio.Event()
            _recv = ws.recv

            async def _ws_heartbeat():
                while True:
                    await ws.send(MsgType.PING)
                    pong_event.clear()
                    await asyncio.wait_for(pong_event.wait(), timeout=timeout)
                    await asyncio.sleep(interval)

            async def recv_with_pong():
                while True:
                    msg = await _recv()
                    if msg != MsgType.PONG:
                        return msg
                    pong_event.set()

            ws.recv = recv_with_pong
            ping_task = asyncio.create_task(_ws_heartbeat())
            try:
                yield ws
            finally:
                ping_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await ping_task

    async def get_user_id(self, timeout: float = 10.0) -> str:
        if self._user_id:
            return self._user_id

        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as session:
            async with session.get(
                f"{self.base_endpoint}/x/v1/user/metadata", headers=self._headers()
            ) as response:
                response.raise_for_status()
                self._user_id = (await response.json()).get("data", {}).get("id")
                return self._user_id

    async def get_backends(self, timeout: float = 10.0) -> Dict[str, Any]:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as session:
            async with session.get(
                f"{self.base_endpoint}/w/v1/plugin/backends", headers=self._headers()
            ) as response:
                response.raise_for_status()
                return await response.json()

    async def create_task(
        self,
        client_id: str,
        prompt_content: Dict[str, Any],
        process_transform=[],
        backend_id: int = 0,
        suppress_preview: bool = True,
        timeout: float = 30.0,
    ) -> str:

        payload = {
            "client_id": client_id,
            "process_transform": process_transform,
            "backend_id": backend_id,
            "suppress_preview_output": suppress_preview,
            "prompt_content": prompt_content,
        }
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as session:
            async with session.post(
                f"{self.base_endpoint}/w/v1/plugin/task/create",
                headers=self._headers(),
                json=payload,
            ) as response:
                logger.debug(
                    f"DEBUG: 提交了任务了 resp: client_id ID: {client_id} {backend_id} {await response.text()}",
                    flush=True,
                )
                response.raise_for_status()
                submission = await response.json()

                logger.debug(f"DEBUG: 提交了任务了 resp: {submission=}", flush=True)
                return submission

    async def cancel_task(self, task_id: str, timeout: float = 10.0) -> None:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as session:
            await session.put(
                f"{self.base_endpoint}/w/v1/comfy/task/{task_id}/cancel",
                headers=self._headers(),
            )

    async def interrupt_task(self, task_id: str, timeout: float = 10.0) -> None:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as session:
            async with session.put(
                f"{self.base_endpoint}/w/v1/comfy/task/{task_id}/interrupt",
                headers=self._headers(),
            ) as response:
                response.raise_for_status()

    def build_draft_ws_url(self, user_id: str) -> str:
        base = self.base_endpoint.replace("https://", "wss://").replace(
            "http://", "ws://"
        )
        params = {
            "userId": user_id,
            "type": "PLUGIN",
            "lang": "zh",
            "token": self.api_key,
        }
        return f"{base}/w/v1/comfy/draft/ws?{urlencode(params)}"

    def build_task_ws_url(self, ws_url: str) -> str:
        params = {"lang": "zh", "token": self.api_key}
        return f"{ws_url}&{urlencode(params)}"
