import os
import configparser
from functools import lru_cache
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

_env_vars: Optional["EnvironmentVariable"] = None

__all__ = ["env_vars", "get_env_vars"]


class EnvironmentVariable(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="CLOUDBERRY_",
        frozen=True,
    )

    bizyair_api_url: str = Field(
        default="https://api.bizyair.cn/x/v1",
        alias="BIZYAIR_API_URL",
    )

    scx_api_url: str = Field(
        default="https://api.bizyair.cn",
        alias="BIZYAIR_SCX_API_URL",
    )

    def get_api_key(self) -> Optional[str]:
        # 1. Environment variable (highest priority, for CI/CD and existing users)
        env_key = os.environ.get("BIZYAIR_API_KEY", "").strip()
        if env_key:
            return env_key

        # 2. New config location: ~/.BizyAirPlus/apikey.ini [default]
        new_config_path = os.path.expanduser("~/.BizyAirPlus/apikey.ini")
        key = self._read_ini_key(new_config_path, "default", "api_key")
        if key:
            return key

        # 3. Legacy bizyengine location: {cwd}/api_key.ini [auth]
        legacy_path = os.path.join(os.getcwd(), "api_key.ini")
        key = self._read_ini_key(legacy_path, "auth", "api_key")
        if key:
            return key

        return None

    @staticmethod
    def _read_ini_key(path: str, section: str, option: str) -> Optional[str]:
        if not os.path.exists(path):
            return None
        config = configparser.RawConfigParser()
        config.read(path)
        if config.has_section(section) and config.has_option(section, option):
            val = config.get(section, option).strip().strip("'\"")
            if val:
                return val
        return None

    def set_api_key(self, api_key: str) -> None:
        config_dir = os.path.expanduser("~/.BizyAirPlus")
        os.makedirs(config_dir, exist_ok=True)
        config_path = os.path.join(config_dir, "apikey.ini")
        
        # Use RawConfigParser to prevent interpolation of '%' characters in API keys
        config = configparser.RawConfigParser()
        if os.path.exists(config_path):
            config.read(config_path)
            
        if not config.has_section("default"):
            config.add_section("default")
            
        config.set("default", "api_key", api_key)
        
        with open(config_path, "w") as f:
            config.write(f)


@lru_cache
def init_env_vars() -> EnvironmentVariable:
    global _env_vars
    _env_vars = EnvironmentVariable()
    return _env_vars


def get_env_vars() -> EnvironmentVariable:
    if _env_vars is None:
        return init_env_vars()
    return _env_vars


env_vars = get_env_vars()
