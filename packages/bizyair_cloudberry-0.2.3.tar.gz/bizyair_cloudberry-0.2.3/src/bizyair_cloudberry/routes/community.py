"""
BizyAir CloudBerry API Routes

This module provides API routes for model selection functionality.
The API endpoints provided:
- /bizyair/apikey/check - Check if API key is set
- /bizyair/apikey/save - Save API key
- /bizyair/community/model_types - Get available model types
- /bizyair/community/base_model_types - Get available base model types
- /bizyair/dict - Get dictionary data (proxied from upstream, cached)
- /bizyair/community/models/query - Query models with filters (mode-aware)
- /bizyair/community/models/{model_id}/detail - Get model detail
"""

import time
import traceback
import urllib.parse

import aiohttp
from aiohttp import web

from ..env import env_vars

_dict_cache: dict = {}
_dict_cache_ts: float = 0.0
_DICT_CACHE_TTL = 3600  # 1 hour


def _auth_headers(api_key: str) -> dict:
    return {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _ok_response(data):
    return web.json_response({"code": 20000, "message": "success", "data": data})


def _err_response(code: int, message: str, status: int = 500):
    return web.json_response({"code": code, "message": message}, status=status)


def _require_api_key():
    api_key = env_vars.get_api_key()
    if not api_key:
        return None, _err_response(40100, "API Key is required", status=401)
    return api_key, None


def _init_apikey_routes(prompt_server):
    @prompt_server.routes.get("/bizyair/apikey/check")
    async def check_api_key(request):
        api_key = env_vars.get_api_key()
        has_key = bool(api_key)
        return web.json_response({"code": 20000, "data": {"has_key": has_key, "key_value": api_key if has_key else ""}})

    @prompt_server.routes.post("/bizyair/apikey/save")
    async def save_api_key(request):
        body = await request.json() if request.body_exists else {}
        api_key = body.get("api_key", "").strip()
        if not api_key:
            return _err_response(40000, "API Key is required", status=400)

        env_vars.set_api_key(api_key)
        return web.json_response({"code": 20000, "data": {"success": True}})


async def _proxy_get(url: str, headers: dict, params: list[tuple] = None):
    if params:
        qs = urllib.parse.urlencode(params, doseq=True)
        url = f"{url}?{qs}"

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as resp:
            if resp.status != 200:
                text = await resp.text()
                return None, _err_response(
                    resp.status,
                    f"BizyAir API error: {text}",
                    status=resp.status,
                )
            data = await resp.json()
            return data, None


def _init_model_routes(prompt_server):

    @prompt_server.routes.get("/bizyair/community/model_types")
    async def get_model_types(request):
        model_types = [
            {"label": "LoRA", "value": "LoRA"},
            {"label": "Controlnet", "value": "Controlnet"},
            {"label": "Checkpoint", "value": "Checkpoint"},
            {"label": "VAE", "value": "VAE"},
            {"label": "UNet", "value": "UNet"},
            {"label": "CLIP", "value": "CLIP"},
            {"label": "Upscaler", "value": "Upscaler"},
            {"label": "Detection", "value": "Detection"},
            {"label": "Other", "value": "Other"},
        ]
        return _ok_response(model_types)

    @prompt_server.routes.get("/bizyair/community/base_model_types")
    async def get_base_model_types(request):
        global _dict_cache
        if _dict_cache and "base_models" in _dict_cache:
            return _ok_response(_dict_cache["base_models"])

        fallback = [
            {"label": "Flux.1 D", "value": "Flux.1 D"},
            {"label": "Flux.1 S", "value": "Flux.1 S"},
            {"label": "SDXL", "value": "SDXL"},
            {"label": "SD 1.5", "value": "SD 1.5"},
            {"label": "SD 3.5", "value": "SD 3.5"},
            {"label": "Pony", "value": "Pony"},
            {"label": "Illustrious", "value": "Illustrious"},
            {"label": "Kolors", "value": "Kolors"},
            {"label": "Other", "value": "Other"},
        ]
        return _ok_response(fallback)

    @prompt_server.routes.get("/bizyair/dict")
    async def get_dict(request):
        global _dict_cache, _dict_cache_ts

        if _dict_cache_ts + _DICT_CACHE_TTL > time.time() and _dict_cache:
            return _ok_response(_dict_cache)

        api_key, err = _require_api_key()
        if err:
            if _dict_cache:
                return _ok_response(_dict_cache)
            return err

        server_url = f"{env_vars.bizyair_api_url}/dict"
        data, proxy_err = await _proxy_get(server_url, _auth_headers(api_key))

        if proxy_err:
            if _dict_cache:
                return _ok_response(_dict_cache)
            return proxy_err

        upstream_data = data.get("data", data)
        _dict_cache = upstream_data
        _dict_cache_ts = time.time()

        return _ok_response(upstream_data)

    @prompt_server.routes.post("/bizyair/community/models/query")
    async def query_models(request):
        try:
            api_key, err = _require_api_key()
            if err:
                return err

            mode = request.rel_url.query.get("mode", "publicity")
            if mode not in ("my", "my_fork", "publicity", "official"):
                return _err_response(40000, f"Invalid mode: {mode}", status=400)

            current = request.rel_url.query.get("current", "1")
            page_size = request.rel_url.query.get("page_size", "28")

            body = await request.json() if request.body_exists else {}
            keyword = body.get("keyword", "")
            model_types = body.get("model_types", [])
            base_models = body.get("base_models", [])
            sort = body.get("sort", "")
            has_draft = body.get("has_draft", None)

            if mode in ("my", "my_fork"):
                server_url = f"{env_vars.bizyair_api_url}/bizy_models/{mode}"
            elif mode == "official":
                server_url = f"{env_vars.bizyair_api_url}/bizy_models/official"
            else:
                server_url = f"{env_vars.bizyair_api_url}/bizy_models/community"

            query_params = [
                ("current", str(current)),
                ("page_size", str(page_size)),
            ]
            if keyword:
                query_params.append(("keyword", keyword))
            if sort:
                query_params.append(("sort", sort))
            if model_types:
                for mt in model_types:
                    query_params.append(("model_types", mt))
            if base_models:
                for bm in base_models:
                    query_params.append(("base_models", bm))
            if has_draft is not None:
                query_params.append(("has_draft", str(has_draft).lower()))

            data, proxy_err = await _proxy_get(
                server_url, _auth_headers(api_key), query_params
            )
            if proxy_err:
                return proxy_err

            upstream_data = data.get("data", data)
            return _ok_response(upstream_data)

        except Exception as e:
            print(f"☁️🍓 BizyAir-Plus: Error querying models: {e}")
            traceback.print_exc()
            return _err_response(50000, str(e))

    @prompt_server.routes.get("/bizyair/community/models/{model_id}/detail")
    async def get_model_detail(request):
        try:
            model_id = request.match_info["model_id"]
            source = request.rel_url.query.get("source", "")

            api_key, err = _require_api_key()
            if err:
                return err

            server_url = (
                f"{env_vars.bizyair_api_url}/bizy_models/{model_id}/detail"
            )
            params = []
            if source:
                params.append(("source", source))

            data, proxy_err = await _proxy_get(
                server_url, _auth_headers(api_key), params or None
            )
            if proxy_err:
                return proxy_err

            upstream_data = data.get("data", data)
            return _ok_response(upstream_data)

        except Exception as e:
            print(f"☁️🍓 BizyAir-Plus: Error getting model detail: {e}")
            traceback.print_exc()
            return _err_response(50000, str(e))


def init_routes():
    """Initialize API routes natively, eliminating bizyengine dependencies."""
    try:
        from server import PromptServer

        prompt_server = PromptServer.instance

        _init_apikey_routes(prompt_server)
        _init_model_routes(prompt_server)
        return True
    except Exception as e:
        print(f"☁️🍓 BizyAir-Plus: Error initializing routes: {e}")
        return False
