import os
from typing import Any, Dict, List

import folder_paths

from .file_utils import FileUtils


class InputHandler:
    def __init__(self):
        self.file_utils = FileUtils()
        self.image_extensions = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}

        self.model_extensions = {".safetensors", ".ckpt", ".pt", ".pth", ".bin"}

        self.model_key_patterns = (
            "model",
            "name",
            "checkpoint",
            "ckpt",
            "unet",
            "vae",
            "clip",
            "encoder",
            "decoder",
            "weights",
            "lora",
            "model_name",
            "checkpoint_name",
            "ckpt_name",
            "unet_name",
            "vae_name",
            "clip_name",
            "lora_name",
            "embedding_name",
        )

        self.input_directories = self._get_input_directories()

        # key format: "node_id:node_type:model_name"
        self.extra_pnginfo_model_map: Dict[str, str] = {}

    def _get_input_directories(self) -> List[str]:
        directories = []
        if hasattr(folder_paths, "get_input_directory"):
            input_dir = folder_paths.get_input_directory()
            directories.append(input_dir)

        if hasattr(folder_paths, "folder_names_and_paths"):
            paths_dict = folder_paths.folder_names_and_paths
            if isinstance(paths_dict, dict):
                for key in paths_dict:
                    if "input" in key.lower():
                        paths = paths_dict[key]
                        if isinstance(paths, (list, tuple)) and len(paths) > 0:
                            directories.extend(
                                paths[0] if isinstance(paths[0], list) else [paths[0]]
                            )

        if not directories:
            possible_paths = [
                os.path.join(os.getcwd(), "input"),
                os.path.join(os.path.dirname(__file__), "..", "..", "input"),
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    directories.append(path)
                    break

        return directories

    def _build_extra_pnginfo_model_map(self, extra_data: Dict[str, Any]) -> None:
        self.extra_pnginfo_model_map.clear()
        self._recursive_build_map(extra_data)

    def _recursive_build_map(self, data: Dict[str, Any]) -> None:
        if not isinstance(data, dict):
            return

        extra_pnginfo = data.get("extra_pnginfo", {})
        if not isinstance(extra_pnginfo, dict):
            return

        workflow = extra_pnginfo.get("workflow", {})
        if not isinstance(workflow, dict):
            return

        self._process_workflow_nodes(workflow)

        definitions = workflow.get("definitions", {})
        if isinstance(definitions, dict):
            subgraphs = definitions.get("subgraphs", [])
            if isinstance(subgraphs, list):
                for subgraph in subgraphs:
                    if isinstance(subgraph, dict):
                        nodes = subgraph.get("nodes", [])
                        if isinstance(nodes, list):
                            for node in nodes:
                                if isinstance(node, dict):
                                    self._process_node(node)
        elif isinstance(definitions, list):
            for item in definitions:
                self._recursive_build_map(item)

    def _process_workflow_nodes(self, workflow: Dict[str, Any]) -> None:
        nodes = workflow.get("nodes", [])
        if not isinstance(nodes, list):
            return

        for node in nodes:
            if isinstance(node, dict):
                self._process_node(node)
                self._recursive_build_map(node)

    def _process_node(self, node: Dict[str, Any]) -> None:
        node_id = node.get("id")
        node_type = node.get("type")
        if node_id is None or node_type is None:
            return

        properties = node.get("properties", {})
        if not isinstance(properties, dict):
            return

        models = properties.get("models", [])
        if not isinstance(models, list):
            return

        for model_entry in models:
            if isinstance(model_entry, dict):
                model_name = model_entry.get("name")
                model_url = model_entry.get("url")
                if model_name and model_url:
                    key = f"{node_id}:{node_type}:{model_name}"
                    self.extra_pnginfo_model_map[key] = model_url

    def process_prompt(
        self, prompt_dict: Dict[str, Any], extra_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        self._build_extra_pnginfo_model_map(extra_data)

        processed_prompt = {}

        for node_id, node_data in prompt_dict.items():
            if not isinstance(node_data, dict):
                processed_prompt[node_id] = node_data
                continue

            if "inputs" in node_data:
                node_type = node_data.get("class_type", "")
                node_data["inputs"] = self._process_node_inputs(
                    node_data["inputs"], node_id=node_id, node_type=node_type
                )

            processed_prompt[node_id] = node_data

        return processed_prompt

    def _process_node_inputs(
        self, inputs: Dict[str, Any], node_id: str, node_type: str
    ) -> Dict[str, Any]:
        processed_inputs = {}

        for key, value in inputs.items():
            if self._is_image_input(key, value):
                processed_inputs[key] = self._upload_image_to_url(value)
            # elif self._is_model_input(key, value):
            #     processed_inputs[key] = self._convert_model_to_url(
            #         value, node_id=node_id, node_type=node_type
            #     )
            else:
                processed_inputs[key] = value

        return processed_inputs

    def _is_image_input(self, key: str, value: Any) -> bool:
        if "image" in key.lower():
            if isinstance(value, str):
                _, ext = os.path.splitext(value.lower())
                if ext in self.image_extensions:
                    if os.path.exists(value):
                        return True
                    if not os.path.isabs(value):
                        full_path = self._find_image_in_input_dirs(value)
                        if full_path:
                            return True

        return False

    def _find_image_in_input_dirs(self, filename: str) -> str:
        for input_dir in self.input_directories:
            full_path = os.path.join(input_dir, filename)
            if os.path.exists(full_path):
                return full_path

        return ""

    def _upload_image_to_url(self, image_path: str) -> str:
        if not os.path.isabs(image_path):
            full_path = self._find_image_in_input_dirs(image_path)
            if full_path:
                image_path = full_path
            else:
                return image_path

        file_url = self.file_utils.upload_file(image_path)

        if not file_url:
            return image_path
        return file_url

    def _is_model_input(self, key: str, value: Any) -> bool:
        if not isinstance(value, str):
            return False

        _, ext = os.path.splitext(value.lower())
        if ext not in self.model_extensions:
            return False

        key_lower = key.lower()
        has_model_key = any(pattern in key_lower for pattern in self.model_key_patterns)

        return has_model_key

    def _convert_model_to_url(
        self, model_name: str, node_id: str, node_type: str
    ) -> str:
        actual_node_id = (
            node_id.split(":")[-1] if ":" in node_id else node_id
        )  # 子图节点需要取最后一部分作为实际 node_id
        key = f"{actual_node_id}:{node_type}:{model_name}"
        result = self.extra_pnginfo_model_map.get(key, model_name)
        return result
