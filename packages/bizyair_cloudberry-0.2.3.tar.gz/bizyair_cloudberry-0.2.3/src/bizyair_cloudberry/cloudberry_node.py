import asyncio
import json
from asyncio.log import logger
from typing import Any, Dict

import comfy.model_management
import folder_paths
from comfy.model_management import InterruptProcessingException

from .event_processor import EventProcessor, EventType
from .input_handler import InputHandler
from .progress_handler import ProgressController
from .scx_executor import SCXAPIExecutor, TaskStatus


class CloudBerrySubgraphNode:
    @classmethod
    def INPUT_TYPES(cls) -> Dict[str, Dict[str, Any]]:
        return {
            "required": {
                "input": ("STRING", {"multiline": True, "default": "{}"}),
                "prompt_id": ("STRING", {"default": ""}),
                "extra_data": ("STRING", {"multiline": True, "default": "{}"}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("status",)
    FUNCTION = "process"
    CATEGORY = "CloudBerry"
    OUTPUT_NODE = True

    @classmethod
    def IS_CHANGED(cls, input: str, prompt_id: str, extra_data: str) -> float:
        return float("NaN")

    def _get_temp_dir(self) -> str:
        return folder_paths.get_temp_directory()

    def _get_output_dir(self) -> str:
        return folder_paths.get_output_directory()

    async def process(
        self, input: str, prompt_id: str, extra_data: str, **kwargs: Any
    ) -> Dict[str, Dict[str, Any]]:
        prompt_dict = json.loads(input)
        extra_data_dict = json.loads(extra_data)
        input_handler = InputHandler()
        processed_prompt = input_handler.process_prompt(prompt_dict, extra_data_dict)

        progress_controller = ProgressController(prompt_id)

        temp_dir = self._get_temp_dir()
        output_dir = self._get_output_dir()
        event_processor = EventProcessor(output_dir, temp_dir, progress_controller)

        executor = SCXAPIExecutor()
        message_queue: asyncio.Queue[Any] = asyncio.Queue()
        cached_outputs: list[Dict[str, Any]] = []

        # backends = await executor.client.get_backends()
        # print(f"Debug: {backends=}", flush=True)

        workflow_task = asyncio.create_task(
            executor.execute_workflow(
                processed_prompt, result_queue=message_queue
            )
        )
        executor.stream

        while True:
            if comfy.model_management.processing_interrupted():
                workflow_task.cancel()
                raise InterruptProcessingException()

            if workflow_task.done():
                exc = workflow_task.exception()
                if exc:
                    # 如果是取消导致的异常，转换为 ComfyUI 的中断异常
                    if isinstance(exc, asyncio.CancelledError):
                        raise InterruptProcessingException()
                    raise exc

            try:
                message = await asyncio.wait_for(message_queue.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue

            if message == TaskStatus.DONE:
                break

            msg_type = message.get("type")

            if msg_type == EventType.CANCELLED:
                raise InterruptProcessingException()

            event_processor.process_event(msg_type, message, cached_outputs)

        return {"ui": {**event_processor.collect_outputs(cached_outputs)}}
