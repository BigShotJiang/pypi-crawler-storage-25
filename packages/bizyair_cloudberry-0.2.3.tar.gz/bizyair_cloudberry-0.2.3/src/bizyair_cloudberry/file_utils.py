import base64
import hashlib
import hmac
import os
from datetime import datetime, timezone
from typing import Any, Dict

import requests

from .env import env_vars


class FileUtils:
    def _get_upload_token(
        self, api_key: str, file_name: str, file_type: str = "inputs"
    ) -> Dict[str, Any]:
        url = f"{env_vars.bizyair_api_url}/upload/token"
        headers = {"Authorization": f"Bearer {api_key}"}
        params = {"file_name": file_name, "file_type": file_type}

        response = requests.get(url, headers=headers, params=params)

        if response.status_code != 200:
            raise ConnectionError(
                f"获取上传凭证失败，状态码: {response.status_code}, 响应: {response.text}"
            )

        data = response.json()

        if not data.get("status"):
            raise ConnectionError(
                f"获取上传凭证失败: {data.get('message', '未知错误')}"
            )

        return data.get("data", {})

    def _upload_file_to_oss(
        self,
        file_path: str,
        endpoint: str,
        bucket: str,
        object_key: str,
        access_key_id: str,
        access_key_secret: str,
        security_token: str,
    ) -> Dict[str, str]:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        if not endpoint:
            raise ValueError("endpoint 不能为空")
        if not bucket:
            raise ValueError("bucket 不能为空")
        if not object_key:
            raise ValueError("object_key 不能为空")

        url = f"https://{bucket}.{endpoint}/{object_key}"

        with open(file_path, "rb") as f:
            file_content = f.read()

        file_size = len(file_content)
        content_type = self._get_content_type(file_path)
        date = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")

        headers = {
            "Content-Length": str(file_size),
            "Content-Type": content_type,
            "Date": date,
            "x-oss-security-token": security_token,
            "Authorization": self._generate_oss_authorization(
                access_key_id,
                access_key_secret,
                "PUT",
                object_key,
                content_type,
                bucket,
                security_token,
                date,
            ),
        }

        response = requests.put(url, data=file_content, headers=headers)

        if response.status_code != 200:
            raise ConnectionError(
                f"上传到 OSS 失败，状态码: {response.status_code}, 响应: {response.text}"
            )

        return {
            "etag": response.headers.get("ETag", ""),
            "x-oss-hash-crc64ecma": response.headers.get("x-oss-hash-crc64ecma", ""),
        }

    def _commit_file(
        self, api_key: str, file_name: str, object_key: str
    ) -> Dict[str, Any]:
        url = f"{env_vars.bizyair_api_url}/input_resource/commit"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {"name": file_name, "object_key": object_key}

        response = requests.post(url, json=payload, headers=headers)

        if response.status_code != 200:
            raise ConnectionError(
                f"提交输入资源失败，状态码: {response.status_code}, 响应: {response.text}"
            )

        data = response.json()

        if not data.get("status"):
            raise ConnectionError(
                f"提交输入资源失败: {data.get('message', '未知错误')}"
            )

        return data.get("data", {})

    def download_file_from_url(self, url: str, file_path: str) -> None:
        pass

    def upload_file(self, file_path: str) -> str:
        api_key = env_vars.get_api_key()
        if not api_key:
            raise ValueError("BizyAir API Key 未设置，请先配置 API Key。")

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        file_name = os.path.basename(file_path)

        token_data = self._get_upload_token(api_key, file_name)

        file_info = token_data.get("file", {})
        storage_info = token_data.get("storage", {})

        self._upload_file_to_oss(
            file_path=file_path,
            endpoint=storage_info.get("endpoint", ""),
            bucket=storage_info.get("bucket", ""),
            object_key=file_info.get("object_key", ""),
            access_key_id=file_info.get("access_key_id", ""),
            access_key_secret=file_info.get("access_key_secret", ""),
            security_token=file_info.get("security_token", ""),
        )

        result = self._commit_file(
            api_key=api_key,
            file_name=file_name,
            object_key=file_info.get("object_key", ""),
        )

        file_url = result.get("url", "")
        return file_url

    def _get_content_type(self, file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()
        content_types = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".mp4": "video/mp4",
            ".mp3": "audio/mpeg",
            ".wav": "audio/wav",
            ".txt": "text/plain",
            ".json": "application/json",
            ".xml": "application/xml",
        }
        return content_types.get(ext, "application/octet-stream")

    def _generate_oss_authorization(
        self,
        access_key_id: str,
        access_key_secret: str,
        method: str,
        object_key: str,
        content_type: str,
        bucket: str,
        security_token: str,
        date: str,
    ) -> str:
        canonicalized_oss_headers = f"x-oss-security-token:{security_token}\n"
        canonicalized_resource = f"/{bucket}/{object_key}"

        string_to_sign = f"{method}\n\n{content_type}\n{date}\n{canonicalized_oss_headers}{canonicalized_resource}"

        signature = base64.b64encode(
            hmac.new(
                access_key_secret.encode("utf-8"),
                string_to_sign.encode("utf-8"),
                hashlib.sha1,
            ).digest()
        ).decode("utf-8")

        return f"OSS {access_key_id}:{signature}"
