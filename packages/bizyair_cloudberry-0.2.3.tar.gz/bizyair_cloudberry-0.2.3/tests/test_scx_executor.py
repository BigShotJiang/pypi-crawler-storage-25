# import asyncio
# import json
# import os
# from datetime import datetime
# from pathlib import Path

# import pytest

# from bizyair_cloudberry.event_processor import EventType
# from bizyair_cloudberry.scx_api_executor import (SCXAPIExecutor,
#                                                  WebSocketMessageType)


# def get_workflow_path(workflow_name: str) -> Path:
#     """获取工作流文件路径"""
#     test_dir = Path(__file__).parent
#     workflow_path = test_dir / "test_workflows" / f"{workflow_name}.json"

#     if not workflow_path.exists():
#         raise FileNotFoundError(
#             f"工作流文件不存在: {workflow_path}\n"
#             f"请在 tests/test_workflows/ 目录下创建对应的工作流文件"
#         )

#     return workflow_path


# def load_workflow(workflow_name: str) -> dict:
#     """加载工作流 JSON 文件"""
#     workflow_path = get_workflow_path(workflow_name)
#     with open(workflow_path, "r", encoding="utf-8") as f:
#         return json.load(f)


# @pytest.mark.skipif(
#     not os.environ.get("BIZYAIR_API_KEY"),
#     reason="需要设置 BIZYAIR_API_KEY 环境变量才能运行集成测试",
# )
# class TestSCXExecutorIntegration:
#     @pytest.fixture
#     def executor(self):
#         return SCXAPIExecutor()

#     @pytest.fixture
#     def workflow(self, request):
#         """从 test_workflows 目录加载指定的工作流文件

#         使用方式：
#         - 命令行指定: pytest --workflow image_test
#         - 默认使用: image_test.json
#         """
#         workflow_name = request.config.getoption("--workflow")
#         print(f"\n[Workflow] 加载工作流: {workflow_name}.json")
#         return load_workflow(workflow_name)

#     @pytest.mark.asyncio
#     async def test_execute_workflow_success(self, executor, workflow, request):
#         """测试 execute_workflow 成功执行 - 与生产环境 process 方法判定逻辑一致

#         生产环境 process 方法判定成功/失败的逻辑：
#         - 成功：收到 WebSocketMessageType.DONE ("[DONE]") 消息
#         - 失败/取消：收到 EventType.CANCELLED ("cancelled") 消息
#         - 注意：execution_error / internal_error 不会提前退出循环，由 event_processor 处理
#         """
#         message_queue: asyncio.Queue = asyncio.Queue()
#         received_events = []

#         async def collect_events():
#             async with asyncio.timeout(60):
#                 while True:
#                     msg = await message_queue.get()
#                     received_events.append(msg)

#                     # 与生产环境 cloudberry_node.py process 方法判定逻辑一致
#                     # 成功：收到 [DONE]
#                     if msg == WebSocketMessageType.DONE:
#                         print(f"[Event] {msg} -> 任务成功")
#                         break

#                     # 失败：收到 cancelled
#                     if isinstance(msg, dict) and msg.get("type") == EventType.CANCELLED:
#                         print(f"[Event] {msg.get('type')} -> 任务被取消")
#                         break

#         workflow_task = asyncio.create_task(
#             executor.execute_workflow(workflow, message_queue)
#         )
#         collector_task = asyncio.create_task(collect_events())

#         try:
#             result = await asyncio.gather(
#                 workflow_task, collector_task, return_exceptions=True
#             )
#             workflow_result = result[0]  # execute_workflow 的返回值

#             # 断言：必须收到至少一个事件
#             assert len(received_events) > 0, "应该收到至少一个事件"

#             # 断言：最后一个事件必须是 DONE（即成功完成）
#             assert (
#                 received_events[-1] == WebSocketMessageType.DONE
#             ), f"任务未成功完成，最后收到的事件: {received_events[-1]}"

#             print(f"[Result] 共收到 {len(received_events)} 个事件")

#         except Exception as e:
#             print(f"[Exception] {e}")
#             raise
#         finally:
#             # 保存事件到 cache 目录，便于后续 debug
#             workflow_name = request.config.getoption("--workflow")
#             self._save_events_to_cache(received_events, workflow_name)

#     def _save_events_to_cache(self, events: list, workflow_name: str = "") -> None:
#         """将测试收到的事件保存到 cache 目录下的 txt 文件中"""
#         cache_dir = Path(__file__).parent / "cache"
#         cache_dir.mkdir(exist_ok=True)

#         # 使用工作流名称和时间戳作为文件名
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"events_{workflow_name}_{timestamp}.txt"
#         filepath = cache_dir / filename

#         with open(filepath, "w", encoding="utf-8") as f:
#             f.write(f"总共收到 {len(events)} 个事件\n")
#             f.write("=" * 60 + "\n\n")
#             for i, event in enumerate(events, 1):
#                 if isinstance(event, str):
#                     f.write(f"[{i}] {event}\n")
#                 elif isinstance(event, dict):
#                     f.write(f"[{i}] {json.dumps(event, ensure_ascii=False)}\n")
#                 else:
#                     f.write(f"[{i}] {type(event).__name__}: {event}\n")

#         print(f"[Debug] 事件已保存到: {filepath}")


# # 运行:
# #   export BIZYAIR_API_KEY=xxx
# #   python -m pytest tests/test_scx_executor.py -v -s
# #   指定工作流: python -m pytest tests/test_scx_executor.py -v -s --workflow image_test
# # 说明: 工作流文件放在 tests/test_workflows/ 目录下，文件名不含 .json 后缀
