import os
import tempfile

import pytest
import requests

from bizyair_cloudberry.file_utils import FileUtils


@pytest.mark.skipif(
    not os.environ.get("BIZYAIR_API_KEY"),
    reason="需要设置 BIZYAIR_API_KEY 环境变量才能运行集成测试",
)
class TestFileUtilsIntegration:
    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        self.file_utils = FileUtils()
        self.test_content = b"Hello, CloudBerry! This is a real integration test."
        with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as tmp:
            tmp.write(self.test_content)
            self.file_path = tmp.name

        yield

        if os.path.exists(self.file_path):
            os.remove(self.file_path)

    def test_upload_file_end_to_end(self):
        file_url = self.file_utils.upload_file(self.file_path)

        assert isinstance(file_url, str)
        assert file_url.startswith("http"), "返回的 URL 格式不正确"

        response = requests.get(file_url, timeout=10)

        assert response.status_code == 200, "下载上传的文件失败"
        assert response.content == self.test_content, "下载的文件内容与上传的不一致"


# cd tests && PYTHONPATH=.. python -m pytest test_file_utils.py
