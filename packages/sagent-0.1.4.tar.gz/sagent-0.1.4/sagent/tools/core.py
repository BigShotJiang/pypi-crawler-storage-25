"""Tool framework: decorator, state, sandbox.

This module contains the infrastructure for building tools.
For built-in tool implementations, see ``tools/`` siblings.

Usage::

    from sagent.tools.core import tool, get_tool_state

    @tool(name="MyTool")
    def my_tool(query: str) -> str:
        ...
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from pathlib import Path
from typing import cast, get_type_hints, overload

import asyncio
import dataclasses
import inspect
import logging
import re
import time
import typing

import yaml

from sagent.agent.runtime import ToolResult
from sagent.agent.state import (
    AgentLike,
    ReadCacheEntry,
    ToolState,
    agent_counter_var,
    agent_label_var,
    agent_path_var,
    agent_registry,
    cost_root_var,
    current_agent_var,
    get_tool_state,
    max_depth_var,
    tool_state_context,
    tool_state_var,
)
from sagent.lib.json import JSON, int_val, json_freeze


logger = logging.getLogger(__name__)

_ASSETS_DIR = Path(__file__).parent.parent / "assets"
_NOW_PLACEHOLDER = "{{NOW}}"
_DEFAULT_RECIPE = "sagent"
_RE_INCLUDE = re.compile(r"\{\{include:\s*(.+?)\}\}")
_recipe_path_override: Path | None = None
_recipe_cache: dict[str, object] | None = None


def resolve_recipe(name_or_path: str) -> Path:
    """Resolve a recipe spec to a yaml path.

    Accepts either a bare name (looked up in ``assets/<name>.yaml``) or
    a filesystem path (anything containing ``/`` or ending in
    ``.yaml``/``.yml``). The path is expanded and resolved.

    Args:
      name_or_path: Recipe name or filesystem path.

    Returns:
      path: Expanded, resolved absolute path to the recipe yaml.

    """
    looks_like_path = "/" in name_or_path or name_or_path.endswith((".yaml", ".yml"))
    base = (
        Path(name_or_path) if looks_like_path else _ASSETS_DIR / f"{name_or_path}.yaml"
    )
    return base.expanduser().resolve()


def set_recipe(name_or_path: str) -> None:
    """Switch the active recipe; clears the load cache.

    Args:
      name_or_path: Recipe name or filesystem path.

    """
    global _recipe_path_override, _recipe_cache  # noqa: PLW0603 -- process-level state
    _recipe_path_override = resolve_recipe(name_or_path)
    _recipe_cache = None


def _load_recipe() -> dict[str, object]:
    """Load and cache the active recipe.yaml."""
    global _recipe_cache  # noqa: PLW0603 -- module-level cache
    if _recipe_cache is not None:
        return _recipe_cache
    recipe_path = _recipe_path_override or (_ASSETS_DIR / f"{_DEFAULT_RECIPE}.yaml")
    loaded = yaml.safe_load(recipe_path.read_text(encoding="utf-8"))
    _recipe_cache = cast(dict[str, object], loaded) if isinstance(loaded, dict) else {}
    return _recipe_cache


def read_asset(path: str | Path) -> str:
    """Read an asset file, expanding ``{{include: path}}`` directives.

    Args:
      path: Relative path within the assets directory, or absolute path.

    Returns:
      text: File contents with include directives recursively expanded.

    """
    p = _ASSETS_DIR / path if isinstance(path, str) else path
    text = p.read_text(encoding="utf-8")

    def _replace(m: re.Match[str]) -> str:
        return read_asset(m.group(1).strip())

    return _RE_INCLUDE.sub(_replace, text)


def recipe_dict(key: str) -> dict[str, str]:
    """Get a typed dict section from the recipe.

    Args:
      key: Top-level recipe key to look up.

    Returns:
      section: String-to-string mapping, empty if key is absent or not a dict.

    """
    raw = _load_recipe().get(key, {})
    if not isinstance(raw, dict):
        return {}
    d = cast(dict[str, object], raw)
    return {str(k): str(v) for k, v in d.items()}


def recipe_list(section: str, key: str) -> list[str]:
    """Get a typed list from a recipe section.

    Args:
      section: Top-level recipe key containing a dict.
      key: Key within that dict whose value is a list.

    Returns:
      items: List of stringified items, empty if absent or malformed.

    """
    raw = _load_recipe().get(section, {})
    if not isinstance(raw, dict):
        return []
    d = cast(dict[str, object], raw)
    items = d.get(key, [])
    if not isinstance(items, list):
        return []
    return [str(x) for x in cast(list[object], items)]


_MISSING_TOOL_DESCRIPTION = "Tool description unavailable; use the JSON schema exactly."


def load_tool_description(name: str) -> str:
    """Load a tool description from the active recipe.

    Tool descriptions are optional prompt fragments, so missing files soft-fail
    to a generic agent-visible description. Other recipe assets stay strict at
    their call sites. Paths are explicit in recipe.yaml -- no fallback search.
    Substitutes ``{{NOW}}`` with the current
    ``Month YYYY``.

    Args:
      name: Tool name (case-insensitive lookup).

    Returns:
      description: Rendered tool description, or a generic fallback on miss.

    """
    tool_descs = recipe_dict("tool_descriptions")
    by_lower = {k.lower(): v for k, v in tool_descs.items()}
    key = name.lower()
    if key not in by_lower:
        logger.error(
            "Tool %r not in recipe %s", name, _recipe_path_override or _DEFAULT_RECIPE
        )
        return ""
    try:
        text = read_asset(str(by_lower[key])).rstrip()
    except FileNotFoundError:
        logger.exception(
            "Missing tool description asset for tool %r in recipe %s: %s",
            name,
            _recipe_path_override or _DEFAULT_RECIPE,
            by_lower[key],
        )
        return _MISSING_TOOL_DESCRIPTION
    if _NOW_PLACEHOLDER in text:
        text = text.replace(_NOW_PLACEHOLDER, time.strftime("%B %Y"))
    return text


# 100K tokens × ~4 chars/token.
TOOL_RESULT_MAX_CHARS = 400_000

_TYPE_MAP: dict[type[object], str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
}


def _type_to_schema(t: type | object) -> dict[str, object]:
    """Convert a Python type annotation to a JSON Schema fragment."""
    if isinstance(t, type) and t in _TYPE_MAP:
        return {"type": _TYPE_MAP[t]}
    origin = typing.get_origin(t)
    if origin is list:
        args = typing.get_args(t) or (str,)
        return {
            "type": "array",
            "items": _type_to_schema(args[0]),
        }
    if origin is dict:
        return {"type": "object"}
    return {"type": "string"}


def _build_schema(
    fn: Callable[..., object],
    hints: dict[str, object],
) -> dict[str, object]:
    """Build JSON Schema from function signature and type hints."""
    sig = inspect.signature(fn)
    properties: dict[str, object] = {}
    required: list[str] = []
    for name, param in sig.parameters.items():
        if name == "self":
            continue
        t = hints.get(name, str)
        description = None
        origin = typing.get_origin(t)
        if origin is typing.Annotated:
            args = typing.get_args(t)
            t = args[0]
            for arg in args[1:]:
                if isinstance(arg, str):
                    description = arg
                    break
        prop = _type_to_schema(t)
        if description:
            prop["description"] = description
        properties[name] = prop
        if param.default is inspect.Parameter.empty:
            required.append(name)
    schema: dict[str, object] = {
        "type": "object",
        "properties": properties,
        "additionalProperties": False,
    }
    if required:
        schema["required"] = required
    return schema


def truncate(text: str, max_chars: int) -> str:
    """Truncate text, appending a notice if truncated.

    Args:
      text: Input text.
      max_chars: Maximum character count before truncation.

    Returns:
      result: Original text, or prefix with a truncation notice appended.

    """
    if len(text) <= max_chars:
        return text
    return (
        text[:max_chars] + f"\n... (truncated, {len(text) - max_chars} chars omitted)"
    )


def to_result(result: str | ToolResult) -> ToolResult:
    """Normalize a tool return value to a ``ToolResult``.

    Strings wrap to ``ToolResult(call_id="", content=result)`` so the
    runtime can stamp the call_id from the originating ``ToolCall``.

    Args:
      result: Plain string or existing ToolResult.

    Returns:
      result: A ``ToolResult`` with the content set.

    """
    if isinstance(result, str):
        return ToolResult(call_id="", content=result)
    return result


def opt_int(directive: Mapping[str, object], key: str) -> int | None:
    """Coerce ``directive[key]`` to int, or None if absent.

    Collapses the recurring 2-line ``_raw`` boilerplate at tool
    entrypoints where an arg is optional.

    Args:
      directive: Parsed tool directive mapping.
      key: Key to look up.

    Returns:
      value: Integer value, or None if the key is absent.

    """
    v = directive.get(key)
    return None if v is None else int_val(v, 0)


def opt_str(directive: Mapping[str, object], key: str) -> str | None:
    """Coerce ``directive[key]`` to str, or None if absent/empty.

    Args:
      directive: Parsed tool directive mapping.
      key: Key to look up.

    Returns:
      value: String value, or None if the key is absent or empty.

    """
    v = directive.get(key)
    if v is None:
        return None
    return str(v) or None


def resolve_tool_path(path: str) -> str:
    """Resolve a tool-supplied filesystem path against the agent shell cwd.

    Bash maintains ``ToolState.bash_cwd`` across ``cd`` commands. File tools
    should interpret relative paths the same way as Bash/List/Grep/Glob so a
    model does not see one cwd for shell commands and another for file edits.
    Empty paths are left empty so required-argument validation and tool-specific
    errors still surface cleanly.

    Args:
      path: Tool-supplied filesystem path (relative or absolute).

    Returns:
      resolved: Absolute path string, or empty when ``path`` is empty.

    """
    if not path:
        return ""
    p = Path(path).expanduser()
    if p.is_absolute():
        return str(p)
    return str(Path(get_tool_state().bash_cwd) / p)


async def run_sync(
    fn: Callable[..., str | ToolResult],
    **kwargs: object,
) -> ToolResult:
    """Run a sync function in a thread, returning a normalized ToolResult.

    ``fn`` may return a plain ``str`` (auto-wrapped into a
    ``ToolResult`` with empty ``call_id``) or a ``ToolResult``
    directly. Plain text content is truncated at
    ``TOOL_RESULT_MAX_CHARS``. Exceptions propagate to the caller;
    the ``_AgentTool`` wrapper or the runtime converts them to
    ``ToolResult(is_error=True)`` at the dispatch boundary.

    Usage in a tool's ``run``::

        async def run(self, args: Mapping[str, object]) -> ToolResult:
            return await run_sync(self._execute, **kwargs)

    Args:
      fn: Synchronous callable returning a string or ToolResult.
      **kwargs: Forwarded to ``fn``.

    Returns:
      result: Normalized ToolResult, content truncated if too large.

    """
    raw = await asyncio.to_thread(fn, **kwargs)
    result = to_result(raw)
    if len(result.content) > TOOL_RESULT_MAX_CHARS:
        return dataclasses.replace(
            result, content=truncate(result.content, TOOL_RESULT_MAX_CHARS)
        )
    return result


class _ToolImpl:
    """Wraps a function as a Tool implementation."""

    __slots__ = (
        "_fn",
        "_is_async",
        "_max_result_chars",
        "description",
        "directive_schema",
        "emit_tool_summary",
        "name",
        "supports_microcompaction",
        "tool_id",
    )

    def __init__(
        self,
        fn: Callable[..., object],
        *,
        name: str | None = None,
        description: str | None = None,
        schema: JSON | None = None,
        max_result_chars: int = TOOL_RESULT_MAX_CHARS,
        supports_microcompaction: bool = False,
    ) -> None:
        self._fn = fn
        self._is_async = inspect.iscoroutinefunction(fn)
        self._max_result_chars = max_result_chars
        self.name = name or getattr(fn, "__name__", "tool")
        self.tool_id = f"application/x-tool-{self.name.lower()}"
        self.description = description or fn.__doc__ or ""
        hints = get_type_hints(fn, include_extras=True)
        hints.pop("return", None)
        self.directive_schema = schema or json_freeze(_build_schema(fn, hints))
        self.supports_microcompaction = supports_microcompaction
        self.emit_tool_summary = False

    def summary(self, args: Mapping[str, object]) -> str:
        """Return a short label for this tool invocation."""
        del args
        return self.name

    def prompt(self) -> str:
        """Return supplemental prompt text for this tool."""
        return ""

    def summary_result(self, result: ToolResult) -> str | None:
        """Return no receipt for decorator-based tools by default."""
        del result
        return None

    async def run(self, args: Mapping[str, object]) -> ToolResult:
        """Invoke the wrapped function and return a ToolResult.

        The wrapped function may return ``str`` (wrapped to
        ``ToolResult(content=...)``) or ``ToolResult`` directly. Text
        content over ``max_result_chars`` is truncated. Exceptions
        propagate; the ``_AgentTool`` wrapper at the dispatch boundary
        converts them to ``is_error=True``.

        Args:
          args: Parsed directive forwarded as keyword arguments.

        Returns:
          result: Normalized ``ToolResult`` with truncated content.

        """
        kwargs = dict(args)
        if self._is_async:
            raw = cast(
                str | ToolResult,
                await cast(Callable[..., Awaitable[object]], self._fn)(**kwargs),
            )
        else:
            raw = cast(str | ToolResult, await asyncio.to_thread(self._fn, **kwargs))
        result = to_result(raw)
        if len(result.content) > self._max_result_chars:
            return dataclasses.replace(
                result, content=truncate(result.content, self._max_result_chars)
            )
        return result


@overload
def tool(
    fn: Callable[..., object],
    /,
    *,
    name: str | None = ...,
    description: str | None = ...,
    schema: JSON | None = ...,
    max_result_chars: int = ...,
    supports_microcompaction: bool = ...,
) -> _ToolImpl: ...


@overload
def tool(
    *,
    name: str | None = ...,
    description: str | None = ...,
    schema: JSON | None = ...,
    max_result_chars: int = ...,
    supports_microcompaction: bool = ...,
) -> Callable[[Callable[..., object]], _ToolImpl]: ...


def tool(
    fn: Callable[..., object] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    schema: JSON | None = None,
    max_result_chars: int = TOOL_RESULT_MAX_CHARS,
    supports_microcompaction: bool = False,
) -> _ToolImpl | Callable[[Callable[..., object]], _ToolImpl]:
    """Decorator to create a Tool from a function.

    Args:
      fn: The function to wrap (when used without arguments).
      name: Override the tool name (defaults to function name).
      description: Override description (defaults to docstring).
      schema: Override JSON schema (defaults to auto-generated).
      max_result_chars: Truncate results beyond this length.
      supports_microcompaction: Whether old results of this tool are
        eligible for microcompaction (clearing on cache-cold). Default False.

    Returns:
      tool_impl: A Tool implementation wrapping fn.

    """
    if fn is not None:
        return _ToolImpl(
            fn,
            name=name,
            description=description,
            schema=schema,
            max_result_chars=max_result_chars,
            supports_microcompaction=supports_microcompaction,
        )
    return lambda f: _ToolImpl(
        f,
        name=name,
        description=description,
        schema=schema,
        max_result_chars=max_result_chars,
        supports_microcompaction=supports_microcompaction,
    )


# Convenience functions that delegate to current state.
def mark_read(
    path: str,
    offset: int = 0,
    limit: int = 0,
    last_lines: int = 0,
    content: str = "",
    mtime: float | None = None,
) -> None:
    """Record that a file has been read.

    Args:
      path: File path (resolved internally).
      offset: Starting line offset of the read.
      limit: Maximum lines read.
      last_lines: EOF-anchored line count.
      content: Full file text for content-based staleness checks.
      mtime: Pre-read mtime, or None to stat now.

    """
    get_tool_state().mark_read(
        path,
        offset,
        limit,
        last_lines=last_lines,
        content=content,
        mtime=mtime,
    )


def has_been_read(path: str) -> bool:
    """Check if a file has been read.

    Args:
      path: File path to check.

    Returns:
      was_read: True if the file has been read in this session.

    """
    return get_tool_state().has_been_read(path)


# Process-wide registry of asyncio.Lock keyed by resolved file path.
# Mutating tools (Edit, Write, etc.) serialize their read-modify-write
# critical sections through this registry so concurrent coroutines -
# e.g. parallel subagents dispatching Edit on the same file - can't
# interleave between the staleness check and the write. Non-mutating
# Reads don't participate; parallel Reads are always safe.
#
# Same path → same lock → serialized across all mutating tools.
# Different paths → different locks → parallel.
#
# asyncio.Lock is safe because sagent runs on a single event loop; the
# lock yields the coroutine (doesn't block the loop) so other work
# continues while a mutation is in flight in the thread pool.
#
# Dict growth is unbounded across a session but each entry is tiny
# (~200 bytes); hundreds of distinct files edited per session is
# bounded-memory trivia. No cleanup needed.
_file_write_locks: dict[str, asyncio.Lock] = {}


def get_file_write_lock(path: str) -> asyncio.Lock:
    """Return the shared write lock for ``path``.

    Args:
      path: File path (resolved internally).

    Returns:
      lock: Shared asyncio.Lock for the resolved path.

    """
    # Avoid ``setdefault`` here - it eagerly constructs a new Lock on
    # every call even when the key already exists, and throws it
    # away. Edit/Write hit this on every mutation; cheap to skip.
    resolved = str(Path(path).resolve())
    lock = _file_write_locks.get(resolved)
    if lock is None:
        lock = asyncio.Lock()
        _file_write_locks[resolved] = lock
    return lock


def changed_files_context(max_diff_lines: int = 500) -> str:
    """Context provider: detect externally modified files.

    Checks all cached files against disk mtime. For each
    changed file, generates a system-reminder with a unified
    diff snippet (capped at ``max_diff_lines``).

    Wire this into Agent via ``context_providers``::

        Agent(context_providers=[changed_files_context])

    Args:
      max_diff_lines: Per-file truncation threshold for the diff
          snippet.

    Returns:
      context: System reminder text, or empty string if
          no files changed.

    """
    changes = get_tool_state().consume_changed_files()
    if not changes:
        return ""
    parts: list[str] = []
    for path, raw_diff in changes.items():
        diff_lines = raw_diff.splitlines(keepends=True)
        snippet = (
            "".join(diff_lines[:max_diff_lines]) + "\n... (truncated)"
            if len(diff_lines) > max_diff_lines
            else raw_diff
        )
        parts.append(
            f"Note: {path} was modified, either by the user, a"
            f" linter, or another agent. This change was intentional,"
            f" so make sure to take it into account as you proceed"
            f" (ie. don't revert it unless the user asks you to)."
            f" Don't tell the user this, since they are already"
            f" aware. Here are the relevant changes (shown with"
            f" line numbers):\n{snippet}",
        )
    return "<system-reminder>\n" + "\n".join(parts) + "\n</system-reminder>"


__all__ = (
    "TOOL_RESULT_MAX_CHARS",
    "AgentLike",
    "ReadCacheEntry",
    "ToolState",
    "agent_counter_var",
    "agent_label_var",
    "agent_path_var",
    "agent_registry",
    "changed_files_context",
    "cost_root_var",
    "current_agent_var",
    "get_file_write_lock",
    "get_tool_state",
    "has_been_read",
    "load_tool_description",
    "mark_read",
    "max_depth_var",
    "opt_int",
    "opt_str",
    "set_recipe",
    "to_result",
    "tool",
    "tool_state_context",
    "tool_state_var",
    "truncate",
)
