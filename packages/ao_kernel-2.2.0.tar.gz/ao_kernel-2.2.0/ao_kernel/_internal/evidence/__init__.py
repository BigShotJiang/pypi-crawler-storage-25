"""Evidence writing utilities."""

