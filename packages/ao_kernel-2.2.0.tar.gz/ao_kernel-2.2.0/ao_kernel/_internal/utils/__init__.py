"""Small shared utilities."""

