from taipan_logger import taipan, configure, trace


configure(special_prefix="SORA SAYS: ", datetime_format="xxYYxxMMxxDD == hh:mm:ss:mimimi", debug=True)

@trace
def maxmix(**kwargs):
    for k in kwargs:
        print(kwargs)
@trace
def fun_call():
    print("hdjwjawdjw")
    x= 563+ 2266
    maxmix(x=13, y=1567,a=26262, poof="dhhdhdh", mool=False)



taipan.info("Oh no im in a module level")
if __name__ == '__main__':
    fun_call()