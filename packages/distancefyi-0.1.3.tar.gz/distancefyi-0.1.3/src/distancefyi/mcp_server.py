"""MCP server for distancefyi — distance and travel time tools for AI assistants.

Run: uvx --from "distancefyi[mcp]" python -m distancefyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("distancefyi")


@mcp.tool()
def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> str:
    """Calculate great-circle distance and travel estimates between two coordinates.

    Args:
        lat1: Latitude of the first point (decimal degrees).
        lon1: Longitude of the first point (decimal degrees).
        lat2: Latitude of the second point (decimal degrees).
        lon2: Longitude of the second point (decimal degrees).
    """
    from distancefyi import (
        bearing,
        compass_direction,
        compute_distance,
        format_distance,
        format_duration,
    )

    result = compute_distance(lat1, lon1, lat2, lon2)
    bear = bearing(lat1, lon1, lat2, lon2)
    direction = compass_direction(bear)

    lines = [
        f"## Distance: {format_distance(result.distance_km)}",
        "",
        "| Property | Value |",
        "|----------|-------|",
        f"| Distance | {result.distance_km:,} km ({result.distance_miles:,} mi) |",
        f"| Bearing | {bear:.1f}° ({direction}) |",
        f"| Flight Time | ~{format_duration(result.flight_minutes)} |",
        f"| Drive Time | ~{format_duration(result.drive_minutes)} |",
    ]
    return "\n".join(lines)


@mcp.tool()
def find_midpoint(lat1: float, lon1: float, lat2: float, lon2: float) -> str:
    """Find the geographic midpoint between two coordinates.

    Args:
        lat1: Latitude of the first point.
        lon1: Longitude of the first point.
        lat2: Latitude of the second point.
        lon2: Longitude of the second point.
    """
    from distancefyi import midpoint

    mid_lat, mid_lon = midpoint(lat1, lon1, lat2, lon2)
    return f"Midpoint: **{mid_lat:.4f}°, {mid_lon:.4f}°**"


@mcp.tool()
def antipodal(lat: float, lon: float) -> str:
    """Find the antipodal (diametrically opposite) point on Earth.

    Args:
        lat: Latitude in decimal degrees.
        lon: Longitude in decimal degrees.
    """
    from distancefyi import antipodal_point

    a_lat, a_lon = antipodal_point(lat, lon)
    return f"Antipodal point of ({lat:.4f}°, {lon:.4f}°): **{a_lat:.4f}°, {a_lon:.4f}°**"


@mcp.tool()
def convert_distance(km: int) -> str:
    """Convert kilometers to miles and nautical miles.

    Args:
        km: Distance in kilometers.
    """
    from distancefyi import km_to_miles, km_to_nautical_miles

    miles = km_to_miles(km)
    nm = km_to_nautical_miles(km)
    return f"{km:,} km = **{miles:,} miles** = **{nm:,} nautical miles**"


@mcp.tool()
def search_cities(query: str) -> str:
    """Search distancefyi.com for cities and countries.

    Args:
        query: Search query (city or country name).
    """
    from distancefyi.api import DistanceFYI

    with DistanceFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
