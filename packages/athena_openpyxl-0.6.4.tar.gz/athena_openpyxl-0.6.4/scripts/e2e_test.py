"""End-to-end smoke test: SDK → local apps/api → staging Keryx.

Exercises the new architecture:
  athena-openpyxl (Python)
    -> POST http://localhost:3000/workbooks/{asset_id}/commands?orgId={workspace_id}
    -> apps/api builds a Spreadsheet over the Y.Doc, applies SetCellValue,
       generates patches, pushes via y-websocket to keryx-staging.
    -> Read the snapshot back and verify A2 == "Hello world".
"""

from __future__ import annotations

import os
import sys

from openpyxl import Workbook
from openpyxl.commands import SetCellValue

ASSET_ID = "asset_3a9328bc-9c1c-4498-be8f-bda3883276f5"
WORKSPACE_ID = "workspace_9ec609ea-ee1a-48b6-9e61-d73d9dfbb651"
BASE_URL = os.environ.get("ATHENA_XLSX_BASE_URL", "http://localhost:3000")


def main() -> int:
    print(f"Opening workbook {ASSET_ID} via {BASE_URL} (workspace={WORKSPACE_ID})")

    wb = Workbook(workbook_id=ASSET_ID, base_url=BASE_URL, org_id=WORKSPACE_ID)
    print(f"  loaded snapshot: sheets={wb.sheetnames}")

    if not wb.sheetnames:
        print("  no sheets returned from snapshot")
        return 1
    sheet = wb.active
    sheet_index = sheet._index
    print(f"  active sheet: index={sheet_index}, title={sheet.title}")

    # Set A2 = "Hello world" via the explicit command path so we can see what
    # we're sending. (sheet["A2"] = "Hello world" goes through the buffer too.)
    cmd = SetCellValue(
        sheet_index=sheet_index,
        row=2,
        col=1,
        value="Hello world",
        cell_type="string",
    )
    print(f"  sending: {cmd.to_dict()}")

    resp = wb._client.post_commands(
        workbook_id=ASSET_ID,
        commands=[cmd],
        return_snapshot=True,
        org_id=WORKSPACE_ID,
    )
    print(f"  applied={resp.get('applied')}")
    if not resp.get("applied"):
        print(f"  FAILED: {resp}")
        return 2

    # Verify
    snap = wb._client.get_snapshot(ASSET_ID, org_id=WORKSPACE_ID)
    target = next((s for s in snap.sheets if s.index == sheet_index), None)
    if target is None:
        print("  could not locate target sheet in snapshot")
        return 3
    a2 = target.cells.get("A2")
    print(f"  read back A2: {a2}")
    if a2 is None or a2.value != "Hello world":
        print("  MISMATCH: expected A2='Hello world'")
        return 4

    print("  OK — A2 round-tripped through apps/api → keryx-staging")
    return 0


if __name__ == "__main__":
    sys.exit(main())
