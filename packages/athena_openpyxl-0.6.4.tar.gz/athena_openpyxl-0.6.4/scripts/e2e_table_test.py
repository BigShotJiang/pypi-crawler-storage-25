"""E2E parity test: agent's exact table-creation code path.

Mirrors the failing input from the agent — uses stock openpyxl import
paths (`openpyxl.worksheet.table`, `openpyxl.styles`) to verify the
re-export shims work end-to-end through the local apps/api.
"""

from __future__ import annotations

import os
import sys

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo

BASE_URL = os.environ.get("ATHENA_XLSX_BASE_URL", "http://localhost:3000")


def main() -> int:
    # Use a fresh wb_* workbook (skips agora ownership check, so no
    # auth token needed). The Y.Doc shape is identical to asset_*.
    print(f"Creating fresh workbook via {BASE_URL}")
    wb = Workbook.create(name="stock-paths-e2e", base_url=BASE_URL)
    print(f"  workbook_id={wb.workbook_id}, sheets={wb.sheetnames}")
    print(f"  loaded snapshot: sheets={wb.sheetnames}")

    sheet_name = "Dummy Data E2E"
    if sheet_name in wb.sheetnames:
        del wb[sheet_name]
    ws = wb.create_sheet(title=sheet_name)
    print(f"  created sheet: {sheet_name}")

    rows = [
        ["ID", "Customer", "Region", "Product", "Quantity", "Unit Price", "Revenue", "Status"],
        [1001, "Acme Corp", "North", "Widget A", 12, 19.99, 239.88, "Open"],
        [1002, "Beta Ltd", "South", "Widget B", 8, 24.50, 196.00, "Closed"],
        [1003, "Cobalt Inc", "East", "Service Plan", 15, 9.99, 149.85, "Open"],
        [1004, "Delta LLC", "West", "Widget A", 20, 19.99, 399.80, "Pending"],
    ]
    for row in rows:
        ws.append(row)
    print(f"  appended {len(rows)} rows")

    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(fill_type="solid", fgColor="365BB7")

    ws.freeze_panes = "A2"

    for row in range(2, ws.max_row + 1):
        ws[f"G{row}"] = f"=E{row}*F{row}"

    ref = f"A1:H{ws.max_row}"
    table = Table(displayName="DummyTableE2E", ref=ref)
    style = TableStyleInfo(
        name="TableStyleMedium9",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    table.tableStyleInfo = style
    ws.add_table(table)
    print(f"  added table {table.displayName} ({ref})")

    widths = {"A": 10, "B": 18, "C": 12, "D": 16, "E": 10, "F": 12, "G": 12, "H": 12}
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    wb.close()
    print("  OK — full agent-style table creation round-tripped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
