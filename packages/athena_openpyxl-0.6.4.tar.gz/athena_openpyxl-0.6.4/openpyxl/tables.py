"""
Table classes — openpyxl.worksheet.table parity surface.

These mirror openpyxl's Table / TableColumn / TableStyleInfo and
serialize to the @rowsncolumns/spreadsheet TableView shape that
the spreadsheet-state engine consumes via createTable / updateTable.
"""

from __future__ import annotations

from typing import Any

from .errors import ValidationError
from .utils import column_index_from_string, parse_range


class TableStyleInfo:
    """Style info for a table.

    Mirrors openpyxl.worksheet.table.TableStyleInfo.
    """

    def __init__(
        self,
        name: str | None = None,
        showFirstColumn: bool = False,
        showLastColumn: bool = False,
        showRowStripes: bool = True,
        showColumnStripes: bool = False,
    ):
        self.name = name
        self.showFirstColumn = showFirstColumn
        self.showLastColumn = showLastColumn
        self.showRowStripes = showRowStripes
        self.showColumnStripes = showColumnStripes


class TableColumn:
    """A single column in a Table.

    Mirrors openpyxl.worksheet.table.TableColumn.
    """

    def __init__(
        self,
        id: int | None = None,
        name: str | None = None,
        totalsRowLabel: str | None = None,
        totalsRowFunction: str | None = None,
    ):
        self.id = id
        self.name = name
        self.totalsRowLabel = totalsRowLabel
        self.totalsRowFunction = totalsRowFunction


class Table:
    """An Excel table with structured references.

    Mirrors openpyxl.worksheet.table.Table.

    Args:
        displayName: Name shown in the Excel UI; must be unique within the workbook.
        ref: Range covered by the table, e.g. ``"A1:D10"``.
        name: Internal name (defaults to ``displayName``).
        headerRowCount: Number of header rows (0 or 1; default 1).
        totalsRowCount: Number of totals rows (0 or 1; default 0).
        tableStyleInfo: Optional ``TableStyleInfo`` controlling banding/highlights.
        tableColumns: Optional list of ``TableColumn`` objects (auto-derived if absent).
        id: Optional explicit numeric id; otherwise the engine assigns one.
    """

    def __init__(
        self,
        displayName: str,
        ref: str,
        name: str | None = None,
        headerRowCount: int = 1,
        totalsRowCount: int = 0,
        tableStyleInfo: TableStyleInfo | None = None,
        tableColumns: list[TableColumn] | None = None,
        id: int | None = None,
    ):
        if not displayName:
            raise ValidationError("displayName is required", "displayName")
        if headerRowCount not in (0, 1):
            raise ValidationError("headerRowCount must be 0 or 1", "headerRowCount")
        if totalsRowCount not in (0, 1):
            raise ValidationError("totalsRowCount must be 0 or 1", "totalsRowCount")

        self.displayName = displayName
        self.name = name or displayName
        self.ref = ref
        self.headerRowCount = headerRowCount
        self.totalsRowCount = totalsRowCount
        self.tableStyleInfo = tableStyleInfo or TableStyleInfo()
        self.tableColumns: list[TableColumn] = tableColumns or []
        self.id = id

    def to_table_view(self, sheet_id: int) -> dict[str, Any]:
        """Serialize to a TableView dict compatible with @rowsncolumns/spreadsheet.

        Indices follow the existing applier convention (1-based input → -1 each
        side; matches the MergeCells handler).
        """
        start_row, start_col, end_row, end_col = parse_range(self.ref)

        columns: list[dict[str, Any]] = []
        for tc in self.tableColumns:
            col_dict: dict[str, Any] = {"name": tc.name or ""}
            columns.append(col_dict)

        view: dict[str, Any] = {
            "id": self.id if self.id is not None else self.displayName,
            "title": self.displayName,
            "sheetId": sheet_id,
            # rowsncolumns table ranges are 1-based inclusive (A1 → 1,1).
            # The previous `- 1` produced 0-based output that caused tables
            # to register at off-by-one positions in the engine.
            "range": {
                "startRowIndex": start_row,
                "endRowIndex": end_row,
                "startColumnIndex": start_col,
                "endColumnIndex": end_col,
            },
            "headerRow": self.headerRowCount > 0,
            "totalRow": self.totalsRowCount > 0,
            "showFirstColumn": self.tableStyleInfo.showFirstColumn,
            "showLastColumn": self.tableStyleInfo.showLastColumn,
            "showRowStripes": self.tableStyleInfo.showRowStripes,
            "showColumnStripes": self.tableStyleInfo.showColumnStripes,
        }
        if self.tableStyleInfo.name is not None:
            view["theme"] = {"name": self.tableStyleInfo.name}
        if columns:
            view["columns"] = columns
        return view

    @classmethod
    def from_table_view(cls, view: dict[str, Any]) -> Table:
        """Reconstruct a ``Table`` from a TableView dict pulled out of a snapshot.

        TableView ranges are stored 1-based, inclusive (matches rowsncolumns
        canonical addressToSelection). Pass through to the A1 ref builder
        unchanged. The previous `+ 1` here was compensating for a now-fixed
        bug in `to_table_view` that incorrectly emitted 0-based ranges.
        """
        rng = view.get("range") or {}
        start_row = int(rng.get("startRowIndex", 1))
        end_row = int(rng.get("endRowIndex", 1))
        start_col = int(rng.get("startColumnIndex", 1))
        end_col = int(rng.get("endColumnIndex", 1))
        ref = f"{_col_letter(start_col)}{start_row}:{_col_letter(end_col)}{end_row}"

        theme = view.get("theme") or {}
        style = TableStyleInfo(
            name=theme.get("name") if isinstance(theme, dict) else None,
            showFirstColumn=bool(view.get("showFirstColumn") or False),
            showLastColumn=bool(view.get("showLastColumn") or False),
            showRowStripes=bool(view.get("showRowStripes", True)),
            showColumnStripes=bool(view.get("showColumnStripes") or False),
        )

        cols: list[TableColumn] = []
        for raw_col in view.get("columns") or []:
            if isinstance(raw_col, dict):
                cols.append(TableColumn(name=raw_col.get("name")))

        title = view.get("title") or "Table"
        return cls(
            displayName=title,
            ref=ref,
            name=title,
            headerRowCount=1 if view.get("headerRow") else 0,
            totalsRowCount=1 if view.get("totalRow") else 0,
            tableStyleInfo=style,
            tableColumns=cols,
            id=view.get("id"),
        )

    def __repr__(self) -> str:
        return f"<Table displayName={self.displayName!r} ref={self.ref!r}>"


def _col_letter(col: int) -> str:
    # Local mirror of utils.get_column_letter to avoid a back-import cycle.
    result = ""
    n = col
    while n > 0:
        n, rem = divmod(n - 1, 26)
        result = chr(65 + rem) + result
    return result


# Force `column_index_from_string` to stay imported (used indirectly via parse_range)
_ = column_index_from_string
