"""Stock-openpyxl-compatible re-export package.

Stock openpyxl exposes conditional-formatting rule classes at
``openpyxl.formatting.rule``; the SDK's canonical implementation lives at
``openpyxl.conditional_formatting``. This package re-exports them at the
stock path.
"""

from __future__ import annotations

from ..conditional_formatting import (
    CellIsRule,
    ColorScaleRule,
    ConditionalFormattingList,
    DataBarRule,
    DuplicateRule,
    FormulaRule,
    IconSetRule,
    TopRule,
    UniqueRule,
)

__all__ = [
    "CellIsRule",
    "ColorScaleRule",
    "ConditionalFormattingList",
    "DataBarRule",
    "DuplicateRule",
    "FormulaRule",
    "IconSetRule",
    "TopRule",
    "UniqueRule",
]
