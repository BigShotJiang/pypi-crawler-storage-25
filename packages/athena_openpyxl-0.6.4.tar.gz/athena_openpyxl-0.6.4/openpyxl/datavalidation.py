"""
Data validation classes — openpyxl.worksheet.datavalidation parity.

DataValidation rules are serialized to the
``DataValidationRuleRecord`` shape consumed by
``@rowsncolumns/spreadsheet-state``'s ``createDataValidationRule``.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from .errors import UnsupportedFeatureError, ValidationError
from .utils import parse_range

# Map openpyxl (type, operator) → engine ConditionType.
# Engine ConditionType list lives in @rowsncolumns/common-types.
_OPERATOR_NUMBER = {
    "between": "NUMBER_BETWEEN",
    "notBetween": "NUMBER_NOT_BETWEEN",
    "lessThan": "NUMBER_LESS",
    "lessThanOrEqual": "NUMBER_LESS_THAN_EQ",
    "greaterThan": "NUMBER_GREATER",
    "greaterThanOrEqual": "NUMBER_GREATER_THAN_EQ",
    "equal": "NUMBER_EQ",
    "notEqual": "NUMBER_NOT_EQ",
}
_OPERATOR_DATE = {
    "between": "DATE_BETWEEN",
    "notBetween": "DATE_NOT_BETWEEN",
    "lessThan": "DATE_BEFORE",
    "lessThanOrEqual": "DATE_ON_OR_BEFORE",
    "greaterThan": "DATE_AFTER",
    "greaterThanOrEqual": "DATE_ON_OR_AFTER",
    "equal": "DATE_EQ",
    "notEqual": "DATE_NOT_EQ",
}
_OPERATOR_TEXT = {
    "equal": "TEXT_EQ",
    "notEqual": "TEXT_NOT_EQ",
}

# Condition types where userEnteredValue is a raw value (engine adds formula
# quoting via normalizeConditionValue). ONE_OF_LIST / ONE_OF_RANGE pass through
# the openpyxl idiom verbatim; CUSTOM_FORMULA is a full expression.
_TYPED_VALUE_CONDITIONS = frozenset(
    {
        *_OPERATOR_NUMBER.values(),
        *_OPERATOR_DATE.values(),
        *_OPERATOR_TEXT.values(),
    }
)


def _unquote_string_literal(formula_expr: str) -> str:
    # openpyxl's formula1/formula2 follow Excel formula grammar (string
    # literals quoted as `"foo"`, `""` as escaped `"`). The rnc engine's
    # `userEnteredValue` is the raw value for typed conditions —
    # `normalizeConditionValue` re-quotes when building the formula, so
    # pass-through would double-quote.
    s = formula_expr.strip()
    if len(s) >= 2 and s.startswith('"') and s.endswith('"'):
        return s[1:-1].replace('""', '"')
    return formula_expr


class DataValidation:
    """A data validation rule on a worksheet range.

    Mirrors openpyxl.worksheet.datavalidation.DataValidation.
    """

    def __init__(
        self,
        type: str | None = None,
        operator: str | None = None,
        formula1: str | None = None,
        formula2: str | None = None,
        allow_blank: bool = False,
        showDropDown: bool = False,
        showErrorMessage: bool = True,
        errorTitle: str | None = None,
        error: str | None = None,
        errorStyle: str | None = None,
        showInputMessage: bool = True,
        promptTitle: str | None = None,
        prompt: str | None = None,
        sqref: str | None = None,
    ):
        self.type = type
        self.operator = operator
        self.formula1 = formula1
        self.formula2 = formula2
        self.allow_blank = allow_blank
        self.showDropDown = showDropDown
        self.showErrorMessage = showErrorMessage
        self.errorTitle = errorTitle
        self.error = error
        self.errorStyle = errorStyle
        self.showInputMessage = showInputMessage
        self.promptTitle = promptTitle
        self.prompt = prompt
        self.ranges: list[str] = []
        if sqref:
            for token in str(sqref).split():
                self.ranges.append(token)

    @property
    def sqref(self) -> str:
        """Space-separated string of all ranges this rule covers."""
        return " ".join(self.ranges)

    @sqref.setter
    def sqref(self, value: str) -> None:
        self.ranges = [tok for tok in str(value).split() if tok]

    def add(self, range_string: str) -> None:
        """Add a range string to the rule."""
        self.ranges.append(range_string)

    def to_engine_record(self, sheet_id: int, rule_id: str | int) -> dict[str, Any]:
        """Serialize to a ``DataValidationRuleRecord`` for the engine."""
        condition_type = self._resolve_condition_type()
        unquote = condition_type in _TYPED_VALUE_CONDITIONS
        values: list[dict[str, str]] = []
        if self.formula1 is not None:
            raw1 = str(self.formula1)
            values.append({"userEnteredValue": _unquote_string_literal(raw1) if unquote else raw1})
        if self.formula2 is not None:
            raw2 = str(self.formula2)
            values.append({"userEnteredValue": _unquote_string_literal(raw2) if unquote else raw2})

        record: dict[str, Any] = {
            "id": rule_id,
            "ranges": [_ref_to_grid_range(r, sheet_id) for r in self.ranges],
            "allowBlank": self.allow_blank,
        }
        if condition_type or values:
            record["condition"] = {}
            if condition_type:
                record["condition"]["type"] = condition_type
            if values:
                record["condition"]["values"] = values

        if self.showInputMessage and (self.prompt or self.promptTitle):
            record["inputMessage"] = {
                "title": self.promptTitle,
                "message": self.prompt,
            }
        if self.showErrorMessage and (self.error or self.errorTitle):
            style = self.errorStyle or "stop"
            record["alert"] = {
                "style": style,
                "message": {"title": self.errorTitle, "message": self.error},
            }
        return record

    def _resolve_condition_type(self) -> str | None:
        """Map openpyxl (type, operator) → engine ConditionType."""
        t = (self.type or "").lower()
        op = self.operator or ""
        if t == "list":
            f = self.formula1 or ""
            # "$A$1:$A$5" looks like a range; otherwise treat as comma list
            if "!" in f or ":" in f or f.startswith("="):
                return "ONE_OF_RANGE"
            return "ONE_OF_LIST"
        if t in ("whole", "decimal"):
            mapped = _OPERATOR_NUMBER.get(op)
            if mapped is None:
                raise UnsupportedFeatureError(
                    f"Operator {op!r} is not supported for numeric data validation"
                )
            return mapped
        if t == "date":
            mapped = _OPERATOR_DATE.get(op)
            if mapped is None:
                raise UnsupportedFeatureError(
                    f"Operator {op!r} is not supported for date data validation"
                )
            return mapped
        if t == "textlength":
            mapped = _OPERATOR_NUMBER.get(op)
            if mapped is None:
                raise UnsupportedFeatureError(
                    f"Operator {op!r} is not supported for textLength data validation"
                )
            return mapped
        if t == "custom":
            return "CUSTOM_FORMULA"
        if t == "":
            return None
        raise UnsupportedFeatureError(f"DataValidation type {self.type!r} not supported")


class DataValidationList:
    """Container exposed as ``ws.data_validations``.

    Mirrors openpyxl's container shape.
    """

    def __init__(self) -> None:
        self.dataValidation: list[DataValidation] = []

    def append(self, dv: DataValidation) -> None:
        if not isinstance(dv, DataValidation):
            raise TypeError(
                f"DataValidationList.append expects a DataValidation, got {type(dv).__name__}"
            )
        self.dataValidation.append(dv)

    def __iter__(self) -> Iterator[DataValidation]:
        return iter(self.dataValidation)

    def __len__(self) -> int:
        return len(self.dataValidation)


def _ref_to_grid_range(ref: str, sheet_id: int) -> dict[str, Any]:
    """Convert ``"A1:C3"`` → engine ``SheetRange``.

    Returns 1-based, inclusive indices to match rowsncolumns' canonical
    `addressToSelection` (A1 → startRowIndex=1, startColumnIndex=1). The
    previous `- 1` here produced 0-based output, which silently caused
    DV rules to never fire in the renderer.
    """
    start_row, start_col, end_row, end_col = parse_range(ref)
    return {
        "sheetId": sheet_id,
        "startRowIndex": start_row,
        "endRowIndex": end_row,
        "startColumnIndex": start_col,
        "endColumnIndex": end_col,
    }


# Marker import to keep ValidationError reachable for downstream typing
_ = ValidationError
