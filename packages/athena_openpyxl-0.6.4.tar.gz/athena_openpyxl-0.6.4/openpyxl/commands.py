"""
Command dataclasses for the XLSX SDK.

Commands represent atomic operations that are sent to the server.
They are validated client-side before transmission.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .errors import ValidationError
from .typing import CellStyle


@dataclass
class Command:
    """Base class for all commands."""

    def to_dict(self) -> dict[str, Any]:
        """Convert command to dictionary for JSON serialization."""
        result = {"type": self.command_type}
        for key, value in asdict(self).items():
            if value is not None and key != "command_type":
                camel_key = self._to_camel_case(key)
                result[camel_key] = value
        return result

    @staticmethod
    def _to_camel_case(snake_str: str) -> str:
        components = snake_str.split("_")
        return components[0] + "".join(x.title() for x in components[1:])

    def validate(self) -> None:
        """Validate command parameters. Raises ValidationError if invalid."""
        pass

    @property
    def command_type(self) -> str:
        """Return the command type string."""
        raise NotImplementedError


# -------------------------------------------------------------------------
# Cell Operations
# -------------------------------------------------------------------------


@dataclass
class SetCellValue(Command):
    """
    Set the value of a cell.

    Args:
        sheet_index: Zero-based index of the sheet
        row: 1-based row number
        col: 1-based column number
        value: Cell value (string, number, boolean, or None)
        cell_type: Optional explicit type hint ('string', 'number', 'boolean', 'date')
    """

    sheet_index: int
    row: int
    col: int
    value: Any
    cell_type: str | None = None

    @property
    def command_type(self) -> str:
        return "SetCellValue"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.row < 1:
            raise ValidationError("row must be >= 1", "row")
        if self.col < 1:
            raise ValidationError("col must be >= 1", "col")


@dataclass
class SetCellFormula(Command):
    """
    Set a formula on a cell.

    Args:
        sheet_index: Zero-based index of the sheet
        row: 1-based row number
        col: 1-based column number
        formula: Formula string (e.g., '=SUM(A1:A10)')
    """

    sheet_index: int
    row: int
    col: int
    formula: str

    @property
    def command_type(self) -> str:
        return "SetCellFormula"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.row < 1:
            raise ValidationError("row must be >= 1", "row")
        if self.col < 1:
            raise ValidationError("col must be >= 1", "col")
        if not self.formula:
            raise ValidationError("formula is required", "formula")


@dataclass
class SetCellStyle(Command):
    """
    Set styling for a cell.

    Args:
        sheet_index: Zero-based index of the sheet
        row: 1-based row number
        col: 1-based column number
        style: Style properties to set
    """

    sheet_index: int
    row: int
    col: int
    style: CellStyle

    @property
    def command_type(self) -> str:
        return "SetCellStyle"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.row < 1:
            raise ValidationError("row must be >= 1", "row")
        if self.col < 1:
            raise ValidationError("col must be >= 1", "col")


@dataclass
class SetRangeValues(Command):
    """
    Set values for a rectangular range of cells (batch operation).

    Args:
        sheet_index: Zero-based index of the sheet
        start_row: 1-based starting row
        start_col: 1-based starting column
        values: 2D list of values (rows x cols)
    """

    sheet_index: int
    start_row: int
    start_col: int
    values: list[list[Any]]

    @property
    def command_type(self) -> str:
        return "SetRangeValues"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.start_row < 1:
            raise ValidationError("start_row must be >= 1", "start_row")
        if self.start_col < 1:
            raise ValidationError("start_col must be >= 1", "start_col")
        if not self.values:
            raise ValidationError("values must not be empty", "values")


# -------------------------------------------------------------------------
# Sheet Operations
# -------------------------------------------------------------------------


@dataclass
class AddSheet(Command):
    """
    Add a new worksheet to the workbook.

    Args:
        name: Name for the new sheet
        index: Position to insert (optional, defaults to end)
    """

    name: str | None = None
    index: int | None = None

    @property
    def command_type(self) -> str:
        return "AddSheet"

    def validate(self) -> None:
        if self.index is not None and self.index < 0:
            raise ValidationError("index must be non-negative", "index")


@dataclass
class DeleteSheet(Command):
    """
    Delete a worksheet from the workbook.

    Args:
        sheet_index: Zero-based index of the sheet to delete
    """

    sheet_index: int

    @property
    def command_type(self) -> str:
        return "DeleteSheet"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")


@dataclass
class RenameSheet(Command):
    """
    Rename a worksheet.

    Args:
        sheet_index: Zero-based index of the sheet
        name: New name for the sheet
    """

    sheet_index: int
    name: str

    @property
    def command_type(self) -> str:
        return "RenameSheet"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if not self.name:
            raise ValidationError("name is required", "name")
        if len(self.name) > 31:
            raise ValidationError("sheet name must be <= 31 characters", "name")


@dataclass
class ReorderSheets(Command):
    """
    Reorder worksheets in the workbook.

    Args:
        new_order: List of sheet indices in the new order
    """

    new_order: list[int]

    @property
    def command_type(self) -> str:
        return "ReorderSheets"

    def validate(self) -> None:
        if not self.new_order:
            raise ValidationError("new_order must not be empty", "new_order")


@dataclass
class CloneSheet(Command):
    """
    Clone a worksheet with all its content.

    Args:
        source_index: Zero-based index of the sheet to clone
        name: Name for the cloned sheet (optional)
    """

    source_index: int
    name: str | None = None

    @property
    def command_type(self) -> str:
        return "CloneSheet"

    def validate(self) -> None:
        if self.source_index < 0:
            raise ValidationError("source_index must be non-negative", "source_index")


# -------------------------------------------------------------------------
# Row/Column Operations
# -------------------------------------------------------------------------


@dataclass
class SetColumnWidth(Command):
    """
    Set the width of a column.

    Args:
        sheet_index: Zero-based index of the sheet
        col: 1-based column number
        width: Column width in character units (Excel default ~8.43)
    """

    sheet_index: int
    col: int
    width: float

    @property
    def command_type(self) -> str:
        return "SetColumnWidth"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.col < 1:
            raise ValidationError("col must be >= 1", "col")
        if self.width < 0:
            raise ValidationError("width must be non-negative", "width")


@dataclass
class SetRowHeight(Command):
    """
    Set the height of a row.

    Args:
        sheet_index: Zero-based index of the sheet
        row: 1-based row number
        height: Row height in points
    """

    sheet_index: int
    row: int
    height: float

    @property
    def command_type(self) -> str:
        return "SetRowHeight"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.row < 1:
            raise ValidationError("row must be >= 1", "row")
        if self.height < 0:
            raise ValidationError("height must be non-negative", "height")


@dataclass
class InsertRows(Command):
    """
    Insert rows into a sheet.

    Args:
        sheet_index: Zero-based index of the sheet
        row: 1-based row number where rows will be inserted before
        count: Number of rows to insert
    """

    sheet_index: int
    row: int
    count: int = 1

    @property
    def command_type(self) -> str:
        return "InsertRows"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.row < 1:
            raise ValidationError("row must be >= 1", "row")
        if self.count < 1:
            raise ValidationError("count must be >= 1", "count")


@dataclass
class InsertColumns(Command):
    """
    Insert columns into a sheet.

    Args:
        sheet_index: Zero-based index of the sheet
        col: 1-based column number where columns will be inserted before
        count: Number of columns to insert
    """

    sheet_index: int
    col: int
    count: int = 1

    @property
    def command_type(self) -> str:
        return "InsertColumns"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.col < 1:
            raise ValidationError("col must be >= 1", "col")
        if self.count < 1:
            raise ValidationError("count must be >= 1", "count")


@dataclass
class DeleteRows(Command):
    """
    Delete rows from a sheet.

    Args:
        sheet_index: Zero-based index of the sheet
        row: 1-based starting row number
        count: Number of rows to delete
    """

    sheet_index: int
    row: int
    count: int = 1

    @property
    def command_type(self) -> str:
        return "DeleteRows"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.row < 1:
            raise ValidationError("row must be >= 1", "row")
        if self.count < 1:
            raise ValidationError("count must be >= 1", "count")


@dataclass
class DeleteColumns(Command):
    """
    Delete columns from a sheet.

    Args:
        sheet_index: Zero-based index of the sheet
        col: 1-based starting column number
        count: Number of columns to delete
    """

    sheet_index: int
    col: int
    count: int = 1

    @property
    def command_type(self) -> str:
        return "DeleteColumns"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.col < 1:
            raise ValidationError("col must be >= 1", "col")
        if self.count < 1:
            raise ValidationError("count must be >= 1", "count")


# -------------------------------------------------------------------------
# Merge Operations
# -------------------------------------------------------------------------


@dataclass
class MergeCells(Command):
    """
    Merge a range of cells.

    Args:
        sheet_index: Zero-based index of the sheet
        start_row: 1-based starting row
        start_col: 1-based starting column
        end_row: 1-based ending row
        end_col: 1-based ending column
    """

    sheet_index: int
    start_row: int
    start_col: int
    end_row: int
    end_col: int

    @property
    def command_type(self) -> str:
        return "MergeCells"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.start_row < 1 or self.start_col < 1:
            raise ValidationError("start_row and start_col must be >= 1", "range")
        if self.end_row < self.start_row:
            raise ValidationError("end_row must be >= start_row", "end_row")
        if self.end_col < self.start_col:
            raise ValidationError("end_col must be >= start_col", "end_col")


@dataclass
class UnmergeCells(Command):
    """
    Unmerge a previously merged range.

    Args:
        sheet_index: Zero-based index of the sheet
        start_row: 1-based starting row
        start_col: 1-based starting column
        end_row: 1-based ending row
        end_col: 1-based ending column
    """

    sheet_index: int
    start_row: int
    start_col: int
    end_row: int
    end_col: int

    @property
    def command_type(self) -> str:
        return "UnmergeCells"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")


# -------------------------------------------------------------------------
# Sheet Properties
# -------------------------------------------------------------------------


@dataclass
class SetSheetProperties(Command):
    """
    Set sheet-level properties.

    Args:
        sheet_index: Zero-based index of the sheet
        frozen_rows: Number of frozen rows (0 to unfreeze)
        frozen_cols: Number of frozen columns (0 to unfreeze)
        hidden: Whether the sheet is hidden
        tab_color: Tab color as 6-character hex string
    """

    sheet_index: int
    frozen_rows: int | None = None
    frozen_cols: int | None = None
    hidden: bool | None = None
    tab_color: str | None = None

    @property
    def command_type(self) -> str:
        return "SetSheetProperties"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.frozen_rows is not None and self.frozen_rows < 0:
            raise ValidationError("frozen_rows must be non-negative", "frozen_rows")
        if self.frozen_cols is not None and self.frozen_cols < 0:
            raise ValidationError("frozen_cols must be non-negative", "frozen_cols")


# -------------------------------------------------------------------------
# Workbook Properties
# -------------------------------------------------------------------------


@dataclass
class SetWorkbookProperties(Command):
    """
    Set workbook-level properties (metadata).

    Args:
        title: Document title
        author: Document author
        subject: Document subject
        keywords: Document keywords
        description: Document description
    """

    title: str | None = None
    author: str | None = None
    subject: str | None = None
    keywords: str | None = None
    description: str | None = None

    @property
    def command_type(self) -> str:
        return "SetWorkbookProperties"

    def validate(self) -> None:
        if all(
            v is None
            for v in [
                self.title,
                self.author,
                self.subject,
                self.keywords,
                self.description,
            ]
        ):
            raise ValidationError("At least one property must be set", "properties")


# -------------------------------------------------------------------------
# Auto-filter & Sorting
# -------------------------------------------------------------------------


@dataclass
class SetAutoFilter(Command):
    """
    Set auto-filter on a range.

    Args:
        sheet_index: Zero-based index of the sheet
        start_row: 1-based starting row
        start_col: 1-based starting column
        end_row: 1-based ending row
        end_col: 1-based ending column
    """

    sheet_index: int
    start_row: int
    start_col: int
    end_row: int
    end_col: int

    @property
    def command_type(self) -> str:
        return "SetAutoFilter"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.start_row < 1 or self.start_col < 1:
            raise ValidationError("start_row and start_col must be >= 1", "range")


@dataclass
class RemoveAutoFilter(Command):
    """
    Remove auto-filter from a sheet.

    Args:
        sheet_index: Zero-based index of the sheet
    """

    sheet_index: int

    @property
    def command_type(self) -> str:
        return "RemoveAutoFilter"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")


# -------------------------------------------------------------------------
# Tables
# -------------------------------------------------------------------------


@dataclass
class CreateTable(Command):
    """
    Create a new table on a sheet.

    The ``table_view`` payload is a dict matching @rowsncolumns/spreadsheet's
    ``TableView`` shape; the SDK's ``Table.to_table_view`` produces it.
    """

    sheet_index: int
    table_view: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "CreateTable"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if not isinstance(self.table_view, dict) or "range" not in self.table_view:
            raise ValidationError("table_view must be a dict with a 'range' key", "table_view")


@dataclass
class UpdateTable(Command):
    """Update an existing table identified by id."""

    sheet_index: int
    table_id: int | str
    table_view: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "UpdateTable"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.table_id is None or self.table_id == "":
            raise ValidationError("table_id is required", "table_id")


@dataclass
class DeleteTable(Command):
    """Delete a table by id."""

    sheet_index: int
    table_id: int | str

    @property
    def command_type(self) -> str:
        return "DeleteTable"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.table_id is None or self.table_id == "":
            raise ValidationError("table_id is required", "table_id")


# -------------------------------------------------------------------------
# Data validation & Conditional formatting
# -------------------------------------------------------------------------


@dataclass
class AddDataValidation(Command):
    """Add a data-validation rule to a sheet.

    ``rule_record`` matches @rowsncolumns ``DataValidationRuleRecord`` shape.
    """

    sheet_index: int
    rule_record: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "AddDataValidation"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if not isinstance(self.rule_record, dict) or "id" not in self.rule_record:
            raise ValidationError("rule_record must include 'id'", "rule_record")


@dataclass
class RemoveDataValidation(Command):
    """Remove a data-validation rule by id."""

    sheet_index: int
    rule_id: int | str

    @property
    def command_type(self) -> str:
        return "RemoveDataValidation"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")


@dataclass
class AddConditionalFormat(Command):
    """Add a conditional formatting rule to a sheet."""

    sheet_index: int
    rule: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "AddConditionalFormat"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if not isinstance(self.rule, dict) or "id" not in self.rule:
            raise ValidationError("rule must include 'id'", "rule")


@dataclass
class RemoveConditionalFormat(Command):
    """Remove a conditional formatting rule by id."""

    sheet_index: int
    rule_id: int | str

    @property
    def command_type(self) -> str:
        return "RemoveConditionalFormat"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")


# -------------------------------------------------------------------------
# Pivots
# -------------------------------------------------------------------------


@dataclass
class CreatePivotTable(Command):
    """Create a pivot table on a sheet."""

    sheet_index: int
    payload: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "CreatePivotTable"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if not isinstance(self.payload, dict) or "pivotId" not in self.payload:
            raise ValidationError("payload must include 'pivotId'", "payload")


@dataclass
class DeletePivotTable(Command):
    """Delete a pivot table by id."""

    pivot_id: str | int

    @property
    def command_type(self) -> str:
        return "DeletePivotTable"

    def validate(self) -> None:
        if self.pivot_id is None or self.pivot_id == "":
            raise ValidationError("pivot_id is required", "pivot_id")


# -------------------------------------------------------------------------
# Charts
# -------------------------------------------------------------------------


@dataclass
class CreateChart(Command):
    """Create an embedded chart on a sheet.

    ``payload`` matches the converter's ``chart.ts`` create payload shape so
    the same engine code path applies.
    """

    sheet_index: int
    payload: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "CreateChart"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if not isinstance(self.payload, dict) or "chartType" not in self.payload:
            raise ValidationError("payload must include 'chartType'", "payload")


# -------------------------------------------------------------------------
# Protection
# -------------------------------------------------------------------------


@dataclass
class SetSheetProtection(Command):
    """Set per-sheet protection state."""

    sheet_index: int
    protection: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "SetSheetProtection"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")


@dataclass
class SetWorkbookProtection(Command):
    """Set workbook-level protection state."""

    protection: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "SetWorkbookProtection"

    def validate(self) -> None:
        if not isinstance(self.protection, dict):
            raise ValidationError("protection must be a dict", "protection")


# -------------------------------------------------------------------------
# Comments
# -------------------------------------------------------------------------


@dataclass
class SetCellComment(Command):
    """Attach a comment to a cell.

    The applier writes the thread to a workbook-level ``commentThreads`` Y.Map
    and points the cell's ``commentThreadId`` at the new thread. Olympus's
    comment renderer will pick this up in a follow-up integration.
    """

    sheet_index: int
    row: int
    col: int
    text: str
    author: str | None = None
    thread_id: str | None = None  # auto-generated when absent

    @property
    def command_type(self) -> str:
        return "SetCellComment"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")
        if self.row < 1 or self.col < 1:
            raise ValidationError("row and col must be >= 1", "coords")


@dataclass
class RemoveCellComment(Command):
    """Detach the comment from a cell."""

    sheet_index: int
    row: int
    col: int

    @property
    def command_type(self) -> str:
        return "RemoveCellComment"

    def validate(self) -> None:
        if self.sheet_index < 0:
            raise ValidationError("sheet_index must be non-negative", "sheet_index")


# -------------------------------------------------------------------------
# Defined names
# -------------------------------------------------------------------------


@dataclass
class CreateNamedRange(Command):
    """Add a named range to the workbook (book-scoped or sheet-scoped)."""

    sheet_index: int  # 0-based sheet ref; -1 for workbook-scoped
    named_range: dict[str, Any]

    @property
    def command_type(self) -> str:
        return "CreateNamedRange"

    def validate(self) -> None:
        if not isinstance(self.named_range, dict) or "name" not in self.named_range:
            raise ValidationError("named_range must include 'name'", "named_range")


@dataclass
class DeleteNamedRange(Command):
    """Remove a named range by id."""

    named_range_id: int | str

    @property
    def command_type(self) -> str:
        return "DeleteNamedRange"

    def validate(self) -> None:
        if self.named_range_id is None or self.named_range_id == "":
            raise ValidationError("named_range_id is required", "named_range_id")


# Type alias for any command
AnyCommand = (
    SetCellValue
    | SetCellFormula
    | SetCellStyle
    | SetRangeValues
    | AddSheet
    | DeleteSheet
    | RenameSheet
    | ReorderSheets
    | CloneSheet
    | SetColumnWidth
    | SetRowHeight
    | InsertRows
    | InsertColumns
    | DeleteRows
    | DeleteColumns
    | MergeCells
    | UnmergeCells
    | SetSheetProperties
    | SetWorkbookProperties
    | SetAutoFilter
    | RemoveAutoFilter
    | CreateTable
    | UpdateTable
    | DeleteTable
    | AddDataValidation
    | RemoveDataValidation
    | AddConditionalFormat
    | RemoveConditionalFormat
    | CreateNamedRange
    | DeleteNamedRange
    | SetCellComment
    | RemoveCellComment
    | SetSheetProtection
    | SetWorkbookProtection
    | CreateChart
    | CreatePivotTable
    | DeletePivotTable
)
