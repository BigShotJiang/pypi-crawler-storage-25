"""
Exception types for the XLSX SDK.
"""

from __future__ import annotations

from typing import Any


class XlsxSdkError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class UnsupportedFeatureError(XlsxSdkError):
    """
    Raised when an unsupported openpyxl feature is accessed.

    athena-python-xlsx maintains API compatibility with openpyxl but
    not all features are implemented yet. This exception clearly indicates
    what isn't available and may suggest alternatives.
    """

    def __init__(self, feature: str, message: str | None = None):
        if message:
            full_message = f"[{feature}] {message}"
        else:
            full_message = (
                f"Feature '{feature}' is not yet implemented in athena-python-xlsx. "
                f"See https://github.com/xlsx-studio/athena-python-xlsx for supported features."
            )
        super().__init__(full_message, {"feature": feature})
        self.feature = feature

    def __str__(self) -> str:
        return self.message


class RemoteError(XlsxSdkError):
    """
    Raised when the server rejects a command or returns an error.

    Includes the HTTP status code and error details from the server.
    """

    def __init__(
        self,
        message: str,
        status_code: int,
        error_code: str | None = None,
        server_message: str | None = None,
    ):
        super().__init__(
            message,
            {
                "status_code": status_code,
                "error_code": error_code,
                "server_message": server_message,
            },
        )
        self.status_code = status_code
        self.error_code = error_code
        self.server_message = server_message


class ConflictError(XlsxSdkError):
    """
    Raised when a command references stale or invalid IDs.

    This can happen when:
    - A cell was deleted by another collaborator
    - A sheet index is out of bounds
    - A workbook ID doesn't exist
    """

    def __init__(self, message: str, stale_ids: list[str] | None = None):
        super().__init__(message, {"stale_ids": stale_ids})
        self.stale_ids = stale_ids or []


class ValidationError(XlsxSdkError):
    """
    Raised when command validation fails.

    This is a client-side error that occurs before sending to the server.
    """

    def __init__(self, message: str, field: str | None = None):
        super().__init__(message, {"field": field})
        self.field = field


class ConnectionError(XlsxSdkError):
    """
    Raised when unable to connect to the server.
    """

    def __init__(self, message: str, url: str | None = None):
        super().__init__(message, {"url": url})
        self.url = url


class AuthenticationError(XlsxSdkError):
    """
    Raised when authentication fails.
    """

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message)


class ExportError(XlsxSdkError):
    """
    Raised when export fails.
    """

    def __init__(self, message: str, job_id: str | None = None):
        super().__init__(message, {"job_id": job_id})
        self.job_id = job_id


class RenderError(XlsxSdkError):
    """
    Raised when rendering fails.
    """

    def __init__(self, message: str, job_id: str | None = None):
        super().__init__(message, {"job_id": job_id})
        self.job_id = job_id


class UploadError(XlsxSdkError):
    """
    Raised when file upload fails.
    """

    def __init__(self, message: str, workbook_id: str | None = None):
        super().__init__(message, {"workbook_id": workbook_id})
        self.workbook_id = workbook_id
