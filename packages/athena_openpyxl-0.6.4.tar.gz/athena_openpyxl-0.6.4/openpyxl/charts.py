"""
Chart authoring — openpyxl.chart parity (Tier C).

Maps openpyxl chart classes to ``@rowsncolumns/spreadsheet`` ``EmbeddedChart``
shape consumed by ``createChart``. The same engine method is already used by
``agora/converter-olympus/src/sheets/chart.ts``; SDK-authored charts and
converter-imported charts share one engine code path.

Supported chart types (mapping to engine ``ChartSpec.chartType``):
- ``BarChart`` → ``"BAR"``
- ``LineChart`` → ``"LINE"``
- ``PieChart`` → ``"PIE"``
- ``ScatterChart`` → ``"SCATTER"``
- ``AreaChart`` → ``"AREA"``
"""

from __future__ import annotations

from typing import Any

from .errors import ValidationError
from .utils import column_index_from_string


class Reference:
    """A cell range reference for a chart's domain or series.

    Mirrors openpyxl.chart.Reference. Accepts either an A1 range string
    or explicit ``min_col`` / ``min_row`` / ``max_col`` / ``max_row``.
    """

    def __init__(
        self,
        worksheet: Any | None = None,
        min_col: int | None = None,
        min_row: int | None = None,
        max_col: int | None = None,
        max_row: int | None = None,
        range_string: str | None = None,
    ):
        self.worksheet = worksheet
        if range_string:
            min_col, min_row, max_col, max_row = self._parse_range_string(range_string)
        # Defer the "needs coords" check to ``to_a1`` so the harness can still
        # introspect the class with no args.
        self.min_col = min_col if min_col is not None else 0
        self.min_row = min_row if min_row is not None else 0
        self.max_col = max_col if max_col is not None else self.min_col
        self.max_row = max_row if max_row is not None else self.min_row
        if min_col is None and range_string is None:
            self._unset = True
        else:
            self._unset = False

    def _parse_range_string(self, s: str) -> tuple[int, int, int, int]:
        # Strip any "Sheet1!" prefix.
        if "!" in s:
            s = s.split("!", 1)[1]
        s = s.replace("$", "")
        if ":" in s:
            start, end = s.split(":")
        else:
            start = end = s
        return (
            *_split_addr(start),
            *_split_addr(end),
        )

    def to_a1(self) -> str:
        if self._unset:
            raise ValidationError(
                "Reference has no coordinates; pass min_col/min_row or range_string",
                "Reference",
            )
        from .utils import get_column_letter

        start = f"{get_column_letter(self.min_col)}{self.min_row}"
        end = f"{get_column_letter(self.max_col)}{self.max_row}"
        return f"{start}:{end}" if start != end else start


def _split_addr(addr: str) -> tuple[int, int]:
    """Split an A1 cell address into (col_idx_1based, row_idx_1based)."""
    col_str = ""
    row_str = ""
    for ch in addr:
        if ch.isalpha():
            col_str += ch
        else:
            row_str += ch
    return column_index_from_string(col_str), int(row_str)


class _BaseChart:
    """Common base for openpyxl chart classes."""

    chart_type: str = ""

    def __init__(
        self,
        title: str | None = None,
        x_axis_title: str | None = None,
        y_axis_title: str | None = None,
        width: int = 400,
        height: int = 300,
    ):
        self.title = title
        self.x_axis_title = x_axis_title
        self.y_axis_title = y_axis_title
        self.width = width
        self.height = height
        self._series: list[tuple[Reference, str | None]] = []
        self._categories: Reference | None = None

    def add_data(
        self, data: Reference, titles_from_data: bool = False, label: str | None = None
    ) -> None:
        """Add a data series. Mirrors openpyxl.chart.Chart.add_data.

        ``titles_from_data=True`` treats the first row of the reference as the
        series label; otherwise ``label`` (or None) is used.
        """
        if titles_from_data and self.worksheet_for_data_labels:
            ws = self.worksheet_for_data_labels
            label_cell = ws.cell(data.min_row, data.min_col)
            label = str(label_cell.value) if label_cell.value is not None else label
            # Trim the label row from the data range.
            data = Reference(
                worksheet=data.worksheet,
                min_col=data.min_col,
                min_row=data.min_row + 1,
                max_col=data.max_col,
                max_row=data.max_row,
            )
        self._series.append((data, label))

    @property
    def worksheet_for_data_labels(self) -> Any | None:
        for ref, _ in self._series:
            if ref.worksheet is not None:
                return ref.worksheet
        return None

    def set_categories(self, categories: Reference) -> None:
        """Set the X-axis categories (matches openpyxl.chart.Chart.set_categories)."""
        self._categories = categories

    def to_engine_payload(self, sheet_id: int, anchor_cell: str) -> dict[str, Any]:
        """Build the payload consumed by the converter's chart engine handler."""
        if not self._series:
            raise ValidationError("Chart has no data series; call add_data() first", "series")
        if self._categories is None:
            raise ValidationError("Chart has no categories; call set_categories()", "categories")

        domain = self._categories.to_a1()
        series_payload = [{"range": ref.to_a1(), "label": label} for ref, label in self._series]

        payload: dict[str, Any] = {
            "sheetId": sheet_id,
            "chartType": self.chart_type,
            "domain": domain,
            "series": series_payload,
            "anchorCell": anchor_cell,
            "width": self.width,
            "height": self.height,
        }
        if self.title:
            payload["title"] = self.title
        if self.x_axis_title:
            payload["xAxisTitle"] = self.x_axis_title
        if self.y_axis_title:
            payload["yAxisTitle"] = self.y_axis_title
        return payload


class BarChart(_BaseChart):
    chart_type = "BAR"


class LineChart(_BaseChart):
    chart_type = "LINE"


class PieChart(_BaseChart):
    chart_type = "PIE"


class ScatterChart(_BaseChart):
    chart_type = "SCATTER"


class AreaChart(_BaseChart):
    chart_type = "AREA"
