"""Stock-openpyxl-compatible re-export package.

Stock openpyxl exposes chart classes at ``openpyxl.chart`` (singular);
the SDK's canonical implementation lives at ``openpyxl.charts`` (plural).
This package re-exports them at the stock path so agent code following
stock conventions (``from openpyxl.chart import BarChart``) works
unchanged.
"""

from __future__ import annotations

from ..charts import (
    AreaChart,
    BarChart,
    LineChart,
    PieChart,
    Reference,
    ScatterChart,
)

__all__ = [
    "AreaChart",
    "BarChart",
    "LineChart",
    "PieChart",
    "Reference",
    "ScatterChart",
]
