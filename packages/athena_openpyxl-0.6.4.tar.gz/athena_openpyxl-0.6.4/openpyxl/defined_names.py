"""
Defined names — openpyxl.workbook.defined_name parity.

Maps to @rowsncolumns engine ``namedRanges`` array via createNamedRange /
deleteNamedRange.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any


class DefinedName:
    """A workbook- or sheet-scoped defined name.

    Mirrors openpyxl.workbook.defined_name.DefinedName.
    """

    def __init__(
        self,
        name: str,
        value: str | None = None,
        comment: str | None = None,
        localSheetId: int | None = None,
        attr_text: str | None = None,
        namedRangeId: str | int | None = None,
    ):
        self.name = name
        self.value = value if value is not None else attr_text
        self.comment = comment
        self.localSheetId = localSheetId
        self.namedRangeId = namedRangeId

    @property
    def attr_text(self) -> str | None:
        """openpyxl alias for ``value``."""
        return self.value

    @attr_text.setter
    def attr_text(self, v: str | None) -> None:
        self.value = v

    def to_engine_record(self, rule_id: str | int) -> dict[str, Any]:
        return {
            "namedRangeId": self.namedRangeId or rule_id,
            "name": self.name,
            "value": self.value,
        }

    def __repr__(self) -> str:
        return f"<DefinedName name={self.name!r} value={self.value!r}>"


class DefinedNameList:
    """Container exposed as ``wb.defined_names``.

    Mirrors openpyxl's ``DefinedNameList`` — supports dict-like access by
    name plus iteration.
    """

    def __init__(self) -> None:
        self.definedName: list[DefinedName] = []

    def add(self, name: DefinedName) -> None:
        if not isinstance(name, DefinedName):
            raise TypeError(f"add() expects DefinedName, got {type(name).__name__}")
        self.definedName.append(name)

    def __contains__(self, key: str) -> bool:
        return any(d.name == key for d in self.definedName)

    def __getitem__(self, key: str) -> DefinedName:
        for d in self.definedName:
            if d.name == key:
                return d
        raise KeyError(key)

    def __setitem__(self, key: str, value: DefinedName) -> None:
        if not isinstance(value, DefinedName):
            raise TypeError(f"value must be DefinedName, got {type(value).__name__}")
        if value.name != key:
            value.name = key
        for i, d in enumerate(self.definedName):
            if d.name == key:
                self.definedName[i] = value
                return
        self.definedName.append(value)

    def __delitem__(self, key: str) -> None:
        for i, d in enumerate(self.definedName):
            if d.name == key:
                self.definedName.pop(i)
                return
        raise KeyError(key)

    def __iter__(self) -> Iterator[DefinedName]:
        return iter(self.definedName)

    def __len__(self) -> int:
        return len(self.definedName)
