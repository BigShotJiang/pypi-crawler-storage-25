"""athena-python-xlsx - Drop-in replacement for openpyxl.

This SDK provides an openpyxl-compatible API that connects to XLSX Studio
for real-time collaboration. Use exactly the same code you would with openpyxl:

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Alignment
    from openpyxl.utils import get_column_letter

    # Configure via environment variables (recommended):
    #   ATHENA_XLSX_BASE_URL=https://api.xlsx-studio.com
    #   ATHENA_XLSX_API_KEY=your-api-key

    # Create a new workbook
    wb = Workbook.create(name="My Workbook")

    # Or upload an existing file
    wb = Workbook.upload("my_data.xlsx")

    # Or connect to an existing workbook
    wb = Workbook(workbook_id="wb_123")

    # Work with sheets and cells (same API as openpyxl)
    ws = wb.active
    ws['A1'] = "Hello World!"
    ws['B1'] = 42
    ws['A1'].font = Font(bold=True, size=14)

    wb.save("output.xlsx")

For features not yet implemented, UnsupportedFeatureError is raised with
a clear message explaining what's not supported.
"""

from __future__ import annotations

import weakref as _weakref
from typing import TYPE_CHECKING as _TYPE_CHECKING

from .cell import Cell, Comment, Hyperlink, MergedCell
from .charts import (
    AreaChart,
    BarChart,
    LineChart,
    PieChart,
    Reference,
    ScatterChart,
)
from .conditional_formatting import (
    CellIsRule,
    ColorScaleRule,
    ConditionalFormattingList,
    DataBarRule,
    DuplicateRule,
    FormulaRule,
    IconSetRule,
    TopRule,
    UniqueRule,
)
from .datavalidation import DataValidation, DataValidationList
from .defined_names import DefinedName, DefinedNameList
from .errors import (
    AuthenticationError,
    ConflictError,
    ConnectionError,
    ExportError,
    RemoteError,
    RenderError,
    UnsupportedFeatureError,
    UploadError,
    ValidationError,
    XlsxSdkError,
)
from .named_styles import NamedStyle, NamedStyleList
from .pivot import PivotField, PivotTable, PivotTableList, PivotValue
from .protection import SheetProtection, WorkbookProtection
from .styles import (
    FORMAT_CURRENCY_EUR,
    FORMAT_CURRENCY_USD,
    FORMAT_DATE_DATETIME,
    FORMAT_DATE_YYYYMMDD2,
    FORMAT_GENERAL,
    FORMAT_NUMBER,
    FORMAT_NUMBER_00,
    FORMAT_NUMBER_COMMA_SEPARATED1,
    FORMAT_PERCENTAGE,
    FORMAT_PERCENTAGE_00,
    Alignment,
    Border,
    Font,
    PatternFill,
    Side,
)
from .tables import Table, TableColumn, TableStyleInfo
from .utils import (
    cell_reference,
    column_index_from_string,
    coordinate_from_string,
    get_column_letter,
    parse_range,
    range_reference,
)
from .workbook import Workbook
from .worksheet import (
    PageMargins,
    PrintOptions,
    PrintPageSetup,
    Worksheet,
)

if _TYPE_CHECKING:
    from .batching import CommandBuffer

_active_buffers: list[_weakref.ref[CommandBuffer]] = []


def flush_all() -> None:
    """Flush all active workbook command buffers.

    Called automatically by Daytona bootstrap after user code executes.
    Also useful for scripts that create multiple Workbook instances.
    """
    alive: list[_weakref.ref[CommandBuffer]] = []
    for ref in _active_buffers:
        buf = ref()
        if buf is not None:
            alive.append(ref)
            if buf.pending_count > 0:
                try:
                    buf.flush()
                except Exception:
                    pass
    _active_buffers[:] = alive


def load_workbook(
    filename: str,
    base_url: str | None = None,
    api_key: str | None = None,
    **_kwargs: object,
) -> Workbook:
    """Open a workbook for editing.

    The argument is overloaded for parity with stock openpyxl plus Athena's
    asset-backed model:

    - **A local file path** (e.g. ``"data.xlsx"``) — uploaded to XLSX Studio
      and a ``Workbook`` is returned connected to the new asset.
    - **An Athena asset id** (e.g. ``"asset_8a2c..."``) — the SDK opens a
      live ``Workbook`` against the existing asset's Y.Doc. No upload happens.
    - **A URL** (``http://`` or ``https://``) — the file is downloaded into
      a temp path and uploaded.

    Stock openpyxl kwargs (``read_only``, ``data_only``, ``keep_vba``,
    ``iso_dates``, ``keep_links``) are accepted and ignored to keep code
    written against the stock signature working unmodified.

    Args:
        filename: Local path, asset_id, or URL.
        base_url: Optional XLSX Studio base URL override.
        api_key: Optional API key override.
    """
    target = str(filename)
    # asset_id form: "asset_xxx" or a 36-char UUID with no path/scheme markers.
    if _looks_like_asset_id(target):
        return Workbook(workbook_id=target, base_url=base_url, api_key=api_key)
    if target.startswith(("http://", "https://")):
        return _load_workbook_from_url(target, base_url=base_url, api_key=api_key)
    return Workbook.upload(target, base_url=base_url, api_key=api_key)


def _looks_like_asset_id(s: str) -> bool:
    if "/" in s or "\\" in s or s.endswith(".xlsx"):
        return False
    if s.startswith("asset_"):
        return True
    # UUID v4 form (no scheme, no slashes, hex+dashes).
    if len(s) == 36 and s.count("-") == 4 and all(c in "-0123456789abcdef" for c in s.lower()):
        return True
    return False


def _load_workbook_from_url(
    url: str, *, base_url: str | None = None, api_key: str | None = None
) -> Workbook:
    """Download an XLSX URL into a temp file, then upload."""
    import tempfile
    import urllib.request
    from pathlib import Path as _Path

    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
        tmp_path = _Path(tmp.name)
    urllib.request.urlretrieve(url, tmp_path)  # noqa: S310 — caller-controlled URL
    try:
        return Workbook.upload(str(tmp_path), base_url=base_url, api_key=api_key)
    finally:
        try:
            tmp_path.unlink()
        except OSError:
            pass


__version__ = "0.6.4"

__all__ = [
    # Main entry points
    "Workbook",
    "load_workbook",
    # Worksheet
    "Worksheet",
    # Tables
    "Table",
    "TableColumn",
    "TableStyleInfo",
    # Data validation & conditional formatting
    "DataValidation",
    "DataValidationList",
    "ConditionalFormattingList",
    "CellIsRule",
    "FormulaRule",
    "ColorScaleRule",
    "TopRule",
    "UniqueRule",
    "DuplicateRule",
    "IconSetRule",
    "DataBarRule",
    # Defined names & named styles
    "DefinedName",
    "DefinedNameList",
    "NamedStyle",
    "NamedStyleList",
    # Protection
    "SheetProtection",
    "WorkbookProtection",
    # Charts
    "Reference",
    "BarChart",
    "LineChart",
    "PieChart",
    "ScatterChart",
    "AreaChart",
    # Pivot tables
    "PivotTable",
    "PivotField",
    "PivotValue",
    "PivotTableList",
    "PrintPageSetup",
    "PageMargins",
    "PrintOptions",
    # Cell
    "Cell",
    "MergedCell",
    "Comment",
    "Hyperlink",
    # Styles
    "Font",
    "PatternFill",
    "Border",
    "Side",
    "Alignment",
    "FORMAT_GENERAL",
    "FORMAT_NUMBER",
    "FORMAT_NUMBER_00",
    "FORMAT_NUMBER_COMMA_SEPARATED1",
    "FORMAT_PERCENTAGE",
    "FORMAT_PERCENTAGE_00",
    "FORMAT_DATE_YYYYMMDD2",
    "FORMAT_DATE_DATETIME",
    "FORMAT_CURRENCY_USD",
    "FORMAT_CURRENCY_EUR",
    # Utils
    "get_column_letter",
    "column_index_from_string",
    "coordinate_from_string",
    "cell_reference",
    "range_reference",
    "parse_range",
    # Errors
    "XlsxSdkError",
    "UnsupportedFeatureError",
    "RemoteError",
    "ConflictError",
    "ValidationError",
    "ConnectionError",
    "AuthenticationError",
    "ExportError",
    "RenderError",
    "UploadError",
    # Flush helper
    "flush_all",
    # Version
    "__version__",
]
