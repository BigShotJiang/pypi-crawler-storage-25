"""
Conditional formatting rule classes.

Mirrors openpyxl.formatting.rule. Rules serialize to the
``ConditionalFormatRule`` shape consumed by
``@rowsncolumns/spreadsheet-state``'s ``createConditionalFormattingRule``.

Engine-supported rule kinds:
- ``BooleanRule`` — covers CellIsRule, FormulaRule
- ``GradientRule`` — covers ColorScaleRule
- ``TopBottomRule`` — covers TopRule (top/bottom N or %)
- ``DistinctRule`` — covers UniqueRule / DuplicateRule

``IconSetRule`` and ``DataBarRule`` aren't part of the engine's
``ConditionalFormatRule`` union; instances accept the openpyxl shape
but raise ``UnsupportedFeatureError`` on serialization.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from .errors import UnsupportedFeatureError
from .utils import parse_range

_BOOLEAN_OPERATOR_MAP = {
    "between": "NUMBER_BETWEEN",
    "notBetween": "NUMBER_NOT_BETWEEN",
    "equal": "NUMBER_EQ",
    "notEqual": "NUMBER_NOT_EQ",
    "greaterThan": "NUMBER_GREATER",
    "greaterThanOrEqual": "NUMBER_GREATER_THAN_EQ",
    "lessThan": "NUMBER_LESS",
    "lessThanOrEqual": "NUMBER_LESS_THAN_EQ",
    "containsText": "TEXT_CONTAINS",
    "notContains": "TEXT_NOT_CONTAINS",
    "beginsWith": "TEXT_STARTS_WITH",
    "endsWith": "TEXT_ENDS_WITH",
}


def _unquote_string_literal(formula_expr: str) -> str:
    # openpyxl's CellIsRule.formula is an Excel formula expression: string
    # literals are quoted (`"Hello"`) and `""` inside is an escaped `"`. The
    # rnc engine's `userEnteredValue` is the raw value — `normalizeConditionValue`
    # adds quoting when building the formula. Pass-through would double-quote.
    s = formula_expr.strip()
    if len(s) >= 2 and s.startswith('"') and s.endswith('"'):
        return s[1:-1].replace('""', '"')
    return formula_expr


class _BaseRule:
    """Common base for openpyxl-shaped CF rules."""

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        raise NotImplementedError


class CellIsRule(_BaseRule):
    """Rule that activates when a cell satisfies a comparison operator.

    Mirrors openpyxl.formatting.rule.CellIsRule.
    """

    def __init__(
        self,
        operator: str,
        formula: list[str] | None = None,
        stopIfTrue: bool = False,
        font: Any = None,
        fill: Any = None,
        border: Any = None,
    ):
        self.operator = operator
        self.formula = formula or []
        self.stopIfTrue = stopIfTrue
        self.font = font
        self.fill = fill
        self.border = border

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        ctype = _BOOLEAN_OPERATOR_MAP.get(self.operator)
        if not ctype:
            raise UnsupportedFeatureError(f"CellIsRule operator {self.operator!r} not supported")
        values = [{"userEnteredValue": _unquote_string_literal(str(f))} for f in self.formula]
        return {
            "id": rule_id,
            "stopIfTrue": self.stopIfTrue,
            "ranges": [_ref_to_sheet_range(r, sheet_id) for r in ranges],
            "booleanRule": {
                "condition": {"type": ctype, "values": values},
                "format": _format_dict(self.font, self.fill, self.border),
            },
        }


class FormulaRule(_BaseRule):
    """Rule activated by a custom formula.

    Mirrors openpyxl.formatting.rule.FormulaRule.
    """

    def __init__(
        self,
        formula: list[str] | None = None,
        stopIfTrue: bool = False,
        font: Any = None,
        fill: Any = None,
        border: Any = None,
    ):
        self.formula = formula or []
        self.stopIfTrue = stopIfTrue
        self.font = font
        self.fill = fill
        self.border = border

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        if not self.formula:
            raise UnsupportedFeatureError("FormulaRule requires at least one formula")
        return {
            "id": rule_id,
            "stopIfTrue": self.stopIfTrue,
            "ranges": [_ref_to_sheet_range(r, sheet_id) for r in ranges],
            "booleanRule": {
                "condition": {"type": "CUSTOM_FORMULA"},
                "formula": self.formula[0],
                "format": _format_dict(self.font, self.fill, self.border),
            },
        }


class ColorScaleRule(_BaseRule):
    """2-stop or 3-stop color scale rule.

    Mirrors openpyxl.formatting.rule.ColorScaleRule.
    """

    def __init__(
        self,
        start_type: str,
        start_value: str | float | None = None,
        start_color: str | None = None,
        end_type: str | None = None,
        end_value: str | float | None = None,
        end_color: str | None = None,
        mid_type: str | None = None,
        mid_value: str | float | None = None,
        mid_color: str | None = None,
    ):
        self.start_type = start_type
        self.start_value = start_value
        self.start_color = start_color
        self.mid_type = mid_type
        self.mid_value = mid_value
        self.mid_color = mid_color
        self.end_type = end_type
        self.end_value = end_value
        self.end_color = end_color

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        if self.start_color is None or self.end_type is None or self.end_color is None:
            raise UnsupportedFeatureError(
                "ColorScaleRule requires start and end interpolation points"
            )
        gradient: dict[str, Any] = {
            "minpoint": _interpolation_point(self.start_type, self.start_value, self.start_color),
            "maxpoint": _interpolation_point(self.end_type, self.end_value, self.end_color),
        }
        if self.mid_type and self.mid_color:
            gradient["midpoint"] = _interpolation_point(
                self.mid_type, self.mid_value, self.mid_color
            )
        return {
            "id": rule_id,
            "ranges": [_ref_to_sheet_range(r, sheet_id) for r in ranges],
            "gradientRule": gradient,
        }


class TopRule(_BaseRule):
    """Top/bottom N (or %) rule.

    Mirrors openpyxl.formatting.rule.Rule(type='top10').
    """

    def __init__(
        self,
        rank: int = 10,
        bottom: bool = False,
        percent: bool = False,
        font: Any = None,
        fill: Any = None,
        border: Any = None,
    ):
        self.rank = rank
        self.bottom = bottom
        self.percent = percent
        self.font = font
        self.fill = fill
        self.border = border

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        return {
            "id": rule_id,
            "ranges": [_ref_to_sheet_range(r, sheet_id) for r in ranges],
            "topBottomRule": {
                "type": "BOTTOM" if self.bottom else "TOP",
                "rank": self.rank,
                "isPercent": self.percent,
                "format": _format_dict(self.font, self.fill, self.border),
            },
        }


class UniqueRule(_BaseRule):
    """Unique-values rule.

    Mirrors openpyxl.formatting.rule.Rule(type='uniqueValues').
    """

    def __init__(
        self,
        font: Any = None,
        fill: Any = None,
        border: Any = None,
    ):
        self.font = font
        self.fill = fill
        self.border = border

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        return {
            "id": rule_id,
            "ranges": [_ref_to_sheet_range(r, sheet_id) for r in ranges],
            "distinctRule": {
                "type": "UNIQUE",
                "format": _format_dict(self.font, self.fill, self.border),
            },
        }


class DuplicateRule(_BaseRule):
    """Duplicate-values rule."""

    def __init__(
        self,
        font: Any = None,
        fill: Any = None,
        border: Any = None,
    ):
        self.font = font
        self.fill = fill
        self.border = border

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        return {
            "id": rule_id,
            "ranges": [_ref_to_sheet_range(r, sheet_id) for r in ranges],
            "distinctRule": {
                "type": "DUPLICATE",
                "format": _format_dict(self.font, self.fill, self.border),
            },
        }


class IconSetRule(_BaseRule):
    """Icon-set rule (object model only — engine has no native support)."""

    def __init__(self, icon_style: str, type: str, values: list[float]):
        self.icon_style = icon_style
        self.type = type
        self.values = values

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        raise UnsupportedFeatureError(
            "IconSetRule has no @rowsncolumns engine equivalent; rule is "
            "object-model only and will not persist."
        )


class DataBarRule(_BaseRule):
    """Data-bar rule (object model only — engine has no native support)."""

    def __init__(
        self,
        start_type: str = "min",
        end_type: str = "max",
        color: str = "FF638EC6",
        showValue: bool = True,
    ):
        self.start_type = start_type
        self.end_type = end_type
        self.color = color
        self.showValue = showValue

    def to_engine_rule(
        self, sheet_id: int, ranges: list[str], rule_id: str | int
    ) -> dict[str, Any]:
        raise UnsupportedFeatureError(
            "DataBarRule has no @rowsncolumns engine equivalent; rule is "
            "object-model only and will not persist."
        )


def _format_dict(font: Any, fill: Any, border: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if font is not None and hasattr(font, "to_style_dict"):
        out.update(font.to_style_dict())
    if fill is not None and hasattr(fill, "to_style_dict"):
        out.update(fill.to_style_dict())
    if border is not None and hasattr(border, "to_style_dict"):
        out.update(border.to_style_dict())
    return out


def _interpolation_point(type_: str, value: str | float | None, color: str) -> dict[str, Any]:
    type_map = {
        "min": "MIN",
        "max": "MAX",
        "num": "NUMBER",
        "number": "NUMBER",
        "percent": "PERCENT",
        "percentile": "PERCENTILE",
    }
    point: dict[str, Any] = {
        "color": color,
        "type": type_map.get(type_.lower(), type_.upper()),
    }
    if value is not None:
        point["value"] = value
    return point


def _ref_to_sheet_range(ref: str, sheet_id: int) -> dict[str, Any]:
    # rowsncolumns' canonical addressToSelection returns **1-based** indices
    # for grid ranges (A1 -> startRowIndex=1, startColumnIndex=1, inclusive).
    # parse_range already returns 1-based, so pass through unchanged. The
    # previous `- 1` here produced 0-based output, which silently caused CF
    # rules to land at off-by-one positions and never render in Olympus.
    start_row, start_col, end_row, end_col = parse_range(ref)
    return {
        "sheetId": sheet_id,
        "startRowIndex": start_row,
        "endRowIndex": end_row,
        "startColumnIndex": start_col,
        "endColumnIndex": end_col,
    }


class ConditionalFormattingList:
    """Container exposed as ``ws.conditional_formatting``.

    Mirrors openpyxl's ``ConditionalFormattingList``.
    """

    def __init__(self, worksheet: Any):
        self._worksheet = worksheet
        self._entries: list[tuple[str, _BaseRule]] = []

    def add(self, range_string: str, rule: _BaseRule) -> None:
        """Apply ``rule`` to ``range_string`` (matches openpyxl)."""
        if not isinstance(rule, _BaseRule):
            raise TypeError(f"add() expects a CF rule, got {type(rule).__name__}")
        self._entries.append((range_string, rule))
        self._worksheet._register_conditional_format(range_string, rule)

    def __iter__(self) -> Iterator[tuple[str, _BaseRule]]:
        return iter(self._entries)

    def __len__(self) -> int:
        return len(self._entries)
