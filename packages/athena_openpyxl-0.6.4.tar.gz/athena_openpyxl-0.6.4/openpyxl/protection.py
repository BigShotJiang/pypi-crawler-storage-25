"""
Sheet & workbook protection — openpyxl.worksheet.protection /
openpyxl.workbook.protection parity.

Object-model exists today; persistence is stored on a Y.Doc
``protectedRanges`` map (workbook-keyed by sheet) that the applier writes.
The Olympus renderer enforces these at the UI layer in a follow-up — today
the SDK just records intent and round-trips through the converter.
"""

from __future__ import annotations


class SheetProtection:
    """Per-sheet protection options.

    Mirrors openpyxl.worksheet.protection.SheetProtection.
    """

    def __init__(
        self,
        sheet: bool = False,
        password: str | None = None,
        objects: bool = False,
        scenarios: bool = False,
        formatCells: bool = True,
        formatColumns: bool = True,
        formatRows: bool = True,
        insertColumns: bool = True,
        insertRows: bool = True,
        insertHyperlinks: bool = True,
        deleteColumns: bool = True,
        deleteRows: bool = True,
        selectLockedCells: bool = False,
        selectUnlockedCells: bool = False,
        sort: bool = True,
        autoFilter: bool = True,
        pivotTables: bool = True,
    ):
        self.sheet = sheet
        self.password = password
        self.objects = objects
        self.scenarios = scenarios
        self.formatCells = formatCells
        self.formatColumns = formatColumns
        self.formatRows = formatRows
        self.insertColumns = insertColumns
        self.insertRows = insertRows
        self.insertHyperlinks = insertHyperlinks
        self.deleteColumns = deleteColumns
        self.deleteRows = deleteRows
        self.selectLockedCells = selectLockedCells
        self.selectUnlockedCells = selectUnlockedCells
        self.sort = sort
        self.autoFilter = autoFilter
        self.pivotTables = pivotTables

    def enable(self) -> None:
        """Turn on sheet protection (matches openpyxl)."""
        self.sheet = True

    def disable(self) -> None:
        """Turn off sheet protection (matches openpyxl)."""
        self.sheet = False

    def to_engine_record(self) -> dict[str, object]:
        return {
            "sheet": self.sheet,
            # Password stored in plaintext today — engine has no hashing
            # convention; openpyxl also stores plaintext on the model.
            "password": self.password,
            "objects": self.objects,
            "scenarios": self.scenarios,
            "formatCells": self.formatCells,
            "formatColumns": self.formatColumns,
            "formatRows": self.formatRows,
            "insertColumns": self.insertColumns,
            "insertRows": self.insertRows,
            "insertHyperlinks": self.insertHyperlinks,
            "deleteColumns": self.deleteColumns,
            "deleteRows": self.deleteRows,
            "selectLockedCells": self.selectLockedCells,
            "selectUnlockedCells": self.selectUnlockedCells,
            "sort": self.sort,
            "autoFilter": self.autoFilter,
            "pivotTables": self.pivotTables,
        }


class WorkbookProtection:
    """Workbook-level protection.

    Mirrors openpyxl.workbook.protection.WorkbookProtection.
    """

    def __init__(
        self,
        workbookPassword: str | None = None,
        revisionsPassword: str | None = None,
        lockStructure: bool = False,
        lockWindows: bool = False,
        lockRevision: bool = False,
    ):
        self.workbookPassword = workbookPassword
        self.revisionsPassword = revisionsPassword
        self.lockStructure = lockStructure
        self.lockWindows = lockWindows
        self.lockRevision = lockRevision

    def to_engine_record(self) -> dict[str, object]:
        return {
            "workbookPassword": self.workbookPassword,
            "revisionsPassword": self.revisionsPassword,
            "lockStructure": self.lockStructure,
            "lockWindows": self.lockWindows,
            "lockRevision": self.lockRevision,
        }
