"""
Utility functions for openpyxl compatibility.

Provides cell reference conversion utilities matching openpyxl.utils.
"""

from __future__ import annotations

import re


def get_column_letter(col_idx: int) -> str:
    """
    Convert a column number into a column letter (1-indexed).

    e.g., 1 -> 'A', 27 -> 'AA', 703 -> 'AAA'

    Matches openpyxl.utils.get_column_letter behavior.
    """
    if col_idx < 1:
        raise ValueError(f"Invalid column index {col_idx}")

    result = []
    while col_idx > 0:
        col_idx, remainder = divmod(col_idx - 1, 26)
        result.append(chr(65 + remainder))
    return "".join(reversed(result))


def column_index_from_string(col_str: str) -> int:
    """
    Convert a column letter into a column number (1-indexed).

    e.g., 'A' -> 1, 'AA' -> 27, 'AAA' -> 703

    Matches openpyxl.utils.column_index_from_string behavior.
    """
    col_str = col_str.upper()
    result = 0
    for char in col_str:
        if not char.isalpha():
            raise ValueError(f"Invalid column string: {col_str}")
        result = result * 26 + (ord(char) - 64)
    return result


def coordinate_from_string(coord: str) -> tuple[str, int]:
    """
    Split a cell coordinate into column letter and row number.

    e.g., 'A1' -> ('A', 1), 'AB23' -> ('AB', 23)
    """
    match = re.match(r"^([A-Za-z]+)(\d+)$", coord)
    if not match:
        raise ValueError(f"Invalid cell coordinate: {coord}")
    return match.group(1).upper(), int(match.group(2))


def cell_reference(row: int, col: int) -> str:
    """
    Convert row and column numbers to a cell reference string.

    e.g., (1, 1) -> 'A1', (3, 27) -> 'AA3'

    Args:
        row: 1-based row number
        col: 1-based column number
    """
    return f"{get_column_letter(col)}{row}"


def range_reference(
    start_row: int,
    start_col: int,
    end_row: int,
    end_col: int,
) -> str:
    """
    Convert row/col bounds to a range reference string.

    e.g., (1, 1, 10, 3) -> 'A1:C10'
    """
    return f"{cell_reference(start_row, start_col)}:{cell_reference(end_row, end_col)}"


def parse_range(range_str: str) -> tuple[int, int, int, int]:
    """
    Parse a range string into (start_row, start_col, end_row, end_col).

    e.g., 'A1:C10' -> (1, 1, 10, 3)
    """
    parts = range_str.split(":")
    if len(parts) != 2:
        raise ValueError(f"Invalid range: {range_str}")
    col1, row1 = coordinate_from_string(parts[0])
    col2, row2 = coordinate_from_string(parts[1])
    return row1, column_index_from_string(col1), row2, column_index_from_string(col2)
