"""
Type definitions and protocols for the XLSX SDK.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, TypedDict

# Type aliases for IDs
WorkbookId = str
SheetId = str
CellId = str
ExportJobId = str
RenderJobId = str


# Cell data types (matching OOXML spec)
CellTypeLiteral = Literal[
    "string",
    "number",
    "boolean",
    "date",
    "formula",
    "error",
    "empty",
]


# Command types
CommandType = Literal[
    "SetCellValue",
    "SetCellStyle",
    "SetCellFormula",
    "AddSheet",
    "DeleteSheet",
    "RenameSheet",
    "SetColumnWidth",
    "SetRowHeight",
    "MergeCells",
    "UnmergeCells",
    "InsertRows",
    "InsertColumns",
    "DeleteRows",
    "DeleteColumns",
    "SetSheetProperties",
]


class CellStyle(TypedDict, total=False):
    """Cell styling options.

    Field names match the XLSX Studio API CellStyleSchema (Zod).
    """

    fontName: str
    fontSize: float
    bold: bool
    italic: bool
    underline: bool
    strikethrough: bool
    fontColor: str
    backgroundColor: str
    numberFormat: str
    horizontalAlignment: str
    verticalAlignment: str
    wrapText: bool
    borderTop: str
    borderBottom: str
    borderLeft: str
    borderRight: str


@dataclass
class CellSnapshot:
    """Snapshot of a cell's state."""

    row: int
    col: int
    value: Any
    cell_type: CellTypeLiteral
    formula: str | None = None
    style: CellStyle | None = None
    comment: str | None = None


@dataclass
class MergedRange:
    """A merged cell range."""

    start_row: int
    start_col: int
    end_row: int
    end_col: int


@dataclass
class SheetSnapshot:
    """Snapshot of a worksheet's state."""

    id: SheetId
    index: int
    name: str
    cells: dict[str, CellSnapshot]
    merged_ranges: list[MergedRange] = field(default_factory=list)
    column_widths: dict[int, float] = field(default_factory=dict)
    row_heights: dict[int, float] = field(default_factory=dict)
    frozen_rows: int = 0
    frozen_cols: int = 0
    hidden: bool = False
    tab_color: str | None = None
    tables: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class WorkbookSnapshot:
    """Complete snapshot of a workbook's state."""

    workbook_id: WorkbookId
    name: str
    sheet_count: int
    sheets: list[SheetSnapshot]
    active_sheet_index: int = 0


class CommandsResponse(TypedDict, total=False):
    """Response from POST /commands."""

    applied: bool
    created: dict[str, list[str]]
    snapshot: WorkbookSnapshot
    error: dict[str, Any]


class ExportStatus(TypedDict, total=False):
    """Export job status."""

    job_id: ExportJobId
    status: Literal["queued", "processing", "completed", "failed"]
    download_url: str | None
    error: str | None


class RenderStatus(TypedDict, total=False):
    """Render job status."""

    job_id: RenderJobId
    status: Literal["queued", "processing", "completed", "failed"]
    image_url: str | None
    error: str | None
