"""
Workbook proxy class - the main entry point for the SDK.

Provides openpyxl-compatible Workbook API that operates
on remote workbooks via the XLSX Studio API.
"""

from __future__ import annotations

import os
import weakref
from collections.abc import Generator, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from ..batching import CommandBuffer, batch_context
from ..client import Client
from ..commands import (
    AddSheet,
    CloneSheet,
    CreateNamedRange,
    DeleteNamedRange,
    DeleteSheet,
    ReorderSheets,
    SetWorkbookProperties,
    SetWorkbookProtection,
)
from ..defined_names import DefinedName, DefinedNameList
from ..named_styles import NamedStyle, NamedStyleList
from ..pivot import PivotTableList
from ..protection import WorkbookProtection
from ..typing import WorkbookId, WorkbookSnapshot
from ..worksheet import Worksheet


class Workbook:
    """
    Proxy for an Excel workbook.

    Provides openpyxl-compatible Workbook API that reads from snapshots
    and writes via commands to the XLSX Studio API.

    Example:
        # Create a new Athena Spreadsheet asset (visible in the workspace)
        wb = Workbook.create(name="My Workbook")
        # → wb.workbook_id is an "asset_<uuid>"

        # Or upload an existing file
        wb = Workbook.upload("my_data.xlsx")

        # Or connect to an existing Athena asset
        wb = Workbook(workbook_id="asset_3a9328bc-9c1c-4498-be8f-bda3883276f5")

        # Or connect to a legacy standalone xlsx-studio workbook
        wb = Workbook(workbook_id="wb_123")

        # Work with sheets and cells (same API as openpyxl)
        ws = wb.active
        ws['A1'] = "Hello World!"
        ws['B1'] = 42

        wb.save("output.xlsx")
    """

    def __init__(
        self,
        workbook_id: WorkbookId | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        org_id: str | None = None,
    ):
        """
        Connect to an existing workbook by ID.

        Args:
            workbook_id: ID of the workbook to connect to.
                        Required unless using create() or upload() class methods.
            base_url: Base URL of the XLSX Studio API.
                     If not provided, uses ATHENA_XLSX_BASE_URL env var.
            api_key: Optional API key for authentication.
            org_id: DEPRECATED — workspace is now resolved server-side from
                   the API key. Pass-through is retained for backwards
                   compatibility with older xlsx-studio API builds; new code
                   should leave this unset. Falls back to ATHENA_ORG_ID env
                   var when set.
        """
        self._client = Client(base_url=base_url, api_key=api_key)
        self._workbook_id = workbook_id
        # Use org_id from parameter, or fall back to ATHENA_ORG_ID env var
        self._org_id = org_id or os.environ.get("ATHENA_ORG_ID")
        self._snapshot: WorkbookSnapshot | None = None
        self._buffer = CommandBuffer(self._client, workbook_id or "", org_id=self._org_id)
        self._worksheets: list[Worksheet] = []
        self._active_sheet_index = 0
        self._defined_names = DefinedNameList()
        self._named_styles: NamedStyleList = NamedStyleList()
        self._next_named_range_id = 1
        self._security = WorkbookProtection()
        self._pivot_tables = PivotTableList()

        # Register buffer for flush_all()
        import openpyxl as _pkg

        _pkg._active_buffers.append(weakref.ref(self._buffer))

        # Load snapshot if we have a workbook ID
        if workbook_id:
            self._load_snapshot()

    def _load_snapshot(self) -> None:
        """Load the workbook snapshot from the server."""
        assert self._workbook_id is not None
        self._snapshot = self._client.get_snapshot(self._workbook_id, org_id=self._org_id)
        self._active_sheet_index = self._snapshot.active_sheet_index

        # Build worksheet proxies
        self._worksheets = []
        for sheet_snap in self._snapshot.sheets:
            ws = Worksheet(
                workbook=self,
                index=sheet_snap.index,
                snapshot=sheet_snap,
                buffer=self._buffer,
            )
            self._worksheets.append(ws)

        # Auto-create a default sheet if workbook is empty
        if not self._worksheets:
            self.create_sheet(title="Sheet1")

    # -------------------------------------------------------------------------
    # Class methods for creating/uploading workbooks
    # -------------------------------------------------------------------------

    @classmethod
    def create(
        cls,
        name: str | None = None,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        parent_folder_id: str | None = None,
        workspace_id: str | None = None,
    ) -> Workbook:
        """
        Create a new Athena Spreadsheet asset and return an opened Workbook.

        Hits ``POST {base_url}/workbooks/empty-asset`` on xlsx-studio,
        which proxies to agora's ``POST /api/xlsx-studio/assets`` to
        register a real Spreadsheet asset on the yhub/Keryx provider.
        The returned ``Workbook`` is bound to the new ``asset_<uuid>``
        and is immediately editable; the asset shows up in the caller's
        Athena workspace.

        Args:
            name: Display title for the spreadsheet. Defaults to the
                Athena naming convention if omitted.
            base_url: xlsx-studio API base URL. Falls back to
                ``$ATHENA_XLSX_BASE_URL``.
            api_key: Athena API key (PropelAuth user API key) or
                access token. Falls back to ``$ATHENA_XLSX_API_KEY`` /
                ``$ATHENA_API_KEY``.
            parent_folder_id: Optional parent folder; defaults to
                workspace root.
            workspace_id: Optional workspace UUID; defaults to the
                caller's current workspace as resolved by Agora.

        Returns:
            ``Workbook`` bound to the newly-created asset.

        DEVIATION FROM openpyxl: stock openpyxl returns a blank
        in-memory workbook for ``Workbook()``. This SDK is asset-backed,
        so net-new asset creation is a separate factory rather than
        overloading the constructor — same pattern as
        ``athena-python-docx``'s ``Document.create()``.
        """
        client = Client(base_url=base_url, api_key=api_key)
        result = client.create_empty_asset(
            name=name,
            parent_folder_id=parent_folder_id,
            workspace_id=workspace_id,
        )
        return cls(workbook_id=result["id"], base_url=base_url, api_key=api_key)

    @classmethod
    def create_standalone(
        cls,
        name: str | None = None,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
    ) -> Workbook:
        """
        Create a standalone xlsx-studio workbook (NOT an Athena asset).

        Returns a ``Workbook`` whose id is ``wb_<id>`` and which lives
        entirely in xlsx-studio's Y.Doc store — it does not appear in
        any user's Athena workspace. Prefer :meth:`create` for new code;
        this exists for parity with the legacy
        ``POST /workbooks/empty`` flow used by tests + a small number of
        non-asset callers.

        Args:
            name: Optional name for the workbook.
            base_url: xlsx-studio API base URL.
            api_key: Optional API key.

        Returns:
            ``Workbook`` connected to the new standalone workbook.
        """
        client = Client(base_url=base_url, api_key=api_key)
        result = client.create_empty_workbook(name=name)
        return cls(workbook_id=result["id"], base_url=base_url, api_key=api_key)

    @classmethod
    def upload(
        cls,
        file_path: str | Path,
        name: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
    ) -> Workbook:
        """
        Upload an XLSX file and return a Workbook connected to it.

        Args:
            file_path: Path to the XLSX file
            name: Optional name (defaults to filename)
            base_url: Base URL of the XLSX Studio API
            api_key: Optional API key

        Returns:
            Workbook instance connected to the uploaded workbook
        """
        client = Client(base_url=base_url, api_key=api_key)
        workbook_id = client.upload_file(str(file_path), name=name)
        return cls(workbook_id=workbook_id, base_url=base_url, api_key=api_key)

    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------

    @property
    def workbook_id(self) -> str | None:
        """The remote workbook ID."""
        return self._workbook_id

    @property
    def title(self) -> str:
        """The workbook name/title."""
        if self._snapshot:
            return self._snapshot.name
        return "Untitled"

    @property
    def active(self) -> Worksheet:
        """Get the active worksheet."""
        if not self._worksheets:
            raise IndexError("Workbook has no worksheets")
        return self._worksheets[self._active_sheet_index]

    @active.setter
    def active(self, worksheet: Worksheet) -> None:
        """Set the active worksheet."""
        for i, ws in enumerate(self._worksheets):
            if ws is worksheet:
                self._active_sheet_index = i
                return
        raise ValueError("Worksheet not found in this workbook")

    @property
    def sheetnames(self) -> list[str]:
        """List of worksheet names."""
        return [ws.title for ws in self._worksheets]

    @property
    def worksheets(self) -> list[Worksheet]:
        """List of all worksheets."""
        return list(self._worksheets)

    @property
    def defined_names(self) -> DefinedNameList:
        """Workbook-level defined names (matches openpyxl)."""
        return self._defined_names

    def add_defined_name(
        self, defined_name: DefinedName, *, sheet: Worksheet | None = None
    ) -> None:
        """Register a defined name and emit ``CreateNamedRange`` for the engine.

        Pass ``sheet=`` to scope the name to a specific worksheet (matches
        openpyxl's ``DefinedName(localSheetId=...)``).
        """
        if not isinstance(defined_name, DefinedName):
            raise TypeError(
                f"add_defined_name expects DefinedName, got {type(defined_name).__name__}"
            )
        if sheet is not None:
            defined_name.localSheetId = self._worksheets.index(sheet)

        rule_id = defined_name.namedRangeId or f"name_{self._next_named_range_id}"
        self._next_named_range_id += 1
        defined_name.namedRangeId = rule_id

        self._defined_names.add(defined_name)
        self._buffer.add(
            CreateNamedRange(
                sheet_index=defined_name.localSheetId
                if defined_name.localSheetId is not None
                else -1,
                named_range=defined_name.to_engine_record(rule_id),
            )
        )

    def delete_defined_name(self, name: str) -> None:
        """Remove a defined name by name."""
        target = self._defined_names[name]
        del self._defined_names[name]
        if target.namedRangeId is not None:
            self._buffer.add(DeleteNamedRange(named_range_id=target.namedRangeId))

    @property
    def named_styles(self) -> NamedStyleList:
        """Workbook-level named styles (matches openpyxl).

        Object-model only at this layer; persistence is via the cellXfs
        registry on each cell-write that resolves ``cell.style = "MyStyle"``.
        """
        return self._named_styles

    @property
    def pivot_tables(self) -> PivotTableList:
        """Workbook-level pivot tables (matches openpyxl)."""
        return self._pivot_tables

    @property
    def security(self) -> WorkbookProtection:
        """Workbook-level protection settings (matches openpyxl)."""
        return self._security

    @security.setter
    def security(self, value: WorkbookProtection) -> None:
        if not isinstance(value, WorkbookProtection):
            raise TypeError(f"security must be a WorkbookProtection, got {type(value).__name__}")
        self._security = value
        self._buffer.add(SetWorkbookProtection(protection=value.to_engine_record()))

    def add_named_style(self, style: NamedStyle) -> None:
        """Register a NamedStyle on the workbook (matches openpyxl)."""
        if not isinstance(style, NamedStyle):
            raise TypeError(f"add_named_style expects NamedStyle, got {type(style).__name__}")
        if self._named_styles.get(style.name) is not None:
            raise ValueError(f"NamedStyle named {style.name!r} already exists")
        self._named_styles.append(style)

    # -------------------------------------------------------------------------
    # Sheet operations
    # -------------------------------------------------------------------------

    def create_sheet(
        self,
        title: str | None = None,
        index: int | None = None,
    ) -> Worksheet:
        """
        Create a new worksheet.

        Args:
            title: Name for the new sheet (defaults to 'Sheet N')
            index: Position to insert (defaults to end)

        Returns:
            The new Worksheet object
        """
        self._buffer.add(
            AddSheet(
                name=title,
                index=index,
            )
        )

        # Flush to get the updated snapshot with the new sheet
        self._buffer.flush()
        self._load_snapshot()

        if index is not None:
            return self._worksheets[index]
        return self._worksheets[-1]

    def remove(self, worksheet: Worksheet) -> None:
        """
        Remove a worksheet from the workbook.

        Args:
            worksheet: The Worksheet object to remove
        """
        for i, ws in enumerate(self._worksheets):
            if ws is worksheet:
                self._buffer.add(DeleteSheet(sheet_index=i))
                self._worksheets.pop(i)
                return
        raise ValueError("Worksheet not found in this workbook")

    def copy_worksheet(self, from_worksheet: Worksheet) -> Worksheet:
        """
        Copy an existing worksheet.

        Args:
            from_worksheet: The worksheet to copy

        Returns:
            The new Worksheet object
        """
        for i, ws in enumerate(self._worksheets):
            if ws is from_worksheet:
                self._buffer.add(CloneSheet(source_index=i))
                self._buffer.flush()
                self._load_snapshot()
                return self._worksheets[-1]
        raise ValueError("Worksheet not found in this workbook")

    def move_sheet(self, sheet: Worksheet | str, offset: int = 0) -> None:
        """
        Move a sheet within the workbook.

        Args:
            sheet: Worksheet object or sheet name
            offset: Number of positions to move (positive = right, negative = left)
        """
        if isinstance(sheet, str):
            idx = self.sheetnames.index(sheet)
        else:
            idx = self._worksheets.index(sheet)

        new_idx = max(0, min(len(self._worksheets) - 1, idx + offset))
        order = list(range(len(self._worksheets)))
        order.remove(idx)
        order.insert(new_idx, idx)

        self._buffer.add(ReorderSheets(new_order=order))

    def __getitem__(self, key: str) -> Worksheet:
        """Get a worksheet by name."""
        for ws in self._worksheets:
            if ws.title == key:
                return ws
        raise KeyError(f"Worksheet '{key}' not found")

    def __contains__(self, key: str) -> bool:
        """Check if a worksheet name exists."""
        return key in self.sheetnames

    def __iter__(self) -> Iterator[Worksheet]:
        """Iterate over worksheets."""
        return iter(self._worksheets)

    def __len__(self) -> int:
        """Number of worksheets."""
        return len(self._worksheets)

    # -------------------------------------------------------------------------
    # Batch context
    # -------------------------------------------------------------------------

    @contextmanager
    def batch(self) -> Generator[Workbook, None, None]:
        """
        Context manager for batch operations.

        All commands within this context are buffered and sent
        as a single request when the context exits.

        Example:
            with wb.batch():
                ws['A1'] = "Hello"
                ws['A2'] = "World"
            # Both commands sent here
        """
        with batch_context(self._buffer):
            yield self

    # -------------------------------------------------------------------------
    # Save / Export
    # -------------------------------------------------------------------------

    def save(self, filename: str | Path) -> None:
        """
        Save the workbook as an XLSX file.

        This triggers an export from the server and downloads the result.

        Args:
            filename: Path to save the XLSX file
        """
        # Flush any pending commands first
        self._buffer.flush()

        assert self._workbook_id is not None
        xlsx_bytes = self._client.export_and_download(self._workbook_id)

        with open(filename, "wb") as f:
            f.write(xlsx_bytes)

    def close(self) -> None:
        """Flush pending commands and close the connection."""
        self._buffer.flush()

    # -------------------------------------------------------------------------
    # Properties metadata
    # -------------------------------------------------------------------------

    @property
    def properties(self) -> WorkbookProperties:
        """Access workbook properties (metadata)."""
        return WorkbookProperties(self)

    def __repr__(self) -> str:
        name = self._snapshot.name if self._snapshot else "new"
        return f'<Workbook "{name}" [{len(self._worksheets)} sheets]>'

    def __enter__(self) -> Workbook:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class WorkbookProperties:
    """
    Workbook document properties (metadata).

    Mirrors openpyxl's DocumentProperties.
    """

    def __init__(self, workbook: Workbook):
        self._workbook = workbook
        self._title: str | None = None
        self._creator: str | None = None
        self._subject: str | None = None
        self._keywords: str | None = None
        self._description: str | None = None

    @property
    def title(self) -> str | None:
        return self._title

    @title.setter
    def title(self, value: str) -> None:
        self._title = value
        self._workbook._buffer.add(SetWorkbookProperties(title=value))

    @property
    def creator(self) -> str | None:
        return self._creator

    @creator.setter
    def creator(self, value: str) -> None:
        self._creator = value
        self._workbook._buffer.add(SetWorkbookProperties(author=value))

    @property
    def subject(self) -> str | None:
        return self._subject

    @subject.setter
    def subject(self, value: str) -> None:
        self._subject = value
        self._workbook._buffer.add(SetWorkbookProperties(subject=value))

    @property
    def keywords(self) -> str | None:
        return self._keywords

    @keywords.setter
    def keywords(self, value: str) -> None:
        self._keywords = value
        self._workbook._buffer.add(SetWorkbookProperties(keywords=value))

    @property
    def description(self) -> str | None:
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        self._description = value
        self._workbook._buffer.add(SetWorkbookProperties(description=value))
