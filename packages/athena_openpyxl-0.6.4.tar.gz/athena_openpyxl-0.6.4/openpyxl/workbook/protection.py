"""Stock-openpyxl-compatible re-export of WorkbookProtection."""

from __future__ import annotations

from ..protection import WorkbookProtection

__all__ = ["WorkbookProtection"]
