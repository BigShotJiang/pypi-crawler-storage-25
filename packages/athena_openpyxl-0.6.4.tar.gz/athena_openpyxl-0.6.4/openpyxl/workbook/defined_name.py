"""Stock-openpyxl-compatible re-export of DefinedName."""

from __future__ import annotations

from ..defined_names import DefinedName, DefinedNameList

__all__ = ["DefinedName", "DefinedNameList"]
