"""Comment-related classes.

Mirrors ``openpyxl.comments``. The actual ``Comment`` class lives in
:mod:`openpyxl.cell` (where it's tightly coupled to ``Cell.comment``);
this module re-exports it so stock openpyxl imports of the form

    from openpyxl.comments import Comment

continue to work unmodified.
"""

from openpyxl.cell import Comment

__all__ = ["Comment"]
