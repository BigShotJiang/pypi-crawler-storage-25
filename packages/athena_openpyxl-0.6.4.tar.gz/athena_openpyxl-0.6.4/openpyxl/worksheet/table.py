"""Stock-openpyxl-compatible re-export.

Stock openpyxl exposes Table at ``openpyxl.worksheet.table``; the SDK's
canonical implementation lives at ``openpyxl.tables``. This module is a
re-export so agent code following stock conventions
(``from openpyxl.worksheet.table import Table, TableStyleInfo``) works
unchanged.
"""

from __future__ import annotations

from ..tables import Table, TableColumn, TableStyleInfo

__all__ = ["Table", "TableColumn", "TableStyleInfo"]
