"""Stock-openpyxl-compatible re-export of Hyperlink."""

from __future__ import annotations

from ..cell import Hyperlink

__all__ = ["Hyperlink"]
