"""Stock-openpyxl-compatible re-export of DataValidation classes."""

from __future__ import annotations

from ..datavalidation import DataValidation, DataValidationList

__all__ = ["DataValidation", "DataValidationList"]
