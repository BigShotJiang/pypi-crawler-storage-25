"""Stock-openpyxl-compatible re-export of SheetProtection."""

from __future__ import annotations

from ..protection import SheetProtection

__all__ = ["SheetProtection"]
