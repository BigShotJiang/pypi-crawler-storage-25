# athena-openpyxl API Parity Exceptions

This document lists all intentional deviations from the standard [openpyxl](https://openpyxl.readthedocs.io/) API in the athena-openpyxl SDK.

The SDK's goal is 1:1 API parity with openpyxl. These exceptions exist because the SDK is a Keryx-backed collaborative client (no local XML, no file path), or because LLM agents need ergonomics not present in openpyxl.

---

## Collaborative-engine omissions (openpyxl members that don't apply)

These standard openpyxl members are omitted because a Y.Doc-backed SDK has no access to a local file or the underlying XML/package structure. Calling them either raises `UnsupportedFeatureError` or — in cases where stock openpyxl uses them as accepted-and-ignored kwargs — the SDK accepts and ignores them too.

| Member | Reason |
|---|---|
| `Workbook(filename=None)` blank in-memory form | No local file path; state lives in the Y.Doc. Use `Workbook(asset_id)`. |
| `load_workbook(read_only=True)` | No streaming-read mode; the Y.Doc is always live. Argument accepted-and-ignored. |
| `Workbook(write_only=True)` | Same. |
| `load_workbook(data_only=True)` | Formula evaluation is Athena's concern, not the SDK's. Accepted-and-ignored. |
| `load_workbook(keep_vba=...)` | VBA passthrough is preserved by the converter, not author-modifiable. Accepted-and-ignored. |
| `wb.iso_dates` | Storage is canonical (1900-based Excel epoch). Flag has no effect. |
| `wb.template` | No template-file model. |
| `Workbook.add_named_style(...)` | Object model exists; persistent-styles wave is later. Raises `UnsupportedFeatureError` for now. |
| `Cell._element`, `Worksheet._cells`, `Workbook._archive` | Internal XML/zip access — not applicable in a Y.Doc-backed model. |
| `Cell.xf_index` direct write | The SDK manages xf indexing through `Session.register_xf`; direct index assignment is rejected. |
| `Chart.add_data(...)` without a subsequent `chart.set_categories(...)` | The downstream `@rowsncolumns/charts` engine requires an explicit category-axis range (`domain` in the chart payload). Stock openpyxl tolerates a chart with no categories and shows index labels; the SDK raises `ValidationError` instead of silently rendering a chart whose x-axis points at nothing. Call `chart.set_categories(Reference(...))` before `ws.add_chart(...)`. |

## Athena-only additions (not in openpyxl)

These additions exist because LLM agents and the Athena collaboration substrate need them. They are additive — code that doesn't use them keeps the same shape as stock openpyxl.

### `Workbook(asset_id, *, branch="main", custom_attributions=...)`

Stock openpyxl `Workbook()` opens a blank in-memory document. The Athena SDK opens a Keryx-backed live document and accepts two extra keyword-only arguments:

- `branch: str` — Y/hub branch name. `"main"` (default) targets the live document. Any other value targets a Y/hub speculative branch — useful for "preview before commit" agent flows. Branched WS writes are best-effort on the current Y/hub deployment; the agora REST path remains canonical for guaranteed branch isolation.
- `custom_attributions: list[dict[str, str]]` — list of `{"k": "...", "v": "..."}` dicts attached to every write. Olympus's activity panel reads these to render audit trails and rollback scopes. Mirrors `agora/agora/services/keryx/client.py:build_agent_attributions`.

```python
Workbook(
    "asset_abc",
    branch="suggest-run-7",
    custom_attributions=[
        {"k": "agent_id", "v": "spreadsheet-author"},
        {"k": "user_message_tracking_id", "v": "msg_xyz"},
    ],
)
```

### `Workbook.create(name=, *, base_url=, api_key=, parent_folder_id=, workspace_id=)`

Stock openpyxl returns a blank in-memory workbook for `Workbook()`. This SDK is asset-backed, so net-new asset creation is a separate factory rather than overloading the constructor — same pattern as `athena-python-docx`'s `Document.create()`.

`Workbook.create()` hits `POST {base_url}/workbooks/empty-asset` on xlsx-studio, which proxies to agora's `POST /api/xlsx-studio/assets`. The result is a real Athena Spreadsheet asset (`asset_<uuid>`) registered in the caller's workspace and immediately editable. Workspace defaulting matches docx-studio: `workspace_id` falls back to the caller's `current_workspace_id`.

```python
with Workbook.create(name="Q4 Forecast") as wb:
    ws = wb.active
    ws["A1"] = "Quarter"
    wb.save("forecast.xlsx")
# → wb.workbook_id is "asset_<uuid>", visible in the user's workspace
```

For the legacy "standalone xlsx-studio workbook" semantics (a `wb_<id>` workbook that lives only on the Fastify stub and is not registered as an Athena asset), use `Workbook.create_standalone(name=...)` instead. Reserved for non-asset callers and tests.

### `wb.batch()` context manager

Groups mutations into one logical Y.Doc update so Olympus's activity log records one entry instead of one-per-cell. Stock openpyxl has no analogue (no live collaboration to optimise for).

```python
with wb.batch():
    for row_idx in range(1, 1001):
        ws.cell(row_idx, 1, f"row {row_idx}")
    wb.save()
```

Re-entrant — nested `with wb.batch():` blocks are tracked by depth and only the outermost exit emits the combined update.

### Top-level `openpyxl.flush_all()`

Calls `save()` on every currently-open Workbook. Used by the Daytona spreadsheet sandbox prelude — agent code typically opens one or more Workbooks without explicit `save()` calls, and the sandbox calls `openpyxl.flush_all()` at script end so any pending Y.Doc updates make it to Keryx before the snapshot is suspended.

Safe to call when no Workbooks are open. Errors raised by individual saves are logged to stderr but don't block other workbooks from flushing.

### `cell.column_letter`

Stock openpyxl exposes `cell.column_letter` since 3.0. We carry the same property and its alias `cell.col_idx` for parity.

### `Workbook.copy_worksheet(source)` always returns a deep-cell-copy

Stock openpyxl's `copy_worksheet` is documented as "best-effort" for cross-deck copies. The SDK guarantees a deep-cell-copy within the same workbook (cells, dimensions, merges, freeze panes, filter, per-cell xfId) — Tables / charts / embeds are NOT duplicated yet (Tier B+).

---

## Structural deviations (openpyxl behaviour differs)

### `wb.save(filename=None)` ignores the filename

Stock openpyxl writes a local `.xlsx` file. The Athena SDK has no local file; `save()` flushes pending Y.Doc updates to Keryx. The positional `filename` argument is accepted for parity but ignored.

### `Worksheet.title` setter validates Excel rules

The setter validates against Excel's title rules (≤ 31 chars, no `\\/?*[]:`, non-blank) eagerly so callers get a `ValueError` at assignment time rather than later when the workbook is rendered. Stock openpyxl validates lazily.

### `wb.move_sheet(worksheet, offset=...)` only accepts integer offsets

Stock openpyxl's signature is `move_sheet(worksheet, offset=0)` where `offset` is an integer — same here. Callers passing `worksheet=<title>` (string) is also accepted as a convenience.

### `Workbook.add_named_style` raises `UnsupportedFeatureError`

Object-model `NamedStyle` is fully implemented; persistent registration to a workbook-level styles registry is Wave 4 styles sub-wave work. Cells can still adopt a named style by **name** via `cell.style = "Heading 1"`; the renderer will resolve the name when the registry lands.

### Whole-column `ws['A:C']` and whole-row `ws[1:5]` reads

Stock openpyxl returns generators bounded by the data dimensions; we return tuples-of-tuples bounded by `ws.max_row` / `ws.max_column`. Behaviour matches as long as your sheet has been written to at least once; on a brand-new sheet, openpyxl returns `()`, the SDK does the same.

---

## Tier-C parity gaps (deferred class implementations)

These openpyxl primitives don't yet have an SDK class. The wrapper class above each is implemented; the deferred class is the lower-level builder stock openpyxl exposes alongside it. They land in a future Tier-C wave; `ImportError` until then.

| Missing import | Wrapper that works today | Notes |
|---|---|---|
| `from openpyxl.chart import Series` | `BarChart`, `LineChart`, `PieChart`, `AreaChart` via `chart.add_data(Reference(...))` | Series is needed only for `ScatterChart` with explicit x/y references; use `add_data` shape for now. |
| `from openpyxl.formatting.rule import Rule` | `CellIsRule`, `FormulaRule`, `ColorScaleRule`, `TopRule`, `UniqueRule`, `DuplicateRule`, `IconSetRule`, `DataBarRule` | Stock openpyxl's generic `Rule(type=...)` builder; the per-type wrappers cover every case the SDK ships. |
| `from openpyxl.styles.differential import DifferentialStyle` | `font=`, `fill=`, `border=` kwargs on each conditional-formatting rule | Pass styling directly to the rule constructor. |

---

## Non-standard convenience methods (not present in openpyxl)

None. The Tier-A surface is parity-clean. If a future agent-friendly addition is proposed, it lands here first with a documented rationale.

---

## Verification

The parity contract is enforced two ways:

1. **`tests/test_python_openpyxl_api_parity.py`** (forthcoming) — walks every class listed in `API_PARITY_REPORT.md` and asserts no unexpected missing / extra members against stock openpyxl.
2. **`tests/baseline-parity/test_baseline_parity.py`** (forthcoming) — runs the same fixture corpus through stock openpyxl and the Athena SDK, structurally diffs the resulting workbooks.

Both lanes are tracked in `xlsx-studio/docs/ATHENA_OPENPYXL_ROADMAP_2026-04-29.md` §6 (test infrastructure).
