# athena-openpyxl SDK — Claude Instructions

## API Parity Rule (MANDATORY)

**This SDK MUST be a 100% exact replica of the standard [openpyxl](https://openpyxl.readthedocs.io/) API.**

Every class, method, property, and parameter name must match openpyxl exactly. The goal is that any code written for stock openpyxl works identically with this SDK — no surprises, no differences.

### What this means in practice

- **Do NOT add new methods** that don't exist in openpyxl
- **Do NOT add new properties** that don't exist in openpyxl
- **Do NOT rename parameters** — use the exact same parameter names as openpyxl
- **Do NOT change method signatures** — if openpyxl's `ws.merge_cells(range_string)` takes a string, ours must too
- **Do NOT change return types** — if openpyxl's `ws.iter_rows()` returns `Iterator[tuple[Cell, ...]]`, ours must too

### How to verify parity

Before adding or modifying any API surface:

1. Check the [openpyxl documentation](https://openpyxl.readthedocs.io/)
2. Check the [openpyxl source code](https://foss.heptapod.net/openpyxl/openpyxl)
3. Confirm the method/property/parameter exists with the same name and signature
4. If it doesn't exist in openpyxl, **do not add it** without explicit user approval

Run the parity test once it lands (`tests/baseline-parity/test_baseline_parity.py`).

### Intentionally omitted (collaborative-engine limitations)

These standard openpyxl members don't apply to a Y.Doc-backed SDK:

- `Workbook(filename=None)` blank-in-memory form — there is no local file path; state lives in the Y.Doc. Use `Workbook(asset_id)`.
- `load_workbook(read_only=True)` / `Workbook(write_only=True)` — Athena's collaborative model has no streaming-only mode; sessions always open against the live Y.Doc.
- `Workbook.iso_dates` — storage is canonical (Excel epoch); flag has no effect.
- `Workbook.template` — no template file model.
- `Worksheet._cells` / `cell._element` / package-part XML access — there is no local OOXML.
- VBA / macros (preserved through round-trip via the converter; not authorable from the SDK).

### Intentional deviations (additions)

These differ from stock openpyxl because the SDK is asset-backed, not file-backed. Each is documented in `docs/API_PARITY_EXCEPTIONS.md`.

- **`Workbook(asset_id, *, branch="main", custom_attributions=[...])`** — opens a Keryx session against the named Athena asset, optionally on a Y/hub speculative branch, and tags every write with the supplied attribution list (Olympus's activity panel surfaces these).
- **`wb.batch()`** — context manager that groups mutations into one logical Y.Doc update so the activity log records one entry rather than one-per-cell. Stock openpyxl has no analogue (no live collab to optimise for).
- **`openpyxl.flush_all()`** — top-level helper used by the Daytona sandbox prelude. Calls `save()` on every currently-open Workbook. Safe to call when no Workbooks are open.

### If you need a deviation

If there is a genuine technical reason why a deviation from openpyxl is necessary (e.g., the SDK is collaborative and cannot replicate XML-level behaviour):

1. **Stop and ask the user** before implementing.
2. Explain what the deviation is and why it's needed.
3. Get explicit confirmation that the deviation is acceptable.
4. Document the deviation in `docs/API_PARITY_EXCEPTIONS.md`.

**Do NOT silently add convenience methods, aliases, or "improved" APIs.** The value of this SDK is that it's a drop-in replacement — any divergence breaks that contract.

## Architecture

This is a **direct-to-Keryx** SDK. Sync façade on top, async pycrdt + y-websocket underneath. Mutations write directly to the Y.Doc; users and other agents see them live via Olympus's `@rowsncolumns/y-spreadsheet` renderer.

```
Agent code (openpyxl idiom)
    ↓
Workbook / Worksheet / Cell (sync facade)
    ↓  _batching.run_sync → background event loop thread
Session (pycrdt Doc + Keryx connection)
    ↓  _keryx_client: ECDSA P-384 JWT + y-websocket sync
Keryx  ←→  Olympus (@rowsncolumns/y-spreadsheet)
```

Key invariants:

- **State of truth is the Y.Doc.** The SDK never builds local OOXML; it reads/writes Y.Map / Y.Array entries that match Olympus's `sheetDataV3` schema.
- **`Session.list_sheets()` materializes a default `Sheet1`** for brand-new docs so the rest of the SDK has something to mutate. Real Keryx sessions populate the array on initial sync.
- **`Session` is single-threaded.** All sync facade calls funnel through `_batching.run_sync` onto one persistent event loop thread.
- **`cellXfs` is interned.** `Session.register_xf` returns the index for an existing identical xf, never duplicates.

## Development

```bash
# Install editable + dev tools.
uv venv
uv pip install -e ".[dev]"

# Run unit tests (no Keryx, no network required — Session.open is stubbed in conftest).
uv run pytest tests/ -x -q

# Run a specific test file.
uv run pytest tests/test_dimensions.py -v
```

## Build numbering

| Level | Version | Released |
|---|---|---|
| Phase 2 (initial direct-Keryx) | `0.1.0` | 2026-04 |
| Wave 0 + 1 + 2 + 3 + 4 (Tier A complete + Tier B object model) | `0.2.0` | 2026-04 |
| Tier B persistence (write_operations integration) | `0.3.0` | TBD |
| Tier A 1:1 parity report green on every class | `1.0.0` | TBD |
| Tier C charts (cross-studio extraction) | `2.0.0` | TBD |

See `xlsx-studio/docs/ATHENA_OPENPYXL_ROADMAP_2026-04-29.md` for the full plan.
