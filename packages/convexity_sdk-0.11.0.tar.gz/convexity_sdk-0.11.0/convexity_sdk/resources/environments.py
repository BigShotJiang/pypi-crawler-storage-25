"""Environments resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    delete_variable_v1_environments_key_delete as _delete_var,
)
from convexity_api_client.api.v1 import (
    get_variables_v1_environments_get as _get,
)
from convexity_api_client.api.v1 import (
    set_variable_v1_environments_key_put as _set_var,
)
from convexity_api_client.api.v1 import (
    set_variables_v1_environments_put as _set_vars,
)
from convexity_api_client.models.environment_response import EnvironmentResponse
from convexity_api_client.models.set_variable_request import SetVariableRequest
from convexity_api_client.models.set_variables_request import SetVariablesRequest


class Environments:
    """Synchronous sub-client for project environment variables."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def get(self, project_id: str) -> EnvironmentResponse:
        """Get all environment variables (secrets masked)."""
        result = _get.sync(client=self._client, project_id=project_id)
        if not isinstance(result, EnvironmentResponse):
            return EnvironmentResponse(variables=[])
        return result

    def set_variables(
        self,
        project_id: str,
        *,
        variables: list[dict],
    ) -> EnvironmentResponse:
        """Bulk upsert variables.

        Args:
            project_id: The project ID.
            variables: List of dicts with ``key``, ``value``, and
                optionally ``isSecret`` (bool, default False).
        """
        items = [
            SetVariableRequest(
                key=v["key"],
                value=v["value"],
                is_secret=v.get("isSecret", False),
            )
            for v in variables
        ]
        body = SetVariablesRequest(variables=items)
        result = _set_vars.sync(client=self._client, body=body, project_id=project_id)
        if not isinstance(result, EnvironmentResponse):
            raise ValueError(f"Unexpected response: {result}")
        return result

    def set_variable(
        self,
        project_id: str,
        *,
        key: str,
        value: str,
        is_secret: bool = False,
    ) -> EnvironmentResponse:
        """Create or update a single variable."""
        body = SetVariableRequest(key=key, value=value, is_secret=is_secret)
        result = _set_var.sync(key, client=self._client, body=body, project_id=project_id)
        if not isinstance(result, EnvironmentResponse):
            raise ValueError(f"Unexpected response: {result}")
        return result

    def delete_variable(
        self,
        project_id: str,
        *,
        key: str,
    ) -> EnvironmentResponse:
        """Delete a single variable."""
        result = _delete_var.sync(key, client=self._client, project_id=project_id)
        if not isinstance(result, EnvironmentResponse):
            raise ValueError(f"Unexpected response: {result}")
        return result
