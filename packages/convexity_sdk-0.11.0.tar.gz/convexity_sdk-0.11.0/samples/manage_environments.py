"""Sample: manage project environment variables (.env for a project).

Demonstrates:
- Bulk-setting environment variables (including secrets)
- Creating a code task that prints all env vars to verify injection
- Running that task and printing the output
- Verifying env var injection via a notebook session
"""

import os
import time

from convexity_api_client.api.notebook import (
    delete_session_api_notebook_session_session_id_delete as _del_session,
)
from convexity_api_client.api.notebook import (
    execute_cell_api_notebook_session_session_id_execute_post as _exec_cell,
)
from convexity_api_client.api.notebook import (
    get_or_create_session_api_notebook_session_get_or_create_post as _get_session,
)
from convexity_api_client.models import CreateRunTaskPayload
from convexity_api_client.models.cell_type import CellType
from convexity_api_client.models.create_run_request import CreateRunRequest
from convexity_api_client.models.execute_cell_request import ExecuteCellRequest
from convexity_api_client.models.get_or_create_session_request import GetOrCreateSessionRequest
from convexity_api_client.models.notebook_cell import NotebookCell
from convexity_api_client.models.notebook_document import NotebookDocument
from convexity_api_client.models.task_scenario import TaskScenario

from convexity_sdk import ConvexityClient

PROJECT_ID = os.environ.get("CONVEXITY_PROJECT_ID", "YOUR_PROJECT_ID")
POLL_INTERVAL = 2  # seconds

client = ConvexityClient()

# ── 1. Bulk-set environment variables ───────────────────────────────────
resp = client.environments.set_variables(
    PROJECT_ID,
    variables=[
        {"key": "DATABASE_URL", "value": "postgres://localhost:5432/mydb"},
        {"key": "API_KEY", "value": "sk-secret-123", "isSecret": True},
        {"key": "LOG_LEVEL", "value": "info"},
    ],
)
print("After bulk set:")
for v in resp.variables:
    print(f"  {v.key} = {v.value}  (secret={v.is_secret})")

# ── 2. Create a code task that prints all env vars ──────────────────────
CELL_CODE = """\
import os

print("=== Environment Variables injected into this Run ===")
for key in sorted(os.environ):
    # Only print CONVEXITY_* and the user-defined vars we set
    if key.startswith("CONVEXITY_") or key in ("DATABASE_URL", "API_KEY", "LOG_LEVEL"):
        print(f"  {key} = {os.environ[key]}")
print("=== Done ===")
"""

TASK_NAME = "Env Vars Verification Task"

# Check if the task already exists
existing = client.tasks.list(PROJECT_ID)
task = next((t for t in existing.tasks if t.name == TASK_NAME), None)

if task is None:
    print("\nCreating verification task …")
    task = client.tasks.create(
        name=TASK_NAME,
        project_id=PROJECT_ID,
        scenario=TaskScenario.OPTIMIZATION,
        description="Prints all environment variables to verify injection.",
    )
    print(f"  Created task: {task.id}")
else:
    print(f"\nReusing existing task: {task.id}")

# Attach the notebook cell
task = client.tasks.update(
    task.id,
    notebook=NotebookDocument(cells=[NotebookCell(id="env-check-1", type_=CellType.CODE, content=CELL_CODE)]),
)

# ── 3. Run the task ─────────────────────────────────────────────────────
print("\nStarting run …")
run_resp = client.runs.create_and_start(
    body=CreateRunRequest(
        code=CELL_CODE,
        task=CreateRunTaskPayload(
            id=task.id,
            notebook=task.notebook,
        ),
    )
)

if run_resp is None or not run_resp.success:
    msg = getattr(run_resp, "message", "unknown error") if run_resp else "no response"
    raise SystemExit(f"Failed to start run: {msg}")

run_id = run_resp.run_id
print(f"  Run created: {run_id}")

# ── 4. Poll for completion ──────────────────────────────────────────────
print("Polling for completion …")
while True:
    run = client.runs.get_status(run_id)
    status = run.status
    if status in ("completed", "failed", "cancelled"):
        break
    time.sleep(POLL_INTERVAL)

if status == "completed":
    print("\n── Run Output ──────────────────────────────────────────────")
    print(getattr(run, "output", "(no output captured)"))
elif status == "failed":
    raise SystemExit(f"Run failed: {getattr(run, 'error_message', '(no details)')}")
else:
    print(f"Run ended with status: {status}")

# ── 5. Verify via notebook session ──────────────────────────────────────
print("\n── Notebook Session Verification ────────────────────────────")
# Get the underlying generated API client from the SDK
api_client = client._api_client

# Create a notebook session for the task (model_id = task.id)
session_resp = _get_session.sync(
    client=api_client,
    body=GetOrCreateSessionRequest(model_id=task.id),
)
print(f"  Session: {session_resp.session_id} (created={session_resp.created})")

# Execute the same env-check code in the notebook kernel
cell_resp = _exec_cell.sync(
    session_resp.session_id,
    client=api_client,
    body=ExecuteCellRequest(code=CELL_CODE),
)
print(f"  Success: {cell_resp.success}  ({cell_resp.execution_time_ms}ms)")

# Print captured stdout from the notebook outputs
if cell_resp.outputs:
    for item in cell_resp.outputs:
        text = getattr(item, "text", None)
        if text:
            print(text, end="")

# Cleanup the notebook session
_del_session.sync(session_resp.session_id, client=api_client)
print("  Session cleaned up")

# ── 6. Cleanup: delete a variable, read back ───────────────────────────
client.environments.delete_variable(PROJECT_ID, key="LOG_LEVEL")
resp = client.environments.get(PROJECT_ID)
print("\nAfter deleting LOG_LEVEL:")
for v in resp.variables:
    print(f"  {v.key} = {v.value}")

client.close()
print("\nDone!")
