//! PyO3 module definition — delegates to [`pipeline::run()`] for all test execution.

#![allow(clippy::useless_conversion)] // pyo3 macros generate this

use pyo3::prelude::*;

mod bridge;
mod cache;
mod collector;
mod config;
mod filter;
mod marker;
mod parallel;
mod pipeline;
mod reporter;
mod scheduler;
mod strict;
mod types;
mod worker_result;

#[pyfunction]
fn run(py: Python<'_>, args: Vec<String>) -> PyResult<i32> {
    pipeline::run(py, args)
}

#[pymodule]
fn _oxitest(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Register a stderr tracing subscriber. try_init() is a no-op if a global
    // subscriber is already set (first cdylib imported in this process wins).
    // Users control verbosity via RUST_LOG (e.g. RUST_LOG=oxitest=debug).
    let _ = tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("warn")),
        )
        .with_writer(reporter::tracing_writer::PbMakeWriter::new())
        .try_init();
    m.add_function(wrap_pyfunction!(run, m)?)?;
    Ok(())
}
