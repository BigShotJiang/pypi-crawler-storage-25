"""Harness plane - agent orchestration."""
