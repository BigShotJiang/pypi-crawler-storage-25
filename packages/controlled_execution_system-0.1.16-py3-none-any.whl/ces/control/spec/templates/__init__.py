"""Bundled spec templates."""
