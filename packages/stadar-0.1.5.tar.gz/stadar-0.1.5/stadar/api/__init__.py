# flake8: noqa

# import apis into api package
from stadar.api.account_api import AccountApi
from stadar.api.auth_api import AuthApi
from stadar.api.billing_api import BillingApi
from stadar.api.games_api import GamesApi
from stadar.api.leagues_api import LeaguesApi
from stadar.api.matches_api import MatchesApi
from stadar.api.meta_api import MetaApi
from stadar.api.series_api import SeriesApi
from stadar.api.tournaments_api import TournamentsApi
from stadar.api.webhooks_api import WebhooksApi

