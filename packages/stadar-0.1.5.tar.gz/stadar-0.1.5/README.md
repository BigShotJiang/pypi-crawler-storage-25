# stadar — Python SDK for the Stadar esports API

Official Python client. Pip-installable. Type-hinted. Generated from
the public OpenAPI 3.1 spec — see
[stadar.net/docs/api](https://stadar.net/docs/api) for the full
reference and `clients/README.md` in the
[monorepo](https://github.com/macgraver/esports-api) for the codegen
posture.

```bash
pip install stadar
```

## Quick start

```python
from stadar import Client

# Reads $STADAR_API_KEY from env, with $STADAR_API_URL override.
client = Client.from_env()

# Or pass explicitly:
client = Client(api_key="esp_live_...", base_url="https://api.stadar.net")

matches = client.matches.list(game="cs2", status="live")
for m in matches.data:
    print(m.id, m.team_a.slug, "vs", m.team_b.slug)
```

## Sandbox

```python
# `esp_test_`-prefixed keys auto-route to the sandbox fixture set.
# `meta.sandbox: true` flags every response from the sandbox.
client = Client(api_key="esp_test_...")
```

## Webhooks

```python
from stadar.webhooks import verify_signature

@app.post("/stadar-webhook")
def handle(request):
    body = request.body  # raw bytes
    signature = request.headers["X-Stadar-Signature"]
    if not verify_signature(body, signature, secret="your-webhook-secret"):
        return 401
    event = parse_event(body)
    # ... handle event
```

See [stadar.net/docs/webhooks](https://stadar.net/docs/webhooks) for
the signature verification recipe.

## License

MIT. Source of truth is the OpenAPI spec; regeneration is part of
every spec change.
