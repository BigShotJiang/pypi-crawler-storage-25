use rstar::primitives::{GeomWithData, Rectangle};
use rstar::{ParentNode, RTree, RTreeNode, RTreeObject};
use interval_tree::{IntervalTree, IntervalTreeNode};

use crate::error::RTreeError;

pub type Object2D = GeomWithData<Rectangle<[f64; 2]>, usize>;
pub type Object3D = GeomWithData<Rectangle<[f64; 3]>, usize>;

pub enum RTreeDim {
    D1(IntervalTree),
    D2(RTree<Object2D>),
    D3(RTree<Object3D>),
}

// Opaque handle for C api
pub enum RTreeH {}

/// Returns a new empty tree with the given dimension.
#[no_mangle]
pub extern "C" fn rtree_create(tree: *mut *mut RTreeH, dim: u32) -> RTreeError {
    if tree.is_null() {
        return RTreeError::NullPointer;
    }
    let rtree = match dim {
        1 => RTreeDim::D1(IntervalTree::bulk_load(&[], &[], &[])),
        2 => RTreeDim::D2(RTree::new()),
        3 => RTreeDim::D3(RTree::new()),
        _ => return RTreeError::InvalidDimension,
    };
    unsafe { *tree = Box::into_raw(Box::new(rtree)) as *mut RTreeH };
    RTreeError::Success
}

/// Frees the given tree.
#[no_mangle]
pub extern "C" fn rtree_free(tree: *mut RTreeH) -> RTreeError {
    if tree.is_null() {
        return RTreeError::NullPointer;
    }
    drop(unsafe { Box::from_raw(tree as *mut RTreeDim) });
    RTreeError::Success
}

fn _rtree_get_dimension(tree: &RTreeDim) -> u32 {
    match tree {
        RTreeDim::D1(_) => 1,
        RTreeDim::D2(_) => 2,
        RTreeDim::D3(_) => 3,
    }
}

/// Returns the dimension of the tree.
#[no_mangle]
pub extern "C" fn rtree_get_dimension(tree: *const RTreeH, dim: *mut u32) -> RTreeError {
    if tree.is_null() || dim.is_null() {
        return RTreeError::NullPointer;
    }
    let rtree = unsafe { &*(tree as *const RTreeDim) };
    unsafe { *dim = _rtree_get_dimension(rtree) };
    RTreeError::Success
}

fn _rtree_bulk_load<const DIM: usize>(
    mins: *const f64,
    maxs: *const f64,
    data: *const usize,
    n: usize,
) -> RTree<GeomWithData<Rectangle<[f64; DIM]>, usize>> {
    let mins = unsafe { std::slice::from_raw_parts(mins, n * DIM) };
    let maxs = unsafe { std::slice::from_raw_parts(maxs, n * DIM) };
    let data = unsafe { std::slice::from_raw_parts(data, n) };

    let objects = (0..n)
        .map(|i| {
            let min: [f64; DIM] = std::array::from_fn(|j| mins[i * DIM + j]);
            let max: [f64; DIM] = std::array::from_fn(|j| maxs[i * DIM + j]);
            GeomWithData::new(Rectangle::from_corners(min, max), data[i])
        })
        .collect();

    RTree::bulk_load(objects)
}

fn _interval_tree_bulk_load(
    mins: *const f64,
    maxs: *const f64,
    data: *const usize,
    n: usize,
) -> IntervalTree {
    let mins = unsafe { std::slice::from_raw_parts(mins, n) };
    let maxs = unsafe { std::slice::from_raw_parts(maxs, n) };
    let data = unsafe { std::slice::from_raw_parts(data, n) };

    IntervalTree::bulk_load(mins, maxs, data)
}

/// Returns a new tree containing the given objects. The input arrays must have the same length.
/// Returns an empty tree if the input arrays are empty.
/// Supported dimensions are currently 1, 2, and 3. Returns an InvalidDimension error for unsupported dimensions.
/// You must free the returned tree with `rtree_free`.
#[no_mangle]
pub extern "C" fn rtree_bulk_load(
    tree: *mut *mut RTreeH,
    mins: *const f64,
    maxs: *const f64,
    ids: *const usize,
    n: usize,
    dim: u32,
) -> RTreeError {
    if tree.is_null() {
        return RTreeError::NullPointer;
    }

    if n == 0 {
        let rtree = match dim {
            1 => RTreeDim::D1(IntervalTree::new()),
            2 => RTreeDim::D2(RTree::new()),
            3 => RTreeDim::D3(RTree::new()),
            _ => return RTreeError::InvalidDimension,
        };
        unsafe { *tree = Box::into_raw(Box::new(rtree)) as *mut RTreeH };
        return RTreeError::Success;
    }

    if mins.is_null() || maxs.is_null() || ids.is_null() {
        return RTreeError::NullPointer;
    }

    let rtree = match dim {
        1 => RTreeDim::D1(_interval_tree_bulk_load(mins, maxs, ids, n)),
        2 => RTreeDim::D2(_rtree_bulk_load::<2>(mins, maxs, ids, n)),
        3 => RTreeDim::D3(_rtree_bulk_load::<3>(mins, maxs, ids, n)),
        _ => return RTreeError::InvalidDimension,
    };

    unsafe { *tree = Box::into_raw(Box::new(rtree)) as *mut RTreeH };
    RTreeError::Success
}

/// Returns the ids of all objects in the tree that contain the given point.
/// If no objects contain the point, returns nids_out = 0.
/// You must free the returned ids with `rtree_free_ids`.
#[no_mangle]
pub extern "C" fn rtree_locate_all_at_point(
    tree: *const RTreeH,
    point: *const f64,
    ids_out: *mut *mut usize,
    nids_out: *mut usize,
) -> RTreeError {
    if tree.is_null() || point.is_null() || ids_out.is_null() || nids_out.is_null() {
        return RTreeError::NullPointer;
    }
    let rtree = unsafe { &*(tree as *const RTreeDim) };
    let mut ids: Vec<usize> = match rtree {
        RTreeDim::D1(tree) => {
            let p: f64 = unsafe { *point };
            tree.locate_all_at_point(p)
        }
        RTreeDim::D2(tree) => {
            let p: [f64; 2] = unsafe { *(point as *const [f64; 2]) };
            tree.locate_all_at_point(&p).map(|obj| obj.data).collect()
        }
        RTreeDim::D3(tree) => {
            let p: [f64; 3] = unsafe { *(point as *const [f64; 3]) };
            tree.locate_all_at_point(&p).map(|obj| obj.data).collect()
        }
    };

    let n = ids.len();
    let ptr = ids.as_mut_ptr();
    std::mem::forget(ids);

    unsafe {
        *nids_out = n;
        *ids_out = ptr;
    }
    RTreeError::Success
}

/// Returns the size of the tree, defined as the number of objects in the tree.
/// An empty tree has size 0.
#[no_mangle]
pub extern "C" fn rtree_size(tree: *const RTreeH, size_out: *mut usize) -> RTreeError {
    if tree.is_null() || size_out.is_null() {
        return RTreeError::NullPointer;
    }
    let rtree = unsafe { &*(tree as *const RTreeDim) };
    let size = match rtree {
        RTreeDim::D1(tree) => tree.size(),
        RTreeDim::D2(tree) => tree.size(),
        RTreeDim::D3(tree) => tree.size(),
    };
    unsafe { *size_out = size };
    RTreeError::Success
}

fn _interval_tree_depth(node: &IntervalTreeNode) -> usize {
    let left_depth = node
        .left
        .as_deref()
        .map_or(0, |left| 1 + _interval_tree_depth(left));
    let right_depth = node
        .right
        .as_deref()
        .map_or(0, |right| 1 + _interval_tree_depth(right));
    left_depth.max(right_depth)
}

fn _rtree_depth<T: RTreeObject>(node: &ParentNode<T>) -> usize {
    node
        .children()
        .iter()
        .map(|child| match child {
            RTreeNode::Leaf(_) => 1,
            RTreeNode::Parent(parent) => 1 + _rtree_depth(parent),
        })
        .max()
        .unwrap_or(0)
}

/// Returns the depth of the tree, defined as the number of edges in the longest path from the root to a leaf.
/// An empty tree has depth 0.
#[no_mangle]
pub extern "C" fn rtree_depth(tree: *const RTreeH, depth_out: *mut usize) -> RTreeError {
    if tree.is_null() || depth_out.is_null() {
        return RTreeError::NullPointer;
    }
    let rtree = unsafe { &*(tree as *const RTreeDim) };
    let size = match rtree {
        RTreeDim::D1(tree) => tree.size(),
        RTreeDim::D2(tree) => tree.size(),
        RTreeDim::D3(tree) => tree.size(),
    };
    if size == 0 {
        unsafe { *depth_out = 0 };
        return RTreeError::Success;
    }
    let depth = match rtree {
        RTreeDim::D1(tree) => _interval_tree_depth(tree.root().unwrap()) + 1,
        RTreeDim::D2(tree) => _rtree_depth(tree.root()),
        RTreeDim::D3(tree) => _rtree_depth(tree.root()),
    };
    unsafe { *depth_out = depth };
    RTreeError::Success
}

/// Frees the ids returned by `rtree_locate_all_at_point`.
#[no_mangle]
pub extern "C" fn rtree_free_ids(ids: *mut usize, n: usize) -> RTreeError {
    if ids.is_null() {
        return RTreeError::NullPointer;
    }
    unsafe { drop(Vec::from_raw_parts(ids, n, n)) };
    RTreeError::Success
}
