from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, date, datetime
from typing import Any, cast

from icalendar import Calendar

from calprint.model import CalendarSummary, EventSummary, TemporalValue


class ParseError(ValueError):
    pass


def parse_calendar(data: bytes) -> CalendarSummary:
    try:
        calendar = cast(Any, Calendar.from_ical(data))
    except Exception as exc:  # pragma: no cover - parser-specific failures vary
        raise ParseError("failed to parse iCalendar data") from exc

    try:
        timezones = sorted(
            {
                timezone_id
                for component in calendar.walk("VTIMEZONE")
                if (timezone_id := _as_text(component.get("TZID"))) is not None
            }
        )
        events = [_parse_event(component) for component in calendar.walk("VEVENT")]
    except Exception as exc:  # pragma: no cover - protects against parser quirks
        raise ParseError("failed to normalize iCalendar data") from exc

    events.sort(key=_event_sort_key)

    return CalendarSummary(
        version=_as_text(calendar.get("VERSION")),
        product_id=_as_text(calendar.get("PRODID")),
        method=_as_text(calendar.get("METHOD")),
        name=_first_present(
            _as_text(calendar.get("X-WR-CALNAME")),
            _as_text(calendar.get("NAME")),
        ),
        timezones=tuple(timezones),
        events=tuple(events),
    )


def _parse_event(component: Any) -> EventSummary:
    raw_attendees = _as_list(component.get("ATTENDEE"))
    attendees = tuple(
        display_name
        for attendee in raw_attendees
        if (display_name := _participant_display(attendee)) is not None
    )

    return EventSummary(
        summary=_as_text(component.get("SUMMARY")),
        start=_as_temporal(component.get("DTSTART")),
        end=_as_temporal(component.get("DTEND")),
        uid=_as_text(component.get("UID")),
        organizer=_participant_display(component.get("ORGANIZER")),
        attendees=attendees,
        attendee_count=len(raw_attendees),
        location=_as_text(component.get("LOCATION")),
        status=_as_text(component.get("STATUS")),
    )


def _event_sort_key(event: EventSummary) -> tuple[bool, str, str, str]:
    return (
        event.start is None,
        _sort_temporal(event.start),
        _sort_text(event.summary),
        _sort_text(event.uid),
    )


def _sort_temporal(value: TemporalValue | None) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        if value.tzinfo is not None:
            return value.astimezone(UTC).isoformat()
        return value.isoformat()
    return value.isoformat()


def _sort_text(value: str | None) -> str:
    if value is None:
        return ""
    return value.casefold()


def _participant_display(value: object) -> str | None:
    if value is None:
        return None

    params = _params_mapping(value)
    common_name = _as_text(params.get("CN"))
    if common_name is not None:
        return common_name

    email_param = _mailto_to_email(_as_text(params.get("EMAIL")))
    if email_param is not None:
        return email_param

    return _mailto_to_email(_as_text(value)) or _as_text(value)


def _params_mapping(value: object) -> Mapping[str, object]:
    params = getattr(value, "params", None)
    if isinstance(params, Mapping):
        return params
    return {}


def _as_list(value: object) -> list[object]:
    if value is None:
        return []
    if isinstance(value, list | tuple):
        return list(value)
    return [value]


def _as_temporal(value: object) -> TemporalValue | None:
    if value is None:
        return None

    candidate = getattr(value, "dt", value)
    if isinstance(candidate, datetime):
        return candidate
    if isinstance(candidate, date):
        return candidate
    return None


def _as_text(value: object) -> str | None:
    if value is None:
        return None
    if isinstance(value, bytes):
        text = value.decode("utf-8", errors="replace")
    else:
        text = str(value)

    stripped = text.strip()
    if not stripped:
        return None
    return stripped


def _mailto_to_email(value: str | None) -> str | None:
    if value is None:
        return None
    lower_value = value.casefold()
    if lower_value.startswith("mailto:"):
        return value[7:]
    return value


def _first_present(*values: str | None) -> str | None:
    for value in values:
        if value is not None:
            return value
    return None
