from __future__ import annotations

from datetime import date, datetime

from calprint.model import CalendarSummary, EventSummary, TemporalValue


def render_calendar(calendar: CalendarSummary) -> str:
    lines = [
        "Calendar",
        f"  Name: {_render_text(calendar.name)}",
        f"  Version: {_render_text(calendar.version)}",
        f"  Product ID: {_render_text(calendar.product_id)}",
        f"  Method: {_render_text(calendar.method)}",
        f"  Timezones: {_render_timezones(calendar.timezones)}",
        f"  Events: {len(calendar.events)}",
    ]

    for index, event in enumerate(calendar.events, start=1):
        lines.extend(["", *_render_event(index, event)])

    return "\n".join(lines)


def _render_event(index: int, event: EventSummary) -> list[str]:
    return [
        f"Event {index}",
        f"  Summary: {_render_text(event.summary)}",
        f"  Start: {_render_temporal(event.start)}",
        f"  End: {_render_temporal(event.end)}",
        f"  UID: {_render_text(event.uid)}",
        f"  Organizer: {_render_text(event.organizer)}",
        f"  Attendees: {_render_attendees(event)}",
        f"  Location: {_render_text(event.location)}",
        f"  Status: {_render_text(event.status)}",
    ]


def _render_attendees(event: EventSummary) -> str:
    if event.attendees:
        return ", ".join(event.attendees)
    if event.attendee_count:
        attendee_label = "attendee" if event.attendee_count == 1 else "attendees"
        return f"{event.attendee_count} {attendee_label}"
    return "-"


def _render_temporal(value: TemporalValue | None) -> str:
    if value is None:
        return "-"
    if isinstance(value, datetime):
        if value.tzinfo is not None:
            timezone_name = value.tzname() or value.strftime("%z")
            return f"{value.strftime('%Y-%m-%d %H:%M')} {timezone_name}"
        return value.strftime("%Y-%m-%d %H:%M")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    return "-"


def _render_text(value: str | None) -> str:
    if value is None:
        return "-"
    return value


def _render_timezones(timezones: tuple[str, ...]) -> str:
    if not timezones:
        return "-"
    return ", ".join(timezones)
