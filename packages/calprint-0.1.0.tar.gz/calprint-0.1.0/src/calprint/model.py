from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime

type TemporalValue = date | datetime


@dataclass(frozen=True, slots=True)
class EventSummary:
    summary: str | None
    start: TemporalValue | None
    end: TemporalValue | None
    uid: str | None
    organizer: str | None
    attendees: tuple[str, ...]
    attendee_count: int
    location: str | None
    status: str | None


@dataclass(frozen=True, slots=True)
class CalendarSummary:
    version: str | None
    product_id: str | None
    method: str | None
    name: str | None
    timezones: tuple[str, ...]
    events: tuple[EventSummary, ...]
