from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path

from calprint import __version__
from calprint.parser import ParseError, parse_calendar
from calprint.render import render_calendar


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="calprint",
        description="Print a human-readable summary of an iCalendar (.ics) file.",
    )
    parser.add_argument("calendar", help="Path to the .ics file to inspect.")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    args = parser.parse_args(argv)

    calendar_path = Path(args.calendar)

    try:
        data = calendar_path.read_bytes()
    except OSError as exc:
        print(f"Error: could not read '{calendar_path}': {exc}", file=sys.stderr)
        return 1

    try:
        calendar = parse_calendar(data)
    except ParseError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(render_calendar(calendar))
    return 0
