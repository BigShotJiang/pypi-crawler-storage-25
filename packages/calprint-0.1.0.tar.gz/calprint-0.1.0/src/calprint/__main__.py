from calprint.cli import main

raise SystemExit(main())
