# AssistAgro API Client

Асинхронный HTTP-клиент для AssistAgro API.

## Установка

```bash
pip install assistagro-client
```

## Использование

```python
import asyncio
from assistagro_client import AssistAgroClient

async def main():
    async with AssistAgroClient(base_url="https://dev-gateway-frontend.agroassist.ru") as client:
        tokens = await client.auth.sign_in(
            email="user@example.com",
            password="password123"
        )
        print(f"Access token: {tokens.access_token[:20]}...")

        fields = await client.fields.list_()
        print(f"Найдено полей: {len(fields)}")

        tasks = await client.tasks.list_(limit=10)
        print(f"Найдено задач: {len(tasks)}")

if __name__ == "__main__":
    asyncio.run(main())
```

## API эндпоинты

- **auth** - Аутентификация (sign_in, refresh_tokens, logout)
- **accounts** - Профили пользователей и аккаунты
- **companies** - Управление компаниями
- **fields** - Поля и контуры
- **tasks** - Управление задачами
- **techmaps** - Технологические карты
- **reports** - Отчёты
- **dictionaries** - Справочники (культуры, пестициды и т.д.)
- **meteostations** - Метеостанции
- **structures** - Структуры

## Примеры

```bash
# Запустить все примеры
uv run python examples/run_tests.py

# Запустить конкретный модуль
uv run python examples/run_tests.py --module structures
uv run python examples/run_tests.py -m auth

# Доступные модули: auth, structures, companies, current_user, users,
# dictionaries, meteostations, tasks, fields, techmaps

# Базовый пример использования
uv run python examples/basic_usage.py

# Полный пример со всеми возможностями
uv run python examples/full_example.py
```

Требуется файл `.env` с переменными:
- `ASSISTAGRO_EMAIL`
- `ASSISTAGRO_PASSWORD`

## Разработка

```bash
# Установить зависимости
uv sync

# Запустить тесты
uv run pytest

# Запустить линтер
uv run ruff check .
```

## Лицензия

MIT
