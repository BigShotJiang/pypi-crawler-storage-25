"""Tasks models."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Task(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    guid: UUID
    task_ext_id: str | None = None
    season_id: int | None = None
    priority_id: int | None = None
    entity_guid: UUID | None = None
    entity_type: str | None = None
    status_id: int | None = None
    name: str | None = None
    description: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class TaskCreateRequest(BaseModel):
    season_id: int
    priority_id: int
    entity_data: dict
    datetimes: dict
    history: list[dict]
