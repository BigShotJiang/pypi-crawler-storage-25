"""Meteostations models."""

from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Meteostation(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    guid: UUID
    name: str
    latitude: float | None = None
    longitude: float | None = None
