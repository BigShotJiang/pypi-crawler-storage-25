"""Companies models."""

from datetime import date
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class License(BaseModel):
    begin_date: date
    end_date: date
    modules: list[int]


class Company(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    company_guid: UUID
    company_ext_id: str | None = None
    name: str | None = None
    inn: str | None = None
    user_count: int = 0
    active_flag: bool = True
    license: License | None = None
