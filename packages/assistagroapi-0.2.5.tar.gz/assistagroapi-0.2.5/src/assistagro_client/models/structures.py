"""Structures models."""

from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Structure(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    structure_guid: UUID
    structure_ext_id: str | None = None
    name: str
    company_guid: UUID | None = None
    area_fact_hectare: float | None = None
    superfield_count: int | None = None
    region_id: int | None = None
    structure_parent_guid: UUID | None = None
    structure_parent_ext_id: str | None = None
    inn: str | None = None
    active_flag: bool = True
