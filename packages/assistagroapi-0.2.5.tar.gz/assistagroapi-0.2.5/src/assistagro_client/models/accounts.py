"""Accounts models."""

from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Company(BaseModel):
    guid: UUID
    name: str
    parent_guid: UUID | None = None


class UserProfile(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    company: Company
    user_guid: UUID
    permissions: str
    is_current: bool
    is_confirmed: bool
