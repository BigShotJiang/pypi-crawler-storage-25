"""Seasons models."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class Season(BaseModel):
    """Season model."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    season_id: int = Field(alias="id")
    is_current: bool | None = None
    name: str | None = None
    ext_id: str | None = None
    from_year: int | None = None
    to_year: int | None = None
    from_date: str | None = None
    to_date: str | None = None
    author_guid: str | None = None
    editor_guid: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class SeasonsResponse(BaseModel):
    """Response from GET /system/seasons."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    season_changer_type_id: int | None = None
    seasons: list[Season] = []
