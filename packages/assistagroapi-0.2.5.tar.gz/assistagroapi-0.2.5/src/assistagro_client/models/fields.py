"""Fields models."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class FieldContour(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    contour_guid: UUID | None = None
    field_guid: UUID | None = None
    superfield_guid: UUID | None = None
    contour: str | None = None
    area_fact_hectare: float | None = None
    area_etalon_hectare: float | None = None
    start_datetime: datetime | None = None
    author_guid: UUID | None = None
    editor_guid: UUID | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class FieldListItem(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    field_guid: UUID | None = None
    field_ext_id: str | None = None
    field_name: str | None = None
    company_guid: UUID | None = None
    area_fact_hectare: float | None = None
    area_etalon_hectare: float | None = None
