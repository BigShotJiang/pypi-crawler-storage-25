"""Reports models."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel


class Report(BaseModel):
    guid: UUID
    task_guid: UUID | None = None
    season_id: int
    entity_guid: UUID | None = None
    entity_type: str | None = None
    status_id: int
    name: str
    created_at: datetime
    updated_at: datetime


class ReportCreateRequest(BaseModel):
    task_guid: UUID | None = None
    season_id: int
    entity_guid: UUID | None = None
    entity_type: str | None = None
    entity_data: dict[str, Any]
    datetimes: dict
    history: list[dict]
