"""Techmaps models."""

from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class TechmapOperation(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    techoperation_guid: UUID | None = None
    begin_date: date | None = None
    end_date: date | None = None
    name: str | None = None


class Techmap(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    guid: UUID | None = None
    season_id: int | None = None
    crop_id: int | None = None
    structure_guid: UUID | None = None
    name: str | None = None
    technology: str | None = None
    techoperations: list[TechmapOperation] | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class TechmapCreateRequest(BaseModel):
    season_id: int
    crop_id: int
    structure_guid: UUID
    name: str
    technology: str | None = None
    techoperations: list[dict]
