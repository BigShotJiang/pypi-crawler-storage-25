"""Main async client for AssistAgro API."""

from __future__ import annotations

import logging
import httpx
from typing import Any, TYPE_CHECKING

from .config import settings
from .exceptions import APIError, TimeoutError, AssistAgroError
from .auth import Auth, AuthTokens

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from .api.v1.accounts import AccountsAPI
    from .api.v1.companies import CompaniesAPI
    from .api.v1.fields import FieldsAPI
    from .api.v1.tasks import TasksAPI
    from .api.v1.techmaps import TechmapsAPI
    from .api.v1.reports import ReportsAPI
    from .api.v1.dictionaries import DictionariesAPI
    from .api.v1.meteostations import MeteostationsAPI
    from .api.v1.structures import StructuresAPI
    from .api.v1.seasons import SeasonsAPI


class AssistAgroClient:
    """Async HTTP client for AssistAgro API."""

    def __init__(
        self,
        base_url: str | None = None,
        timeout: int | None = None,
        token: str | None = None,
        debug: bool | None = None,
    ):
        self.base_url = base_url or settings.base_url
        self.timeout = timeout or settings.timeout
        self._token = token
        self._debug = debug if debug is not None else settings.debug
        self._user_data: dict[str, Any] = {}
        self._permissions: list[str] = []
        self._client: httpx.AsyncClient | None = None
        self._auth: Auth | None = None
        self._auth_tokens: AuthTokens | None = None
        self._accounts: AccountsAPI | None = None
        self._companies: CompaniesAPI | None = None
        self._fields: FieldsAPI | None = None
        self._tasks: TasksAPI | None = None
        self._techmaps: TechmapsAPI | None = None
        self._reports: ReportsAPI | None = None
        self._dictionaries: DictionariesAPI | None = None
        self._meteostations: MeteostationsAPI | None = None
        self._structures: StructuresAPI | None = None
        self._seasons: SeasonsAPI | None = None

    @property
    def token(self) -> str | None:
        return self._token

    @token.setter
    def token(self, value: str | None) -> None:
        self._token = value

    def set_user_data(self, user_data: dict[str, Any]) -> None:
        self._user_data = user_data

    def set_permissions(self, permissions: list[str]) -> None:
        self._permissions = permissions

    @property
    def auth(self) -> Auth:
        if self._auth is None:
            self._auth = Auth(self)
        return self._auth

    def set_auth_tokens(self, tokens: AuthTokens) -> None:
        self._auth_tokens = tokens
        self._token = tokens.access_token

    @property
    def accounts(self) -> AccountsAPI:
        if self._accounts is None:
            from .api.v1.accounts import AccountsAPI

            self._accounts = AccountsAPI(self)
        return self._accounts

    @property
    def companies(self) -> CompaniesAPI:
        if self._companies is None:
            from .api.v1.companies import CompaniesAPI

            self._companies = CompaniesAPI(self)
        return self._companies

    @property
    def fields(self) -> FieldsAPI:
        if self._fields is None:
            from .api.v1.fields import FieldsAPI

            self._fields = FieldsAPI(self)
        return self._fields

    @property
    def tasks(self) -> TasksAPI:
        if self._tasks is None:
            from .api.v1.tasks import TasksAPI

            self._tasks = TasksAPI(self)
        return self._tasks

    @property
    def techmaps(self) -> TechmapsAPI:
        if self._techmaps is None:
            from .api.v1.techmaps import TechmapsAPI

            self._techmaps = TechmapsAPI(self)
        return self._techmaps

    @property
    def reports(self) -> ReportsAPI:
        if self._reports is None:
            from .api.v1.reports import ReportsAPI

            self._reports = ReportsAPI(self)
        return self._reports

    @property
    def dictionaries(self) -> DictionariesAPI:
        if self._dictionaries is None:
            from .api.v1.dictionaries import DictionariesAPI

            self._dictionaries = DictionariesAPI(self)
        return self._dictionaries

    @property
    def meteostations(self) -> MeteostationsAPI:
        if self._meteostations is None:
            from .api.v1.meteostations import MeteostationsAPI

            self._meteostations = MeteostationsAPI(self)
        return self._meteostations

    @property
    def structures(self) -> StructuresAPI:
        if self._structures is None:
            from .api.v1.structures import StructuresAPI

            self._structures = StructuresAPI(self)
        return self._structures

    @property
    def seasons(self) -> SeasonsAPI:
        if self._seasons is None:
            from .api.v1.seasons import SeasonsAPI

            self._seasons = SeasonsAPI(self)
        return self._seasons

    def _get_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {
            "Content-Type": "application/json",
        }
        if self._token:
            headers["x-token"] = self._token
        if self._user_data:
            headers["x-user-data"] = str(self._user_data)
        if self._permissions:
            headers["x-permissions"] = ",".join(self._permissions)
        return headers

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
            )
        return self._client

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "AssistAgroClient":
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    async def request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make HTTP request."""
        client = await self._get_client()

        # Merge custom headers with auth headers
        request_headers = self._get_headers()
        if "headers" in kwargs:
            request_headers.update(kwargs.pop("headers"))

        try:
            if self._debug:
                logger.debug(f"Request: {method} {path}")
            response = await client.request(
                method=method,
                url=path,
                headers=request_headers,
                **kwargs,
            )
            if self._debug:
                logger.debug(
                    f"Response: {response.status_code} {response.text[:200] if response.text else 'empty'}"
                )
            if response.status_code >= 400:
                logger.warning(f"API Error {response.status_code}: {response.text}")
                raise APIError(
                    message=response.text or response.reason_phrase,
                    status_code=response.status_code,
                )
            return response
        except httpx.TimeoutException as e:
            raise TimeoutError(f"Request to {path} timed out") from e
        except httpx.HTTPError as e:
            raise AssistAgroError(f"HTTP error: {e}") from e

    def _parse_json_response(self, response: httpx.Response) -> Any:
        """Parse JSON response, handling empty responses."""
        if not response.content:
            return []
        return response.json()

    async def get(self, path: str, **kwargs: Any) -> httpx.Response:
        """GET request."""
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> httpx.Response:
        """POST request."""
        return await self.request("POST", path, **kwargs)

    async def put(self, path: str, **kwargs: Any) -> httpx.Response:
        """PUT request."""
        return await self.request("PUT", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        """DELETE request."""
        return await self.request("DELETE", path, **kwargs)
