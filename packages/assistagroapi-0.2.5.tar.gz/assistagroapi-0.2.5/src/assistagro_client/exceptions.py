"""Custom exceptions."""


class AssistAgroError(Exception):
    """Base exception for AssistAgro client."""

    pass


class AuthenticationError(AssistAgroError):
    """Raised when authentication fails."""

    pass


class APIError(AssistAgroError):
    """Raised when API returns an error."""

    def __init__(self, message: str, status_code: int):
        self.status_code = status_code
        super().__init__(message)


class TimeoutError(AssistAgroError):
    """Raised when request times out."""

    pass
