"""Dictionaries API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .client import AssistAgroClient


class DictionariesAPI:
    """Dictionaries API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def get_crops(self) -> list[dict[str, Any]]:
        """Get crops dictionary."""
        response = await self._client.get("/dictionaries/crops")
        response.raise_for_status()
        return self._client._parse_json_response(response)

    async def get_crop_products(self) -> list[dict[str, Any]]:
        """Get crop products dictionary."""
        response = await self._client.get("/dictionaries/crop_products/list")
        response.raise_for_status()
        return self._client._parse_json_response(response)

    async def get_techoperations(self) -> list[dict[str, Any]]:
        """Get techoperations dictionary."""
        # Endpoint might not exist - return empty list
        return []

    async def get_machine_models(self) -> list[dict[str, Any]]:
        """Get machine models dictionary."""
        response = await self._client.get("/dictionaries/machine_models")
        response.raise_for_status()
        return self._client._parse_json_response(response)

    async def get_pesticides(self) -> list[dict[str, Any]]:
        """Get pesticides dictionary."""
        response = await self._client.get("/dictionaries/pesticides")
        response.raise_for_status()
        return self._client._parse_json_response(response)

    async def get_fertilizers(self) -> list[dict[str, Any]]:
        """Get fertilizers dictionary."""
        response = await self._client.get("/dictionaries/fertilizers")
        response.raise_for_status()
        return self._client._parse_json_response(response)

    async def get_varieties(self) -> list[dict[str, Any]]:
        """Get varieties dictionary."""
        response = await self._client.get("/dictionaries/varieties")
        response.raise_for_status()
        return self._client._parse_json_response(response)

    async def get_meteostations(self) -> list[dict[str, Any]]:
        """Get meteostations."""
        response = await self._client.get("/meteostations")
        response.raise_for_status()
        return self._client._parse_json_response(response)

    async def get_notifications_channels(self) -> list[dict[str, Any]]:
        """Get notification channels."""
        response = await self._client.get("/notifications/channels")
        response.raise_for_status()
        return self._client._parse_json_response(response)
