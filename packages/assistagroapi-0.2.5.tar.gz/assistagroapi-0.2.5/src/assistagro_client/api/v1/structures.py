"""Structures API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

from assistagro_client.models.structures import Structure

if TYPE_CHECKING:
    from assistagro_client.client import AssistAgroClient


class StructuresAPI:
    """Structures API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def list_(self) -> list[Structure]:
        """List structures."""
        response = await self._client.get("/structures/list")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, dict) and "structures" in data:
            structures_data = data["structures"]
        else:
            structures_data = data if data else []
        return (
            [Structure(**item) for item in structures_data] if structures_data else []
        )
