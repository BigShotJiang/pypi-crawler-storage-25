"""Accounts API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from assistagro_client.models.accounts import UserProfile

if TYPE_CHECKING:
    from assistagro_client.client import AssistAgroClient


class AccountsAPI:
    """Accounts API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def get_users(self, account_guid: UUID | None = None) -> list[UserProfile]:
        """Get user profiles."""
        params = {}
        if account_guid:
            params["account_guid"] = str(account_guid)
        response = await self._client.get("/account/users", params=params)
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return [UserProfile(**item) for item in data] if data else []

    async def get_current_user(self) -> dict:
        """Get current user info."""
        response = await self._client.get("/account/users/current")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return data if data else {}

    async def get_user(self, user_guid: UUID) -> dict:
        """Get user by GUID."""
        response = await self._client.get(f"/account/users/{user_guid}")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return data if data else {}
