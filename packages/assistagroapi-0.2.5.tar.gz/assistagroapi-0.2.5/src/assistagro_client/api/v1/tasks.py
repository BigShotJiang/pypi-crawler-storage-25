"""Tasks API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from assistagro_client.models.tasks import Task

if TYPE_CHECKING:
    from assistagro_client.client import AssistAgroClient


class TasksAPI:
    """Tasks API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def create(
        self,
        season_id: int,
        priority_id: int,
        entity_data: dict,
        datetimes: dict,
        history: list[dict],
        task_ext_id: str | None = None,
        check_deleted_objects: bool = True,
    ) -> Task:
        """Create a task."""
        params = {}
        if not check_deleted_objects:
            params["check_deleted_objects"] = "false"
        response = await self._client.post(
            "/tasks",
            params=params,
            json={
                "season_id": season_id,
                "priority_id": priority_id,
                "entity_data": entity_data,
                "datetimes": datetimes,
                "history": history,
                "task_ext_id": task_ext_id,
            },
        )
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return Task(**data) if data else None

    async def list_(
        self,
        structure_guid: UUID | None = None,
        superfield_guid: UUID | None = None,
        limit: int = 100,
        offset: int = 0,
        season_id: int | None = None,
        status_id: int | None = None,
    ) -> list[Task]:
        """List tasks with filters.

        Args:
            structure_guid: Filter by structure GUID.
            superfield_guid: Filter by superfield GUID.
            limit: Maximum number of results.
            offset: Offset for pagination.
            season_id: Filter by season ID.
            status_id: Filter by status ID.
        """
        params = {"limit": limit, "offset": offset}
        if structure_guid:
            params["structure_guid"] = str(structure_guid)
        if superfield_guid:
            params["superfield_guid"] = str(superfield_guid)
        if season_id:
            params["season_id"] = season_id
        if status_id:
            params["status_id"] = status_id
        response = await self._client.get("/tasks/list", params=params)
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, list):
            return (
                [Task(**item) for item in data if isinstance(item, dict)]
                if data
                else []
            )
        return []

    async def get_statuses(self) -> list[dict]:
        """Get available task statuses."""
        # Endpoint might not exist - return empty list
        return []
