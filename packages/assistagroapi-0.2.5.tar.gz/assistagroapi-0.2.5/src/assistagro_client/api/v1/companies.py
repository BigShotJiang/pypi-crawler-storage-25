"""Companies API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

from assistagro_client.models.companies import Company

if TYPE_CHECKING:
    from assistagro_client.client import AssistAgroClient


class CompaniesAPI:
    """Companies API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def list_(self) -> list[Company]:
        """Get current user's company.

        Returns the company associated with the authenticated user.
        """
        response = await self._client.get("/account/users/current")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, dict) and "company" in data:
            company_data = data["company"]
            return [Company(**company_data)] if company_data else []
        return []
