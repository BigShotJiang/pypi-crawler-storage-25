"""System API endpoints (seasons, etc.)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from assistagro_client.models.seasons import Season, SeasonsResponse

if TYPE_CHECKING:
    from assistagro_client.client import AssistAgroClient


class SeasonsAPI:
    """System/Seasons API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def list(self) -> list[Season]:
        """Get all seasons.

        Returns:
            List of seasons.
        """
        response = await self._client.get("/system/seasons")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, dict):
            parsed = SeasonsResponse(**data)
            return parsed.seasons
        return []

    async def get_current(self) -> Season | None:
        """Get current season.

        Returns:
            Current season or None.
        """
        seasons = await self.list()
        for season in seasons:
            if season.is_current is True:
                return season
        return None

    async def get_by_year(self, year: int) -> Season | None:
        """Get season by year.

        Searches for a season where from_year == year (the calendar year the season covers).

        Args:
            year: The year to search for.

        Returns:
            Matching season or None.
        """
        seasons = await self.list()
        for season in seasons:
            if season.from_year == year:
                return season
        return None

    async def get_season_id_by_year(self, year: int) -> int | None:
        """Get season_id by year.

        Args:
            year: The year to search for.

        Returns:
            season_id or None if not found.
        """
        season = await self.get_by_year(year)
        return season.season_id if season else None

    async def get_by_name(self, name: str) -> Season | None:
        """Get season by name.

        Args:
            name: The season name to search for.

        Returns:
            Matching season or None.
        """
        seasons = await self.list()
        for season in seasons:
            if season.name == name:
                return season
        return None

    async def get_season_id_by_name(self, name: str) -> int | None:
        """Get season_id by name.

        Args:
            name: The season name to search for.

        Returns:
            season_id or None if not found.
        """
        season = await self.get_by_name(name)
        return season.season_id if season else None
