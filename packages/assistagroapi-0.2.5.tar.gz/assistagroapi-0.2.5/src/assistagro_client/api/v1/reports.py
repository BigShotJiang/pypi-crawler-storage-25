"""Reports API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from uuid import UUID

from assistagro_client.models.reports import Report

if TYPE_CHECKING:
    from assistagro_client.client import AssistAgroClient


class ReportsAPI:
    """Reports API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def create(
        self,
        season_id: int,
        entity_data: dict[str, Any],
        datetimes: dict,
        history: list[dict],
        task_guid: UUID | None = None,
        entity_guid: UUID | None = None,
        entity_type: str | None = None,
    ) -> Report:
        """Create a report."""
        response = await self._client.post(
            "/reports",
            json={
                "task_guid": str(task_guid) if task_guid else None,
                "season_id": season_id,
                "entity_guid": str(entity_guid) if entity_guid else None,
                "entity_type": entity_type,
                "entity_data": entity_data,
                "datetimes": datetimes,
                "history": history,
            },
        )
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return Report(**data) if data else None
