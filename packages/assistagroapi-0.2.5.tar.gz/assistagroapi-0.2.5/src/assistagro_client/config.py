"""Configuration settings."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ASSISTAGRO_")

    base_url: str = "https://gateway-frontend.agroassist.ru"
    timeout: int = 30
    debug: bool = False


settings = Settings()
