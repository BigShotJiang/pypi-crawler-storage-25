"""Tests for Auth module."""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from assistagro_client import AssistAgroClient, AuthTokens, AuthenticationError


@pytest.mark.asyncio
async def test_sign_in_success():
    client = AssistAgroClient()
    client._client = AsyncMock()

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "access_token": "test_access_token",
        "access_token_expires_in": 3600,
        "refresh_token": "test_refresh_token",
        "refresh_token_expires_in": 86400,
        "superset_token": "test_superset_token",
        "superset_token_expires_in": 3600,
    }

    with patch.object(client, "post", return_value=mock_response):
        tokens = await client.auth.sign_in("test@test.com", "password123")
        assert isinstance(tokens, AuthTokens)
        assert tokens.access_token == "test_access_token"
        assert client.token == "test_access_token"


@pytest.mark.asyncio
async def test_sign_in_invalid_credentials():
    client = AssistAgroClient()
    client._client = AsyncMock()

    mock_response = MagicMock()
    mock_response.status_code = 401

    with patch.object(client, "post", return_value=mock_response):
        with pytest.raises(AuthenticationError):
            await client.auth.sign_in("test@test.com", "wrong_password")


@pytest.mark.asyncio
async def test_sign_in_2fa_enabled():
    client = AssistAgroClient()
    client._client = AsyncMock()

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "session_guid": "test-session-guid",
        "attempts": 0,
        "max_attempts": 5,
        "expires_at": "2024-07-09T17:00:00.435",
        "next_request_available_at": "2024-07-09T17:00:00.435",
        "code_request": 0,
        "max_code_request": 5,
    }

    with patch.object(client, "post", return_value=mock_response):
        result = await client.auth.sign_in("test@test.com", "password123")
        assert hasattr(result, "session_guid")
        assert result.session_guid == "test-session-guid"


@pytest.mark.asyncio
async def test_refresh_tokens():
    client = AssistAgroClient()
    client._client = AsyncMock()

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "access_token": "new_access_token",
        "access_token_expires_in": 3600,
        "refresh_token": "new_refresh_token",
        "refresh_token_expires_in": 86400,
        "superset_token": None,
        "superset_token_expires_in": None,
    }

    with patch.object(client, "post", return_value=mock_response):
        tokens = await client.auth.refresh_tokens("old_refresh_token")
        assert tokens.access_token == "new_access_token"


@pytest.mark.asyncio
async def test_refresh_tokens_invalid():
    client = AssistAgroClient()
    client._client = AsyncMock()

    mock_response = MagicMock()
    mock_response.status_code = 401

    with patch.object(client, "post", return_value=mock_response):
        with pytest.raises(AuthenticationError):
            await client.auth.refresh_tokens("invalid_token")


@pytest.mark.asyncio
async def test_logout():
    client = AssistAgroClient(token="test_token")
    client._client = AsyncMock()

    mock_response = MagicMock()
    mock_response.status_code = 200

    with patch.object(client, "post", return_value=mock_response):
        await client.auth.logout()
        assert client.token is None
