"""Tests for AssistAgro client."""

import pytest

from assistagro_client import AssistAgroClient


@pytest.mark.asyncio
async def test_client_initialization():
    client = AssistAgroClient(base_url="https://test.example.com", timeout=60)
    assert client.base_url == "https://test.example.com"
    assert client.timeout == 60
    assert client.token is None


@pytest.mark.asyncio
async def test_client_with_token():
    client = AssistAgroClient(token="test_token")
    assert client.token == "test_token"


@pytest.mark.asyncio
async def test_set_auth_tokens():
    from assistagro_client import AuthTokens

    client = AssistAgroClient()
    tokens = AuthTokens(
        access_token="test_access",
        access_token_expires_in=3600,
        refresh_token="test_refresh",
        refresh_token_expires_in=86400,
    )
    client.set_auth_tokens(tokens)
    assert client.token == "test_access"


@pytest.mark.asyncio
async def test_set_user_data():
    client = AssistAgroClient()
    user_data = {"company_guid": "test-company-guid"}
    client.set_user_data(user_data)
    assert client._user_data == user_data


@pytest.mark.asyncio
async def test_set_permissions():
    client = AssistAgroClient()
    permissions = ["read", "write"]
    client.set_permissions(permissions)
    assert client._permissions == permissions


@pytest.mark.asyncio
async def test_get_headers_without_token():
    client = AssistAgroClient()
    headers = client._get_headers()
    assert headers["Content-Type"] == "application/json"
    assert "x-token" not in headers


@pytest.mark.asyncio
async def test_get_headers_with_token():
    client = AssistAgroClient(token="test_token")
    headers = client._get_headers()
    assert headers["x-token"] == "test_token"


@pytest.mark.asyncio
async def test_auth_property():
    client = AssistAgroClient()
    auth = client.auth
    assert auth is not None
    assert auth._client is client


@pytest.mark.asyncio
async def test_context_manager():
    async with AssistAgroClient() as client:
        assert client._client is None
    assert client._client is None
