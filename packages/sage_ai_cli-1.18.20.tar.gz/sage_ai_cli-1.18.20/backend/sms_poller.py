"""
SAGE central SMS/message bridge — server-side.

SAGE owns a single bridge email address (configured via env vars).
Users message that address from iMessage or Gmail.
The backend receives the email, authenticates the sender against
their registered contacts, and routes the task to the right CLI
session via WebSocket.

Environment variables (set in Cloud Run):
  SAGE_BRIDGE_EMAIL          — e.g. message@sageworksai.com
  SAGE_BRIDGE_APP_PASSWORD   — Gmail/iCloud app password for that account
  SAGE_BRIDGE_IMAP_HOST      — default: imap.gmail.com
  SAGE_BRIDGE_SMTP_HOST      — default: smtp.gmail.com
  SAGE_BRIDGE_SMTP_PORT      — default: 587
  SAGE_BRIDGE_DISPLAY_EMAIL  — shown to users, defaults to SAGE_BRIDGE_EMAIL

The CLI never touches email.  It opens a WebSocket to /ws/sms,
authenticates with its SAGE token, and waits for tasks.
"""

from __future__ import annotations

import asyncio
import email as _email_mod
import email.utils
import imaplib
import logging
import os
import re
import smtplib
import time
from email.mime.text import MIMEText
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import WebSocket

logger = logging.getLogger("sage.sms_poller")

# ── Configuration from environment ────────────────────────────────────────────

BRIDGE_EMAIL       = os.environ.get("SAGE_BRIDGE_EMAIL",         "messages@sageworksai.com")
BRIDGE_PASSWORD    = os.environ.get("SAGE_BRIDGE_APP_PASSWORD",  "")
BRIDGE_IMAP_HOST   = os.environ.get("SAGE_BRIDGE_IMAP_HOST",     "imap.gmail.com")
BRIDGE_SMTP_HOST   = os.environ.get("SAGE_BRIDGE_SMTP_HOST",     "smtp.gmail.com")
BRIDGE_SMTP_PORT   = int(os.environ.get("SAGE_BRIDGE_SMTP_PORT", "587"))
# Address shown to users — defaults to the bridge email itself
DISPLAY_EMAIL      = os.environ.get("SAGE_BRIDGE_DISPLAY_EMAIL", BRIDGE_EMAIL)

# ── Active CLI WebSocket sessions ──────────────────────────────────────────────
# { uid: { computer_name: WebSocket } }
_cli_sessions: dict[str, dict[str, "WebSocket"]] = {}

# Pending task replies: { task_id: asyncio.Future }
_pending: dict[str, "asyncio.Future[str]"] = {}


def register_cli_session(uid: str, computer_name: str, ws: "WebSocket") -> None:
    _cli_sessions.setdefault(uid, {})[computer_name.lower()] = ws
    logger.info("CLI connected: uid=%s computer=%s", uid, computer_name)


def unregister_cli_session(uid: str, computer_name: str) -> None:
    user_sessions = _cli_sessions.get(uid, {})
    user_sessions.pop(computer_name.lower(), None)
    if not user_sessions:
        _cli_sessions.pop(uid, None)
    logger.info("CLI disconnected: uid=%s computer=%s", uid, computer_name)


def get_online_computers(uid: str) -> list[str]:
    return list(_cli_sessions.get(uid, {}).keys())


async def dispatch_to_cli(
    uid: str,
    computer_name: str | None,
    task_id: str,
    task: str,
    from_addr: str,
) -> str | None:
    """
    Send a task to a CLI session and await the result.
    Returns the output string, or None if no session is available.
    """
    user_sessions = _cli_sessions.get(uid, {})
    if not user_sessions:
        return None

    # Route: specific computer, @all, or first available
    if computer_name == "all":
        targets = list(user_sessions.values())
    elif computer_name and computer_name in user_sessions:
        targets = [user_sessions[computer_name]]
    elif computer_name and computer_name not in user_sessions:
        return f"❌ [{computer_name}] is not online. Online: {', '.join(user_sessions) or 'none'}"
    else:
        targets = [next(iter(user_sessions.values()))]  # first available

    loop = asyncio.get_event_loop()
    futures: list["asyncio.Future[str]"] = []
    for ws in targets:
        fut: asyncio.Future[str] = loop.create_future()
        _pending[task_id] = fut
        try:
            await ws.send_json({
                "type": "task",
                "task_id": task_id,
                "task": task,
                "from": from_addr,
            })
            futures.append(fut)
        except Exception as exc:
            logger.warning("Could not send task to CLI: %s", exc)
            _pending.pop(task_id, None)

    if not futures:
        return None

    try:
        # Wait up to 3 minutes for the CLI to respond
        results = await asyncio.wait_for(
            asyncio.gather(*futures, return_exceptions=True),
            timeout=180,
        )
        outputs = [r for r in results if isinstance(r, str)]
        return "\n\n".join(outputs) if outputs else "Task completed."
    except asyncio.TimeoutError:
        _pending.pop(task_id, None)
        return "⏱ Task timed out (>3 min). Check your terminal for progress."


def resolve_task_result(task_id: str, output: str) -> None:
    """Called when a CLI WebSocket sends back a result."""
    fut = _pending.pop(task_id, None)
    if fut and not fut.done():
        fut.set_result(output)


# ── Email utilities ────────────────────────────────────────────────────────────

def _clean_body(raw: str) -> str:
    lines = raw.splitlines()
    clean: list[str] = []
    for line in lines:
        lower = line.strip().lower()
        if re.match(r'^on .{5,80} wrote:$', lower):
            break
        if lower.startswith(("--\n", "-- \n", ">>>", "from:", "sent:", "subject:")):
            break
        clean.append(line)
    return "\n".join(clean).strip()


def _parse_routing(text: str) -> tuple[str | None, str]:
    m = re.match(r'^@([\w\-]+)\s*[:：]\s*', text.strip())
    if m:
        return m.group(1).lower(), text[m.end():].strip()
    return None, text.strip()


def _chunk_text(text: str, max_chars: int = 1500) -> list[str]:
    if len(text) <= max_chars:
        return [text]
    chunks: list[str] = []
    paras = [p.strip() for p in re.split(r'\n{2,}', text) if p.strip()]
    current = ""
    for para in paras:
        candidate = (current + "\n\n" + para).strip() if current else para
        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current)
            if len(para) > max_chars:
                for i in range(0, len(para), max_chars - 20):
                    chunks.append(para[i:i + max_chars - 20])
                current = ""
            else:
                current = para
    if current:
        chunks.append(current)
    return chunks or [text[:max_chars]]


def send_reply(to_addr: str, text: str, computer_name: str = "SAGE") -> None:
    """Send a reply from the SAGE bridge email."""
    if not BRIDGE_EMAIL or not BRIDGE_PASSWORD:
        logger.warning("SAGE_BRIDGE_EMAIL not configured — cannot send reply")
        return
    chunks = _chunk_text(text)
    total = len(chunks)
    try:
        srv = smtplib.SMTP(BRIDGE_SMTP_HOST, BRIDGE_SMTP_PORT)
        srv.ehlo(); srv.starttls(); srv.ehlo()
        srv.login(BRIDGE_EMAIL, BRIDGE_PASSWORD)
        for i, chunk in enumerate(chunks):
            prefix = f"[{computer_name}] " + (f"({i+1}/{total}) " if total > 1 else "")
            msg = MIMEText(prefix + chunk)
            msg["From"] = f"SAGE AI <{DISPLAY_EMAIL or BRIDGE_EMAIL}>"
            msg["To"] = to_addr
            msg["Subject"] = "SAGE"
            srv.send_message(msg)
            if i < total - 1:
                time.sleep(0.4)
        srv.quit()
        logger.info("Replied to %s (%d parts)", to_addr, total)
    except Exception as exc:
        logger.error("SMTP reply failed: %s", exc)


# ── Inbound email handler ──────────────────────────────────────────────────────

async def handle_inbound_email(from_addr: str, body: str) -> None:
    """
    Process one inbound email: authenticate sender, route task to CLI, reply.
    Called from the IMAP poller loop.
    """
    from .sms_manager import find_user_by_contact_email

    from_addr = from_addr.lower().strip()
    body = _clean_body(body).strip()
    if not body:
        return

    # Look up SAGE user by sender email
    uid = find_user_by_contact_email(from_addr)
    if uid is None:
        logger.info("Ignored unregistered sender: %s", from_addr)
        # Don't reply — prevents spam/probing
        return

    target, task = _parse_routing(body)
    logger.info("Task from %s → [%s]: %s", from_addr, target or "any", task[:80])

    import uuid
    task_id = str(uuid.uuid4())
    online = get_online_computers(uid)

    if not online:
        send_reply(
            from_addr,
            "⚠️ No SAGE computers are currently online.\n"
            "Start the bridge on your computer with: sage sms start",
        )
        return

    output = await dispatch_to_cli(uid, target, task_id, task, from_addr)
    if output:
        # Determine which computer responded for the prefix
        computer_label = target if target and target != "all" else (online[0] if online else "SAGE")
        send_reply(from_addr, output, computer_name=computer_label)


# ── IMAP IDLE poller (runs as asyncio background task) ────────────────────────

async def run_imap_poller() -> None:
    """
    Persistent IMAP IDLE loop for the SAGE bridge inbox.
    Runs forever in the background; reconnects on failure.
    """
    if not BRIDGE_EMAIL or not BRIDGE_PASSWORD:
        logger.warning(
            "SAGE_BRIDGE_EMAIL / SAGE_BRIDGE_APP_PASSWORD not set — "
            "SMS bridge disabled. Set these in Cloud Run env vars."
        )
        return

    logger.info("SMS poller starting for %s", BRIDGE_EMAIL)
    reconnect_delay = 5

    while True:
        mail = None
        try:
            mail = await asyncio.to_thread(_imap_connect)
            reconnect_delay = 5
            logger.info("IMAP connected (%s)", BRIDGE_IMAP_HOST)

            # Drain any messages that arrived while disconnected
            await _drain_and_dispatch(mail)

            # IDLE loop
            while True:
                activity = await asyncio.to_thread(_imap_idle_wait, mail, 25)
                if activity:
                    await _drain_and_dispatch(mail)

        except asyncio.CancelledError:
            logger.info("SMS poller cancelled")
            return
        except Exception as exc:
            logger.warning("IMAP error: %s — reconnecting in %ds", exc, reconnect_delay)
            await asyncio.sleep(reconnect_delay)
            reconnect_delay = min(reconnect_delay * 2, 120)
        finally:
            if mail:
                try:
                    mail.logout()
                except Exception:
                    pass


def _imap_connect() -> imaplib.IMAP4_SSL:
    mail = imaplib.IMAP4_SSL(BRIDGE_IMAP_HOST)
    mail.login(BRIDGE_EMAIL, BRIDGE_PASSWORD)
    mail.select("INBOX")
    return mail


def _imap_idle_wait(mail: imaplib.IMAP4_SSL, timeout: int = 25) -> bool:
    """Send IMAP IDLE, block until notification or timeout. Returns True if activity."""
    try:
        tag = mail._new_tag().decode()
        mail.send(f"{tag} IDLE\r\n".encode())
        resp = mail.readline()
        if not resp.startswith(b"+"):
            mail.send(b"DONE\r\n")
            return False
        mail.sock.settimeout(timeout)
        try:
            line = mail.readline()
        except (OSError, TimeoutError):
            line = b""
        finally:
            mail.sock.settimeout(None)
        mail.send(b"DONE\r\n")
        mail.readline()  # consume tagged OK
        return bool(line and line.strip())
    except Exception:
        return False


async def _drain_and_dispatch(mail: imaplib.IMAP4_SSL) -> None:
    """Fetch all UNSEEN messages and dispatch each as a task."""
    messages = await asyncio.to_thread(_fetch_unseen, mail)
    for m in messages:
        asyncio.create_task(handle_inbound_email(m["from"], m["body"]))


def _fetch_unseen(mail: imaplib.IMAP4_SSL) -> list[dict]:
    results = []
    _, data = mail.search(None, "UNSEEN")
    ids = data[0].split() if data[0] else []
    for mid in ids:
        try:
            _, hdr = mail.fetch(mid, "(BODY.PEEK[HEADER.FIELDS (FROM)])")
            _, body_data = mail.fetch(mid, "(BODY.PEEK[TEXT])")
            # Mark read immediately — prevents double processing on reconnect
            mail.store(mid, "+FLAGS", "\\Seen")
            raw_hdr  = hdr[0][1]       if isinstance(hdr[0], tuple)       else b""
            raw_body = body_data[0][1] if isinstance(body_data[0], tuple) else b""
            msg      = _email_mod.message_from_bytes(raw_hdr + b"\r\n\r\n" + raw_body)
            from_addr = _email_mod.utils.parseaddr(msg.get("From", ""))[1].lower().strip()
            body_text = raw_body.decode("utf-8", errors="replace")
            if from_addr and body_text:
                results.append({"from": from_addr, "body": body_text})
        except Exception as exc:
            logger.warning("Failed to fetch message %s: %s", mid, exc)
    return results
