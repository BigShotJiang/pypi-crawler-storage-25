"""
Firestore operations for the SAGE SMS/message bridge.

Schema
------
users/{uid}/sms_computers/{computer_id}
    computer_id   : str   (slugified hostname + short uuid)
    computer_name : str   (human-readable, used for @name: routing)
    bridge_email  : str   (the Gmail/iCloud inbox SAGE polls)
    last_seen     : str   (ISO datetime, updated every heartbeat)
    registered_at : str   (ISO datetime)

users/{uid}/sms_contacts/{contact_id}
    email         : str   (sender email SAGE will accept — iCloud, Gmail, etc.)
    label         : str   (e.g. "iPhone", "Android")
    added_at      : str   (ISO datetime)

Security model
--------------
- Contacts are fetched by the CLI at startup and cached in memory.
- Only emails in the contact list can trigger tasks on any of the user's computers.
- Computer registration is tied to the SAGE login — no anonymous registration.
"""

from __future__ import annotations

import uuid
import re
from datetime import datetime, timezone
from typing import Any

import logging

logger = logging.getLogger(__name__)


def _get_db():
    try:
        import firebase_admin
        from firebase_admin import firestore as fs
        if not firebase_admin._apps:
            firebase_admin.initialize_app()
        return fs.client()
    except Exception as exc:
        logger.warning("Firestore unavailable: %s", exc)
        return None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _slug(name: str) -> str:
    """Normalize a name to a safe document ID segment."""
    return re.sub(r"[^a-z0-9\-]", "-", name.lower())[:40]


# ── Computers ──────────────────────────────────────────────────────────────────

def register_computer(uid: str, computer_name: str, bridge_email: str) -> dict:
    """
    Register or update a computer for a user.

    If a computer with the same name already exists for this user,
    update it in place (idempotent — safe to call on every `sage sms start`).
    Returns the computer document dict.
    """
    db = _get_db()
    if db is None:
        return _mock_computer(uid, computer_name, bridge_email)

    slug = _slug(computer_name)
    col = db.collection("users").document(uid).collection("sms_computers")

    # Check for existing record with same name
    existing = col.where("computer_name", "==", computer_name).limit(1).stream()
    for doc in existing:
        data = {**doc.to_dict(), "last_seen": _now(), "bridge_email": bridge_email}
        doc.reference.update({"last_seen": _now(), "bridge_email": bridge_email})
        return data

    # New registration
    computer_id = f"{slug}-{uuid.uuid4().hex[:8]}"
    data = {
        "computer_id":   computer_id,
        "computer_name": computer_name,
        "bridge_email":  bridge_email,
        "last_seen":     _now(),
        "registered_at": _now(),
    }
    col.document(computer_id).set(data)
    return data


def heartbeat_computer(uid: str, computer_name: str) -> None:
    """Update last_seen timestamp for a computer. Called every poll cycle."""
    db = _get_db()
    if db is None:
        return
    try:
        col = db.collection("users").document(uid).collection("sms_computers")
        for doc in col.where("computer_name", "==", computer_name).limit(1).stream():
            doc.reference.update({"last_seen": _now()})
    except Exception as exc:
        logger.debug("Heartbeat failed: %s", exc)


def list_computers(uid: str) -> list[dict]:
    db = _get_db()
    if db is None:
        return []
    try:
        return [
            doc.to_dict()
            for doc in db.collection("users").document(uid)
                          .collection("sms_computers").stream()
        ]
    except Exception as exc:
        logger.warning("list_computers failed: %s", exc)
        return []


def remove_computer(uid: str, computer_id: str) -> bool:
    db = _get_db()
    if db is None:
        return False
    try:
        db.collection("users").document(uid) \
          .collection("sms_computers").document(computer_id).delete()
        return True
    except Exception:
        return False


# ── Contacts ───────────────────────────────────────────────────────────────────

def _contact_doc_id(email: str) -> str:
    return email.lower().strip().replace("@", "_at_").replace(".", "_")


def add_contact(uid: str, email: str, label: str = "") -> dict:
    """
    Add an authorized sender contact.

    Writes to two places:
      users/{uid}/sms_contacts/{doc_id}  — user's contact list
      sms_contact_index/{doc_id}         — reverse lookup: email → uid (O(1), no index needed)
    """
    db = _get_db()
    email = email.lower().strip()
    doc_id = _contact_doc_id(email)
    data = {"email": email, "label": label or email, "added_at": _now()}
    if db is None:
        return data
    try:
        db.collection("users").document(uid) \
          .collection("sms_contacts").document(doc_id).set(data, merge=True)
        # Write reverse index so find_user_by_contact_email is a direct read
        db.collection("sms_contact_index").document(doc_id).set(
            {"uid": uid, "email": email, "updated_at": _now()}, merge=True
        )
    except Exception as exc:
        logger.warning("add_contact failed: %s", exc)
    return data


def list_contacts(uid: str) -> list[dict]:
    db = _get_db()
    if db is None:
        return []
    try:
        return [
            doc.to_dict()
            for doc in db.collection("users").document(uid)
                          .collection("sms_contacts").stream()
        ]
    except Exception as exc:
        logger.warning("list_contacts failed: %s", exc)
        return []


def remove_contact(uid: str, email: str) -> bool:
    db = _get_db()
    if db is None:
        return False
    doc_id = _contact_doc_id(email)
    try:
        db.collection("users").document(uid) \
          .collection("sms_contacts").document(doc_id).delete()
        db.collection("sms_contact_index").document(doc_id).delete()
        return True
    except Exception:
        return False


def get_contact_emails(uid: str) -> list[str]:
    """Return just the email strings for authorization checks."""
    return [c["email"] for c in list_contacts(uid) if c.get("email")]


def find_user_by_contact_email(email: str) -> str | None:
    """
    Look up which SAGE user registered this email as a contact.
    Uses a flat reverse-index collection for O(1) reads — no collection
    group query, no Firestore index required.
    """
    db = _get_db()
    if db is None:
        return None
    doc_id = _contact_doc_id(email)
    try:
        doc = db.collection("sms_contact_index").document(doc_id).get()
        if doc.exists:
            return doc.to_dict().get("uid")
    except Exception as exc:
        logger.warning("find_user_by_contact_email failed: %s", exc)
    return None


# ── Helpers ────────────────────────────────────────────────────────────────────

def _mock_computer(uid: str, name: str, bridge_email: str) -> dict:
    """Fallback when Firestore is unavailable."""
    return {
        "computer_id":   f"local-{_slug(name)}",
        "computer_name": name,
        "bridge_email":  bridge_email,
        "last_seen":     _now(),
        "registered_at": _now(),
    }
