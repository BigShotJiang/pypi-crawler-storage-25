# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2018-2026 BioInception PVT LTD
# Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
# See the NOTICE file for attribution, trademark, and algorithm IP terms.
"""
SMSD -- Substructure & Maximum Common Substructure search for chemical graphs.

Copyright (c) 2018-2026 BioInception PVT LTD
Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
Licensed under Apache 2.0.

Quick start::

    from smsd import parse_smiles, find_mcs, is_substructure, similarity

    benzene = parse_smiles("c1ccccc1")
    phenol  = parse_smiles("c1ccc(O)cc1")

    assert is_substructure(benzene, phenol)

    mcs = find_mcs(benzene, phenol)
    print(f"MCS size: {len(mcs)}")

    sim = similarity(benzene, phenol)
    print(f"Similarity: {sim:.3f}")
"""

__version__ = "6.0.0"
__author__ = "Syed Asad Rahman"

from smsd._smsd import (
    # Types
    ChemOptions,
    McsOptions,
    MolGraph,
    MolGraphBuilder,
    # Enums
    BondOrderMode,
    AromaticityMode,
    RingFusionMode,
    # SMILES / SMARTS
    parse_smiles,
    to_smiles,
    to_smarts,
    # Substructure
    is_substructure,
    find_substructure,
    # MCS
    find_mcs,
    # RASCAL
    similarity_upper_bound,
    screen_targets,
    # Fingerprints
    path_fingerprint,
    mcs_fingerprint,
    fingerprint_subset,
    analyze_fp_quality,
    # GPU / compute backend query (CUDA on Linux/Windows, Metal on macOS)
    gpu_is_available,
    gpu_device_info,
)


# ---------------------------------------------------------------------------
# Convenience helpers that wrap the raw C++ bindings with Pythonic defaults
# ---------------------------------------------------------------------------

def similarity(mol1, mol2):
    """Compute RASCAL similarity upper bound between two molecules.

    Accepts either MolGraph objects or SMILES strings.

    Returns:
        float: Tanimoto-like similarity in [0.0, 1.0].
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    return similarity_upper_bound(g1, g2)


def mcs(mol1, mol2, *, tautomer_aware=False, timeout_ms=10000, **kwargs):
    """Find Maximum Common Substructure between two molecules.

    Accepts either MolGraph objects or SMILES strings.

    Args:
        mol1: First molecule (MolGraph or SMILES string).
        mol2: Second molecule (MolGraph or SMILES string).
        tautomer_aware: Use tautomer-aware matching.
        timeout_ms: Timeout in milliseconds.
        **kwargs: Additional McsOptions fields (e.g. connected_only=False).

    Returns:
        dict: Mapping from mol1 atom indices to mol2 atom indices.
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    chem = ChemOptions.tautomer_profile() if tautomer_aware else ChemOptions()
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return find_mcs(g1, g2, chem, opts)


def substructure_search(query, target, *, timeout_ms=10000):
    """Find a substructure mapping of query in target.

    Accepts either MolGraph objects or SMILES strings.

    Returns:
        list: List of (query_atom, target_atom) pairs, or empty list if not
        a substructure.
    """
    q = _ensure_mol(query)
    t = _ensure_mol(target)
    return find_substructure(q, t, ChemOptions(), timeout_ms)


def fingerprint(mol, *, kind="mcs", path_length=7, fp_size=2048):
    """Compute a molecular fingerprint.

    Args:
        mol: MolGraph or SMILES string.
        kind: "path" for simple path fingerprint, "mcs" for MCS-aware.
        path_length: Maximum bond path length (default 7).
        fp_size: Fingerprint size in bits (default 2048).

    Returns:
        list[int]: Sorted list of set bit positions.
    """
    g = _ensure_mol(mol)
    if kind == "path":
        return path_fingerprint(g, path_length, fp_size)
    elif kind == "mcs":
        return mcs_fingerprint(g, path_length, fp_size)
    else:
        raise ValueError(f"Unknown fingerprint kind: {kind!r}. Use 'path' or 'mcs'.")


def tanimoto(fp1, fp2, fp_size=2048):
    """Compute Tanimoto coefficient between two fingerprints.

    Args:
        fp1: List of set bit positions (from fingerprint()).
        fp2: List of set bit positions (from fingerprint()).
        fp_size: Fingerprint size in bits.

    Returns:
        float: Tanimoto similarity in [0.0, 1.0].
    """
    s1 = set(fp1)
    s2 = set(fp2)
    intersection = len(s1 & s2)
    union = len(s1 | s2)
    if union == 0:
        return 1.0
    return intersection / union


def batch_substructure(query, targets, *, timeout_ms=10000):
    """Check whether query is a substructure of each molecule in targets.

    Automatically dispatches to multi-core OpenMP via the C++ extension.
    Pass pre-parsed MolGraph objects for best performance (avoids per-call
    SMILES parsing).

    Args:
        query:      MolGraph or SMILES string.
        targets:    List of MolGraph or SMILES strings.
        timeout_ms: Per-pair timeout in milliseconds.

    Returns:
        list[bool]: True at index i when query is a substructure of targets[i].
    """
    from smsd._smsd import batch_substructure as _batch_sub  # type: ignore[import]
    q = _ensure_mol(query)
    ts = [_ensure_mol(t) for t in targets]
    return _batch_sub(q, ts, ChemOptions(), timeout_ms)


def batch_mcs(query, targets, *, timeout_ms=10000, **kwargs):
    """Compute MCS between query and every molecule in targets in parallel.

    Dispatches to multi-core OpenMP automatically.

    Args:
        query:      MolGraph or SMILES string.
        targets:    List of MolGraph or SMILES strings.
        timeout_ms: Per-pair timeout in milliseconds.
        **kwargs:   Extra McsOptions fields (e.g. connected_only=False).

    Returns:
        list[dict]: MCS atom mappings (query → target index) for each target.
    """
    from smsd._smsd import batch_mcs as _batch_mcs  # type: ignore[import]
    q = _ensure_mol(query)
    ts = [_ensure_mol(t) for t in targets]
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return _batch_mcs(q, ts, ChemOptions(), opts)


def _ensure_mol(obj):
    """Convert a SMILES string to MolGraph, or return MolGraph as-is."""
    if isinstance(obj, str):
        return parse_smiles(obj)
    if isinstance(obj, MolGraph):
        return obj
    raise TypeError(
        f"Expected MolGraph or SMILES string, got {type(obj).__name__}"
    )


# ---------------------------------------------------------------------------
# RDKit interoperability helpers (RDKit is an optional dependency)
# ---------------------------------------------------------------------------

def from_rdkit(mol):
    """Convert an RDKit Mol to SMSD MolGraph via SMILES round-trip.

    RDKit is an optional dependency -- this function raises ImportError
    if RDKit is not installed.

    Example::

        from rdkit import Chem
        import smsd

        mol = Chem.MolFromSmiles("c1ccccc1")
        g = smsd.from_rdkit(mol)
        # Use g with any SMSD function
    """
    try:
        from rdkit import Chem
    except ImportError:
        raise ImportError(
            "RDKit is required for from_rdkit(). "
            "Install with: pip install rdkit"
        )
    smi = Chem.MolToSmiles(mol)
    return parse_smiles(smi)


def mcs_rdkit(mol1, mol2, **kwargs):
    """Find Maximum Common Substructure between two RDKit Mol objects.

    Accepts any keyword arguments supported by :func:`mcs` (e.g.
    ``tautomer_aware``, ``timeout_ms``).

    Example::

        from rdkit import Chem
        import smsd

        m1 = Chem.MolFromSmiles("c1ccccc1")
        m2 = Chem.MolFromSmiles("c1ccc(O)cc1")
        result = smsd.mcs_rdkit(m1, m2)
    """
    g1 = from_rdkit(mol1)
    g2 = from_rdkit(mol2)
    return mcs(g1, g2, **kwargs)


def substructure_rdkit(query_mol, target_mol, **kwargs):
    """Check substructure relationship between two RDKit Mol objects.

    Accepts any keyword arguments supported by :func:`substructure_search`
    (e.g. ``timeout_ms``).

    Example::

        from rdkit import Chem
        import smsd

        benzene = Chem.MolFromSmiles("c1ccccc1")
        phenol  = Chem.MolFromSmiles("c1ccc(O)cc1")
        result = smsd.substructure_rdkit(benzene, phenol)
    """
    gq = from_rdkit(query_mol)
    gt = from_rdkit(target_mol)
    return substructure_search(gq, gt, **kwargs)


# =========================================================================
# Export & Depiction — plug into RDKit, matplotlib, or Jupyter
# =========================================================================


def to_rdkit(mol_or_smiles):
    """Convert SMSD MolGraph (or SMILES string) to an RDKit Mol object.

    Example::

        import smsd
        g = smsd.parse_smiles("c1ccccc1")
        rdkit_mol = smsd.to_rdkit(g)

        # Now use RDKit for drawing, fingerprints, descriptors, etc.
        from rdkit.Chem import Draw
        Draw.MolToImage(rdkit_mol)
    """
    try:
        from rdkit import Chem
    except ImportError:
        raise ImportError(
            "RDKit is required for to_rdkit(). "
            "Install with: pip install rdkit"
        )
    if isinstance(mol_or_smiles, str):
        smi = mol_or_smiles
    elif hasattr(mol_or_smiles, "__class__") and "MolGraph" in type(mol_or_smiles).__name__:
        smi = to_smiles(mol_or_smiles)
    else:
        raise TypeError(f"Expected MolGraph or SMILES string, got {type(mol_or_smiles)}")
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        raise ValueError(f"RDKit could not parse SMILES: {smi}")
    return mol


def depict_mcs(mol1, mol2, *, tautomer_aware=False, timeout_ms=10000,
               size=(600, 300), highlight_color=(0.5, 0.8, 1.0)):
    """Find MCS and return an RDKit image with matched atoms highlighted.

    Works in Jupyter notebooks (auto-displays) and scripts (returns PIL Image).

    Example::

        import smsd
        img = smsd.depict_mcs("c1ccccc1", "c1ccc(O)cc1")
        img.save("mcs.png")  # or just display in Jupyter
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import Draw, AllChem
    except ImportError:
        raise ImportError(
            "RDKit is required for depict_mcs(). "
            "Install with: pip install rdkit"
        )

    # Parse inputs
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)

    # Find MCS
    mapping = mcs(g1, g2, tautomer_aware=tautomer_aware, timeout_ms=timeout_ms)

    # Convert to RDKit mols for drawing
    smi1 = to_smiles(g1) if not isinstance(mol1, str) else mol1
    smi2 = to_smiles(g2) if not isinstance(mol2, str) else mol2
    rdmol1 = Chem.MolFromSmiles(smi1)
    rdmol2 = Chem.MolFromSmiles(smi2)
    if rdmol1 is None or rdmol2 is None:
        raise ValueError("Could not convert molecules for depiction")

    AllChem.Compute2DCoords(rdmol1)
    AllChem.Compute2DCoords(rdmol2)

    # Highlight matched atoms
    q_atoms = list(mapping.keys()) if mapping else []
    t_atoms = list(mapping.values()) if mapping else []

    img = Draw.MolsToGridImage(
        [rdmol1, rdmol2],
        molsPerRow=2,
        subImgSize=(size[0] // 2, size[1]),
        highlightAtomLists=[q_atoms, t_atoms],
        legends=[f"Query ({len(q_atoms)} matched)", f"Target ({len(t_atoms)} matched)"],
    )
    return img


def depict_substructure(query, target, *, timeout_ms=10000,
                        size=(600, 300)):
    """Find substructure and return an RDKit image with matched atoms highlighted.

    Example::

        import smsd
        img = smsd.depict_substructure("c1ccccc1", "c1ccc(O)cc1")
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import Draw, AllChem
    except ImportError:
        raise ImportError(
            "RDKit is required for depict_substructure(). "
            "Install with: pip install rdkit"
        )

    gq = _ensure_mol(query)
    gt = _ensure_mol(target)

    result = substructure_search(gq, gt, timeout_ms=timeout_ms)
    mapping = result if isinstance(result, dict) else {}

    smi_q = to_smiles(gq) if not isinstance(query, str) else query
    smi_t = to_smiles(gt) if not isinstance(target, str) else target
    rdmol_q = Chem.MolFromSmiles(smi_q)
    rdmol_t = Chem.MolFromSmiles(smi_t)
    if rdmol_q is None or rdmol_t is None:
        raise ValueError("Could not convert molecules for depiction")

    AllChem.Compute2DCoords(rdmol_q)
    AllChem.Compute2DCoords(rdmol_t)

    q_atoms = list(mapping.keys()) if mapping else []
    t_atoms = list(mapping.values()) if mapping else []

    img = Draw.MolsToGridImage(
        [rdmol_q, rdmol_t],
        molsPerRow=2,
        subImgSize=(size[0] // 2, size[1]),
        highlightAtomLists=[q_atoms, t_atoms],
        legends=[f"Query", f"Target ({len(t_atoms)} matched)"],
    )
    return img


def to_svg(mol_or_smiles, *, size=(300, 200)):
    """Generate SVG depiction of a molecule using RDKit.

    Example::

        svg = smsd.to_svg("c1ccccc1")
        with open("benzene.svg", "w") as f:
            f.write(svg)
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import Draw, AllChem, rdMolDraw2D
    except ImportError:
        raise ImportError(
            "RDKit is required for to_svg(). "
            "Install with: pip install rdkit"
        )

    if isinstance(mol_or_smiles, str):
        mol = Chem.MolFromSmiles(mol_or_smiles)
    elif hasattr(mol_or_smiles, "__class__") and "MolGraph" in type(mol_or_smiles).__name__:
        mol = Chem.MolFromSmiles(to_smiles(mol_or_smiles))
    else:
        mol = mol_or_smiles  # assume RDKit mol

    if mol is None:
        raise ValueError("Could not parse molecule for SVG depiction")

    AllChem.Compute2DCoords(mol)
    drawer = rdMolDraw2D.MolDraw2DSVG(size[0], size[1])
    drawer.DrawMolecule(mol)
    drawer.FinishDrawing()
    return drawer.GetDrawingText()


def export_sdf(molecules, filename):
    """Export a list of SMSD MolGraphs (or SMILES strings) to an SDF file via RDKit.

    Example::

        mols = [smsd.parse_smiles(s) for s in ["CCO", "c1ccccc1", "CC(=O)O"]]
        smsd.export_sdf(mols, "output.sdf")
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import AllChem
    except ImportError:
        raise ImportError(
            "RDKit is required for export_sdf(). "
            "Install with: pip install rdkit"
        )

    writer = Chem.SDWriter(filename)
    for mol in molecules:
        if isinstance(mol, str):
            rdmol = Chem.MolFromSmiles(mol)
        elif hasattr(mol, "__class__") and "MolGraph" in type(mol).__name__:
            rdmol = Chem.MolFromSmiles(to_smiles(mol))
        else:
            rdmol = mol
        if rdmol is not None:
            AllChem.Compute2DCoords(rdmol)
            writer.write(rdmol)
    writer.close()


__all__ = [
    # Types
    "ChemOptions",
    "McsOptions",
    "MolGraph",
    "MolGraphBuilder",
    # Enums
    "BondOrderMode",
    "AromaticityMode",
    "RingFusionMode",
    # SMILES / SMARTS
    "parse_smiles",
    "to_smiles",
    "to_smarts",
    # Substructure
    "is_substructure",
    "find_substructure",
    "substructure_search",
    # MCS
    "find_mcs",
    "mcs",
    # Similarity
    "similarity",
    "similarity_upper_bound",
    "screen_targets",
    # Fingerprints
    "fingerprint",
    "path_fingerprint",
    "mcs_fingerprint",
    "fingerprint_subset",
    "analyze_fp_quality",
    "tanimoto",
    # Parallel batch
    "batch_substructure",
    "batch_mcs",
    # GPU / compute backend
    "gpu_is_available",
    "gpu_device_info",
    # RDKit interoperability
    "from_rdkit",
    "to_rdkit",
    "mcs_rdkit",
    "substructure_rdkit",
    # Export & depiction (RDKit-powered)
    "depict_mcs",
    "depict_substructure",
    "to_svg",
    "export_sdf",
]
