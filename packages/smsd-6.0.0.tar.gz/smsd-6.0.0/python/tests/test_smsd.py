# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2018-2026 BioInception PVT LTD
# Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
# See the NOTICE file for attribution, trademark, and algorithm IP terms.
"""
Tests for the SMSD Python bindings.

Run with:  pytest tests/test_smsd.py -v
"""
import pytest
import smsd
from smsd import (
    parse_smiles,
    to_smiles,
    is_substructure,
    find_substructure,
    find_mcs,
    similarity_upper_bound,
    screen_targets,
    path_fingerprint,
    mcs_fingerprint,
    fingerprint_subset,
    analyze_fp_quality,
    ChemOptions,
    McsOptions,
    MolGraph,
    MolGraphBuilder,
    BondOrderMode,
    AromaticityMode,
    RingFusionMode,
)


# ===========================================================================
# SMILES parsing
# ===========================================================================

class TestParseSMILES:
    """Test SMILES parsing for various molecules."""

    def test_benzene(self):
        mol = parse_smiles("c1ccccc1")
        assert mol.n == 6
        for i in range(6):
            assert mol.atomic_num[i] == 6
            assert mol.aromatic[i] is True
            assert mol.ring[i] is True

    def test_aspirin(self):
        mol = parse_smiles("CC(=O)Oc1ccccc1C(=O)O")
        assert mol.n == 13
        # Count carbons and oxygens
        n_c = sum(1 for z in mol.atomic_num if z == 6)
        n_o = sum(1 for z in mol.atomic_num if z == 8)
        assert n_c == 9
        assert n_o == 4

    def test_caffeine(self):
        mol = parse_smiles("Cn1cnc2c1c(=O)n(c(=O)n2C)C")
        assert mol.n == 14
        # Should have N and O atoms
        n_n = sum(1 for z in mol.atomic_num if z == 7)
        n_o = sum(1 for z in mol.atomic_num if z == 8)
        assert n_n == 4
        assert n_o == 2

    def test_ethanol(self):
        mol = parse_smiles("CCO")
        assert mol.n == 3
        assert mol.atomic_num[2] == 8

    def test_empty_raises(self):
        with pytest.raises(Exception):
            parse_smiles("")

    def test_invalid_raises(self):
        with pytest.raises(Exception):
            parse_smiles("[Zq]")

    def test_round_trip(self):
        """Parse -> write -> re-parse should give the same atom count."""
        mol1 = parse_smiles("c1ccccc1")
        smi = to_smiles(mol1)
        mol2 = parse_smiles(smi)
        assert mol2.n == mol1.n

    def test_charged_atom(self):
        mol = parse_smiles("[NH4+]")
        assert mol.n == 1
        assert mol.atomic_num[0] == 7
        assert mol.formal_charge[0] == 1

    def test_isotope(self):
        mol = parse_smiles("[13CH4]")
        assert mol.n == 1
        assert mol.mass_number[0] == 13

    def test_disconnected(self):
        mol = parse_smiles("C.C")
        assert mol.n == 2


# ===========================================================================
# SMILES writer
# ===========================================================================

class TestToSMILES:
    """Test canonical SMILES generation."""

    def test_canonical_benzene(self):
        mol = parse_smiles("c1ccccc1")
        smi = to_smiles(mol)
        assert isinstance(smi, str)
        assert len(smi) > 0

    def test_canonical_aspirin(self):
        mol = parse_smiles("CC(=O)Oc1ccccc1C(=O)O")
        smi = to_smiles(mol)
        assert isinstance(smi, str)
        # Re-parse should give same structure
        mol2 = parse_smiles(smi)
        assert mol2.n == 13


# ===========================================================================
# Substructure search
# ===========================================================================

class TestSubstructure:
    """Test substructure (subgraph isomorphism) search."""

    def test_benzene_in_phenol(self):
        benzene = parse_smiles("c1ccccc1")
        phenol = parse_smiles("c1ccc(O)cc1")
        assert is_substructure(benzene, phenol) is True

    def test_phenol_not_in_benzene(self):
        benzene = parse_smiles("c1ccccc1")
        phenol = parse_smiles("c1ccc(O)cc1")
        assert is_substructure(phenol, benzene) is False

    def test_benzene_in_naphthalene(self):
        benzene = parse_smiles("c1ccccc1")
        naphthalene = parse_smiles("c1ccc2ccccc2c1")
        assert is_substructure(benzene, naphthalene) is True

    def test_find_substructure_mapping(self):
        benzene = parse_smiles("c1ccccc1")
        phenol = parse_smiles("c1ccc(O)cc1")
        mapping = find_substructure(benzene, phenol)
        assert len(mapping) == 6  # all 6 benzene atoms mapped
        # Each pair should be (query_idx, target_idx)
        for qi, ti in mapping:
            assert 0 <= qi < 6
            assert 0 <= ti < 7

    def test_self_substructure(self):
        mol = parse_smiles("CCO")
        assert is_substructure(mol, mol) is True

    def test_empty_query_is_substructure(self):
        """An empty molecule is a substructure of anything."""
        mol = parse_smiles("C")
        empty = MolGraph()
        assert is_substructure(empty, mol) is True


# ===========================================================================
# MCS (Maximum Common Substructure)
# ===========================================================================

class TestMCS:
    """Test MCS search."""

    def test_benzene_toluene(self):
        benzene = parse_smiles("c1ccccc1")
        toluene = parse_smiles("Cc1ccccc1")
        mapping = find_mcs(benzene, toluene)
        assert len(mapping) == 6  # benzene ring is the MCS

    def test_aspirin_acetaminophen(self):
        aspirin = parse_smiles("CC(=O)Oc1ccccc1C(=O)O")
        acetaminophen = parse_smiles("CC(=O)Nc1ccc(O)cc1")
        mapping = find_mcs(aspirin, acetaminophen)
        assert len(mapping) >= 7  # at least the ring + some shared atoms

    def test_identical_molecules(self):
        mol = parse_smiles("c1ccccc1")
        mapping = find_mcs(mol, mol)
        assert len(mapping) == 6

    def test_mcs_returns_dict(self):
        g1 = parse_smiles("CCO")
        g2 = parse_smiles("CCCO")
        mapping = find_mcs(g1, g2)
        assert isinstance(mapping, dict)
        for k, v in mapping.items():
            assert isinstance(k, int)
            assert isinstance(v, int)

    def test_mcs_with_options(self):
        g1 = parse_smiles("c1ccccc1")
        g2 = parse_smiles("c1ccc(O)cc1")
        opts = McsOptions()
        opts.timeout_ms = 5000
        mapping = find_mcs(g1, g2, ChemOptions(), opts)
        assert len(mapping) == 6


# ===========================================================================
# RASCAL (similarity upper bound)
# ===========================================================================

class TestRASCAL:
    """Test RASCAL similarity screening."""

    def test_similar_molecules(self):
        benzene = parse_smiles("c1ccccc1")
        toluene = parse_smiles("Cc1ccccc1")
        sim = similarity_upper_bound(benzene, toluene)
        assert sim > 0.5
        assert sim <= 1.0

    def test_identical_similarity(self):
        mol = parse_smiles("c1ccccc1")
        sim = similarity_upper_bound(mol, mol)
        assert sim == pytest.approx(1.0)

    def test_dissimilar_molecules(self):
        methane = parse_smiles("C")
        cholesterol = parse_smiles(
            "CC(CCCC(C)C)C1CCC2C1(CCC3C2CC=C4C3(CCC(C4)O)C)C"
        )
        sim = similarity_upper_bound(methane, cholesterol)
        assert sim < 0.5

    def test_convenience_similarity(self):
        """Test the convenience wrapper that accepts SMILES strings."""
        sim = smsd.similarity("c1ccccc1", "Cc1ccccc1")
        assert sim > 0.5

    def test_empty_molecule(self):
        mol = parse_smiles("C")
        empty = MolGraph()
        sim = similarity_upper_bound(mol, empty)
        assert sim == 0.0


# ===========================================================================
# Fingerprints
# ===========================================================================

class TestFingerprint:
    """Test path and MCS fingerprints."""

    def test_path_fingerprint_basic(self):
        mol = parse_smiles("c1ccccc1")
        fp = path_fingerprint(mol)
        assert isinstance(fp, list)
        assert len(fp) > 0
        # All bits should be in range [0, 2048)
        assert all(0 <= b < 2048 for b in fp)

    def test_mcs_fingerprint_basic(self):
        mol = parse_smiles("c1ccccc1")
        fp = mcs_fingerprint(mol)
        assert isinstance(fp, list)
        assert len(fp) > 0
        assert all(0 <= b < 2048 for b in fp)

    def test_self_subset(self):
        """A fingerprint should be a subset of itself."""
        mol = parse_smiles("c1ccccc1")
        fp = path_fingerprint(mol)
        assert fingerprint_subset(fp, fp) is True

    def test_subset_property(self):
        """Substructure fingerprint should be subset of superstructure."""
        benzene = parse_smiles("c1ccccc1")
        phenol = parse_smiles("c1ccc(O)cc1")
        fp_benz = path_fingerprint(benzene)
        fp_phen = path_fingerprint(phenol)
        # benzene paths should be a subset of phenol paths
        assert fingerprint_subset(fp_benz, fp_phen) is True

    def test_fingerprint_custom_size(self):
        mol = parse_smiles("CCO")
        fp = path_fingerprint(mol, path_length=5, fp_size=1024)
        assert all(0 <= b < 1024 for b in fp)

    def test_mcs_fingerprint_subset(self):
        benzene = parse_smiles("c1ccccc1")
        toluene = parse_smiles("Cc1ccccc1")
        fp_benz = mcs_fingerprint(benzene)
        fp_tol = mcs_fingerprint(toluene)
        # benzene MCS fp should be subset of toluene
        assert fingerprint_subset(fp_benz, fp_tol) is True

    def test_analyze_fp_quality(self):
        mol = parse_smiles("c1ccccc1")
        fp = path_fingerprint(mol)
        quality = analyze_fp_quality(fp)
        assert "set_bits" in quality
        assert "density" in quality
        assert "fp_size" in quality
        assert "expected_collision_rate" in quality
        assert "is_saturated" in quality
        assert quality["set_bits"] == len(fp)
        assert quality["fp_size"] == 2048
        assert 0.0 <= quality["density"] <= 1.0

    def test_convenience_fingerprint(self):
        """Test the convenience wrapper."""
        fp_path = smsd.fingerprint("CCO", kind="path")
        fp_mcs = smsd.fingerprint("CCO", kind="mcs")
        assert isinstance(fp_path, list)
        assert isinstance(fp_mcs, list)

    def test_tanimoto(self):
        fp1 = smsd.fingerprint("c1ccccc1")
        fp2 = smsd.fingerprint("Cc1ccccc1")
        sim = smsd.tanimoto(fp1, fp2)
        assert 0.0 <= sim <= 1.0
        # Same molecule should give 1.0
        assert smsd.tanimoto(fp1, fp1) == pytest.approx(1.0)


# ===========================================================================
# Tautomer-aware matching
# ===========================================================================

class TestTautomer:
    """Test tautomer-aware MCS."""

    def test_keto_enol_tautomer_profile(self):
        """Keto and enol forms should have larger MCS with tautomer-aware opts."""
        # 2-hydroxypyridine (enol) vs 2-pyridinone (keto)
        enol = parse_smiles("Oc1ccccn1")
        keto = parse_smiles("O=C1C=CC=CN1")
        # Standard MCS
        mapping_strict = find_mcs(enol, keto)
        # Tautomer-aware MCS
        taut_opts = ChemOptions.tautomer_profile()
        mapping_taut = find_mcs(enol, keto, taut_opts)
        # Tautomer-aware should find at least as many atoms
        assert len(mapping_taut) >= len(mapping_strict)

    def test_tautomer_profile_creation(self):
        opts = ChemOptions.tautomer_profile()
        assert opts.tautomer_aware is True
        assert opts.match_formal_charge is False

    def test_convenience_mcs_tautomer(self):
        """Test the convenience mcs() with tautomer_aware flag."""
        mapping = smsd.mcs("Oc1ccccn1", "O=C1C=CC=CN1", tautomer_aware=True)
        assert isinstance(mapping, dict)
        assert len(mapping) > 0


# ===========================================================================
# Batch screening
# ===========================================================================

class TestBatchScreening:
    """Test batch RASCAL screening."""

    # 20 diverse SMILES for building a screening library
    LIBRARY_SMILES = [
        "c1ccccc1",                          # benzene
        "Cc1ccccc1",                         # toluene
        "c1ccc(O)cc1",                       # phenol
        "c1ccc(N)cc1",                       # aniline
        "c1ccc(C(=O)O)cc1",                 # benzoic acid
        "CCO",                               # ethanol
        "CCCO",                              # propanol
        "CCCCO",                             # butanol
        "CC(=O)O",                           # acetic acid
        "CC(=O)Oc1ccccc1C(=O)O",            # aspirin
        "CC(=O)Nc1ccc(O)cc1",               # acetaminophen
        "c1ccc2ccccc2c1",                    # naphthalene
        "CC(C)Cc1ccc(cc1)C(C)C(=O)O",       # ibuprofen
        "Cn1cnc2c1c(=O)n(c(=O)n2C)C",       # caffeine
        "C1CCCCC1",                          # cyclohexane
        "c1ccncc1",                          # pyridine
        "c1cc[nH]c1",                        # pyrrole
        "c1ccsc1",                           # thiophene
        "C=C",                               # ethylene
        "C#C",                               # acetylene
    ]

    def test_screen_100_molecules(self):
        """Screen a library of molecules against a query."""
        # Build library by repeating and varying the 20 SMILES 5 times
        library = []
        for _ in range(5):
            for smi in self.LIBRARY_SMILES:
                library.append(parse_smiles(smi))
        assert len(library) == 100

        query = parse_smiles("c1ccccc1")  # benzene
        hits = screen_targets(query, library, 0.5)
        assert isinstance(hits, list)
        # Should find at least benzene copies (indices 0, 20, 40, 60, 80)
        assert len(hits) >= 5
        # All hits should be valid indices
        assert all(0 <= idx < 100 for idx in hits)

    def test_screen_high_threshold(self):
        """With very high threshold, only identical molecules pass."""
        library = [parse_smiles(s) for s in self.LIBRARY_SMILES]
        query = parse_smiles("c1ccccc1")
        hits = screen_targets(query, library, 0.99)
        # Only benzene (index 0) should pass
        assert 0 in hits


# ===========================================================================
# ChemOptions and McsOptions configuration
# ===========================================================================

class TestOptions:
    """Test options configuration."""

    def test_chem_options_defaults(self):
        opts = ChemOptions()
        assert opts.match_atom_type is True
        assert opts.match_formal_charge is True
        assert opts.tautomer_aware is False
        assert opts.complete_rings_only is False

    def test_chem_options_modification(self):
        opts = ChemOptions()
        opts.tautomer_aware = True
        opts.complete_rings_only = True
        assert opts.tautomer_aware is True
        assert opts.complete_rings_only is True

    def test_mcs_options_defaults(self):
        opts = McsOptions()
        assert opts.connected_only is True
        assert opts.induced is False
        assert opts.timeout_ms == 10000

    def test_mcs_options_modification(self):
        opts = McsOptions()
        opts.timeout_ms = 5000
        opts.connected_only = False
        assert opts.timeout_ms == 5000
        assert opts.connected_only is False

    def test_bond_order_mode_enum(self):
        assert BondOrderMode.STRICT is not None
        assert BondOrderMode.LOOSE is not None
        assert BondOrderMode.ANY is not None

    def test_ring_fusion_mode_enum(self):
        assert RingFusionMode.IGNORE is not None
        assert RingFusionMode.PERMISSIVE is not None
        assert RingFusionMode.STRICT is not None

    def test_chem_options_repr(self):
        opts = ChemOptions()
        r = repr(opts)
        assert "ChemOptions" in r

    def test_mcs_options_repr(self):
        opts = McsOptions()
        r = repr(opts)
        assert "McsOptions" in r


# ===========================================================================
# MolGraph properties
# ===========================================================================

class TestMolGraph:
    """Test MolGraph properties and methods."""

    def test_mol_repr(self):
        mol = parse_smiles("CCO")
        assert "MolGraph" in repr(mol)
        assert "3" in repr(mol)

    def test_mol_len(self):
        mol = parse_smiles("c1ccccc1")
        assert len(mol) == 6

    def test_bond_order(self):
        mol = parse_smiles("C=C")
        assert mol.bond_order(0, 1) == 2

    def test_has_bond(self):
        mol = parse_smiles("CC")
        assert mol.has_bond(0, 1) is True

    def test_no_bond(self):
        mol = parse_smiles("C.C")
        assert mol.has_bond(0, 1) is False

    def test_builder(self):
        """Build a molecule using MolGraphBuilder."""
        builder = MolGraphBuilder(3)
        builder.atom(0, 6, 0, False, False)   # carbon
        builder.atom(1, 6, 0, False, False)   # carbon
        builder.atom(2, 8, 0, False, False)   # oxygen
        builder.bond(0, 1, 1, False, False)   # C-C single bond
        builder.bond(1, 2, 1, False, False)   # C-O single bond
        mol = builder.build()
        assert mol.n == 3
        assert mol.atomic_num[0] == 6
        assert mol.atomic_num[2] == 8

    def test_morgan_ranks(self):
        mol = parse_smiles("c1ccccc1")
        assert len(mol.morgan_rank) == 6

    def test_canonical_labels(self):
        mol = parse_smiles("c1ccccc1")
        assert len(mol.canonical_label) == 6
