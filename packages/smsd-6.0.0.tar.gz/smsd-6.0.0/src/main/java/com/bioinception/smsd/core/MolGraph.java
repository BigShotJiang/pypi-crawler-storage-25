/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 * See the NOTICE file for attribution, trademark, and algorithm IP terms. */
package com.bioinception.smsd.core;

import java.util.*;
import org.openscience.cdk.graph.Cycles;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IBond;
import org.openscience.cdk.interfaces.IDoubleBondStereochemistry;
import org.openscience.cdk.interfaces.IStereoElement;
import org.openscience.cdk.interfaces.ITetrahedralChirality;

/**
 * Immutable, CDK-free molecular graph representation for fast substructure
 * and MCS computation. Can be built from a CDK {@link IAtomContainer} or
 * programmatically via {@link Builder}.
 */
public final class MolGraph {
  final IAtomContainer mol;
  final int n;
  public final int[] atomicNum, formalCharge, label, massNumber;
  int[] morganRank, orbit, canonicalLabel;
  long canonicalHash;
  private volatile boolean canonicalComputed = false;
  private volatile boolean tautomerClassesComputed = false;
  private volatile boolean ringCountsComputed = false;
  final boolean[] ring, aromatic;
  final int[] degree;
  public final int[] ringCount;
  final int[][] neighbors;
  private BitSet[] adj;          // lazy — built on first access via getAdj()
  long[][] adjLong;
  final int words;
  private int[][] cachedNLF1, cachedNLF2, cachedNLF3;
  private static final int SPARSE_THRESHOLD = 200;
  final int[][] bondOrdMatrix;
  final boolean[][] bondRingMatrix, bondAromMatrix;
  final HashMap<Long, int[]> sparseBondProps;
  final int[] tetraChirality;
  final int[][] dbStereoConf;
  public int[]   tautomerClass;
  /**
   * Per-atom pKa-informed relevance weight for tautomeric matches, in [0,1].
   * 1.0 = atom not in any tautomeric system (no confidence penalty).
   * Values below 1.0 express how likely this atom's current resonance form
   * is at physiological pH 7.4, based on empirical pKa data (Sitzmann 2010).
   * Used by SearchEngine.computeTautomerConfidence() after MCS.
   */
  public float[] tautomerWeight;
  ChemOptions.Solvent solvent = ChemOptions.Solvent.AQUEOUS;
  double pH = 7.4;
  int[][] sssrRings;
  int[][] rcbRings; // Relevant Cycle Basis (union of all MCBs)

  // ---------------------------------------------------------------------------
  // Empirical pKa-derived tautomer relevance weights at pH 7.4
  // References: Sitzmann et al. JCIM 2010; Karabina et al. 2014; ChEMBL pKa db
  // ---------------------------------------------------------------------------
  public static final float TW_KETO_ENOL         = 0.98f; // pKa ~20  — keto overwhelmingly dominant
  public static final float TW_AMIDE_IMIDIC      = 0.97f; // pKa ~15-17 — amide form dominant
  public static final float TW_LACTAM_LACTIM     = 0.97f; // cyclic amide — lactam dominant
  public static final float TW_UREA              = 0.96f; // pKa ~14 — urea form dominant
  public static final float TW_PYRIDINONE        = 0.95f; // pKa ~1  — lactam dominant
  public static final float TW_THIOAMIDE         = 0.94f; // pKa ~13 — thioamide dominant
  public static final float TW_THIONE_THIOL      = 0.94f; // pKa ~10-11 — thione dominant
  public static final float TW_ENAMINONE         = 0.85f; // vinylogous amide — amine form dominant
  public static final float TW_HYDROXAMIC        = 0.85f; // pKa ~8  — neutral hydroxamic dominant
  public static final float TW_PHENOL_QUINONE    = 0.88f; // pKa ~10 — phenol dominant
  public static final float TW_HYDROXYPYRIMIDINE = 0.90f; // lactam tautomer dominant in N-heterocycles
  public static final float TW_PURINE_NH         = 0.78f; // N9-H dominant in purines (adenine, guanine)
  public static final float TW_DIKETONE_ENOL     = 0.72f; // pKa ~8-11 — pH-sensitive, mixed at 7.4
  public static final float TW_NITROSO_OXIME     = 0.70f; // oxime slightly more stable than nitroso
  public static final float TW_CYANAMIDE         = 0.80f; // cyanamide dominant over carbodiimide
  public static final float TW_IMIDE             = 0.92f; // imide N-H dominant
  public static final float TW_AMIDINE          = 0.50f;  // symmetric — equal tautomers
  public static final float TW_GUANIDINE        = 0.50f;  // symmetric — equal tautomers
  public static final float TW_IMIDAZOLE_NH     = 0.50f;  // N1H/N3H symmetric in unsubstituted
  public static final float TW_TRIAZOLE_NH      = 0.50f;  // 1H/2H symmetric
  public static final float TW_TETRAZOLE_NH     = 0.50f;  // 1H/2H symmetric
  public static final float TW_NITRO_ACI        = 0.25f;  // pKa ~3.5 — aci form minor at pH 7.4

  static final int HASH_PRIME = 1000003;

  public boolean hasBond(int i, int j) { return bondOrder(i, j) != 0; }

  public int atomCount() { return n; }

  public int[] getOrbit() { ensureCanonical(); return orbit; }

  public int[][] computeRings() {
    if (sssrRings != null) return sssrRings;
    if (n == 0) { sssrRings = new int[0][]; return sssrRings; }

    int edgeCount = 0;
    for (int i = 0; i < n; i++) edgeCount += neighbors[i].length;
    edgeCount /= 2;

    boolean[] visited = new boolean[n];
    int components = 0;
    for (int i = 0; i < n; i++) {
      if (visited[i]) continue;
      components++;
      Deque<Integer> bfsQ = new ArrayDeque<>();
      bfsQ.add(i);
      visited[i] = true;
      while (!bfsQ.isEmpty()) {
        int u = bfsQ.poll();
        for (int v : neighbors[u]) if (!visited[v]) { visited[v] = true; bfsQ.add(v); }
      }
    }
    int cycleRank = edgeCount - n + components;
    if (cycleRank <= 0) { sssrRings = new int[0][]; return sssrRings; }

    // Horton candidate generation: for every vertex v and every edge (eU, eV),
    // find shortest path from v to eU and from v to eV (excluding edge eU-eV),
    // form cycle from both paths + the edge. This is O(V*E*V) but guaranteed
    // to find all cycles needed for both SSSR and relevant cycles.

    // Build edge index
    Map<Long, Integer> edgeIdx = new HashMap<>();
    List<int[]> edgeList = new ArrayList<>();
    for (int i = 0; i < n; i++)
      for (int j : neighbors[i])
        if (j > i) {
          edgeIdx.put(bondKey(i, j), edgeList.size());
          edgeList.add(new int[]{i, j});
        }
    int totalEdges = edgeList.size();

    // Helper: BFS shortest path from start to target, avoiding edge (avoidU, avoidV)
    // Returns atom path, or empty list if unreachable
    List<boolean[]> candidateMasks = new ArrayList<>();
    List<int[]> candidateAtoms = new ArrayList<>();
    List<Integer> candidateSizes = new ArrayList<>();
    Set<String> seenMasks = new HashSet<>();

    for (int v = 0; v < n; v++) {
      for (int[] edge : edgeList) {
        int eU = edge[0], eV = edge[1];

        // Find shortest path from v to eU, avoiding edge (eU, eV)
        List<Integer> path1 = bfsPath(v, eU, eU, eV);
        if (path1.isEmpty()) continue;

        // Find shortest path from v to eV, avoiding edge (eU, eV)
        List<Integer> path2 = bfsPath(v, eV, eU, eV);
        if (path2.isEmpty()) continue;

        // Check paths are vertex-disjoint (only share vertex v)
        Set<Integer> p1Interior = new HashSet<>();
        for (int i = 1; i < path1.size(); i++) p1Interior.add(path1.get(i));
        boolean disjoint = true;
        for (int i = 1; i < path2.size(); i++) {
          if (p1Interior.contains(path2.get(i))) { disjoint = false; break; }
        }
        if (!disjoint) continue;

        // Build edge mask for this cycle
        boolean[] mask = new boolean[totalEdges];
        int edgeId = edgeIdx.get(bondKey(eU, eV));
        mask[edgeId] = true;

        boolean valid = true;
        for (int i = 0; i < path1.size() - 1 && valid; i++) {
          Integer idx = edgeIdx.get(bondKey(Math.min(path1.get(i), path1.get(i+1)),
                                            Math.max(path1.get(i), path1.get(i+1))));
          if (idx == null) valid = false; else mask[idx] = true;
        }
        for (int i = 0; i < path2.size() - 1 && valid; i++) {
          Integer idx = edgeIdx.get(bondKey(Math.min(path2.get(i), path2.get(i+1)),
                                            Math.max(path2.get(i), path2.get(i+1))));
          if (idx == null) valid = false; else mask[idx] = true;
        }
        if (!valid) continue;

        // Deduplicate by edge mask
        String maskStr = Arrays.toString(mask);
        if (!seenMasks.add(maskStr)) continue;

        int ringSize = path1.size() + path2.size() - 1;
        if (ringSize < 3 || ringSize > 20) continue;

        candidateMasks.add(mask);
        candidateSizes.add(ringSize);

        // Build atom list: path1(v→eU) + eV + reverse(path2 interior, eV→...→v excluded)
        // path1 = [v, ..., eU], path2 = [v, ..., eV]
        // Cycle: v → ... → eU → eV → ... → v (backwards through path2)
        List<Integer> atoms = new ArrayList<>(path1); // [v, ..., eU]
        // Append path2 in reverse, skipping the first element (v) since path1 starts at v
        for (int i = path2.size() - 1; i >= 1; i--) atoms.add(path2.get(i));
        candidateAtoms.add(atoms.stream().mapToInt(Integer::intValue).toArray());
      }
    }

    // Sort candidates by size (smallest first)
    Integer[] order = new Integer[candidateMasks.size()];
    for (int i = 0; i < order.length; i++) order[i] = i;
    Arrays.sort(order, Comparator.comparingInt(candidateSizes::get));

    // Interleaved SSSR + RCB pipeline (Vismara's rule, 2-phase reduction):
    // Phase 1: Check relevance (independence from STRICTLY SHORTER cycles only)
    // Phase 2: Check SSSR inclusion (independence from ALL basis cycles)
    List<int[]> sssr = new ArrayList<>();
    List<int[]> rcb = new ArrayList<>();
    List<boolean[]> rcbMasks = new ArrayList<>();
    List<boolean[]> basisMatrix = new ArrayList<>();
    List<Integer> basisSizes = new ArrayList<>();

    // O(E) leading-bit lookup for row-echelon reduction
    int[] basisByLeadingBit = new int[totalEdges];
    Arrays.fill(basisByLeadingBit, -1);

    for (int idx : order) {
      boolean[] mask = candidateMasks.get(idx);
      int cSize = candidateSizes.get(idx);

      // Phase 1: Check relevance — reduce only against STRICTLY SHORTER basis cycles
      boolean[] phase1Mask = mask.clone();
      for (int b = 0; b < totalEdges; b++) {
        if (phase1Mask[b]) {
          int basisIdx = basisByLeadingBit[b];
          if (basisIdx != -1 && basisSizes.get(basisIdx) < cSize) {
            for (int k = b; k < totalEdges; k++) {
              phase1Mask[k] ^= basisMatrix.get(basisIdx)[k];
            }
          }
        }
      }

      boolean relevant = false;
      for (boolean bit : phase1Mask) if (bit) { relevant = true; break; }

      if (relevant) {
        // Deduplicate for RCB by edge mask
        boolean dup = false;
        for (boolean[] existingMask : rcbMasks) {
          if (Arrays.equals(mask, existingMask)) { dup = true; break; }
        }
        if (!dup) {
          rcb.add(candidateAtoms.get(idx));
          rcbMasks.add(mask);
        }

        // Phase 2: Check SSSR inclusion — reduce against ALL basis cycles
        boolean[] phase2Mask = phase1Mask.clone();
        for (int b = 0; b < totalEdges; b++) {
          if (phase2Mask[b]) {
            int basisIdx = basisByLeadingBit[b];
            if (basisIdx != -1) {
              for (int k = b; k < totalEdges; k++) {
                phase2Mask[k] ^= basisMatrix.get(basisIdx)[k];
              }
            }
          }
        }

        boolean independent = false;
        int newLeadingBit = -1;
        for (int b = 0; b < totalEdges; b++) {
          if (phase2Mask[b]) { independent = true; newLeadingBit = b; break; }
        }

        if (independent && sssr.size() < cycleRank) {
          sssr.add(candidateAtoms.get(idx));
          basisMatrix.add(phase2Mask); // Add the FULLY REDUCED mask
          basisSizes.add(cSize);
          basisByLeadingBit[newLeadingBit] = basisMatrix.size() - 1;
        }
      }
    }

    sssrRings = sssr.toArray(new int[0][]);
    rcbRings = rcb.toArray(new int[0][]);
    return sssrRings;
  }

  /**
   * Computes the set of relevant cycles (union of all minimum cycle bases).
   * A cycle is relevant if it cannot be expressed as the XOR (symmetric
   * difference) of strictly shorter cycles. This set is unique for a given
   * molecule -- unlike a single MCB/SSSR which may be arbitrary.
   *
   * <p>Algorithm based on Vismara (1997) and Kolodzik et al. (2012):
   * <ol>
   *   <li>Compute a single MCB via {@link #computeRings()} (Horton's algorithm)</li>
   *   <li>Enumerate all short cycles up to the maximum MCB cycle length</li>
   *   <li>A cycle is relevant iff it is not a linear combination (over GF(2))
   *       of strictly shorter cycles</li>
   * </ol>
   *
   * @return array of relevant cycles, each cycle given as an array of atom indices
   */
  public int[][] computeRelevantCycles() {
    computeRings(); // ensures rcbRings is populated
    if (rcbRings != null) return rcbRings;
    return new int[0][];
  }


  /**
   * Computes Unique Ring Families (URFs) as described by Kolodzik, Urbaczek
   * &amp; Rarey (2012). Two relevant cycles belong to the same URF if one can
   * be obtained from the other by a single edge exchange -- i.e. their
   * symmetric difference (XOR) has exactly two edges that form a path of
   * length 2 (sharing a common vertex).
   *
   * @return list of URFs, each URF is a list of cycles (each cycle is an array of atom indices)
   */
  public int[][][] computeURFs() {
    ensureCanonical();
    int[][] rc = computeRelevantCycles();
    if (rc.length == 0) return new int[0][][];

    // Build edge index + O(1) inverse lookup
    Map<Long, Integer> edgeIndex = new HashMap<>();
    for (int i = 0; i < n; i++) {
      for (int j : neighbors[i]) {
        if (j > i) edgeIndex.computeIfAbsent(bondKey(i, j), k -> edgeIndex.size());
      }
    }
    int numEdges = edgeIndex.size();
    int longWords = (numEdges + 63) >>> 6;

    // O(1) inverse lookup: edge index → (u, v) pair
    int[][] indexToEdge = new int[numEdges][2];
    for (Map.Entry<Long, Integer> e : edgeIndex.entrySet()) {
      long k = e.getKey();
      int idx = e.getValue();
      indexToEdge[idx] = new int[] { (int)(k >>> 32), (int)(k & 0xFFFFFFFFL) };
    }

    // Build edge-incidence vectors for each relevant cycle
    long[][] vectors = new long[rc.length][longWords];
    for (int ci = 0; ci < rc.length; ci++) {
      int[] c = rc[ci];
      for (int i = 0; i < c.length; i++) {
        int a = c[i], b = c[(i + 1) % c.length];
        long key = bondKey(Math.min(a, b), Math.max(a, b));
        Integer idx = edgeIndex.get(key);
        if (idx != null) vectors[ci][idx >>> 6] ^= 1L << (idx & 63);
      }
    }

    int nrc = rc.length;
    int[] family = new int[nrc];
    for (int i = 0; i < nrc; i++) family[i] = i;

    // Generate orbit-based signatures for each cycle (lexicographically minimal)
    String[] sigs = new String[nrc];
    for (int i = 0; i < nrc; i++) sigs[i] = getCycleOrbitSignature(rc[i]);

    // Group cycles into URFs using two criteria (in order):
    //   1. Orbit-signature match: only when every atom in both cycles shares the
    //      same orbit value (vertex-transitive ring systems, e.g. cubane where
    //      all atoms have orbit=0). Without this guard, fused systems like
    //      naphthalene are incorrectly merged because both 6-rings happen to
    //      produce the same orbit sequence after rotation/reflection.
    //   2. Kolodzik single-edge exchange: symmetric difference == 2 edges
    //      sharing a common vertex.
    for (int i = 0; i < nrc; i++) {
      for (int j = i + 1; j < nrc; j++) {
        if (rc[i].length != rc[j].length) continue;

        // 1. Orbit-signature match — guarded: only apply when all atoms in
        //    both cycles belong to the same orbit (vertex-transitive).
        if (sigs[i].equals(sigs[j])) {
          int orb0 = orbit[rc[i][0]];
          boolean allSame = true;
          for (int a : rc[i]) { if (orbit[a] != orb0) { allSame = false; break; } }
          if (allSame) for (int a : rc[j]) { if (orbit[a] != orb0) { allSame = false; break; } }
          if (allSame) {
            union(family, i, j);
            continue;
          }
        }

        // 2. Kolodzik single edge exchange (handles non-symmetric but interchangeable rings)
        long[] xor = new long[longWords];
        int popcount = 0;
        for (int w = 0; w < longWords; w++) {
          xor[w] = vectors[i][w] ^ vectors[j][w];
          popcount += Long.bitCount(xor[w]);
        }
        if (popcount == 2) {
          int[] diffEdges = new int[2];
          int di = 0;
          for (int w = 0; w < longWords && di < 2; w++) {
            long bits = xor[w];
            while (bits != 0 && di < 2) {
              int bit = Long.numberOfTrailingZeros(bits);
              diffEdges[di++] = (w << 6) + bit;
              bits &= bits - 1;
            }
          }
          int[] e1 = indexToEdge[diffEdges[0]]; // O(1) instead of O(E)
          int[] e2 = indexToEdge[diffEdges[1]];
          if (e1 != null && e2 != null && sharesVertex(e1, e2)) {
            union(family, i, j);
          }
        }
      }
    }

    // Group by family
    Map<Integer, List<Integer>> groups = new HashMap<>();
    for (int i = 0; i < nrc; i++) {
      groups.computeIfAbsent(find(family, i), k -> new ArrayList<>()).add(i);
    }

    int[][][] result = new int[groups.size()][][];
    int gi = 0;
    for (List<Integer> members : groups.values()) {
      result[gi] = new int[members.size()][];
      for (int m = 0; m < members.size(); m++) {
        result[gi][m] = rc[members.get(m)];
      }
      gi++;
    }
    return result;
  }

  /** Reverse-lookup: given an edge index, find the (u,v) pair. */
  private static int[] edgeFromIndex(int idx, Map<Long, Integer> edgeIndex) {
    for (Map.Entry<Long, Integer> e : edgeIndex.entrySet()) {
      if (e.getValue() == idx) {
        long key = e.getKey();
        return new int[] { (int)(key >>> 32), (int)(key & 0xFFFFFFFFL) };
      }
    }
    return null;
  }

  private static boolean sharesVertex(int[] e1, int[] e2) {
    return e1[0] == e2[0] || e1[0] == e2[1] || e1[1] == e2[0] || e1[1] == e2[1];
  }

  private static int find(int[] parent, int i) {
    while (parent[i] != i) { parent[i] = parent[parent[i]]; i = parent[i]; }
    return i;
  }

  private static void union(int[] parent, int a, int b) {
    a = find(parent, a); b = find(parent, b);
    if (a != b) parent[a] = b;
  }

  /** Generates a lexicographically minimal orbit signature for a cycle. */
  private String getCycleOrbitSignature(int[] c) {
    int len = c.length;
    int[] bestSeq = null;
    for (int dir = 0; dir <= 1; dir++) {
      for (int start = 0; start < len; start++) {
        int[] seq = new int[len];
        for (int i = 0; i < len; i++) {
          int idx = dir == 0 ? (start + i) % len : (start - i + len) % len;
          seq[i] = orbit[c[idx]];
        }
        if (bestSeq == null || compareSeq(seq, bestSeq) < 0) bestSeq = seq;
      }
    }
    return Arrays.toString(bestSeq);
  }

  private static int compareSeq(int[] a, int[] b) {
    for (int i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return Integer.compare(a[i], b[i]);
    }
    return 0;
  }

  int[][] getNLF1() {
    if (cachedNLF1 == null) cachedNLF1 = buildAllNLF(this, MolGraph::buildNLF1);
    return cachedNLF1;
  }

  int[][] getNLF2() {
    if (cachedNLF2 == null) cachedNLF2 = buildAllNLF(this, MolGraph::buildNLF2);
    return cachedNLF2;
  }

  int[][] getNLF3() {
    if (cachedNLF3 == null) cachedNLF3 = buildAllNLF(this, MolGraph::buildNLF3);
    return cachedNLF3;
  }

  int dbStereo(int i, int j) {
    return dbStereoConf != null ? dbStereoConf[i][j] : 0;
  }

  /** BFS shortest path from start to target, avoiding the edge (avoidU, avoidV). */
  private List<Integer> bfsPath(int start, int target, int avoidU, int avoidV) {
    if (start == target) {
      List<Integer> single = new ArrayList<>();
      single.add(start);
      return single;
    }
    int[] parent = new int[n];
    Arrays.fill(parent, -1);
    boolean[] vis = new boolean[n];
    vis[start] = true;
    Deque<Integer> q = new ArrayDeque<>();
    q.add(start);
    while (!q.isEmpty()) {
      int u = q.poll();
      for (int v : neighbors[u]) {
        if ((u == avoidU && v == avoidV) || (u == avoidV && v == avoidU)) continue;
        if (vis[v]) continue;
        vis[v] = true;
        parent[v] = u;
        if (v == target) {
          List<Integer> path = new ArrayList<>();
          for (int c = target; c != -1; c = parent[c]) path.add(c);
          java.util.Collections.reverse(path);
          return path;
        }
        q.add(v);
      }
    }
    return java.util.Collections.emptyList();
  }

  /** Check if the molecule already has ring membership flags set (e.g. by Cycles.markRingAtomsAndBonds). */
  private static boolean hasRingFlags(IAtomContainer mol) {
    // Only check isInRing() — NOT isAromatic(). CDK's SmilesParser sets aromatic flags
    // from lowercase SMILES but does NOT set ring membership flags. We must call
    // Cycles.markRingAtomsAndBonds() even if atoms are marked aromatic.
    int n = mol.getAtomCount();
    int check = Math.min(n, 8);
    for (int i = 0; i < check; i++) {
      if (mol.getAtom(i).isInRing()) return true;
    }
    int bCheck = Math.min(mol.getBondCount(), 8);
    for (int i = 0; i < bCheck; i++) {
      if (mol.getBond(i).isInRing()) return true;
    }
    return false;
  }

  static long bondKey(int i, int j) {
    return ((long) Math.min(i, j) << 32) | Math.max(i, j);
  }

  private static int encodeBondOrder(IBond b) {
    if (b == null) return 0;
    if (b.isAromatic()) return 4;
    IBond.Order ord = b.getOrder();
    if (ord == IBond.Order.SINGLE) return 1;
    if (ord == IBond.Order.DOUBLE) return 2;
    if (ord == IBond.Order.TRIPLE) return 3;
    return 1;
  }

  int bondOrder(int i, int j) {
    if (bondOrdMatrix != null) return bondOrdMatrix[i][j];
    int[] props = sparseBondProps.get(bondKey(i, j));
    return props != null ? props[0] : 0;
  }

  boolean bondInRing(int i, int j) {
    if (bondRingMatrix != null) return bondRingMatrix[i][j];
    int[] props = sparseBondProps.get(bondKey(i, j));
    return props != null && props[1] != 0;
  }

  boolean bondAromatic(int i, int j) {
    if (bondAromMatrix != null) return bondAromMatrix[i][j];
    int[] props = sparseBondProps.get(bondKey(i, j));
    return props != null && props[2] != 0;
  }

  public MolGraph(IAtomContainer mol) {
    this.mol = mol;
    this.n = mol.getAtomCount();
    this.words = (n + 63) >>> 6;

    // Ensure ring/aromaticity flags are set (SmilesParser may not call ring perception).
    // Skip the expensive CDK ring perception if the molecule already has ring flags
    // (e.g., from AtomContainerManipulator.percieveAtomTypesAndConfigureAtoms + Aromaticity.apply).
    if (!hasRingFlags(mol)) {
      try { Cycles.markRingAtomsAndBonds(mol); } catch (Exception ignored) {}
    }

    IdentityHashMap<IAtom, Integer> idxMap = new IdentityHashMap<>(n);
    for (int i = 0; i < n; i++) idxMap.put(mol.getAtom(i), i);

    this.atomicNum = new int[n];
    this.formalCharge = new int[n];
    this.massNumber = new int[n];
    this.label = new int[n];
    this.ring = new boolean[n];
    this.aromatic = new boolean[n];
    this.degree = new int[n];

    for (int i = 0; i < n; i++) {
      IAtom a = mol.getAtom(i);
      Integer az = a.getAtomicNumber();
      atomicNum[i] = az != null ? az : 0;
      Integer fc = a.getFormalCharge();
      formalCharge[i] = fc != null ? fc : 0;
      Integer mn = a.getMassNumber();
      massNumber[i] = mn != null ? mn : 0;
      ring[i] = a.isInRing();
      aromatic[i] = a.isAromatic();
      label[i] = (atomicNum[i] << 2) | (aromatic[i] ? 2 : 0) | (ring[i] ? 1 : 0);
    }

    // Build neighbors and bond properties in a single bond-iteration pass.
    // Avoids per-atom getConnectedAtomsList() calls (each allocates an ArrayList).
    int[] degreeCount = new int[n];
    for (IBond b : mol.bonds()) {
      degreeCount[idxMap.get(b.getAtom(0))]++;
      degreeCount[idxMap.get(b.getAtom(1))]++;
    }
    this.neighbors = new int[n][];
    for (int i = 0; i < n; i++) { neighbors[i] = new int[degreeCount[i]]; degree[i] = 0; }

    if (n <= SPARSE_THRESHOLD) {
      this.bondOrdMatrix = new int[n][n];
      this.bondRingMatrix = new boolean[n][n];
      this.bondAromMatrix = new boolean[n][n];
      this.sparseBondProps = null;
      for (IBond b : mol.bonds()) {
        int a = idxMap.get(b.getAtom(0)), c = idxMap.get(b.getAtom(1));
        neighbors[a][degree[a]++] = c;
        neighbors[c][degree[c]++] = a;
        int ord = encodeBondOrder(b);
        boolean inRing = b.isInRing(), arom = b.isAromatic();
        bondOrdMatrix[a][c] = ord; bondOrdMatrix[c][a] = ord;
        bondRingMatrix[a][c] = inRing; bondRingMatrix[c][a] = inRing;
        bondAromMatrix[a][c] = arom; bondAromMatrix[c][a] = arom;
      }
    } else {
      this.bondOrdMatrix = null;
      this.bondRingMatrix = null;
      this.bondAromMatrix = null;
      this.sparseBondProps = new HashMap<>(mol.getBondCount() * 3);
      for (IBond b : mol.bonds()) {
        int a = idxMap.get(b.getAtom(0)), c = idxMap.get(b.getAtom(1));
        neighbors[a][degree[a]++] = c;
        neighbors[c][degree[c]++] = a;
        sparseBondProps.put(bondKey(a, c),
            new int[] {encodeBondOrder(b), b.isInRing() ? 1 : 0, b.isAromatic() ? 1 : 0});
      }
    }

    // Stereo: only allocate if the molecule actually has stereo elements
    @SuppressWarnings("unchecked")
    Iterable<IStereoElement<?, ?>> stereoElements = (Iterable) mol.stereoElements();
    boolean hasStereo = stereoElements.iterator().hasNext();
    this.tetraChirality = hasStereo ? new int[n] : null;
    this.dbStereoConf = (hasStereo && n <= SPARSE_THRESHOLD) ? new int[n][n] : null;
    if (hasStereo) {
      for (IStereoElement<?, ?> se : stereoElements) {
        if (se instanceof ITetrahedralChirality) {
          ITetrahedralChirality tc = (ITetrahedralChirality) se;
          Integer idx = idxMap.get(tc.getChiralAtom());
          if (idx != null)
            tetraChirality[idx] = tc.getStereo() == ITetrahedralChirality.Stereo.CLOCKWISE ? 1 : 2;
        } else if (se instanceof IDoubleBondStereochemistry) {
          IDoubleBondStereochemistry dbs = (IDoubleBondStereochemistry) se;
          IBond stereoBond = dbs.getStereoBond();
          Integer a = idxMap.get(stereoBond.getAtom(0)), c = idxMap.get(stereoBond.getAtom(1));
          if (a != null && c != null && dbStereoConf != null) {
            int conf = dbs.getStereo() == IDoubleBondStereochemistry.Conformation.TOGETHER ? 1 : 2;
            dbStereoConf[a][c] = conf;
            dbStereoConf[c][a] = conf;
          }
        }
      }
    }

    this.ringCount = new int[n];
    initDerivedFields();
  }

  MolGraph(Builder b) {
    this.mol = null;
    this.n = b.n;
    this.words = (n + 63) >>> 6;
    this.atomicNum = b.atomicNum.clone();
    this.formalCharge = b.formalCharge != null ? b.formalCharge.clone() : new int[n];
    this.massNumber = b.massNumber != null ? b.massNumber.clone() : new int[n];
    this.ring = b.ring != null ? b.ring.clone() : new boolean[n];
    this.aromatic = b.aromatic != null ? b.aromatic.clone() : new boolean[n];
    this.label = new int[n];
    this.degree = new int[n];
    for (int i = 0; i < n; i++)
      label[i] = (atomicNum[i] << 2) | (aromatic[i] ? 2 : 0) | (ring[i] ? 1 : 0);

    this.neighbors = new int[n][];
    for (int i = 0; i < n; i++) {
      neighbors[i] = b.neighbors[i] != null ? b.neighbors[i].clone() : new int[0];
      degree[i] = neighbors[i].length;
    }

    if (n <= SPARSE_THRESHOLD) {
      this.bondOrdMatrix = new int[n][n];
      this.bondRingMatrix = new boolean[n][n];
      this.bondAromMatrix = new boolean[n][n];
      this.sparseBondProps = null;
      for (int i = 0; i < n; i++) {
        int[] nbs = neighbors[i];
        int[] ords = b.bondOrders != null && b.bondOrders[i] != null ? b.bondOrders[i] : null;
        boolean[] rings = b.bondRings != null && b.bondRings[i] != null ? b.bondRings[i] : null;
        boolean[] aroms = b.bondAroms != null && b.bondAroms[i] != null ? b.bondAroms[i] : null;
        for (int k = 0; k < nbs.length; k++) {
          int j = nbs[k];
          bondOrdMatrix[i][j] = ords != null && k < ords.length ? ords[k] : 1;
          bondRingMatrix[i][j] = rings != null && k < rings.length && rings[k];
          bondAromMatrix[i][j] = aroms != null && k < aroms.length && aroms[k];
        }
      }
    } else {
      this.bondOrdMatrix = null;
      this.bondRingMatrix = null;
      this.bondAromMatrix = null;
      this.sparseBondProps = new HashMap<>();
      for (int i = 0; i < n; i++) {
        int[] nbs = neighbors[i];
        int[] ords = b.bondOrders != null && b.bondOrders[i] != null ? b.bondOrders[i] : null;
        boolean[] rings = b.bondRings != null && b.bondRings[i] != null ? b.bondRings[i] : null;
        boolean[] aroms = b.bondAroms != null && b.bondAroms[i] != null ? b.bondAroms[i] : null;
        for (int k = 0; k < nbs.length; k++) {
          int j = nbs[k];
          if (i < j) {
            sparseBondProps.put(bondKey(i, j), new int[] {
                ords != null && k < ords.length ? ords[k] : 1,
                rings != null && k < rings.length && rings[k] ? 1 : 0,
                aroms != null && k < aroms.length && aroms[k] ? 1 : 0});
          }
        }
      }
    }

    this.tetraChirality = b.tetraChirality != null ? b.tetraChirality.clone() : new int[n];
    if (n <= SPARSE_THRESHOLD) {
      this.dbStereoConf = new int[n][n];
      if (b.dbStereoConf != null)
        for (int i = 0; i < n; i++)
          if (b.dbStereoConf[i] != null)
            System.arraycopy(b.dbStereoConf[i], 0, dbStereoConf[i], 0, n);
    } else {
      this.dbStereoConf = null;
    }

    this.ringCount = new int[n];
    initDerivedFields();
  }

  private void initDerivedFields() {
    // adj (BitSet[]) is lazy — built on first getAdj() call.
    // Only adjLong is eagerly built (used by substructure/MCS hot paths).
    this.adjLong = new long[n][words];
    for (int i = 0; i < n; i++)
      for (int k : neighbors[i]) adjLong[i][k >>> 6] |= 1L << (k & 63);
    // Tautomer classes are O(n), cheap, and accessed as public fields — always compute eagerly.
    computeTautomerClasses();
    applySolventCorrection(solvent);
    adjustWeightsForPH(pH);
    tautomerClassesComputed = true;
    // Canonical labeling and ring counts are lazy (ensureCanonical / ensureRingCounts).
  }

  /** Lazily build BitSet[] adjacency (used by MCS refinement and NLF2/NLF3 builders). */
  BitSet[] getAdj() {
    if (adj == null) {
      BitSet[] a = new BitSet[n];
      for (int i = 0; i < n; i++) {
        a[i] = new BitSet(n);
        for (int k : neighbors[i]) a[i].set(k);
      }
      this.adj = a;
    }
    return adj;
  }

  /** Lazily compute Morgan ranks, canonical labeling, orbit partition, and canonical hash. */
  void ensureCanonical() {
    if (canonicalComputed) return;
    synchronized (this) {
      if (canonicalComputed) return;
      this.morganRank = computeMorganRanks(n, label, neighbors);
      int[][] clResult = computeCanonicalLabeling(n, label, degree, neighbors);
      this.canonicalLabel = clResult[0];
      this.orbit = clResult[1];
      this.canonicalHash = computeCanonicalHash(n, canonicalLabel, neighbors, label);
      canonicalComputed = true;
    }
  }

  /** Lazily compute tautomer class assignments and pKa-based relevance weights. */
  void ensureTautomerClasses() {
    if (tautomerClassesComputed) return;
    synchronized (this) {
      if (tautomerClassesComputed) return;
      computeTautomerClasses();
      tautomerClassesComputed = true;
    }
  }

  /** Lazily compute per-atom ring membership counts (needed for STRICT ring-fusion matching). */
  public void ensureRingCounts() {
    if (ringCountsComputed) return;
    synchronized (this) {
      if (ringCountsComputed) return;
      computeRingCounts();
      ringCountsComputed = true;
    }
  }

  /** Get ring counts, computing lazily if needed. */
  public int[] getRingCounts() {
    ensureRingCounts();
    return ringCount;
  }

  private void computeRingCounts() {
    // Use Relevant Cycle Basis (unique/deterministic) instead of SSSR (non-deterministic).
    // This ensures ringCount is consistent across runs for symmetric molecules like cubane.
    java.util.Arrays.fill(ringCount, 0);
    int[][] relevant = computeRelevantCycles();
    for (int[] r : relevant) {
      for (int atom : r) ringCount[atom]++;
    }
  }

  /**
   * Assign a tautomer class to a set of atoms with a shared relevance weight.
   * If any atom already belongs to an existing class, merge by reusing that
   * class for all atoms in the group (prevents class fracture when
   * tautomeric motifs overlap on shared atoms).
   */
  private void tc(int[] atoms, int cls, float w, float[] wArr) {
    // Merge: if any atom already has a class, reuse it
    for (int a : atoms) if (tautomerClass[a] != -1) { cls = tautomerClass[a]; break; }
    for (int a : atoms) {
      tautomerClass[a] = cls;
      if (wArr[a] == 1.0f) wArr[a] = w;
    }
  }

  void computeTautomerClasses() {
    tautomerClass  = new int[n];
    tautomerWeight = new float[n];
    Arrays.fill(tautomerClass,  -1);
    Arrays.fill(tautomerWeight, 1.0f);
    int classId = 0;

    for (int i = 0; i < n; i++) {
      if (tautomerClass[i] != -1) continue;

      // -----------------------------------------------------------------------
      // T1: Keto/enol  C=O ↔ C-OH  (aliphatic, non-amide)
      //     Detects O of a carbonyl; groups O + adjacent C neighbours.
      //     Weight TW_KETO_ENOL: keto overwhelmingly dominant (pKa ~20).
      //     Amide carbonyls (N on C) handled separately in T3/T4 with lower weight.
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 8 && !aromatic[i]) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
            boolean hasN = false;
            for (int k : neighbors[j]) { if (k != i && atomicNum[k] == 7) { hasN = true; break; } }
            float w = hasN ? TW_AMIDE_IMIDIC : TW_KETO_ENOL;
            int cls = -1;
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 6 && !aromatic[k]) {
                if (cls == -1) { cls = classId++; tautomerClass[i] = cls; tautomerWeight[i] = w; }
                if (tautomerClass[k] == -1) { tautomerClass[k] = cls; if (tautomerWeight[k]==1.0f) tautomerWeight[k]=w; }
              }
            }
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 7) {
                if (cls == -1) { cls = classId++; tautomerClass[i] = cls; tautomerWeight[i] = w; }
                if (tautomerClass[k] == -1) { tautomerClass[k] = cls; if (tautomerWeight[k]==1.0f) tautomerWeight[k]=w; }
              }
            }
            if (cls != -1) break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T2: Thione/thiol  C=S ↔ C-SH  (thione dominant, pKa ~10-11)
      //     Thioamide N-C(=S) ↔ N=C-SH gets higher weight (pKa ~13)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 16 && !aromatic[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
            boolean hasN = false;
            for (int k : neighbors[j]) { if (k != i && atomicNum[k] == 7) { hasN = true; break; } }
            float w = hasN ? TW_THIOAMIDE : TW_THIONE_THIOL;
            int cls = -1;
            for (int k : neighbors[j]) {
              if (k != i && (atomicNum[k] == 6 || atomicNum[k] == 7)) {
                if (cls == -1) { cls = classId++; tautomerClass[i] = cls; tautomerWeight[i] = w; }
                if (tautomerClass[k] == -1) { tautomerClass[k] = cls; if (tautomerWeight[k]==1.0f) tautomerWeight[k]=w; }
              }
            }
            if (cls != -1) break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T3: Nitroso/oxime  C=N-OH ↔ C(=O)-NH  (oxime slightly more stable)
      //     Requires N=C double bond to avoid matching simple amide N-C=O
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && !ring[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 8) {
                int cls = classId++;
                tc(new int[]{i, k}, cls, TW_NITROSO_OXIME, tautomerWeight);
                break;
              }
            }
            if (tautomerClass[i] != -1) break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T4: Phenol/quinone  arom-C-OH ↔ para-C=O  (phenol dominant, pKa ~10)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && aromatic[j] && ring[j]) {
            for (int a : neighbors[j]) {
              if (a != i && atomicNum[a] == 6 && aromatic[a] && ring[a]) {
                for (int b : neighbors[a]) {
                  if (b != j && atomicNum[b] == 6 && aromatic[b] && ring[b]) {
                    for (int c : neighbors[b]) {
                      if (c != a && c != j && atomicNum[c] == 6 && aromatic[c] && ring[c]) {
                        int cls = classId++;
                        tc(new int[]{i, j, c}, cls, TW_PHENOL_QUINONE, tautomerWeight);
                        for (int d : neighbors[c]) {
                          if (atomicNum[d] == 8 && !aromatic[d] && tautomerClass[d] == -1) {
                            tautomerClass[d] = cls; tautomerWeight[d] = TW_PHENOL_QUINONE;
                          }
                        }
                        break;
                      }
                    }
                    if (tautomerClass[i] != -1) break;
                  }
                }
                if (tautomerClass[i] != -1) break;
              }
            }
            if (tautomerClass[i] != -1) break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T5: 1,3-diketone enolisation  C(=O)-C-C(=O)  (pKa ~8-11, pH-sensitive)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
            for (int bridge : neighbors[j]) {
              if (bridge != i && atomicNum[bridge] == 6 && !aromatic[bridge]) {
                for (int m : neighbors[bridge]) {
                  if (m != j && atomicNum[m] == 6) {
                    for (int o2 : neighbors[m]) {
                      if (o2 != bridge && atomicNum[o2] == 8 && !aromatic[o2]) {
                        int cls = (tautomerClass[o2] != -1) ? tautomerClass[o2] : classId++;
                        float w = TW_DIKETONE_ENOL;
                        if (tautomerClass[i]      == -1) { tautomerClass[i]      = cls; tautomerWeight[i]      = w; }
                        if (tautomerClass[bridge] == -1) { tautomerClass[bridge] = cls; tautomerWeight[bridge] = w; }
                        if (tautomerClass[o2]     == -1) { tautomerClass[o2]     = cls; tautomerWeight[o2]     = w; }
                        break;
                      }
                    }
                    if (tautomerClass[i] != -1) break;
                  }
                }
                if (tautomerClass[i] != -1) break;
              }
            }
            if (tautomerClass[i] != -1) break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T6: Aromatic N adjacent to exocyclic C=O  (lactam/2-pyridinone/uracil)
      //     Lactam form dominant at pH 7.4 (pKa ~1 for 2-pyridinone)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && aromatic[i] && ring[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && aromatic[j]) {
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 8 && !aromatic[k] && tautomerClass[k] == -1) {
                int cls = classId++;
                tc(new int[]{i, k}, cls, TW_PYRIDINONE, tautomerWeight);
              }
            }
          }
        }
      }

      // -----------------------------------------------------------------------
      // T7: Aromatic N–N or N–C–N  (imidazole, pyrazole, benzimidazole, indazole)
      //     N1H/N3H symmetric tautomers — weight 0.50
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && aromatic[i] && ring[i] && tautomerClass[i] == -1) {
        // Direct N–N bond (pyrazole/indazole)
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 7 && aromatic[j] && ring[j] && tautomerClass[j] == -1) {
            int cls = classId++;
            tc(new int[]{i, j}, cls, TW_IMIDAZOLE_NH, tautomerWeight);
            break;
          }
        }
        // N–C–N through aromatic C (imidazole/benzimidazole)
        if (tautomerClass[i] == -1) {
          for (int j : neighbors[i]) {
            if (atomicNum[j] == 6 && aromatic[j] && ring[j]) {
              for (int k : neighbors[j]) {
                if (k != i && atomicNum[k] == 7 && aromatic[k] && ring[k] && tautomerClass[k] == -1) {
                  int cls = classId++;
                  tc(new int[]{i, k}, cls, TW_IMIDAZOLE_NH, tautomerWeight);
                  break;
                }
              }
              if (tautomerClass[i] != -1) break;
            }
          }
        }
      }

      // -----------------------------------------------------------------------
      // T8: Amidine  N=C-N ↔ N-C=N  (non-aromatic, symmetric, weight 0.50)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && !aromatic[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 7 && !aromatic[k]) {
                int cls = classId++;
                tc(new int[]{i, j, k}, cls, TW_AMIDINE, tautomerWeight);
                break;
              }
            }
            if (tautomerClass[i] != -1) break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T9: Guanidine  C connected to ≥3 N (symmetric, weight 0.50)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 6 && tautomerClass[i] == -1) {
        List<Integer> nNbrs = new ArrayList<>();
        for (int j : neighbors[i]) { if (atomicNum[j] == 7 && !aromatic[j]) nNbrs.add(j); }
        if (nNbrs.size() >= 3) {
          int cls = classId++;
          tautomerClass[i] = cls; tautomerWeight[i] = TW_GUANIDINE;
          for (int ni : nNbrs) { if (tautomerClass[ni]==-1) { tautomerClass[ni]=cls; tautomerWeight[ni]=TW_GUANIDINE; } }
        }
      }

      // -----------------------------------------------------------------------
      // T10: Urea  O=C(-N)(-N)  — two N on same carbonyl C (dominant, pKa ~14)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
            List<Integer> nn = new ArrayList<>();
            for (int k : neighbors[j]) { if (k != i && atomicNum[k] == 7) nn.add(k); }
            if (nn.size() >= 2) {
              int cls = classId++;
              tautomerClass[i] = cls; tautomerWeight[i] = TW_UREA;
              tautomerClass[j] = cls; tautomerWeight[j] = TW_UREA;
              for (int ni : nn) { if (tautomerClass[ni]==-1) { tautomerClass[ni]=cls; tautomerWeight[ni]=TW_UREA; } }
            }
            break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T11: β-Enaminone  N-C=C-C=O  (vinylogous amide, weight 0.85)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && !aromatic[i] && tautomerClass[i] == -1) {
        outer11:
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && bondOrder(i, j) == 1) {
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 6 && bondOrder(j, k) == 2) {
                for (int m : neighbors[k]) {
                  if (m != j && atomicNum[m] == 6) {
                    for (int o : neighbors[m]) {
                      if (o != k && atomicNum[o] == 8 && bondOrder(m, o) == 2) {
                        int cls = classId++;
                        tc(new int[]{i, j, k, m, o}, cls, TW_ENAMINONE, tautomerWeight);
                        break outer11;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // -----------------------------------------------------------------------
      // T12: Imide  C(=O)-N-C(=O)  (N flanked by two carbonyls, pKa ~9-10)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && tautomerClass[i] == -1) {
        List<Integer> carbonyls = new ArrayList<>();
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6) {
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 8 && bondOrder(j, k) == 2) { carbonyls.add(j); break; }
            }
          }
        }
        if (carbonyls.size() >= 2) {
          int cls = classId++;
          tautomerClass[i] = cls; tautomerWeight[i] = TW_IMIDE;
          for (int c : carbonyls) { if (tautomerClass[c]==-1) { tautomerClass[c]=cls; tautomerWeight[c]=TW_IMIDE; } }
        }
      }

      // -----------------------------------------------------------------------
      // T13: Hydroxamic acid  N(-OH)-C=O ↔ NH-C(=O)-OH  (pKa ~8, weight 0.85)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && tautomerClass[i] == -1) {
        int oh = -1;
        for (int j : neighbors[i]) { if (atomicNum[j] == 8 && !aromatic[j] && bondOrder(i,j)==1) { oh = j; break; } }
        if (oh != -1) {
          for (int j : neighbors[i]) {
            if (atomicNum[j] == 6) {
              for (int k : neighbors[j]) {
                if (k != i && atomicNum[k] == 8 && bondOrder(j, k) == 2) {
                  int cls = classId++;
                  tc(new int[]{i, oh, j, k}, cls, TW_HYDROXAMIC, tautomerWeight);
                  break;
                }
              }
              if (tautomerClass[i] != -1) break;
            }
          }
        }
      }

      // -----------------------------------------------------------------------
      // T14: Hydroxypyrimidine/purine  exocyclic OH on arom-C with ring-N neighbour
      //      Covers adenine/guanine amino-imino, hydroxypyrimidine, cytosine
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 6 && aromatic[j] && ring[j] && bondOrder(i, j) == 1) {
            for (int k : neighbors[j]) {
              if (k != i && atomicNum[k] == 7 && aromatic[k] && ring[k]) {
                int cls = classId++;
                tc(new int[]{i, j, k}, cls, TW_HYDROXYPYRIMIDINE, tautomerWeight);
                break;
              }
            }
            if (tautomerClass[i] != -1) break;
          }
        }
      }

      // -----------------------------------------------------------------------
      // T15: Tetrazole / triazole  N-H tautomers in aromatic rings with ≥2 N-N bonds
      //      (1H/2H symmetric, weight 0.50)
      // -----------------------------------------------------------------------
      if (atomicNum[i] == 7 && aromatic[i] && ring[i] && tautomerClass[i] == -1) {
        List<Integer> adjN = new ArrayList<>();
        for (int j : neighbors[i]) {
          if (atomicNum[j] == 7 && aromatic[j] && ring[j]) adjN.add(j);
        }
        if (adjN.size() >= 2) { // tetrazole (≥3N in ring); also covers 1,2,3-triazole
          for (int j : adjN) {
            if (tautomerClass[j] == -1) {
              int cls = classId++;
              tc(new int[]{i, j}, cls, TW_TETRAZOLE_NH, tautomerWeight);
              break;
            }
          }
        }
      }
    }
  }

  // =========================================================================
  // Tier 2: Solvent-dependent tautomer weight corrections
  //
  // Aprotic/non-aqueous solvents shift keto-enol and related equilibria.
  // Literature pKa shifts (Bordwell 1988; Olmstead 1977):
  //   DMSO:       keto-enol +5 pKa units  -> enol more prevalent (shift -0.15)
  //               amide/lactam +3          -> imidic slightly more prevalent
  //   Methanol:   keto-enol +2             -> small shift (-0.05)
  //   Chloroform: keto-enol +8 (aprotic)   -> much more enol (-0.25)
  // =========================================================================

  /** Adjust tautomer weights for solvent effects. Call after computeTautomerClasses(). */
  void applySolventCorrection(ChemOptions.Solvent solvent) {
    if (solvent == null || solvent == ChemOptions.Solvent.AQUEOUS) return;
    if (tautomerWeight == null) return;

    float ketoShift, amideShift, generalShift;
    switch (solvent) {
      case DMSO:
        ketoShift = -0.15f;
        amideShift = -0.08f;
        generalShift = -0.05f;
        break;
      case CHLOROFORM:
        ketoShift = -0.25f;
        amideShift = -0.12f;
        generalShift = -0.08f;
        break;
      case METHANOL:
        ketoShift = -0.05f;
        amideShift = -0.02f;
        generalShift = -0.01f;
        break;
      case ACETONITRILE:
        ketoShift = -0.10f;
        amideShift = -0.05f;
        generalShift = -0.03f;
        break;
      case DIETHYL_ETHER:
        ketoShift = -0.20f;
        amideShift = -0.10f;
        generalShift = -0.06f;
        break;
      default:
        return;
    }

    for (int i = 0; i < n; i++) {
      if (tautomerClass[i] == -1) continue;
      float w = tautomerWeight[i];
      if (w >= 1.0f) continue;

      float shift;
      if (w >= 0.96f) {
        shift = (w >= 0.97f) ? amideShift : ketoShift;
        if (Math.abs(w - TW_KETO_ENOL) < 0.005f) shift = ketoShift;
      } else if (w >= 0.93f) {
        shift = amideShift;
      } else if (w >= 0.84f) {
        shift = generalShift;
      } else {
        shift = generalShift;
      }

      tautomerWeight[i] = Math.max(0.05f, Math.min(0.99f, w + shift));
    }
  }

  /**
   * Adjust tautomer weights based on pH deviation from reference (7.4).
   * Uses simplified Henderson-Hasselbalch scaling: as pH moves away from
   * physiological, weights shift toward 0.5 (equal tautomer population).
   */
  void adjustWeightsForPH(double pH) {
    if (Math.abs(pH - 7.4) < 0.01) return; // no adjustment at reference pH
    float shift = (float) (0.1 * (pH - 7.4));
    for (int i = 0; i < n; i++) {
      if (tautomerClass[i] == -1) continue;
      float w = tautomerWeight[i];
      if (w == 1.0f) continue; // non-tautomeric atom
      tautomerWeight[i] = Math.max(0.1f, Math.min(0.99f, w + shift));
    }
  }

  private static int[] computeMorganRanks(int n, int[] initLabel, int[][] neighbors) {
    int[] rank = new int[n];
    System.arraycopy(initLabel, 0, rank, 0, n);
    int[] rankNew = new int[n];
    int[] nbSorted = new int[16];
    for (int iter = 0; iter < 8; iter++) {
      HashSet<Integer> prevSet = new HashSet<>();
      for (int v = 0; v < n; v++) prevSet.add(rank[v]);
      int prevDistinct = prevSet.size();
      for (int v = 0; v < n; v++) {
        int[] nbs = neighbors[v];
        int deg = nbs.length;
        if (deg > nbSorted.length) nbSorted = new int[deg];
        for (int k = 0; k < deg; k++) nbSorted[k] = rank[nbs[k]];
        java.util.Arrays.sort(nbSorted, 0, deg);
        int h = rank[v] * HASH_PRIME;
        for (int k = 0; k < deg; k++) h = h * 31 + nbSorted[k];
        rankNew[v] = h;
      }
      System.arraycopy(rankNew, 0, rank, 0, n);
      HashSet<Integer> newSet = new HashSet<>();
      for (int v = 0; v < n; v++) newSet.add(rank[v]);
      if (newSet.size() <= prevDistinct) break;
    }
    return rank;
  }

  private static final int MAX_SEARCH_NODES = 50000;
  private static final int CANON_SEARCH_LIMIT = 200;

  private static int[][] computeCanonicalLabeling(int n, int[] label, int[] degree, int[][] neighbors) {
    if (n == 0) return new int[][] {new int[0], new int[0]};
    int[] mRank = new int[n];
    System.arraycopy(label, 0, mRank, 0, n);
    int[] mNew = new int[n];
    int[] scratch = new int[16];
    for (int iter = 0; iter < 8; iter++) {
      int prevDistinct;
      { HashSet<Integer> s = new HashSet<>(); for (int v = 0; v < n; v++) s.add(mRank[v]); prevDistinct = s.size(); }
      for (int v = 0; v < n; v++) {
        int[] nbs = neighbors[v];
        int d = nbs.length;
        if (d > scratch.length) scratch = new int[d];
        for (int k = 0; k < d; k++) scratch[k] = mRank[nbs[k]];
        Arrays.sort(scratch, 0, d);
        int h = mRank[v] * HASH_PRIME;
        for (int k = 0; k < d; k++) h = h * 31 + scratch[k];
        mNew[v] = h;
      }
      System.arraycopy(mNew, 0, mRank, 0, n);
      int newDistinct;
      { HashSet<Integer> s = new HashSet<>(); for (int v = 0; v < n; v++) s.add(mRank[v]); newDistinct = s.size(); }
      if (newDistinct <= prevDistinct) break;
    }
    int[] uf = new int[n];
    for (int i = 0; i < n; i++) uf[i] = i;
    Integer[] sorted = new Integer[n];
    for (int i = 0; i < n; i++) sorted[i] = i;
    final int[] mr = mRank;
    Arrays.sort(sorted, (a, b) -> {
      int c = Integer.compare(label[a], label[b]);
      if (c != 0) return c;
      c = Integer.compare(degree[a], degree[b]);
      return c != 0 ? c : Integer.compare(mr[a], mr[b]);
    });
    int[] initPerm = new int[n];
    boolean[] initCellEnd = new boolean[n];
    for (int i = 0; i < n; i++) initPerm[i] = sorted[i];
    for (int i = 0; i < n - 1; i++) {
      int vi = sorted[i], vj = sorted[i + 1];
      initCellEnd[i] = (label[vi] != label[vj] || degree[vi] != degree[vj] || mr[vi] != mr[vj]);
    }
    initCellEnd[n - 1] = true;
    if (n > CANON_SEARCH_LIMIT) {
      int cs = 0;
      for (int i = 0; i < n; i++) {
        if (initCellEnd[i]) {
          for (int j = cs + 1; j <= i; j++) ufUnion(uf, initPerm[cs], initPerm[j]);
          cs = i + 1;
        }
      }
      int[] canonLabel = new int[n];
      for (int pos = 0; pos < n; pos++) canonLabel[initPerm[pos]] = pos;
      return new int[][] {canonLabel, buildOrbits(uf, n)};
    }
    refinePartition(n, initPerm, initCellEnd, neighbors, label, -1);
    int[] bestPerm = null;
    int nodeCount = 0;
    boolean budgetExceeded = false;
    ArrayDeque<int[]> permStack = new ArrayDeque<>();
    ArrayDeque<boolean[]> cellEndStack = new ArrayDeque<>();
    int targetCell = findSmallestNonSingleton(n, initCellEnd);
    if (targetCell < 0) {
      bestPerm = initPerm.clone();
    } else {
      int cellStart = 0;
      for (int i = 0; i < n; i++) {
        if (i > 0 && initCellEnd[i - 1]) cellStart = i;
        if (i == targetCell) break;
      }
      for (int i = targetCell; i >= cellStart; i--) {
        int[] p = initPerm.clone();
        boolean[] ce = initCellEnd.clone();
        if (i != cellStart) {
          int tmp = p[i];
          System.arraycopy(p, cellStart, p, cellStart + 1, i - cellStart);
          p[cellStart] = tmp;
        }
        ce[cellStart] = true;
        refinePartition(n, p, ce, neighbors, label, cellStart);
        permStack.push(p);
        cellEndStack.push(ce);
        nodeCount++;
      }
    }
    while (!permStack.isEmpty() && !budgetExceeded) {
      int[] perm = permStack.pop();
      boolean[] cellEnd = cellEndStack.pop();
      int nc = findSmallestNonSingleton(n, cellEnd);
      if (nc < 0) {
        if (bestPerm == null || comparePerm(perm, bestPerm, n, label, neighbors) < 0) {
          bestPerm = perm.clone();
        } else if (comparePerm(perm, bestPerm, n, label, neighbors) == 0) {
          for (int i = 0; i < n; i++) ufUnion(uf, perm[i], bestPerm[i]);
        }
        continue;
      }
      if (bestPerm != null && partialCompare(perm, bestPerm, n, cellEnd, label, neighbors) > 0) continue;
      int cellStart = 0;
      for (int i = 0; i < n; i++) {
        if (i > 0 && cellEnd[i - 1]) cellStart = i;
        if (i == nc) break;
      }
      int cellSize = nc - cellStart + 1;
      if (nodeCount + cellSize > MAX_SEARCH_NODES) { budgetExceeded = true; break; }
      for (int i = nc; i >= cellStart; i--) {
        int[] p = perm.clone();
        boolean[] ce = cellEnd.clone();
        if (i != cellStart) {
          int tmp = p[i];
          System.arraycopy(p, cellStart, p, cellStart + 1, i - cellStart);
          p[cellStart] = tmp;
        }
        ce[cellStart] = true;
        refinePartition(n, p, ce, neighbors, label, cellStart);
        permStack.push(p);
        cellEndStack.push(ce);
        nodeCount++;
      }
    }
    if (bestPerm == null) bestPerm = initPerm.clone();
    int[] canonLabel = new int[n];
    for (int pos = 0; pos < n; pos++) canonLabel[bestPerm[pos]] = pos;
    int cs = 0;
    for (int i = 0; i < n; i++) {
      if (initCellEnd[i]) {
        for (int j = cs + 1; j <= i; j++) ufUnion(uf, initPerm[cs], initPerm[j]);
        cs = i + 1;
      }
    }
    return new int[][] {canonLabel, buildOrbits(uf, n)};
  }

  private static int[] buildOrbits(int[] uf, int n) {
    int[] orbit = new int[n];
    for (int i = 0; i < n; i++) orbit[i] = ufFind(uf, i);
    int[] orbitMin = new int[n];
    Arrays.fill(orbitMin, n);
    for (int i = 0; i < n; i++) { int r = orbit[i]; if (i < orbitMin[r]) orbitMin[r] = i; }
    for (int i = 0; i < n; i++) orbit[i] = orbitMin[orbit[i]];
    return orbit;
  }

  private static int ufFind(int[] uf, int x) {
    while (uf[x] != x) { uf[x] = uf[uf[x]]; x = uf[x]; }
    return x;
  }

  private static void ufUnion(int[] uf, int a, int b) {
    a = ufFind(uf, a); b = ufFind(uf, b);
    if (a != b) { if (a < b) uf[b] = a; else uf[a] = b; }
  }

  private static int findSmallestNonSingleton(int n, boolean[] cellEnd) {
    int bestSize = n + 1, bestEnd = -1, cellStart = 0;
    for (int i = 0; i < n; i++) {
      if (cellEnd[i]) {
        int size = i - cellStart + 1;
        if (size > 1 && size < bestSize) { bestSize = size; bestEnd = i; }
        cellStart = i + 1;
      }
    }
    return bestEnd;
  }

  private static void refinePartition(
      int n, int[] perm, boolean[] cellEnd, int[][] neighbors, int[] label, int targetPos) {
    int[] inv = new int[n];
    for (int i = 0; i < n; i++) inv[perm[i]] = i;
    boolean changed = true;
    int maxIter = n * 2 + 10;
    while (changed && maxIter-- > 0) {
      changed = false;
      int sStart = 0;
      for (int sEnd = 0; sEnd < n; sEnd++) {
        if (!cellEnd[sEnd]) continue;
        int cStart = 0;
        for (int cEnd = 0; cEnd < n; cEnd++) {
          if (!cellEnd[cEnd]) continue;
          int cSize = cEnd - cStart + 1;
          if (cSize <= 1) { cStart = cEnd + 1; continue; }
          int[] count = new int[cSize];
          for (int ci = 0; ci < cSize; ci++) {
            int v = perm[cStart + ci], cnt = 0;
            for (int nb : neighbors[v]) {
              int nbPos = inv[nb];
              if (nbPos >= sStart && nbPos <= sEnd) cnt++;
            }
            count[ci] = cnt;
          }
          boolean allSame = true;
          for (int ci = 1; ci < cSize; ci++) if (count[ci] != count[0]) { allSame = false; break; }
          if (allSame) { cStart = cEnd + 1; continue; }
          Integer[] idx = new Integer[cSize];
          for (int ci = 0; ci < cSize; ci++) idx[ci] = ci;
          final int fcs = cStart;
          final int[] cnt = count, prm = perm;
          Arrays.sort(idx, (a, bx) -> {
            int c = Integer.compare(cnt[a], cnt[bx]);
            if (c != 0) return c;
            c = Integer.compare(label[prm[fcs + a]], label[prm[fcs + bx]]);
            return c != 0 ? c : Integer.compare(prm[fcs + a], prm[fcs + bx]);
          });
          int[] tmp = new int[cSize];
          for (int ci = 0; ci < cSize; ci++) tmp[ci] = perm[cStart + idx[ci]];
          System.arraycopy(tmp, 0, perm, cStart, cSize);
          for (int ci = 0; ci < cSize; ci++) inv[perm[cStart + ci]] = cStart + ci;
          for (int ci = 0; ci < cSize - 1; ci++) {
            boolean wasBoundary = (cStart + ci == cEnd);
            boolean newBoundary = (cnt[idx[ci]] != cnt[idx[ci + 1]]);
            cellEnd[cStart + ci] = newBoundary || wasBoundary;
            if (newBoundary && !wasBoundary) changed = true;
          }
          cellEnd[cEnd] = true;
          cStart = cEnd + 1;
        }
        sStart = sEnd + 1;
      }
    }
  }

  private static int comparePerm(int[] perm1, int[] perm2, int n, int[] label, int[][] neighbors) {
    int[] inv1 = new int[n], inv2 = new int[n];
    for (int i = 0; i < n; i++) { inv1[perm1[i]] = i; inv2[perm2[i]] = i; }
    for (int pos = 0; pos < n; pos++) {
      int v1 = perm1[pos], v2 = perm2[pos];
      int c = Integer.compare(label[v1], label[v2]);
      if (c != 0) return c;
      int[] nb1 = neighbors[v1], nb2 = neighbors[v2];
      c = Integer.compare(nb1.length, nb2.length);
      if (c != 0) return c;
      int[] cn1 = new int[nb1.length], cn2 = new int[nb2.length];
      for (int k = 0; k < nb1.length; k++) cn1[k] = inv1[nb1[k]];
      for (int k = 0; k < nb2.length; k++) cn2[k] = inv2[nb2[k]];
      Arrays.sort(cn1); Arrays.sort(cn2);
      for (int k = 0; k < nb1.length; k++) {
        c = Integer.compare(cn1[k], cn2[k]);
        if (c != 0) return c;
      }
    }
    return 0;
  }

  private static int partialCompare(
      int[] perm, int[] bestPerm, int n, boolean[] cellEnd, int[] label, int[][] neighbors) {
    int cellStart = 0;
    for (int pos = 0; pos < n; pos++) {
      if (cellEnd[pos]) {
        if (pos == cellStart) {
          int c = Integer.compare(label[perm[pos]], label[bestPerm[pos]]);
          if (c != 0) return c;
        }
        cellStart = pos + 1;
      }
    }
    return 0;
  }

  private static long computeCanonicalHash(int n, int[] canonLabel, int[][] neighbors, int[] label) {
    int[] inv = new int[n];
    for (int i = 0; i < n; i++) inv[canonLabel[i]] = i;
    long hash = 0;
    for (int cp = 0; cp < n; cp++) hash = hash * HASH_PRIME + label[inv[cp]];
    for (int cp = 0; cp < n; cp++) {
      int v = inv[cp];
      int[] nbs = neighbors[v];
      int[] cNbs = new int[nbs.length];
      for (int k = 0; k < nbs.length; k++) cNbs[k] = canonLabel[nbs[k]];
      Arrays.sort(cNbs);
      for (int cn : cNbs) hash = hash * HASH_PRIME + ((long) Math.min(cp, cn) * n + Math.max(cp, cn));
    }
    return hash;
  }

  public int[] getOrbits() { ensureCanonical(); return orbit.clone(); }
  public int[] getCanonicalLabeling() { ensureCanonical(); return canonicalLabel.clone(); }
  public long getCanonicalHash() { ensureCanonical(); return canonicalHash; }

  // ---- Canonical SMILES generation ----

  private static final Map<Integer, String> ORGANIC_SYMBOLS = new HashMap<>();
  static {
    ORGANIC_SYMBOLS.put(5, "B"); ORGANIC_SYMBOLS.put(6, "C"); ORGANIC_SYMBOLS.put(7, "N");
    ORGANIC_SYMBOLS.put(8, "O"); ORGANIC_SYMBOLS.put(15, "P"); ORGANIC_SYMBOLS.put(16, "S");
    ORGANIC_SYMBOLS.put(9, "F"); ORGANIC_SYMBOLS.put(17, "Cl"); ORGANIC_SYMBOLS.put(35, "Br");
    ORGANIC_SYMBOLS.put(53, "I");
  }

  private static final String[] ELEMENT_SYMBOL = new String[119];
  static {
    String[] syms = {
      "?","H","He","Li","Be","B","C","N","O","F","Ne","Na","Mg","Al","Si","P","S",
      "Cl","Ar","K","Ca","Sc","Ti","V","Cr","Mn","Fe","Co","Ni","Cu","Zn","Ga",
      "Ge","As","Se","Br","Kr","Rb","Sr","Y","Zr","Nb","Mo","Tc","Ru","Rh","Pd",
      "Ag","Cd","In","Sn","Sb","Te","I","Xe","Cs","Ba","La","Ce","Pr","Nd","Pm",
      "Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm","Yb","Lu","Hf","Ta","W","Re","Os",
      "Ir","Pt","Au","Hg","Tl","Pb","Bi","Po","At","Rn","Fr","Ra","Ac","Th","Pa",
      "U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr","Rf","Db","Sg",
      "Bh","Hs","Mt","Ds","Rg","Cn","Nh","Fl","Mc","Lv","Ts","Og"
    };
    System.arraycopy(syms, 0, ELEMENT_SYMBOL, 0, Math.min(syms.length, ELEMENT_SYMBOL.length));
  }

  public String toCanonicalSmiles() {
    if (n == 0) return "";
    ensureCanonical();
    int[] inv = new int[n];
    for (int i = 0; i < n; i++) inv[canonicalLabel[i]] = i;
    int[] color = new int[n];
    @SuppressWarnings("unchecked")
    List<int[]>[] ringClosures = new List[n];
    Set<Long> ringEdges = new HashSet<>();
    int[] nextRing = {1};
    for (int ci = 0; ci < n; ci++) {
      int start = inv[ci];
      if (color[start] == 0) preScanDfs(start, -1, color, ringClosures, ringEdges, nextRing);
    }
    boolean[] visited = new boolean[n];
    StringBuilder sb = new StringBuilder();
    for (int ci = 0; ci < n; ci++) {
      int start = inv[ci];
      if (visited[start]) continue;
      if (sb.length() > 0) sb.append('.');
      emitSmiles(start, -1, visited, sb, ringClosures, ringEdges);
    }
    return sb.toString();
  }

  private void preScanDfs(int atom, int parent, int[] color, List<int[]>[] rc, Set<Long> ringEdges, int[] nextRing) {
    color[atom] = 1;
    int[] sorted = sortedNeighborsByCanonical(atom);
    int skippedParent = 0;
    for (int nb : sorted) {
      if (nb == parent && skippedParent == 0) { skippedParent = 1; continue; }
      if (color[nb] == 0) {
        preScanDfs(nb, atom, color, rc, ringEdges, nextRing);
      } else if (color[nb] == 1) {
        int rid = nextRing[0]++;
        if (rc[nb] == null) rc[nb] = new ArrayList<>();
        if (rc[atom] == null) rc[atom] = new ArrayList<>();
        rc[nb].add(new int[] {rid, atom});
        rc[atom].add(new int[] {rid, nb});
        ringEdges.add(bondKey(atom, nb));
      }
    }
    color[atom] = 2;
  }

  private void emitSmiles(int atom, int parent, boolean[] visited, StringBuilder sb, List<int[]>[] rc, Set<Long> ringEdges) {
    visited[atom] = true;
    writeAtom(atom, sb);
    if (rc[atom] != null) {
      for (int[] entry : rc[atom]) {
        if (!visited[entry[1]]) writeBondSymbol(atom, entry[1], sb);
        writeRingDigit(entry[0], sb);
      }
    }
    int[] sorted = sortedNeighborsByCanonical(atom);
    int childCount = 0;
    for (int nb : sorted) if (!visited[nb] && !ringEdges.contains(bondKey(atom, nb))) childCount++;
    int childIdx = 0;
    for (int nb : sorted) {
      if (visited[nb] || ringEdges.contains(bondKey(atom, nb))) continue;
      childIdx++;
      boolean needParen = childCount > 1 && childIdx < childCount;
      if (needParen) sb.append('(');
      writeBondSymbol(atom, nb, sb);
      emitSmiles(nb, atom, visited, sb, rc, ringEdges);
      if (needParen) sb.append(')');
    }
  }

  private int[] sortedNeighborsByCanonical(int atom) {
    int[] sorted = neighbors[atom].clone();
    for (int a = 0; a < sorted.length - 1; a++)
      for (int b2 = a + 1; b2 < sorted.length; b2++)
        if (canonicalLabel[sorted[a]] > canonicalLabel[sorted[b2]]) {
          int tmp = sorted[a]; sorted[a] = sorted[b2]; sorted[b2] = tmp;
        }
    return sorted;
  }

  private void writeAtom(int atom, StringBuilder sb) {
    int z = atomicNum[atom], charge = formalCharge[atom];
    boolean arom = aromatic[atom];
    String sym = ORGANIC_SYMBOLS.get(z);
    if (sym != null && charge == 0) {
      sb.append(arom ? Character.toLowerCase(sym.charAt(0)) : sym);
    } else {
      sb.append('[');
      String elemSym = (z >= 0 && z < ELEMENT_SYMBOL.length && ELEMENT_SYMBOL[z] != null) ? ELEMENT_SYMBOL[z] : "?";
      if (arom) {
        sb.append(Character.toLowerCase(elemSym.charAt(0)));
        if (elemSym.length() > 1) sb.append(elemSym.substring(1));
      } else { sb.append(elemSym); }
      if (charge > 0) { sb.append('+'); if (charge > 1) sb.append(charge); }
      else if (charge < 0) { sb.append('-'); if (charge < -1) sb.append(-charge); }
      sb.append(']');
    }
  }

  private void writeBondSymbol(int from, int to, StringBuilder sb) {
    int order = bondOrder(from, to);
    boolean fromArom = aromatic[from], toArom = aromatic[to];
    if (order == 4 || (fromArom && toArom)) return;
    if (order == 2) sb.append('=');
    else if (order == 3) sb.append('#');
    else if (order == 1 && (fromArom != toArom)) sb.append('-');
  }

  private void writeRingDigit(int rid, StringBuilder sb) {
    if (rid < 10) sb.append(rid);
    else { sb.append('%'); sb.append(rid); }
  }

  // ---- Builder ----

  public static final class Builder {
    private int n;
    private int[] atomicNum, formalCharge, massNumber;
    private boolean[] ring, aromatic;
    private int[][] neighbors, bondOrders;
    private boolean[][] bondRings, bondAroms;
    private int[] tetraChirality;
    private int[][] dbStereoConf;

    public Builder atomCount(int n) { this.n = n; return this; }
    public Builder atomicNumbers(int[] atomicNum) { this.atomicNum = atomicNum; return this; }
    public Builder formalCharges(int[] formalCharge) { this.formalCharge = formalCharge; return this; }
    public Builder massNumbers(int[] massNumber) { this.massNumber = massNumber; return this; }
    public Builder ringFlags(boolean[] ring) { this.ring = ring; return this; }
    public Builder aromaticFlags(boolean[] aromatic) { this.aromatic = aromatic; return this; }
    public Builder neighbors(int[][] neighbors) { this.neighbors = neighbors; return this; }
    public Builder bondOrders(int[][] bondOrders) { this.bondOrders = bondOrders; return this; }
    public Builder bondRingFlags(boolean[][] bondRings) { this.bondRings = bondRings; return this; }
    public Builder bondAromaticFlags(boolean[][] bondAroms) { this.bondAroms = bondAroms; return this; }
    public Builder tetrahedralChirality(int[] tetraChirality) { this.tetraChirality = tetraChirality; return this; }
    public Builder doubleBondStereo(int[][] dbStereoConf) { this.dbStereoConf = dbStereoConf; return this; }

    public MolGraph build() {
      if (atomicNum == null || atomicNum.length != n)
        throw new IllegalArgumentException("atomicNumbers must have length == atomCount");
      if (neighbors == null || neighbors.length != n)
        throw new IllegalArgumentException("neighbors must have length == atomCount");
      return new MolGraph(this);
    }
  }

  // ---- NLF helpers (package-accessible) ----

  static final int[] EMPTY_NLF = new int[0];

  static int[] freqMapToSortedArray(Map<Integer, Integer> freq) {
    if (freq.isEmpty()) return EMPTY_NLF;
    int[] arr = new int[freq.size() * 2];
    int k = 0;
    for (Map.Entry<Integer, Integer> e : freq.entrySet()) { arr[k++] = e.getKey(); arr[k++] = e.getValue(); }
    int pairs = freq.size();
    for (int i = 1; i < pairs; i++) {
      int keyLabel = arr[i * 2], keyFreq = arr[i * 2 + 1];
      int j = i - 1;
      while (j >= 0 && arr[j * 2] > keyLabel) {
        arr[(j + 1) * 2] = arr[j * 2];
        arr[(j + 1) * 2 + 1] = arr[j * 2 + 1];
        j--;
      }
      arr[(j + 1) * 2] = keyLabel;
      arr[(j + 1) * 2 + 1] = keyFreq;
    }
    return arr;
  }

  /**
   * NLF label: atomicNum + aromaticity, WITHOUT ring bit.
   * Ring membership is a one-directional constraint (ring query must match ring target,
   * but non-ring query may match ring target), so including it in NLF would
   * over-prune valid substructure matches.  Matches C++ nlfLabel().
   */
  static int nlfLabel(MolGraph g, int idx) {
    return (g.atomicNum[idx] << 1) | (g.aromatic[idx] ? 1 : 0);
  }

  static int[] buildNLF1(MolGraph g, int idx) {
    int[] nbs = g.neighbors[idx];
    int deg = nbs.length;
    if (deg == 0) return EMPTY_NLF;
    // Fast path: avoid HashMap for small neighborhoods (common case: degree 1-6).
    // Collect labels, sort, then run-length encode.
    int[] labels = new int[deg];
    for (int i = 0; i < deg; i++) labels[i] = nlfLabel(g, nbs[i]);
    Arrays.sort(labels);
    // Count distinct labels
    int distinct = 1;
    for (int i = 1; i < deg; i++) if (labels[i] != labels[i - 1]) distinct++;
    int[] arr = new int[distinct * 2];
    int k = 0;
    arr[0] = labels[0]; arr[1] = 1;
    for (int i = 1; i < deg; i++) {
      if (labels[i] == labels[i - 1]) { arr[k + 1]++; }
      else { k += 2; arr[k] = labels[i]; arr[k + 1] = 1; }
    }
    return arr;
  }

  static int[] buildNLF2(MolGraph g, int idx) {
    Map<Integer, Integer> freq = new HashMap<>();
    BitSet direct = g.getAdj()[idx];
    BitSet seen = new BitSet(g.n);
    for (int nb : g.neighbors[idx])
      for (int j : g.neighbors[nb]) {
        if (j == idx || direct.get(j) || seen.get(j)) continue;
        seen.set(j);
        freq.merge(nlfLabel(g, j), 1, Integer::sum);
      }
    return freqMapToSortedArray(freq);
  }

  static int[] buildNLF3(MolGraph g, int idx) {
    Map<Integer, Integer> freq = new HashMap<>();
    BitSet level1 = g.getAdj()[idx];
    BitSet level2 = new BitSet(g.n);
    for (int v = level1.nextSetBit(0); v >= 0; v = level1.nextSetBit(v + 1))
      for (int j : g.neighbors[v]) if (j != idx && !level1.get(j)) level2.set(j);
    BitSet level3 = new BitSet(g.n);
    for (int v = level2.nextSetBit(0); v >= 0; v = level2.nextSetBit(v + 1))
      for (int j : g.neighbors[v]) if (j != idx && !level1.get(j) && !level2.get(j)) level3.set(j);
    for (int j = level3.nextSetBit(0); j >= 0; j = level3.nextSetBit(j + 1))
      freq.merge(nlfLabel(g, j), 1, Integer::sum);
    return freqMapToSortedArray(freq);
  }

  // ---------------------------------------------------------------------------
  // Lenient SMILES pre-sanitiser (parity with C++ ParseOptions::lenient)
  // ---------------------------------------------------------------------------

  /**
   * Best-effort sanitisation of a SMILES string before CDK parsing.
   * <ul>
   *   <li>Balances parentheses: appends missing {@code )} or strips trailing extra {@code )}</li>
   *   <li>Removes unclosed ring-digit openings (single digits and {@code %nn} notation)</li>
   * </ul>
   *
   * @param smi the raw SMILES string
   * @return a cleaned SMILES that CDK's SmilesParser is more likely to accept
   */
  public static String sanitizeSmiles(String smi) {
    if (smi == null || smi.isEmpty()) return smi;

    // --- Pass 1: balance parentheses ---
    int depth = 0;
    for (int i = 0; i < smi.length(); i++) {
      char c = smi.charAt(i);
      if (c == '[') { // skip bracket atoms entirely
        while (i < smi.length() - 1 && smi.charAt(i) != ']') i++;
      } else if (c == '(') {
        depth++;
      } else if (c == ')') {
        if (depth > 0) depth--;
        // else: will be stripped below
      }
    }

    StringBuilder sb = new StringBuilder(smi.length() + depth);
    int excess = 0; // tracks extra ')' that have no matching '('
    int openCount = 0;
    for (int i = 0; i < smi.length(); i++) {
      char c = smi.charAt(i);
      if (c == '[') {
        int start = i;
        while (i < smi.length() - 1 && smi.charAt(i) != ']') i++;
        sb.append(smi, start, i + 1);
        continue;
      }
      if (c == '(') {
        openCount++;
        sb.append(c);
      } else if (c == ')') {
        if (openCount > 0) {
          openCount--;
          sb.append(c);
        }
        // else: skip extra closing paren
      } else {
        sb.append(c);
      }
    }
    // Append missing closing parens
    for (int i = 0; i < openCount; i++) sb.append(')');

    String balanced = sb.toString();

    // --- Pass 2: remove unclosed ring digits ---
    // Track which ring digits are opened but never closed
    Map<Integer, Integer> ringFirstPos = new LinkedHashMap<>();
    Set<Integer> closedRings = new HashSet<>();
    for (int i = 0; i < balanced.length(); i++) {
      char c = balanced.charAt(i);
      if (c == '[') {
        while (i < balanced.length() - 1 && balanced.charAt(i) != ']') i++;
        continue;
      }
      int ringNum = -1;
      int consumed = 0;
      if (c == '%' && i + 2 < balanced.length()
          && Character.isDigit(balanced.charAt(i + 1))
          && Character.isDigit(balanced.charAt(i + 2))) {
        ringNum = (balanced.charAt(i + 1) - '0') * 10 + (balanced.charAt(i + 2) - '0');
        consumed = 3;
      } else if (Character.isDigit(c) && i > 0) {
        // Only treat as ring digit if preceded by an atom character
        char prev = balanced.charAt(i - 1);
        if (prev == ']' || Character.isLetter(prev) || Character.isDigit(prev)) {
          ringNum = c - '0';
          consumed = 1;
        }
      }
      if (ringNum >= 0) {
        if (ringFirstPos.containsKey(ringNum) && !closedRings.contains(ringNum)) {
          closedRings.add(ringNum);
          ringFirstPos.remove(ringNum);
        } else {
          ringFirstPos.put(ringNum, i);
        }
        if (consumed > 1) i += consumed - 1;
      }
    }

    if (ringFirstPos.isEmpty()) return balanced;

    // Rebuild string, stripping unclosed ring references
    Set<Integer> removePositions = new HashSet<>(ringFirstPos.values());
    // For %nn notation, also remove the two following digits
    Map<Integer, Integer> posToLen = new HashMap<>();
    for (Map.Entry<Integer, Integer> entry : ringFirstPos.entrySet()) {
      int pos = entry.getValue();
      if (pos < balanced.length() && balanced.charAt(pos) == '%') {
        posToLen.put(pos, 3);
      } else {
        posToLen.put(pos, 1);
      }
    }

    StringBuilder result = new StringBuilder(balanced.length());
    for (int i = 0; i < balanced.length(); i++) {
      if (posToLen.containsKey(i)) {
        i += posToLen.get(i) - 1; // skip
      } else {
        result.append(balanced.charAt(i));
      }
    }
    return result.toString();
  }

  static boolean nlfOk(int[] fq, int[] ft) {
    int fi = 0, ti = 0;
    while (fi < fq.length) {
      int fLabel = fq[fi], fFreq = fq[fi + 1];
      while (ti < ft.length && ft[ti] < fLabel) ti += 2;
      if (ti >= ft.length || ft[ti] != fLabel || ft[ti + 1] < fFreq) return false;
      fi += 2;
    }
    return true;
  }

  static boolean nlfCheckOk(
      int qi, int tj, int[][] qNLF1, int[][] tNLF1, int[][] qNLF2, int[][] tNLF2,
      int[][] qNLF3, int[][] tNLF3, boolean useTwoHop, boolean useThreeHop) {
    if (!nlfOk(qNLF1[qi], tNLF1[tj])) return false;
    if (useTwoHop && !nlfOk(qNLF2[qi], tNLF2[tj])) return false;
    return !useThreeHop || nlfOk(qNLF3[qi], tNLF3[tj]);
  }

  @FunctionalInterface
  interface NLFBuilder {
    int[] build(MolGraph g, int idx);
  }

  static int[][] buildAllNLF(MolGraph g, NLFBuilder builder) {
    int[][] nlf = new int[g.n][];
    for (int i = 0; i < g.n; i++) nlf[i] = builder.build(g, i);
    return nlf;
  }

  // ---- Bond compatibility (ChemOps) ----

  static final class ChemOps {
    static boolean bondsCompatible(MolGraph g1, int qi, int qk, MolGraph g2, int tj, int tk, ChemOptions C) {
      int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
      if (qOrd == 0 || tOrd == 0) return false;
      // Tautomer-aware: relax bond ORDER (single/double interchangeable)
      // but still enforce aromaticity, stereo, and ring constraints.
      boolean tautBondRelax = C.tautomerAware && g1.tautomerClass != null && g2.tautomerClass != null
          && g1.tautomerClass[qi] != -1 && g1.tautomerClass[qk] != -1
          && g2.tautomerClass[tj] != -1 && g2.tautomerClass[tk] != -1;
      // Strict aromaticity: aromatic bonds must match aromatic bonds (no ring guard needed)
      if (C.aromaticityMode == ChemOptions.AromaticityMode.STRICT
          && g1.bondAromatic(qi, qk) != g2.bondAromatic(tj, tk)) return false;
      if (C.useBondStereo) {
        int qConf = g1.dbStereo(qi, qk), tConf = g2.dbStereo(tj, tk);
        if (qConf != 0 && tConf != 0 && qConf != tConf) return false;
      }
      if (C.ringMatchesRingOnly && g1.bondInRing(qi, qk) && !g2.bondInRing(tj, tk)) return false;
      if (tautBondRelax) return true;  // bond order relaxed for tautomeric bonds
      if (C.matchBondOrder == ChemOptions.BondOrderMode.ANY) return true;
      if (qOrd == tOrd) return true;
      if (C.matchBondOrder == ChemOptions.BondOrderMode.LOOSE) return true;
      if (C.aromaticityMode == ChemOptions.AromaticityMode.FLEXIBLE) {
        boolean qa = g1.bondAromatic(qi, qk), ta = g2.bondAromatic(tj, tk);
        if ((qa && ta) || (qa && (tOrd == 1 || tOrd == 2)) || (ta && (qOrd == 1 || qOrd == 2))) return true;
      }
      return false;
    }
  }
}
