/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 * See the NOTICE file for attribution, trademark, and algorithm IP terms. */
package com.bioinception.smsd.core;

import org.openscience.cdk.interfaces.IAtomContainer;

/**
 * Fingerprint computation engine for SMSD: path, MCS-aware, and circular (ECFP/FCFP) fingerprints.
 *
 * <p>All fingerprints are returned as {@code long[]} bitsets. Use the format conversion methods
 * ({@link #toBitSet}, {@link #toHex}, {@link #toBinaryString}) for interop with databases and REST APIs.
 *
 * <p>For batch workloads, pre-convert molecules to {@link MolGraph} once and use the MolGraph overloads
 * to avoid repeated IAtomContainer→MolGraph conversion overhead.
 *
 * @author Syed Asad Rahman
 * @since 6.0
 */
public final class FingerprintEngine {

  /** FNV-1a 64-bit seed (offset basis). */
  static final long FNV1A_SEED = -3750763034362895579L;
  /** FNV-1a 64-bit prime. */
  static final long FNV1A_PRIME = 1099511628211L;

  private FingerprintEngine() {} // static utility

  /** Fingerprint invariant mode for circular fingerprints. */
  public enum Mode {
    /** ECFP: atomic number, degree, charge, ring, aromaticity, tautomer class. */
    ECFP,
    /** FCFP: pharmacophoric feature classes (H-bond donor/acceptor, ionisable, aromatic, hydrophobic). */
    FCFP
  }

  // ---- Path Fingerprint ----

  public static long[] pathFingerprint(IAtomContainer mol, int pathLength, int fpSize) {
    if (mol == null) throw new NullPointerException("mol");
    if (pathLength <= 0) throw new IllegalArgumentException("pathLength must be > 0");
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    return SearchEngine.pathFingerprint(mol, pathLength, fpSize);
  }

  // ---- MCS Fingerprint ----

  public static long[] mcsFingerprint(IAtomContainer mol, ChemOptions chem, int pathLength, int fpSize) {
    if (mol == null) throw new NullPointerException("mol");
    if (pathLength <= 0) throw new IllegalArgumentException("pathLength must be > 0");
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    return SearchEngine.mcsFingerprint(mol, chem, pathLength, fpSize);
  }

  // ---- Subset & Similarity ----

  public static boolean fingerprintSubset(long[] query, long[] target) {
    if (query == null) throw new NullPointerException("query");
    if (target == null) throw new NullPointerException("target");
    return SearchEngine.fingerprintSubset(query, target);
  }

  public static double tanimoto(long[] fp1, long[] fp2) {
    return SearchEngine.mcsFingerprintSimilarity(fp1, fp2);
  }

  // ---- Circular ECFP ----

  public static long[] circularFingerprint(IAtomContainer mol, int radius, int fpSize) {
    return ecfp(mol, radius, fpSize);
  }

  public static long[] ecfp(IAtomContainer mol, int radius, int fpSize) {
    if (mol == null) throw new NullPointerException("mol");
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    return ecfp(new MolGraph(mol), radius, fpSize);
  }

  public static long[] ecfp(MolGraph g, int radius, int fpSize) {
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    int n = g.n;
    int numWords = (fpSize + 63) / 64;
    long[] fp = new long[numWords];
    if (n == 0) return fp;

    long[] atomHash = new long[n];
    for (int i = 0; i < n; i++) {
      long h = FNV1A_SEED;
      h ^= g.atomicNum[i];       h *= FNV1A_PRIME;
      h ^= g.degree[i];          h *= FNV1A_PRIME;
      h ^= g.ring[i] ? 1 : 0;   h *= FNV1A_PRIME;
      h ^= g.aromatic[i] ? 1 : 0; h *= FNV1A_PRIME;
      h ^= g.formalCharge[i] + 4; h *= FNV1A_PRIME;
      if (g.tautomerClass != null && g.tautomerClass[i] >= 0) {
        h ^= 0xCAFE00L + g.tautomerClass[i]; h *= FNV1A_PRIME;
      }
      atomHash[i] = h;
      int bit = (int) (Long.remainderUnsigned(h, fpSize));
      fp[bit >> 6] |= 1L << (bit & 63);
    }

    return expandRadii(g, fp, atomHash, radius, fpSize, n);
  }

  // ---- Circular FCFP ----

  public static long[] fcfp(IAtomContainer mol, int radius, int fpSize) {
    if (mol == null) throw new NullPointerException("mol");
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    return fcfp(new MolGraph(mol), radius, fpSize);
  }

  public static long[] fcfp(MolGraph g, int radius, int fpSize) {
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    int n = g.n;
    int numWords = (fpSize + 63) / 64;
    long[] fp = new long[numWords];
    if (n == 0) return fp;

    long[] atomHash = new long[n];
    for (int i = 0; i < n; i++) {
      int features = classifyPharmacophore(g, i);
      long h = FNV1A_SEED;
      h ^= features;          h *= FNV1A_PRIME;
      h ^= g.degree[i];       h *= FNV1A_PRIME;
      h ^= g.ring[i] ? 1 : 0; h *= FNV1A_PRIME;
      atomHash[i] = h;
      int bit = (int) (Long.remainderUnsigned(h, fpSize));
      fp[bit >> 6] |= 1L << (bit & 63);
    }

    return expandRadii(g, fp, atomHash, radius, fpSize, n);
  }

  // ---- Mode dispatch ----

  public static long[] circularFingerprint(IAtomContainer mol, int radius, int fpSize, Mode mode) {
    if (mol == null) throw new NullPointerException("mol");
    MolGraph g = new MolGraph(mol);
    return circularFingerprint(g, radius, fpSize, mode);
  }

  public static long[] circularFingerprint(MolGraph g, int radius, int fpSize, Mode mode) {
    return (mode == Mode.FCFP) ? fcfp(g, radius, fpSize) : ecfp(g, radius, fpSize);
  }

  // ---- Shared radius expansion ----

  private static long[] expandRadii(MolGraph g, long[] fp, long[] atomHash,
                                     int radius, int fpSize, int n) {
    int maxRadius = (radius < 0) ? n : radius;
    long[] prevHash = atomHash.clone();
    long[] nextHash = new long[n];

    for (int r = 1; r <= maxRadius; r++) {
      boolean anyNew = false;
      for (int i = 0; i < n; i++) {
        int deg = g.neighbors[i].length;
        if (deg == 0) { nextHash[i] = prevHash[i]; continue; }
        long[] nbHashes = new long[deg];
        for (int k = 0; k < deg; k++) {
          int nb = g.neighbors[i][k];
          nbHashes[k] = prevHash[nb] ^ (g.bondOrder(i, nb) * 31L);
        }
        java.util.Arrays.sort(nbHashes);

        long h = FNV1A_SEED;
        h ^= r;            h *= FNV1A_PRIME;
        h ^= prevHash[i];  h *= FNV1A_PRIME;
        for (long nh : nbHashes) { h ^= nh; h *= FNV1A_PRIME; }
        nextHash[i] = h;

        int bit = (int) (Long.remainderUnsigned(h, fpSize));
        long mask = 1L << (bit & 63);
        if ((fp[bit >> 6] & mask) == 0) anyNew = true;
        fp[bit >> 6] |= mask;
      }
      System.arraycopy(nextHash, 0, prevHash, 0, n);
      if (radius < 0 && !anyNew) break;
    }
    return fp;
  }

  // ---- Pharmacophore Classification (FCFP) ----

  /**
   * Classify an atom into pharmacophoric feature classes.
   * Returns bitmask: bit 0=donor, 1=acceptor, 2=positive, 3=negative, 4=aromatic, 5=hydrophobic.
   */
  static int classifyPharmacophore(MolGraph g, int idx) {
    int z = g.atomicNum[idx];
    int charge = g.formalCharge[idx];
    boolean arom = g.aromatic[idx];
    int deg = g.degree[idx];
    int features = 0;

    // H-bond donor: N-H, O-H, S-H (Rogers & Hahn 2010)
    if (z == 7 || z == 8 || z == 16) {
      int typicalValence = (z == 7) ? 3 : (z == 8) ? 2 : 2; // S typical valence 2
      if (deg < typicalValence && charge >= 0) features |= 1;
    }

    // H-bond acceptor: N, O, S, F with lone pairs — exclude positively charged N
    if ((z == 7 && charge <= 0) || z == 8 || z == 9 || z == 16) features |= 2;

    // Positive ionisable: basic amines only (exclude amide N: N adjacent to C=O)
    if (z == 7 && charge > 0) features |= 4;
    if (z == 7 && !arom && deg <= 3 && charge == 0) {
      boolean isAmide = false;
      for (int nb : g.neighbors[idx]) {
        if (g.atomicNum[nb] == 6) {
          for (int nb2 : g.neighbors[nb]) {
            if (nb2 != idx && g.atomicNum[nb2] == 8 && g.bondOrder(nb, nb2) == 2) {
              isAmide = true; break;
            }
          }
        }
        if (isAmide) break;
      }
      if (!isAmide) features |= 4;
    }

    // Negative ionisable: carboxylic, phosphoric, sulfonic acid
    if (z == 8 && charge < 0) features |= 8;
    if (z == 8 && charge == 0 && deg == 1) {
      for (int nb : g.neighbors[idx]) {
        int nbZ = g.atomicNum[nb];
        // Carboxylic acid: O on C with another O
        if (nbZ == 6) {
          for (int nb2 : g.neighbors[nb]) {
            if (nb2 != idx && g.atomicNum[nb2] == 8) features |= 8;
          }
        }
        // Phosphoric acid: O on P; Sulfonic acid: O on S
        if (nbZ == 15 || nbZ == 16) features |= 8;
      }
    }

    // Aromatic
    if (arom) features |= 16;

    // Hydrophobic: non-aromatic C with no heteroatom neighbors, or halogens (Cl, Br, I)
    if (z == 6 && !arom) {
      boolean hasHetero = false;
      for (int nb : g.neighbors[idx]) {
        int nbZ = g.atomicNum[nb];
        if (nbZ != 6 && nbZ != 1) { hasHetero = true; break; }
      }
      if (!hasHetero) features |= 32;
    }
    if (z == 17 || z == 35 || z == 53) features |= 32; // Cl, Br, I

    return features;
  }

  // ---- Format Conversions ----

  public static java.util.BitSet toBitSet(long[] fp) {
    return java.util.BitSet.valueOf(fp);
  }

  public static long[] fromBitSet(java.util.BitSet bs) {
    return bs.toLongArray();
  }

  public static String toHex(long[] fp) {
    StringBuilder sb = new StringBuilder(fp.length * 16);
    for (long w : fp) sb.append(String.format("%016x", w));
    return sb.toString();
  }

  public static long[] fromHex(String hex) {
    int words = (hex.length() + 15) / 16;
    long[] fp = new long[words];
    for (int i = 0; i < words; i++) {
      int start = i * 16;
      int end = Math.min(start + 16, hex.length());
      fp[i] = Long.parseUnsignedLong(hex.substring(start, end), 16);
    }
    return fp;
  }

  public static String toBinaryString(long[] fp, int fpSize) {
    StringBuilder sb = new StringBuilder(fpSize);
    for (int i = 0; i < fpSize; i++) {
      sb.append((fp[i >> 6] & (1L << (i & 63))) != 0 ? '1' : '0');
    }
    return sb.toString();
  }
}
