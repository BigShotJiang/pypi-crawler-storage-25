"""Session name generation service.

Automatically generates meaningful session names using the current session model
when it is cheap enough for a lightweight naming request.
"""

from typing import Any

from alloy_runtime_sdk.api_client.client import ApiClient
from alloy_runtime_types.dtos.generation import GenerateTextRequest
from alloy_runtime_sdk.logging.config import get_logger

logger = get_logger(__name__)

# Prompt for generating session names
NAME_GENERATION_PROMPT = """Generate a short, descriptive title (3-6 words) for a chat conversation based on the user's first message. The title should capture the main topic or intent.

Rules:
- Return ONLY the title, nothing else
- No quotes, punctuation at the end, or explanations
- Use title case
- Be specific but concise
- If the message is a greeting or very generic, create a generic but friendly title

Examples:
- "Help me write a Python script" -> "Python Script Assistance"
- "What's the weather like?" -> "Weather Information Request"
- "Hello!" -> "New Conversation"
- "Debug this React component" -> "React Component Debugging"

User's first message:
{message}

Title:"""


class SessionNameGenerator:
    """Generates session names using a fast, cheap model.

    Uses the session model only when it is cheap enough for lightweight naming.
    Expensive or missing session models skip auto-naming entirely.

    Usage:
        generator = SessionNameGenerator()
        name = await generator.generate_name(client, "Help me write a function")
        # Returns something like "Function Writing Help"
    """

    # Cheap models that are OK to use for naming (won't cost much)
    _CHEAP_MODEL_PATTERNS = [
        "flash",
        "mini",
        "nano",
        "haiku",
        "instant",
        "3.5-turbo",
        "8b",
        "7b",
    ]

    def __init__(
        self,
        max_message_length: int = 500,
    ) -> None:
        """Initialize the session name generator.

        Args:
            max_message_length: Maximum length of user message to include in prompt.
        """
        self._max_message_length = max_message_length

    def _is_cheap_model(self, model_name: str) -> bool:
        """Check if a model is considered cheap enough for naming tasks."""
        model_lower = model_name.lower()
        return any(pattern in model_lower for pattern in self._CHEAP_MODEL_PATTERNS)

    async def generate_name(
        self,
        client: ApiClient,
        first_message: str,
        session_provider_key: str | None = None,
        session_model_name: str | None = None,
    ) -> str | None:
        """Generate a session name based on the first message.

        Uses the session model exactly once when it is cheap enough.

        Args:
            client: ApiClient for making API calls.
            first_message: The user's first message in the session.
            session_provider_key: Optional provider key from the session (tried first if cheap).
            session_model_name: Optional model name from the session (tried first if cheap).

        Returns:
            Generated session name (3-6 words), or None if naming is skipped or fails.
        """
        logger.info(
            "session_name_generator_starting",
            first_message_length=len(first_message),
            session_provider_key=session_provider_key,
            session_model_name=session_model_name,
        )

        if not session_provider_key or not session_model_name:
            logger.info(
                "session_name_not_using_session_model",
                session_provider_key=session_provider_key,
                session_model_name=session_model_name,
                is_cheap=None,
            )
            return None

        if not self._is_cheap_model(session_model_name):
            logger.info(
                "session_name_not_using_session_model",
                session_provider_key=session_provider_key,
                session_model_name=session_model_name,
                is_cheap=False,
            )
            return None

        prompt = NAME_GENERATION_PROMPT.format(
            message=first_message[: self._max_message_length]
        )

        try:
            logger.info(
                "session_name_generation_attempt",
                attempt_number=1,
                provider=session_provider_key,
                model=session_model_name,
            )

            request_data: dict[str, Any] = {
                "model": f"{session_provider_key}/{session_model_name}",
                "prompt": prompt,
                "tags": ["system.session_naming"],
            }
            if "mode" in GenerateTextRequest.model_fields:
                request_data["mode"] = "sync"
            else:
                request_data["stream"] = False
            request = GenerateTextRequest(**request_data)

            response = await client.generate_text_sync(request)
            logger.info(
                "session_name_generation_response",
                provider=session_provider_key,
                model=session_model_name,
                raw_output=response.output_text if response.output_text else None,
            )

            generated_name = self._clean_name(response.output_text)
            if generated_name:
                logger.info(
                    "session_name_generated_success",
                    provider=session_provider_key,
                    model=session_model_name,
                    generated_name=generated_name,
                )
                return generated_name

            logger.warning(
                "session_name_cleaned_to_empty",
                provider=session_provider_key,
                model=session_model_name,
                raw_output=response.output_text,
            )
            return None
        except Exception as e:
            logger.info(
                "session_name_generation_model_failed",
                attempt_number=1,
                provider=session_provider_key,
                model=session_model_name,
                error=str(e),
                error_type=type(e).__name__,
            )
            return None

    def _clean_name(self, raw_name: str) -> str | None:
        """Clean and validate the generated name.

        Args:
            raw_name: Raw output from the model.

        Returns:
            Cleaned name (max 100 chars), or None if invalid.
        """
        # Strip whitespace and quotes
        name = raw_name.strip().strip("\"'")

        # Remove common prefixes the model might add
        prefixes_to_remove = ["Title:", "title:", "Name:", "name:"]
        for prefix in prefixes_to_remove:
            if name.startswith(prefix):
                name = name[len(prefix) :].strip()

        # Validate length
        if not name or len(name) < 2:
            return None

        return name
