import asyncio
from datetime import datetime
import threading
from time import time
import pingintel_api
from pingintel_api.pingvision import types as t


api_client = pingintel_api.PingVisionAPIClient()


# GET by pingid(s) or job_id(s) for status and completion
#     job: run_sovfixer
#     outputs:
#         job.results.transitioned_to_status



def get_team_uuid(company_name: str, team_name: str):
    ret = api_client.list_teams()

    for team in ret:
        if team["company_name"] == company_name and team["team_name"] == team_name:
            return team
    else:
        print("Team not found. Available teams:")
        for team in ret:
            print(f"* {team['company_name']} / {team['team_name']} ({team['team_uuid']})")
        raise ValueError(f"Team not found: {company_name} / {team_name}")


def get_statuses(division_uuid, status_names: list[str] | None = None) -> list[t.PingVisionListSubmissionStatusItemResponse]:
    statuses = api_client.list_submission_statuses(division=division_uuid)
    ret = []
    for status in statuses:
        if status_names and status["name"] in status_names:
            ret.append(status)
    return ret


# background thread:
def poll_for_events(db, earliest_allowed_time=datetime(2026, 2, 1)):
    last_cursor_id = None
    while 1:
        time.sleep(30)
        new_events = api_client.list_submission_events(cursor_id=last_cursor_id, page_size=50, start=earliest_allowed_time)
        last_cursor_id = new_events['cursor_id']
        for event in new_events['results']:
            event_type = event['event_type']
            ping_id = event['pingid']
            if event_type == t.SUBMISSION_EVENT_LOG_TYPE.SUBMISSION_STATUS_CHANGE:
                status = event['new_value']
                db[ping_id] = status

                if status == 'Awaiting Clearance Clarification':
                    # notify people asking for help
                    ...
                elif status == 'Awaiting Data Entry Clarification':
                    # notify people asking for help
                    ...

                elif status == 'Received':
                    ...
                elif status == 'Processing':
                    ...
                elif status == 'Cleared':
                    ...
                elif status == 'Blocked':
                    ...
                elif status == 'Data Entry':
                    ...
                elif status == 'Underwriting':
                    ...

def wait_for_status(pingid, desired_status):
    while True:
        status = db.get(pingid)
        if status == desired_status:
            return
        time.sleep(5)

company_name = "PING"  # replace with your company name
team_name = "PING"  # replace with your team name

team = get_team_uuid(company_name, team_name)
team_uuid = team["team_uuid"]
division_uuid = team["division_uuid"]
statuses = get_statuses(
    division_uuid=division_uuid,
    status_names=["Received", "Initializing", "Waiting for Scrubbing", "Waiting for Peer Review"],
)
status_uuids = {status['name']: status["uuid"] for status in statuses}

db={}
threading.start_task(poll_for_events(db))

# Initiate New Submission: https://docs.pingintel.com/ping-vision/create-submission/initiate-new-submission
ret = api_client.create_submission(my_eml, insured_name=None)
pingid = ret['id']

# will generate events SSC:Received, SSC:Processing, SSC:Cleared.
data_entry_status_uuid = status_uuids['Data Entry']

# When you're ready to trigger scrubbing:
ret = api_client.change_status(pingid, data_entry_status_uuid)
wait_for_status(pingid, 'Underwriting')
ret = api_client.list_submission_activity(pingid)
if ret and 'results' in ret:
    documents = ret['results'][0].get('documents', [])

    for doc in documents:
        if doc['document_type'] == '???':
            output_path = f"/path/to/downloads/{pingid}_{doc['filename']}"
            api_client.download_document(output_path, pingid=pingid, filename=doc['filename'])  # https://docs.pingintel.com/ping-vision/get-submission-data/download-submission-document














Update Submission:
    https://docs.pingintel.com/ping-vision/update-submission/update-submission-details#response-is-building-data-ready-one-of-0
    set_building_data_ready = True

    returns job_id
    outputs:
        job.results.transitioned_to_status = null
        job.results.documents






CREATING...., PENDING_CLEARANCE, CLEARED, CLEAR_, BLOCKED, START_ENRICHMENT.

Kettle needs clearance, yesterday.
Kettle needs enrichment, yesterday.
We need working code to get them all the way through