"""
Set one or more PingVision submissions to a given workflow status.

Accepts pingids (e.g. p-ob-amw-agtdgc) or client_refs. Identifiers starting
with "p-" are treated as pingids; all others are looked up as client_refs.

Usage:
    python close_submissions.py <id1> [id2 ...] --status <name> [options]

    python close_submissions.py p-ob-amw-abc123 my-client-ref-456 --status Closed
    python close_submissions.py p-ob-amw-abc123 --status Declined --env staging --dry-run
"""

import argparse
import sys

from pingintel_api import PingVisionAPIClient


def resolve_pingids(client: PingVisionAPIClient, identifiers: list[str]) -> dict[str, str | None]:
    """Return {identifier: pingid} for all identifiers. pingid is None if not found."""
    result = {}
    for ident in identifiers:
        if ident.startswith("p-"):
            result[ident] = ident
        else:
            activity = client.list_submission_activity(client_ref=ident, page_size=10)
            submissions = activity.get("results", [])
            if not submissions:
                print(f"  WARNING: No submission found for client_ref={ident!r}", file=sys.stderr)
                result[ident] = None
            elif len(submissions) > 1:
                pingids = [s["id"] for s in submissions]
                print(
                    f"  WARNING: Multiple submissions found for client_ref={ident!r}: {pingids}. Skipping.",
                    file=sys.stderr,
                )
                result[ident] = None
            else:
                result[ident] = submissions[0]["id"]
    return result


def find_status_uuid(client: PingVisionAPIClient, division_uuid: str, status_name: str) -> str:
    statuses = client.list_submission_statuses(division=division_uuid)
    matched = [s for s in statuses if s["name"].lower() == status_name.lower()]
    if not matched:
        available = [s["name"] for s in statuses]
        raise RuntimeError(f"Status {status_name!r} not found. Available: {available}")
    return matched[0]["uuid"]


def find_division_uuid(client: PingVisionAPIClient, team_name: str | None, division: str | None) -> str:
    teams = client.list_teams()
    if not teams:
        raise RuntimeError("No teams found for this API token.")
    if division:
        matched = [
            t for t in teams
            if t["division_uuid"] == division
            or t.get("division_name", "").lower() == division.lower()
            or t.get("division_short_name", "").lower() == division.lower()
        ]
        if not matched:
            available = [(t.get("division_short_name") or t["division_name"], t["division_uuid"]) for t in teams]
            raise RuntimeError(f"Division {division!r} not found. Available: {available}")
        return matched[0]["division_uuid"]
    if team_name:
        matched = [t for t in teams if t["team_name"] == team_name]
        if not matched:
            available = [t["team_name"] for t in teams]
            raise RuntimeError(f"Team {team_name!r} not found. Available: {available}")
        return matched[0]["division_uuid"]
    if len(teams) == 1:
        return teams[0]["division_uuid"]
    names = [t["team_name"] for t in teams]
    raise RuntimeError(f"Multiple teams found: {names}. Specify one with --team or --division.")


def main():
    parser = argparse.ArgumentParser(description="Set PingVision submission workflow status.")
    parser.add_argument("identifiers", nargs="+", help="pingids or client_refs to update")
    parser.add_argument("--status", required=True, help="Target workflow status name (e.g. Closed, Declined)")
    parser.add_argument("--env", default="prod", help="API environment (prod, staging, local). Default: prod")
    parser.add_argument("--api-url", help="Override API URL (e.g. http://localhost:8002)")
    parser.add_argument("--team", help="Team name for status lookup (required if multiple teams)")
    parser.add_argument("--division", help="Division UUID (alternative to --team)")
    parser.add_argument("--dry-run", action="store_true", help="Print what would happen without making changes")
    args = parser.parse_args()

    kwargs = {}
    if args.api_url:
        kwargs["api_url"] = args.api_url
    else:
        kwargs["environment"] = args.env

    client = PingVisionAPIClient(**kwargs)

    division_uuid = find_division_uuid(client, args.team, args.division)
    status_uuid = find_status_uuid(client, division_uuid, args.status)
    print(f"Status {args.status!r} UUID: {status_uuid}")

    id_map = resolve_pingids(client, args.identifiers)

    success, skipped, failed = 0, 0, 0
    for ident, pingid in id_map.items():
        if pingid is None:
            skipped += 1
            continue
        label = pingid if ident == pingid else f"{pingid} (client_ref={ident!r})"
        if args.dry_run:
            print(f"  DRY RUN: would set {label} -> {args.status!r}")
            success += 1
            continue
        try:
            client.change_status(pingid=pingid, workflow_status_id=status_uuid)
            print(f"  Updated {label} -> {args.status!r}")
            success += 1
        except Exception as e:
            print(f"  ERROR updating {label}: {e}", file=sys.stderr)
            failed += 1

    print(f"\nDone. {success} updated, {skipped} skipped, {failed} failed.")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
