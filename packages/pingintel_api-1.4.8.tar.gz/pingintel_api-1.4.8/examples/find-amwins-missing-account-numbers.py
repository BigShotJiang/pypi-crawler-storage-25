#!/usr/bin/env python3
"""
Find Amwins missing account numbers by looking up policy_number from PingVision and SOVFixer.

Iterates through SOVFixer history for Amwins, finds pingids, and checks if policy numbers
match between PingVision submission and SOVFixer jobs.
"""

import click, datetime
from pprint import pprint

from pingintel_api import PingVisionAPIClient, SOVFixerAPIClient


def check_pingid(pingid: str, pv_client: PingVisionAPIClient, sf_client: SOVFixerAPIClient, dump: bool = False) -> bool:
    """
    Check policy numbers for a PingVision submission and its associated SOVFixer jobs.
    Returns True if all match, False if any mismatch.
    """
    # Get PingVision submission activity
    activity = pv_client.list_submission_activity(pingid=pingid)
    results = activity.get("results", [])

    if dump:
        click.echo("\n--- PingVision submission activity ---")
        pprint(activity)

    if not results:
        click.echo(f"No submission found for pingid: {pingid}")
        return True

    submission = results[0]

    # Get submission's extra_data.policy_number
    extra_data = submission.get("extra_data", {}) or {}
    submission_policy_number = extra_data.get("policy_number")
    click.echo(f"{pingid}: {submission_policy_number}")

    # Get jobs from the submission
    jobs = submission.get("jobs", [])
    all_match = True

    for job in jobs:
        sovid = job.get("sovid")

        if not sovid:

            continue

        # Look up the SOVFixer activity for this sovid
        sf_activity = sf_client.list_activity(id=sovid)
        if dump:
            click.echo(f"\n--- SOVFixer activity for {sovid} ---")
            pprint(sf_activity)
        sf_results = sf_activity.get("results", [])
        if sf_results:
            sf_extra_data = sf_results[0].get("extra_data", {}) or {}
            sf_policy_number = sf_extra_data.get("policy_number")
        else:
            sf_policy_number = None

        click.echo(f"  {sovid}: {sf_policy_number}")

        # Check for mismatch
        if submission_policy_number != sf_policy_number:
            click.echo(f"  *** MISMATCH: submission={submission_policy_number}, sovfixer={sf_policy_number}")
            all_match = False

    return all_match


@click.command()
@click.option(
    "-e",
    "--environment",
    type=click.Choice(["prod", "prodeu", "staging", "dev"], case_sensitive=False),
    default="prod",
    help="API environment (prod, dev, etc.)",
)
@click.option(
    "--limit",
    type=int,
    default=None,
    help="Maximum number of history items to process.",
)
@click.option(
    "--id",
    "pingid",
    default=None,
    help="Check a single pingid instead of iterating through history.",
)
@click.option(
    "--dump",
    is_flag=True,
    default=False,
    help="Prettyprint the raw API responses.",
)
def main(environment: str, limit: int | None, pingid: str | None, dump: bool):
    """Iterate through Amwins SOVFixer history and check for policy number mismatches."""
    pv_client = PingVisionAPIClient(environment=environment)
    sf_client = SOVFixerAPIClient(environment=environment, auth_token="3b9f832a6e930859bdc25cd231626983f61b1988")

    # If a specific pingid is provided, just check that one
    if pingid:
        click.echo(f"Checking single pingid: {pingid}")
        all_match = check_pingid(pingid, pv_client, sf_client, dump=dump)
        if not all_match:
            breakpoint()
        return

    seen_pingids = set()
    count = 0
    cursor_id = "s-ha-amw-5htfh5"

    click.echo("Fetching SOVFixer history for Amwins...")
    has_remaining = True

    while has_remaining:
        history = sf_client.list_history(cursor_id=cursor_id, page_size=100, start=datetime.datetime(2025, 1, 1))
        cursor_id = history.get("cursor_id")
        print(history["cursor_id"])
        has_remaining = len(history.get("results", []))
        for item in history.get("results", []):
            # Filter for Amwins
            # org_short_name = item.get("organization__short_name", "")
            # if org_short_name != "amwins":
            #     continue

            pingid = item.get("pingid")
            sovid = item.get("sovid")
            record_type = item.get("record_type")

            if not pingid or pingid in seen_pingids:
                continue

            seen_pingids.add(pingid)
            count += 1

            click.echo(f"Checking {pingid} ({count}) ---")

            all_match = check_pingid(pingid, pv_client, sf_client, dump=dump)

            if not all_match:
                breakpoint()

            if limit and count >= limit:
                click.echo(f"\nReached limit of {limit} pingids.")
                return

    click.echo(f"\nDone. Checked {count} pingids.")


if __name__ == "__main__":
    main()
