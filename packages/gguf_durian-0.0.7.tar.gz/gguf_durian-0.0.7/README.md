## durian

execute the installer (once):
```
python3 -m gguf_durian
```

after installation, simply type:
```
durian
```

---

check version
```
durian version
```

update [✷durian](https://durian.gguf.org) to the latest version manually by:
```
durian update
```

![screenshot](https://raw.githubusercontent.com/calcuis/goldfish/master/durian.jpg)