from setuptools import setup, find_packages

setup(
    name="minhtanfe",           # Đổi lại thành viết liền cho khớp thư mục
    version="16.6.0",           # Tăng version lên hẳn một bản mới
    author="Le Minh Tan",
    author_email="lmtan2005@gmail.com",
    description="AI Feature Extractor by Minh Tan",
    long_description="MinhTanFE Library for AI research", 
    long_description_content_type="text/plain",
    packages=find_packages(),
    install_requires=[
        "torch>=1.7.0",
        "numpy"
    ],
    python_requires='>=3.6',
)