# MinhTan-FE Library
High-performance Feature Extractor for AI research.