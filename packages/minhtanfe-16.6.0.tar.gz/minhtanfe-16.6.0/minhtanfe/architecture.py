import torch
import torch.nn as nn
import torch.nn.functional as F

class MinhTanFE_Module(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        # Attention Mechanism (Alpha Gate) - Giúp mô hình tập trung vào nét chữ
        self.alpha_gate = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 4, 1, bias=False),
            nn.BatchNorm2d(in_channels // 4), 
            nn.SiLU(),
            nn.Conv2d(in_channels // 4, 1, 1, bias=False), 
            nn.Sigmoid()
        )
        # Depthwise Separable Convolution - Tối ưu tốc độ xử lý
        self.dw = nn.Conv2d(in_channels, in_channels, 3, padding=1, groups=in_channels, bias=False)
        self.pw = nn.Conv2d(in_channels, out_channels, 1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        
        # Residual Connection - Giúp dòng chảy đạo hàm ổn định
        self.res_proj = nn.Conv2d(in_channels, out_channels, 1, bias=False) if in_channels != out_channels else nn.Identity()

    def forward(self, x):
        identity = self.res_proj(x)
        mask = self.alpha_gate(x)
        # Kết hợp Attention Mask và Residual
        return F.silu(self.bn(self.pw(self.dw(x * mask))) + identity)

class v16_4(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        # Lớp trích xuất đặc trưng đầu tiên (Stem)
        self.stem = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1, bias=False), 
            nn.BatchNorm2d(32), 
            nn.SiLU()
        )
        # Khối MinhTanFE chủ đạo
        self.fe = MinhTanFE_Module(32, 48)
        
        # Lớp phân loại (Classifier)
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((2, 2)), 
            nn.Flatten(), 
            nn.Linear(48*4, 128), 
            nn.SiLU(), 
            nn.Linear(128, num_classes)
        )

    def forward(self, x):
        x = self.stem(x)
        x = self.fe(x)
        return self.classifier(x)

# ==========================================
# PHẦN QUAN TRỌNG: TƯƠNG THÍCH NGƯỢC (ALIAS)
# ==========================================
# Giúp các code cũ gọi v16_1 vẫn chạy được bản 16.4 siêu cấp này
v16_1 = v16_4 
MinhTanFE_V16_1 = MinhTanFE_Module
MinhTanClassifier = v16_4