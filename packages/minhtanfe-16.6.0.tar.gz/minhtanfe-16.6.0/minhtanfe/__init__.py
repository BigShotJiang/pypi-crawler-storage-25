# minhtanfe/__init__.py

from .architecture import (
    v16_1, 
    v16_4, 
    MinhTanFE_V16_1, 
    MinhTanFE_Module, 
    MinhTanClassifier
)

# Khai báo phiên bản thư viện
__version__ = "16.4.1"
__author__ = "Le Minh Tan"