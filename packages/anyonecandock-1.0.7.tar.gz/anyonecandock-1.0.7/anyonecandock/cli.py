#!/usr/bin/env python3
"""
anyonecandock  CLI  —  acd <command> [options]

Commands
--------
  dock      Full pipeline: receptor + ligand + Vina docking (single ligand)
  batch     Batch docking from a .smi file or SMILES list
  receptor  Prepare a receptor only (download/convert → .pdb + .pdbqt + box)
  ligand    Prepare a ligand only (SMILES/file → .pdbqt + .sdf)
  diagram   Generate a 2D interaction diagram SVG for a completed docking run

Run  acd <command> --help  for per-command options.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import textwrap
from pathlib import Path

# ── optional pretty-print ─────────────────────────────────────────────────────
try:
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
    _RICH = True
    _con = Console()
except ImportError:
    _RICH = False

    class _FakeConsole:
        def print(self, *a, **kw): print(*a)
        def log(self, *a, **kw): print(*a)
        def rule(self, *a, **kw): print("─" * 60)
    _con = _FakeConsole()


# ── helpers ───────────────────────────────────────────────────────────────────

def _banner():
    txt = textwrap.dedent("""\
        ╔══════════════════════════════════════════════════════╗
        ║  anyone can dock  —  AutoDock Vina 1.2.7 + pKaNET   ║
        ╚══════════════════════════════════════════════════════╝""")
    if _RICH:
        _con.print(f"[bold cyan]{txt}[/bold cyan]")
    else:
        print(txt)


def _ok(msg: str):
    prefix = "[green]✓[/green]" if _RICH else "✓"
    _con.print(f"{prefix}  {msg}")


def _warn(msg: str):
    prefix = "[yellow]⚠[/yellow]" if _RICH else "⚠"
    _con.print(f"{prefix}  {msg}")


def _err(msg: str):
    prefix = "[red]✗[/red]" if _RICH else "✗"
    _con.print(f"{prefix}  {msg}")
    sys.exit(1)


def _step(msg: str):
    if _RICH:
        _con.rule(f"[bold]{msg}[/bold]")
    else:
        print(f"\n{'─'*60}\n  {msg}\n{'─'*60}")


def _import_core():
    """Import core.py from the same package directory."""
    try:
        from anyonecandock import core
        return core
    except ImportError:
        here = Path(__file__).resolve().parent
        import importlib.util
        spec = importlib.util.spec_from_file_location("core", here / "core.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod


def _spinner(label: str):
    """Return a context manager with a spinner (rich) or plain print (fallback)."""
    if _RICH:
        return Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]{label}[/cyan]"),
            TimeElapsedColumn(),
            transient=True,
        )
    import contextlib
    @contextlib.contextmanager
    def _fake():
        print(f"⏳  {label} …")
        yield None
    return _fake()


def _pubchem_smiles(name: str) -> str:
    """Look up a compound by name on PubChem and return its IsomericSMILES."""
    import requests
    from urllib.parse import quote
    _ok(f"Searching PubChem for '{name}' …")
    r = requests.get(
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
        f"{quote(name)}/property/IsomericSMILES/JSON",
        timeout=10,
    )
    if r.status_code != 200:
        _err(f"Compound '{name}' not found on PubChem (HTTP {r.status_code})")
    smiles = r.json()["PropertyTable"]["Properties"][0]["IsomericSMILES"]
    _ok(f"Found SMILES: {smiles}")
    return smiles


def _print_scores(scores: list, ref_score: float | None = None):
    if not scores:
        _warn("No scores returned.")
        return
    if _RICH:
        t = Table(title="Docking Scores", show_header=True, header_style="bold cyan")
        t.add_column("Pose", style="dim")
        t.add_column("Affinity (kcal/mol)", justify="right")
        t.add_column("RMSD lb", justify="right")
        t.add_column("RMSD ub", justify="right")
        for s in scores:
            aff = s["affinity"]
            color = "green" if aff < -8 else "yellow" if aff < -6 else "red"
            t.add_row(str(s["pose"]), f"[{color}]{aff:.2f}[/{color}]",
                      f"{s['rmsd_lb']:.2f}", f"{s['rmsd_ub']:.2f}")
        _con.print(t)
    else:
        print(f"\n{'Pose':>6}  {'Affinity':>16}  {'RMSD lb':>8}  {'RMSD ub':>8}")
        print("─" * 48)
        for s in scores:
            print(f"{s['pose']:>6}  {s['affinity']:>16.2f}  {s['rmsd_lb']:>8.2f}  {s['rmsd_ub']:>8.2f}")

    best = scores[0]["affinity"]
    label = ("Very strong" if best < -11 else "Strong" if best < -9
             else "Moderate" if best < -7 else "Weak")
    _ok(f"Best pose: {best:.2f} kcal/mol  ({label} predicted binding)")
    if ref_score is not None:
        _ok(f"vs reference: {best - ref_score:+.2f} kcal/mol")


def _write_scores_csv(scores: list, path: str, lig_name: str = ""):
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["ligand", "pose", "affinity", "rmsd_lb", "rmsd_ub"])
        w.writeheader()
        for s in scores:
            w.writerow({"ligand": lig_name, **s})


def _resolve_ligand(args, name: str) -> tuple[str, str]:
    """
    Return (smiles, name) from --smiles, --compound, or raise via _err.
    Does NOT prepare the ligand — just resolves the input to a SMILES string.
    """
    if getattr(args, "ligand_file", None):
        return "", name   # file path; caller handles prepare_ligand_from_file

    smiles = getattr(args, "smiles", None) or ""
    compound = getattr(args, "compound", None) or ""

    if compound and not smiles:
        smiles = _pubchem_smiles(compound)
        if not name or name == "LIG":
            name = compound.replace(" ", "_")

    if not smiles:
        _err("Provide --smiles <SMILES>,  --compound <name>,  or  --ligand-file <path>")

    return smiles, name


# ── sub-command: receptor ─────────────────────────────────────────────────────

def cmd_receptor(args):
    core = _import_core()
    _step("Receptor preparation")

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    if args.pdb:
        token = args.pdb.strip().upper()
        fmt   = args.fmt.upper()
        ext   = "cif" if fmt == "CIF" else "pdb"
        raw   = str(out / f"raw.{ext}")
        _ok(f"Downloading {token} ({fmt}) from RCSB …")
        rc, _ = core.run_cmd(["curl", "-sf",
                               f"https://files.rcsb.org/download/{token}.{ext}",
                               "-o", raw])
        if rc != 0 or not os.path.exists(raw) or os.path.getsize(raw) < 200:
            if fmt == "PDB":
                raw_cif = str(out / "raw.cif")
                rc2, _ = core.run_cmd(["curl", "-sf",
                                        f"https://files.rcsb.org/download/{token}.cif",
                                        "-o", raw_cif])
                if rc2 == 0 and os.path.exists(raw_cif) and os.path.getsize(raw_cif) > 200:
                    raw = raw_cif
                    _warn("PDB unavailable; fell back to CIF")
                else:
                    _err(f"Download failed for {token}")
            else:
                _err(f"Download failed for {token}")
    elif args.file:
        raw = args.file
        if not os.path.exists(raw):
            _err(f"File not found: {raw}")
    else:
        _err("Provide --pdb <PDB_ID>  or  --file <path>")

    manual_xyz = (float(args.cx or 0), float(args.cy or 0), float(args.cz or 0))

    with _spinner("Preparing receptor"):
        result = core.prepare_receptor(
            raw_pdb=raw,
            wdir=out,
            center_mode=args.center,
            manual_xyz=manual_xyz,
            prody_sel=args.sel or "",
            box_size=(args.bx, args.by, args.bz),
        )

    if not result["success"]:
        _err(f"Receptor preparation failed: {result['error']}")

    cx, cy, cz = result["cx"], result["cy"], result["cz"]
    _ok(f"Receptor PDB : {result['rec_fh']}")
    _ok(f"PDBQT        : {result['rec_pdbqt']}")
    _ok(f"Box config   : {result['config_txt']}")
    _ok(f"Grid center  : ({cx:.3f}, {cy:.3f}, {cz:.3f})")
    if result.get("cocrystal_ligand_id"):
        _ok(f"Co-crystal   : {result['cocrystal_ligand_id']}")

    summary = {
        "rec_fh":              result["rec_fh"],
        "rec_pdbqt":           result["rec_pdbqt"],
        "config_txt":          result["config_txt"],
        "cx": cx, "cy": cy, "cz": cz,
        "sx": result["sx"], "sy": result["sy"], "sz": result["sz"],
        "ligand_pdb_path":     result.get("ligand_pdb_path"),
        "cocrystal_ligand_id": result.get("cocrystal_ligand_id", ""),
    }
    summary_path = str(out / "receptor_summary.json")
    with open(summary_path, "w") as fh:
        json.dump(summary, fh, indent=2)
    _ok(f"Summary JSON : {summary_path}")


# ── sub-command: ligand ────────────────────────────────────────────────────────

def cmd_ligand(args):
    core = _import_core()
    _step("Ligand preparation")

    out  = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    name = args.name or "LIG"
    ph   = args.ph
    prot_mode = "neutral" if args.neutral else "pkanet"

    print(f"⏳  Preparing {name} at pH {ph} …")

    if getattr(args, "file", None):
        if not os.path.exists(args.file):
            _err(f"File not found: {args.file}")
        result = core.prepare_ligand_from_file(args.file, name, out)
    else:
        smiles, name = _resolve_ligand(args, name)
        result = core.prepare_ligand(
            smiles=smiles,
            name=name,
            ph=ph,
            wdir=out,
            mode=prot_mode,
            use_pubchem=not args.no_pubchem,
            max_tautomers=args.max_tautomers,
            ph_window=args.ph_window,
        )

    if not result["success"]:
        _err(f"Ligand preparation failed: {result['error']}")

    _ok(f"PDBQT         : {result['pdbqt']}")
    _ok(f"SDF (3D)      : {result['sdf']}")
    _ok(f"Formal charge : {int(result.get('net_charge', result.get('charge', 0))):+d}")
    _ok(f"SMILES (final): {result.get('prot_smiles', '')}")
    if result.get("pkanet_ranked_csv"):
        _ok(f"pKaNET CSV    : {result['pkanet_ranked_csv']}")


# ── sub-command: dock ─────────────────────────────────────────────────────────

def cmd_dock(args):
    core = _import_core()
    _banner()
    _step("Single-ligand docking")

    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)

    # ── Step 1: Receptor ──────────────────────────────────────────────────────
    _step("Step 1 — Receptor")

    if args.receptor_json:
        with open(args.receptor_json) as fh:
            rec_summary = json.load(fh)
        _ok(f"Using saved receptor: {rec_summary['rec_fh']}")
    else:
        rec_out = out / "receptor"
        rec_out.mkdir(exist_ok=True)

        # auto-detect: file vs PDB ID
        if os.path.exists(args.receptor):
            raw = os.path.abspath(args.receptor)
        else:
            token   = args.receptor.strip().upper()
            fmt_ext = "cif" if args.fmt.upper() == "CIF" else "pdb"
            raw     = str(rec_out / f"raw.{fmt_ext}")
            _ok(f"Downloading {token} …")
            rc, _ = core.run_cmd(["curl", "-sf",
                                   f"https://files.rcsb.org/download/{token}.{fmt_ext}",
                                   "-o", raw])
            if rc != 0 or not os.path.exists(raw) or os.path.getsize(raw) < 200:
                # CIF fallback
                raw_cif = str(rec_out / "raw.cif")
                rc2, _ = core.run_cmd(["curl", "-sf",
                                        f"https://files.rcsb.org/download/{token}.cif",
                                        "-o", raw_cif])
                if rc2 == 0 and os.path.exists(raw_cif) and os.path.getsize(raw_cif) > 200:
                    raw = raw_cif
                    _warn("PDB unavailable; fell back to CIF")
                else:
                    _err(f"Download failed for {token}")

        manual_xyz = (float(args.cx or 0), float(args.cy or 0), float(args.cz or 0))

        print("⏳  Preparing receptor …")
        rec_result = core.prepare_receptor(
            raw_pdb=raw,
            wdir=rec_out,
            center_mode=args.center,
            manual_xyz=manual_xyz,
            prody_sel=args.sel or "",
            box_size=(args.bx, args.by, args.bz),
        )
        if not rec_result["success"]:
            _err(f"Receptor prep failed: {rec_result['error']}")

        rec_summary = {
            "rec_fh":              rec_result["rec_fh"],
            "rec_pdbqt":           rec_result["rec_pdbqt"],
            "config_txt":          rec_result["config_txt"],
            "cx": rec_result["cx"], "cy": rec_result["cy"], "cz": rec_result["cz"],
            "sx": rec_result["sx"], "sy": rec_result["sy"], "sz": rec_result["sz"],
            "ligand_pdb_path":     rec_result.get("ligand_pdb_path"),
            "cocrystal_ligand_id": rec_result.get("cocrystal_ligand_id", ""),
        }

        # save JSON for re-use
        with open(str(rec_out / "receptor_summary.json"), "w") as fh:
            json.dump(rec_summary, fh, indent=2)

        cx, cy, cz = rec_result["cx"], rec_result["cy"], rec_result["cz"]
        _ok(f"Receptor ready — center ({cx:.2f}, {cy:.2f}, {cz:.2f})")
        if rec_result.get("cocrystal_ligand_id"):
            _ok(f"Co-crystal ligand: {rec_result['cocrystal_ligand_id']}")

    # use absolute paths so Vina always finds them
    rec_pdbqt  = os.path.abspath(rec_summary["rec_pdbqt"])
    config_txt = os.path.abspath(rec_summary["config_txt"])

    # ── Step 2: Vina binary ───────────────────────────────────────────────────
    print("⏳  Checking Vina binary …")
    vina_path, vina_err = core.get_vina_binary()
    if vina_path is None:
        _err(f"Could not get Vina binary: {vina_err}")
    _ok(f"Vina: {vina_path}")

    # ── Step 3: Ligand ────────────────────────────────────────────────────────
    _step("Step 2 — Ligand")

    lig_out   = out / "ligand"
    lig_out.mkdir(exist_ok=True)
    name      = args.name or "LIG"
    ph        = args.ph
    prot_mode = "neutral" if args.neutral else "pkanet"

    if getattr(args, "ligand_file", None):
        print(f"⏳  Preparing {name} from file …")
        lig_result = core.prepare_ligand_from_file(args.ligand_file, name, lig_out)
    else:
        smiles, name = _resolve_ligand(args, name)
        print(f"⏳  Preparing {name} at pH {ph} …")
        lig_result = core.prepare_ligand(
            smiles=smiles,
            name=name,
            ph=ph,
            wdir=lig_out,
            mode=prot_mode,
            use_pubchem=not args.no_pubchem,
            max_tautomers=args.max_tautomers,
            ph_window=args.ph_window,
        )

    if not lig_result["success"]:
        _err(f"Ligand prep failed: {lig_result['error']}")

    prot_smiles = lig_result.get("prot_smiles", "")
    charge      = int(lig_result.get("net_charge", lig_result.get("charge", 0)))
    _ok(f"Ligand SMILES : {prot_smiles}")
    _ok(f"Formal charge : {charge:+d}")

    # ── Step 4: Optional redocking reference ─────────────────────────────────
    ref_score = None
    if args.redock_smiles:
        _step("Step 2b — Redocking reference")
        pts    = args.redock_smiles.strip().split(None, 1)
        rd_smi = pts[0]
        rd_nm  = pts[1].replace(" ", "_") if len(pts) > 1 else "redock"
        print(f"⏳  Docking reference {rd_nm} …")
        rd_prep = core.prepare_ligand(rd_smi, "redock_" + rd_nm, ph, lig_out,
                                       mode=prot_mode)
        if rd_prep["success"]:
            rd_dock = core.run_vina(
                os.path.abspath(rd_prep["pdbqt"]),   # ligand — note: positional swap fixed below
                rec_pdbqt, config_txt,
                vina_path, args.exhaustiveness, args.poses,
                int(args.energy_range), lig_out, "redock_" + rd_nm,
            )
            # run_vina signature: receptor, ligand, config, vina, exh, modes, range, wdir, name
            rd_dock = core.run_vina(
                receptor_pdbqt = rec_pdbqt,
                ligand_pdbqt   = os.path.abspath(rd_prep["pdbqt"]),
                config_txt     = config_txt,
                vina_path      = vina_path,
                exhaustiveness = args.exhaustiveness,
                n_modes        = args.poses,
                energy_range   = int(args.energy_range),
                wdir           = lig_out,
                out_name       = "redock_" + rd_nm,
            )
            if rd_dock["success"] and rd_dock["top_score"] is not None:
                ref_score = rd_dock["top_score"]
                _ok(f"Reference score: {ref_score:.2f} kcal/mol")

    # ── Step 5: Docking ───────────────────────────────────────────────────────
    _step("Step 3 — AutoDock Vina")

    print(f"⏳  Running Vina (exhaustiveness={args.exhaustiveness}) …")
    dock = core.run_vina(
        receptor_pdbqt = rec_pdbqt,
        ligand_pdbqt   = os.path.abspath(lig_result["pdbqt"]),
        config_txt     = config_txt,
        vina_path      = vina_path,
        exhaustiveness = args.exhaustiveness,
        n_modes        = args.poses,
        energy_range   = int(args.energy_range),
        wdir           = out,
        out_name       = name,
    )

    if not dock["success"]:
        _err(f"Vina failed: {dock['error']}\n{dock['log'][:400]}")

    # ── Bond-order fix ────────────────────────────────────────────────────────
    pv_sdf = str(out / f"{name}_pv_ready.sdf")
    if prot_smiles:
        core.fix_sdf_bond_orders(dock["out_sdf"], prot_smiles, pv_sdf)
    if not os.path.exists(pv_sdf) or os.path.getsize(pv_sdf) < 10:
        pv_sdf = dock["out_sdf"]

    # ── Results ───────────────────────────────────────────────────────────────
    _step("Results")
    _print_scores(dock["scores"], ref_score=ref_score)

    scores_csv = str(out / f"{name}_scores.csv")
    _write_scores_csv(dock["scores"], scores_csv, lig_name=name)

    _ok(f"All poses PDBQT : {dock['out_pdbqt']}")
    _ok(f"All poses SDF   : {dock['out_sdf']}")
    if os.path.exists(pv_sdf) and os.path.getsize(pv_sdf) > 10:
        _ok(f"PV-ready SDF    : {pv_sdf}")
    _ok(f"Scores CSV      : {scores_csv}")

    # ── Optional per-pose SDF ─────────────────────────────────────────────────
    if args.save_poses:
        poses_dir = out / "poses"
        poses_dir.mkdir(exist_ok=True)
        sdf_src = pv_sdf if (os.path.exists(pv_sdf) and os.path.getsize(pv_sdf) > 10) \
                  else dock["out_sdf"]
        mols = core.load_mols_from_sdf(sdf_src, sanitize=False)
        for i, mol in enumerate(mols, 1):
            core.write_single_pose(mol,     str(poses_dir / f"{name}_pose{i}.sdf"))
            core.write_single_pose_pdb(mol, str(poses_dir / f"{name}_pose{i}.pdb"))
        _ok(f"Individual poses: {poses_dir}/")

    # ── Optional 2D diagram ───────────────────────────────────────────────────
    if args.diagram:
        _generate_diagram(
            core       = core,
            rec_fh     = rec_summary["rec_fh"],
            pose_sdf   = pv_sdf if os.path.exists(pv_sdf) else dock["out_sdf"],
            smiles     = prot_smiles,
            lig_name   = name,
            best_score = dock["top_score"],
            pose_idx   = 0,
            out        = out,
            cutoff     = args.diagram_cutoff,
        )


# ── sub-command: batch ────────────────────────────────────────────────────────

def cmd_batch(args):
    core = _import_core()
    _banner()
    _step("Batch docking")

    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)

    # ── Receptor ──────────────────────────────────────────────────────────────
    if args.receptor_json:
        with open(args.receptor_json) as fh:
            rec_summary = json.load(fh)
        _ok(f"Loaded receptor: {rec_summary['rec_fh']}")
    else:
        rec_out = out / "receptor"
        rec_out.mkdir(exist_ok=True)

        if os.path.exists(args.receptor):
            raw = os.path.abspath(args.receptor)
        else:
            token = args.receptor.strip().upper()
            raw   = str(rec_out / "raw.pdb")
            _ok(f"Downloading {token} …")
            rc, _ = core.run_cmd(["curl", "-sf",
                                   f"https://files.rcsb.org/download/{token}.pdb",
                                   "-o", raw])
            if rc != 0 or not os.path.exists(raw) or os.path.getsize(raw) < 200:
                _err(f"Download failed for {token}")

        print("⏳  Preparing receptor …")
        rec_result = core.prepare_receptor(
            raw_pdb=raw,
            wdir=rec_out,
            center_mode=args.center,
            box_size=(args.bx, args.by, args.bz),
        )
        if not rec_result["success"]:
            _err(f"Receptor prep failed: {rec_result['error']}")

        rec_summary = {
            "rec_fh":    rec_result["rec_fh"],
            "rec_pdbqt": rec_result["rec_pdbqt"],
            "config_txt": rec_result["config_txt"],
        }
        _ok("Receptor ready")

    rec_pdbqt  = os.path.abspath(rec_summary["rec_pdbqt"])
    config_txt = os.path.abspath(rec_summary["config_txt"])

    # ── Read ligand input ─────────────────────────────────────────────────────
    smiles_pairs: list[tuple[str, str]] = []

    if args.ligands:
        with open(args.ligands) as fh:
            for i, line in enumerate(fh):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                pts = line.split(None, 1)
                nm  = pts[1].replace(" ", "_") if len(pts) > 1 else f"lig_{i+1}"
                smiles_pairs.append((pts[0], nm))
    elif args.smiles_list:
        for i, entry in enumerate(args.smiles_list):
            pts = entry.strip().split(None, 1)
            nm  = pts[1].replace(" ", "_") if len(pts) > 1 else f"lig_{i+1}"
            smiles_pairs.append((pts[0], nm))
    else:
        _err("Provide --ligands <file.smi>  or  --smiles-list SMILES [SMILES ...]")

    _ok(f"Ligands to dock: {len(smiles_pairs)}")

    # ── Vina binary ───────────────────────────────────────────────────────────
    print("⏳  Checking Vina binary …")
    vina_path, vina_err = core.get_vina_binary()
    if vina_path is None:
        _err(f"Could not get Vina: {vina_err}")

    # ── Optional reference ────────────────────────────────────────────────────
    ref_score = None
    prot_mode = "neutral" if args.neutral else "pkanet"

    if args.redock_smiles:
        pts    = args.redock_smiles.strip().split(None, 1)
        rd_smi = pts[0]
        rd_nm  = pts[1].replace(" ", "_") if len(pts) > 1 else "redock"
        rd_out = out / "redock"
        rd_out.mkdir(exist_ok=True)
        print(f"⏳  Docking reference {rd_nm} …")
        rd_prep = core.prepare_ligand(rd_smi, "redock_" + rd_nm, args.ph, rd_out)
        if rd_prep["success"]:
            rd_dock = core.run_vina(
                receptor_pdbqt = rec_pdbqt,
                ligand_pdbqt   = os.path.abspath(rd_prep["pdbqt"]),
                config_txt     = config_txt,
                vina_path      = vina_path,
                exhaustiveness = args.exhaustiveness,
                n_modes        = args.poses,
                energy_range   = 3,
                wdir           = rd_out,
                out_name       = "redock_" + rd_nm,
            )
            if rd_dock["success"] and rd_dock["top_score"] is not None:
                ref_score = rd_dock["top_score"]
                _ok(f"Reference score: {ref_score:.2f} kcal/mol")

    # ── Main loop ─────────────────────────────────────────────────────────────
    results = []
    n = len(smiles_pairs)

    for i, (smi, nm) in enumerate(smiles_pairs, 1):
        print(f"  [{i}/{n}] {nm}")
        lig_wdir = out / nm
        lig_wdir.mkdir(exist_ok=True)
        try:
            prep = core.prepare_ligand(
                smiles=smi, name=nm, ph=args.ph,
                wdir=lig_wdir, mode=prot_mode,
            )
            if not prep["success"]:
                results.append({"Name": nm, "SMILES": smi, "Top Score": None,
                                 "Charge": None, "Status": f"PREP_FAILED: {prep['error']}"})
                _warn(f"  Prep failed: {prep['error']}")
                continue

            dock = core.run_vina(
                receptor_pdbqt = rec_pdbqt,
                ligand_pdbqt   = os.path.abspath(prep["pdbqt"]),
                config_txt     = config_txt,
                vina_path      = vina_path,
                exhaustiveness = args.exhaustiveness,
                n_modes        = args.poses,
                energy_range   = 3,
                wdir           = lig_wdir,
                out_name       = nm,
            )
            if not dock["success"] or dock["top_score"] is None:
                results.append({"Name": nm, "SMILES": smi, "Top Score": None,
                                 "Charge": prep.get("charge"), "Status": "DOCK_FAILED"})
                _warn("  Dock failed")
                continue

            pv_sdf = str(lig_wdir / f"{nm}_pv_ready.sdf")
            core.fix_sdf_bond_orders(dock["out_sdf"], prep.get("prot_smiles", smi), pv_sdf)
            if not os.path.exists(pv_sdf) or os.path.getsize(pv_sdf) < 10:
                pv_sdf = dock["out_sdf"]

            top = dock["top_score"]
            results.append({
                "Name": nm, "SMILES": smi,
                "Prepared SMILES": prep.get("prot_smiles", ""),
                "Top Score": top,
                "Charge": prep.get("charge"),
                "Status": "OK",
                "out_sdf": dock["out_sdf"],
                "pv_sdf": pv_sdf,
                "out_pdbqt": dock["out_pdbqt"],
            })
            label = "✓ Strong" if top < -9 else "✓ Moderate" if top < -7 else "  Weak"
            _ok(f"  {label}  {top:.2f} kcal/mol")

        except Exception as exc:
            results.append({"Name": nm, "SMILES": smi, "Top Score": None,
                             "Charge": None, "Status": f"ERROR: {exc}"})
            _warn(f"  Exception: {exc}")

    # ── Summary ───────────────────────────────────────────────────────────────
    _step("Batch Summary")
    ok_results = sorted([r for r in results if r["Status"] == "OK"],
                        key=lambda r: r["Top Score"])

    if _RICH:
        t = Table(
            title=f"Batch Results  (ref = {ref_score:.2f} kcal/mol)" if ref_score
                  else "Batch Results",
            show_header=True, header_style="bold cyan",
        )
        t.add_column("Rank"); t.add_column("Name")
        t.add_column("Top Score", justify="right")
        t.add_column("Δ vs ref",  justify="right")
        t.add_column("Charge",    justify="right")
        for rank, r in enumerate(ok_results, 1):
            s     = r["Top Score"]
            color = "green" if s < -9 else "yellow" if s < -7 else "red"
            delta = f"{s - ref_score:+.2f}" if ref_score is not None else "—"
            t.add_row(str(rank), r["Name"], f"[{color}]{s:.2f}[/{color}]",
                      delta, str(r.get("Charge", "?")))
        _con.print(t)
    else:
        print(f"\n{'Rank':>5}  {'Name':<30}  {'Score':>10}  {'Δ ref':>8}  {'Charge':>8}")
        print("─" * 68)
        for rank, r in enumerate(ok_results, 1):
            s     = r["Top Score"]
            delta = f"{s - ref_score:+.2f}" if ref_score is not None else "—"
            print(f"{rank:>5}  {r['Name']:<30}  {s:>10.2f}  {delta:>8}  "
                  f"{str(r.get('Charge','?')):>8}")

    csv_path = str(out / "batch_scores.csv")
    with open(csv_path, "w", newline="") as fh:
        fieldnames = ["Name", "SMILES", "Prepared SMILES", "Top Score",
                      "Charge", "Status", "out_sdf", "pv_sdf"]
        w = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader(); w.writerows(results)

    n_ok = sum(1 for r in results if r["Status"] == "OK")
    _ok(f"Scores CSV  : {csv_path}")
    _ok(f"Completed   : {n_ok}/{n} ligands docked successfully")
    if ref_score is not None and ok_results:
        _ok(f"Better than reference: {sum(1 for r in ok_results if r['Top Score'] < ref_score)} ligand(s)")


# ── 2D diagram helper ─────────────────────────────────────────────────────────

def _generate_diagram(core, rec_fh, pose_sdf, smiles, lig_name,
                      best_score, pose_idx, out, cutoff=4.5):
    try:
        title = f"Pose {pose_idx+1}  ·  {lig_name}"
        if best_score is not None:
            title += f"  ·  {best_score:.2f} kcal/mol"
        print("⏳  Generating 2D interaction diagram …")
        svg_bytes = core.draw_interaction_diagram(
            receptor_pdb  = rec_fh,
            pose_sdf      = pose_sdf,
            smiles        = smiles,
            title         = title,
            cutoff        = cutoff,
            size          = (800, 759),
            max_residues  = 14,
        )
        diag_path = str(out / f"{lig_name}_diagram.svg")
        with open(diag_path, "wb") as fh:
            fh.write(svg_bytes)
        _ok(f"2D diagram SVG: {diag_path}")

        try:
            import cairosvg
            png_bytes = cairosvg.svg2png(bytestring=svg_bytes, scale=2,
                                          background_color="white")
            png_path = str(out / f"{lig_name}_diagram.png")
            with open(png_path, "wb") as fh:
                fh.write(png_bytes)
            _ok(f"2D diagram PNG: {png_path}")
        except ImportError:
            _warn("cairosvg not installed — PNG skipped (pip install cairosvg)")
    except Exception as exc:
        _warn(f"Diagram generation failed: {exc}")


def cmd_diagram(args):
    core = _import_core()
    _step("2D interaction diagram")

    if not os.path.exists(args.receptor):
        _err(f"Receptor PDB not found: {args.receptor}")
    if not os.path.exists(args.pose_sdf):
        _err(f"Pose SDF not found: {args.pose_sdf}")

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    mols = core.load_mols_from_sdf(args.pose_sdf, sanitize=False)
    if not mols:
        _err("No molecules found in SDF file")
    idx = max(0, min(args.pose - 1, len(mols) - 1))

    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".sdf", delete=False) as tf:
        tmp_sdf = tf.name
    core.write_single_pose(mols[idx], tmp_sdf)

    _generate_diagram(
        core       = core,
        rec_fh     = args.receptor,
        pose_sdf   = tmp_sdf,
        smiles     = args.smiles or "",
        lig_name   = args.name or "ligand",
        best_score = args.score,
        pose_idx   = idx,
        out        = out,
        cutoff     = args.cutoff,
    )
    os.unlink(tmp_sdf)


# ── argument parser ───────────────────────────────────────────────────────────

def _add_receptor_args(p):
    p.add_argument("--receptor", metavar="PDB_ID_or_FILE",
                   help="4-letter PDB ID (auto-downloaded) or path to .pdb/.cif file")
    p.add_argument("--receptor-json", metavar="PATH",
                   help="JSON from a previous  acd receptor  run (skips re-prep)")
    p.add_argument("--fmt", default="PDB", choices=["PDB", "CIF"])
    p.add_argument("--center", default="auto",
                   choices=["auto", "manual", "selection"])
    p.add_argument("--cx", type=float, help="X centre (--center manual)")
    p.add_argument("--cy", type=float, help="Y centre (--center manual)")
    p.add_argument("--cz", type=float, help="Z centre (--center manual)")
    p.add_argument("--sel", metavar="PRODY_SEL",
                   help="ProDy selection string (--center selection)")
    p.add_argument("--bx", type=int, default=20, help="Box X size Å (default: 20)")
    p.add_argument("--by", type=int, default=20, help="Box Y size Å (default: 20)")
    p.add_argument("--bz", type=int, default=20, help="Box Z size Å (default: 20)")


def _add_ligand_args(p):
    p.add_argument("--smiles",       metavar="SMILES",
                   help="Ligand SMILES string")
    p.add_argument("--compound",     metavar="NAME",
                   help="Compound name to search on PubChem (e.g. baicalein, erlotinib)")
    p.add_argument("--ligand-file",  metavar="PATH",
                   help="Ligand structure file (.sdf/.mol2/.pdb)")
    p.add_argument("--name",         default="LIG",
                   help="Ligand output name (default: LIG)")
    p.add_argument("--ph",           type=float, default=7.4,
                   help="Target pH (default: 7.4)")
    p.add_argument("--pkanet",       action="store_true", default=True,
                   help="Use pKaNET Cloud+ protonation (default)")
    p.add_argument("--neutral",      action="store_true",
                   help="Neutral mode: keep input charge, add H only")
    p.add_argument("--no-pubchem",   action="store_true",
                   help="Skip PubChem pKa lookup")
    p.add_argument("--max-tautomers", type=int, default=8, metavar="N")
    p.add_argument("--ph-window",    type=float, default=1.0)


def _add_vina_args(p):
    p.add_argument("-e", "--exhaustiveness", type=int, default=16, metavar="N",
                   help="Vina exhaustiveness (default: 16)")
    p.add_argument("-n", "--poses",          type=int, default=10, metavar="N",
                   help="Max poses to output (default: 10)")
    p.add_argument("--energy-range",         type=float, default=3.0, metavar="KCAL",
                   help="Energy range above best pose (default: 3.0)")


def build_parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="acd",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    root.add_argument("--version", action="version", version="%(prog)s (anyonecandock)")
    sub = root.add_subparsers(dest="command", required=True)

    # ── dock ──────────────────────────────────────────────────────────────────
    p_dock = sub.add_parser(
        "dock",
        help="Full pipeline: receptor → ligand → Vina → results",
        description=textwrap.dedent("""\
            End-to-end single-ligand docking.

            Examples
            --------
              acd dock --receptor 1M17 --smiles "CCO" --name ethanol
              acd dock --receptor 1M17 --compound baicalein
              acd dock --receptor receptor.pdb --ligand-file ligand.sdf --name mylig
              acd dock --receptor-json ./rec/receptor_summary.json --compound erlotinib
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_receptor_args(p_dock)
    _add_ligand_args(p_dock)
    _add_vina_args(p_dock)
    p_dock.add_argument("-o", "--output", default="./acd_results")
    p_dock.add_argument("--redock-smiles", metavar="'SMILES [name]'")
    p_dock.add_argument("--save-poses", action="store_true")
    p_dock.add_argument("--diagram", action="store_true")
    p_dock.add_argument("--diagram-cutoff", type=float, default=4.5, metavar="Å")

    # ── batch ─────────────────────────────────────────────────────────────────
    p_batch = sub.add_parser(
        "batch",
        help="Batch docking from a .smi file or SMILES list",
        description=textwrap.dedent("""\
            Examples
            --------
              acd batch --receptor 1M17 --ligands compounds.smi
              acd batch --receptor 4AGN --smiles-list "CCO ethanol" "c1ccccc1O phenol"
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_receptor_args(p_batch)
    _add_vina_args(p_batch)
    p_batch.add_argument("--ph",          type=float, default=7.4)
    p_batch.add_argument("--pkanet",      action="store_true", default=True)
    p_batch.add_argument("--neutral",     action="store_true")
    p_batch.add_argument("--ligands",     metavar="FILE.smi")
    p_batch.add_argument("--smiles-list", nargs="+", metavar="'SMILES [name]'")
    p_batch.add_argument("--redock-smiles", metavar="'SMILES [name]'")
    p_batch.add_argument("-o", "--output", default="./acd_batch")

    # ── receptor ──────────────────────────────────────────────────────────────
    p_rec = sub.add_parser("receptor", help="Prepare receptor only")
    p_rec.add_argument("--pdb",    metavar="PDB_ID")
    p_rec.add_argument("--file",   metavar="PATH")
    p_rec.add_argument("--fmt",    default="PDB", choices=["PDB", "CIF"])
    p_rec.add_argument("--center", default="auto",
                       choices=["auto", "manual", "selection"])
    p_rec.add_argument("--cx", type=float)
    p_rec.add_argument("--cy", type=float)
    p_rec.add_argument("--cz", type=float)
    p_rec.add_argument("--sel", metavar="PRODY_SEL")
    p_rec.add_argument("--bx", type=int, default=20)
    p_rec.add_argument("--by", type=int, default=20)
    p_rec.add_argument("--bz", type=int, default=20)
    p_rec.add_argument("-o", "--output", default="./acd_receptor")

    # ── ligand ────────────────────────────────────────────────────────────────
    p_lig = sub.add_parser("ligand", help="Prepare ligand only")
    _add_ligand_args(p_lig)
    p_lig.add_argument("--file", metavar="PATH")
    p_lig.add_argument("-o", "--output", default="./acd_ligand")

    # ── diagram ───────────────────────────────────────────────────────────────
    p_diag = sub.add_parser("diagram", help="Generate 2D interaction diagram")
    p_diag.add_argument("--receptor", required=True, metavar="PATH")
    p_diag.add_argument("--pose-sdf", required=True, metavar="PATH")
    p_diag.add_argument("--smiles",   metavar="SMILES")
    p_diag.add_argument("--name",     default="ligand")
    p_diag.add_argument("--pose",     type=int, default=1)
    p_diag.add_argument("--score",    type=float)
    p_diag.add_argument("--cutoff",   type=float, default=4.5)
    p_diag.add_argument("-o", "--output", default="./acd_diagram")

    return root


def main():
    parser = build_parser()
    args   = parser.parse_args()

    dispatch = {
        "dock":     cmd_dock,
        "batch":    cmd_batch,
        "receptor": cmd_receptor,
        "ligand":   cmd_ligand,
        "diagram":  cmd_diagram,
    }
    fn = dispatch.get(args.command)
    if fn is None:
        parser.print_help()
        sys.exit(1)

    try:
        fn(args)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)


if __name__ == "__main__":
    main()