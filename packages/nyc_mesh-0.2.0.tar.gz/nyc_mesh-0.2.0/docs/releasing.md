# Releasing

This guide covers the current PyPI release workflow for `nyc-mesh`.

## Release discipline

- Current release line: `0.1.x`
- Version source: git tags via Hatch VCS
- Preferred publish trigger: GitHub Release publication

Patch releases in the `0.1.x` line should stay backward-compatible. Cut a new
minor release when the documented extraction workflow, dependency expectations,
or public export surface expands in a meaningful way.

## Pre-release checks

Before tagging a release, run:

```bash
make ci
make audit
make docs-build
make smoke-dist
```

That covers:

- lint, typing, and public API checks
- docs build validation
- source and wheel builds
- installed-wheel smoke testing for the CLI and a known-good local CityGML
  workflow

## Publishing configuration

This repo publishes through `.github/workflows/cd.yml` using GitHub trusted
publishing and the `pypi` environment.

Repository-admin setup such as PyPI project creation, trusted publisher
registration, and Read the Docs project linking is managed manually outside the
repo and is intentionally not duplicated here.

## Release path

The standard production path is:

1. create the final release tag, for example `0.1.0`
2. push the tag
3. optionally run the `CD` workflow against TestPyPI first
4. publish the matching GitHub Release
5. let the `release.published` trigger publish to real PyPI

If you prefer the manual route, run the `CD` workflow from the same tag with:

- `publish=true`
- `repository=pypi`

## Post-release verification

After the release lands on PyPI:

1. Install `nyc-mesh` from PyPI in a clean environment.
2. Run `nyc-mesh --help`.
3. Run
   `nyc-mesh export-geojson --input "C:/path/to/DA_WISE_GML.zip" --output buildings.geojson`
   with a known-good official or pinned local CityGML input.
4. Confirm the PyPI project page renders the README correctly.
5. Confirm the docs site, GitHub release notes, and repo sidebar links reflect
   the release.
