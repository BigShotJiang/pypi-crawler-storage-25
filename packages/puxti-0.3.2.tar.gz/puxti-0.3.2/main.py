def main():
    print("Hello from puxti!")


if __name__ == "__main__":
    main()
