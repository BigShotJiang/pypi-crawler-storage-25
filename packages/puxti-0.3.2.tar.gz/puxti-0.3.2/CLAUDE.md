# puxti — CLAUDE.md

This file gives Claude Code persistent context for the puxti project.
Read this before every session. Keep it under 200 lines.

---

## What We're Building

Puxti is an **organizational knowledge layer for data teams** that lowers the cost
of evolving data models by making implicit definitions explicit at the moment of change.

**The wedge:** schema change propagation — detect a change, capture its semantic
meaning, generate downstream updates (dbt, Airflow/Dagster, dashboards, docs) as a
reviewable PR.

**The deeper value:** every change builds a knowledge layer about this org's specific
data semantics, making future changes cheaper and smarter. It compounds.

**Name:** Puxtiri (Aymara) = water running down.

---

## Two Types of Change We Solve

| Type | Example | Approach |
|------|---------|----------|
| Structural | `date` → `recorded_date` column rename | Deterministic propagation |
| Semantic | Opportunity → line items per opportunity (cardinality shift) | Semantic capture + reasoning |

Both require understanding **organizational reality**, not just schema diffs.
This is what differentiates puxti from code generators and data catalogs.

---

## Current Status

- **Phase:** Discovery complete — shifting to design partner iteration
- **Interviews done:** 9 — see `@docs/contacts.md`
- **Design partners confirmed:** 3 (2 paying, 1 free tier) — see `@docs/contacts.md`
- **Key decisions made:**
  - Entry point: **web app** (entity graph + change workflow) + CLI for engineers
  - Connector architecture: **stack-agnostic core**, connectors as plugins
  - v1 connectors: **dbt + Airflow first**, then expand
  - Upstream boundary: ingestion layer — streaming (Kafka/Flink) is phase 2+
  - Semantic graph is a **first-class layer** in the Knowledge Graph, separate from structural lineage
  - Dual interface confirmed: CLI for engineers, web UI for PM/manager discussions
  - Model-agnostic LLM configuration needed — 3 of 9 interviews are GCP/Gemini shops

Do not build features that haven't been validated in interviews yet.
Check `docs/interviews/` for latest signal before scoping anything.

---

## Project Structure

```
puxti/
├── CLAUDE.md              ← you are here
├── docs/
│   ├── spec.md            ← product spec (source of truth)
│   ├── interviews/        ← one file per interview
│   └── architecture.md   ← technical design (when ready)
├── src/
│   ├── core/              ← change detection + semantic capture
│   ├── connectors/        ← dbt, Airflow, Dagster, BigQuery, etc.
│   ├── propagation/       ← downstream update generation
│   └── api/               ← backend API
├── tests/
└── README.md
```

If a directory doesn't exist yet, create it before writing files into it.

---

## Tech Stack (Planned)

- **Language:** Python (primary), TypeScript (web app frontend)
- **Package manager:** `uv` for Python, `pnpm` for Node
- **Database:** PostgreSQL (metadata store)
- **Graph store:** Neo4j (decided)
- **LLM:** Anthropic Claude API (`claude-sonnet-4-6` for semantic reasoning)
- **Testing:** pytest (Python), vitest (TS)
- **Infra:** TBD — keep cloud-agnostic for now

Update this section when decisions are confirmed.

---

## Coding Conventions

- Python: type hints on all function signatures
- Keep functions small and single-purpose
- Connectors must implement a standard interface — see `src/connectors/base.py`
- Never hardcode credentials — use environment variables via `.env` + `python-dotenv`
- All schema change operations must be **read-first, write-on-confirm** — never write
  to a user's data stack without explicit confirmation
- PRs are the output format — never push directly to main branches of connected repos

---

## Key Design Principles

1. **Semantic capture is mandatory, not optional.** Every propagation flow must include
   a step where the user describes what the change means. This is the product.

2. **Human stays in control.** Always deliver changes as a reviewable PR. Never
   auto-apply without confirmation. Trust is the hardest thing to earn.

3. **Load-bearing, not observational.** Puxti must be in the critical path of making
   changes — not a sidebar tool. If users can bypass it, they will.

4. **Connectors are modular.** Each tool integration (dbt, Airflow, Superset, etc.)
   is a separate connector with a standard interface. Never couple connector logic
   to core propagation logic.

5. **Forcing alignment is the product.** When two teams define the same entity
   differently, puxti surfaces the conflict and blocks propagation until both parties
   agree. Never silently pick one definition. The resolution — not the detection — is
   the value.

---

## Commands

```bash
# Setup
uv sync                        # install Python deps
pnpm install                   # install Node deps

# Development
uv run pytest                  # run tests
uv run python -m puxti         # run CLI locally

# Connectors
uv run pytest tests/connectors/  # test a specific connector

# Linting
uv run ruff check src/         # lint
uv run ruff format src/        # format
```

Add new commands here as the project grows.

---

## What NOT to Do

- Do not generate changes that apply directly to a user's production stack without a PR
- Do not build a data catalog — that is explicitly not the product
- Do not add a feature just because it sounds useful — check interview signal first
- Do not import from deprecated packages — check `pyproject.toml` for approved deps
- Do not write CLAUDE.md-style instructions into code comments

---

## Reference Docs

Use `@` to load these on demand (don't add them to this file):

- `@docs/milestones.md` — M1/M2/M3 breakdown and current status ← start here
- `@docs/spec.md` — full product spec
- `@docs/architecture.md` — technical architecture
- `@docs/interviews/` — customer interview notes and signal

---

*Last updated: April 2026 — discovery complete, 3 design partners confirmed, building*
