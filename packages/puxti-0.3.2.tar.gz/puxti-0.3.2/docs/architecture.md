# Puxti — Architecture

**Version:** v0.2
**Date:** April 2026
**Status:** Working prototype — M1 (capture + column rename) and M2 (scan + redefine) are complete and tested.
Decisions marked 🔲 are open. Decisions marked ✅ are confirmed.

---

## Table of Contents

1. [Guiding Principles](#1-guiding-principles)
2. [System Overview](#2-system-overview)
3. [Core Components](#3-core-components)
4. [Data Model](#4-data-model)
5. [The Semantic Capture Flow](#5-the-semantic-capture-flow)
5b. [The Knowledge Graph Correction Flow](#5b-the-knowledge-graph-correction-flow)
6. [Connector Architecture](#6-connector-architecture)
7. [LLM Usage](#7-llm-usage)
8. [Trust & Safety Model](#8-trust--safety-model)
9. [Tech Stack Decisions](#9-tech-stack-decisions)
10. [Open Architecture Questions](#10-open-architecture-questions)

---

## 1. Guiding Principles

These constrain every architecture decision. If a proposal violates one, revisit it.

**1. Read-first, write-on-confirm.**  
Puxti never modifies a user's data stack without explicit human confirmation. All generated changes are delivered as a reviewable PR. The system observes and proposes; the human decides.

**2. Semantic capture is in the critical path.**  
Every propagation flow must pass through a semantic capture step. This is not optional and cannot be bypassed. It is the mechanism by which the knowledge layer is built over time.

**3. Connectors are modular and isolated.**  
No connector knows about another connector. The core orchestration layer is the only thing that understands the full graph. This keeps integrations testable, replaceable, and independently deployable.

**4. The knowledge layer compounds.**  
Every change enriches the system's understanding of this org's data semantics. Architecture decisions should be evaluated by whether they support or undermine this compounding property.

**5. Trust is earned incrementally.**  
Start with read-only access where possible. Request write access (PR generation) only when needed. Never ask for more permissions than the current feature requires.

---

## 2. System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        USER INTERFACE                       │
│                         (Web App)                           │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                       PUXTI CORE                            │
│                                                             │
│   ┌─────────────┐   ┌──────────────┐   ┌───────────────┐  │
│   │   Change     │   │   Semantic   │   │  Propagation  │  │
│   │  Detection  │──▶│   Capture    │──▶│    Engine     │  │
│   └─────────────┘   └──────────────┘   └───────┬───────┘  │
│                                                 │           │
│   ┌─────────────────────────────────────────────▼───────┐  │
│   │                  Knowledge Graph                     │  │
│   │     (entities · definitions · lineage · history)    │  │
│   └─────────────────────────────────────────────────────┘  │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                     CONNECTOR LAYER                         │
│                                                             │
│   Warehouse    dbt      Airflow   Dagster   BI    Git/VCS   │
│  (BQ/Snwflk) (Core/Cld) (DAGs)   (assets) (Superset etc.) │
└─────────────────────────────────────────────────────────────┘
```

The three core modules — Change Detection, Semantic Capture, and Propagation Engine — are stateless processors. All state lives in the Knowledge Graph.

---

## 3. Core Components

### 3.1 Change Detection

Responsible for identifying that something has changed (or is about to change) in the user's data stack.

**Two modes:**
- **Reactive:** watches for schema changes in the warehouse (column added/renamed/dropped, table restructured). Triggered by a webhook, scheduled poll, or CI hook.
- **Proactive:** user explicitly declares a change is coming ("I'm about to rename this column"). This is the preferred mode for Type 2 (semantic) changes where the intent precedes the implementation.

**Inputs:** warehouse schema snapshots, git diffs, user declarations  
**Outputs:** a `ChangeEvent` — structured representation of what changed and where

```python
# Rough shape — not final
@dataclass
class ChangeEvent:
    id: str
    type: Literal["structural", "semantic", "unknown"]
    source: str                  # e.g. "bigquery.my_dataset.users"
    change: dict                 # before/after representation
    detected_at: datetime
    declared_by: str | None      # user who declared it, if proactive
    semantic_context: str | None # filled in by Semantic Capture
```

---

### 3.2 Semantic Capture

The heart of Puxti. Transforms a raw `ChangeEvent` into a semantically enriched event that the Propagation Engine can reason about.

**Process:**
1. Receives a `ChangeEvent`
2. Queries the Knowledge Graph for existing context about the affected entities
3. Presents the user with a structured prompt: *"You renamed `date` to `recorded_date` in the users table. What does this change mean? What should downstream consumers understand about this?"*
4. User provides semantic context (free text, or guided options based on change type)
5. LLM enriches and structures the response (see §7)
6. Writes enriched definition back to Knowledge Graph
7. Returns a `SemanticChangeEvent` to the Propagation Engine

**Design constraint:** this step must feel lightweight. If it takes more than 60 seconds of user effort, adoption will fail. The UX here is critical.

---

### 3.3 Propagation Engine

Receives a `SemanticChangeEvent` and determines what needs to change across the connected stack.

**Process:**
1. Queries the Knowledge Graph for all nodes dependent on the changed entity
2. For each dependent node, determines the nature of the required change
3. Dispatches to the relevant connector(s) to generate the actual changes
4. Assembles all generated changes into a single PR payload
5. Opens a PR via the VCS connector (GitHub/GitLab)

**Key challenge:** handling Type 2 (semantic) changes where the propagation is not deterministic. For a column rename, the change is mechanical. For a cardinality shift (opportunity → line items), the engine must reason about what downstream models *mean*, not just what they reference.

✅ **Decided:** always generate a proposal with transparent reasoning. See §10, question 3.

---

### 3.4 Knowledge Graph

The persistent state of Puxti. Stores:

- **Entities** — tables, columns, models, DAGs, dashboards, metrics
- **Definitions** — semantic descriptions of each entity, versioned over time
- **Lineage** — directed graph of dependencies between entities
- **Change history** — every change event and its semantic context, with timestamps
- **Org context** — team structure, ownership, stack configuration

**Why a graph?** Lineage is fundamentally a graph problem. Chained dbt model dependencies, cross-tool propagation paths, and multi-hop impact analysis all require efficient traversal. A relational DB can model this but with significantly more complexity.

**Two layers within the graph:**

The Knowledge Graph has two distinct layers that must not be conflated:

- **Structural lineage** — which entity depends on which. Populated by connectors reading
  the actual stack (dbt manifest, Airflow DAGs, etc.). This is deterministic and connector-specific.

- **Semantic graph** — what each entity *means* and how concepts relate to each other across
  the full stack, regardless of which connector owns them. This is populated by semantic
  capture — built from user descriptions accumulated over every change.

The semantic graph is first-class, not an annotation on top of structural lineage.
This is what allows puxti to handle chained semantic dependencies — for example:

  `sales → revenue → marketing cost ratio → board dashboard`

A structural lineage tool sees that `revenue` references `sales`. The semantic graph knows
that *revenue is calculated from sales excluding refunds*, so redefining *sales* to include
trial conversions makes *revenue* wrong, the *ratio* misleading, and the board dashboard
untrustworthy — even if nothing in the dbt graph technically broke.

**Design implication:** the semantic graph must be queryable independently of connectors.
The Propagation Engine queries it to understand meaning before dispatching to connectors
for structural changes.

✅ **Decided:** Neo4j. See §10, question 1.

---

## 4. Data Model

High-level entity model. Not final — will evolve with the prototype.

```
Entity
  id, name, type (table|column|model|dag|dashboard|metric)
  source_connector
  project              ← project name (e.g. dbt project, Airflow instance). Used for scoping and purge.
  created_at, updated_at

Definition
  id, entity_id
  description (semantic text)
  version, created_at
  created_by (user | llm | import | scan | correct)
  change_event_id (the change that triggered this definition)

Edge (lineage)
  from_entity_id, to_entity_id
  type (depends_on | transforms | references | derived_from)
  connector

ChangeEvent
  id, type, source_entity_id
  change (jsonb — before/after)
  semantic_context (text)
  status (detected | captured | propagated | closed)
  created_at

PropagationResult
  change_event_id
  connector
  target_entity_id
  generated_diff (text)
  pr_url
  status (pending | opened | merged | rejected)
```

---

## 5. The Semantic Capture Flow

This is the most important user-facing flow in the product. Every other component serves it.

```
Web App (user-initiated) / CI Hook (automated detection)
      │
      │  schema diff or explicit declaration
      ▼
Change Detection
      │
      │  ChangeEvent
      ▼
Knowledge Graph ◀──── "what do we already know about this entity?"
      │
      │  existing definitions + lineage context
      ▼
Semantic Capture (LLM-assisted)
      │
      │  structured prompt to user
      ▼
User Input  ◀──── "what does this change mean?"
      │
      │  free text / guided response
      ▼
LLM Enrichment  ◀──── structures, validates, resolves ambiguity
      │
      │  SemanticChangeEvent
      ▼
Knowledge Graph ◀──── write enriched definition (versioned)
      │
      │  SemanticChangeEvent
      ▼
Propagation Engine
      │
      │  connector dispatch
      ▼
PR opened on GitHub/GitLab
      │
      │  human reviews and merges
      ▼
Knowledge Graph ◀──── mark change as closed, record PR outcome
```

---

## 5b. The Knowledge Graph Correction Flow

This flow handles the case where an entity's definition in the Knowledge Graph is
inaccurate — either because the LLM inferred it incorrectly during scan, or because
the user wants to refine it before it compounds into downstream errors.

**This is distinct from `redefine`.** `redefine` handles a real change in business
reality and propagates it to code as a PR. `correct` fixes the KG's representation
of what was always true. Conflating the two would either generate unnecessary PRs
or silently miss changes that needed propagation.

### Command

```bash
puxti correct --entity <entity_id>
```

### Flow

```
User invokes puxti correct --entity <id>
      │
      │  fetch current definition + all edges (from and to)
      ▼
Display current state
  - Current definition text
  - All semantic edges involving this entity (both directions)
      │
      │  user provides corrected definition
      ▼
Show diff (old definition → new definition)
      │
      │  confirm diff or edit further
      ▼
Re-evaluate affected edges
  - LLM reviews each edge in light of the new definition
  - Flags edges that look inconsistent with the correction
  - User decides per edge: keep / update description / remove
      │
      │  per-edge decisions confirmed
      ▼
Classify the correction
  Puxti asks: "Is this a correction to how puxti understood this entity,
  or has the business meaning of this entity actually changed?"
      │
      ├── Correction (KG was wrong)
      │     → write new definition version + updated edges to KG
      │     → done, no PRs generated
      │
      └── Real change (business reality changed)
            → hand off to redefine flow with new definition pre-filled
            → redefine generates PRs as normal
```

### Key Design Constraints

**Atomic writes.** All KG updates — new definition version and all edge changes —
are written together or not at all. No partial states where definition and edges
are inconsistent.

**Versioned, not overwritten.** The correction writes a new definition version
(version + 1), preserving the previous definition in history. The audit log records
the correction with `created_by="correct"` to distinguish it from scan-inferred
and user-declared definitions.

**Edge re-evaluation is LLM-assisted, human-confirmed.** The LLM proposes which
edges to keep, update, or remove based on the new definition. The user makes the
final call on each — consistent with the read-first, write-on-confirm principle.

**Corrections are a quality signal.** Every correction on a scan-inferred definition
is evidence that the LLM's initial inference was off for that entity type or SQL
pattern. Log corrections separately in the audit log so the pattern can be analyzed
over time to identify where auto-scan is weakest.

### Data Model Addition

```
CorrectionEvent
  id, entity_id
  old_definition_id, new_definition_id
  edges_kept: list[edge_id]
  edges_updated: list[{edge_id, new_description}]
  edges_removed: list[edge_id]
  classified_as: "correction" | "real_change"
  created_at, created_by
```

If `classified_as = "real_change"`, the CorrectionEvent links to the resulting
ChangeEvent created by the `redefine` handoff.

---

## 6. Connector Architecture

Each connector is an isolated module that implements a standard interface. The core never calls connector internals directly — only through the interface.

### 6.0 Stack-Agnostic Design Decision

✅ **Decided:** the connector layer is stack-agnostic from day one. The core — Knowledge Graph,
Semantic Capture, Propagation Engine — has no knowledge of any specific tool. Connectors are
plugins that implement the standard interface below.

**v1 connector priorities:** dbt (Core + Cloud) and Airflow as first connectors, alongside
warehouse read connectors (BigQuery, Snowflake) and GitHub for PR output. Additional connectors
(Dagster, Looker, Superset) follow based on design partner needs.

**Rationale:** 4 of 6 discovery interviews involved non-dbt-primary stacks (Databricks,
Snowflake, Kafka/Flink, Java/MySQL). A dbt-only architecture would exclude the majority of
the signal. Building the connector interface correctly once is preferable to a costly refactor
after v1.

### 6.1 Base Interface

```python
from abc import ABC, abstractmethod
from puxti.models import ChangeEvent, SemanticChangeEvent, ConnectorConfig

class BaseConnector(ABC):

    def __init__(self, config: ConnectorConfig):
        self.config = config

    @abstractmethod
    def health_check(self) -> bool:
        """Verify connection and required permissions."""

    @abstractmethod
    def extract_schema(self) -> list[Entity]:
        """Read current state of all entities in this connector."""

    @abstractmethod
    def extract_lineage(self) -> list[Edge]:
        """Read dependency graph for entities in this connector."""

    @abstractmethod
    def generate_changes(self, event: SemanticChangeEvent) -> list[FileDiff]:
        """Given a semantic change event, generate the required file changes.
        Must NOT write anything — returns diffs only.

        Warehouse connectors (BigQuery, Snowflake, Databricks) must return []
        here. The warehouse is the source of truth for what changed, never the
        target of generated changes. All propagation targets are downstream
        connectors (dbt, Airflow, BI tools). This asymmetry is intentional."""

    def supports_change_type(self, change_type: str) -> bool:
        """Override to declare which change types this connector handles."""
        return True
```

### 6.2 Connector Registry (v1 scope)

| Connector | Read (schema + lineage) | Write (generate diff) | Priority |
|---|---|---|---|
| `BigQueryConnector` | ✅ | n/a (warehouse) | P0 |
| `SnowflakeConnector` | ✅ | n/a (warehouse) | P0 |
| `DbtCoreConnector` | ✅ | ✅ | P0 |
| `DbtCloudConnector` | ✅ | ✅ | P0 |
| `AirflowConnector` | ✅ | ✅ | P0 |
| `DagsterConnector` | ✅ | ✅ | P1 |
| `GitHubConnector` | ✅ | ✅ (open PR) | P0 |
| `GitLabConnector` | ✅ | ✅ (open PR) | P1 |
| `LookerConnector` | ✅ | ✅ (LookML — Git-native) | P1 |
| `SupersetConnector` | ✅ | ✅ (YAML export/import) | P2 |

### 6.3 Connector Configuration

Each connector is configured via a `puxti.yaml` in the repo root:

```yaml
# puxti.yaml — example
version: 1

connectors:
  warehouse:
    type: bigquery
    project: my-gcp-project
    dataset: analytics

  transformation:
    type: dbt_core
    project_dir: ./dbt
    profiles_dir: ~/.dbt

  orchestration:
    type: airflow
    base_url: https://airflow.internal
    dag_dir: ./dags

  vcs:
    type: github
    repo: my-org/data-platform
    base_branch: main
```

---

## 7. LLM Usage

Puxti uses Claude (Anthropic) for semantic reasoning tasks. LLM calls are never in the read path — only in the semantic capture and propagation reasoning steps.

### 7.1 Where LLM Is Used

| Task | Model | Notes |
|---|---|---|
| Semantic capture enrichment | `claude-sonnet-4-6` | Structures user input into a clean definition |
| Ambiguity resolution | `claude-sonnet-4-6` | Asks clarifying questions when change intent is unclear |
| Propagation reasoning (Type 2) | `claude-sonnet-4-6` | Reasons about non-deterministic semantic changes |
| Release note generation | `claude-sonnet-4-6` | Drafts human-readable change summary |
| Scan — definition inference | `claude-sonnet-4-6` | Infers starter business definitions from SQL + upstream context |
| Scan — semantic edge proposal | `claude-sonnet-4-6` | Proposes DERIVED_FROM edges between models; batched to avoid token limits |
| Correct — edge re-assessment | `claude-sonnet-4-6` | Reviews affected edges when a definition is corrected; proposes keep/update/remove per edge |

### 7.2 Where LLM Is NOT Used

- Schema diffing (deterministic)
- dbt model parsing (use dbt's own manifest)
- Lineage extraction (deterministic graph traversal)
- PR generation for Type 1 (structural) changes — these are templated

### 7.3 Prompt Design Principles

- Always provide the full Knowledge Graph context for the affected entity before asking for reasoning
- Keep user-facing prompts under 3 sentences — this is a productivity tool, not a chat interface
- LLM outputs for code changes must always be validated against the connector's schema before being included in a PR
- Never include credentials or raw data in LLM prompts — only metadata and definitions

### 7.4 SQL Generation Confidence Model

For semantic changes (Case 3 — definition redefinition), the LLM attempts to generate SQL
diffs for affected downstream models. Confidence is determined by traversal depth in the
semantic graph — deeper chains compound uncertainty at each hop.

| Traversal depth | LLM action | PR annotation |
|-----------------|-----------|---------------|
| Hop 1 | Generate SQL diff | `PUXTI [high confidence] — verify reasoning` |
| Hop 2 | Generate SQL diff | `PUXTI [verify carefully] — logic inferred across 2 hops` |
| Hop 3+ | Impact analysis only, no SQL | `PUXTI [manual review required] — chain too deep to generate reliably` |

**Why depth drives confidence:**
The human expert's mental map of metric dependencies is a graph — the same structure puxti
models explicitly. Shallow graphs (1–2 hops, e.g. a marketing data mart) have simple additive
or filtered logic the LLM can reason about reliably. Deep graphs (3+ hops, e.g. insurance P&L,
balance sheets, regulatory capital ratios) compound uncertainty at each step — a wrong inference
at hop 2 silently corrupts everything downstream. The graph depth makes the risk visible.

**Practical implication:** domain complexity maps directly to graph depth. A marketing data mart
typically has 1–2 semantic hops. An insurance P&L or balance sheet may have 5–7. Puxti's
confidence degrades gracefully and visibly — engineers see *why* something requires manual
review, not just that it does.

**Long-term:** as the semantic graph matures through repeated use, the LLM has more context at
each hop. Confidence improves naturally without changing the model — the graph compounds.

### 7.5 Handling Large SQL Files

Real-world data stacks contain SQL files that can be hundreds or thousands of lines — deeply
chained CTEs, complex window functions, multi-stage aggregations. Sending a full large SQL file
to an LLM risks hitting output token limits and producing a truncated, invalid response.

Three strategies, in order of preference:

**1. Selective extraction via SQL AST (preferred)**
Since puxti always knows *what changed* (a specific column, table, or concept), a SQL parser
(`sqlglot`) can be used to extract only the clauses that reference the changed entity — JOIN
conditions, SELECT expressions, WHERE predicates, CTE references. The LLM receives the relevant
10–20 lines, not the full file. Changes are applied back to the original via a targeted patch.
This is surgical, dialect-aware (BigQuery, Snowflake, Redshift), and keeps LLM context small.

**2. CTE-aware chunking (fallback)**
When selective extraction is not precise enough, the SQL is split on CTE boundaries — which are
natural, well-defined seams. Each CTE is processed independently with a summary of preceding
CTEs as context rather than their full text. Results are reassembled in order. Works well for
pipelines structured as linear CTE chains.

**3. Two-pass: locate then rewrite**
First pass: send the full SQL and ask the LLM to identify which specific lines or expressions
reference the changed entity (response is just line numbers and short excerpts — small).
Second pass: send only those excerpts for the actual rewrite. Avoids needing a SQL parser,
at the cost of one additional LLM call.

**Implementation note:** `sqlglot` is the preferred parsing library. It handles multiple SQL
dialects natively — important because design partners run BigQuery, Snowflake, and Databricks.
Add it as a dependency when large-SQL handling is implemented, not before.

---

## 8. Trust & Safety Model

Trust is the hardest thing to earn in a tool that touches production data infrastructure. Every architecture decision should be evaluated against this model.

### 8.1 Permission Levels

| Level | What Puxti can do | When it applies |
|---|---|---|
| **Read-only** | Extract schema, lineage, definitions. No writes anywhere. | Onboarding, initial scan |
| **Propose** | Everything in Read + open draft PRs in VCS. Cannot merge. | Default operating mode |
| **Auto-apply** | Everything in Propose + merge PRs that pass all checks. | Opt-in, per change type, never default |

Auto-apply will not be available in v1. It may be introduced in a later phase for specific low-risk change types (e.g. documentation-only updates).

### 8.2 What Puxti Never Does

- Directly modifies warehouse schemas (ALTER TABLE, DROP COLUMN, etc.)
- Pushes to main/production branches
- Merges its own PRs
- Stores raw data — only metadata, schemas, and definitions
- Sends organizational data to third-party LLM providers without user consent

### 8.3 Audit Log

Every action Puxti takes is written to an immutable audit log:

```
timestamp | actor (user|system) | action | entity | before | after | pr_url
```

This is non-negotiable. Users must be able to see everything Puxti has ever done in their stack.

---

## 9. Tech Stack Decisions

| Layer | Decision | Status |
|---|---|---|
| Primary language | Python | ✅ |
| Package manager | `uv` | ✅ |
| API framework | FastAPI | ✅ directional |
| Metadata store | PostgreSQL | ✅ directional |
| Graph store | Neo4j | ✅ |
| LLM provider | Anthropic Claude API | ✅ |
| LLM model | `claude-sonnet-4-6` | ✅ |
| Frontend / UI | Web app (v1) — entity graph + change workflow | ✅ |
| CLI framework | Typer — primary interface for M1/M2; web app in M3 | ✅ |
| Testing | pytest + pytest-asyncio | ✅ |
| Linting / formatting | Ruff | ✅ |
| Containerization | Docker | ✅ directional |
| Deployment | cloud-agnostic for now | ✅ |

---

## 10. Open Architecture Questions

These need answers before or during the prototype phase. Ordered by priority.

**1. Graph store choice**
✅ **Decided: Neo4j.** Purpose-built for graph traversal, mature ecosystem, and the right
fit for the two-layer Knowledge Graph (structural lineage + semantic graph). Operational
complexity is an acceptable trade-off at this stage.

**2. Entry point**
✅ **Decided: web app.** Entity graph visualization with a structured change workflow on top.
First buyer-profile interview (Engineering Manager at a crypto exchange) described this unprompted — a surface
to see entities, describe changes semantically, view affected relations, and see what changes per
repo. CLI remains available as a secondary interface but is not the primary UX.

**3. Non-deterministic propagation strategy**
✅ **Decided: always generate a proposal, always show the reasoning.**

For Type 2 (semantic) changes, the engine always generates a best-effort proposal — never
just an impact report. An impact report without generated changes is a data catalog: it
observes but doesn't act. That is explicitly not the product.

The proposal is always accompanied by the chain of reasoning that produced it:
  - "I interpreted this change as X"
  - "Therefore I restructured these models as Y"
  - "Please verify the Z logic — this is where semantic ambiguity exists"

A wrong proposal with transparent reasoning is useful — the human can see where the
reasoning broke down, correct it, and that correction feeds back into the semantic graph.
A wrong proposal without reasoning is damaging — it looks confident and gets merged or
dismissed without understanding why it failed.

The PR is the safety net. The product is designed around human review — a wrong proposal
in a reviewable PR is a starting point, not a liability. A design partner's two-phase migration
instinct confirms this: users don't expect a perfect automated answer, they expect
something that moves the work forward and that they can validate.

**Implementation note:** the reasoning chain is generated by the LLM alongside the code
changes — not as a separate step. Both are part of the same PR payload. See §7.

**4. Multi-repo support**
✅ **Decided: independent PRs with a shared change ID.**
A single schema change generates one PR per affected repo. All PRs share a `change_id`
that links them together — visible in the PR description and queryable in the Knowledge
Graph. This gives reviewers in each repo full context ("this PR is part of change X which
also touches dbt and Looker") without requiring atomic cross-repo transactions, which are
fragile and hard to roll back.

The shared change ID is the traceability primitive. The audit log uses it to track the
full propagation lifecycle across all repos from a single change event.

**5. Onboarding and initial scan**
✅ **Decided: progressive enrichment across four layers.**

Onboarding builds the Knowledge Graph incrementally — starting from what can be inferred
automatically and deepening through human input and existing knowledge artifacts.

**Layer 1 — Schema scan (automated, zero effort)** ✅ Implemented as `puxti scan`
Puxti reads the dbt manifest on first connection: all model entities, structural lineage
edges, and column-level relationships. LLM infers a starter definition for each model
from SQL + upstream context + any descriptions already in dbt yml files. Two modes:
`--interactive` (one model at a time, user confirms each before writing) and `--auto`
(all definitions in one pass, user reviews the full table and confirms as a group).
After definitions are written, LLM proposes initial semantic edges (DERIVED_FROM, etc.)
for a second round of confirmation. This is the baseline: structurally complete, with
an LLM-seeded semantic graph the human has explicitly confirmed.

**Layer 2 — Human validation (guided reaction workflow)**
The tool presents what it found and asks the human to react: "here's what I think I'm
seeing — does this look right?" Not a blank form. The human corrects misclassifications,
names unnamed concepts, and fills gaps the scan couldn't infer. This is where the
semantic graph gets its first real content. Framed as "version 0.1 — your feedback makes
it smarter" to set the right expectation and position the human as collaborator, not
corrector.

**Layer 3 — Document ingestion (passive enrichment)**
The human can feed in existing knowledge artifacts: specs, Confluence exports, PDFs,
Notion pages, data dictionaries. The LLM extracts definitions, business concepts, and
relationships and proposes additions to the semantic graph. The human confirms or rejects
each proposal. Nothing lands as canonical without confirmation.

**Layer 4 — Git history (retrospective context)**
PRs and commit history in GitHub/GitLab are mined for semantic signals — PR descriptions,
review comments, commit messages often contain the reasoning behind past changes
("renamed this because the business now defines X as Y"). Treated as suggestive rather
than authoritative — rich when available, noisy when not. Always requires human
confirmation before entering the semantic graph.

**Design constraint across all layers:** the human always confirms before anything is
written to the semantic graph as canonical. The scan guesses, the documents suggest,
the PRs hint — nothing is trusted until a human says so. Consistent with the
read-first, write-on-confirm principle (§1).

**6. Definition conflicts**
✅ **Decided: conflict resolution flow, both parties must agree.**
When the same entity is defined differently by two teams, puxti surfaces the conflict
explicitly — showing both definitions side by side, similar to a merge conflict in
GitHub or GitLab. Neither definition is silently overwritten. Both owners are notified
and must reach an agreed resolution before the change can be propagated.

The resolved definition is written to the semantic graph as the canonical version,
with the conflict history preserved for audit. If the parties cannot agree, the change
is blocked — puxti does not propagate on top of an unresolved conflict.

This is intentional: forcing alignment is the product. Silently picking one definition
would undermine the entire semantic layer.

---

*puxti.com · architecture v0.2 · April 2026 · M1 + M2 complete*
*Update this document as decisions get made. Mark resolved questions ✅ and remove them from §10.*
