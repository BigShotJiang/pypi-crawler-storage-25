# Puxti — Design Partner Feedback Guide

**Version:** April 2026
**Confidential — shared with design partners only**

Thank you for being part of this early build. This document gives you a structured way to share feedback as you use puxti on your real dbt project. There are no right answers — the goal is to understand what works, what frustrates you, and what would make this tool genuinely load-bearing in your workflow.

You can share feedback however is easiest: fill this in and send it back, drop comments inline, or schedule a call to walk through it together.

---

## 1. Setup

*We want to understand how hard the first hour was — every friction point here is a person who doesn't get to the value.*

- How long did it take from clone to a successful `puxti health` check?
- Did you hit any blockers during setup (Neo4j, credentials, dbt manifest)?
- Is there anything in the setup process you would not want to do regularly?

---

## 2. Scan — Bootstrapping the Knowledge Graph

*The scan is the first time puxti reasons about your data model. We want to know how accurate it felt and whether the workflow fit your context.*

- Did you use interactive or auto mode? Why?
- How accurate were the LLM-inferred definitions for your models? (rough %, or examples of good/bad)
- Did the proposed semantic edges make sense? Were there obvious ones it missed?
- Did the confirmation step feel natural, or was it too much / too little friction?
- After scanning, did `puxti describe` reflect your mental model of your data stack?

---

## 3. Capture — Column Renames

*This is the deterministic propagation path. It should feel almost mechanical.*

- Did you run `capture` on a real rename, or a test case?
- How was the PR quality? Did the diffs look correct?
- Was the entity ID format (`model.project.model.column`) intuitive to construct?
- Any cases where `capture` missed references it should have caught?

---

## 4. Redefine — Semantic Changes

*This is the harder, more valuable path. We expect it to be rougher — honest signal here matters most.*

- Did you try `redefine` on a real semantic change in your stack?
- Did the semantic graph traversal surface the right downstream entities?
- How was the confidence annotation on diffs (`high confidence` / `verify carefully` / `manual review required`)? Did it track with your own judgment?
- Was there a case where puxti annotated something you would have caught automatically? Or missed something it should have flagged?

### 4a. Hop Depth — Where puxti stops generating SQL

*This is a deliberate design decision we want explicit feedback on. When a semantic change propagates through multiple hops of the dependency graph, puxti currently generates SQL only for the first two hops and annotates deeper ones as `PUXTI [manual review required]` rather than generating code. The reasoning: SQL generated three or more hops away from the changed definition has too much inferred context to be trustworthy without human review. But we are not certain this is the right tradeoff.*

- Did you hit the hop depth limit on any of your changes? At what depth?
- When you saw `PUXTI [manual review required]`, what did you do? (reviewed manually, ignored it, wished puxti had tried anyway)
- Would you prefer puxti to attempt SQL generation at any depth and flag uncertainty — even if the output is sometimes wrong — rather than stopping?
- Or would you prefer puxti to be conservative and annotate, so you always know the generated code is trustworthy?
- If puxti generated SQL at deeper hops but required you to explicitly confirm each one, would that feel like the right tradeoff?
- Is there a depth where you would trust generated SQL without careful review? (1 hop? 2? Never for semantic changes?)

*There is no right answer here. The product currently favors safety over coverage — we want to know if that matches how you actually work, or if it gets in your way.*

---

## 5. Correct — Fixing Inaccurate Definitions

*This is the correction loop for when the LLM got something wrong during scan.*

- Did you need to correct any definitions after scanning?
- Was the edge re-assessment useful, or did it feel like overhead?
- Did the correction / real change classification make sense as a distinction?

---

## 6. The Knowledge Graph as a Whole

*We want to know if the Knowledge Graph feels like a real artifact — something that reflects your org's data reality — or just an internal implementation detail.*

- After running scan and a few changes: does `puxti describe` feel like a useful view of your data model?
- Would you show this to a PM or data manager, or does it feel too technical?
- Is there information you expected to see that is missing?
- Is there information present that feels like noise?

---

## 7. Workflow Fit

*Puxti is designed to be in the critical path — not a sidebar tool. We want to understand whether it felt that way.*

- At what point in a real change would you reach for puxti? (before writing dbt, after, when a PR is in review?)
- Did you feel like puxti saved you work, or added work?
- Is there a type of change you make frequently that puxti did not handle?
- Would you run puxti before opening a PR, or after? Does that sequence feel natural?

---

## 8. Known Limitations — Your Priority Order

We know about the following rough edges. Which ones bother you most?

| Limitation | Your priority (high / medium / low / doesn't affect me) |
|---|---|
| No re-scan reminder when dbt project changes | |
| Entity IDs are hard to discover without running `puxti describe` first | |
| `correct` → `redefine` handoff requires manual copy-paste | |
| No web UI — CLI only | |
| No Airflow connector | |

---

## 9. The Semantic Capture Step

*This is the core of the product. We need to understand whether it feels like a natural part of your workflow or like documentation overhead.*

- When you used `capture` or `redefine`, did the `--description` feel like a useful forcing function, or an annoying requirement?
- Did you find yourself writing richer descriptions than you normally would in a commit message or PR description?
- Did the semantic context show up usefully in the PR output?

---

## 10. Source Onboarding — Future Vision

*This feature does not exist yet. We are sharing the concept to get your reaction before building it. There are no wrong answers — we want to know if the vision resonates with how you actually work.*

The idea: a `puxti onboard` command that makes semantic capture the entry point for bringing a new data source into existence.

```
puxti onboard \
  --source "salesforce.opportunities" \
  --from "task.airflow.salesforce_sync.extract_opps" \
  --description "One row per Salesforce opportunity. Represents a potential deal in the pipeline. Amount is USD at close. Closed-won becomes revenue." \
  --repo "acme/data"
```

Puxti would generate a PR containing: `sources.yml` entry, a staging model scaffold, dbt tests at three tiers (structural, schema-aware, and semantic tests that only make sense if you know what the entity means), and the cross-system link in the Knowledge Graph — all from day 0, before the first dbt run.

**Questions:**

- Does the problem resonate? When you last onboarded a new source, where did the semantic knowledge about it end up?
- Is the moment of onboarding actually when you have the most clarity about what a source means — or does understanding come later, after working with the data?
- What part of source onboarding takes the most time today?
- Would you trust puxti-generated tests enough to merge them without heavy review? What would make you trust them more?
- If puxti could generate semantically meaningful tests (e.g. `amount > 0 for closed-won opportunities`) from your description — tests that a generic tool could not produce — would that change how you approach test coverage?
- Is there a version of this that would feel like too much automation? Where would you want to stay in control?

---

## 11. Open Feedback

Anything else — things that surprised you (good or bad), features you expected to exist, moments where the tool felt magical, moments where it felt broken.

---

*Feedback goes directly to the product. There is no triage layer between you and the decisions being made. Thank you for the time.*
