# Puxti — Milestones

Three milestones to a demoable, design-partner-ready product.

---

## M1 — Semantic capture + column rename propagation ✅ Done

**Goal:** prove the end-to-end loop works. One command, one PR.

- Project scaffold (Python, uv, Neo4j via Docker)
- Knowledge Graph data model (Entity, Definition, Edge, SemanticEdge, ChangeEvent)
- dbt connector: reads manifest, extracts entities + lineage, generates column rename diffs
- Semantic capture: user describes the change → LLM enriches → written to Knowledge Graph
- Propagation engine: orchestrates connectors, produces FileDiffs
- GitHub connector: opens a PR with the diffs and semantic context
- CLI: `puxti capture` + `puxti health` + `--dry-run` cost estimate
- No web app — CLI-driven so design partners can see the flow immediately

**Case covered:** Case 1 — structural change (column rename). Deterministic propagation.

---

## M2 — Onboarding + definition redefinition ✅ Done

**Goal:** prove the semantic graph earns its place. The harder, more differentiated case.
M2 has two parts that belong together — without onboarding, redefinition is useless.

### Part A — `puxti scan` (Knowledge Graph bootstrapping)

Seeds the Knowledge Graph from the existing dbt project before any changes are declared.
Without this, the semantic graph is empty and `puxti redefine` finds nothing.

**Two modes (user's choice, explained in README):**

- `--interactive` — walks through each entity one by one. LLM proposes a definition, user
  confirms or edits before it's written. Slower, higher accuracy. Recommended for first
  onboarding.
- `--auto` — LLM generates all definitions in one pass, shows a summary report. User
  reviews the full list and explicitly confirms before anything is written to the graph.
  Faster, but requires careful review.

**What scan does:**
1. Reads dbt manifest → all Entity nodes + structural lineage edges (extends existing dbt connector)
2. For each entity, LLM infers a starter definition from SQL + column name + context
3. LLM proposes initial semantic edges (DERIVED_FROM, etc.) based on definitions + SQL relationships
4. User explicitly confirms each definition before it lands in the semantic graph (both modes)

**Confirmation is mandatory** — nothing is written to the semantic graph as canonical without
explicit user approval. Consistent with the read-first, write-on-confirm principle.

### Part B — `puxti redefine` (Case 3 — semantic change)

A user redefines what an entity *means* — not a rename, a conceptual shift (e.g. "gross_revenue
now excludes refunds"). The structural graph hasn't changed. But downstream entities that depend
on the *meaning* are now wrong — and only the semantic graph can surface them.

- New CLI command: `puxti redefine --entity <id> --description "<new meaning>" --repo <owner/repo>`
- Semantic graph traversal: `get_semantic_dependents_with_depth()` drives downstream impact analysis
- Structural fallback: when the semantic graph has no dependents, falls back to LINEAGE-based dependents
- Upstream passthrough: walks `get_structural_ancestors()` to find every model in the upstream chain
  that needs to expose the new attribute — generates SQL diffs to thread it through (entity → stg → mart)
- Depth-aware SQL generation:
  - Hop 1 — LLM generates SQL diff, annotated `PUXTI [high confidence]`
  - Hop 2 — LLM generates SQL diff, annotated `PUXTI [verify carefully]`
  - Hop 3+ — annotation only, `PUXTI [manual review required]`
- Single deployable PR: upstream passthrough diffs first, then downstream semantic diffs — with ordering
  notes so the reviewer knows which files must be merged before others
- `--dry-run` flag: estimates token/cost without calling LLM or opening a PR

**Case covered:** Case 3 — semantic change. Non-deterministic propagation with LLM reasoning.

**Why this before M3:** this is where the two-layer Knowledge Graph proves its value.
Without M2, puxti is a smarter find-and-replace. With M2, it's a reasoning layer.

---

## M3 — Web app + Case 2 🔲 Future

**Goal:** make the product accessible to non-engineers (PMs, managers) and add the
remaining change case.

- Web app: entity graph visualization + structured change workflow
- Case 2: attribute surfacing — a new attribute emerges from existing data
  (e.g. a field that was always there now becomes a first-class business concept)
- Multi-connector support: Airflow connector alongside dbt

**Case covered:** Case 2 — attribute surfacing. Hybrid (structural detection + semantic capture).

---

## Change Cases Reference

| Case | Name | Example | Propagation |
|------|------|---------|-------------|
| 1 | Structural change | `order_date` → `recorded_date` column rename | Deterministic — find & replace with semantic context |
| 2 | Attribute surfacing | A field becomes a first-class business concept | Hybrid — structural detection + semantic reasoning |
| 3 | Definition redefinition | Revenue now excludes refunds | Non-deterministic — pure semantic reasoning |
