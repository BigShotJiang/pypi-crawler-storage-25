# Puxti — Product Specification

**Version:** v0.3 Draft
**Date:** April 2026
**Status:** Discovery complete — 9 interviews, 3 design partners confirmed, building
**Confidential**

> Puxtiri (Aymara) — water running down. When something changes upstream, it flows naturally through everything below it.

---

## Table of Contents

1. [The Problem](#1-the-problem)
2. [Product Vision](#2-product-vision)
3. [Target Users](#3-target-users)
4. [Product — Phase 1](#4-product--phase-1-wedge)
5. [Roadmap](#5-roadmap)
6. [Key Risks & Open Questions](#6-key-risks--open-questions)
7. [Success Metrics](#7-success-metrics--phase-1)

---

## 1. The Problem

### 1.1 The Surface Problem — Cascading Changes

Data engineers spend a disproportionate amount of time propagating changes across their stack. A single column rename triggers updates across dbt models, Airflow DAGs, Superset dashboards, documentation, and release notes — each with its own syntax, format, and failure mode. Miss one, and something breaks silently in production.

> **Interview signal — Lead of Engineering, early-stage startup:** schema changes consumed up to 30% of his time. A single `date → recorded_date` rename required touching dozens of interconnected systems manually.

Current tools don't solve this because they are code generators, not system orchestrators. GitHub Copilot can write a dbt model. It cannot say: *"this schema change means updating these 3 models, regenerating this dashboard, and here is the release note draft."*

---

### 1.2 The Deeper Problem — Organizational Semantics

Beneath the mechanical propagation problem lies a harder one: the meaning of data is never fully explicit. Companies make trade-offs when modeling reality into entities, attributes, relationships, and rules. These trade-offs are economic and human — there is never enough time to make them perfect.

The result: implicit knowledge lives in people's heads, Slack threads, Jira tickets, and Confluence pages that are stale within weeks. Two types of change expose this most painfully:

| | Type 1 — Structural | Type 2 — Semantic |
|---|---|---|
| **Example** | `date → recorded_date` column rename | Opportunity → line item per opportunity (cardinality shift) |
| **Nature** | Same data, new structure | New meaning, new model |
| **Includes** | Column renames, table restructures, schema migrations | Business logic redefinitions, cardinality shifts, KPI changes |
| **Approach** | Deterministic propagation — a tool can handle this confidently given enough context | Requires the tool to understand organizational reality — what this entity means, not just its structure |

> **Interview signal — Analytics Engineer, high-growth SaaS company:** a Salesforce migration restructured the opportunity entity to order line items per opportunity — a breaking change in cardinality, cross-sell, and upsell logic. *"Changes in business logic is more intense and that breaks the modelling."*

---

### 1.3 Why Nothing Has Solved This

Data catalogs (Atlan, Datahub, Alation) document what exists. They are read-only mirrors of reality. When you need to change something, you close the catalog tab and go back to suffering manually. Documentation that does not reduce the cost of change has no real value — which is why catalogs go stale, nobody trusts them, and the cycle repeats.

**The fundamental insight:** schema changes are the symptom. The real problem is organizational knowledge — implicit definitions that were never made explicit, business semantics that live nowhere reliable, and a stack that has no way to reason about what things mean when they change.

---

## 2. Product Vision

### 2.1 What Puxti Is

> Puxti lowers the cost of evolving your data model by making the implicit explicit at the moment of change — capturing organizational reality as a byproduct of doing the actual work, not as extra documentation effort.

Puxti is not a schema change tool. It is not a data catalog. It is an **organizational knowledge layer for data teams** that is load-bearing — meaning it sits in the critical path of making changes, not alongside them.

Because it is in the critical path, semantic context gets captured as a byproduct of the work. Every change makes the system smarter about your specific organizational reality. It compounds.

### 2.2 Scope Boundary — The Ingestion Layer

Puxti's upstream boundary is the **ingestion layer** — the point where backend or source data enters the data stack. Everything downstream of that point (transformation, orchestration, BI, documentation) is puxti's domain. Everything upstream (backend databases, application ORMs, event streams, APIs) is not.

**What this means in practice:**
- Puxti detects source schema changes (e.g. a new column appearing in a warehouse table) and treats them as signals to capture and propagate — but does not own the backend workflow that caused them.
- Puxti does not open PRs in backend repositories or interact with backend CI pipelines.
- When a source schema change is detected, puxti surfaces it as an upstream event and prompts semantic capture — "this looks like it came from the backend, what does it mean for the data stack?"

**Why this boundary matters:**
The backend surface is too heterogeneous to own in v1 (relational DBs, event streams, APIs, ORMs — each with different tooling, workflows, and team cultures). The trust model is also different: data engineers opening PRs in backend repos requires organizational trust that puxti hasn't earned yet.

**Future direction:** making downstream data impact visible *before* a backend change ships (PM estimation problem) is a natural phase 2 expansion — but it requires sitting in backend CI pipelines and is a different buyer conversation.

---

### 2.3 The Key Differentiator

| Every other tool assumes | Puxti assumes |
|---|---|
| Definitions already exist | Definitions are always incomplete |
| They just need to be documented or propagated | Always evolving |
| → Catalogs, linters, code generators | Trade-offs are economic and human — builds for that reality instead of fighting it |

---

### 2.4 The Workflow Shift

**Today's broken flow:**
1. Business person writes requirement in Jira
2. Data engineer interprets it
3. Implements something
4. Meaning is lost in the artifact
5. Definitions change next quarter — no thread connecting old to new

**Puxti's flow:**
1. The definition itself is the input — *"Opportunity now means a collection of line items"*
2. The system reasons about what needs to change technically
3. Jira becomes optional — or just the output (PR, release note)
4. Every change builds the knowledge layer for the next one

---

## 3. Target Users

### 3.1 Primary — Analytics Engineers
Sit exactly at the boundary between business meaning and technical implementation. Feel semantic pain most acutely. Already responsible for translating business logic into dbt models. **Score: 8/10 problem urgency** (confirmed by primary design partner, Analytics Engineer at SaaS company).

### 3.2 Secondary — Data Engineers (IC)
Feel the operational cascading change pain directly. Less exposed to the semantic layer but deeply affected by the downstream consequences of undefined semantics. **Score: 6/10** in stable products, up to 30% time cost in early-stage.

### 3.3 Champion — Head of Data / Data Engineering Manager
Owns the organizational knowledge problem at the strategic level. Feels quarterly definition drift. Would champion Puxti internally and hold the budget. Key to enterprise sales cycle.

### 3.4 Adjacent — Product Managers / Business Analysts
The other side of the definition gap. Currently communicates data requirements through Jira — a format that destroys semantic precision at every handoff. Not the primary buyer but a key stakeholder in the workflow shift.

### 3.5 Buyer Mindset — Value-Oriented vs. Delivery-Oriented

Not all data teams are equal buyers. Two distinct mindsets determine how they perceive puxti's value and how easy the sale is.

**Value-oriented teams** measure themselves by economic impact and business partnership. They work closely with commercial, product, and finance stakeholders. For them, time reclaimed from schema change maintenance means more capacity to build new value with the business — a strategic argument. These teams have higher willingness to pay and tell a better story to the next customer. **Prioritize these as design partners.**

**Delivery-oriented teams** measure themselves by technical output — dashboards delivered, ad-hoc requests completed, pipelines maintained. For them, puxti is a cost-saving tool that increases throughput. The ROI argument still works but it is tactical, harder to justify internally, and produces a weaker reference story.

**How to identify them in interviews:** listen for how they describe their team's purpose. "We help the commercial team understand retention" → value-oriented. "We maintain the pipelines and deliver dashboards" → delivery-oriented. The framing appears before you ask about pricing.

Our primary Analytics Engineer design partner is a strong example of the value-oriented profile — embedded in business logic at a high-growth SaaS company.

### Company Profile (Initial Target)
Series A–C startups and SMEs with 10–50 person data teams. Modern stack (dbt + Airflow/Dagster + cloud warehouse + BI tool). Active product development = frequent definition changes. Enough complexity that cascading changes are painful but not so much process that adoption is slow.

**Preferred verticals:** SaaS, fintech (non-regulated), e-commerce, marketplaces, developer tools — sectors where data teams move fast and definition changes are frequent.

**Avoid early:** insurance, telco, banking, healthcare, and other hyperregulated industries. Vendor qualification processes in these sectors are long, requirements lists are extensive, and security reviews alone can take months. This is not a product problem — it is a structural go-to-market constraint. Experience at Orange and in the insurance sector confirms this pattern directly.

**Why regulated industries feel less pain (and why that's structural, not accidental)**
Definition stability in regulated industries is enforced by design. In insurance, pricing models require regulatory approval — you cannot change how you underwrite household risk without sign-off, because an unconventional estimation can trigger a capital requirement increase. In banking, GAAP and IFRS standardize definitions legally. The result: data models in these sectors are stable not because the teams are disciplined, but because the regulator demands it.

This explains the contradictory interview signal: a data engineer in insurance describing semantic changes as "not hard" is not underestimating the problem — they genuinely have less of it.

**The sweet spot: SaaS companies actively evolving their core product model**
Some definitions are standard across all SaaS companies — sales pipelines, MRR, churn follow well-established patterns. The pain concentrates where the core product model is still being discovered: new features introduce new entities, new go-to-market motions redefine existing ones, and the data team is always catching up to the product team. This is where definitions change fastest, where implicit knowledge accumulates fastest, and where puxti's value is highest.

**A useful interview filter:** "how often do your core business definitions change?" — the answer immediately signals whether the environment has enough churn to feel the pain acutely.

### Out of Scope — Enterprise / Large Corporates
Large enterprise accounts (e.g. financial services, asset management, regulated industries) are explicitly out of scope for design partners and early sales. Procurement cycles of 1–2 years, security reviews, and compliance requirements make them the wrong first customer regardless of problem fit.

Large corp contacts with relevant domain expertise are valuable as **advisors** — they provide problem signal, domain knowledge, and future reference potential without the sales cycle cost. Treat them accordingly: seek their input, not their signature.

Regulated industries and large enterprise are a natural expansion once the product is mature and the business is profitable — at that point, long sales cycles become manageable rather than existential. The sequencing is: prove it works for fast-moving SaaS → build revenue base → enterprise becomes an option, not a dependency.

---

## 4. Product — Phase 1 (Wedge)

> **Phase 1 goal:** make schema change propagation feel magical. Prove the orchestration layer works across the full stack. Capture semantic context as a byproduct. Land 3–5 paying design partners.

### 4.1 Core Feature — Schema Change Propagation

The user initiates or detects a schema change in their data warehouse. Puxti:

1. Detects the change (or accepts it as explicit input)
2. **Asks the user: what does this change mean?** ← semantic capture step
3. Reasons about downstream impact across the connected stack
4. Generates: dbt model updates, Airflow/Dagster DAG changes, dashboard config changes, draft release notes
5. Delivers as a reviewable PR — human stays in control

The semantic capture step (step 2) is what differentiates this from a simple propagation script. It is the moment where the implicit becomes explicit — and it is lightweight enough that users will do it because the payoff (automated downstream updates) is immediate.

---

### 4.2 Supported Stack (v1)

The connector layer is stack-agnostic from day one — each tool is a plugin implementing
a standard interface. v1 ships dbt and Airflow as the first two connectors, with the
architecture ready for everything else.

| Layer | Tools (v1 scope) | Priority |
|---|---|---|
| Warehouse | BigQuery, Snowflake | P0 — read only (source of truth) |
| Transformation | dbt Core, dbt Cloud | P0 — first write connector |
| Orchestration | Airflow | P0 — second write connector |
| Version control | GitHub | P0 — PR output |
| Warehouse | Databricks | P1 |
| Orchestration | Dagster | P1 |
| BI / Dashboards | Looker, Superset | P2 |
| Version control | GitLab | P1 |
| Documentation | Confluence, Notion, Markdown | P2 |

**Rationale for dbt + Airflow first:** our primary design partner is dbt-centric.
Airflow is the most common orchestration layer across the interview sample. Together they
cover the transformation → orchestration propagation path, which is the highest-frequency
pain point in the data.

---

### 4.3 Decisions Made

**Entry point: web app.**
Entity graph visualization with a structured change workflow. Users see entities and their
relationships, describe what a change means, see affected relations across the stack, and
review what changes per repo before anything is written. First buyer-profile interviewee
An Engineering Manager at a crypto exchange described this unprompted. CLI is a secondary interface.

**Chained semantic dependencies: semantic graph as first-class layer.**
A key design partner's concern — how does the tool handle lineage across complex multi-level business
aggregations like `sales → revenue → marketing cost ratio` — is answered by a semantic
graph that sits above the structural lineage graph. The structural graph (populated by
connectors) tracks which entity depends on which. The semantic graph (populated by semantic
capture) tracks what each entity *means* and how concepts relate across the full stack.
A change to *sales* that makes *revenue* semantically wrong — even if nothing in the dbt
graph technically broke — is traceable through the semantic graph. See architecture.md §3.4.

### 4.4 Cross-System Semantic Linking — Phase 2 North Star

The dbt-only phase proves the core loop. The moment that makes puxti irreplaceable is cross-system semantic linking: making explicit the relationships that exist only in engineers' heads.

**The mental model every data engineer carries but never writes down:**

> "The `sales` data that feeds `stg_orders` in dbt comes from the `extract_sales` task in the `sales_pipeline` Airflow DAG. When that DAG changes how it extracts sales, it means something different arrives at this dbt source."

No tool captures this today. Catalogs document what exists within a system. Lineage tools trace structural dependencies within a system. The cross-system relationship — "this DAG output *is* this dbt source, and here is what that relationship means" — lives only in people's heads, Slack threads, and onboarding documents that go stale within weeks.

**What puxti does with it:**

A new command — `puxti link` — lets engineers declare this relationship explicitly:

```
puxti link \
  --from task.airflow.sales_pipeline.extract_sales \
  --to source.jaffle_shop.raw_sales \
  --description "extract_sales produces the raw sales events that raw_sales ingests — one row per transaction, pre-deduplication"
```

This creates a semantic edge between an Airflow task entity and a dbt source entity in the Knowledge Graph. Once that edge exists:

- A change to the Airflow DAG surfaces downstream dbt impact with full semantic context — not just "something upstream changed" but "the definition of what this source receives has changed, here are the affected models"
- A dbt model redefinition can trace back to the orchestration layer that produces its source data
- The compounding effect of the semantic graph extends across system boundaries for the first time

**Why this is the wow moment:**

Every other data tool operates within system boundaries. Puxti's Knowledge Graph is the first place in an organization's data stack where cross-system semantic relationships are first-class. An engineer who sees their own mental model — the one they carry in their head about how Airflow feeds dbt — reflected back in a graph, and then sees a DAG change automatically inform downstream model updates with correct semantic context, understands immediately what puxti is.

This is also the compounding value made visible: each declared cross-system link makes the next change cheaper to reason about across the full stack, not just within one tool.

**Sequencing rationale:**

Phase 1 (dbt-only) builds the habit: capture change meaning, get a PR. Design partners establish that the core loop works and feels natural. Phase 2 extends the graph across system boundaries. The `puxti link` command is new — it does not exist today — and it is arguably more important than the Airflow connector itself, because without it, cross-system propagation has no semantic path to walk.

---

### 4.6 Source Onboarding — Phase 3 North Star

Cross-system linking (section 4.4) proves the graph works across boundaries. Source onboarding goes one step further: puxti becomes the entry point for bringing a new data source into existence — capturing meaning at the moment it is most available and using it to generate every downstream artifact in one go.

**The problem with onboarding today:**

The engineer who wires up a new source is the person with the richest understanding of what it means — what the entity represents, what the fields are, what valid data looks like, what business concept it feeds. That knowledge is at peak availability at the moment of onboarding. Today that moment passes and the meaning evaporates into a Jira ticket or an onboarding doc that goes stale within weeks. Everything downstream — staging models, tests, documentation, semantic edges — is built without that original context.

**The puxti onboarding workflow:**

A new command — `puxti onboard` — makes semantic capture the entry point:

```
puxti onboard \
  --source "salesforce.opportunities" \
  --from "task.airflow.salesforce_sync.extract_opps" \
  --description "One row per Salesforce opportunity. Represents a potential deal in the pipeline. Amount is in USD at time of close. Closed-won opportunities become revenue." \
  --repo "acme/data"
```

Puxti generates and opens a PR containing:

1. `sources.yml` entry with the semantic description
2. `stg_<source>.sql` scaffold with column selection and type casting
3. dbt tests — three tiers, each requiring progressively more semantic context:

| Tier | Example | How generated |
|------|---------|---------------|
| Structural | `unique`, `not_null` on PKs | Always — derivable from schema alone |
| Schema-aware | `amount > 0`, timestamps in valid range | Column names and types + LLM |
| **Semantic** | `amount never negative for closed-won`, valid stage transitions | **Requires knowing what the entity means** — only puxti can generate these |

4. The cross-system link established in the Knowledge Graph from day 0 — the ingestion artifact and the dbt source are connected semantically before the first dbt run

**Why tier 3 tests are the moat:**

Generic code generators and AI coding assistants can produce tier 1 and sometimes tier 2 tests. Tier 3 tests — the ones that encode what *valid data for this concept in this org* looks like — require semantic context. A tool that knows "opportunity" means "potential deal, closed-won becomes revenue" can generate `assert amount > 0 where stage = 'Closed Won'`. A tool that only sees the schema cannot.

**Why onboarding is the right moment:**

Semantic capture during onboarding costs near zero — the engineer is already in definition mode, already thinking about what the data represents. Retrofitting meaning onto an existing source requires archaeology. Capturing it at source creation requires a single `--description` flag.

Once the meaning is in the Knowledge Graph at day 0, every future change to that source is informed by its original intent. The compounding effect begins from the first commit, not after months of accumulated captures.

**Sequencing rationale:**

Phase 1 (dbt-only, changes) proves the capture habit. Phase 2 (cross-system linking) proves the graph works across boundaries. Phase 3 (source onboarding) makes puxti load-bearing from the start of a source's life — not just when something changes. At that point, bypassing puxti means losing the semantic foundation that makes everything else work. That is the definition of being in the critical path.

---

### 4.7 Open Questions (Needs More Signal)

- How does Puxti handle semantic ambiguity — when old and new definitions overlap?

---

## 5. Roadmap

| Phase | Timeframe | Goals |
|---|---|---|
| **Discovery** | Now → Month 2 | Complete 10–15 interviews across data engineers, analytics engineers, managers, PMs. Validate Type 1 and Type 2 pain. Identify 3–5 design partner candidates. Define v1 technical architecture. |
| **Prototype** | Month 2–3 | Build web app with entity graph + change workflow. Schema change propagation for dbt against BigQuery/Snowflake. User inputs a change → system generates dbt updates as PR. Semantic capture step from day one. |
| **Design Partners** | Month 3–5 | 3–5 design partners using the tool weekly in dbt context. Instrument everything. Focus on: does the semantic capture step get adopted naturally? Does the Knowledge Graph feel like a true reflection of their data model? |
| **Cross-System Linking** | Month 5–7 | Introduce `puxti link` — cross-system semantic edge declaration. Add Airflow connector. First propagation path that crosses system boundaries (DAG change → dbt model update with semantic context). This is the wow moment: the Knowledge Graph becomes the first place in the org where cross-system data relationships are explicit. |
| **Source Onboarding** | Month 7–10 | Introduce `puxti onboard` — semantic capture at the moment a new source enters the stack. Generates `sources.yml`, staging model scaffold, and three tiers of dbt tests (including semantic tests derivable only from the declared meaning). Establishes the cross-system link at day 0. Puxti becomes load-bearing from source creation, not just at change time. |
| **Launch** | Month 10–12 | Validation checkpoint: are people using it without being pushed? Concrete time savings documented across changes and onboarding. If yes: expand stack coverage + start charging. If no: assess pivot options. |

---

## 6. Key Risks & Open Questions

### 6.1 Technical Risks

**Semantic understanding at scale:** chained semantic dependencies (e.g. `sales → revenue → marketing cost ratio`) are handled by a two-layer Knowledge Graph — structural lineage populated by connectors, and a semantic graph populated by semantic capture. The semantic graph is first-class, not an annotation. This is the core technical moat and the hardest thing to build correctly.

**Read + write access requirement:** Phase 1 requires both read access (to understand the stack) and write access (to generate PRs). Write access is a significant trust barrier, especially in enterprise. PR-as-output model mitigates this but needs validation.

### 6.2 Go-to-Market Risks

**Enterprise sales cycle:** the deeper the integration, the longer the trust-building required. Starting with a narrow, safe workflow (schema propagation as PR) is the right mitigation. Enterprise accounts are explicitly out of scope for v1 design partners — procurement and compliance cycles alone can run 1–2 years. Large corp contacts should be cultivated as advisors, not pursued as customers.

**Agent / managed capability model (filed, not decided):** A VP of Data at a major media company suggested puxti could be offered as an agent in the way McKinsey deploys consultants alongside AI tools — software and expert guidance packaged together as an engageable capability rather than a self-serve tool. This solves the enterprise procurement problem: consulting spend is a different budget line with a different approval path than SaaS.

Two things make this worth keeping on file: (1) it matches the early reality — in the first engagements, you are the agent; running managed onboardings while the product matures is a natural path to revenue and learning simultaneously. (2) It gives large enterprises like UMG a way in when SaaS procurement is blocked by model approval, legal review, or GCP standardization.

The tension: a services model scales with people, not code. Optimizing for it early risks building a consultancy instead of a product. The right sequence: prove the self-serve loop with design partners first. If large enterprise accounts cannot buy through normal channels, the agent model is the entry wedge — not the core business.

**Adoption — behavior change is hard:** the implicit-to-explicit shift requires people to be more precise about definitions. This has always been a personal drive problem, not a tooling problem. Puxti needs to make being explicit the path of least resistance — not a cultural achievement.

### 6.3 Competitive Risks

**dbt adds native propagation:** dbt is the natural place for this to live eventually. Mitigation: Puxti's value is cross-stack (not just dbt) and semantic (not just structural).

**AI coding assistants get smarter:** as Copilot and Cursor get better at understanding codebases, they may partially solve the Type 1 problem. Mitigation: Type 2 (semantic) requires organizational context that general coding assistants cannot have.

---

## 7. Success Metrics — Phase 1

| Metric | Target | Why it matters |
|---|---|---|
| Interviews completed | 10–15 | Sufficient signal before building |
| Design partners recruited | 3–5 | Real usage, not just interest |
| Weekly active usage (no pushing) | >80% of partners | True product-market fit signal |
| Time saved per schema change | >50% reduction | Quantified value prop for sales |
| Semantic capture step adoption | >70% of changes | Proves the knowledge layer works |
| PR acceptance rate | >60% | Tool accuracy is high enough to trust |

---

*puxti.com · v0.3 Draft · April 2026 · Confidential*
