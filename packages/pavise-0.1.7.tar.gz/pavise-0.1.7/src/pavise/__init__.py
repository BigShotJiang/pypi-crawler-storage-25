"""Pavise: DataFrame validation library using Python Protocol for structural subtyping."""

__version__ = "0.1.7"
__all__ = []
