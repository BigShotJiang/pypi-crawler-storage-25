"""
Générateurs de grammaire pour le parser DSN.

Génère les fichiers de grammaire PEST (Rust) et Lark (Python).
"""

from typing import Any, Dict


def convert_regex_to_pest(regex: str, min_len: Any, max_len: Any) -> str:
    """Convertit une regex Excel en règle PEST."""
    if not regex or regex == "-":
        # Pas de regex, utiliser les longueurs
        if min_len and max_len:
            return f"ANY{{{min_len},{max_len}}}"
        elif min_len:
            return f"ANY{{{min_len},}}"
        elif max_len:
            return f"ANY{{,{max_len}}}"
        else:
            return "ANY*"

    # Convertit les patterns communs
    import re as re_module

    regex = regex.strip()

    # [1-9][0-9]* -> ASCII_DIGIT{1,}
    if re_module.match(r"^\[1-9\]\[0-9\]\*$", regex):
        return "ASCII_DIGIT{1,}"

    # [0-9]*[1-9][0-9]* -> au moins un chiffre non-zéro
    if re_module.match(r"^\[0-9\]\*\[1-9\]\[0-9\]\*$", regex):
        return "ASCII_DIGIT{1,}"

    # Chiffres purs
    if regex == "^[0-9]+$":
        if min_len and max_len and min_len == max_len:
            return f"ASCII_DIGIT{{{min_len}}}"
        elif min_len and max_len:
            return f"ASCII_DIGIT{{{min_len},{max_len}}}"
        else:
            return "ASCII_DIGIT+"

    # Alphanumérique
    if regex == "^[A-Za-z0-9]+$":
        if min_len and max_len:
            return f"ASCII_ALPHANUMERIC{{{min_len},{max_len}}}"
        else:
            return "ASCII_ALPHANUMERIC+"

    # Pour les regex complexes, on crée un pattern ANY pour la grammaire
    # La validation sera faite en Python
    return "value"


def generate_pest_grammar(types_data: Dict, blocks_data: Dict, rubriques_data: Dict) -> str:
    """
    Génère la grammaire PEST pour le format ligne par ligne.
    Format: SXX.GXX.XX.XXX,VALEUR
    """
    lines = [
        "// Grammaire DSN (Données Sociales Nominatives)",
        "// Générée automatiquement depuis dsn-datatypes-CT2026.xlsx",
        "// Format: SXX.GXX.XX.XXX,VALEUR",
        "",
        "// Règles de base",
        'WS = _{ " " | "\\t" }',
        'NEWLINE = _{ "\\n" | "\\r\\n" | "\\r" }',
        "",
        "// Ligne DSN complète (block.rubrique,valeur)",
        'dsn_line = @{ block_id ~ "." ~ rubrique_id ~ "," ~ value }',
        'block_id = @{ "S" ~ ASCII_DIGIT{2} ~ ".G" ~ ASCII_DIGIT{2} ~ "." ~ ASCII_DIGIT{2} }',
        "rubrique_id = @{ ASCII_DIGIT{3} }",
        "value = @{ (!NEWLINE ~ ANY)* }",
        "",
        "// Structure DSN - liste de lignes",
        "dsn_file = { SOI ~ (dsn_line ~ NEWLINE)* ~ dsn_line? ~ EOI }",
        "",
    ]

    return "\n".join(lines)


def convert_regex_to_lark(regex: str, min_len: Any, max_len: Any) -> str:
    """
    Convertit une regex Excel en pattern Lark.
    """
    if not regex or regex == "-":
        # Pas de regex, utiliser les longueurs
        if min_len and max_len:
            return f"/[^\\n]{{{min_len},{max_len}}}/"
        elif min_len:
            return f"/[^\\n]{{{min_len},}}$/"
        elif max_len:
            return f"/[^\\n]{{0,{max_len}}}/"
        else:
            return "/[^\\n]+/"

    # Convertit les patterns communs
    import re as re_module

    regex = regex.strip()

    # [1-9][0-9]* -> /[1-9][0-9]*/
    if re_module.match(r"^\[1-9\]\[0-9\]\*$", regex):
        return "/[1-9][0-9]*/"

    # [0-9]*[1-9][0-9]* -> au moins un chiffre non-zéro
    if re_module.match(r"^\[0-9\]\*\[1-9\]\[0-9\]\*$", regex):
        return "/[0-9]*[1-9][0-9]*/"

    # Chiffres purs
    if regex == "^[0-9]+$":
        if min_len and max_len and min_len == max_len:
            return f"/[0-9]{{{min_len}}}/"
        elif min_len and max_len:
            return f"/[0-9]{{{min_len},{max_len}}}/"
        else:
            return "/[0-9]+/"

    # Alphanumérique
    if regex == "^[A-Za-z0-9]+$":
        if min_len and max_len:
            return f"/[A-Za-z0-9]{{{min_len},{max_len}}}/"
        else:
            return "/[A-Za-z0-9]+/"

    # Pour les regex complexes, on les utilise telles quelles
    # en retirant les ancres ^ et $ si présentes
    clean_regex = regex.strip("^$")
    return f"/{clean_regex}/"


def generate_lark_grammar(types_data: Dict, blocks_data: Dict, rubriques_data: Dict) -> str:
    """
    Génère la grammaire Lark pour le format ligne par ligne.
    Format: SXX.GXX.XX.XXX,VALEUR
    """
    lines = [
        "// Grammaire DSN (Données Sociales Nominatives) - Format Lark",
        "// Générée automatiquement depuis dsn-datatypes-CT2026.xlsx",
        "// Format: SXX.GXX.XX.XXX,VALEUR ou SXX.GXX.XX.XXX,'VALEUR'",
        "// Compatible avec https://github.com/lark-parser/lark",
        "",
        "// On ignore les espaces (pas utilisés dans ce format)",
        "%import common.WS",
        "%ignore WS",
        "",
        "// Structure DSN - liste de lignes",
        "dsn_file: dsn_line+",
        "",
        "// Ligne DSN: SXX.GXX.XX.XXX,VALEUR avec valeur optionnellement entre guillemets",
        'dsn_line: block_id "." rubrique_id "," dsn_value NEWLINE?',
        'block_id: "S" DIGIT DIGIT ".G" DIGIT DIGIT "." DIGIT DIGIT',
        "rubrique_id: DIGIT DIGIT DIGIT",
        "dsn_value: QUOTED_STRING | UNQUOTED_STRING",
        "QUOTED_STRING: /'[^'\\n]*'/",
        "UNQUOTED_STRING: /[^\\r\\n,]+/",
        "DIGIT: /[0-9]/",
        "NEWLINE: /\\r?\\n/",
        "",
    ]

    return "\n".join(lines)
