# Changelog

Toutes les modifications notables de ce projet seront documentées dans ce fichier.

Le format est basé sur [Keep a Changelog](https://keepachangelog.com/fr/1.0.0/),
et ce projet adhère à [Semantic Versioning](https://semver.org/lang/fr/).

## [0.1.1] - 2024-03-29

### Correction
- #1 & #3 - Non prise en compte de certains blocs répétés

### Ajouts
- #2 - Ruff et pytest

## [0.1.0] - 2024-03-15

### Ajout
- Première version publique
- Support de 59 blocs DSN
- Parseur basé sur Lark
- Types Python fortement typés avec dataclasses
- Validation des données
- Export JSON natif
- Support des enums avec descriptions lisibles
- CLI `dsn-tools` pour parser en ligne de commande
