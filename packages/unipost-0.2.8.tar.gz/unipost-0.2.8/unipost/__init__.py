"""Official UniPost API client for Python."""

from unipost.client import UniPost
from unipost.async_client import AsyncUniPost
from unipost.errors import (
    UniPostError,
    AuthError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    PlatformError,
    QuotaError,
)
from unipost.webhook import verify_webhook_signature
from unipost.types import (
    Workspace,
    SocialAccount,
    Profile,
    Post,
    PlatformResult,
    AccountHealth,
    ConnectSession,
    OAuthConnectResponse,
    ManagedUser,
    PostAnalytics,
    PostAnalyticsItem,
    AnalyticsRollup,
    ApiKey,
    CreatedApiKey,
    PlatformCredential,
    WebhookSubscription,
    DeliveryJob,
    Plan,
    Usage,
    MediaUploadResponse,
)
from unipost.resources.profiles import Profiles
from unipost.resources.api_keys import ApiKeys

__version__ = "0.2.8"
__all__ = [
    "UniPost",
    "AsyncUniPost",
    "UniPostError",
    "AuthError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "PlatformError",
    "QuotaError",
    "verify_webhook_signature",
    "Workspace",
    "SocialAccount",
    "Profile",
    "Profiles",
    "Post",
    "PlatformResult",
    "AccountHealth",
    "ConnectSession",
    "OAuthConnectResponse",
    "ManagedUser",
    "PostAnalytics",
    "PostAnalyticsItem",
    "AnalyticsRollup",
    "ApiKey",
    "ApiKeys",
    "CreatedApiKey",
    "PlatformCredential",
    "WebhookSubscription",
    "DeliveryJob",
    "Plan",
    "Usage",
    "MediaUploadResponse",
]
