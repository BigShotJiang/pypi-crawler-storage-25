"""Neural network model readers."""
