from modulitiz_nano.ModuloStringhe import ModuloStringhe
from modulitiz_rpi.oneWire.temperature.OneWireTempModule import OneWireTempModule


class OneWireDS18B20Module(OneWireTempModule):
	
	def __init__(self,addressOrPattern:str|None,*args,**kwargs):
		if ModuloStringhe.isEmpty(addressOrPattern):
			addressOrPattern="28*"
		super().__init__(addressOrPattern,*args,**kwargs)
