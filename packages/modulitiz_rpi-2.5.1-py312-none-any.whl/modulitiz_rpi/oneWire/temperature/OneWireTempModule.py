import re
from typing import override

from modulitiz_nano.ModuloStringhe import ModuloStringhe
from modulitiz_nano.exceptions.ExceptionRuntime import ExceptionRuntime
from modulitiz_nano.sistema.ModuloSystem import ModuloSystem
from modulitiz_rpi.oneWire.AbstractOneWireModule import AbstractOneWireModule


class OneWireTempModule(AbstractOneWireModule):
	
	def __init__(self,*args,**kwargs):
		super().__init__(*args,**kwargs)
	
	@override
	def _populateCustom(self):
		output=ModuloSystem.systemCallReturnOutput('sudo modprobe w1-therm',None).strip()
		if not ModuloStringhe.isEmpty(output):
			raise ExceptionRuntime(f"Cannot enable 1Wire temperature channel:\n{output}")
	
	@override
	def read(self)->dict[str,float|None]:
		results=super().read()
		resultsNew:dict[str,float|None]={}
		for idDevice,valueStr in results.items():
			resultsNew[idDevice]=self.__toTemp(valueStr)
		return resultsNew
	
	@staticmethod
	def __toTemp(valueStr:str)-> float|None:
		regexResult=re.search(r"""t=([\d.]+)""",valueStr)
		if regexResult is None:
			return None
		return float(regexResult.group(1))/1000.0
