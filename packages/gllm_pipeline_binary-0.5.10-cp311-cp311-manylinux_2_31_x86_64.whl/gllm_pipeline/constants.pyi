from enum import StrEnum

class ConfigKeys:
    """Keys used in pipeline configuration dictionaries."""
    DEBUG_STATE: str
    THREAD_ID: str

class StreamMode(StrEnum):
    """Langgraph stream modes for pipeline execution."""
    DEBUG: str
    VALUES: str
