from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from gllm_pipeline.types import Group as Group, Val as Val
from typing import TypeAlias

PipelineSteps: TypeAlias
PipelineState: TypeAlias
InputMapSpec: TypeAlias
