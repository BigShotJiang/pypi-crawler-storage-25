from gllm_pipeline.alias import PipelineState as PipelineState
from typing import Any

DOT_NOTATION: str

def resolve_dotted_path(obj: Any, path: str) -> Any:
    '''Resolve a dotted path against an object or dict.

    Args:
        obj (Any): The object to resolve the path against.
        path (str): The dotted path (e.g., "a.b.c").

    Returns:
        Any: The resolved value, or `_MISSING` if not found.

    Raises:
        ValueError: If the path contains empty segments.
    '''
def shallow_dump(state: PipelineState) -> dict[str, Any]:
    """Convert Pydantic model to dict while preserving nested Pydantic objects.

    Args:
        state (PipelineState): The state to convert.

    Returns:
        dict[str, Any]: The state as a dictionary with preserved nested Pydantic objects.
    """
