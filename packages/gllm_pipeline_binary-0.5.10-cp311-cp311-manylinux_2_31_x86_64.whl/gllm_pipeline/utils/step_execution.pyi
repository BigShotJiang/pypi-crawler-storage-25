from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from langgraph.runtime import Runtime
from typing import Any, TypeGuard

def is_step_list(branch: object) -> TypeGuard[list['BasePipelineStep']]:
    """Check if a value is a list of pipeline steps.

    Args:
        branch (object): Value to validate.

    Returns:
        bool: True if the value is a list of BasePipelineStep instances.
    """
async def execute_sequential_steps(steps: list['BasePipelineStep'], state: dict[str, Any], runtime: Runtime) -> dict[str, Any] | None:
    """Execute a sequence of steps sequentially and return accumulated state updates.

    Each step will receive the updated state from the previous step. In the end, all state updates
    will be merged into a single update dictionary.

    Args:
        steps (list[BasePipelineStep]): The steps to run sequentially.
        state (dict[str, Any]): The initial state to pass to the first step.
        runtime (Runtime): Runtime information for step execution.

    Returns:
        dict[str, Any] | None: The accumulated state updates from all steps, or None if no updates.
    """
def has_interrupt_step(steps: list['BasePipelineStep']) -> bool:
    """Check if any of the provided steps contains an InterruptStep.

    Args:
        steps (list[BasePipelineStep]): The pipeline steps to search.

    Returns:
        bool: True if an InterruptStep is found directly or nested in composite steps.
    """
