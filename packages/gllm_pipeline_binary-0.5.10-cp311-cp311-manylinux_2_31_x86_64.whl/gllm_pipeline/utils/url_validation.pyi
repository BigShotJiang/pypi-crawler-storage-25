def is_safe_url(url: str, allowed_schemes: set[str], allowed_hostname: set[str] | None = None) -> bool:
    """Validates that a URL is safe to fetch to prevent SSRF attacks.

    Only URLs satisfying all of the following are permitted:
    1. Scheme is in allowed schemes (e.g. https).
    2. No embedded credentials (userinfo component is absent).
    3. Hostname belongs to an allowed provider (e.g. Google Drive, AWS S3).

    Args:
        url (str): The URL to validate.
        allowed_schemes (set[str]): Set of allowed URL schemes
        allowed_hostname (set[str] | None): Set of allowed hostnames. If None, hostname validation is skipped.

    Returns:
        bool: True if the URL is safe to fetch; False otherwise.
    """
