from _typeshed import Incomplete
from gllm_pipeline.alias import InputMapSpec as InputMapSpec, PipelineState as PipelineState
from gllm_pipeline.types import Group as Group, Val as Val
from gllm_pipeline.utils.input_map import DOT_NOTATION as DOT_NOTATION, resolve_dotted_path as resolve_dotted_path, shallow_dump as shallow_dump

class HasInputsMixin:
    '''Mixin class for steps that consume a unified input_map.

    The input_map maps argument names to a state/config key (str), a fixed value (Val),
    or a grouped wrapper (Group).
    Resolution semantics:
    1. For str specs: read from state first; if missing, fall back to config["configurable"].
       String specs can use dot notation (e.g. "a.b.c") for nested dictionary or attribute access.
    2. For Val specs: use the literal value.

    Attributes:
        input_map (dict[str, str | Val | Group]): Mapping of argument names to a state/config key (str),
            a fixed value (Val), or a grouped wrapper (Group).
    '''
    input_map: Incomplete
    def __init__(self, input_map: InputMapSpec | None = None) -> None:
        '''Initialize with a unified input_map.

        Args:
            input_map (InputMapSpec | None):
                Mapping of argument names to a state/config key (str), a fixed value (Val),
                or a grouped wrapper (Group).
                Also accepts a list form for ergonomics:
                1. str: identity mapping ("key" -> {"key": "key"})
                2. dict[str, str]: explicit mapping to state/config key
                3. dict[str, Val]: fixed/literal value
                4. dict[str, Group]: grouped wrapper around a lookup or literal spec
                Defaults to None, in which case an empty mapping is used.
        '''
