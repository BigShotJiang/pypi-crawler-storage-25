from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.utils.typing_compat import is_typeddict as is_typeddict
from pydantic.json_schema import JsonSchemaValue
from typing import Any, Literal, overload

def is_typeddict_or_basemodel(type_hint: type) -> bool:
    """Check if a type is a TypedDict or Pydantic BaseModel.

    Args:
        type_hint (type): The type to check.

    Returns:
        bool: True if the type is a TypedDict or BaseModel, False otherwise.
    """
def filter_output_by_schema(result: PipelineState, schema: type) -> dict[str, Any]:
    """Filter the output result to match the provided schema.

    Args:
        result (PipelineState): The result to filter.
        schema (type): The schema (TypedDict or BaseModel) to filter against.

    Returns:
        dict[str, Any]: The filtered result as a dictionary.

    Raises:
        ValueError: If the schema is not a TypedDict or Pydantic BaseModel.
    """
@overload
def validate_schema(schema: type | None, allow_none: Literal[False] = False, default: type | None = None) -> type: ...
@overload
def validate_schema(schema: type | None, allow_none: Literal[True], default: type | None = None) -> type | None: ...
def get_json_schema(schema_type: type | None) -> JsonSchemaValue:
    '''Convert a TypedDict or Pydantic model to JSON schema.

    Args:
        schema_type (type | None): The type to convert to JSON schema. Can be None.

    Returns:
        JsonSchemaValue: The JSON schema representation.
        Returns {"type": "object"} if schema_type is None or not a TypedDict or Pydantic model.
    '''
