from _typeshed import Incomplete
from collections.abc import Callable
from gllm_core.schema import Component
from gllm_core.utils.retry import RetryConfig
from gllm_pipeline.alias import InputMapSpec as InputMapSpec, PipelineState as PipelineState
from gllm_pipeline.exclusions import ExclusionSet as ExclusionSet
from gllm_pipeline.steps.composite_step import BaseCompositeStep as BaseCompositeStep
from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from gllm_pipeline.steps.step_error_handler.step_error_handler import BaseStepErrorHandler as BaseStepErrorHandler
from gllm_pipeline.types import CacheConfig as CacheConfig
from gllm_pipeline.utils.async_utils import execute_callable as execute_callable
from gllm_pipeline.utils.graph import create_edge as create_edge
from gllm_pipeline.utils.has_inputs_mixin import HasInputsMixin as HasInputsMixin
from gllm_pipeline.utils.input_map import shallow_dump as shallow_dump
from gllm_pipeline.utils.mermaid import MERMAID_HEADER as MERMAID_HEADER
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from langgraph.types import Command
from typing import Any

LoopCallableType = Callable[[dict[str, Any]], bool | str]
LoopConditionType = Component | LoopCallableType

class WhileDoStep(BaseCompositeStep, HasInputsMixin):
    """A pipeline step that executes a do-while loop construct.

    The loop body executes at least once and a condition node appended at the
    end determines whether to jump back to the loop's entry point.

    Attributes:
        name (str): A unique identifier for the pipeline step.
        body (BasePipelineStep | list[BasePipelineStep]): The step(s) to execute in the loop body.
        condition (LoopConditionType): The condition to evaluate after each iteration.
        input_map (InputMapSpec | None): Unified input map for the condition.
        output_state (str | None): Key to store the condition result in the pipeline state.
        retry_policy (RetryPolicy | None): Configuration for retry behavior.
        error_handler (BaseStepErrorHandler | None): Strategy to handle errors during execution.
    """
    body: Incomplete
    condition: Incomplete
    output_state: Incomplete
    def __init__(self, name: str, body: BasePipelineStep | list[BasePipelineStep], condition: LoopConditionType, input_map: InputMapSpec | None = None, output_state: str | None = None, retry_config: RetryConfig | None = None, error_handler: BaseStepErrorHandler | None = None, cache: CacheConfig | None = None) -> None:
        """Initialize a WhileDoStep.

        Args:
            name (str): A unique identifier for this pipeline step.
            body (BasePipelineStep | list[BasePipelineStep]): The loop body to execute.
            condition (LoopConditionType): The condition to evaluate at the end of each iteration.
            input_map (InputMapSpec | None, optional): Unified input map for the condition. Defaults to None.
            output_state (str | None, optional): Key to store the condition result in the state. Defaults to None.
            retry_config (RetryConfig | None, optional): Retry config applied to the condition node.
                Defaults to None.
            error_handler (BaseStepErrorHandler | None, optional): Error handling strategy for condition.
                Defaults to None.
            cache (CacheConfig | None, optional): Caching config for the condition. Defaults to None.

        Raises:
            TypeError: If body is empty or condition is invalid.
        """
    is_excluded: Incomplete
    def apply_exclusions(self, exclusions: ExclusionSet) -> None:
        """Apply exclusions to this composite step and its children.

        Args:
            exclusions (ExclusionSet): The exclusion set to apply.
        """
    async def execute(self, state: PipelineState, runtime: Runtime, config: RunnableConfig | None = None) -> Command | dict[str, Any] | None:
        """Evaluate the condition and route back or exit the loop.

        Args:
            state (PipelineState): The current state of the pipeline workflow.
            runtime (Runtime): The runtime context of the pipeline workflow execution.
            config (RunnableConfig | None, optional): Execution configuration for the node. Defaults to None.

        Returns:
            Command | dict[str, Any] | None: A LangGraph command directing execution back to the loop entry,
                an update payload when the loop exits, or None when there is no state update.
        """
    async def execute_direct(self, state: dict[str, Any], runtime: Runtime, config: RunnableConfig | None = None) -> dict[str, Any] | None:
        """Reject direct execution for WhileDoStep.

        Args:
            state (dict[str, Any]): The initial state data.
            runtime (Runtime): The runtime context of the pipeline execution.
            config (RunnableConfig | None, optional): Configuration for the runnable. Defaults to None.

        Returns:
            dict[str, Any] | None: This method does not return normally.

        Raises:
            NotImplementedError: Always raised since loop routing requires a graph.
        """
