from _typeshed import Incomplete
from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.steps.step_error_handler.step_error_handler import BaseStepErrorHandler as BaseStepErrorHandler
from gllm_pipeline.utils.error_handling import ErrorContext as ErrorContext
from langgraph.runtime import Runtime
from typing import Any, Callable

class FallbackStepErrorHandler(BaseStepErrorHandler):
    """Strategy that executes a fallback callable on error.

    Attributes:
        fallback (Callable[[BaseException, PipelineState, Runtime, ErrorContext], dict[str, Any] | None]):
            A callable that generates the fallback state dynamically.
            It should accept (error, state, runtime, context) and return a fallback state.
    """
    fallback: Incomplete
    def __init__(self, fallback: Callable[[BaseException, PipelineState, Runtime, ErrorContext], dict[str, Any] | None]) -> None:
        """Initialize the strategy with a fallback callable.

        Args:
            fallback (Callable[[BaseException, PipelineState, Runtime, ErrorContext], dict[str, Any] | None]):
                A callable that generates the fallback state dynamically.
                It should accept (error, state, runtime, context) and return a fallback state.
        """
