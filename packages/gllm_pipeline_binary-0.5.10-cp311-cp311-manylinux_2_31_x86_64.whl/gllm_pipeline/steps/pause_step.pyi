from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from typing import Any

class PauseStep(BasePipelineStep):
    '''A named marker step for use as a static breakpoint target.

    `PauseStep` does **not** pause execution by itself.  It exists only so
    that its ``name`` can be referenced in ``interrupt_before`` or
    ``interrupt_after`` lists when calling ``Pipeline.invoke()``.

    This is the recommended pattern for **debugging**: insert one or more
    `PauseStep` instances at interesting points in the pipeline, then
    selectively activate breakpoints at invocation time without recompiling
    the graph.

    Examples:
    ```python
    from gllm_pipeline.steps import pause, step
    from gllm_pipeline.pipeline import Pipeline

    bp = pause(name="before_llm")
    pipeline = Pipeline([preprocess, bp, llm_step, postprocess])

    # Debug run — pause right before the LLM call:
    result = await pipeline.invoke(state, interrupt_before=["before_llm"])
    ```

    Attributes:
        name (str): A unique identifier for this pipeline step.
    '''
    def __init__(self, name: str, **kwargs: Any) -> None:
        """Initialize a PauseStep.

        Args:
            name (str): A unique identifier for this step.  This name is used
                as the target for `interrupt_before` or `interrupt_after`.
            **kwargs (Any): Forwarded to `BasePipelineStep.__init__`.

        Raises:
            ValueError: If `cache` is provided in kwargs, as this step cannot be cached.
        """
    async def execute(self, state: PipelineState, runtime: Runtime, config: RunnableConfig | None = None) -> None:
        """Execute this step, which does nothing.

        Args:
            state (PipelineState): The current state of the pipeline.
            runtime (Runtime): Runtime information for this step's execution.
            config (RunnableConfig | None, optional): The runnable configuration. Defaults to None.
        """
