from _typeshed import Incomplete
from abc import ABC, abstractmethod
from gllm_core.utils.retry import RetryConfig
from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.exclusions import ExclusionSet as ExclusionSet
from gllm_pipeline.observability.tracing import ErrorCategory as ErrorCategory, SpanAttributes as SpanAttributes, SpanEvents as SpanEvents, get_tracer as get_tracer, set_span_error as set_span_error, set_span_success as set_span_success
from gllm_pipeline.pipeline.pipeline import Pipeline as Pipeline
from gllm_pipeline.steps.step_error_handler import RaiseStepErrorHandler as RaiseStepErrorHandler
from gllm_pipeline.steps.step_error_handler.step_error_handler import BaseStepErrorHandler as BaseStepErrorHandler
from gllm_pipeline.types import CacheConfig as CacheConfig
from gllm_pipeline.utils.error_handling import ErrorContext as ErrorContext
from gllm_pipeline.utils.graph import create_edge as create_edge
from gllm_pipeline.utils.input_map import shallow_dump as shallow_dump
from gllm_pipeline.utils.retry_converter import retry_config_to_langgraph_policy as retry_config_to_langgraph_policy
from langchain_core.runnables import RunnableConfig as RunnableConfig
from langgraph.graph import StateGraph
from langgraph.runtime import Runtime
from langgraph.types import RetryPolicy
from typing import Any

LANGGRAPH_CONFIG_PREFIX: str

class BasePipelineStep(ABC):
    '''The base class for all pipeline steps.

    A pipeline step represents a single operation or task within a larger processing pipeline.
    Each step must implement:
    1. execute() - to perform the actual operation
    2. add_to_graph() - to integrate with the pipeline structure (optional, default implementation provided)

    The default implementation of add_to_graph is suitable for steps that:
    1. Have a single entry point
    2. Have a single exit point
    3. Connect to all previous endpoints

    For more complex graph structures (e.g., conditional branching), steps should override add_to_graph.

    Examples:
        1. Basic Usage:
            ```python
            step = MyCustomStep("my_step")
            ```

        2. Adding Step Level Caching:
            ```python
            from gllm_pipeline.types import CacheConfig

            step = MyCustomStep(
                "my_step",
                cache=CacheConfig(store=cache_store)
            )

        3. Retry Configuration:
            ```python
            retry_config = RetryConfig(max_retries=3, backoff_factor=2)
            step = MyCustomStep(
                "my_step",
                retry_config=retry_config
            )
            ```

        4. Error Handling:
            ```python
            step = MyCustomStep(
                "my_step",
                error_handler=error_handler
            )
            ```

    Attributes:
        name (str): A unique identifier for the pipeline step.
        retry_policy (RetryPolicy | None): Configuration for retry behavior using LangGraph\'s RetryPolicy.
        cache_store (Cache | None): The cache store used for caching step results, if configured.
        is_cache_enabled (bool): Property indicating whether caching is enabled for this step.
    '''
    name: Incomplete
    error_handler: Incomplete
    retry_policy: Incomplete
    cache_store: Incomplete
    def __init__(self, name: str, retry_config: RetryConfig | None = None, error_handler: BaseStepErrorHandler | None = None, cache: CacheConfig | None = None) -> None:
        '''Initializes a new pipeline step.

        Args:
            name (str): A unique identifier for the pipeline step.
            retry_config (RetryConfig | None, optional): Configuration for retry behavior using
                GLLM Core\'s RetryConfig. Defaults to None, in which case no retry config is applied.
                The RetryConfig is automatically converted to LangGraph\'s RetryPolicy when needed for internal use.
                Note that `timeout` is not supported and will be ignored.
            error_handler (BaseStepErrorHandler | None, optional): Strategy to handle errors during execution.
                Defaults to None, in which case the RaiseStepErrorHandler is used.
            cache (CacheConfig | None, optional): Configuration for the cache store including the cache
                store instance and its settings. Defaults to None, in which case no caching will be used.

        Caching Mechanism:
            When a cache configuration is provided, the step\'s execution method is automatically
            wrapped with a cache decorator. This means:
            1. Before execution, the cache is checked for existing results based on input parameters
            2. If a cached result exists and is valid, it\'s returned immediately
            3. If no cached result exists, the step executes normally and the result is cached
            4. Cache keys are generated from the step\'s input state, runtime, and config
            5. The cache name defaults to "step_{step_name}" if not specified in the CacheConfig
        '''
    @property
    def is_cache_enabled(self) -> bool:
        """Whether caching is enabled for this step.

        Returns:
            bool: True if caching is enabled, False otherwise.
        """
    @property
    def is_excluded(self) -> bool:
        """Whether this step is excluded from execution/graph integration.

        Returns:
            bool: True if the step is excluded, False otherwise.
        """
    @is_excluded.setter
    def is_excluded(self, value: bool) -> None:
        """Set the exclusion state for this step.

        Args:
            value (bool): Exclusion flag.
        """
    async def invoke(self, state: PipelineState, runtime: Runtime, config: RunnableConfig | None = None):
        """Invoke the step's execute method with caching support.

        This is the main entry point for step execution. It handles caching if enabled.
        When caching is enabled, it will:
        1. Check if there's a cached result for the given inputs
        2. If found, return the cached result
        3. If not found, execute the step and cache the result

        Args:
            state (PipelineState): The current state of the pipeline.
            runtime (Runtime): The runtime information to pass to the step.
            config (RunnableConfig | None, optional): The runnable configuration to pass to the step. Defaults to None.

        Returns:
            dict[str, Any] | None: Updates to apply to the pipeline state, or None if no updates.
        """
    def add_to_graph(self, graph: StateGraph, previous_endpoints: list[str], retry_policy: RetryPolicy | None = None) -> list[str]:
        """Integrates this step into the pipeline's internal structure.

        This method is responsible for:
        1. Adding the step's node(s) to the graph if not already present
        2. Creating edges from previous endpoints to this step's entry points
        3. Returning this step's exit points (endpoints)

        This method provides a default implementation suitable for simple steps.
        Steps with more complex graph structures should override this method.

        This method is used by `Pipeline` to manage the pipeline's execution flow.
        It should not be called directly by users.

        Args:
            graph (StateGraph): The internal representation of the pipeline structure.
            previous_endpoints (list[str]): The endpoints from previous steps to connect to.
            retry_policy (RetryPolicy | None): Configuration for retry behavior using LangGraph's RetryPolicy.
                If None, the retry policy of the step is used. If the step is not a retryable step,
                this parameter is ignored.

        Returns:
            list[str]: The exit points (endpoints) of this step.
        """
    @abstractmethod
    async def execute(self, state: PipelineState, runtime: Runtime, config: RunnableConfig | None = None) -> dict[str, Any] | None:
        """Executes the operation defined for this pipeline step.

        This method should be implemented by subclasses to perform the actual processing or computation for this step.

        Args:
            state (PipelineState): The current state of the pipeline, containing all data.
            runtime (Runtime): Runtime information for this step's execution.
            config (RunnableConfig | None, optional): Runnable configuration containing thread_id and other
                LangGraph config. This allows steps to access invocation-level configuration like thread_id for
                tracking and checkpointing. Defaults to None.

        Returns:
            dict[str, Any] | None: The update to the pipeline state after this step's operation.
                This should include new or modified data produced by this step, not the entire state.
                Returns None if no state update is needed.

        Raises:
            NotImplementedError: If the subclass does not implement this method.
        """
    async def execute_direct(self, state: dict[str, Any], runtime: Runtime, config: RunnableConfig | None = None) -> dict[str, Any] | None:
        """Execute this step directly, bypassing graph-based execution.

        This method is used when a step needs to be executed directly, such as in parallel execution.
        The default implementation calls _execute_step for consistent error handling.

        Args:
            state (dict[str, Any]): The current state of the pipeline.
            runtime (Runtime): Runtime information for this step's execution.
            config (RunnableConfig | None, optional): The runnable configuration to pass to the step.

        Returns:
            dict[str, Any] | None: Updates to apply to the pipeline state, or None if no updates.
        """
    def apply_exclusions(self, exclusions: ExclusionSet) -> None:
        """Apply exclusions to this step.

        Args:
            exclusions (ExclusionSet): The exclusion set to apply.
        """
    def get_mermaid_diagram(self) -> str:
        """Generates a Mermaid diagram representation of the pipeline step.

        This method provides a default implementation that can be overridden by subclasses
        to provide more detailed or specific diagrams.

        It is recommended to implement this method for subclasses that have multiple connections to other steps.

        Returns:
            str: Empty string.
        """
    def __or__(self, other: BasePipelineStep | Pipeline) -> Pipeline:
        """Combines this step with another step or pipeline.

        This method allows for easy composition of pipeline steps using the | operator.

        Args:
            other (BasePipelineStep | Pipeline): Another step or pipeline to combine with this one.

        Returns:
            Pipeline: A new pipeline containing the combined steps.
        """
    def __lshift__(self, other: BasePipelineStep | Pipeline) -> Pipeline:
        """Combines this step with another step or pipeline using the '<<' operator.

        Args:
            other (BasePipelineStep | Pipeline): The step or pipeline to add after this step.

        Returns:
            Pipeline: A new pipeline with this step followed by the other step or pipeline.
        """
    def __rshift__(self, other: BasePipelineStep | Pipeline) -> Pipeline:
        """Combines this step with another step or pipeline using the '>>' operator.

        Args:
            other (BasePipelineStep | Pipeline): The step or pipeline to include this step in.

        Returns:
            Pipeline: A new pipeline with this step included in the other step or pipeline.
        """
