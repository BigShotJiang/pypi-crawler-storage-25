from _typeshed import Incomplete
from gllm_core.utils.retry import RetryConfig
from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from gllm_pipeline.steps.step_error_handler.step_error_handler import BaseStepErrorHandler as BaseStepErrorHandler
from gllm_pipeline.types import CacheConfig as CacheConfig
from gllm_pipeline.utils.input_map import shallow_dump as shallow_dump
from langchain_core.runnables import RunnableConfig as RunnableConfig
from langgraph.runtime import Runtime
from typing import Any

class LogStep(BasePipelineStep):
    """A specialized pipeline step for logging messages.

    This step uses the Messenger component to log messages during pipeline execution.
    It supports both plain text messages and template messages with placeholders for state variables.

    Attributes:
        name (str): A unique identifier for this pipeline step.
        messenger (Messenger): The messenger component used to format and send messages.
        emit_kwargs (dict[str, Any]): Additional arguments to pass to the event emitter.
        retry_policy (RetryPolicy | None): Configuration for retry behavior using LangGraph's RetryPolicy.
    """
    messenger: Incomplete
    emit_kwargs: Incomplete
    def __init__(self, name: str, message: str, is_template: bool = True, emit_kwargs: dict[str, Any] | None = None, retry_config: RetryConfig | None = None, error_handler: BaseStepErrorHandler | None = None, cache: CacheConfig | None = None) -> None:
        """Initializes a new LogStep.

        Args:
            name (str): A unique identifier for this pipeline step.
            message (str): The message to be logged. May contain placeholders in curly braces for state variables.
            is_template (bool, optional): Whether the message is a template with placeholders. Defaults to True.
            emit_kwargs (dict[str, Any] | None, optional): Additional keyword arguments to pass to the event emitter.
                Defaults to None.
            retry_config (RetryConfig | None, optional): Configuration for retry behavior using GLLM Core's RetryConfig.
                Defaults to None, in which case no retry config is applied.
            error_handler (BaseStepErrorHandler | None, optional): Strategy to handle errors during execution.
                Defaults to None, in which case the RaiseStepErrorHandler is used.
            cache (CacheConfig | None, optional): Configuration for the cache store including the cache
                store instance and its settings. Defaults to None, in which case no caching will be used.
        """
    async def execute(self, state: PipelineState, runtime: Runtime, config: RunnableConfig | None = None) -> None:
        """Executes the log step by formatting and emitting the message.

        Args:
            state (PipelineState): The current state of the pipeline, containing all data.
            runtime (Runtime): Runtime information for this step's execution.
            config (RunnableConfig | None, optional): The runnable configuration. Defaults to None.

        Returns:
            None: This step does not modify the pipeline state.

        Raises:
            RuntimeError: If an error occurs during message emission.
        """
