from _typeshed import Incomplete
from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from typing import Any

class InterruptStep(BasePipelineStep):
    """A pipeline step that pauses execution using LangGraph's interrupt feature.

    When the pipeline reaches this step, it will throw an interrupt which pauses
    execution and returns control to the caller (along with the current state).
    To resume, the user must invoke the pipeline again with a `Command(resume=...)`
    payload and the same `thread_id`.

    The value returned from the `interrupt()` call (which is whatever the user
    provides in `Command(resume=val)`) will be stored in the state key specified
    by `resume_value_map` if provided.
    """
    message: Incomplete
    resume_value_map: Incomplete
    def __init__(self, name: str, message: str | dict[str, Any] = 'Pipeline interrupted.', resume_value_map: str | list[str] | None = None, **kwargs: Any) -> None:
        '''Initializes an InterruptStep.

        Args:
            name (str): The unique identifier for this step.
            message (str | dict[str, Any], optional): The payload to emit when the interrupt occurs.
                Defaults to "Pipeline interrupted.".
            resume_value_map (str | list[str] | None, optional): State key(s) where the resume
                value will be stored. Defaults to None.
            **kwargs (Any): Additional configuration (e.g., error_handler) for the BasePipelineStep.

        Raises:
            ValueError: If `cache` is provided in kwargs, as this step cannot be cached.
        '''
    async def execute(self, state: PipelineState, runtime: Runtime, config: RunnableConfig | None = None) -> dict[str, Any] | None:
        """Execute the interrupt and handle the resumed value.

        Args:
            state (PipelineState): The current pipeline state.
            runtime (Runtime): The pipeline runtime.
            config (RunnableConfig | None): The RunnableConfig.

        Returns:
            dict[str, Any] | None: State updates containing the resumed value
                if a `resume_value_map` is configured.

        Raises:
            TypeError: If `resume_value_map` is a list but the resumed value is not a dictionary.
        """
