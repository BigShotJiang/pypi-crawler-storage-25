from _typeshed import Incomplete
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_pipeline.router.backend.base_adapter import BaseAdapter as BaseAdapter
from gllm_pipeline.router.backend.llmrouter import LLMRouterMLPAdapter as LLMRouterMLPAdapter, LLMRouterSVMAdapter as LLMRouterSVMAdapter
from gllm_pipeline.router.backend.llmrouter.config import MLPConfig as MLPConfig, SVMConfig as SVMConfig
from gllm_pipeline.router.router import BaseRouter as BaseRouter
from gllm_pipeline.router.schema import RouterInput as RouterInput
from typing import Any

class ClassifierRouter(BaseRouter):
    """Router that uses classifier-based routing via LLMRouter adapters.

    Delegates to LLMRouter adapters (MLP or SVM) for classification-based routing.
    Provides factory classmethods for convenient construction with different backends.

    Attributes:
        backend (BaseAdapter): The classifier adapter for routing.
    """
    backend: Incomplete
    def __init__(self, backend: BaseAdapter, default_route: str, valid_routes: set[str]) -> None:
        """Initialize the ClassifierRouter.

        Args:
            backend (BaseAdapter): The classifier adapter for routing.
                Must be an instance of BaseAdapter.
            default_route (str): The default route to use if routing fails.
            valid_routes (set[str]): A set of valid routes for the router.

        Raises:
            ValueError:
            1. If backend is not a BaseAdapter instance.
            2. If default_route is not in valid_routes.
        """
    @classmethod
    def mlp(cls, model_path: str, default_route: str, valid_routes: set[str], config: MLPConfig, encoder: BaseEMInvoker | None = None, device: str = 'cpu', hyperparameters: dict[str, Any] | None = None) -> ClassifierRouter:
        '''Create a ClassifierRouter with MLP backend.

        Args:
            model_path (str): Path to the trained MLP classifier model file.
            default_route (str): The default route to use if routing fails.
            valid_routes (set[str]): A set of valid routes for the router.
            config (MLPConfig): Configuration for the MLP classifier.
            encoder (BaseEMInvoker | None, optional): EM Invoker for custom embeddings.
                If None, uses LLMRouter\'s built-in Longformer. Defaults to None.
            device (str, optional): Device for model inference. Defaults to "cpu".
            hyperparameters (dict[str, Any] | None, optional): Runtime hyperparameter overrides.
                Defaults to None.

        Returns:
            ClassifierRouter: A ClassifierRouter instance with MLP backend.
        '''
    @classmethod
    def svm(cls, model_path: str, default_route: str, valid_routes: set[str], config: SVMConfig, encoder: BaseEMInvoker | None = None) -> ClassifierRouter:
        """Create a ClassifierRouter with SVM backend.

        Args:
            model_path (str): Path to the trained SVM classifier model file.
            default_route (str): The default route to use if routing fails.
            valid_routes (set[str]): A set of valid routes for the router.
            config (SVMConfig): Configuration for the SVM classifier.
            encoder (BaseEMInvoker | None, optional): EM Invoker for custom embeddings.
                If None, uses LLMRouter's built-in Longformer. Defaults to None.

        Returns:
            ClassifierRouter: A ClassifierRouter instance with SVM backend.
        """
