from _typeshed import Incomplete
from gllm_inference.request_processor import LMRequestProcessor, UsesLM
from gllm_pipeline.router.backend.native.lm_based.lm_based_adapter import NativeLMBasedAdapter as NativeLMBasedAdapter
from gllm_pipeline.router.router import BaseRouter as BaseRouter
from gllm_pipeline.router.schema import RouterInput as RouterInput
from pydantic import BaseModel
from typing import Any

DEFAULT_LM_OUTPUT_KEY: str

class LMBasedRouterPresetKwargs(BaseModel):
    """Schema for LMBasedRouter.from_preset preset_kwargs.

    This model validates and documents the allowed parameters for the preset configuration.

    Attributes:
        lm_invoker_kwargs (dict[str, Any] | None): Configuration for the language model invoker.
        prompt_builder_kwargs (dict[str, Any] | None): Configuration for the prompt builder.
        lm_output_key (str): The key in the language model's output that contains the route.
        default_route (str): Default route to use if LM cannot determine route.
        valid_routes (set[str]): Set of valid routes for the router.
    """
    model_config: Incomplete
    lm_invoker_kwargs: dict[str, Any] | None
    prompt_builder_kwargs: dict[str, Any] | None
    lm_output_key: str
    default_route: str
    valid_routes: set[str]

class LMBasedRouter(BaseRouter, UsesLM):
    '''A router that utilizes a language model to determine the appropriate route for an input source.

    This class routes a given input source to an appropriate path based on the output of a language model.
    If the determined route is not valid, it defaults to a predefined route.

    The router delegates routing logic to a pluggable backend adapter (e.g., NativeLMBasedAdapter).

    Attributes:
        backend (BaseAdapter): The backend implementation handling routing logic.
        lm_request_processor (LMRequestProcessor): The request processor that handles requests to the language model.
        default_route (str): The default route to be used if the language model\'s output is invalid.
        valid_routes (set[str]): A set of valid routes for the router.
        lm_output_key (str, optional): The key in the language model\'s output that contains the route.

    Notes:
        The `lm_request_processor` must be configured to:
        1. Take a "source" key as input. The input source of the router should be passed as the value of
            this "source" key.
        2. Return a JSON object which contains the selected route as a string. The key of the route is specified by the
        `lm_output_key` attribute. Furthermore, the selected route must be present in the `valid_routes` set.

        Output example, assuming the `lm_output_key` is "route":
        {
            "route": "<route_string>"
        }
    '''
    lm_request_processor: Incomplete
    lm_output_key: Incomplete
    backend: NativeLMBasedAdapter
    def __init__(self, lm_request_processor: LMRequestProcessor, default_route: str, valid_routes: set[str], lm_output_key: str = ...) -> None:
        """Initializes a new instance of the LMBasedRouter class.

        Args:
            lm_request_processor (LMRequestProcessor): The request processor that handles requests to the
                language model.
            default_route (str): The default route to be used if the language model's output is invalid.
            valid_routes (set[str]): A set of valid routes for the router.
            lm_output_key (str, optional): The key in the language model's output that contains the route.
                Defaults to DEFAULT_LM_OUTPUT_KEY.

        Raises:
            ValueError: If the provided default route is not in the set of valid routes.
        """
    @classmethod
    def from_preset(cls, modality: str, preset_kwargs: dict[str, Any] | None = None, **kwargs: Any) -> LMBasedRouter:
        '''Initialize the LM based router component using preset model configurations.

        Examples:
            ```python
            router = LMBasedRouter.from_preset(modality="image")
            router = LMBasedRouter.from_preset(
                modality="image",
                preset_kwargs={"default_route": "custom_route", "valid_routes": {"custom_route", "other"}}
            )
            ```

        Args:
            modality (str): Type of modality input (e.g., "image").
            preset_kwargs (LMBasedRouterPresetKwargs | dict[str, Any] | None): Additional kwargs for the preset.
                Can be provided as a dict or as an LMBasedRouterPresetKwargs instance.
                When provided as a dict, unknown keys will raise a ValidationError.
                Defaults to None.

                The following keys are allowed:
                1. `lm_invoker_kwargs`: Configuration for the language model invoker.
                2. `prompt_builder_kwargs`: Configuration for the prompt builder.
                3. `lm_output_key`: The key in the language model\'s output that contains the route.
                4. `default_route`: Default route to use if LM cannot determine route.
                5. `valid_routes`: Set of valid routes for the router.
            **kwargs (Any): Additional arguments to pass for this class.

        Returns:
            LMBasedRouter: Initialized LM-based router component using preset model.
        '''
    @classmethod
    def native(cls, lm_request_processor: LMRequestProcessor, default_route: str, valid_routes: set[str], lm_output_key: str = ...) -> LMBasedRouter:
        """Create LM-based router with native backend.

        This is a convenience classmethod that creates an LMBasedRouter with a NativeLMBasedAdapter.

        Args:
            lm_request_processor (LMRequestProcessor): The request processor that handles requests to the
                language model.
            default_route (str): The default route to be used if the language model's output is invalid.
            valid_routes (set[str]): A set of valid routes for the router.
            lm_output_key (str, optional): The key in the language model's output that contains the route.
                Defaults to DEFAULT_LM_OUTPUT_KEY.

        Returns:
            LMBasedRouter: Initialized router with native backend.
        """
