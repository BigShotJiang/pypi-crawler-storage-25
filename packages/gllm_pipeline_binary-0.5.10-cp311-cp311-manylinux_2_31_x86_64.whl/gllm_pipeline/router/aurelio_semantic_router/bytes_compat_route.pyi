from gllm_pipeline.router.backend.aurelio.bytes_compat_route import BytesCompatRoute as BytesCompatRoute

__all__ = ['BytesCompatRoute']
