from gllm_pipeline.router.backend.aurelio.encoders.tei_encoder import TEIEncoder as TEIEncoder

__all__ = ['TEIEncoder']
