from gllm_pipeline.router.backend.aurelio.encoders.langchain_encoder import LangchainEmbeddingsEncoder as LangchainEmbeddingsEncoder

__all__ = ['LangchainEmbeddingsEncoder']
