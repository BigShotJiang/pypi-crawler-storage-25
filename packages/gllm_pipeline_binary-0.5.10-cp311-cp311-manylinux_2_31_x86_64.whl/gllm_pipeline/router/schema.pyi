from enum import StrEnum
from gllm_inference.schema import EMContent

RouterInput = EMContent | bytes
RouteExamples = dict[str, list[EMContent]]

class ContentType(StrEnum):
    """Enumeration of supported content types for router utterances."""
    BASE64: str
    URL: str
    PLAINTEXT: str

class BackendType(StrEnum):
    """Backend implementation types."""
    NATIVE: str
    LLMROUTER: str
    AURELIO: str

class ModalityType(StrEnum):
    """Modality types for router input."""
    IMAGE: str
    TEXT: str

class SemanticRouterStrategy(StrEnum):
    """Semantic router strategy."""
    SIMILARITY: str

class ClassifierStrategy(StrEnum):
    """Classifier strategy for LLMRouter-based routing."""
    MLP: str
    SVM: str
    KNN: str
