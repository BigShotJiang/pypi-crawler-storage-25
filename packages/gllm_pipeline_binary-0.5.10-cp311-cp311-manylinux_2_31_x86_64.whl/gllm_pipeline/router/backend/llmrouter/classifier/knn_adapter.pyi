from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_pipeline.router.backend.llmrouter.classifier.llmrouter_adapter import LLMRouterBaseAdapter as LLMRouterBaseAdapter
from gllm_pipeline.router.backend.llmrouter.config import KNNConfig as KNNConfig
from gllm_pipeline.router.schema import RouterInput as RouterInput

class LLMRouterKNNAdapter(LLMRouterBaseAdapter):
    """Adapter for LLMRouter KNN-based classification routing.

    Bypasses KNNRouter.__init__ (training-coupled) via KNNRouter.__new__,
    reconstructing only the inference shell from KNNConfig metadata.
    KNeighborsClassifier predicts model name strings directly — no
    idx_to_model mapping needed.

    Attributes:
        encoder (BaseEMInvoker | None): EM Invoker for custom embeddings.
            If None, uses llmrouter's built-in Longformer.
        router (KNNRouter): Initialized KNNRouter inference shell.
    """
    def __init__(self, model_path: str, config: KNNConfig, encoder: BaseEMInvoker | None = None) -> None:
        """Initialize the KNN adapter.

        Args:
            model_path (str): Path to the trained KNN classifier model file (.pkl).
            config (KNNConfig): Configuration holding inference metadata (num_classes).
                Must match the trained model.
            encoder (BaseEMInvoker | None, optional): EM Invoker for custom embeddings.
                If None, uses llmrouter's built-in Longformer. Defaults to None.

        Raises:
            FileNotFoundError: If model_path does not exist.
        """
