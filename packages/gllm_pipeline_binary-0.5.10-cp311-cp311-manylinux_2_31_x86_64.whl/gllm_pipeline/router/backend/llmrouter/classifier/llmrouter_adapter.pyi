from _typeshed import Incomplete
from gllm_pipeline.router.backend.base_adapter import BaseAdapter as BaseAdapter
from gllm_pipeline.router.schema import RouterInput as RouterInput
from typing import Any

class LLMRouterBaseAdapter(BaseAdapter):
    """Abstract base adapter for LLMRouter classifiers.

    Implements the template method pattern with shared routing logic.
    Subclasses must implement abstract methods for router-specific behavior.

    Attributes:
        encoder (BaseEMInvoker | None): EM Invoker instance for custom embeddings. If None, uses
            llmrouter's built-in Longformer.
        router (MetaRouter): Initialized router inference shell.
    """
    encoder: Incomplete
    router: Incomplete
    def __init__(self, model_path: str, config: Any, encoder: BaseEMInvoker | None = None) -> None:
        """Initialize the LLMRouter adapter.

        Args:
            model_path (str): Path to the trained classifier model file.
            config (Any): Configuration holding inference metadata.
            encoder (BaseEMInvoker | None, optional): EM Invoker instance for custom embeddings.
                Defaults to None.

        Raises:
            FileNotFoundError: If model_path does not exist.
        """
    async def route(self, source: RouterInput, route_filter: set[str] | None = None, **kwargs: Any) -> str | None:
        """Execute routing using template method pattern.

        Routes using llmrouter's built-in Longformer or a custom EM Invoker
        based on encoder presence.

        Args:
            source (RouterInput): Input to route (text, Attachment, or bytes).
            route_filter (set[str] | None, optional): Allowlist of routes to consider.
                Defaults to None.
            **kwargs (Any): Additional routing parameters (ignored).

        Returns:
            str | None: Selected route name, or None if routing fails or no route matches.

        Raises:
            ValueError: If bytes input provided without encoder.
            RuntimeError: If routing fails due to internal errors.
        """
