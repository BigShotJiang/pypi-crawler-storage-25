from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_pipeline.router.backend.llmrouter.classifier.llmrouter_adapter import LLMRouterBaseAdapter as LLMRouterBaseAdapter
from gllm_pipeline.router.backend.llmrouter.config import SVMConfig as SVMConfig
from gllm_pipeline.router.schema import RouterInput as RouterInput

class LLMRouterSVMAdapter(LLMRouterBaseAdapter):
    """Adapter for LLMRouter SVM-based classification routing.

    Bypasses SVMRouter.__init__ (training-coupled) via SVMRouter.__new__,
    reconstructing only the inference shell from SVMConfig metadata.
    SVC predicts model name strings directly - no idx_to_model mapping needed.

    Attributes:
        encoder (BaseEMInvoker | None): EM Invoker instance for custom embeddings.
            If None, uses llmrouter's built-in Longformer.
        router (SVMRouter): Initialized SVMRouter inference shell.
    """
    def __init__(self, model_path: str, config: SVMConfig, encoder: BaseEMInvoker | None = None) -> None:
        """Initializes a new instance of the LLMRouterSVMAdapter class.

        Args:
            model_path (str): Path to the trained SVM classifier model file.
            config (SVMConfig): Configuration holding inference metadata (num_classes).
                Must match the trained model.
            encoder (BaseEMInvoker | None, optional): EM Invoker instance for custom
                embeddings. If None, uses llmrouter's built-in Longformer. Defaults to None.
        """
