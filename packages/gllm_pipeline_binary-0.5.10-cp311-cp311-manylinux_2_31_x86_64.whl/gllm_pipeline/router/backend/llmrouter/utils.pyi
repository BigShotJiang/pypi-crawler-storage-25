import torch
from gllm_inference.schema import Vector
from typing import Any

EXPECTED_TENSOR_DIMS: int

def embedding_to_tensor(embedding: Vector | list[Vector]) -> torch.Tensor:
    """Convert an embedding vector to a torch Tensor with shape [1, D].

    Args:
        embedding (Vector | list[Vector]): Embedding vector as a flat list
            of floats or a single-element nested list containing one float list.

    Returns:
        torch.Tensor: Float32 tensor with shape [1, D].

    Raises:
        ValueError:
        1. If the embedding is empty.
        2. If the nested list has more than one row (batch size > 1).
        3. If the nested list has inconsistent inner lengths (ragged).
        4. If the embedding contains non-numeric values.
        5. If the resulting shape is not [1, D] for any other reason.
        6. If the embedding dimension D is 0.
    """
def build_yaml_config(model_path: str, hparam: dict[str, Any] | None = None, extra: dict[str, Any] | None = None) -> str:
    """Build a temporary YAML config file for llmrouter-lib.

    Creates a temporary YAML file with the llmrouter-lib config contract:
    `model_path.load_model_path` holds the model path and `hparam` holds
    optional hyper-parameters. The caller is responsible for cleaning up the
    temporary file.

    Args:
        model_path (str): Path to the trained classifier model file.
        hparam (dict[str, Any] | None, optional): Hyper-parameters to include in the YAML.
            Defaults to None.
        extra (dict[str, Any] | None, optional): Additional top-level
            configuration keys to include in the YAML. Must not contain
            reserved keys. Defaults to None.

    Returns:
        str: Absolute path to the created temporary YAML config file.

    Raises:
        ValueError: If model_path is empty, does not exist, or extra contains reserved keys.
    """
