from abc import ABC, abstractmethod
from gllm_pipeline.router.schema import RouterInput as RouterInput
from typing import Any, Generic, TypeVar

T = TypeVar('T')

class BaseAdapter(ABC):
    """Abstract base class for router backend adapters.

    Defines the interface that all backend implementations must follow.
    Adapters handle provider-specific logic, model initialization, and routing execution.
    """
    def __init__(self) -> None:
        """Initialize the adapter."""
    @abstractmethod
    async def route(self, source: RouterInput, **kwargs: Any) -> str | None:
        """Execute routing using backend implementation.

        Args:
            source (RouterInput): The input source to be routed.
            **kwargs: Additional routing parameters.

        Returns:
            str | None: Selected route name, or None if no route matches.

        Raises:
            NotImplementedError: If the method is not implemented by the subclass.
        """
    @classmethod
    def from_file(cls, file_path: str, **kwargs: Any) -> BaseAdapter:
        """Load adapter from a configuration file.

        Subclasses that support file-based initialization must override this method.

        Args:
            file_path (str): Path to configuration file (JSON or YAML).
            **kwargs (Any): Additional arguments for initialization.

        Returns:
            BaseAdapter: Initialized adapter instance.

        Raises:
            NotImplementedError: If not implemented by the subclass.
        """
    def train(self, training_data: Generic[T]) -> None:
        """Train the backend with provided training data.

        Subclasses can override this method if training is supported.

        Args:
            training_data (Generic[T]): Training data configuration.
                The structure depends on the specific backend implementation.

        Raises:
            NotImplementedError: If the method is not implemented by the subclass.
        """
