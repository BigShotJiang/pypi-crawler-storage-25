import numpy as np
from _typeshed import Incomplete
from gllm_datastore.core.filters.schema import QueryOptions
from gllm_datastore.data_store.base import BaseDataStore
from gllm_pipeline.router.backend.aurelio.index.aurelio_index import BaseAurelioIndex as BaseAurelioIndex
from gllm_pipeline.router.utils import encode_bytes as encode_bytes
from semantic_router import Route
from typing import Any

DEFAULT_GET_ALL_QUERY_OPTION: Incomplete
ROUTE_PAYLOAD_KEY: str
UTTERANCE_PAYLOAD_KEY: str

class DataStoreAdapterIndex(BaseAurelioIndex):
    """A datastore-backed implementation of BaseAurelioIndex for use with AurelioSemanticRouter.

        This index performs similarity search over a backend datastore with vector capability to
        retrieve relevant route payloads. The datastore must implement the BaseDataStore interface
        with vector capability registered for querying by vector and filtering by metadata.
        """
    index: BaseDataStore
    def __init__(self, data_store: BaseDataStore, query_option: QueryOptions = ..., **kwargs: Any) -> None:
        """Initialize the DataStoreAdapterIndex.

            Args:
                data_store (BaseDataStore): The datastore instance with vector capability registered.
                query_option (QueryOptions, optional): Query options for retrieving all routes.
                    Defaults to DEFAULT_GET_ALL_QUERY_OPTION.
                **kwargs (Any): Additional keyword arguments forwarded to the BaseAurelioIndex.

            Raises:
                ValueError: If the datastore does not have vector capability registered.
            """
    def __len__(self) -> int:
        """Returns the total number of vectors in the index.

            If the index is not initialized returns 0.

            Returns:
                int: The total number of vectors.
            """
    def add(self, embeddings: list[list[float]], routes: list[str], utterances: list[Any], function_schemas: list[dict[str, Any]] | None = None, metadata_list: list[dict[str, Any]] | None = None) -> None:
        """Add route-utterance pairs into the datastore.

            Each utterance is associated with its route and encoded as a Chunk. Binary strings
            are automatically base64-encoded for safe storage.

            Note:
                The `embeddings`, `function_schemas`, and `metadata_list` parameters are accepted
                for interface compatibility but are not used, as the datastore handles embedding
                generation internally.

            Args:
                embeddings (list[list[float]]): Pre-computed embeddings (unused, for interface compatibility).
                routes (list[str]): List of route identifiers.
                utterances (list[Any]): List of utterance strings or bytes.
                function_schemas (list[dict[str, Any]], optional): Function schemas (unused, for interface
                    compatibility).
                metadata_list (list[dict[str, Any]], optional): Metadata list (unused, for interface compatibility).

            Raises:
                AssertionError: If `routes` and `utterances` have different lengths.
            """
    def get_routes(self, **kwargs: Any) -> dict[str, list]:
        """Retrieve all routes and their corresponding utterances from the datastore.

            Returns:
                dict[str, list]: A dictionary where each key is a route and the value is a
                list of associated utterance strings.
                **kwargs (Any): Additional keyword arguments forwarded to the retrieve method.
            """
    def query(self, vector: np.ndarray, top_k: int = 5, route_filter: list[str] | None = None, retrieval_params: dict | None = None, **kwargs: Any) -> tuple[np.ndarray, list[str]]:
        """Perform a similarity query using the provided vector, optionally filtering by route.

            Args:
                vector (np.ndarray): Query vector to search against stored vectors.
                top_k (int, optional): Maximum number of top matching results to return. Defaults to 5.
                route_filter (list[str] | None, optional): Optional list of route names to filter
                    the search results by. If None, all routes are considered.
                retrieval_params (dict | None, optional): Filter parameters to narrow the search. Defaults to None.
                **kwargs (Any): Additional keyword arguments forwarded to the datastore.

            Returns:
                tuple[np.ndarray, list[str]]: A tuple containing:
                    - A NumPy array of similarity scores.
                    - A list of corresponding route names for each match.
            """
    def is_ready(self, **kwargs: Any) -> bool:
        """Checks if the index is ready to be used.

            This is a mandatory method to be implemented from `BaseIndex`.

            Args:
                **kwargs (Any): Additional keyword arguments (unused, for interface compatibility).

            Returns:
                bool: True if the index has one or more vectors; False otherwise.
            """
    async def ais_ready(self, **kwargs: Any) -> bool:
        """Checks if the index is ready to be used in async.

            Args:
                **kwargs (Any): Additional keyword arguments (unused, for interface compatibility).

            Returns:
                bool: True if the index has one or more vectors; False otherwise.
            """
    def load_routes_from_json(self, file_path: str, transform_utterance: Any = None, **kwargs: Any) -> None:
        """Load route-utterance pairs from a JSON file and insert them into the datastore.

            The JSON file must contain a dictionary mapping route names to lists of utterances.
            Each utterance can optionally be transformed before storage.

            Args:
                file_path (str): Path to a `.json` file containing routes and utterances.
                transform_utterance (Callable[[str], str | bytes] | None): Optional function to
                    preprocess each utterance before storage. Must return `str` or `bytes`.
                **kwargs (Any): Additional keyword arguments forwarded to load_routes_from_dict.

            Raises:
                ValueError: If the provided file is not a JSON file.
            """
    def load_routes_from_dict(self, routes: list[Route] | dict[str, list[Any]], transform_utterance: Any = None, **kwargs: Any) -> None:
        """Load route-utterance pairs from a list of `Route` or a dictionary and insert into the datastore.

            This method supports two input formats:
                1. A list of `Route` objects from `semantic_router`, where each route has a `name` and `utterances`.
                2. A dictionary mapping route names (str) to lists of utterances (list[str]).

            Optionally, a `transform_utterance` function can be provided to process each utterance before storage.
            Utterances can be any type; use `transform_utterance` to ensure the final result is str or bytes.

            Args:
                routes (list[Route] | dict[str, list]): Route data in either list or dictionary format.
                transform_utterance (Callable[[str], str | bytes] | None): Optional function to transform
                    each utterance before storage. Must return `str` or `bytes`.
                **kwargs (Any): Additional keyword arguments forwarded to add method.

            Raises:
                ValueError: If `routes` is not a list of `Route` objects or a dictionary,
                    if route names are invalid,
                    if utterances are not lists of non-empty strings,
                    or if transformed utterances are not `str` or `bytes`.
            """
exception = e

class DataStoreAdapterIndex:
    """Dummy DataStoreAdapterIndex for when semantic_router is not installed."""
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize dummy DataStoreAdapterIndex.

            Args:
                *args: Variable length argument list.
                **kwargs: Variable length keyword argument list.
            """
