from _typeshed import Incomplete
from gllm_inference.em_invoker.em_invoker import BaseEMInvoker
from gllm_pipeline.router.backend.aurelio.bytes_compat_route import BytesCompatRoute as BytesCompatRoute
from gllm_pipeline.router.backend.aurelio.index.aurelio_index import BaseAurelioIndex as BaseAurelioIndex
from gllm_pipeline.router.backend.base_adapter import BaseAdapter as BaseAdapter
from gllm_pipeline.router.preset.semantic.image_domain_specific import IMAGE_DOMAIN_SPECIFIC_ROUTES as IMAGE_DOMAIN_SPECIFIC_ROUTES
from gllm_pipeline.router.schema import ModalityType as ModalityType, RouteExamples as RouteExamples, RouterInput as RouterInput
from semantic_router import Route
from semantic_router.encoders.base import DenseEncoder
from semantic_router.index import LocalIndex
from typing import Any

AURELIO_PRESET_MAPPING: dict[tuple[ModalityType, str], dict[str, list[str]]]
DEFAULT_IMAGE_ENCODER_MODEL: str

class AurelioSimilarityAdapter(BaseAdapter):
    """Aurelio Labs semantic router backend adapter.

    This adapter integrates Aurelio Labs' semantic router library with the GLLM
    router framework, providing semantic similarity-based routing capabilities.

    Attributes:
        route_layer (SemanticRouter): The Aurelio Labs route layer that handles the routing logic.
        encoder (DenseEncoder): The dense encoder used for vectorization.
    """
    encoder: Incomplete
    route_layer: Incomplete
    def __init__(self, encoder: DenseEncoder | BaseEMInvoker, route_examples: list[Route] | RouteExamples | None = None, index: BaseAurelioIndex | LocalIndex | None = None, auto_sync: str = 'local', similarity_threshold: float = 0.5, **kwargs: Any) -> None:
        '''Initialize the Aurelio adapter.

        Args:
            encoder (DenseEncoder | BaseEMInvoker): Aurelio Labs DenseEncoder instance or EM invoker.
                If a BaseEMInvoker is provided, it will be automatically wrapped in an EMInvokerEncoder.
            route_examples (list[Route] | RouteExamples | None, optional): Route examples configuration.
                Defaults to None.
            index (BaseAurelioIndex | None, optional): A router index to retrieve routes.
                If provided, it is prioritized over `route_examples`. Defaults to None.
            auto_sync (str, optional): The auto-sync mode for the router. Defaults to "local".
            similarity_threshold (float, optional): The score threshold for the encoder when using EMInvoker.
                Only applies when encoder is a BaseEMInvoker. Otherwise, the similarity threshold should be defined
                directly when initializing the encoder. Defaults to 0.5.
            **kwargs (Any): Additional keyword arguments to pass to SemanticRouter.

        Raises:
            ValueError:
                1. If neither route_examples nor index is provided.
                2. If similarity_threshold is not between 0.0 and 1.0.
        '''
    @classmethod
    def from_file(cls, file_path: str, encoder: DenseEncoder | BaseEMInvoker, **kwargs: Any) -> AurelioSimilarityAdapter:
        """Load Aurelio adapter from JSON/YAML file.

        Args:
            file_path (str): Path to configuration file (JSON or YAML).
            encoder (DenseEncoder | BaseEMInvoker): Dense encoder or EM invoker.
            **kwargs (Any): Additional configuration parameters (override file config).

        Returns:
            AurelioSimilarityAdapter: Initialized adapter instance.

        Raises:
            FileNotFoundError: If file does not exist.
            ValueError: If file format is invalid or required fields missing.
        """
    @classmethod
    def from_preset(cls, preset_name: str, modality: str | ModalityType = ..., routes: RouteExamples | None = None, encoder: DenseEncoder | BaseEMInvoker | None = None, index: BaseAurelioIndex | LocalIndex | None = None, similarity_threshold: float = 0.5, **kwargs: Any) -> AurelioSimilarityAdapter:
        """Initialize adapter from a preset configuration.

        Separates preset data (routes) from backend initialization. If routes or encoder
        are not provided, defaults are used based on the modality.

        Args:
            preset_name (str): Name of the preset to use.
            modality (str | ModalityType): Modality type (e.g., ModalityType.IMAGE). Used to select default routes
                and encoder if not explicitly provided. Defaults to ModalityType.IMAGE.
            routes (RouteExamples | None): Optional routes dict to override preset defaults.
                Maps route names to lists of utterance strings or bytes (e.g. raw image data).
            encoder (DenseEncoder | BaseEMInvoker | None): Optional encoder to override the default CLIPEncoder.
            index (BaseAurelioIndex | None): Optional pre-built index. If provided, routes are ignored
                for index construction.
            similarity_threshold (float, optional): The score threshold for the encoder when using EMInvoker.
                Only applies when encoder is a BaseEMInvoker. Otherwise, the similarity threshold should be defined
                directly when initializing the encoder. Defaults to 0.5.
            **kwargs (Any): Additional keyword arguments passed to `AurelioSimilarityAdapter.__init__`.

        Returns:
            AurelioSimilarityAdapter: Initialized adapter instance with pre-built index.

        Raises:
            ValueError: If the modality is not supported.
        """
    async def route(self, source: RouterInput, **kwargs: Any) -> str | None:
        """Route the input using semantic similarity.

        Args:
            source (RouterInput): The input source to be routed.
            **kwargs (Any): Additional routing parameters (ignored).

        Returns:
            str | None: The name of the selected route, or None if no route matches.

        Raises:
            ValueError: If non-str or non-bytes input is provided without an `EMInvokerEncoder`.
            RuntimeError: If routing fails.
        """
