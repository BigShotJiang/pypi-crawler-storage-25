from gllm_pipeline.router.backend.native.lm_based.lm_based_adapter import NativeLMBasedAdapter as NativeLMBasedAdapter

__all__ = ['NativeLMBasedAdapter']
