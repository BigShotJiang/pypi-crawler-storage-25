from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.prompt_builder import PromptBuilder
from gllm_pipeline.router.preset.lm_based.image_domain_specific import DEFAULT_MODEL_ID as DEFAULT_MODEL_ID, IMAGE_ROUTER_SYSTEM_PROMPT as IMAGE_ROUTER_SYSTEM_PROMPT, IMAGE_ROUTER_USER_PROMPT as IMAGE_ROUTER_USER_PROMPT

def get_router_image_domain_specific(lm_invoker_kwargs: dict | None = None, prompt_builder_kwargs: dict | None = None) -> dict[str, BaseLMInvoker | PromptBuilder]:
    """Returns the domain-specific preset components for image routing.

    Returns:
        dict[str, BaseLMInvoker | PromptBuilder]: The LM invoker, prompt builder.
    """
