from enum import StrEnum
from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.utils.input_map import shallow_dump as shallow_dump
from opentelemetry import trace
from typing import Any, Final

class SpanAttributes:
    '''Semantic attribute keys for OpenTelemetry spans.

    These constants define the attribute namespace used throughout gllm-pipeline instrumentation. All keys follow the
    `gllm.*` convention for consistency with OpenTelemetry semantic conventions.

    Attributes are organized by scope:
    1. Pipeline-level: Attributes describing the overall pipeline execution
    2. Step-level: Attributes describing individual step characteristics
    3. Execution context: Attributes about the runtime environment
    4. State: Attributes describing input/output state shapes

    Examples:
        ```python
        from gllm_pipeline.observability.tracing import get_tracer, SpanAttributes

        tracer = get_tracer()
        with tracer.start_as_current_span("pipeline.invoke.my_pipeline") as span:
            span.set_attribute(SpanAttributes.PIPELINE_NAME, "my_pipeline")
            span.set_attribute(SpanAttributes.PIPELINE_STEP_COUNT, 3)
        ```
    '''
    PIPELINE_NAME: Final[str]
    PIPELINE_STEP_COUNT: Final[str]
    PIPELINE_RECURSION_LIMIT: Final[str]
    STEP_NAME: Final[str]
    STEP_TYPE: Final[str]
    STEP_HAS_CACHE: Final[str]
    STEP_ERROR_HANDLER_TYPE: Final[str]
    STEP_HAS_RETRY_POLICY: Final[str]
    THREAD_ID: Final[str]
    INPUT_STATE_KEYS: Final[str]
    OUTPUT_STATE_KEYS: Final[str]

class SpanEvents:
    '''Semantic event names for OpenTelemetry spans.

    These constants define the event namespace used throughout gllm-pipeline instrumentation. Events mark significant
    points in the execution lifecycle and provide structured logging within spans.

    Events are organized by category:
    1. Lifecycle: Step entry, exit, and error events
    2. Cache: Cache hit/miss events for steps with caching
    3. Retry: Retry attempt events for steps with retry policies
    4. State: State update events when step modifies pipeline state
    5. Condition: Condition evaluation events for conditional steps

    Examples:
        ```python
        from gllm_pipeline.observability.tracing import get_tracer, SpanEvents

        tracer = get_tracer()
        with tracer.start_as_current_span("pipeline.step.my_step") as span:
            span.add_event(SpanEvents.STEP_ENTRY)
            # ... step execution ...
            span.add_event(SpanEvents.STEP_EXIT)
        ```
    '''
    STEP_ENTRY: Final[str]
    STEP_EXIT: Final[str]
    STEP_ERROR: Final[str]
    CACHE_HIT: Final[str]
    CACHE_MISS: Final[str]
    RETRY_ATTEMPT: Final[str]
    STATE_UPDATE: Final[str]
    CONDITION_EVALUATED: Final[str]

class ErrorCategory(StrEnum):
    """Error category constants for span error recording.

    These constants define the standard error categories used throughout
    gllm-pipeline instrumentation for consistent error classification.

    Examples:
        ```python
        from gllm_pipeline.observability.tracing import set_span_error, ErrorCategory

        set_span_error(span, exception, ErrorCategory.GENERIC)
        ```
    """
    CANCELLED: str
    GENERIC: str
    INVOKER_ERROR: str
    TIMEOUT: str

def get_tracer() -> trace.Tracer:
    '''Get the gllm-pipeline tracer singleton.

    Returns a `trace.Tracer` instance for creating spans. The tracer is lazily initialized on first call and cached
    for subsequent calls using thread-safe double-checked locking.

    When no `TracerProvider` is configured, this returns a no-op tracer with zero overhead. The tracer version is
    automatically determined from package metadata, defaulting to `"0.0.0"` if the package is not installed
    (e.g., during editable installs without metadata).

    This function is thread-safe and uses double-checked locking to ensure that only one tracer instance is created
    even when called concurrently from multiple threads.

    Examples:
        ```python
        from gllm_pipeline.observability.tracing import get_tracer

        tracer = get_tracer()
        with tracer.start_as_current_span("my_span") as span:
            span.set_attribute("key", "value")
        ```

    Returns:
        trace.Tracer: Tracer instance for the gllm-pipeline instrumentation.
    '''
def set_span_error(span: trace.Span, exception: BaseException, category: ErrorCategory) -> None:
    '''Set span error status and add error event.

    This helper function standardizes error recording across pipeline and step
    execution spans. It adds a structured error event with the exception type,
    message, and category, then sets the span status to ERROR.

    Examples:
        ```python
        from gllm_pipeline.observability.tracing import get_tracer, set_span_error, ErrorCategory

        tracer = get_tracer()
        with tracer.start_as_current_span("my_operation") as span:
            try:
                # ... operation ...
            except Exception as e:
                set_span_error(span, e, ErrorCategory.GENERIC)
                raise
        ```

    Args:
        span (trace.Span): The OpenTelemetry span to set error on.
        exception (BaseException): The exception that occurred.
        category (ErrorCategory): The error category. Use `ErrorCategory` enum values
            (e.g., `ErrorCategory.GENERIC`, `ErrorCategory.CANCELLED`).

    '''
def set_span_success(span: trace.Span, result: dict[str, Any] | None, output_attr: str = ...) -> None:
    '''Set span status and exit event for successful execution.

    This helper function standardizes success recording across pipeline and step
    execution spans. It records output state keys when available and adds an
    appropriate exit event.

    Examples:
        ```python
        from gllm_pipeline.observability.tracing import get_tracer, set_span_success

        tracer = get_tracer()
        with tracer.start_as_current_span("my_operation") as span:
            result = perform_operation()
            set_span_success(span, result)
        ```

    Args:
        span (trace.Span): The OpenTelemetry span to update.
        result (dict[str, Any] | None): The execution result (dict or None).
        output_attr (str, optional): The attribute name for output state keys.
            Defaults to `SpanAttributes.OUTPUT_STATE_KEYS`.
    '''
def get_state_keys(state: PipelineState) -> str:
    '''Extract sorted comma-separated keys from state.

    This helper function extracts keys from either a dictionary or Pydantic
    BaseModel state, returning them as a sorted comma-separated string.

    Examples:
        ```python
        from gllm_pipeline.observability.tracing import get_state_keys

        state = {"user_query": "What is AI?", "context": "..."}
        keys = get_state_keys(state)  # Returns "context,user_query"
        ```

    Args:
        state (PipelineState): The pipeline state (dict or Pydantic model).

    Returns:
        str: Comma-separated sorted keys.

    '''
