from _typeshed import Incomplete
from gllm_core.schema.tool import Tool
from gllm_pipeline.alias import PipelineState as PipelineState
from gllm_pipeline.constants import ConfigKeys as ConfigKeys, StreamMode as StreamMode
from gllm_pipeline.exclusions import ExclusionManager as ExclusionManager, ExclusionSet as ExclusionSet
from gllm_pipeline.observability.tracing import ErrorCategory as ErrorCategory, SpanAttributes as SpanAttributes, get_state_keys as get_state_keys, get_tracer as get_tracer, set_span_error as set_span_error
from gllm_pipeline.pipeline.composer import Composer as Composer
from gllm_pipeline.pipeline.states import RAGState as RAGState
from gllm_pipeline.steps.pipeline_step import BasePipelineStep as BasePipelineStep
from gllm_pipeline.steps.terminator_step import TerminatorStep as TerminatorStep
from gllm_pipeline.types import CacheConfig as CacheConfig, PipelineInvocation as PipelineInvocation
from gllm_pipeline.utils.graph import create_edge as create_edge
from gllm_pipeline.utils.input_map import shallow_dump as shallow_dump
from gllm_pipeline.utils.mermaid import MERMAID_HEADER as MERMAID_HEADER, combine_mermaid_diagrams as combine_mermaid_diagrams, extract_step_diagrams as extract_step_diagrams
from gllm_pipeline.utils.schema import filter_output_by_schema as filter_output_by_schema, get_json_schema as get_json_schema, is_typeddict_or_basemodel as is_typeddict_or_basemodel, validate_schema as validate_schema
from gllm_pipeline.utils.step_execution import has_interrupt_step as has_interrupt_step
from gllm_pipeline.utils.typing_compat import is_typeddict as is_typeddict
from langgraph.graph import StateGraph
from langgraph.types import Command
from typing import Any, Callable

DEFAULT_TOOL_NAME: str
INDENTATION: str

class Pipeline:
    '''Represents a sequence of steps executed in order, forming a pipeline.

    A pipeline can have zero or more steps. When a pipeline has no steps (empty list), it acts as a
    pass-through pipeline that simply returns the input state unchanged. This is useful when using
    the pipe (|) operator to define RAG State without requiring explicit steps.

    Examples:
        # Basic pipeline with steps
        ```python
        pipeline = Pipeline([retrieval_step, generation_step, terminator_step])
        ```

        # Empty pipeline (pass-through)
        ```python
        pipeline = Pipeline([])
        pipeline = Pipeline(None)
        ```

        # Pipeline with custom state type
        ```python
        class CustomState(TypedDict):
            user_query: str
            context: str
            response: str

        pipeline = Pipeline([retrieval_step, generation_step], state_type=CustomState)
        ```

        # Named pipeline for subgraph usage
        ```python
        pipeline = Pipeline([retrieval_step, generation_step], name="rag_pipeline")
        ```

        # Pipeline with caching
        ```python
        pipeline = Pipeline(
            [retrieval_step, generation_step],
            cache=CacheConfig(store=cache_store, key_func=lambda x: x["input"]["user_query"])
        )
        ```

        # Using pipe (|) operator to combine steps
        ```python
        pipeline = retrieval_step | generation_step | terminator_step
        ```
        # Using pipe (|) operator to combine step with pipeline
        ```python
        pipeline = Pipeline([retrieval_step, generation_step]) | terminator_step
        ```
        # Using pipe (|) operator to combine pipelines
        ```python
        pipeline1 = Pipeline([retrieval_step])
        pipeline2 = Pipeline([generation_step, terminator_step])
        combined_pipeline = pipeline1 | pipeline2
        ```

        # Configure step exclusion after initialization (set-only)
        ```python
        log_step = log(name="log_step", ...)
        retrieval_step = step(name="retrieval_step", ...)
        generation_step = step(name="generation_step", ...)
        pipeline = Pipeline([log_step, retrieval_step, generation_step])
        pipeline.exclusions.exclude("log_step")  # Skip logging step
        ```

        # Configure composite step exclusion
        ```python
        log_step = log(name="log_step", ...)
        retrieval_a_step = step(name="retrieval_a_step", ...)
        retrieval_b_step = step(name="retrieval_b_step", ...)
        parallel_step = parallel(
            name="parallel_step", {"retrieval_a": retrieval_a_step, "retrieval_b": retrieval_b_step},
        )
        pipeline = Pipeline([log_step, parallel_step])
        pipeline.exclusions.exclude("parallel_step")  # Skip the entire parallel step
        pipeline.exclusions.exclude("parallel_step.retrieval_a")  # Skip retrieval_a step
        pipeline.exclusions.exclude("parallel_step.retrieval_b")  # Skip retrieval_b step
        ```

    Attributes:
        steps (list[BasePipelineStep]): List of steps to be executed in the pipeline. Can be empty
            for a pass-through pipeline.
        state_type (type): The type of state used in the pipeline. Defaults to RAGState.
        recursion_limit (int): The maximum number of steps allowed.
        name (str | None): A name for this pipeline. Used when this pipeline is included as a subgraph.
            Defaults to None, in which case the name will be "Subgraph" followed by a unique identifier.
        exclusions (ExclusionManager): The exclusion manager for this pipeline.

    '''
    name: Incomplete
    steps: Incomplete
    recursion_limit: Incomplete
    checkpointer: Incomplete
    interrupt_before: Incomplete
    interrupt_after: Incomplete
    def __init__(self, steps: list[BasePipelineStep] | None = None, state_type: type[Any] = ..., input_type: type[Any] | None = None, output_type: type[Any] | None = None, context_schema: type[Any] | None = None, recursion_limit: int = 30, name: str | None = None, cache: CacheConfig | None = None, checkpointer: Any = None, interrupt_before: list[str] | str | None = None, interrupt_after: list[str] | str | None = None) -> None:
        '''Initializes the Pipeline with the given steps and state type.

        Args:
            steps (list[BasePipelineStep] | None, optional): List of steps to be executed in the pipeline.
                Defaults to None, in which case the steps will be `[]` and simply returns the input state unchanged.
            state_type (type, optional): The type of pipeline\'s overall internal state.
                Could be a TypedDict or a Pydantic BaseModel. Defaults to RAGState.
            input_type (type | None, optional): The type of pipeline\'s input state.
                This state should be compatible with the pipeline\'s `state_type`.
                Could be a TypedDict or a Pydantic BaseModel. Defaults to None, in which case the input state type
                will be the same as the pipeline\'s `state_type`.
            output_type (type | None, optional): The type of pipeline\'s output state.
                This state should be compatible with the pipeline\'s `state_type`.
                Could be a TypedDict or a Pydantic BaseModel. Defaults to None, in which case the output state type
                will be the same as the pipeline\'s `state_type`.
            context_schema (type | None, optional): The type of pipeline\'s runtime context.
                Defaults to None, in which case no context schema will be used.
            recursion_limit (int, optional): The maximum number of steps allowed. Defaults to 30.
            name (str | None, optional): A name for this pipeline. Used when this pipeline is included as a subgraph.
                Defaults to None, in which case the name will be "Subgraph" followed by a unique identifier.
            cache (CacheConfig | None, optional): Configuration for the cache store including the cache
                store instance and its settings. Defaults to None, in which case no caching will be used.
            checkpointer (Any, optional): A LangGraph checkpoint saver instance (e.g., MemorySaver) to persist state
                and enable resuming from interruptions. Defaults to None.
            interrupt_before (list[str] | str | None, optional): Name(s) of steps to pause before executing.
                Requires a `checkpointer` to save state. Defaults to None.
            interrupt_after (list[str] | str | None, optional): Name(s) of steps to pause after executing.
                Requires a `checkpointer` to save state. Defaults to None.
        '''
    @property
    def state_type(self) -> type[Any]:
        """The current state type of the pipeline.

        Returns:
            type[Any]: The current state type.
        """
    @state_type.setter
    def state_type(self, new_state_type: type[Any]) -> None:
        """Sets a new state type for the pipeline.

        Args:
            new_state_type (type[Any]): The new state type to set.

        Note:
            This operation will rebuild the pipeline graph if it has already been initialized, which can be
            computationally expensive for complex pipelines.
            It is recommended to set the state type before building the pipeline graph.
        """
    @property
    def graph(self) -> StateGraph | None:
        """The graph representation of the pipeline.

        If the graph doesn't exist yet, it will be built automatically.

        Returns:
            StateGraph | None: The graph representation of the pipeline, or None if the pipeline has no steps.
        """
    @property
    def exclusions(self) -> ExclusionManager:
        """Get the exclusion manager for this pipeline.

        Returns:
            ExclusionManager: The exclusion manager for this pipeline.
        """
    @property
    def composer(self) -> Composer:
        """Get a Composer instance that manages this pipeline.

        The Composer provides a fluent API for building pipelines by chaining
        step-adding methods. It allows for easy composition of pipeline steps
        in a readable, chainable manner.

        Returns:
            Composer: A composer instance that manages this pipeline.
        """
    def build_graph(self) -> None:
        """Builds the graph representation of the pipeline by connecting the steps."""
    def clear(self) -> None:
        """Clears the pipeline by resetting steps, graph, and app to their initial state.

        This method resets the pipeline to an empty state, clearing all steps and
        invalidating any built graph or compiled app. Useful for reusing a pipeline
        instance with different configurations.
        """
    async def invoke(self, initial_state: PipelineState | Command | None = None, config: dict[str, Any] | None = None, thread_id: str | None = None, context: dict[str, Any] | None = None, interrupt_before: list[str] | str | None = None, interrupt_after: list[str] | str | None = None) -> dict[str, Any]:
        '''Runs the pipeline asynchronously with the given initial state and configuration.

        Args:
            initial_state (PipelineState | None, optional): The initial state to start the pipeline with.
                This initial state should comply with the state type of the pipeline. Can be None
                or a Command to resume.
            config (dict[str, Any], optional): Additional configuration for the pipeline. Should only contain
                configuration flags like \'debug_state\'. User-defined config should not
                have "langgraph_" prefix as it should be reserved for internal use. Runtime context
                should be passed via the \'context\' parameter instead. Defaults to None.
            thread_id (str | None, optional): The thread ID for this specific pipeline invocation. This will be passed
                in the invocation_config.configurable when invoking the pipeline. Useful for checkpointing and
                tracking related invocations. Defaults to None.
            context (dict[str, Any], optional): Runtime context for the pipeline execution. This contains
                user-defined data that steps might need during execution. When not provided, will fall back
                to using \'config\' for backwards compatibility. Defaults to None.
            interrupt_before (list[str] | str | None, optional): Name(s) of step nodes to pause execution
                before.  Passed to LangGraph at runtime — no graph recompilation needed.
                Requires a checkpointer. Defaults to None.
            interrupt_after (list[str] | str | None, optional): Name(s) of step nodes to pause execution
                after.  Passed to LangGraph at runtime — no graph recompilation needed.
                Requires a checkpointer. Defaults to None.

        Returns:
            dict[str, Any]: The final state after the pipeline execution.
                If \'debug_state\' is set to True in the config, the state logs will be included
                in the final state with the key \'__state_logs__\'.

        Raises:
            BaseInvokerError: If an error occurs during LM invocation.
            asyncio.CancelledError: If the execution is cancelled, preserved with added context.
            TimeoutError: If the execution times out, preserved with added context.
            RuntimeError: If an error occurs during pipeline execution. If the error is due to a step
                execution, the step name will be included in the error message.
        '''
    def as_tool(self, description: str | None = None, input_schema: type[Any] | None = None, output_schema: type[Any] | None = None, input_transform: Callable[[dict[str, Any]], dict[str, Any]] | None = None, output_transform: Callable[[dict[str, Any]], Any] | None = None) -> Tool:
        '''Convert the pipeline to a Tool instance.

        This method allows a Pipeline instance to be used as a tool, with flexible input/output
        transformation support. The pipeline must have an input_type defined unless a custom
        input_schema is provided with input_transform.

        Note that if the input_schema is not provided, the input schema will fall back to the
        pipeline\'s input_type and context_schema. In this case, the input_transform is ignored.

        Examples:
            ```python
            # Default behavior with context schema
            class InputState(TypedDict):
                user_query: str

            class ContextSchema(TypedDict):
                session_id: str

            pipeline = Pipeline(
                [retrieval_step, generation_step],
                input_type=InputState,
                context_schema=ContextSchema,
                name="rag_pipeline"
            )
            tool = pipeline.as_tool()
            result = await tool.invoke(
                input={"user_query": "What is AI?"},
                context={"session_id": "abc123"}
            )

            # Custom input schema with transforms
            class ToolInput(TypedDict):
                message: str
                limit: int

            def pre_transform(data):
                return {
                    "input": {"user_query": data["message"]},
                    "config": {"max_results": data["limit"]}
                }

            def post_transform(data):
                return {"processed": True, "result": data}

            tool = pipeline.as_tool(
                input_schema=ToolInput,
                input_transform=pre_transform,
                output_transform=post_transform
            )
            result = await tool.invoke(message="What is AI?", limit=5)
            ```

        Args:
            description (str | None, optional): Optional description to associate with the tool.
                Defaults to None, in which case a description will be generated automatically.
            input_schema (type[Any] | None, optional): Custom input schema for
                the tool (TypedDict or Pydantic BaseModel). If provided,
                input_transform must also be provided. Defaults to None.
            output_schema (type[Any] | None, optional): Custom output schema for
                the tool (TypedDict or Pydantic BaseModel). If provided,
                the output will be filtered to match this schema after applying
                output_transform. If not provided, uses the pipeline\'s output_type. Defaults to None.
            input_transform (Callable | None, optional): Function to transform tool input
                to pipeline invocation format. Must return dict with \'input\' key and optional
                \'config\' key. Required if input_schema is provided. Defaults to None.
            output_transform (Callable | None, optional): Function to transform pipeline
                output before returning from tool. Can change the output type. Defaults to None.

        Returns:
            Tool: A Tool instance that wraps the pipeline.

        Raises:
            ValueError: If the pipeline does not have an input schema defined and no custom
                input_schema is provided, or if input_schema is provided without
                input_transform, or if input_schema/output_schema is not a TypedDict or BaseModel.

        '''
    def get_mermaid_diagram(self) -> str:
        """Generate a Mermaid diagram representation of the pipeline.

        Returns:
            str: The complete Mermaid diagram representation.
        """
    def __or__(self, other: Pipeline | BasePipelineStep) -> Pipeline:
        """Combines the current pipeline with another pipeline or step using the '|' operator.

        When combining two pipelines, the state types must match.

        Args:
            other (Pipeline | BasePipelineStep): The other pipeline or step to combine with.

        Returns:
            Pipeline: A new pipeline consisting of the combined steps.

        Raises:
            ValueError: If the state types of the pipelines do not match.
        """
    def __lshift__(self, other: Pipeline | BasePipelineStep) -> Pipeline:
        """Includes another pipeline or step using the '<<' operator.

        This allows for easy composition where:
        - If 'other' is a Pipeline: it becomes a subgraph within this pipeline
        - If 'other' is a BasePipelineStep: it's added directly to this pipeline's steps

        The syntax `pipeline1 << pipeline2` visually indicates pipeline2 being inserted into pipeline1.
        The syntax `pipeline << step` adds the step to the pipeline.

        Args:
            other (Pipeline | BasePipelineStep): The pipeline to include as a subgraph or step to add.

        Returns:
            Pipeline: A new pipeline with the other pipeline included as a subgraph step or with the step added.
        """
    def __rshift__(self, other: Pipeline | BasePipelineStep) -> Pipeline:
        """Includes this pipeline as a subgraph in another context using the '>>' operator.

        This allows for easy composition where:
        - If 'other' is a Pipeline: this pipeline becomes a subgraph within the other pipeline
        - If 'other' is a BasePipelineStep: a new pipeline is created with the step, and this pipeline
          is included as a subgraph within that pipeline

        The syntax `pipeline1 >> pipeline2` embeds pipeline1 as a subgraph within pipeline2
        (equivalent to pipeline2 << pipeline1).
        The syntax `pipeline >> step` creates a new pipeline with the step, and includes this pipeline
        as a subgraph within that pipeline.

        Args:
            other (Pipeline | BasePipelineStep): The pipeline to include this pipeline in as a subgraph,
                or a step to create a new pipeline with.

        Returns:
            Pipeline: A new pipeline with this pipeline included as a subgraph.
        """
