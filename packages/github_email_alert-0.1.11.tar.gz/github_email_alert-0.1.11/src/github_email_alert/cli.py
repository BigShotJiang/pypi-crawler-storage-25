"""Command-line interface for GitHub Email Alert.

This module provides the CLI entry point for sending GitHub event notifications
via email. It parses command-line arguments and environment variables to
configure and send email alerts.
"""

import os
import sys
import argparse
from typing import List, Optional

from . import __version__
from .emailer import send_email
from .templates import build_email


def parse_list(value: Optional[str]) -> List[str]:
    """Parse a comma-separated string into a list of trimmed values.

    Converts a comma-separated string (e.g., "email1@example.com, email2@example.com")
    into a list of trimmed strings, filtering out empty values.

    Args:
        value: Comma-separated string to parse, or None/empty string.

    Returns:
        List of trimmed strings. Returns empty list if input is None or empty.

    Example:
        >>> parse_list("email1@example.com, email2@example.com")
        ['email1@example.com', 'email2@example.com']
        >>> parse_list("")
        []
        >>> parse_list(None)
        []
    """
    if not value:
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def main() -> None:
    """Main CLI entry point for GitHub Email Alert.

    Parses command-line arguments and environment variables, then sends
    an email notification for the specified GitHub event.

    Command-line arguments:
        branch_ref: Name of the branch that triggered the event
        event_type: Type of GitHub event (branch_create, branch_delete, new_pr, merge_pr, conflict)

    Environment variables (required):
        EMAIL_USER: SMTP email address for authentication
        EMAIL_PASS: SMTP password or app-specific password
        EMAIL_TO: Comma-separated list of recipient email addresses

    Environment variables (optional):
        EMAIL_FROM: Email address to use as sender (default: EMAIL_USER)
        EMAIL_CC: Comma-separated list of CC email addresses
        ATTACHMENT_PATHS: Comma-separated list of file paths to attach
        SMTP_HOST: SMTP server hostname (default: smtp.gmail.com)
        SMTP_PORT: SMTP server port (default: 587)
        GITHUB_ACTOR: GitHub username who triggered the event (default: "Unknown")
        PR_TITLE: Pull request title (default: "N/A")
        BASE_REF: Target/base branch name (default: "main")
        REPO_NAME: Repository name (default: "Unknown")
        CONFLICT_FILES: Comma-separated list of conflicting files (for conflict events)

    Raises:
        ValueError: If required environment variables are missing.
        SystemExit: If email sending fails or invalid arguments are provided.

    Example:
        >>> # Set environment variables
        >>> os.environ["EMAIL_USER"] = "sender@example.com"
        >>> os.environ["EMAIL_PASS"] = "password"
        >>> os.environ["EMAIL_TO"] = "recipient@example.com"
        >>> # Run: github-email-alert feature/login new_pr
    """
    # Set up argument parser
    parser = argparse.ArgumentParser(
        description="Send email alerts for GitHub events",
        epilog=(
            "Required environment variables: EMAIL_USER, EMAIL_PASS, EMAIL_TO\n"
            "See README.md for complete documentation and examples."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show program's version number and exit",
    )
    parser.add_argument(
        "branch_ref",
        help="Name of the branch that triggered the event (e.g., 'feature/login')",
    )
    parser.add_argument(
        "event_type",
        choices=["branch_create", "branch_delete", "new_pr", "merge_pr", "conflict"],
        help="Type of GitHub event to notify about",
    )

    args = parser.parse_args()

    # Build context dictionary from environment variables and arguments
    context = {
        "actor": os.getenv("GITHUB_ACTOR", "Unknown"),
        "pr_title": os.getenv("PR_TITLE", "N/A"),
        "branch_ref": args.branch_ref,
        "base_ref": os.getenv("BASE_REF", "main"),
        "repo_name": os.getenv("REPO_NAME", "Unknown"),
        "conflict_files": os.getenv("CONFLICT_FILES", ""),
    }

    # Get email configuration from environment variables
    email_user = os.getenv("EMAIL_USER")
    email_pass = os.getenv("EMAIL_PASS")
    email_from = os.getenv("EMAIL_FROM")
    email_to = parse_list(os.getenv("EMAIL_TO"))
    email_cc = parse_list(os.getenv("EMAIL_CC"))
    attachment_paths = parse_list(os.getenv("ATTACHMENT_PATHS"))

    # Validate required environment variables
    if not email_user:
        print("Error: EMAIL_USER environment variable is required", file=sys.stderr)
        sys.exit(1)
    if not email_pass:
        print("Error: EMAIL_PASS environment variable is required", file=sys.stderr)
        sys.exit(1)
    if not email_to:
        print("Error: EMAIL_TO environment variable is required", file=sys.stderr)
        sys.exit(1)

    # Generate email subject and body from template
    try:
        subject, plain_body, html_body = build_email(args.event_type, context)
    except Exception as e:
        print(f"Error building email template: {e}", file=sys.stderr)
        sys.exit(1)

    # Send the email
    try:
        send_email(
            smtp_host=os.getenv("SMTP_HOST", "smtp.gmail.com"),
            smtp_port=int(os.getenv("SMTP_PORT", "587")),
            email_user=email_user,
            email_pass=email_pass,
            to_list=email_to,
            cc_list=email_cc,
            subject=subject,
            body=html_body,
            email_from=email_from,
            plain_body=plain_body,
            attachment_paths=attachment_paths if attachment_paths else None,
        )
        print(f"Email sent successfully for {args.event_type} event on branch {args.branch_ref}")
    except ValueError as e:
        # Handle Unicode safely for error messages
        error_msg = str(e).encode('ascii', errors='replace').decode('ascii')
        print(f"Error: {error_msg}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        # Handle Unicode safely for error messages
        error_msg = str(e).encode('ascii', errors='replace').decode('ascii')
        print(f"Error sending email: {error_msg}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
