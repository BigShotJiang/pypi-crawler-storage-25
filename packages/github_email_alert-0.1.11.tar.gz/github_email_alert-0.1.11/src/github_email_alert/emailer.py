"""Email sending functionality for GitHub email alerts.

This module provides functionality to send HTML emails via SMTP,
specifically designed for GitHub Actions notifications.
"""

import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Optional


def send_email(
    smtp_host: str,
    smtp_port: int,
    email_user: str,
    email_pass: str,
    to_list: List[str],
    cc_list: List[str],
    subject: str,
    body: str,
    email_from: Optional[str] = None,
    plain_body: Optional[str] = None,
    attachment_paths: Optional[List[str]] = None,
) -> None:
    """Send a multipart email (plain text + HTML) via SMTP with optional attachments.

    Creates and sends a multipart email message with UTF-8 encoding using the provided
    SMTP configuration. Supports both TO and CC recipients, plain text and HTML versions,
    and file attachments. Uses TLS encryption for secure transmission.

    Args:
        smtp_host: SMTP server hostname (e.g., 'smtp.gmail.com').
        smtp_port: SMTP server port number (typically 587 for TLS).
        email_user: Email address to authenticate with SMTP server.
        email_pass: Password or app-specific password for SMTP authentication.
        to_list: List of primary recipient email addresses.
        cc_list: List of CC recipient email addresses (can be empty).
        subject: Email subject line.
        body: HTML email body content.
        email_from: Email address to use as sender. If None, uses email_user.
        plain_body: Plain text version of the email body. If provided, creates multipart email.
        attachment_paths: List of file paths to attach to the email.

    Raises:
        smtplib.SMTPException: If SMTP server connection or authentication fails.
        smtplib.SMTPRecipientsRefused: If any recipient addresses are invalid.
        ValueError: If to_list is empty.
        FileNotFoundError: Warning if attachment file not found (continues without it).

    Example:
        >>> send_email(
        ...     smtp_host="smtp.gmail.com",
        ...     smtp_port=587,
        ...     email_user="auth@example.com",
        ...     email_pass="password",
        ...     to_list=["recipient@example.com"],
        ...     cc_list=["cc@example.com"],
        ...     subject="Test Email",
        ...     body="<html><body><h1>Hello</h1></body></html>",
        ...     plain_body="Hello",
        ...     email_from="sender@example.com",
        ...     attachment_paths=["report.pdf"]
        ... )
    """
    # Validate that at least one recipient is provided
    if not to_list:
        raise ValueError("At least one recipient email address is required")

    # Use email_from if provided, otherwise fall back to email_user
    sender_email = email_from if email_from else email_user

    # Create multipart message container
    msg = MIMEMultipart()
    msg["From"] = sender_email
    msg["To"] = ", ".join(to_list)

    # Add CC recipients if provided
    if cc_list:
        msg["Cc"] = ", ".join(cc_list)

    msg["Subject"] = subject

    # If both plain and HTML bodies are provided, create multipart/alternative
    if plain_body:
        msg_alternative = MIMEMultipart("alternative")
        # Attach plain text version with UTF-8 encoding
        msg_alternative.attach(MIMEText(plain_body, "plain", "utf-8"))
        # Attach HTML version with UTF-8 encoding
        msg_alternative.attach(MIMEText(body, "html", "utf-8"))
        msg.attach(msg_alternative)
    else:
        # Only HTML body provided - attach with UTF-8 encoding
        msg.attach(MIMEText(body, "html", "utf-8"))

    # Attach files if provided
    if attachment_paths:
        for attachment_path in attachment_paths:
            try:
                with open(attachment_path, "rb") as attachment:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(attachment.read())
                    encoders.encode_base64(part)
                    filename = os.path.basename(attachment_path)
                    part.add_header(
                        "Content-Disposition",
                        f"attachment; filename= {filename}",
                    )
                    msg.attach(part)
            except FileNotFoundError:
                print(f"Warning: Attachment file not found: {attachment_path}")
            except Exception as e:
                print(f"Warning: Failed to attach file {attachment_path}. Error: {str(e)}")

    # Combine all recipients for sending
    recipients = to_list + cc_list

    # Connect to SMTP server and send email
    with smtplib.SMTP(smtp_host, smtp_port) as server:
        # Enable TLS encryption
        server.starttls()
        # Authenticate with SMTP server
        server.login(email_user, email_pass)
        # Send the email to all recipients
        server.sendmail(sender_email, recipients, msg.as_string())
