"""Email template generation for GitHub event notifications.

This module provides functionality to generate HTML email templates
for various GitHub events such as branch creation, PR merges, and conflicts.
"""

import re
from typing import Dict, Tuple


# Supported event types
SUPPORTED_EVENTS = {
    "branch_create",
    "branch_delete",
    "new_pr",
    "merge_pr",
    "conflict",
}

# Event types that don't have a PR title
EVENTS_WITHOUT_TITLE = {"branch_create", "branch_delete"}


def build_email(event_type: str, context: Dict[str, str]) -> Tuple[str, str, str]:
    """Build email subject, plain text body, and HTML body for a GitHub event.

    Generates a formatted multipart email with subject line, plain text version,
    and HTML version based on the event type and provided context information.

    Args:
        event_type: Type of GitHub event. Supported values:
            - 'branch_create': Branch created event
            - 'branch_delete': Branch deleted event
            - 'new_pr': New pull request created
            - 'merge_pr': Pull request merged
            - 'conflict': Merge conflict detected
        context: Dictionary containing event context with keys:
            - 'actor': GitHub username who triggered the event
            - 'pr_title': Pull request title (optional for branch events)
            - 'branch_ref': Source branch name
            - 'base_ref': Target/base branch name (optional)
            - 'repo_name': Repository name
            - 'conflict_files': Comma-separated list of conflicting files (optional, for conflict events)

    Returns:
        Tuple[str, str, str]: A tuple containing (subject, plain_body, html_body).
            - subject: Email subject line with emoji and event info
            - plain_body: Plain text email body
            - html_body: Complete HTML email body

    Example:
        >>> context = {
        ...     "actor": "john_doe",
        ...     "pr_title": "Add new feature",
        ...     "branch_ref": "feature/login",
        ...     "base_ref": "main",
        ...     "repo_name": "my-repo"
        ... }
        >>> subject, plain, html = build_email("new_pr", context)
        >>> print(subject)
        🆕 [NEW PR] Add new feature
    """
    # Extract context values with defaults
    actor = context.get("actor", "Unknown")
    pr_title = context.get("pr_title", "")
    branch_ref = context.get("branch_ref", "Unknown")
    base_ref = context.get("base_ref", "")
    repo_name = context.get("repo_name", "Unknown")
    conflict_files = context.get("conflict_files", "")

    # Email template configurations for each event type
    templates: Dict[str, Dict[str, str]] = {
        "branch_create": {
            "subject": f"🆕 [BRANCH CREATED] {branch_ref}",
            "header": "Branch Created",
            "color": "#0076D7",  # Blue
        },
        "branch_delete": {
            "subject": f"⚠️ [BRANCH DELETED] {branch_ref}",
            "header": "Branch Deleted",
            "color": "#DC3545",  # Red
        },
        "new_pr": {
            "subject": f"🆕 [NEW PR] {pr_title}",
            "header": "New Pull Request Created",
            "color": "#0076D7",  # Blue
        },
        "merge_pr": {
            "subject": f"✅ [MERGED PR] {pr_title}",
            "header": "Pull Request Merged",
            "color": "#28A745",  # Green
        },
        "conflict": {
            "subject": f"⚠️ [CONFLICT] {branch_ref}",
            "header": "Merge Conflict Detected",
            "color": "#DC3545",  # Red
        },
    }

    # Get template for the event type
    template = templates.get(event_type)

    # Return test template if event type is not recognized
    if not template:
        return f"[TEST] {event_type}", "Test Email", "<h2>Test Email</h2>"

    # Build plain text body sections
    plain_sections = []
    plain_sections.append(f"{template['header']}\n{'=' * len(template['header'])}\n")
    
    # Build HTML body sections
    html_sections = []

    # Actor information (always included)
    plain_sections.append(f"User: {actor}")
    html_sections.append(f"<p><strong>User:</strong> {actor}</p>")

    # PR title (only for PR-related events, not branch events)
    if event_type not in EVENTS_WITHOUT_TITLE and pr_title:
        plain_sections.append(f"Title: {pr_title}")
        html_sections.append(f"<p><strong>Title:</strong> {pr_title}</p>")

    # Source branch (always included)
    plain_sections.append(f"Source Branch: {branch_ref}")
    html_sections.append(f"<p><strong>Source Branch:</strong> {branch_ref}</p>")

    # Target branch (optional, only if provided)
    if base_ref:
        plain_sections.append(f"Target Branch: {base_ref}")
        html_sections.append(f"<p><strong>Target Branch:</strong> {base_ref}</p>")

    # Repository name (always included)
    plain_sections.append(f"Repository: {repo_name}")
    html_sections.append(f"<p><strong>Repository:</strong> {repo_name}</p>")

    # Conflict files (only for conflict events, if provided)
    if event_type == "conflict" and conflict_files:
        # Check if it's a simple comma-separated list or a full message
        if ":" in conflict_files or ("." in conflict_files and " " in conflict_files):
            # It's a message format - add line breaks for better readability
            formatted_message = conflict_files
            
            # Plain text version
            plain_formatted = formatted_message.replace(": ", ":\n")
            plain_formatted = re.sub(r'\. ([A-Z])', r'.\n\n\1', plain_formatted)
            plain_formatted = re.sub(r' ([Pp]lease)', r'\n\n\1', plain_formatted)
            plain_sections.append(f"\nConflicting Files:\n{plain_formatted}")
            
            # HTML version
            html_formatted = formatted_message.replace(": ", ":<br>")
            html_formatted = re.sub(r'\. ([A-Z])', r'.<br><br>\1', html_formatted)
            html_formatted = re.sub(r' ([Pp]lease)', r'<br><br>\1', html_formatted)
            html_sections.append(f"<p><strong>Conflicting Files:</strong></p><p>{html_formatted}</p>")
        else:
            # Simple comma-separated list - format as bullet points
            files_list = [f.strip() for f in conflict_files.split(",") if f.strip()]
            if files_list:
                # Plain text version
                plain_files = "\n".join([f"  - {file}" for file in files_list])
                plain_sections.append(f"\nConflicting Files:\n{plain_files}")
                
                # HTML version
                files_html = "<ul>" + "".join([f"<li>{file}</li>" for file in files_list]) + "</ul>"
                html_sections.append(f"<p><strong>Conflicting Files:</strong></p>{files_html}")

    # Build complete plain text email body
    plain_body = "\n".join(plain_sections)
    plain_body += "\n\n" + "-" * 40 + "\nAutomated GitHub Notification"

    # Build complete HTML email body
    html_body = f"""<html>
<body>
<h2 style="color:{template['color']};">{template['header']}</h2>
{''.join(html_sections)}
<hr>
<p><em>Automated GitHub Notification</em></p>
</body>
</html>"""

    return template["subject"], plain_body, html_body
