"""
langgraph-stream-parser: Universal parser for LangGraph streaming outputs.

This package provides a typed interface for parsing streaming outputs from
LangGraph agents, normalizing the complex output shapes into consistent,
typed event objects.

Basic Usage:
    from langgraph_stream_parser import StreamParser
    from langgraph_stream_parser.events import ContentEvent, InterruptEvent

    parser = StreamParser()

    for event in parser.parse(graph.stream(input, stream_mode="updates")):
        match event:
            case ContentEvent(content=text):
                print(text, end="")
            case InterruptEvent(action_requests=actions):
                # Handle human-in-the-loop
                ...

Legacy Dict-Based API:
    from langgraph_stream_parser import stream_graph_updates

    for update in stream_graph_updates(agent, input_data, config=config):
        if "chunk" in update:
            print(update["chunk"], end="")
        elif update.get("status") == "interrupt":
            # Handle interrupt
            ...
"""
from .parser import StreamParser
from .events import (
    ContentEvent,
    ToolCallStartEvent,
    ToolCallEndEvent,
    ToolExtractedEvent,
    InterruptEvent,
    StateUpdateEvent,
    UsageEvent,
    CustomEvent,
    ValuesEvent,
    DebugEvent,
    CompleteEvent,
    ErrorEvent,
    StreamEvent,
    event_to_dict,
)
from .extractors.base import ToolExtractor
from .extractors.builtins import ThinkToolExtractor, TodoExtractor, DisplayInlineExtractor
from .resume import create_resume_input, prepare_agent_input
from .compat import (
    stream_graph_updates,
    astream_graph_updates,
    resume_graph_from_interrupt,
    aresume_graph_from_interrupt,
)

__version__ = "0.1.7"

__all__ = [
    # Main parser
    "StreamParser",
    # Event types
    "ContentEvent",
    "ToolCallStartEvent",
    "ToolCallEndEvent",
    "ToolExtractedEvent",
    "InterruptEvent",
    "StateUpdateEvent",
    "UsageEvent",
    "CustomEvent",
    "ValuesEvent",
    "DebugEvent",
    "CompleteEvent",
    "ErrorEvent",
    "StreamEvent",
    # Extractors
    "ToolExtractor",
    "ThinkToolExtractor",
    "TodoExtractor",
    "DisplayInlineExtractor",
    # Resume utilities
    "create_resume_input",
    "prepare_agent_input",
    # Serialization
    "event_to_dict",
    # Legacy/compat functions
    "stream_graph_updates",
    "astream_graph_updates",
    "resume_graph_from_interrupt",
    "aresume_graph_from_interrupt",
]
