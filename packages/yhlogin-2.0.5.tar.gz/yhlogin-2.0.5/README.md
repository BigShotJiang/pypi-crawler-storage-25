# yhlogin

永辉统一身份认证登录工具，支持多服务登录和配置管理。

## 安装

```bash
pip install yhlogin
```

## CLI 使用

### 登录命令

登录后返回带登录信息的 url、cookis、其他Service特定的信息

```bash
# 基本用法（使用保存的配置）
yhlogin login BigData

# 指定所有参数
yhlogin login BigData <username> <password> <otp_key>
```

**可用服务：**

使用 `yhlogin services` 查看所有可用服务及简写：

```bash
yhlogin services
```

输出示例：

```text
可用服务列表:
--------------------------------------------------
  BigData         - 数据中台                 简写：bigdata, bd
  Olap            - OLAP                 简写：olap, o
  YhBi            - YHBI                 简写：yhbi, bi
--------------------------------------------------
共 3 个可用服务
使用简写或完整类名进行登录，例如：yhlogin login bd 或 yhlogin login BigData
```

登录时可使用服务名称或简写：

```bash
# 使用简写
yhlogin login bd
yhlogin login bi
yhlogin login olap

# 使用完整名称
yhlogin login BigData
yhlogin login YhBi
yhlogin login Olap

# 指定所有参数
yhlogin login BigData <username> <password> <otp_key>
```

### 配置管理

配置保存在 XDG 规范目录：

- macOS/Linux: `~/.config/yhlogin/config.json`
- Windows: `%APPDATA%/yhlogin/config.json`

```bash
# 保存配置
yhlogin config set --username <用户名> --password <密码> --otp-key <OTP 密钥>

# 查看配置
yhlogin config show

# 清除配置
yhlogin config clear
```

## Python API 使用

### v2 版本（推荐）

#### 同步方式

```python
from yhlogin import Yhlogin
from yhlogin.service import BigData, YhBi

yh = Yhlogin()
result = yh.login(
    username="your_username",
    password="your_password",
    otp_key="your_otp_key",
    service=BigData,  # 或 YhBi
    skip_ad=True,     # 是否绕域限制，默认 True
)
print(result)
```

#### 异步方式

```python
import asyncio
from yhlogin import Yhlogin
from yhlogin.service import BigData, YhBi

async def main():
    yh = Yhlogin()
    result = await yh.login_async(
        username="your_username",
        password="your_password",
        otp_key="your_otp_key",
        service=BigData,  # 或 YhBi
        skip_ad=True,     # 是否绕过域限制，默认 True
    )
    print(result)

asyncio.run(main())
```

### v1 版本（旧版，兼容用）

v1 版本的 `login` 方法使用装饰器自动判断同步/异步调用方式：

```python
from yhlogin.v1 import Yhlogin

yh = Yhlogin()

# 同步调用
yh.login(
    username="your_username",
    password="your_password",
    otp_key="your_otp_key",
    service="https://bigdata.yonghui.cn",  # 直接传入服务 URL
    skip_ad=True,
)

# 获取结果
print(yh.url)      # 登录后的 URL
print(yh.cookies)  # 登录后的 Cookies

# 异步调用（在异步上下文中）
await yh.login(
    username="your_username",
    password="your_password",
    otp_key="your_otp_key",
    service="https://bigdata.yonghui.cn",
    skip_ad=True,
)
```

**v1 与 v2 的主要区别：**

- v1: `service` 参数为字符串 URL，登录后结果保存在实例的 `url` 和 `cookies` 属性
- v2: `service` 参数为 Service 类或字符串 URL，登录后返回字典包含结果

## 版本更新

### 2.0.5

- CLI 命令执行后返回正确的 Exit code（成功返回 0，失败返回 1）

### 2.0.2

- 新增 `yhlogin services` 命令，查看可用服务列表及简写
- 登录命令支持服务简写（如 `bd` 代替 `BigData`）
- 动态发现 service 模块中的 Service 子类

### 2.0

- 新增 CLI 登录功能（`login`）
- 新增 CLI 配置管理功能（`config set/show/clear`）
- CLI 支持保存用户名、密码、OTP 密钥
- CLI 登录命令支持使用保存的配置
- 调整 CLI 参数顺序，service 放在第一位
- 同步函数和异步函数分离

### 1.0.13

- 修复部分问题

### 1.0.10

- 修复部分问题

### 1.0.9

- 修复部分问题

### 1.0.7

- 修复不跳过域登录失败问题

### 1.0.5

- login 支持使用同步、异步 2 种方式调用
