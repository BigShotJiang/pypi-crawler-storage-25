import logging
import ssl

import httpx
import pyotp
from tenacity import retry, stop_after_attempt
from .service import Service

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)

logger.setLevel(logging.INFO)


class Yhlogin:
    retry_num = 1

    def __init__(self) -> None:
        self.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"

        # YHBI的SSL原因，需配置
        ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        ctx.options |= 0x4  # 启用 OP_LEGACY_SERVER_CONNECT
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        self.transport = httpx.HTTPTransport(verify=ctx)
        self.async_transport = httpx.AsyncHTTPTransport(verify=ctx)

    def _get_e1s1_data(self, username: str, password: str) -> dict[str, object]:
        return {
            "flag": 1,
            "username": username,
            "password": password,
            "phoneNum": None,
            "captcha": None,
            "sourceType": 1,
            "execution": "e2s1",
            "_eventId": "submit",
            "geolocation": None,
        }

    def _get_e1s2_data(self, username: str, otp_key: str) -> dict[str, object]:
        dynamic_password = pyotp.TOTP(otp_key).now()
        return {
            "flag": 1,
            "token": dynamic_password,
            "username": username,
            "password": None,
            "phoneNum": None,
            "captcha": None,
            "sourceType": 1,
            "execution": "e2s2",
            "_eventId": "submit",
            "geolocation": None,
        }

    @retry(stop=stop_after_attempt(retry_num))
    def login(
        self,
        username: str,
        password: str,
        otp_key: str,
        service: type[Service] | str,
        skip_ad: bool = True,
    ) -> dict[str, object]:
        # 如果传入的是字符串，直接使用；如果是 Service 类或者子类，使用其 SERVICE_URL 属性
        if isinstance(service, str):
            service_url = service
            service = Service
        elif isinstance(service, type) and issubclass(service, Service):
            service_url = service.SERVICE_URL
        else:
            raise ValueError("service必须是字符串或Service的子类")

        skip_ad_service = "https://oa"

        target_url = service_url
        service_url = skip_ad_service if skip_ad else service_url
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": self.UserAgent,
        }

        with httpx.Client(transport=self.transport) as client:
            response = client.get(
                url=target_url, headers=headers, follow_redirects=True  # type: ignore
            )
            target_login_url = response.url.__str__()
            login_url = target_login_url.split("?")[0]

            # 使用跳过域网址
            if skip_ad:
                url = f"{login_url}?service={service_url}"
            else:
                url = target_login_url
            e1s1_data = self._get_e1s1_data(username, password)
            # 原因不明，就是要get，不然没办法登录
            client.get(url=url, headers=headers)
            response = client.post(url=url, headers=headers, data=e1s1_data)
            res_text = response.text
            res_status_code = response.status_code

            # 如果status_code是401则需要填otp
            if res_status_code == 401:
                if res_text.find('id = "dynamicPassword"'):
                    e1s2_data = self._get_e1s2_data(username, otp_key)
                    response = client.post(url=url, headers=headers, data=e1s2_data)
                    res_status_code = response.status_code

            # 目标网站的登录
            if res_status_code == 302:
                redirect = service.redirect(client, target_login_url)
                self.cookies = redirect.get("cookies")
                self.url = redirect.get("url")
                return redirect
            else:
                raise ValueError("登录失败")

    @retry(stop=stop_after_attempt(retry_num))
    async def login_async(
        self,
        username: str,
        password: str,
        otp_key: str,
        service: type[Service] | str,
        skip_ad: bool = True,
    ) -> dict[str, object]:
        # 如果传入的是字符串，直接使用；如果是 Service 类或者子类，使用其 SERVICE_URL 属性
        if isinstance(service, str):
            service_url = service
            service = Service
        elif isinstance(service, type) and issubclass(service, Service):
            service_url = service.SERVICE_URL
        else:
            raise ValueError("service必须是字符串或Service的子类")

        skip_ad_service = "https://oa"

        target_url = service_url
        service_url = skip_ad_service if skip_ad else service_url
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": self.UserAgent,
        }

        async with httpx.AsyncClient(transport=self.async_transport) as client:
            response = await client.get(
                url=target_url, headers=headers, follow_redirects=True  # type: ignore
            )
            target_login_url = response.url.__str__()
            login_url = target_login_url.split("?")[0]

            # 使用跳过域网址
            if skip_ad:
                url = f"{login_url}?service={service_url}"
            else:
                url = target_login_url
            e1s1_data = self._get_e1s1_data(username, password)
            # 原因不明，就是要get，不然没办法登录
            await client.get(url=url, headers=headers)
            response = await client.post(url=url, headers=headers, data=e1s1_data)
            res_text = response.text
            res_status_code = response.status_code

            # 如果status_code是401则需要填otp
            if res_status_code == 401:
                if res_text.find('id = "dynamicPassword"'):
                    e1s2_data = self._get_e1s2_data(username, otp_key)
                    response = await client.post(
                        url=url, headers=headers, data=e1s2_data
                    )
                    res_status_code = response.status_code

            # 目标网站的登录
            if res_status_code == 302:
                redirect = await service.redirect_async(client, target_login_url)
                self.cookies = redirect.get("cookies")
                self.url = redirect.get("url")
                return redirect
            else:
                raise ValueError("登录失败")
