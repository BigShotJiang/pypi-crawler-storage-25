import argparse
import sys
import json
import os
from pathlib import Path

from .v2 import Yhlogin
from . import service as service_module
from .service import Service


def get_service_classes():
    """获取所有可用的 Service 子类及其简写映射"""
    service_classes = {}
    abbreviations_map = {}

    # 遍历 service 模块中的所有类
    for name in dir(service_module):
        obj = getattr(service_module, name)
        # 检查是否是 Service 的子类且不是 Service 本身
        if isinstance(obj, type) and issubclass(obj, Service) and obj is not Service:
            service_classes[name] = obj
            # 收集所有简写
            for abbr in getattr(obj, 'ABBREVIATIONS', []):
                abbreviations_map[abbr.lower()] = name
            # 类名本身也作为可用的简写（小写）
            abbreviations_map[name.lower()] = name

    return service_classes, abbreviations_map


def resolve_service_name(service_name: str, abbreviations_map: dict) -> str:
    """根据简写或服务名解析为实际的服务类名"""
    return abbreviations_map.get(service_name.lower(), service_name)


def get_config_dir() -> Path:
    """获取配置目录（XDG 规范）"""
    if os.name == "nt":  # Windows
        base = Path(os.environ.get("APPDATA", ""))
    else:  # macOS/Linux
        xdg_config = os.environ.get("XDG_CONFIG_HOME", "")
        if xdg_config:
            base = Path(xdg_config)
        else:
            base = Path.home() / ".config"
    return base / "yhlogin"


def get_config_path() -> Path:
    """获取配置文件路径"""
    return get_config_dir() / "config.json"


def load_config() -> dict:
    """加载配置文件"""
    config_path = get_config_path()
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_config(config: dict) -> None:
    """保存配置文件"""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = get_config_path()
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def cmd_config_set(args):
    """设置配置命令"""
    config = load_config()

    if not (args.username or args.password or args.otp_key):
        print("错误：至少需要提供一个配置项", file=sys.stderr)
        return 1

    if args.username:
        config["username"] = args.username
    if args.password:
        config["password"] = args.password
    if args.otp_key:
        config["otp_key"] = args.otp_key

    save_config(config)
    print("配置已保存")
    print(f"配置文件位置：{get_config_path()}")
    return 0


def cmd_config_show(args):
    """显示配置命令"""
    config = load_config()
    if not config:
        print("未配置任何信息")
        return 1

    print("当前配置:")
    if "username" in config:
        print(f"  username: {config['username']}")
    if "password" in config:
        print(f"  password: {'*' * len(config['password'])}")
    if "otp_key" in config:
        print(f"  otp_key: {config['otp_key']}")
    return 0


def cmd_config_clear(args):
    """清除配置命令"""
    config_path = get_config_path()
    if config_path.exists():
        config_path.unlink()
        print("配置已清除")
    else:
        print("无配置可清除")


def cmd_login(args):
    """登录命令"""
    service_classes, abbreviations_map = get_service_classes()

    # 解析服务名（支持简写）
    service_name = resolve_service_name(args.service, abbreviations_map)

    if service_name not in service_classes:
        print(f"错误：未知的 service '{args.service}'")
        print(f"可用的 service: {', '.join(service_classes.keys())}")
        print(f"使用 'yhlogin services' 查看所有可用服务及简写")
        return 1

    service_class = service_classes[service_name]

    # 如果未提供凭证，尝试从配置加载
    username = args.username
    password = args.password
    otp_key = args.otp_key

    if not (username and password and otp_key):
        config = load_config()
        if not username:
            username = config.get("username")
        if not password:
            password = config.get("password")
        if not otp_key:
            otp_key = config.get("otp_key")

    if not username:
        print("错误：未指定用户名，且无保存的配置", file=sys.stderr)
        return 1
    if not password:
        print("错误：未指定密码，且无保存的配置", file=sys.stderr)
        return 1
    if not otp_key:
        print("错误：未指定 OTP 密钥，且无保存的配置", file=sys.stderr)
        return 1

    try:
        yh = Yhlogin()
        result = yh.login(
            username=username,
            password=password,
            otp_key=otp_key,
            service=service_class,
        )
        print(json.dumps(result, indent=2, default=str))
        return 0
    except Exception as e:
        print(f"错误：{e}", file=sys.stderr)
        return 1


def cmd_services(_args=None):
    """列出所有可用服务命令"""
    service_classes, abbreviations_map = get_service_classes()

    print("可用服务列表:")
    print("-" * 50)
    for name, cls in service_classes.items():
        description = getattr(cls, 'DESCRIPTION', '无描述')
        abbreviations = getattr(cls, 'ABBREVIATIONS', [])
        abbr_str = ', '.join(abbreviations) if abbreviations else '无'
        print(f"  {name:15} - {description:20} 简写：{abbr_str}")
    print("-" * 50)
    print(f"共 {len(service_classes)} 个可用服务")
    print("使用简写或完整类名进行登录，例如：yhlogin login bd 或 yhlogin login BigData")


def main():
    parser = argparse.ArgumentParser(
        description="YH Login CLI - 永辉登录工具"
    )
    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # login 命令
    login_parser = subparsers.add_parser("login", help="登录到指定服务")
    login_parser.add_argument(
        "service",
        help="服务名称或简写 (使用 'yhlogin services' 查看可用服务)"
    )
    login_parser.add_argument(
        "username",
        nargs="?",
        help="用户名（可选，如不提供则使用保存的配置）"
    )
    login_parser.add_argument(
        "password",
        nargs="?",
        help="密码（可选，如不提供则使用保存的配置）"
    )
    login_parser.add_argument(
        "otp_key",
        nargs="?",
        help="OTP 密钥（可选，如不提供则使用保存的配置）"
    )
    login_parser.set_defaults(func=cmd_login)

    # config 命令
    config_parser = subparsers.add_parser("config", help="管理配置")
    config_subparsers = config_parser.add_subparsers(dest="config_action", help="配置操作")

    # config set
    config_set_parser = config_subparsers.add_parser("set", help="保存配置")
    config_set_parser.add_argument("--username", help="用户名")
    config_set_parser.add_argument("--password", help="密码")
    config_set_parser.add_argument("--otp-key", dest="otp_key", help="OTP 密钥")
    config_set_parser.set_defaults(func=cmd_config_set)

    # config show
    config_show_parser = config_subparsers.add_parser("show", help="显示当前配置")
    config_show_parser.set_defaults(func=cmd_config_show)

    # config clear
    config_clear_parser = config_subparsers.add_parser("clear", help="清除配置")
    config_clear_parser.set_defaults(func=cmd_config_clear)

    # services 命令
    services_parser = subparsers.add_parser("services", help="列出所有可用服务及简写")
    services_parser.set_defaults(func=cmd_services)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 1

    if args.command == "config" and args.config_action is None:
        config_parser.print_help()
        return 1

    exit_code = args.func(args)
    sys.exit(exit_code if exit_code is not None else 0)


if __name__ == "__main__":
    main()
