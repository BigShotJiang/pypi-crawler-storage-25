"""v2 API 功能测试"""
import pytest
from yhlogin import Yhlogin
from yhlogin.service import Service, BigData, YhBi


# 测试账号（请根据实际情况修改）
TEST_USERNAME = "80858056"
TEST_PASSWORD = "Zzwyh3142"
TEST_OTP_KEY = "YK4LRWG4WHWONNIJ"


class TestServiceClasses:
    """测试 Service 类"""

    def test_service_base_class(self):
        """测试基础 Service 类"""
        assert Service.SERVICE_URL is None
        assert hasattr(Service, "redirect")

    def test_bigdata_service(self):
        """测试 BigData 服务"""
        assert BigData.SERVICE_URL is not None
        assert "bigdata.yonghui.cn" in BigData.SERVICE_URL
        assert hasattr(BigData, "redirect")

    def test_yhbi_service(self):
        """测试 YhBi 服务"""
        assert YhBi.SERVICE_URL is not None
        assert hasattr(YhBi, "redirect")


class TestYhloginV2:
    """测试 Yhlogin v2 API"""

    def test_init(self):
        """测试初始化"""
        yh = Yhlogin()
        assert yh.UserAgent is not None
        assert yh.transport is not None
        assert yh.async_transport is not None

    def test_login_with_string_service(self):
        """测试使用字符串 service 登录"""
        yh = Yhlogin()
        # 使用错误的凭证测试错误处理
        with pytest.raises(Exception):
            yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn"
            )

    def test_login_with_service_class(self):
        """测试使用 Service 类登录"""
        yh = Yhlogin()
        # 使用错误的凭证测试错误处理
        with pytest.raises(Exception):
            yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service=BigData
            )

    def test_login_invalid_service_type(self):
        """测试无效的 service 类型"""
        import tenacity
        yh = Yhlogin()
        yh.retry_num = 1  # 禁用重试
        with pytest.raises(tenacity.RetryError):
            yh.login(
                username="test",
                password="test",
                otp_key="test",
                service=123  # 无效类型
            )

    def test_get_e1s1_data(self):
        """测试生成 e1s1 数据"""
        yh = Yhlogin()
        data = yh._get_e1s1_data("testuser", "testpass")
        assert data["flag"] == 1
        assert data["username"] == "testuser"
        assert data["password"] == "testpass"
        assert data["execution"] == "e2s1"

    def test_get_e1s2_data(self):
        """测试生成 e1s2 数据"""
        yh = Yhlogin()
        data = yh._get_e1s2_data("testuser", "TESTOTPKEY")
        assert data["flag"] == 1
        assert data["username"] == "testuser"
        assert data["execution"] == "e2s2"
        # TOTP 动态密码应该是 6 位数字
        assert len(data["token"]) == 6
        assert data["token"].isdigit()


class TestYhloginAsync:
    """测试 Yhlogin 异步 API"""

    @pytest.mark.asyncio
    async def test_login_async_with_string_service(self):
        """测试异步登录（字符串 service）"""
        yh = Yhlogin()
        with pytest.raises(Exception):
            await yh.login_async(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn"
            )

    @pytest.mark.asyncio
    async def test_login_async_with_service_class(self):
        """测试异步登录（Service 类）"""
        yh = Yhlogin()
        with pytest.raises(Exception):
            await yh.login_async(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service=BigData
            )

    @pytest.mark.asyncio
    async def test_login_async_invalid_service_type(self):
        """测试异步登录无效 service 类型"""
        import tenacity
        yh = Yhlogin()
        yh.retry_num = 1  # 禁用重试
        with pytest.raises(tenacity.RetryError):
            await yh.login_async(
                username="test",
                password="test",
                otp_key="test",
                service=123
            )
