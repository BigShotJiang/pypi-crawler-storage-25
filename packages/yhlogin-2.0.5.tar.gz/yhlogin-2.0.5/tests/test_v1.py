"""v1 API 功能测试"""
import pytest
import asyncio
from yhlogin.v1 import Yhlogin


# 测试账号（请根据实际情况修改）
TEST_USERNAME = "80858056"
TEST_PASSWORD = "Zzwyh3142"
TEST_OTP_KEY = "YK4LRWG4WHWONNIJ"


class TestYhloginV1:
    """测试 Yhlogin v1 API"""

    def test_init(self):
        """测试初始化"""
        yh = Yhlogin()
        assert yh.UserAgent is not None
        assert yh.transport is not None
        assert yh.async_transport is not None

    def test_login_sync(self):
        """测试同步登录（自动检测）"""
        yh = Yhlogin()
        # 使用错误的凭证测试错误处理
        with pytest.raises(Exception):
            yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn"
            )

    @pytest.mark.asyncio
    async def test_login_async(self):
        """测试异步登录"""
        yh = Yhlogin()
        # 使用错误的凭证测试错误处理
        with pytest.raises(Exception):
            await yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn"
            )

    def test_login_sets_instance_attributes(self):
        """测试登录后设置实例属性（失败情况）"""
        yh = Yhlogin()
        with pytest.raises(Exception):
            yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn"
            )
        # 登录失败时不会设置 url 和 cookies
        assert not hasattr(yh, 'url') or yh.url is None
        assert not hasattr(yh, 'cookies') or yh.cookies is None

    def test_service_url_conversion(self):
        """测试 service URL 转换（bigdata 兼容处理）"""
        yh = Yhlogin()
        # 这个测试主要验证代码不会报错
        with pytest.raises(Exception):
            yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn"
            )

    def test_skip_ad_parameter(self):
        """测试 skip_ad 参数"""
        yh = Yhlogin()
        # 测试 skip_ad=True（默认）
        with pytest.raises(Exception):
            yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn",
                skip_ad=True
            )

        # 测试 skip_ad=False
        with pytest.raises(Exception):
            yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn",
                skip_ad=False
            )


class TestYhloginV1Async:
    """测试 Yhlogin v1 异步功能"""

    @pytest.mark.asyncio
    async def test_login_in_async_context(self):
        """测试在异步上下文中调用 login（应返回协程）"""
        yh = Yhlogin()
        coro = yh.login(
            username="invalid_user",
            password="invalid_pass",
            otp_key="INVALID_KEY",
            service="https://bigdata.yonghui.cn"
        )
        # 在异步上下文中，应该返回协程对象
        assert asyncio.iscoroutine(coro)
        # 等待协程完成，应该抛出异常
        with pytest.raises(Exception):
            await coro

    @pytest.mark.asyncio
    async def test_login_async_direct(self):
        """测试直接 await login 方法"""
        yh = Yhlogin()
        with pytest.raises(Exception):
            await yh.login(
                username="invalid_user",
                password="invalid_pass",
                otp_key="INVALID_KEY",
                service="https://bigdata.yonghui.cn",
                skip_ad=False
            )
