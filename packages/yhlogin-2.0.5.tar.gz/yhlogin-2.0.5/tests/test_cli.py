"""CLI 功能测试"""
import subprocess
import json
import os
import pytest
from pathlib import Path


class TestCLIConfig:
    """测试 config 命令"""

    def test_config_set(self):
        """测试保存配置"""
        result = subprocess.run(
            ["yhlogin", "config", "set",
             "--username", "testuser",
             "--password", "testpass123",
             "--otp-key", "JBSWY3DPEHPK3PXP"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "配置已保存" in result.stdout

    def test_config_show(self):
        """测试查看配置"""
        # 先设置配置
        subprocess.run(
            ["yhlogin", "config", "set",
             "--username", "testuser",
             "--password", "testpass123",
             "--otp-key", "JBSWY3DPEHPK3PXP"],
            capture_output=True
        )

        result = subprocess.run(
            ["yhlogin", "config", "show"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "username: testuser" in result.stdout
        assert "otp_key: JBSWY3DPEHPK3PXP" in result.stdout

    def test_config_clear(self):
        """测试清除配置"""
        # 先设置配置
        subprocess.run(
            ["yhlogin", "config", "set",
             "--username", "testuser",
             "--password", "testpass123",
             "--otp-key", "JBSWY3DPEHPK3PXP"],
            capture_output=True
        )

        result = subprocess.run(
            ["yhlogin", "config", "clear"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "配置已清除" in result.stdout

        # 验证配置已清除
        result = subprocess.run(
            ["yhlogin", "config", "show"],
            capture_output=True,
            text=True
        )
        assert "未配置任何信息" in result.stdout


class TestCLILogin:
    """测试 login 命令"""

    def test_login_help(self):
        """测试 login 命令帮助"""
        result = subprocess.run(
            ["yhlogin", "login", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "service" in result.stdout
        assert "username" in result.stdout
        assert "password" in result.stdout
        assert "otp_key" in result.stdout

    def test_login_invalid_service(self):
        """测试无效的 service 名称"""
        result = subprocess.run(
            ["yhlogin", "login", "InvalidService"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0
        assert "未知的 service" in result.stdout

    def test_login_without_credentials(self):
        """测试无凭证时登录失败"""
        # 先清除配置
        subprocess.run(["yhlogin", "config", "clear"], capture_output=True)

        result = subprocess.run(
            ["yhlogin", "login", "BigData"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0
        assert "未指定用户名" in result.stderr

    def test_login_with_missing_credentials(self):
        """测试部分提供凭证时登录失败"""
        # 先清除配置
        subprocess.run(["yhlogin", "config", "clear"], capture_output=True)

        result = subprocess.run(
            ["yhlogin", "login", "BigData", "testuser"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0
        assert "未指定密码" in result.stderr


class TestCLIMain:
    """测试主命令"""

    def test_main_help(self):
        """测试主帮助"""
        result = subprocess.run(
            ["yhlogin", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "login" in result.stdout
        assert "config" in result.stdout

    def test_no_command(self):
        """测试无命令时显示帮助"""
        result = subprocess.run(
            ["yhlogin"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0
        assert "usage" in result.stdout
