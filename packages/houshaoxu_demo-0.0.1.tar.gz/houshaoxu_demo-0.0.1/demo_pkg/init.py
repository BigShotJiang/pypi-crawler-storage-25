__version__ = "0.0.1"

def say_hi():
    return "Hello, this is my first PyPI package!"