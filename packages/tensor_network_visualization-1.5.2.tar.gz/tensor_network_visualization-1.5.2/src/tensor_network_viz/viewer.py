from __future__ import annotations

from dataclasses import replace
from typing import Any, TypeAlias, cast

import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d.axes3d import Axes3D

from ._input_inspection import _detect_network_engine_with_input
from ._registry import _get_plotters
from ._typing import FigureLike, root_figure
from .config import EngineName, PlotConfig, ViewName

RenderedAxes: TypeAlias = Axes | Axes3D


def _show_figure(fig: FigureLike) -> None:
    """Show *fig* in a Jupyter kernel via IPython display, else ``plt.show()``."""
    display_figure = root_figure(fig)
    try:
        from IPython.core.getipython import get_ipython
        from IPython.display import display
    except ImportError:
        plt.show()
        return
    ip = get_ipython()
    if ip is not None and getattr(ip, "kernel", None) is not None:
        display(display_figure)
        return
    plt.show()


def _detect_engine_with_network(network: Any) -> tuple[EngineName, Any]:
    """Infer the backend engine and preserve single-pass iterables when needed."""
    return _detect_network_engine_with_input(network)


def _detect_engine(network: Any) -> EngineName:
    """Infer the backend engine from the received tensor-network object."""
    detected_engine, _ = _detect_engine_with_network(network)
    return detected_engine


def show_tensor_network(
    network: Any,
    *,
    engine: EngineName | None = None,
    view: ViewName | None = None,
    config: PlotConfig | None = None,
    ax: RenderedAxes | None = None,
    show_controls: bool = True,
    show: bool = True,
) -> tuple[Figure, RenderedAxes]:
    """Render a tensor network and optionally display the figure.

    Args:
        network: Tensor network object (with 'nodes'/'leaf_nodes'), or an
            iterable of nodes with 'edges', 'axes_names' or 'axis_names',
            and 'name'.
        engine: Rendering engine; supported values are "tensorkrowch",
            "tensornetwork", "quimb", "tenpy", and "einsum". When omitted,
            ``show_tensor_network`` infers the engine from ``network``.
        view: "2d" or "3d" visualization mode. ``None`` defaults to ``"2d"``
            unless ``ax`` is a 3D axes, in which case the view is inferred.
        config: Optional styling; uses defaults if None. Use ``PlotConfig`` for
            colors, labels, layout, ``hover_labels`` (interactive hover
            tooltips), contraction highlighting, and related render behavior.
        ax: Optional Matplotlib axes to render into. When passed, the 2D/3D
            selector is suppressed and the view is fixed to that axes.
        show_controls: If True, attach figure-level controls for view, hover,
            and label toggles when the renderer exposes the required scene
            cache. Set False for a static render without widgets.
        show: If True, display the figure. In a Jupyter kernel this uses
            ``IPython.display.display(fig)`` (use ``pip install
            "tensor-network-visualization[jupyter]"`` and ``%matplotlib widget``
            for interactive figures). Otherwise ``plt.show()`` is used.

    Note:
        Repeated calls with the **same** ``network`` instance reuse the normalized
        graph structure for regular objects and for re-iterable builtin containers
        such as ``list``, ``tuple``, and ``dict``. One-shot iterators are rebuilt on
        each call. After in-place changes, call
        ``clear_tensor_network_graph_cache(network)`` so the next draw re-extracts the
        structure.

    Returns:
        Tuple of (Figure, Axes) for further customization.

    Example:
        >>> config = PlotConfig(figsize=(8, 6))
        >>> fig, ax = show_tensor_network(network, config=config)
    """
    style = config or PlotConfig()
    ax_view: ViewName | None = None
    if ax is not None:
        ax_view = "3d" if getattr(ax, "name", "") == "3d" else "2d"
    resolved_view = ax_view or "2d" if view is None else view
    if ax_view is not None and resolved_view != ax_view:
        raise ValueError(f"Provided ax is {ax_view}, but view={resolved_view!r} was requested.")
    if resolved_view not in ("2d", "3d"):
        raise ValueError(f"Unsupported tensor network view: {resolved_view}")
    network_input = network
    if engine is None:
        resolved_engine, network_input = _detect_engine_with_network(network)
    else:
        resolved_engine = engine
    plot_2d, plot_3d = _get_plotters(resolved_engine)
    if not show_controls:
        static_style = style
        if style.contraction_playback or style.contraction_scheme_cost_hover:
            static_style = replace(
                static_style,
                show_contraction_scheme=True,
                contraction_playback=False,
                contraction_scheme_cost_hover=False,
            )
        if resolved_view == "2d":
            fig, ax_out = plot_2d(
                network_input,
                ax=cast(Axes, ax) if ax is not None else None,
                config=static_style,
                _build_contraction_controls=False,
                _build_scene_state=False,
            )
        elif resolved_view == "3d":
            fig, ax_out = plot_3d(
                network_input,
                ax=ax,
                config=static_style,
                _build_contraction_controls=False,
                _build_scene_state=False,
            )
        else:
            raise ValueError(f"Unsupported tensor network view: {resolved_view}")
    else:
        from .interactive_viewer import show_tensor_network_interactive

        fig, ax_out = show_tensor_network_interactive(
            network_input,
            engine=resolved_engine,
            view=resolved_view,
            config=style,
            ax=ax,
        )
    if show:
        _show_figure(fig)
    return root_figure(fig), ax_out
