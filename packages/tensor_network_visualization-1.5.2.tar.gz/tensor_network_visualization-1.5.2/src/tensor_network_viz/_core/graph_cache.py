"""Reuse normalized graphs across repeated draws of the same network object.

Covers preview + export and 2D + 3D.
"""

from __future__ import annotations

import contextlib
import weakref
from collections.abc import Callable
from typing import Any

from .graph import _GraphData

_graph_weak_cache: weakref.WeakKeyDictionary[Any, dict[int, _GraphData]] = (
    weakref.WeakKeyDictionary()
)
_builtin_container_cache: dict[tuple[int, int], tuple[tuple[Any, ...], _GraphData]] = {}
_MAX_BUILTIN_CONTAINER_CACHE_ENTRIES: int = 128

# On objects without weak-key support (e.g. plain list), fall back to an instance attribute dict.
_CACHE_ATTR: str = "_tensor_network_viz_graph_cache_by_builder"


def _builtin_container_signature(network: Any) -> tuple[Any, ...] | None:
    if isinstance(network, list):
        return ("list", tuple(id(item) for item in network))
    if isinstance(network, tuple):
        return ("tuple", tuple(id(item) for item in network))
    if isinstance(network, dict):
        return ("dict", tuple(id(item) for item in network.values()))
    return None


def _builtin_container_cache_get(
    network: Any,
    *,
    builder_id: int,
) -> _GraphData | None:
    signature = _builtin_container_signature(network)
    if signature is None:
        return None
    hit = _builtin_container_cache.get((id(network), builder_id))
    if hit is None:
        return None
    cached_signature, graph = hit
    if cached_signature != signature:
        return None
    return graph


def _builtin_container_cache_put(
    network: Any,
    *,
    builder_id: int,
    graph: _GraphData,
) -> bool:
    signature = _builtin_container_signature(network)
    if signature is None:
        return False
    cache_key = (id(network), builder_id)
    _builtin_container_cache[cache_key] = (signature, graph)
    while len(_builtin_container_cache) > _MAX_BUILTIN_CONTAINER_CACHE_ENTRIES:
        oldest_key = next(iter(_builtin_container_cache))
        del _builtin_container_cache[oldest_key]
    return True


def _get_or_build_graph(
    network: Any,
    builder: Callable[[Any], _GraphData],
) -> _GraphData:
    """Return a cached :class:`_GraphData` for *network* when *builder* matches a previous build."""
    b_id = id(builder)
    try:
        bucket = _graph_weak_cache.get(network)
        if bucket is not None:
            hit = bucket.get(b_id)
            if hit is not None:
                return hit
    except TypeError:
        pass

    builtin_hit = _builtin_container_cache_get(network, builder_id=b_id)
    if builtin_hit is not None:
        return builtin_hit

    attr_bucket = getattr(network, _CACHE_ATTR, None)
    if isinstance(attr_bucket, dict):
        hit = attr_bucket.get(b_id)
        if isinstance(hit, _GraphData):
            return hit

    graph = builder(network)

    try:
        bucket = _graph_weak_cache.get(network)
        if bucket is None:
            bucket = {}
            _graph_weak_cache[network] = bucket
        bucket[b_id] = graph
    except TypeError:
        if _builtin_container_cache_put(network, builder_id=b_id, graph=graph):
            return graph
        try:
            if not isinstance(attr_bucket, dict):
                attr_bucket = {}
            attr_bucket[b_id] = graph
            setattr(network, _CACHE_ATTR, attr_bucket)
        except (TypeError, AttributeError):
            pass

    return graph


def clear_tensor_network_graph_cache(
    network: Any,
    *,
    builder: Callable[[Any], _GraphData] | None = None,
) -> None:
    """Drop cached :class:`_GraphData` for *network* (all builders, or only *builder*).

    Call this after in-place edits to a tensor network so the next draw re-extracts the structure.
    """
    b_id = id(builder) if builder is not None else None
    try:
        bucket = _graph_weak_cache.get(network)
        if bucket is not None:
            if b_id is None:
                bucket.clear()
            else:
                bucket.pop(b_id, None)
            if not bucket:
                del _graph_weak_cache[network]
    except (TypeError, KeyError):
        pass

    builtin_key_prefix = id(network)
    if b_id is None:
        for key in tuple(_builtin_container_cache):
            if key[0] == builtin_key_prefix:
                del _builtin_container_cache[key]
    else:
        _builtin_container_cache.pop((builtin_key_prefix, b_id), None)

    attr_bucket = getattr(network, _CACHE_ATTR, None)
    if not isinstance(attr_bucket, dict):
        return
    if b_id is None:
        attr_bucket.clear()
    else:
        attr_bucket.pop(b_id, None)
    if not attr_bucket:
        with contextlib.suppress(AttributeError):
            delattr(network, _CACHE_ATTR)


__all__ = [
    "_get_or_build_graph",
    "clear_tensor_network_graph_cache",
]
