from __future__ import annotations

import math

import numpy as np
import pytest

from tensor_network_viz import PlotConfig
from tensor_network_viz._core._draw_common import _graph_edge_degree
from tensor_network_viz._core.graph import (
    _EdgeEndpoint,
    _GraphData,
    _make_contraction_edge,
    _make_dangling_edge,
    _make_node,
    _NodeData,
)
from tensor_network_viz._core.layout import (
    _analyze_layout_components_cached,
    _compute_axis_directions,
    _compute_component_layout_2d,
    _compute_layout,
    _dangling_stub_segment_2d,
    _dangling_stub_segment_3d,
    _is_dangling_leg_axis,
    _planar_contraction_bond_segments_2d,
    _segment_point_min_distance_sq_2d,
    _segments_cross_2d,
)
from tensor_network_viz._core.layout.direction_common import _behavior_direction_order_2d
from tensor_network_viz._core.layout.free_directions_2d import (
    _direction_angle_conflicts_2d,
    _pick_candidate_direction_2d,
)
from tensor_network_viz._core.renderer import (
    _SHORTEST_EDGE_RADIUS_FRACTION,
    _resolve_draw_scale,
)


def _build_chain_graph(
    *,
    length: int,
    dangling_axis_counts: dict[int, int] | None = None,
) -> _GraphData:
    dangling_axis_counts = dangling_axis_counts or {}
    nodes = {}
    edges = []

    for node_id in range(length):
        axes_names = []
        if node_id > 0:
            axes_names.append("left")
        if node_id < length - 1:
            axes_names.append("right")
        for dangling_index in range(dangling_axis_counts.get(node_id, 0)):
            axes_names.append(f"d{node_id}_{dangling_index}")
        nodes[node_id] = _make_node(f"N{node_id}", tuple(axes_names))

    for node_id in range(length - 1):
        left_axis = len(nodes[node_id].axes_names) - dangling_axis_counts.get(node_id, 0) - 1
        right_axis = 0
        edges.append(
            _make_contraction_edge(
                _EdgeEndpoint(node_id, left_axis, "right"),
                _EdgeEndpoint(node_id + 1, right_axis, "left"),
                name=f"e{node_id}",
                label=None,
            )
        )

    for node_id, count in dangling_axis_counts.items():
        start_axis = len(nodes[node_id].axes_names) - count
        for offset in range(count):
            axis_index = start_axis + offset
            axis_name = nodes[node_id].axes_names[axis_index]
            edges.append(
                _make_dangling_edge(
                    _EdgeEndpoint(node_id, axis_index, axis_name),
                    name=axis_name,
                    label=None,
                )
            )

    return _GraphData(nodes=nodes, edges=tuple(edges))


def test_graph_edge_degree_counts_all_edge_kinds() -> None:
    graph = _build_chain_graph(length=3)
    assert _graph_edge_degree(graph, 0) == 1
    assert _graph_edge_degree(graph, 1) == 2
    assert _graph_edge_degree(graph, 2) == 1

    isolated_dangling = _build_chain_graph(length=1, dangling_axis_counts={0: 1})
    assert _graph_edge_degree(isolated_dangling, 0) == 1

    leaf_with_phys = _build_chain_graph(length=2, dangling_axis_counts={1: 1})
    assert _graph_edge_degree(leaf_with_phys, 1) == 2


def test_dangling_leg_axis_matches_open_edges() -> None:
    g = _GraphData(
        nodes={
            0: _make_node("A", ("left", "p")),
            1: _make_node("B", ("right",)),
        },
        edges=(
            _make_contraction_edge(
                _EdgeEndpoint(0, 0, "left"),
                _EdgeEndpoint(1, 0, "right"),
                name=None,
            ),
            _make_dangling_edge(_EdgeEndpoint(0, 1, "p"), name="p"),
        ),
    )
    assert _is_dangling_leg_axis(g, 0, 1) is True
    assert _is_dangling_leg_axis(g, 0, 0) is False
    assert _is_dangling_leg_axis(g, 1, 0) is False


def test_behavior_direction_order_2d_rotates_north_template() -> None:
    north = _behavior_direction_order_2d("north")
    south = _behavior_direction_order_2d("south")
    east = _behavior_direction_order_2d("east")
    west = _behavior_direction_order_2d("west")

    expected_north = (
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([1.0, 1.0], dtype=float) / np.sqrt(2.0),
        np.array([-1.0, 1.0], dtype=float) / np.sqrt(2.0),
        np.array([-1.0, -1.0], dtype=float) / np.sqrt(2.0),
        np.array([1.0, -1.0], dtype=float) / np.sqrt(2.0),
    )
    expected_north_semidiagonals = (
        np.array([math.cos(math.radians(67.5)), math.sin(math.radians(67.5))], dtype=float),
        np.array([math.cos(math.radians(112.5)), math.sin(math.radians(112.5))], dtype=float),
        np.array([math.cos(math.radians(157.5)), math.sin(math.radians(157.5))], dtype=float),
        np.array([math.cos(math.radians(202.5)), math.sin(math.radians(202.5))], dtype=float),
        np.array([math.cos(math.radians(247.5)), math.sin(math.radians(247.5))], dtype=float),
        np.array([math.cos(math.radians(292.5)), math.sin(math.radians(292.5))], dtype=float),
        np.array([math.cos(math.radians(337.5)), math.sin(math.radians(337.5))], dtype=float),
        np.array([math.cos(math.radians(22.5)), math.sin(math.radians(22.5))], dtype=float),
    )

    for idx, expected in enumerate(expected_north):
        assert np.allclose(north[idx], expected, atol=1e-9)
    for idx, expected in enumerate(expected_north_semidiagonals, start=8):
        assert np.allclose(north[idx], expected, atol=1e-9)

    assert np.allclose(south[0], np.array([0.0, -1.0], dtype=float), atol=1e-9)
    assert np.allclose(east[0], np.array([1.0, 0.0], dtype=float), atol=1e-9)
    assert np.allclose(west[0], np.array([-1.0, 0.0], dtype=float), atol=1e-9)


def test_direction_angle_conflicts_2d_respects_five_degree_threshold() -> None:
    assert _direction_angle_conflicts_2d(
        np.array([0.0, 1.0], dtype=float),
        np.array([math.sin(math.radians(4.0)), math.cos(math.radians(4.0))], dtype=float),
    )
    assert _direction_angle_conflicts_2d(
        np.array([0.0, 1.0], dtype=float),
        np.array([math.sin(math.radians(176.0)), math.cos(math.radians(176.0))], dtype=float),
    )
    assert not _direction_angle_conflicts_2d(
        np.array([0.0, 1.0], dtype=float),
        np.array([math.sin(math.radians(10.0)), math.cos(math.radians(10.0))], dtype=float),
    )


def test_pick_candidate_direction_2d_returns_last_tried_when_all_fail() -> None:
    candidates = (
        np.array([0.0, 1.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    )
    picked = _pick_candidate_direction_2d(
        candidates=candidates,
        is_valid=lambda _candidate: False,
    )

    assert np.allclose(picked, candidates[-1], atol=1e-9)


def test_compute_axis_directions_chain_2d_allows_opposite_free_axes_on_same_node() -> None:
    graph = _build_chain_graph(length=3, dangling_axis_counts={1: 2})
    positions = {
        0: np.array([0.0, 0.0], dtype=float),
        1: np.array([1.0, 0.0], dtype=float),
        2: np.array([2.0, 0.0], dtype=float),
    }

    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=1.0)
    free_axis_indices = [
        axis_index
        for axis_index, axis_name in enumerate(graph.nodes[1].axes_names)
        if axis_name.startswith("d1_")
    ]
    picked = [
        np.asarray(directions[(1, axis_index)], dtype=float) for axis_index in free_axis_indices
    ]

    assert np.allclose(picked[0], np.array([0.0, 1.0], dtype=float), atol=1e-6)
    assert np.allclose(picked[1], np.array([0.0, -1.0], dtype=float), atol=1e-6)


def test_physical_stub_2d_segment_clears_neighbor_node_disk() -> None:
    """Physical dangling legs use strict clearance: stub polyline must not pierce neighbor disks."""
    nodes = {
        0: _make_node("A", ("right", "phys")),
        1: _make_node("B", ("left",)),
    }
    edges = [
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "right"),
            _EdgeEndpoint(1, 0, "left"),
            name="bond",
        ),
        _make_dangling_edge(_EdgeEndpoint(0, 1, "phys"), name="phys"),
    ]
    graph = _GraphData(nodes=nodes, edges=tuple(edges))
    positions = {
        0: np.array([0.0, 0.0], dtype=float),
        1: np.array([0.35, 0.0], dtype=float),
    }
    ds = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=ds)
    direction = directions[(0, 1)]
    p0, p1 = _dangling_stub_segment_2d(positions[0], direction, draw_scale=ds)
    r_disk = float(PlotConfig.DEFAULT_NODE_RADIUS) * max(float(ds), 1e-6) * 1.08
    dist = math.sqrt(_segment_point_min_distance_sq_2d(p0, p1, positions[1]))
    assert dist >= r_disk - 1e-9


def test_resolve_draw_scale_from_shortest_contraction_edge() -> None:
    graph = _build_chain_graph(length=3)
    positions = {
        0: np.array([0.0, 0.0], dtype=float),
        1: np.array([0.4, 0.0], dtype=float),
        2: np.array([1.4, 0.0], dtype=float),
    }
    frac = float(_SHORTEST_EDGE_RADIUS_FRACTION)
    nr = float(PlotConfig.DEFAULT_NODE_RADIUS)
    s = _resolve_draw_scale(graph, positions)
    d_min = 0.4
    assert abs(s - frac * d_min / nr) < 1e-9
    assert abs(frac * d_min - nr * s) < 1e-9

    tight = {
        0: np.array([0.0, 0.0], dtype=float),
        1: np.array([0.25, 0.0], dtype=float),
        2: np.array([2.0, 0.0], dtype=float),
    }
    st = _resolve_draw_scale(graph, tight)
    assert abs(st - frac * 0.25 / nr) < 1e-9
    assert abs(frac * 0.25 - nr * st) < 1e-9


def test_resolve_draw_scale_heuristic_when_no_contraction_edges() -> None:
    graph = _build_chain_graph(length=1)
    positions = {0: np.array([0.0, 0.0], dtype=float)}
    s = _resolve_draw_scale(graph, positions)
    lo, hi = 0.35, 1.85
    assert lo <= s <= hi


def _build_3d_grid_graph(lx: int, ly: int, lz: int) -> _GraphData:
    """3D nearest-neighbor cubic lattice; same bond topology as cubic PEPS (no physical legs)."""

    def node_index(i: int, j: int, k: int) -> int:
        return i * ly * lz + j * lz + k

    nodes = {}
    edge_specs: list[tuple[int, int, str, str]] = []

    for i in range(lx):
        for j in range(ly):
            for k in range(lz):
                axes_names: list[str] = []
                if i > 0:
                    axes_names.append("xm")
                if i < lx - 1:
                    axes_names.append("xp")
                if j > 0:
                    axes_names.append("ym")
                if j < ly - 1:
                    axes_names.append("yp")
                if k > 0:
                    axes_names.append("zm")
                if k < lz - 1:
                    axes_names.append("zp")
                nid = node_index(i, j, k)
                nodes[nid] = _make_node(f"P{i}_{j}_{k}", tuple(axes_names))

    axis_lookup = {
        node_id: {name: index for index, name in enumerate(node.axes_names)}
        for node_id, node in nodes.items()
    }

    for i in range(lx):
        for j in range(ly):
            for k in range(lz):
                nid = node_index(i, j, k)
                if i < lx - 1:
                    rid = node_index(i + 1, j, k)
                    edge_specs.append((nid, rid, "xp", "xm"))
                if j < ly - 1:
                    rid = node_index(i, j + 1, k)
                    edge_specs.append((nid, rid, "yp", "ym"))
                if k < lz - 1:
                    rid = node_index(i, j, k + 1)
                    edge_specs.append((nid, rid, "zp", "zm"))

    edges = [
        _make_contraction_edge(
            _EdgeEndpoint(left_id, axis_lookup[left_id][left_name], left_name),
            _EdgeEndpoint(right_id, axis_lookup[right_id][right_name], right_name),
            name=f"{left_id}_{right_id}",
            label=None,
        )
        for left_id, right_id, left_name, right_name in edge_specs
    ]
    return _GraphData(nodes=nodes, edges=tuple(edges))


def _build_3d_grid_graph_with_dangling_phys(lx: int, ly: int, lz: int) -> _GraphData:
    """3D nearest-neighbor cubic lattice with one dangling phys leg per tensor."""

    def node_index(i: int, j: int, k: int) -> int:
        return i * ly * lz + j * lz + k

    nodes = {}
    edge_specs: list[tuple[int, int, str, str]] = []

    for i in range(lx):
        for j in range(ly):
            for k in range(lz):
                axes_names: list[str] = ["phys"]
                if i > 0:
                    axes_names.append("xm")
                if i < lx - 1:
                    axes_names.append("xp")
                if j > 0:
                    axes_names.append("ym")
                if j < ly - 1:
                    axes_names.append("yp")
                if k > 0:
                    axes_names.append("zm")
                if k < lz - 1:
                    axes_names.append("zp")
                nid = node_index(i, j, k)
                nodes[nid] = _make_node(f"P{i}_{j}_{k}", tuple(axes_names))

    axis_lookup = {
        node_id: {name: index for index, name in enumerate(node.axes_names)}
        for node_id, node in nodes.items()
    }

    for i in range(lx):
        for j in range(ly):
            for k in range(lz):
                nid = node_index(i, j, k)
                if i < lx - 1:
                    rid = node_index(i + 1, j, k)
                    edge_specs.append((nid, rid, "xp", "xm"))
                if j < ly - 1:
                    rid = node_index(i, j + 1, k)
                    edge_specs.append((nid, rid, "yp", "ym"))
                if k < lz - 1:
                    rid = node_index(i, j, k + 1)
                    edge_specs.append((nid, rid, "zp", "zm"))

    edges = [
        _make_contraction_edge(
            _EdgeEndpoint(left_id, axis_lookup[left_id][left_name], left_name),
            _EdgeEndpoint(right_id, axis_lookup[right_id][right_name], right_name),
            name=f"{left_id}_{right_id}",
            label=None,
        )
        for left_id, right_id, left_name, right_name in edge_specs
    ]
    for node_id, axis_map in axis_lookup.items():
        edges.append(
            _make_dangling_edge(
                _EdgeEndpoint(node_id, axis_map["phys"], "phys"),
                name=f"p{node_id}",
                label=None,
            )
        )
    return _GraphData(nodes=nodes, edges=tuple(edges))


def _build_binary_tree_graph_with_leaf_phys() -> _GraphData:
    nodes = {
        0: _make_node("R", ("left", "right")),
        1: _make_node("L", ("parent", "left", "right")),
        2: _make_node("M", ("parent", "left", "right")),
        3: _make_node("LL", ("parent", "phys")),
        4: _make_node("LR", ("parent", "phys")),
        5: _make_node("ML", ("parent", "phys")),
        6: _make_node("MR", ("parent", "phys")),
    }
    edges = (
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "left"),
            _EdgeEndpoint(1, 0, "parent"),
            name="e01",
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 1, "right"),
            _EdgeEndpoint(2, 0, "parent"),
            name="e02",
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 1, "left"),
            _EdgeEndpoint(3, 0, "parent"),
            name="e13",
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 2, "right"),
            _EdgeEndpoint(4, 0, "parent"),
            name="e14",
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 1, "left"),
            _EdgeEndpoint(5, 0, "parent"),
            name="e25",
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 2, "right"),
            _EdgeEndpoint(6, 0, "parent"),
            name="e26",
        ),
        _make_dangling_edge(_EdgeEndpoint(3, 1, "phys"), name="phys_3", label=None),
        _make_dangling_edge(_EdgeEndpoint(4, 1, "phys"), name="phys_4", label=None),
        _make_dangling_edge(_EdgeEndpoint(5, 1, "phys"), name="phys_5", label=None),
        _make_dangling_edge(_EdgeEndpoint(6, 1, "phys"), name="phys_6", label=None),
    )
    return _GraphData(nodes=nodes, edges=edges)


def _build_grid_graph(rows: int, cols: int) -> _GraphData:
    nodes = {}
    edge_specs: list[tuple[int, int, str, str]] = []

    def node_index(row: int, col: int) -> int:
        return row * cols + col

    for row in range(rows):
        for col in range(cols):
            axes_names = []
            if col > 0:
                axes_names.append("left")
            if col < cols - 1:
                axes_names.append("right")
            if row > 0:
                axes_names.append("down")
            if row < rows - 1:
                axes_names.append("up")
            nodes[node_index(row, col)] = _make_node(f"N{row}_{col}", tuple(axes_names))

    axis_lookup = {
        node_id: {name: index for index, name in enumerate(node.axes_names)}
        for node_id, node in nodes.items()
    }

    for row in range(rows):
        for col in range(cols):
            node_id = node_index(row, col)
            if col < cols - 1:
                right_id = node_index(row, col + 1)
                edge_specs.append((node_id, right_id, "right", "left"))
            if row < rows - 1:
                up_id = node_index(row + 1, col)
                edge_specs.append((node_id, up_id, "up", "down"))

    edges = [
        _make_contraction_edge(
            _EdgeEndpoint(left_id, axis_lookup[left_id][left_name], left_name),
            _EdgeEndpoint(right_id, axis_lookup[right_id][right_name], right_name),
            name=f"{left_id}_{right_id}",
            label=None,
        )
        for left_id, right_id, left_name, right_name in edge_specs
    ]
    return _GraphData(nodes=nodes, edges=tuple(edges))


def _build_grid_graph_with_dangling_phys(rows: int, cols: int) -> _GraphData:
    nodes = {}
    edge_specs: list[tuple[int, int, str, str]] = []

    def node_index(row: int, col: int) -> int:
        return row * cols + col

    for row in range(rows):
        for col in range(cols):
            axes_names = []
            if col > 0:
                axes_names.append("left")
            if col < cols - 1:
                axes_names.append("right")
            if row > 0:
                axes_names.append("down")
            if row < rows - 1:
                axes_names.append("up")
            axes_names.append("phys")
            nodes[node_index(row, col)] = _make_node(f"N{row}_{col}", tuple(axes_names))

    axis_lookup = {
        node_id: {name: index for index, name in enumerate(node.axes_names)}
        for node_id, node in nodes.items()
    }

    for row in range(rows):
        for col in range(cols):
            node_id = node_index(row, col)
            if col < cols - 1:
                right_id = node_index(row, col + 1)
                edge_specs.append((node_id, right_id, "right", "left"))
            if row < rows - 1:
                up_id = node_index(row + 1, col)
                edge_specs.append((node_id, up_id, "up", "down"))

    edges = [
        _make_contraction_edge(
            _EdgeEndpoint(left_id, axis_lookup[left_id][left_name], left_name),
            _EdgeEndpoint(right_id, axis_lookup[right_id][right_name], right_name),
            name=f"{left_id}_{right_id}",
            label=None,
        )
        for left_id, right_id, left_name, right_name in edge_specs
    ]
    for node_id in sorted(nodes):
        edges.append(
            _make_dangling_edge(
                _EdgeEndpoint(node_id, axis_lookup[node_id]["phys"], "phys"),
                name=f"p{node_id}",
                label=None,
            )
        )
    return _GraphData(nodes=nodes, edges=tuple(edges))


def _build_planar_cycle_graph() -> _GraphData:
    nodes = {
        0: _make_node("A", ("right", "up")),
        1: _make_node("B", ("left", "up")),
        2: _make_node("C", ("down", "left")),
        3: _make_node("D", ("right", "down")),
    }
    edges = (
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "right"),
            _EdgeEndpoint(1, 0, "left"),
            name="ab",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 1, "up"),
            _EdgeEndpoint(2, 0, "down"),
            name="bc",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 1, "left"),
            _EdgeEndpoint(3, 0, "right"),
            name="cd",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(3, 1, "down"),
            _EdgeEndpoint(0, 1, "up"),
            name="da",
            label=None,
        ),
    )
    return _GraphData(nodes=nodes, edges=edges)


def _build_planar_house_graph_with_phys() -> _GraphData:
    nodes = {
        0: _make_node("A", ("right", "up", "phys")),
        1: _make_node("B", ("left", "up", "phys")),
        2: _make_node("C", ("down", "right", "roof", "phys")),
        3: _make_node("D", ("down", "left", "roof", "phys")),
        4: _make_node("R", ("left_roof", "right_roof", "phys")),
    }
    edges = (
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "right"),
            _EdgeEndpoint(1, 0, "left"),
            name="ab",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 1, "up"),
            _EdgeEndpoint(2, 0, "down"),
            name="ac",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 1, "up"),
            _EdgeEndpoint(3, 0, "down"),
            name="bd",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 1, "right"),
            _EdgeEndpoint(3, 1, "left"),
            name="cd",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 2, "roof"),
            _EdgeEndpoint(4, 0, "left_roof"),
            name="ce",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(3, 2, "roof"),
            _EdgeEndpoint(4, 1, "right_roof"),
            name="de",
            label=None,
        ),
        _make_dangling_edge(_EdgeEndpoint(0, 2, "phys"), name="p0", label=None),
        _make_dangling_edge(_EdgeEndpoint(1, 2, "phys"), name="p1", label=None),
        _make_dangling_edge(_EdgeEndpoint(2, 3, "phys"), name="p2", label=None),
        _make_dangling_edge(_EdgeEndpoint(3, 3, "phys"), name="p3", label=None),
        _make_dangling_edge(_EdgeEndpoint(4, 2, "phys"), name="p4", label=None),
    )
    return _GraphData(nodes=nodes, edges=edges)


def _build_star_with_free_axes() -> _GraphData:
    nodes = {
        0: _make_node("Center", ("left", "right", "up", "down", "f0", "f1", "f2", "f3")),
        1: _make_node("L", ("bond",)),
        2: _make_node("R", ("bond",)),
        3: _make_node("U", ("bond",)),
        4: _make_node("D", ("bond",)),
    }
    edges = [
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "left"),
            _EdgeEndpoint(1, 0, "bond"),
            name="l",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 1, "right"),
            _EdgeEndpoint(2, 0, "bond"),
            name="r",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 2, "up"),
            _EdgeEndpoint(3, 0, "bond"),
            name="u",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 3, "down"),
            _EdgeEndpoint(4, 0, "bond"),
            name="d",
            label=None,
        ),
    ]
    for axis_index in range(4, 8):
        axis_name = nodes[0].axes_names[axis_index]
        edges.append(
            _make_dangling_edge(
                _EdgeEndpoint(0, axis_index, axis_name),
                name=axis_name,
                label=None,
            )
        )
    return _GraphData(nodes=nodes, edges=tuple(edges))


def _build_hypergraph_with_virtual_hub() -> _GraphData:
    nodes = {
        0: _make_node("A", ("h",)),
        1: _make_node("B", ("h",)),
        2: _make_node("C", ("h",)),
        -1: _make_node("", ("h0", "h1", "h2"), label="h", is_virtual=True),
    }
    edges = (
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "h"),
            _EdgeEndpoint(-1, 0, "h0"),
            name="h",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 0, "h"),
            _EdgeEndpoint(-1, 1, "h1"),
            name="h",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 0, "h"),
            _EdgeEndpoint(-1, 2, "h2"),
            name="h",
            label=None,
        ),
    )
    return _GraphData(nodes=nodes, edges=edges)


def _build_einsum_like_mps_graph() -> _GraphData:
    nodes = {
        0: _make_node("A0", ("p", "a")),
        1: _make_node("x0", ("p",)),
        2: _make_node("A1", ("a", "p", "b")),
        3: _make_node("x1", ("p",)),
    }
    edges = (
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "p"),
            _EdgeEndpoint(1, 0, "p"),
            name="p0",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 1, "a"),
            _EdgeEndpoint(2, 0, "a"),
            name="a",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 1, "p"),
            _EdgeEndpoint(3, 0, "p"),
            name="p1",
            label=None,
        ),
        _make_dangling_edge(
            _EdgeEndpoint(2, 2, "b"),
            name="b",
            label=None,
        ),
    )
    return _GraphData(nodes=nodes, edges=edges)


def _build_complete_graph_5() -> _GraphData:
    """K5 complete graph: non-planar, classified as 'generic', uses force-directed fallback."""
    nodes = {}
    for i in range(5):
        axes = [f"e{i}_{j}" for j in range(5) if j != i]
        nodes[i] = _make_node(f"N{i}", tuple(axes))

    axis_by_pair: dict[tuple[int, int], int] = {}
    for i in range(5):
        idx = 0
        for j in range(5):
            if j != i:
                axis_by_pair[(i, j)] = idx
                idx += 1

    edges = []
    for i in range(5):
        for j in range(i + 1, 5):
            name = f"e{i}_{j}"
            edges.append(
                _make_contraction_edge(
                    _EdgeEndpoint(i, axis_by_pair[(i, j)], name),
                    _EdgeEndpoint(j, axis_by_pair[(j, i)], name),
                    name=name,
                    label=None,
                )
            )
    return _GraphData(nodes=nodes, edges=tuple(edges))


def _with_one_dangling_phys_per_node(graph: _GraphData) -> _GraphData:
    nodes = {
        node_id: _make_node(
            node.name,
            (*node.axes_names, "phys"),
            label=node.label,
            is_virtual=node.is_virtual,
        )
        for node_id, node in graph.nodes.items()
    }
    edges = list(graph.edges)
    for node_id, node in sorted(nodes.items()):
        axis_index = len(node.axes_names) - 1
        edges.append(
            _make_dangling_edge(
                _EdgeEndpoint(node_id, axis_index, "phys"),
                name=f"p{node_id}",
                label=None,
            )
        )
    return _GraphData(nodes=nodes, edges=tuple(edges))


def _build_grid_with_leaf_nodes() -> _GraphData:
    nodes = {
        0: _make_node("P00", ("right", "up", "s")),
        1: _make_node("P01", ("left", "up", "t")),
        2: _make_node("P10", ("right", "down", "v")),
        3: _make_node("P11", ("left", "down", "w")),
        4: _make_node("x00", ("s",)),
        5: _make_node("x01", ("t",)),
        6: _make_node("x10", ("v",)),
        7: _make_node("x11", ("w",)),
    }
    edges = (
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "right"),
            _EdgeEndpoint(1, 0, "left"),
            name="h0",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 0, "right"),
            _EdgeEndpoint(3, 0, "left"),
            name="h1",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 1, "up"),
            _EdgeEndpoint(2, 1, "down"),
            name="v0",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 1, "up"),
            _EdgeEndpoint(3, 1, "down"),
            name="v1",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 2, "s"),
            _EdgeEndpoint(4, 0, "s"),
            name="s",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 2, "t"),
            _EdgeEndpoint(5, 0, "t"),
            name="t",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 2, "v"),
            _EdgeEndpoint(6, 0, "v"),
            name="v",
            label=None,
        ),
        _make_contraction_edge(
            _EdgeEndpoint(3, 2, "w"),
            _EdgeEndpoint(7, 0, "w"),
            name="w",
            label=None,
        ),
    )
    return _GraphData(nodes=nodes, edges=edges)


def _build_peps_grid_with_leaf_vectors(rows: int, cols: int) -> tuple[_GraphData, dict[int, int]]:
    nodes: dict[int, _NodeData] = {}
    edges = []
    leaf_parent_by_id: dict[int, int] = {}

    def core_node_id(row: int, col: int) -> int:
        return 2 * (row * cols + col)

    def leaf_node_id(row: int, col: int) -> int:
        return core_node_id(row, col) + 1

    for row in range(rows):
        for col in range(cols):
            axes_names: list[str] = []
            if col > 0:
                axes_names.append("left")
            if col < cols - 1:
                axes_names.append("right")
            if row > 0:
                axes_names.append("down")
            if row < rows - 1:
                axes_names.append("up")
            phys_name = f"p_{row}_{col}"
            axes_names.append(phys_name)
            core_id = core_node_id(row, col)
            leaf_id = leaf_node_id(row, col)
            nodes[core_id] = _make_node(f"P{row}_{col}", tuple(axes_names))
            nodes[leaf_id] = _make_node(f"x{row}_{col}", (phys_name,))
            leaf_parent_by_id[leaf_id] = core_id

    axis_lookup = {
        node_id: {name: index for index, name in enumerate(node.axes_names)}
        for node_id, node in nodes.items()
    }

    for row in range(rows):
        for col in range(cols):
            core_id = core_node_id(row, col)
            if col < cols - 1:
                right_id = core_node_id(row, col + 1)
                edges.append(
                    _make_contraction_edge(
                        _EdgeEndpoint(core_id, axis_lookup[core_id]["right"], "right"),
                        _EdgeEndpoint(right_id, axis_lookup[right_id]["left"], "left"),
                        name=f"h_{row}_{col}",
                        label=None,
                    )
                )
            if row < rows - 1:
                up_id = core_node_id(row + 1, col)
                edges.append(
                    _make_contraction_edge(
                        _EdgeEndpoint(core_id, axis_lookup[core_id]["up"], "up"),
                        _EdgeEndpoint(up_id, axis_lookup[up_id]["down"], "down"),
                        name=f"v_{row}_{col}",
                        label=None,
                    )
                )
            phys_name = f"p_{row}_{col}"
            leaf_id = leaf_node_id(row, col)
            edges.append(
                _make_contraction_edge(
                    _EdgeEndpoint(core_id, axis_lookup[core_id][phys_name], phys_name),
                    _EdgeEndpoint(leaf_id, 0, phys_name),
                    name=phys_name,
                    label=None,
                )
            )
    return _GraphData(nodes=nodes, edges=tuple(edges)), leaf_parent_by_id


def _segment_segment_min_distance_sq_3d(
    start_a: np.ndarray,
    end_a: np.ndarray,
    start_b: np.ndarray,
    end_b: np.ndarray,
) -> float:
    """Squared minimum distance between two 3D segments."""

    delta_a = end_a - start_a
    delta_b = end_b - start_b
    offset = start_a - start_b
    aa = float(np.dot(delta_a, delta_a))
    ab = float(np.dot(delta_a, delta_b))
    bb = float(np.dot(delta_b, delta_b))
    ao = float(np.dot(delta_a, offset))
    bo = float(np.dot(delta_b, offset))
    denom = aa * bb - ab * ab
    small = 1e-12
    s_num = 0.0
    s_den = denom
    t_num = 0.0
    t_den = denom

    if denom < small:
        s_num = 0.0
        s_den = 1.0
        t_num = bo
        t_den = bb
    else:
        s_num = ab * bo - bb * ao
        t_num = aa * bo - ab * ao
        if s_num < 0.0:
            s_num = 0.0
            t_num = bo
            t_den = bb
        elif s_num > s_den:
            s_num = s_den
            t_num = bo + ab
            t_den = bb

    if t_num < 0.0:
        t_num = 0.0
        if -ao < 0.0:
            s_num = 0.0
        elif -ao > aa:
            s_num = s_den
        else:
            s_num = -ao
            s_den = aa
    elif t_num > t_den:
        t_num = t_den
        if (-ao + ab) < 0.0:
            s_num = 0.0
        elif (-ao + ab) > aa:
            s_num = s_den
        else:
            s_num = -ao + ab
            s_den = aa

    s_param = 0.0 if abs(s_num) < small else s_num / s_den
    t_param = 0.0 if abs(t_num) < small else t_num / t_den
    delta = offset + s_param * delta_a - t_param * delta_b
    return float(np.dot(delta, delta))


def _principal_axis(points: np.ndarray) -> np.ndarray:
    centered = points - points.mean(axis=0, keepdims=True)
    _, _, vh = np.linalg.svd(centered, full_matrices=False)
    axis = vh[0]
    return axis / np.linalg.norm(axis)


def test_compute_layout_line_chain_2d_is_colinear_and_evenly_spaced() -> None:
    graph = _build_chain_graph(length=4, dangling_axis_counts={0: 1, 3: 1})

    positions = _compute_layout(graph, dimensions=2, seed=0)
    coords = np.stack([positions[node_id] for node_id in range(4)])

    assert np.allclose(coords[:, 1], 0.0, atol=1e-6)
    assert np.all(np.diff(coords[:, 0]) > 0.0)
    assert np.allclose(np.diff(coords[:, 0]), np.diff(coords[:, 0])[0], atol=1e-6)


def test_compute_layout_line_chain_3d_keeps_backbone_straight_and_planar() -> None:
    graph = _build_chain_graph(length=4, dangling_axis_counts={0: 1, 3: 1})

    positions = _compute_layout(graph, dimensions=3, seed=0)
    coords = np.stack([positions[node_id] for node_id in range(4)])

    assert np.allclose(coords[:, 1], 0.0, atol=1e-6)
    assert np.allclose(coords[:, 2], 0.0, atol=1e-6)
    assert np.all(np.diff(coords[:, 0]) > 0.0)
    assert np.allclose(np.diff(coords[:, 0]), np.diff(coords[:, 0])[0], atol=1e-6)


def test_compute_layout_einsum_like_mps_2d_reattaches_degree_one_nodes_as_Ls() -> None:
    graph = _build_einsum_like_mps_graph()

    positions = _compute_layout(graph, dimensions=2, seed=0)

    assert np.allclose(positions[0][1], positions[2][1], atol=1e-6)
    assert positions[0][0] < positions[2][0]
    assert np.allclose(positions[1][0], positions[0][0], atol=1e-6)
    assert np.allclose(positions[3][0], positions[2][0], atol=1e-6)
    assert abs(positions[1][1] - positions[0][1]) > 0.2
    assert abs(positions[3][1] - positions[2][1]) > 0.2


def test_compute_layout_einsum_like_mps_3d_reattaches_degree_one_nodes_orthogonally() -> None:
    graph = _build_einsum_like_mps_graph()

    positions = _compute_layout(graph, dimensions=3, seed=0)
    left_vector = positions[1] - positions[0]
    right_vector = positions[3] - positions[2]

    assert np.allclose(positions[0][1:], positions[2][1:], atol=1e-6)
    assert positions[0][0] < positions[2][0]
    assert abs(left_vector[0]) < 1e-6
    assert abs(right_vector[0]) < 1e-6
    assert np.linalg.norm(left_vector[1:]) > 0.2
    assert np.linalg.norm(right_vector[1:]) > 0.2


def test_compute_axis_directions_einsum_like_mps_3d_avoids_reusing_leaf_direction() -> None:
    graph = _build_einsum_like_mps_graph()

    positions = _compute_layout(graph, dimensions=3, seed=0)
    directions = _compute_axis_directions(graph, positions, dimensions=3)

    assert np.allclose(directions[(2, 1)], np.array([0.0, 0.0, 1.0]), atol=1e-6)
    assert np.allclose(directions[(2, 2)], np.array([0.0, 0.0, -1.0]), atol=1e-6)


def test_compute_layout_grid_with_leaf_nodes_2d_keeps_leaf_positions_off_core_nodes() -> None:
    graph = _build_grid_with_leaf_nodes()

    positions = _compute_layout(graph, dimensions=2, seed=0)
    core_positions = [positions[node_id] for node_id in range(4)]

    for leaf_id in range(4, 8):
        assert all(
            not np.allclose(positions[leaf_id], core_position, atol=1e-6)
            for core_position in core_positions
        )


def _assert_peps_leaf_vectors_clear_2d(rows: int, cols: int) -> None:
    graph, leaf_parent_by_id = _build_peps_grid_with_leaf_vectors(rows, cols)
    positions = _compute_layout(graph, dimensions=2, seed=0)
    draw_scale = _resolve_draw_scale(graph, positions)
    r_disk = float(PlotConfig.DEFAULT_NODE_RADIUS) * max(float(draw_scale), 1e-6) * 1.08
    bond_segments = _planar_contraction_bond_segments_2d(graph, positions, scale=draw_scale)

    for leaf_id, parent_id in leaf_parent_by_id.items():
        parent = np.asarray(positions[parent_id], dtype=float).reshape(-1)[:2]
        leaf = np.asarray(positions[leaf_id], dtype=float).reshape(-1)[:2]
        for node_id, node_position in positions.items():
            if node_id in {leaf_id, parent_id}:
                continue
            other = np.asarray(node_position, dtype=float).reshape(-1)[:2]
            assert np.linalg.norm(leaf - other) >= r_disk - 1e-9
        for left_id, right_id, bond_start, bond_end in bond_segments:
            if left_id in {leaf_id, parent_id} or right_id in {leaf_id, parent_id}:
                continue
            assert not _segments_cross_2d(parent, leaf, bond_start, bond_end)


def test_compute_layout_peps_leaf_vectors_2d_clear_other_core_nodes_3x3() -> None:
    _assert_peps_leaf_vectors_clear_2d(3, 3)


def test_compute_layout_peps_leaf_vectors_2d_clear_other_core_nodes_4x4() -> None:
    _assert_peps_leaf_vectors_clear_2d(4, 4)


def test_compute_layout_peps_leaf_vectors_2d_regular_grid_boundary_faces_prefer_cardinals() -> None:
    graph, _leaf_parent_by_id = _build_peps_grid_with_leaf_vectors(3, 3)
    positions = _compute_layout(graph, dimensions=2, seed=0)

    expected_by_site = {
        (2, 0): np.array([0.0, 1.0], dtype=float),
        (2, 1): np.array([0.0, 1.0], dtype=float),
        (2, 2): np.array([0.0, 1.0], dtype=float),
        (0, 0): np.array([0.0, -1.0], dtype=float),
        (0, 1): np.array([0.0, -1.0], dtype=float),
        (0, 2): np.array([0.0, -1.0], dtype=float),
        (1, 0): np.array([-1.0, 0.0], dtype=float),
        (1, 2): np.array([1.0, 0.0], dtype=float),
    }

    for (row, col), expected in expected_by_site.items():
        parent_id = 2 * (row * 3 + col)
        leaf_id = parent_id + 1
        direction = np.asarray(
            positions[leaf_id] - positions[parent_id],
            dtype=float,
        ).reshape(-1)[:2]
        direction /= np.linalg.norm(direction)
        assert np.allclose(direction, expected, atol=1e-6), (row, col, direction)


def test_compute_axis_directions_grid_2d_phys_legs_follow_shell_behaviors() -> None:
    graph = _build_grid_graph_with_dangling_phys(3, 3)
    positions = {
        row * 3 + col: np.array([float(col), float(row)], dtype=float)
        for row in range(3)
        for col in range(3)
    }

    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=1.0)

    expected_by_site = {
        (2, 0): np.array([0.0, 1.0], dtype=float),
        (2, 1): np.array([0.0, 1.0], dtype=float),
        (2, 2): np.array([0.0, 1.0], dtype=float),
        (0, 0): np.array([0.0, -1.0], dtype=float),
        (0, 1): np.array([0.0, -1.0], dtype=float),
        (0, 2): np.array([0.0, -1.0], dtype=float),
        (1, 0): np.array([-1.0, 0.0], dtype=float),
        (1, 1): np.array([1.0, 1.0], dtype=float) / np.sqrt(2.0),
        (1, 2): np.array([1.0, 0.0], dtype=float),
    }

    for (row, col), expected in expected_by_site.items():
        node_id = row * 3 + col
        axis_index = graph.nodes[node_id].axes_names.index("phys")
        assert np.allclose(directions[(node_id, axis_index)], expected, atol=1e-6)


def test_compute_layout_grid_2d_places_nodes_on_regular_lattice() -> None:
    graph = _build_grid_graph(2, 2)

    positions = _compute_layout(graph, dimensions=2, seed=0)
    coords = np.stack([positions[node_id] for node_id in sorted(graph.nodes)])
    x_values = np.unique(np.round(coords[:, 0], decimals=6))
    y_values = np.unique(np.round(coords[:, 1], decimals=6))

    assert len(x_values) == 2
    assert len(y_values) == 2
    assert math.isclose(
        abs(x_values[1] - x_values[0]),
        abs(y_values[1] - y_values[0]),
        rel_tol=1e-6,
    )


def test_compute_layout_3d_grid_spans_three_axes() -> None:
    graph = _build_3d_grid_graph(2, 2, 2)

    positions = _compute_layout(graph, dimensions=3, seed=0)
    coords = np.stack([positions[node_id] for node_id in sorted(graph.nodes)])

    assert float(coords[:, 0].std()) > 1e-6
    assert float(coords[:, 1].std()) > 1e-6
    assert float(coords[:, 2].std()) > 1e-6


def test_compute_layout_3d_grid_uniform_nearest_neighbor_spacing() -> None:
    graph = _build_3d_grid_graph(2, 3, 2)

    positions = _compute_layout(graph, dimensions=3, seed=0)
    lengths: list[float] = []
    for edge in graph.edges:
        left_ep, right_ep = edge.endpoints
        delta = positions[left_ep.node_id] - positions[right_ep.node_id]
        lengths.append(float(np.linalg.norm(delta)))

    assert lengths
    mean_len = float(np.mean(lengths))
    assert all(math.isclose(L, mean_len, rel_tol=1e-5, abs_tol=1e-8) for L in lengths)


def test_compute_layout_2d_grid3d_depth_projects_with_positive_x_and_negative_y() -> None:
    graph = _build_3d_grid_graph(2, 2, 3)

    positions = _compute_layout(graph, dimensions=2, seed=0)
    component = _analyze_layout_components_cached(graph)[0]
    assert component.grid3d_mapping is not None

    node_id_by_coords = {coords: node_id for node_id, coords in component.grid3d_mapping.items()}
    p000 = positions[node_id_by_coords[(0, 0, 0)]]
    p001 = positions[node_id_by_coords[(0, 0, 1)]]
    p002 = positions[node_id_by_coords[(0, 0, 2)]]

    assert float(p001[0]) > float(p000[0])
    assert float(p001[1]) < float(p000[1])
    assert float(p002[0]) > float(p001[0])
    assert float(p002[1]) < float(p001[1])


def test_layered_visible_order_2d_draws_grid3d_from_far_face_to_near_face() -> None:
    import tensor_network_viz._core.draw.render_prep as render_prep

    graph = _build_3d_grid_graph(2, 2, 3)

    layered_order = render_prep._layered_visible_order_2d(graph)
    component = _analyze_layout_components_cached(graph)[0]
    k_sequence = [component.grid3d_mapping[node_id][2] for node_id in layered_order]

    assert k_sequence == sorted(k_sequence)


def test_layered_tensor_label_zorders_2d_stay_above_all_node_disks() -> None:
    import tensor_network_viz._core.draw.render_prep as render_prep

    graph = _build_3d_grid_graph(2, 2, 3)

    visible_order = list(render_prep._layered_visible_order_2d(graph))
    label_zorders = render_prep._layered_tensor_label_zorders_2d(visible_order)
    max_disk_zorder = max(
        render_prep._ZORDER_LAYER_BASE
        + index * render_prep._ZORDER_LAYER_STRIDE
        + render_prep._ZORDER_LAYER_DISK
        for index, _node_id in enumerate(visible_order)
    )

    assert label_zorders
    assert all(zorder > max_disk_zorder for zorder in label_zorders.values())


def test_register_render_hover_2d_uses_layered_visible_order_for_grid3d(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure

    import tensor_network_viz._core.draw.render_prep as render_prep

    graph = _build_3d_grid_graph(2, 2, 3)
    positions = _compute_layout(graph, dimensions=2, seed=0)
    directions = _compute_axis_directions(graph, positions, dimensions=2)
    scale = _resolve_draw_scale(graph, positions)

    fig = Figure()
    FigureCanvasAgg(fig)
    ax = fig.add_subplot(111)
    try:
        context = render_prep._prepare_render_context(
            ax=ax,
            graph=graph,
            positions=positions,
            config=PlotConfig(hover_labels=True),
            dimensions=2,
            scale=scale,
            show_tensor_labels=True,
            show_index_labels=False,
        )
        render_prep._draw_edges_nodes_and_labels(
            ax=ax,
            context=context,
            directions=directions,
            show_tensor_labels=True,
            show_index_labels=False,
            tensor_disk_radius_px_3d=None,
        )

        captured: dict[str, tuple[int, ...]] = {}

        def _capture_hover_state(
            state: render_prep._RenderHoverState,
            *,
            scheme_patches_2d: object | None = None,
            scheme_aabbs_3d: object | None = None,
        ) -> None:
            del scheme_patches_2d, scheme_aabbs_3d
            captured["visible_node_ids"] = state.visible_node_ids

        monkeypatch.setattr(render_prep, "_apply_saved_hover_state", _capture_hover_state)

        render_prep._register_render_hover(
            ax=ax,
            context=context,
            show_tensor_labels=True,
            show_index_labels=False,
            scheme_patches_2d=[],
            scheme_aabbs_3d=[],
            tensor_disk_radius_px_3d=None,
        )

        assert captured["visible_node_ids"] == render_prep._layered_visible_order_2d(graph)
    finally:
        fig.clear()


def test_build_interactive_scene_state_2d_uses_layered_visible_order_for_grid3d() -> None:
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure

    import tensor_network_viz._core.draw.render_prep as render_prep

    graph = _build_3d_grid_graph(2, 2, 3)
    positions = _compute_layout(graph, dimensions=2, seed=0)
    directions = _compute_axis_directions(graph, positions, dimensions=2)
    scale = _resolve_draw_scale(graph, positions)

    fig = Figure()
    FigureCanvasAgg(fig)
    ax = fig.add_subplot(111)
    try:
        context = render_prep._prepare_render_context(
            ax=ax,
            graph=graph,
            positions=positions,
            config=PlotConfig(hover_labels=True),
            dimensions=2,
            scale=scale,
            show_tensor_labels=True,
            show_index_labels=False,
        )
        render_prep._draw_edges_nodes_and_labels(
            ax=ax,
            context=context,
            directions=directions,
            show_tensor_labels=True,
            show_index_labels=False,
            tensor_disk_radius_px_3d=None,
        )
        hover_state = render_prep._RenderHoverState(
            ax=ax,
            figure=ax.figure,
            dimensions=2,
            node_patch_coll=render_prep._node_patch_collection_from_plotter(context),
            visible_node_ids=(),
            tensor_hover=dict(context.tensor_hover_by_node or {}),
            edge_hover=tuple(context.hover_edge_targets or ()),
            line_width_px_hint=float(context.params.lw),
        )

        scene = render_prep._build_interactive_scene_state(
            ax=ax,
            context=context,
            directions=directions,
            scale=scale,
            hover_state=hover_state,
            tensor_disk_radius_px_3d=None,
        )

        assert scene.visible_node_ids == render_prep._layered_visible_order_2d(graph)
    finally:
        fig.clear()


def test_compute_layout_planar_cycle_3d_stays_on_single_plane() -> None:
    graph = _build_planar_cycle_graph()

    positions = _compute_layout(graph, dimensions=3, seed=0)
    coords = np.stack([positions[node_id] for node_id in sorted(graph.nodes)])

    assert np.allclose(coords[:, 2], 0.0, atol=1e-6)


def test_compute_axis_directions_chain_3d_assigns_orthogonal_open_end() -> None:
    graph = _build_chain_graph(length=3, dangling_axis_counts={0: 1, 2: 1})

    positions = _compute_layout(graph, dimensions=3, seed=0)
    directions = _compute_axis_directions(graph, positions, dimensions=3)

    assert np.allclose(directions[(0, 1)], np.array([0.0, 0.0, 1.0]), atol=1e-6)


def test_compute_axis_directions_3d_supports_xp_alias_for_free_axes() -> None:
    graph = _GraphData(
        nodes={
            0: _make_node("A", ("up", "xp")),
            1: _make_node("B", ("down",)),
        },
        edges=(
            _make_contraction_edge(
                _EdgeEndpoint(0, 0, "up"),
                _EdgeEndpoint(1, 0, "down"),
                name="vertical",
                label=None,
            ),
        ),
    )
    positions = {
        0: np.array([0.0, 0.0, 0.0], dtype=float),
        1: np.array([0.0, 1.0, 0.0], dtype=float),
    }

    directions = _compute_axis_directions(graph, positions, dimensions=3)

    assert np.allclose(directions[(0, 1)], np.array([1.0, 0.0, 0.0]), atol=1e-6)


def test_compute_axis_directions_competing_free_axes_prefer_unused_orthogonal_directions() -> None:
    graph = _build_star_with_free_axes()

    positions = _compute_layout(graph, dimensions=3, seed=0)
    directions = _compute_axis_directions(graph, positions, dimensions=3)

    assert np.allclose(directions[(0, 4)], np.array([0.0, 1.0, 0.0]), atol=1e-6)
    assert np.allclose(directions[(0, 5)], np.array([0.0, -1.0, 0.0]), atol=1e-6)
    for axis_index in range(6, 8):
        assert np.isclose(np.linalg.norm(directions[(0, axis_index)]), 1.0, atol=1e-6)


def test_compute_axis_directions_cubic_phys_stubs_3d_clear_nonincident_bonds() -> None:
    graph = _build_3d_grid_graph_with_dangling_phys(3, 3, 2)

    positions = _compute_layout(graph, dimensions=3, seed=0)
    draw_scale = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=3, draw_scale=draw_scale)
    bond_segments = [
        (
            int(left_id),
            int(right_id),
            np.asarray(positions[left_id], dtype=float).reshape(-1)[:3],
            np.asarray(positions[right_id], dtype=float).reshape(-1)[:3],
        )
        for left_id, right_id in (
            edge.node_ids for edge in graph.edges if edge.kind == "contraction"
        )
    ]

    for edge in graph.edges:
        if edge.kind != "dangling":
            continue
        endpoint = edge.endpoints[0]
        origin = np.asarray(positions[endpoint.node_id], dtype=float).reshape(-1)[:3]
        direction = np.asarray(
            directions[(endpoint.node_id, endpoint.axis_index)],
            dtype=float,
        ).reshape(-1)[:3]
        start, end = _dangling_stub_segment_3d(origin, direction, draw_scale=draw_scale)
        for left_id, right_id, bond_start, bond_end in bond_segments:
            if endpoint.node_id in {left_id, right_id}:
                continue
            distance = math.sqrt(
                _segment_segment_min_distance_sq_3d(start, end, bond_start, bond_end)
            )
            assert distance >= 0.2 - 1e-9


def test_compute_axis_directions_cubic_phys_stubs_3d_face_centers_point_outward() -> None:
    graph = _build_3d_grid_graph_with_dangling_phys(3, 3, 3)

    positions = _compute_layout(graph, dimensions=3, seed=0)
    directions = _compute_axis_directions(graph, positions, dimensions=3)
    component = _analyze_layout_components_cached(graph)[0]
    node_id_by_coords = {coords: node_id for node_id, coords in component.grid3d_mapping.items()}
    centroid = np.mean(
        np.stack(
            [
                np.asarray(positions[node_id], dtype=float).reshape(-1)[:3]
                for node_id in component.anchor_node_ids
            ],
            axis=0,
        ),
        axis=0,
    )

    face_center_coords = (
        (2, 1, 1),
        (1, 2, 1),
        (1, 1, 2),
        (0, 1, 1),
        (1, 0, 1),
        (1, 1, 0),
    )
    for coords in face_center_coords:
        node_id = node_id_by_coords[coords]
        axis_index = graph.nodes[node_id].axes_names.index("phys")
        direction = np.asarray(directions[(node_id, axis_index)], dtype=float).reshape(-1)[:3]
        direction /= np.linalg.norm(direction)
        outward = np.asarray(positions[node_id], dtype=float).reshape(-1)[:3] - centroid
        outward /= np.linalg.norm(outward)
        assert float(np.dot(direction, outward)) > 0.95, (coords, direction, outward)


def test_compute_axis_directions_cubic_phys_stubs_2d_clear_nonincident_projected_bonds() -> None:
    graph = _build_3d_grid_graph_with_dangling_phys(3, 3, 2)

    positions = _compute_layout(graph, dimensions=2, seed=0)
    draw_scale = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=draw_scale)
    component = _analyze_layout_components_cached(graph)[0]
    radius = float(PlotConfig.DEFAULT_NODE_RADIUS) * max(float(draw_scale), 1e-6)

    for edge in graph.edges:
        if edge.kind != "dangling":
            continue
        endpoint = edge.endpoints[0]
        origin = np.asarray(positions[endpoint.node_id], dtype=float).reshape(-1)[:2]
        direction = np.asarray(
            directions[(endpoint.node_id, endpoint.axis_index)],
            dtype=float,
        ).reshape(-1)[:2]
        _start, end = _dangling_stub_segment_2d(origin, direction, draw_scale=draw_scale)
        first_neighbors = set(component.contraction_graph.neighbors(endpoint.node_id))
        second_neighbors = {
            second_id
            for neighbor_id in first_neighbors
            for second_id in component.contraction_graph.neighbors(neighbor_id)
            if second_id != endpoint.node_id
        }
        for neighbor_id in sorted(first_neighbors | second_neighbors):
            other = np.asarray(positions[neighbor_id], dtype=float).reshape(-1)[:2]
            assert np.linalg.norm(end - other) >= radius - 1e-9


def test_compute_axis_directions_grid3d_2d_top_and_bottom_shells_keep_free_cardinals() -> None:
    graph = _build_3d_grid_graph_with_dangling_phys(2, 3, 2)

    positions = _compute_layout(graph, dimensions=2, seed=0)
    draw_scale = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=draw_scale)

    y_by_node = {
        node_id: round(float(np.asarray(position, dtype=float).reshape(-1)[1]), 6)
        for node_id, position in positions.items()
    }
    top_y = max(y_by_node.values())
    bottom_y = min(y_by_node.values())
    top_node_ids = [node_id for node_id, y in y_by_node.items() if y == top_y]
    bottom_node_ids = [node_id for node_id, y in y_by_node.items() if y == bottom_y]

    assert top_node_ids
    assert bottom_node_ids

    for node_id in top_node_ids:
        axis_index = graph.nodes[node_id].axes_names.index("phys")
        assert np.allclose(
            directions[(node_id, axis_index)],
            np.array([0.0, 1.0], dtype=float),
            atol=1e-6,
        ), graph.nodes[node_id].name

    for node_id in bottom_node_ids:
        axis_index = graph.nodes[node_id].axes_names.index("phys")
        assert np.allclose(
            directions[(node_id, axis_index)],
            np.array([0.0, -1.0], dtype=float),
            atol=1e-6,
        ), graph.nodes[node_id].name


def test_compute_layout_virtual_hub_uses_incident_barycenter() -> None:
    graph = _build_hypergraph_with_virtual_hub()

    positions = _compute_layout(graph, dimensions=2, seed=0)
    visible_coords = np.stack([positions[node_id] for node_id in (0, 1, 2)])

    assert np.allclose(positions[-1], visible_coords.mean(axis=0), atol=1e-6)


def test_compute_layout_hypergraph_3d_keeps_visible_nodes_planar() -> None:
    graph = _build_hypergraph_with_virtual_hub()

    positions = _compute_layout(graph, dimensions=3, seed=0)
    visible_coords = np.stack([positions[node_id] for node_id in (0, 1, 2)])
    axis = _principal_axis(visible_coords)
    residuals = visible_coords - visible_coords.mean(axis=0, keepdims=True)
    off_axis = residuals - np.outer(residuals @ axis, axis)

    assert np.max(np.linalg.norm(off_axis, axis=1)) > 0.2
    assert np.allclose(visible_coords[:, 2], 0.0, atol=1e-6)


def test_compute_layout_generic_graph_uses_force_fallback_produces_valid_positions() -> None:
    """Generic (non-planar) graphs fall back to force-directed layout; output must be valid."""
    graph = _build_complete_graph_5()

    positions = _compute_layout(graph, dimensions=2, seed=0, iterations=50)

    assert len(positions) == 5
    coords = np.stack([positions[i] for i in range(5)])
    assert not np.any(np.isnan(coords))
    assert not np.any(np.isinf(coords))
    assert np.all(np.isfinite(coords))


def test_tree_component_layout_2d_skips_force_layout_when_anchors_cover_all_nodes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    graph = _build_binary_tree_graph_with_leaf_phys()
    component = _analyze_layout_components_cached(graph)[0]

    def fail_force_layout(*args: object, **kwargs: object) -> dict[int, np.ndarray]:
        del args, kwargs
        raise AssertionError("_compute_force_layout should not run for fully anchored trees")

    monkeypatch.setattr(
        "tensor_network_viz._core.layout.positions._compute_force_layout",
        fail_force_layout,
    )

    positions = _compute_component_layout_2d(graph, component, seed=0, iterations=1)

    assert set(positions) == set(graph.nodes)


def test_compute_axis_directions_tree_2d_leaf_phys_legs_prefer_south_when_corridor_is_free() -> (
    None
):
    graph = _build_binary_tree_graph_with_leaf_phys()

    positions = _compute_layout(graph, dimensions=2, seed=0)
    draw_scale = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=draw_scale)

    for leaf_id in (3, 4, 5, 6):
        axis_index = graph.nodes[leaf_id].axes_names.index("phys")
        assert np.allclose(
            directions[(leaf_id, axis_index)],
            np.array([0.0, -1.0], dtype=float),
            atol=1e-6,
        ), graph.nodes[leaf_id].name


def _neighbor_shell_ids(component: object, node_id: int) -> tuple[set[int], set[int]]:
    first_neighbors = set(component.contraction_graph.neighbors(node_id))
    second_neighbors = {
        second_id
        for neighbor_id in first_neighbors
        for second_id in component.contraction_graph.neighbors(neighbor_id)
        if second_id != node_id and second_id not in first_neighbors
    }
    return first_neighbors, second_neighbors


def _assert_local_neighbor_rules_hold_2d(
    graph: _GraphData,
    positions: dict[int, np.ndarray],
    directions: dict[tuple[int, int], np.ndarray],
    *,
    draw_scale: float,
) -> None:
    component = _analyze_layout_components_cached(graph)[0]
    radius = float(PlotConfig.DEFAULT_NODE_RADIUS) * max(float(draw_scale), 1e-6)

    for edge in graph.edges:
        if edge.kind != "dangling":
            continue
        endpoint = edge.endpoints[0]
        first_neighbors, second_neighbors = _neighbor_shell_ids(component, endpoint.node_id)
        origin = np.asarray(positions[endpoint.node_id], dtype=float).reshape(-1)[:2]
        direction = np.asarray(
            directions[(endpoint.node_id, endpoint.axis_index)],
            dtype=float,
        ).reshape(-1)[:2]
        _start, end = _dangling_stub_segment_2d(origin, direction, draw_scale=draw_scale)

        for neighbor_id in sorted(first_neighbors | second_neighbors):
            other = np.asarray(positions[neighbor_id], dtype=float).reshape(-1)[:2]
            assert np.linalg.norm(end - other) >= radius - 1e-9

        for other_edge in graph.edges:
            if other_edge.kind == "contraction":
                left_endpoint, right_endpoint = other_edge.endpoints
                left_id = left_endpoint.node_id
                right_id = right_endpoint.node_id
                if endpoint.node_id in {left_id, right_id}:
                    continue
                if left_id not in first_neighbors | second_neighbors and right_id not in (
                    first_neighbors | second_neighbors
                ):
                    continue
                bond_start = np.asarray(positions[left_id], dtype=float).reshape(-1)[:2]
                bond_end = np.asarray(positions[right_id], dtype=float).reshape(-1)[:2]
                assert not _segments_cross_2d(_start, end, bond_start, bond_end)
                continue

            other_endpoint = other_edge.endpoints[0]
            if other_endpoint.node_id not in first_neighbors | second_neighbors:
                continue
            other_direction = np.asarray(
                directions[(other_endpoint.node_id, other_endpoint.axis_index)],
                dtype=float,
            ).reshape(-1)[:2]
            other_start, other_end = _dangling_stub_segment_2d(
                positions[other_endpoint.node_id],
                other_direction,
                draw_scale=draw_scale,
            )
            assert not _segments_cross_2d(_start, end, other_start, other_end)


def test_compute_axis_directions_tree_2d_phys_legs_respect_local_neighbor_rules() -> None:
    graph = _build_binary_tree_graph_with_leaf_phys()

    positions = _compute_layout(graph, dimensions=2, seed=0)
    draw_scale = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=draw_scale)

    _assert_local_neighbor_rules_hold_2d(graph, positions, directions, draw_scale=draw_scale)


def test_compute_axis_directions_planar_2d_phys_legs_respect_local_neighbor_rules() -> None:
    graph = _build_planar_house_graph_with_phys()

    positions = _compute_layout(graph, dimensions=2, seed=0)
    draw_scale = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=draw_scale)

    _assert_local_neighbor_rules_hold_2d(graph, positions, directions, draw_scale=draw_scale)


def test_compute_axis_directions_generic_2d_phys_legs_respect_local_neighbor_rules() -> None:
    graph = _with_one_dangling_phys_per_node(_build_complete_graph_5())

    positions = _compute_layout(graph, dimensions=2, seed=0, iterations=50)
    draw_scale = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=draw_scale)

    _assert_local_neighbor_rules_hold_2d(graph, positions, directions, draw_scale=draw_scale)


def test_weird_topology_2d_phys_stubs_do_not_cross() -> None:
    """Regression: example 'weird' graph must not draw crossing dangling (phys) segments in 2D."""
    nodes = {
        0: _make_node("center", ("north", "east", "south", "west", "phys")),
        1: _make_node("north", ("center", "east", "phys")),
        2: _make_node("east", ("center", "north", "south", "phys")),
        3: _make_node("south", ("center", "east", "west_a", "west_b", "phys")),
        4: _make_node("west", ("center", "south_a", "south_b", "phys")),
    }
    edges = [
        _make_contraction_edge(
            _EdgeEndpoint(0, 0, "north"), _EdgeEndpoint(1, 0, "center"), name=None
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 1, "east"), _EdgeEndpoint(2, 0, "center"), name=None
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 2, "south"), _EdgeEndpoint(3, 0, "center"), name=None
        ),
        _make_contraction_edge(
            _EdgeEndpoint(0, 3, "west"), _EdgeEndpoint(4, 0, "center"), name=None
        ),
        _make_contraction_edge(
            _EdgeEndpoint(1, 1, "east"), _EdgeEndpoint(2, 1, "north"), name=None
        ),
        _make_contraction_edge(
            _EdgeEndpoint(2, 2, "south"), _EdgeEndpoint(3, 1, "east"), name=None
        ),
        _make_contraction_edge(
            _EdgeEndpoint(3, 2, "west_a"), _EdgeEndpoint(4, 1, "south_a"), name=None
        ),
        _make_contraction_edge(
            _EdgeEndpoint(3, 3, "west_b"), _EdgeEndpoint(4, 2, "south_b"), name=None
        ),
        _make_dangling_edge(_EdgeEndpoint(0, 4, "phys"), name="phys"),
        _make_dangling_edge(_EdgeEndpoint(1, 2, "phys"), name="phys"),
        _make_dangling_edge(_EdgeEndpoint(2, 3, "phys"), name="phys"),
        _make_dangling_edge(_EdgeEndpoint(3, 4, "phys"), name="phys"),
        _make_dangling_edge(_EdgeEndpoint(4, 3, "phys"), name="phys"),
    ]
    graph = _GraphData(nodes=nodes, edges=tuple(edges))
    positions = _compute_layout(graph, dimensions=2, seed=0)
    ds = _resolve_draw_scale(graph, positions)
    directions = _compute_axis_directions(graph, positions, dimensions=2, draw_scale=ds)

    stubs: list[tuple[np.ndarray, np.ndarray]] = []
    for edge in graph.edges:
        if edge.kind != "dangling":
            continue
        ep = edge.endpoints[0]
        direction = directions[(ep.node_id, ep.axis_index)]
        origin = positions[ep.node_id]
        stubs.append(_dangling_stub_segment_2d(origin, direction, draw_scale=ds))

    for i in range(len(stubs)):
        for j in range(i + 1, len(stubs)):
            p0, p1 = stubs[i]
            q0, q1 = stubs[j]
            assert not _segments_cross_2d(p0, p1, q0, q1), f"stubs {i} and {j} cross"

    bond_segments = _planar_contraction_bond_segments_2d(graph, positions, scale=ds)
    stub_idx = 0
    for edge in graph.edges:
        if edge.kind != "dangling":
            continue
        ep = edge.endpoints[0]
        p0, p1 = stubs[stub_idx]
        stub_idx += 1
        for a, b, ba, bb in bond_segments:
            if a == ep.node_id or b == ep.node_id:
                continue
            assert not _segments_cross_2d(p0, p1, ba, bb), (
                f"stub from node {ep.node_id} crosses bond {a}-{b}"
            )
