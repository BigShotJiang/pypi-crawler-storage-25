"""Generate pydantic v2 BaseModel classes from schema-salad definitions."""

__version__ = "0.1.9"

PROJECT_NAME = "schema-salad-plus-pydantic"
PROJECT_AUTHOR = "jmchilton"
PROJECT_URL = f"https://github.com/{PROJECT_AUTHOR}/{PROJECT_NAME}"
