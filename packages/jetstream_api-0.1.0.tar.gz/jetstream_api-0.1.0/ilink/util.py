from __future__ import annotations

import io
import struct

from .common import ILC


def _to_signed32(value: int) -> int:
    if value & 0x80000000:
        return value - 0x100000000
    return value


def _to_signed64(value: int) -> int:
    if value & 0x8000000000000000:
        return value - 0x10000000000000000
    return value


def ba_pick_bytes(ba: bytes, offset: int, length: int | None = None) -> bytes:
    if length is None:
        if offset < 0 or offset > len(ba):
            raise ValueError("offset out of range")
        return ba[offset:]
    if length < 0:
        raise ValueError("length must be >= 0")
    end = offset + length
    if offset < 0 or end > len(ba):
        raise ValueError("range out of bounds")
    return ba[offset:end]


def ba_null_trim(ba: bytes, offset: int, max_len: int) -> bytes:
    if max_len < 0:
        raise ValueError("max_len must be >= 0")
    end = min(offset + max_len, len(ba))
    length = max_len
    for i in range(offset, end):
        if ba[i] == 0:
            length = i - offset
            break
    return ba_pick_bytes(ba, offset, length)


def ba_pick_string(ba: bytes, offset: int, length: int, encoding: str | None = None) -> str:
    data = ba_null_trim(ba, offset, length)
    return data.decode(encoding or "utf-8", errors="ignore")


def ba_pick_int(ba: bytes, offset: int, length: int) -> int:
    text = ba_pick_string(ba, offset, length)
    try:
        return int(text)
    except ValueError:
        return 0


def ba_pick_long(ba: bytes, offset: int, length: int) -> int:
    text = ba_pick_string(ba, offset, length)
    try:
        return int(text)
    except ValueError:
        return 0


def ba_merge(value: int | str | bytes, dest: bytearray, dest_offset: int) -> None:
    if isinstance(value, int):
        raw = str(value).encode("utf-8")
    elif isinstance(value, str):
        raw = value.encode("utf-8")
    else:
        raw = value
    end = dest_offset + len(raw)
    if dest_offset < 0 or end > len(dest):
        raise ValueError("destination buffer too small")
    dest[dest_offset:end] = raw


def ba_print(ba: bytes) -> None:
    out = []
    for b in ba:
        out.append(" " if b == 0 else bytes([b]).decode("utf-8", errors="ignore"))
    print("[" + "".join(out) + "]")


class ILInputStream:
    def __init__(self, ba: bytes) -> None:
        if ba is None:
            raise ValueError("ba is None")
        self._buffer = io.BytesIO(ba)
        self._is_little_endian = False

    def read_bytes(self, fixed_length: int) -> bytes | None:
        if fixed_length == 0:
            return None
        data = self._buffer.read(fixed_length)
        if len(data) != fixed_length:
            raise EOFError("insufficient data")
        return data

    def read_bytes_until_null(self) -> bytes:
        chunks = bytearray()
        while True:
            b = self._buffer.read(1)
            if not b:
                raise EOFError("null terminator not found")
            if b == b"":
                break
            chunks.extend(b)
        return bytes(chunks)

    def read_string(self, fixed_length: int, encoding: str | None = None) -> str:
        if fixed_length == 0:
            return ""
        data = self.read_bytes(fixed_length)
        if data is None:
            return ""
        return data.decode(encoding or "utf-8")

    def read_string_default(self, fixed_length: int) -> str:
        return self.read_string(fixed_length, None)

    def read_string_until_null(self, encoding: str | None = None) -> str:
        data = self.read_bytes_until_null()
        return data.decode(encoding or "utf-8")

    def read_int(self) -> int:
        data = self._buffer.read(4)
        if len(data) != 4:
            raise EOFError("insufficient data")
        value = struct.unpack(">I", data)[0]
        if self._is_little_endian:
            value = ILC.swap_int(value & 0xFFFFFFFF)
        return _to_signed32(value)

    def read_long(self) -> int:
        data = self._buffer.read(8)
        if len(data) != 8:
            raise EOFError("insufficient data")
        value = struct.unpack(">Q", data)[0]
        if self._is_little_endian:
            value = ILC.swap_long(value & 0xFFFFFFFFFFFFFFFF)
        return _to_signed64(value)

    def close(self) -> None:
        try:
            self._buffer.close()
        except Exception:
            pass

    def set_little_endian(self, value: bool) -> None:
        self._is_little_endian = value

    def __del__(self) -> None:
        self.close()


class ILOutputStream:
    def __init__(self, size: int) -> None:
        self._size = size
        self._buffer = io.BytesIO()
        self._is_little_endian = False

    def write_bytes(self, ba: bytes | None) -> None:
        if ba is None:
            return
        self._buffer.write(ba)

    def write_bytes_fixed(self, ba: bytes | None, fixed_length: int) -> None:
        if ba is None:
            return
        if len(ba) < fixed_length:
            raise ValueError("byte array too short for fixed_length")
        self._buffer.write(ba[:fixed_length])

    def write_string(self, fixed_string: str) -> None:
        self.write_bytes(fixed_string.encode("utf-8"))

    def write_string_encoded(self, fixed_string: str, encoding: str) -> None:
        self.write_bytes(fixed_string.encode(encoding))

    def write_string_fixed(self, fixed_string: str, fixed_length: int) -> None:
        self.write_bytes_fixed(fixed_string.encode("utf-8"), fixed_length)

    def write_string_fixed_encoded(self, fixed_string: str, fixed_length: int, encoding: str) -> None:
        self.write_bytes_fixed(fixed_string.encode(encoding), fixed_length)

    def write_int(self, number: int) -> None:
        value = number & 0xFFFFFFFF
        if self._is_little_endian:
            value = ILC.swap_int(value)
        self._buffer.write(struct.pack(">I", value & 0xFFFFFFFF))

    def to_byte_array(self) -> bytes:
        data = self._buffer.getvalue()
        if len(data) < self._size:
            data += b"" * (self._size - len(data))
        self.close()
        return data

    def set_little_endian(self, value: bool) -> None:
        self._is_little_endian = value

    def close(self) -> None:
        try:
            self._buffer.close()
        except Exception:
            pass

    def __del__(self) -> None:
        self.close()
