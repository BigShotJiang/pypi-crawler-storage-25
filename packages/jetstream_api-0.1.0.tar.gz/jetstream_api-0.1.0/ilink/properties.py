from __future__ import annotations

import datetime
from enum import IntEnum
from typing import List

from .common import ILC
from .exception import ILDeserializeException, ILException, UnsupportedOperationException
from .util import (
    ba_merge,
    ba_pick_bytes,
    ba_pick_int,
    ba_pick_long,
    ba_pick_string,
)


def _format_millis(value: int, fmt: str) -> str:
    dt = datetime.datetime.fromtimestamp(value / 1000.0)
    return dt.strftime(fmt)


def _validate_log_level(value: int) -> None:
    if value not in (
        ILC.MIMQ_TRACE,
        ILC.MIMQ_DEBUG,
        ILC.MIMQ_MSG,
        ILC.MIMQ_INFO,
        ILC.MIMQ_WARN,
        ILC.MIMQ_ERROR,
        ILC.MIMQ_FATAL,
        ILC.MIMQ_SYSTEM,
    ):
        raise UnsupportedOperationException(
            f"[{value}] is an unacceptable value. (acceptable value range: 0~7)"
        )


class _AutoAccessor:
    def __getattr__(self, name: str):
        if name.startswith("get") and len(name) > 3:
            field = name[3].lower() + name[4:]
            if hasattr(self, field):
                return lambda: getattr(self, field)
        if name.startswith("set") and len(name) > 3:
            field = name[3].lower() + name[4:]
            if hasattr(self, field):
                return lambda value: setattr(self, field, value)
        if name.startswith("is") and len(name) > 2:
            field = name[2].lower() + name[3:]
            if hasattr(self, field):
                return lambda: bool(getattr(self, field))
        raise AttributeError(f"{self.__class__.__name__} has no attribute {name}")


class DestItem(_AutoAccessor):
    def __init__(
        self,
        qmgr_name: str | None = None,
        qmgr_ip: str | None = None,
        qmgr_port: int | None = None,
        ba: bytes | bytearray | None = None,
    ) -> None:
        self.qmgrName = ""
        self.qmgrIp = ""
        self.qmgrPort = 0
        self.statusCode = ILC.MIMQ_STOPPED
        self.errorString = ""
        self.rtt = -1
        self.depth = -1

        if ba is None:
            if qmgr_name is not None:
                self.qmgrName = qmgr_name
            if qmgr_ip is not None:
                self.qmgrIp = qmgr_ip
            if qmgr_port is not None:
                self.qmgrPort = qmgr_port
            return

        try:
            if len(ba) < ILC.MIMQ_VO_DEST_ITEM_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_DEST_ITEM_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.qmgrName = ba_pick_string(ba, offset, 48)
            offset += 48
            self.qmgrIp = ba_pick_string(ba, offset, 128)
            offset += 128
            self.qmgrPort = ba_pick_int(ba, offset, 10)
            offset += 10
            self.statusCode = ba_pick_int(ba, offset, 10)
            offset += 10
            self.errorString = ba_pick_string(ba, offset, 512)
            offset += 512
            self.rtt = ba_pick_int(ba, offset, 10)
            offset += 10
            self.depth = ba_pick_int(ba, offset, 10)
            offset += 10
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_DEST_ITEM_LEN)
        offset = 0
        ba_merge(self.qmgrName, ba, offset)
        offset += 48
        ba_merge(self.qmgrIp, ba, offset)
        offset += 128
        ba_merge(self.qmgrPort, ba, offset)
        offset += 10
        ba_merge(self.statusCode, ba, offset)
        offset += 10
        ba_merge(self.errorString, ba, offset)
        offset += 512
        ba_merge(self.rtt, ba, offset)
        offset += 10
        ba_merge(self.depth, ba, offset)
        offset += 10
        return bytes(ba)

    def get_status_string(self) -> str:
        if self.statusCode == ILC.MIMQ_RUNNING:
            return ILC.MIMQ_RUNNING_STR
        if self.statusCode == ILC.MIMQ_STOPPED:
            return ILC.MIMQ_STOPPED_STR
        if self.statusCode == ILC.MIMQ_STARTING:
            return ILC.MIMQ_STARTING_STR
        if self.statusCode == ILC.MIMQ_STOPPING:
            return ILC.MIMQ_STOPPING_STR
        return ILC.MIMQ_ERROR_STR


class PartitionItem(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.size = 0
        self.msgCnt = 0
        self.trxCnt = 0
        self.fragmentCnt = 0
        self.fragmentSize = 0

        if ba is None:
            return

        try:
            if len(ba) < ILC.MIMQ_VO_PARTITION_ITEM_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_PARTITION_ITEM_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.size = ba_pick_long(ba, offset, 20)
            offset += 20
            self.msgCnt = ba_pick_int(ba, offset, 10)
            offset += 10
            self.trxCnt = ba_pick_int(ba, offset, 10)
            offset += 10
            self.fragmentCnt = ba_pick_int(ba, offset, 10)
            offset += 10
            self.fragmentSize = ba_pick_long(ba, offset, 20)
            offset += 20
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_PARTITION_ITEM_LEN)
        offset = 0
        ba_merge(self.size, ba, offset)
        offset += 20
        ba_merge(self.msgCnt, ba, offset)
        offset += 10
        ba_merge(self.trxCnt, ba, offset)
        offset += 10
        ba_merge(self.fragmentCnt, ba, offset)
        offset += 10
        ba_merge(self.fragmentSize, ba, offset)
        offset += 20
        return bytes(ba)

    def __str__(self) -> str:
        return (
            f"SIZE({self.size}), MSG(Stored {self.msgCnt} / Processing {self.trxCnt}), "
            f"FRAGMENT({self.fragmentCnt} / {self.fragmentSize})\n"
        )


class ILQueueMinorProperty(_AutoAccessor):
    def __init__(
        self,
        name: str | bytes | bytearray | None = None,
        qtype: int = ILC.MIMQ_LOCAL_PERSISTENT,
    ) -> None:
        self.name = ""
        self.type = ILC.MIMQ_LOCAL_PERSISTENT
        self.depth = 0

        if isinstance(name, (bytes, bytearray)):
            self._from_bytes(bytes(name))
            return
        if name is None:
            return
        if not ILC.is_all_valid_xml_chars(name):
            raise UnsupportedOperationException(
                f"[{name}] is an unacceptable value. (it contains invalid xml characters.)"
            )
        self.name = name
        self.type = qtype

    def _from_bytes(self, ba: bytes) -> None:
        try:
            if len(ba) < ILC.MIMQ_VO_MINOR_QUE_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_MINOR_QUE_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.name = ba_pick_string(ba, offset, 70)
            offset += 70
            self.type = ba_pick_int(ba, offset, 5)
            offset += 5
            self.depth = ba_pick_int(ba, offset, 10)
            offset += 10
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_MINOR_QUE_LEN)
        offset = 0
        ba_merge(self.name, ba, offset)
        offset += 70
        ba_merge(self.type, ba, offset)
        offset += 5
        ba_merge(self.depth, ba, offset)
        offset += 10
        return bytes(ba)


class ILLocalQueueMinorProperty(ILQueueMinorProperty):
    def __init__(self, name: str | bytes | bytearray | None = None) -> None:
        if isinstance(name, (bytes, bytearray)):
            super().__init__(name)
        elif name is None:
            super().__init__()
        else:
            super().__init__(name, ILC.MIMQ_LOCAL_PERSISTENT)


class ILRemoteQueueMinorProperty(ILQueueMinorProperty):
    def __init__(self, name: str | bytes | bytearray | None = None) -> None:
        if isinstance(name, (bytes, bytearray)):
            super().__init__(name)
        elif name is None:
            super().__init__()
        else:
            super().__init__(name, ILC.MIMQ_REMOTE_QUEUE)


class ILXmitQueueMinorProperty(ILQueueMinorProperty):
    def __init__(self, name: str | bytes | bytearray | None = None) -> None:
        if isinstance(name, (bytes, bytearray)):
            super().__init__(name)
        elif name is None:
            super().__init__()
        else:
            super().__init__(name, ILC.MIMQ_CHANNEL_TRANSMISSION_QUEUE)


class ILQueueProperty(_AutoAccessor):
    def __init__(
        self,
        name: str | bytes | bytearray | None = None,
        qtype: int = ILC.MIMQ_LOCAL_PERSISTENT,
    ) -> None:
        self.name = ""
        self.type = ILC.MIMQ_LOCAL_PERSISTENT
        self.triggered = False
        self.triggerType = ILC.MIMQ_TRIGGER_FIRST
        self.triggerProcess = ""
        self.remoteQmgrName = ""
        self.remoteQueueName = ""
        self.xmitQueueName = ""
        self.depth = 0
        self.maxDepth = 99999999
        self.maxMsgLength = 104857600
        self.traceEnabled = False
        self.incomingDelayDepth = -1
        self.incomingDelay = -1
        self.expiry = -1
        self.expiredQueue = ""
        self.deliveryMode = ILC.MIMQ_DELIVERY_MODE_DEPENDS_ON_MSG
        self.maxMemorySize = 10485760
        self.sharedMemorySize = 0
        self.numberOfPartition = 10

        if isinstance(name, (bytes, bytearray)):
            self._from_bytes(bytes(name))
            return
        if name is None:
            return
        if not ILC.is_all_valid_xml_chars(name):
            raise UnsupportedOperationException(
                f"[{name}] is an unacceptable value. (it contains invalid xml characters.)"
            )
        self.name = name
        self.type = qtype

    def _from_bytes(self, ba: bytes) -> None:
        try:
            if len(ba) < ILC.MIMQ_VO_QUEUE_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_QUEUE_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.name = ba_pick_string(ba, offset, 70)
            offset += 70
            self.type = ba_pick_int(ba, offset, 6)
            offset += 6
            offset += 200
            self.triggered = ba_pick_string(ba, offset, 2).lower() == "t"
            offset += 2
            self.triggerType = ba_pick_int(ba, offset, 2)
            offset += 2
            self.triggerProcess = ba_pick_string(ba, offset, 1000)
            offset += 1000
            offset += 100
            self.remoteQmgrName = ba_pick_string(ba, offset, 100)
            offset += 100
            self.remoteQueueName = ba_pick_string(ba, offset, 100)
            offset += 100
            self.xmitQueueName = ba_pick_string(ba, offset, 100)
            offset += 100
            offset += 60
            self.depth = ba_pick_int(ba, offset, 10)
            offset += 10
            self.maxDepth = ba_pick_int(ba, offset, 10)
            offset += 10
            self.maxMsgLength = ba_pick_int(ba, offset, 10)
            offset += 10
            self.traceEnabled = ba_pick_string(ba, offset, 1).lower() == "t"
            offset += 2
            self.expiry = ba_pick_long(ba, offset, 20)
            offset += 20
            self.expiredQueue = ba_pick_string(ba, offset, 70)
            offset += 70
            self.deliveryMode = ba_pick_int(ba, offset, 2)
            offset += 2
            self.maxMemorySize = ba_pick_long(ba, offset, 20)
            offset += 20
            self.sharedMemorySize = ba_pick_long(ba, offset, 20)
            offset += 20
            self.numberOfPartition = ba_pick_int(ba, offset, 10)
            offset += 10
            offset += 228
            self.incomingDelayDepth = ba_pick_int(ba, offset, 10)
            offset += 10
            self.incomingDelay = ba_pick_int(ba, offset, 10)
            offset += 10
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_QUEUE_LEN)
        offset = 0
        ba_merge(self.name, ba, offset)
        offset += 70
        ba_merge(self.type, ba, offset)
        offset += 6
        offset += 200
        ba_merge("t" if self.triggered else "f", ba, offset)
        offset += 2
        ba_merge(self.triggerType, ba, offset)
        offset += 2
        ba_merge(self.triggerProcess, ba, offset)
        offset += 1000
        offset += 100
        ba_merge(self.remoteQmgrName, ba, offset)
        offset += 100
        ba_merge(self.remoteQueueName, ba, offset)
        offset += 100
        ba_merge(self.xmitQueueName, ba, offset)
        offset += 100
        offset += 60
        ba_merge(self.depth, ba, offset)
        offset += 10
        ba_merge(self.maxDepth, ba, offset)
        offset += 10
        ba_merge(self.maxMsgLength, ba, offset)
        offset += 10
        ba_merge("t" if self.traceEnabled else "f", ba, offset)
        offset += 2
        ba_merge(self.expiry, ba, offset)
        offset += 20
        ba_merge(self.expiredQueue, ba, offset)
        offset += 70
        ba_merge(self.deliveryMode, ba, offset)
        offset += 2
        ba_merge(self.maxMemorySize, ba, offset)
        offset += 20
        ba_merge(self.sharedMemorySize, ba, offset)
        offset += 20
        ba_merge(self.numberOfPartition, ba, offset)
        offset += 10
        offset += 228
        ba_merge(self.incomingDelayDepth, ba, offset)
        offset += 10
        ba_merge(self.incomingDelay, ba, offset)
        offset += 10
        return bytes(ba)

    def get_type_string(self) -> str:
        if self.type == ILC.MIMQ_LOCAL_PERSISTENT:
            return "LOCAL"
        if self.type == ILC.MIMQ_REMOTE_QUEUE:
            return "REMOTE"
        if self.type == ILC.MIMQ_CHANNEL_TRANSMISSION_QUEUE:
            return "XMIT"
        return "UNKNOWN"

    def get_minor_property(self) -> ILQueueMinorProperty:
        mp = ILQueueMinorProperty()
        mp.name = self.name
        mp.type = self.type
        mp.depth = self.depth
        return mp

    def __str__(self) -> str:
        return (
            "\n"
            + f"\tNAME({self.name}) TYPE({self.get_type_string()})\n"
            + f"\tTRIGGER({'ON' if self.triggered else 'OFF'})\n"
            + f"\tTRIGGER-PROCESS({self.triggerProcess})\n"
            + f"\tCUR-DEPTH({self.depth}) TRACE({'ON' if self.traceEnabled else 'OFF'})\n"
            + f"\tMAX-DEPTH({self.maxDepth}) MAX-MSG-LENGTH({self.maxMsgLength})\n"
            + "\tREMOTE-QMGR(" + self.remoteQmgrName + ") REMOTE-QUEUE(" + self.remoteQueueName
            + ") XMIT-QUEUE(" + self.xmitQueueName + ")\n"
            + "\tEXPIRY(after "
            + str(self.expiry)
            + "ms, move to "
            + self.expiredQueue
            + ") PERSISTENCE("
            + str(self.deliveryMode)
            + ")\n"
            + "\tMAX-MEMORY-SIZE("
            + str(self.maxMemorySize)
            + "bytes) SHARED-MEMORY-SIZE("
            + str(self.sharedMemorySize)
            + "bytes)\n"
            + "\tNUM-PARTITION ("
            + str(self.numberOfPartition)
            + ") DELAY(over "
            + str(self.incomingDelayDepth)
            + "depth, "
            + str(self.incomingDelay)
            + "ms)\n"
        )


class ILChannelType(IntEnum):
    SERVER = 0
    CLIENT = 1


class ILChannelStatus(IntEnum):
    RUNNING = 0
    STOPPED = 1
    STARTING = 2
    STOPPING = 3
    EXCEPTION = 4


class ILChannelDirection(IntEnum):
    SEND = 0
    RECV = 1


class ILChannelSecurity(IntEnum):
    NONE = 0
    SEED = 1
    ARIA = 2
    TLS = 3
    GPKI = 4
    MAGIC = 5


class ILChannelBalanceMode(IntEnum):
    ROUND_ROBIN = 0
    QUEUE_DEPTH = 1
    ACTIVE_STANDBY = 2


class ILChannelMinorProperty(_AutoAccessor):
    def __init__(
        self,
        name: str | bytes | bytearray | None = None,
        channel_type: ILChannelType = ILChannelType.CLIENT,
        direction: ILChannelDirection = ILChannelDirection.SEND,
    ) -> None:
        self.name = ""
        self.type = ILChannelType.CLIENT
        self.status = ILChannelStatus.STOPPED
        self.direction = ILChannelDirection.SEND
        self.autoStart = True

        if isinstance(name, (bytes, bytearray)):
            self._from_bytes(bytes(name))
            return
        if name is None:
            return
        if not ILC.is_all_valid_xml_chars(name):
            raise UnsupportedOperationException(
                f"[{name}] is an unacceptable value. (it contains invalid xml characters.)"
            )
        self.name = name
        self.type = channel_type
        self.direction = direction

    def _from_bytes(self, ba: bytes) -> None:
        try:
            if len(ba) < ILC.MIMQ_VO_MINOR_CHL_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_MINOR_CHL_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.name = ba_pick_string(ba, offset, 70)
            offset += 70
            self.status = ILChannelStatus(ba_pick_int(ba, offset, 2))
            offset += 2
            self.type = ILChannelType(ba_pick_int(ba, offset, 2))
            offset += 2
            self.direction = ILChannelDirection(ba_pick_int(ba, offset, 2))
            offset += 2
            self.autoStart = ba_pick_string(ba, offset, 1).lower() == "a"
            offset += 2
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_MINOR_CHL_LEN)
        offset = 0
        ba_merge(self.name, ba, offset)
        offset += 70
        ba_merge(int(self.status), ba, offset)
        offset += 2
        ba_merge(int(self.type), ba, offset)
        offset += 2
        ba_merge(int(self.direction), ba, offset)
        offset += 2
        ba_merge("A" if self.autoStart else "M", ba, offset)
        offset += 2
        return bytes(ba)


class ILClientSendChannelMinorProperty(ILChannelMinorProperty):
    def __init__(self, name: str | bytes | bytearray | None = None) -> None:
        if isinstance(name, (bytes, bytearray)):
            super().__init__(name)
        elif name is None:
            super().__init__()
        else:
            super().__init__(name, ILChannelType.CLIENT, ILChannelDirection.SEND)


class ILClientRecvChannelMinorProperty(ILChannelMinorProperty):
    def __init__(self, name: str | bytes | bytearray | None = None) -> None:
        if isinstance(name, (bytes, bytearray)):
            super().__init__(name)
        elif name is None:
            super().__init__()
        else:
            super().__init__(name, ILChannelType.CLIENT, ILChannelDirection.RECV)


class ILServerSendChannelMinorProperty(ILChannelMinorProperty):
    def __init__(self, name: str | bytes | bytearray | None = None) -> None:
        if isinstance(name, (bytes, bytearray)):
            super().__init__(name)
        elif name is None:
            super().__init__()
        else:
            super().__init__(name, ILChannelType.SERVER, ILChannelDirection.SEND)


class ILServerRecvChannelMinorProperty(ILChannelMinorProperty):
    def __init__(self, name: str | bytes | bytearray | None = None) -> None:
        if isinstance(name, (bytes, bytearray)):
            super().__init__(name)
        elif name is None:
            super().__init__()
        else:
            super().__init__(name, ILChannelType.SERVER, ILChannelDirection.RECV)


class ILChannelProperty(_AutoAccessor):
    def __init__(
        self,
        name: str | bytes | bytearray | None = None,
        channel_type: ILChannelType = ILChannelType.CLIENT,
        direction: ILChannelDirection = ILChannelDirection.SEND,
    ) -> None:
        self.name = ""
        self.type = ILChannelType.CLIENT
        self.status = ILChannelStatus.STOPPED
        self.direction = ILChannelDirection.SEND
        self.security = ILChannelSecurity.NONE
        self.destManagerName = ""
        self.destManagerIp = ""
        self.destManagerPort = 0
        self.autoStart = True
        self.xmitQueueName = ""
        self.keyFileName = ""
        self.certFileName = ""
        self.timeout = 30
        self.rtt = -1
        self.traceEnabled = False
        self.balanceMode = ILChannelBalanceMode.ROUND_ROBIN
        self.destGroupBufferLength = 0
        self.destGroup: List[DestItem] = []

        if isinstance(name, (bytes, bytearray)):
            self._from_bytes(bytes(name))
            return
        if name is None:
            return
        if not ILC.is_all_valid_xml_chars(name):
            raise UnsupportedOperationException(
                f"[{name}] is an unacceptable value. (it contains invalid xml characters.)"
            )
        self.name = name
        self.type = channel_type
        self.direction = direction

    def _from_bytes(self, ba: bytes) -> None:
        try:
            if len(ba) < ILC.MIMQ_VO_CHANNEL_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_CHANNEL_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.name = ba_pick_string(ba, offset, 48)
            offset += 48
            self.type = ILChannelType(ba_pick_int(ba, offset, 1))
            offset += 1
            self.status = ILChannelStatus(ba_pick_int(ba, offset, 1))
            offset += 1
            self.direction = ILChannelDirection(ba_pick_int(ba, offset, 1))
            offset += 1
            self.security = ILChannelSecurity(ba_pick_int(ba, offset, 1))
            offset += 1
            self.destManagerName = ba_pick_string(ba, offset, 48)
            offset += 48
            self.destManagerIp = ba_pick_string(ba, offset, 128)
            offset += 128
            self.destManagerPort = ba_pick_int(ba, offset, 10)
            offset += 10
            self.autoStart = ba_pick_string(ba, offset, 1).upper() == "T"
            offset += 1
            offset += 10
            self.xmitQueueName = ba_pick_string(ba, offset, 48)
            offset += 48
            offset += 10
            self.keyFileName = ba_pick_string(ba, offset, 512)
            offset += 512
            self.certFileName = ba_pick_string(ba, offset, 512)
            offset += 512
            self.timeout = ba_pick_int(ba, offset, 10)
            offset += 10
            self.traceEnabled = ba_pick_string(ba, offset, 1).lower() == "t"
            offset += 2
            self.rtt = ba_pick_int(ba, offset, 10)
            offset += 10
            self.balanceMode = ILChannelBalanceMode(ba_pick_int(ba, offset, 1))
            offset += 1
            self.destGroupBufferLength = ba_pick_int(ba, offset, 10)
            offset += 10
            if self.destGroupBufferLength > 0:
                count = ba_pick_int(ba, offset, 5)
                offset += 5
                for _ in range(count):
                    item = DestItem(ba=ba_pick_bytes(ba, offset, ILC.MIMQ_VO_DEST_ITEM_LEN))
                    self.destGroup.append(item)
                    offset += ILC.MIMQ_VO_DEST_ITEM_LEN
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        self.destGroupBufferLength = (
            len(self.destGroup) * ILC.MIMQ_VO_DEST_ITEM_LEN + ILC.MIMQ_LIST_ITEM_COUNT_LENGTH
            if self.destGroup
            else 0
        )
        ba = bytearray(ILC.MIMQ_VO_CHANNEL_LEN + self.destGroupBufferLength)
        offset = 0
        ba_merge(self.name, ba, offset)
        offset += 48
        ba_merge(int(self.type), ba, offset)
        offset += 1
        ba_merge(int(self.status), ba, offset)
        offset += 1
        ba_merge(int(self.direction), ba, offset)
        offset += 1
        ba_merge(int(self.security), ba, offset)
        offset += 1
        ba_merge(self.destManagerName, ba, offset)
        offset += 48
        ba_merge(self.destManagerIp, ba, offset)
        offset += 128
        ba_merge(self.destManagerPort, ba, offset)
        offset += 10
        ba_merge("T" if self.autoStart else "F", ba, offset)
        offset += 1
        offset += 10
        ba_merge(self.xmitQueueName, ba, offset)
        offset += 48
        offset += 10
        ba_merge(self.keyFileName, ba, offset)
        offset += 512
        ba_merge(self.certFileName, ba, offset)
        offset += 512
        ba_merge(self.timeout, ba, offset)
        offset += 10
        ba_merge("t" if self.traceEnabled else "f", ba, offset)
        offset += 2
        ba_merge(self.rtt, ba, offset)
        offset += 10
        ba_merge(int(self.balanceMode), ba, offset)
        offset += 1
        ba_merge(self.destGroupBufferLength, ba, offset)
        offset += 10
        if self.destGroup:
            ba_merge(len(self.destGroup), ba, offset)
            offset += ILC.MIMQ_LIST_ITEM_COUNT_LENGTH
            for item in self.destGroup:
                ba_merge(item.get_serialized(), ba, offset)
                offset += ILC.MIMQ_VO_DEST_ITEM_LEN
        return bytes(ba)

    def get_type_string(self) -> str:
        if self.type == ILChannelType.CLIENT:
            return "CLIENT"
        if self.type == ILChannelType.SERVER:
            return "SERVER"
        return "UNKNOWN"

    def get_status_string(self) -> str:
        if self.status == ILChannelStatus.RUNNING:
            return "RUNNING"
        if self.status == ILChannelStatus.STOPPED:
            return "STOPPED"
        if self.status == ILChannelStatus.STARTING:
            return "STARTING"
        if self.status == ILChannelStatus.STOPPING:
            return "STOPPING"
        if self.status == ILChannelStatus.EXCEPTION:
            return "EXCEPTION"
        return "UNKNOWN"

    def get_direction_string(self) -> str:
        if self.direction == ILChannelDirection.SEND:
            return "SEND"
        if self.direction == ILChannelDirection.RECV:
            return "RECV"
        return "UNKNOWN"

    def get_security_string(self) -> str:
        return self.security.name

    def set_timeout(self, sec: int) -> None:
        if sec < -1:
            raise UnsupportedOperationException(
                f"[{sec}] is an unacceptable value. (acceptable value range: -1~)"
            )
        self.timeout = sec

    def is_balance_channel(self) -> bool:
        return len(self.destGroup) > 0

    def get_dest_group_buffer_length(self) -> int:
        return self.destGroupBufferLength

    def get_minor_property(self) -> ILChannelMinorProperty:
        mp = ILChannelMinorProperty()
        mp.name = self.name
        mp.type = self.type
        mp.direction = self.direction
        mp.autoStart = self.autoStart
        mp.status = self.status
        return mp

    def __str__(self) -> str:
        common = (
            "\n"
            + f"\tNAME({self.name}) STYLE({self.type.name}.{self.direction.name})\n"
            + f"\tSTATUS({self.status.name}) START-MODE({'AUTO' if self.autoStart else 'MANUAL'})\n"
            + f"\tTIMEOUT({self.timeout}) TRACE({'ON' if self.traceEnabled else 'OFF'})\n"
            + "\tSECURITY(" + self.security.name + ") KEY(" + self.keyFileName + ") CERT(" + self.certFileName + ")\n"
            + "\tXMIT-QUEUE(" + self.xmitQueueName + ") BALANCE-MODE(" + self.balanceMode.name + ")\n"
        )
        if self.is_balance_channel():
            for idx, di in enumerate(self.destGroup):
                common += (
                    "\tDESTINATION["
                    + str(idx)
                    + "](" + di.qmgrName + ", " + di.qmgrIp + ":" + str(di.qmgrPort) + ")\n"
                )
        else:
            if self.destManagerIp == "":
                common += "\tDESTINATION()\n"
            else:
                common += (
                    "\tDESTINATION(" + self.destManagerName + ", " + self.destManagerIp
                    + ":" + str(self.destManagerPort) + ")\n"
                )
        return common


class ILAccessRuleProperty(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.type = 0
        self.id = ILC.MIMQ_ACCESS_RULE_ANY
        self.ip = ILC.MIMQ_ACCESS_RULE_ANY
        self.clientName = ILC.MIMQ_ACCESS_RULE_ANY
        self.clientType = ILC.MIMQ_ACCESS_RULE_ANY

        if ba is None:
            return
        try:
            if len(ba) < ILC.MIMQ_VO_ACCESSRULE_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_ACCESSRULE_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.id = ba_pick_string(ba, offset, 12)
            offset += 12
            self.type = ba_pick_int(ba, offset, 2)
            offset += 2
            self.ip = ba_pick_string(ba, offset, 24)
            offset += 24
            self.clientName = ba_pick_string(ba, offset, 48)
            offset += 48
            self.clientType = ba_pick_string(ba, offset, 8)
            offset += 8
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_ACCESSRULE_LEN)
        offset = 0
        ba_merge(self.id, ba, offset)
        offset += 12
        ba_merge(self.type, ba, offset)
        offset += 2
        ba_merge(self.ip, ba, offset)
        offset += 24
        ba_merge(self.clientName, ba, offset)
        offset += 48
        ba_merge(self.clientType, ba, offset)
        offset += 8
        return bytes(ba)

    def set_type(self, value: int) -> None:
        if value not in (ILC.MIMQ_ACL_BY_BLACKLIST, ILC.MIMQ_ACL_BY_WHITELIST):
            raise UnsupportedOperationException(
                f"[{value}] is an unacceptable value. (acceptable value range: 0~1)"
            )
        self.type = value

    def set_client_type(self, value: str) -> None:
        upper = value.upper()
        if upper not in ("SYS", "PRX", "CHL", "USR"):
            raise UnsupportedOperationException(
                f"[{value}] is an unacceptable value. (acceptable value list: [SYS | PRX | USR | CHL])"
            )
        self.clientType = value

    def __str__(self) -> str:
        return (
            f"ID({self.id}) IP({self.ip}) CLIENT-NAME({self.clientName}) "
            f"CLIENT-TYPE({self.clientType})"
        )


class ILSecureFileProperty(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.name = ""
        self.date = ""
        self.size = 0
        self.keyStatus = ""

        if ba is None:
            return
        try:
            if len(ba) < ILC.MIMQ_VO_CERTFILE_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_CERTFILE_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.name = ba_pick_string(ba, offset, 256)
            offset += 256
            self.date = ba_pick_string(ba, offset, 64)
            offset += 64
            self.size = ba_pick_int(ba, offset, 10)
            offset += 10
            self.keyStatus = ba_pick_string(ba, offset, 12)
            offset += 12
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_CERTFILE_LEN)
        offset = 0
        ba_merge(self.name, ba, offset)
        offset += 256
        ba_merge(self.date, ba, offset)
        offset += 64
        ba_merge(self.size, ba, offset)
        offset += 10
        ba_merge(self.keyStatus, ba, offset)
        offset += 12
        return bytes(ba)

    def __str__(self) -> str:
        return (
            f"NAME({self.name}) SIZE({self.size}bytes) DATE({self.date}) "
            f"KEY-STATUS({self.keyStatus})"
        )


class ILQueueRealTimeInfo(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.curDepth = 0
        self.openTime = 0
        self.lastPutTime = 0
        self.lastGetTime = 0
        self.lastPutClient = ""
        self.lastGetClient = ""
        self.numberOfClient = 0
        self.numberOfChannel = 0
        self.uncommittedPut = 0
        self.uncommittedGet = 0
        self.partitions: List[PartitionItem] = []

        if ba is None:
            return
        try:
            if len(ba) < ILC.MIMQ_VO_QUEUE_INFO_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_QUEUE_INFO_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.curDepth = ba_pick_int(ba, offset, 10)
            offset += 10
            self.openTime = ba_pick_long(ba, offset, 20)
            offset += 20
            self.lastPutTime = ba_pick_long(ba, offset, 20)
            offset += 20
            self.lastGetTime = ba_pick_long(ba, offset, 20)
            offset += 20
            self.lastPutClient = ba_pick_string(ba, offset, 70)
            offset += 70
            self.lastGetClient = ba_pick_string(ba, offset, 70)
            offset += 70
            self.numberOfClient = ba_pick_int(ba, offset, 10)
            offset += 10
            self.numberOfChannel = ba_pick_int(ba, offset, 10)
            offset += 10
            self.uncommittedPut = ba_pick_int(ba, offset, 10)
            offset += 10
            self.uncommittedGet = ba_pick_int(ba, offset, 10)
            offset += 10
            count = ba_pick_int(ba, offset, 5)
            offset += 5
            for _ in range(count):
                item = PartitionItem(
                    ba_pick_bytes(ba, offset, ILC.MIMQ_VO_PARTITION_ITEM_LEN)
                )
                self.partitions.append(item)
                offset += ILC.MIMQ_VO_PARTITION_ITEM_LEN
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        buffer_length = ILC.MIMQ_VO_QUEUE_INFO_LEN + ILC.MIMQ_LIST_ITEM_COUNT_LENGTH
        if self.partitions:
            buffer_length += len(self.partitions) * ILC.MIMQ_VO_PARTITION_ITEM_LEN
        ba = bytearray(buffer_length)
        offset = 0
        ba_merge(self.curDepth, ba, offset)
        offset += 10
        ba_merge(self.openTime, ba, offset)
        offset += 20
        ba_merge(self.lastPutTime, ba, offset)
        offset += 20
        ba_merge(self.lastGetTime, ba, offset)
        offset += 20
        ba_merge(self.lastPutClient, ba, offset)
        offset += 70
        ba_merge(self.lastGetClient, ba, offset)
        offset += 70
        ba_merge(self.numberOfClient, ba, offset)
        offset += 10
        ba_merge(self.numberOfChannel, ba, offset)
        offset += 10
        ba_merge(self.uncommittedPut, ba, offset)
        offset += 10
        ba_merge(self.uncommittedGet, ba, offset)
        offset += 10
        ba_merge(len(self.partitions), ba, offset)
        offset += 5
        for item in self.partitions:
            ba_merge(item.get_serialized(), ba, offset)
            offset += ILC.MIMQ_VO_PARTITION_ITEM_LEN
        return bytes(ba)

    def __str__(self) -> str:
        ret = ""
        ret += f"CURDEPTH({self.curDepth})\n"
        ret += f"OPENTIME({self.openTime})\n"
        if self.lastPutClient == "":
            ret += "LASTPUT(-)\n"
        else:
            ret += f"LASTPUT(By {self.lastPutClient}, {self.lastPutTime})\n"
        if self.lastGetClient == "":
            ret += "LASTGET(-)\n"
        else:
            ret += f"LASTGET(By {self.lastGetClient}, {self.lastGetTime})\n"
        ret += f"ACCESS(Client {self.numberOfClient}, Channel {self.numberOfChannel})\n"
        ret += f"TRANSACTED(Put {self.uncommittedPut}, Get {self.uncommittedGet})\n"
        ret += "Partitions -------------------------------------------------------\n"
        for partition in self.partitions:
            ret += "  " + str(partition)
        return ret


class ILQueueFlow(_AutoAccessor):
    def __init__(
        self,
        incoming_msg_count: int | None = None,
        outgoing_msg_count: int | None = None,
        incoming_data_size: int | None = None,
        outgoing_data_size: int | None = None,
        cur_depth: int | None = None,
        ba: bytes | bytearray | None = None,
    ) -> None:
        self.incomingMsgCount = 0
        self.outgoingMsgCount = 0
        self.incomingDataSize = 0
        self.outgoingDataSize = 0
        self.depth = 0

        if ba is None:
            if incoming_msg_count is not None:
                self.incomingMsgCount = incoming_msg_count
            if outgoing_msg_count is not None:
                self.outgoingMsgCount = outgoing_msg_count
            if incoming_data_size is not None:
                self.incomingDataSize = incoming_data_size
            if outgoing_data_size is not None:
                self.outgoingDataSize = outgoing_data_size
            if cur_depth is not None:
                self.depth = cur_depth
            return

        try:
            if len(ba) < ILC.MIMQ_VO_QUEUE_FLOW_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_QUEUE_FLOW_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.incomingMsgCount = ba_pick_int(ba, offset, 10)
            offset += 10
            self.outgoingMsgCount = ba_pick_int(ba, offset, 10)
            offset += 10
            self.incomingDataSize = ba_pick_long(ba, offset, 20)
            offset += 20
            self.outgoingDataSize = ba_pick_long(ba, offset, 20)
            offset += 20
            self.depth = ba_pick_int(ba, offset, 10)
            offset += 10
        except Exception as exc:
            raise ILException(exc) from exc

    def __str__(self) -> str:
        return (
            "in : "
            + str(self.incomingMsgCount)
            + " ("
            + str(self.incomingDataSize)
            + "bytes), out : "
            + str(self.outgoingMsgCount)
            + " ("
            + str(self.outgoingDataSize)
            + "bytes), depth : "
            + str(self.depth)
        )


class ILQmgrMinorProperty(_AutoAccessor):
    def __init__(
        self, name: str | bytes | bytearray | None = None, port: int = -1, auto_start: bool = True
    ) -> None:
        self.name = ""
        self.status = ILC.MIMQ_STOPPED
        self.port = -1
        self.autoStart = True

        if isinstance(name, (bytes, bytearray)):
            self._from_bytes(bytes(name))
            return
        if name is None:
            return
        self.name = name
        self.port = port
        self.autoStart = auto_start

    def _from_bytes(self, ba: bytes) -> None:
        try:
            if len(ba) < ILC.MIMQ_VO_MINOR_MGR_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_MINOR_MGR_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.status = ba_pick_int(ba, offset, 2)
            offset += 2
            self.name = ba_pick_string(ba, offset, 70)
            offset += 70
            self.port = ba_pick_int(ba, offset, 6)
            offset += 6
            start_mode = ba_pick_string(ba, offset, 2)
            offset += 2
            self.autoStart = start_mode.upper() == "A"
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_MINOR_MGR_LEN)
        offset = 0
        ba_merge(self.status, ba, offset)
        offset += 2
        ba_merge(self.name, ba, offset)
        offset += 70
        ba_merge(self.port, ba, offset)
        offset += 6
        ba_merge("A" if self.autoStart else "M", ba, offset)
        offset += 2
        return bytes(ba)


class ILQmgrProperty(_AutoAccessor):
    def __init__(
        self,
        name: str | bytes | bytearray | None = None,
        port: int = -1,
        auto_start: bool | None = None,
        home_path: str | None = None,
    ) -> None:
        self.status = ILC.MIMQ_STOPPED
        self.name = ""
        self.homeDir = ""
        self.ipAddress = "127.0.0.1"
        self.port = -1
        self.autoStart = True
        self.version = ""
        self.channelRetryTimeInterval = 5
        self.connectTimeout = -1
        self.acceptWaitTimeout = -1
        self.sendTimeout = 10
        self.recvWaitTimeout = 86400
        self.acceptPoolSize = 1
        self.eventPoolSize = 1
        self.sessionPerThread = 10
        self.logLevelSystem = 4
        self.logFileSizeSystem = 4194304
        self.logFileCountSystem = 5
        self.logLevelClient = 4
        self.logFileSizeClient = 4194304
        self.logFileCountClient = 5
        self.logLevelQueue = 4
        self.logFileSizeQueue = 4194304
        self.logFileCountQueue = 5
        self.logLevelChannel = 4
        self.logFileSizeChannel = 4194304
        self.logFileCountChannel = 5
        self.traceEnabled = False
        self.aclEnabled = False
        self.aclType = 0
        self.deadLetterQueueName = ILC.MIMQ_DLQ_NAME
        self.useAsync = False
        self.deadSessionKeepDuration = 600
        self.deadSessionMaxCount = 1000

        if isinstance(name, (bytes, bytearray)):
            self._from_bytes(bytes(name))
            return
        if name is None:
            return
        self.name = name
        self.port = port
        if auto_start is not None:
            self.autoStart = auto_start
        if home_path is not None:
            self.homeDir = home_path

    def _from_bytes(self, ba: bytes) -> None:
        try:
            if len(ba) < ILC.MIMQ_VO_QMGR_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_QMGR_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.status = ba_pick_int(ba, offset, 6)
            offset += 6
            self.name = ba_pick_string(ba, offset, 60)
            offset += 60
            self.homeDir = ba_pick_string(ba, offset, 100)
            offset += 100
            self.ipAddress = ba_pick_string(ba, offset, 100)
            offset += 100
            self.port = ba_pick_int(ba, offset, 6)
            offset += 6
            offset += 6
            offset += 23
            start_mode = ba_pick_string(ba, offset, 20)
            offset += 20
            self.autoStart = start_mode.upper() == "AUTO"
            offset += 23
            tmp = ba_pick_string(ba, offset, 1)
            if tmp:
                self.useAsync = tmp.lower() == "a"
            offset += 2
            tmp = ba_pick_string(ba, offset, 10)
            if tmp:
                try:
                    self.deadSessionKeepDuration = int(tmp)
                except Exception:
                    pass
            offset += 10
            tmp = ba_pick_string(ba, offset, 10)
            if tmp:
                try:
                    self.deadSessionMaxCount = int(tmp)
                except Exception:
                    pass
            offset += 10
            self.version = ba_pick_string(ba, offset, 20)
            offset += 20
            self.channelRetryTimeInterval = ba_pick_int(ba, offset, 10)
            offset += 10
            offset += 10
            self.connectTimeout = ba_pick_int(ba, offset, 10)
            offset += 10
            self.acceptWaitTimeout = ba_pick_int(ba, offset, 10)
            offset += 10
            self.sendTimeout = ba_pick_int(ba, offset, 10)
            offset += 10
            self.recvWaitTimeout = ba_pick_int(ba, offset, 10)
            offset += 10
            self.acceptPoolSize = ba_pick_int(ba, offset, 10)
            offset += 10
            self.eventPoolSize = ba_pick_int(ba, offset, 10)
            offset += 10
            offset += 50
            self.logLevelSystem = ba_pick_int(ba, offset, 2)
            offset += 2
            self.logFileSizeSystem = ba_pick_int(ba, offset, 15)
            offset += 15
            self.logFileCountSystem = ba_pick_int(ba, offset, 5)
            offset += 5
            self.logLevelClient = ba_pick_int(ba, offset, 2)
            offset += 2
            self.logFileSizeClient = ba_pick_int(ba, offset, 15)
            offset += 15
            self.logFileCountClient = ba_pick_int(ba, offset, 5)
            offset += 5
            self.logLevelQueue = ba_pick_int(ba, offset, 2)
            offset += 2
            self.logFileSizeQueue = ba_pick_int(ba, offset, 15)
            offset += 15
            self.logFileCountQueue = ba_pick_int(ba, offset, 5)
            offset += 5
            self.logLevelChannel = ba_pick_int(ba, offset, 2)
            offset += 2
            self.logFileSizeChannel = ba_pick_int(ba, offset, 15)
            offset += 15
            self.logFileCountChannel = ba_pick_int(ba, offset, 5)
            offset += 5
            self.traceEnabled = ba_pick_string(ba, offset, 1).lower() == "t"
            offset += 2
            self.aclEnabled = ba_pick_string(ba, offset, 1).lower() == "t"
            offset += 2
            self.aclType = ba_pick_int(ba, offset, 2)
            offset += 2
            self.sessionPerThread = ba_pick_int(ba, offset, 10)
            offset += 10
            self.deadLetterQueueName = ba_pick_string(ba, offset, 32)
            offset += 32
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_QMGR_LEN)
        offset = 0
        ba_merge(self.status, ba, offset)
        offset += 6
        ba_merge(self.name, ba, offset)
        offset += 60
        ba_merge(self.homeDir, ba, offset)
        offset += 100
        ba_merge(self.ipAddress, ba, offset)
        offset += 100
        ba_merge(self.port, ba, offset)
        offset += 6
        offset += 6
        offset += 23
        ba_merge("AUTO" if self.autoStart else "MANUAL", ba, offset)
        offset += 20
        offset += 23
        ba_merge("a" if self.useAsync else "s", ba, offset)
        offset += 2
        ba_merge(self.deadSessionKeepDuration, ba, offset)
        offset += 10
        ba_merge(self.deadSessionMaxCount, ba, offset)
        offset += 10
        ba_merge(self.version, ba, offset)
        offset += 20
        ba_merge(self.channelRetryTimeInterval, ba, offset)
        offset += 10
        offset += 10
        ba_merge(self.connectTimeout, ba, offset)
        offset += 10
        ba_merge(self.acceptWaitTimeout, ba, offset)
        offset += 10
        ba_merge(self.sendTimeout, ba, offset)
        offset += 10
        ba_merge(self.recvWaitTimeout, ba, offset)
        offset += 10
        ba_merge(self.acceptPoolSize, ba, offset)
        offset += 10
        ba_merge(self.eventPoolSize, ba, offset)
        offset += 10
        offset += 50
        ba_merge(self.logLevelSystem, ba, offset)
        offset += 2
        ba_merge(self.logFileSizeSystem, ba, offset)
        offset += 15
        ba_merge(self.logFileCountSystem, ba, offset)
        offset += 5
        ba_merge(self.logLevelClient, ba, offset)
        offset += 2
        ba_merge(self.logFileSizeClient, ba, offset)
        offset += 15
        ba_merge(self.logFileCountClient, ba, offset)
        offset += 5
        ba_merge(self.logLevelQueue, ba, offset)
        offset += 2
        ba_merge(self.logFileSizeQueue, ba, offset)
        offset += 15
        ba_merge(self.logFileCountQueue, ba, offset)
        offset += 5
        ba_merge(self.logLevelChannel, ba, offset)
        offset += 2
        ba_merge(self.logFileSizeChannel, ba, offset)
        offset += 15
        ba_merge(self.logFileCountChannel, ba, offset)
        offset += 5
        ba_merge("t" if self.traceEnabled else "f", ba, offset)
        offset += 2
        ba_merge("t" if self.aclEnabled else "f", ba, offset)
        offset += 2
        ba_merge(self.aclType, ba, offset)
        offset += 2
        ba_merge(self.sessionPerThread, ba, offset)
        offset += 10
        ba_merge(self.deadLetterQueueName, ba, offset)
        offset += 32
        return bytes(ba)

    def get_status_string(self) -> str:
        if self.status == ILC.MIMQ_RUNNING:
            return ILC.MIMQ_RUNNING_STR
        if self.status == ILC.MIMQ_STOPPED:
            return ILC.MIMQ_STOPPED_STR
        if self.status == ILC.MIMQ_STARTING:
            return ILC.MIMQ_STARTING_STR
        if self.status == ILC.MIMQ_STOPPING:
            return ILC.MIMQ_STOPPING_STR
        return ILC.MIMQ_ERROR_STR

    def get_acl_type_string(self) -> str:
        if self.aclType == ILC.MIMQ_ACL_BY_BLACKLIST:
            return "BLACKLIST"
        if self.aclType == ILC.MIMQ_ACL_BY_WHITELIST:
            return "WHITELIST"
        return "UNKNOWN"

    def set_log_level_system(self, value: int) -> None:
        _validate_log_level(value)
        self.logLevelSystem = value

    def set_log_level_client(self, value: int) -> None:
        _validate_log_level(value)
        self.logLevelClient = value

    def set_log_level_queue(self, value: int) -> None:
        _validate_log_level(value)
        self.logLevelQueue = value

    def set_log_level_channel(self, value: int) -> None:
        _validate_log_level(value)
        self.logLevelChannel = value

    def set_accept_pool_size(self, size: int) -> None:
        if size < 1 or size > 9:
            raise UnsupportedOperationException(
                f"[{size}] is an unacceptable value. (acceptable value range: 1~9)"
            )
        self.acceptPoolSize = size

    def set_event_pool_size(self, size: int) -> None:
        if size < 1 or size > 99:
            raise UnsupportedOperationException(
                f"[{size}] is an unacceptable value. (acceptable value range: 1~99)"
            )
        self.eventPoolSize = size

    def set_session_per_thread(self, count: int) -> None:
        if count < 1:
            raise UnsupportedOperationException(
                f"[{count}] is an unacceptable value. (acceptable value range: 1~)"
            )
        self.sessionPerThread = count

    def set_acl_type(self, value: int) -> None:
        if value not in (ILC.MIMQ_ACL_BY_BLACKLIST, ILC.MIMQ_ACL_BY_WHITELIST):
            raise UnsupportedOperationException(
                f"[{value}] is an unacceptable value. (acceptable value range: 0~1)"
            )
        self.aclType = value

    def get_minor_property(self) -> ILQmgrMinorProperty:
        mp = ILQmgrMinorProperty()
        mp.name = self.name
        mp.port = self.port
        mp.status = self.status
        mp.autoStart = self.autoStart
        return mp

    def __str__(self) -> str:
        if self.useAsync:
            tcp_lsr = (
                "\tTCP-LISTENER(Mode:ASYNC,AcceptPool:"
                + str(self.acceptPoolSize)
                + ", EventPool:"
                + str(self.eventPoolSize)
                + ", SessionPerThread:"
                + str(self.sessionPerThread)
                + ")\n"
            )
        else:
            tcp_lsr = "\tTCP-LISTENER(Mode:SYNC)\n"
        return (
            "\n"
            + "\tNAME(" + self.name + ") STATUS(" + self.get_status_string() + ")\n"
            + "\tSTART-MODE(" + ("AUTO" if self.autoStart else "MANUAL")
            + ") TRACE(" + ("ON" if self.traceEnabled else "OFF") + ")\n"
            + "\tHOME-PATH(" + self.homeDir + ") LISTEN(" + self.ipAddress + ":" + str(self.port) + ")\n"
            + "\tLOGGER(SYS: " + str(self.logFileSizeSystem) + "bytes " + str(self.logFileCountSystem)
            + "files, " + ILC.get_log_level_string(self.logLevelSystem) + ")\n"
            + "\tLOGGER(CLI: " + str(self.logFileSizeClient) + "bytes " + str(self.logFileCountClient)
            + "files, " + ILC.get_log_level_string(self.logLevelClient) + ")\n"
            + "\tLOGGER(QUE: " + str(self.logFileSizeQueue) + "bytes " + str(self.logFileCountQueue)
            + "files, " + ILC.get_log_level_string(self.logLevelQueue) + ")\n"
            + "\tLOGGER(CHL: " + str(self.logFileSizeChannel) + "bytes " + str(self.logFileCountChannel)
            + "files, " + ILC.get_log_level_string(self.logLevelChannel) + ")\n"
            + "\tCHANNEL-RETRY-INTERVAL(" + str(self.channelRetryTimeInterval)
            + "sec) SOCKET-TIMEOUT(" + str(self.recvWaitTimeout) + ")\n"
            + tcp_lsr
            + "\tACL(" + ("ON" if self.aclEnabled else "OFF") + ") ACL-TYPE(" + self.get_acl_type_string() + ")\n"
            + "\tDEADSESSION(Max " + str(self.deadSessionMaxCount) + "ea, " + str(self.deadSessionKeepDuration) + "sec)\n"
            + "\tVERSION(" + self.version + ")\n"
        )


class ILSessionMinorProperty(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.id = ""
        self.status = 1
        self.peer = ""
        self.clientName = ""
        self.clientType = ""

        if ba is None:
            return
        try:
            if len(ba) < ILC.MIMQ_VO_MINOR_SES_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_MINOR_SES_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.status = ba_pick_int(ba, offset, 2)
            offset += 2
            self.id = ba_pick_string(ba, offset, 36)
            offset += 36
            self.peer = ba_pick_string(ba, offset, 22)
            offset += 22
            self.clientName = ba_pick_string(ba, offset, 70)
            offset += 70
            self.clientType = ba_pick_string(ba, offset, 4)
            offset += 4
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_MINOR_SES_LEN)
        offset = 0
        ba_merge(self.status, ba, offset)
        offset += 2
        ba_merge(self.id, ba, offset)
        offset += 36
        ba_merge(self.peer, ba, offset)
        offset += 22
        ba_merge(self.clientName, ba, offset)
        offset += 70
        ba_merge(self.clientType, ba, offset)
        offset += 4
        return bytes(ba)


class ILSessionProperty(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.id = ""
        self.createdTime = 0
        self.peerAddr = ""
        self.peerPort = 0
        self.clientName = ""
        self.clientType = ""
        self.transacted = False
        self.autoCommit = False
        self.lastAccessObject = ""
        self.totalPutCount = 0
        self.totalGetCount = 0
        self.totalPutSize = 0
        self.totalGetSize = 0
        self.countPutting = 0
        self.countGetting = 0
        self.sizePutting = 0
        self.sizeGetting = 0
        self.status = 1
        self.destroyedTime = 0
        self.exceptionMsg = ""
        self.traceEnabled = False

        if ba is None:
            return
        try:
            if len(ba) < ILC.MIMQ_VO_SESSION_LEN:
                raise ILDeserializeException(
                    "invalid byte array length. fixed : ["
                    + str(ILC.MIMQ_VO_SESSION_LEN)
                    + "] / actual : ["
                    + str(len(ba))
                    + "]"
                )
            offset = 0
            self.id = ba_pick_string(ba, offset, 36)
            offset += 36
            self.createdTime = ba_pick_long(ba, offset, 20)
            offset += 20
            self.peerAddr = ba_pick_string(ba, offset, 15)
            offset += 15
            self.peerPort = ba_pick_int(ba, offset, 5)
            offset += 5
            self.clientName = ba_pick_string(ba, offset, 70)
            offset += 70
            self.clientType = ba_pick_string(ba, offset, 3)
            offset += 3
            self.transacted = ba_pick_string(ba, offset, 1).upper() == "T"
            offset += 1
            self.autoCommit = ba_pick_string(ba, offset, 1).upper() == "T"
            offset += 1
            self.lastAccessObject = ba_pick_string(ba, offset, 48)
            offset += 48
            self.totalPutCount = ba_pick_long(ba, offset, 20)
            offset += 20
            self.totalGetCount = ba_pick_long(ba, offset, 20)
            offset += 20
            self.totalPutSize = ba_pick_long(ba, offset, 20)
            offset += 20
            self.totalGetSize = ba_pick_long(ba, offset, 20)
            offset += 20
            self.countPutting = ba_pick_long(ba, offset, 20)
            offset += 20
            self.countGetting = ba_pick_long(ba, offset, 20)
            offset += 20
            self.sizePutting = ba_pick_long(ba, offset, 20)
            offset += 20
            self.sizeGetting = ba_pick_long(ba, offset, 20)
            offset += 20
            self.status = ba_pick_int(ba, offset, 1)
            offset += 1
            self.destroyedTime = ba_pick_long(ba, offset, 20)
            offset += 20
            self.exceptionMsg = ba_pick_string(ba, offset, 128)
            offset += 512
            self.traceEnabled = ba_pick_string(ba, offset, 1).lower() == "t"
        except Exception as exc:
            raise ILException(exc) from exc

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_SESSION_LEN)
        offset = 0
        ba_merge(self.id, ba, offset)
        offset += 36
        ba_merge(self.createdTime, ba, offset)
        offset += 20
        ba_merge(self.peerAddr, ba, offset)
        offset += 15
        ba_merge(self.peerPort, ba, offset)
        offset += 5
        ba_merge(self.clientName, ba, offset)
        offset += 70
        ba_merge(self.clientType, ba, offset)
        offset += 3
        ba_merge("T" if self.transacted else "F", ba, offset)
        offset += 1
        ba_merge("T" if self.autoCommit else "F", ba, offset)
        offset += 1
        ba_merge(self.lastAccessObject, ba, offset)
        offset += 48
        ba_merge(self.totalPutCount, ba, offset)
        offset += 20
        ba_merge(self.totalGetCount, ba, offset)
        offset += 20
        ba_merge(self.totalPutSize, ba, offset)
        offset += 20
        ba_merge(self.totalGetSize, ba, offset)
        offset += 20
        ba_merge(self.countPutting, ba, offset)
        offset += 20
        ba_merge(self.countGetting, ba, offset)
        offset += 20
        ba_merge(self.sizePutting, ba, offset)
        offset += 20
        ba_merge(self.sizeGetting, ba, offset)
        offset += 20
        ba_merge(self.status, ba, offset)
        offset += 1
        ba_merge(self.destroyedTime, ba, offset)
        offset += 20
        ba_merge(self.exceptionMsg, ba, offset)
        offset += 512
        ba_merge("t" if self.traceEnabled else "f", ba, offset)
        return bytes(ba)

    def get_created_time(self) -> str:
        return _format_millis(self.createdTime, "%Y-%m-%d %H:%M:%S.%f")[:-3]

    def get_created_time_in_millisecond(self) -> int:
        return self.createdTime

    def get_status_string(self) -> str:
        if self.status == 0:
            return "DEAD"
        if self.status == 1:
            return "IDLE"
        if self.status == 2:
            return "BEGIN_RECV"
        if self.status == 3:
            return "RECEIVING"
        if self.status == 4:
            return "ON_RECV"
        if self.status == 5:
            return "BEGIN_SEND"
        if self.status == 6:
            return "SENDING"
        if self.status == 7:
            return "ON_SEND"
        return "UNKNOWN"

    def get_destroyed_time(self) -> str:
        return _format_millis(self.destroyedTime, "%Y-%m-%d %H:%M:%S.%f")[:-3]

    def get_destroyed_time_in_millisecond(self) -> int:
        return self.destroyedTime

    def get_minor_property(self) -> ILSessionMinorProperty:
        mp = ILSessionMinorProperty()
        mp.id = self.id
        mp.peer = self.peerAddr + ":" + str(self.peerPort)
        mp.status = self.status
        mp.clientName = self.clientName
        mp.clientType = self.clientType
        return mp

    def __str__(self) -> str:
        return (
            "\n"
            + f"\tID({self.id}) STATUS({self.get_status_string()})\n"
            + f"\tCREATED({self.get_created_time()})\n"
            + f"\tREMOVED({self.get_destroyed_time()})\n"
            + "\tPEER(" + self.peerAddr + ":" + str(self.peerPort)
            + ") TRACE(" + ("ON" if self.traceEnabled else "OFF") + ")\n"
            + "\tCLIENT-TYPE(" + self.clientType + ") CLIENT-NAME(" + self.clientName + ")\n"
            + "\tTRANSACTED(" + ("TRUE" if self.transacted else "FALSE")
            + ") AUTOCOMMIT(" + ("TRUE" if self.autoCommit else "FALSE") + ")\n"
            + "\tLAST-ACCESS-OBJECT(" + self.lastAccessObject + ")\n"
            + "\tPUT(" + str(self.totalPutCount) + ", " + str(self.totalPutSize)
            + "bytes) PUTTING(" + str(self.countPutting) + ", " + str(self.sizePutting) + "bytes)\n"
            + "\tGET(" + str(self.totalGetCount) + ", " + str(self.totalGetSize)
            + "bytes) GETTING(" + str(self.countGetting) + ", " + str(self.sizeGetting) + "bytes)\n"
            + "\tEXCEPTION(" + self.exceptionMsg + ")\n"
        )


class ILServiceProperty(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.ip = "127.0.0.1"
        self.port = 9998
        self.version = ""
        self.timeoutSocketConnect = 10
        self.timeoutSocketRecv = 600
        self.poolSizeAccept = 1
        self.poolSizeEvent = 1
        self.logLevelSystem = 4
        self.logFileSizeSystem = 4194304
        self.logFileCountSystem = 5
        self.logLevelClient = 4
        self.logFileSizeClient = 4194304
        self.logFileCountClient = 5
        self.traceEnabled = False
        self.aclEnabled = False
        self.aclType = 0
        self.relayType = ILC.MIMQ_SVC_TYPE_HUB
        self.key = ""
        self.name = ""
        self.hubIp = ""
        self.hubPort = -1

        if ba is None:
            return
        if len(ba) < ILC.MIMQ_VO_SERVER_LEN:
            raise ILDeserializeException(
                "invalid byte array length. fixed : ["
                + str(ILC.MIMQ_VO_SERVER_LEN)
                + "] / actual : ["
                + str(len(ba))
                + "]"
            )
        offset = 0
        self.ip = ba_pick_string(ba, offset, 100)
        offset += 100
        self.port = ba_pick_int(ba, offset, 6)
        offset += 6
        offset += 22
        self.version = ba_pick_string(ba, offset, 20)
        offset += 20
        self.timeoutSocketConnect = ba_pick_int(ba, offset, 10)
        offset += 10
        self.timeoutSocketRecv = ba_pick_int(ba, offset, 10)
        offset += 10
        self.poolSizeAccept = ba_pick_int(ba, offset, 10)
        offset += 10
        self.poolSizeEvent = ba_pick_int(ba, offset, 10)
        offset += 10
        self.logLevelSystem = ba_pick_int(ba, offset, 2)
        offset += 2
        self.logFileSizeSystem = ba_pick_int(ba, offset, 15)
        offset += 15
        self.logFileCountSystem = ba_pick_int(ba, offset, 5)
        offset += 5
        self.logLevelClient = ba_pick_int(ba, offset, 2)
        offset += 2
        self.logFileSizeClient = ba_pick_int(ba, offset, 15)
        offset += 15
        self.logFileCountClient = ba_pick_int(ba, offset, 5)
        offset += 5
        offset += 44
        self.traceEnabled = ba_pick_string(ba, offset, 1).lower() == "t"
        offset += 2
        self.aclEnabled = ba_pick_string(ba, offset, 1).lower() == "t"
        offset += 2
        self.aclType = ba_pick_int(ba, offset, 2)
        offset += 2
        self.relayType = ba_pick_int(ba, offset, 1)
        offset += 2
        self.key = ba_pick_string(ba, offset, 36)
        offset += 36
        self.name = ba_pick_string(ba, offset, 48)
        offset += 48
        self.hubIp = ba_pick_string(ba, offset, 24)
        offset += 24
        self.hubPort = ba_pick_int(ba, offset, 10)
        offset += 10

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_SERVER_LEN)
        offset = 0
        ba_merge(self.ip, ba, offset)
        offset += 100
        ba_merge(self.port, ba, offset)
        offset += 6
        offset += 22
        ba_merge(self.version, ba, offset)
        offset += 20
        ba_merge(self.timeoutSocketConnect, ba, offset)
        offset += 10
        ba_merge(self.timeoutSocketRecv, ba, offset)
        offset += 10
        ba_merge(self.poolSizeAccept, ba, offset)
        offset += 10
        ba_merge(self.poolSizeEvent, ba, offset)
        offset += 10
        ba_merge(self.logLevelSystem, ba, offset)
        offset += 2
        ba_merge(self.logFileSizeSystem, ba, offset)
        offset += 15
        ba_merge(self.logFileCountSystem, ba, offset)
        offset += 5
        ba_merge(self.logLevelClient, ba, offset)
        offset += 2
        ba_merge(self.logFileSizeClient, ba, offset)
        offset += 15
        ba_merge(self.logFileCountClient, ba, offset)
        offset += 5
        offset += 44
        ba_merge("t" if self.traceEnabled else "f", ba, offset)
        offset += 2
        ba_merge("t" if self.aclEnabled else "f", ba, offset)
        offset += 2
        ba_merge(self.aclType, ba, offset)
        offset += 2
        ba_merge(self.relayType, ba, offset)
        offset += 2
        ba_merge(self.key, ba, offset)
        offset += 36
        ba_merge(self.name, ba, offset)
        offset += 48
        ba_merge(self.hubIp, ba, offset)
        offset += 24
        ba_merge(self.hubPort, ba, offset)
        offset += 10
        return bytes(ba)

    def get_log_level(self, log_type: int) -> int:
        if log_type == ILC.MIMQ_LOGGER_TYPE_SYSTEM:
            return self.logLevelSystem
        if log_type == ILC.MIMQ_LOGGER_TYPE_CLIENT:
            return self.logLevelClient
        return -1

    def get_log_level_string(self, log_type: int) -> str:
        return ILC.get_log_level_string(self.get_log_level(log_type))

    def set_log_level(self, log_type: int, log_level: int) -> None:
        _validate_log_level(log_level)
        if log_type == ILC.MIMQ_LOGGER_TYPE_SYSTEM:
            self.logLevelSystem = log_level
        elif log_type == ILC.MIMQ_LOGGER_TYPE_CLIENT:
            self.logLevelClient = log_level
        else:
            raise UnsupportedOperationException(
                f"[{log_type}] is an unacceptable value. (acceptable value list: [0 | 1])"
            )

    def set_pool_size_accept(self, size: int) -> None:
        if size < 1 or size > 9:
            raise UnsupportedOperationException(
                f"[{size}] is an unacceptable value. (acceptable value range: 1~9)"
            )
        self.poolSizeAccept = size

    def set_pool_size_event(self, size: int) -> None:
        if size < 1 or size > 99:
            raise UnsupportedOperationException(
                f"[{size}] is an unacceptable value. (acceptable value range: 1~99)"
            )
        self.poolSizeEvent = size

    def set_timeout_socket_connect(self, sec: int) -> None:
        if sec < -1:
            raise UnsupportedOperationException(
                f"[{sec}] is an unacceptable value. (acceptable value range: -1~)"
            )
        self.timeoutSocketConnect = sec

    def set_timeout_socket_recv(self, sec: int) -> None:
        if sec < -1:
            raise UnsupportedOperationException(
                f"[{sec}] is an unacceptable value. (acceptable value range: -1~)"
            )
        self.timeoutSocketRecv = sec

    def set_acl_type(self, value: int) -> None:
        if value not in (ILC.MIMQ_ACL_BY_BLACKLIST, ILC.MIMQ_ACL_BY_WHITELIST):
            raise UnsupportedOperationException(
                f"[{value}] is an unacceptable value. (acceptable value range: 0~1)"
            )
        self.aclType = value

    def is_hub(self) -> bool:
        return self.relayType == ILC.MIMQ_SVC_TYPE_HUB

    def __str__(self) -> str:
        return (
            "\n"
            + "\tLISTEN(" + self.ip + ":" + str(self.port) + ") TRACE(" + ("ON" if self.traceEnabled else "OFF") + ")\n"
            + "\tLOGGER TYPE(SYS) LEVEL(" + ILC.get_log_level_string(self.logLevelSystem)
            + ") ROLLING(" + str(self.logFileSizeSystem) + "bytes, " + str(self.logFileCountSystem) + "files)\n"
            + "\tLOGGER TYPE(CLI) LEVEL(" + ILC.get_log_level_string(self.logLevelClient)
            + ") ROLLING(" + str(self.logFileSizeClient) + "bytes, " + str(self.logFileCountClient) + "files)\n"
            + "\tTCPLSR ACCEPT(" + str(self.poolSizeAccept) + "threads) EVENT(" + str(self.poolSizeEvent) + "threads)\n"
            + "\tTCPSOCKET TIMEOUT(" + str(self.timeoutSocketRecv) + "sec)\n"
            + "\tACL(" + ("ON" if self.aclEnabled else "OFF") + ") ACL-TYPE(" + ("BLACKLIST" if self.aclType == ILC.MIMQ_ACL_BY_BLACKLIST else "WHITELIST" if self.aclType == ILC.MIMQ_ACL_BY_WHITELIST else "UNKNOWN") + ")\n"
            + "\tRELAY-TYPE(" + ("HUB" if self.is_hub() else "SPOKE") + ") NAME(" + self.name + ") HUB(" + self.hubIp + ":" + str(self.hubPort) + ")\n"
            + "\tVERSION(" + self.version + ")\n"
        )


class ILSpokeProperty(_AutoAccessor):
    def __init__(self, ba: bytes | bytearray | None = None) -> None:
        self.key = ""
        self.name = ""
        self.peer = ""
        self.isRunning = False

        if ba is None:
            return
        if len(ba) < ILC.MIMQ_VO_SPOKEINFO_LEN:
            raise ILDeserializeException(
                "invalid byte array length. fixed : ["
                + str(ILC.MIMQ_VO_SPOKEINFO_LEN)
                + "] / actual : ["
                + str(len(ba))
                + "]"
            )
        offset = 0
        self.key = ba_pick_string(ba, offset, 36)
        offset += 36
        self.name = ba_pick_string(ba, offset, 48)
        offset += 48
        self.peer = ba_pick_string(ba, offset, 24)
        offset += 24
        self.isRunning = ba_pick_string(ba, offset, 1).lower() == "t"
        offset += 1

    def get_serialized(self) -> bytes:
        ba = bytearray(ILC.MIMQ_VO_SPOKEINFO_LEN)
        offset = 0
        ba_merge(self.key, ba, offset)
        offset += 36
        ba_merge(self.name, ba, offset)
        offset += 48
        ba_merge(self.peer, ba, offset)
        offset += 24
        ba_merge("t" if self.isRunning else "f", ba, offset)
        offset += 1
        return bytes(ba)

    def __str__(self) -> str:
        return (
            "KEY(" + self.key + ") NAME(" + self.name + ") PEER(" + self.peer
            + ") STATUS(" + ("LIVE" if self.isRunning else "DEAD") + ")"
        )


class ILPropertyUtil:
    @staticmethod
    def get_serialized(vo) -> bytes:
        if isinstance(
            vo,
            (
                ILServiceProperty,
                ILAccessRuleProperty,
                ILSessionProperty,
                ILQmgrProperty,
                ILQueueProperty,
                ILChannelProperty,
            ),
        ):
            return vo.get_serialized()
        raise ILDeserializeException(f"{vo.__class__.__name__} is unsupported object type.")
