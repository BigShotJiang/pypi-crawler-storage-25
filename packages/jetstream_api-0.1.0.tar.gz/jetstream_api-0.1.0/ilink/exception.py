from __future__ import annotations

from .common import ILC, ILCC, ILRC


class UnsupportedOperationException(Exception):
    pass


class ILDeserializeException(Exception):
    def __init__(self, msg: str, cause: Exception | None = None) -> None:
        super().__init__(msg)
        if cause is not None:
            self.__cause__ = cause


class ILException(Exception):
    def __init__(self, cause: Exception) -> None:
        super().__init__(cause)
        self.completion_code = 0
        self.reason_code = 0
        self.report_msg = ""
        self._set_code_by_instance(cause)

    def get_completion_code(self) -> int:
        return self.completion_code

    def get_reason_code(self) -> int:
        return self.reason_code

    def get_message(self) -> str:
        return self.get_localized_message()

    def get_localized_message(self) -> str:
        return f"{self._get_completion_string()} ({self._get_reason_msg()})"

    def get_report_msg(self) -> str:
        return self.report_msg

    def __str__(self) -> str:
        return self.get_localized_message()

    def _set_code_by_instance(self, cause: Exception) -> None:
        self.completion_code = ILCC.MIMQC_FATAL_ERROR
        # Check specific subtypes first (most-specific to least-specific)
        if isinstance(cause, ILOperationException):
            self.completion_code = cause.get_comp_code()
            self.reason_code = cause.get_reason_code()
            self.report_msg = cause.get_report_msg()
        elif isinstance(cause, ILSessionException):
            self.completion_code = ILCC.MIMQC_RECONNECT_REQUIRED
            self.reason_code = cause.get_reason_code()
        elif isinstance(cause, ILMsgTypeException):
            self.reason_code = ILRC.MIMQE_INVALID_MSG_TYPE
        elif isinstance(cause, ILDeserializeException):
            self.reason_code = ILRC.MIMQE_INVALID_BUFFER_SIZE
        elif isinstance(cause, (UnsupportedOperationException, NotImplementedError)):
            self.completion_code = ILCC.MIMQC_USER_FAULT
            self.reason_code = ILRC.MIMQE_NOT_SUPPORTED
        elif isinstance(cause, ILNoMsgException):
            self.completion_code = ILCC.MIMQC_NORMAL
            self.reason_code = ILRC.MIMQE_NO_MSG_AVAILABLE
        elif isinstance(cause, ILTimeoutException):
            self.completion_code = ILCC.MIMQC_NORMAL
            self.reason_code = ILRC.MIMQE_WAIT_TIMEOUT
        elif isinstance(cause, ILException):
            self.completion_code = cause.get_completion_code()
            self.reason_code = cause.get_reason_code()
            self.report_msg = cause.get_report_msg()
        else:
            self.reason_code = ILRC.MIMQE_INTERNAL_ERROR

    _COMPLETION_CODE_NAMES: dict[int, str] = {
        ILCC.MIMQC_NORMAL: "MIMQC_NORMAL",
        ILCC.MIMQC_USER_FAULT: "MIMQC_USER_FAULT",
        ILCC.MIMQC_SYSTEM_FAULT: "MIMQC_SYSTEM_FAULT",
        ILCC.MIMQC_SERVICE_FAULT: "MIMQC_SERVICE_FAULT",
        ILCC.MIMQC_RECONNECT_REQUIRED: "MIMQC_RECONNECT_REQUIRED",
        ILCC.MIMQC_FATAL_ERROR: "MIMQC_FATAL_ERROR",
    }

    _REASON_CODE_NAMES: dict[int, str] = {
        ILRC.MIMQE_OBJECT_NOT_FOUND: "MIMQE_OBJECT_NOT_FOUND",
        ILRC.MIMQE_OBJECT_ALREADY_EXIST: "MIMQE_OBJECT_ALREADY_EXIST",
        ILRC.MIMQE_REMOTE_OPERATION_FAILURE: "MIMQE_REMOTE_OPERATION_FAILURE",
        ILRC.MIMQE_QUEUE_FULL: "MIMQE_QUEUE_FULL",
        ILRC.MIMQE_MSG_SIZE_OVER: "MIMQE_MSG_SIZE_OVER",
        ILRC.MIMQE_NOT_AVAILABLE_QUEUE_TYPE: "MIMQE_NOT_AVAILABLE_QUEUE_TYPE",
        ILRC.MIMQE_OBJECT_IN_USE: "MIMQE_OBJECT_IN_USE",
        ILRC.MIMQE_BROWSER_NOT_EXIST: "MIMQE_BROWSER_NOT_EXIST",
        ILRC.MIMQE_CHANNEL_IS_RUNNING: "MIMQE_CHANNEL_IS_RUNNING",
        ILRC.MIMQE_UNABLE_TO_START_SERVER_CHANNEL: "MIMQE_UNABLE_TO_START_SERVER_CHANNEL",
        ILRC.MIMQE_QMGR_IS_RUNNING: "MIMQE_QMGR_IS_RUNNING",
        ILRC.MIMQE_QMGR_NOT_RUNNING: "MIMQE_QMGR_NOT_RUNNING",
        ILRC.MIMQE_ENGINE_MSG_INDEX_ERROR: "MIMQE_ENGINE_MSG_INDEX_ERROR",
        ILRC.MIMQE_FILESYSTEM_IO_ERROR: "MIMQE_FILESYSTEM_IO_ERROR",
        ILRC.MIMQE_INTERNAL_SESSION_ERROR: "MIMQE_INTERNAL_SESSION_ERROR",
        ILRC.MIMQE_SERVICE_DENIED: "MIMQE_SERVICE_DENIED",
        ILRC.MIMQE_INVALID_REQUEST: "MIMQE_INVALID_REQUEST",
        ILRC.MIMQE_CONFIGURATION_ERROR: "MIMQE_CONFIGURATION_ERROR",
        ILRC.MIMQE_SYSTEM_RESOURCE_ERROR: "MIMQE_SYSTEM_RESOURCE_ERROR",
        ILRC.MIMQE_SESSION_TIMEOUT: "MIMQE_SESSION_TIMEOUT",
        ILRC.MIMQE_NOT_CONNECTED: "MIMQE_NOT_CONNECTED",
        ILRC.MIMQE_ALREADY_CONNECTED: "MIMQE_ALREADY_CONNECTED",
        ILRC.MIMQE_RAW_SOCKET_ERROR: "MIMQE_RAW_SOCKET_ERROR",
        ILRC.MIMQE_INVALID_ADDRESS: "MIMQE_INVALID_ADDRESS",
        ILRC.MIMQE_UNSUPPORTED_DEVICE_EVENT: "MIMQE_UNSUPPORTED_DEVICE_EVENT",
        ILRC.MIMQE_INTERNAL_ERROR: "MIMQE_INTERNAL_ERROR",
        ILRC.MIMQE_INVALID_MSG_TYPE: "MIMQE_INVALID_MSG_TYPE",
        ILRC.MIMQE_INVALID_BUFFER_SIZE: "MIMQE_INVALID_BUFFER_SIZE",
        ILRC.MIMQE_INVALID_ARGUMENT: "MIMQE_INVALID_ARGUMENT",
        ILRC.MIMQE_INVALID_DELIMITER: "MIMQE_INVALID_DELIMITER",
        ILRC.MIMQE_NIO_ERROR: "MIMQE_NIO_ERROR",
        ILRC.MIMQE_BIO_ERROR: "MIMQE_BIO_ERROR",
        ILRC.MIMQE_NOT_SUPPORTED: "MIMQE_NOT_SUPPORTED",
        ILRC.MIMQE_NO_MSG_AVAILABLE: "MIMQE_NO_MSG_AVAILABLE",
        ILRC.MIMQE_WAIT_TIMEOUT: "MIMQE_WAIT_TIMEOUT",
        ILRC.MIMQE_PROXY_CONN_ERROR: "MIMQE_PROXY_CONN_ERROR",
    }

    def _get_completion_string(self) -> str:
        return self._COMPLETION_CODE_NAMES.get(
            self.completion_code, f"MIMQC_UNKNOWN_CODE ({self.completion_code})"
        )

    def _get_reason_msg(self) -> str:
        return self._REASON_CODE_NAMES.get(
            self.reason_code, f"MIMQE_UNKNOWN_CODE ({self.reason_code})"
        )


class ILMsgTypeException(Exception):
    _TYPE_NAMES: dict[int, str] = {
        ILC.MIMQ_DATA_MESSAGE: "MIMQ_DATA_MESSAGE",
        ILC.MIMQ_REQUEST_MESSAGE: "MIMQ_REQUEST_MESSAGE",
        ILC.MIMQ_REPORT_MESSAGE: "MIMQ_REPORT_MESSAGE",
        ILC.MIMQ_LONG_REPORT_MESSAGE: "MIMQ_LONG_REPORT_MESSAGE",
        ILC.MIMQ_LONG_REQUEST_MESSAGE: "MIMQ_LONG_REQUEST_MESSAGE",
        ILC.MIMQ_DATAGRAM: "MIMQ_DATAGRAM",
        ILC.MIMQ_REQUEST: "MIMQ_REQUEST",
        ILC.MIMQ_REPLY: "MIMQ_REPLY",
        ILC.MIMQ_BASIC_MESSAGE: "MIMQ_BASIC_MESSAGE",
        ILC.MIMQ_TEXT_MESSAGE: "MIMQ_TEXT_MESSAGE",
        ILC.MIMQ_BYTES_MESSAGE: "MIMQ_BYTES_MESSAGE",
        ILC.MIMQ_STREAM_MESSAGE: "MIMQ_STREAM_MESSAGE",
        ILC.MIMQ_MAP_MESSAGE: "MIMQ_MAP_MESSAGE",
        ILC.MIMQ_OBJECT_MESSAGE: "MIMQ_OBJECT_MESSAGE",
        ILC.MIMQ_BYTES_DATALESS_MESSAGE: "MIMQ_BYTES_DATALESS_MESSAGE",
        ILC.MIMQ_PROXY_REQUEST_MESSAGE: "MIMQ_PROXY_REQUEST_MESSAGE",
        ILC.MIMQ_PROXY_LONG_REQUEST_MESSAGE: "MIMQ_PROXY_LONG_REQUEST_MESSAGE",
    }

    def __init__(self, type_code: int, msg: str) -> None:
        super().__init__(msg)
        self.type_code = type_code
        self.msg = msg

    def get_message(self) -> str:
        return f"msg type is [{self.get_type_string()}] {self.msg}"

    def get_localized_message(self) -> str:
        return self.get_message()

    def get_type_code(self) -> int:
        return self.type_code

    def get_type_string(self) -> str:
        return self._TYPE_NAMES.get(self.type_code, "UNKNOWN_TYPE")

    def __str__(self) -> str:
        return self.get_message()


class ILNoMsgException(Exception):
    def __init__(self, qmgr_name: str, queue_name: str) -> None:
        super().__init__(f"no message available. qmgr[{qmgr_name}], queue[{queue_name}]")


# ---- Prefix-to-error-code mapping tables for ILOperationException ---------
# Each entry: (prefix_tuple, comp_code, reason_code)
# Order matters: first match wins.  More-specific prefixes must come before
# broader ones (e.g. "MIMQE_INVALID_ARGUMENT (Channel" before "MIMQE_INVALID_ARGUMENT").
_PREFIX_RULES: list[tuple[tuple[str, ...], int, int]] = [
    # --- exact / simple prefixes ---
    (("MIMQE_OBJECT_NOT_FOUND",), ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_OBJECT_NOT_FOUND),
    (("MIMQE_OBJECT_ALREADY_EXIST",), ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_OBJECT_ALREADY_EXIST),
    (("MIMQE_ALREADY_CONNECTED",), ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_ALREADY_CONNECTED),
    # --- engine/index errors (FATAL) ---
    (("MIMQE_MSG_NOT_FOUND", "MIMQE_INDEX_DUPLICATED"),
     ILCC.MIMQC_FATAL_ERROR, ILRC.MIMQE_ENGINE_MSG_INDEX_ERROR),
    # --- filesystem I/O (SYSTEM_FAULT) ---
    (("MIMQE_FILE_", "MIMQE_TRX_CODE_WRITE_", "MIMQE_MOVE_CURSOR_",
      "MIMQE_INQUIRE_CURSOR_", "MIMQE_CLOSE_FD_", "MIMQE_RENAME_",
      "MIMQE_RESERVE_CHAR_WRITE_", "MIMQE_MSG_HEADER_WRITE_",
      "MIMQE_MSG_BODY_WRITE_", "MIMQE_MSG_HEADER_READ_",
      "MIMQE_MSG_BODY_READ_", "MIMQE_HISTORY_",
      "MIMQE_INVALID_CURSOR_POSITION", "MIMQE_CREATE_DIR_",
      "MIMQE_DIR_CREATE_", "MIMQE_XML_DUMP_"),
     ILCC.MIMQC_SYSTEM_FAULT, ILRC.MIMQE_FILESYSTEM_IO_ERROR),
    # --- configuration errors (before generic MIMQE_INVALID_ARGUMENT) ---
    (("MIMQE_INVALID_ARGUMENT (Channel", "MIMQE_INVALID_ARGUMENT (DestQmgr",
      "MIMQE_CFG_", "MIMQE_PARSE_XML_", "MIMQE_INVALID_LOG"),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_CONFIGURATION_ERROR),
    # --- invalid request ---
    (("MIMQE_INVALID_SELECTOR_TYPE", "MIMQE_INVALID_MSG_TYPE",
      "MIMQE_INVALID_REQ_CODE",
      "MIMQE_INVALID_ARGUMENT (MISSING_PROXY_QMGR)",
      "MIMQE_INVALID_INNER_TYPE",
      "MIMQE_NOT_SUPPORTED_IN_OFFLINE_MODE", "MIMQE_INVALID_TARGET",
      "MIMQE_UNSUPPORTED_", "MIMQE_UNAVAILABLE_"),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_INVALID_REQUEST),
    # --- session/connection errors (SERVICE_FAULT) ---
    (("MIMQE_ASIO_", "MIMQE_SSL_", "MIMQE_NOT_CONNECTED",
      "MIMQE_SOCKET_", "MIMQE_CHANGE_IO_", "MIMQE_RESOLVE_",
      "MIMQE_CONNECTION_DENIED", "MIMQE_PROTOCOL_", "MIMQE_TIMEOUT",
      "MIMQE_TRX_", "MIMQE_PING_", "MIMQE_CLEAR_", "MIMQE_PIPE_"),
     ILCC.MIMQC_SERVICE_FAULT, ILRC.MIMQE_INTERNAL_SESSION_ERROR),
    # --- resource errors ---
    (("MIMQE_OUT_OF_MEMORY",), ILCC.MIMQC_SYSTEM_FAULT, ILRC.MIMQE_SYSTEM_RESOURCE_ERROR),
    (("MIMQE_QUEUE_FULL",), ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_QUEUE_FULL),
    (("MIMQE_MSG_SIZE_OVER",), ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_MSG_SIZE_OVER),
    (("MIMQE_NOT_AVAILABLE_QUEUE_TYPE",),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_NOT_AVAILABLE_QUEUE_TYPE),
    (("MIMQE_OBJECT_IN_USE", "MIMQE_PORT_ALREADY_IN_USE"),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_OBJECT_IN_USE),
    (("MIMQE_BROWSER_NOT_EXIST",), ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_BROWSER_NOT_EXIST),
    (("MIMQE_CHANNEL_IS_RUNNING", "MIMQE_CHANNEL_NOT_STOPPED"),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_CHANNEL_IS_RUNNING),
    (("MIMQE_UNABLE_TO_START_SERVER_CHANNEL",),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_UNABLE_TO_START_SERVER_CHANNEL),
    # --- generic invalid argument (after the more-specific prefixes) ---
    (("MIMQE_INVALID_ARGUMENT", "MIMQE_INVALID_POOL_SIZE",
      "MIMQE_INVALID_INTERVAL", "MIMQE_INVALID_LOG_LEVEL",
      "MIMQE_INVALID_KEY_TYPE"),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_INVALID_ARGUMENT),
    (("MIMQE_INVALID_DELIMITER",), ILCC.MIMQC_SERVICE_FAULT, ILRC.MIMQE_INVALID_DELIMITER),
    (("MIMQE_NOT_SUPPORTED", "MIMQE_UNSUPPORTED_ENCRYPT_MODE"),
     ILCC.MIMQC_FATAL_ERROR, ILRC.MIMQE_NOT_SUPPORTED),
    (("MIMQE_QMGR_IS_RUNNING", "MIMQE_QMGR_NOT_STOPPED"),
     ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_QMGR_IS_RUNNING),
    (("MIMQE_QMGR_NOT_RUNNING",), ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_QMGR_NOT_RUNNING),
]

# Substring-based rules (checked with ``in``).
_CONTAINS_RULES: list[tuple[str, int, int]] = [
    ("ValidRange :", ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_CONFIGURATION_ERROR),
    (" : NULL", ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_INVALID_REQUEST),
    ("QueueType : REMOTE", ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_NOT_AVAILABLE_QUEUE_TYPE),
    ("QueueTypeCode :", ILCC.MIMQC_USER_FAULT, ILRC.MIMQE_NOT_AVAILABLE_QUEUE_TYPE),
]


class ILOperationException(Exception):
    def __init__(self, msg: str, cause: Exception | None = None) -> None:
        super().__init__(msg)
        if cause is not None:
            self.__cause__ = cause
        self.report_msg = msg
        self.comp_code = 0
        self.reason_code = self._resolve_reason_code()

    def get_comp_code(self) -> int:
        return self.comp_code

    def get_reason_code(self) -> int:
        return self.reason_code

    def get_report_msg(self) -> str:
        return self.report_msg

    # Keep old name as alias for callers that may reference it.
    def get_reason_code_by_msg(self) -> int:
        return self.reason_code

    def _resolve_reason_code(self) -> int:
        self.comp_code = ILCC.MIMQC_USER_FAULT
        msg = self.report_msg

        # 1) SERVICE_DENIED has special sub-rule
        if msg.startswith("MIMQE_SERVICE_DENIED"):
            if not msg.startswith("MIMQE_SERVICE_DENIED_BY_"):
                self.comp_code = ILCC.MIMQC_SERVICE_FAULT
            return ILRC.MIMQE_SERVICE_DENIED

        # 2) PROXY_ prefix has sub-rule based on suffix
        if msg.startswith("MIMQE_PROXY_"):
            if msg.endswith("_NOT_ALLOWED"):
                self.comp_code = ILCC.MIMQC_USER_FAULT
                return ILRC.MIMQE_INVALID_REQUEST
            self.comp_code = ILCC.MIMQC_RECONNECT_REQUIRED
            return ILRC.MIMQE_PROXY_CONN_ERROR

        # 3) Table-driven prefix matching
        for prefixes, comp, reason in _PREFIX_RULES:
            if any(msg.startswith(p) for p in prefixes):
                self.comp_code = comp
                return reason

        # 4) Substring-based rules
        for substr, comp, reason in _CONTAINS_RULES:
            if substr in msg:
                self.comp_code = comp
                return reason

        # 5) Default fallback
        self.comp_code = ILCC.MIMQC_SERVICE_FAULT
        return ILRC.MIMQE_REMOTE_OPERATION_FAILURE


class ILSessionException(Exception):
    def __init__(self, reason_code: int, msg: str | None = None, cause: Exception | None = None) -> None:
        if msg is None and cause is None:
            super().__init__()
        elif msg is None:
            super().__init__(cause)
        else:
            super().__init__(msg)
        if cause is not None:
            self.__cause__ = cause
        self.reason_code = reason_code

    def get_reason_code(self) -> int:
        return self.reason_code


class ILTimeoutException(Exception):
    def __init__(self, timeout: int) -> None:
        super().__init__(f"wait timeout (over {timeout}sec)")
