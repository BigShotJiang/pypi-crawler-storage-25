﻿
from __future__ import annotations

import selectors
import socket
import struct
import time
from .common import ILC, ILRC
from .exception import (
    ILMsgTypeException,
    ILOperationException,
    ILSessionException,
)
from .msg import ILDataMsg, ILMsg, ILMsgUtil, ILReportMsg


def _ba_pick_int(ba: bytes, offset: int, length: int) -> int:
    try:
        chunk = ba[offset : offset + length]
        if not chunk:
            return 0
        return int(chunk.split(b"\x00", 1)[0].decode("utf-8"))
    except Exception:
        return 0


class TCPConnector:
    def __init__(self) -> None:
        self.socket: socket.socket | None = None

    def is_online(self) -> bool:
        return self.socket is not None and self._is_connected()

    def isOnline(self) -> bool:
        return self.is_online()

    def connect(self, host: str, port: int, timeout_ms: int) -> None:
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(timeout_ms / 1000.0)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.socket.setsockopt(
                socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0)
            )
            self.socket.connect((host, port))
        except PermissionError as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INVALID_ADDRESS,
                f"permission error when resolve address : [{host}:{port}]",
                exc,
            ) from exc
        except socket.gaierror as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INVALID_ADDRESS,
                f"invalid address : [{host}:{port}]",
                exc,
            ) from exc
        except OSError as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_RAW_SOCKET_ERROR,
                "invalid underlying protocol : [TCP error]",
                exc,
            ) from exc
        except ValueError as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INVALID_ARGUMENT,
                f"invalid port number : [{port}]",
                exc,
            ) from exc
        except socket.timeout as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_BIO_ERROR,
                f"socket connect timeout (over {timeout_ms}ms)",
                exc,
            ) from exc
        except Exception as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INTERNAL_ERROR,
                "unhandled exception",
                exc,
            ) from exc

    def shutdown(self) -> None:
        if self.socket is not None:
            try:
                self.socket.close()
            except Exception:
                pass
            self.socket = None

    def send(self, msg: ILMsg) -> None:
        self.send_bytes(msg.toByteArray(True))

    def send_bytes(self, buffer: bytes) -> None:
        try:
            if self.socket is None or not self._is_connected():
                raise ILSessionException(
                    ILRC.MIMQE_NOT_CONNECTED,
                    "connect() has not yet been called or disconnect() has been called.",
                )
            self.socket.sendall(buffer)
        except ILSessionException:
            self.shutdown()
            raise
        except Exception as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_BIO_ERROR,
                "write() failure.",
                exc,
            ) from exc

    def recv(self, timeout_ms: int) -> ILMsg:
        try:
            if self.socket is None or not self._is_connected():
                raise ILSessionException(
                    ILRC.MIMQE_NOT_CONNECTED,
                    "connect() has not yet been called or disconnect() has been called.",
                )
            ba_len = self._recv_exact(ILC.SZ_LEN, timeout_ms)
            n_data = _ba_pick_int(ba_len, 0, ILC.SZ_LEN) - 9
            ba_data = self._recv_exact(n_data, timeout_ms)
            if ba_data[-1] != ord("\n"):
                raise ILSessionException(
                    ILRC.MIMQE_INVALID_DELIMITER,
                    f"invalid transmission delimiter : [{ba_data[-1]}]",
                )
            return ILMsg(ba_len, ba_data)
        except ILSessionException:
            self.shutdown()
            raise
        except Exception as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INTERNAL_ERROR,
                "unhandled exception",
                exc,
            ) from exc

    def _recv_exact(self, size: int, timeout_ms: int) -> bytes:
        if size <= 0:
            return b""
        if self.socket is None:
            raise ILSessionException(
                ILRC.MIMQE_NOT_CONNECTED,
                "connect() has not yet been called or disconnect() has been called.",
            )
        deadline = time.time() + (timeout_ms / 1000.0)
        chunks: list[bytes] = []
        remaining = size
        while remaining > 0:
            remaining_time = deadline - time.time()
            if remaining_time <= 0:
                raise ILSessionException(
                    ILRC.MIMQE_WAIT_TIMEOUT,
                    f"wait timeout (over {timeout_ms}ms)",
                )
            self.socket.settimeout(remaining_time)
            data = self.socket.recv(remaining)
            if not data:
                raise ILSessionException(
                    ILRC.MIMQE_BIO_ERROR,
                    "socket closed while receiving data",
                )
            chunks.append(data)
            remaining -= len(data)
        return b"".join(chunks)

    def _is_connected(self) -> bool:
        try:
            return self.socket is not None and self.socket.fileno() >= 0
        except Exception:
            return False


class TCPConnectorNIO:
    def __init__(self) -> None:
        self.sc: socket.socket | None = None
        self.selector: selectors.BaseSelector | None = None

    def is_online(self) -> bool:
        return self.sc is not None and self.sc.fileno() >= 0

    def isOnline(self) -> bool:
        return self.is_online()

    def connect(self, host: str, port: int, timeout_ms: int) -> None:
        try:
            self.selector = selectors.DefaultSelector()
            self.sc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sc.setblocking(False)
            self.sc.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self.sc.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.sc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sc.setsockopt(
                socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0)
            )

            result = self.sc.connect_ex((host, port))
            if result == 0:
                return
            self._wait_for_device_event("connect", timeout_ms)
        except ILSessionException:
            self.shutdown()
            raise
        except socket.gaierror as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INVALID_ADDRESS,
                f"invalid address : [{host}:{port}]",
                exc,
            ) from exc
        except ValueError as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INVALID_ARGUMENT,
                f"invalid port number : [{port}]",
                exc,
            ) from exc
        except OSError as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_RAW_SOCKET_ERROR,
                "invalid underlying protocol : [TCP error]",
                exc,
            ) from exc
        except Exception as exc:
            self.shutdown()
            raise ILSessionException(
                ILRC.MIMQE_INTERNAL_ERROR,
                "unhandled exception",
                exc,
            ) from exc

    def shutdown(self) -> None:
        if self.sc is not None:
            try:
                self.sc.close()
            except Exception:
                pass
            self.sc = None
        if self.selector is not None:
            try:
                self.selector.close()
            except Exception:
                pass
            self.selector = None

    def send(self, msg: ILMsg) -> None:
        self.send_bytes(msg.toByteArray(True))

    def send_bytes(self, buffer: bytes) -> None:
        if self.sc is None:
            raise ILSessionException(
                ILRC.MIMQE_NOT_CONNECTED,
                "connect() has not yet been called or disconnect() has been called.",
            )
        try:
            view = memoryview(buffer)
            total = 0
            while total < len(buffer):
                sent = self.sc.send(view[total:])
                if sent == 0:
                    self._wait_for_device_event("write", 1000)
                    continue
                total += sent
            if total != len(buffer):
                raise ILSessionException(
                    ILRC.MIMQE_NIO_ERROR,
                    f"write tried : [{len(buffer)}] / actual : [{total}]",
                )
        except ILSessionException:
            raise
        except Exception as exc:
            raise ILSessionException(
                ILRC.MIMQE_NIO_ERROR,
                "write() failure.",
                exc,
            ) from exc

    def recv(self, timeout_ms: int) -> ILMsg:
        try:
            if self.sc is None:
                raise ILSessionException(
                    ILRC.MIMQE_NOT_CONNECTED,
                    "connect() has not yet been called or disconnect() has been called.",
                )
            remain = timeout_ms
            begin_time = time.time()
            ba_len = self._read_bytes(ILC.SZ_LEN, remain)
            data_len = _ba_pick_int(ba_len, 0, ILC.SZ_LEN) - 9
            remain -= int((time.time() - begin_time) * 1000)
            ba_data = self._read_bytes(data_len, remain)
            if ba_data[-1] != ord("\n"):
                raise ILSessionException(
                    ILRC.MIMQE_INVALID_DELIMITER,
                    f"invalid transmission delimiter : [{ba_data[-1]}]",
                )
            return ILMsg(ba_len, ba_data)
        except ILSessionException:
            raise
        except Exception as exc:
            raise ILSessionException(
                ILRC.MIMQE_INTERNAL_ERROR,
                "unhandled exception",
                exc,
            ) from exc

    def _wait_for_device_event(self, event: str, timeout_ms: int) -> None:
        if self.selector is None or self.sc is None:
            raise ILSessionException(ILRC.MIMQE_NOT_CONNECTED, "selector closed")
        try:
            if event == "connect":
                mask = selectors.EVENT_WRITE
            elif event == "read":
                mask = selectors.EVENT_READ
            elif event == "write":
                mask = selectors.EVENT_WRITE
            else:
                raise ILSessionException(
                    ILRC.MIMQE_UNSUPPORTED_DEVICE_EVENT,
                    f"unknown select key event code : [{event}]",
                )

            self.selector.register(self.sc, mask)
            remain = timeout_ms
            while remain > 0:
                begin_time = time.time()
                events = self.selector.select(remain / 1000.0)
                if events:
                    for key, _ in events:
                        if key.fileobj is not self.sc:
                            continue
                        if event == "connect":
                            err = self.sc.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                            if err != 0:
                                raise ILSessionException(
                                    ILRC.MIMQE_NIO_ERROR,
                                    "non-blocking connect() failure.",
                                )
                        return
                elapse = int((time.time() - begin_time) * 1000)
                # Avoid busy-spin: if select returned instantly with no events,
                # apply a short back-off (10ms) instead of the old 1s sleep.
                if elapse < 10:
                    time.sleep(0.01)
                    elapse += 10
                remain -= elapse
            raise ILSessionException(
                ILRC.MIMQE_SESSION_TIMEOUT,
                f"waiting time has exceeded the time limit : [{timeout_ms}ms]",
            )
        except ILSessionException:
            raise
        except ValueError as exc:
            raise ILSessionException(
                ILRC.MIMQE_INVALID_ARGUMENT,
                f"invalid timeout : [{timeout_ms}]",
                exc,
            ) from exc
        except Exception as exc:
            raise ILSessionException(
                ILRC.MIMQE_INTERNAL_ERROR,
                "unhandled exception",
                exc,
            ) from exc
        finally:
            try:
                self.selector.unregister(self.sc)
            except Exception:
                pass

    def _read_bytes(self, size: int, timeout_ms: int) -> bytes:
        if self.sc is None:
            raise ILSessionException(
                ILRC.MIMQE_NOT_CONNECTED,
                "connect() has not been called yet.",
            )
        if size <= 0:
            return b""
        read_total = 0
        remain = timeout_ms
        chunks: list[bytes] = []
        while read_total < size and remain > 0:
            begin_time = time.time()
            try:
                data = self.sc.recv(size - read_total)
            except BlockingIOError:
                data = b""
            if not data:
                self._wait_for_device_event("read", max(remain, 1))
                remain -= int((time.time() - begin_time) * 1000)
                continue
            chunks.append(data)
            read_total += len(data)
            remain -= int((time.time() - begin_time) * 1000)
        if read_total < size:
            raise ILSessionException(
                ILRC.MIMQE_SESSION_TIMEOUT,
                f"waiting time has exceeded the time limit : [{timeout_ms}ms]",
            )
        if read_total != size:
            raise ILSessionException(
                ILRC.MIMQE_NIO_ERROR,
                f"read tried : [{size}] / actual : [{read_total}]",
            )
        return b"".join(chunks)


class ILRequestHelper:
    """High-level request-response protocol handler over TCP.

    .. note:: Thread Safety

        Instances of this class are **not** thread-safe.
    """

    def __init__(self, conn: TCPConnector | None = None) -> None:
        self.conn = conn or TCPConnector()
        self.sessionTimeoutMS = 600000

    def connect(self, host: str, port: int) -> None:
        self.conn.connect(host, port, self.sessionTimeoutMS)

    def shutdown(self) -> None:
        self.conn.shutdown()

    def set_conn(self, conn: TCPConnector) -> None:
        self.conn = conn

    def setConn(self, conn: TCPConnector) -> None:
        self.set_conn(conn)

    def get_conn(self) -> TCPConnector:
        return self.conn

    def getConn(self) -> TCPConnector:
        return self.get_conn()

    def is_online(self) -> bool:
        return self.conn.is_online()

    def isOnline(self) -> bool:
        return self.is_online()

    def set_session_timeout(self, value: int) -> None:
        self.sessionTimeoutMS = value

    def setSessionTimeout(self, value: int) -> None:
        self.set_session_timeout(value)

    def get_session_timeout(self) -> int:
        return self.sessionTimeoutMS

    def getSessionTimeout(self) -> int:
        return self.get_session_timeout()

    def request(self, *args) -> ILReportMsg | None:
        if not args:
            raise ValueError("request requires parameters")
        qmgr_name = ""
        ext = None
        idx = 0
        if isinstance(args[0], str):
            qmgr_name = args[0]
            idx = 1
        if idx >= len(args) or not isinstance(args[idx], int):
            raise ValueError("request code is required")
        request_code = args[idx]
        idx += 1

        success_code = None
        if idx < len(args) and isinstance(args[idx], int):
            success_code = args[idx]
            idx += 1
        if idx < len(args) and isinstance(args[idx], (bytes, bytearray)):
            ext = bytes(args[idx])
            idx += 1
        arg_list = [str(a) for a in args[idx:]]

        if success_code is None:
            if qmgr_name == "":
                msg = (
                    ILMsgUtil.create_request_msg_with_ext(request_code, ext, *arg_list)
                    if ext is not None
                    else ILMsgUtil.create_request_msg(request_code, *arg_list)
                )
            else:
                msg = ILMsgUtil.create_request_msg_with_qmgr(qmgr_name, request_code, ext, *arg_list)
            self.conn.send(msg)
            res_msg = self.conn.recv(self.sessionTimeoutMS)
            if ILC.MIMQ_REPORT_MESSAGE != res_msg.getType():
                raise ILMsgTypeException(
                    res_msg.getType(), " msg type must be [MIMQ_REPORT_MESSAGE]"
                )
            return res_msg.getReportMsg()

        if qmgr_name == "":
            msg = (
                ILMsgUtil.create_request_msg_with_ext(request_code, ext, *arg_list)
                if ext is not None
                else ILMsgUtil.create_request_msg(request_code, *arg_list)
            )
        else:
            msg = ILMsgUtil.create_request_msg_with_qmgr(qmgr_name, request_code, ext, *arg_list)
        self.conn.send(msg)
        res_msg = self.conn.recv(self.sessionTimeoutMS)
        if ILC.MIMQ_REPORT_MESSAGE != res_msg.getType():
            raise ILMsgTypeException(
                res_msg.getType(), " msg type must be [MIMQ_REPORT_MESSAGE]"
            )
        report_msg = res_msg.getReportMsg()
        if report_msg.getCode() != success_code:
            raise ILOperationException(report_msg.getArg2())
        return None

    def inquire(self, *args) -> ILMsg:
        if not args:
            raise ValueError("inquire requires parameters")
        if isinstance(args[0], ILMsg):
            request_msg = args[0]
            check_msg_type = bool(args[1]) if len(args) > 1 else True
            return self._inquire(request_msg, check_msg_type)

        qmgr_name = ""
        ext = None
        idx = 0
        if isinstance(args[0], str):
            qmgr_name = args[0]
            idx = 1
        if idx >= len(args) or not isinstance(args[idx], int):
            raise ValueError("request code is required")
        request_code = args[idx]
        idx += 1
        if idx < len(args) and isinstance(args[idx], (bytes, bytearray)):
            ext = bytes(args[idx])
            idx += 1
        arg_list = [str(a) for a in args[idx:]]

        if qmgr_name == "":
            return self._inquire(ILMsgUtil.create_request_msg(request_code, *arg_list), True)
        return self._inquire(
            ILMsgUtil.create_request_msg_with_qmgr(qmgr_name, request_code, ext, *arg_list),
            True,
        )

    def inquire_data_or_report(self, qmgr_name: str, request_code: int, ext: bytes, *args: str) -> ILMsg:
        msg = ILMsgUtil.create_request_msg_with_qmgr(qmgr_name, request_code, ext, *args)
        return self._inquire(msg, False)

    def inquireDataOrReport(self, qmgr_name: str, request_code: int, ext: bytes, *args: str) -> ILMsg:
        return self.inquire_data_or_report(qmgr_name, request_code, ext, *args)

    def apply(self, *args) -> None:
        if not args:
            raise ValueError("apply requires parameters")
        idx = 0
        qmgr_name = ""
        if isinstance(args[0], str):
            qmgr_name = args[0]
            idx = 1
        if idx + 2 >= len(args):
            raise ValueError("apply requires request_code, data, success_code")
        long_request_code = args[idx]
        data = args[idx + 1]
        success_code = args[idx + 2]
        if not isinstance(long_request_code, int) or not isinstance(success_code, int):
            raise ValueError("request_code and success_code must be int")
        if not isinstance(data, (bytes, bytearray)):
            raise ValueError("data must be bytes")

        msg = (
            ILMsgUtil.create_long_request_msg(long_request_code, bytes(data))
            if qmgr_name == ""
            else ILMsgUtil.create_long_request_msg_with_qmgr(
                qmgr_name, long_request_code, bytes(data)
            )
        )
        self.conn.send(msg)
        res_msg = self.conn.recv(self.sessionTimeoutMS)
        if ILC.MIMQ_REPORT_MESSAGE != res_msg.getType():
            raise ILMsgTypeException(
                res_msg.getType(), " msg type must be [MIMQ_REPORT_MESSAGE]"
            )
        report_msg = res_msg.getReportMsg()
        if report_msg.getCode() != success_code:
            raise ILOperationException(report_msg.getArg2())

    def send(self, qmgr_name: str, msg: ILDataMsg) -> None:
        self.conn.send(ILMsgUtil.create_proxy_data_msg(qmgr_name, msg))

    def _inquire(self, request_msg: ILMsg, check_msg_type: bool) -> ILMsg:
        self.conn.send(request_msg)
        res_msg = self.conn.recv(self.sessionTimeoutMS)
        if not check_msg_type:
            return res_msg
        if res_msg.getType() in (ILC.MIMQ_LONG_REPORT_MESSAGE, ILC.MIMQ_DATA_MESSAGE):
            return res_msg
        if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
            raise ILOperationException(res_msg.getReportMsg().getArg2())
        raise ILMsgTypeException(
            res_msg.getType(),
            " msg type must be [MIMQ_LONG_REPORT_MESSAGE] or [MIMQ_DATA_MESSAGE]",
        )
