from __future__ import annotations

import inspect
import time
import uuid

from .common import ILC, ILRC, MatchOption
from .connectivity import ILRequestHelper
from .exception import (
    ILException,
    ILMsgTypeException,
    ILNoMsgException,
    ILOperationException,
    ILSessionException,
    ILTimeoutException,
)
from .msg import ILDataMsg, ILMsg, ILMsgUtil, ILReportMsg, JMSHeader
from .properties import (
    ILAccessRuleProperty,
    ILChannelMinorProperty,
    ILChannelProperty,
    ILChannelStatus,
    ILChannelType,
    ILChannelDirection,
    ILQmgrMinorProperty,
    ILQmgrProperty,
    ILQueueFlow,
    ILQueueMinorProperty,
    ILQueueProperty,
    ILQueueRealTimeInfo,
    ILSecureFileProperty,
    ILServiceProperty,
    ILSessionMinorProperty,
    ILSessionProperty,
    ILSpokeProperty,
    ILPropertyUtil,
    ILLocalQueueMinorProperty,
    ILRemoteQueueMinorProperty,
    ILXmitQueueMinorProperty,
    ILClientSendChannelMinorProperty,
    ILClientRecvChannelMinorProperty,
    ILServerSendChannelMinorProperty,
    ILServerRecvChannelMinorProperty,
)
from .util import ba_merge

_ADMIN_QMGR_TOKEN = object()

# Exception types that should propagate without re-wrapping
_PASSTHROUGH_EXCEPTIONS = (
    ILException, ILOperationException, ILSessionException,
    ILMsgTypeException, ILNoMsgException, ILTimeoutException,
)


class ILAdminService:
    """Administrative service client for ilink server management.

    .. note:: Thread Safety

        Instances of this class are **not** thread-safe.  Each thread must use
        its own ``ILAdminService`` instance.

    Supports the context-manager protocol::

        with ILAdminService() as svc:
            svc.connect(host, port)
            qmgrs = svc.get_qmgr_list()
    """

    def __init__(self) -> None:
        self.host = ""
        self.port = 0
        self.sessionId = ""
        self.version = ""
        self.revision = 0
        self.service = ILRequestHelper()

    # --- context manager ---------------------------------------------------
    def __enter__(self) -> "ILAdminService":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()
        return None

    @staticmethod
    def main(args: list[str]) -> None:
        if len(args) != 1:
            print("available argrments.")
            print("    --version : displays the library version.")
        ILC.print_version(args[0] if args else "")

    def getHost(self) -> str:
        return self.host

    def getPort(self) -> int:
        return self.port

    def connect(self, host: str, port: int, clientName: str = "") -> None:
        """Establish a connection to the ilink admin service.

        Args:
            host: Hostname or IP address of the ilink server.
            port: Admin (ilsvc) port number.
            clientName: Optional client identifier. If omitted, the calling
                module name is used automatically.

        Raises:
            ILOperationException: If already connected or the connection is
                refused by the server.
            ILSessionException: If the port is not the admin (ilsvc) port.

        Example::

            svc = ILAdminService()
            svc.connect("192.168.1.10", 20119, "my_admin_tool")
        """
        self.host = host
        self.port = port
        try:
            if self.service.isOnline():
                raise ILOperationException("MIMQE_ALREADY_CONNECTED")

            self.service.connect(host, port)
            if not clientName:
                try:
                    frame = inspect.stack()[-1]
                    module_name = frame.frame.f_globals.get("__name__", "")
                    clientName = module_name.rsplit(".", 1)[-1] or ""
                except Exception:
                    clientName = ""
            conn_res_msg = self.service.request(
                ILC.MIMQ_NEW_CONNECTION, "0", clientName, "USR"
            )
            if conn_res_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if conn_res_msg.getCode() != ILC.MIMQ_SUCCESSFUL_CONNECTION:
                self.service.shutdown()
                raise ILOperationException(conn_res_msg.getArg2())

            if conn_res_msg.getArg3() != ILC.MIMQ_CLIENT_NAME_ILSVC:
                self.disconnect()
                raise ILSessionException(
                    ILRC.MIMQE_INVALID_ADDRESS,
                    "invalid protocol (this is not the 'ilsvc' port number!)",
                )

            self.sessionId = conn_res_msg.getArg1()
            self.version = conn_res_msg.getArg2()
            if self.version:
                try:
                    self.version = self.version.replace(" jetstream", "")
                    self.revision = int(self.version[-4:])
                except Exception:
                    pass
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def disconnect(self) -> None:
        """Disconnect from the ilink admin service.

        Sends a graceful disconnection request and shuts down the underlying
        transport.  Safe to call even when not connected.

        Example::

            svc.disconnect()
        """
        if not self.service.isOnline():
            return
        try:
            self.service.request(
                ILC.MIMQ_DISCONNECTION, ILC.MIMQ_SUCCESSFUL_DISCONNECTION
            )
        except Exception:
            pass
        finally:
            self.service.shutdown()

    def healthCheck(self) -> bool:
        """Check whether the connection to the admin service is alive.

        Sends a ping to the server.  If the ping fails, the connection is
        shut down automatically.

        Returns:
            ``True`` if the server responded to the ping, ``False`` otherwise.

        Example::

            if not svc.healthCheck():
                svc.connect("localhost", 20119)
        """
        try:
            if self.service.isOnline():
                self.service.request(ILC.MIMQ_PING, ILC.MIMQ_SUCCESSFUL_PING)
                return True
        except Exception:
            self.service.shutdown()
        return False

    def isConnected(self) -> bool:
        """Return ``True`` if the admin service connection is currently open."""
        return self.service.isOnline()

    def setSessionTimeout(self, timeoutMS: int) -> None:
        """Set the socket-level session timeout in milliseconds.

        Args:
            timeoutMS: Timeout value in milliseconds.  Negative values are
                ignored.

        Example::

            svc.setSessionTimeout(30000)  # 30 seconds
        """
        if timeoutMS < 0:
            return
        self.service.setSessionTimeout(timeoutMS)

    def getSessionTimeout(self) -> int:
        """Return the current session timeout in milliseconds."""
        return self.service.getSessionTimeout()

    def getSessionId(self) -> str:
        """Return the session identifier assigned by the server on connect."""
        return self.sessionId

    def getVersion(self) -> str:
        """Return the server version string reported at connection time."""
        return self.version

    def getProperty(self) -> ILServiceProperty:
        """Retrieve the server-level service properties.

        Returns:
            An :class:`ILServiceProperty` containing global server settings.

        Raises:
            ILException: On communication or server-side errors.

        Example::

            prop = svc.getProperty()
            print(prop.getTraceEnabled())
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_SERVER_PROPERTY)
            return ILServiceProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setProperty(self, vo: ILServiceProperty) -> None:
        """Update the server-level service properties.

        Args:
            vo: An :class:`ILServiceProperty` with the desired settings.

        Raises:
            ILException: On communication or server-side errors.

        Example::

            prop = svc.getProperty()
            prop.setTraceEnabled(True)
            svc.setProperty(prop)
        """
        try:
            self.service.apply(
                ILC.MIMQ_SET_SERVER_PROPERTY,
                vo.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_SET_SERVER_PROPERTY,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setSystemTrace(self, enabled: bool) -> None:
        """Enable or disable the server-level system trace.

        Args:
            enabled: ``True`` to enable tracing, ``False`` to disable.

        Example::

            svc.setSystemTrace(True)
        """
        try:
            vo = self.getProperty()
            vo.setTraceEnabled(enabled)
            self.setProperty(vo)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc
    def getQmgrList(self) -> list[ILQmgrProperty]:
        """Retrieve the list of all queue managers defined on the server.

        Returns:
            A list of :class:`ILQmgrProperty` objects, one per queue manager.

        Raises:
            ILOperationException: If the server reports an error.

        Example::

            for qm in svc.getQmgrList():
                print(qm.name, qm.get_status_string())
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_MANAGER_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILQmgrProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQmgrMinorList(self) -> list[ILQmgrMinorProperty]:
        """Retrieve a lightweight list of queue managers (fewer fields than full properties).

        Returns:
            A list of :class:`ILQmgrMinorProperty` objects.

        Example::

            for qm in svc.getQmgrMinorList():
                print(qm.name, qm.status)
        """
        try:
            if self.revision < 2762:
                props = self.getQmgrList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(ILC.MIMQ_GET_MANAGER_MINOR_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILQmgrMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQmgrProperty(self, qmgrName: str) -> ILQmgrProperty:
        """Retrieve the full properties of a specific queue manager.

        Args:
            qmgrName: Name of the queue manager.

        Returns:
            An :class:`ILQmgrProperty` for the specified queue manager.

        Raises:
            ILOperationException: If the queue manager is not found.

        Example::

            prop = svc.getQmgrProperty("QMGR1")
            print(prop.get_status_string(), prop.port)
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_MANAGER_PROPERTY, qmgrName)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILQmgrProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setQmgrProperty(self, vo: ILQmgrProperty) -> None:
        """Update the properties of a queue manager.

        Args:
            vo: An :class:`ILQmgrProperty` with the desired settings.

        Raises:
            ILException: On communication or server-side errors.

        Example::

            prop = svc.getQmgrProperty("QMGR1")
            prop.setDescription("Production queue manager")
            svc.setQmgrProperty(prop)
        """
        try:
            self.service.apply(
                ILC.MIMQ_SET_MANAGER_PROPERTY,
                vo.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_SET_MANAGER_PROPERTY,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setHomePath(self, qmgrName: str, homePath: str) -> None:
        """Set the home (data storage) path for a queue manager.

        Args:
            qmgrName: Name of the queue manager.
            homePath: Absolute filesystem path to use as the queue manager's
                home directory.

        Raises:
            ILException: On communication or server-side errors.

        Example::

            svc.setHomePath("QMGR1", "/data/jetstream/qmgr1")
        """
        try:
            ba = bytearray(ILC.MIMQ_LONG_REQUEST_ARG_LENGTH + len(homePath))
            ba_merge(qmgrName, ba, 0)
            ba_merge(homePath, ba, ILC.MIMQ_LONG_REQUEST_ARG_LENGTH)
            self.service.apply(
                ILC.MIMQ_SET_MANAGER_HOMEPATH,
                bytes(ba),
                ILC.MIMQ_SUCCESSFUL_SET_MANAGER_HOMEPATH,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def createQmgr(
        self,
        qmgrName_or_vo: ILQmgrProperty | str,
        port: int | None = None,
        isAutoStart: bool | None = None,
        homePath: str | None = None,
    ) -> None:
        """Create a new queue manager on the server.

        Can be called with a pre-built :class:`ILQmgrProperty` or with
        individual parameters that will be assembled into one.

        Args:
            qmgrName_or_vo: Either an :class:`ILQmgrProperty` instance or
                the queue manager name as a string.
            port: Listener port for the new queue manager (used when
                *qmgrName_or_vo* is a string).
            isAutoStart: Whether the queue manager starts automatically when
                the server starts.
            homePath: Filesystem path for the queue manager's data directory.

        Raises:
            ILOperationException: If a queue manager with the same name
                already exists.

        Example::

            svc.createQmgr("QMGR_NEW", port=20200, isAutoStart=True)
        """
        try:
            if isinstance(qmgrName_or_vo, ILQmgrProperty):
                vo = qmgrName_or_vo
            else:
                qmgr_name = qmgrName_or_vo
                if homePath is not None and isAutoStart is None:
                    vo = ILQmgrProperty(qmgr_name, port or 0, home_path=homePath)
                elif homePath is not None:
                    vo = ILQmgrProperty(qmgr_name, port or 0, isAutoStart, homePath)
                elif isAutoStart is not None:
                    vo = ILQmgrProperty(qmgr_name, port or 0, isAutoStart)
                else:
                    vo = ILQmgrProperty(qmgr_name, port or 0)
            self.service.apply(
                ILC.MIMQ_CREATE_MANAGER,
                vo.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_CREATE_MANAGER,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeQmgr(self, qmgrName: str) -> None:
        """Remove (delete) a queue manager from the server.

        The queue manager must be stopped before it can be removed.

        Args:
            qmgrName: Name of the queue manager to remove.

        Raises:
            ILOperationException: If the queue manager does not exist or
                cannot be removed.

        Example::

            svc.stopQmgr("QMGR_OLD")
            svc.removeQmgr("QMGR_OLD")
        """
        try:
            self.service.request(
                ILC.MIMQ_REMOVE_MANAGER,
                ILC.MIMQ_SUCCESSFUL_REMOVE_MANAGER,
                qmgrName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def startQmgr(self, qmgrName: str) -> None:
        """Start a stopped queue manager.

        Args:
            qmgrName: Name of the queue manager to start.

        Raises:
            ILOperationException: If the queue manager cannot be started.

        Example::

            svc.startQmgr("QMGR1")
        """
        try:
            self.service.request(
                ILC.MIMQ_START_MANAGER,
                ILC.MIMQ_SUCCESSFUL_START_MANAGER,
                qmgrName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def startQmgrWithStatus(self, qmgrName: str, timeout: int) -> str:
        """Start a queue manager and wait until it reaches a terminal status.

        Polls the queue manager status every second until it reports
        *RUNNING*, *ERROR*, or the timeout is reached.

        Args:
            qmgrName: Name of the queue manager to start.
            timeout: Maximum number of seconds to wait.

        Returns:
            The final status string (e.g. ``"Running"`` or ``"Error"``).

        Example::

            status = svc.startQmgrWithStatus("QMGR1", timeout=30)
            print("Final status:", status)
        """
        try:
            self.startQmgr(qmgrName)
            status_str = ""
            for _ in range(timeout):
                status_str = self.getQmgrProperty(qmgrName).get_status_string()
                if status_str in (ILC.MIMQ_RUNNING_STR, ILC.MIMQ_ERROR_STR):
                    break
                time.sleep(1)
            return status_str
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def stopQmgr(self, qmgrName: str) -> None:
        """Stop a running queue manager.

        Args:
            qmgrName: Name of the queue manager to stop.

        Raises:
            ILOperationException: If the queue manager cannot be stopped.

        Example::

            svc.stopQmgr("QMGR1")
        """
        try:
            self.service.request(
                ILC.MIMQ_STOP_MANAGER, ILC.MIMQ_SUCCESSFUL_STOP_MANAGER, qmgrName
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def stopQmgrWithStatus(self, qmgrName: str, timeout: int) -> str:
        """Stop a queue manager and wait until it reaches a terminal status.

        Polls with adaptive back-off until the status is *Stopped* or
        *Error*, or the timeout expires.

        Args:
            qmgrName: Name of the queue manager to stop.
            timeout: Maximum number of seconds to wait.

        Returns:
            The final status string (e.g. ``"Stopped"`` or ``"Error"``).

        Example::

            status = svc.stopQmgrWithStatus("QMGR1", timeout=30)
        """
        try:
            self.stopQmgr(qmgrName)
            status_str = ""
            remain = timeout * 1000
            sleep_ms = 900
            while remain > 0:
                time.sleep(sleep_ms / 1000.0)
                status_str = self.getQmgrProperty(qmgrName).get_status_string()
                if status_str in (ILC.MIMQ_STOPPED_STR, ILC.MIMQ_ERROR_STR):
                    break
                remain -= sleep_ms
                sleep_ms = sleep_ms // 3 if sleep_ms > 100 else sleep_ms
            return status_str
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def waitForQmgrStatus(self, qmgrName: str, status: int, timeout: int) -> bool:
        """Block until a queue manager reaches the desired status or timeout.

        Args:
            qmgrName: Name of the queue manager.
            status: Target status code to wait for.
            timeout: Maximum number of seconds to wait.

        Returns:
            ``True`` if the target status was reached, ``False`` on timeout.

        Example::

            reached = svc.waitForQmgrStatus("QMGR1", ILC.MIMQ_RUNNING, 60)
        """
        for _ in range(timeout):
            prop = self.getQmgrProperty(qmgrName)
            if prop.status == status:
                return True
            try:
                time.sleep(1)
            except Exception:
                pass
        return False

    def isQmgrExist(self, qmgrName: str) -> bool:
        """Check whether a queue manager with the given name exists.

        Args:
            qmgrName: Name of the queue manager.

        Returns:
            ``True`` if found, ``False`` otherwise.

        Example::

            if svc.isQmgrExist("QMGR1"):
                print("Queue manager exists")
        """
        try:
            self.getQmgrProperty(qmgrName)
            return True
        except ILException as exc:
            if exc.get_reason_code() == ILRC.MIMQE_OBJECT_NOT_FOUND:
                return False
            raise

    def setKeyFilePassword(self, keyFileName: str, password: str) -> None:
        """Set the password for a TLS/SSL key file on the server.

        Args:
            keyFileName: Name of the key file.
            password: Password to associate with the key file.

        Raises:
            ILException: On communication or server-side errors.

        Example::

            svc.setKeyFilePassword("server.kdb", "s3cret")
        """
        try:
            ba = bytearray(256)
            ba_merge(keyFileName, ba, 0)
            ba_merge(password, ba, 128)
            self.service.apply(
                ILC.MIMQ_SET_KEY_PASSWORD,
                bytes(ba),
                ILC.MIMQ_SUCCESSFUL_SET_KEY_PASSWORD,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc
    def getSessionList(self) -> list[ILSessionProperty]:
        """Retrieve the list of all active client sessions on the server.

        Returns:
            A list of :class:`ILSessionProperty` objects.

        Example::

            for sess in svc.getSessionList():
                print(sess.sessionId, sess.clientName)
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_SESSION_INFO_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILSessionProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getSessionMinorList(self) -> list[ILSessionMinorProperty]:
        """Retrieve a lightweight list of active client sessions.

        Returns:
            A list of :class:`ILSessionMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getSessionList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(ILC.MIMQ_GET_SESSION_INFO_MINOR_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILSessionMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getSessionProperty(self, sessionId: str) -> ILSessionProperty:
        """Retrieve the properties of a specific client session.

        Args:
            sessionId: The session identifier.

        Returns:
            An :class:`ILSessionProperty` for the session.

        Raises:
            ILOperationException: If the session is not found.
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_SESSION_INFO, sessionId)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILSessionProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeSession(self, sessionId: str) -> None:
        """Forcibly remove (disconnect) a client session.

        Args:
            sessionId: The session identifier to remove.

        Raises:
            ILOperationException: If the session cannot be removed.

        Example::

            svc.removeSession("abc-123-def")
        """
        try:
            self.service.request(
                ILC.MIMQ_REMOVE_SESSION,
                ILC.MIMQ_SUCCESSFUL_REMOVE_SESSION,
                sessionId,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setSessionTrace(self, sessionId: str, enabled: bool) -> None:
        """Enable or disable tracing for a specific client session.

        Args:
            sessionId: The session identifier.
            enabled: ``True`` to enable, ``False`` to disable.

        Example::

            svc.setSessionTrace("abc-123-def", True)
        """
        try:
            self.service.request(
                ILC.MIMQ_SET_SESSION_TRACE,
                ILC.MIMQ_SUCCESSFUL_SET_SESSION_TRACE,
                sessionId,
                "true" if enabled else "false",
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getAccessRuleList(self) -> list[ILAccessRuleProperty]:
        """Retrieve all access rules defined at the server level.

        Returns:
            A list of :class:`ILAccessRuleProperty` objects.

        Example::

            rules = svc.getAccessRuleList()
            for r in rules:
                print(r.ruleId, r.address)
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_ACCESSRULE_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILAccessRuleProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def addAccessRule(self, rule: ILAccessRuleProperty) -> None:
        """Add a new access rule at the server level.

        Args:
            rule: An :class:`ILAccessRuleProperty` defining the rule.

        Raises:
            ILException: On communication or server-side errors.
        """
        try:
            self.service.apply(
                ILC.MIMQ_CREATE_ACCESSRULE,
                ILPropertyUtil.get_serialized(rule),
                ILC.MIMQ_SUCCESSFUL_CREATE_ACCESSRULE,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeAccessRule(self, ruleId: str) -> None:
        """Remove an access rule by its identifier.

        Args:
            ruleId: The unique rule identifier.

        Raises:
            ILOperationException: If the rule is not found.
        """
        try:
            self.service.request(
                ILC.MIMQ_REMOVE_ACCESSRULE,
                ILC.MIMQ_SUCCESSFUL_REMOVE_ACCESSRULE,
                ruleId,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def accessAdminQmgr(self, qmgrName: str) -> "ILAdminQmgr":
        """Obtain an administrative handle for managing a specific queue manager.

        The returned :class:`ILAdminQmgr` shares the same underlying
        connection as this service instance.

        Args:
            qmgrName: Name of the queue manager.

        Returns:
            An :class:`ILAdminQmgr` bound to the specified queue manager.

        Example::

            qmgr = svc.accessAdminQmgr("QMGR1")
            print(qmgr.getQueueList())
        """
        return ILAdminQmgr(qmgrName, self.service, self.revision, _ADMIN_QMGR_TOKEN)

    def getSpokeList(self) -> list[ILSpokeProperty]:
        """Retrieve the list of spoke connections available on the server.

        Returns:
            A list of :class:`ILSpokeProperty` objects.
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_SPOKE_PROPERTY_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILSpokeProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def spokeSwitchTo(self, spokeKey: str, timeoutSec: int) -> None:
        """Switch the admin connection to a different spoke server.

        Args:
            spokeKey: The spoke identifier to switch to.
            timeoutSec: Timeout in seconds for the switch operation.

        Raises:
            ILException: On communication or server-side errors.
        """
        try:
            self.service.request(
                ILC.MIMQ_SET_SPOKE_CONNECTION,
                ILC.MIMQ_SUCCESSFUL_SET_SPOKE_CONNECTION,
                spokeKey,
                str(timeoutSec),
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getSecureFileList(self) -> list[ILSecureFileProperty]:
        """Retrieve the list of secure files stored on the server.

        Returns:
            A list of :class:`ILSecureFileProperty` objects.
        """
        try:
            res_msg = self.service.inquire(ILC.MIMQ_GET_SECURE_FILE_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILSecureFileProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def addSecureFile(self, fileName: str, password_or_content, fileContent=None) -> None:
        """Upload a secure file to the server.

        Can be called in two ways:

        * ``addSecureFile(name, content)`` -- no password.
        * ``addSecureFile(name, password, content)`` -- with password.

        Args:
            fileName: Name to store the file under on the server.
            password_or_content: Either the file content (bytes) when called
                with two args, or the password (str) when called with three.
            fileContent: The file content (bytes), required when a password
                is provided.

        Example::

            with open("cert.pem", "rb") as f:
                svc.addSecureFile("cert.pem", f.read())
        """
        try:
            if fileContent is None:
                password = ""
                content = password_or_content
            else:
                password = password_or_content
                content = fileContent
            ba = bytearray(len(content) + ILC.ILINKBYTE256)
            offset = 0
            ba_merge(fileName, ba, offset)
            offset += 128
            ba_merge(password, ba, offset)
            offset += 128
            ba[offset : offset + len(content)] = content
            self.service.apply(
                ILC.MIMQ_ADD_SECURE_FILE,
                bytes(ba),
                ILC.MIMQ_SUCCESSFUL_ADD_SECURE_FILE,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeSecureFile(self, fileName: str) -> None:
        """Remove a secure file from the server.

        Args:
            fileName: Name of the secure file to remove.
        """
        try:
            self.service.request(
                ILC.MIMQ_REMOVE_SECURE_FILE,
                ILC.MIMQ_SUCCESSFUL_REMOVE_SECURE_FILE,
                fileName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setSecureFilePassword(self, fileName: str, password: str) -> None:
        """Set or change the password of a secure file.

        Args:
            fileName: Name of the secure file.
            password: New password to set.
        """
        try:
            self.service.request(
                ILC.MIMQ_SET_SECURE_FILE_PWD,
                ILC.MIMQ_SUCCESSFUL_SET_SECURE_FILE_PWD,
                fileName,
                password,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def compareSecureFilePassword(self, fileName: str, password: str) -> bool:
        """Verify a password against the one stored for a secure file.

        Args:
            fileName: Name of the secure file.
            password: Password to verify.

        Returns:
            ``True`` if the password matches, ``False`` otherwise.

        Example::

            if svc.compareSecureFilePassword("cert.pem", "s3cret"):
                print("Password is correct")
        """
        try:
            report_msg = self.service.request(
                ILC.MIMQ_COMPARE_SECURE_FILE_PWD, fileName, password
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_COMPARE_SECURE_FILE_PWD:
                raise ILOperationException(report_msg.getArg2())
            return report_msg.getArg1().lower() == "t"
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def _createLogBrowser(self, objectName: str) -> "ILLogBrowser":
        try:
            report_msg = self.service.request(
                ILC.MIMQ_CREATE_LOG_BROWSER_REQUEST, "", objectName
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_LOG_BROWSER_CREATION:
                raise ILOperationException(report_msg.getArg2())
            try:
                browser_id = int(report_msg.getArg1())
                return ILLogBrowser(browser_id, self.service)
            except Exception as exc:
                raise ILOperationException("MIMQE_INVALID_NUMBER_FORMAT", exc)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def createSystemLogBrowser(self) -> "ILLogBrowser":
        """Create a browser for the server system log.

        Returns:
            An :class:`ILLogBrowser` for iterating over system log entries.

        Example::

            browser = svc.createSystemLogBrowser()
            while browser.hasNext():
                print(browser.next().getData())
            browser.close()
        """
        return self._createLogBrowser("")

    def createErrorLogBrowser(self) -> "ILLogBrowser":
        """Create a browser for the server error log.

        Returns:
            An :class:`ILLogBrowser` for iterating over error log entries.
        """
        return self._createLogBrowser("error")

    def createSessionLogBrowser(self, clientName: str) -> "ILLogBrowser":
        """Create a browser for a specific client session's log.

        Args:
            clientName: The client name whose session log to browse.

        Returns:
            An :class:`ILLogBrowser` for iterating over that session's log.
        """
        return self._createLogBrowser(clientName)


class ILAdminQmgr:
    """Administrative handle for managing a specific queue manager's resources.

    Provides operations for queues, channels, sessions, access rules,
    message put/get, transactions, and log browsing within a single queue
    manager.  Instances are obtained via
    :meth:`ILAdminService.accessAdminQmgr` and must not be constructed
    directly.

    .. note:: Thread Safety

        Instances of this class are **not** thread-safe.  Each thread must
        use its own ``ILAdminQmgr`` obtained from its own
        ``ILAdminService``.

    Example::

        with ILAdminService() as svc:
            svc.connect("localhost", 20119)
            qmgr = svc.accessAdminQmgr("QMGR1")
            queues = qmgr.getQueueList()
            for q in queues:
                print(q.name)
    """

    def __init__(
        self,
        qmgrName: str,
        service: ILRequestHelper,
        revision: int,
        token=None,
    ) -> None:
        if token is not _ADMIN_QMGR_TOKEN:
            raise ILOperationException("MIMQE_NOT_SUPPORTED")
        self.qmgrName = qmgrName
        self.service = service
        self.waitMsgTimeoutMS = 60000
        self.isInfiniteWaiting = False
        self.revision = revision

    @staticmethod
    def main(args: list[str]) -> None:
        if len(args) != 1:
            print("available argrments.")
            print("    --version : displays the library version.")
        ILC.print_version(args[0] if args else "")

    def getProperty(self) -> ILQmgrProperty:
        """Retrieve the full properties of this queue manager.

        Returns:
            An :class:`ILQmgrProperty` for this queue manager.

        Example::

            prop = qmgr.getProperty()
            print(prop.name, prop.get_status_string())
        """
        try:
            res_msg = self.service.inquire(self.qmgrName, ILC.MIMQ_GET_MANAGER_PROPERTY)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILQmgrProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setProperty(self, vo: ILQmgrProperty) -> None:
        """Update the properties of this queue manager.

        Args:
            vo: An :class:`ILQmgrProperty` with the desired settings.

        Example::

            prop = qmgr.getProperty()
            prop.setDescription("Updated description")
            qmgr.setProperty(prop)
        """
        try:
            self.service.apply(
                self.qmgrName,
                ILC.MIMQ_SET_MANAGER_PROPERTY,
                vo.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_SET_MANAGER_PROPERTY,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setHomePath(self, homePath: str) -> None:
        """Set the home (data storage) path for this queue manager.

        Args:
            homePath: Absolute filesystem path to use.
        """
        try:
            ba = bytearray(ILC.MIMQ_LONG_REQUEST_ARG_LENGTH + len(homePath))
            ba_merge(self.qmgrName, ba, 0)
            ba_merge(homePath, ba, ILC.MIMQ_LONG_REQUEST_ARG_LENGTH)
            self.service.apply(
                ILC.MIMQ_SET_MANAGER_HOMEPATH,
                bytes(ba),
                ILC.MIMQ_SUCCESSFUL_SET_MANAGER_HOMEPATH,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setSystemTrace(self, enabled: bool) -> None:
        """Enable or disable the system trace for this queue manager.

        Args:
            enabled: ``True`` to enable, ``False`` to disable.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_SET_SYSTEM_TRACE,
                ILC.MIMQ_NOT_SUCCESSFUL_SET_SYSTEM_TRACE,
                "true" if enabled else "false",
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc
    def getSessionList(self) -> list[ILSessionProperty]:
        """Retrieve all active sessions connected to this queue manager.

        Returns:
            A list of :class:`ILSessionProperty` objects.
        """
        try:
            res_msg = self.service.inquire(self.qmgrName, ILC.MIMQ_GET_SESSION_INFO_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILSessionProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getSessionMinorList(self) -> list[ILSessionMinorProperty]:
        """Retrieve a lightweight list of sessions on this queue manager.

        Returns:
            A list of :class:`ILSessionMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getSessionList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_SESSION_INFO_MINOR_LIST
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILSessionMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getSessionProperty(self, sessionId: str) -> ILSessionProperty:
        """Retrieve the properties of a session on this queue manager.

        Args:
            sessionId: The session identifier.

        Returns:
            An :class:`ILSessionProperty` for the session.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_SESSION_INFO, sessionId
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILSessionProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeSession(self, sessionId: str) -> None:
        """Forcibly remove a session from this queue manager.

        Args:
            sessionId: The session identifier to remove.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_REMOVE_SESSION,
                ILC.MIMQ_SUCCESSFUL_REMOVE_SESSION,
                sessionId,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setSessionTrace(self, sessionId: str, enabled: bool) -> None:
        """Enable or disable tracing for a session on this queue manager.

        Args:
            sessionId: The session identifier.
            enabled: ``True`` to enable, ``False`` to disable.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_SET_SESSION_TRACE,
                ILC.MIMQ_NOT_SUCCESSFUL_SET_SESSION_TRACE,
                sessionId,
                "true" if enabled else "false",
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getAccessRuleList(self) -> list[ILAccessRuleProperty]:
        """Retrieve all access rules for this queue manager.

        Returns:
            A list of :class:`ILAccessRuleProperty` objects.
        """
        try:
            res_msg = self.service.inquire(self.qmgrName, ILC.MIMQ_GET_ACCESSRULE_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILAccessRuleProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def addAccessRule(self, rule: ILAccessRuleProperty) -> None:
        """Add a new access rule to this queue manager.

        Args:
            rule: An :class:`ILAccessRuleProperty` defining the rule.
        """
        try:
            self.service.apply(
                self.qmgrName,
                ILC.MIMQ_CREATE_ACCESSRULE,
                ILPropertyUtil.get_serialized(rule),
                ILC.MIMQ_SUCCESSFUL_CREATE_ACCESSRULE,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeAccessRule(self, ruleId: str) -> None:
        """Remove an access rule from this queue manager.

        Args:
            ruleId: The unique rule identifier.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_REMOVE_ACCESSRULE,
                ILC.MIMQ_SUCCESSFUL_REMOVE_ACCESSRULE,
                ruleId,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQueueList(self) -> list[ILQueueProperty]:
        """Retrieve all queues defined on this queue manager.

        Returns:
            A list of :class:`ILQueueProperty` objects.

        Example::

            for q in qmgr.getQueueList():
                print(q.name, q.type)
        """
        try:
            res_msg = self.service.inquire(self.qmgrName, ILC.MIMQ_GET_QUEUE_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILQueueProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQueueMinorList(self) -> list[ILQueueMinorProperty]:
        """Retrieve a lightweight list of all queues on this queue manager.

        Returns:
            A list of :class:`ILQueueMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getQueueList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(self.qmgrName, ILC.MIMQ_GET_QUEUE_MINOR_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILQueueMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getLocalQueueList(self) -> list[ILQueueProperty]:
        """Retrieve only the local persistent queues on this queue manager.

        Returns:
            A list of :class:`ILQueueProperty` for local queues.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_QUEUE_LIST, str(ILC.MIMQ_LOCAL_PERSISTENT)
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILQueueProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getLocalQueueMinorList(self) -> list[ILLocalQueueMinorProperty]:
        """Retrieve a lightweight list of local persistent queues.

        Returns:
            A list of :class:`ILLocalQueueMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getLocalQueueList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_GET_QUEUE_MINOR_LIST,
                str(ILC.MIMQ_LOCAL_PERSISTENT),
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILLocalQueueMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getRemoteQueueList(self) -> list[ILQueueProperty]:
        """Retrieve only the remote queues on this queue manager.

        Returns:
            A list of :class:`ILQueueProperty` for remote queues.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_QUEUE_LIST, str(ILC.MIMQ_REMOTE_QUEUE)
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILQueueProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getRemoteQueueMinorList(self) -> list[ILRemoteQueueMinorProperty]:
        """Retrieve a lightweight list of remote queues.

        Returns:
            A list of :class:`ILRemoteQueueMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getRemoteQueueList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_GET_QUEUE_MINOR_LIST,
                str(ILC.MIMQ_REMOTE_QUEUE),
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILRemoteQueueMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getXmitQueueList(self) -> list[ILQueueProperty]:
        """Retrieve only the transmission queues on this queue manager.

        Returns:
            A list of :class:`ILQueueProperty` for transmission queues.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_GET_QUEUE_LIST,
                str(ILC.MIMQ_CHANNEL_TRANSMISSION_QUEUE),
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILQueueProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getXmitQueueMinorList(self) -> list[ILXmitQueueMinorProperty]:
        """Retrieve a lightweight list of transmission queues.

        Returns:
            A list of :class:`ILXmitQueueMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getXmitQueueList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_GET_QUEUE_MINOR_LIST,
                str(ILC.MIMQ_CHANNEL_TRANSMISSION_QUEUE),
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILXmitQueueMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc
    def createQueue(self, prop: ILQueueProperty) -> None:
        """Create a new queue on this queue manager.

        Args:
            prop: An :class:`ILQueueProperty` defining the queue to create.

        Raises:
            ILOperationException: If a queue with the same name already exists.

        Example::

            prop = ILQueueProperty("APP.ORDERS")
            qmgr.createQueue(prop)
        """
        try:
            self.service.apply(
                self.qmgrName,
                ILC.MIMQ_CREATE_QUEUE_REQUEST,
                prop.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_QUEUE_CREATION,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeQueue(self, queueName: str) -> None:
        """Remove (delete) a queue from this queue manager.

        Args:
            queueName: Name of the queue to remove.

        Raises:
            ILOperationException: If the queue does not exist.

        Example::

            qmgr.removeQueue("APP.TEMP")
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_REMOVE_QUEUE,
                ILC.MIMQ_SUCCESSFUL_REMOVE_QUEUE,
                queueName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def flushQueue(self, queueName: str) -> None:
        """Remove all messages from a queue.

        Args:
            queueName: Name of the queue to flush.

        Example::

            qmgr.flushQueue("APP.DEAD_LETTER")
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_FLUSH_QUEUE,
                ILC.MIMQ_SUCCESSFUL_QUEUE_FLUSH,
                queueName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQueueProperty(self, queueName: str) -> ILQueueProperty:
        """Retrieve the full properties of a queue.

        Args:
            queueName: Name of the queue.

        Returns:
            An :class:`ILQueueProperty` for the queue.

        Raises:
            ILOperationException: If the queue is not found.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_QUEUE_PROPERTY, queueName
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILQueueProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getLocalQueueProperty(self, queueName: str) -> ILQueueProperty:
        """Retrieve the properties of a local persistent queue.

        Args:
            queueName: Name of the local queue.

        Returns:
            An :class:`ILQueueProperty` for the queue.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_GET_QUEUE_PROPERTY,
                queueName,
                str(ILC.MIMQ_LOCAL_PERSISTENT),
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILQueueProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getRemoteQueueProperty(self, queueName: str) -> ILQueueProperty:
        """Retrieve the properties of a remote queue.

        Args:
            queueName: Name of the remote queue.

        Returns:
            An :class:`ILQueueProperty` for the queue.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_GET_QUEUE_PROPERTY,
                queueName,
                str(ILC.MIMQ_REMOTE_QUEUE),
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILQueueProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getXmitQueueProperty(self, queueName: str) -> ILQueueProperty:
        """Retrieve the properties of a transmission queue.

        Args:
            queueName: Name of the transmission queue.

        Returns:
            An :class:`ILQueueProperty` for the queue.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_GET_QUEUE_PROPERTY,
                queueName,
                str(ILC.MIMQ_CHANNEL_TRANSMISSION_QUEUE),
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILQueueProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setQueueProperty(self, prop: ILQueueProperty) -> None:
        """Update the properties of a queue.

        Args:
            prop: An :class:`ILQueueProperty` with the desired settings.

        Example::

            prop = qmgr.getQueueProperty("APP.ORDERS")
            prop.setMaxDepth(50000)
            qmgr.setQueueProperty(prop)
        """
        try:
            self.service.apply(
                self.qmgrName,
                ILC.MIMQ_SET_QUEUE_PROPERTY,
                prop.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_SET_QUEUE_PROPERTY,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def isQueueExist(self, queueName: str) -> bool:
        """Check whether a queue with the given name exists.

        Args:
            queueName: Name of the queue.

        Returns:
            ``True`` if the queue exists, ``False`` otherwise.
        """
        try:
            self.getQueueProperty(queueName)
            return True
        except ILException as exc:
            if exc.get_reason_code() == ILRC.MIMQE_OBJECT_NOT_FOUND:
                return False
            raise

    def isQueueEmpty(self, queueName: str) -> bool:
        """Check whether a queue currently has no messages.

        Args:
            queueName: Name of the queue.

        Returns:
            ``True`` if the queue is empty, ``False`` otherwise.
        """
        try:
            report_msg = self.service.request(
                self.qmgrName, ILC.MIMQ_IS_QUEUE_EMPTY, queueName
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_IS_QUEUE_EMPTY:
                raise ILOperationException(report_msg.getArg2())
            return report_msg.getArg1() == "true"
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def isQueueFull(self, queueName: str) -> bool:
        """Check whether a queue has reached its maximum depth.

        Args:
            queueName: Name of the queue.

        Returns:
            ``True`` if the queue is full, ``False`` otherwise.
        """
        try:
            report_msg = self.service.request(
                self.qmgrName, ILC.MIMQ_IS_QUEUE_FULL, queueName
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_IS_QUEUE_FULL:
                raise ILOperationException(report_msg.getArg2())
            return report_msg.getArg1() == "true"
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQueueDepth(self, queueName: str) -> int:
        """Return the current number of messages in a queue.

        Args:
            queueName: Name of the queue.

        Returns:
            The message count (depth) of the queue.

        Example::

            depth = qmgr.getQueueDepth("APP.ORDERS")
            print(f"Pending messages: {depth}")
        """
        try:
            report_msg = self.service.request(
                self.qmgrName, ILC.MIMQ_GET_QUEUE_DEPTH, queueName
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_GET_QUEUE_DEPTH:
                raise ILOperationException(report_msg.getArg2())
            try:
                return int(report_msg.getArg1())
            except Exception as exc:
                raise ILOperationException(
                    f"MIMQE_INVALID_NUMBER_FORMAT ({report_msg.getArg1()})", exc
                )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setQueueTrace(self, queueName: str, enabled: bool) -> None:
        """Enable or disable tracing for a specific queue.

        Args:
            queueName: Name of the queue.
            enabled: ``True`` to enable, ``False`` to disable.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_SET_QUEUE_TRACE,
                ILC.MIMQ_NOT_SUCCESSFUL_SET_QUEUE_TRACE,
                queueName,
                "true" if enabled else "false",
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQueueFlowInfo(self, queueName: str) -> ILQueueFlow:
        """Retrieve the current message flow statistics for a queue.

        Args:
            queueName: Name of the queue.

        Returns:
            An :class:`ILQueueFlow` with put/get counts, sizes, and depth.
        """
        try:
            report_msg = self.service.request(
                self.qmgrName, ILC.MIMQ_GET_QUEUE_ACCESS_INFO, queueName
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_GET_QUEUE_ACCESS_INFO:
                raise ILOperationException(report_msg.getArg2())

            put_info = report_msg.getArg1().split("/")
            get_info = report_msg.getArg2().split("/")
            try:
                put_count = int(put_info[0])
                get_count = int(get_info[0])
                cur_depth = int(report_msg.getArg3())
                put_size = int(put_info[1]) if len(put_info) > 1 else 0
                get_size = int(get_info[1]) if len(get_info) > 1 else 0
                return ILQueueFlow(put_count, get_count, put_size, get_size, cur_depth)
            except Exception as exc:
                raise ILOperationException("MIMQE_INVALID_NUMBER_FORMAT", exc)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQueueFlowInfoArray(self, queueName: str) -> list[ILQueueFlow]:
        """Retrieve an array of historical message flow snapshots for a queue.

        Returns at least 10 entries (padded with zeroes if fewer exist).

        Args:
            queueName: Name of the queue.

        Returns:
            A list of :class:`ILQueueFlow` snapshots.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_QUEUE_ACCESS_INFO_ARRAY, queueName
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            result = ILMsgUtil.parse_data_msg(ILQueueFlow, res_msg)
            if len(result) < 10:
                return result + [ILQueueFlow(0, 0, 0, 0, 0) for _ in range(10 - len(result))]
            return result
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def createBrowser(self, queueName: str) -> "ILQueueBrowser":
        """Create a queue browser for peeking at messages without removing them.

        Args:
            queueName: Name of the queue to browse.

        Returns:
            An :class:`ILQueueBrowser` for iterating over the queue's messages.

        Example::

            browser = qmgr.createBrowser("APP.ORDERS")
            try:
                while browser.hasNext():
                    msg = browser.next()
                    print(msg.getHeader().getMsgId())
            finally:
                browser.close()
        """
        try:
            report_msg = self.service.request(
                self.qmgrName, ILC.MIMQ_CREATE_QUEUE_BROWSER_REQUEST, queueName
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_QUEUE_BROWSER_CREATION:
                raise ILOperationException(report_msg.getArg2())
            try:
                browser_id = int(report_msg.getArg1())
                return ILQueueBrowser(self.qmgrName, queueName, browser_id, self.service)
            except Exception as exc:
                raise ILOperationException("MIMQE_INVALID_NUMBER_FORMAT", exc)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getChannelList(self) -> list[ILChannelProperty]:
        """Retrieve all channels defined on this queue manager.

        Returns:
            A list of :class:`ILChannelProperty` objects.

        Example::

            for ch in qmgr.getChannelList():
                print(ch.name, ch.get_status_string())
        """
        try:
            res_msg = self.service.inquire(self.qmgrName, ILC.MIMQ_GET_CHANNEL_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILChannelProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getChannelMinorList(self) -> list[ILChannelMinorProperty]:
        """Retrieve a lightweight list of all channels, with type-specific subclasses.

        Returns:
            A list of channel minor property objects, each cast to the
            appropriate subclass based on type and direction.
        """
        try:
            if self.revision < 2762:
                props = self.getChannelList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(self.qmgrName, ILC.MIMQ_GET_CHANNEL_MINOR_LIST)
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            result = ILMsgUtil.parse_data_msg(ILChannelMinorProperty, res_msg)
            for idx, cp in enumerate(result):
                if cp.type == ILChannelType.CLIENT:
                    if cp.direction == ILChannelDirection.SEND:
                        result[idx] = ILClientSendChannelMinorProperty(cp.get_serialized())
                    else:
                        result[idx] = ILClientRecvChannelMinorProperty(cp.get_serialized())
                else:
                    if cp.direction == ILChannelDirection.SEND:
                        result[idx] = ILServerSendChannelMinorProperty(cp.get_serialized())
                    else:
                        result[idx] = ILServerRecvChannelMinorProperty(cp.get_serialized())
            return result
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getClientSendChannelList(self) -> list[ILChannelProperty]:
        """Retrieve all client-send channels on this queue manager.

        Returns:
            A list of :class:`ILChannelProperty` for CLIENT.SEND channels.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_LIST, "CLIENT.SEND"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILChannelProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getClientSendChannelMinorList(self) -> list[ILClientSendChannelMinorProperty]:
        """Retrieve a lightweight list of client-send channels.

        Returns:
            A list of :class:`ILClientSendChannelMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getClientSendChannelList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_MINOR_LIST, "CLIENT.SEND"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILClientSendChannelMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getClientRecvChannelList(self) -> list[ILChannelProperty]:
        """Retrieve all client-receive channels on this queue manager.

        Returns:
            A list of :class:`ILChannelProperty` for CLIENT.RECV channels.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_LIST, "CLIENT.RECV"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILChannelProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getClientRecvChannelMinorList(self) -> list[ILClientRecvChannelMinorProperty]:
        """Retrieve a lightweight list of client-receive channels.

        Returns:
            A list of :class:`ILClientRecvChannelMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getClientRecvChannelList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_MINOR_LIST, "CLIENT.RECV"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILClientRecvChannelMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getServerSendChannelList(self) -> list[ILChannelProperty]:
        """Retrieve all server-send channels on this queue manager.

        Returns:
            A list of :class:`ILChannelProperty` for SERVER.SEND channels.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_LIST, "SERVER.SEND"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILChannelProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getServerSendChannelMinorList(self) -> list[ILServerSendChannelMinorProperty]:
        """Retrieve a lightweight list of server-send channels.

        Returns:
            A list of :class:`ILServerSendChannelMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getServerSendChannelList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_MINOR_LIST, "SERVER.SEND"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILServerSendChannelMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getServerRecvChannelList(self) -> list[ILChannelProperty]:
        """Retrieve all server-receive channels on this queue manager.

        Returns:
            A list of :class:`ILChannelProperty` for SERVER.RECV channels.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_LIST, "SERVER.RECV"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILChannelProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getServerRecvChannelMinorList(self) -> list[ILServerRecvChannelMinorProperty]:
        """Retrieve a lightweight list of server-receive channels.

        Returns:
            A list of :class:`ILServerRecvChannelMinorProperty` objects.
        """
        try:
            if self.revision < 2762:
                props = self.getServerRecvChannelList()
                return [prop.get_minor_property() for prop in props]
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_MINOR_LIST, "SERVER.RECV"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILMsgUtil.parse_data_msg(ILServerRecvChannelMinorProperty, res_msg)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getChannelProperty(self, channelName: str) -> ILChannelProperty:
        """Retrieve the full properties of a channel.

        Args:
            channelName: Name of the channel.

        Returns:
            An :class:`ILChannelProperty` for the channel.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_PROPERTY, channelName
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILChannelProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getClientSendChannelProperty(self, channelName: str) -> ILChannelProperty:
        """Retrieve the properties of a client-send channel.

        Args:
            channelName: Name of the channel.

        Returns:
            An :class:`ILChannelProperty` for the channel.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_PROPERTY, channelName, "CLIENT.SEND"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILChannelProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getClientRecvChannelProperty(self, channelName: str) -> ILChannelProperty:
        """Retrieve the properties of a client-receive channel.

        Args:
            channelName: Name of the channel.

        Returns:
            An :class:`ILChannelProperty` for the channel.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_PROPERTY, channelName, "CLIENT.RECV"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILChannelProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getServerSendChannelProperty(self, channelName: str) -> ILChannelProperty:
        """Retrieve the properties of a server-send channel.

        Args:
            channelName: Name of the channel.

        Returns:
            An :class:`ILChannelProperty` for the channel.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_PROPERTY, channelName, "SERVER.SEND"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILChannelProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getServerRecvChannelProperty(self, channelName: str) -> ILChannelProperty:
        """Retrieve the properties of a server-receive channel.

        Args:
            channelName: Name of the channel.

        Returns:
            An :class:`ILChannelProperty` for the channel.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_CHANNEL_PROPERTY, channelName, "SERVER.RECV"
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILChannelProperty(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setChannelProperty(self, prop: ILChannelProperty) -> None:
        """Update the properties of a channel.

        Args:
            prop: An :class:`ILChannelProperty` with the desired settings.
        """
        try:
            self.service.apply(
                self.qmgrName,
                ILC.MIMQ_SET_CHANNEL_PROPERTY,
                prop.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_SET_CHANNEL_PROPERTY,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def createChannel(self, prop: ILChannelProperty) -> None:
        """Create a new channel on this queue manager.

        Args:
            prop: An :class:`ILChannelProperty` defining the channel.

        Raises:
            ILOperationException: If a channel with the same name exists.

        Example::

            prop = ILChannelProperty("TO.REMOTE", ILChannelType.SERVER,
                                     ILChannelDirection.SEND)
            qmgr.createChannel(prop)
        """
        try:
            self.service.apply(
                self.qmgrName,
                ILC.MIMQ_CREATE_CHANNEL,
                prop.get_serialized(),
                ILC.MIMQ_SUCCESSFUL_CREATE_CHANNEL,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeChannel(self, channelName: str) -> None:
        """Remove (delete) a channel from this queue manager.

        Args:
            channelName: Name of the channel to remove.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_REMOVE_CHANNEL,
                ILC.MIMQ_SUCCESSFUL_REMOVE_CHANNEL,
                channelName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def isChannelExist(self, channelName: str) -> bool:
        """Check whether a channel with the given name exists.

        Args:
            channelName: Name of the channel.

        Returns:
            ``True`` if the channel exists, ``False`` otherwise.
        """
        try:
            self.getChannelProperty(channelName)
            return True
        except ILException as exc:
            if exc.get_reason_code() == ILRC.MIMQE_OBJECT_NOT_FOUND:
                return False
            raise

    def startChannel(self, channelName: str) -> None:
        """Start a stopped channel.

        Args:
            channelName: Name of the channel to start.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_START_CHANNEL,
                ILC.MIMQ_SUCCESSFUL_START_CHANNEL,
                channelName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def startChannelWithStatus(self, channelName: str, timeout: int) -> str:
        """Start a channel and wait until it reaches a terminal status.

        Args:
            channelName: Name of the channel to start.
            timeout: Maximum number of seconds to wait.

        Returns:
            The final status string (e.g. ``"Running"`` or ``"Error"``).
        """
        try:
            self.startChannel(channelName)
            status_str = ""
            for _ in range(timeout):
                status_str = self.getChannelProperty(channelName).get_status_string()
                if status_str in (ILC.MIMQ_RUNNING_STR, ILC.MIMQ_ERROR_STR):
                    break
                time.sleep(1)
            return status_str
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def stopChannel(self, channelName: str) -> None:
        """Stop a running channel.

        Args:
            channelName: Name of the channel to stop.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_STOP_CHANNEL,
                ILC.MIMQ_SUCCESSFUL_STOP_CHANNEL,
                channelName,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def stopChannelWithStatus(self, channelName: str, timeout: int) -> str:
        """Stop a channel and wait until it reaches a terminal status.

        Args:
            channelName: Name of the channel to stop.
            timeout: Maximum number of seconds to wait.

        Returns:
            The final status string (e.g. ``"Stopped"`` or ``"Error"``).
        """
        try:
            self.stopChannel(channelName)
            status_str = ""
            for _ in range(timeout):
                status_str = self.getChannelProperty(channelName).get_status_string()
                if status_str in (ILC.MIMQ_STOPPED_STR, ILC.MIMQ_ERROR_STR):
                    break
                time.sleep(1)
            return status_str
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def waitForChannelStatus(
        self, channelName: str, status: ILChannelStatus, timeout: int
    ) -> bool:
        """Block until a channel reaches the desired status or timeout.

        Args:
            channelName: Name of the channel.
            status: Target :class:`ILChannelStatus` to wait for.
            timeout: Maximum number of seconds to wait.

        Returns:
            ``True`` if the target status was reached, ``False`` on timeout.
        """
        for _ in range(timeout):
            prop = self.getChannelProperty(channelName)
            if prop.status == status:
                return True
            try:
                time.sleep(1)
            except Exception:
                pass
        return False

    def setChannelTrace(self, channelName: str, enabled: bool) -> None:
        """Enable or disable tracing for a specific channel.

        Args:
            channelName: Name of the channel.
            enabled: ``True`` to enable, ``False`` to disable.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_SET_CHANNEL_TRACE,
                ILC.MIMQ_NOT_SUCCESSFUL_SET_CHANNEL_TRACE,
                channelName,
                "true" if enabled else "false",
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setChannelTimeout(self, channelName: str, timeout: int) -> None:
        """Set the connection timeout for a channel.

        Args:
            channelName: Name of the channel.
            timeout: Timeout value in seconds.
        """
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_SET_CHANNEL_TIMEOUT,
                ILC.MIMQ_NOT_SUCCESSFUL_SET_CHANNEL_TIMEOUT,
                channelName,
                str(timeout),
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def commit(self) -> int:
        """Commit the current transaction.

        All messages put or got since the last commit/rollback are made
        permanent.

        Returns:
            The number of messages affected, or ``-1`` if unavailable.

        Raises:
            ILOperationException: If the commit fails.

        Example::

            qmgr.put("APP.ORDERS", b"order data")
            qmgr.commit()
        """
        try:
            report_msg = self.service.request(
                self.qmgrName, ILC.MIMQ_COMMIT_TRANSACTION_REQUEST
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_COMMIT:
                raise ILOperationException(report_msg.getArg2())
            if report_msg.getArg1() == "":
                return -1
            return int(report_msg.getArg1())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def rollback(self) -> int:
        """Roll back the current transaction.

        All messages put or got since the last commit/rollback are discarded.

        Returns:
            The number of messages affected, or ``-1`` if unavailable.
        """
        try:
            report_msg = self.service.request(self.qmgrName, ILC.MIMQ_ROLLBACK_REQUEST)
            if (
                report_msg is not None
                and report_msg.getCode() == ILC.MIMQ_SUCCESSFUL_ROLLBACK
                and report_msg.getArg1() != ""
            ):
                return int(report_msg.getArg1())
        except Exception:
            pass
        return -1

    def put(
        self,
        queueName: str,
        data_or_header: bytes | bytearray | JMSHeader | ILDataMsg,
        data: bytes | bytearray | None = None,
    ) -> str:
        """Put a message onto a queue.

        Accepts several calling conventions:

        * ``put(queue, raw_bytes)`` -- send raw bytes with a default header.
        * ``put(queue, jms_header, data_bytes)`` -- send with a custom header.
        * ``put(queue, data_msg)`` -- send a pre-built :class:`ILDataMsg`.

        A message ID is auto-generated if not already set.

        Args:
            queueName: Target queue name.
            data_or_header: Raw bytes, a :class:`JMSHeader`, or a complete
                :class:`ILDataMsg`.
            data: Message payload bytes (required when *data_or_header* is a
                :class:`JMSHeader`).

        Returns:
            The message ID of the sent message.

        Example::

            msg_id = qmgr.put("APP.ORDERS", b'{"item": "widget", "qty": 5}')
            qmgr.commit()
        """
        try:
            if isinstance(data_or_header, ILDataMsg):
                msg = data_or_header
            elif isinstance(data_or_header, JMSHeader):
                msg = ILDataMsg(data_or_header, bytes(data or b""))
            elif isinstance(data_or_header, (bytes, bytearray)):
                header = JMSHeader()
                msg = ILDataMsg(header, bytes(data_or_header))
            else:
                raise TypeError("unsupported message type")

            msg_id = msg.getHeader().getMsgId()
            if msg_id == "":
                msg_id = str(uuid.uuid4())
                msg.getHeader().setMsgId(msg_id)
            msg.getHeader().setDestination(queueName)
            msg.getHeader().setTimeStamp(int(time.time() * 1000))
            self.service.send(self.qmgrName, msg)
            return msg_id
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def setWaitMsgTimeoutMS(self, value: int) -> None:
        """Set the timeout for :meth:`get` operations in milliseconds.

        Use :const:`ILC.MIMQ_MSGGET_INFINITE` for indefinite blocking.

        Args:
            value: Timeout in milliseconds, or ``MIMQ_MSGGET_INFINITE``.

        Example::

            qmgr.setWaitMsgTimeoutMS(5000)  # 5 seconds
        """
        if value == ILC.MIMQ_MSGGET_INFINITE:
            self.isInfiniteWaiting = True
            self.waitMsgTimeoutMS = 60000
        else:
            self.isInfiniteWaiting = False
            self.waitMsgTimeoutMS = value

    def get(
        self, queueName: str, matchId: str | None = None, option: MatchOption = MatchOption.NONE
    ) -> ILDataMsg:
        """Get (consume) a message from a queue.

        Blocks up to the timeout configured by :meth:`setWaitMsgTimeoutMS`.
        Optionally filters by message ID or correlation ID.

        Args:
            queueName: Name of the queue to get from.
            matchId: Optional message ID or correlation ID to match.
            option: The :class:`MatchOption` controlling the match behaviour.

        Returns:
            An :class:`ILDataMsg` containing the message header and payload.

        Raises:
            ILNoMsgException: If no matching message is available within the
                timeout period.

        Example::

            try:
                msg = qmgr.get("APP.ORDERS")
                print(msg.getData())
                qmgr.commit()
            except ILNoMsgException:
                print("No messages available")
        """
        try:
            ext = None
            if matchId:
                ext = ILC.make_selector(matchId, option).encode("utf-8")
            req_msg = ILMsgUtil.create_request_msg_with_qmgr(
                self.qmgrName,
                ILC.MIMQ_GET_REQUEST,
                ext,
                "",
                queueName,
                str(self.waitMsgTimeoutMS),
            )
            while True:
                self.service.getConn().send(req_msg)
                timeout = self.service.getSessionTimeout()
                if (
                    not self.isInfiniteWaiting
                    and timeout > 0
                    and timeout <= self.waitMsgTimeoutMS
                ):
                    timeout = self.waitMsgTimeoutMS * 2

                msg = self.service.getConn().recv(timeout)
                if msg.getType() == ILC.MIMQ_DATA_MESSAGE:
                    return msg.getDataMsg()

                if msg.getType() != ILC.MIMQ_REPORT_MESSAGE:
                    raise ILMsgTypeException(
                        msg.getType(),
                        "msg type must be [MIMQ_DATA_MESSAGE] or [MIMQ_REPORT_MESSAGE]",
                    )

                if msg.getReportMsg().getCode() != ILC.MIMQ_NO_NEW_MESSAGE:
                    raise ILOperationException(msg.getReportMsg().getArg2())

                if not self.isInfiniteWaiting:
                    break

            raise ILNoMsgException(self.qmgrName, queueName)
        except ILNoMsgException:
            raise
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def removeMsg(self, queueName: str, arrMsgId: str | list[str]) -> None:
        """Remove one or more specific messages from a queue by message ID.

        Args:
            queueName: Name of the queue.
            arrMsgId: A single message ID string or a list of message IDs.

        Example::

            qmgr.removeMsg("APP.ORDERS", "msg-id-123")
            qmgr.removeMsg("APP.ORDERS", ["id-1", "id-2", "id-3"])
        """
        try:
            msg_ids = [arrMsgId] if isinstance(arrMsgId, str) else arrMsgId
            buflen = (
                len(msg_ids) * ILC.ILINKBYTE48
                + ILC.MIMQ_LONG_REQUEST_ARG_LENGTH
                + ILC.SZ_LEN
            )
            buffer = bytearray(buflen)
            offset = 0
            ba_merge(queueName, buffer, offset)
            offset += ILC.MIMQ_LONG_REQUEST_ARG_LENGTH
            ba_merge(len(msg_ids), buffer, offset)
            offset += ILC.SZ_LEN
            for msg_id in msg_ids:
                ba_merge(msg_id, buffer, offset)
                offset += ILC.ILINKBYTE48
            self.service.apply(
                self.qmgrName,
                ILC.MIMQ_REMOVE_MSG,
                bytes(buffer),
                ILC.MIMQ_SUCCESSFUL_REMOVE_MSG,
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def _createLogBrowser(self, objectName: str) -> "ILLogBrowser":
        try:
            report_msg = self.service.request(
                ILC.MIMQ_CREATE_LOG_BROWSER_REQUEST, self.qmgrName, objectName
            )
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_LOG_BROWSER_CREATION:
                raise ILOperationException(report_msg.getArg2())
            try:
                browser_id = int(report_msg.getArg1())
                return ILLogBrowser(browser_id, self.service)
            except Exception as exc:
                raise ILOperationException("MIMQE_INVALID_NUMBER_FORMAT", exc)
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def createSystemLogBrowser(self) -> "ILLogBrowser":
        """Create a browser for this queue manager's system log.

        Returns:
            An :class:`ILLogBrowser` for iterating over system log entries.
        """
        return self._createLogBrowser("")

    def createErrorLogBrowser(self) -> "ILLogBrowser":
        """Create a browser for this queue manager's error log.

        Returns:
            An :class:`ILLogBrowser` for iterating over error log entries.
        """
        return self._createLogBrowser("error")

    def createObjectLogBrowser(self, objectName: str) -> "ILLogBrowser":
        """Create a browser for a specific object's log within this queue manager.

        Args:
            objectName: Name of the object (queue, channel, etc.) whose log
                to browse.

        Returns:
            An :class:`ILLogBrowser` for iterating over that object's log.
        """
        return self._createLogBrowser(objectName)

    def getQueueRealTimeInfo(self, queueName: str) -> ILQueueRealTimeInfo:
        """Retrieve real-time (live) information about a queue.

        Args:
            queueName: Name of the queue.

        Returns:
            An :class:`ILQueueRealTimeInfo` with live queue metrics.
        """
        try:
            res_msg = self.service.inquire(
                self.qmgrName, ILC.MIMQ_GET_QUEUE_LIVE_PROPERTY, queueName
            )
            if res_msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(res_msg.getReportMsg().getArg2())
            return ILQueueRealTimeInfo(res_msg.getDataMsg().getData())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc


class ILLogBrowser:
    """Iterator-style browser for reading server, error, or session log entries.

    Created via :meth:`ILAdminService.createSystemLogBrowser`,
    :meth:`ILAdminService.createErrorLogBrowser`,
    :meth:`ILAdminService.createSessionLogBrowser`, or the corresponding
    methods on :class:`ILAdminQmgr`.  The browser should be closed when no
    longer needed.

    Example::

        browser = svc.createSystemLogBrowser()
        try:
            while browser.hasNext():
                entry = browser.next()
                print(entry.getData())
        finally:
            browser.close()
    """

    def __init__(self, browser_id: int, service: ILRequestHelper) -> None:
        self.browserId = str(browser_id)
        self.service = service

    def __del__(self) -> None:
        if self.browserId:
            self.close()

    def close(self) -> None:
        """Close this log browser and release server-side resources.

        Safe to call even when the connection is already closed.

        Example::

            browser.close()
        """
        if not self.service.isOnline():
            return
        try:
            self.service.request(
                ILC.MIMQ_BROWSER_DELETION,
                ILC.MIMQ_SUCCESSFUL_BROWSER_DELETION,
                self.browserId,
            )
        except Exception:
            pass

    def hasNext(self) -> bool:
        """Check whether there is another log entry available.

        Returns:
            ``True`` if at least one more log entry is available.

        Example::

            while browser.hasNext():
                entry = browser.next()
        """
        try:
            report_msg = self.service.request(
                ILC.MIMQ_BROWSER_HAS_MORE_ELEMENTS, self.browserId
            )
            return report_msg is not None and (
                report_msg.getCode() == ILC.MIMQ_BROWSER_HAS_MORE_ELEMENTS
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def next(self) -> ILDataMsg:
        """Advance the cursor and return the next log entry.

        Returns:
            An :class:`ILDataMsg` containing the log entry data.

        Raises:
            ILOperationException: If no more entries are available or a
                server error occurs.

        Example::

            entry = browser.next()
            print(entry.getData())
        """
        try:
            msg = self.service.inquire(ILC.MIMQ_BROWSER_NEXT_ELEMENT, self.browserId)
            if msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                raise ILOperationException(msg.getReportMsg().getArg2())
            return msg.getDataMsg()
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc


class ILQueueBrowser:
    """Iterator-style browser for peeking at messages in a queue without removing them.

    Created via :meth:`ILAdminQmgr.createBrowser`.  Supports optional
    message-ID matching and header-only retrieval.  The browser should be
    closed when no longer needed.

    Example::

        qmgr = svc.accessAdminQmgr("QMGR1")
        browser = qmgr.createBrowser("APP.QUEUE")
        try:
            while browser.hasNext():
                msg = browser.next()
                print(msg.getHeader().getMsgId())
        finally:
            browser.close()
    """

    def __init__(
        self,
        qmgrName: str,
        queueName: str,
        browser_id: int,
        service: ILRequestHelper,
    ) -> None:
        self.qmgrName = qmgrName
        self.queueName = queueName
        self.browserId = str(browser_id)
        self.service = service
        self.closed = False

    def __del__(self) -> None:
        if self.browserId:
            self.close()

    def close(self) -> None:
        """Close this queue browser and release server-side resources.

        Safe to call multiple times; subsequent calls are no-ops.

        Example::

            browser.close()
        """
        if not self.service.isOnline() or self.closed:
            return
        try:
            self.service.request(
                self.qmgrName,
                ILC.MIMQ_BROWSER_DELETION,
                ILC.MIMQ_SUCCESSFUL_BROWSER_DELETION,
                self.queueName,
                self.browserId,
            )
            self.closed = True
        except Exception:
            pass

    def hasNext(self, matchId: str = "", option: MatchOption = MatchOption.NONE) -> bool:
        """Check whether there is another message available in the browse cursor.

        Args:
            matchId: Optional message ID or correlation ID to match.
            option: The :class:`MatchOption` controlling the match behaviour.

        Returns:
            ``True`` if at least one more message is available.

        Example::

            while browser.hasNext():
                msg = browser.next()
        """
        try:
            report_msg = self.service.request(
                self.qmgrName,
                ILC.MIMQ_BROWSER_HAS_MORE_ELEMENTS,
                ILC.make_selector(matchId, option).encode("utf-8"),
                self.queueName,
                self.browserId,
            )
            return report_msg is not None and (
                report_msg.getCode() == ILC.MIMQ_BROWSER_HAS_MORE_ELEMENTS
            )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def next(
        self, matchId: str = "", option: MatchOption = MatchOption.NONE
    ) -> ILDataMsg:
        """Advance the cursor and return the next message (header + body).

        Args:
            matchId: Optional message ID or correlation ID to match.
            option: The :class:`MatchOption` controlling the match behaviour.

        Returns:
            An :class:`ILDataMsg` containing the message header and payload.

        Raises:
            ILNoMsgException: If no more messages are available.

        Example::

            msg = browser.next()
            print(msg.getHeader().getMsgId(), len(msg.getData()))
        """
        try:
            msg = self.service.inquire(
                self.qmgrName,
                ILC.MIMQ_BROWSER_NEXT_ELEMENT,
                ILC.make_selector(matchId, option).encode("utf-8"),
                self.queueName,
                self.browserId,
            )
            if msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                report_msg = msg.getReportMsg()
                if report_msg.getCode() == ILC.MIMQ_NO_NEW_MESSAGE:
                    raise ILNoMsgException(self.qmgrName, self.queueName)
                raise ILOperationException(report_msg.getArg2())
            return msg.getDataMsg()
        except ILNoMsgException:
            raise
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def nextHeaderOnly(
        self, matchId: str = "", option: MatchOption = MatchOption.NONE
    ) -> ILDataMsg:
        """Advance the cursor and return only the message header (no body).

        Useful for browsing message metadata without transferring payload
        data over the network.

        Args:
            matchId: Optional message ID or correlation ID to match.
            option: The :class:`MatchOption` controlling the match behaviour.

        Returns:
            An :class:`ILDataMsg` with the header populated but no payload.

        Raises:
            ILNoMsgException: If no more messages are available.

        Example::

            header_msg = browser.nextHeaderOnly()
            print(header_msg.getHeader().getMsgId())
        """
        try:
            msg = self.service.inquireDataOrReport(
                self.qmgrName,
                ILC.MIMQ_BROWSER_NEXT_ELEMENT_DATALESS,
                ILC.make_selector(matchId, option).encode("utf-8"),
                self.queueName,
                self.browserId,
            )
            if msg.getType() == ILC.MIMQ_REPORT_MESSAGE:
                report_msg = msg.getReportMsg()
                if report_msg.getCode() == ILC.MIMQ_NO_NEW_MESSAGE:
                    raise ILNoMsgException(self.qmgrName, self.queueName)
                raise ILOperationException(report_msg.getArg2())
            return msg.getDataMsg()
        except ILNoMsgException:
            raise
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def skip(self, count: int) -> int:
        """Skip forward by the specified number of messages in the browse cursor.

        Args:
            count: Number of messages to skip.

        Returns:
            A status code from the server.

        Raises:
            ILOperationException: If the skip operation fails (e.g. not
                enough messages).

        Example::

            browser.skip(10)  # skip the first 10 messages
            msg = browser.next()
        """
        try:
            report_msg = self.service.request(
                self.qmgrName,
                ILC.MIMQ_BROWSER_SKIP_ELEMENT,
                self.queueName,
                self.browserId,
                str(count),
            )
            if report_msg is not None and (
                report_msg.getCode() == ILC.MIMQ_NOT_SUCCESSFUL_BROWSE
            ):
                raise ILOperationException(report_msg.getArg2())
            return report_msg.getCode() if report_msg is not None else 0
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc
