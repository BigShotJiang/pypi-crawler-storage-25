from __future__ import annotations

import inspect
import time
import uuid
from typing import List

from .common import ILC, ILRC, MatchOption
from .connectivity import ILRequestHelper, TCPConnector
from .exception import (
    ILException,
    ILMsgTypeException,
    ILNoMsgException,
    ILOperationException,
    ILSessionException,
)
from .msg import ILDataMsg, ILMsg, ILMsgUtil, JMSHeader
from .util import ba_merge, ba_pick_int

# Exception types that should propagate without re-wrapping
_PASSTHROUGH_EXCEPTIONS = (
    ILException, ILOperationException, ILSessionException,
    ILMsgTypeException, ILNoMsgException,
)


class ILQmgr:
    """ilink Queue Manager client for message put/get operations.

    Provides connectivity to a single ilink queue manager instance and
    supports transactional message send/receive through :class:`ILQueue`
    handles.

    .. note:: Thread Safety

        Instances of this class are **not** thread-safe.  Each thread must use
        its own ``ILQmgr`` instance.  Sharing a single instance across threads
        will corrupt internal state and socket I/O.

    Example::

        with ILQmgr() as qmgr:
            qmgr.connect("192.168.0.10", 5000, auto_commit=True)
            q = qmgr.access_queue("APP.REQUEST.Q")
            q.put(b"Hello ilink")
    """

    def __init__(self) -> None:
        self.host = ""
        self.port = 0
        self.sessionId = ""
        self.version = ""
        self.name = ""
        self.clientName = ""
        self.qmgrRecvWait = 86400
        self.keepAlive = 600
        self.lastAccessTime = -1
        self.isAutoCommitFlag = False
        self.service = ILRequestHelper()

    # --- context manager ---------------------------------------------------
    def __enter__(self) -> "ILQmgr":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()
        return None

    @staticmethod
    def main(args: list[str]) -> None:
        if len(args) != 1:
            print("available argrments.")
            print("    --version : displays the library version.")
        ILC.print_version(args[0] if args else "")

    def get_host(self) -> str:
        """Return the host address of the connected queue manager.

        Returns:
            The IP address or hostname passed to :meth:`connect`.

        Example::

            qmgr.connect("192.168.0.10", 5000)
            print(qmgr.get_host())  # "192.168.0.10"
        """
        return self.host

    def getHost(self) -> str:
        return self.get_host()

    def get_port(self) -> int:
        """Return the port number of the connected queue manager.

        Returns:
            The port number passed to :meth:`connect`.

        Example::

            qmgr.connect("192.168.0.10", 5000)
            print(qmgr.get_port())  # 5000
        """
        return self.port

    def getPort(self) -> int:
        return self.get_port()

    def get_client_name(self) -> str:
        """Return the client identifier for the current session.

        Returns:
            The client name supplied at :meth:`connect`, or the auto-detected
            caller module name if none was provided.

        Example::

            qmgr.connect("192.168.0.10", 5000, client_name="order-svc")
            print(qmgr.get_client_name())  # "order-svc"
        """
        return self.clientName

    def getClientName(self) -> str:
        return self.get_client_name()

    def get_qmgr_name(self) -> str:
        """Return the queue manager name reported by the server.

        Returns:
            The name assigned to the queue manager on the ilink server side.

        Example::

            qmgr.connect("192.168.0.10", 5000)
            print(qmgr.get_qmgr_name())  # "QMGR01"
        """
        return self.name

    def getQmgrName(self) -> str:
        return self.get_qmgr_name()

    def is_auto_commit(self) -> bool:
        """Check whether the session is in auto-commit mode.

        Returns:
            ``True`` if every put/get is automatically committed,
            ``False`` if manual :meth:`commit` / :meth:`rollback` is required.

        Example::

            qmgr.connect("192.168.0.10", 5000, auto_commit=True)
            print(qmgr.is_auto_commit())  # True
        """
        return self.isAutoCommitFlag

    def isAutoCommit(self) -> bool:
        return self.is_auto_commit()

    def get_qmgr_recv_wait(self) -> int:
        """Return the queue-manager-side receive wait time (seconds)."""
        return self.qmgrRecvWait

    def getQmgrRecvWait(self) -> int:
        return self.get_qmgr_recv_wait()

    def get_keep_alive(self) -> int:
        """Return the keep-alive interval (seconds)."""
        return self.keepAlive

    def getKeepAlive(self) -> int:
        return self.get_keep_alive()

    def set_last_access_time(self) -> None:
        """Record the current time as the last access timestamp."""
        self.lastAccessTime = int(time.time() * 1000)

    def setLastAccessTime(self) -> None:
        self.set_last_access_time()

    def get_last_access_time(self) -> int:
        """Return the last access timestamp in epoch milliseconds."""
        return self.lastAccessTime

    def getLastAccessTime(self) -> int:
        return self.get_last_access_time()

    def is_idle(self) -> bool:
        """Check whether the session has been idle longer than the keep-alive interval.

        Returns:
            ``True`` if the elapsed time since last access exceeds the keep-alive
            threshold.
        """
        if self.lastAccessTime < 0:
            return False
        return int(time.time() * 1000) - self.lastAccessTime > self.keepAlive * 1000

    def isIdle(self) -> bool:
        return self.is_idle()

    def connect(
        self,
        host: str,
        port: int,
        client_name: str = "",
        auto_commit: bool = False,
        *,
        clientName: str | None = None,
        isAutoCommit: bool | None = None,
    ) -> None:
        """Connect to an ilink queue manager.

        Establishes a TCP connection and creates a new session on the target
        queue manager.

        Args:
            host: IP address or hostname of the ilink queue manager.
            port: Listener port of the queue manager (not the ilsvc admin port).
            client_name: Identifier for this client session.  If omitted, the
                caller's module name is used automatically.
            auto_commit: When ``True`` the session operates in auto-acknowledge
                mode where every put/get is committed immediately.  When
                ``False`` (default) the caller must invoke :meth:`commit` or
                :meth:`rollback` explicitly.

        Raises:
            ILSessionException: If the address is invalid or the connection
                cannot be established.
            ILOperationException: If the server refuses the connection.

        Example::

            qmgr = ILQmgr()
            qmgr.connect("192.168.0.10", 5000)                    # manual commit
            qmgr.connect("192.168.0.10", 5000, auto_commit=True)  # auto commit
            qmgr.connect("192.168.0.10", 5000, client_name="billing-svc")
        """
        # Support legacy positional bool for client_name (Java-style overload)
        if isinstance(client_name, bool):
            auto_commit = client_name
            client_name = ""
        # Support legacy keyword arguments
        if clientName is not None:
            client_name = clientName
        if isAutoCommit is not None:
            auto_commit = isAutoCommit
        try:
            self.host = host
            self.port = port
            self.service.connect(host, port)
            if not client_name:
                try:
                    frame = inspect.stack()[-1]
                    module_name = frame.frame.f_globals.get("__name__", "")
                    client_name = module_name.rsplit(".", 1)[-1] or ""
                except Exception:
                    client_name = ""
            self.clientName = client_name
            conn_mode = ILC.MIMQ_SESSION_TRANSACTED
            if auto_commit:
                conn_mode = ILC.MIMQ_AUTO_ACKNOWLEDGE
            conn_res_msg = self.service.request(
                ILC.MIMQ_NEW_CONNECTION, str(conn_mode), client_name, "USR"
            )
            if conn_res_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if conn_res_msg.getCode() != ILC.MIMQ_SUCCESSFUL_CONNECTION:
                self.service.shutdown()
                raise ILOperationException(conn_res_msg.getArg2())

            self.sessionId = conn_res_msg.getArg1()
            self.isAutoCommitFlag = auto_commit
            if self.sessionId == "":
                self.disconnect()
                raise ILSessionException(
                    ILRC.MIMQE_INVALID_ADDRESS,
                    "invalid protocol (empty session id) - check connection address.",
                )

            self.name = conn_res_msg.getArg3()
            if self.name == ILC.MIMQ_CLIENT_NAME_ILSVC:
                self.disconnect()
                raise ILSessionException(
                    ILRC.MIMQE_INVALID_ADDRESS,
                    "invalid protocol (this is the 'ilsvc' port number. plz specify the 'qmgr' port number!)",
                )

            self.version = conn_res_msg.getArg2()
            if self.version == "":
                self.version = "5"

            if ILC.CONN_INFO_DELIMITER in conn_res_msg.getArg2():
                conn_info = conn_res_msg.getArg2().split(ILC.CONN_INFO_DELIMITER)
                if len(conn_info) > 1:
                    self.version = conn_info[0]
                    try:
                        self.qmgrRecvWait = int(conn_info[1])
                        if self.keepAlive > self.qmgrRecvWait:
                            self.keepAlive = self.qmgrRecvWait
                    except Exception:
                        pass
            else:
                self.version = conn_res_msg.getArg2() or "5"

            self.set_last_access_time()
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def disconnect(self) -> None:
        """Disconnect from the queue manager.

        Sends a graceful disconnection request and closes the underlying
        TCP socket.  Safe to call even if not connected.

        Example::

            qmgr.connect("192.168.0.10", 5000)
            # ... work ...
            qmgr.disconnect()
        """
        if not self.service.isOnline():
            return
        try:
            self.service.request(ILC.MIMQ_DISCONNECTION, ILC.MIMQ_SUCCESSFUL_DISCONNECTION)
        except Exception:
            pass
        finally:
            self.service.shutdown()

    def access_queue(self, queue_name: str, exist_check: bool = True) -> "ILQueue":
        """Obtain an ILQueue handle for the specified queue.

        The returned :class:`ILQueue` object can be used to put and get
        messages on the named queue.

        Args:
            queue_name: Name of the target queue (e.g. ``"APP.REQUEST.Q"``).
            exist_check: When ``True`` (default) the queue existence is
                verified on the server before returning.  Set to ``False`` to
                skip this check for performance.

        Returns:
            An :class:`ILQueue` instance bound to *queue_name*.

        Raises:
            ILOperationException: If *exist_check* is ``True`` and the queue
                does not exist on the server.

        Example::

            q = qmgr.access_queue("APP.REQUEST.Q")
            q.put(b"hello")
        """
        return ILQueue(self, queue_name, exist_check)

    def accessQueue(self, queueName: str, existCheck: bool = True) -> "ILQueue":
        return self.access_queue(queueName, existCheck)

    def commit(self) -> int:
        """Commit all uncommitted put/get operations in the current session.

        This method is only meaningful when the session is in manual-commit
        mode (``auto_commit=False``).

        Returns:
            The number of messages committed, or ``-1`` if unknown.

        Raises:
            ILOperationException: If the commit fails on the server side.

        Example::

            qmgr.connect("192.168.0.10", 5000, auto_commit=False)
            q = qmgr.access_queue("APP.Q")
            q.put(b"msg1")
            q.put(b"msg2")
            committed = qmgr.commit()  # both messages committed atomically
        """
        try:
            report_msg = self.service.request(ILC.MIMQ_COMMIT_TRANSACTION_REQUEST)
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_COMMIT:
                raise ILOperationException(report_msg.getArg2())
            if report_msg.getArg1() == "":
                return -1
            self.set_last_access_time()
            return int(report_msg.getArg1())
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def rollback(self) -> int:
        """Roll back all uncommitted put/get operations in the current session.

        Returns:
            The number of messages rolled back, or ``-1`` if unknown.
            This method does not raise exceptions; failures are silently
            absorbed.

        Example::

            q.put(b"should not be sent")
            qmgr.rollback()  # message discarded
        """
        try:
            self.set_last_access_time()
            report_msg = self.service.request(ILC.MIMQ_ROLLBACK_REQUEST)
            if (
                report_msg is not None
                and report_msg.getCode() == ILC.MIMQ_SUCCESSFUL_ROLLBACK
                and report_msg.getArg1() != ""
            ):
                return int(report_msg.getArg1())
        except Exception:
            pass
        return -1

    def health_check(self) -> bool:
        """Verify the queue manager connection with a PING request.

        Returns:
            ``True`` if the queue manager responds successfully, ``False``
            otherwise (the connection is shut down on failure).

        Example::

            if not qmgr.health_check():
                qmgr.connect("192.168.0.10", 5000)  # reconnect
        """
        try:
            if self.service.isOnline():
                self.service.request(ILC.MIMQ_PING, ILC.MIMQ_SUCCESSFUL_PING)
                self.set_last_access_time()
                return True
        except Exception:
            self.service.shutdown()
        return False

    def healthCheck(self) -> bool:
        return self.health_check()

    def is_connected(self) -> bool:
        """Check whether the underlying socket is still open.

        Returns:
            ``True`` if the TCP connection to the queue manager is active.
        """
        return self.service.isOnline()

    def isConnected(self) -> bool:
        return self.is_connected()

    def set_session_timeout(self, timeout_ms: int) -> None:
        """Set the packet-reception wait timeout.

        Args:
            timeout_ms: Timeout in milliseconds.  Negative values are ignored.

        Example::

            qmgr.set_session_timeout(30000)  # 30 seconds
        """
        if timeout_ms < 0:
            return
        self.service.setSessionTimeout(timeout_ms)

    def setSessionTimeout(self, timeoutMS: int) -> None:
        self.set_session_timeout(timeoutMS)

    def get_session_timeout(self) -> int:
        """Return the current session timeout in milliseconds.

        Returns:
            The timeout value (default 600000 ms).
        """
        return self.service.getSessionTimeout()

    def getSessionTimeout(self) -> int:
        return self.get_session_timeout()

    def get_session_id(self) -> str:
        """Return the 36-character UUID session identifier assigned by the server.

        Returns:
            The session ID string, or ``""`` if not yet connected.
        """
        return self.sessionId

    def getSessionId(self) -> str:
        return self.get_session_id()

    def get_version(self) -> str:
        """Return the queue manager engine version string.

        Returns:
            A version string such as ``"6.3.3"``.
        """
        return self.version

    def getVersion(self) -> str:
        return self.get_version()

    def get_name(self) -> str:
        """Return the queue manager name (same as :meth:`get_qmgr_name`)."""
        return self.name

    def getName(self) -> str:
        return self.get_name()

    def get_conn(self) -> TCPConnector:
        """Return the underlying TCP connector instance (advanced use)."""
        return self.service.getConn()

    def getConn(self) -> TCPConnector:
        return self.get_conn()

    def get_queue_depth(self, queue_name: str) -> int:
        """Return the current message count in the specified queue.

        Args:
            queue_name: Name of the queue to query.

        Returns:
            The number of messages currently held in the queue.

        Raises:
            ILOperationException: If the queue does not exist or the server
                returns an error.

        Example::

            depth = qmgr.get_queue_depth("APP.REQUEST.Q")
            print(f"Messages pending: {depth}")
        """
        try:
            report_msg = self.service.request(ILC.MIMQ_GET_QUEUE_DEPTH, queue_name)
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_GET_QUEUE_DEPTH:
                raise ILOperationException(report_msg.getArg2())
            self.set_last_access_time()
            try:
                return int(report_msg.getArg1())
            except Exception as exc:
                raise ILOperationException(
                    f"MIMQE_INVALID_NUMBER_FORMAT ({report_msg.getArg1()})", exc
                )
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def getQueueDepth(self, queueName: str) -> int:
        return self.get_queue_depth(queueName)

    def flush_queue(self, queue_name: str) -> None:
        """Remove all messages from the specified queue.

        Args:
            queue_name: Name of the queue to flush.

        Raises:
            ILOperationException: If the queue does not exist.

        Example::

            qmgr.flush_queue("APP.TEMP.Q")
        """
        try:
            self.service.request(
                ILC.MIMQ_FLUSH_QUEUE, ILC.MIMQ_SUCCESSFUL_QUEUE_FLUSH, queue_name
            )
            self.set_last_access_time()
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def flushQueue(self, queueName: str) -> None:
        self.flush_queue(queueName)

    def is_queue_exist(self, queue_name: str) -> bool:
        """Check whether the specified queue exists on the queue manager.

        Args:
            queue_name: Name of the queue to check.

        Returns:
            ``True`` if the queue exists, ``False`` otherwise.

        Example::

            if qmgr.is_queue_exist("APP.REQUEST.Q"):
                q = qmgr.access_queue("APP.REQUEST.Q")
        """
        try:
            report_msg = self.service.request(ILC.MIMQ_IS_QUEUE_EXIST, queue_name)
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_IS_QUEUE_EXIST:
                raise ILOperationException(report_msg.getArg2())
            self.set_last_access_time()
            return report_msg.getArg1() == "true"
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def isQueueExist(self, queueName: str) -> bool:
        return self.is_queue_exist(queueName)

    def is_queue_empty(self, queue_name: str) -> bool:
        """Check whether the specified queue contains zero messages.

        Args:
            queue_name: Name of the queue to check.

        Returns:
            ``True`` if the queue is empty.

        Example::

            if qmgr.is_queue_empty("APP.REPLY.Q"):
                print("No replies yet")
        """
        try:
            report_msg = self.service.request(ILC.MIMQ_IS_QUEUE_EMPTY, queue_name)
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_IS_QUEUE_EMPTY:
                raise ILOperationException(report_msg.getArg2())
            self.set_last_access_time()
            return report_msg.getArg1() == "true"
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def isQueueEmpty(self, queueName: str) -> bool:
        return self.is_queue_empty(queueName)

    def is_queue_full(self, queue_name: str) -> bool:
        """Check whether the specified queue has reached its maximum depth.

        Args:
            queue_name: Name of the queue to check.

        Returns:
            ``True`` if the queue is full.

        Example::

            if qmgr.is_queue_full("APP.REQUEST.Q"):
                print("Queue is full, try again later")
        """
        try:
            report_msg = self.service.request(ILC.MIMQ_IS_QUEUE_FULL, queue_name)
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_IS_QUEUE_FULL:
                raise ILOperationException(report_msg.getArg2())
            self.set_last_access_time()
            return report_msg.getArg1() == "true"
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def isQueueFull(self, queueName: str) -> bool:
        return self.is_queue_full(queueName)


class ILQueue:
    """Handle for putting and getting messages on a single ilink queue.

    Instances are created via :meth:`ILQmgr.access_queue` -- do not
    instantiate directly.

    Example::

        q = qmgr.access_queue("APP.REQUEST.Q")
        msg_id = q.put(b"request payload")
        reply = q.get()
    """

    def __init__(self, qmgr: ILQmgr, queueName: str, existCheck: bool) -> None:
        self.qmgr = qmgr
        self.conn = self.qmgr.get_conn()
        self.helper = ILRequestHelper(self.conn)
        self.name = queueName
        self.waitMsgTimeoutMS = 60000
        self.isInfiniteWaiting = False

        if not existCheck:
            return
        try:
            report_msg = self.helper.request(ILC.MIMQ_IS_QUEUE_EXIST, queueName)
            if report_msg is None:
                raise ILOperationException("MIMQE_INTERNAL_ERROR")
            if report_msg.getCode() != ILC.MIMQ_SUCCESSFUL_IS_QUEUE_EXIST:
                raise ILOperationException(report_msg.getArg2())
            if report_msg.getArg1() != "true":
                raise ILOperationException(f"MIMQE_OBJECT_NOT_FOUND ({queueName})")
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def put(
        self, data_or_header: bytes | bytearray | JMSHeader | ILDataMsg, data=None
    ) -> str:
        """Put a message onto the queue.

        Accepts three calling conventions:

        * ``put(data: bytes)`` -- send raw bytes with a default JMS header.
        * ``put(header: JMSHeader, data: bytes)`` -- send bytes with a
          custom JMS header.
        * ``put(msg: ILDataMsg)`` -- send a pre-built data message object.

        A UUID message-ID is generated automatically unless already set on
        the header.

        Args:
            data_or_header: Raw ``bytes``, a :class:`JMSHeader`, or a
                complete :class:`ILDataMsg`.
            data: Message payload when *data_or_header* is a
                :class:`JMSHeader`.  Ignored otherwise.

        Returns:
            The message ID (UUID string) assigned to the sent message.

        Raises:
            ILOperationException: If the put is rejected by the server
                (e.g. queue full, message too large).

        Example::

            # Simple byte payload
            msg_id = q.put(b"hello world")

            # With custom header
            hdr = JMSHeader()
            hdr.setPriority(9)
            msg_id = q.put(hdr, b"urgent payload")

            # Pre-built message
            dm = ILDataMsg(JMSHeader(), b"data")
            msg_id = q.put(dm)
        """
        if isinstance(data_or_header, ILDataMsg):
            return self._put_msg(data_or_header)
        if isinstance(data_or_header, JMSHeader):
            return self._put_msg(ILDataMsg(data_or_header, bytes(data or b"")))
        if isinstance(data_or_header, (bytes, bytearray)):
            header = JMSHeader()
            return self._put_msg(ILDataMsg(header, bytes(data_or_header)))
        raise TypeError("unsupported message type")

    def _put_msg(self, msg: ILDataMsg) -> str:
        try:
            msg_id = msg.getHeader().getMsgId()
            if msg_id == "":
                msg_id = str(uuid.uuid4())
                msg.getHeader().setMsgId(msg_id)
            msg.getHeader().setDestination(self.name)
            msg.getHeader().setTimeStamp(int(time.time() * 1000))
            self.conn.send(ILMsgUtil.create_data_msg(msg))
            if self.qmgr.is_auto_commit():
                report_msg = self.conn.recv(self.qmgr.get_session_timeout())
                if report_msg.getType() != ILC.MIMQ_REPORT_MESSAGE:
                    raise ILMsgTypeException(
                        report_msg.getType(), "msg type must be [MIMQ_REPORT_MESSAGE]"
                    )
                if report_msg.getReportMsg().getCode() != ILC.MIMQ_SUCCESSFUL_PUT:
                    raise ILOperationException(report_msg.getReportMsg().getArg2())
            self.qmgr.set_last_access_time()
            return msg_id
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def puts(self, msgs: List[ILDataMsg]) -> List[str]:
        """Put multiple messages onto the queue in a single batch.

        All messages are transmitted as one network packet for efficiency.
        A UUID message-ID is generated for each message that does not
        already have one.

        Args:
            msgs: A list of :class:`ILDataMsg` objects to send.

        Returns:
            A list of message ID strings in the same order as *msgs*.

        Raises:
            ILOperationException: If the batch put is rejected by the server.

        Example::

            msgs = [ILDataMsg(JMSHeader(), b"m1"),
                    ILDataMsg(JMSHeader(), b"m2")]
            ids = q.puts(msgs)
        """
        try:
            msg_list: List[ILMsg] = []
            msg_ids: List[str] = [""] * len(msgs)
            buffer_length = 10
            for idx, data_msg in enumerate(msgs):
                msg_id = data_msg.getHeader().getMsgId()
                if msg_id == "":
                    msg_id = str(uuid.uuid4())
                    data_msg.getHeader().setMsgId(msg_id)
                msg_ids[idx] = msg_id
                data_msg.getHeader().setDestination(self.name)
                data_msg.getHeader().setTimeStamp(int(time.time() * 1000))
                wrapped_msg = ILMsgUtil.create_data_msg(data_msg)
                buffer_length += wrapped_msg.get_msg_length()
                msg_list.append(wrapped_msg)

            buffer = bytearray(buffer_length)
            offset = 0
            ba_merge(len(msgs), buffer, offset)
            offset += 10
            for msg in msg_list:
                data = msg.to_byte_array(False)
                buffer[offset : offset + msg.get_msg_length()] = data
                offset += msg.get_msg_length()

            header = JMSHeader()
            header.setDestination(self.name)
            self.conn.send(
                ILMsg(ILC.MIMQ_ARRAY_DATA_MESSAGE, ILDataMsg(header, bytes(buffer)))
            )

            if self.qmgr.is_auto_commit():
                report_msg = self.conn.recv(self.qmgr.get_session_timeout())
                if report_msg.getType() != ILC.MIMQ_REPORT_MESSAGE:
                    raise ILMsgTypeException(
                        report_msg.getType(), "msg type must be [MIMQ_REPORT_MESSAGE]"
                    )
                if report_msg.getReportMsg().getCode() != ILC.MIMQ_SUCCESSFUL_PUT:
                    raise ILOperationException(report_msg.getReportMsg().getArg2())
            self.qmgr.set_last_access_time()
            return msg_ids
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

    def set_wait_msg_timeout_ms(self, value: int) -> None:
        """Set the wait timeout for message retrieval operations.

        Controls how long :meth:`get` and :meth:`gets` will wait for a
        message to arrive before raising :class:`ILNoMsgException`.

        Args:
            value: Timeout in milliseconds.  Use ``ILC.MIMQ_MSGGET_INFINITE``
                (``-1``) for infinite waiting.  Default is ``60000`` (60 s).

        Example::

            q.set_wait_msg_timeout_ms(5000)   # wait up to 5 seconds
            q.set_wait_msg_timeout_ms(-1)     # wait forever
        """
        if value == ILC.MIMQ_MSGGET_INFINITE:
            self.isInfiniteWaiting = True
            self.waitMsgTimeoutMS = 60000
        else:
            self.isInfiniteWaiting = False
            self.waitMsgTimeoutMS = value

    def setWaitMsgTimeoutMS(self, value: int) -> None:
        self.set_wait_msg_timeout_ms(value)

    def get(self, matchId: str | None = None, option: MatchOption = MatchOption.NONE) -> ILDataMsg:
        """Retrieve a message from the queue.

        Without arguments, returns the highest-priority message in FIFO
        order.  A *matchId* and *option* can be supplied to retrieve a
        specific message by its message ID or correlation ID.

        Args:
            matchId: The identifier to match against.  ``None`` for
                unfiltered retrieval.
            option: The matching strategy -- one of
                :attr:`MatchOption.MATCH_MSG_ID`,
                :attr:`MatchOption.MATCH_CORREL_ID`, or
                :attr:`MatchOption.NONE` (default).

        Returns:
            The retrieved :class:`ILDataMsg`.

        Raises:
            ILNoMsgException: If no matching message arrives within the
                configured wait timeout.
            ILOperationException: If the server reports an error.

        Example::

            # Get next available message
            msg = q.get()
            print(msg.getData())

            # Get by message ID
            msg = q.get("abc-123", MatchOption.MATCH_MSG_ID)

            # Get by correlation ID
            msg = q.get("corr-456", MatchOption.MATCH_CORREL_ID)
        """
        try:
            ext = None
            if matchId:
                ext = ILC.make_selector(matchId, option).encode("utf-8")
            req_msg = ILMsgUtil.create_request_msg_with_ext(
                ILC.MIMQ_GET_REQUEST,
                ext,
                "",
                self.name,
                str(self.waitMsgTimeoutMS),
            )
            while True:
                self.conn.send(req_msg)
                timeout = self.qmgr.get_session_timeout()
                if (
                    not self.isInfiniteWaiting
                    and timeout > 0
                    and timeout <= self.waitMsgTimeoutMS
                ):
                    timeout = self.waitMsgTimeoutMS * 2
                self.qmgr.set_last_access_time()
                msg = self.conn.recv(timeout)
                if msg.getType() == ILC.MIMQ_DATA_MESSAGE:
                    return msg.getDataMsg()

                if msg.getType() != ILC.MIMQ_REPORT_MESSAGE:
                    raise ILMsgTypeException(
                        msg.getType(),
                        "msg type must be [MIMQ_DATA_MESSAGE] or [MIMQ_REPORT_MESSAGE]",
                    )
                if msg.getReportMsg().getCode() != ILC.MIMQ_NO_NEW_MESSAGE:
                    raise ILOperationException(msg.getReportMsg().getArg2())

                if not self.isInfiniteWaiting:
                    break
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

        raise ILNoMsgException(self.qmgr.get_name(), self.name)

    def gets(self, max_count: int) -> List[ILDataMsg]:
        """Retrieve multiple messages from the queue in a single batch.

        Args:
            max_count: Maximum number of messages to retrieve.

        Returns:
            A list of :class:`ILDataMsg` objects (may be shorter than
            *max_count* if fewer messages are available).

        Raises:
            ILNoMsgException: If no messages arrive within the wait timeout.

        Example::

            messages = q.gets(10)
            for m in messages:
                print(m.getData())
        """
        try:
            req_msg = ILMsgUtil.create_request_msg_with_ext(
                ILC.MIMQ_GETS_REQUEST,
                None,
                str(max_count),
                self.name,
                str(self.waitMsgTimeoutMS),
            )
            while True:
                self.conn.send(req_msg)
                timeout = self.qmgr.get_session_timeout()
                if (
                    not self.isInfiniteWaiting
                    and timeout > 0
                    and timeout <= self.waitMsgTimeoutMS
                ):
                    timeout = self.waitMsgTimeoutMS * 2
                self.qmgr.set_last_access_time()
                msg = self.conn.recv(timeout)
                if msg.getType() == ILC.MIMQ_ARRAY_DATA_MESSAGE:
                    offset = 0
                    data_msgs: List[ILDataMsg] = []
                    buffer = msg.getDataMsg().getData() or b""
                    cnt = ba_pick_int(buffer, offset, 10)
                    offset += 10
                    for _ in range(cnt):
                        length = ba_pick_int(buffer, offset, 10)
                        ba = buffer[offset : offset + length]
                        offset += length
                        temp_msg = ILMsg(ba)
                        data_msgs.append(temp_msg.getDataMsg())
                    return data_msgs

                if msg.getType() != ILC.MIMQ_REPORT_MESSAGE:
                    raise ILMsgTypeException(
                        msg.getType(),
                        "msg type must be [MIMQ_ARRAY_DATA_MESSAGE] or [MIMQ_REPORT_MESSAGE]",
                    )
                if msg.getReportMsg().getCode() != ILC.MIMQ_NO_NEW_MESSAGE:
                    raise ILOperationException(msg.getReportMsg().getArg2())

                if not self.isInfiniteWaiting:
                    break
        except _PASSTHROUGH_EXCEPTIONS:
            raise
        except Exception as exc:
            raise ILException(exc) from exc

        raise ILNoMsgException(self.qmgr.get_name(), self.name)
