"""iLink - Python client API for iLink M.O.M. (Message Oriented Middleware)."""

__version__ = "0.1.0"

# --- Admin / Service ---
from .admin import ILAdminService, ILAdminQmgr, ILLogBrowser, ILQueueBrowser

# --- Queue Manager & Queue ---
from .qmgr import ILQmgr, ILQueue

# --- Message ---
from .msg import ILMsg, ILMsgUtil

# --- Constants & Enums ---
from .common import ILC, ILCC, ILRC, MatchOption

# --- Properties ---
from .properties import (
    DestItem,
    PartitionItem,
    ILQueueProperty,
    ILChannelProperty,
    ILChannelType,
    ILChannelStatus,
    ILChannelDirection,
    ILChannelSecurity,
    ILChannelBalanceMode,
    ILQmgrProperty,
    ILSessionProperty,
    ILServiceProperty,
    ILSpokeProperty,
    ILAccessRuleProperty,
    ILSecureFileProperty,
    ILQueueRealTimeInfo,
    ILQueueFlow,
)

# --- Exceptions ---
from .exception import (
    ILException,
    ILNoMsgException,
    ILTimeoutException,
    ILOperationException,
    ILSessionException,
    ILMsgTypeException,
)

__all__ = [
    # Admin
    "ILAdminService",
    "ILAdminQmgr",
    "ILLogBrowser",
    "ILQueueBrowser",
    # QMgr / Queue
    "ILQmgr",
    "ILQueue",
    # Message
    "ILMsg",
    "ILMsgUtil",
    # Constants
    "ILC",
    "ILCC",
    "ILRC",
    "MatchOption",
    # Properties
    "DestItem",
    "PartitionItem",
    "ILQueueProperty",
    "ILChannelProperty",
    "ILChannelType",
    "ILChannelStatus",
    "ILChannelDirection",
    "ILChannelSecurity",
    "ILChannelBalanceMode",
    "ILQmgrProperty",
    "ILSessionProperty",
    "ILServiceProperty",
    "ILSpokeProperty",
    "ILAccessRuleProperty",
    "ILSecureFileProperty",
    "ILQueueRealTimeInfo",
    "ILQueueFlow",
    # Exceptions
    "ILException",
    "ILNoMsgException",
    "ILTimeoutException",
    "ILOperationException",
    "ILSessionException",
    "ILMsgTypeException",
]
