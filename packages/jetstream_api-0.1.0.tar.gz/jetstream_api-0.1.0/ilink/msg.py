﻿
from __future__ import annotations

from typing import Dict, List, Type, TypeVar

from .common import ILC
from .exception import (
    ILDeserializeException,
    ILException,
    ILMsgTypeException,
    UnsupportedOperationException,
)
from .properties import (
    ILAccessRuleProperty,
    ILChannelMinorProperty,
    ILChannelProperty,
    ILClientRecvChannelMinorProperty,
    ILClientSendChannelMinorProperty,
    ILLocalQueueMinorProperty,
    ILQmgrMinorProperty,
    ILQmgrProperty,
    ILQueueFlow,
    ILQueueMinorProperty,
    ILQueueProperty,
    ILRemoteQueueMinorProperty,
    ILSecureFileProperty,
    ILServerRecvChannelMinorProperty,
    ILServerSendChannelMinorProperty,
    ILServiceProperty,
    ILSessionMinorProperty,
    ILSessionProperty,
    ILSpokeProperty,
    ILXmitQueueMinorProperty,
)
from .util import (
    ILInputStream,
    ILOutputStream,
    ba_merge,
    ba_pick_bytes,
    ba_pick_int,
    ba_pick_long,
    ba_pick_string,
)

T = TypeVar("T")


class ILInnerMsg:
    def to_byte_array(self) -> bytes:
        raise NotImplementedError

    def get_msg_length(self) -> int:
        raise NotImplementedError

    def toByteArray(self) -> bytes:
        return self.to_byte_array()

    def getMsgLength(self) -> int:
        return self.get_msg_length()


class ILRequestMsg(ILInnerMsg):
    def __init__(
        self,
        code: int | bytes | bytearray,
        arg1: str = "",
        arg2: str = "",
        arg3: str = "",
        ext: bytes | None = None,
    ) -> None:
        self.code = 0
        self.arg1 = ""
        self.arg2 = ""
        self.arg3 = ""
        self.extension: bytes | None = None

        if isinstance(code, (bytes, bytearray)):
            data = bytes(code)
            pivot = 0
            self.code = ba_pick_int(data, pivot, ILC.SZ_CODE)
            pivot += ILC.SZ_CODE
            self.arg1 = ba_pick_string(data, pivot, ILC.SZ_ARG)
            pivot += ILC.SZ_ARG
            self.arg2 = ba_pick_string(data, pivot, ILC.SZ_ARG)
            pivot += ILC.SZ_ARG
            self.arg3 = ba_pick_string(data, pivot, ILC.SZ_ARG)
            pivot += ILC.SZ_ARG
            extension_length = ba_pick_int(data, pivot, ILC.SZ_LEN)
            pivot += ILC.SZ_LEN
            if extension_length > 0:
                self.extension = data[pivot : pivot + extension_length]
        else:
            self.code = code
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.extension = ext

    def to_byte_array(self) -> bytes:
        serialized = bytearray(self.get_msg_length())
        pivot = 0
        has_ext = self.extension is not None
        ba_merge(self.code, serialized, pivot)
        pivot += ILC.SZ_CODE
        ba_merge(self.arg1, serialized, pivot)
        pivot += ILC.SZ_ARG
        ba_merge(self.arg2, serialized, pivot)
        pivot += ILC.SZ_ARG
        ba_merge(self.arg3, serialized, pivot)
        pivot += ILC.SZ_ARG
        ba_merge(self.extension and len(self.extension) or 0, serialized, pivot)
        pivot += ILC.SZ_LEN
        if has_ext:
            serialized[pivot : pivot + len(self.extension)] = self.extension
        return bytes(serialized)

    def get_msg_length(self) -> int:
        length = ILC.SZ_CMD + ILC.SZ_LEN
        if self.extension is not None:
            length += len(self.extension)
        return length

    def set_extension(self, data: bytes | None) -> None:
        self.extension = data

    def setExtension(self, data: bytes | None) -> None:
        self.set_extension(data)


class ILReportMsg(ILInnerMsg):
    def __init__(
        self,
        code: int | bytes | bytearray,
        arg1: str = "",
        arg2: str = "",
        arg3: str = "",
    ) -> None:
        self.code = 0
        self.arg1 = ""
        self.arg2 = ""
        self.arg3 = ""

        if isinstance(code, (bytes, bytearray)):
            data = bytes(code)
            pivot = 0
            self.code = ba_pick_int(data, pivot, ILC.SZ_CODE)
            pivot += ILC.SZ_CODE
            self.arg1 = ba_pick_string(data, pivot, ILC.SZ_ARG)
            pivot += ILC.SZ_ARG
            self.arg2 = ba_pick_string(data, pivot, ILC.SZ_ARG)
            pivot += ILC.SZ_ARG
            self.arg3 = ba_pick_string(data, pivot, ILC.SZ_ARG)
            pivot += ILC.SZ_ARG
        else:
            self.code = code
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3

    def to_byte_array(self) -> bytes:
        serialized = bytearray(self.get_msg_length())
        pivot = 0
        ba_merge(self.code, serialized, pivot)
        pivot += ILC.SZ_CODE
        ba_merge(self.arg1, serialized, pivot)
        pivot += ILC.SZ_ARG
        ba_merge(self.arg2, serialized, pivot)
        pivot += ILC.SZ_ARG
        ba_merge(self.arg3, serialized, pivot)
        pivot += ILC.SZ_ARG
        return bytes(serialized)

    def get_msg_length(self) -> int:
        return ILC.SZ_CMD

    def get_code(self) -> int:
        return self.code

    def get_arg1(self) -> str:
        return self.arg1

    def get_arg2(self) -> str:
        return self.arg2

    def get_arg3(self) -> str:
        return self.arg3

    def getCode(self) -> int:
        return self.get_code()

    def getArg1(self) -> str:
        return self.get_arg1()

    def getArg2(self) -> str:
        return self.get_arg2()

    def getArg3(self) -> str:
        return self.get_arg3()


class JMSHeader:
    def __init__(self, buffer: bytes | bytearray | None = None) -> None:
        self.dataTypeCode = ILC.MIMQ_BYTES_MESSAGE
        self.internalExpiration = 0
        self.internalTimeStamp = 0
        self.internalMsgId = ""
        self.correlId = ""
        self.deliveryMode = ILC.MIMQ_PERSISTENT_MESSAGE
        self.destination = ""
        self.expiration = 0
        self.msgId = ""
        self.priority = 4
        self.redelivered = False
        self.replyTo = ""
        self.timeStamp = 0
        self.dataTypeString = "Bytes"

        if buffer is None:
            return

        data = bytes(buffer)
        pivot = 0
        self.dataTypeCode = ba_pick_int(data, pivot, ILC.SZ_CODE)
        pivot += ILC.SZ_CODE
        self.internalExpiration = ba_pick_long(data, pivot, ILC.SZ_JMS_EXP)
        pivot += ILC.SZ_JMS_EXP
        self.internalTimeStamp = ba_pick_long(data, pivot, ILC.SZ_JMS_EXP)
        pivot += ILC.SZ_JMS_EXP
        self.internalMsgId = ba_pick_string(data, pivot, ILC.SZ_JMS_IN_MSGID)
        pivot += ILC.SZ_JMS_IN_MSGID
        self.correlId = ba_pick_string(data, pivot, ILC.SZ_JMS_MSGID)
        pivot += ILC.SZ_JMS_MSGID
        self.deliveryMode = ba_pick_int(data, pivot, ILC.SZ_CODE)
        pivot += ILC.SZ_CODE
        self.destination = ba_pick_string(data, pivot, ILC.SZ_JMS_NAME)
        pivot += ILC.SZ_JMS_NAME
        self.expiration = ba_pick_long(data, pivot, ILC.SZ_JMS_EXP)
        pivot += ILC.SZ_JMS_EXP
        self.msgId = ba_pick_string(data, pivot, ILC.SZ_JMS_MSGID)
        pivot += ILC.SZ_JMS_MSGID
        self.priority = ba_pick_int(data, pivot, ILC.SZ_JMS_BOOL)
        pivot += ILC.SZ_JMS_BOOL
        self.redelivered = ba_pick_string(data, pivot, ILC.SZ_JMS_BOOL).lower() == "t"
        pivot += ILC.SZ_JMS_BOOL
        self.replyTo = ba_pick_string(data, pivot, ILC.SZ_JMS_NAME)
        pivot += ILC.SZ_JMS_NAME
        self.timeStamp = ba_pick_long(data, pivot, ILC.SZ_JMS_EXP)
        pivot += ILC.SZ_JMS_EXP
        self.dataTypeString = ba_pick_string(data, pivot, ILC.SZ_JMS_TYPE)

    def to_byte_array(self) -> bytes:
        serialized = bytearray(ILC.SZ_JMS_HEADER)
        pivot = 0
        ba_merge(self.dataTypeCode, serialized, pivot)
        pivot += ILC.SZ_CODE
        ba_merge(self.internalExpiration, serialized, pivot)
        pivot += ILC.SZ_JMS_EXP
        ba_merge(self.internalTimeStamp, serialized, pivot)
        pivot += ILC.SZ_JMS_EXP
        ba_merge(self.internalMsgId, serialized, pivot)
        pivot += ILC.SZ_JMS_IN_MSGID
        ba_merge(self.correlId, serialized, pivot)
        pivot += ILC.SZ_JMS_MSGID
        ba_merge(self.deliveryMode, serialized, pivot)
        pivot += ILC.SZ_CODE
        ba_merge(self.destination, serialized, pivot)
        pivot += ILC.SZ_JMS_NAME
        ba_merge(self.expiration, serialized, pivot)
        pivot += ILC.SZ_JMS_EXP
        ba_merge(self.msgId, serialized, pivot)
        pivot += ILC.SZ_JMS_MSGID
        ba_merge(self.priority, serialized, pivot)
        pivot += ILC.SZ_JMS_BOOL
        ba_merge("t" if self.redelivered else "f", serialized, pivot)
        pivot += ILC.SZ_JMS_BOOL
        ba_merge(self.replyTo, serialized, pivot)
        pivot += ILC.SZ_JMS_NAME
        ba_merge(self.timeStamp, serialized, pivot)
        pivot += ILC.SZ_JMS_EXP
        ba_merge(self.dataTypeString, serialized, pivot)
        return bytes(serialized)

    def getHeaderLength(self) -> int:
        return ILC.SZ_JMS_HEADER

    def getInternalExpiration(self) -> int:
        return self.internalExpiration

    def setInternalExpiration(self, internalExpiration: int) -> None:
        self.internalExpiration = internalExpiration

    def getInternalTimeStamp(self) -> int:
        return self.internalTimeStamp

    def setInternalTimeStamp(self, internalTimeStamp: int) -> None:
        self.internalTimeStamp = internalTimeStamp

    def getInternalMsgId(self) -> str:
        return self.internalMsgId

    def setInternalMsgId(self, internalMsgId: str) -> None:
        self.internalMsgId = internalMsgId

    def getDataTypeCode(self) -> int:
        return self.dataTypeCode

    def setDataTypeCode(self, dataTypeCode: int) -> None:
        if dataTypeCode == ILC.MIMQ_BASIC_MESSAGE:
            self.dataTypeString = "Basic"
        elif dataTypeCode == ILC.MIMQ_TEXT_MESSAGE:
            self.dataTypeString = "Text"
        elif dataTypeCode == ILC.MIMQ_BYTES_MESSAGE:
            self.dataTypeString = "Bytes"
        elif dataTypeCode == ILC.MIMQ_STREAM_MESSAGE:
            self.dataTypeString = "Stream"
        elif dataTypeCode == ILC.MIMQ_MAP_MESSAGE:
            self.dataTypeString = "Map"
        elif dataTypeCode == ILC.MIMQ_OBJECT_MESSAGE:
            self.dataTypeString = "Object"
        elif dataTypeCode == ILC.MIMQ_BYTES_DATALESS_MESSAGE:
            self.dataTypeString = "BytesNoData"
        else:
            raise UnsupportedOperationException(
                f"[{dataTypeCode}] is an unacceptable value. (acceptable value range: 2008~2014)"
            )
        self.dataTypeCode = dataTypeCode

    def getMsgId(self) -> str:
        return self.msgId

    def setMsgId(self, msgId: str) -> None:
        self.msgId = msgId

    def getCorrelId(self) -> str:
        return self.correlId

    def setCorrelId(self, correlId: str) -> None:
        self.correlId = correlId

    def getDeliveryMode(self) -> int:
        return self.deliveryMode

    def getDeliveryModeString(self) -> str:
        if self.deliveryMode == ILC.MIMQ_DELIVERY_MODE_NON_PERSISTENCE:
            return "NON_PERSISTENCE"
        return "PERSISTENCE"

    def setDeliveryMode(self, deliveryMode: int) -> None:
        if deliveryMode not in (
            ILC.MIMQ_NON_PERSISTENT_MESSAGE,
            ILC.MIMQ_PERSISTENT_MESSAGE,
        ):
            raise UnsupportedOperationException(
                f"[{deliveryMode}] is an unacceptable value. "
                "(acceptable value: ILC.MIMQ_NON_PERSISTENT_MESSAGE or ILC.MIMQ_PERSISTENT_MESSAGE)"
            )
        self.deliveryMode = deliveryMode

    def getDestination(self) -> str:
        return self.destination

    def setDestination(self, destination: str) -> None:
        self.destination = destination

    def getExpiration(self) -> int:
        return self.expiration

    def setExpiration(self, expiration: int) -> None:
        self.expiration = expiration
        self.internalExpiration = expiration

    def getPriority(self) -> int:
        return self.priority

    def setPriority(self, priority: int) -> None:
        if priority < 0 or priority > 9:
            raise UnsupportedOperationException(
                f"[{priority}] is an unacceptable value. (acceptable value range: 0~9)"
            )
        self.priority = priority

    def isRedelivered(self) -> bool:
        return self.redelivered

    def setRedelivered(self, redelivered: bool) -> None:
        self.redelivered = redelivered

    def getReplyTo(self) -> str:
        return self.replyTo

    def setReplyTo(self, replyTo: str) -> None:
        self.replyTo = replyTo

    def getTimeStamp(self) -> int:
        return self.timeStamp

    def setTimeStamp(self, timeStamp: int) -> None:
        self.timeStamp = timeStamp

    def getDataTypeString(self) -> str:
        return self.dataTypeString

    def setDataTypeString(self, dataTypeString: str) -> None:
        if dataTypeString == "Basic":
            self.dataTypeCode = ILC.MIMQ_BASIC_MESSAGE
        elif dataTypeString == "Bytes":
            self.dataTypeCode = ILC.MIMQ_BYTES_MESSAGE
        elif dataTypeString == "Text":
            self.dataTypeCode = ILC.MIMQ_TEXT_MESSAGE
        elif dataTypeString == "Stream":
            self.dataTypeCode = ILC.MIMQ_STREAM_MESSAGE
        elif dataTypeString == "Map":
            self.dataTypeCode = ILC.MIMQ_MAP_MESSAGE
        elif dataTypeString == "Object":
            self.dataTypeCode = ILC.MIMQ_OBJECT_MESSAGE
        elif dataTypeString == "BytesNoData":
            self.dataTypeCode = ILC.MIMQ_BYTES_DATALESS_MESSAGE
        else:
            return
        self.dataTypeString = dataTypeString


class RFHStruct:
    def __init__(self, *args) -> None:
        self.strucId = ""
        self.version = 2
        self.strucLength = 44
        self.encoding = 273
        self.codedCharSetId = 1208
        self.format = "MQSTR   "
        self.flags = 0
        self.nameValueCodedCharSetId = 1208
        self.nameValueList: List[bytes] = []
        self.data: bytes | None = None

        if not args:
            return
        if len(args) == 1 and isinstance(args[0], (bytes, bytearray)):
            self.parse(bytes(args[0]))
            return
        if len(args) == 3 and all(isinstance(arg, (bytes, bytearray)) for arg in args):
            nv_list = [bytes(args[0]), bytes(args[1])]
            self.setNameValueList(nv_list)
            self.data = bytes(args[2])
            return
        if len(args) == 2 and isinstance(args[0], list) and isinstance(args[1], (bytes, bytearray)):
            self.setNameValueList([bytes(v) for v in args[0]])
            self.data = bytes(args[1])
            return
        raise TypeError("unsupported RFHStruct constructor arguments")

    def parse(self, data: bytes | None) -> None:
        self.strucId = ""
        self.data = data
        if data is None or len(data) < 40:
            return
        is_stream: ILInputStream | None = None
        try:
            is_stream = ILInputStream(data)
            self.strucId = is_stream.read_string(4)
            if not self.isRFH():
                self.strucId = ""
                return
            self.version = is_stream.read_int()
            if self.version != 2:
                is_stream.set_little_endian(True)
                self.version = ILC.swap_int(self.version)
                if self.version != 2:
                    self.strucId = ""
                    return
            self.strucLength = is_stream.read_int()
            self.encoding = is_stream.read_int()
            self.codedCharSetId = is_stream.read_int()
            self.format = is_stream.read_string(8)
            self.flags = is_stream.read_int()
            self.nameValueCodedCharSetId = is_stream.read_int()

            n_read = 0
            while self.strucLength - 36 > n_read:
                name_value_length = is_stream.read_int()
                if name_value_length > 0:
                    self.nameValueList.append(is_stream.read_bytes(name_value_length) or b"")
                else:
                    self.nameValueList.append(b"")
                n_read += name_value_length + 4
            remaining = len(data) - self.strucLength
            self.data = is_stream.read_bytes(remaining)
        except Exception:
            self.strucId = ""
            return
        finally:
            if is_stream is not None:
                is_stream.close()

    def isRFH(self) -> bool:
        return ILC.RFH_STRUCID == self.strucId

    def to_byte_array(self) -> bytes | None:
        if not self.isRFH():
            return self.data
        data_length = 0 if self.data is None else len(self.data)
        os_stream: ILOutputStream | None = None
        try:
            os_stream = ILOutputStream(self.strucLength + data_length)
            os_stream.set_little_endian(False)
            os_stream.write_string_fixed(self.strucId, 4)
            os_stream.write_int(self.version)
            os_stream.write_int(self.strucLength)
            os_stream.write_int(self.encoding)
            os_stream.write_int(self.codedCharSetId)
            os_stream.write_string_fixed(self.format, 8)
            os_stream.write_int(self.flags)
            os_stream.write_int(self.nameValueCodedCharSetId)
            for item in self.nameValueList:
                os_stream.write_int(len(item))
                os_stream.write_bytes(item)
            os_stream.write_bytes(self.data)
            return os_stream.to_byte_array()
        except Exception as exc:
            raise IOError(str(exc)) from exc
        finally:
            if os_stream is not None:
                os_stream.close()

    def getStrucId(self) -> str:
        return self.strucId

    def setStrucId(self) -> None:
        self.strucId = ILC.RFH_STRUCID if self.nameValueList else ""

    def setStrucLength(self) -> None:
        length = 36
        for item in self.nameValueList:
            length += 4
            length += len(item)
        self.strucLength = length

    def getVersion(self) -> int:
        return self.version

    def setVersion(self, version: int) -> None:
        self.version = version

    def getStrucLength(self) -> int:
        return self.strucLength

    def getEncoding(self) -> int:
        return self.encoding

    def setEncoding(self, encoding: int) -> None:
        if encoding not in (273, 546, 785):
            raise UnsupportedOperationException(
                f"[{encoding}] is an unacceptable value. (available values : 273, 546, 785)"
            )
        self.encoding = encoding

    def getCodedCharSetId(self) -> int:
        return self.codedCharSetId

    def setCodedCharSetId(self, codedCharSetId: int) -> None:
        self.codedCharSetId = codedCharSetId

    def getFormat(self) -> str:
        return self.format

    def setFormat(self, format_value: str) -> None:
        self.format = format_value

    def getFlags(self) -> int:
        return self.flags

    def setFlags(self, flags: int) -> None:
        self.flags = flags

    def getNameValueCodedCharSetId(self) -> int:
        return self.nameValueCodedCharSetId

    def setNameValueCodedCharSetId(self, nameValueCodedCharSetId: int) -> None:
        self.nameValueCodedCharSetId = nameValueCodedCharSetId

    def getNameValueList(self) -> List[bytes]:
        return self.nameValueList

    def setNameValueList(self, nameValueList: List[bytes] | None) -> None:
        self.nameValueList = [] if nameValueList is None else nameValueList
        self.setStrucId()
        self.setStrucLength()

    def _find_slot_index(self, key: str) -> int:
        for i, item in enumerate(self.nameValueList):
            if key in item.decode("utf-8", errors="ignore"):
                return i
        return -1

    def getMcdLength(self) -> int:
        index = self._find_slot_index("<mcd>")
        return 0 if index < 0 else len(self.nameValueList[index])

    def getMcd(self) -> bytes | None:
        index = self._find_slot_index("<mcd>")
        return None if index < 0 else self.nameValueList[index]

    def setMcd(self, mcd: bytes | None) -> None:
        index = self._find_slot_index("<mcd>")
        if index == -1:
            if mcd is not None:
                self.nameValueList.append(mcd)
        else:
            if mcd is not None:
                self.nameValueList[index] = mcd
            else:
                self.nameValueList.pop(index)
        self.setStrucId()
        self.setStrucLength()

    def getUsrLength(self) -> int:
        index = self._find_slot_index("<usr>")
        return 0 if index < 0 else len(self.nameValueList[index])

    def getUsr(self) -> bytes | None:
        index = self._find_slot_index("<usr>")
        return None if index < 0 else self.nameValueList[index]

    def setUsr(self, usr: bytes | None) -> None:
        index = self._find_slot_index("<usr>")
        if index == -1:
            if usr is not None:
                self.nameValueList.append(usr)
        else:
            if usr is not None:
                self.nameValueList[index] = usr
            else:
                self.nameValueList.pop(index)
        self.setStrucId()
        self.setStrucLength()

    def getDataLength(self) -> int:
        return 0 if self.data is None else len(self.data)

    def getData(self) -> bytes | None:
        return self.data

    def setData(self, data: bytes | None) -> None:
        self.data = data

    def getSerializedLength(self) -> int:
        return self.getDataLength() + self.strucLength if self.isRFH() else self.getDataLength()


class ILDataMsg(ILInnerMsg):
    def __init__(self, *args) -> None:
        self.header: JMSHeader = JMSHeader()
        self.rfh = RFHStruct()
        self.propertyLength = 0
        self.property: bytes | None = None
        self.dataLength = 0
        self.data: bytes | None = None
        self.lengthOfHeaderOnlyMsg = 0
        self.proxyQmgrName = ""

        if len(args) == 1 and isinstance(args[0], (bytes, bytearray)):
            buffer = bytes(args[0])
            self.header = JMSHeader(buffer)
            pivot = ILC.SZ_JMS_HEADER
            self.propertyLength = ba_pick_int(buffer, pivot, ILC.SZ_LEN)
            pivot += ILC.SZ_LEN
            if self.propertyLength > 0:
                self.property = buffer[pivot : pivot + self.propertyLength]
                pivot += self.propertyLength
            self.lengthOfHeaderOnlyMsg = ba_pick_int(buffer, pivot, ILC.SZ_LEN)
            pivot += ILC.SZ_LEN
            if (
                self.lengthOfHeaderOnlyMsg > 0
                and self.header.getDataTypeCode() != ILC.MIMQ_BYTES_DATALESS_MESSAGE
            ):
                data_buffer = buffer[pivot : pivot + self.lengthOfHeaderOnlyMsg]
                self.setData(data_buffer)
            return

        if len(args) >= 2 and isinstance(args[0], JMSHeader):
            header = args[0]
            if len(args) == 2:
                data = args[1]
                self.setHeader(header)
                self.setData(data)
            elif len(args) == 3:
                prop, data = args[1], args[2]
                self.setHeader(header)
                self.setProperty(prop)
                self.setData(data)
            else:
                raise TypeError("invalid ILDataMsg arguments")
            return

        if args:
            raise TypeError("invalid ILDataMsg arguments")

    def setProxyQmgrName(self, qmgrName: str) -> None:
        self.proxyQmgrName = qmgrName

    def to_byte_array(self) -> bytes:
        serialized = bytearray(self.get_msg_length())
        pivot = 0
        header_bytes = self.header.to_byte_array()
        serialized[pivot : pivot + ILC.SZ_JMS_HEADER] = header_bytes
        pivot += ILC.SZ_JMS_HEADER

        ba_merge(self.propertyLength, serialized, pivot)
        pivot += ILC.SZ_LEN

        if self.property is not None and self.propertyLength > 0:
            serialized[pivot : pivot + self.propertyLength] = self.property
            pivot += self.propertyLength

        if self.header.getDataTypeCode() not in (
            ILC.MIMQ_BYTES_DATALESS_MESSAGE,
            ILC.MIMQ_BASIC_MESSAGE,
        ):
            ba_data_len = self.rfh.getSerializedLength()
            if self.proxyQmgrName:
                ba_merge(ba_data_len + 70, serialized, pivot)
                pivot += ILC.SZ_LEN
                qmgr_bytes = self.proxyQmgrName.encode("utf-8")
                serialized[pivot : pivot + len(qmgr_bytes)] = qmgr_bytes
                pivot += 70
            else:
                ba_merge(ba_data_len, serialized, pivot)
                pivot += ILC.SZ_LEN

            if ba_data_len > 0:
                rfh_bytes = self.rfh.to_byte_array()
                if rfh_bytes:
                    serialized[pivot : pivot + self.rfh.getSerializedLength()] = rfh_bytes
        return bytes(serialized)

    def get_msg_length(self) -> int:
        ret = ILC.SZ_JMS_HEADER + ILC.SZ_LEN + self.propertyLength
        if self.header.getDataTypeCode() not in (
            ILC.MIMQ_BYTES_DATALESS_MESSAGE,
            ILC.MIMQ_BASIC_MESSAGE,
        ):
            ret += ILC.SZ_LEN + self.rfh.getSerializedLength()
        if self.proxyQmgrName:
            ret += 70
        return ret

    def getHeader(self) -> JMSHeader:
        return self.header

    def setHeader(self, header: JMSHeader | None) -> None:
        self.header = header if header is not None else JMSHeader()

    def getPropertyLength(self) -> int:
        return self.propertyLength

    def getProperty(self) -> Dict[str, str]:
        ret: Dict[str, str] = {}
        if self.property is None:
            return ret
        iis: ILInputStream | None = None
        try:
            iis = ILInputStream(self.property)
            n_read = 0
            while self.propertyLength > n_read:
                delimiter = iis.read_string(2)
                if delimiter != "ST":
                    raise ILDeserializeException(
                        f"invalid property key delimiter : {delimiter}"
                    )
                key_len_string = iis.read_string_until_null()
                key_len = int(key_len_string)
                key = iis.read_string(key_len)
                delimiter = iis.read_string(2)
                if delimiter != "ST":
                    raise ILDeserializeException(
                        f"invalid property value delimiter : {delimiter}"
                    )
                value_len_string = iis.read_string_until_null()
                value_len = int(value_len_string)
                value = iis.read_string(value_len)
                ret[key] = value
                n_read += (
                    len(key_len_string)
                    + key_len
                    + len(value_len_string)
                    + value_len
                    + 6
                )
        except ILDeserializeException:
            raise
        except Exception as exc:
            raise IOError(str(exc)) from exc
        finally:
            if iis is not None:
                iis.close()
        return ret

    def getPropertyAsByteArray(self) -> Dict[bytes, bytes]:
        ret: Dict[bytes, bytes] = {}
        if self.property is None:
            return ret
        iis: ILInputStream | None = None
        try:
            iis = ILInputStream(self.property)
            n_read = 0
            while self.propertyLength > n_read:
                delimiter = iis.read_string(2)
                if delimiter != "ST":
                    raise ILDeserializeException(
                        f"invalid property key delimiter : {delimiter}"
                    )
                key_len_string = iis.read_string_until_null()
                key_len = int(key_len_string)
                key = iis.read_bytes(key_len) or b""
                delimiter = iis.read_string(2)
                if delimiter != "ST":
                    raise ILDeserializeException(
                        f"invalid property value delimiter : {delimiter}"
                    )
                value_len_string = iis.read_string_until_null()
                value_len = int(value_len_string)
                value = iis.read_bytes(value_len) or b""
                ret[key] = value
                n_read += (
                    len(key_len_string)
                    + key_len
                    + len(value_len_string)
                    + value_len
                    + 6
                )
        except ILDeserializeException:
            raise
        except Exception as exc:
            raise IOError(str(exc)) from exc
        finally:
            if iis is not None:
                iis.close()
        return ret

    def setProperty(self, propertyMap: Dict[str, str] | None) -> None:
        self.propertyLength = 0
        self.property = None
        if propertyMap is None:
            return
        for key, value in propertyMap.items():
            k = len(key.encode("utf-8"))
            v = len(value.encode("utf-8"))
            self.propertyLength += (
                k + v + 6 + len(str(k)) + len(str(v))
            )
        if self.propertyLength == 0:
            return

        null_byte = b"\x00"
        ios: ILOutputStream | None = None
        try:
            ios = ILOutputStream(self.propertyLength)
            for key, value in propertyMap.items():
                ios.write_string(f"ST{len(key.encode('utf-8'))}")
                ios.write_bytes(null_byte)
                ios.write_string(key)
                ios.write_string(f"ST{len(value.encode('utf-8'))}")
                ios.write_bytes(null_byte)
                ios.write_string(value)
            self.property = ios.to_byte_array()
        except Exception as exc:
            raise IOError(str(exc)) from exc
        finally:
            if ios is not None:
                ios.close()

    def setPropertyAsByteArray(self, propertyMap: Dict[bytes, bytes] | None) -> None:
        self.propertyLength = 0
        self.property = None
        if propertyMap is None:
            return
        for key, value in propertyMap.items():
            k = len(key)
            v = len(value)
            self.propertyLength += (
                k + v + 6 + len(str(k)) + len(str(v))
            )
        if self.propertyLength == 0:
            return

        null_byte = b"\x00"
        ios: ILOutputStream | None = None
        try:
            ios = ILOutputStream(self.propertyLength)
            for key, value in propertyMap.items():
                ios.write_string(f"ST{len(key)}")
                ios.write_bytes(null_byte)
                ios.write_bytes(key)
                ios.write_string(f"ST{len(value)}")
                ios.write_bytes(null_byte)
                ios.write_bytes(value)
            self.property = ios.to_byte_array()
        except Exception as exc:
            raise IOError(str(exc)) from exc
        finally:
            if ios is not None:
                ios.close()

    def getRFH(self) -> RFHStruct:
        return self.rfh

    def getDataWithRFHLength(self) -> int:
        return (
            self.lengthOfHeaderOnlyMsg
            if self.header.getDataTypeCode() == ILC.MIMQ_BYTES_DATALESS_MESSAGE
            else self.rfh.getSerializedLength()
        )

    def getDataWithRFH(self) -> bytes | None:
        return self.rfh.to_byte_array()

    def getDataLength(self) -> int:
        return self.dataLength

    def getData(self) -> bytes | None:
        return self.data

    def setData(self, data: bytes | bytearray | None) -> None:
        self.rfh.parse(bytes(data) if data is not None else None)
        self.data = self.rfh.getData()
        self.dataLength = self.rfh.getDataLength()


class ILMsg:
    def __init__(self, *args) -> None:
        self.header = bytearray(ILC.SZ_IL_HEADER)
        self.type = ILC.MIMQ_REQUEST_MESSAGE
        self.length = 0
        self.contentLength = 0
        self.content: ILInnerMsg | None = None

        if len(args) == 2 and isinstance(args[0], int):
            self._init_from_type(args[0], args[1])
            return
        if len(args) == 2 and isinstance(args[0], (bytes, bytearray)):
            self._init_from_length_data(bytes(args[0]), bytes(args[1]))
            return
        if len(args) == 1 and isinstance(args[0], (bytes, bytearray)):
            self._init_from_data(bytes(args[0]))
            return
        raise TypeError("invalid ILMsg arguments")

    def _init_from_type(self, msg_type: int, msg: ILInnerMsg) -> None:
        if msg_type in (
            ILC.MIMQ_DATA_MESSAGE,
            ILC.MIMQ_ARRAY_DATA_MESSAGE,
            ILC.MIMQ_PROXY_DATA_MESSAGE,
            ILC.MIMQ_PROXY_ARRAY_DATA_MESSAGE,
            ILC.MIMQ_LONG_REPORT_MESSAGE,
            ILC.MIMQ_LONG_REQUEST_MESSAGE,
            ILC.MIMQ_PROXY_LONG_REQUEST_MESSAGE,
        ):
            if not isinstance(msg, ILDataMsg):
                raise ILMsgTypeException(msg_type, "inner msg object type must be ILDataMsg")
        elif msg_type in (ILC.MIMQ_REQUEST_MESSAGE, ILC.MIMQ_PROXY_REQUEST_MESSAGE):
            if not isinstance(msg, ILRequestMsg):
                raise ILMsgTypeException(msg_type, "inner msg object type must be ILRequestMsg")
        elif msg_type == ILC.MIMQ_REPORT_MESSAGE:
            if not isinstance(msg, ILReportMsg):
                raise ILMsgTypeException(msg_type, "inner msg object type must be ILReportMsg")
        else:
            raise ILMsgTypeException(msg_type, "unknown msg type")

        self.type = msg_type
        self.content = msg
        self.contentLength = msg.get_msg_length()
        self.length = self.contentLength + ILC.SZ_IL_HEADER

        ba_merge(self.length, self.header, 0)
        ba_merge(self.type, self.header, ILC.SZ_LEN)
        ba_merge(self.contentLength, self.header, ILC.SZ_LEN + ILC.SZ_CODE)

    def _init_from_length_data(self, length_bytes: bytes, data: bytes) -> None:
        try:
            self.header[:10] = length_bytes[:10]
            self.header[10:25] = data[:15]
            self._parse_header()
            ba_content = data[15 : 15 + self.contentLength]
            self._parse_content(ba_content)
        except Exception as exc:
            raise ILException(exc) from exc

    def _init_from_data(self, data: bytes) -> None:
        try:
            self.header[:25] = data[:25]
            self._parse_header()
            ba_content = data[25 : 25 + self.contentLength]
            self._parse_content(ba_content)
        except Exception as exc:
            raise ILException(exc) from exc

    def _parse_header(self) -> None:
        self.length = ba_pick_int(self.header, 0, ILC.SZ_LEN)
        self.type = ba_pick_int(self.header, ILC.SZ_LEN, ILC.SZ_CODE)
        self.contentLength = ba_pick_int(self.header, ILC.SZ_LEN + ILC.SZ_CODE, ILC.SZ_LEN)

    def _update_header(self) -> None:
        ba_merge(self.length, self.header, 0)
        ba_merge(self.type, self.header, ILC.SZ_LEN)
        ba_merge(self.contentLength, self.header, ILC.SZ_LEN + ILC.SZ_CODE)

    def _parse_content(self, content: bytes) -> None:
        try:
            if self.type == ILC.MIMQ_REQUEST_MESSAGE:
                self.content = ILRequestMsg(content)
            elif self.type == ILC.MIMQ_LONG_REQUEST_MESSAGE:
                self.content = ILDataMsg(content)
            elif self.type == ILC.MIMQ_REPORT_MESSAGE:
                self.content = ILReportMsg(content)
            elif self.type == ILC.MIMQ_LONG_REPORT_MESSAGE:
                self.content = ILDataMsg(content)
            elif self.type in (ILC.MIMQ_DATA_MESSAGE, ILC.MIMQ_ARRAY_DATA_MESSAGE):
                data_msg = ILDataMsg(content)
                data_msg.getHeader().setTimeStamp(data_msg.getHeader().getInternalTimeStamp())
                self.content = data_msg
            else:
                raise ILMsgTypeException(self.type, "unknown msg type")
        except Exception as exc:
            raise ILException(exc) from exc

    def to_byte_array(self, attach_transfer_delimiter: bool) -> bytes:
        self.contentLength = self.content.get_msg_length() if self.content else 0
        self.length = self.contentLength + ILC.SZ_IL_HEADER
        self._update_header()
        array_length = self.length + (1 if attach_transfer_delimiter else 0)
        serialized = bytearray(array_length)
        serialized[: ILC.SZ_IL_HEADER] = self.header
        if self.contentLength and self.content is not None:
            serialized[
                ILC.SZ_IL_HEADER : ILC.SZ_IL_HEADER + self.contentLength
            ] = self.content.to_byte_array()
        if attach_transfer_delimiter:
            serialized[array_length - 1] = ord("\n")
        return bytes(serialized)

    def get_msg_length(self) -> int:
        return self.length

    def getRequestMsg(self) -> ILRequestMsg:
        if self.type != ILC.MIMQ_REQUEST_MESSAGE:
            raise ILMsgTypeException(self.type, "msg type must be [MIMQ_REQUEST_MESSAGE]")
        if self.content is None:
            raise ILMsgTypeException(self.type, "inner msg is null")
        if not isinstance(self.content, ILRequestMsg):
            raise ILMsgTypeException(self.type, "inner msg object type is not ILRequestMsg")
        return self.content

    def getReportMsg(self) -> ILReportMsg:
        if self.type != ILC.MIMQ_REPORT_MESSAGE:
            raise ILMsgTypeException(self.type, "msg type must be [MIMQ_REPORT_MESSAGE]")
        if self.content is None:
            raise ILMsgTypeException(self.type, "inner msg is null")
        if not isinstance(self.content, ILReportMsg):
            raise ILMsgTypeException(self.type, "inner msg object type is not ILReportMsg")
        return self.content

    def getDataMsg(self) -> ILDataMsg:
        if not isinstance(self.content, ILDataMsg):
            raise ILMsgTypeException(self.type, "inner msg object type is not ILDataMsg")
        return self.content

    def getType(self) -> int:
        return self.type

    def getTypeString(self) -> str:
        if self.type == ILC.MIMQ_REQUEST_MESSAGE:
            return "MIMQ_REQUEST_MESSAGE"
        if self.type == ILC.MIMQ_REPORT_MESSAGE:
            return "MIMQ_REPORT_MESSAGE"
        if self.type == ILC.MIMQ_DATA_MESSAGE:
            return "MIMQ_DATA_MESSAGE"
        if self.type == ILC.MIMQ_LONG_REQUEST_MESSAGE:
            return "MIMQ_LONG_REQUEST_MESSAGE"
        if self.type == ILC.MIMQ_LONG_REPORT_MESSAGE:
            return "MIMQ_LONG_REPORT_MESSAGE"
        if self.type == ILC.MIMQ_PROXY_REQUEST_MESSAGE:
            return "MIMQ_PROXY_REQUEST_MESSAGE"
        if self.type == ILC.MIMQ_PROXY_LONG_REQUEST_MESSAGE:
            return "MIMQ_PROXY_LONG_REQUEST_MESSAGE"
        if self.type == ILC.MIMQ_PROXY_DATA_MESSAGE:
            return "MIMQ_PROXY_DATA_MESSAGE"
        return f"UNKNOWN MSG-TYPE CODE [{self.type}]"

    def toByteArray(self, attach_transfer_delimiter: bool) -> bytes:
        return self.to_byte_array(attach_transfer_delimiter)

    def getMsgLength(self) -> int:
        return self.get_msg_length()


class ILMsgUtil:
    def __init__(self) -> None:
        raise RuntimeError("ILMsgUtil is a static utility class")

    @staticmethod
    def create_request_msg(code: int, *args: str) -> ILMsg:
        return ILMsgUtil.create_request_msg_with_qmgr("", code, None, *args)

    @staticmethod
    def create_request_msg_with_ext(code: int, ext: bytes | None, *args: str) -> ILMsg:
        return ILMsgUtil.create_request_msg_with_qmgr("", code, ext, *args)

    @staticmethod
    def create_request_msg_with_qmgr(
        qmgr_name: str, code: int, ext: bytes | None = None, *args: str
    ) -> ILMsg:
        arg1 = args[0] if len(args) > 0 else ""
        arg2 = args[1] if len(args) > 1 else ""
        arg3 = args[2] if len(args) > 2 else ""
        inner_msg = ILRequestMsg(code, arg1, arg2, arg3)
        is_proxy = qmgr_name != ""
        if is_proxy:
            name = qmgr_name.encode("utf-8")
            if ext is None:
                ba = bytearray(70)
                ba[: len(name)] = name
            else:
                ba = bytearray(70 + len(ext))
                ba[: len(name)] = name
                ba[70 : 70 + len(ext)] = ext
            inner_msg.set_extension(bytes(ba))
        else:
            inner_msg.set_extension(ext)
        return ILMsg(
            ILC.MIMQ_PROXY_REQUEST_MESSAGE if is_proxy else ILC.MIMQ_REQUEST_MESSAGE,
            inner_msg,
        )

    @staticmethod
    def create_long_request_msg(code: int, ba: bytes) -> ILMsg:
        length = len(ba) + ILC.MIMQ_LONG_REQUEST_CODE_LENGTH
        offset = 0
        buffer = bytearray(length)
        ba_merge(code, buffer, offset)
        offset += ILC.MIMQ_LONG_REQUEST_CODE_LENGTH
        buffer[offset : offset + len(ba)] = ba
        return ILMsg(ILC.MIMQ_LONG_REQUEST_MESSAGE, ILDataMsg(JMSHeader(), None, bytes(buffer)))

    @staticmethod
    def create_long_request_msg_with_qmgr(qmgr_name: str, code: int, ba: bytes) -> ILMsg:
        length = len(ba) + 70 + ILC.MIMQ_LONG_REQUEST_CODE_LENGTH
        offset = 0
        buffer = bytearray(length)
        ba_merge(qmgr_name, buffer, offset)
        offset += 70
        ba_merge(code, buffer, offset)
        offset += ILC.MIMQ_LONG_REQUEST_CODE_LENGTH
        buffer[offset : offset + len(ba)] = ba
        return ILMsg(
            ILC.MIMQ_PROXY_LONG_REQUEST_MESSAGE,
            ILDataMsg(JMSHeader(), None, bytes(buffer)),
        )

    @staticmethod
    def create_data_msg(msg: ILDataMsg) -> ILMsg:
        msg.setProxyQmgrName("")
        return ILMsg(ILC.MIMQ_DATA_MESSAGE, msg)

    @staticmethod
    def create_proxy_data_msg(qmgr_name: str, msg: ILDataMsg) -> ILMsg:
        msg.setProxyQmgrName(qmgr_name)
        return ILMsg(ILC.MIMQ_PROXY_DATA_MESSAGE, msg)

    @staticmethod
    def parse_data_msg(cls: Type[T], msg: ILMsg) -> List[T]:
        offset = 0
        ba = msg.getDataMsg().getData() or b""
        is_large_array = cls in (ILSessionMinorProperty, ILSessionProperty)
        count_length = (
            ILC.MIMQ_LARGE_LIST_ITEM_COUNT_LENGTH
            if is_large_array
            else ILC.MIMQ_LIST_ITEM_COUNT_LENGTH
        )
        count = ba_pick_int(ba, offset, count_length)
        offset += count_length

        if cls is ILServiceProperty:
            serialized_length = ILC.MIMQ_VO_SERVER_LEN
        elif cls is ILAccessRuleProperty:
            serialized_length = ILC.MIMQ_VO_ACCESSRULE_LEN
        elif cls is ILSessionProperty:
            serialized_length = ILC.MIMQ_VO_SESSION_LEN
        elif cls is ILQmgrProperty:
            serialized_length = ILC.MIMQ_VO_QMGR_LEN
        elif cls is ILQueueProperty:
            serialized_length = ILC.MIMQ_VO_QUEUE_LEN
        elif cls is ILChannelProperty:
            serialized_length = ILC.MIMQ_VO_CHANNEL_LEN
        elif cls is ILSpokeProperty:
            serialized_length = ILC.MIMQ_VO_SPOKEINFO_LEN
        elif cls is ILSecureFileProperty:
            serialized_length = ILC.MIMQ_VO_CERTFILE_LEN
        elif cls is ILQmgrMinorProperty:
            serialized_length = ILC.MIMQ_VO_MINOR_MGR_LEN
        elif cls is ILSessionMinorProperty:
            serialized_length = ILC.MIMQ_VO_MINOR_SES_LEN
        elif cls in (
            ILQueueMinorProperty,
            ILLocalQueueMinorProperty,
            ILRemoteQueueMinorProperty,
            ILXmitQueueMinorProperty,
        ):
            serialized_length = ILC.MIMQ_VO_MINOR_QUE_LEN
        elif cls in (
            ILChannelMinorProperty,
            ILClientSendChannelMinorProperty,
            ILServerRecvChannelMinorProperty,
            ILServerSendChannelMinorProperty,
            ILClientRecvChannelMinorProperty,
        ):
            serialized_length = ILC.MIMQ_VO_MINOR_CHL_LEN
        elif cls is ILQueueFlow:
            serialized_length = ILC.MIMQ_VO_QUEUE_FLOW_LEN
        else:
            raise ILDeserializeException(f"{cls.__name__} is unsupported object type.")

        items: List[T] = []
        is_channel = serialized_length == ILC.MIMQ_VO_CHANNEL_LEN
        for _ in range(count):
            try:
                if is_channel:
                    item = cls(ba_pick_bytes(ba, offset))  # type: ignore[call-arg]
                    serialized_length = (
                        item.get_dest_group_buffer_length() + ILC.MIMQ_VO_CHANNEL_LEN
                    )
                else:
                    item = cls(  # type: ignore[call-arg]
                        ba_pick_bytes(ba, offset, serialized_length)
                    )
            except Exception as exc:
                raise ILDeserializeException(
                    f"failed to create instance of class {cls.__name__}", exc
                ) from exc
            items.append(item)
            offset += serialized_length
        return items
