from __future__ import annotations

from .admin import ILAdminQmgr, ILAdminService
from .common import ILC
from .properties import (
    DestItem,
    ILChannelDirection,
    ILChannelProperty,
    ILChannelSecurity,
    ILChannelType,
    ILQueueProperty,
)
from .exception import ILException

HOST = "10.10.1.95"
PORT = 9998
QMGR = "TEST"


def list_qmgrs(service: ILAdminService):
    qmgr_list = service.getQmgrList()
    for qmgr in qmgr_list:
        print(qmgr.name)
    return qmgr_list


def create_local_queue(service: ILAdminService, qmgr_name: str = QMGR) -> None:
    qmgr = service.accessAdminQmgr(qmgr_name)
    queue_prop = ILQueueProperty("PYTEST.LQ", ILC.MIMQ_LOCAL_PERSISTENT)
    qmgr.createQueue(queue_prop)
    print("created:", queue_prop.name)


def create_qmgr(service: ILAdminService, name: str, port: int) -> None:
    service.createQmgr(name, port)


def create_channel(
    qmgr: ILAdminQmgr,
    name: str,
    channel_type: ILChannelType,
    direction: ILChannelDirection,
    dest_items: list[DestItem],
    security: ILChannelSecurity,
) -> None:
    prop = ILChannelProperty(name, channel_type, direction)
    prop.security = security
    prop.destGroup = dest_items
    qmgr.createChannel(prop)


def start_channel(qmgr: ILAdminQmgr, channel_name: str) -> None:
    qmgr.startChannel(channel_name)


def list_qmgr_sessions(qmgr: ILAdminQmgr):
    return qmgr.getSessionList()


def example_dest_items() -> list[DestItem]:
    return [
        DestItem("TEST", "10.10.1.95", 19998),
    ]


if __name__ == "__main__":
    service = ILAdminService()
    try:
        print("[1/4] service connect...")
        service.connect(HOST, PORT, "PYTEST")
        print("connected")

        print("[2/4] list qmgrs...")
        qmgrs = list_qmgrs(service)
        print(f"qmgr count: {len(qmgrs)}")

        print("[3/4] create local queue...")
        # create_local_queue(service)
        print("queue created")

        print("[4/4] channel/session tests...")
        qmgr = service.accessAdminQmgr(QMGR)
        sessions = list_qmgr_sessions(qmgr)
        print(f"session count: {len(sessions)}")

        dest_items = example_dest_items()
        print(f"dest items: {len(dest_items)}")
        create_channel(
            qmgr,
            "PYTEST.CHL3",
            ILChannelType.CLIENT,
            ILChannelDirection.SEND,
            dest_items,
            ILChannelSecurity.NONE,
        )
        cp = qmgr.getChannelProperty("PYTEST.CHL")
        print(cp)
    except ILException as e:
        print(e.get_message())
    finally:
        service.disconnect()
        print("disconnected")
