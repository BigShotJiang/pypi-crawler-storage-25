"""Request/Result-Modelle und Events für die öffentliche API."""

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path


@dataclass
class PosterSpec:
    """Parameter für die Vorschaubild-Auswahl."""

    frame_number: int | None = None
    timestamp_seconds: float | None = None
    crop_position: str | None = None


@dataclass
class InfuseProfile:
    """Aktiviert das Infuse-Medienset: Original-Video + Artworks + NFO."""

    output_dir: Path


@dataclass
class WebProfile:
    """Aktiviert das Web-Medienset: HTML + komprimiertes Video + optional ZIP."""

    output_dir: Path
    include_zip: bool = True
    enable_og_tags: bool = True


@dataclass
class CreateMediasetRequest:
    """Fachlicher Request zur Erstellung eines Mediasets (ein Video).

    Attributes:
        source_path: Pfad zur Videodatei.
        title: Titel des Videos. Wird auch als H1-Überschrift verwendet,
            sofern mediaset_title nicht gesetzt ist.
        mediaset_title: Optionaler H1-Titel, falls abweichend vom Video-Titel.
        recording_date: Aufnahmedatum im ISO-Format (YYYY-MM-DD).
        poster: Parameter für die Vorschaubild-Auswahl.
        work_dir: Arbeitsverzeichnis für temporäre Dateien (Thumbnails, NFO).
            Default: Verzeichnis der Quelldatei.
        force: Erzwingt Neuerstellung auch wenn Video bereits vorhanden ist.
    """

    source_path: Path
    title: str | None = None
    description: str | None = None
    category: str | None = None
    recording_date: str | None = None
    poster: PosterSpec | None = None
    mediaset_title: str | None = None
    work_dir: Path | None = None
    infuse: InfuseProfile | None = None
    web: WebProfile | None = None
    web_id: str | None = None    # Hidden-Link-ID (12-stellig, a-z 0-9). Default: auto-generiert
    max_luminance: int | None = None
    force: bool = False


@dataclass
class RuntimeOptions:
    """Technische Laufzeitoptionen, getrennt vom fachlichen Request."""

    base_url: str = ""
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"


@dataclass
class InfuseResult:
    """Ergebnis des Infuse-Profils."""

    output_dir: Path
    video_path: Path
    landscape_path: Path
    portrait_path: Path
    nfo_path: Path


@dataclass
class WebResult:
    """Ergebnis des Web-Profils."""

    output_dir: Path
    web_id: str
    html_path: Path
    video_path: Path
    landscape_path: Path
    zip_path: Path | None = None


@dataclass
class MediasetResult:
    """Ergebnis der Mediaset-Erstellung."""

    success: bool
    infuse: InfuseResult | None = None
    web: WebResult | None = None
    error_message: str | None = None


class MediasetCreatorStage(StrEnum):
    """Stable stage IDs for structured events."""

    MEDIASET_STARTED = "mediaset_started"
    VIDEO_ANALYZED = "video_analyzed"
    THUMBNAILS_CREATED = "thumbnails_created"
    NFO_CREATED = "nfo_created"
    INFUSE_READY = "infuse_ready"
    VIDEO_COPIED = "video_copied"
    VIDEO_SKIPPED = "video_skipped"
    VIDEO_COMPRESSED = "video_compressed"
    VIDEO_RECOMPRESSED = "video_recompressed"
    ZIP_CREATED = "zip_created"
    HTML_GENERATED = "html_generated"
    WEB_READY = "web_ready"
    MEDIASET_COMPLETED = "mediaset_completed"


@dataclass
class MediasetCreatorEvent:
    """Strukturiertes Event für Fortschrittsinformationen."""

    stage_id: str
    message: str
    paths: dict[str, Path] | None = None
