"""API-Fassade: Öffentliche Schnittstelle des Mediaset Creators."""

from collections.abc import Callable

from .models import (
    CreateMediasetRequest,
    MediasetCreatorEvent,
    MediasetResult,
    RuntimeOptions,
)


def create_mediaset(
    request: CreateMediasetRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediasetCreatorEvent], None] | None = None,
) -> MediasetResult:
    """Erstellt ein Mediaset aus einer Videodatei.

    Mindestens ein Ausgabe-Profil (infuse oder web) muss im Request gesetzt sein.

    Args:
        request: Fachlicher Request mit Videodatei, Metadaten und Profilen.
        runtime: Technische Laufzeitoptionen (Pfade, URLs). Optional.
        on_event: Optionaler Callback für strukturierte Fortschritts-Events.

    Returns:
        MediasetResult mit Erfolg/Fehler und profil-basierten Ergebnissen.
    """
    if request.infuse is None and request.web is None:
        return MediasetResult(
            success=False,
            error_message="Mindestens ein Profil (infuse oder web) muss angegeben werden.",
        )

    from mediaset_creator.core.mediaset_assembler import assemble_mediaset

    try:
        return assemble_mediaset(request, runtime, on_event)
    except Exception as e:
        return MediasetResult(success=False, error_message=str(e))
