"""CLI-Adapter für den Mediaset Creator."""

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from mediaset_creator.api import (
    CreateMediasetRequest,
    InfuseProfile,
    MediasetCreatorEvent,
    MediasetCreatorStage,
    PosterSpec,
    RuntimeOptions,
    WebProfile,
    create_mediaset,
)
from mediaset_creator.services import config_manager

app = typer.Typer(invoke_without_command=True)
config_app = typer.Typer()
app.add_typer(config_app, name="config", help="Konfiguration verwalten.")

stderr_console = Console(stderr=True)


@app.callback()
def main(ctx: typer.Context) -> None:
    """Mediaset Creator – Erstellt Mediensets aus Videodateien."""
    if ctx.invoked_subcommand is None:
        ctx.get_help()


@app.command(name="create")
def create_cmd(
    video: Path = typer.Argument(
        ...,
        help="Pfad zur Videodatei.",
        exists=True,
        dir_okay=False,
    ),
    title: Optional[str] = typer.Option(
        None,
        "--title",
        help="Titel des Videos (auch H1-Überschrift, sofern --mediaset-title nicht gesetzt).",
    ),
    mediaset_title: Optional[str] = typer.Option(
        None,
        "--mediaset-title",
        help="Optionaler H1-Titel, falls abweichend vom Video-Titel.",
    ),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        help="Beschreibung des Videos.",
    ),
    category: Optional[str] = typer.Option(
        None,
        "--category",
        help="Kategorie des Videos.",
    ),
    recording_date: Optional[str] = typer.Option(
        None,
        "--date",
        help="Aufnahmedatum im ISO-Format (YYYY-MM-DD).",
    ),
    max_luminance: Optional[int] = typer.Option(
        None,
        "--max-luminance",
        help="Peak-Leuchtdichte in nits (MaxCLL) für HDR-Metadaten. Default: 1000.",
    ),
    infuse_dir: Optional[Path] = typer.Option(
        None,
        "--infuse-dir",
        help="Zielverzeichnis für Infuse-Medienset (aktiviert Infuse-Profil).",
    ),
    web_dir: Optional[Path] = typer.Option(
        None,
        "--web-dir",
        help="Basisverzeichnis für Web-Medienset (Web-ID-Unterordner wird erstellt).",
    ),
    web_id: Optional[str] = typer.Option(
        None,
        "--web-id",
        help="Web-ID übersteuern (12 Zeichen, a-z 0-9). Default: auto-generiert.",
    ),
    no_zip: bool = typer.Option(
        False,
        "--no-zip",
        help="Kein ZIP im Web-Profil.",
    ),
    no_og_tags: bool = typer.Option(
        False,
        "--no-og-tags",
        help="OG-Tags im Web-Profil deaktivieren.",
    ),
    work_dir: Optional[Path] = typer.Option(
        None,
        "--work-dir",
        help="Arbeitsverzeichnis für temporäre Dateien. Default: Verzeichnis der Quelldatei.",
    ),
    poster_frame: Optional[int] = typer.Option(
        None,
        "--poster-frame",
        help="Video-Framenummer für Vorschaubild.",
    ),
    poster_at: Optional[float] = typer.Option(
        None,
        "--poster-at",
        help="Zeitpunkt in Sekunden für Vorschaubild-Frame.",
    ),
    poster_crop: Optional[str] = typer.Option(
        None,
        "--poster-crop",
        help="Bildausschnitt für Poster (left/center-left/center/center-right/right).",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Erzwingt Neuerstellung aller Dateien.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Zusätzliche Ablaufinformationen auf stderr ausgeben.",
    ),
) -> None:
    """Erstellt ein Mediaset aus einer Videodatei."""
    # Default: Ohne Profile → Web-Medienset im Quellverzeichnis
    if infuse_dir is None and web_dir is None:
        web_dir = video.parent

    # Titel: --title ist der Video-Titel, Fallback auf Dateiname
    effective_title = title
    if not effective_title:
        use_filename = config_manager.get_with_default("title.filename_fallback").lower() != "false"
        if use_filename:
            effective_title = video.stem

    # PosterSpec nur erstellen wenn mindestens ein Poster-Parameter gesetzt
    poster = None
    if poster_frame is not None or poster_at is not None or poster_crop is not None:
        poster = PosterSpec(
            frame_number=poster_frame,
            timestamp_seconds=poster_at,
            crop_position=poster_crop,
        )

    # Profile aufbauen
    infuse_profile = InfuseProfile(output_dir=infuse_dir) if infuse_dir else None

    web_profile = None
    if web_dir:
        og_enabled = not no_og_tags
        if og_enabled:
            og_enabled_cfg = config_manager.get_with_default("branding.enabled")
            if og_enabled_cfg.lower() == "false":
                og_enabled = False
        web_profile = WebProfile(
            output_dir=web_dir,
            include_zip=not no_zip,
            enable_og_tags=og_enabled,
        )

    request = CreateMediasetRequest(
        source_path=video,
        title=effective_title,
        description=description,
        category=category,
        recording_date=recording_date,
        poster=poster,
        mediaset_title=mediaset_title,
        work_dir=work_dir,
        infuse=infuse_profile,
        web=web_profile,
        web_id=web_id,
        max_luminance=max_luminance,
        force=force,
    )

    # RuntimeOptions aus Config
    runtime = RuntimeOptions(
        base_url=config_manager.get_with_default("branding.base_url"),
        ffmpeg_path=config_manager.get_with_default("tools.ffmpeg"),
        ffprobe_path=config_manager.get_with_default("tools.ffprobe"),
    )

    # Event-Callback
    ALWAYS_SHOW = {
        MediasetCreatorStage.VIDEO_COMPRESSED,
        MediasetCreatorStage.VIDEO_SKIPPED,
        MediasetCreatorStage.INFUSE_READY,
        MediasetCreatorStage.WEB_READY,
    }

    def on_event(event: MediasetCreatorEvent) -> None:
        if not verbose and event.stage_id not in ALWAYS_SHOW:
            return
        stderr_console.print(f"  {event.message}")

    result = create_mediaset(request, runtime, on_event=on_event)

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    # Ergebnis auf stdout
    if result.infuse and result.web:
        output = json.dumps({
            "infuse": str(result.infuse.output_dir),
            "web": str(result.web.output_dir),
        })
        print(output)
    elif result.web:
        print(result.web.output_dir)
    elif result.infuse:
        print(result.infuse.output_dir)


# --- Config-Subcommands ---

@config_app.command(name="set")
def config_set_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel (z.B. 'branding.base_url')."),
    value: str = typer.Argument(..., help="Wert."),
) -> None:
    """Speichert einen Konfigurationswert."""
    if not config_manager.set_value(key, value):
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        stderr_console.print("Erlaubte Schlüssel:")
        for k, (desc, default) in config_manager.ALLOWED_KEYS.items():
            stderr_console.print(f"  {k}: {desc} (Standard: {default or '(leer)'})")
        raise typer.Exit(code=2)
    stderr_console.print(f"Gespeichert: {key} = {value}")


@config_app.command(name="get")
def config_get_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel."),
) -> None:
    """Liest einen Konfigurationswert."""
    if key not in config_manager.ALLOWED_KEYS:
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        raise typer.Exit(code=2)
    val = config_manager.get(key)
    if val is None:
        desc, default = config_manager.ALLOWED_KEYS[key]
        stderr_console.print(f"(nicht gesetzt, Standard: {default or '(leer)'})")
    else:
        print(val)


@config_app.command(name="list")
def config_list_cmd() -> None:
    """Zeigt alle konfigurierten Werte an."""
    stored = config_manager.list_all()
    if not stored:
        stderr_console.print("Keine Konfigurationswerte gespeichert.")
        stderr_console.print(f"Konfigurationsdatei: {config_manager.CONFIG_PATH}")
        return
    for key, val in sorted(stored.items()):
        print(f"{key} = {val}")
