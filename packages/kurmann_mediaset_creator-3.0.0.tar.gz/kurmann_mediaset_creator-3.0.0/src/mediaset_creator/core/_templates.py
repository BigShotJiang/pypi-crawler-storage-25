"""Built-in Jinja2-Templates für die HTML-Generierung."""

INDEX_TEMPLATE = """\
<!DOCTYPE html>
<html lang="de-CH">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% if item.category %}{{ item.category }} \u2013 {% endif %}{{ mediaset_title }}</title>
{% if branding.enabled and og_url %}
    <!-- OpenGraph Metadaten -->
    <meta property="og:title" content="{{ item.title or mediaset_title }}" />
    <meta property="og:type" content="video.movie" />
    <meta property="og:url" content="{{ og_url }}" />
{% if og_image_url %}
    <meta property="og:image" content="{{ og_image_url }}" />
    <meta property="og:image:secure_url" content="{{ og_image_url }}" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="1920" />
    <meta property="og:image:height" content="1080" />
{% endif %}
{% if item.description %}
    <meta property="og:description" content="{{ item.description }}" />
    <meta name="description" content="{{ item.description }}" />
{% endif %}
{% if branding.locale %}
    <meta property="og:locale" content="{{ branding.locale }}" />
{% endif %}
{% if branding.site_name %}
    <meta property="og:site_name" content="{{ branding.site_name }}" />
{% endif %}
{% endif %}
    <style>
        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: #bbb;
            background-color: #000;
            line-height: 1.5;
        }

        main {
            max-width: 1440px;
            margin: 0 auto;
            padding: 1.5rem 1rem;
        }

        /* Header-Bereich */
        .site-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .site-name {
            font-size: 0.8rem;
            color: #666;
            letter-spacing: 0.15em;
            text-transform: uppercase;
            margin-bottom: 0.3rem;
        }

        h1 {
            text-align: center;
            font-size: 1.8rem;
            font-weight: 600;
            color: #ddd;
            margin-bottom: 0.3rem;
        }

        .duration-info {
            text-align: center;
            font-size: 0.95rem;
            color: #888;
            margin-bottom: 0.8rem;
        }

        /* Technische Specs (dezent unterhalb des Videos) */
        .tech-specs {
            margin-top: 1.5rem;
            font-size: 0.78rem;
            color: #666;
            text-align: center;
            line-height: 1.7;
        }
        .tech-specs .spec-label {
            color: #555;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-size: 0.7rem;
            margin-right: 0.4rem;
        }
        .tech-specs .spec-value {
            font-variant-numeric: tabular-nums;
        }
        .tech-specs > div {
            margin-bottom: 0.15rem;
        }

        .privacy-notice {
            text-align: center;
            font-size: 0.78rem;
            color: #555;
            max-width: 600px;
            margin: 0 auto 2rem auto;
            line-height: 1.6;
        }

        a {
            color: #0071c1;
        }

        /* Video-Container */
        .mediaset-item {
            margin-bottom: 3rem;
        }

        .video-container {
            position: relative;
            display: block;
            overflow: hidden;
            cursor: pointer;
        }

        .video-container img {
            width: 100%;
            height: auto;
            display: block;
            border: 1px solid #444;
        }

        /* Play-Icon */
        .play-icon {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            height: 20%;
            opacity: 0.7;
            pointer-events: none;
            transition: opacity 0.2s;
            filter: drop-shadow(0 0 12px rgba(0, 0, 0, 0.7));
        }

        .video-container:hover .play-icon {
            opacity: 0.9;
        }

        /* Badges (Kategorie, Qualitaet, Datum) */
        .badge {
            position: absolute;
            color: #fff;
            background-color: rgba(0, 0, 0, 0.55);
            padding: 5px 12px;
            letter-spacing: 0.1em;
            font-size: 0.8em;
            white-space: nowrap;
        }

        .badge-category {
            top: 3%;
            left: 0;
        }

        .badge-date {
            bottom: 3%;
            left: 0;
        }

        .badge svg {
            vertical-align: middle;
            margin-right: 6px;
        }

        /* Beschreibung */
        .item-description {
            text-align: center;
            margin-top: 0.8rem;
            font-size: 1rem;
        }

        /* Download-Bereich */
        .item-download {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.9rem;
        }

        .item-download a {
            color: #999;
            text-decoration: underline;
        }

        .item-download a:hover {
            color: #ccc;
        }

        .download-note {
            text-align: center;
            margin-top: 0.4rem;
            font-size: 0.75rem;
            color: #555;
        }

        /* Meta-Informationen */
        .meta-info {
            text-align: center;
            margin-top: 1.2rem;
            font-size: 0.75rem;
            color: #444;
        }

        /* Footer */
        footer {
            text-align: center;
            opacity: 0.5;
            font-size: 0.85rem;
            margin-top: 2rem;
            padding: 1rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            main {
                padding: 1rem 0.5rem;
            }

            h1 {
                font-size: 1.4rem;
            }
        }
    </style>
</head>

<body>
    <main>
        <div class="site-header">
{% if branding.site_name %}
            <p class="site-name">{{ branding.site_name }}</p>
{% endif %}
            <h1>{{ mediaset_title }}</h1>
{% if item.duration_seconds > 0 %}
            <p class="duration-info">{{ item.duration_seconds | duration }}</p>
{% endif %}
            <p class="privacy-notice">
                Dies ist ein privater Link. Das Video ist nicht &ouml;ffentlich zug&auml;nglich.<br>
                Der Link ist in der Regel einen Monat g&uuml;ltig. Bitte den Download nutzen, um das Original zu behalten.
            </p>
        </div>
        <div class="mediaset-item">
            <a class="video-container" href="{{ item.video_filename | e }}" aria-label="{{ item.title or 'Video abspielen' }}">
                <img src="{{ item.landscape_filename | e }}" alt="{{ item.title or 'Vorschaubild' }}">
                <svg class="play-icon" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" fill="#ffffff">
                    <rect width="48" height="48" fill="none"/>
                    <circle cx="24" cy="24" r="22" fill="rgba(0,0,0,0.35)" stroke="#ffffff" stroke-width="1.5"/>
                    <path d="M34.6,23.3,18.1,13.2c-.6-.4-1.1-.1-1.1.6V34.2c0,.7.5,1,1.1.6L34.6,24.7A.8.8,0,0,0,34.6,23.3Z"/>
                </svg>
{% if item.category %}
                <span class="badge badge-category">{{ item.category }}</span>
{% endif %}
{% if item.recording_date %}
                <span class="badge badge-date">
                    <svg width="16" height="16" viewBox="0 0 32 32" fill="#ffffff" xmlns="http://www.w3.org/2000/svg">
                        <path d="M234,543 L228,538 L228,535 L234,531 L234,543 Z M223,529.012 C220.232,529.012 217.989,526.768 217.989,524 C217.989,521.232 220.232,518.989 223,518.989 C225.768,518.989 228.011,521.232 228.011,524 C228.011,526.768 225.768,529.012 223,529.012 Z M226,541 C226,542.104 225.104,543 224,543 L208,543 C206.896,543 206,542.104 206,541 L206,533 C206,531.896 206.896,531 208,531 L224,531 C225.104,531 226,531.896 226,533 L226,541 Z M206,525 C206,522.791 207.791,521 210,521 C212.209,521 214,522.791 214,525 C214,527.209 212.209,529 210,529 C207.791,529 206,527.209 206,525 Z M234,529 L228,533 C228,531.786 227.448,530.712 226.594,529.979 C228.626,528.753 230,526.546 230,524 C230,520.134 226.866,517 223,517 C219.134,517 216,520.134 216,524 C216,525.962 216.812,527.729 218.111,529 L214.443,529 C215.4,527.937 216,526.544 216,525 C216,521.687 213.313,519 210,519 C206.687,519 204,521.687 204,525 C204,526.809 204.816,528.41 206.082,529.511 C204.847,530.191 204,531.49 204,533 L204,541 C204,543.209 205.791,545 208,545 L224,545 C226.209,545 228,543.209 228,541 L228,540 L234,545 C235.104,545 236,544.104 236,543 L236,531 C236,529.896 235.104,529 234,529 Z" transform="translate(-204, -517)"/>
                    </svg>
                    {{ item.recording_date }}
                </span>
{% endif %}
            </a>
{% if item.description %}
            <p class="item-description">{{ item.description }}</p>
{% endif %}
{% if item.zip_filename %}
            <p class="item-download">
                <a href="{{ item.zip_filename | e }}" download>Original herunterladen in voller Aufl&ouml;sung (ZIP{% if item.zip_size_bytes %}, {{ item.zip_size_bytes | filesize_gb }}{% endif %})</a>
            </p>
            <p class="download-note">Kompatibel mit Infuse &ndash; enth&auml;lt Titelbild, Fanart und Metadaten</p>
{% endif %}
{% if (item.web_specs and item.web_specs.has_data()) or (item.original_specs and item.original_specs.has_data()) %}
            <div class="tech-specs">
{% if item.web_specs and item.web_specs.has_data() %}
                <div><span class="spec-label">Stream</span><span class="spec-value">{{ item.web_specs.format_compact() }}</span></div>
{% endif %}
{% if item.original_specs and item.original_specs.has_data() %}
                <div><span class="spec-label">Original (ZIP)</span><span class="spec-value">{{ item.original_specs.format_compact() }}</span></div>
{% endif %}
            </div>
{% endif %}
        </div>
        <p class="meta-info">Erstellt am {{ created_at }}</p>
    </main>

    <footer>
        <p>&copy; {{ year | default('2026') }} <strong>Mediaset Creator</strong> by Patrick Kurmann</p>
    </footer>
</body>

</html>
"""

TEMPLATES = {
    "index.html": INDEX_TEMPLATE,
}
