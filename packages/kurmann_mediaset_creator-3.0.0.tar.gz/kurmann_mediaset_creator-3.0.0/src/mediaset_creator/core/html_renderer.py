"""HTML-Rendering für Mediasets via Jinja2-Template."""

from dataclasses import dataclass
from datetime import datetime
from urllib.parse import quote

from jinja2 import DictLoader, Environment, select_autoescape

from mediaset_creator.core._templates import TEMPLATES


@dataclass
class BrandingConfig:
    """Konfiguration für sichtbares Branding (Header) und OpenGraph-Tags.

    `site_name` wird sowohl im sichtbaren Header oben als auch im
    OG-Meta-Tag verwendet. `enabled` steuert nur die OG-Tags.
    """

    enabled: bool = True            # OG-Meta-Tags rendern (sichtbares Branding immer aktiv)
    base_url: str = ""              # Stamm-URL für OG-Tags (z.B. https://mediathek.kurmann.swiss/)
    site_name: str = ""             # Sichtbar im Header + OG-Meta
    locale: str = "de_CH"           # OG-Meta locale
    web_id: str = ""                # Wird mit base_url zur vollständigen Video-URL kombiniert


@dataclass
class VideoSpecs:
    """Technische Spezifikationen eines Videos für die HTML-Anzeige."""

    width: int = 0
    height: int = 0
    bitrate_bps: int = 0
    frame_rate: float = 0.0
    bit_depth: int = 0
    color_space_label: str = ""  # z.B. "BT.2020 PQ", "BT.709 SDR"
    codec_name: str = ""

    def has_data(self) -> bool:
        return self.width > 0 and self.height > 0

    def format_compact(self) -> str:
        """Kompakte Anzeige: 'BT.2020 PQ · 2560×1440 · 60 fps · 14 Mbit/s'."""
        parts: list[str] = []
        if self.color_space_label:
            parts.append(self.color_space_label)
        if self.width and self.height:
            parts.append(f"{self.width}×{self.height}")
        if self.frame_rate:
            # "60" statt "60.0" wenn ganzzahlig
            fps_str = f"{int(self.frame_rate)}" if self.frame_rate == int(self.frame_rate) else f"{self.frame_rate:.2f}"
            parts.append(f"{fps_str} fps")
        if self.bitrate_bps:
            mbit = self.bitrate_bps / 1_000_000
            parts.append(f"{mbit:.0f} Mbit/s")
        return " \u00b7 ".join(parts)


@dataclass
class VideoRenderData:
    """Aufbereitete Daten eines Videos für das Template."""

    video_filename: str
    landscape_filename: str
    zip_filename: str | None = None
    title: str | None = None
    description: str | None = None
    category: str | None = None
    recording_date: str | None = None
    duration_seconds: float = 0.0
    zip_size_bytes: int = 0
    web_specs: VideoSpecs | None = None       # Specs des Web-MP4 (gestreamt)
    original_specs: VideoSpecs | None = None  # Specs des Originals (im ZIP)


def _format_duration(seconds: float) -> str:
    """Formatiert Sekunden als 'Xm Ys'."""
    total = int(seconds)
    mins, secs = divmod(total, 60)
    if mins > 0:
        return f"{mins} Min. {secs} Sek."
    return f"{secs} Sek."


def _format_filesize_gb(size_bytes: int) -> str:
    """Formatiert Bytes als GB-Angabe."""
    gb = size_bytes / (1024 ** 3)
    if gb >= 1.0:
        return f"{gb:.1f} GB"
    mb = size_bytes / (1024 ** 2)
    return f"{mb:.0f} MB"


def render_html(
    item: VideoRenderData,
    mediaset_title: str | None = None,
    branding: BrandingConfig | None = None,
    created_at: str | None = None,
) -> str:
    """Rendert das HTML für ein Mediaset (ein Video).

    Args:
        item: Aufbereitete Daten des Videos.
        mediaset_title: Titel für die H1-Überschrift.
        branding: Branding-Konfiguration (Site-Name, OG-Tags, Web-ID).
        created_at: Erstellungsdatum als formatierter String.

    Returns:
        Vollständiger HTML-String.
    """
    branding = branding or BrandingConfig()

    env = Environment(
        loader=DictLoader(TEMPLATES),
        autoescape=select_autoescape(["html"]),
    )
    env.filters["duration"] = _format_duration
    env.filters["filesize_gb"] = _format_filesize_gb
    template = env.get_template("index.html")

    # OG-URL zusammensetzen
    og_url = ""
    og_image_url = ""
    if branding.enabled and branding.base_url and branding.web_id:
        base = branding.base_url.rstrip("/")
        og_url = f"{base}/{branding.web_id}/"
        og_image_url = f"{og_url}{quote(item.landscape_filename)}"

    # Titel-Fallback
    display_title = mediaset_title or item.title or "Medienset"

    return template.render(
        item=item,
        mediaset_title=display_title,
        branding=branding,
        og_url=og_url,
        og_image_url=og_image_url,
        year=datetime.now().year,
        created_at=created_at or datetime.now().strftime("%d.%m.%Y, %H:%M Uhr"),
    )
