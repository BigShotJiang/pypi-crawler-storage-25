"""Videoprobing und -komprimierung via ffprobe/ffmpeg."""

import json
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

INITIAL_CRF = 20
CRF_STEP = 2
MAX_CRF = 28
MAX_BITRATE_BPS = 40_000_000

_HDR_TRANSFERS = {"smpte2084", "arib-std-b67"}
_HDR_PRIMARIES = {"bt2020"}


@dataclass
class VideoInfo:
    """Technische Metadaten eines Videos."""

    width: int
    height: int
    bitrate_bps: int
    codec_name: str
    duration_seconds: float = 0.0
    color_transfer: str = ""
    color_primaries: str = ""
    color_space: str = ""
    frame_rate: float = 0.0
    bit_depth: int = 0  # 8 oder 10 (typisch); 0 = unbekannt
    is_dolby_vision: bool = False  # True wenn DV-Profile/Side-Data erkannt

    @property
    def is_hdr(self) -> bool:
        """True wenn das Video HDR-Signalisierung enthält (PQ, HLG, BT.2020 oder Dolby Vision)."""
        return (
            self.color_transfer in _HDR_TRANSFERS
            or self.color_primaries in _HDR_PRIMARIES
            or self.is_dolby_vision
        )

    @property
    def color_space_label(self) -> str:
        """Menschenlesbare Farbraum-Bezeichnung.

        Beispiele: 'Dolby Vision', 'BT.2020 PQ', 'BT.709 SDR'.
        Dolby Vision hat Vorrang vor reinem PQ-Label, da DV technisch
        auf BT.2020 PQ basiert + zusätzliche Dynamic Metadata enthält.
        """
        if self.is_dolby_vision:
            return "Dolby Vision"
        primaries_label = {
            "bt2020": "BT.2020",
            "bt709": "BT.709",
        }.get(self.color_primaries, self.color_primaries.upper() if self.color_primaries else "")
        transfer_label = {
            "smpte2084": "PQ",
            "arib-std-b67": "HLG",
            "bt709": "SDR",
        }.get(self.color_transfer, "")
        if primaries_label and transfer_label:
            return f"{primaries_label} {transfer_label}"
        return primaries_label or transfer_label or ""

    @property
    def exceeds_4k(self) -> bool:
        """True wenn Auflösung grösser als 4K UHD (3840×2160)."""
        return self.width * self.height > 3840 * 2160

    def exceeds_bitrate_threshold(self, max_bitrate_bps: int = MAX_BITRATE_BPS) -> bool:
        """True wenn Bitrate über dem Schwellwert liegt."""
        return self.bitrate_bps > max_bitrate_bps

    def needs_compression(self, max_bitrate_bps: int = MAX_BITRATE_BPS) -> bool:
        """True wenn Kompression empfohlen wird (>4K oder Bitrate über Schwellwert)."""
        return self.exceeds_4k or self.exceeds_bitrate_threshold(max_bitrate_bps)

    def summary(self) -> str:
        """Lesbare Zusammenfassung für Log-Ausgaben."""
        megapixel = self.width * self.height / 1_000_000
        mbit = self.bitrate_bps / 1_000_000
        hdr_label = " | HDR" if self.is_hdr else ""
        return f"{self.width}×{self.height} ({megapixel:.1f} MP) | {mbit:.0f} Mbit/s | {self.codec_name}{hdr_label}"


@dataclass
class CompressionResult:
    """Ergebnis einer Videokomprimierung."""

    output_path: Path
    final_crf: int
    final_bitrate_bps: int | None
    iterations: int
    encoder: str = "libx265"


def probe_video(source_path: Path, ffprobe_path: str = "ffprobe") -> VideoInfo | None:
    """Analysiert Videoauflösung und Bitrate via ffprobe.

    Returns:
        VideoInfo mit Metadaten, oder None bei Fehler.
    """
    cmd = [
        ffprobe_path,
        "-v", "quiet",
        "-print_format", "json",
        "-show_streams",
        "-show_format",
        str(source_path),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
    except (subprocess.CalledProcessError, FileNotFoundError, json.JSONDecodeError):
        return None

    # Ersten Video-Stream suchen
    video_stream = next(
        (s for s in data.get("streams", []) if s.get("codec_type") == "video"),
        None,
    )
    if not video_stream:
        return None

    try:
        width = int(video_stream["width"])
        height = int(video_stream["height"])
        codec_name = video_stream.get("codec_name", "unbekannt")
        bitrate_bps = int(data["format"]["bit_rate"])
        duration_seconds = float(data["format"].get("duration", 0))
    except (KeyError, ValueError, TypeError):
        return None

    color_transfer = video_stream.get("color_transfer", "")
    color_primaries = video_stream.get("color_primaries", "")
    color_space = video_stream.get("color_space", "")
    frame_rate = _parse_frame_rate(video_stream)
    bit_depth = _parse_bit_depth(video_stream)
    is_dolby_vision = _detect_dolby_vision(video_stream)

    return VideoInfo(
        width=width, height=height, bitrate_bps=bitrate_bps,
        codec_name=codec_name, duration_seconds=duration_seconds,
        color_transfer=color_transfer, color_primaries=color_primaries,
        color_space=color_space,
        frame_rate=frame_rate, bit_depth=bit_depth,
        is_dolby_vision=is_dolby_vision,
    )


def _parse_frame_rate(video_stream: dict) -> float:
    """Extrahiert die Framerate aus ffprobe-Stream-Daten (z.B. '60/1' → 60.0)."""
    for key in ("avg_frame_rate", "r_frame_rate"):
        rate_str = video_stream.get(key, "")
        if "/" not in rate_str:
            continue
        try:
            num, den = rate_str.split("/")
            if int(den) > 0:
                return round(int(num) / int(den), 3)
        except (ValueError, ZeroDivisionError):
            continue
    return 0.0


def _parse_bit_depth(video_stream: dict) -> int:
    """Leitet die Bittiefe aus dem pix_fmt ab (yuv420p10le → 10, yuv420p → 8)."""
    pix_fmt = video_stream.get("pix_fmt", "")
    if "10" in pix_fmt or "p010" in pix_fmt:
        return 10
    if "12" in pix_fmt:
        return 12
    if "yuv" in pix_fmt or "nv12" in pix_fmt or "rgb" in pix_fmt:
        return 8
    return 0


def _detect_dolby_vision(video_stream: dict) -> bool:
    """Erkennt Dolby Vision via Codec-Tag, Side-Data oder Profil.

    DV-Indikatoren:
    - codec_tag_string beginnt mit 'dvh' (HEVC-DV) oder 'dvav' (H.264-DV)
    - side_data_list enthält 'DOVI configuration record'
    - profile enthält 'Dolby Vision'
    """
    codec_tag = video_stream.get("codec_tag_string", "").lower()
    if codec_tag.startswith("dvh") or codec_tag.startswith("dvav"):
        return True

    profile = video_stream.get("profile", "")
    if "dolby vision" in profile.lower():
        return True

    for sd in video_stream.get("side_data_list", []):
        sd_type = sd.get("side_data_type", "").lower()
        if "dovi" in sd_type or "dolby vision" in sd_type:
            return True

    return False


def _has_aac_at(ffmpeg_path: str = "ffmpeg") -> bool:
    """Prüft ob der aac_at-Encoder (AudioToolbox, macOS) verfügbar ist."""
    try:
        result = subprocess.run(
            [ffmpeg_path, "-encoders"],
            capture_output=True, text=True, check=False,
        )
        return "aac_at" in result.stdout
    except FileNotFoundError:
        return False


def _audio_codec(ffmpeg_path: str = "ffmpeg") -> str:
    """Wählt den besten verfügbaren AAC-Encoder."""
    return "aac_at" if _has_aac_at(ffmpeg_path) else "aac"


def _run_ffmpeg(cmd: list[str], nice_level: int | None) -> None:
    """Führt ein ffmpeg-Kommando aus, optional mit nice."""
    if nice_level is not None:
        cmd = ["nice", "-n", str(nice_level)] + cmd
    subprocess.run(cmd, check=True)


def _hdr_x265_params(max_luminance: int) -> str:
    """Baut x265-Parameter für korrekte HDR-Signalisierung.

    Ohne diese Metadaten müssen Player die Peak-Luminanz raten und
    nehmen oft 10'000 nits (PQ-Maximum) an, was zu schlechtem
    Tonemapping auf Geräten mit eingebautem Tonemap führt.

    Args:
        max_luminance: Peak-Leuchtdichte des Masterings in nits (z.B. 1000).

    Mastering Display: Display P3 Primaries (iPhone/iPad Standard),
    D65 White Point. MaxFALL wird auf 40% des MaxCLL geschätzt.
    """
    max_fall = max(1, max_luminance * 4 // 10)
    # L-Werte in 1/10000 nits: Peak * 10000, Min = 1 (0.0001 nits)
    max_l = max_luminance * 10000
    return (
        f"open-gop=0:hdr-opt=1:repeat-headers=1:"
        f"max-cll={max_luminance},{max_fall}:"
        f"master-display=G(13250,34500)B(7500,3000)R(34000,16000)"
        f"WP(15635,16450)L({max_l},1)"
    )


def _build_libx265_cmd(
    ffmpeg_path: str, source_path: Path, output_path: Path,
    crf: int, preset: str, max_luminance: int | None = None,
) -> list[str]:
    """Baut das ffmpeg-Kommando für libx265 Software-Encoding.

    Bei max_luminance != None werden HDR-Metadaten (MaxCLL, Mastering Display)
    in den HEVC-Stream eingebettet.
    """
    x265_params = _hdr_x265_params(max_luminance) if max_luminance else "open-gop=0"
    audio = _audio_codec(ffmpeg_path)
    return [
        ffmpeg_path,
        "-y",
        "-i", str(source_path),
        "-vf", "scale=2560:1440:flags=lanczos",
        "-c:v", "libx265",
        "-preset", preset,
        "-crf", str(crf),
        "-pix_fmt", "yuv420p10le",
        "-tag:v", "hvc1",
        "-x265-params", x265_params,
        "-c:a", audio,
        "-b:a", "192k",
        "-movflags", "+faststart",
        str(output_path),
    ]


def _build_videotoolbox_cmd(
    ffmpeg_path: str, source_path: Path, output_path: Path,
) -> list[str]:
    """Baut das ffmpeg-Kommando für VideoToolbox Hardware-Encoding (Fallback)."""
    return [
        ffmpeg_path,
        "-y",
        "-i", str(source_path),
        "-vf", "scale=2560:1440:flags=lanczos",
        "-c:v", "hevc_videotoolbox",
        "-profile:v", "main10",
        "-pix_fmt", "p010le",
        "-q:v", "65",
        "-tag:v", "hvc1",
        "-g", "30",
        "-c:a", "aac_at",
        "-b:a", "192k",
        "-movflags", "+faststart",
        str(output_path),
    ]


def compress_video(
    source_path: Path,
    output_path: Path,
    ffmpeg_path: str = "ffmpeg",
    ffprobe_path: str = "ffprobe",
    nice_level: int | None = None,
    on_recompress: Callable[[str], None] | None = None,
    initial_crf: int = INITIAL_CRF,
    max_bitrate_bps: int = MAX_BITRATE_BPS,
    preset: str = "slow",
    max_luminance: int | None = None,
) -> CompressionResult:
    """Komprimiert Video zu MP4 (HEVC, 2560×1440).

    Verwendet libx265 Software-Encoding mit CRF-Modus für bestmögliche Qualität.
    Falls libx265 nicht verfügbar ist, wird automatisch auf VideoToolbox (macOS)
    zurückgefallen. Nach der Komprimierung wird die Bitrate geprüft und bei Bedarf
    mit erhöhtem CRF erneut komprimiert.

    Bei max_luminance != None werden HDR-Metadaten (MaxCLL, Mastering Display)
    eingebettet, damit Geräte mit eingebautem Tonemapping korrekt arbeiten.

    Returns:
        CompressionResult mit Pfad, finalem CRF, Bitrate, Iterationsanzahl und Encoder.

    Raises:
        subprocess.CalledProcessError: Wenn ffmpeg auch mit Fallback fehlschlägt.
    """
    crf = initial_crf
    iteration = 0

    while True:
        iteration += 1
        cmd = _build_libx265_cmd(
            ffmpeg_path, source_path, output_path, crf, preset,
            max_luminance=max_luminance,
        )

        try:
            _run_ffmpeg(cmd, nice_level)
        except subprocess.CalledProcessError:
            if iteration == 1:
                # Fallback auf VideoToolbox (einmaliger Versuch, kein Loop)
                if on_recompress:
                    on_recompress("libx265 nicht verfügbar – Fallback auf VideoToolbox")
                fallback_cmd = _build_videotoolbox_cmd(ffmpeg_path, source_path, output_path)
                _run_ffmpeg(fallback_cmd, nice_level)
                result_info = probe_video(output_path, ffprobe_path=ffprobe_path)
                final_bps = result_info.bitrate_bps if result_info else None
                return CompressionResult(output_path, crf, final_bps, 1, encoder="videotoolbox")
            raise

        # Bitrate des Ergebnisses prüfen
        result_info = probe_video(output_path, ffprobe_path=ffprobe_path)
        final_bps = result_info.bitrate_bps if result_info else None

        if result_info is None or result_info.bitrate_bps <= max_bitrate_bps:
            if crf > initial_crf and on_recompress:
                mbit = result_info.bitrate_bps / 1_000_000 if result_info else 0
                on_recompress(f"Bitrate nach Nachkomprimierung: {mbit:.0f} Mbit/s (CRF={crf})")
            return CompressionResult(output_path, crf, final_bps, iteration)

        # CRF-Obergrenze erreicht
        next_crf = crf + CRF_STEP
        if next_crf > MAX_CRF:
            mbit = result_info.bitrate_bps / 1_000_000
            if on_recompress:
                on_recompress(f"CRF-Obergrenze erreicht (CRF={crf}, {mbit:.0f} Mbit/s)")
            return CompressionResult(output_path, crf, final_bps, iteration)

        mbit = result_info.bitrate_bps / 1_000_000
        if on_recompress:
            on_recompress(f"Bitrate zu hoch ({mbit:.0f} Mbit/s) – Nachkomprimierung mit CRF={next_crf}")

        crf = next_crf
