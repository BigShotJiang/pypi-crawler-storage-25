"""Generierung und Validierung von Web-IDs (Hidden-Link-Identifier).

Format: 12 Zeichen Lowercase-Base36 (a-z, 0-9).
Entropie: 36^12 ≈ 4.7 × 10^18 Möglichkeiten — komplett unbruteforce-bar
für Hidden-Link-Sicherheit.
"""

from __future__ import annotations

import re
import secrets

WEB_ID_LENGTH = 12
WEB_ID_ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789"
_WEB_ID_RE = re.compile(r"^[a-z0-9]{12}$")


def generate_web_id() -> str:
    """Erzeugt eine neue 12-stellige Lowercase-Base36 ID.

    Beispiel: ``a3xk9mn2pqrw``
    """
    return "".join(secrets.choice(WEB_ID_ALPHABET) for _ in range(WEB_ID_LENGTH))


def is_valid_web_id(value: str) -> bool:
    """Prüft ob ein String dem Web-ID-Format entspricht (12 Zeichen, a-z, 0-9)."""
    return bool(_WEB_ID_RE.match(value))
