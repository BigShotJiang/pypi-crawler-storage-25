"""Orchestrierung der Mediaset-Erstellung: Dateien kopieren, Thumbnails erzeugen, HTML rendern."""

import re
import shutil
import subprocess
import unicodedata
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

from mediaset_creator.api.models import (
    CreateMediasetRequest,
    InfuseResult,
    MediasetCreatorEvent,
    MediasetCreatorStage,
    MediasetResult,
    RuntimeOptions,
    WebResult,
)
from mediaset_creator.core.asset_builder import copy_video, create_nfo, create_video_thumbnails, create_zip
from mediaset_creator.core.date_utils import format_date_german, parse_iso_date
from mediaset_creator.core.html_renderer import BrandingConfig, VideoRenderData, VideoSpecs, render_html
from mediaset_creator.core.video_processor import VideoInfo, compress_video, probe_video
from mediaset_creator.core.web_id import generate_web_id, is_valid_web_id


def _video_info_to_specs(info: VideoInfo | None) -> VideoSpecs | None:
    """Konvertiert eine VideoInfo in VideoSpecs für die HTML-Anzeige."""
    if info is None:
        return None
    return VideoSpecs(
        width=info.width,
        height=info.height,
        bitrate_bps=info.bitrate_bps,
        frame_rate=info.frame_rate,
        bit_depth=info.bit_depth,
        color_space_label=info.color_space_label,
        codec_name=info.codec_name,
    )


_TRANSLITERATION = str.maketrans({
    "ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss",
    "Ä": "Ae", "Ö": "Oe", "Ü": "Ue",
})

_DEFAULT_MAX_LUMINANCE = 1000


def _sanitize_stem(stem: str) -> str:
    """Erzeugt einen ASCII-sicheren Dateinamen-Stamm für Webserver-Kompatibilität."""
    stem = unicodedata.normalize("NFC", stem)
    stem = stem.translate(_TRANSLITERATION)
    stem = stem.replace(" ", "-")
    stem = re.sub(r"[^A-Za-z0-9\-_]", "", stem)
    stem = re.sub(r"-{2,}", "-", stem)
    return stem.strip("-")


def _emit(
    on_event: Callable[[MediasetCreatorEvent], None] | None,
    stage_id: str,
    message: str,
    paths: dict[str, Path] | None = None,
) -> None:
    if on_event:
        on_event(MediasetCreatorEvent(
            stage_id=stage_id,
            message=message,
            paths=paths,
        ))


def assemble_mediaset(
    request: CreateMediasetRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediasetCreatorEvent], None] | None = None,
) -> MediasetResult:
    """Erstellt ein Mediaset aus einer Videodatei.

    Returns:
        MediasetResult mit profil-basierten Ergebnissen.
    """
    runtime = runtime or RuntimeOptions()

    _emit(on_event, MediasetCreatorStage.MEDIASET_STARTED,
          f"Mediaset wird erstellt für {request.source_path.name}")

    # Konfiguration lesen
    use_sidecar = _get_config_value("thumbnails.sidecar").lower() != "false"
    use_date_prefix = _get_config_value("filename.date_prefix").lower() != "false"
    use_auto_compress = _get_config_value("video.auto_compress").lower() != "false"
    portrait_suffix = _get_config_value("thumbnails.portrait_suffix") or "-poster"
    nice_raw = _get_config_value("tools.nice_level").strip()
    nice_level = int(nice_raw) if nice_raw.lstrip("-").isdigit() else None
    crf_raw = _get_config_value("video.crf").strip()
    initial_crf = int(crf_raw) if crf_raw.isdigit() else 20
    preset = _get_config_value("video.preset").strip() or "slow"
    max_bitrate_raw = _get_config_value("video.max_bitrate").strip()
    max_bitrate_bps = int(float(max_bitrate_raw) * 1_000_000) if max_bitrate_raw else 40_000_000

    # Dateinamen-Stämme berechnen
    iso_date = request.recording_date or ""
    display_date = format_date_german(iso_date) if iso_date else None
    base_stem = request.source_path.stem

    if use_date_prefix and parse_iso_date(iso_date):
        original_stem = f"{iso_date} {base_stem}"
    else:
        original_stem = base_stem
    target_stem = _sanitize_stem(original_stem)

    # ── PHASE 1: Analyse + Shared Assets ──

    video_info = probe_video(request.source_path, ffprobe_path=runtime.ffprobe_path)
    duration_seconds = video_info.duration_seconds if video_info else 0.0
    needs_compress = use_auto_compress and video_info and video_info.needs_compression(max_bitrate_bps)
    is_hdr = video_info.is_hdr if video_info else False

    # HDR-Metadaten: max_luminance bestimmen (nur bei HDR-Quellen relevant)
    max_luminance: int | None = None
    if is_hdr:
        max_luminance = request.max_luminance or _DEFAULT_MAX_LUMINANCE

    if use_auto_compress:
        if video_info:
            if is_hdr:
                analyse_msg = f"HDR erkannt – Metadaten werden eingebettet ({max_luminance} nits): {video_info.summary()}"
            elif needs_compress:
                analyse_msg = f"Komprimierung nötig: {video_info.summary()}"
            else:
                analyse_msg = f"Keine Komprimierung: {video_info.summary()}"
        else:
            analyse_msg = "Videoanalyse nicht möglich – Original wird verwendet"
        _emit(on_event, MediasetCreatorStage.VIDEO_ANALYZED, analyse_msg)

    # Shared Assets erzeugen (work_dir oder Quellverzeichnis, kein /tmp)
    asset_dir = request.work_dir or request.source_path.parent

    poster = request.poster
    landscape_path, portrait_path = create_video_thumbnails(
        request.source_path, asset_dir, runtime, use_sidecar=use_sidecar,
        title=request.title, category=request.category,
        recording_date=display_date,
        portrait_suffix=portrait_suffix,
        frame_number=poster.frame_number if poster else None,
        timestamp_seconds=poster.timestamp_seconds if poster else None,
        crop_position=poster.crop_position if poster else None,
    )
    _emit(on_event, MediasetCreatorStage.THUMBNAILS_CREATED,
          f"Vorschaubilder erstellt für: {request.source_path.name}")

    nfo_path = create_nfo(
        video_stem=base_stem,
        output_dir=asset_dir,
        title=request.title,
        published=iso_date or None,
        category=request.category,
        description=request.description,
    )
    _emit(on_event, MediasetCreatorStage.NFO_CREATED,
          f"NFO-Datei erstellt: {nfo_path.name}")

    # ── PHASE 2: Infuse-Profil ──

    infuse_result: InfuseResult | None = None

    if request.infuse is not None:
        infuse_dir = request.infuse.output_dir
        infuse_dir.mkdir(parents=True, exist_ok=True)

        # Original-Video kopieren (mit Original-Dateinamen inkl. Umlaute)
        infuse_video = copy_video(
            request.source_path, infuse_dir, target_stem=original_stem,
        )
        # Landscape mit -fanart Suffix
        infuse_landscape = infuse_dir / f"{original_stem}-fanart{landscape_path.suffix}"
        shutil.copy2(landscape_path, infuse_landscape)
        # Portrait mit -poster Suffix
        infuse_portrait = infuse_dir / f"{original_stem}{portrait_suffix}{portrait_path.suffix}"
        shutil.copy2(portrait_path, infuse_portrait)
        # NFO
        infuse_nfo = infuse_dir / f"{original_stem}.nfo"
        shutil.copy2(nfo_path, infuse_nfo)

        infuse_result = InfuseResult(
            output_dir=infuse_dir,
            video_path=infuse_video,
            landscape_path=infuse_landscape,
            portrait_path=infuse_portrait,
            nfo_path=infuse_nfo,
        )
        _emit(on_event, MediasetCreatorStage.INFUSE_READY,
              f"Infuse-Medienset bereit: {infuse_dir}",
              paths={
                  "output_dir": infuse_dir,
                  "video": infuse_video,
                  "landscape": infuse_landscape,
                  "portrait": infuse_portrait,
                  "nfo": infuse_nfo,
              })

    # ── PHASE 3: Web-Profil vorbereiten ──

    web_result: WebResult | None = None

    if request.web is not None:
        # Web-ID bestimmen (12-stellig, a-z 0-9)
        if request.web_id:
            if not is_valid_web_id(request.web_id):
                return MediasetResult(
                    success=False,
                    error_message=f"Ungültige Web-ID: '{request.web_id}' (erwartet: 12 Zeichen, a-z 0-9)",
                )
            web_id = request.web_id
        else:
            web_id = generate_web_id()

        web_dir = request.web.output_dir / web_id
        web_dir.mkdir(parents=True, exist_ok=True)

        # Landscape kopieren (sanitisierter Name, ohne Suffix)
        web_landscape = web_dir / f"{target_stem}{landscape_path.suffix}"
        shutil.copy2(landscape_path, web_landscape)

        # Video: kopieren oder Komprimierung vormerken
        existing_video = _find_existing_video(web_dir, target_stem)
        source_mtime = request.source_path.stat().st_mtime
        compress_pending = False

        if existing_video and not request.force and existing_video.stat().st_mtime >= source_mtime:
            web_video_path = existing_video
            _emit(on_event, MediasetCreatorStage.VIDEO_SKIPPED,
                  f"Video unverändert, übersprungen: {existing_video.name}")
        elif needs_compress:
            # Komprimierung wird in Phase 4 durchgeführt
            web_video_path = web_dir / f"{target_stem}.mp4"
            compress_pending = True
        else:
            web_video_path = copy_video(
                request.source_path, web_dir, target_stem=target_stem,
            )
            _emit(on_event, MediasetCreatorStage.VIDEO_COPIED,
                  f"Video kopiert: {request.source_path.name}")

        # ZIP erstellen (falls gewünscht)
        zip_path: Path | None = None
        if request.web.include_zip:
            zip_path = create_zip(
                web_video_path,  # Naming-Referenz (bestimmt ZIP-Namen)
                landscape_path, portrait_path, web_dir,
                zip_video_path=request.source_path,
                nfo_path=nfo_path,
                original_stem=original_stem,
                portrait_suffix=portrait_suffix,
            )
            _emit(on_event, MediasetCreatorStage.ZIP_CREATED,
                  f"ZIP erstellt: {zip_path.name}")

        # ── PHASE 4: Komprimierung (langsam) — VOR HTML-Generierung,
        #    damit das HTML die finalen Web-Specs (Bitrate etc.) anzeigen kann.

        if compress_pending:
            def _on_recompress(message: str) -> None:
                _emit(on_event, MediasetCreatorStage.VIDEO_RECOMPRESSED, message)

            try:
                comp = compress_video(
                    request.source_path, web_video_path,
                    ffmpeg_path=runtime.ffmpeg_path,
                    ffprobe_path=runtime.ffprobe_path,
                    nice_level=nice_level,
                    on_recompress=_on_recompress,
                    initial_crf=initial_crf,
                    max_bitrate_bps=max_bitrate_bps,
                    preset=preset,
                    max_luminance=max_luminance,
                )
                mbit = comp.final_bitrate_bps / 1_000_000 if comp.final_bitrate_bps else 0
                encoder_label = f" ({comp.encoder})" if comp.encoder != "libx265" else ""
                summary = f"Video komprimiert: {web_video_path.name} | CRF={comp.final_crf} | {mbit:.0f} Mbit/s{encoder_label}"
                if comp.iterations > 1:
                    summary += f" | {comp.iterations} Durchläufe"
                _emit(on_event, MediasetCreatorStage.VIDEO_COMPRESSED, summary)
            except subprocess.CalledProcessError:
                web_video_dest = copy_video(
                    request.source_path, web_dir, target_stem=target_stem,
                )
                web_video_path = web_video_dest
                _emit(on_event, MediasetCreatorStage.VIDEO_COPIED,
                      f"Komprimierung fehlgeschlagen – Original kopiert: {request.source_path.name}")

        # HTML generieren (nach Komprimierung, mit Web-Specs)
        branding = BrandingConfig(
            enabled=request.web.enable_og_tags,
            base_url=runtime.base_url,
            site_name=_get_config_value("branding.site_name"),
            locale=_get_config_value("branding.locale") or "de_CH",
            web_id=web_id,
        )

        # Specs für Web (nach Komprimierung) und Original
        web_specs = _video_info_to_specs(
            probe_video(web_video_path, ffprobe_path=runtime.ffprobe_path)
        )
        original_specs = _video_info_to_specs(video_info)

        render_data = VideoRenderData(
            video_filename=web_video_path.name,
            landscape_filename=web_landscape.name,
            zip_filename=zip_path.name if zip_path else None,
            title=request.title,
            description=request.description,
            category=request.category,
            recording_date=display_date,
            duration_seconds=duration_seconds,
            zip_size_bytes=zip_path.stat().st_size if zip_path else 0,
            web_specs=web_specs,
            original_specs=original_specs,
        )

        created_at = datetime.now().strftime("%d.%m.%Y, %H:%M Uhr")
        effective_title = request.mediaset_title or request.title

        html_content = render_html(
            item=render_data,
            mediaset_title=effective_title,
            branding=branding,
            created_at=created_at,
        )
        html_path = web_dir / "index.html"
        html_path.write_text(html_content, encoding="utf-8")
        _emit(on_event, MediasetCreatorStage.HTML_GENERATED, "HTML-Seite generiert")

        web_result = WebResult(
            output_dir=web_dir,
            web_id=web_id,
            html_path=html_path,
            video_path=web_video_path,
            landscape_path=web_landscape,
            zip_path=zip_path,
        )
        _emit(on_event, MediasetCreatorStage.WEB_READY,
              f"Web-Medienset bereit: {web_dir}",
              paths={
                  "output_dir": web_dir,
                  "html": html_path,
                  "video": web_video_path,
                  "landscape": web_landscape,
                  **({"zip": zip_path} if zip_path else {}),
              })

    # Shared Assets aufräumen (liegen im Quellverzeichnis)
    if landscape_path.exists():
        landscape_path.unlink()
    if portrait_path.exists():
        portrait_path.unlink()
    if nfo_path.exists():
        nfo_path.unlink()

    # ── PHASE 5: Abschluss ──

    _emit(on_event, MediasetCreatorStage.MEDIASET_COMPLETED,
          "Mediaset abgeschlossen")

    return MediasetResult(
        success=True,
        infuse=infuse_result,
        web=web_result,
    )


_VIDEO_EXTENSIONS = {".mp4", ".m4v", ".mov", ".mkv", ".avi"}


def _find_existing_video(output_dir: Path, target_stem: str) -> Path | None:
    """Sucht eine vorhandene Videodatei mit dem gegebenen Stem im Ausgabeverzeichnis."""
    for ext in _VIDEO_EXTENSIONS:
        candidate = output_dir / f"{target_stem}{ext}"
        if candidate.exists():
            return candidate
    return None


def _get_config_value(key: str) -> str:
    """Liest einen Config-Wert. Fängt ImportError ab falls Config nicht verfügbar."""
    try:
        from mediaset_creator.services import config_manager
        return config_manager.get_with_default(key)
    except Exception:
        return ""
