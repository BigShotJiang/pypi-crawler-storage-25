# cfsem python examples

## Field Explorer

In this interactive example, examine the B-field and A-field of cfsem's finite-length-finite-thickness filament calcs
and compare to point-source calculations, section discretizations, and $B = \nabla \times A$ equivalence tests.

The full example can be run like `uv run --group dev examples/field_explorer.py`; the plot shown below is only an excerpt.

<figure markdown="span">
  <iframe
    class="plotly-embed"
    loading="lazy"
    src="../example_outputs/field_explorer.html"
    title="Field explorer example"
  ></iframe>
  <figcaption>
    B-field of an arrangement of finite-length, finite-thickness filaments.
  </figcaption>
</figure>

## Helmholtz Coil Pair

This example uses [cfsem.flux_density_circular_filament][] to map the B-field of
a [Helmholtz coil pair](https://en.wikipedia.org/wiki/Helmholtz_coil),
an arrangement of two circular coils which produces a region of
nearly uniform magnetic field.

<figure markdown="span">
  ![Helmholtz coil example](example_outputs/helmholtz.png)
  <figcaption>
    B-field of a Helmholtz coil, calculated with cfsem.
    On the left, the red dashes outline where the B-field magnitude is within 1% of its value at (r=0, z=0), and the black dots show where the coils intersect the r-z plane.
  </figcaption>
</figure>

``` py title="examples/helmholtz.py"
--8<-- "examples/helmholtz.py"
```

## Quadrilateral Element Explorer

Explore `quad4` and `quad9` interpolation in a Plotly Dash app. The example
shows a central element with one layer of neighboring elements, quadrature
locations for `gl3` or `gl4`, and the interpolated scalar field lifted above the
analysis mesh.

Run it with `uv run --group dev examples/element_explorer.py`.

<figure markdown="span">
  <iframe
    class="plotly-embed"
    loading="lazy"
    src="../example_outputs/element_explorer.html"
    title="Quadrilateral element explorer example"
  ></iframe>
  <figcaption>
    Quadrilateral interpolation surface and quadrature points.
  </figcaption>
</figure>

## High-aspect-ratio Coil Inductance

Estimate the (low-frequency) self- and mutual- inductance of a pair of air-core solenoids,
comparing results from modeling as either collections of axisymmetric loops or
as thin helical filaments.

``` py title="examples/inductance.py"
--8<-- "examples/inductance.py"
```

## Axisymmetric FEM Solenoid Stress Explorer

Explore the axisymmetric FEM stress solver in a Plotly Dash app. The example
varies the solenoid cross-section, current density, element family, quadrature,
material model, and loop-source position. It assembles the sparse FEM system,
adds the external loop source plus smooth winding-pack self-field, and compares
radial sections against row-matched 1D finite-difference reference profiles.

Run it with `uv run --group dev examples/solenoid_stress_axisymmetric_fem.py`.

## Axisymmetric FEM Solenoid Stress Convergence Study

Run an explicit radial-refinement study that configures the 2D FEM model to
match the 1D solver assumptions as closely as possible, then compares both
against the analytic long-solenoid stress formula on the midplane. The current
hardcoded sweep uses `quad9` elements with `gl3` quadrature and radial target
spacings from `50 mm` down to `1 mm`.

Run it with `uv run --group dev examples/solenoid_stress_axisymmetric_fem_convergence.py`
or add `--no-plot` for CI-style execution.

<figure markdown="span">
  ![Axisymmetric FEM convergence example](example_outputs/solenoid_stress_axisymmetric_fem_convergence.png)
  <figcaption>
    Midplane stress convergence for the 1D FD and axisymmetric FEM solenoid solvers.
  </figcaption>
</figure>

## Axisymmetric FEM Repeated-Load Operator Example

Run a small non-GUI example that assembles the constrained reduced model once,
then updates the load values to rebuild the reduced right-hand side for multiple
cases. The script makes the operator construction explicit, applies all four
supported load types,

- body-force density
- surface pressure
- surface traction in global `(r, z)` components
- nodal temperature with thermal strain

and checks the Rust-side `model.solve(rhs)` result against a SciPy solve on the
same reduced stiffness matrix. It uses the operators `body_force_to_rhs`,
`pressure_to_rhs`, `traction_to_rhs`, `temperature_to_rhs`, and `constant_rhs`
to rebuild the reduced load vector.

Run it with `uv run --group dev examples/solenoid_stress_surface_traction.py`.

## Loop Inductance

Estimate the (low-frequency) self-inductance of a finite-radius wire loop by different methods.

<figure markdown="span">
  ![Helmholtz coil example](example_outputs/loop_inductance.png)
  <figcaption>
    Inductance of a wire loop by different integration methods.
  </figcaption>
</figure>
