"""
Repository for `synced_tool_rules` (V29 migration) — cloud-pushed policy
bundle rules layered over local Tool Permissions.

active-mcp-and-policy-sync bundle, Phase 2 / Release B.

Lifecycle:
- Wiped + rewritten on every successful bundle apply (atomic in a single
  transaction so a failed apply leaves the previous bundle intact).
- Read at Tool Permissions request time to compute `effective_action`:
  cloud rule > local user rule > default.
- Cleared on graceful unenroll.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, List, Optional

from securevector.app.database.connection import DatabaseConnection

logger = logging.getLogger(__name__)


@dataclass
class SyncedToolRule:
    """One cloud-pushed rule, ready to layer over a local Tool Permission row."""

    id: int
    bundle_id: str
    policy_id: str
    policy_name: Optional[str]
    policy_version: int
    org_id: str
    org_name: Optional[str]
    tool_id: str
    effect: str  # 'allow' | 'deny' | 'prompt'
    priority: int
    reason: Optional[str]
    applied_at: str  # ISO timestamp


class SyncedRulesRepository:
    """CRUD over the synced_tool_rules table."""

    def __init__(self, db: DatabaseConnection):
        self.db = db

    async def list_all(self) -> List[SyncedToolRule]:
        rows = await self.db.fetch_all(
            "SELECT id, bundle_id, policy_id, policy_name, policy_version, "
            "org_id, org_name, tool_id, effect, priority, reason, applied_at "
            "FROM synced_tool_rules ORDER BY priority DESC, id ASC"
        )
        return [self._row_to_rule(r) for r in rows]

    async def find_by_tool(self, tool_id: str) -> Optional[SyncedToolRule]:
        """Return the highest-priority synced rule matching `tool_id`, or None."""
        row = await self.db.fetch_one(
            "SELECT id, bundle_id, policy_id, policy_name, policy_version, "
            "org_id, org_name, tool_id, effect, priority, reason, applied_at "
            "FROM synced_tool_rules WHERE tool_id = ? "
            "ORDER BY priority DESC, id ASC LIMIT 1",
            (tool_id,),
        )
        return self._row_to_rule(row) if row else None

    async def replace_bundle(
        self,
        *,
        bundle_id: str,
        policy_id: str,
        policy_name: Optional[str],
        policy_version: int,
        org_id: str,
        org_name: Optional[str],
        rules: Iterable[dict],
    ) -> int:
        """
        Atomically replace the synced ruleset with the contents of a verified
        bundle. Wipes existing rows for this `policy_id` first, then inserts
        the new bundle's rules. Returns the number of rules inserted.

        Each `rules` item must have keys: tool_id, effect, priority (int),
        reason (optional). Missing fields are tolerated where reasonable.
        """
        applied_at = datetime.now(timezone.utc).isoformat()
        conn = await self.db.connect()
        async with conn.execute("BEGIN"):
            pass
        try:
            # v1 strategy: wipe-and-rewrite the entire table on each apply.
            # If/when multi-policy stacking lands, narrow the wipe by policy_id.
            await conn.execute("DELETE FROM synced_tool_rules")
            count = 0
            for rule in rules:
                tool_id = rule.get("tool_id")
                effect = rule.get("effect", "deny")
                if not tool_id or effect not in ("allow", "deny", "prompt"):
                    logger.warning(
                        "Skipping invalid synced rule %r (tool_id missing or bad effect)",
                        rule,
                    )
                    continue
                # Per-rule policy attribution — when the engine emits an
                # aggregated org-level bundle (Option A), each rule carries
                # its source policy_id / name / version. Fall back to the
                # bundle-level values for legacy single-policy bundles
                # where the engine hadn't started stamping per-rule yet.
                row_policy_id = rule.get("source_policy_id") or policy_id
                row_policy_name = rule.get("source_policy_name") or policy_name
                row_policy_version = rule.get("source_policy_version")
                if row_policy_version is None:
                    row_policy_version = policy_version
                await conn.execute(
                    "INSERT INTO synced_tool_rules "
                    "(bundle_id, policy_id, policy_name, policy_version, "
                    " org_id, org_name, tool_id, effect, priority, reason, applied_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        bundle_id,
                        row_policy_id,
                        row_policy_name,
                        int(row_policy_version),
                        org_id,
                        org_name,
                        tool_id,
                        effect,
                        int(rule.get("priority") or 0),
                        rule.get("reason"),
                        applied_at,
                    ),
                )
                count += 1
            await conn.commit()
            logger.info(
                "Replaced synced rules: bundle=%s policy=%s v=%d count=%d",
                bundle_id,
                policy_id,
                policy_version,
                count,
            )
            return count
        except Exception:
            await conn.rollback()
            raise

    async def get_last_applied_version(self, policy_id: str) -> Optional[int]:
        """
        Return the highest policy_version applied for a given policy_id, or
        None if this policy hasn't been applied yet. Used by the version
        guard in bundle_verifier.
        """
        row = await self.db.fetch_one(
            "SELECT MAX(policy_version) AS v FROM synced_tool_rules WHERE policy_id = ?",
            (policy_id,),
        )
        return int(row["v"]) if row and row["v"] is not None else None

    async def clear(self) -> int:
        """Wipe all synced rules — used on graceful unenroll."""
        conn = await self.db.connect()
        cursor = await conn.execute("DELETE FROM synced_tool_rules")
        await conn.commit()
        return cursor.rowcount or 0

    async def list_policies(self) -> List[dict]:
        """
        One row per distinct policy_id, with aggregated metadata. Used by the
        local app's MCP Policies page to show what's synced from the cloud.

        We MAX() the per-policy fields because every row in a given policy
        carries the same bundle/org/version metadata (rewritten atomically
        on each apply); the aggregation is just to flatten N rules to one
        policy row.
        """
        rows = await self.db.fetch_all(
            "SELECT policy_id, "
            "       MAX(bundle_id) AS bundle_id, "
            "       MAX(policy_name) AS policy_name, "
            "       MAX(policy_version) AS policy_version, "
            "       MAX(org_id) AS org_id, "
            "       MAX(org_name) AS org_name, "
            "       MAX(applied_at) AS applied_at, "
            "       COUNT(*) AS rule_count "
            "FROM synced_tool_rules "
            "GROUP BY policy_id "
            "ORDER BY applied_at DESC"
        )
        return [
            {
                "policy_id": r["policy_id"],
                "policy_name": r["policy_name"],
                "bundle_id": r["bundle_id"],
                "policy_version": int(r["policy_version"]),
                "org_id": r["org_id"],
                "org_name": r["org_name"],
                "applied_at": r["applied_at"],
                "rule_count": int(r["rule_count"]),
            }
            for r in rows
        ]

    async def list_rules_for_policy(self, policy_id: str) -> List[SyncedToolRule]:
        """All rules for a given policy_id, sorted by priority then id."""
        rows = await self.db.fetch_all(
            "SELECT id, bundle_id, policy_id, policy_name, policy_version, "
            "org_id, org_name, tool_id, effect, priority, reason, applied_at "
            "FROM synced_tool_rules WHERE policy_id = ? "
            "ORDER BY priority DESC, id ASC",
            (policy_id,),
        )
        return [self._row_to_rule(r) for r in rows]

    @staticmethod
    def _row_to_rule(row) -> SyncedToolRule:
        # policy_name may be missing on rows written before V30 migration ran;
        # SQLite returns the column as None in that case which is what we want.
        return SyncedToolRule(
            id=row["id"],
            bundle_id=row["bundle_id"],
            policy_id=row["policy_id"],
            policy_name=row["policy_name"] if "policy_name" in row.keys() else None,
            policy_version=row["policy_version"],
            org_id=row["org_id"],
            org_name=row["org_name"],
            tool_id=row["tool_id"],
            effect=row["effect"],
            priority=row["priority"],
            reason=row["reason"],
            applied_at=row["applied_at"],
        )
