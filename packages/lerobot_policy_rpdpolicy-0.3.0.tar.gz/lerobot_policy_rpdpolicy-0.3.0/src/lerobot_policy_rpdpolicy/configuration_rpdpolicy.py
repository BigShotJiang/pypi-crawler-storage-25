from dataclasses import dataclass, field
from lerobot.configs.policies import PreTrainedConfig
from lerobot.optim.optimizers import AdamWConfig
from lerobot.configs.types import NormalizationMode

@PreTrainedConfig.register_subclass("rpdpolicy")
@dataclass
class RPDConfig(PreTrainedConfig):

    action_dim: int              = 7
    state_dim: int               = 7
    backbone_name: str           = "convnext_small"
    backbone_pretrained: bool    = True
    freeze_backbone: bool        = False
    image_channels: list[int]    = field(default_factory=lambda: [3, 3])
    fpn_channels: int            = 256
    fpn_layers: int              = 3
    cbam_reduction: int          = 16

    dim_model: int               = 512
    n_heads: int                 = 8
    n_encoder_layers: int        = 4
    n_decoder_layers: int        = 4
    dim_feedforward: int         = 2048
    dropout: float               = 0.1
    pre_norm: bool               = False
    feedforward_activation: str  = "relu"
    normalization_mapping: dict[str, NormalizationMode] = field(
        default_factory=lambda: {
            "VISUAL": NormalizationMode.MEAN_STD,
            "STATE": NormalizationMode.MEAN_STD,
            "ACTION": NormalizationMode.MEAN_STD,
        }
    )
    use_vae: bool                = True
    latent_dim: int              = 32
    n_vae_encoder_layers: int    = 4
    kl_weight: float             = 10.0
    use_per_cam_tokens: bool     = False
    use_per_scale_proj: bool     = True

    chunk_size: int              = 50
    n_action_steps: int          = 1
    temporal_ensemble_coeff: float | None = None

    optimizer_lr: float          = 1e-4
    optimizer_lr_backbone: float = 1e-5
    optimizer_weight_decay: float = 1e-4
    optimizer_grad_clip_norm: float = 10.0

    def __post_init__(self):
        super().__post_init__()
        assert self.action_dim >= 1
        assert self.state_dim >= 1
        for ch in self.image_channels:
            assert ch in (3, 4), "each channel must be 3 or 4"
        assert self.n_action_steps <= self.chunk_size

    def validate_features(self) -> None:
        pass
    def get_optimizer_preset(self) -> AdamWConfig:
        return AdamWConfig(
            lr=self.optimizer_lr,
            weight_decay=self.optimizer_weight_decay,
        )

    def get_scheduler_preset(self) -> None:
        return None

    @property
    def observation_delta_indices(self) -> None:
        return None

    @property
    def action_delta_indices(self) -> list:
        return list(range(self.chunk_size))

    @property
    def reward_delta_indices(self) -> None:
        return None