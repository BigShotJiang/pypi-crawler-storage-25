import torch 
import torch.nn as nn
from torch.nn import functional as F 
import timm 


#------------ Backbone -----------------

class Backbone(nn.Module):
    def __init__(self, name:str = 'convnext_small', pretrained: bool = True, in_channels: int = 4): 
        super().__init__() 
        self.net = timm.create_model(name, features_only = True , pretrained= pretrained, in_chans = in_channels) 
        all_channels = self.net.feature_info.channels() 
        all_strides = self.net.feature_info.reduction() 
        self.level_idx   = sorted([i for i, s in enumerate(all_strides)
                                   if s in (8, 16, 32)])
        self.out_channels = [all_channels[i] for i in self.level_idx]

    def forward(self,x): 
        all_feats = self.net(x) 
        return [all_feats[i] for i in self.level_idx]
        
#----------------------------------------------------


#---------------------BiFPN--------------------------
                          
class DepthwiseSepConv(nn.Module): 
    def __init__(self, ch):
        super().__init__() 
        self.depth_wise_conv = nn.Conv2d(ch , ch,  3, padding=1 , groups= ch , bias = False) 
        self.point_wise_conv = nn.Conv2d(ch , ch , 1, bias = False) 
        self.bn = nn.BatchNorm2d(ch) 
    
    def forward(self, x): 
        return F.relu(self.bn(self.point_wise_conv(self.depth_wise_conv(x))), inplace=True) 
    

class BiFPNLayer(nn.Module): 
    def __init__(self, ch:int , num_levels: int = 3, eps: float = 1e-4): 
        super().__init__() 
        self.eps    = eps 
        self.num_levels = num_levels 
        self.top_down_weights = nn.ParameterList(
            [nn.Parameter(torch.ones(2)) for _ in range(num_levels - 1)])
        self.bottom_up_weights = nn.ParameterList(
            [nn.Parameter(torch.ones(3)) for _ in range(num_levels - 1)])
        self.top_down_convs    = nn.ModuleList(
            [DepthwiseSepConv(ch) for _ in range(num_levels - 1)])
        self.bottom_up_convs   = nn.ModuleList(
            [DepthwiseSepConv(ch) for _ in range(num_levels - 1)])
        self.downsample = nn.MaxPool2d(2, 2) 

    def _fuse2(self, w , x1 , x2): 
        w1 , w2 = F.relu(w[0]), F.relu(w[1])
        return (w1 * x1 + w2 * x2) / (w1 + w2 + self.eps) 
    
    def _fuse3(self, w , x1 ,x2 , x3): 
        w1 , w2, w3 = F.relu(w[0]) , F.relu(w[1]) , F.relu(w[2]) 
        return (w1 * x1 + w2 * x2 + w3 * x3) / (w1 + w2 + w3 + self.eps) 
    
    def forward(self, features): 
        P = list(features) 
        N = self.num_levels 
        top_down = [None] * N 
        top_down[-1] = P[-1]
        for i in range(N-2 , -1 , -1): 
            up   = F.interpolate(top_down[i+1], size = P[i].shape[-2:], mode = 'nearest') 
            top_down[i] = self.top_down_convs[i](self._fuse2(self.top_down_weights[i],P[i], up))
        out     = [None] * N 
        out[0]  = top_down[0] 

        for i in range(1, N): 
            down = self.downsample(out[i-1]) 
            if down.shape[-2:] != top_down[i].shape[-2:]: 
                down = F.interpolate(down , size= top_down[i].shape[-2:], mode = 'nearest')
            out[i] = self.bottom_up_convs[i-1](
                self._fuse3(self.bottom_up_weights[i-1], P[i], top_down[i], down))
        return out 
        
class BiFPN(nn.Module): 
    def __init__(self, in_channels: list , out_channels: int = 256, num_layers: int =3): 
        super().__init__() 
        self.input_projection = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(c, out_channels, 1 , bias = False), 
                nn.BatchNorm2d(out_channels), 
                nn.ReLU(inplace= True),
            ) for c in in_channels 
        ])
        self.layers = nn.ModuleList([
            BiFPNLayer(out_channels, num_levels = len(in_channels))
            for _ in range(num_layers) 
        ])

    def forward(self, features): 
        x = [proj(f) for proj , f in zip(self.input_projection, features)]
        for layer in self.layers: 
            x = layer(x) 
        return x 
    
#-------------------------------------------------------------------------------------


#-------------------------Convolutional Block Attention Module------------------------

class ChannelAttention(nn.Module): 
    def __init__(self, channels: int , reduction: int = 16): 
        super().__init__() 
        self.avg_pool = nn.AdaptiveAvgPool2d(1) 
        self.max_pool = nn.AdaptiveMaxPool2d(1) 
        self.mlp = nn.Sequential(
            nn.Conv2d(channels , channels //reduction , 1 , bias = False), 
            nn.ReLU(inplace = True), 
            nn.Conv2d(channels // reduction , channels , 1, bias= False),
        )
    
    def forward(self, x): 
        return torch.sigmoid(self.mlp(self.avg_pool(x)) + 
                             self.mlp(self.max_pool(x))) 

class SpatialAttention(nn.Module): 
    def __init__(self): 
        super().__init__() 
        self.conv = nn.Conv2d(2, 1 ,7 , padding = 3 , bias = False) 
    
    def forward(self , x): 
        avg = x.mean(dim = 1, keepdim = True) 
        mx  = x.max(dim = 1, keepdim = True).values 
        return torch.sigmoid(self.conv(torch.cat([avg, mx], dim = 1)))

class CBAM(nn.Module): 
    def __init__(self, channels: int , reduction: int = 16): 
        super().__init__() 
        self.ca = ChannelAttention(channels, reduction) 
        self.sa = SpatialAttention() 

    def forward(self, x): 
        x = x * self.ca(x) 
        x = x * self.sa(x)  
        return x 

#--------------------------------Backbone-----------------------------------

class FeaturExtractor(nn.Module): 
    def __init__(self, cfg: dict, in_channels = 3): 
        super().__init__() 
        self.cfg = cfg
        
        channels = cfg.get('fpn_channels', 256) 
        num_layers = cfg.get('num_layers' , 3) 

        self.backbone   = Backbone(cfg['backbone'],in_channels=in_channels) 
        self.bifpn      = BiFPN(self.backbone.out_channels, 
                                out_channels= channels , num_layers= num_layers)
        self.cbam_levels = nn.ModuleList([CBAM(channels) for _ in range(len(self.backbone.out_channels))])

    def forward(self, x): 
        features = self.backbone(x)
        features = self.bifpn(features)
        features = [cbam(feature) for cbam, feature in zip(self.cbam_levels, features)]
        return features




#-----------------------------------------------------------------------------------


if __name__ == "__main__": 
    cfg = {'backbone': 'convnext_small', 'fpn_channels': 256, 'num_layers': 3}
    model = FeaturExtractor(cfg)
    x = torch.randn(2, 4, 480, 640)
    out = model(x)
    # expect 3 tensors, all with 256 channels
    for f in out:
        print(f.shape)