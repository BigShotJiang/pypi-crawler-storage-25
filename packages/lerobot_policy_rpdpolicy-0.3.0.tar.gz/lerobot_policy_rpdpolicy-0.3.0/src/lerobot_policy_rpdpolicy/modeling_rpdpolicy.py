import math 
from collections import deque
from collections.abc import Callable 
from itertools import chain 
import numpy as np 

import torch
import torch.nn as nn 
import torch.nn.functional as F 
import torchvision 
import einops 
from torch import Tensor
from torchvision.models._utils import IntermediateLayerGetter 
from torchvision.ops.misc import FrozenBatchNorm2d 

from lerobot.utils.constants import ACTION, OBS_ENV_STATE, OBS_IMAGES, OBS_STATE
from lerobot.policies.pretrained import PreTrainedPolicy
from .configuration_rpdpolicy import RPDConfig 

from .CNN_Backbone import FeaturExtractor 


#------------------------UTILS--------------------------------- 

def get_activation_fn(fn: str) -> Callable: 
    "Return an activation function given a string" 
    try: 
        func = getattr(F, fn) 
    except: 
        func = F.relu 
    return func 

def create_sinsoidal_pos_embedding(num_positions: int , dimension: int) ->Tensor: 
    """
    1D Sinusodal positional embeddings from Attention is All you Need paper.
    Args: 
        num_positions: Number of token positions required. 
    Returns: (num_positions, dimension) position embeddings (sthe first dimension is the batch dimension) 
    """
    
    def get_position_angle_vec(position): 
        return [position / np.power(10000, 2 * (hid_j // 2) / dimension) for hid_j in range(dimension)]
    
    sinusoid_table = np.array([get_position_angle_vec(pos_i) for pos_i in range(num_positions)])
    sinusoid_table[:, 0::2] = np.sin(sinusoid_table[:, 0::2]) 
    sinusoid_table[:, 1::2] = np.cos(sinusoid_table[:, 1::2])
    return torch.from_numpy(sinusoid_table).float()    

class RPDSinsoidalPositionEmbedding2d(nn.Module): 
    """
    2D sinusoidal positional embeddings as in Attention is All you Need. 

    The variation is that the position indices are normalized in [0, 2pi] 
    (actuatlly the lower bound is 1/H for vertical direction and 1/W for horizontal directdion )
    """

    def __init__(self, dimesion:int): 
        super().__init__() 

        if dimesion % 2 != 0:
            raise ValueError(f"dimesion must be even for 2D sinusoidal embeddings, got {dimesion}.")

        self.dim  = dimesion 
        self.eps = 1e-5 
        self.temp = 10000 
    
    def forward(self, x: Tensor) -> Tensor: 
        """
        Args: 
            x: A (B, C, H ,W) batch of 2d feature map to generate the embedding for. 
        Returns: 
            A (1 , C , H , W) batch of corresponding sinusoidal positional embeddins  
        """
        not_mask = torch.ones_like(x[0, :1])
        y_range = not_mask.cumsum(1, dtype=torch.float32)
        x_range = not_mask.cumsum(2, dtype= torch.float32)

        y_range = y_range / (y_range[:, -1:, :]+ self.eps) * (2*math.pi)
        x_range = x_range / (x_range[:, -1:, :]+ self.eps) * (2*math.pi)

        inverse_fequency = self.temp ** (
            2 * (torch.arange(self.dim, dtype= torch.float32, 
            device=x.device) // 2) / self.dim
        )
        x_range = x_range.unsqueeze(-1) / inverse_fequency 
        y_range = y_range.unsqueeze(-1) / inverse_fequency 

        pos_embed_x = torch.stack((x_range[..., 0::2].sin(), x_range[..., 1::2].cos()), dim=-1).flatten(3) 
        pos_embed_y = torch.stack((y_range[..., 0::2].sin(), y_range[..., 1::2].cos()), dim=-1).flatten(3) 

        return torch.cat((pos_embed_y, pos_embed_x),dim = 3).permute(0, 3, 1, 2)
    
class RPDTemporalEnsembler: 
    def __init__(self, temporal_ensemble_coeff: float , chunk_size: int) -> None: 
        self.chunk_size = chunk_size 
        self.ensemble_weights = torch.exp(-temporal_ensemble_coeff * 
        torch.arange(chunk_size)) 
        self.ensemble_weights_cumsum = torch.cumsum(self.ensemble_weights, dim = 0) 
        self.reset() 

    def reset(self): 
        self.ensemble_actions = None 
        self.ensemble_actions_count = None 

    def update(self, actions: Tensor)-> Tensor: 
        self.ensemble_weights = self.ensemble_weights.to(device=actions.device) 
        self.ensemble_weights_cumsum = self.ensemble_weights_cumsum.to(device=actions.device) 
        if self.ensemble_actions is None:
            self.ensemble_actions = actions.clone() 
            self.ensemble_actions_count = torch.ones( 
                (self.chunk_size, 1) , dtype= torch.long , device= self.ensemble_actions.device
            )

        else: 
            self.ensemble_actions *= self.ensemble_weights_cumsum[self.ensemble_actions_count - 1] 

            self.ensemble_actions += actions[:, :-1] * self.ensemble_weights[self.ensemble_actions_count]

            self.ensemble_actions /= self.ensemble_weights_cumsum[self.ensemble_actions_count]

            self.ensemble_actions_count = torch.clamp(self.ensemble_actions_count + 1 , max= self.chunk_size) 

            self.ensemble_actions = torch.cat([self.ensemble_actions, actions[:, -1:]], dim = 1) 

            self.ensemble_actions_count = torch.cat(
                [self.ensemble_actions_count, torch.ones_like(self.ensemble_actions_count[-1:])]
            )

        action , self.ensemble_actions , self.ensemble_actions_count = (
            self.ensemble_actions[: , 0],
            self.ensemble_actions[: , 1:], 
            self.ensemble_actions_count[1:], 
        )
        
        return action 
    
#------------------------------- Model Architechture--------------------------



class RPDEncoder(nn.Module): 
    def __init__(self, config: RPDConfig, is_vae_encoder: bool = True): 
        super().__init__() 
        self.is_vae_encodesr = is_vae_encoder 
        num_layers = config.n_vae_encoder_layers if self.is_vae_encodesr else config.n_encoder_layers
        self.layers = nn.ModuleList([RPDEncoderLayer(config) for _ in range(num_layers)])
        self.norm = nn.LayerNorm(config.dim_model) if config.pre_norm else nn.Identity() 
    
    def forward(self , x: Tensor, pos_embed: Tensor | None = None, key_padding_mask: Tensor | None = None) -> Tensor: 
        for layer in self.layers: 
            x = layer(x, pos_embed= pos_embed, key_padding_mask = key_padding_mask) 
        x = self.norm(x) 
        return x 


class RPDEncoderLayer(nn.Module): 
    def __init__(self, config: RPDConfig): 
        super().__init__() 
        self.self_attn = nn.MultiheadAttention(config.dim_model , config.n_heads , dropout= config.dropout) 

        # Feed Forward Layers 
        self.linear1 = nn.Linear(config.dim_model, config.dim_feedforward) 
        self.dropout = nn.Dropout(config.dropout) 
        self.linear2 = nn.Linear(config.dim_feedforward, config.dim_model) 
        
        self.norm1 = nn.LayerNorm(config.dim_model)
        self.norm2 = nn.LayerNorm(config.dim_model) 
        self.dropout1 = nn.Dropout(config.dropout) 
        self.dropout2 = nn.Dropout(config.dropout) 

        self.activation = get_activation_fn(config.feedforward_activation) 
        self.pre_norm = config.pre_norm 

    def forward(self, x , pos_embed: Tensor | None = None , key_padding_mask: Tensor | None = None) -> Tensor: 
        skip = x 
        if self.pre_norm: 
            x = self.norm1(x) 
        q = k = x if pos_embed is None else x + pos_embed
        x = self.self_attn(q, k, value=x, key_padding_mask=key_padding_mask)
        x = x[0] 
        x = skip + self.dropout1(x)
        if self.pre_norm: 
            skip = x 
            x = self.norm2(x) 
        else: 
            x = self.norm1(x) 
            skip = x 
        x = self.linear2(self.dropout(self.activation(self.linear1(x)))) 
        x = skip + self.dropout2(x) 
        if not self.pre_norm: 
            x = self.norm2(x) 
        return x 
    
class RPDecoder(nn.Module): 
    def __init__(self, config: RPDConfig): 
        super().__init__() 
        self.layers = nn.ModuleList([RPDecoderLayer(config) for _ in range(config.n_decoder_layers)]) 
        self.norm = nn.LayerNorm(config.dim_model) 
    
    def forward(self, x: Tensor, encoder_out: Tensor, decoder_pos_embed: Tensor | None = None , encoder_pos_embed: Tensor | None = None) -> Tensor : 
        for layer in self.layers: 
            x = layer(
                x , encoder_out, 
                decoder_pos_embed= decoder_pos_embed, encoder_pos_embed = encoder_pos_embed
            )
        if self.norm is not None: 
            x = self.norm(x) 
        return x 

class RPDecoderLayer(nn.Module): 
    def __init__(self, config: RPDConfig): 
        super().__init__() 
        self.self_attn = nn.MultiheadAttention(config.dim_model, config.n_heads, dropout = config.dropout) 
        self.multihead_attn = nn.MultiheadAttention(config.dim_model, config.n_heads, dropout= config.dropout) 

        self.linear1 = nn.Linear(config.dim_model , config.dim_feedforward) 
        self.dropout = nn.Dropout(config.dropout) 
        self.linear2 = nn.Linear(config.dim_feedforward, config.dim_model) 

        self.norm1 = nn.LayerNorm(config.dim_model) 
        self.norm2 = nn.LayerNorm(config.dim_model) 
        self.norm3 = nn.LayerNorm(config.dim_model) 
        self.dropout1 = nn.Dropout(config.dropout) 
        self.dropout2 = nn.Dropout(config.dropout) 
        self.dropout3 = nn.Dropout(config.dropout) 

        self.activation = get_activation_fn((config.feedforward_activation))
        self.pre_norm = config.pre_norm 

    
    def maybe_add_pos_embed(self, tensor: Tensor, pos_embed: Tensor | None) -> Tensor: 
        return tensor if pos_embed is None else tensor + pos_embed 
    
    def forward(self, x: Tensor, encoder_out: Tensor, decoder_pos_embed: Tensor | None = None , encoder_pos_embed: Tensor | None = None) -> Tensor: 
        """
        Args: 
            x: (Decoder Sequence , Batch , Channel) tensor of input tokens. 
            encoder_out: (Encoder Sequence , B , C)  output features from the last layer of the encoder we are 
                cross-attending with. 
            encoder_pos_embed: (ES, 1, C) positional embedding for keys (from the encoder) 
            decoder_pos_embed: (DS, 1, C) positional embedding for the queries (from the decoder) 
        Returns: 
            (DS, B, C) tensor of decoder output features. 
        """
        skip = x 
        if self.pre_norm: 
            x = self.norm1(x) 
        q = k = self.maybe_add_pos_embed(x , decoder_pos_embed) 
        x = self.self_attn(q, k , value=x)[0] # select just the ouput not the attention weights 
        x = skip + self.dropout(x) 
        if self.pre_norm: 
            skip = x 
            x = self.norm2(x) 
        else: 
            x = self.norm1(x) 
            skip = x 
        x = self.linear2(self.dropout(self.activation(self.linear1(x)))) 
        x = skip + self.dropout3(x) 
        if not self.pre_norm: 
            x = self.norm3(x) 
        return x 
    
class RPDTransformer(nn.Module): 
    """
    Currently this version of the transformer is inspired from ACT i.e Action Chunking Transformer but as we go further deep into info about how lerobot policies work this version of the transformer is going to change for sure 

    Note: In this vode we use the terms 'vae_encoder', 'encoder', 'decoder'. The meanings are as follows: 
        - The 'vae_encoder' is variational auto-encoer the purpose of using conditional vae in this case: there are many ways to execute the same task , vae ensures that we do it in the right way by assigning a weight to  different ways of the same task, so that the robot reasons well on 
        *Which way is best for doing this action based on the current environment* 
        - A transformer with an  `encoder` and `decoder` are used with cross-attention is used as the VAE decoder. 
    """

    def __init__(self, config:RPDConfig): 
        # BERT style VAE encoder with input tokens [cls, end-effector_state, *action_sequence]. 
        # The cls token forms parameters of the latent's distribution (like this [*means , *log_variances])). 
        super().__init__() 
        self.config = config 

        if self.config.use_vae: 
            self.vae_encoder = RPDEncoder(config, is_vae_encoder=True) 
            self.vae_encoder_cls_embed = nn.Embedding(1, config.dim_model) 
            # Projection layer for end-effector state configuration to hidden dimension 
            if self.config.robot_state_feature: 
                self.vae_encoder_robot_state_input_proj = nn.Linear(
                    self.config.robot_state_feature.shape[0], 
                    config.dim_model)
            # Projection layer for action (end-effector target) to hidden dimension 
            self.vae_encoder_action_input_proj = nn.Linear(
                self.config.action_feature.shape[0], 
                config.dim_model,
            )
            # Projection layer from the VAE encoder's ouptut to the latent distribution's parameter space. 
            self.vae_encoder_latent_ouput_proj = nn.Linear(config.dim_model, config.latent_dim * 2) 
            # Fixed sinusoidal positional embedding for the input to the VAE  encoder, Unsqueeze for batch 
            num_input_token_encoder = 1 + config.chunk_size
            if self.config.robot_state_feature: 
                num_input_token_encoder += 1 
            self.register_buffer(
                "vae_encoder_pos_enc",
                create_sinsoidal_pos_embedding
                (num_input_token_encoder, config.dim_model).unsqueeze(0), 
            )
        
        # This part is unique to RPDPolicy , we are infusing depth channel with our custom CNN Feature extracter unlike ACT'S resnet 
        if self.config.image_features: 
            self.backbones = nn.ModuleList([
                FeaturExtractor(
                    cfg= {
                        "backbone": config.backbone_name, 
                        "fpn_channels": config.fpn_channels, 
                        "num_layers": config.fpn_layers,
                    }, in_channels = ch 
                )
                for ch in config.image_channels 
            ])
        num_cams = len(config.image_channels) 
        num_scales = 1 # BiFPN outputs P3 P4 P5 

        if config.use_per_scale_proj: 
            self.encoder_img_feat_input_proj = nn.ModuleList([
                nn.ModuleList([
                    nn.Conv2d(config.fpn_channels, config.dim_model, kernel_size= 1) 
                    for _ in range(num_scales)
                ])
                for _ in range(num_cams)
            ])
        else: 
            self.encoder_img_feat_input_proj = nn.ModuleList([
                nn.Conv2d(config.fpn_channels, config.dim_model, kernel_size= 1) 
                for _ in range(num_cams) 
            ])
        if not config.use_per_cam_tokens: 
            self.cam_id_embed = nn.Embedding(num_cams , config.dim_model) 
            
        self.encoder = RPDEncoder(config) 
        self.decoder = RPDecoder(config) 

        if self.config.robot_state_feature: 
            self.encoder_robot_state_input_proj = nn.Linear(
                self.config.robot_state_feature.shape[0] , config.dim_model
            )
        if self.config.env_state_feature: 
            self.encoder_env_state_input_proj = nn.Linear(
                self.config.env_state_feature.shape[0], config.dim_model
            )
        self.vae_encoder_latent_input_proj = nn.Linear(config.latent_dim , config.dim_model) 
        
        # Transformer encoder positional embeddings 
        n_1d_tokens = 1 
        if self.config.robot_state_feature: 
            n_1d_tokens += 1 
        if self.config.env_state_feature: 
            n_1d_tokens += 1 
        self.encoder_1d_feature_pos_embed = nn.Embedding(n_1d_tokens, config.dim_model) 
        if self.config.image_features: 
            self.encoder_cam_feat_pos_embed =  RPDSinsoidalPositionEmbedding2d(config.dim_model // 2) 
        
        # Transformer decoder 
        # Learnable positional e;mbedding fro the transformers's decoder (in the style of DETR object queries) 
        self.decoder_pos_embed = nn.Embedding(config.chunk_size, config.dim_model) 
        
        # Final action regression head on the output of the transformer's decoder 
        self.action_head = nn.Linear(config.dim_model , self.config.action_feature.shape[0]) 

        self._reset_params() 
    
    def _reset_params(self):
        """ Xavier-uniform initialization of the transformer parameters as in the orginal code"""
        for p in chain(self.encoder.parameters(), self.decoder.parameters()): 
            if p.dim() > 1: 
                nn.init.xavier_uniform_(p) 

    def forward(self, batch: dict[str, Tensor]) -> tuple[Tensor, tuple[Tensor, Tensor] | tuple[None , None]]:
        """A forward pass through the Transformer 
        `batch` should have following structure: 
        {
            [robot_state_feature] (optimal) (B, state_dim) batch of end-effector states. 
            
            [image_features]: #TODO: ADD image feature shape 
            
            [env_state_feature] : (B, env_dim) batch of enviromnent states. 

            [action_features] (optional, only if training with VAE): (B, chunk_size , action_dim) batch of actions.
        }

        Returns: 
            (B, chunk_size, action_dim) batch of action sequences 
            Tuple containing the latent PDF's parameters (mean, log(σ²)) both as (B, L) tensors where L is the  latent dimension. 
        """
        if self.config.use_vae and self.training: 
            assert ACTION in batch, (
                "actions must be provideds when using the variational objective in training mode." 
            )
        batch_size = batch[OBS_IMAGES][0].shape[0]  if OBS_IMAGES in batch else batch[OBS_ENV_STATE].shape[0]

        # Prepare the latent for input to the transformer encoder. 
        if self.config.use_vae and ACTION in batch and self.training: 
            # Prepare the input to VAE_encoder: [cls, *end-effector state configuration, *action sequence].
            cls_embed = einops.repeat(
                self.vae_encoder_cls_embed.weight, "1 d -> b 1 d" , b = batch_size
            )
            if self.config.robot_state_feature: 
                robot_state_embed = self.vae_encoder_robot_state_input_proj(batch[OBS_STATE])
                robot_state_embed = robot_state_embed.unsqueeze(1)
            action_embed = self.vae_encoder_action_input_proj(batch[ACTION])

            if self.config.robot_state_feature: 
                self.vae_encoder_input = [cls_embed, robot_state_embed, action_embed] 
            else: 
                self.vae_encoder_input = [cls_embed, action_embed] 
            self.vae_encoder_input = torch.cat(self.vae_encoder_input, dim =1 ) 
            
            # Prepare fixed positional embedding 
            # Note: deteach() shouldn't be necessary but leaving it same as the original code just in case 
            pos_embed = self.vae_encoder_pos_enc.clone().detach() 

            # Prepare key padding mask for the transformer encoder. We have 1 or 2 extra tokens at the
            # start of the sequence depending on whether we use input states or not (cls and end-effector_state).
            # False means not a padding token 
            cls_joint_is_pad = torch.full(
                (batch_size, 2 if self.config.robot_state_feature else 1), 
                False, 
                device=batch[OBS_STATE].device,
            )
            key_padding_mask = torch.cat(
                [cls_joint_is_pad, batch["action_is_pad"]] , dim=1,
            )
            
            cls_token_out = self.vae_encoder(
                self.vae_encoder_input.permute(1, 0 ,2), 
                pos_embed = pos_embed.permute(1, 0 ,2), 
                key_padding_mask = key_padding_mask, 
            )[0] 
            latent_pdf_params = self.vae_encoder_latent_ouput_proj(cls_token_out) 
            mu = latent_pdf_params[:, : self.config.latent_dim] 
            log_sigma_x2 = latent_pdf_params[:, self.config.latent_dim:] 
            latent_sample = mu + log_sigma_x2.div(2).exp() * torch.randn_like(mu)
        else: 
            mu = log_sigma_x2 = None 
            latent_sample = torch.zeros([batch_size, self.config.latent_dim], 
            dtype= torch.float32).to(
                batch[OBS_STATE].device
            )
            
        encoder_in_tokens = [self.vae_encoder_latent_input_proj(latent_sample)]
        encoder_in_pos_embed = list(self.encoder_1d_feature_pos_embed.weight.unsqueeze(1)) 

        # Robot state token.
        if self.config.robot_state_feature:
            encoder_in_tokens.append(self.encoder_robot_state_input_proj(batch[OBS_STATE]))
        # Environment state token.
        if self.config.env_state_feature:
            encoder_in_tokens.append(self.encoder_env_state_input_proj(batch[OBS_ENV_STATE]))

        if self.config.image_features: 
            all_cam_tokens = [] 
            all_cam_pos_embeds = [] 

            for cam_idx , (img, backbone) in enumerate(zip(batch[OBS_IMAGES], self.backbones)): 
                multi_scale_feats = backbone(img) 
                multi_scale_feats = [multi_scale_feats[-1]] 

                cam_tokens = [] 
                cam_pos_embeds = [] 

                for scale_idx , feat in enumerate(multi_scale_feats): 
                    if self.config.use_per_scale_proj: 
                        proj = self.encoder_img_feat_input_proj[cam_idx][scale_idx] 
                    else: 
                        proj = self.encoder_img_feat_input_proj[cam_idx]
                    cam_pos_embed = self.encoder_cam_feat_pos_embed(feat).to(dtype = feat.dtype) 
                    feat = proj(feat) 
                    feat = einops.rearrange(feat, "b c h w -> (h w) b c")
                    cam_pos_embed = einops.rearrange(cam_pos_embed, "b c h w -> (h w) b c")

                    cam_tokens.append(feat) 
                    cam_pos_embeds.append(cam_pos_embed)


                cam_tokens = torch.cat(cam_tokens, dim = 0)
                # for i, p in enumerate(cam_pos_embeds):
                #     print(f"scale {i}: {p.shape}")
                cam_pos_embed = torch.cat(cam_pos_embeds, dim = 0) 
                if not self.config.use_per_cam_tokens: 
                    cam_tokens = cam_tokens + self.cam_id_embed.weight[cam_idx]
                
                all_cam_tokens.append(cam_tokens) 
                all_cam_pos_embeds.append(cam_pos_embed) 
            if self.config.use_per_cam_tokens: 
                for cam_tokens , cam_pos_embeds in zip(all_cam_tokens, all_cam_pos_embeds): 
                    encoder_in_tokens.extend(list(cam_tokens)) 
                    encoder_in_pos_embed.extend(list(cam_pos_embed)) 
            else: 
                merged_tokens = torch.cat(all_cam_tokens, dim = 0) 
                merged_pos    = torch.cat(all_cam_pos_embeds, dim=0) 
                encoder_in_tokens.extend(list(merged_tokens)) 
                encoder_in_pos_embed.extend(list(merged_pos)) 
                            
        encoder_in_tokens = torch.stack(encoder_in_tokens, dim = 0) 
        encoder_in_pos_embed = torch.stack(encoder_in_pos_embed, dim = 0) 

        encoder_out = self.encoder(encoder_in_tokens, pos_embed = encoder_in_pos_embed) 
        
        decoder_in = torch.zeros(
            (self.config.chunk_size, batch_size, self.config.dim_model), 
            dtype= encoder_in_pos_embed.dtype, 
            device=encoder_in_pos_embed.device,
        )

        decoder_out = self.decoder(
            decoder_in, 
            encoder_out, 
            encoder_pos_embed = encoder_in_pos_embed, 
            decoder_pos_embed = self.decoder_pos_embed.weight.unsqueeze(1), 
        )

        decoder_out = decoder_out.transpose(0, 1) 
        actions = self.action_head(decoder_out) 

        return actions , (mu , log_sigma_x2) 

class RPDPolicy(PreTrainedPolicy): 
    config_class = RPDConfig 
    name = "rpdpolicy" 

    def __init__(
        self, 
        config: RPDConfig,
        dataset_stats=None,
        **kwargs, 
    ):
        """
        Args: 
            config: Policy configuration class instance or None, in which case the default instantiation of 
                    the configuration class is used. 
        """
        super().__init__(config, dataset_stats)
        config.validate_features() 
        self.config = config 
        self.model = RPDTransformer(config) 

        if config.temporal_ensemble_coeff is not None: 
            self.temporal_ensembler = RPDTemporalEnsembler(config.temporal_ensemble_coeff, config.chunk_size) 
            
        self.reset() 

    def  get_optim_params(self) -> dict: 
        return [
            {
                "params" : [
                    p 
                    for n , p in self.named_parameters() 
                    if not n.startswith("model.backbones") and p.requires_grad
                ]
            },
            {
                "params": [
                    p 
                    for n, p in self.named_parameters() 
                    if n.startswith("model.backbones") and p.requires_grad
                ],
                "lr": self.config.optimizer_lr_backbone,
            }, 
        ]
    
    def reset(self):
        """This should be called whenever the environment is reset."""
        if self.config.temporal_ensemble_coeff is not None: 
            self.temporal_ensembler.reset() 
        else: 
            self._action_queue = deque([], maxlen= self.config.n_action_steps) 

    @torch.no_grad() 
    def select_action(self, batch: dict[str , Tensor])-> Tensor:
        """Select a single action given environment observations 
        
        This method wraps `select_actions` in ordesr to return one action at a time for execution in the environment. 
        It works by managing the actions in a queue and only queue is empty.
        """
        self.eval() 

        if self.config.temporal_ensemble_coeff is not None: 
            actions = self.predict_action_chunk(batch) 
            action = self.temporal_ensembler.update(actions) 
            return action 
        
        if len(self._action_queue) == 0: 
            actions = self.predict_action_chunk(batch)[:, : self.config.n_action_steps] 

            self._action_queue.extend(actions.transpose(0, 1)) 
        return self._action_queue.popleft() 
    
    @torch.no_grad() 
    def predict_action_chunk(self, batch: dict[str, Tensor])-> Tensor: 
        """Predict a chunk of actions given environment observations"""
        self.eval() 

        if self.config.image_features: 
            batch = dict(batch) 

            batch[OBS_IMAGES] = [batch[key] for key in self.config.image_features] 

        actions = self.model(batch)[0] 
        return actions 
    
    def forward(self, batch: dict[str, Tensor]) -> tuple[Tensor, dict]: 
        """Run the batch through the model and compute the loss for training or validation. """
        if self.config.image_features: 
            batch = dict(batch) 
            batch[OBS_IMAGES] = [batch[key] for key in self.config.image_features]
        
        actions_hat, (mu_hat, log_sigma_x2_hat) = self.model(batch) 

        l1_loss = (
            F.l1_loss(batch[ACTION], actions_hat, reduction="none")
            * (~batch["action_is_pad"]).unsqueeze(-1)
        ).mean() 

        loss_dict = {"l1_loss": l1_loss.item()}
        if self.config.use_vae: 
            mean_kld = (
                (-0.5 * (1 + log_sigma_x2_hat - mu_hat.pow(2) - (log_sigma_x2_hat).exp())).sum(-1).mean() 
            )
            loss_dict["kld_loss"] = mean_kld.item() 
            loss = l1_loss + self.config.kl_weight * mean_kld
        else: 
            loss = l1_loss 
        
        return loss , loss_dict