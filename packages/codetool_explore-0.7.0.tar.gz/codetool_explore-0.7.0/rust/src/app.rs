use crate::config::Config;
use crate::output::render_json;
use crate::search::search;

pub(crate) fn run(config: Config) -> Result<String, String> {
    for root in &config.roots {
        if !root.is_dir() && !root.is_file() {
            return Err(format!(
                "root is neither a directory nor file: {}",
                root.to_string_lossy()
            ));
        }
    }
    if config.pattern.is_empty() && matches!(config.target.as_str(), "content" | "content_or_path")
    {
        return Err("pattern must not be empty".to_string());
    }
    if !matches!(
        config.target.as_str(),
        "content" | "path" | "content_or_path"
    ) {
        return Err("target must be one of: content, path, content_or_path".to_string());
    }
    if !matches!(config.path_scope.as_str(), "path" | "basename") {
        return Err("path-scope must be one of: path, basename".to_string());
    }
    if !matches!(config.mode.as_str(), "files" | "snippets" | "count") {
        return Err("mode must be one of: files, snippets, count".to_string());
    }
    if config.mode == "snippets" && config.target == "path" {
        return Err(
            "mode='snippets' is not supported for target='path'; use target='content' or target='content_or_path'"
                .to_string(),
        );
    }
    if !matches!(
        config.case.as_str(),
        "smart"
            | "sensitive"
            | "case-sensitive"
            | "exact"
            | "insensitive"
            | "ignore"
            | "ignorecase"
            | "case-insensitive"
            | "i"
    ) {
        return Err("case must be one of: smart, sensitive, insensitive".to_string());
    }

    let result = search(&config)?;
    Ok(render_json(&config, &result))
}
