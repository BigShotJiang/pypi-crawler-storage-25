use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};

use crate::case::resolve_case;
use crate::config::Config;
use crate::literal::LiteralMatcher;
use crate::matcher::{PathMatcher, SearchMatcher};
use crate::models::{FileMatch, SearchResult, Skipped, SnippetMatch};
use crate::ranking::RankingContext;
use crate::regex_search::RegexLineMatcher;
use crate::walker::walk_and_search_parallel;

pub(crate) fn search(config: &Config) -> Result<SearchResult, String> {
    let (effective_case, case_sensitive) = resolve_case(&config.case, &config.pattern);
    let content_enabled = matches!(config.target.as_str(), "content" | "content_or_path");
    let path_enabled = matches!(config.target.as_str(), "path" | "content_or_path");
    let content_matcher = if content_enabled {
        Some(if config.regex {
            SearchMatcher::Regex(RegexLineMatcher::new(&config.pattern, case_sensitive)?)
        } else {
            let needle = if case_sensitive {
                config.pattern.as_bytes().to_vec()
            } else {
                config.pattern.as_bytes().to_ascii_lowercase()
            };
            SearchMatcher::Literal(LiteralMatcher::new(needle, case_sensitive))
        })
    } else {
        None
    };
    let path_matcher = if path_enabled {
        Some(PathMatcher::new(
            &config.pattern,
            config.regex,
            case_sensitive,
        )?)
    } else {
        None
    };
    let collect_snippets = config.mode == "snippets";

    let counters = Arc::new(SearchCounters::default());
    let collections = Arc::new(Mutex::new(SearchCollections::default()));
    walk_and_search_parallel(
        config,
        content_matcher.as_ref(),
        path_matcher.as_ref(),
        collect_snippets,
        Arc::clone(&counters),
        Arc::clone(&collections),
    );

    let mut collections = lock_collections(&collections);
    let mut file_matches = std::mem::take(&mut collections.file_matches);
    let mut snippet_matches = std::mem::take(&mut collections.snippet_matches);

    let ranking = RankingContext::new(&config.pattern);
    file_matches.sort_by_cached_key(|item| ranking.file_sort_key(item));
    snippet_matches.sort_by_cached_key(|item| ranking.snippet_sort_key(item));

    Ok(SearchResult {
        file_matches,
        snippet_matches,
        scanned_files: counters.scanned_files.load(Ordering::Relaxed),
        scanned_bytes: counters.scanned_bytes.load(Ordering::Relaxed),
        skipped: Skipped {
            binary: counters.skipped_binary.load(Ordering::Relaxed),
            huge: counters.skipped_huge.load(Ordering::Relaxed),
            errors: counters.skipped_errors.load(Ordering::Relaxed),
        },
        effective_case,
    })
}

#[derive(Default)]
pub(crate) struct SearchCollections {
    pub(crate) file_matches: Vec<FileMatch>,
    pub(crate) snippet_matches: Vec<SnippetMatch>,
}

#[derive(Default)]
pub(crate) struct SearchCounters {
    pub(crate) scanned_files: AtomicUsize,
    pub(crate) scanned_bytes: AtomicU64,
    pub(crate) skipped_binary: AtomicUsize,
    pub(crate) skipped_huge: AtomicUsize,
    pub(crate) skipped_errors: AtomicUsize,
}

pub(crate) fn lock_collections(
    collections: &Mutex<SearchCollections>,
) -> MutexGuard<'_, SearchCollections> {
    collections
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}
