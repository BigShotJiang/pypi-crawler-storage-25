use std::cmp::min;
use std::env;
use std::ffi::OsString;
use std::path::{Path, PathBuf};

use caseless::default_case_fold_str;

use crate::constants::MAX_LIMIT;
use crate::path_utils::{absolute_path, normalize_relpath};

#[derive(Debug)]
pub(crate) struct Config {
    pub(crate) pattern: String,
    pub(crate) roots: Vec<PathBuf>,
    pub(crate) root_display: Vec<String>,
    pub(crate) rel_base: Option<PathBuf>,
    pub(crate) regex: bool,
    pub(crate) target: String,
    pub(crate) path_scope: String,
    pub(crate) mode: String,
    pub(crate) case: String,
    pub(crate) limit: usize,
    pub(crate) cursor: Option<String>,
    pub(crate) offset: usize,
    pub(crate) context_lines: usize,
    pub(crate) globs: Vec<String>,
    pub(crate) excludes: Vec<String>,
}

pub(crate) fn parse_args() -> Result<Config, String> {
    let mut pattern: Option<String> = None;
    let mut roots: Vec<String> = Vec::new();
    let mut regex = false;
    let mut target = "content".to_string();
    let mut path_scope = "path".to_string();
    let mut mode = "files".to_string();
    let mut case = "smart".to_string();
    let mut limit = 50usize;
    let mut cursor: Option<String> = None;
    let mut context_lines = 0usize;
    let mut globs: Vec<String> = Vec::new();
    let mut excludes: Vec<String> = Vec::new();

    let mut args = env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                return Err(help_text());
            }
            "--pattern" => {
                pattern = Some(next_value(&mut args, "--pattern")?);
            }
            "--root" => {
                roots.push(next_value(&mut args, "--root")?);
            }
            "--regex" => {
                regex = true;
            }
            "--target" => {
                target = next_value(&mut args, "--target")?.to_ascii_lowercase();
            }
            "--path-scope" => {
                path_scope = next_value(&mut args, "--path-scope")?.to_ascii_lowercase();
            }
            "--mode" => {
                mode = next_value(&mut args, "--mode")?.to_ascii_lowercase();
            }
            "--case" => {
                case = next_value(&mut args, "--case")?.to_ascii_lowercase();
            }
            "--limit" => {
                let parsed = next_value(&mut args, "--limit")?
                    .parse::<usize>()
                    .map_err(|_| "limit must be a positive integer".to_string())?;
                if parsed == 0 {
                    return Err("limit must be a positive integer".to_string());
                }
                limit = min(parsed, MAX_LIMIT);
            }
            "--cursor" => {
                cursor = Some(next_value(&mut args, "--cursor")?);
            }
            "--context-lines" => {
                context_lines = next_value(&mut args, "--context-lines")?
                    .parse::<usize>()
                    .map_err(|_| "context-lines must be a non-negative integer".to_string())?;
            }
            "--glob" => {
                globs.push(normalize_relpath(&next_value(&mut args, "--glob")?));
            }
            "--exclude" => {
                excludes.push(normalize_relpath(&next_value(&mut args, "--exclude")?));
            }
            _ if arg.starts_with("--") => {
                return Err(format!("unknown option: {arg}"));
            }
            _ => {
                if pattern.is_none() {
                    pattern = Some(arg);
                } else {
                    return Err(format!("unexpected positional argument: {arg}"));
                }
            }
        }
    }

    let pattern = pattern.ok_or_else(|| "missing --pattern".to_string())?;
    if roots.is_empty() {
        roots.push(".".to_string());
    }
    let absolute_roots = roots
        .iter()
        .map(|root| absolute_path(Path::new(root)))
        .collect::<Vec<_>>();
    let rel_base = if absolute_roots.len() > 1 {
        Some(common_root_base(&absolute_roots))
    } else {
        None
    };
    let offset = cursor
        .as_deref()
        .and_then(|value| value.parse::<usize>().ok())
        .unwrap_or(0);

    Ok(Config {
        pattern,
        roots: absolute_roots,
        root_display: roots,
        rel_base,
        regex,
        target,
        path_scope,
        mode,
        case,
        limit,
        cursor,
        offset,
        context_lines,
        globs,
        excludes,
    })
}

fn next_value(args: &mut impl Iterator<Item = String>, flag: &str) -> Result<String, String> {
    args.next()
        .ok_or_else(|| format!("missing value for {flag}"))
}

fn common_root_base(roots: &[PathBuf]) -> PathBuf {
    let Some(first) = roots.first() else {
        return absolute_path(Path::new("."));
    };
    let mut common = root_base(first)
        .components()
        .map(|component| component.as_os_str().to_os_string())
        .collect::<Vec<OsString>>();

    for root in roots.iter().skip(1) {
        let parts = root_base(root)
            .components()
            .map(|component| component.as_os_str().to_os_string())
            .collect::<Vec<OsString>>();
        let shared = common
            .iter()
            .zip(parts.iter())
            .take_while(|(left, right)| common_component_eq(left, right))
            .count();
        common.truncate(shared);
    }

    let mut out = PathBuf::new();
    for component in common {
        out.push(component);
    }
    if out.as_os_str().is_empty() {
        absolute_path(Path::new("."))
    } else {
        out
    }
}

fn common_component_eq(left: &OsString, right: &OsString) -> bool {
    common_component_eq_for_platform(left, right, cfg!(windows))
}

fn common_component_eq_for_platform(left: &OsString, right: &OsString, windows: bool) -> bool {
    if windows {
        default_case_fold_str(left.to_string_lossy().as_ref())
            == default_case_fold_str(right.to_string_lossy().as_ref())
    } else {
        left == right
    }
}

fn root_base(root: &Path) -> PathBuf {
    if root.is_file() {
        root.parent()
            .filter(|path| !path.as_os_str().is_empty())
            .unwrap_or_else(|| Path::new("."))
            .to_path_buf()
    } else {
        root.to_path_buf()
    }
}

fn help_text() -> String {
    "Usage: codetool-explore-rust --pattern TEXT [--regex] [--target content|path|content_or_path] [--path-scope path|basename] [--root PATH ...] [--mode files|snippets|count] [--case smart|sensitive|insensitive] [--glob PATTERN] [--exclude PATTERN] [--limit N] [--cursor OFFSET] [--context-lines N]".to_string()
}

#[cfg(test)]
mod tests {
    use super::common_component_eq_for_platform;
    use std::ffi::OsString;

    #[test]
    fn windows_common_base_components_are_case_insensitive() {
        let left = OsString::from("Repo");
        let right = OsString::from("repo");

        assert!(common_component_eq_for_platform(&left, &right, true));
        assert!(!common_component_eq_for_platform(&left, &right, false));
    }
}
