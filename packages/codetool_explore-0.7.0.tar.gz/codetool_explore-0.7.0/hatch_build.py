"""Target-aware Hatch wheel hook for prebuilt Rust helper wheels."""

from __future__ import annotations

import os
import sysconfig
from pathlib import Path

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


PACKAGE = "codetool_explore"
BASE_BINARY = "codetool-explore-rust"
TARGET_RUNTIME_ENVS = (
    "CODETOOL_EXPLORE_TARGET_RUNTIME",
    "CODETOOL_TARGET_RUNTIME",
)
TARGET_WHEEL_TAG_ENVS = (
    "CODETOOL_EXPLORE_TARGET_WHEEL_TAG",
    "CODETOOL_TARGET_WHEEL_TAG",
)

RUNTIME_TO_WHEEL_TAG = {
    "linux-x86_64": "manylinux2014_x86_64",
    "linux-aarch64": "manylinux2014_aarch64",
    "macos-x86_64": "macosx_10_12_x86_64",
    "macos-arm64": "macosx_11_0_arm64",
    "windows-x86_64": "win_amd64",
    "windows-arm64": "win_arm64",
}

RUNTIME_ALIASES = {
    "linux-amd64": "linux-x86_64",
    "linux-x64": "linux-x86_64",
    "linux-arm64": "linux-aarch64",
    "darwin-x86_64": "macos-x86_64",
    "darwin-amd64": "macos-x86_64",
    "darwin-arm64": "macos-arm64",
    "darwin-aarch64": "macos-arm64",
    "macos-aarch64": "macos-arm64",
    "macosx-x86_64": "macos-x86_64",
    "macosx-arm64": "macos-arm64",
    "windows-amd64": "windows-x86_64",
    "windows-x64": "windows-x86_64",
    "windows-aarch64": "windows-arm64",
    "win-x86_64": "windows-x86_64",
    "win-amd64": "windows-x86_64",
    "win-arm64": "windows-arm64",
}


def _first_env(names: tuple[str, ...]) -> str | None:
    for name in names:
        value = os.environ.get(name)
        if value:
            return value
    return None


def normalize_runtime_key(value: str) -> str:
    key = value.strip().lower().replace("_", "-")
    key = key.replace("linux-x86-64", "linux-x86_64")
    key = key.replace("macos-x86-64", "macos-x86_64")
    key = key.replace("windows-x86-64", "windows-x86_64")
    key = key.replace("darwin-x86-64", "darwin-x86_64")
    key = RUNTIME_ALIASES.get(key, key)
    if key not in RUNTIME_TO_WHEEL_TAG:
        supported = ", ".join(sorted(RUNTIME_TO_WHEEL_TAG))
        raise ValueError(
            f"unsupported target runtime {value!r}; expected one of: {supported}"
        )
    return key


def host_runtime_key() -> str:
    platform_tag = sysconfig.get_platform().replace(".", "_").replace("-", "_").lower()
    # Convert common sysconfig tags to the stable runtime keys used by the package.
    if platform_tag.startswith("linux"):
        if "aarch64" in platform_tag or "arm64" in platform_tag:
            return "linux-aarch64"
        return "linux-x86_64"
    if platform_tag.startswith("macos"):
        if "arm64" in platform_tag or "aarch64" in platform_tag:
            return "macos-arm64"
        return "macos-x86_64"
    if platform_tag.startswith("win") or platform_tag.startswith("windows"):
        if "arm64" in platform_tag or "aarch64" in platform_tag:
            return "windows-arm64"
        return "windows-x86_64"
    return normalize_runtime_key(platform_tag.replace("_", "-"))


def target_runtime_key() -> str:
    value = _first_env(TARGET_RUNTIME_ENVS)
    return normalize_runtime_key(value) if value else host_runtime_key()


def wheel_tag_for_runtime(runtime_key: str) -> str:
    explicit = _first_env(TARGET_WHEEL_TAG_ENVS)
    if explicit:
        return explicit.strip().replace("-", "_").replace(".", "_")
    return RUNTIME_TO_WHEEL_TAG[normalize_runtime_key(runtime_key)]


def binary_names_for_runtime(runtime_key: str) -> list[str]:
    names = [f"{BASE_BINARY}-{runtime_key}"]
    if runtime_key == "linux-x86_64":
        names.append(f"{BASE_BINARY}-linux-x86_64")
    if runtime_key.endswith("arm64"):
        names.append(f"{BASE_BINARY}-{runtime_key.replace('arm64', 'aarch64')}")
    return names


class CustomBuildHook(BuildHookInterface):
    """Select exactly one staged Rust helper and mark the wheel platform-specific."""

    package = PACKAGE

    def initialize(self, version: str, build_data: dict) -> None:
        if self.target_name != "wheel":
            return

        runtime_key = target_runtime_key()
        package_bin = Path(self.root) / "src" / self.package / "_bin"
        selected = _find_staged_binary(package_bin, runtime_key)
        if selected is None:
            # Keep Python-only wheels possible; runtime still falls back to Python.
            if _first_env(TARGET_RUNTIME_ENVS):
                raise FileNotFoundError(
                    f"missing staged Rust helper for {runtime_key} in {package_bin}"
                )
            return

        build_data["pure_python"] = False
        build_data["tag"] = f"py3-none-{wheel_tag_for_runtime(runtime_key)}"

        force_include = build_data.setdefault("force_include", {})
        src_root = Path(self.root) / "src"
        force_include[selected.relative_to(self.root).as_posix()] = (
            selected.relative_to(src_root).as_posix()
        )


def _find_staged_binary(package_bin: Path, runtime_key: str) -> Path | None:
    suffixes = (".exe", "") if runtime_key.startswith("windows-") else ("", ".exe")
    for name in binary_names_for_runtime(runtime_key):
        for suffix in suffixes:
            candidate = package_bin / f"{name}{suffix}"
            if candidate.is_file():
                return candidate
    return None
