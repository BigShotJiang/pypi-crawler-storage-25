"""Public exception taxonomy for codetool-explore."""

from __future__ import annotations


class ExploreError(Exception):
    """Base class for controlled codetool-explore failures."""


class ExploreArgumentError(ExploreError, ValueError):
    """Raised for invalid public explore arguments."""


class ExplorePatternError(ExploreArgumentError):
    """Raised for invalid or unsupported search patterns."""


class ExploreRootError(ExploreError, OSError):
    """Raised when the requested root/path cannot be explored."""


class ExploreBackendError(ExploreError, RuntimeError):
    """Raised when a selected backend fails at runtime."""
