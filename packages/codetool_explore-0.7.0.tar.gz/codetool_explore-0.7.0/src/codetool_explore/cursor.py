"""Cursor and pagination helpers for compact search result pages."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TypeVar

from .errors import ExploreArgumentError

T = TypeVar("T")

DEFAULT_LIMIT = 50
MAX_LIMIT = 1_000


def normalize_limit(limit: int | None) -> int:
    """Return a safe positive result limit.

    The public API defaults to 50 results. A hard cap keeps accidental huge
    responses from flooding an agent context window.
    """

    if limit is None:
        return DEFAULT_LIMIT
    try:
        value = int(limit)
    except (TypeError, ValueError) as exc:
        raise ExploreArgumentError("limit must be a positive integer") from exc
    if value <= 0:
        raise ExploreArgumentError("limit must be a positive integer")
    return min(value, MAX_LIMIT)


def decode_cursor(cursor: str | int | None) -> int:
    """Decode a simple opaque-enough offset cursor.

    Cursors are decimal offsets on purpose: compact, stable across Python and
    the std-only Rust CLI, and easy to recover from if a caller logs them.
    Invalid cursors are treated as the first page instead of failing a search.
    """

    if cursor in (None, ""):
        return 0
    try:
        offset = int(str(cursor), 10)
    except (TypeError, ValueError):
        return 0
    return max(0, offset)


def encode_cursor(offset: int) -> str:
    """Encode the next result offset as a compact cursor string."""

    return str(max(0, int(offset)))


def page_items(
    items: Sequence[T],
    *,
    limit: int | None = DEFAULT_LIMIT,
    cursor: str | int | None = None,
) -> tuple[list[T], bool, str | None, int]:
    """Return ``(page, truncated, next_cursor, offset)`` for ``items``."""

    safe_limit = normalize_limit(limit)
    offset = min(decode_cursor(cursor), len(items))
    end = offset + safe_limit
    page = list(items[offset:end])
    truncated = end < len(items)
    next_cursor = encode_cursor(end) if truncated else None
    return page, truncated, next_cursor, offset
