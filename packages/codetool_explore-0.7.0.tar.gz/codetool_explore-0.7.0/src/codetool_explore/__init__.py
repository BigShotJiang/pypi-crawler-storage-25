"""Fast workspace search for coding-agent tools.

The main public API is intentionally a single function:

```
from codetool_explore import explore
```

`explore()` can target file contents, file paths, a content/path union, read-only
file ranges, or one-level directory listings. Patterns are regexes by default
for search targets. ``backend="auto"`` dispatches searchable targets to a
bundled or development Rust CLI accelerator when available, with the pure-Python
stdlib backend as fallback. Use ``result_format="text"`` for maximally compact
raw text output. Controlled failures raise ``ExploreError`` subclasses.
"""

from __future__ import annotations

from .api import explore
from .errors import (
    ExploreArgumentError,
    ExploreBackendError,
    ExploreError,
    ExplorePatternError,
    ExploreRootError,
)

__all__ = [
    "explore",
    "ExploreArgumentError",
    "ExploreBackendError",
    "ExploreError",
    "ExplorePatternError",
    "ExploreRootError",
]
