"""Compact result shaping for public search output.

The search backends return the full, compatibility-preserving result shape.
This module owns the API output compression layer that runs after any backend
finishes, keeping location/count/pagination data while abbreviating low-value
metadata for coding-agent token efficiency.
"""

from __future__ import annotations


def _next_request(result: dict[str, object]) -> dict[str, object] | None:
    next_cursor = result.get("next_cursor")
    if next_cursor is None:
        return None
    request: dict[str, object] = {
        "pattern": result.get("pattern"),
        "root": result.get("root"),
        "cursor": next_cursor,
        "limit": result.get("limit"),
        "backend": result.get("backend_requested", result.get("backend")),
    }
    for key in ("target", "path_scope", "mode", "case", "regex", "glob", "exclude"):
        if key in result:
            request[key] = result[key]
    return request


def _backend_info(result: dict[str, object]) -> dict[str, object]:
    backend: dict[str, object] = {"selected": result.get("backend")}
    if "backend_requested" in result:
        backend["requested"] = result["backend_requested"]
    if "backend_fallback" in result:
        backend["fallback"] = result["backend_fallback"]
    return backend


def _page_info(result: dict[str, object], returned: int) -> dict[str, object]:
    page: dict[str, object] = {
        "returned": result.get("returned", returned),
        "limit": result.get("limit"),
        "offset": result.get("offset"),
        "truncated": result.get("truncated", False),
        "next_cursor": result.get("next_cursor"),
    }
    next_request = _next_request(result)
    if next_request is not None:
        page["next_request"] = next_request
    return page


def _compress_read_result(result: dict[str, object]) -> dict[str, object]:
    output: dict[str, object] = {
        "format": "compressed",
        "target": "read",
        "backend": _backend_info(result),
        "path": result.get("path"),
        "start_line": result.get("start_line"),
        "line_count": result.get("line_count", result.get("returned", 0)),
        "page": _page_info(result, int(result.get("returned", 0) or 0)),
        "text": result.get("text", ""),
    }
    if result.get("content_truncated"):
        output["content_truncated"] = True
    return output


def _compress_list_result(result: dict[str, object]) -> dict[str, object]:
    entries: list[dict[str, object]] = []
    for entry in result.get("entries", []):
        if not isinstance(entry, dict):
            continue
        compact: dict[str, object] = {}
        if "path" in entry:
            compact["p"] = entry["path"]
        if "kind" in entry:
            compact["k"] = entry["kind"]
        entries.append(compact)

    return {
        "format": "compressed",
        "target": "list",
        "backend": _backend_info(result),
        "path": result.get("path"),
        "page": _page_info(result, len(entries)),
        "totals": {
            "entries": result.get("total_entries", 0),
            "files": result.get("total_files", 0),
            "dirs": result.get("total_dirs", 0),
        },
        "entries": entries,
    }


def compress_result(result: dict[str, object]) -> dict[str, object]:
    """Return the default compact structured search result shape."""

    target = result.get("target", "content")
    if target == "read":
        return _compress_read_result(result)
    if target == "list":
        return _compress_list_result(result)

    mode = str(result.get("mode", "files"))
    compact_matches: list[dict[str, object]] = []
    for match in result.get("matches", []):
        if not isinstance(match, dict):
            continue
        compact: dict[str, object] = {}
        if "path" in match:
            compact["p"] = match["path"]
        if mode != "files":
            if "line" in match:
                compact["l"] = match["line"]
            elif "first_line" in match:
                compact["l"] = match["first_line"]
            if "count" in match:
                compact["c"] = match["count"]
        if "snippet" in match:
            compact["s"] = match["snippet"]
        if "context" in match:
            compact["ctx"] = match["context"]
        if "match_kind" in match:
            compact["m"] = match["match_kind"]
        if "kind" in match and match.get("kind") != "file":
            compact["k"] = match["kind"]
        compact_matches.append(compact)

    totals: dict[str, object] = {
        "files": result.get("total_files", 0),
        "matches": result.get("total_matches", 0),
        "count": result.get("count", 0),
    }
    target = result.get("target", "content")
    if target != "content":
        totals["path"] = result.get("path_matches", 0)
        totals["content_files"] = result.get("content_files", 0)
        totals["content_count"] = result.get("content_count", 0)

    output: dict[str, object] = {
        "format": "compressed",
        "mode": mode,
        "backend": _backend_info(result),
        "totals": totals,
        "page": _page_info(result, len(compact_matches)),
        "matches": compact_matches,
    }
    if target != "content" and "target" in result:
        output["target"] = result["target"]
    return output
