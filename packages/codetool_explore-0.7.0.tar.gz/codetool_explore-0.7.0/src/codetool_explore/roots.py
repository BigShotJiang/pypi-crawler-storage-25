"""Root argument normalisation shared by search backends."""

from __future__ import annotations

import os
import shlex
from collections.abc import Iterable
from dataclasses import dataclass

from .errors import ExploreArgumentError, ExploreRootError


Pathish = str | os.PathLike[str]
RootInput = Pathish | Iterable[Pathish]


@dataclass(frozen=True)
class SearchRoot:
    """One validated root path."""

    raw: str
    abs_path: str


@dataclass(frozen=True)
class NormalizedRoots:
    """Validated root set plus multi-root display/path metadata."""

    roots: tuple[SearchRoot, ...]
    from_sequence: bool
    rel_base: str | None
    display: str | list[str]

    @property
    def has_multiple(self) -> bool:
        return len(self.roots) > 1


def _is_root_sequence(value: object) -> bool:
    return isinstance(value, Iterable) and not isinstance(
        value, (str, bytes, os.PathLike)
    )


def _coerce_path(value: object) -> str:
    try:
        path = os.fspath(value)
    except TypeError as exc:
        raise ExploreArgumentError(
            "root must be a path string or a list of path strings"
        ) from exc
    if not isinstance(path, str):
        raise ExploreArgumentError(
            "root must be a path string or a list of path strings"
        )
    return path


def _is_searchable_path(raw_path: str) -> bool:
    abs_path = os.path.abspath(raw_path)
    return os.path.isdir(abs_path) or os.path.isfile(abs_path)


def _strip_matching_quotes(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def _split_space_separated_roots(raw_path: str) -> tuple[str, ...] | None:
    """Split a mistaken space-separated root string when it is unambiguous."""

    if not raw_path.strip() or not any(char.isspace() for char in raw_path):
        return None
    if _is_searchable_path(raw_path):
        return None
    try:
        parts = tuple(
            _strip_matching_quotes(part) for part in shlex.split(raw_path, posix=False)
        )
    except ValueError:
        return None
    if len(parts) < 2 or not all(parts):
        return None
    if not all(_is_searchable_path(part) for part in parts):
        return None
    return parts


def _common_rel_base(abs_roots: tuple[str, ...]) -> str:
    common_inputs = [
        os.path.dirname(path) if os.path.isfile(path) else path for path in abs_roots
    ]
    try:
        common = os.path.commonpath(common_inputs)
    except ValueError:
        common = os.path.abspath(os.curdir)
    if os.path.isfile(common):
        common = os.path.dirname(common)
    return common or os.path.abspath(os.curdir)


def normalize_search_roots(root: RootInput) -> NormalizedRoots:
    """Validate ``root`` as one path or a non-empty iterable of paths."""

    from_sequence = _is_root_sequence(root)
    if from_sequence:
        raw_values = tuple(root)  # type: ignore[arg-type]
        if not raw_values:
            raise ExploreArgumentError("root list must not be empty")
    else:
        allow_implicit_split = isinstance(root, str)
        raw_path = _coerce_path(root)
        split_roots = (
            _split_space_separated_roots(raw_path)
            if allow_implicit_split
            else None
        )
        if split_roots is None:
            raw_values = (raw_path,)
        else:
            raw_values = split_roots
            from_sequence = True

    raw_paths = tuple(_coerce_path(value) for value in raw_values)
    search_roots: list[SearchRoot] = []
    for raw_path in raw_paths:
        abs_path = os.path.abspath(raw_path)
        if not (os.path.isdir(abs_path) or os.path.isfile(abs_path)):
            if not os.path.exists(abs_path):
                raise ExploreRootError(f"root does not exist: {raw_path!r}")
            raise ExploreRootError(
                f"root is neither a directory nor file: {raw_path!r}"
            )
        search_roots.append(SearchRoot(raw=raw_path, abs_path=abs_path))

    rel_base = (
        _common_rel_base(tuple(item.abs_path for item in search_roots))
        if len(search_roots) > 1
        else None
    )
    display: str | list[str] = list(raw_paths) if from_sequence else raw_paths[0]
    return NormalizedRoots(
        roots=tuple(search_roots),
        from_sequence=from_sequence,
        rel_base=rel_base,
        display=display,
    )
