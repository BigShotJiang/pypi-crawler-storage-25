"""Public API for codetool-explore."""

from __future__ import annotations

import os
import re
from collections.abc import Iterable

from .compression import compress_result
from .errors import ExploreArgumentError, ExploreBackendError, ExplorePatternError
from .explorer import list_path_target, read_file_target
from .python_backend import resolve_case, search_python
from .roots import RootInput
from .rust_backend import RustBackendUnavailable, find_rust_binary, search_rust
from .text_output import format_text_result

BACKENDS = frozenset({"auto", "python", "rust", "native"})
SEARCH_TARGETS = frozenset({"content", "path", "content_or_path"})
EXPLORATION_TARGETS = frozenset({"read", "list"})
TARGETS = SEARCH_TARGETS | EXPLORATION_TARGETS
RESULT_FORMATS = frozenset({"compressed", "full", "text"})
RESULT_FORMAT_ALIASES = {
    "raw": "text",
    "plain": "text",
    "plaintext": "text",
}
EMPTY_REGEX_SAMPLES = ("", "a", "abc", " a ", "_", "0", "é")


def _normalize_api_target(target: str) -> str:
    selected_target = str(target or "content").lower()
    if selected_target not in TARGETS:
        raise ExploreArgumentError(
            "target must be one of: content, path, content_or_path, read, list"
        )
    return selected_target


def _normalize_result_format(
    result_format: str | None,
    *,
    target: str = "content",
) -> str:
    default = "text" if target in EXPLORATION_TARGETS else "compressed"
    selected_format = str(result_format or default).lower()
    selected_format = RESULT_FORMAT_ALIASES.get(selected_format, selected_format)
    if selected_format not in RESULT_FORMATS:
        raise ExploreArgumentError(
            "result_format must be one of: compressed, full, text"
        )
    return selected_format


def _finalize_result(result: dict[str, object], result_format: str) -> dict[str, object] | str:
    selected_format = _normalize_result_format(
        result_format,
        target=str(result.get("target", "content")),
    )
    if selected_format == "full":
        return result
    if selected_format == "text":
        return format_text_result(result)
    return compress_result(result)


def _regex_can_produce_empty_match(pattern: str, *, case: str) -> bool:
    requested_case = str(case or "smart").lower()
    _, case_sensitive = resolve_case(requested_case, pattern)
    flags = 0 if case_sensitive else re.IGNORECASE
    try:
        compiled = re.compile(pattern, flags)
    except re.error as exc:
        raise ExplorePatternError(f"invalid regex: {exc}") from exc
    return any(
        any(match.start() == match.end() for match in compiled.finditer(sample))
        for sample in EMPTY_REGEX_SAMPLES
    )


def _materialize_root_for_fallback(root: RootInput) -> RootInput:
    if isinstance(root, Iterable) and not isinstance(root, (str, bytes, os.PathLike)):
        return tuple(root)
    return root


def explore(
    pattern: str,
    root: RootInput = ".",
    target: str = "content",
    regex: bool = True,
    path_scope: str = "path",
    glob: str | Iterable[str] | None = None,
    exclude: str | Iterable[str] | None = None,
    case: str = "smart",
    mode: str = "files",
    context_lines: int = 0,
    limit: int = 50,
    cursor: str | int | None = None,
    backend: str = "auto",
    result_format: str | None = None,
    start_line: int = 1,
) -> dict[str, object] | str:
    """Search, read, or list workspace files below ``root``.

    ``target`` selects what the pattern is matched against:
    ``"content"`` searches file contents, ``"path"`` searches relative file
    paths without opening files, and ``"content_or_path"`` returns files
    matching either.
    ``"read"`` treats ``pattern`` as one file path and returns a controlled
    line range for each root. ``"list"`` treats ``pattern`` as one
    file/directory path and returns a one-level listing for each root.
    Patterns are interpreted as regex by default; pass ``regex=False`` for exact
    literal search. ``root`` may be one directory/file path or a non-empty list
    of directory/file paths. Multi-root searches/reads/listings report paths
    relative to the roots' common base, so sibling roots keep prefixes such as
    ``src/...``.
    To tolerate common JSON/tool-call mistakes, a whitespace-separated root
    string is treated as multiple roots only when that exact path does not
    exist and every split token is an existing file or directory.
    ``backend="auto"`` prefers the optional Rust CLI accelerator when available
    and falls back to the pure-Python backend otherwise. Regex searches use the
    Rust helper when it supports the requested syntax; Python remains the
    compatibility fallback.

    Search results are returned in a compact structured shape by default; read
    results default to plain text (with path headers only when multiple files
    are read) and list results default to tree-compressed text. Pass
    ``result_format="full"`` to receive the pre-compression backend result
    dictionary unchanged. Pass ``result_format="text"`` (or ``"raw"``) for an
    RTK-inspired plain-text rendering optimized for token compression.
    """

    selected = str(backend or "auto").lower()
    if selected not in BACKENDS:
        raise ExploreArgumentError(
            "backend must be one of: auto, python, rust, native"
        )
    normalised_target = _normalize_api_target(target)
    selected_format = _normalize_result_format(
        result_format,
        target=normalised_target,
    )

    if normalised_target == "read":
        result = read_file_target(
            pattern,
            root=root,
            start_line=start_line,
            limit=limit,
            cursor=cursor,
        )
        if selected != "python":
            result["backend_requested"] = selected
        return _finalize_result(result, selected_format)

    if normalised_target == "list":
        result = list_path_target(
            pattern,
            root=root,
            glob=glob,
            exclude=exclude,
            limit=limit,
            cursor=cursor,
        )
        if selected != "python":
            result["backend_requested"] = selected
        return _finalize_result(result, selected_format)

    if selected == "python":
        result = search_python(
            pattern,
            root=root,
            regex=regex,
            target=normalised_target,
            path_scope=path_scope,
            glob=glob,
            exclude=exclude,
            case=case,
            mode=mode,
            context_lines=context_lines,
            limit=limit,
            cursor=cursor,
        )
        return _finalize_result(result, selected_format)

    if selected in {"rust", "native"}:
        result = search_rust(
            pattern,
            root=root,
            regex=regex,
            target=normalised_target,
            path_scope=path_scope,
            glob=glob,
            exclude=exclude,
            case=case,
            mode=mode,
            context_lines=context_lines,
            limit=limit,
            cursor=cursor,
        )
        return _finalize_result(result, selected_format)

    # auto: prefer Rust if discoverable, then fall back to Python. The fallback
    # preserves Python-regex compatibility for syntax unsupported by Rust's
    # regex engine.
    root_for_auto = _materialize_root_for_fallback(root)
    rust_binary = find_rust_binary()
    if rust_binary:
        fallback_reason: str | None = None
        if (
            regex
            and normalised_target in {"content", "content_or_path"}
            and isinstance(pattern, str)
            and _regex_can_produce_empty_match(pattern, case=case)
        ):
            fallback_reason = (
                "Rust backend skipped for regex patterns that can match empty "
                "spans; Python preserves re.finditer count semantics"
            )
        if fallback_reason is None:
            try:
                result = search_rust(
                    pattern,
                    root=root_for_auto,
                    regex=regex,
                    target=normalised_target,
                    path_scope=path_scope,
                    glob=glob,
                    exclude=exclude,
                    case=case,
                    mode=mode,
                    context_lines=context_lines,
                    limit=limit,
                    cursor=cursor,
                    binary=rust_binary,
                )
                result["backend_requested"] = "auto"
                return _finalize_result(result, selected_format)
            except (
                RustBackendUnavailable,
                ExploreBackendError,
                ExplorePatternError,
                ExploreArgumentError,
                RuntimeError,
                ValueError,
            ) as exc:
                fallback_reason = str(exc)
    else:
        fallback_reason = "Rust backend unavailable"

    result = search_python(
        pattern,
        root=root_for_auto,
        regex=regex,
        target=normalised_target,
        path_scope=path_scope,
        glob=glob,
        exclude=exclude,
        case=case,
        mode=mode,
        context_lines=context_lines,
        limit=limit,
        cursor=cursor,
    )
    result["backend_requested"] = "auto"
    result["backend_fallback"] = fallback_reason
    return _finalize_result(result, selected_format)
