"""Read-only workspace exploration targets for the public API."""

from __future__ import annotations

import codecs
import os
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

from .cursor import normalize_limit, page_items
from .errors import ExploreArgumentError, ExploreRootError
from .ignore import (
    matches_glob,
    normalize_patterns,
    normalize_relpath,
    relative_path,
    should_ignore_path,
)
from .python_backend.constants import binary_check_bytes
from .python_backend.ignore_rules import ignore_patterns_for_root
from .python_backend.models import IgnorePatterns
from .roots import NormalizedRoots, RootInput, SearchRoot, normalize_search_roots

MAX_READ_CHARS = 100_000
READ_CHUNK_BYTES = 8192


@dataclass(frozen=True)
class ResolvedExplorePath:
    """One read/list path resolved against a single root."""

    query: str
    abs_path: str
    display_path: str
    root_display: str | list[str]
    display_base: str | None
    root_base: str
    search_root_abs: str
    root_is_file: bool
    rel_base_abs: str | None


def read_file_target(
    path: object,
    *,
    root: RootInput = ".",
    start_line: int = 1,
    limit: int = 50,
    cursor: str | int | None = None,
) -> dict[str, object]:
    """Return a controlled line range from one text file under each root."""

    safe_limit = normalize_limit(limit)
    safe_start_line = _normalize_start_line(start_line, cursor=cursor)
    resolved_paths = _resolve_explore_paths(
        path,
        root=root,
        target="read",
        allow_multiple=True,
    )
    files: list[dict[str, object]] = []
    seen_files: set[str] = set()
    for resolved in resolved_paths:
        identity = os.path.normcase(os.path.abspath(resolved.abs_path))
        if identity in seen_files:
            continue
        seen_files.add(identity)
        error_path = (
            resolved.query if len(resolved_paths) == 1 else resolved.display_path
        )
        files.append(
            _read_resolved_file(
                resolved,
                error_path=error_path,
                start_line=safe_start_line,
                limit=safe_limit,
            )
        )

    text = _format_read_files_text(files)
    returned_lines = sum(int(item.get("returned", 0) or 0) for item in files)
    content_truncated = any(bool(item.get("content_truncated")) for item in files)
    next_cursor = next(
        (
            str(item_next)
            for item in files
            if (item_next := item.get("next_cursor")) not in (None, "")
        ),
        None,
    )
    path_display: object
    if len(files) == 1:
        path_display = files[0]["path"]
    else:
        path_display = [item["path"] for item in files]

    result: dict[str, object] = {
        "pattern": resolved_paths[0].query,
        "root": resolved_paths[0].root_display,
        "target": "read",
        "mode": "read",
        "path": path_display,
        "start_line": safe_start_line,
        "limit": safe_limit,
        "cursor": None if cursor in (None, "") else str(cursor),
        "text": text,
        "returned": returned_lines,
        "line_count": returned_lines,
        "count": returned_lines,
        "file_count": len(files),
        "truncated": bool(next_cursor or content_truncated),
        "content_truncated": content_truncated,
        "next_cursor": next_cursor,
        "offset": safe_start_line - 1,
        "backend": "python",
    }
    if len(files) > 1:
        result["files"] = files
    return result


def list_path_target(
    path: object,
    *,
    root: RootInput = ".",
    glob: str | Iterable[str] | None = None,
    exclude: str | Iterable[str] | None = None,
    limit: int = 50,
    cursor: str | int | None = None,
) -> dict[str, object]:
    """Return one ls-like page for a file or one directory level."""

    safe_limit = normalize_limit(limit)
    resolved_paths = _resolve_explore_paths(
        path,
        root=root,
        target="list",
        allow_empty=True,
        allow_multiple=True,
    )
    glob_patterns = normalize_patterns(glob)
    exclude_patterns = normalize_patterns(exclude)

    entries: list[dict[str, object]] = []
    seen_entries: set[tuple[str, str]] = set()
    for resolved in resolved_paths:
        error_path = (
            resolved.query if len(resolved_paths) == 1 else resolved.display_path
        )
        if not os.path.exists(resolved.abs_path):
            raise ExploreRootError(f"list target does not exist: {error_path!r}")
        if os.path.isfile(resolved.abs_path):
            root_entries = _list_single_file(
                resolved,
                glob_patterns=glob_patterns,
                exclude_patterns=exclude_patterns,
            )
        elif os.path.isdir(resolved.abs_path):
            root_entries = _list_directory(
                resolved,
                glob_patterns=glob_patterns,
                exclude_patterns=exclude_patterns,
            )
        else:
            raise ExploreRootError(
                f"list target is neither a directory nor file: {error_path!r}"
            )
        for entry in root_entries:
            identity = _entry_identity(entry)
            if identity in seen_entries:
                continue
            seen_entries.add(identity)
            entries.append(entry)

    page, truncated, next_cursor, offset = page_items(
        entries, limit=safe_limit, cursor=cursor
    )
    total_files = sum(1 for entry in entries if entry.get("kind") == "file")
    total_dirs = sum(1 for entry in entries if entry.get("kind") == "dir")
    path_display: object
    if len(resolved_paths) == 1:
        path_display = resolved_paths[0].display_path
    else:
        path_display = [resolved.display_path for resolved in resolved_paths]

    result: dict[str, object] = {
        "pattern": resolved_paths[0].query,
        "root": resolved_paths[0].root_display,
        "target": "list",
        "mode": "list",
        "path": path_display,
        "entries": page,
        "returned": len(page),
        "total_entries": len(entries),
        "total_matches": len(entries),
        "count": len(entries),
        "total_files": total_files,
        "total_dirs": total_dirs,
        "truncated": truncated,
        "next_cursor": next_cursor,
        "offset": offset,
        "limit": safe_limit,
        "cursor": None if cursor in (None, "") else str(cursor),
        "backend": "python",
    }
    if glob_patterns:
        result["glob"] = list(glob_patterns)
    if exclude_patterns:
        result["exclude"] = list(exclude_patterns)
    return result


def _resolve_explore_path(
    path: object,
    *,
    root: RootInput,
    target: str,
    allow_empty: bool = False,
) -> ResolvedExplorePath:
    return _resolve_explore_paths(
        path,
        root=root,
        target=target,
        allow_empty=allow_empty,
        allow_multiple=False,
    )[0]


def _resolve_explore_paths(
    path: object,
    *,
    root: RootInput,
    target: str,
    allow_empty: bool = False,
    allow_multiple: bool = False,
) -> tuple[ResolvedExplorePath, ...]:
    root_set = normalize_search_roots(root)
    if root_set.has_multiple and not allow_multiple:
        raise ExploreArgumentError(f"target={target!r} supports one root at a time")

    try:
        query = os.fspath(path)
    except TypeError as exc:
        raise ExploreArgumentError(f"{target} path must be a string") from exc
    if not isinstance(query, str):
        raise ExploreArgumentError(f"{target} path must be a string")
    if not query:
        if allow_empty:
            query = "."
        else:
            raise ExploreArgumentError(f"{target} path must not be empty")

    return tuple(
        _resolve_path_for_search_root(
            query,
            search_root=search_root,
            root_set=root_set,
            target=target,
        )
        for search_root in root_set.roots
    )


def _resolve_path_for_search_root(
    query: str,
    *,
    search_root: SearchRoot,
    root_set: NormalizedRoots,
    target: str,
) -> ResolvedExplorePath:
    root_abs = search_root.abs_path
    root_is_file = os.path.isfile(root_abs)
    root_base = root_abs if os.path.isdir(root_abs) else os.path.dirname(root_abs)
    if target == "read" and root_is_file:
        display_base = root_set.rel_base if root_set.has_multiple else root_base
        display_path = _display_path(root_abs, display_base)
        return ResolvedExplorePath(
            query=query,
            abs_path=root_abs,
            display_path=display_path,
            root_display=root_set.display,
            display_base=display_base,
            root_base=root_base,
            search_root_abs=root_abs,
            root_is_file=True,
            rel_base_abs=root_set.rel_base,
        )
    if os.path.isabs(query):
        abs_path = os.path.abspath(query)
        base = root_set.rel_base if root_set.has_multiple else root_base
        display_base = base if base and _is_under(abs_path, base) else None
    else:
        abs_path = (
            os.path.abspath(root_abs)
            if root_is_file and query == "."
            else os.path.abspath(os.path.join(root_base, query))
        )
        display_base = root_set.rel_base if root_set.has_multiple else root_base
    display_path = _display_path(abs_path, display_base)
    return ResolvedExplorePath(
        query=query,
        abs_path=abs_path,
        display_path=display_path,
        root_display=root_set.display,
        display_base=display_base,
        root_base=root_base,
        search_root_abs=root_abs,
        root_is_file=root_is_file,
        rel_base_abs=root_set.rel_base,
    )


def _normalize_start_line(start_line: int, *, cursor: str | int | None) -> int:
    if cursor not in (None, ""):
        try:
            value = int(str(cursor), 10)
        except (TypeError, ValueError):
            return 1
        return max(1, value)
    try:
        value = int(start_line)
    except (TypeError, ValueError) as exc:
        raise ExploreArgumentError("start_line must be a positive integer") from exc
    if value <= 0:
        raise ExploreArgumentError("start_line must be a positive integer")
    return value


def _read_resolved_file(
    resolved: ResolvedExplorePath,
    *,
    error_path: str,
    start_line: int,
    limit: int,
) -> dict[str, object]:
    if not os.path.exists(resolved.abs_path):
        raise ExploreRootError(f"file does not exist: {error_path!r}")
    if os.path.isdir(resolved.abs_path):
        raise ExploreRootError(f"read target is a directory: {error_path!r}")
    if not os.path.isfile(resolved.abs_path):
        raise ExploreRootError(f"read target is not a file: {error_path!r}")

    _raise_if_binary(resolved.abs_path, resolved.display_path)
    text, returned_lines, has_more_lines, content_truncated = _read_text_range(
        resolved.abs_path,
        display_path=resolved.display_path,
        start_line=start_line,
        limit=limit,
    )
    next_cursor = (
        str(start_line + returned_lines)
        if has_more_lines and returned_lines > 0
        else None
    )
    return {
        "path": resolved.display_path,
        "text": text,
        "returned": returned_lines,
        "line_count": returned_lines,
        "content_truncated": content_truncated,
        "next_cursor": next_cursor,
    }


def _format_read_files_text(files: list[dict[str, object]]) -> str:
    if len(files) == 1:
        return str(files[0].get("text", ""))
    sections: list[str] = []
    for item in files:
        header = f"{item.get('path', '')}:"
        text = str(item.get("text", ""))
        if text or int(item.get("returned", 0) or 0) > 0:
            sections.append(f"{header}\n{text}")
        else:
            sections.append(header)
    return "\n".join(sections)


def _is_under(path: str, base: str) -> bool:
    try:
        common_path = os.path.commonpath(
            (os.path.abspath(path), os.path.abspath(base))
        )
    except ValueError:
        return False
    return common_path == os.path.abspath(base)


def _display_path(path: str, base: str | None) -> str:
    if base is not None:
        return relative_path(path, base) or "."
    return normalize_relpath(os.path.abspath(path)) or "."


def _raise_if_binary(path: str, display_path: str) -> None:
    try:
        with open(path, "rb") as handle:
            probe = handle.read(binary_check_bytes())
    except OSError as exc:
        _raise_read_error(display_path, exc)
    if b"\x00" in probe:
        raise ExploreRootError(f"file appears to be binary: {display_path!r}")


def _read_text_range(
    path: str,
    *,
    display_path: str,
    start_line: int,
    limit: int,
) -> tuple[str, int, bool, bool]:
    lines: list[str] = []
    current_parts: list[str] = []
    output_chars = 0
    current_line_started = False
    line_number = 1
    has_more_lines = False
    content_truncated = False
    stopped_early = False

    def start_output_line() -> bool:
        nonlocal current_line_started, output_chars, content_truncated
        if current_line_started:
            return True
        if len(lines) >= limit:
            return False
        separator_chars = 1 if lines else 0
        if output_chars + separator_chars > MAX_READ_CHARS:
            content_truncated = True
            return False
        output_chars += separator_chars
        current_line_started = True
        return True

    def append_fragment(fragment: str) -> bool:
        nonlocal output_chars, content_truncated
        if not start_output_line():
            return False
        remaining = MAX_READ_CHARS - output_chars
        if remaining <= 0:
            content_truncated = True
            return False
        if len(fragment) > remaining:
            current_parts.append(fragment[:remaining])
            output_chars += remaining
            content_truncated = True
            return False
        current_parts.append(fragment)
        output_chars += len(fragment)
        return True

    def finish_output_line() -> None:
        nonlocal current_line_started, current_parts
        line = "".join(current_parts)
        if line.endswith("\r"):
            line = line[:-1]
        lines.append(line)
        current_parts = []
        current_line_started = False

    def process_text(text: str) -> bool:
        nonlocal content_truncated, has_more_lines, line_number
        while text:
            if line_number < start_line:
                newline_index = text.find("\n")
                if newline_index < 0:
                    return True
                line_number += 1
                text = text[newline_index + 1 :]
                continue

            if not current_line_started and len(lines) >= limit:
                has_more_lines = True
                return False

            newline_index = text.find("\n")
            if newline_index < 0:
                if not append_fragment(text):
                    return False
                return True

            fragment = text[:newline_index]
            if fragment and not append_fragment(fragment):
                return False
            if not fragment and not start_output_line():
                has_more_lines = True
                return False
            finish_output_line()
            line_number += 1
            text = text[newline_index + 1 :]
        return True

    try:
        decoder = codecs.getincrementaldecoder("utf-8")()
        with open(path, "rb") as handle:
            while True:
                chunk = handle.read(READ_CHUNK_BYTES)
                if not chunk:
                    break
                if b"\x00" in chunk:
                    raise ExploreRootError(
                        f"file appears to be binary: {display_path!r}"
                    )
                text = decoder.decode(chunk)
                if text and not process_text(text):
                    stopped_early = True
                    break
            else_text = "" if stopped_early else decoder.decode(b"", final=True)
            if else_text and not (has_more_lines or content_truncated):
                process_text(else_text)
        if current_line_started and len(lines) < limit:
            finish_output_line()
    except UnicodeDecodeError as exc:
        raise ExploreRootError(
            f"file is not valid UTF-8 text: {display_path!r}"
        ) from exc
    except ExploreRootError:
        raise
    except OSError as exc:
        _raise_read_error(display_path, exc)

    return "\n".join(lines), len(lines), has_more_lines, content_truncated


def _raise_read_error(display_path: str, exc: OSError) -> None:
    message = getattr(exc, "strerror", None) or str(exc)
    raise ExploreRootError(f"cannot read file {display_path!r}: {message}") from exc


def _list_single_file(
    resolved: ResolvedExplorePath,
    *,
    glob_patterns: tuple[str, ...],
    exclude_patterns: tuple[str, ...],
) -> list[dict[str, object]]:
    parent = os.path.dirname(resolved.abs_path) or os.curdir
    rel_path = _display_path(resolved.abs_path, resolved.display_base)
    api_ignore_patterns, api_ignore_base = _listing_ignore_patterns(
        resolved,
        is_file=True,
    )
    local_ignore_patterns = ignore_patterns_for_root(
        resolved.abs_path,
        rel_base_abs=None,
        is_file=True,
    )
    if should_ignore_path(
        rel_path,
        is_dir=False,
        exclude_patterns=exclude_patterns,
        ignore_patterns=api_ignore_patterns.common,
        root_ignore_patterns=api_ignore_patterns.root,
        common_rel_path=relative_path(resolved.abs_path, api_ignore_base),
    ) or _is_ignored_by_local_listing_patterns(
        resolved.abs_path,
        rel_path=rel_path,
        is_dir=False,
        local_base=parent,
        root_ignore_patterns=local_ignore_patterns.root,
    ) or not matches_glob(rel_path, glob_patterns):
        return []
    return [{"path": rel_path, "kind": "file"}]


def _list_directory(
    resolved: ResolvedExplorePath,
    *,
    glob_patterns: tuple[str, ...],
    exclude_patterns: tuple[str, ...],
) -> list[dict[str, object]]:
    api_ignore_patterns, api_ignore_base = _listing_ignore_patterns(
        resolved,
        is_file=False,
    )
    local_ignore_patterns = ignore_patterns_for_root(
        resolved.abs_path,
        rel_base_abs=None,
        is_file=False,
    )
    entries: list[dict[str, object]] = []
    try:
        with os.scandir(resolved.abs_path) as directory_entries:
            for entry in directory_entries:
                try:
                    is_dir = entry.is_dir(follow_symlinks=False)
                    is_file = entry.is_file(follow_symlinks=False)
                except OSError:
                    continue
                if not is_dir and not is_file:
                    continue
                rel_path = _display_path(entry.path, resolved.display_base)
                if should_ignore_path(
                    rel_path,
                    is_dir=is_dir,
                    exclude_patterns=exclude_patterns,
                    ignore_patterns=api_ignore_patterns.common,
                    root_ignore_patterns=api_ignore_patterns.root,
                    common_rel_path=relative_path(entry.path, api_ignore_base),
                ) or _is_ignored_by_local_listing_patterns(
                    entry.path,
                    rel_path=rel_path,
                    is_dir=is_dir,
                    local_base=resolved.abs_path,
                    root_ignore_patterns=local_ignore_patterns.root,
                ):
                    continue
                if not matches_glob(rel_path, glob_patterns):
                    continue
                entries.append(
                    {
                        "path": f"{rel_path}/" if is_dir else rel_path,
                        "kind": "dir" if is_dir else "file",
                    }
                )
    except OSError as exc:
        message = getattr(exc, "strerror", None) or str(exc)
        raise ExploreRootError(
            f"cannot list directory {resolved.display_path!r}: {message}"
        ) from exc
    entries.sort(key=_entry_sort_key)
    return entries


def _listing_ignore_patterns(
    resolved: ResolvedExplorePath,
    *,
    is_file: bool,
) -> tuple[IgnorePatterns, str]:
    root_filter_base = (
        os.path.dirname(resolved.search_root_abs) or os.curdir
        if resolved.root_is_file
        else resolved.search_root_abs
    )
    if _is_under(resolved.abs_path, root_filter_base):
        return (
            ignore_patterns_for_root(
                resolved.search_root_abs,
                rel_base_abs=resolved.rel_base_abs,
                is_file=resolved.root_is_file,
            ),
            root_filter_base,
        )

    api_ignore_base = _listing_api_ignore_base(resolved, is_file=is_file)
    return (
        ignore_patterns_for_root(
            api_ignore_base,
            rel_base_abs=None,
            is_file=False,
        ),
        api_ignore_base,
    )


def _listing_api_ignore_base(resolved: ResolvedExplorePath, *, is_file: bool) -> str:
    if _is_under(resolved.abs_path, resolved.root_base):
        return resolved.root_base
    if is_file:
        return os.path.dirname(resolved.abs_path) or os.curdir
    return resolved.abs_path


def _is_ignored_by_local_listing_patterns(
    path: str,
    *,
    rel_path: str,
    is_dir: bool,
    local_base: str,
    root_ignore_patterns: tuple[str, ...],
) -> bool:
    if not root_ignore_patterns:
        return False
    return should_ignore_path(
        rel_path,
        is_dir=is_dir,
        root_ignore_patterns=root_ignore_patterns,
        common_rel_path=relative_path(path, local_base),
    )


def _entry_sort_key(entry: dict[str, Any]) -> tuple[str, str]:
    path = str(entry.get("path", ""))
    return (path.rstrip("/").casefold(), path)


def _entry_identity(entry: dict[str, object]) -> tuple[str, str]:
    kind = str(entry.get("kind", ""))
    path = normalize_relpath(str(entry.get("path", ""))).rstrip("/")
    return (os.path.normcase(path), kind)
