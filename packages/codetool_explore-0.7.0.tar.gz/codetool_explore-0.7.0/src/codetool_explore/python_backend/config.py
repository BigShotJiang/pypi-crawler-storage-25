"""Public-option normalization for the Python backend."""

from __future__ import annotations

from ..errors import ExploreArgumentError
from .constants import VALID_MODES, VALID_PATH_SCOPES, VALID_TARGETS


def normalize_mode(mode: str) -> str:
    """Validate and normalise a public output mode."""

    normalised = str(mode or "files").lower()
    if normalised not in VALID_MODES:
        raise ExploreArgumentError("mode must be one of: files, snippets, count")
    return normalised


def normalize_target(target: str) -> str:
    """Validate and normalise the public search target."""

    normalised = str(target or "content").lower()
    if normalised not in VALID_TARGETS:
        raise ExploreArgumentError(
            "target must be one of: content, path, content_or_path"
        )
    return normalised


def normalize_path_scope(path_scope: str) -> str:
    """Validate and normalise the path field matched by path search."""

    normalised = str(path_scope or "path").lower()
    if normalised not in VALID_PATH_SCOPES:
        raise ExploreArgumentError("path_scope must be one of: path, basename")
    return normalised