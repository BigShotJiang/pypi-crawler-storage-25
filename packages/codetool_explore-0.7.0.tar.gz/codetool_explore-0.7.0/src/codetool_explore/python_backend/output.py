"""Result-shaping helpers for the Python backend."""

from __future__ import annotations


def path_file_match(
    rel_path: str,
    *,
    mode: str,
    match_kind: str = "path",
) -> dict[str, object]:
    """Build a file-level row for a path-only match."""

    match: dict[str, object] = {
        "path": rel_path,
        "kind": "file",
        "match_kind": match_kind,
    }
    if mode == "count":
        match["count"] = 1
    return match


def record_path_only_match(
    file_matches: list[dict[str, object]],
    snippet_matches: list[dict[str, object]],
    rel_path: str,
    *,
    mode: str,
    collect_snippets: bool,
) -> None:
    """Append a path-only match to file/snippet collections."""

    match = path_file_match(rel_path, mode=mode)
    file_matches.append(match)
    if collect_snippets:
        snippet_matches.append(dict(match))


def mark_snippets_for_content_or_path_target(
    snippets: list[dict[str, object]],
    *,
    path_matches: bool,
) -> None:
    """Mark content snippets with combined content/path target metadata."""

    match_kind = "content_and_path" if path_matches else "content"
    for snippet in snippets:
        snippet["kind"] = "file"
        snippet["match_kind"] = match_kind


def base_result(
    *,
    pattern: str,
    root: str | list[str],
    regex: bool,
    target: str,
    path_scope: str,
    mode: str,
    requested_case: str,
    effective_case: str,
    limit: int,
    cursor: str | int | None,
) -> dict[str, object]:
    """Return the stable metadata prefix for a backend result."""

    result: dict[str, object] = {
        "pattern": pattern,
        "root": root,
        "regex": bool(regex),
        "target": target,
        "mode": mode,
        "case": requested_case,
        "effective_case": effective_case,
        "limit": limit,
        "cursor": None if cursor is None else str(cursor),
        "backend": "python",
    }
    if target != "content":
        result["path_scope"] = path_scope
    return result