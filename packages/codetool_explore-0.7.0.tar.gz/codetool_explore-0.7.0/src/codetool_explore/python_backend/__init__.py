"""Pure-Python stdlib backend for workspace search.

The package mirrors the Rust helper's ``rust/src`` organization so equivalent
backend responsibilities live in equivalent module names:

* ``constants`` and ``models`` define shared backend data;
* ``case`` and ``config`` validate public search options;
* ``walker`` and ``ignore_rules`` enumerate candidate files;
* ``matcher``, ``literal``, ``regex_search``, ``file_search``, and ``text``
  perform path/content matching; and
* ``search`` coordinates ranking, pagination, and result assembly.
"""

from __future__ import annotations

import re

from .case import resolve_case
from .config import normalize_mode, normalize_path_scope, normalize_target
from .constants import (
    BINARY_CHECK_BYTES,
    MAX_FILE_BYTES,
    MAX_SNIPPETS_PER_FILE,
    MAX_SNIPPET_CHARS,
    VALID_MODES,
    VALID_PATH_SCOPES,
    VALID_TARGETS,
)
from .models import BinaryFileError, CandidateFile, IgnorePatterns
from .file_search import read_text_candidate
from .ignore_rules import ignore_patterns_for_root
from .literal import LiteralMatcher, count_non_overlapping, search_literal_file
from .matcher import PathMatcher, path_match_subject
from .output import (
    base_result,
    mark_snippets_for_content_or_path_target,
    path_file_match,
    record_path_only_match,
)
from .regex_search import RegexLineMatcher, search_regex_file
from .search import search_python
from .text import context_for_lines, crop, decode_line
from .walker import iter_candidate_files

__all__ = [
    "BINARY_CHECK_BYTES",
    "MAX_FILE_BYTES",
    "MAX_SNIPPETS_PER_FILE",
    "MAX_SNIPPET_CHARS",
    "VALID_MODES",
    "VALID_PATH_SCOPES",
    "VALID_TARGETS",
    "BinaryFileError",
    "CandidateFile",
    "IgnorePatterns",
    "iter_candidate_files",
    "normalize_mode",
    "normalize_path_scope",
    "normalize_target",
    "resolve_case",
    "search_python",
]


def _read_text_candidate(path: str, size: int) -> bytes:
    """Compatibility wrapper for the former single-file module helper."""

    return read_text_candidate(CandidateFile(path=path, rel_path=path, size=size))


def _search_literal_file(
    path: str,
    rel_path: str,
    size: int,
    *,
    pattern: str,
    needle: bytes,
    case_sensitive: bool,
    context_lines: int,
    collect_snippets: bool,
) -> tuple[dict[str, object] | None, list[dict[str, object]]]:
    """Compatibility wrapper for the former literal search helper."""

    del pattern
    candidate = CandidateFile(path=path, rel_path=rel_path, size=size)
    return search_literal_file(
        candidate,
        read_text_candidate(candidate),
        LiteralMatcher(needle=needle, case_sensitive=case_sensitive),
        context_lines=context_lines,
        collect_snippets=collect_snippets,
    )


def _search_regex_file(
    path: str,
    rel_path: str,
    size: int,
    *,
    compiled: re.Pattern[str],
    context_lines: int,
    collect_snippets: bool,
) -> tuple[dict[str, object] | None, list[dict[str, object]]]:
    """Compatibility wrapper for the former regex search helper."""

    candidate = CandidateFile(path=path, rel_path=rel_path, size=size)
    return search_regex_file(
        candidate,
        read_text_candidate(candidate),
        RegexLineMatcher(compiled=compiled),
        context_lines=context_lines,
        collect_snippets=collect_snippets,
    )


def _path_matches_literal(
    rel_path: str,
    *,
    pattern: str,
    case_sensitive: bool,
    path_scope: str,
) -> bool:
    """Compatibility wrapper for the former path-literal helper."""

    return PathMatcher.build(
        pattern,
        regex=False,
        case_sensitive=case_sensitive,
    ).is_match(rel_path, path_scope)


def _path_matches_regex(
    rel_path: str,
    *,
    compiled: re.Pattern[str],
    path_scope: str,
) -> bool:
    """Compatibility wrapper for the former path-regex helper."""

    return compiled.search(path_match_subject(rel_path, path_scope)) is not None


_base_result = base_result
_context_for_lines = context_for_lines
_count_non_overlapping = count_non_overlapping
_crop = crop
_decode_line = decode_line
_ignore_patterns_for_root = ignore_patterns_for_root
_mark_snippets_for_content_or_path_target = (
    mark_snippets_for_content_or_path_target
)
_path_file_match = path_file_match
_path_match_subject = path_match_subject
_record_path_only_match = record_path_only_match