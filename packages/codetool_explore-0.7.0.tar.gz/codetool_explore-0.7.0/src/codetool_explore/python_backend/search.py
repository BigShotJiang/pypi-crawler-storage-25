"""Top-level pure-Python backend search orchestration."""

from __future__ import annotations

import os
import re
from collections.abc import Iterable

from ..cursor import normalize_limit, page_items
from ..errors import ExploreArgumentError, ExplorePatternError
from ..ignore import normalize_patterns
from ..ranking import file_sort_key, snippet_sort_key
from ..roots import RootInput, normalize_search_roots
from .case import resolve_case
from .config import normalize_mode, normalize_path_scope, normalize_target
from .constants import max_file_bytes
from .file_search import search_file
from .matcher import PathMatcher, build_content_matcher
from .models import BinaryFileError, CandidateFile, SearchCounters
from .output import (
    base_result,
    mark_snippets_for_content_or_path_target,
    record_path_only_match,
)
from .walker import iter_candidate_files


def search_python(
    pattern: str,
    root: RootInput = ".",
    *,
    regex: bool = False,
    target: str = "content",
    path_scope: str = "path",
    glob: str | Iterable[str] | None = None,
    exclude: str | Iterable[str] | None = None,
    case: str = "smart",
    mode: str = "files",
    context_lines: int = 0,
    limit: int = 50,
    cursor: str | int | None = None,
) -> dict[str, object]:
    """Search file contents, paths, or content/path union using Python."""

    if not isinstance(pattern, str):
        raise ExploreArgumentError("pattern must be a string")
    normalised_target = normalize_target(target)
    if pattern == "" and normalised_target in {"content", "content_or_path"}:
        raise ExplorePatternError("pattern must not be empty")

    root_set = normalize_search_roots(root)

    normalised_mode = normalize_mode(mode)
    if normalised_mode == "snippets" and normalised_target == "path":
        raise ExploreArgumentError(
            "mode='snippets' is not supported for target='path'; "
            "use target='content' or target='content_or_path'"
        )
    safe_limit = normalize_limit(limit)
    safe_context_lines = max(0, int(context_lines or 0))
    requested_case = str(case or "smart").lower()
    effective_case, case_sensitive = resolve_case(requested_case, pattern)
    normalised_path_scope = normalize_path_scope(path_scope)
    glob_patterns = normalize_patterns(glob)
    exclude_patterns = normalize_patterns(exclude)

    base = base_result(
        pattern=pattern,
        root=root_set.display,
        regex=regex,
        target=normalised_target,
        path_scope=normalised_path_scope,
        mode=normalised_mode,
        requested_case=requested_case,
        effective_case=effective_case,
        limit=safe_limit,
        cursor=cursor,
    )

    content_enabled = normalised_target in {"content", "content_or_path"}
    path_enabled = normalised_target in {"path", "content_or_path"}
    try:
        content_matcher = (
            build_content_matcher(
                pattern,
                regex=regex,
                case_sensitive=case_sensitive,
            )
            if content_enabled
            else None
        )
        path_matcher = (
            PathMatcher.build(
                pattern,
                regex=regex,
                case_sensitive=case_sensitive,
            )
            if path_enabled
            else None
        )
    except re.error as exc:
        raise ExplorePatternError(f"invalid regex: {exc}") from exc

    collect_snippets = normalised_mode == "snippets"
    file_matches: list[dict[str, object]] = []
    snippet_matches: list[dict[str, object]] = []
    counters = SearchCounters()
    seen_candidate_paths: set[str] = set()

    for search_root in root_set.roots:
        candidates = iter_candidate_files(
            search_root.abs_path,
            rel_base=root_set.rel_base,
            glob_patterns=glob_patterns,
            exclude_patterns=exclude_patterns,
        )
        for candidate in candidates:
            candidate_key = os.path.normcase(os.path.abspath(candidate.path))
            if candidate_key in seen_candidate_paths:
                continue
            seen_candidate_paths.add(candidate_key)
            _search_candidate(
                candidate,
                content_matcher=content_matcher,
                path_matcher=path_matcher,
                path_scope=normalised_path_scope,
                target=normalised_target,
                mode=normalised_mode,
                context_lines=safe_context_lines,
                collect_snippets=collect_snippets,
                counters=counters,
                file_matches=file_matches,
                snippet_matches=snippet_matches,
            )

    file_matches.sort(key=lambda item: file_sort_key(item, pattern))
    snippet_matches.sort(key=lambda item: snippet_sort_key(item, pattern))

    total_files = len(file_matches)
    content_occurrences = sum(
        int(match["count"])
        for match in file_matches
        if match.get("match_kind") != "path" and "count" in match
    )
    path_only_occurrences = sum(
        int(match.get("count", 1))
        for match in file_matches
        if match.get("match_kind") == "path"
    )
    total_occurrences = (
        content_occurrences
        if normalised_target == "content"
        else content_occurrences + path_only_occurrences
    )

    if normalised_mode == "snippets":
        all_matches = snippet_matches
        total_matches = len(snippet_matches)
    else:
        all_matches = file_matches
        total_matches = total_files

    page, truncated, next_cursor, offset = page_items(
        all_matches, limit=safe_limit, cursor=cursor
    )

    result = {
        **base,
        "matches": page,
        "returned": len(page),
        "total_files": total_files,
        "total_matches": total_matches,
        "count": total_occurrences,
        "content_count": content_occurrences,
        "content_files": counters.content_match_count,
        "path_matches": counters.path_match_count,
        "truncated": truncated,
        "next_cursor": next_cursor,
        "offset": offset,
        "scanned_files": counters.scanned_files,
        "scanned_bytes": counters.scanned_bytes,
        "skipped": counters.skipped,
    }
    if glob_patterns:
        result["glob"] = list(glob_patterns)
    if exclude_patterns:
        result["exclude"] = list(exclude_patterns)
    return result


def _search_candidate(
    candidate: CandidateFile,
    *,
    content_matcher: object | None,
    path_matcher: PathMatcher | None,
    path_scope: str,
    target: str,
    mode: str,
    context_lines: int,
    collect_snippets: bool,
    counters: SearchCounters,
    file_matches: list[dict[str, object]],
    snippet_matches: list[dict[str, object]],
) -> None:
    path_matches = (
        path_matcher.is_match(candidate.rel_path, path_scope)
        if path_matcher is not None
        else False
    )

    if target == "path":
        counters.scanned_files += 1
        if path_matches:
            record_path_only_match(
                file_matches,
                snippet_matches,
                candidate.rel_path,
                mode=mode,
                collect_snippets=False,
            )
            counters.path_match_count += 1
        return

    if candidate.size > max_file_bytes():
        if target == "content_or_path" and path_matches:
            _record_content_or_path_target_path_fallback(
                file_matches,
                snippet_matches,
                candidate.rel_path,
                mode=mode,
                collect_snippets=collect_snippets,
                counters=counters,
            )
        counters.skipped_huge += 1
        return

    counters.scanned_files += 1
    counters.scanned_bytes += candidate.size
    try:
        assert content_matcher is not None
        file_match, snippets = search_file(
            candidate,
            content_matcher,
            context_lines=context_lines,
            collect_snippets=collect_snippets,
        )
    except BinaryFileError:
        if target == "content_or_path" and path_matches:
            _record_content_or_path_target_path_fallback(
                file_matches,
                snippet_matches,
                candidate.rel_path,
                mode=mode,
                collect_snippets=collect_snippets,
                counters=counters,
            )
        counters.skipped_binary += 1
        return
    except OverflowError:
        if target == "content_or_path" and path_matches:
            _record_content_or_path_target_path_fallback(
                file_matches,
                snippet_matches,
                candidate.rel_path,
                mode=mode,
                collect_snippets=collect_snippets,
                counters=counters,
            )
        counters.skipped_huge += 1
        return
    except (OSError, UnicodeError, re.error):
        if target == "content_or_path" and path_matches:
            _record_content_or_path_target_path_fallback(
                file_matches,
                snippet_matches,
                candidate.rel_path,
                mode=mode,
                collect_snippets=collect_snippets,
                counters=counters,
            )
        counters.skipped_errors += 1
        return

    if file_match is None:
        if target == "content_or_path" and path_matches:
            _record_content_or_path_target_path_fallback(
                file_matches,
                snippet_matches,
                candidate.rel_path,
                mode=mode,
                collect_snippets=collect_snippets,
                counters=counters,
            )
        return

    if target == "content_or_path":
        file_match["kind"] = "file"
        file_match["match_kind"] = "content_and_path" if path_matches else "content"
        if collect_snippets:
            mark_snippets_for_content_or_path_target(
                snippets,
                path_matches=path_matches,
            )
        if path_matches:
            counters.path_match_count += 1
    counters.content_match_count += 1
    file_matches.append(file_match)
    snippet_matches.extend(snippets)


def _record_content_or_path_target_path_fallback(
    file_matches: list[dict[str, object]],
    snippet_matches: list[dict[str, object]],
    rel_path: str,
    *,
    mode: str,
    collect_snippets: bool,
    counters: SearchCounters,
) -> None:
    record_path_only_match(
        file_matches,
        snippet_matches,
        rel_path,
        mode=mode,
        collect_snippets=collect_snippets,
    )
    counters.path_match_count += 1