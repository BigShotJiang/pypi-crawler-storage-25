"""Command-line interface for codetool-explore."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence

from .api import explore
from .errors import ExploreError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="codetool-explore",
        description=(
            "Search file contents, file paths, read files, or list directories "
            "with compact JSON or raw text output."
        ),
    )
    parser.add_argument("pattern", nargs="?", help="text or regex pattern to search")
    parser.add_argument("path", nargs="?", help="root directory/file (default: .)")
    parser.add_argument("--pattern", dest="pattern_flag", help="text or regex pattern")
    action_group = parser.add_mutually_exclusive_group()
    action_group.add_argument(
        "--read",
        dest="read_path",
        help="read one known file path under each root with controlled line output",
    )
    action_group.add_argument(
        "--list",
        dest="list_path",
        help="list one directory level or one file path under each root",
    )
    parser.add_argument(
        "--root",
        dest="roots",
        action="append",
        default=None,
        help="root directory/file (repeat for multiple roots; default: .)",
    )
    parser.add_argument(
        "--target",
        choices=("content", "path", "content_or_path", "read", "list"),
        default="content",
        help="search target (default: content)",
    )
    parser.add_argument(
        "--path-scope",
        choices=("path", "basename"),
        default="path",
        help=(
            "path field matched when --target path/content_or_path "
            "(default: path)"
        ),
    )
    parser.add_argument(
        "--format",
        choices=("compressed", "full", "text", "raw", "plain"),
        default=None,
        help=(
            "output format (default: compressed JSON for search, plain text "
            "for read, tree text for list)"
        ),
    )
    parser.add_argument(
        "--raw",
        action="store_true",
        help='shortcut for --format text; prints "No Match" when empty',
    )
    parser.add_argument(
        "--mode",
        choices=("files", "snippets", "count"),
        default="files",
        help="result mode (default: files)",
    )
    parser.add_argument("--context-lines", type=int, default=0)
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--cursor")
    parser.add_argument("--start-line", type=int, default=1)
    parser.add_argument("--glob", action="append")
    parser.add_argument("--exclude", action="append")
    parser.add_argument(
        "--case",
        default="smart",
        choices=(
            "smart",
            "sensitive",
            "case-sensitive",
            "exact",
            "insensitive",
            "ignore",
            "ignorecase",
            "case-insensitive",
            "i",
        ),
    )
    parser.add_argument(
        "--backend",
        default="auto",
        choices=("auto", "python", "rust", "native"),
    )
    regex_group = parser.add_mutually_exclusive_group()
    regex_group.add_argument(
        "--regex",
        dest="regex",
        action="store_true",
        default=True,
        help="interpret pattern as regex (default)",
    )
    regex_group.add_argument(
        "-F",
        "--literal",
        dest="regex",
        action="store_false",
        help="interpret pattern literally",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    cli_root = None
    if args.roots is not None:
        cli_root = args.roots[0] if len(args.roots) == 1 else args.roots

    action_target = None
    if args.read_path is not None:
        action_target = "read"
        if args.pattern_flag is not None or args.pattern is not None or args.path is not None:
            parser.error("--read cannot be combined with positional pattern/path or --pattern")
        pattern = args.read_path
        root = cli_root or "."
    elif args.list_path is not None:
        action_target = "list"
        if args.pattern_flag is not None or args.pattern is not None or args.path is not None:
            parser.error("--list cannot be combined with positional pattern/path or --pattern")
        pattern = args.list_path
        root = cli_root or "."
    elif args.pattern_flag is not None:
        pattern = args.pattern_flag
        root = cli_root or args.path or args.pattern or "."
    else:
        pattern = args.pattern
        root = cli_root or args.path or "."
    if pattern is None:
        parser.error("missing path" if args.target in {"read", "list"} else "missing pattern")
    result_format = "text" if args.raw else args.format
    target = action_target or args.target

    try:
        result = explore(
            pattern,
            root=root,
            target=target,
            regex=args.regex,
            path_scope=args.path_scope,
            glob=args.glob,
            exclude=args.exclude,
            case=args.case,
            mode=args.mode,
            context_lines=args.context_lines,
            limit=args.limit,
            cursor=args.cursor,
            start_line=args.start_line,
            backend=args.backend,
            result_format=result_format,
        )
    except ExploreError as exc:
        print(f"codetool-explore: {exc}", file=sys.stderr)
        return 2
    if isinstance(result, str):
        sys.stdout.write(result)
        if not result.endswith("\n"):
            sys.stdout.write("\n")
    else:
        print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


def run() -> None:
    raise SystemExit(main(sys.argv[1:]))


if __name__ == "__main__":
    run()