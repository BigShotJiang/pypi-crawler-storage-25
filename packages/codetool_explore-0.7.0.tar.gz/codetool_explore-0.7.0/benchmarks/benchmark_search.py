"""Benchmark repository-scale text search tools against real corpus checkouts.

Run from the repository root:

    cargo build --release --manifest-path rust/Cargo.toml
    uv run python benchmarks/benchmark_search.py --output reports/search_benchmark.json

The benchmark walks every first-level repository in ``benchmarks/corpus`` and
times the same representative literal-search scenarios with:

* ``rg`` (ripgrep);
* GNU ``grep``;
* ``rtk grep``; and
* ``codetool-explore`` (the Rust helper used by this package).

Results are written as JSON so they can be archived across implementation
changes and compared between machines. The report also records output token
counts for raw text, compressed JSON, full JSON, ``rg``, GNU ``grep``, and
``rtk grep`` using tiktoken when available.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import signal
import statistics
import subprocess
import sys
import tempfile
import threading
import time
from collections.abc import Iterable
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = REPO_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from codetool_explore import explore  # noqa: E402
from codetool_explore.rust_backend import find_rust_binary  # noqa: E402

try:  # benchmark/reporting only; not a package runtime dependency
    import tiktoken  # type: ignore[import-not-found]  # noqa: E402
except Exception:  # pragma: no cover - depends on local benchmark env
    tiktoken = None  # type: ignore[assignment]


CORPUS_DIR = REPO_ROOT / "benchmarks" / "corpus"

# Keep the competing tools close to codetool-explore's default coding-agent
# traversal: include dot-directories that matter to developers, but avoid VCS,
# dependency, cache, and build trees.
DEFAULT_EXCLUDES = (
    ".git/**",
    ".hg/**",
    ".svn/**",
    "node_modules/**",
    "target/**",
    "dist/**",
    "build/**",
    ".venv/**",
    "venv/**",
    "__pycache__/**",
    ".pytest_cache/**",
    ".mypy_cache/**",
    ".ruff_cache/**",
    ".cache/**",
    ".next/**",
    ".nuxt/**",
    ".vscode/**",
)

SCENARIOS: tuple[dict[str, object], ...] = (
    {
        "name": "literal_files_error",
        "description": "common diagnostic term in files mode",
        "pattern": "error",
        "case": "smart",
        "mode": "files",
        "limit": 200,
    },
    {
        "name": "insensitive_config_snippets",
        "description": "configuration term, explicit case-insensitive snippets",
        "pattern": "CONFIG",
        "case": "insensitive",
        "mode": "snippets",
        "context_lines": 1,
        "limit": 200,
    },
    {
        "name": "rust_impl_files",
        "description": "Rust implementation search constrained to Rust files",
        "pattern": "impl",
        "case": "smart",
        "mode": "files",
        "glob": "*.rs",
        "limit": 200,
    },
    {
        "name": "python_def_files",
        "description": "Python function search constrained to Python files",
        "pattern": "def ",
        "case": "smart",
        "mode": "files",
        "glob": "*.py",
        "limit": 200,
    },
    {
        "name": "agent_docs_snippets",
        "description": "agent/documentation search with context",
        "pattern": "agent",
        "case": "insensitive",
        "mode": "snippets",
        "context_lines": 2,
        "limit": 200,
    },
    {
        "name": "count_todo",
        "description": "count occurrences of a common maintenance marker",
        "pattern": "TODO",
        "case": "insensitive",
        "mode": "count",
        "limit": 200,
    },
    {
        "name": "no_match_probe",
        "description": "no-match token cost for the raw text warning",
        "pattern": "__codetool_explore_no_match_probe__",
        "case": "sensitive",
        "mode": "snippets",
        "limit": 200,
    },
)

_TOKENIZER = None


def tokenizer():
    global _TOKENIZER
    if tiktoken is None:
        return None
    if _TOKENIZER is None:
        _TOKENIZER = tiktoken.get_encoding("o200k_base")
    return _TOKENIZER


def byte_len(text: str) -> int:
    return len(text.encode("utf-8"))


def line_count(text: str) -> int:
    return 0 if text == "" else text.count("\n") + (0 if text.endswith("\n") else 1)


def token_len(text: str) -> int:
    enc = tokenizer()
    if enc is None:
        return max(1, round(len(text) / 4)) if text else 0
    return len(enc.encode(text))


def output_stats(text: str) -> dict[str, object]:
    return {
        "bytes": byte_len(text),
        "chars": len(text),
        "lines": line_count(text),
        "tokens": token_len(text),
        "tokenizer": "tiktoken:o200k_base" if tokenizer() is not None else "approx_4chars",
    }


def output_stats_stream(handle) -> tuple[dict[str, object], str]:
    enc = tokenizer()
    handle.seek(0)
    bytes_total = 0
    chars_total = 0
    lines = 0
    tokens = 0
    preview_parts: list[str] = []
    saw_text = False
    ended_with_newline = False
    for chunk in handle:
        saw_text = True
        ended_with_newline = chunk.endswith("\n")
        bytes_total += byte_len(chunk)
        chars_total += len(chunk)
        lines += chunk.count("\n")
        if enc is None:
            tokens += max(1, round(len(chunk) / 4)) if chunk else 0
        else:
            tokens += len(enc.encode(chunk))
        if sum(len(part) for part in preview_parts) < 500:
            preview_parts.append(chunk)
    if saw_text and not ended_with_newline:
        lines += 1
    return (
        {
            "bytes": bytes_total,
            "chars": chars_total,
            "lines": lines,
            "tokens": tokens,
            "tokenizer": "tiktoken:o200k_base"
            if enc is not None
            else "approx_4chars",
        },
        "".join(preview_parts)[:500],
    )


def sha256_file(path: str | None) -> str | None:
    if not path:
        return None
    try:
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except OSError:
        return None


def command_output(command: Iterable[str], timeout: float = 5) -> str | None:
    try:
        completed = subprocess.run(
            list(command),
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    output = (completed.stdout or completed.stderr).strip()
    return output or None


def can_run(command: list[str], timeout: float = 5) -> bool:
    try:
        completed = subprocess.run(
            command,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    # The Rust helper exits 2 for --help because it returns the usage text via
    # its error path. Reaching process exit at all is the important part here.
    return completed.returncode in {0, 2}


def discover_codetool_binary(explicit: str | None) -> str | None:
    """Find a runnable codetool-explore helper for benchmarking.

    The package discovery order prefers staged wheel helpers. In this checkout a
    staged musl helper may be present on a glibc-only machine, so the benchmark
    validates candidates and prefers freshly built development binaries.
    """

    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    env_value = os.environ.get("CODETOOL_EXPLORE_RUST_BINARY")
    if env_value:
        candidates.append(Path(env_value).expanduser())
    for profile in ("release", "debug"):
        candidates.append(
            REPO_ROOT / "rust" / "target" / profile / "codetool-explore-rust"
        )
    discovered = find_rust_binary()
    if discovered:
        candidates.append(Path(discovered))
    path_binary = shutil.which("codetool-explore-rust")
    if path_binary:
        candidates.append(Path(path_binary))

    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if (
            candidate.is_file()
            and os.access(candidate, os.X_OK)
            and can_run([str(candidate), "--help"])
        ):
            return str(candidate)
    return None


def discover_corpora(corpus_dir: Path) -> list[Path]:
    if not corpus_dir.is_dir():
        raise SystemExit(f"corpus directory not found: {corpus_dir}")
    corpora = sorted(path for path in corpus_dir.iterdir() if path.is_dir())
    if not corpora:
        raise SystemExit(f"no corpus repositories found in {corpus_dir}")
    return corpora


def count_corpus_files(root: Path) -> dict[str, int]:
    files = 0
    bytes_total = 0
    for directory, dirnames, filenames in os.walk(root):
        rel_dir = Path(directory).relative_to(root).as_posix()
        dirnames[:] = [
            name
            for name in dirnames
            if f"{name}/**" not in DEFAULT_EXCLUDES
            and (rel_dir == "." or f"{rel_dir}/{name}/**" not in DEFAULT_EXCLUDES)
        ]
        for filename in filenames:
            path = Path(directory) / filename
            try:
                stat = path.stat()
            except OSError:
                continue
            files += 1
            bytes_total += stat.st_size
    return {"files": files, "bytes": bytes_total}


def apply_case(args: list[str], case: str) -> None:
    if case == "smart":
        args.append("--smart-case")
    elif case == "insensitive":
        args.append("--ignore-case")
    elif case == "sensitive":
        args.append("--case-sensitive")


def apply_grep_case(args: list[str], case: str, pattern: str) -> None:
    if case == "insensitive" or (
        case == "smart" and not any(ch.isupper() for ch in pattern)
    ):
        args.append("--ignore-case")


def append_rg_globs(args: list[str], scenario: dict[str, object]) -> None:
    for pattern in DEFAULT_EXCLUDES:
        args.extend(("--glob", f"!{pattern}"))
    glob = scenario.get("glob")
    if glob:
        args.extend(("--glob", str(glob)))
    exclude = scenario.get("exclude")
    if exclude:
        excludes = (exclude,) if isinstance(exclude, str) else tuple(exclude)  # type: ignore[arg-type]
        for pattern in excludes:
            args.extend(("--glob", f"!{pattern}"))


def append_grep_exclude(args: list[str], pattern: str) -> None:
    if pattern.endswith("/**"):
        directory = pattern[:-3].rstrip("/")
        # GNU grep applies --exclude-dir to directory basenames. This mirrors
        # the common benchmark excludes closely enough for timing comparison.
        name = directory.rsplit("/", 1)[-1]
        if name:
            args.append(f"--exclude-dir={name}")
            return
    args.append(f"--exclude={pattern.rsplit('/', 1)[-1]}")


def append_grep_globs(args: list[str], scenario: dict[str, object]) -> None:
    for pattern in DEFAULT_EXCLUDES:
        append_grep_exclude(args, pattern)
    glob = scenario.get("glob")
    if glob:
        args.append(f"--include={glob}")
    exclude = scenario.get("exclude")
    if exclude:
        excludes = (exclude,) if isinstance(exclude, str) else tuple(exclude)  # type: ignore[arg-type]
        for pattern in excludes:
            append_grep_exclude(args, str(pattern))


def build_rg_command(root: Path, scenario: dict[str, object]) -> list[str]:
    mode = str(scenario.get("mode", "files"))
    args = [
        "rg",
        "--fixed-strings",
        "--hidden",
        "--no-messages",
        "--color",
        "never",
    ]
    apply_case(args, str(scenario.get("case", "smart")))
    append_rg_globs(args, scenario)
    if mode == "files":
        args.append("--files-with-matches")
    elif mode == "count":
        args.append("--count-matches")
    else:
        args.append("--line-number")
        context = int(scenario.get("context_lines") or 0)
        if context:
            args.extend(("--context", str(context)))
    args.extend((str(scenario["pattern"]), str(root)))
    return args


def build_grep_command(root: Path, scenario: dict[str, object]) -> list[str]:
    mode = str(scenario.get("mode", "files"))
    pattern = str(scenario["pattern"])
    args = [
        "grep",
        "--recursive",
        "--fixed-strings",
        "--binary-files=without-match",
        "--with-filename",
    ]
    apply_grep_case(args, str(scenario.get("case", "smart")), pattern)
    append_grep_globs(args, scenario)
    if mode == "files":
        args.append("--files-with-matches")
    elif mode == "count":
        # GNU grep --count is line-count based. --only-matching gives an
        # occurrence-oriented workload, closer to codetool/rg count scans.
        args.append("--only-matching")
    else:
        args.append("--line-number")
        context = int(scenario.get("context_lines") or 0)
        if context:
            args.extend(("--context", str(context)))
    args.extend((pattern, str(root)))
    return args


def build_rtk_command(root: Path, scenario: dict[str, object]) -> list[str]:
    # rtk grep proxies to ripgrep and then compacts output. Extra ripgrep
    # arguments are intentionally passed after PATH as documented by rtk grep.
    args = [
        "rtk",
        "grep",
        str(scenario["pattern"]),
        str(root),
        "--fixed-strings",
        "--hidden",
        "--no-messages",
        "--color",
        "never",
    ]
    apply_case(args, str(scenario.get("case", "smart")))
    append_rg_globs(args, scenario)
    mode = str(scenario.get("mode", "files"))
    if mode == "files":
        args.append("--files-with-matches")
    elif mode == "count":
        args.append("--count-matches")
    else:
        args.append("--line-number")
        context = int(scenario.get("context_lines") or 0)
        if context:
            args.extend(("--context", str(context)))
    return args


def build_codetool_command(
    root: Path,
    scenario: dict[str, object],
    codetool_binary: str,
) -> list[str]:
    args = [
        codetool_binary,
        "--pattern",
        str(scenario["pattern"]),
        "--root",
        str(root),
        "--mode",
        str(scenario.get("mode", "files")),
        "--case",
        str(scenario.get("case", "smart")),
        "--limit",
        str(int(scenario.get("limit") or 200)),
        "--context-lines",
        str(int(scenario.get("context_lines") or 0)),
    ]
    glob = scenario.get("glob")
    if glob:
        args.extend(("--glob", str(glob)))
    exclude = scenario.get("exclude")
    if exclude:
        excludes = (exclude,) if isinstance(exclude, str) else tuple(exclude)  # type: ignore[arg-type]
        for pattern in excludes:
            args.extend(("--exclude", str(pattern)))
    return args


def available_tools(
    codetool_binary: str | None, requested: list[str] | None
) -> dict[str, str]:
    tools = {
        "rg": shutil.which("rg") or "",
        "grep": shutil.which("grep") or "",
        "rtk": shutil.which("rtk") or "",
        "codetool-explore": codetool_binary or "",
    }
    if requested:
        requested_set = set(requested)
        tools = {name: path for name, path in tools.items() if name in requested_set}
    missing = [name for name, path in tools.items() if not path]
    if missing:
        raise SystemExit(
            "missing required benchmark tool(s): "
            + ", ".join(missing)
            + ". Build Rust with `cargo build --release --manifest-path rust/Cargo.toml` "
            "or adjust --tool."
        )
    return tools


def build_command(
    tool: str, root: Path, scenario: dict[str, object], codetool_binary: str
) -> list[str]:
    if tool == "rg":
        return build_rg_command(root, scenario)
    if tool == "grep":
        return build_grep_command(root, scenario)
    if tool == "rtk":
        return build_rtk_command(root, scenario)
    if tool == "codetool-explore":
        return build_codetool_command(root, scenario, codetool_binary)
    raise ValueError(f"unknown tool: {tool}")


def run_once(command: list[str], timeout: float) -> tuple[float, int]:
    start = time.perf_counter()
    process = subprocess.Popen(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if (
        hasattr(signal, "SIGALRM")
        and hasattr(signal, "setitimer")
        and threading.current_thread() is threading.main_thread()
    ):
        previous_handler = signal.getsignal(signal.SIGALRM)

        def handle_timeout(signum: int, frame: object) -> None:
            process.kill()
            raise subprocess.TimeoutExpired(command, timeout)

        signal.signal(signal.SIGALRM, handle_timeout)
        signal.setitimer(signal.ITIMER_REAL, timeout)
        try:
            returncode = process.wait()
        except subprocess.TimeoutExpired:
            process.wait()
            raise
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous_handler)
        return time.perf_counter() - start, returncode

    timed_out = False

    def kill_process() -> None:
        nonlocal timed_out
        timed_out = True
        process.kill()

    timer = threading.Timer(timeout, kill_process)
    timer.daemon = True
    timer.start()
    returncode = process.wait()
    timer.cancel()
    if timed_out:
        raise subprocess.TimeoutExpired(command, timeout)
    return time.perf_counter() - start, returncode


def summarise(durations: list[float], returncodes: list[int]) -> dict[str, object]:
    if not durations:
        return {"runs": 0}
    median_seconds = statistics.median(durations)
    return {
        "runs": len(durations),
        "min_ms": round(min(durations) * 1000, 3),
        "median_ms": round(median_seconds * 1000, 3),
        "max_ms": round(max(durations) * 1000, 3),
        "returncodes": sorted(set(returncodes)),
    }


def capture_output_stats(command: list[str], timeout: float) -> dict[str, object]:
    try:
        with tempfile.TemporaryFile(mode="w+t", encoding="utf-8") as stdout_file:
            with tempfile.TemporaryFile(mode="w+t", encoding="utf-8") as stderr_file:
                completed = subprocess.run(
                    command,
                    check=False,
                    stdout=stdout_file,
                    stderr=stderr_file,
                    text=True,
                    errors="replace",
                    timeout=timeout,
                )
                stdout_stats, preview = output_stats_stream(stdout_file)
                stderr_stats, _ = output_stats_stream(stderr_file)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {
            "available": False,
            "error": str(exc),
            "command": command,
            "stdout": output_stats(""),
        }
    return {
        "available": True,
        "command": command,
        "returncode": completed.returncode,
        "stdout": stdout_stats,
        "stderr": stderr_stats,
        "preview": preview,
    }


def benchmark_tool(
    tool: str,
    root: Path,
    scenario: dict[str, object],
    codetool_binary: str,
    rounds: int,
    warmup: int,
    timeout: float,
) -> dict[str, object]:
    command = build_command(tool, root, scenario, codetool_binary)
    durations: list[float] = []
    returncodes: list[int] = []
    for _ in range(warmup):
        _, code = run_once(command, timeout)
        if code not in {0, 1}:
            raise RuntimeError(
                f"{tool} warmup failed with exit code {code}: {' '.join(command)}"
            )
    for _ in range(rounds):
        duration, code = run_once(command, timeout)
        if code not in {0, 1}:
            raise RuntimeError(
                f"{tool} failed with exit code {code}: {' '.join(command)}"
            )
        durations.append(duration)
        returncodes.append(code)
    summary = summarise(durations, returncodes)
    summary["command"] = command
    return summary


def pct_smaller(smaller: int, larger: int) -> float | None:
    if larger <= 0:
        return None
    return round(((larger - smaller) / larger) * 100, 2)


def ratio(numerator: int, denominator: int) -> float | None:
    if denominator <= 0:
        return None
    return round(numerator / denominator, 3)


def output_compression_summary(
    root: Path, scenario: dict[str, object], timeout: float
) -> dict[str, object]:
    """Compare token/byte size for raw text, JSON, rg, and rtk output."""

    common = {
        "root": str(root),
        "backend": "auto",
        "regex": bool(scenario.get("regex", False)),
        "case": str(scenario.get("case", "smart")),
        "mode": str(scenario.get("mode", "files")),
        "context_lines": int(scenario.get("context_lines") or 0),
        "limit": int(scenario.get("limit") or 200),
    }
    if glob := scenario.get("glob"):
        common["glob"] = glob
    if exclude := scenario.get("exclude"):
        common["exclude"] = exclude

    pattern = str(scenario["pattern"])
    compressed = explore(pattern, **common)
    full = explore(pattern, **common, result_format="full")
    raw_text = explore(pattern, **common, result_format="text")
    compressed_json = json.dumps(compressed, sort_keys=True, separators=(",", ":"))
    full_json = json.dumps(full, sort_keys=True, separators=(",", ":"))
    assert isinstance(raw_text, str)

    full_stats = output_stats(full_json)
    compressed_stats = output_stats(compressed_json)
    raw_stats = output_stats(raw_text)
    rg = (
        capture_output_stats(build_rg_command(root, scenario), timeout)
        if shutil.which("rg")
        else {"available": False, "stdout": output_stats("")}
    )
    grep = (
        capture_output_stats(build_grep_command(root, scenario), timeout)
        if shutil.which("grep")
        else {"available": False, "stdout": output_stats("")}
    )
    rtk = (
        capture_output_stats(build_rtk_command(root, scenario), timeout)
        if shutil.which("rtk")
        else {"available": False, "stdout": output_stats("")}
    )

    compressed_bytes = int(compressed_stats["bytes"])
    full_bytes = int(full_stats["bytes"])
    saved = full_bytes - compressed_bytes
    full_tokens = int(full_stats["tokens"])
    compressed_tokens = int(compressed_stats["tokens"])
    raw_tokens = int(raw_stats["tokens"])
    rg_stdout = rg.get("stdout")
    grep_stdout = grep.get("stdout")
    rtk_stdout = rtk.get("stdout")
    rg_tokens = int(rg_stdout["tokens"]) if isinstance(rg_stdout, dict) else 0
    grep_tokens = (
        int(grep_stdout["tokens"]) if isinstance(grep_stdout, dict) else 0
    )
    rtk_tokens = int(rtk_stdout["tokens"]) if isinstance(rtk_stdout, dict) else 0
    return {
        "reference": "raw_text_token_compression",
        "backend": "auto",
        "tokenizer": raw_stats["tokenizer"],
        "full_json": full_stats,
        "compressed_json": compressed_stats,
        "raw_text": raw_stats,
        "rg_stdout": rg,
        "grep_stdout": grep,
        "rtk_grep_stdout": rtk,
        "no_match_output": raw_text if raw_text == "No Match" else None,
        "comparison": {
            "raw_vs_full_tokens_percent_smaller": pct_smaller(raw_tokens, full_tokens),
            "raw_vs_compressed_tokens_percent_smaller": pct_smaller(
                raw_tokens, compressed_tokens
            ),
            "raw_over_rtk_tokens_ratio": ratio(raw_tokens, rtk_tokens),
            "raw_over_rg_tokens_ratio": ratio(raw_tokens, rg_tokens),
            "raw_over_grep_tokens_ratio": ratio(raw_tokens, grep_tokens),
            "raw_extra_tokens_over_rtk": (
                raw_tokens - rtk_tokens if rtk_tokens else None
            ),
            "raw_extra_tokens_over_rg": raw_tokens - rg_tokens if rg_tokens else None,
            "raw_extra_tokens_over_grep": (
                raw_tokens - grep_tokens if grep_tokens else None
            ),
        },
        # Backward-compatible summary fields consumed by older report tooling.
        "full_json_bytes": full_bytes,
        "compressed_json_bytes": compressed_bytes,
        "bytes_saved": saved,
        "compression_ratio": (
            round(compressed_bytes / full_bytes, 4) if full_bytes else None
        ),
        "percent_smaller": round((saved / full_bytes) * 100, 2) if full_bytes else None,
    }


def benchmark_metadata(
    codetool_binary: str | None, tools: dict[str, str]
) -> dict[str, object]:
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "tools": {
            "rg": command_output(["rg", "--version"]),
            "grep": command_output(["grep", "--version"]),
            "rtk": command_output(["rtk", "--version"]),
            "codetool_explore_binary": codetool_binary,
            "codetool_explore_sha256": sha256_file(codetool_binary),
            "rustc": command_output(["rustc", "--version"]),
            "cargo": command_output(["cargo", "--version"]),
        },
        "tool_paths": tools,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus-dir", type=Path, default=CORPUS_DIR)
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--timeout", type=float, default=120)
    parser.add_argument(
        "--scenario",
        action="append",
        choices=[str(item["name"]) for item in SCENARIOS],
        help="scenario to run; may be passed more than once (default: all)",
    )
    parser.add_argument(
        "--tool",
        action="append",
        choices=["rg", "grep", "rtk", "codetool-explore"],
        help="tool to run; may be passed more than once (default: all)",
    )
    parser.add_argument(
        "--codetool-binary",
        help="codetool-explore Rust helper to benchmark; defaults to package discovery",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="write JSON results to this path in addition to stdout",
    )
    parser.add_argument(
        "--update-readme",
        action="store_true",
        help="refresh README benchmark tables after writing --output",
    )
    args = parser.parse_args()

    if args.codetool_binary:
        os.environ["CODETOOL_EXPLORE_RUST_BINARY"] = args.codetool_binary
    codetool_binary = discover_codetool_binary(args.codetool_binary)
    tools = available_tools(codetool_binary, args.tool)
    codetool_binary = tools.get("codetool-explore", codetool_binary)
    assert codetool_binary is not None

    selected_scenarios = [
        scenario
        for scenario in SCENARIOS
        if args.scenario is None or scenario["name"] in set(args.scenario)
    ]
    corpora = discover_corpora(args.corpus_dir)

    results: dict[str, object] = {
        "metadata": benchmark_metadata(codetool_binary, tools),
        "corpus_dir": str(args.corpus_dir),
        "rounds": args.rounds,
        "warmup": args.warmup,
        "default_excludes": DEFAULT_EXCLUDES,
        "scenarios": {
            str(item["name"]): {
                key: value for key, value in item.items() if key not in {"name"}
            }
            for item in selected_scenarios
        },
        "corpora": {},
    }

    corpus_results = results["corpora"]
    assert isinstance(corpus_results, dict)
    for corpus in corpora:
        scenario_results: dict[str, object] = {}
        corpus_results[corpus.name] = {
            "path": str(corpus),
            "size": count_corpus_files(corpus),
            "scenarios": scenario_results,
        }
        for scenario in selected_scenarios:
            tool_results: dict[str, object] = {}
            scenario_results[str(scenario["name"])] = tool_results
            for tool in tools:
                tool_results[tool] = benchmark_tool(
                    tool,
                    corpus,
                    scenario,
                    codetool_binary,
                    args.rounds,
                    args.warmup,
                    args.timeout,
                )
            tool_results["output_compression"] = output_compression_summary(
                corpus, scenario, args.timeout
            )

            codetool_median = (
                tool_results.get("codetool-explore", {}).get("median_ms")
                if isinstance(tool_results.get("codetool-explore"), dict)
                else None
            )
            if isinstance(codetool_median, int | float) and codetool_median > 0:
                speedups: dict[str, float] = {}
                for tool, summary in tool_results.items():
                    if tool == "codetool-explore" or not isinstance(summary, dict):
                        continue
                    median = summary.get("median_ms")
                    if isinstance(median, int | float) and median > 0:
                        speedups[f"codetool_vs_{tool}_median"] = round(
                            median / codetool_median, 2
                        )
                tool_results["speedups"] = speedups

    output = json.dumps(results, indent=2, sort_keys=True)
    print(output)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output + "\n", encoding="utf-8")
        if args.update_readme:
            updater = REPO_ROOT / "scripts" / "update_readme_benchmarks.py"
            subprocess.run(
                [
                    sys.executable,
                    str(updater),
                    "--performance",
                    str(args.output),
                    "--tokens",
                    str(args.output),
                ],
                check=True,
            )
    elif args.update_readme:
        raise SystemExit("--update-readme requires --output")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
