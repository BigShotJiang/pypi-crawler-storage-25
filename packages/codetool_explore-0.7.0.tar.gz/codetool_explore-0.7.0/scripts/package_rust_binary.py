#!/usr/bin/env python3
"""Build and stage the Rust CLI backend inside the Python package.

The script stages one Rust executable in ``src/codetool_explore/_bin`` using
stable runtime keys:

* linux-x86_64, linux-aarch64
* macos-x86_64, macos-arm64
* windows-x86_64, windows-arm64

Use ``--target-runtime`` or ``CODETOOL_EXPLORE_TARGET_RUNTIME`` / generic
``CODETOOL_TARGET_RUNTIME`` when staging cross-compiled binaries. The wheel hook
then includes only the binary matching that target runtime.
"""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import stat
import subprocess
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
RUST_MANIFEST = REPO_ROOT / "rust" / "Cargo.toml"
PACKAGE_BIN = REPO_ROOT / "src" / "codetool_explore" / "_bin"
BASE_BINARY = "codetool-explore-rust"
TARGET_RUNTIME_ENVS = (
    "CODETOOL_EXPLORE_TARGET_RUNTIME",
    "CODETOOL_TARGET_RUNTIME",
)
SUPPORTED_RUNTIME_KEYS = (
    "linux-x86_64",
    "linux-aarch64",
    "macos-x86_64",
    "macos-arm64",
    "windows-x86_64",
    "windows-arm64",
)
RUNTIME_ALIASES = {
    "linux-amd64": "linux-x86_64",
    "linux-x64": "linux-x86_64",
    "linux-arm64": "linux-aarch64",
    "darwin-x86_64": "macos-x86_64",
    "darwin-amd64": "macos-x86_64",
    "darwin-arm64": "macos-arm64",
    "darwin-aarch64": "macos-arm64",
    "macos-aarch64": "macos-arm64",
    "macosx-x86_64": "macos-x86_64",
    "macosx-arm64": "macos-arm64",
    "windows-amd64": "windows-x86_64",
    "windows-x64": "windows-x86_64",
    "windows-aarch64": "windows-arm64",
    "win-x86_64": "windows-x86_64",
    "win-amd64": "windows-x86_64",
    "win-arm64": "windows-arm64",
}


def normalize_machine(machine: str | None = None) -> str:
    raw = (machine or platform.machine() or "unknown").lower().replace("-", "_")
    return {
        "amd64": "x86_64",
        "x64": "x86_64",
        "i386": "x86",
        "i686": "x86",
        "arm64": "arm64",
        "aarch64": "aarch64",
    }.get(raw, raw)


def normalize_runtime_key(value: str) -> str:
    key = value.strip().lower().replace("_", "-")
    key = key.replace("linux-x86-64", "linux-x86_64")
    key = key.replace("macos-x86-64", "macos-x86_64")
    key = key.replace("windows-x86-64", "windows-x86_64")
    key = key.replace("darwin-x86-64", "darwin-x86_64")
    key = RUNTIME_ALIASES.get(key, key)
    if key not in SUPPORTED_RUNTIME_KEYS:
        supported = ", ".join(SUPPORTED_RUNTIME_KEYS)
        raise SystemExit(
            f"unsupported target runtime {value!r}; expected one of: {supported}"
        )
    return key


def host_runtime_key() -> str:
    if os.name == "nt":
        os_tag = "windows"
    elif sys.platform == "darwin":
        os_tag = "macos"
    elif sys.platform.startswith("linux"):
        os_tag = "linux"
    else:
        os_tag = sys.platform.replace("-", "_")

    arch = normalize_machine()
    if os_tag == "linux" and arch == "arm64":
        arch = "aarch64"
    elif os_tag in {"macos", "windows"} and arch == "aarch64":
        arch = "arm64"
    return normalize_runtime_key(f"{os_tag}-{arch}")


def env_runtime_key() -> str | None:
    for name in TARGET_RUNTIME_ENVS:
        value = os.environ.get(name)
        if value:
            return normalize_runtime_key(value)
    return None


def executable_suffix(runtime_key: str) -> str:
    return ".exe" if runtime_key.startswith("windows-") else ""


def built_binary_path(
    profile: str, runtime_key: str, target_triple: str | None = None
) -> Path:
    if target_triple:
        return (
            REPO_ROOT
            / "rust"
            / "target"
            / target_triple
            / profile
            / f"{BASE_BINARY}{executable_suffix(runtime_key)}"
        )
    return (
        REPO_ROOT
        / "rust"
        / "target"
        / profile
        / f"{BASE_BINARY}{executable_suffix(runtime_key)}"
    )


def staged_binary_path(runtime_key: str) -> Path:
    return PACKAGE_BIN / f"{BASE_BINARY}-{runtime_key}{executable_suffix(runtime_key)}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--profile",
        choices=("release", "debug"),
        default="release",
        help="Cargo build profile to stage; release is used for wheels.",
    )
    parser.add_argument("--target-runtime", help="Stable runtime key to stage.")
    parser.add_argument(
        "--cargo-target", help="Cargo target triple for cross-compilation."
    )
    parser.add_argument(
        "--source",
        type=Path,
        help="Copy this prebuilt executable instead of rust/target output.",
    )
    parser.add_argument(
        "--no-build",
        action="store_true",
        help="Only copy an already-built executable.",
    )
    args = parser.parse_args()

    runtime_key = (
        normalize_runtime_key(args.target_runtime)
        if args.target_runtime
        else (env_runtime_key() or host_runtime_key())
    )

    if args.source is not None:
        source = args.source.expanduser().resolve()
    else:
        if not args.no_build:
            cargo_args = ["cargo", "build", "--manifest-path", str(RUST_MANIFEST)]
            if args.profile == "release":
                cargo_args.append("--release")
            if args.cargo_target:
                cargo_args.extend(("--target", args.cargo_target))
            subprocess.run(cargo_args, check=True, cwd=REPO_ROOT)
        source = built_binary_path(args.profile, runtime_key, args.cargo_target)

    if not source.is_file():
        raise SystemExit(f"built Rust binary not found: {source}")

    PACKAGE_BIN.mkdir(parents=True, exist_ok=True)
    target = staged_binary_path(runtime_key)
    shutil.copy2(source, target)
    target.chmod(target.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    print(target.relative_to(REPO_ROOT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
