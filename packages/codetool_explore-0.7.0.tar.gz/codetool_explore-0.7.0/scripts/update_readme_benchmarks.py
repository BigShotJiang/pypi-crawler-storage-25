"""Refresh generated benchmark tables in README.md from reports/*.json."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import mean
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
START = "<!-- benchmark-results:start -->"
END = "<!-- benchmark-results:end -->"


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def fmt_ms(value: float) -> str:
    return f"{value:.1f} ms"


def fmt_bytes(value: int) -> str:
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f} MB"
    if value >= 1_000:
        return f"{value / 1_000:.1f} KB"
    return f"{value} B"


def bar(value: float, max_value: float, width: int = 18) -> str:
    if max_value <= 0:
        return ""
    filled = max(1, round((value / max_value) * width))
    return "█" * filled + "░" * (width - filled)


def timing_rows(data: dict[str, Any]) -> list[tuple[str, float]]:
    values: dict[str, list[float]] = {
        "codetool-explore": [],
        "rg": [],
        "grep": [],
        "rtk": [],
    }
    for corpus in data.get("corpora", {}).values():
        for scenario in corpus.get("scenarios", {}).values():
            for tool in values:
                summary = scenario.get(tool)
                if isinstance(summary, dict) and isinstance(
                    summary.get("median_ms"), int | float
                ):
                    values[tool].append(float(summary["median_ms"]))
    return [
        (tool, mean(samples))
        for tool, samples in values.items()
        if samples
    ]


def render_timing(data: dict[str, Any], source: str) -> list[str]:
    rows = sorted(timing_rows(data), key=lambda item: item[1])
    max_ms = max((value for _, value in rows), default=0)
    corpora = data.get("corpora", {})
    scenarios = data.get("scenarios", {})
    lines = [
        "### Execution performance",
        "",
        (
            f"Mean of median wall-clock timings across {len(corpora)} corpora × "
            f"{len(scenarios)} scenarios, {data.get('rounds', '?')} measured rounds "
            f"after {data.get('warmup', '?')} warmup."
        ),
        "",
        "| Tool | Mean median time | Chart |",
        "| --- | ---: | --- |",
    ]
    for tool, value in rows:
        lines.append(f"| `{tool}` | {fmt_ms(value)} | {bar(value, max_ms)} |")
    fastest_tool, fastest = rows[0] if rows else (None, 0)
    codetool = dict(rows).get("codetool-explore")
    if codetool and fastest:
        lines.append("")
        if fastest_tool == "codetool-explore":
            lines.append("`codetool-explore` is the fastest tool in this run.")
        else:
            note = (
                f"`codetool-explore` is {codetool / fastest:.2f}× slower than "
                f"`{fastest_tool}` in this run"
            )
            rtk = dict(rows).get("rtk")
            if rtk and rtk > codetool:
                note += f" and {rtk / codetool:.2f}× faster than `rtk`"
            lines.append(note + ".")
    lines += ["", f"Source: `{source}`."]
    return lines


def compression_totals(data: dict[str, Any]) -> dict[str, Any]:
    totals: dict[str, int] = {
        "full_bytes": 0,
        "compressed_bytes": 0,
        "raw_bytes": 0,
        "rg_bytes": 0,
        "grep_bytes": 0,
        "rtk_bytes": 0,
        "full_tokens": 0,
        "compressed_tokens": 0,
        "raw_tokens": 0,
        "rg_tokens": 0,
        "grep_tokens": 0,
        "rtk_tokens": 0,
    }
    savings: list[float] = []
    samples = 0
    tokenizer = None
    for corpus in data.get("corpora", {}).values():
        for scenario in corpus.get("scenarios", {}).values():
            item = scenario.get("output_compression")
            if not isinstance(item, dict):
                continue
            samples += 1
            full_stats = item.get("full_json")
            compressed_stats = item.get("compressed_json")
            raw_stats = item.get("raw_text")
            rg_stats = item.get("rg_stdout", {})
            grep_stats = item.get("grep_stdout", {})
            rtk_stats = item.get("rtk_grep_stdout", {})
            if isinstance(full_stats, dict):
                totals["full_bytes"] += int(full_stats.get("bytes", 0))
                totals["full_tokens"] += int(full_stats.get("tokens", 0))
                tokenizer = tokenizer or full_stats.get("tokenizer")
            else:
                full = item.get("full_json_bytes")
                if isinstance(full, int):
                    totals["full_bytes"] += full
                    totals["full_tokens"] += round(full / 4)
            if isinstance(compressed_stats, dict):
                totals["compressed_bytes"] += int(compressed_stats.get("bytes", 0))
                totals["compressed_tokens"] += int(compressed_stats.get("tokens", 0))
                tokenizer = tokenizer or compressed_stats.get("tokenizer")
            else:
                compressed = item.get("compressed_json_bytes")
                if isinstance(compressed, int):
                    totals["compressed_bytes"] += compressed
                    totals["compressed_tokens"] += round(compressed / 4)
            if isinstance(raw_stats, dict):
                totals["raw_bytes"] += int(raw_stats.get("bytes", 0))
                totals["raw_tokens"] += int(raw_stats.get("tokens", 0))
                tokenizer = tokenizer or raw_stats.get("tokenizer")
            if isinstance(rg_stats, dict) and isinstance(rg_stats.get("stdout"), dict):
                stdout = rg_stats["stdout"]
                totals["rg_bytes"] += int(stdout.get("bytes", 0))
                totals["rg_tokens"] += int(stdout.get("tokens", 0))
            if isinstance(grep_stats, dict) and isinstance(grep_stats.get("stdout"), dict):
                stdout = grep_stats["stdout"]
                totals["grep_bytes"] += int(stdout.get("bytes", 0))
                totals["grep_tokens"] += int(stdout.get("tokens", 0))
            if isinstance(rtk_stats, dict) and isinstance(rtk_stats.get("stdout"), dict):
                stdout = rtk_stats["stdout"]
                totals["rtk_bytes"] += int(stdout.get("bytes", 0))
                totals["rtk_tokens"] += int(stdout.get("tokens", 0))
            percent = item.get("percent_smaller")
            if isinstance(percent, int | float):
                savings.append(float(percent))
    return {
        "totals": totals,
        "savings": savings,
        "samples": samples,
        "tokenizer": tokenizer or "approx_4chars",
    }


def render_tokens(data: dict[str, Any], source: str) -> list[str]:
    if "summary" not in data:
        aggregate = compression_totals(data)
        totals = aggregate["totals"]
        raw = int(totals["raw_bytes"])
        rtk = int(totals["rtk_bytes"])
        rg = int(totals["rg_bytes"])
        raw_tokens = int(totals["raw_tokens"])
        rtk_tokens = int(totals["rtk_tokens"])
        rg_tokens = int(totals["rg_tokens"])
        savings = aggregate["savings"]
        if not raw:
            raise SystemExit(f"{source} does not contain token-compression data")
        rows = []
        if raw:
            rows.append(("`codetool-explore`", raw_tokens, raw))
        if rtk:
            rows.append(("`rtk grep` stdout", rtk_tokens, rtk))
        if rg:
            rows.append(("`rg` stdout", rg_tokens, rg))
        max_tokens = max(tokens for _, tokens, _ in rows)
        samples = aggregate["samples"] or len(savings)
        raw_ratio = round(raw_tokens / rtk_tokens, 2) if rtk_tokens else None
        raw_note = (
            f" It is {raw_ratio}× the `rtk grep` token count in this run."
            if raw_ratio is not None
            else ""
        )
        lines = [
            "### Token compression",
            "",
            (
                "Token counts use `tiktoken` when available. The table compares "
                f"serialized output across {samples} corpus/scenario samples."
            ),
            "",
            "| Output | Tokens | Bytes | Chart |",
            "| --- | ---: | ---: | --- |",
        ]
        for label, tokens, bytes_value in sorted(rows, key=lambda item: item[1]):
            lines.append(
                f"| {label} | {tokens:,} | {fmt_bytes(bytes_value)} | {bar(tokens, max_tokens)} |"
            )
        lines += [
            "",
            (
                "`codetool-explore` is raw text from "
                '`explore(..., result_format="text")`; it omits metadata and '
                "is optimized for minimum tokens." + raw_note
            ),
            "",
            f"Source: `{source}`.",
        ]
        return lines

    summary = data["summary"]
    totals = summary["total_bytes"]
    raw = int(totals.get("codetool_raw_text", 0))
    rtk = int(totals.get("rtk_grep_stdout", 0))
    rg = int(totals.get("rg_stdout", 0))
    token_totals = summary.get("total_tokens", {})
    raw_tokens = int(token_totals.get("codetool_raw_text", round(raw / 4)))
    rtk_tokens = int(token_totals.get("rtk_grep_stdout", round(rtk / 4)))
    rg_tokens = int(token_totals.get("rg_stdout", round(rg / 4)))
    rows = []
    if raw:
        rows.append(("`codetool-explore`", raw_tokens, raw))
    if rtk:
        rows.append(("`rtk grep` stdout", rtk_tokens, rtk))
    if rg:
        rows.append(("`rg` stdout", rg_tokens, rg))
    max_tokens = max(tokens for _, tokens, _ in rows)
    comparison = summary["total_comparison"]
    lines = [
        "### Token compression",
        "",
        (
            "Token counts use `tiktoken` when available. The table compares output "
            f"across {summary['scenarios']} RTK-corpus scenarios."
        ),
        "",
        "| Output | Tokens | Bytes | Chart |",
        "| --- | ---: | ---: | --- |",
    ]
    for label, tokens, bytes_value in sorted(rows, key=lambda item: item[1]):
        lines.append(
            f"| {label} | {tokens:,} | {fmt_bytes(bytes_value)} | {bar(tokens, max_tokens)} |"
        )
    raw_ratio = comparison.get("codetool_raw_over_rtk_tokens_ratio")
    raw_note = (
        f" It is {raw_ratio}× the `rtk grep` token count in this run."
        if raw_ratio is not None
        else ""
    )
    lines += [
        "",
        (
            "`codetool-explore` is raw text from "
            '`explore(..., result_format="text")`; it omits backend/totals '
            "metadata, includes only a cursor hint when truncated, and prints "
            "`No Match` for empty pages." + raw_note
        ),
        "",
        f"Source: `{source}`.",
    ]
    return lines


def render_block(perf: dict[str, Any], perf_source: str, tokens: dict[str, Any], tokens_source: str) -> str:
    lines = [
        START,
        "",
        "<!-- Generated by scripts/update_readme_benchmarks.py; do not edit by hand. -->",
        "",
        *render_timing(perf, perf_source),
        "",
        *render_tokens(tokens, tokens_source),
        "",
        END,
    ]
    return "\n".join(lines)


def replace_block(readme: Path, block: str) -> None:
    text = readme.read_text(encoding="utf-8")
    if START not in text or END not in text:
        raise SystemExit(f"{readme} is missing benchmark markers")
    before, rest = text.split(START, 1)
    _, after = rest.split(END, 1)
    readme.write_text(before + block + after, encoding="utf-8")


def display_path(path: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(REPO_ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--readme", type=Path, default=REPO_ROOT / "README.md")
    parser.add_argument(
        "--performance",
        type=Path,
        default=REPO_ROOT / "reports" / "search_benchmark.json",
    )
    parser.add_argument(
        "--tokens",
        type=Path,
        default=REPO_ROOT / "reports" / "search_benchmark_rtk_compression.json",
    )
    args = parser.parse_args()

    perf = load_json(args.performance)
    tokens = load_json(args.tokens)
    block = render_block(
        perf,
        display_path(args.performance),
        tokens,
        display_path(args.tokens),
    )
    replace_block(args.readme, block)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
