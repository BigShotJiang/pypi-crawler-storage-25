from __future__ import annotations


def test_public_import_exports_explore(tmp_path):
    import codetool_explore
    from codetool_explore import ExploreError, __all__, explore

    (tmp_path / "example.py").write_text("needle\n", encoding="utf-8")

    assert __all__ == [
        "explore",
        "ExploreArgumentError",
        "ExploreBackendError",
        "ExploreError",
        "ExplorePatternError",
        "ExploreRootError",
    ]
    assert issubclass(ExploreError, Exception)
    assert not hasattr(codetool_explore, "search")
    result = explore("needle", root=str(tmp_path), backend="python")
    assert result["backend"] == {"selected": "python"}
    assert result["matches"][0]["p"] == "example.py"
    assert explore("example", root=str(tmp_path), target="path", backend="python")[
        "matches"
    ][0]["p"] == "example.py"
