from __future__ import annotations

import importlib.util
from pathlib import Path


spec = importlib.util.spec_from_file_location(
    "hatch_build", Path(__file__).resolve().parents[1] / "hatch_build.py"
)
hatch_build = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(hatch_build)


def test_wheel_tag_env_specific_overrides_generic(monkeypatch):
    monkeypatch.setenv("CODETOOL_TARGET_WHEEL_TAG", "linux_aarch64")
    monkeypatch.setenv("CODETOOL_EXPLORE_TARGET_WHEEL_TAG", "manylinux_2_28_x86_64")

    assert hatch_build.wheel_tag_for_runtime("linux-x86_64") == "manylinux_2_28_x86_64"


def test_runtime_to_default_wheel_tags():
    assert hatch_build.wheel_tag_for_runtime("linux-aarch64") == "manylinux2014_aarch64"
    assert hatch_build.wheel_tag_for_runtime("macos-arm64") == "macosx_11_0_arm64"
    assert hatch_build.wheel_tag_for_runtime("windows-x86_64") == "win_amd64"


def test_find_staged_binary_selects_only_requested_runtime(tmp_path):
    bin_dir = tmp_path / "_bin"
    bin_dir.mkdir()
    linux = bin_dir / "codetool-explore-rust-linux-x86_64"
    macos = bin_dir / "codetool-explore-rust-macos-arm64"
    linux.write_text("linux", encoding="utf-8")
    macos.write_text("mac", encoding="utf-8")

    assert hatch_build._find_staged_binary(bin_dir, "macos-arm64") == macos
