from __future__ import annotations

import json
import subprocess
import sys

import pytest

from codetool_explore import ExploreArgumentError
from codetool_explore import rust_backend
from codetool_explore.rust_backend import RustBackendUnavailable, search_rust


def test_find_rust_binary_uses_environment_variable(monkeypatch):
    monkeypatch.setenv(rust_backend.ENV_BINARY, sys.executable)

    assert rust_backend.find_rust_binary() == sys.executable


def test_search_rust_invokes_binary_and_parses_json(monkeypatch, tmp_path):
    captured = {}

    def fake_run(args, **kwargs):
        captured["args"] = args
        captured["kwargs"] = kwargs
        return subprocess.CompletedProcess(
            args,
            0,
            stdout=json.dumps({"matches": [], "argv": args[1:]}),
            stderr="",
        )

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    result = search_rust(
        "Needle",
        root=str(tmp_path),
        mode="snippets",
        glob=["*.py"],
        exclude="build/**",
        context_lines=2,
        limit=3,
        cursor="6",
        binary="/fake/rust",
    )

    assert result["backend"] == "rust"
    assert "--pattern" in result["argv"]
    assert result["argv"][result["argv"].index("--pattern") + 1] == "Needle"
    assert result["argv"][result["argv"].index("--mode") + 1] == "snippets"
    assert result["argv"][result["argv"].index("--target") + 1] == "content"
    assert result["argv"][result["argv"].index("--glob") + 1] == "*.py"
    assert result["argv"][result["argv"].index("--exclude") + 1] == "build/**"
    assert captured["kwargs"]["capture_output"] is True
    assert captured["kwargs"]["text"] is True
    assert captured["kwargs"]["encoding"] == "utf-8"


def test_search_rust_passes_regex_flag(monkeypatch, tmp_path):
    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(
            args,
            0,
            stdout=json.dumps({"matches": [], "argv": args[1:]}),
            stderr="",
        )

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    result = search_rust(
        r"Need(le|les)",
        root=str(tmp_path),
        regex=True,
        binary="/fake/rust",
    )

    assert result["backend"] == "rust"
    assert "--regex" in result["argv"]


def test_search_rust_passes_path_target(monkeypatch, tmp_path):
    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(
            args,
            0,
            stdout=json.dumps({"matches": [], "argv": args[1:]}),
            stderr="",
        )

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    result = search_rust(
        "",
        root=str(tmp_path),
        target="path",
        path_scope="basename",
        binary="/fake/rust",
    )

    assert result["backend"] == "rust"
    assert result["argv"][result["argv"].index("--target") + 1] == "path"
    assert result["argv"][result["argv"].index("--path-scope") + 1] == "basename"


def test_search_rust_passes_multiple_roots(monkeypatch, tmp_path):
    src = tmp_path / "src"
    tests = tmp_path / "tests"
    src.mkdir()
    tests.mkdir()

    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(
            args,
            0,
            stdout=json.dumps({"matches": [], "argv": args[1:]}),
            stderr="",
        )

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    result = search_rust(
        "Needle",
        root=[str(src), str(tests)],
        binary="/fake/rust",
    )

    root_indexes = [
        index for index, value in enumerate(result["argv"]) if value == "--root"
    ]
    assert [result["argv"][index + 1] for index in root_indexes] == [
        str(src),
        str(tests),
    ]


def test_search_rust_splits_space_separated_root_string(monkeypatch, tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "tools").mkdir()
    monkeypatch.chdir(tmp_path)

    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(
            args,
            0,
            stdout=json.dumps({"matches": [], "argv": args[1:]}),
            stderr="",
        )

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    result = search_rust("Needle", root="src tools", binary="/fake/rust")

    root_indexes = [
        index for index, value in enumerate(result["argv"]) if value == "--root"
    ]
    assert [result["argv"][index + 1] for index in root_indexes] == [
        "src",
        "tools",
    ]


def test_search_rust_allows_content_or_path_target_snippets(monkeypatch, tmp_path):
    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(
            args,
            0,
            stdout=json.dumps({"matches": [], "argv": args[1:]}),
            stderr="",
        )

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    result = search_rust(
        "Needle",
        root=str(tmp_path),
        target="content_or_path",
        mode="snippets",
        binary="/fake/rust",
    )

    assert result["backend"] == "rust"
    assert result["argv"][result["argv"].index("--target") + 1] == "content_or_path"
    assert result["argv"][result["argv"].index("--mode") + 1] == "snippets"


def test_search_rust_unavailable(monkeypatch):
    monkeypatch.setattr(rust_backend, "find_rust_binary", lambda: None)

    with pytest.raises(RustBackendUnavailable):
        search_rust("Needle")


@pytest.mark.parametrize(
    ("kwargs", "message"),
    [
        ({"mode": "unknown"}, "mode"),
        ({"path_scope": "unknown"}, "path_scope"),
        ({"case": "unknown"}, "case"),
        ({"limit": 0}, "limit"),
        ({"context_lines": "many"}, "context_lines"),
        ({"target": "path", "mode": "snippets"}, "snippets"),
        ({"target": "both"}, "target"),
        ({"target": "read"}, "target"),
        ({"target": "list"}, "target"),
    ],
)
def test_search_rust_validates_arguments_before_binary_discovery(
    monkeypatch, tmp_path, kwargs, message
):
    def fail_discovery():
        raise AssertionError("Rust binary discovery should not run")

    monkeypatch.setattr(rust_backend, "find_rust_binary", fail_discovery)

    with pytest.raises(ExploreArgumentError, match=message):
        search_rust("Needle", root=str(tmp_path), **kwargs)


def test_search_rust_reports_invalid_json(monkeypatch):
    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(args, 0, stdout="not-json", stderr="")

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    with pytest.raises(RuntimeError, match="invalid JSON"):
        search_rust("Needle", binary="/fake/rust")


def test_search_rust_reports_nonzero_exit(monkeypatch):
    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(args, 5, stdout="", stderr="boom")

    monkeypatch.setattr(rust_backend.subprocess, "run", fake_run)

    with pytest.raises(RuntimeError, match="boom"):
        search_rust("Needle", binary="/fake/rust")
