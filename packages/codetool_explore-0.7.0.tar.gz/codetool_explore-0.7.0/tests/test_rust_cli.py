from __future__ import annotations

import json
import shutil
import subprocess

import pytest


def run_rust_cli_raw(root, *args):
    cargo = shutil.which("cargo")
    if cargo is None:
        pytest.skip("cargo is not available")

    command = [
        cargo,
        "run",
        "--quiet",
        "--manifest-path",
        "rust/Cargo.toml",
        "--",
        *args,
    ]
    if root is not None:
        command.extend(["--root", str(root)])
    return subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )


def run_rust_cli(tmp_path, *args):
    completed = run_rust_cli_raw(tmp_path, *args)
    completed.check_returncode()
    return json.loads(completed.stdout)



def test_rust_cli_literal_search_json_output(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "service.py").write_text(
        "class UserService:\n    pass\n", encoding="utf-8"
    )
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "ignored.py").write_text(
        "UserService\n", encoding="utf-8"
    )
    (tmp_path / "binary.bin").write_bytes(b"\x00UserService\n")

    result = run_rust_cli(
        tmp_path,
        "--pattern",
        "UserService",
        "--mode",
        "files",
    )

    assert result["backend"] == "rust"
    assert result["matches"] == [
        {"path": "src/service.py", "count": 1, "first_line": 1}
    ]
    assert result["skipped"] == {"binary": 1, "huge": 0, "errors": 0}


def test_rust_cli_case_insensitive_snippets_and_non_overlapping_count(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "cases.py").write_text(
        "aaa\nAaAa\nUserService\nuserservice\n",
        encoding="utf-8",
    )

    insensitive = run_rust_cli(
        tmp_path,
        "--pattern",
        "userservice",
        "--mode",
        "snippets",
        "--limit",
        "10",
    )

    assert insensitive["effective_case"] == "insensitive"
    assert insensitive["count"] == 2
    assert insensitive["total_matches"] == 2
    assert [match["line"] for match in insensitive["matches"]] == [3, 4]
    assert all("context" not in match for match in insensitive["matches"])

    non_overlapping = run_rust_cli(
        tmp_path,
        "--pattern",
        "aa",
        "--case",
        "insensitive",
        "--mode",
        "count",
        "--limit",
        "10",
    )

    assert non_overlapping["count"] == 3
    assert non_overlapping["matches"] == [
        {"path": "src/cases.py", "count": 3, "first_line": 1}
    ]


def test_rust_cli_regex_alternation_snippets_and_line_anchors(tmp_path):
    (tmp_path / "docs").mkdir()
    (tmp_path / "docs" / "help.md").write_text(
        "before\n"
        "Maximum number of results\n"
        "Text or regex pattern\n"
        "maximum number of results\n",
        encoding="utf-8",
    )
    pattern = "Maximum number of results" + "|" + "Text or regex pattern"

    alternation = run_rust_cli(
        tmp_path,
        "--pattern",
        pattern,
        "--regex",
        "--mode",
        "snippets",
        "--context-lines",
        "1",
        "--limit",
        "10",
    )

    assert alternation["regex"] is True
    assert alternation["effective_case"] == "sensitive"
    assert alternation["count"] == 2
    assert [match["line"] for match in alternation["matches"]] == [2, 3]
    assert alternation["matches"][0]["context"] == [
        {"line": 1, "text": "before"},
        {"line": 2, "text": "Maximum number of results"},
        {"line": 3, "text": "Text or regex pattern"},
    ]

    anchored = run_rust_cli(
        tmp_path,
        "--pattern",
        "^Text or regex pattern$",
        "--regex",
        "--mode",
        "files",
    )

    assert anchored["matches"] == [
        {"path": "docs/help.md", "count": 1, "first_line": 3}
    ]


def test_rust_cli_rejects_empty_match_regex_counts(tmp_path):
    (tmp_path / "sample.txt").write_text("abc\n", encoding="utf-8")

    completed = run_rust_cli_raw(
        tmp_path,
        "--pattern",
        "a*",
        "--regex",
        "--mode",
        "count",
    )

    assert completed.returncode == 2
    assert "empty spans" in completed.stderr


def test_rust_cli_file_root_searches_only_that_file(tmp_path):
    docs = tmp_path / "docs"
    docs.mkdir()
    target = docs / "tools.md"
    target.write_text("before\n## `search`\nsearch again\n", encoding="utf-8")
    (docs / "other.md").write_text("search should not be scanned\n", encoding="utf-8")

    result = run_rust_cli(
        target,
        "--pattern",
        "search",
        "--mode",
        "snippets",
        "--context-lines",
        "1",
        "--limit",
        "10",
    )

    assert result["backend"] == "rust"
    assert result["scanned_files"] == 1
    assert result["count"] == 2
    assert result["total_files"] == 1
    assert [match["path"] for match in result["matches"]] == ["tools.md", "tools.md"]
    assert result["matches"][0]["context"] == [
        {"line": 1, "text": "before"},
        {"line": 2, "text": "## `search`"},
        {"line": 3, "text": "search again"},
    ]


def test_rust_cli_accepts_multiple_roots_with_common_relative_paths(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "tests").mkdir()
    (tmp_path / "docs").mkdir()
    (tmp_path / "src" / "a.py").write_text("Needle\n", encoding="utf-8")
    (tmp_path / "src" / "skip").mkdir()
    (tmp_path / "src" / "skip" / "generated.py").write_text(
        "Needle\n", encoding="utf-8"
    )
    (tmp_path / "tests" / "test_a.py").write_text("Needle\n", encoding="utf-8")
    (tmp_path / "docs" / "a.md").write_text("Needle\n", encoding="utf-8")

    result = run_rust_cli(
        None,
        "--pattern",
        "Needle",
        "--mode",
        "files",
        "--root",
        str(tmp_path / "src"),
        "--root",
        str(tmp_path / "tests"),
        "--exclude",
        "src/skip/**",
    )

    assert result["root"] == [str(tmp_path / "src"), str(tmp_path / "tests")]
    assert {match["path"] for match in result["matches"]} == {
        "src/a.py",
        "tests/test_a.py",
    }


def test_rust_cli_deduplicates_overlapping_roots(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "a.py").write_text("Needle\n", encoding="utf-8")

    result = run_rust_cli(
        None,
        "--pattern",
        "Needle",
        "--mode",
        "files",
        "--root",
        str(tmp_path),
        "--root",
        str(tmp_path / "src"),
    )

    assert result["matches"] == [
        {"path": "src/a.py", "count": 1, "first_line": 1}
    ]
    assert result["total_files"] == 1
    assert result["count"] == 1
    assert result["scanned_files"] == 1


def test_rust_cli_searches_explicit_root_named_like_common_ignore(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "build" / "sub").mkdir(parents=True)
    (tmp_path / "build" / "node_modules").mkdir()
    (tmp_path / ".gitignore").write_text("build/\n", encoding="utf-8")
    (tmp_path / "src" / "a.py").write_text("Needle\n", encoding="utf-8")
    (tmp_path / "build" / "sub" / "generated.py").write_text(
        "Needle\n", encoding="utf-8"
    )
    (tmp_path / "build" / "node_modules" / "pkg.py").write_text(
        "Needle\n", encoding="utf-8"
    )

    result = run_rust_cli(
        None,
        "--pattern",
        "Needle",
        "--mode",
        "files",
        "--root",
        str(tmp_path / "src"),
        "--root",
        str(tmp_path / "build"),
    )

    assert {match["path"] for match in result["matches"]} == {
        "src/a.py",
        "build/sub/generated.py",
    }
    assert result["total_files"] == 2


def test_rust_cli_preserves_root_local_bare_ignore_patterns(tmp_path):
    (tmp_path / "src" / "sub").mkdir(parents=True)
    (tmp_path / "tests").mkdir()
    (tmp_path / "src" / ".gitignore").write_text("generated.py\n", encoding="utf-8")
    (tmp_path / "src" / "keep.py").write_text("Needle\n", encoding="utf-8")
    (tmp_path / "src" / "sub" / "generated.py").write_text(
        "Needle\n", encoding="utf-8"
    )
    (tmp_path / "tests" / "test_keep.py").write_text("Needle\n", encoding="utf-8")

    result = run_rust_cli(
        None,
        "--pattern",
        "Needle",
        "--mode",
        "files",
        "--root",
        str(tmp_path / "src"),
        "--root",
        str(tmp_path / "tests"),
    )

    assert {match["path"] for match in result["matches"]} == {
        "src/keep.py",
        "tests/test_keep.py",
    }
    assert result["total_files"] == 2


def test_rust_cli_preserves_explicit_root_ignored_by_wildcard_child_pattern(
    tmp_path,
):
    (tmp_path / "src").mkdir()
    (tmp_path / "build" / "sub").mkdir(parents=True)
    (tmp_path / ".gitignore").write_text("build/*\n", encoding="utf-8")
    (tmp_path / "src" / "a.py").write_text("Needle\n", encoding="utf-8")
    (tmp_path / "build" / "sub" / "generated.py").write_text(
        "Needle\n", encoding="utf-8"
    )

    result = run_rust_cli(
        None,
        "--pattern",
        "Needle",
        "--mode",
        "files",
        "--root",
        str(tmp_path / "src"),
        "--root",
        str(tmp_path / "build"),
    )

    assert {match["path"] for match in result["matches"]} == {
        "src/a.py",
        "build/sub/generated.py",
    }
    assert result["total_files"] == 2


def test_rust_cli_path_target_does_not_require_content_match(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "auth.py").write_text("no content hit\n", encoding="utf-8")
    (tmp_path / "src" / "users.py").write_text("auth only in content\n", encoding="utf-8")

    result = run_rust_cli(
        tmp_path,
        "--pattern",
        "auth",
        "--target",
        "path",
        "--mode",
        "files",
    )

    assert result["target"] == "path"
    assert result["scanned_files"] == 2
    assert result["scanned_bytes"] == 0
    assert result["count"] == 1
    assert result["matches"] == [
        {"path": "src/auth.py", "kind": "file", "match_kind": "path"}
    ]


def test_rust_cli_literal_path_search_uses_unicode_casefold(tmp_path):
    (tmp_path / "CAFÉ.py").write_text("", encoding="utf-8")
    (tmp_path / "Straße.py").write_text("", encoding="utf-8")

    result = run_rust_cli(
        tmp_path,
        "--pattern",
        "café",
        "--target",
        "path",
        "--case",
        "insensitive",
        "--mode",
        "files",
        "--limit",
        "10",
    )
    sharp_s = run_rust_cli(
        tmp_path,
        "--pattern",
        "strasse",
        "--target",
        "path",
        "--case",
        "insensitive",
        "--mode",
        "files",
        "--limit",
        "10",
    )

    assert [match["path"] for match in result["matches"]] == ["CAFÉ.py"]
    assert [match["path"] for match in sharp_s["matches"]] == ["Straße.py"]


def test_rust_cli_content_or_path_target_marks_content_and_path_kinds(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "auth.py").write_text("no content hit\n", encoding="utf-8")
    (tmp_path / "src" / "users.py").write_text("auth in content\n", encoding="utf-8")
    (tmp_path / "src" / "auth_model.py").write_text("auth in content\n", encoding="utf-8")

    result = run_rust_cli(
        tmp_path,
        "--pattern",
        "auth",
        "--target",
        "content_or_path",
        "--mode",
        "files",
    )

    by_path = {match["path"]: match for match in result["matches"]}
    assert by_path["src/auth.py"]["match_kind"] == "path"
    assert by_path["src/users.py"]["match_kind"] == "content"
    assert by_path["src/auth_model.py"]["match_kind"] == "content_and_path"
    assert result["path_matches"] == 2
    assert result["content_files"] == 2
    assert result["content_count"] == 2
    assert result["count"] == 3


def test_rust_cli_content_or_path_target_snippets_include_path_only_rows(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "auth.py").write_text("no content hit\n", encoding="utf-8")
    (tmp_path / "src" / "users.py").write_text(
        "auth in content\n", encoding="utf-8"
    )
    (tmp_path / "src" / "auth_model.py").write_text(
        "auth in content too\n", encoding="utf-8"
    )

    result = run_rust_cli(
        tmp_path,
        "--pattern",
        "auth",
        "--target",
        "content_or_path",
        "--mode",
        "snippets",
        "--limit",
        "10",
    )

    by_path = {match["path"]: match for match in result["matches"]}
    assert by_path["src/auth.py"] == {
        "path": "src/auth.py",
        "kind": "file",
        "match_kind": "path",
    }
    assert by_path["src/users.py"]["line"] == 1
    assert by_path["src/users.py"]["match_kind"] == "content"
    assert by_path["src/auth_model.py"]["line"] == 1
    assert by_path["src/auth_model.py"]["match_kind"] == "content_and_path"
    assert result["total_files"] == 3
    assert result["total_matches"] == 3
    assert result["path_matches"] == 2
    assert result["content_files"] == 2
    assert result["content_count"] == 2
    assert result["count"] == 3
