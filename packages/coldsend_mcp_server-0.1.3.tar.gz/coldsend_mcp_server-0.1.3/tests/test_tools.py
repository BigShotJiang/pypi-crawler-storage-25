"""
Tests for ColdSend MCP Server tools.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from pydantic import BaseModel

from coldsend_mcp.tools.campaigns import (
    create_campaign,
    list_campaigns,
    get_campaign,
    pause_campaign,
)
from datetime import datetime


class TestCampaignTools:
    """Test campaign management tools."""

    @pytest.mark.asyncio
    async def test_create_campaign(self):
        """Test creating a campaign."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "name": "Test Campaign",
                "status": "DRAFT"
            },
            "message": "Campaign created successfully"
        }

        with patch('coldsend_mcp.tools.campaigns.create_api_client', return_value=mock_api_client):
            result = await create_campaign(
                name="Test Campaign",
                schedule_send_at="2025-01-15T09:00:00",
                daily_limit=100,
            )

        assert result["campaign"]["id"] == "550e8400-e29b-41d4-a716-446655440000"
        assert result["campaign"]["status"] == "DRAFT"
        mock_api_client.post.assert_called_once_with(
            "/campaigns",
            {
                "name": "Test Campaign",
                "schedule_send_at": "2025-01-15T09:00:00",
                "daily_limit": 100,
                "enable_replies": True,
                "track_opens": True,
                "track_clicks": True,
            }
        )

    @pytest.mark.asyncio
    async def test_list_campaigns(self):
        """Test listing campaigns with filters."""
        mock_api_client = AsyncMock()
        mock_api_client.get.return_value = {
            "campaigns": [
                {"id": "1", "name": "Campaign 1", "status": "ACTIVE"},
                {"id": "2", "name": "Campaign 2", "status": "DRAFT"}
            ],
            "total": 2,
            "page": 1,
            "limit": 20
        }

        with patch('coldsend_mcp.tools.campaigns.create_api_client', return_value=mock_api_client):
            result = await list_campaigns(
                status_filter="ACTIVE",
                search=None,
                sort_by="created_at",
                sort_order="desc",
                page=1,
                limit=20,
            )

        assert len(result["campaigns"]) == 2
        mock_api_client.get.assert_called_once_with(
            "/campaigns",
            params={
                "page": 1,
                "limit": 20,
                "status": "ACTIVE",
                "sort_by": "created_at",
                "sort_order": "desc",
            }
        )

    @pytest.mark.asyncio
    async def test_get_campaign(self):
        """Test getting a specific campaign."""
        mock_api_client = AsyncMock()
        mock_api_client.get.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "name": "Q1 Outreach",
                "status": "ACTIVE",
                "daily_limit": 100
            }
        }

        with patch('coldsend_mcp.tools.campaigns.create_api_client', return_value=mock_api_client):
            result = await get_campaign("550e8400-e29b-41d4-a716-446655440000")

        assert result["campaign"]["id"] == "550e8400-e29b-41d4-a716-446655440000"
        mock_api_client.get.assert_called_once_with(
            "/campaigns/550e8400-e29b-41d4-a716-446655440000"
        )

    @pytest.mark.asyncio
    async def test_pause_campaign(self):
        """Test pausing a campaign."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "PAUSED"
            },
            "message": "Campaign paused successfully"
        }

        with patch('coldsend_mcp.tools.campaigns.create_api_client', return_value=mock_api_client):
            result = await pause_campaign("550e8400-e29b-41d4-a716-446655440000")

        assert result["campaign"]["status"] == "PAUSED"
        mock_api_client.post.assert_called_once_with(
            "/campaigns/550e8400-e29b-41d4-a716-446655440000/pause"
        )
