"""
Tests for authentication module.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from fastapi import HTTPException
import hashlib

from coldsend_mcp.auth import (
    hash_api_key,
    validate_api_key,
    get_current_api_key,
    APIClient,
    AuthenticationError
)


class TestAPIKeyHashing:
    """Test API key hashing functionality."""
    
    def test_hash_api_key_consistency(self):
        """Test that hashing produces consistent results."""
        api_key = "test_api_key_123"

        with patch('coldsend_mcp.auth.settings') as mock_settings:
            mock_settings.api_key_hash_secret = "test_secret"
            mock_settings.jwt_secret_key = None

            hash1 = hash_api_key(api_key)
            hash2 = hash_api_key(api_key)

        assert hash1 == hash2
    
    def test_hash_api_key_different_secrets(self):
        """Test that different secrets produce different hashes."""
        api_key = "test_api_key_123"
        
        with patch('coldsend_mcp.auth.settings') as mock_settings:
            mock_settings.api_key_hash_secret = "secret1"
            mock_settings.jwt_secret_key = None
            
            hash1 = hash_api_key(api_key)
            
            mock_settings.api_key_hash_secret = "secret2"
            mock_settings.jwt_secret_key = None
            
            hash2 = hash_api_key(api_key)
            
            assert hash1 != hash2
    
    def test_hash_api_key_format(self):
        """Test that hash is in correct format (SHA-256 hex)."""
        api_key = "test_api_key_123"

        with patch('coldsend_mcp.auth.settings') as mock_settings:
            mock_settings.api_key_hash_secret = "test_secret"
            mock_settings.jwt_secret_key = None

            hash_result = hash_api_key(api_key)

        # SHA-256 produces 64 character hex string
        assert len(hash_result) == 64
        assert all(c in '0123456789abcdef' for c in hash_result)


class TestAPIClient:
    """Test the API client wrapper."""
    
    @pytest.mark.asyncio
    async def test_api_client_get(self):
        """Test GET request."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": "test"}
        mock_response.raise_for_status = MagicMock()

        with patch('coldsend_mcp.auth.httpx.AsyncClient') as MockClient:
            mock_instance = AsyncMock()
            mock_instance.get.return_value = mock_response
            MockClient.return_value = mock_instance

            client = APIClient("http://test.com", "test_key")
            result = await client.get("/endpoint", params={"key": "value"})

            assert result == {"data": "test"}
            mock_instance.get.assert_called_once_with(
                "/endpoint",
                params={"key": "value"}
            )
    
    @pytest.mark.asyncio
    async def test_api_client_post(self):
        """Test POST request."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"result": "success"}
        mock_response.raise_for_status = MagicMock()

        with patch('coldsend_mcp.auth.httpx.AsyncClient') as MockClient:
            mock_instance = AsyncMock()
            mock_instance.post.return_value = mock_response
            MockClient.return_value = mock_instance

            client = APIClient("http://test.com", "test_key")
            result = await client.post("/endpoint", json={"data": "value"})

            assert result == {"result": "success"}
            mock_instance.post.assert_called_once_with(
                "/endpoint",
                json={"data": "value"}
            )
    
    @pytest.mark.asyncio
    async def test_api_client_close(self):
        """Test closing the client."""
        with patch('coldsend_mcp.auth.httpx.AsyncClient') as MockClient:
            mock_instance = AsyncMock()
            MockClient.return_value = mock_instance

            client = APIClient("http://test.com", "test_key")
            await client.close()

            mock_instance.aclose.assert_called_once()


class TestGetCurrentAPIKey:
    """Test API key extraction from requests."""
    
    @pytest.mark.asyncio
    async def test_get_current_api_key_success(self):
        """Test successful API key extraction."""
        mock_request = MagicMock()
        mock_request.headers = {"X-API-Key": "valid_api_key"}
        
        with patch('coldsend_mcp.auth.validate_api_key', new_callable=AsyncMock) as mock_validate:
            mock_validate.return_value = {"authenticated": True}
            
            result = await get_current_api_key(mock_request)
            
            assert result == "valid_api_key"
            mock_validate.assert_called_once_with("valid_api_key")
    
    @pytest.mark.asyncio
    async def test_get_current_api_key_missing(self):
        """Test missing API key raises exception."""
        mock_request = MagicMock()
        mock_request.headers = {}
        
        with pytest.raises(HTTPException) as exc_info:
            await get_current_api_key(mock_request)
        
        assert exc_info.value.status_code == 401
        assert "API key required" in str(exc_info.value.detail)
    
    @pytest.mark.asyncio
    async def test_get_current_api_key_invalid(self):
        """Test invalid API key raises exception."""
        mock_request = MagicMock()
        mock_request.headers = {"X-API-Key": "invalid_key"}
        
        with patch('coldsend_mcp.auth.validate_api_key', new_callable=AsyncMock) as mock_validate:
            mock_validate.side_effect = AuthenticationError("Invalid API key")
            
            with pytest.raises(HTTPException) as exc_info:
                await get_current_api_key(mock_request)
            
            assert exc_info.value.status_code == 401
            assert "Invalid API key" in str(exc_info.value.detail)


@pytest.mark.asyncio
async def test_validate_api_key_valid():
    """Test validating a valid API key."""
    with patch('httpx.AsyncClient') as MockClient:
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"user": {"id": "123"}}
        MockClient.return_value.get.return_value = mock_response
        
        result = await validate_api_key("valid_key")
        
        assert result["authenticated"] is True


@pytest.mark.asyncio
async def test_validate_api_key_invalid():
    """Test validating an invalid API key."""
    mock_response = AsyncMock()
    mock_response.status_code = 401

    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch('coldsend_mcp.auth.httpx.AsyncClient', return_value=mock_client):
        with pytest.raises(AuthenticationError) as exc_info:
            await validate_api_key("invalid_key")

        assert "Invalid API key" in str(exc_info.value)
