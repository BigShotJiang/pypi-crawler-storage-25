"""
Tests for domain and sender account tools.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from coldsend_mcp.tools.domains import (
    list_domains,
    get_domain,
    add_domain,
    verify_domain_dns,
    delete_domain
)

from coldsend_mcp.tools.sender_accounts import (
    list_sender_accounts,
    create_coldsend_inbox,
    create_smtp_inbox,
    send_test_email,
    pause_inbox,
    resume_inbox,
    delete_inbox
)


class TestDomainTools:
    """Test domain management tools."""

    @pytest.mark.asyncio
    async def test_list_domains(self):
        """Test listing domains."""
        mock_api_client = AsyncMock()
        mock_api_client.get.return_value = {
            "domains": [
                {"id": "1", "domain_name": "example.com", "status": "verified"},
                {"id": "2", "domain_name": "test.com", "status": "pending"}
            ],
            "total": 2,
            "page": 1,
            "limit": 20
        }

        with patch('coldsend_mcp.tools.domains.create_api_client', return_value=mock_api_client):
            result = await list_domains(page=1, limit=20)

        assert len(result["domains"]) == 2
        mock_api_client.get.assert_called_once_with(
            "/domains",
            params={"page": 1, "limit": 20}
        )

    @pytest.mark.asyncio
    async def test_get_domain(self):
        """Test getting domain details."""
        mock_api_client = AsyncMock()
        mock_api_client.get.return_value = {
            "domain": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "domain_name": "example.com",
                "status": "verified",
                "dns_records": [
                    {"type": "MX", "name": "@", "value": "mx.coldsend.io"}
                ]
            }
        }

        with patch('coldsend_mcp.tools.domains.create_api_client', return_value=mock_api_client):
            result = await get_domain("550e8400-e29b-41d4-a716-446655440000")

        assert result["domain"]["domain_name"] == "example.com"
        mock_api_client.get.assert_called_once_with(
            "/domains/550e8400-e29b-41d4-a716-446655440000"
        )

    @pytest.mark.asyncio
    async def test_add_domain(self):
        """Test adding a new domain."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "domain": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "domain_name": "newdomain.com",
                "status": "pending"
            },
            "message": "Domain added successfully"
        }

        with patch('coldsend_mcp.tools.domains.create_api_client', return_value=mock_api_client):
            result = await add_domain(
                domain_name="newdomain.com",
                use_nameservers=True,
            )

        assert result["domain"]["domain_name"] == "newdomain.com"
        mock_api_client.post.assert_called_once_with(
            "/domains",
            {"domain_name": "newdomain.com", "use_nameservers": True}
        )

    @pytest.mark.asyncio
    async def test_verify_domain_dns(self):
        """Test DNS verification."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "verification": {
                "status": "verified",
                "records": {
                    "mx": "valid",
                    "txt": "valid",
                    "cname": "valid"
                }
            }
        }

        with patch('coldsend_mcp.tools.domains.create_api_client', return_value=mock_api_client):
            result = await verify_domain_dns("550e8400-e29b-41d4-a716-446655440000")

        assert result["verification"]["status"] == "verified"
        mock_api_client.post.assert_called_once_with(
            "/domains/550e8400-e29b-41d4-a716-446655440000/verify"
        )

    @pytest.mark.asyncio
    async def test_delete_domain(self):
        """Test deleting a domain."""
        mock_api_client = AsyncMock()
        mock_api_client.delete.return_value = {
            "success": True,
            "message": "Domain deleted successfully"
        }

        with patch('coldsend_mcp.tools.domains.create_api_client', return_value=mock_api_client):
            result = await delete_domain("550e8400-e29b-41d4-a716-446655440000")

        assert result["success"] is True
        mock_api_client.delete.assert_called_once_with(
            "/domains/550e8400-e29b-41d4-a716-446655440000"
        )


class TestSenderAccountTools:
    """Test sender account management tools."""

    @pytest.mark.asyncio
    async def test_list_sender_accounts(self):
        """Test listing sender accounts."""
        mock_api_client = AsyncMock()
        mock_api_client.get.return_value = {
            "sender_accounts": [
                {"id": "1", "email_address": "john@example.com", "status": "ACTIVE"},
                {"id": "2", "email_address": "jane@example.com", "status": "ACTIVE"}
            ],
            "total": 2,
            "page": 1
        }

        with patch('coldsend_mcp.tools.sender_accounts.create_api_client', return_value=mock_api_client):
            result = await list_sender_accounts(
                page=1,
                limit=20,
                inbox_type="COLDSEND",
                status=None,
                search=None,
            )

        assert len(result["sender_accounts"]) == 2
        mock_api_client.get.assert_called_once_with(
            "/sender-accounts",
            params={
                "page": 1,
                "limit": 20,
                "inbox_type": "COLDSEND"
            }
        )

    @pytest.mark.asyncio
    async def test_create_coldsend_inbox(self):
        """Test creating ColdSend native inbox."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "inbox": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "email_address": "test@example.com",
                "status": "ACTIVE"
            },
            "message": "Inbox created successfully"
        }

        with patch('coldsend_mcp.tools.sender_accounts.create_api_client', return_value=mock_api_client):
            result = await create_coldsend_inbox(
                email_address="test@example.com",
                domain_id="550e8400-e29b-41d4-a716-446655440000",
                name="Test User",
            )

        assert result["inbox"]["email_address"] == "test@example.com"
        mock_api_client.post.assert_called_once_with(
            "/sender-accounts/coldsend",
            {
                "email_address": "test@example.com",
                "domain_id": "550e8400-e29b-41d4-a716-446655440000",
                "name": "Test User"
            }
        )

    @pytest.mark.asyncio
    async def test_create_smtp_inbox(self):
        """Test creating SMTP inbox."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "inbox": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "email_address": "user@gmail.com",
                "smtp_host": "smtp.gmail.com"
            },
            "message": "SMTP inbox created successfully"
        }

        with patch('coldsend_mcp.tools.sender_accounts.create_api_client', return_value=mock_api_client):
            result = await create_smtp_inbox(
                email_address="user@gmail.com",
                smtp_host="smtp.gmail.com",
                smtp_port=587,
                smtp_username="user@gmail.com",
                smtp_password="app-password",
                smtp_security="STARTTLS",
            )

        assert result["inbox"]["email_address"] == "user@gmail.com"
        mock_api_client.post.assert_called_once_with(
            "/sender-accounts/smtp",
            {
                "email_address": "user@gmail.com",
                "smtp_host": "smtp.gmail.com",
                "smtp_port": 587,
                "smtp_username": "user@gmail.com",
                "smtp_password": "app-password",
                "smtp_security": "STARTTLS",
                "name": None
            }
        )

    @pytest.mark.asyncio
    async def test_send_test_email(self):
        """Test sending test email."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "success": True,
            "message": "Test email sent successfully",
            "sent_at": "2025-01-15T10:30:00Z"
        }

        with patch('coldsend_mcp.tools.sender_accounts.create_api_client', return_value=mock_api_client):
            result = await send_test_email(
                inbox_id="550e8400-e29b-41d4-a716-446655440000",
                to_email="personal@email.com",
                subject="Test Email",
                body="This is a test",
            )

        assert result["success"] is True
        mock_api_client.post.assert_called_once_with(
            "/sender-accounts/550e8400-e29b-41d4-a716-446655440000/test",
            {
                "to_email": "personal@email.com",
                "subject": "Test Email",
                "body": "This is a test"
            }
        )

    @pytest.mark.asyncio
    async def test_pause_inbox(self):
        """Test pausing an inbox."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "inbox": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "PAUSED"
            },
            "message": "Inbox paused successfully"
        }

        with patch('coldsend_mcp.tools.sender_accounts.create_api_client', return_value=mock_api_client):
            result = await pause_inbox("550e8400-e29b-41d4-a716-446655440000")

        assert result["inbox"]["status"] == "PAUSED"
        mock_api_client.post.assert_called_once_with(
            "/sender-accounts/550e8400-e29b-41d4-a716-446655440000/pause"
        )

    @pytest.mark.asyncio
    async def test_resume_inbox(self):
        """Test resuming an inbox."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "inbox": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "ACTIVE"
            },
            "message": "Inbox resumed successfully"
        }

        with patch('coldsend_mcp.tools.sender_accounts.create_api_client', return_value=mock_api_client):
            result = await resume_inbox("550e8400-e29b-41d4-a716-446655440000")

        assert result["inbox"]["status"] == "ACTIVE"
        mock_api_client.post.assert_called_once_with(
            "/sender-accounts/550e8400-e29b-41d4-a716-446655440000/resume"
        )

    @pytest.mark.asyncio
    async def test_delete_inbox(self):
        """Test deleting an inbox."""
        mock_api_client = AsyncMock()
        mock_api_client.delete.return_value = {
            "success": True,
            "message": "Inbox deleted successfully"
        }

        with patch('coldsend_mcp.tools.sender_accounts.create_api_client', return_value=mock_api_client):
            result = await delete_inbox("550e8400-e29b-41d4-a716-446655440000")

        assert result["success"] is True
        mock_api_client.delete.assert_called_once_with(
            "/sender-accounts/550e8400-e29b-41d4-a716-446655440000"
        )
