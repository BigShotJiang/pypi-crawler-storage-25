"""
Tests for campaign update and activation tools.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from coldsend_mcp.tools.campaign_updates import (
    update_campaign,
    activate_campaign
)


class TestCampaignUpdateTools:
    """Test campaign update and activation tools."""

    @pytest.mark.asyncio
    async def test_update_campaign_name(self):
        """Test updating campaign name."""
        mock_api_client = AsyncMock()
        mock_api_client.put.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "name": "Q1 Outreach - Updated",
                "status": "DRAFT"
            },
            "message": "Campaign updated successfully"
        }

        with patch('coldsend_mcp.tools.campaign_updates.create_api_client', return_value=mock_api_client):
            result = await update_campaign(
                campaign_id="550e8400-e29b-41d4-a716-446655440000",
                updates={"name": "Q1 Outreach - Updated"},
            )

        assert result["campaign"]["name"] == "Q1 Outreach - Updated"
        mock_api_client.put.assert_called_once_with(
            "/campaigns/550e8400-e29b-41d4-a716-446655440000",
            {"name": "Q1 Outreach - Updated"}
        )

    @pytest.mark.asyncio
    async def test_update_campaign_daily_limit(self):
        """Test updating daily limit."""
        mock_api_client = AsyncMock()
        mock_api_client.put.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "daily_limit": 150,
                "status": "DRAFT"
            },
            "message": "Campaign updated successfully"
        }

        with patch('coldsend_mcp.tools.campaign_updates.create_api_client', return_value=mock_api_client):
            result = await update_campaign(
                campaign_id="550e8400-e29b-41d4-a716-446655440000",
                updates={"daily_limit": 150},
            )

        assert result["campaign"]["daily_limit"] == 150
        mock_api_client.put.assert_called_once_with(
            "/campaigns/550e8400-e29b-41d4-a716-446655440000",
            {"daily_limit": 150}
        )

    @pytest.mark.asyncio
    async def test_update_campaign_multiple_fields(self):
        """Test updating multiple fields at once."""
        mock_api_client = AsyncMock()
        mock_api_client.put.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "name": "Updated Campaign",
                "daily_limit": 200,
                "track_opens": False,
                "track_clicks": True
            },
            "message": "Campaign updated successfully"
        }

        updates = {
            "name": "Updated Campaign",
            "daily_limit": 200,
            "track_opens": False,
            "track_clicks": True,
            "enable_replies": True
        }

        with patch('coldsend_mcp.tools.campaign_updates.create_api_client', return_value=mock_api_client):
            result = await update_campaign(
                campaign_id="550e8400-e29b-41d4-a716-446655440000",
                updates=updates,
            )

        # Should filter out None values but keep all provided values
        call_args = mock_api_client.put.call_args[0][1]
        assert len(call_args) == 5  # All 5 fields should be present

        mock_api_client.put.assert_called_once_with(
            "/campaigns/550e8400-e29b-41d4-a716-446655440000",
            call_args
        )

    @pytest.mark.asyncio
    async def test_update_campaign_empty_updates(self):
        """Test that empty updates raises error."""
        with pytest.raises(ValueError, match="No valid updates provided"):
            await update_campaign(
                campaign_id="550e8400-e29b-41d4-a716-446655440000",
                updates={},
            )

    @pytest.mark.asyncio
    async def test_activate_campaign_from_paused(self):
        """Test activating a paused campaign."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "ACTIVE",
                "name": "Q1 Outreach"
            },
            "message": "Campaign activated successfully"
        }

        with patch('coldsend_mcp.tools.campaign_updates.create_api_client', return_value=mock_api_client):
            result = await activate_campaign(
                campaign_id="550e8400-e29b-41d4-a716-446655440000",
            )

        assert result["campaign"]["status"] == "ACTIVE"
        mock_api_client.post.assert_called_once_with(
            "/campaigns/550e8400-e29b-41d4-a716-446655440000/activate"
        )

    @pytest.mark.asyncio
    async def test_resume_campaign(self):
        """Test resuming a paused campaign (alias for activate)."""
        mock_api_client = AsyncMock()
        mock_api_client.post.return_value = {
            "campaign": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "ACTIVE",
                "launched_at": "2025-01-15T10:00:00Z"
            },
            "message": "Campaign resumed successfully"
        }

        with patch('coldsend_mcp.tools.campaign_updates.create_api_client', return_value=mock_api_client):
            result = await activate_campaign(
                campaign_id="550e8400-e29b-41d4-a716-446655440000",
            )

        assert result["campaign"]["status"] == "ACTIVE"
        assert result["message"] == "Campaign resumed successfully"
        mock_api_client.post.assert_called_once_with(
            "/campaigns/550e8400-e29b-41d4-a716-446655440000/activate"
        )
