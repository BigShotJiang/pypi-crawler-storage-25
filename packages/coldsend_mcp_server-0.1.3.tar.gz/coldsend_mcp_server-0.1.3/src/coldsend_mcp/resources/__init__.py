"""
Resources for ColdSend MCP Server.

Exposes read-only data resources that AI assistants can access for context.
"""

from mcp.server.fastmcp import FastMCP
import structlog

from ..auth import create_api_client

logger = structlog.get_logger(__name__)

# Initialize MCP server for resources
mcp = FastMCP()


@mcp.resource("campaign://{campaign_id}/status")
async def get_campaign_status(campaign_id: str) -> str:
    """
    Real-time campaign status (read-only resource).
    
    This resource provides the current status of a campaign without
    modifying any data. Useful for AI assistants to check state before
    taking actions.
    
    ## Resource URI Format
    
    ```
    campaign://{campaign_id}/status
    ```
    
    ## Example Usage in Claude Desktop
    
    ```
    Read the status of campaign 550e8400-e29b-41d4-a716-446655440000
    ```
    
    Args:
        campaign_id: Campaign UUID from the URI
    
    Returns:
        Plain text status report
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(f"/campaigns/{campaign_id}")
        
        campaign = response.get("campaign", {})
        status_text = f"""
Campaign: {campaign.get('name', 'Unknown')}
Status: {campaign.get('status', 'UNKNOWN')}
Created: {campaign.get('created_at', 'N/A')}
Launched: {campaign.get('launched_at', 'Not yet launched') or 'Not yet launched'}

Progress:
- Total Leads: {campaign.get('total_leads', 0)}
- Sent: {campaign.get('sent_count', 0)}
- Replied: {campaign.get('reply_count', 0)}
- Bounced: {campaign.get('bounce_count', 0)}

Daily Limit: {campaign.get('daily_limit', 0)} emails/day
        """.strip()
        
        logger.debug(
            "Campaign status resource accessed",
            campaign_id=campaign_id,
            status=campaign.get('status')
        )
        
        return status_text
        
    except Exception as e:
        logger.error("Failed to get campaign status", error=str(e))
        return f"Error retrieving campaign status: {str(e)}"


@mcp.resource("account://limits")
async def get_account_limits() -> str:
    """
    Current account sending limits and quota (read-only resource).
    
    Provides information about your account's sending capacity and
    current usage.
    
    ## Resource URI Format
    
    ```
    account://limits
    ```
    
    ## Example Usage
    
    ```
    Check my account limits before uploading more leads
    ```
    
    Returns:
        Plain text report of account limits and usage
    """
    try:
        api_client = create_api_client()
        response = await api_client.get("/metrics/account")
        
        limits_text = f"""
Account Sending Limits
======================

Daily Quota:
- Limit: {response.get('daily_limit', 'N/A')} emails/day
- Sent Today: {response.get('daily_sent', 0)}
- Remaining: {response.get('remaining_daily', 'N/A')}

Monthly Quota:
- Limit: {response.get('monthly_limit', 'N/A')} emails/month
- Sent This Month: {response.get('monthly_sent', 0)}
- Remaining: {response.get('remaining_monthly', 'N/A')}

Account Status:
- Plan: {response.get('plan_name', 'Unknown')}
- Active Campaigns: {response.get('active_campaigns', 0)}
- Connected Inboxes: {response.get('total_inboxes', 0)}
- Health Score: {response.get('health_score', 'N/A')}/100

Recommendation:
{f"You can send {response.get('remaining_daily', 0)} more emails today." if response.get('remaining_daily') else "You've reached your daily limit. Consider upgrading your plan."}
        """.strip()
        
        logger.info(
            "Account limits resource accessed",
            daily_remaining=response.get('remaining_daily', 0)
        )
        
        return limits_text
        
    except Exception as e:
        logger.error("Failed to get account limits", error=str(e))
        return f"Error retrieving account limits: {str(e)}"


@mcp.resource("campaign://{campaign_id}/leads/summary")
async def get_campaign_leads_summary(campaign_id: str) -> str:
    """
    Summary of leads in a campaign (read-only resource).
    
    Provides a high-level overview of lead statistics without
    individual lead details.
    
    ## Resource URI Format
    
    ```
    campaign://{campaign_id}/leads/summary
    ```
    
    Args:
        campaign_id: Campaign UUID
    
    Returns:
        Plain text summary of lead statistics
    """
    try:
        api_client = create_api_client()
        stats_response = await api_client.get(f"/campaigns/{campaign_id}/leads/stats")
        
        stats = stats_response.get("stats", {})
        total = stats_response.get("total", 0)
        
        summary_text = f"""
Leads Summary for Campaign
==========================

Total Leads: {total}

Status Breakdown:
- Pending: {stats.get('pending_count', 0)} ({stats.get('pending_percent', 0):.1f}%)
- Sent: {stats.get('sent_count', 0)} ({stats.get('sent_percent', 0):.1f}%)
- Opened: {stats.get('opened_count', 0)} ({stats.get('opened_percent', 0):.1f}%)
- Replied: {stats.get('replied_count', 0)} ({stats.get('replied_percent', 0):.1f}%)
- Bounced: {stats.get('bounced_count', 0)} ({stats.get('bounced_percent', 0):.1f}%)
- Unsubscribed: {stats.get('unsubscribed_count', 0)} ({stats.get('unsubscribed_percent', 0):.1f}%)

Performance Metrics:
- Open Rate: {stats.get('open_rate', 0):.1f}%
- Reply Rate: {stats.get('reply_rate', 0):.1f}%
- Bounce Rate: {stats.get('bounce_rate', 0):.1f}%
        """.strip()
        
        logger.debug(
            "Campaign leads summary accessed",
            campaign_id=campaign_id,
            total_leads=total
        )
        
        return summary_text
        
    except Exception as e:
        logger.error("Failed to get leads summary", error=str(e))
        return f"Error retrieving leads summary: {str(e)}"
