"""
Prompt templates for ColdSend MCP Server.

Provides guided workflows and reusable prompt templates for common tasks.
"""

from mcp.server.fastmcp import FastMCP

# Initialize MCP server for prompts
mcp = FastMCP()


@mcp.prompt()
def campaign_performance_review(campaign_id: str):
    """
    Analyze campaign performance and suggest improvements.
    
    Use this prompt template to guide users through performance analysis.
    
    ## Workflow
    
    1. Fetch campaign analytics
    2. Compare against industry benchmarks
    3. Identify underperforming areas
    4. Suggest specific optimizations
    5. Offer to implement changes
    
    Args:
        campaign_id: Campaign to analyze
    
    Returns:
        Guided prompt template
    """
    return f"""
I'll help you analyze the performance of your campaign and provide actionable recommendations.

Here's what I'll do:

**Step 1: Performance Overview**
Let me fetch the analytics for your campaign...

**Step 2: Benchmark Comparison**
I'll compare your metrics against industry averages:
- Average open rate: ~20-25%
- Average reply rate: ~2-5%
- Average bounce rate: <2%

**Step 3: Identify Issues**
I'll look for:
- Low open rates (subject line problems)
- Low reply rates (messaging/offer issues)
- High bounce rates (list quality problems)
- High unsubscribe rates (targeting mismatch)

**Step 4: Recommendations**
Based on the analysis, I'll suggest specific improvements:
- A/B test subject lines
- Refine targeting criteria
- Improve email copy
- Optimize send times

**Step 5: Implementation**
I can help you implement these changes directly.

Shall I proceed with analyzing campaign {campaign_id}?
    """


@mcp.prompt()
def lead_import_assistance(csv_description: str = ""):
    """
    Help users properly format and import leads from CSV.
    
    Guide users through the lead import process with best practices.
    
    Args:
        csv_description: Optional description of the CSV file
    
    Returns:
        Guided prompt template
    """
    return f"""
I'll help you import leads into your campaign successfully.

**CSV Format Requirements:**

✅ Required Column:
- `email` - Recipient email address (required)

📋 Recommended Columns:
- `first_name` - For personalization
- `last_name` - For formal communication
- `company` - Company name
- `title` - Job title/role
- `linkedin_url` - LinkedIn profile

**Best Practices:**

1. **Data Quality**
   - Remove duplicates
   - Verify email formats
   - Clean invalid entries

2. **Personalization Fields**
   - Include at least first_name for better engagement
   - Add company/title for targeted messaging

3. **File Format**
   - UTF-8 encoding
   - Comma-separated values
   - Headers in first row

**Import Process:**

1. Upload your CSV file
2. Map columns to ColdSend fields (if needed)
3. Review validation results
4. Confirm import

What would you like help with?
- [ ] Formatting your CSV correctly
- [ ] Uploading leads to a campaign
- [ ] Mapping custom columns
- [ ] Cleaning your lead list
    """


@mcp.prompt()
def campaign_launch_checklist():
    """
    Pre-launch checklist to ensure campaign success.
    
    Guide users through a comprehensive pre-launch verification.
    
    Returns:
        Interactive checklist template
    """
    return """
Before launching your campaign, let's verify everything is ready:

## 📋 Pre-Launch Checklist

### ✅ Campaign Configuration
- [ ] Campaign name is clear and descriptive
- [ ] Daily sending limit is appropriate
- [ ] Start date/time is optimal for your audience
- [ ] Timezone is set correctly

### ✅ Lead List
- [ ] Minimum 50 leads uploaded (recommended)
- [ ] All leads validated (no syntax errors)
- [ ] Duplicates removed
- [ ] Unsubscribes filtered out

### ✅ Email Content
- [ ] Subject line tested (< 50 characters)
- [ ] Email body personalized with variables
- [ ] Call-to-action is clear
- [ ] Unsubscribe link included
- [ ] Links tracked and working

### ✅ Sender Inboxes
- [ ] At least 1 inbox connected
- [ ] Inbox health score > 80/100
- [ ] Domain authentication (DKIM/SPF) configured
- [ ] Daily limits set appropriately

### ✅ Testing
- [ ] Test email sent to yourself
- [ ] Links render correctly
- [ ] Personalization works (merge tags)
- [ ] Mobile-friendly formatting

### ⚠️ Compliance
- [ ] GDPR/CCPA compliance verified
- [ ] Recipients opted in or legitimate interest
- [ ] Physical address included (CAN-SPAM)
- [ ] Clear opt-out mechanism

---

**Ready to launch?** I can help you:
1. Review each item in detail
2. Fix any issues found
3. Send test emails
4. Launch the campaign

Which would you like to start with?
    """


@mcp.prompt()
def troubleshoot_low_engagement():
    """
    Diagnose and fix low engagement rates.
    
    Systematic approach to improving campaign performance.
    
    Returns:
        Diagnostic workflow template
    """
    return """
Let's diagnose why your campaign isn't getting the engagement you want.

## 🔍 Diagnostic Questions

Please tell me:

1. **What are your current metrics?**
   - Open rate: ___%
   - Reply rate: ___%
   - Click rate: ___%

2. **What's your industry?**
   - Tech/SaaS
   - Marketing/Agency
   - Finance
   - Healthcare
   - E-commerce
   - Other: ___

3. **Who's your target audience?**
   - C-level executives
   - Managers
   - Individual contributors
   - Mixed

4. **What's your offer/value proposition?**
   - Product demo
   - Free consultation
   - Content/resource
   - Partnership opportunity
   - Other: ___

## 📊 Common Issues & Solutions

**Low Open Rates (< 20%)**
→ Weak subject lines
→ Poor sender reputation
→ Wrong send times
→ Spam folder placement

**Low Reply Rates (< 2%)**
→ Unclear value proposition
→ Weak call-to-action
→ Generic messaging
→ Wrong targeting

**High Bounce Rates (> 2%)**
→ Poor list quality
→ Outdated contact info
→ Invalid email addresses

**High Unsubscribes**
→ Over-promising
→ Irrelevant content
→ Too frequent emails

Once you share your metrics, I'll provide specific recommendations!
    """
