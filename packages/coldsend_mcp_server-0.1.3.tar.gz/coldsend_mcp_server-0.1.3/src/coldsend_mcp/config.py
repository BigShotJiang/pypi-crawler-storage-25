"""
Configuration and settings for ColdSend MCP Server.
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """MCP Server configuration."""
    
    # Environment
    environment: str = "development"
    debug: bool = False
    
    # Server config
    mcp_host: str = "0.0.0.0"
    mcp_port: int = 8080
    
    # ColdSend API configuration
    coldsend_api_url: str = "https://api.coldsend.pro/api/public/v1"
    coldsend_api_timeout: int = 30  # seconds
    
    # Authentication
    api_key_hash_secret: Optional[str] = None
    jwt_secret_key: Optional[str] = None  # Fallback for API key hashing
    
    # OAuth 2.1 configuration (Phase 2)
    oauth_client_id: Optional[str] = None
    oauth_client_secret: Optional[str] = None
    oauth_redirect_uri: Optional[str] = None
    oauth_issuer_url: Optional[str] = None
    
    # Rate limiting
    rate_limit_requests: int = 100  # per minute
    rate_limit_window: int = 60  # seconds
    
    # Logging
    log_level: str = "INFO"
    enable_structlog: bool = True
    
    # Health check
    health_check_enabled: bool = True
    
    class Config:
        env_file = ".env"
        case_sensitive = False


def get_settings() -> Settings:
    """Get settings instance."""
    return Settings()
