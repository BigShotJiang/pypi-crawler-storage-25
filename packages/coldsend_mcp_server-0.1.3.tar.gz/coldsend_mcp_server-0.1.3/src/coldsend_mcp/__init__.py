"""
ColdSend MCP Server - AI-Native Email Campaign Management

Model Context Protocol (MCP) server that wraps ColdSend's public APIs
to enable AI assistants like Claude and Cursor to manage email campaigns.
"""

__version__ = "0.1.3"
