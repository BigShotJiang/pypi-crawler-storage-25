"""
Lead management tools for ColdSend MCP Server.

Exposes lead import, export, and management operations as MCP tools.
"""

import json
from typing import Annotated, Optional, List
from pydantic import BaseModel, Field

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

import structlog
import httpx

from ..auth import create_api_client
from ..config import get_settings

settings = get_settings()

logger = structlog.get_logger(__name__)

# Initialize MCP tools router
mcp = FastMCP()


class LeadUploadRequest(BaseModel):
    """Request schema for uploading leads."""
    campaign_id: str = Field(..., description="Campaign ID to upload leads to")
    csv_content: str = Field(..., description="CSV content as string")
    mapping: dict = Field(
        default=None,
        description="Column mapping (email, first_name, last_name, company, etc.)"
    )


@mcp.tool(
    name="leads.upload",
    title="Upload Leads CSV",
    annotations=ToolAnnotations(
        title="Upload Leads CSV",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def upload_leads_csv(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign to upload leads to")],
    csv_content: Annotated[str, Field(description="CSV data as a string with headers in the first row; email column is required")],
    mapping: Annotated[Optional[dict], Field(description="Optional column mapping dictionary, e.g. {'email_address': 'email', 'fname': 'first_name'}")] = None,
) -> dict:
    """
    Upload leads from CSV to a campaign.
    
    Import recipient emails and metadata into a campaign for outreach.
    
    ## CSV Format Requirements
    
    - First row must be headers
    - Required column: `email`
    - Optional columns: `first_name`, `last_name`, `company`, `title`, etc.
    - Supports custom columns for personalization
    
    ## Column Mapping
    
    If your CSV headers don't match ColdSend's expected format, provide
    a mapping dictionary:
    ```python
    mapping = {
        "email_address": "email",  # Map 'email_address' column to 'email' field
        "fname": "first_name",
        "lname": "last_name"
    }
    ```
    
    Args:
        campaign_id: Target campaign UUID
        csv_content: CSV data as string (not file path)
        mapping: Optional column mapping dictionary
    
    Returns:
        Upload results including:
            - Total rows processed
            - Valid leads created
            - Invalid/skipped rows
            - Error details if any
    
    Example:
        ```python
        csv_data = \"\"\"email,first_name,last_name,company
        john@example.com,John,Doe,Acme Inc
        jane@example.com,Jane,Smith,Tech Corp\"\"\"
        
        result = await upload_leads_csv(
            campaign_id="550e8400-e29b-41d4-a716-446655440000",
            csv_content=csv_data,
            mapping=None
        )
        print(f"Uploaded {result['total_valid']} leads")
        ```
    """
    try:
        # Prepare multipart form data
        import io
        from httpx import AsyncClient
        
        # Create file-like object from CSV string
        api_client = create_api_client()
        csv_file = io.BytesIO(csv_content.encode('utf-8'))
        files = {
            'file': ('leads.csv', csv_file, 'text/csv')
        }
        
        data = {}
        if mapping:
            data['mapping'] = json.dumps(mapping)
        
        async with AsyncClient(base_url=settings.coldsend_api_url, timeout=60) as client:
            # Note: We need to handle file upload differently
            # For now, use the API client with raw request
            response = await api_client.client.post(
                f"/campaigns/{campaign_id}/leads/upload",
                files=files,
                data=data
            )
            
            result = response.json()
        
        logger.info(
            "Leads uploaded via MCP",
            campaign_id=campaign_id,
            total_rows=result.get("total_rows", 0),
            valid_rows=result.get("total_valid", 0)
        )
        
        return result
        
    except Exception as e:
        logger.error("Failed to upload leads", error=str(e))
        raise


@mcp.tool(
    name="leads.list",
    title="List Leads",
    annotations=ToolAnnotations(
        title="List Leads",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def list_leads(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign whose leads to list")],
    page: Annotated[int, Field(ge=1, description="Page number (1-based indexing)")] = 1,
    limit: Annotated[int, Field(ge=1, le=100, description="Number of results per page (1-100)")] = 20,
    status_filter: Annotated[Optional[str], Field(description="Filter by lead status: PENDING, SENT, REPLIED, BOUNCED")] = None,
) -> dict:
    """
    List all leads in a campaign.
    
    Retrieve leads with pagination and optional filtering by status.
    
    Args:
        campaign_id: Campaign UUID
        page: Page number (1-based)
        limit: Number of results per page (1-100)
        status_filter: Filter by lead status
            - PENDING: Not yet sent
            - SENT: Email sent
            - REPLIED: Lead replied
            - BOUNCED: Email bounced
    
    Returns:
        List of leads with pagination metadata
    
    Example:
        ```python
        # Get all pending leads
        result = await list_leads(
            campaign_id="550e8400-e29b-41d4-a716-446655440000",
            status_filter="PENDING"
        )
        ```
    """
    try:
        api_client = create_api_client()
        params = {
            "page": page,
            "limit": limit,
        }
        
        if status_filter:
            params["status"] = status_filter
        
        response = await api_client.get(f"/campaigns/{campaign_id}/leads", params=params)
        
        logger.debug(
            "Listed leads via MCP",
            campaign_id=campaign_id,
            page=page,
            limit=limit
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to list leads", error=str(e))
        raise


@mcp.tool(
    name="leads.delete",
    title="Delete Lead",
    annotations=ToolAnnotations(
        title="Delete Lead",
        readOnlyHint=False,
        destructiveHint=True,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def delete_lead(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign containing the lead")],
    lead_id: Annotated[str, Field(description="The UUID of the lead to delete from the campaign")],
) -> dict:
    """
    Delete a lead from a campaign.
    
    Remove a specific lead from the campaign. This is useful for
    cleaning up invalid leads or respecting unsubscribe requests.
    
    Args:
        campaign_id: Campaign UUID
        lead_id: Lead UUID to delete
    
    Returns:
        Confirmation message
    
    Example:
        ```python
        result = await delete_lead(
            campaign_id="550e8400-e29b-41d4-a716-446655440000",
            lead_id="123e4567-e89b-12d3-a456-426614174000"
        )
        print(result['message'])
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.delete(
            f"/campaigns/{campaign_id}/leads/{lead_id}"
        )
        
        logger.info(
            "Lead deleted via MCP",
            campaign_id=campaign_id,
            lead_id=lead_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to delete lead", error=str(e))
        raise


@mcp.tool(
    name="leads.stats",
    title="Get Lead Stats",
    annotations=ToolAnnotations(
        title="Get Lead Stats",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_lead_stats(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign to get lead statistics for")],
) -> dict:
    """
    Get aggregate statistics about leads in a campaign.
    
    Returns counts and percentages for each lead status.
    
    Args:
        campaign_id: Campaign UUID
    
    Returns:
        Lead statistics including:
            - Total leads
            - Count by status (pending, sent, replied, bounced)
            - Reply rate percentage
            - Bounce rate percentage
    
    Example:
        ```python
        stats = await get_lead_stats("550e8400-e29b-41d4-a716-446655440000")
        print(f"Reply rate: {stats['reply_rate']}%")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(f"/campaigns/{campaign_id}/leads/stats")
        
        logger.debug(
            "Retrieved lead stats via MCP",
            campaign_id=campaign_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get lead stats", error=str(e))
        raise
