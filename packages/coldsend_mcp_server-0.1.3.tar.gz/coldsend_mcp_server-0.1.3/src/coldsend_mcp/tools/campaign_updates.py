"""
Campaign update and activation tools for ColdSend MCP Server.

Completes campaign management with update and activate functionality.
"""

from datetime import datetime
from typing import Annotated, Optional, List
from pydantic import BaseModel, Field

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

import structlog

from ..auth import create_api_client

logger = structlog.get_logger(__name__)

# Initialize MCP tools router
mcp = FastMCP()


class CampaignUpdateRequest(BaseModel):
    """Request schema for updating campaign configuration."""
    name: Optional[str] = Field(None, description="Campaign name")
    schedule_send_at: Optional[datetime] = Field(None, description="When to start sending")
    daily_limit: Optional[int] = Field(None, ge=1, le=1000, description="Max emails per day")
    enable_replies: Optional[bool] = Field(None, description="Process replies")
    track_opens: Optional[bool] = Field(None, description="Track opens")
    track_clicks: Optional[bool] = Field(None, description="Track clicks")


@mcp.tool(
    name="campaigns.update",
    title="Update Campaign",
    annotations=ToolAnnotations(
        title="Update Campaign",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def update_campaign(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign to update")],
    updates: Annotated[dict, Field(description="Dictionary of fields to update: name, schedule_send_at, daily_limit, enable_replies, track_opens, track_clicks")],
) -> dict:
    """
    Update campaign configuration.
    
    Modify campaign settings after creation. You can update basic information,
    scheduling, limits, and tracking preferences.
    
    ## What Can Be Updated
    
    **Basic Settings:**
    - Campaign name
    - Daily sending limit
    - Start schedule
    
    **Tracking Options:**
    - Enable/disable open tracking
    - Enable/disable click tracking
    - Enable/disable reply processing
    
    **Advanced (Future):**
    - Email variants for A/B testing
    - Follow-up sequence configuration
    - Lead mapping rules
    
    ## Important Notes
    
    - Some changes may not be allowed if campaign is already ACTIVE
    - Changes take effect immediately
    - Already sent emails are not affected
    
    Args:
        campaign_id: Campaign UUID to update
        updates: Dictionary of fields to update. Valid keys:
            - name: New campaign name
            - schedule_send_at: New start time (ISO 8601)
            - daily_limit: New daily limit (1-1000)
            - enable_replies: True/False for reply processing
            - track_opens: True/False for open tracking
            - track_clicks: True/False for click tracking
    
    Returns:
        Updated campaign details with confirmation
    
    Example:
        ```python
        # Update campaign name and daily limit
        result = await update_campaign(
            campaign_id="550e8400-e29b-41d4-a716-446655440000",
            updates={
                "name": "Q1 Outreach - Updated",
                "daily_limit": 150
            }
        )
        
        # Update tracking options
        result = await update_campaign(
            campaign_id="550e8400-e29b-41d4-a716-446655440000",
            updates={
                "track_opens": False,
                "track_clicks": True
            }
        )
        ```
    """
    try:
        # Filter out None values
        clean_updates = {k: v for k, v in updates.items() if v is not None}
        
        if not clean_updates:
            raise ValueError("No valid updates provided")
        
        api_client = create_api_client()
        response = await api_client.put(
            f"/campaigns/{campaign_id}",
            clean_updates
        )
        
        logger.info(
            "Campaign updated via MCP",
            campaign_id=campaign_id,
            updates=list(clean_updates.keys())
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to update campaign", error=str(e))
        raise


@mcp.tool(
    name="campaigns.activate",
    title="Activate Campaign",
    annotations=ToolAnnotations(
        title="Activate Campaign",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def activate_campaign(
    campaign_id: Annotated[str, Field(description="The UUID of the draft or paused campaign to activate")],
) -> dict:
    """
    Activate or resume a campaign.
    
    Resume a paused campaign to continue sending emails, or activate
    a draft campaign that's ready to start.
    
    ## When to Use
    
    **Resume Paused Campaign:**
    - Campaign was previously paused
    - Ready to restart sending
    - All configuration is preserved
    
    **Activate Draft Campaign:**
    - Campaign setup is complete
    - Leads have been uploaded
    - Ready to start sending
    
    ## Prerequisites
    
    - Campaign must be in PAUSED or DRAFT status
    - Campaign must have at least one lead uploaded
    - Campaign must have sender inboxes configured
    
    ## What Happens
    
    - Status changes to ACTIVE
    - Email sending begins/resumes
    - Daily limit enforcement starts
    - Analytics tracking continues
    
    Args:
        campaign_id: Campaign UUID to activate
    
    Returns:
        Activation confirmation with new status and timestamp
    
    Example:
        ```python
        # Resume a paused campaign
        result = await activate_campaign(
            campaign_id="550e8400-e29b-41d4-a716-446655440000"
        )
        print(f"Campaign activated: {result['status']}")
        
        # Check current status first
        campaign = await get_campaign(campaign_id)
        if campaign['campaign']['status'] == 'PAUSED':
            await activate_campaign(campaign_id)
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.post(f"/campaigns/{campaign_id}/activate")
        
        logger.info(
            "Campaign activated via MCP",
            campaign_id=campaign_id,
            status=response.get("campaign", {}).get("status")
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to activate campaign", error=str(e))
        raise
