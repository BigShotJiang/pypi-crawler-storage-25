"""
Campaign management tools for ColdSend MCP Server.

Exposes campaign CRUD and lifecycle operations as MCP tools.
"""

from typing import Annotated, Optional
from pydantic import Field

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
import structlog

from ..auth import create_api_client

logger = structlog.get_logger(__name__)

# Initialize MCP tools router
mcp = FastMCP()


@mcp.tool(
    name="campaigns.create",
    title="Create Campaign",
    annotations=ToolAnnotations(
        title="Create Campaign",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def create_campaign(
    name: Annotated[str, Field(description="Campaign name")],
    schedule_send_at: Annotated[str, Field(description="When to start sending emails (ISO 8601 datetime string)")],
    daily_limit: Annotated[int, Field(ge=1, le=1000, description="Max emails per day")] = 50,
    enable_replies: Annotated[bool, Field(description="Whether to process reply emails")] = True,
    track_opens: Annotated[bool, Field(description="Track when recipients open emails")] = True,
    track_clicks: Annotated[bool, Field(description="Track when recipients click links")] = True,
) -> dict:
    """
    Create a new cold email campaign.
    
    This initializes a campaign with basic configuration. After creation,
    you'll need to:
    1. Upload leads (recipients)
    2. Configure sender inboxes
    3. Design email content
    4. Launch the campaign
    
    Args:
        name: Campaign name
        schedule_send_at: When to start sending (ISO 8601 format)
        daily_limit: Maximum emails to send per day (1-1000)
        enable_replies: Whether to process reply emails
        track_opens: Track when recipients open emails
        track_clicks: Track when recipients click links
    
    Returns:
        Created campaign details including ID and status
    
    Example:
        ```python
        result = await create_campaign(
            name="Q1 Outreach",
            schedule_send_at="2025-01-15T09:00:00Z",
            daily_limit=100
        )
        print(f"Created campaign: {result['campaign']['name']}")
        ```
    """
    try:
        api_client = create_api_client()
        config = {
            "name": name,
            "schedule_send_at": schedule_send_at,
            "daily_limit": daily_limit,
            "enable_replies": enable_replies,
            "track_opens": track_opens,
            "track_clicks": track_clicks,
        }
        response = await api_client.post(
            "/campaigns",
            config
        )
        
        logger.info(
            "Campaign created via MCP",
            campaign_id=response.get("campaign", {}).get("id"),
            campaign_name=name
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to create campaign", error=str(e))
        raise


@mcp.tool(
    name="campaigns.list",
    title="List Campaigns",
    annotations=ToolAnnotations(
        title="List Campaigns",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def list_campaigns(
    status_filter: Annotated[Optional[str], Field(description="Filter by status: DRAFT, ACTIVE, PAUSED, COMPLETED, FAILED")] = None,
    search: Annotated[Optional[str], Field(description="Search campaigns by name (case-insensitive partial match)")] = None,
    sort_by: Annotated[Optional[str], Field(description="Field to sort by: name, status, created_at, launched_at, sent_count, reply_count")] = "created_at",
    sort_order: Annotated[str, Field(description="Sort direction: asc or desc")] = "desc",
    page: Annotated[int, Field(ge=1, description="Page number (1-based indexing)")] = 1,
    limit: Annotated[int, Field(ge=1, le=100, description="Number of results per page (1-100)")] = 20,
) -> dict:
    """
    List all campaigns with filtering and pagination.
    
    Retrieve a paginated list of campaigns with optional filtering by status,
    search term, and sorting options.
    
    Args:
        status_filter: Filter by campaign status
            - DRAFT: Not yet launched
            - ACTIVE: Currently sending
            - PAUSED: Temporarily stopped
            - COMPLETED: Finished sending all emails
            - FAILED: Stopped due to errors
        search: Search campaigns by name (case-insensitive partial match)
        sort_by: Field to sort by (name, status, created_at, launched_at, sent_count, reply_count)
        sort_order: Sort direction (asc or desc)
        page: Page number (1-based indexing)
        limit: Number of results per page (1-100)
    
    Returns:
        List of campaigns with pagination metadata
    
    Example:
        ```python
        # Get all active campaigns
        result = await list_campaigns(status_filter="ACTIVE")
        
        # Search for campaigns with "Q1" in name
        result = await list_campaigns(search="Q1")
        ```
    """
    try:
        api_client = create_api_client()
        params = {
            "page": page,
            "limit": limit,
        }
        
        if status_filter:
            params["status"] = status_filter
        if search:
            params["search"] = search
        if sort_by:
            params["sort_by"] = sort_by
        if sort_order:
            params["sort_order"] = sort_order
        
        response = await api_client.get("/campaigns", params=params)
        
        logger.debug(
            "Listed campaigns via MCP",
            page=page,
            limit=limit,
            status_filter=status_filter
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to list campaigns", error=str(e))
        raise


@mcp.tool(
    name="campaigns.get",
    title="Get Campaign",
    annotations=ToolAnnotations(
        title="Get Campaign",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_campaign(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign to retrieve")],
) -> dict:
    """
    Get detailed information about a specific campaign.
    
    Args:
        campaign_id: The UUID of the campaign to retrieve
    
    Returns:
        Full campaign details including configuration, statistics, and status
    
    Example:
        ```python
        campaign = await get_campaign("550e8400-e29b-41d4-a716-446655440000")
        print(f"Campaign status: {campaign['campaign']['status']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(f"/campaigns/{campaign_id}")
        
        logger.debug(
            "Retrieved campaign via MCP",
            campaign_id=campaign_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get campaign", error=str(e))
        raise


@mcp.tool(
    name="campaigns.pause",
    title="Pause Campaign",
    annotations=ToolAnnotations(
        title="Pause Campaign",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def pause_campaign(
    campaign_id: Annotated[str, Field(description="The UUID of the active campaign to pause")],
) -> dict:
    """
    Pause an active campaign.
    
    Stops sending emails immediately. The campaign can be resumed later.
    
    Args:
        campaign_id: The UUID of the campaign to pause
    
    Returns:
        Updated campaign details with PAUSED status
    
    Example:
        ```python
        result = await pause_campaign("550e8400-e29b-41d4-a716-446655440000")
        print(f"Campaign paused: {result['message']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.post(f"/campaigns/{campaign_id}/pause")
        
        logger.info(
            "Campaign paused via MCP",
            campaign_id=campaign_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to pause campaign", error=str(e))
        raise


@mcp.tool(
    name="campaigns.resume",
    title="Resume Campaign",
    annotations=ToolAnnotations(
        title="Resume Campaign",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def resume_campaign(
    campaign_id: Annotated[str, Field(description="The UUID of the paused campaign to resume")],
) -> dict:
    """
    Resume a paused campaign.
    
    Restarts email sending from where it left off.
    
    Args:
        campaign_id: The UUID of the campaign to resume
    
    Returns:
        Updated campaign details with ACTIVE status
    
    Example:
        ```python
        result = await resume_campaign("550e8400-e29b-41d4-a716-446655440000")
        print(f"Campaign resumed: {result['message']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.post(f"/campaigns/{campaign_id}/resume")
        
        logger.info(
            "Campaign resumed via MCP",
            campaign_id=campaign_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to resume campaign", error=str(e))
        raise


@mcp.tool(
    name="campaigns.delete",
    title="Delete Campaign",
    annotations=ToolAnnotations(
        title="Delete Campaign",
        readOnlyHint=False,
        destructiveHint=True,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def delete_campaign(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign to permanently delete")],
) -> dict:
    """
    Delete a campaign permanently.
    
    ⚠️ WARNING: This action cannot be undone. All campaign data,
    including leads, emails, and analytics, will be permanently deleted.
    
    Args:
        campaign_id: The UUID of the campaign to delete
    
    Returns:
        Confirmation message
    
    Example:
        ```python
        result = await delete_campaign("550e8400-e29b-41d4-a716-446655440000")
        print(result['message'])
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.delete(f"/campaigns/{campaign_id}")
        
        logger.warning(
            "Campaign deleted via MCP",
            campaign_id=campaign_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to delete campaign", error=str(e))
        raise
