"""
Analytics and metrics tools for ColdSend MCP Server.

Exposes campaign analytics, account metrics, and reporting as MCP tools.
"""

from datetime import datetime
from typing import Annotated, Optional
from pydantic import BaseModel, Field

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

import structlog

from ..auth import create_api_client

logger = structlog.get_logger(__name__)

# Initialize MCP tools router
mcp = FastMCP()


@mcp.tool(
    name="analytics.campaign",
    title="Get Campaign Analytics",
    annotations=ToolAnnotations(
        title="Get Campaign Analytics",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_campaign_analytics(
    campaign_id: Annotated[str, Field(description="The UUID of the campaign to get analytics for")],
) -> dict:
    """
    Get comprehensive analytics for a campaign.
    
    Retrieve detailed performance metrics including delivery, engagement,
    and conversion statistics.
    
    ## Metrics Included:
    
    **Delivery Metrics:**
    - Sent count
    - Delivered count
    - Bounce count (hard + soft)
    - Bounce rate
    
    **Engagement Metrics:**
    - Open count
    - Open rate
    - Click count
    - Click-through rate (CTR)
    - Reply count
    - Reply rate
    
    **Conversion Metrics:**
    - Unsubscribe count
    - Unsubscribe rate
    - Marked as spam count
    
    **Timeline:**
    - First send time
    - Last send time
    - Completion percentage
    
    Args:
        campaign_id: Campaign UUID to get analytics for
    
    Returns:
        Comprehensive analytics object with all metrics
    
    Example:
        ```python
        analytics = await get_campaign_analytics(
            campaign_id="550e8400-e29b-41d4-a716-446655440000"
        )
        
        print(f"Open rate: {analytics['open_rate']}%")
        print(f"Reply rate: {analytics['reply_rate']}%")
        print(f"Bounce rate: {analytics['bounce_rate']}%")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(f"/campaigns/{campaign_id}/analytics")
        
        logger.info(
            "Campaign analytics retrieved via MCP",
            campaign_id=campaign_id,
            sent_count=response.get("sent_count", 0),
            open_rate=response.get("open_rate", 0)
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get campaign analytics", error=str(e))
        raise


@mcp.tool(
    name="analytics.account",
    title="Get Account Metrics",
    annotations=ToolAnnotations(
        title="Get Account Metrics",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_account_metrics(
) -> dict:
    """
    Get account-level metrics and usage statistics.
    
    Retrieve information about your account's sending capacity,
    current usage, and quota limits.
    
    ## Metrics Included:
    
    **Quota Information:**
    - Daily sending limit
    - Monthly sending limit
    - Current daily sent count
    - Current monthly sent count
    - Remaining daily quota
    - Remaining monthly quota
    
    **Account Status:**
    - Subscription plan
    - Active campaigns count
    - Total inboxes connected
    - Account health score
    
    **Usage Trends:**
    - Emails sent today
    - Emails sent this week
    - Emails sent this month
    - Average daily send rate
    
    Returns:
        Account metrics with quotas and usage
    
    Example:
        ```python
        metrics = await get_account_metrics()
        
        print(f"Daily quota: {metrics['daily_limit']}")
        print(f"Remaining today: {metrics['remaining_daily']}")
        print(f"Active campaigns: {metrics['active_campaigns']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get("/metrics/account")
        
        logger.info(
            "Account metrics retrieved via MCP",
            daily_sent=response.get("daily_sent", 0),
            monthly_sent=response.get("monthly_sent", 0)
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get account metrics", error=str(e))
        raise


@mcp.tool(
    name="analytics.inbox",
    title="Get Inbox Performance",
    annotations=ToolAnnotations(
        title="Get Inbox Performance",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_inbox_performance(
    inbox_id: Annotated[str, Field(description="The UUID of the inbox to analyze performance for")],
    days: Annotated[int, Field(ge=1, le=90, description="Number of days to include in the analysis (1-90)")] = 7,
) -> dict:
    """
    Get performance metrics for a specific inbox.
    
    Analyze how well an email inbox is performing across all campaigns.
    
    Args:
        inbox_id: Inbox UUID to analyze
        days: Number of days to include in analysis (1-90)
    
    Returns:
        Inbox performance metrics including:
            - Emails sent
            - Delivery rate
            - Open rate
            - Reply rate
            - Bounce rate
            - Spam complaint rate
            - Health score
    
    Example:
        ```python
        performance = await get_inbox_performance(
            inbox_id="123e4567-e89b-12d3-a456-426614174000",
            days=30
        )
        print(f"Inbox health score: {performance['health_score']}/100")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(
            f"/inboxes/{inbox_id}/performance",
            params={"days": days}
        )
        
        logger.info(
            "Inbox performance retrieved via MCP",
            inbox_id=inbox_id,
            days=days,
            health_score=response.get("health_score", 0)
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get inbox performance", error=str(e))
        raise


@mcp.tool(
    name="analytics.compare",
    title="Compare Campaigns",
    annotations=ToolAnnotations(
        title="Compare Campaigns",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def compare_campaigns(
    campaign_ids: Annotated[list[str], Field(description="List of 2-10 campaign UUIDs to compare side-by-side")],
) -> dict:
    """
    Compare analytics across multiple campaigns.
    
    Side-by-side comparison of campaign performance metrics.
    
    Args:
        campaign_ids: List of campaign UUIDs to compare (2-10 campaigns)
    
    Returns:
        Comparison data with metrics for each campaign
    
    Example:
        ```python
        comparison = await compare_campaigns([
            "550e8400-e29b-41d4-a716-446655440000",
            "660e8400-e29b-41d4-a716-446655440001"
        ])
        
        for campaign in comparison['campaigns']:
            print(f"{campaign['name']}: {campaign['reply_rate']}% reply rate")
        ```
    """
    try:
        if len(campaign_ids) < 2:
            raise ValueError("Must compare at least 2 campaigns")
        if len(campaign_ids) > 10:
            raise ValueError("Cannot compare more than 10 campaigns at once")
        
        # Get analytics for each campaign
        api_client = create_api_client()
        campaigns_data = []
        for campaign_id in campaign_ids:
            analytics = await api_client.get(f"/campaigns/{campaign_id}/analytics")
            campaigns_data.append(analytics)
        
        result = {
            "campaigns": campaigns_data,
            "comparison": {
                "avg_open_rate": sum(c.get("open_rate", 0) for c in campaigns_data) / len(campaigns_data),
                "avg_reply_rate": sum(c.get("reply_rate", 0) for c in campaigns_data) / len(campaigns_data),
                "avg_bounce_rate": sum(c.get("bounce_rate", 0) for c in campaigns_data) / len(campaigns_data),
            }
        }
        
        logger.info(
            "Campaigns compared via MCP",
            campaign_count=len(campaign_ids),
            avg_reply_rate=result["comparison"]["avg_reply_rate"]
        )
        
        return result
        
    except Exception as e:
        logger.error("Failed to compare campaigns", error=str(e))
        raise
