"""
Sender account management tools for ColdSend MCP Server.

Exposes inbox creation, management, and testing operations as MCP tools.
Supports all inbox types: ColdSend Native, SMTP (BYOC), Google Workspace, Outlook 365.
"""

from typing import Annotated, Optional, List
from pydantic import BaseModel, Field, EmailStr

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

import structlog

from ..auth import create_api_client

logger = structlog.get_logger(__name__)

# Initialize MCP tools router
mcp = FastMCP()


class ColdSendInboxCreateRequest(BaseModel):
    """Request for creating a ColdSend native inbox."""
    email_address: EmailStr = Field(..., description="Email address for the inbox")
    domain_id: str = Field(..., description="Domain ID to use")
    name: str = Field(default=None, description="Display name for sender")


class SMTPInboxCreateRequest(BaseModel):
    """Request for creating a custom SMTP inbox."""
    email_address: EmailStr = Field(..., description="Email address")
    smtp_host: str = Field(..., description="SMTP server hostname")
    smtp_port: int = Field(587, ge=1, le=65535, description="SMTP port")
    smtp_username: str = Field(..., description="SMTP username")
    smtp_password: str = Field(..., description="SMTP password or app password")
    smtp_security: str = Field("STARTTLS", description="Security type: STARTTLS, SSL_TLS, or NONE")
    name: str = Field(default=None, description="Display name for sender")


@mcp.tool(
    name="sender.list",
    title="List Sender Accounts",
    annotations=ToolAnnotations(
        title="List Sender Accounts",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def list_sender_accounts(
    page: Annotated[int, Field(ge=1, description="Page number (1-based indexing)")] = 1,
    limit: Annotated[int, Field(ge=1, le=100, description="Number of results per page (1-100)")] = 20,
    inbox_type: Annotated[Optional[str], Field(description="Filter by inbox type: COLDSEND, GOOGLE_WORKSPACE, OUTLOOK_365, CUSTOM_SMTP")] = None,
    status: Annotated[Optional[str], Field(description="Filter by status: ACTIVE, PAUSED, DISABLED")] = None,
    search: Annotated[Optional[str], Field(description="Search by email address (partial match)")] = None,
) -> dict:
    """
    List all sender accounts (inboxes) in your workspace.
    
    Retrieve a paginated list of configured sender email accounts.
    
    Args:
        page: Page number (1-based)
        limit: Items per page (1-100)
        inbox_type: Filter by inbox type
            - COLDSEND: ColdSend native inboxes
            - GOOGLE_WORKSPACE: Google Workspace/Gmail
            - OUTLOOK_365: Microsoft Outlook/Office 365
            - CUSTOM_SMTP: Custom SMTP servers
        status: Filter by status
            - ACTIVE: Sending normally
            - PAUSED: Temporarily stopped
            - DISABLED: Permanently disabled
        search: Search by email address (partial match)
    
    Returns:
        List of sender accounts with details:
            - Email address and display name
            - Inbox type and provider
            - Status and health score
            - Daily/monthly sending stats
            - Domain information
    
    Example:
        ```python
        # List all active ColdSend inboxes
        result = await list_sender_accounts(
            inbox_type="COLDSEND",
            status="ACTIVE"
        )
        ```
    """
    try:
        api_client = create_api_client()
        params = {
            "page": page,
            "limit": limit,
        }
        
        if inbox_type:
            params["inbox_type"] = inbox_type
        if status:
            params["status"] = status
        if search:
            params["search"] = search
        
        response = await api_client.get("/sender-accounts", params=params)
        
        logger.debug(
            "Listed sender accounts via MCP",
            page=page,
            limit=limit,
            count=len(response.get("sender_accounts", []))
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to list sender accounts", error=str(e))
        raise


@mcp.tool(
    name="sender.create_coldsend",
    title="Create ColdSend Inbox",
    annotations=ToolAnnotations(
        title="Create ColdSend Inbox",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def create_coldsend_inbox(
    email_address: Annotated[str, Field(description="Email address for the new inbox, e.g. 'john@example.com'")],
    domain_id: Annotated[str, Field(description="The UUID of the verified domain to use for this inbox")],
    name: Annotated[Optional[str], Field(description="Optional display name for the sender, e.g. 'John Doe'")] = None,
) -> dict:
    """
    Create a new ColdSend native inbox.
    
    ColdSend manages the email infrastructure automatically.
    Best for high-volume sending with minimal setup.
    
    ## What You Get
    
    - Automatically configured email account
    - High deliverability optimization
    - Warm-up automation included
    - Dedicated IP (on higher plans)
    
    ## Requirements
    
    - Domain must be verified and active
    - Domain must have completed DNS verification
    - Account must have available inbox quota
    
    Args:
        email_address: Email address to create (e.g., john@example.com)
        domain_id: Verified domain UUID to use
        name: Optional display name for sender
    
    Returns:
        Created inbox details including:
            - Inbox ID and email address
            - Initial status
            - Configuration details
            - Next steps for activation
    
    Example:
        ```python
        result = await create_coldsend_inbox(
            email_address="john@example.com",
            domain_id="550e8400-e29b-41d4-a716-446655440000",
            name="John Doe"
        )
        print(f"Inbox created: {result['inbox']['email_address']}")
        ```
    """
    try:
        api_client = create_api_client()
        config = {
            "email_address": email_address,
            "domain_id": domain_id,
            "name": name
        }
        response = await api_client.post("/sender-accounts/coldsend", config)
        
        logger.info(
            "ColdSend inbox created via MCP",
            email_address=email_address,
            inbox_id=response.get("inbox", {}).get("id")
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to create ColdSend inbox", error=str(e))
        raise


@mcp.tool(
    name="sender.create_smtp",
    title="Create SMTP Inbox",
    annotations=ToolAnnotations(
        title="Create SMTP Inbox",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def create_smtp_inbox(
    email_address: Annotated[str, Field(description="Email address for this SMTP inbox")],
    smtp_host: Annotated[str, Field(description="SMTP server hostname, e.g. 'smtp.gmail.com'")],
    smtp_port: Annotated[int, Field(description="SMTP port number (common: 587 for STARTTLS, 465 for SSL)")] = 587,
    smtp_username: Annotated[Optional[str], Field(description="SMTP username, often the full email address")] = None,
    smtp_password: Annotated[Optional[str], Field(description="SMTP password or app-specific password")] = None,
    smtp_security: Annotated[str, Field(description="Security type: STARTTLS, SSL_TLS, or NONE")] = "STARTTLS",
    name: Annotated[Optional[str], Field(description="Optional display name for the sender")] = None,
) -> dict:
    """
    Create a custom SMTP inbox (Bring Your Own Cloud).
    
    Connect your existing email infrastructure to ColdSend.
    Supports Gmail, Outlook 365, Amazon SES, SendGrid, etc.
    
    ## Security Types
    
    - **STARTTLS** (recommended): Upgrades plain connection to encrypted
    - **SSL_TLS**: Implicit SSL/TLS from connection start
    - **NONE**: No encryption (not recommended)
    
    ## Common SMTP Settings
    
    **Gmail:**
    - Host: smtp.gmail.com
    - Port: 587 (STARTTLS) or 465 (SSL)
    - Use App Password (not regular password)
    
    **Outlook 365:**
    - Host: smtp.office365.com
    - Port: 587 (STARTTLS)
    - Username: Full email address
    
    **Amazon SES:**
    - Host: email-smtp.[region].amazonaws.com
    - Port: 587 or 2587
    - Use SES SMTP credentials
    
    Args:
        email_address: Email address for this inbox
        smtp_host: SMTP server hostname
        smtp_port: SMTP port (default: 587)
        smtp_username: SMTP username (often full email)
        smtp_password: SMTP password or app password
        smtp_security: Security type (STARTTLS, SSL_TLS, NONE)
        name: Optional display name for sender
    
    Returns:
        Created inbox details including:
            - Inbox ID and configuration
            - Connection test results
            - Status and next steps
    
    Example:
        ```python
        result = await create_smtp_inbox(
            email_address="john@gmail.com",
            smtp_host="smtp.gmail.com",
            smtp_port=587,
            smtp_username="john@gmail.com",
            smtp_password="app-password-here",
            smtp_security="STARTTLS"
        )
        ```
    """
    try:
        api_client = create_api_client()
        config = {
            "email_address": email_address,
            "smtp_host": smtp_host,
            "smtp_port": smtp_port,
            "smtp_username": smtp_username or email_address,
            "smtp_password": smtp_password,
            "smtp_security": smtp_security,
            "name": name
        }
        response = await api_client.post("/sender-accounts/smtp", config)
        
        logger.info(
            "SMTP inbox created via MCP",
            email_address=email_address,
            inbox_id=response.get("inbox", {}).get("id")
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to create SMTP inbox", error=str(e))
        raise


@mcp.tool(
    name="sender.test",
    title="Send Test Email",
    annotations=ToolAnnotations(
        title="Send Test Email",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
        openWorldHint=True,
    ),
)
async def send_test_email(
    inbox_id: Annotated[str, Field(description="The UUID of the inbox to send the test email from")],
    to_email: Annotated[str, Field(description="Recipient email address for the test, e.g. your personal email")],
    subject: Annotated[str, Field(description="Email subject line for the test")] = "Test Email from ColdSend",
    body: Annotated[str, Field(description="Email body content for the test")] = "This is a test email to verify your inbox configuration.",
) -> dict:
    """
    Send a test email from an inbox.
    
    Verify that your inbox is properly configured and can send emails.
    
    ## Use Cases
    
    - Test new inbox configuration
    - Verify SMTP settings are correct
    - Check email deliverability
    - Confirm sender name and signature
    
    Args:
        inbox_id: Inbox UUID to test
        to_email: Recipient email address (can be your personal email)
        subject: Email subject line
        body: Email body content
    
    Returns:
        Test email result including:
            - Send status (success/failed)
            - Error details if failed
            - Timestamp and message ID
    
    Example:
        ```python
        result = await send_test_email(
            inbox_id="550e8400-e29b-41d4-a716-446655440000",
            to_email="your-personal@email.com",
            subject="Testing my ColdSend inbox"
        )
        print(f"Test email sent: {result['success']}")
        ```
    """
    try:
        api_client = create_api_client()
        test_config = {
            "to_email": to_email,
            "subject": subject,
            "body": body
        }
        response = await api_client.post(f"/sender-accounts/{inbox_id}/test", test_config)
        
        logger.info(
            "Test email sent via MCP",
            inbox_id=inbox_id,
            to_email=to_email,
            success=response.get("success", False)
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to send test email", error=str(e))
        raise


@mcp.tool(
    name="sender.pause",
    title="Pause Inbox",
    annotations=ToolAnnotations(
        title="Pause Inbox",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def pause_inbox(
    inbox_id: Annotated[str, Field(description="The UUID of the active inbox to pause")],
) -> dict:
    """
    Pause an inbox temporarily.
    
    Stops sending from this inbox while preserving configuration.
    Useful for:
    - Taking breaks from campaigns
    - Investigating deliverability issues
    - Reducing sending volume
    
    Paused inboxes:
    - Retain all configuration
    - Don't send any emails
    - Can be resumed anytime
    - Don't count against some quotas
    
    Args:
        inbox_id: Inbox UUID to pause
    
    Returns:
        Updated inbox status (PAUSED)
    
    Example:
        ```python
        result = await pause_inbox("550e8400-e29b-41d4-a716-446655440000")
        print(f"Inbox paused: {result['inbox']['status']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.post(f"/sender-accounts/{inbox_id}/pause")
        
        logger.info(
            "Inbox paused via MCP",
            inbox_id=inbox_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to pause inbox", error=str(e))
        raise


@mcp.tool(
    name="sender.resume",
    title="Resume Inbox",
    annotations=ToolAnnotations(
        title="Resume Inbox",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def resume_inbox(
    inbox_id: Annotated[str, Field(description="The UUID of the paused inbox to resume")],
) -> dict:
    """
    Resume a paused inbox.
    
    Restarts email sending from where it left off.
    
    After resuming:
    - Normal sending resumes
    - Daily limits reset
    - Campaigns continue from pause point
    
    Args:
        inbox_id: Inbox UUID to resume
    
    Returns:
        Updated inbox status (ACTIVE)
    
    Example:
        ```python
        result = await resume_inbox("550e8400-e29b-41d4-a716-446655440000")
        print(f"Inbox resumed: {result['inbox']['status']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.post(f"/sender-accounts/{inbox_id}/resume")
        
        logger.info(
            "Inbox resumed via MCP",
            inbox_id=inbox_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to resume inbox", error=str(e))
        raise


@mcp.tool(
    name="sender.delete",
    title="Delete Inbox",
    annotations=ToolAnnotations(
        title="Delete Inbox",
        readOnlyHint=False,
        destructiveHint=True,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def delete_inbox(
    inbox_id: Annotated[str, Field(description="The UUID of the inbox to permanently delete")],
) -> dict:
    """
    Delete an inbox permanently.
    
    ⚠️ WARNING: This action cannot be undone.
    
    Prerequisites:
    - No active campaigns using this inbox
    - All scheduled emails must be cancelled
    
    After deletion:
    - Inbox configuration removed
    - Sending history preserved in analytics
    - Cannot reuse email address immediately
    
    Args:
        inbox_id: Inbox UUID to delete
    
    Returns:
        Deletion confirmation
    
    Example:
        ```python
        result = await delete_inbox("550e8400-e29b-41d4-a716-446655440000")
        print(result['message'])
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.delete(f"/sender-accounts/{inbox_id}")
        
        logger.warning(
            "Inbox deleted via MCP",
            inbox_id=inbox_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to delete inbox", error=str(e))
        raise


@mcp.tool(
    name="sender.health",
    title="Get Inbox Health",
    annotations=ToolAnnotations(
        title="Get Inbox Health",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_inbox_health(
    inbox_id: Annotated[str, Field(description="The UUID of the inbox to analyze health for")],
    days: Annotated[int, Field(ge=1, le=90, description="Number of days to include in the health analysis (1-90)")] = 7,
) -> dict:
    """
    Get detailed inbox health report.
    
    Comprehensive analysis of inbox performance and reputation.
    
    ## Health Metrics
    
    **Deliverability Score (0-100):**
    - Based on bounce rates, spam complaints, engagement
    - 80+ = Excellent, 60-79 = Good, <60 = Needs improvement
    
    **Sending Patterns:**
    - Daily/weekly volume trends
    - Consistency scoring
    - Peak performance times
    
    **Reputation Indicators:**
    - Bounce rate trends
    - Spam complaint rate
    - Engagement metrics (opens/replies)
    
    **Issues Detected:**
    - Authentication problems
    - Blacklist appearances
    - Throttling by providers
    
    Args:
        inbox_id: Inbox UUID to analyze
        days: Analysis period (1-90 days, default: 7)
    
    Returns:
        Health report including:
            - Overall health score (0-100)
            - Detailed metrics breakdown
            - Issues and recommendations
            - Historical trends
    
    Example:
        ```python
        health = await get_inbox_health(
            inbox_id="550e8400-e29b-41d4-a716-446655440000",
            days=30
        )
        print(f"Health score: {health['health_score']}/100")
        print(f"Status: {health['status']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(
            f"/sender-accounts/{inbox_id}/health",
            params={"days": days}
        )
        
        logger.info(
            "Retrieved inbox health via MCP",
            inbox_id=inbox_id,
            health_score=response.get("health", {}).get("health_score", 0)
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get inbox health", error=str(e))
        raise
