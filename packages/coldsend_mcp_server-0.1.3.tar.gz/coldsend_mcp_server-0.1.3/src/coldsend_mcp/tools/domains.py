"""
Domain management tools for ColdSend MCP Server.

Exposes domain DNS verification, status checking, and lifecycle operations as MCP tools.
"""

from typing import Annotated, Optional, List
from pydantic import BaseModel, Field

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

import structlog

from ..auth import create_api_client

logger = structlog.get_logger(__name__)

# Initialize MCP tools router
mcp = FastMCP()


class DomainCreateRequest(BaseModel):
    """Request schema for adding a domain."""
    domain_name: str = Field(..., description="Domain name to add (e.g., example.com)")
    use_nameservers: bool = Field(default=True, description="Whether to use ColdSend nameservers")


@mcp.tool(
    name="domains.list",
    title="List Domains",
    annotations=ToolAnnotations(
        title="List Domains",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def list_domains(
    page: Annotated[int, Field(ge=1, description="Page number (1-based indexing)")] = 1,
    limit: Annotated[int, Field(ge=1, le=100, description="Number of results per page (1-100)")] = 20,
) -> dict:
    """
    List all domains in your workspace.
    
    Retrieve a paginated list of configured domains with their verification status.
    
    Args:
        page: Page number (1-based)
        limit: Number of results per page (1-100)
    
    Returns:
        List of domains with status information including:
            - Domain name and ID
            - Verification status (verified, pending, failed)
            - DNS record status
            - Mailcow integration status
            - Cloudflare verification status
    
    Example:
        ```python
        result = await list_domains(page=1, limit=20)
        for domain in result['domains']:
            print(f"{domain['domain_name']}: {domain['status']}")
        ```
    """
    try:
        api_client = create_api_client()
        params = {"page": page, "limit": limit}
        response = await api_client.get("/domains", params=params)
        
        logger.debug(
            "Listed domains via MCP",
            page=page,
            limit=limit,
            count=len(response.get("domains", []))
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to list domains", error=str(e))
        raise


@mcp.tool(
    name="domains.get",
    title="Get Domain",
    annotations=ToolAnnotations(
        title="Get Domain",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_domain(
    domain_id: Annotated[str, Field(description="The UUID of the domain to retrieve details for")],
) -> dict:
    """
    Get detailed information about a specific domain.
    
    Includes DNS records, verification status, and configuration details.
    
    Args:
        domain_id: Domain UUID
    
    Returns:
        Full domain details including:
            - Basic info (name, status, created_at)
            - DNS records (MX, TXT, CNAME)
            - Verification status (Cloudflare, Mailcow)
            - Nameserver configuration
            - Inbox count and limits
    
    Example:
        ```python
        domain = await get_domain("550e8400-e29b-41d4-a716-446655440000")
        print(f"DNS Records: {domain['dns_records']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(f"/domains/{domain_id}")
        
        logger.info(
            "Retrieved domain via MCP",
            domain_id=domain_id,
            domain_name=response.get("domain", {}).get("domain_name")
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get domain", error=str(e))
        raise


@mcp.tool(
    name="domains.add",
    title="Add Domain",
    annotations=ToolAnnotations(
        title="Add Domain",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def add_domain(
    domain_name: Annotated[str, Field(description="The domain name to add, e.g. 'example.com'")],
    use_nameservers: Annotated[bool, Field(description="Whether to use ColdSend managed nameservers (recommended)")] = True,
) -> dict:
    """
    Add a new domain to your workspace.
    
    This initiates the domain verification process. You'll need to configure
    DNS records as instructed to complete verification.
    
    ## Verification Process
    
    1. Add domain to ColdSend (this endpoint)
    2. Configure DNS records at your domain registrar
    3. Wait for DNS propagation (5-30 minutes)
    4. Verify DNS records (ColdSend auto-checks periodically)
    5. Domain becomes active once verified
    
    ## Required DNS Records
    
    **MX Record:**
    - Name: @ (or your domain)
    - Value: mx.coldsend.io
    - Priority: 10
    
    **TXT Record (SPF):**
    - Name: @
    - Value: v=spf1 include:coldsend.io ~all
    
    **CNAME Record (DKIM):**
    - Name: coldsend._domainkey
    - Value: dkim.coldsend.io
    
    Args:
        domain_name: Domain name to add (e.g., "example.com")
        use_nameservers: Whether to use ColdSend nameservers (recommended)
    
    Returns:
        Domain creation result with:
            - Domain ID and name
            - Initial status (usually "pending")
            - Next steps for verification
    
    Example:
        ```python
        result = await add_domain("example.com")
        print(f"Domain added: {result['domain']['domain_name']}")
        print(f"Status: {result['domain']['status']}")
        ```
    """
    try:
        api_client = create_api_client()
        config = {
            "domain_name": domain_name,
            "use_nameservers": use_nameservers
        }
        response = await api_client.post("/domains", config)
        
        logger.info(
            "Domain added via MCP",
            domain_name=domain_name,
            domain_id=response.get("domain", {}).get("id")
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to add domain", error=str(e))
        raise


@mcp.tool(
    name="domains.verify",
    title="Verify Domain DNS",
    annotations=ToolAnnotations(
        title="Verify Domain DNS",
        readOnlyHint=False,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def verify_domain_dns(
    domain_id: Annotated[str, Field(description="The UUID of the domain to trigger DNS verification for")],
) -> dict:
    """
    Trigger DNS verification check for a domain.
    
    Forces an immediate DNS record verification instead of waiting
    for the automatic periodic checks.
    
    Use this after you've configured DNS records to get instant feedback.
    
    Args:
        domain_id: Domain UUID to verify
    
    Returns:
        Verification results including:
            - Overall verification status
            - Individual DNS record status
            - Error messages if any records are missing/incorrect
    
    Example:
        ```python
        result = await verify_domain_dns("550e8400-e29b-41d4-a716-446655440000")
        print(f"Verification status: {result['verification']['status']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.post(f"/domains/{domain_id}/verify")
        
        logger.info(
            "Domain DNS verification triggered",
            domain_id=domain_id,
            status=response.get("verification", {}).get("status")
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to verify domain DNS", error=str(e))
        raise


@mcp.tool(
    name="domains.progress",
    title="Get Domain Activation Progress",
    annotations=ToolAnnotations(
        title="Get Domain Activation Progress",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    ),
)
async def get_domain_activation_progress(
    domain_id: Annotated[str, Field(description="The UUID of the domain to check activation progress for")],
) -> dict:
    """
    Get domain activation progress and next steps.
    
    Provides a detailed breakdown of what's completed and what's pending
    in the domain setup process.
    
    Args:
        domain_id: Domain UUID
    
    Returns:
        Progress report including:
            - Overall completion percentage
            - Step-by-step progress
            - Pending actions required
            - Estimated time to completion
    
    Example:
        ```python
        progress = await get_domain_activation_progress("550e8400-e29b-41d4-a716-446655440000")
        print(f"Completion: {progress['progress']['percent_complete']}%")
        print(f"Next step: {progress['progress']['next_step']}")
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.get(f"/domains/{domain_id}/progress")
        
        logger.debug(
            "Retrieved domain activation progress",
            domain_id=domain_id,
            percent_complete=response.get("progress", {}).get("percent_complete", 0)
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to get domain activation progress", error=str(e))
        raise


@mcp.tool(
    name="domains.delete",
    title="Delete Domain",
    annotations=ToolAnnotations(
        title="Delete Domain",
        readOnlyHint=False,
        destructiveHint=True,
        idempotentHint=False,
        openWorldHint=False,
    ),
)
async def delete_domain(
    domain_id: Annotated[str, Field(description="The UUID of the domain to permanently delete")],
) -> dict:
    """
    Delete a domain permanently.
    
    ⚠️ WARNING: This will remove the domain from your workspace.
    Any inboxes using this domain will be affected.
    
    Prerequisites:
    - All inboxes using this domain must be deleted first
    - Domain cannot have active campaigns
    
    Args:
        domain_id: Domain UUID to delete
    
    Returns:
        Deletion confirmation
    
    Example:
        ```python
        result = await delete_domain("550e8400-e29b-41d4-a716-446655440000")
        print(result['message'])
        ```
    """
    try:
        api_client = create_api_client()
        response = await api_client.delete(f"/domains/{domain_id}")
        
        logger.warning(
            "Domain deleted via MCP",
            domain_id=domain_id
        )
        
        return response
        
    except Exception as e:
        logger.error("Failed to delete domain", error=str(e))
        raise
