"""
Authentication middleware and utilities for ColdSend MCP Server.

Supports two authentication methods:
1. API Key passthrough (Phase 1 - MVP)
2. OAuth 2.1 (Phase 2 - Production)
"""

import hashlib
import secrets
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from contextvars import ContextVar

import structlog
from fastapi import HTTPException, status, Request
import httpx

from .config import get_settings

logger = structlog.get_logger(__name__)

# Context variable to store current API key
api_key_context: ContextVar[Optional[str]] = ContextVar("api_key", default=None)

settings = get_settings()


class AuthenticationError(Exception):
    """Custom exception for authentication errors."""
    pass


class APIClient:
    """HTTP client for communicating with ColdSend public APIs."""
    
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url
        self.api_key = api_key
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers={"X-API-Key": api_key},
            timeout=settings.coldsend_api_timeout
        )
    
    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()
    
    async def get(self, path: str, params: Optional[Dict] = None):
        """Make GET request."""
        response = await self.client.get(path, params=params)
        response.raise_for_status()
        return response.json()
    
    async def post(self, path: str, json: Dict):
        """Make POST request."""
        response = await self.client.post(path, json=json)
        response.raise_for_status()
        return response.json()
    
    async def put(self, path: str, json: Dict):
        """Make PUT request."""
        response = await self.client.put(path, json=json)
        response.raise_for_status()
        return response.json()
    
    async def delete(self, path: str):
        """Make DELETE request."""
        response = await self.client.delete(path)
        response.raise_for_status()
        return response.json()


def hash_api_key(raw_key: str) -> str:
    """
    Hash an API key using SHA-256 and a secret pepper.
    
    Matches the implementation in coldsend-api-service.
    
    Raises:
        ValueError: If API_KEY_HASH_SECRET or JWT_SECRET_KEY is not configured
    """
    secret = settings.api_key_hash_secret or settings.jwt_secret_key
    if not secret:
        raise ValueError(
            "API_KEY_HASH_SECRET or JWT_SECRET_KEY environment variable must be configured. "
            "This secret is used to hash API keys and must match the coldsend-api-service configuration."
        )
    payload = f"{secret}:{raw_key}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


async def validate_api_key(api_key: str) -> Dict[str, Any]:
    """
    Validate API key by calling the ColdSend API.
    
    Args:
        api_key: Raw API key from request
        
    Returns:
        User/team information if valid
        
    Raises:
        AuthenticationError: If API key is invalid
    """
    try:
        # Make a test call to get current user info
        async with httpx.AsyncClient(
            base_url=settings.coldsend_api_url,
            headers={"X-API-Key": api_key},
            timeout=10
        ) as client:
            # Try to get account info (we'll need to add this endpoint or use existing one)
            response = await client.get("/me")
            
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            elif response.status_code == 403:
                raise AuthenticationError("API key lacks required permissions")
            elif response.status_code != 200:
                # For now, just verify the key works
                # In production, implement a proper /me endpoint
                pass
            
            return {
                "authenticated": True,
                "auth_method": "api_key"
            }
            
    except httpx.HTTPError as e:
        logger.warning("API key validation failed", error=str(e))
        raise AuthenticationError(f"Failed to validate API key: {str(e)}")


async def get_current_api_key(request: Request) -> str:
    """
    Extract and validate API key from request headers.
    
    This is the primary authentication dependency for MCP tools.
    
    Args:
        request: FastAPI request object
        
    Returns:
        Validated API key
        
    Raises:
        HTTPException: If authentication fails
    """
    # Try to get API key from X-API-Key header
    api_key = request.headers.get("X-API-Key")
    
    if not api_key:
        # Check Authorization header for Bearer token (OAuth Phase 2)
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            # OAuth 2.1 flow - implement in Phase 2
            logger.info("OAuth token detected, will implement in Phase 2")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="OAuth 2.1 authentication not yet implemented. Use X-API-Key header."
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="API key required. Include your API key in the X-API-Key header.",
                headers={"WWW-Authenticate": "ApiKey"}
            )
    
    # Validate the API key
    try:
        await validate_api_key(api_key)
        
        # Store in context for use by tools
        api_key_context.set(api_key)
        
        return api_key
        
    except AuthenticationError as e:
        logger.warning("API key authentication failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
            headers={"WWW-Authenticate": "ApiKey"}
        )


async def get_api_client(request: Request) -> APIClient:
    """
    Get authenticated API client for making requests to ColdSend APIs.
    
    Usage as dependency:
        @mcp.tool()
        async def create_campaign(
            api_client: APIClient = Depends(get_api_client)
        ):
            response = await api_client.post("/campaigns", {...})
            return response
    
    Args:
        request: FastAPI request object
        
    Returns:
        Authenticated APIClient instance
    """
    api_key = await get_current_api_key(request)
    return APIClient(settings.coldsend_api_url, api_key)


def create_api_client() -> APIClient:
    """
    Create an API client from the current context.
    
    Use this in MCP tools instead of Depends() to avoid JSON schema issues.
    
    Returns:
        Authenticated APIClient instance or raises RuntimeError
    """
    api_key = api_key_context.get()
    if not api_key:
        raise RuntimeError("Not authenticated. Please provide X-API-Key header.")
    
    return APIClient(settings.coldsend_api_url, api_key)


async def require_api_scopes(*required_scopes: str):
    """
    Dependency factory to enforce API key scopes.
    
    Usage:
        @mcp.tool()
        async def create_campaign(
            _: None = Depends(require_api_scopes("campaigns:create"))
        ):
            ...
    
    Args:
        *required_scopes: Required scope strings
        
    Returns:
        Dependency function
    """
    async def _dependency(request: Request):
        # Get API key first
        api_key = await get_current_api_key(request)
        
        # TODO: Query API to get current key's scopes
        # For Phase 1, we'll skip scope validation
        # In Phase 2, implement proper scope checking
        
        logger.debug(
            "Scope validation skipped for Phase 1",
            api_key_hash=hash_api_key(api_key)[:8] + "...",
            required_scopes=required_scopes
        )
        
        return api_key
    
    return _dependency
