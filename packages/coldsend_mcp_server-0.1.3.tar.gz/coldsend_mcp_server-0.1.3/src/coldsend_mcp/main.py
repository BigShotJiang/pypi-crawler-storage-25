"""
Main entry point for ColdSend MCP Server.

Runs the MCP server with dual transport support:
- Streamable HTTP (modern) on /mcp
- SSE (legacy) on /sse and /messages
"""

import structlog
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.server import TransportSecuritySettings
from mcp.types import Icon

from .config import get_settings
from .auth import api_key_context
from .tools import campaigns, leads, analytics, domains, sender_accounts, campaign_updates
from .resources import mcp as resources
from .prompts import mcp as prompts

# Configure logging
settings = get_settings()
structlog.configure(
    processors=[
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer()
    ],
    wrapper_class=structlog.make_filtering_bound_logger(settings.log_level),
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)

# Create main MCP server
mcp = FastMCP(
    name="ColdSend Email Campaign Assistant",
    host=settings.mcp_host,
    port=settings.mcp_port,
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
    website_url="https://coldsend.pro",
    icons=[
        Icon(
            src="https://cloud.coldsend.pro/favicon-coldsend.png",
            mimeType="image/png",
        )
    ],
    instructions=(
        "AI-native cold email campaign management server. "
        "Create and manage email campaigns, upload and organize leads from CSV, "
        "configure sender inboxes (ColdSend native, SMTP, Google Workspace, Outlook 365), "
        "track delivery and engagement analytics, manage custom domains with DNS verification, "
        "and optimize email deliverability — all through natural language via the Model Context Protocol. "
        "Authenticate with your ColdSend API key to get started."
    ),
)

# Register tools from modules
for tool_module in [campaigns.mcp, leads.mcp, analytics.mcp, domains.mcp, sender_accounts.mcp, campaign_updates.mcp]:
    for tool in tool_module._tool_manager._tools.values():
        mcp._tool_manager._tools[tool.name] = tool

# Register resources
for resource in resources._resource_manager._resources.values():
    mcp._resource_manager._resources[resource.uri] = resource
for template in resources._resource_manager._templates.values():
    mcp._resource_manager._templates[template.uri_template] = template

# Register prompts
for prompt in prompts._prompt_manager._prompts.values():
    mcp._prompt_manager._prompts[prompt.name] = prompt


async def health_check(request):
    """Health check endpoint for Kubernetes probes."""
    from starlette.responses import JSONResponse
    return JSONResponse({
        "status": "healthy",
        "service": "coldsend-mcp-server",
        "version": "0.1.2"
    })


async def server_card(request):
    """Dynamically generated server card for Smithery publishing.
    
    Introspects registered tools, resources, and prompts at runtime
    so new capabilities are automatically advertised.
    """
    from starlette.responses import JSONResponse

    # Build tools list from registered tools
    tools_list = []
    for tool in mcp._tool_manager.list_tools():
        tools_list.append({
            "name": tool.name,
            "description": tool.description,
            "inputSchema": tool.parameters,
        })

    # Build resources list from registered resources + templates
    resources_list = []
    for resource in mcp._resource_manager._resources.values():
        resources_list.append({
            "uri": str(resource.uri),
            "name": resource.name or str(resource.uri),
            "description": resource.description or "",
            "mimeType": resource.mime_type,
        })
    for template in mcp._resource_manager._templates.values():
        resources_list.append({
            "uriTemplate": str(template.uri_template),
            "name": template.name or str(template.uri_template),
            "description": template.description or "",
            "mimeType": template.mime_type,
        })

    # Build prompts list from registered prompts
    prompts_list = []
    for prompt in mcp._prompt_manager._prompts.values():
        prompt_entry = {
            "name": prompt.name,
            "description": prompt.description or "",
        }
        if prompt.arguments:
            prompt_entry["arguments"] = [
                {
                    "name": arg.name,
                    "description": arg.description or "",
                    "required": arg.required,
                }
                for arg in prompt.arguments
            ]
        prompts_list.append(prompt_entry)

    return JSONResponse({
        "serverInfo": {
            "name": "ColdSend Email Campaign Assistant",
            "version": "0.1.2",
            "description": mcp.instructions,
            "websiteUrl": mcp.website_url,
        },
        "tools": tools_list,
        "resources": resources_list,
        "prompts": prompts_list,
    })


async def root(request):
    """Root endpoint with service information and transport discovery."""
    from starlette.responses import JSONResponse
    return JSONResponse({
        "name": "ColdSend MCP Server",
        "version": "0.1.2",
        "description": "AI-native email campaign management via Model Context Protocol",
        "transports": {
            "streamable-http": {
                "endpoint": "/mcp",
                "description": "Modern MCP transport (Claude Code, Cursor, VS Code, Smithery)",
            },
            "sse": {
                "endpoint": "/sse",
                "messages": "/messages",
                "description": "Legacy SSE transport (OpenCode, older clients)",
            },
        },
        "endpoints": {
            "mcp": "/mcp",
            "sse": "/sse",
            "health": "/health",
        },
    })


def create_app():
    """
    Create a combined ASGI app serving both Streamable HTTP and SSE transports.

    Routes:
        /mcp              - Streamable HTTP transport (modern)
        /sse              - SSE transport endpoint (legacy)
        /messages         - SSE message endpoint (legacy)
        /health           - Health check
        /.well-known/mcp/server-card.json - Server card for Smithery
        /                 - Service info with transport discovery
    """
    from starlette.applications import Starlette
    from starlette.routing import Route, Mount

    # Create transport sub-apps. Custom routes are NOT registered via
    # @mcp.custom_route so they won't be duplicated in the sub-apps.
    http_app = mcp.streamable_http_app()
    sse_app = mcp.sse_app()

    # Lifespan: run the Streamable HTTP session manager
    async def lifespan(app):
        async with mcp.session_manager.run():
            yield

    # Build combined route list — custom routes first (highest priority),
    # then transport routes from both sub-apps.
    routes = [
        # Custom routes (checked first)
        Route("/health", endpoint=health_check, methods=["GET"]),
        Route(
            "/.well-known/mcp/server-card.json",
            endpoint=server_card,
            methods=["GET"],
        ),
        Route("/", endpoint=root, methods=["GET"]),
    ]

    # Add transport routes from streamable-http sub-app (/mcp)
    for route in http_app.routes:
        routes.append(route)

    # Add transport routes from SSE sub-app (/sse, /messages)
    for route in sse_app.routes:
        routes.append(route)

    app = Starlette(lifespan=lifespan, routes=routes)

    logger.info(
        "Created dual-transport MCP app",
        transports=["streamable-http (/mcp)", "sse (/sse, /messages)"],
    )

    return app


# Expose ASGI app for uvicorn/gunicorn
app = create_app()


def run_server():
    """
    Run the MCP server with dual transport support.
    """
    import uvicorn

    logger.info(
        "Starting ColdSend MCP Server",
        host=settings.mcp_host,
        port=settings.mcp_port,
        transports=["streamable-http (/mcp)", "sse (/sse, /messages)"],
    )

    uvicorn.run(app, host=settings.mcp_host, port=settings.mcp_port)


if __name__ == "__main__":
    run_server()
