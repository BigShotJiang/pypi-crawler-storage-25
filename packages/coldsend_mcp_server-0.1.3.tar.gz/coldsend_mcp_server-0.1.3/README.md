# ColdSend MCP Server

**AI-Native Email Campaign Management via Model Context Protocol**

ColdSend MCP Server enables AI assistants like Claude Desktop, Claude Code, Cursor IDE, Windsurf, OpenCode, and other MCP-compatible clients to manage cold email campaigns through natural language.

The server supports **dual transport** — Streamable HTTP (modern) and SSE (legacy) — for maximum client compatibility.

## Installation

```bash
pip install coldsend-mcp-server
```

## Quick Start

You only need your ColdSend API key to get started.

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "coldsend": {
      "command": "coldsend-mcp",
      "env": {
        "X-API-Key": "your-coldsend-api-key"
      }
    }
  }
}
```

### Claude Code

```bash
claude mcp add coldsend https://mcp.coldsend.pro/mcp -t http -e X-API-Key=your-api-key
```

### Cursor IDE / Windsurf

1. Open Settings -> MCP
2. Add new MCP server:
   - Name: `ColdSend`
   - Type: `http` (Streamable HTTP)
   - URL: `https://mcp.coldsend.pro/mcp`
   - Headers: `X-API-Key: your-api-key`

### OpenCode

Add to your `opencode.jsonc`:

```jsonc
{
  "mcp": {
    "coldsend": {
      "type": "remote",
      "url": "https://mcp.coldsend.pro/sse",
      "enabled": true,
      "headers": {
        "X-API-Key": "{env:COLDSEND_API_KEY}"
      }
    }
  }
}
```

### Remote Server (No Installation Required)

You can connect directly to the hosted server without installing anything. Two transport endpoints are available:

| Transport | URL | Use With |
|-----------|-----|----------|
| Streamable HTTP | `https://mcp.coldsend.pro/mcp` | Claude Code, Cursor, VS Code, Smithery |
| SSE (legacy) | `https://mcp.coldsend.pro/sse` | OpenCode, older clients |

Header: `X-API-Key: your-api-key`

## Available Tools

### Campaign Management

| Tool | Description |
|------|-------------|
| `create_campaign` | Create a new email campaign |
| `list_campaigns` | List all campaigns with filtering |
| `get_campaign` | Get specific campaign details |
| `update_campaign` | Update campaign configuration |
| `pause_campaign` | Pause an active campaign |
| `activate_campaign` | Activate/resume a campaign |
| `resume_campaign` | Resume a paused campaign |
| `delete_campaign` | Delete a campaign permanently |

### Lead Management

| Tool | Description |
|------|-------------|
| `upload_leads_csv` | Upload leads from CSV |
| `list_leads` | List leads in a campaign |
| `delete_lead` | Remove a lead |
| `get_lead_stats` | Get lead statistics |

### Analytics & Metrics

| Tool | Description |
|------|-------------|
| `get_campaign_analytics` | Comprehensive campaign analytics |
| `get_account_metrics` | Account-level metrics and quotas |
| `get_inbox_performance` | Inbox performance analysis |
| `compare_campaigns` | Compare multiple campaigns |

### Domain Management

| Tool | Description |
|------|-------------|
| `list_domains` | List all domains with verification status |
| `get_domain` | Get domain details with DNS records |
| `add_domain` | Add new domain for verification |
| `verify_domain_dns` | Trigger DNS verification check |
| `get_domain_activation_progress` | Check setup progress |
| `delete_domain` | Delete domain permanently |

### Sender Account Management

| Tool | Description |
|------|-------------|
| `list_sender_accounts` | List all sender inboxes |
| `create_coldsend_inbox` | Create ColdSend native inbox |
| `create_smtp_inbox` | Create custom SMTP inbox (BYOC) |
| `send_test_email` | Send test email to verify configuration |
| `pause_inbox` | Pause inbox temporarily |
| `resume_inbox` | Resume paused inbox |
| `delete_inbox` | Delete inbox permanently |
| `get_inbox_health` | Get detailed health report |

## Example Interactions

**Creating a Campaign:**

> Create a new campaign called "Q1 Outreach" starting January 15th with a daily limit of 100 emails.

**Checking Performance:**

> How is my Q1 Outreach campaign performing?

**Uploading Leads:**

> Upload these leads to my Q1 Outreach campaign: [paste CSV]

**Managing Domains:**

> Add the domain outreach.acme.com and show me the DNS records I need to configure.

**Inbox Health:**

> Check the health of all my sender inboxes and flag any issues.

## Authentication

The MCP server uses API key authentication. Pass your ColdSend API key via the `X-API-Key` header — the server forwards it securely to the ColdSend API.

Get your API key from your [ColdSend dashboard](https://cloud.coldsend.pro).

### Smithery

This server is also available on [Smithery](https://smithery.ai/servers/pipelinescientists/coldsend-mcp) if you prefer to use it from there.

## Transport Endpoints

The server exposes two transport protocols on different paths:

| Path | Transport | Description |
|------|-----------|-------------|
| `/mcp` | Streamable HTTP | Modern MCP transport (recommended) |
| `/sse` | SSE | Legacy transport for older clients |
| `/messages` | SSE POST | Message endpoint for SSE transport |
| `/health` | HTTP GET | Health check for Kubernetes probes |
| `/` | HTTP GET | Service info with transport discovery |

## Configuration

The server works out of the box with sensible defaults. All configuration is optional:

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `COLDSEND_API_URL` | `https://api.coldsend.pro/api/public/v1` | ColdSend API endpoint |
| `MCP_PORT` | `8080` | Server port |
| `LOG_LEVEL` | `INFO` | Logging level |

## Requirements

- Python 3.11+

## Links

- **Website**: [coldsend.pro](https://coldsend.pro)
- **API Docs**: [docs.coldsend.pro](https://docs.coldsend.pro)
- **Support**: support@coldsend.pro

## License

MIT License - see [LICENSE](LICENSE) for details.

---

**Built with [Model Context Protocol](https://modelcontextprotocol.io/) by the ColdSend Team**
