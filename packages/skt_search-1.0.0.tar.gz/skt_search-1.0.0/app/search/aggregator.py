"""
Search Result Aggregator
Combines results from multiple sources, removes duplicates, ranks by relevance
"""
import hashlib
import logging
from typing import List, Dict
from difflib import SequenceMatcher

logger = logging.getLogger(__name__)

class ResultAggregator:
    def __init__(self):
        self.similarity_threshold = 0.85

    def _get_url_hash(self, url: str) -> str:
        """Create hash for deduplication"""
        return hashlib.md5(url.lower().encode()).hexdigest()[:16]

    def _similarity(self, text1: str, text2: str) -> float:
        """Calculate text similarity"""
        return SequenceMatcher(None, text1.lower(), text2.lower()).ratio()

    def aggregate(self, results_list: List[List[Dict]], max_results: int = 10) -> List[Dict]:
        """
        Aggregate and deduplicate results from multiple sources
        """
        seen_urls = set()
        seen_content = []
        final_results = []

        # Flatten all results
        all_results = []
        for results in results_list:
            all_results.extend(results)

        # Sort by source priority and relevance
        source_priority = {
            "duckduckgo": 1,
            "searxng": 2,
            "brave": 3,
            "google_scrape": 4,
            "bing_scrape": 5
        }

        for result in all_results:
            url = result.get('url', '')
            title = result.get('title', '')
            snippet = result.get('snippet', '')

            if not url:
                continue

            # Check URL duplicate
            url_hash = self._get_url_hash(url)
            if url_hash in seen_urls:
                continue

            # Check content similarity
            is_duplicate = False
            for existing in seen_content:
                if self._similarity(title + snippet, existing) > self.similarity_threshold:
                    is_duplicate = True
                    break

            if is_duplicate:
                continue

            seen_urls.add(url_hash)
            seen_content.append(title + snippet)

            # Add source priority score
            source = result.get('source', 'unknown')
            result['priority'] = source_priority.get(source, 99)

            final_results.append(result)

        # Sort by priority and limit
        final_results.sort(key=lambda x: x.get('priority', 99))

        logger.info(f"✅ Aggregated {len(final_results)} unique results from {len(all_results)} total")
        return final_results[:max_results]

    def enrich_with_scraping(self, results: List[Dict], scraper) -> List[Dict]:
        """Enrich search results with scraped content"""
        enriched = []

        for result in results:
            url = result.get('url', '')
            if url:
                try:
                    scraped = scraper.scrape_page(url)
                    if scraped.get('status') == 200:
                        result['full_content'] = scraped.get('content', '')[:5000]
                        result['page_title'] = scraped.get('title', '')
                        result['metadata'] = scraped.get('metadata', {})
                except Exception as e:
                    logger.warning(f"Could not enrich {url}: {e}")

            enriched.append(result)

        return enriched

aggregator = ResultAggregator()
