"""
Search modules
"""
from .duckduckgo import ddg_search
from .searxng import searxng_search
from .brave import brave_search
from .scraper import scraper
from .aggregator import aggregator
