"""
SearXNG Metasearch Fallback
Uses public SearXNG instances when DuckDuckGo is blocked
"""
import time
import random
import logging
from typing import List, Dict
import requests

logger = logging.getLogger(__name__)

try:
    from fake_useragent import UserAgent
    ua = UserAgent()
except ImportError:
    ua = None

SEARXNG_INSTANCES = [
    "https://search.sapti.me",
    "https://searx.be",
    "https://searx.tiekoetter.com",
    "https://search.bus-hit.me",
    "https://searxng.nicfab.eu",
    "https://searx.drgns.space",
    "https://search.rhscz.eu",
    "https://search.citw.lgbt",
    "https://searxng.site",
    "https://search.smnz.de",
    "https://searxng.ch",
    "https://paulgo.io",
    "https://search.ononoki.org",
    "https://searx.fi",
    "https://search.gcomm.ch",
]

class SearXNGSearch:
    def __init__(self):
        self.timeout = 20
        self.max_retries = 2

    def search(self, query: str, max_results: int = 10) -> List[Dict]:
        """Search using SearXNG instances"""
        results = []

        instances = SEARXNG_INSTANCES.copy()
        random.shuffle(instances)

        for instance in instances[:3]:
            try:
                params = {
                    'q': query,
                    'format': 'json',
                    'language': 'en',
                    'safesearch': '0',
                    'categories': 'general'
                }

                user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                if ua:
                    try:
                        user_agent = ua.random
                    except:
                        pass

                headers = {
                    'User-Agent': user_agent,
                    'Accept': 'application/json',
                }

                response = requests.get(
                    instance + "/search",
                    params=params,
                    headers=headers,
                    timeout=self.timeout
                )

                if response.status_code == 200:
                    data = response.json()

                    for result in data.get('results', [])[:max_results]:
                        results.append({
                            "title": result.get('title', ''),
                            "url": result.get('url', ''),
                            "snippet": result.get('content', ''),
                            "source": "searxng_" + instance.split("//")[1].split("/")[0],
                            "score": result.get('score', 0)
                        })

                    if results:
                        logger.info("SearXNG found " + str(len(results)) + " results from " + instance)
                        return results

            except Exception as e:
                logger.warning("SearXNG instance " + instance + " failed: " + str(e))
                time.sleep(random.uniform(1, 3))
                continue

        logger.error("All SearXNG instances failed")
        return results

    def search_images(self, query: str, max_results: int = 10) -> List[Dict]:
        """Search images via SearXNG"""
        results = []
        instances = SEARXNG_INSTANCES.copy()
        random.shuffle(instances)

        for instance in instances[:2]:
            try:
                params = {
                    'q': query,
                    'format': 'json',
                    'categories': 'images'
                }

                user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                if ua:
                    try:
                        user_agent = ua.random
                    except:
                        pass

                response = requests.get(
                    instance + "/search",
                    params=params,
                    headers={'User-Agent': user_agent},
                    timeout=self.timeout
                )

                if response.status_code == 200:
                    data = response.json()
                    for result in data.get('results', [])[:max_results]:
                        results.append({
                            "title": result.get('title', ''),
                            "url": result.get('img_src', ''),
                            "source_url": result.get('url', ''),
                            "source": "searxng_images"
                        })
                    return results

            except Exception as e:
                logger.warning("Image search failed: " + str(e))

        return results

searxng_search = SearXNGSearch()
