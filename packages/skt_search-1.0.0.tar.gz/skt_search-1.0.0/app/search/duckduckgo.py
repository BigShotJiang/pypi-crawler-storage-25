"""
DuckDuckGo Search with Anti-Block Bypass
Handles 202, 404, 429 errors with human-like behavior
"""
import time
import random
from typing import List, Dict
import logging

logger = logging.getLogger(__name__)

try:
    from duckduckgo_search import DDGS
    DDGS_AVAILABLE = True
except ImportError:
    DDGS_AVAILABLE = False
    logger.warning("duckduckgo_search not installed. Install with: pip install duckduckgo-search")

try:
    from fake_useragent import UserAgent
    ua = UserAgent()
except ImportError:
    ua = None

class DuckDuckGoSearch:
    def __init__(self):
        self.ddgs = None
        self.retry_count = 3
        self.delay_range = (2, 8)

    def _get_random_headers(self):
        """Generate human-like headers"""
        user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        if ua:
            try:
                user_agent = ua.random
            except:
                pass

        return {
            'User-Agent': user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0',
        }

    def _human_delay(self):
        """Random delay to mimic human behavior"""
        delay = random.uniform(*self.delay_range)
        time.sleep(delay)

    def search(self, query: str, max_results: int = 10, region: str = "wt-wt") -> List[Dict]:
        """
        Search DuckDuckGo with anti-block measures
        """
        if not DDGS_AVAILABLE:
            logger.warning("DDGS not available. Returning empty results.")
            return []

        results = []

        for attempt in range(self.retry_count):
            try:
                self._human_delay()

                with DDGS(headers=self._get_random_headers()) as ddgs:
                    search_results = ddgs.text(
                        query,
                        region=region,
                        safesearch="off",
                        max_results=max_results
                    )

                    for result in search_results:
                        results.append({
                            "title": result.get("title", ""),
                            "url": result.get("href", ""),
                            "snippet": result.get("body", ""),
                            "source": "duckduckgo"
                        })

                    if results:
                        logger.info("Found " + str(len(results)) + " results for: " + query)
                        return results

            except Exception as e:
                error_msg = str(e)
                logger.warning("Attempt " + str(attempt + 1) + " failed: " + error_msg)

                if "202" in error_msg or "429" in error_msg:
                    wait_time = random.uniform(10, 30)
                    logger.info("Rate limited. Waiting " + str(wait_time) + "s...")
                    time.sleep(wait_time)

                elif "404" in error_msg:
                    logger.info("Trying alternative endpoint...")

                else:
                    wait_time = (2 ** attempt) + random.uniform(0, 3)
                    time.sleep(wait_time)

        logger.error("All attempts failed for query: " + query)
        return results

    def search_news(self, query: str, max_results: int = 10) -> List[Dict]:
        """Search news via DuckDuckGo"""
        if not DDGS_AVAILABLE:
            return []

        try:
            with DDGS(headers=self._get_random_headers()) as ddgs:
                results = ddgs.news(query, max_results=max_results)
                return [{
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "snippet": r.get("body", ""),
                    "date": r.get("date", ""),
                    "source": "duckduckgo_news"
                } for r in results]
        except Exception as e:
            logger.error("News search error: " + str(e))
            return []

    def search_images(self, query: str, max_results: int = 10) -> List[Dict]:
        """Search images via DuckDuckGo"""
        if not DDGS_AVAILABLE:
            return []

        try:
            with DDGS(headers=self._get_random_headers()) as ddgs:
                results = ddgs.images(query, max_results=max_results)
                return [{
                    "title": r.get("title", ""),
                    "url": r.get("image", ""),
                    "source_url": r.get("url", ""),
                    "source": "duckduckgo_images"
                } for r in results]
        except Exception as e:
            logger.error("Image search error: " + str(e))
            return []

ddg_search = DuckDuckGoSearch()
