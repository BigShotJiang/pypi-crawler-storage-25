"""
Advanced Web Scraper with Human-like Behavior
Scrapes ALL websites including Google results, W3Schools, etc.
"""
import time
import random
import logging
from typing import List, Dict, Optional
from urllib.parse import urljoin, urlparse
import requests

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False
    BeautifulSoup = None

try:
    from fake_useragent import UserAgent
    ua = UserAgent()
except ImportError:
    ua = None

logger = logging.getLogger(__name__)

class WebScraper:
    def __init__(self):
        self.session = requests.Session()
        self.timeout = 15
        self.max_retries = 3
        self.delay_range = (1, 5)

    def _get_headers(self, url: str) -> dict:
        """Get human-like headers for specific domain"""
        domain = urlparse(url).netloc

        user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        if ua:
            try:
                user_agent = ua.random
            except:
                pass

        base_headers = {
            'User-Agent': user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9,hi;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Referer': 'https://www.google.com/',
        }

        if 'w3schools' in domain:
            base_headers['Referer'] = 'https://www.w3schools.com/'
        elif 'stackoverflow' in domain:
            base_headers['Referer'] = 'https://stackoverflow.com/'
        elif 'github' in domain:
            base_headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9'

        return base_headers

    def _human_delay(self):
        """Random delay to avoid detection"""
        time.sleep(random.uniform(*self.delay_range))

    def scrape_page(self, url: str, extract_content: bool = True) -> Dict:
        """
        Scrape a single webpage with anti-detection
        """
        if not BS4_AVAILABLE:
            logger.warning("BeautifulSoup not installed. Install: pip install beautifulsoup4 lxml")
            return {"url": url, "status": 0, "error": "BeautifulSoup not installed"}

        self._human_delay()

        for attempt in range(self.max_retries):
            try:
                headers = self._get_headers(url)
                response = self.session.get(
                    url, 
                    headers=headers, 
                    timeout=self.timeout,
                    allow_redirects=True
                )

                if response.status_code == 200:
                    soup = BeautifulSoup(response.content, 'lxml')

                    result = {
                        "url": url,
                        "status": 200,
                        "title": self._extract_title(soup),
                        "content": "",
                        "links": [],
                        "images": [],
                        "metadata": {}
                    }

                    if extract_content:
                        result["content"] = self._extract_content(soup)
                        result["links"] = self._extract_links(soup, url)
                        result["images"] = self._extract_images(soup, url)
                        result["metadata"] = self._extract_metadata(soup)

                    logger.info("Scraped: " + url)
                    return result

                elif response.status_code in [403, 429]:
                    wait = random.uniform(5, 15)
                    logger.warning("Blocked (" + str(response.status_code) + "). Waiting " + str(wait) + "s...")
                    time.sleep(wait)
                    continue

                else:
                    logger.warning("Status " + str(response.status_code) + " for " + url)
                    return {"url": url, "status": response.status_code, "error": "HTTP " + str(response.status_code)}

            except requests.exceptions.Timeout:
                logger.warning("Timeout for " + url)
                time.sleep(random.uniform(3, 8))

            except Exception as e:
                logger.error("Error scraping " + url + ": " + str(e))
                time.sleep(random.uniform(2, 5))

        return {"url": url, "status": 0, "error": "Max retries exceeded"}

    def _extract_title(self, soup) -> str:
        """Extract page title"""
        title_tag = soup.find('title')
        return title_tag.get_text(strip=True) if title_tag else "No Title"

    def _extract_content(self, soup) -> str:
        """Extract main content from page"""
        for script in soup(["script", "style", "nav", "footer", "header", "aside"]):
            script.decompose()

        main_content = (
            soup.find('main') or 
            soup.find('article') or 
            soup.find('div', class_=lambda x: x and 'content' in x.lower()) or
            soup.find('div', id=lambda x: x and 'content' in x.lower()) or
            soup.find('body')
        )

        if main_content:
            text = main_content.get_text(separator=chr(10), strip=True)
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            return chr(10).join(lines)

        return ""

    def _extract_links(self, soup, base_url: str) -> List[Dict]:
        """Extract all links from page"""
        links = []
        for a in soup.find_all('a', href=True):
            href = urljoin(base_url, a['href'])
            links.append({
                "url": href,
                "text": a.get_text(strip=True),
                "title": a.get('title', '')
            })
        return links[:50]

    def _extract_images(self, soup, base_url: str) -> List[Dict]:
        """Extract images from page"""
        images = []
        for img in soup.find_all('img'):
            src = img.get('src', img.get('data-src', ''))
            if src:
                images.append({
                    "url": urljoin(base_url, src),
                    "alt": img.get('alt', ''),
                    "title": img.get('title', '')
                })
        return images[:20]

    def _extract_metadata(self, soup) -> Dict:
        """Extract meta tags"""
        metadata = {}
        for meta in soup.find_all('meta'):
            name = meta.get('name', meta.get('property', ''))
            content = meta.get('content', '')
            if name and content:
                metadata[name] = content
        return metadata

    def scrape_multiple(self, urls: List[str], max_pages: int = 10) -> List[Dict]:
        """Scrape multiple URLs"""
        results = []
        for url in urls[:max_pages]:
            result = self.scrape_page(url)
            results.append(result)
            time.sleep(random.uniform(1, 3))
        return results

    def deep_scrape(self, start_url: str, depth: int = 2, max_pages: int = 10) -> List[Dict]:
        """
        Deep scrape - follows links up to specified depth
        """
        visited = set()
        to_visit = [(start_url, 0)]
        results = []

        while to_visit and len(results) < max_pages:
            url, current_depth = to_visit.pop(0)

            if url in visited or current_depth > depth:
                continue

            visited.add(url)
            result = self.scrape_page(url)
            results.append(result)

            if current_depth < depth:
                for link in result.get('links', []):
                    link_url = link['url']
                    if link_url not in visited:
                        to_visit.append((link_url, current_depth + 1))

            time.sleep(random.uniform(1, 3))

        return results

scraper = WebScraper()
