"""
Brave Search API Integration
Free tier: 2000 queries/month
"""
import os
import logging
from typing import List, Dict
import requests

logger = logging.getLogger(__name__)

BRAVE_API_URL = "https://api.search.brave.com/res/v1/web/search"

class BraveSearch:
    def __init__(self):
        self.api_key = os.getenv("BRAVE_API_KEY", "")

    def search(self, query: str, max_results: int = 10) -> List[Dict]:
        """Search using Brave Search API"""
        if not self.api_key:
            logger.warning("No Brave API key configured")
            return []

        try:
            headers = {
                "Accept": "application/json",
                "X-Subscription-Token": self.api_key
            }

            params = {
                "q": query,
                "count": min(max_results, 20),
                "offset": 0,
                "mkt": "en-US",
                "safesearch": "off",
                "freshness": "all",
                "text_decorations": False,
                "text_snippets": True
            }

            response = requests.get(
                BRAVE_API_URL,
                headers=headers,
                params=params,
                timeout=15
            )

            if response.status_code == 200:
                data = response.json()
                results = []

                for result in data.get("web", {}).get("results", []):
                    results.append({
                        "title": result.get("title", ""),
                        "url": result.get("url", ""),
                        "snippet": result.get("description", ""),
                        "source": "brave",
                        "age": result.get("age", ""),
                        "page_age": result.get("page_age", "")
                    })

                logger.info(f"✅ Brave Search: {len(results)} results")
                return results

            else:
                logger.warning(f"⚠️ Brave API error: {response.status_code}")
                return []

        except Exception as e:
            logger.error(f"❌ Brave search error: {e}")
            return []

    def search_images(self, query: str, max_results: int = 10) -> List[Dict]:
        """Search images via Brave"""
        if not self.api_key:
            return []

        try:
            headers = {
                "Accept": "application/json",
                "X-Subscription-Token": self.api_key
            }

            params = {
                "q": query,
                "count": min(max_results, 50)
            }

            response = requests.get(
                "https://api.search.brave.com/res/v1/images/search",
                headers=headers,
                params=params,
                timeout=15
            )

            if response.status_code == 200:
                data = response.json()
                return [{
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "source_url": r.get("source", ""),
                    "source": "brave_images"
                } for r in data.get("results", [])]

        except Exception as e:
            logger.error(f"Brave image search error: {e}")

        return []

brave_search = BraveSearch()
