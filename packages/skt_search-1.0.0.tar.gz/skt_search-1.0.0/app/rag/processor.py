"""
RAG (Retrieval Augmented Generation) Processor
Processes search results into context for LLM
"""
import re
import logging
from typing import List, Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class RAGProcessor:
    def __init__(self):
        self.max_context_length = 8000
        self.chunk_size = 1000
        self.chunk_overlap = 200

    def process_results(self, results: List[Dict], query: str) -> Dict:
        """
        Process search results into RAG context
        """
        context_parts = []
        sources = []

        for idx, result in enumerate(results, 1):
            title = result.get('title', 'No Title')
            url = result.get('url', '')
            snippet = result.get('snippet', '')
            full_content = result.get('full_content', snippet)

            # Create context entry
            context_entry = f"""
[Source {idx}]
Title: {title}
URL: {url}
Content: {full_content[:1500]}
"""
            context_parts.append(context_entry)

            sources.append({
                "index": idx,
                "title": title,
                "url": url,
                "snippet": snippet[:200]
            })

        # Combine context
        full_context = "\n".join(context_parts)

        # Truncate if too long
        if len(full_context) > self.max_context_length:
            full_context = full_context[:self.max_context_length] + "\n...[Content truncated]"

        return {
            "context": full_context,
            "sources": sources,
            "query": query,
            "result_count": len(results),
            "timestamp": datetime.now().isoformat()
        }

    def generate_follow_up_questions(self, query: str, context: str) -> List[str]:
        """Generate follow-up questions like Perplexity"""
        # Simple rule-based generation (can be enhanced with LLM)
        follow_ups = []

        # Extract key terms
        key_terms = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', query)

        templates = [
            f"What are the latest developments in {query}?",
            f"How does {query} compare to alternatives?",
            f"What are the pros and cons of {query}?",
            f"Can you provide examples of {query}?",
            f"What is the history of {query}?",
            f"How can I implement {query}?",
            f"What are common mistakes with {query}?",
        ]

        return templates[:5]

    def generate_related_searches(self, query: str) -> List[str]:
        """Generate related search queries"""
        related = [
            f"{query} tutorial",
            f"{query} examples",
            f"{query} vs alternative",
            f"best {query}",
            f"{query} documentation",
            f"how to use {query}",
            f"{query} guide",
        ]
        return related[:5]

    def highlight_sources(self, answer: str, sources: List[Dict]) -> str:
        """Highlight source citations in answer"""
        # Add source references
        highlighted = answer
        for source in sources:
            idx = source['index']
            url = source['url']
            # Replace any existing references
            highlighted = highlighted.replace(
                f"[{idx}]",
                f"[[{idx}]]({url})"
            )
        return highlighted

rag_processor = RAGProcessor()
