"""
HuggingFace Private Bucket Integration
Store files in HuggingFace private dataset/bucket
"""
import os
import logging
from typing import Optional, Dict, List
from huggingface_hub import HfApi, create_repo, upload_file, hf_hub_download

logger = logging.getLogger(__name__)

class HuggingFaceBucket:
    def __init__(self):
        self.token = os.getenv("HF_TOKEN", "")
        self.api = HfApi(token=self.token) if self.token else None
        self.bucket_name = os.getenv("BUCKET_NAME", "skt-search-storage")
        self.repo_type = "dataset"  # Use dataset repo as bucket

    def _ensure_repo_exists(self):
        """Ensure bucket repository exists"""
        if not self.api:
            logger.warning("No HF token available")
            return False

        try:
            self.api.repo_info(repo_id=self.bucket_name, repo_type=self.repo_type)
            return True
        except Exception:
            # Create repo if doesn't exist
            try:
                create_repo(
                    repo_id=self.bucket_name,
                    repo_type=self.repo_type,
                    private=True,
                    token=self.token,
                    exist_ok=True
                )
                logger.info(f"✅ Created bucket: {self.bucket_name}")
                return True
            except Exception as e:
                logger.error(f"❌ Failed to create bucket: {e}")
                return False

    def upload_file(self, file_path: str, repo_filename: str) -> bool:
        """Upload file to HuggingFace bucket"""
        if not self._ensure_repo_exists():
            return False

        try:
            upload_file(
                path_or_fileobj=file_path,
                path_in_repo=repo_filename,
                repo_id=self.bucket_name,
                repo_type=self.repo_type,
                token=self.token
            )
            logger.info(f"✅ Uploaded {repo_filename} to bucket")
            return True
        except Exception as e:
            logger.error(f"❌ Upload failed: {e}")
            return False

    def download_file(self, repo_filename: str, local_path: str) -> bool:
        """Download file from HuggingFace bucket"""
        try:
            downloaded = hf_hub_download(
                repo_id=self.bucket_name,
                filename=repo_filename,
                repo_type=self.repo_type,
                token=self.token,
                local_dir=local_path
            )
            logger.info(f"✅ Downloaded {repo_filename}")
            return True
        except Exception as e:
            logger.error(f"❌ Download failed: {e}")
            return False

    def list_files(self) -> List[str]:
        """List files in bucket"""
        if not self.api:
            return []

        try:
            files = self.api.list_repo_files(
                repo_id=self.bucket_name,
                repo_type=self.repo_type,
                token=self.token
            )
            return files
        except Exception as e:
            logger.error(f"❌ List failed: {e}")
            return []

    def save_search_result(self, query: str, result_data: Dict) -> bool:
        """Save search result to bucket"""
        import json
        from datetime import datetime

        filename = f"searches/{datetime.now().strftime('%Y%m%d')}/{query[:50].replace(' ', '_')}.json"

        try:
            # Save to temp file first
            temp_path = f"/tmp/{filename.replace('/', '_')}"
            with open(temp_path, 'w') as f:
                json.dump(result_data, f, indent=2)

            return self.upload_file(temp_path, filename)
        except Exception as e:
            logger.error(f"❌ Save search result failed: {e}")
            return False

# Singleton
bucket = HuggingFaceBucket()
