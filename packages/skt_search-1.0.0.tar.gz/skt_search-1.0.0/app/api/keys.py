"""
API Key Management System
Generate, validate, and manage API keys for users
"""
import secrets
import hashlib
import logging
from typing import Dict, Optional, List
from datetime import datetime, timedelta
import json
import os

logger = logging.getLogger(__name__)

# Simple file-based storage (can be replaced with DB)
KEYS_FILE = "/tmp/skt_api_keys.json"

class APIKeyManager:
    def __init__(self):
        self.keys = self._load_keys()

    def _load_keys(self) -> Dict:
        """Load keys from file"""
        if os.path.exists(KEYS_FILE):
            try:
                with open(KEYS_FILE, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading keys: {e}")
        return {}

    def _save_keys(self):
        """Save keys to file"""
        try:
            with open(KEYS_FILE, 'w') as f:
                json.dump(self.keys, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving keys: {e}")

    def generate_key(self, tier: str = "fast", owner: str = "", 
                     daily_limit: int = 5000, expires_days: int = 365) -> Dict:
        """
        Generate new API key

        Args:
            tier: fast, thinking, or pro
            owner: Key owner identifier
            daily_limit: Max requests per day
            expires_days: Days until expiration
        """
        # Generate secure key
        raw_key = f"skt_{secrets.token_urlsafe(32)}"
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()[:16]

        key_data = {
            "key_id": key_hash,
            "full_key": raw_key,  # Only shown once
            "tier": tier,
            "owner": owner,
            "daily_limit": daily_limit,
            "used_today": 0,
            "total_used": 0,
            "created_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + timedelta(days=expires_days)).isoformat(),
            "is_active": True,
            "last_used": None
        }

        self.keys[key_hash] = key_data
        self._save_keys()

        logger.info(f"✅ Generated new API key: {key_hash} for tier: {tier}")

        return {
            "api_key": raw_key,
            "key_id": key_hash,
            "tier": tier,
            "daily_limit": daily_limit,
            "expires_at": key_data["expires_at"]
        }

    def validate_key(self, api_key: str) -> Optional[Dict]:
        """Validate API key and return key data"""
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()[:16]

        if key_hash not in self.keys:
            return None

        key_data = self.keys[key_hash]

        # Check if active
        if not key_data.get("is_active", True):
            return None

        # Check expiration
        expires = datetime.fromisoformat(key_data["expires_at"])
        if datetime.now() > expires:
            return None

        # Check daily limit
        # Reset counter if new day
        last_used = key_data.get("last_used")
        if last_used:
            last_date = datetime.fromisoformat(last_used).date()
            if datetime.now().date() != last_date:
                key_data["used_today"] = 0

        if key_data["used_today"] >= key_data["daily_limit"]:
            return None

        return key_data

    def use_key(self, api_key: str):
        """Increment usage counter"""
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()[:16]
        if key_hash in self.keys:
            self.keys[key_hash]["used_today"] += 1
            self.keys[key_hash]["total_used"] += 1
            self.keys[key_hash]["last_used"] = datetime.now().isoformat()
            self._save_keys()

    def revoke_key(self, key_id: str) -> bool:
        """Revoke an API key"""
        if key_id in self.keys:
            self.keys[key_id]["is_active"] = False
            self._save_keys()
            return True
        return False

    def update_limit(self, key_id: str, new_limit: int) -> bool:
        """Update daily limit for a key"""
        if key_id in self.keys:
            self.keys[key_id]["daily_limit"] = new_limit
            self._save_keys()
            return True
        return False

    def get_all_keys(self) -> List[Dict]:
        """Get all keys (for admin)"""
        return list(self.keys.values())

    def get_key_stats(self, key_id: str) -> Optional[Dict]:
        """Get usage statistics for a key"""
        if key_id in self.keys:
            key = self.keys[key_id]
            return {
                "key_id": key_id,
                "tier": key["tier"],
                "used_today": key["used_today"],
                "daily_limit": key["daily_limit"],
                "total_used": key["total_used"],
                "is_active": key["is_active"],
                "created_at": key["created_at"],
                "expires_at": key["expires_at"]
            }
        return None

key_manager = APIKeyManager()
