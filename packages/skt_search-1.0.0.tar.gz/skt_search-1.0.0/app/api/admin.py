"""
Admin Panel for SKT Search API
Manage API keys, rate limits, and system settings
"""
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime
from fastapi import HTTPException

logger = logging.getLogger(__name__)

class AdminPanel:
    def __init__(self, key_manager):
        self.key_manager = key_manager
        self.admin_username = "admin"
        self.admin_password = "skt_admin_2024"

    def authenticate(self, username: str, password: str) -> bool:
        """Authenticate admin user"""
        return username == self.admin_username and password == self.admin_password

    def get_dashboard_stats(self) -> Dict:
        """Get system statistics"""
        keys = self.key_manager.get_all_keys()

        total_keys = len(keys)
        active_keys = sum(1 for k in keys if k.get("is_active", True))
        total_requests = sum(k.get("total_used", 0) for k in keys)

        tier_distribution = {}
        for k in keys:
            tier = k.get("tier", "fast")
            tier_distribution[tier] = tier_distribution.get(tier, 0) + 1

        return {
            "total_keys": total_keys,
            "active_keys": active_keys,
            "total_requests": total_requests,
            "tier_distribution": tier_distribution,
            "timestamp": datetime.now().isoformat()
        }

    def create_key(self, tier: str = "fast", owner: str = "", 
                   daily_limit: int = 5000) -> Dict:
        """Create new API key from admin panel"""
        return self.key_manager.generate_key(
            tier=tier,
            owner=owner,
            daily_limit=daily_limit
        )

    def revoke_key(self, key_id: str) -> bool:
        """Revoke an API key"""
        return self.key_manager.revoke_key(key_id)

    def update_key_limit(self, key_id: str, new_limit: int) -> bool:
        """Update rate limit for a key"""
        return self.key_manager.update_limit(key_id, new_limit)

    def get_all_keys_info(self) -> List[Dict]:
        """Get all keys with info"""
        return self.key_manager.get_all_keys()

    def get_key_details(self, key_id: str) -> Optional[Dict]:
        """Get detailed info about a key"""
        return self.key_manager.get_key_stats(key_id)

    def generate_html_dashboard(self) -> str:
        """Generate HTML admin dashboard"""
        stats = self.get_dashboard_stats()
        keys = self.get_all_keys_info()

        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>SKT Search API - Admin Panel</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; }}
        .header {{ background: linear-gradient(135deg, #1e3a5f, #0f172a); padding: 20px; text-align: center; }}
        .header h1 {{ color: #60a5fa; font-size: 28px; }}
        .header p {{ color: #94a3b8; margin-top: 5px; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0; }}
        .stat-card {{ background: #1e293b; border-radius: 12px; padding: 20px; border: 1px solid #334155; }}
        .stat-card h3 {{ color: #60a5fa; font-size: 14px; text-transform: uppercase; }}
        .stat-card .value {{ font-size: 32px; font-weight: bold; color: #fff; margin: 10px 0; }}
        .keys-table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        .keys-table th {{ background: #1e3a5f; padding: 12px; text-align: left; color: #60a5fa; }}
        .keys-table td {{ padding: 12px; border-bottom: 1px solid #334155; }}
        .keys-table tr:hover {{ background: #1e293b; }}
        .badge {{ padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }}
        .badge-fast {{ background: #22c55e; color: #000; }}
        .badge-thinking {{ background: #f59e0b; color: #000; }}
        .badge-pro {{ background: #ef4444; color: #fff; }}
        .btn {{ padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; }}
        .btn-danger {{ background: #ef4444; color: #fff; }}
        .btn-primary {{ background: #3b82f6; color: #fff; }}
        .form-group {{ margin: 15px 0; }}
        .form-group label {{ display: block; margin-bottom: 5px; color: #94a3b8; }}
        .form-group input, .form-group select {{ width: 100%; padding: 10px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #fff; }}
        .create-form {{ background: #1e293b; padding: 20px; border-radius: 12px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔍 SKT Search API - Admin Panel</h1>
        <p>Developed by SKT AI LABS, India | Vision: Sir Shrijan Kumar Tiwari</p>
    </div>

    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total API Keys</h3>
                <div class="value">{stats['total_keys']}</div>
            </div>
            <div class="stat-card">
                <h3>Active Keys</h3>
                <div class="value">{stats['active_keys']}</div>
            </div>
            <div class="stat-card">
                <h3>Total Requests</h3>
                <div class="value">{stats['total_requests']:,}</div>
            </div>
            <div class="stat-card">
                <h3>Fast / Thinking / Pro</h3>
                <div class="value" style="font-size: 18px;">
                    {stats['tier_distribution'].get('fast', 0)} / 
                    {stats['tier_distribution'].get('thinking', 0)} / 
                    {stats['tier_distribution'].get('pro', 0)}
                </div>
            </div>
        </div>

        <div class="create-form">
            <h2 style="color: #60a5fa; margin-bottom: 15px;">➕ Create New API Key</h2>
            <form action="/admin/create-key" method="post">
                <div class="form-group">
                    <label>Tier</label>
                    <select name="tier">
                        <option value="fast">Fast (Free - 5000/day)</option>
                        <option value="thinking">Thinking (Free - 100/day)</option>
                        <option value="pro">Pro (Paid - Unlimited)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Owner</label>
                    <input type="text" name="owner" placeholder="Enter owner name">
                </div>
                <div class="form-group">
                    <label>Daily Limit</label>
                    <input type="number" name="daily_limit" value="5000">
                </div>
                <button type="submit" class="btn btn-primary">Generate Key</button>
            </form>
        </div>

        <h2 style="color: #60a5fa; margin: 20px 0;">🔑 All API Keys</h2>
        <table class="keys-table">
            <thead>
                <tr>
                    <th>Key ID</th>
                    <th>Tier</th>
                    <th>Owner</th>
                    <th>Used Today</th>
                    <th>Limit</th>
                    <th>Total Used</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
        """

        for key in keys:
            tier = key.get('tier', 'fast')
            badge_class = f"badge-{tier}"
            status = "Active" if key.get('is_active', True) else "Revoked"
            status_color = "#22c55e" if key.get('is_active', True) else "#ef4444"

            html += f"""
                <tr>
                    <td>{key.get('key_id', '')[:12]}...</td>
                    <td><span class="badge {badge_class}">{tier.upper()}</span></td>
                    <td>{key.get('owner', 'N/A')}</td>
                    <td>{key.get('used_today', 0)}</td>
                    <td>{key.get('daily_limit', 0)}</td>
                    <td>{key.get('total_used', 0):,}</td>
                    <td style="color: {status_color};">{status}</td>
                    <td>{key.get('created_at', '')[:10]}</td>
                    <td>
                        <form action="/admin/revoke-key" method="post" style="display: inline;">
                            <input type="hidden" name="key_id" value="{key.get('key_id', '')}">
                            <button type="submit" class="btn btn-danger">Revoke</button>
                        </form>
                    </td>
                </tr>
            """

        html += """
            </tbody>
        </table>
    </div>
</body>
</html>
        """
        return html

# Admin panel instance (initialized with key_manager in main.py)
admin_panel = None
