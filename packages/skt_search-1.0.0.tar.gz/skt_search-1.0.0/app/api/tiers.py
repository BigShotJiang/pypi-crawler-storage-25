"""
Tier Management System
Fast (Free 5000/day), Thinking, Pro (Paid/Unlimited)
"""
from typing import Dict, Optional
from enum import Enum

class SearchMode(Enum):
    FAST = "fast"
    THINKING = "thinking"
    PRO = "pro"

TIER_CONFIG = {
    SearchMode.FAST: {
        "name": "Fast Search",
        "description": "Quick results with basic summarization",
        "daily_limit": 5000,
        "max_results": 10,
        "scrape_depth": 1,
        "model": "microsoft/phi-2",
        "features": ["web_search", "basic_summary", "source_links"],
        "price": 0,  # Free
        "is_paid": False
    },
    SearchMode.THINKING: {
        "name": "Thinking Search",
        "description": "Deep analysis with reasoning",
        "daily_limit": 100,
        "max_results": 15,
        "scrape_depth": 2,
        "model": "Qwen/Qwen2.5-0.5B-Instruct",
        "features": [
            "web_search", 
            "deep_analysis", 
            "source_links",
            "follow_up_questions",
            "related_searches",
            "content_scraping"
        ],
        "price": 0,  # Free but limited
        "is_paid": False
    },
    SearchMode.PRO: {
        "name": "Pro Search",
        "description": "Unlimited access with best models",
        "daily_limit": float('inf'),  # Unlimited
        "max_results": 20,
        "scrape_depth": 3,
        "model": "meta-llama/Llama-3.2-1B-Instruct",
        "features": [
            "web_search",
            "deep_analysis",
            "source_links",
            "follow_up_questions",
            "related_searches",
            "content_scraping",
            "image_search",
            "news_search",
            "unlimited_requests",
            "priority_support"
        ],
        "price": 999,  # INR per month (example)
        "is_paid": True
    }
}

def get_tier_config(mode: str) -> Optional[Dict]:
    """Get configuration for a search mode"""
    try:
        search_mode = SearchMode(mode.lower())
        return TIER_CONFIG[search_mode]
    except ValueError:
        return TIER_CONFIG[SearchMode.FAST]

def get_all_tiers() -> Dict:
    """Get all tier configurations"""
    return {mode.value: config for mode, config in TIER_CONFIG.items()}

def check_tier_access(api_key_data: Dict, requested_mode: str) -> tuple:
    """Check if API key has access to requested mode"""
    key_tier = api_key_data.get("tier", "fast")

    tier_hierarchy = {"fast": 1, "thinking": 2, "pro": 3}

    requested_level = tier_hierarchy.get(requested_mode.lower(), 1)
    key_level = tier_hierarchy.get(key_tier.lower(), 1)

    if key_level >= requested_level:
        return True, get_tier_config(requested_mode)
    else:
        return False, get_tier_config(key_tier)
