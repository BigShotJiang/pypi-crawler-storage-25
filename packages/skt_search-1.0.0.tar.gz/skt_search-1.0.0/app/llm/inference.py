"""
LLM Inference Engine
Uses HuggingFace Inference API (Free Tier)
"""
import os
import logging
from typing import Dict
import requests
from .models import get_model_for_mode

logger = logging.getLogger(__name__)

HF_API_URL = "https://api-inference.huggingface.co/models/"

class InferenceEngine:
    def __init__(self):
        self.token = os.getenv("HF_TOKEN", "")
        self.timeout = 60

    def _get_headers(self) -> Dict:
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        return headers

    def generate(self, prompt: str, mode: str = "fast", system_prompt: str = "") -> Dict:
        model_config = get_model_for_mode(mode)
        model_name = model_config["name"]

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        formatted_prompt = self._format_prompt(messages, model_name)

        payload = {
            "inputs": formatted_prompt,
            "parameters": {
                "max_new_tokens": model_config["max_tokens"],
                "temperature": model_config["temperature"],
                "return_full_text": False,
                "do_sample": True
            }
        }

        try:
            response = requests.post(
                HF_API_URL + model_name,
                headers=self._get_headers(),
                json=payload,
                timeout=self.timeout
            )

            if response.status_code == 200:
                result = response.json()
                if isinstance(result, list) and len(result) > 0:
                    generated_text = result[0].get('generated_text', '')
                    return {
                        "success": True,
                        "text": generated_text,
                        "model": model_name,
                        "mode": mode
                    }

            elif response.status_code == 503:
                logger.warning("Model " + model_name + " is loading...")
                return {
                    "success": False,
                    "error": "Model is loading. Please retry in a few seconds.",
                    "model": model_name
                }
            else:
                logger.error("API Error " + str(response.status_code) + ": " + response.text)

        except requests.exceptions.Timeout:
            logger.error("Request timeout")
            return {
                "success": False,
                "error": "Request timeout. Model may be busy.",
                "model": model_name
            }
        except Exception as e:
            logger.error("Inference error: " + str(e))

        fallback = model_config.get("fallback")
        if fallback and fallback != model_name:
            logger.info("Trying fallback model: " + fallback)
            return self._try_fallback(prompt, fallback, mode, system_prompt)

        return {
            "success": False,
            "error": "All models failed. Please try again later.",
            "model": model_name
        }

    def _try_fallback(self, prompt: str, model_name: str, mode: str, system_prompt: str) -> Dict:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        formatted_prompt = self._format_prompt(messages, model_name)

        payload = {
            "inputs": formatted_prompt,
            "parameters": {
                "max_new_tokens": 512,
                "temperature": 0.7,
                "return_full_text": False
            }
        }

        try:
            response = requests.post(
                HF_API_URL + model_name,
                headers=self._get_headers(),
                json=payload,
                timeout=self.timeout
            )

            if response.status_code == 200:
                result = response.json()
                if isinstance(result, list) and len(result) > 0:
                    return {
                        "success": True,
                        "text": result[0].get('generated_text', ''),
                        "model": model_name,
                        "mode": mode,
                        "fallback": True
                    }
        except Exception as e:
            logger.error("Fallback failed: " + str(e))

        return {
            "success": False,
            "error": "All models unavailable.",
            "model": model_name
        }

    def _format_prompt(self, messages: list, model_name: str) -> str:
        formatted = ""
        newline = chr(10)

        for msg in messages:
            role = msg["role"]
            content_text = msg["content"]

            if "llama" in model_name.lower():
                tag = "<|" + role + "|>" + newline
                formatted += tag + content_text + newline

            elif "qwen" in model_name.lower():
                tag = "<|im_start|>" + role + newline
                formatted += tag + content_text + newline

            else:
                formatted += role + ": " + content_text + newline

        if "llama" in model_name.lower():
            formatted += "<|assistant|>" + newline
        elif "qwen" in model_name.lower():
            formatted += "<|im_start|>assistant" + newline
        else:
            formatted += "assistant: "

        return formatted

inference = InferenceEngine()
