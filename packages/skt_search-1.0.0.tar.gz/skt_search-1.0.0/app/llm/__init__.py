"""
LLM modules
"""
from .models import get_model_for_mode, get_all_models
from .inference import inference
