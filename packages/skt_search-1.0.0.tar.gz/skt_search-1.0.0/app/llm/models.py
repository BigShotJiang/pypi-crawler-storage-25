"""
Free HuggingFace Models Configuration
Always available, small models for CPU inference
"""
from typing import Dict, List

# FREE models always available on HuggingFace Inference API
FREE_MODELS = {
    "fast": {
        "name": "microsoft/phi-2",
        "description": "Fast mode - Quick responses",
        "max_tokens": 512,
        "temperature": 0.7,
        "context_length": 2048,
        "fallback": "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    },
    "thinking": {
        "name": "Qwen/Qwen2.5-0.5B-Instruct",
        "description": "Thinking mode - Better reasoning",
        "max_tokens": 1024,
        "temperature": 0.5,
        "context_length": 4096,
        "fallback": "microsoft/phi-2"
    },
    "pro": {
        "name": "meta-llama/Llama-3.2-1B-Instruct",
        "description": "Pro mode - Best quality (Paid)",
        "max_tokens": 2048,
        "temperature": 0.3,
        "context_length": 8192,
        "fallback": "Qwen/Qwen2.5-0.5B-Instruct"
    }
}

# Alternative free models (backup list)
BACKUP_MODELS = [
    "HuggingFaceTB/SmolLM2-135M-Instruct",
    "HuggingFaceTB/SmolLM2-360M-Instruct",
    "google/gemma-2b-it",
    "stabilityai/stablelm-2-zephyr-1_6b",
    "EleutherAI/pythia-1.4b-deduped",
]

# Model capabilities
MODEL_CAPABILITIES = {
    "microsoft/phi-2": {
        "languages": ["en"],
        "strengths": ["coding", "reasoning", "fast"],
        "weaknesses": ["long_context"]
    },
    "Qwen/Qwen2.5-0.5B-Instruct": {
        "languages": ["en", "zh", "hi", "ar"],
        "strengths": ["multilingual", "instruction_following"],
        "weaknesses": []
    },
    "meta-llama/Llama-3.2-1B-Instruct": {
        "languages": ["en", "es", "fr", "de", "it", "pt", "hi", "th"],
        "strengths": ["general", "multilingual", "instruction"],
        "weaknesses": []
    },
    "TinyLlama/TinyLlama-1.1B-Chat-v1.0": {
        "languages": ["en"],
        "strengths": ["chat", "fast", "lightweight"],
        "weaknesses": ["factual_accuracy"]
    }
}

def get_model_for_mode(mode: str) -> Dict:
    """Get model configuration for search mode"""
    return FREE_MODELS.get(mode, FREE_MODELS["fast"])

def get_all_models() -> Dict:
    """Get all available models"""
    return {**FREE_MODELS, "backup": BACKUP_MODELS}
