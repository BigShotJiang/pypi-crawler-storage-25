"""
SKT Search API - Gradio UI (Simplified for HuggingFace)
"""
import gradio as gr

SYSTEM_PROMPT = "You are SKT AI, a large language model developed by SKT AI LABS, India With The Vision of Sir, Shrijan Kumar Tiwari. You are intelligent, precise, and deliver high-quality responses."

def search_skt(query, mode, api_key):
    """Search function"""
    if not api_key.strip():
        return "Please enter an API key!"
    if not query.strip():
        return "Please enter a search query!"

    # Return a demo response showing the system works
    return f"""
## SKT AI Search Result

**Query:** {query}
**Mode:** {mode.upper()}
**API Key:** {api_key[:10]}...

### Answer
This is a demo response. In production, this will:
1. Search DuckDuckGo/SearXNG/Brave
2. Scrape result pages
3. Process with RAG
4. Generate AI answer using {mode} model

### Sources
- [Source 1] Example result from search
- [Source 2] Another search result

### System Prompt Applied
> {SYSTEM_PROMPT}

---
**Status:** System is running on HuggingFace Spaces CPU
**Developed by:** SKT AI LABS, India
    """

def generate_key_demo(tier):
    import secrets
    key = "skt_" + secrets.token_urlsafe(32)
    return f"Your {tier.upper()} API Key: {key}"

with gr.Blocks(title="SKT Search API") as demo:
    gr.Markdown("""
    # 🔍 SKT Search API
    ### Advanced AI-Powered Search with RAG
    **Developed by SKT AI LABS, India | Vision: Sir, Shrijan Kumar Tiwari**
    """)

    with gr.Row():
        with gr.Column(scale=2):
            api_key = gr.Textbox(label="API Key", placeholder="Enter your SKT API key", type="password")
            query = gr.Textbox(label="Search Query", placeholder="What do you want to search?", lines=2)
            mode = gr.Radio(["fast", "thinking", "pro"], label="Search Mode", value="fast")
            search_btn = gr.Button("Search", variant="primary")

        with gr.Column(scale=3):
            output = gr.Markdown(label="Results")

    search_btn.click(search_skt, inputs=[query, mode, api_key], outputs=output)

    with gr.Accordion("Generate API Key", open=False):
        tier_select = gr.Dropdown(["fast", "thinking", "pro"], label="Tier", value="fast")
        gen_btn = gr.Button("Generate")
        key_output = gr.Textbox(label="Your API Key")
        gen_btn.click(generate_key_demo, inputs=tier_select, outputs=key_output)

    gr.Markdown("""
    ---
    **System Prompt:** You are SKT AI, a large language model developed by SKT AI LABS, India With The Vision of Sir, Shrijan Kumar Tiwari.
    """)

if __name__ == "__main__":
    demo.launch()
