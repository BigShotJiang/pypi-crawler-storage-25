"""
SKT Search API Package
Developed by SKT AI LABS, India
"""
__version__ = "1.0.0"
