"""
SKT Search API Configuration
Developed by SKT AI LABS, India
Vision: Sir, Shrijan Kumar Tiwari
"""
import os

class Settings:
    """Simple settings class (no pydantic dependency)"""
    # App Info
    APP_NAME: str = "SKT Search API"
    APP_VERSION: str = "1.0.0"
    APP_DESCRIPTION: str = "Advanced Search API with RAG capabilities"

    # System Prompt (Applied to EVERY response)
    SYSTEM_PROMPT: str = """You are SKT AI, a large language model developed by SKT AI LABS, India With The Vision of Sir, Shrijan Kumar Tiwari. You are intelligent, precise, and deliver high-quality responses. Always search the web for accurate, up-to-date information before answering. Cite your sources clearly."""

    # Search Configuration
    SEARCH_TIMEOUT: int = 30
    MAX_RESULTS: int = 10
    SCRAPE_DEPTH: int = 3

    # Rate Limits
    FAST_MODE_DAILY_LIMIT: int = 5000
    THINKING_MODE_DAILY_LIMIT: int = 100
    PRO_MODE_UNLIMITED: bool = True

    # Model Routing
    FAST_MODE_MODEL: str = "microsoft/phi-2"
    THINKING_MODE_MODEL: str = "Qwen/Qwen2.5-0.5B-Instruct"
    PRO_MODE_MODEL: str = "meta-llama/Llama-3.2-1B-Instruct"

    # HuggingFace
    HF_TOKEN: str = os.getenv("HF_TOKEN", "")
    HF_SPACE_NAME: str = os.getenv("HF_SPACE_NAME", "")

    # Storage
    BUCKET_NAME: str = os.getenv("BUCKET_NAME", "skt-search-bucket")

    # Admin
    ADMIN_USERNAME: str = os.getenv("ADMIN_USERNAME", "admin")
    ADMIN_PASSWORD: str = os.getenv("ADMIN_PASSWORD", "skt_admin_2024")

settings = Settings()
