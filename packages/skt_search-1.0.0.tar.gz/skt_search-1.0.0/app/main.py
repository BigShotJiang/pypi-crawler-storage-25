"""
SKT Search API - Main Application
FastAPI backend with all endpoints
"""
import os
import logging
from typing import Optional, Dict, List
from datetime import datetime

from fastapi import FastAPI, HTTPException, Depends, Header, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Import modules
from .config import settings
from .search.duckduckgo import ddg_search
from .search.searxng import searxng_search
from .search.scraper import scraper
from .search.aggregator import aggregator
from .rag.processor import rag_processor
from .llm.inference import inference
from .api.keys import key_manager
from .api.tiers import get_tier_config, check_tier_access
from .api.admin import AdminPanel
from .storage.bucket import bucket

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize admin panel
admin_panel = AdminPanel(key_manager)

# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=settings.APP_DESCRIPTION
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request Models
class SearchRequest(BaseModel):
    query: str
    mode: str = "fast"  # fast, thinking, pro
    max_results: int = 10
    region: str = "wt-wt"
    include_scraping: bool = True

class GenerateRequest(BaseModel):
    prompt: str
    mode: str = "fast"
    max_tokens: int = 512

# Dependency to validate API key
async def verify_api_key(x_api_key: str = Header(...)):
    """Verify API key from header"""
    if not x_api_key:
        raise HTTPException(status_code=401, detail="API key required")

    key_data = key_manager.validate_key(x_api_key)
    if not key_data:
        raise HTTPException(status_code=403, detail="Invalid or expired API key")

    return key_data

# Health check
@app.get("/")
async def root():
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "system_prompt": settings.SYSTEM_PROMPT
    }

@app.get("/health")
async def health():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Search endpoint
@app.post("/api/search")
async def search(request: SearchRequest, api_key_data: Dict = Depends(verify_api_key)):
    """
    Main search endpoint with RAG
    """
    # Check tier access
    has_access, tier_config = check_tier_access(api_key_data, request.mode)

    if not has_access:
        raise HTTPException(
            status_code=403, 
            detail=f"Your key tier ({api_key_data['tier']}) doesn't support {request.mode} mode"
        )

    # Check rate limit
    if api_key_data["used_today"] >= api_key_data["daily_limit"]:
        raise HTTPException(status_code=429, detail="Daily rate limit exceeded")

    # Increment usage
    key_manager.use_key(api_key_data.get("full_key", ""))

    query = request.query
    mode = request.mode
    max_results = min(request.max_results, tier_config["max_results"])

    logger.info(f"🔍 Search: '{query}' | Mode: {mode} | Key: {api_key_data['key_id'][:8]}...")

    # 1. Search multiple sources
    all_results = []

    # DuckDuckGo (primary)
    ddg_results = ddg_search.search(query, max_results=max_results)
    all_results.append(ddg_results)

    # SearXNG (fallback)
    if len(ddg_results) < max_results:
        searx_results = searxng_search.search(query, max_results=max_results)
        all_results.append(searx_results)

    # 2. Aggregate results
    aggregated = aggregator.aggregate(all_results, max_results=max_results)

    # 3. Scrape content if enabled
    if request.include_scraping and tier_config.get("scrape_depth", 0) > 0:
        urls = [r["url"] for r in aggregated if r.get("url")]
        scraped = scraper.scrape_multiple(urls, max_pages=tier_config["scrape_depth"])

        # Enrich results with scraped content
        for i, result in enumerate(aggregated):
            if i < len(scraped) and scraped[i].get("status") == 200:
                result["full_content"] = scraped[i].get("content", "")[:2000]
                result["page_title"] = scraped[i].get("title", "")

    # 4. Process with RAG
    rag_context = rag_processor.process_results(aggregated, query)

    # 5. Generate AI answer
    system_prompt = settings.SYSTEM_PROMPT

    prompt = f"""Based on the following search results, provide a comprehensive answer to the query.

Query: {query}

Search Results:
{rag_context['context']}

Please provide a detailed, accurate answer with citations to the sources. Be precise and helpful."""

    ai_response = inference.generate(prompt, mode=mode, system_prompt=system_prompt)

    # 6. Generate extras
    follow_ups = rag_processor.generate_follow_up_questions(query, rag_context["context"])
    related = rag_processor.generate_related_searches(query)

    # 7. Save to bucket
    bucket.save_search_result(query, {
        "query": query,
        "mode": mode,
        "results": aggregated,
        "ai_answer": ai_response.get("text", ""),
        "timestamp": datetime.now().isoformat()
    })

    return {
        "query": query,
        "mode": mode,
        "answer": ai_response.get("text", ""),
        "sources": rag_context["sources"],
        "follow_up_questions": follow_ups,
        "related_searches": related,
        "model_used": ai_response.get("model", ""),
        "total_results": len(aggregated),
        "remaining_quota": api_key_data["daily_limit"] - api_key_data["used_today"],
        "system_prompt_applied": True
    }

# Simple search (no AI)
@app.get("/api/search/simple")
async def simple_search(
    q: str, 
    max_results: int = 10,
    x_api_key: str = Header(...)
):
    """Simple search without AI processing"""
    api_key_data = key_manager.validate_key(x_api_key)
    if not api_key_data:
        raise HTTPException(status_code=403, detail="Invalid API key")

    key_manager.use_key(x_api_key)

    results = ddg_search.search(q, max_results=max_results)
    return {"query": q, "results": results, "count": len(results)}

# Generate text endpoint
@app.post("/api/generate")
async def generate_text(request: GenerateRequest, api_key_data: Dict = Depends(verify_api_key)):
    """Generate text with AI"""
    key_manager.use_key(api_key_data.get("full_key", ""))

    response = inference.generate(
        request.prompt, 
        mode=request.mode,
        system_prompt=settings.SYSTEM_PROMPT
    )

    return {
        "text": response.get("text", ""),
        "model": response.get("model", ""),
        "mode": request.mode,
        "success": response.get("success", False)
    }

# API Key Management
@app.post("/api/keys/generate")
async def generate_api_key(
    tier: str = "fast",
    owner: str = "",
    daily_limit: int = 5000,
    admin_user: str = Form(...),
    admin_pass: str = Form(...)
):
    """Generate new API key (admin only)"""
    if not admin_panel.authenticate(admin_user, admin_pass):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")

    return key_manager.generate_key(tier=tier, owner=owner, daily_limit=daily_limit)

@app.get("/api/keys/stats")
async def get_key_stats(
    key_id: str,
    admin_user: str = Form(...),
    admin_pass: str = Form(...)
):
    """Get key statistics"""
    if not admin_panel.authenticate(admin_user, admin_pass):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")

    stats = key_manager.get_key_stats(key_id)
    if not stats:
        raise HTTPException(status_code=404, detail="Key not found")
    return stats

# Admin Dashboard
@app.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(
    username: str = Form(...),
    password: str = Form(...)
):
    """Admin HTML dashboard"""
    if not admin_panel.authenticate(username, password):
        return HTMLResponse(content="<h1>Unauthorized</h1>", status_code=401)

    return HTMLResponse(content=admin_panel.generate_html_dashboard())

@app.post("/admin/create-key")
async def admin_create_key(
    tier: str = Form(...),
    owner: str = Form(""),
    daily_limit: int = Form(5000),
    username: str = Form(...),
    password: str = Form(...)
):
    """Create key from admin panel"""
    if not admin_panel.authenticate(username, password):
        return HTMLResponse(content="<h1>Unauthorized</h1>", status_code=401)

    key = key_manager.generate_key(tier=tier, owner=owner, daily_limit=daily_limit)
    return JSONResponse(content={"api_key": key["api_key"], "tier": tier})

@app.post("/admin/revoke-key")
async def admin_revoke_key(
    key_id: str = Form(...),
    username: str = Form(...),
    password: str = Form(...)
):
    """Revoke key from admin panel"""
    if not admin_panel.authenticate(username, password):
        return HTMLResponse(content="<h1>Unauthorized</h1>", status_code=401)

    success = key_manager.revoke_key(key_id)
    return JSONResponse(content={"success": success})

# Tier info
@app.get("/api/tiers")
async def get_tiers():
    """Get all tier information"""
    from .api.tiers import get_all_tiers
    return get_all_tiers()

# Scrape endpoint
@app.get("/api/scrape")
async def scrape_url(
    url: str,
    x_api_key: str = Header(...)
):
    """Scrape a specific URL"""
    api_key_data = key_manager.validate_key(x_api_key)
    if not api_key_data:
        raise HTTPException(status_code=403, detail="Invalid API key")

    key_manager.use_key(x_api_key)

    result = scraper.scrape_page(url)
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7860)
