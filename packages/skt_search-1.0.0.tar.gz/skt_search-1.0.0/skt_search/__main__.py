"""
Run SKT Search API: python -m skt_search
"""
import os
import sys
import argparse

def main():
    parser = argparse.ArgumentParser(description="SKT Search API")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind")
    parser.add_argument("--port", type=int, default=7860, help="Port to bind")
    parser.add_argument("--mode", choices=["fast", "thinking", "pro"], default="fast", help="Search mode")
    parser.add_argument("--query", help="Search query (CLI mode)")
    parser.add_argument("--api-key", help="API key for search")
    parser.add_argument("--ui", action="store_true", help="Launch Gradio UI")
    parser.add_argument("--generate-key", action="store_true", help="Generate API key")
    parser.add_argument("--tier", choices=["fast", "thinking", "pro"], default="fast", help="Key tier")

    args = parser.parse_args()

    if args.generate_key:
        from skt_search.api.keys import key_manager
        key_data = key_manager.generate_key(tier=args.tier, owner="cli")
        print("=" * 60)
        print("SKT SEARCH API - NEW KEY GENERATED")
        print("=" * 60)
        print("API Key: " + key_data["api_key"])
        print("Tier: " + key_data["tier"])
        print("Daily Limit: " + str(key_data["daily_limit"]))
        print("=" * 60)
        print("WARNING: Save this key now! It will not be shown again.")
        return

    if args.query:
        # CLI search mode
        print("SKT Search API - CLI Mode")
        print("Query: " + args.query)
        print("Mode: " + args.mode)
        print("-" * 60)

        from skt_search.search.duckduckgo import ddg_search
        from skt_search.rag.processor import rag_processor
        from skt_search.llm.inference import inference
        from skt_search.config import settings

        results = ddg_search.search(args.query)
        print("Found " + str(len(results)) + " results")

        if results:
            rag_context = rag_processor.process_results(results, args.query)

            prompt = "Based on these search results, answer: " + args.query + "

" + rag_context["context"]
            response = inference.generate(prompt, mode=args.mode, system_prompt=settings.SYSTEM_PROMPT)

            print("
" + "=" * 60)
            print("ANSWER:")
            print("=" * 60)
            print(response.get("text", "No response"))
            print("
Sources:")
            for s in rag_context["sources"]:
                print("[" + str(s["index"]) + "] " + s["title"] + " - " + s["url"])
        return

    if args.ui:
        # Launch Gradio UI
        print("Starting SKT Search API - Gradio UI...")
        from skt_search.ui.gradio_app import demo
        demo.launch(server_name=args.host, server_port=args.port, share=False)
        return

    # Default: launch FastAPI
    print("Starting SKT Search API - FastAPI...")
    print("Developed by SKT AI LABS, India")
    print("Vision: Sir, Shrijan Kumar Tiwari")
    print("-" * 60)

    import uvicorn
    from skt_search.main import app
    uvicorn.run(app, host=args.host, port=args.port)

if __name__ == "__main__":
    main()
