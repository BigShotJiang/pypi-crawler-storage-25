"""
CLI Entry Point for SKT Search API
Usage: skt-search [options]
"""
from .__main__ import main

def cli_main():
    main()
