"""
SKT Search API - Complete Search & RAG Package
Developed by SKT AI LABS, India
Vision: Sir, Shrijan Kumar Tiwari

Usage:
    import skt_search
    app = skt_search.create_app()

    # Or run directly:
    python -m skt_search

    # Or use CLI:
    skt-search --mode fast --query "Python tutorial"
"""
__version__ = "1.0.0"
__author__ = "SKT AI LABS"

# Core exports
from .config import settings
from .search.duckduckgo import ddg_search
from .search.searxng import searxng_search
from .search.brave import brave_search
from .search.scraper import scraper
from .search.aggregator import aggregator
from .rag.processor import rag_processor
from .llm.models import get_model_for_mode, get_all_models
from .llm.inference import inference
from .api.keys import key_manager
from .api.tiers import get_tier_config, check_tier_access, SearchMode
from .storage.bucket import bucket

def create_app():
    """Create FastAPI application instance"""
    from .main import app
    return app

def create_gradio_app():
    """Create Gradio UI instance"""
    from .ui.gradio_app import demo
    return demo

# System prompt applied to every response
SYSTEM_PROMPT = """You are SKT AI, a large language model developed by SKT AI LABS, India With The Vision of Sir, Shrijan Kumar Tiwari. You are intelligent, precise, and deliver high-quality responses. Always search the web for accurate, up-to-date information before answering. Cite your sources clearly."""
