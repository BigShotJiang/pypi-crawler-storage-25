"""
SKT Search API - Setup
pip install skt-search
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="skt-search",
    version="1.0.0",
    author="SKT AI LABS",
    author_email="contact@sktailabs.in",
    description="Advanced Search API with RAG capabilities - Developed by SKT AI LABS, India",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://huggingface.co/spaces/sktailabs/skt-search",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "fastapi>=0.109.0",
        "uvicorn>=0.27.0",
        "pydantic>=2.5.0",
        "python-multipart>=0.0.6",
        "duckduckgo-search>=4.4.3",
        "requests>=2.31.0",
        "beautifulsoup4>=4.12.3",
        "lxml>=5.1.0",
        "gradio>=4.16.0",
        "httpx>=0.26.0",
        "aiohttp>=3.9.3",
        "huggingface-hub>=0.20.3",
        "numpy>=1.26.3",
        "pandas>=2.2.0",
        "python-dotenv>=1.0.0",
        "jinja2>=3.1.3",
        "fake-useragent>=1.4.0",
    ],
    entry_points={
        "console_scripts": [
            "skt-search=skt_search.cli:cli_main",
        ],
    },
)
