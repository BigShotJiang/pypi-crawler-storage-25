# agentidentity_1

Python SDK for the [Agent Identity Systems](https://agentidentity_1.io) API.

## Install

```bash
pip install agentidentity_1
```

## Quickstart

```python
from agentidentity_1 import AISClient, RegisterAgentInput

ais = AISClient(base_url="https://api.agentidentity_1.io")

# Register a new agent (plaintext key returned once)
resp = ais.register(RegisterAgentInput(
    name="my-agent",
    risk_tier="TIER_1",
    owner_id="org-abc123",
))
print("Agent ID:", resp.agent.id)
print("API Key (store securely):", resp.api_key)

# Verify authorization
result = ais.verify(resp.agent.id)
print("Authorized:", result.authorized)   # True
print("Query time:", result.query_ms, "ms")

# Get agent + credential summaries (no plaintext)
agent_resp = ais.get_agent(resp.agent.id)
cred = agent_resp.credentials[0]

# Revoke a credential
ais.revoke_credential(resp.agent.id, cred.id, revoke_reason="rotating keys")

# Authorized is now False
after = ais.verify(resp.agent.id)
print("Authorized after revoke:", after.authorized)  # False
```

## Context manager

```python
with AISClient(base_url="https://api.agentidentity_1.io") as ais:
    result = ais.verify(agent_id)
```

## Error handling

```python
from agentidentity_1 import AISClient, AISError

try:
    ais.verify("does-not-exist")
except AISError as e:
    print(e.status, e.body["error"])  # 404 agent not found
```

## Requirements

- Python 3.10+
- [httpx](https://www.python-httpx.org/) ≥ 0.27
