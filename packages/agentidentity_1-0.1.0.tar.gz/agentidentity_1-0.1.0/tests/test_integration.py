"""
Integration tests for agentidentity_1 Python SDK.
Runs against a live ais-api at AIS_API_URL (default: http://localhost:3001).
"""
import os
import pytest
from agentidentity_1 import AISClient, AISError, RegisterAgentInput

BASE_URL = os.environ.get("AIS_API_URL", "http://localhost:3001")


@pytest.fixture(scope="module")
def client():
    with AISClient(base_url=BASE_URL) as c:
        yield c


@pytest.fixture(scope="module")
def registered(client):
    """Register a test agent once for the whole module."""
    return client.register(RegisterAgentInput(
        name="py-sdk-integration-agent",
        description="Python SDK integration test",
        risk_tier="TIER_2",
        owner_id="py-sdk-test-suite",
    ))


def test_register(registered):
    assert registered.agent.status    == "active"
    assert registered.agent.risk_tier == "TIER_2"
    assert registered.api_key.startswith("ais_live_")
    assert len(registered.warning) > 0
    print(f"\n       agentId={registered.agent.id}")
    print(f"       api_key={registered.api_key[:18]}...")


def test_verify_authorized(client, registered):
    resp = client.verify(registered.agent.id)
    assert resp.verified   is True
    assert resp.authorized is True
    assert resp.query_ms   < 500
    assert resp.credential is not None
    assert resp.audit_chain is not None
    print(f"\n       authorized={resp.authorized} query_ms={resp.query_ms}")


def test_get_agent(client, registered):
    resp = client.get_agent(registered.agent.id)
    assert resp.agent.id == registered.agent.id
    assert resp.agent.name == "py-sdk-integration-agent"
    assert len(resp.credentials) == 1
    assert resp.credentials[0].revoked is False
    assert resp.credentials[0].prefix is not None


def test_verify_unknown_agent_returns_404(client):
    with pytest.raises(AISError) as exc_info:
        client.verify("00000000-0000-0000-0000-999999999999")
    assert exc_info.value.status == 404


def test_revoke_and_verify(client, registered):
    # Get the live credential row id
    agent_resp = client.get_agent(registered.agent.id)
    cred_id    = agent_resp.credentials[0].id

    revoke = client.revoke_credential(
        registered.agent.id,
        credential_id=cred_id,
        revoke_reason="py-sdk integration test cleanup",
    )
    assert revoke.revoked  is True
    assert revoke.agent_id == registered.agent.id
    assert revoke.revoked_at is not None
    print(f"\n       revoked_at={revoke.revoked_at}")

    # Verify authorized=False after revoke
    verify = client.verify(registered.agent.id)
    assert verify.authorized is False
    assert verify.credential is None
    print(f"       authorized={verify.authorized} ✓")
