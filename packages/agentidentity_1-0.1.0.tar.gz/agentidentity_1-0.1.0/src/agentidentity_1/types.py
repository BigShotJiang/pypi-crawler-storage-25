"""Shared type definitions for the agentidentity_1 SDK."""
from __future__ import annotations
from dataclasses import dataclass, field


# ── Enums (plain strings — validated server-side) ────────────────────────────

RiskTier      = str  # 'TIER_1' | 'TIER_2' | 'TIER_3' | 'TIER_4'
AgentStatus   = str  # 'active' | 'suspended' | 'decommissioned'
CredentialType = str  # 'jwt' | 'cert' | 'api_key' | 'mtls'


# ── Domain objects ────────────────────────────────────────────────────────────

@dataclass
class Agent:
    id:          str
    name:        str
    status:      AgentStatus
    risk_tier:   RiskTier
    created_at:  str
    description: str | None        = None
    fingerprint: str | None        = None
    owner_id:    str | None        = None
    metadata:    dict              = field(default_factory=dict)
    updated_at:  str | None        = None


@dataclass
class CredentialSummary:
    id:         str
    type:       CredentialType
    issued_at:  str
    revoked:    bool
    prefix:     str | None = None
    expires_at: str | None = None


# ── Request inputs ────────────────────────────────────────────────────────────

@dataclass
class RegisterAgentInput:
    name:        str
    description: str | None              = None
    risk_tier:   RiskTier                = 'TIER_1'
    owner_id:    str | None              = None
    metadata:    dict                    = field(default_factory=dict)


# ── Response types ────────────────────────────────────────────────────────────

@dataclass
class IssuedCredential:
    type:       str
    prefix:     str
    api_key_id: str
    scopes:     list[str]
    issued_at:  str
    expires_at: str | None


@dataclass
class RegisterAgentResponse:
    agent:      Agent
    credential: IssuedCredential
    api_key:    str   # plaintext — returned once, never stored server-side
    warning:    str


@dataclass
class GetAgentResponse:
    agent:       Agent
    credentials: list[CredentialSummary]


@dataclass
class VerifyCredential:
    id:               str
    type:             CredentialType
    issued_at:        str
    revoked:          bool
    cert_fingerprint: str | None = None
    expires_at:       str | None = None


@dataclass
class AuditChain:
    stub:     bool
    entries:  int
    chain_id: str | None = None
    note:     str        = ''


@dataclass
class VerifyResponse:
    agentId:     str
    verified:    bool
    authorized:  bool
    query_ms:    int
    ts:          str
    status:      AgentStatus | None    = None
    risk_tier:   RiskTier | None       = None
    fingerprint: str | None            = None
    credential:  VerifyCredential | None = None
    audit_chain: AuditChain | None     = None


@dataclass
class RevokeCredentialResponse:
    credential_id: str
    type:          str
    agent_id:      str
    revoked:       bool
    revoked_at:    str
    revoke_reason: str
    issued_at:     str
    expires_at:    str | None = None
