"""HTTP client implementation for the AIS API."""
from __future__ import annotations
from typing import Any
import httpx
from .types import (
    Agent,
    AuditChain,
    CredentialSummary,
    GetAgentResponse,
    IssuedCredential,
    RegisterAgentInput,
    RegisterAgentResponse,
    RevokeCredentialResponse,
    VerifyCredential,
    VerifyResponse,
)


class AISError(Exception):
    """Raised when the AIS API returns a non-2xx response."""

    def __init__(self, status: int, body: dict[str, Any]) -> None:
        self.status = status
        self.body   = body
        super().__init__(f"AIS API error {status}: {body.get('error', 'unknown')}")


def _parse_agent(d: dict[str, Any]) -> Agent:
    return Agent(
        id=d['id'], name=d['name'], status=d['status'],
        risk_tier=d['risk_tier'], created_at=d['created_at'],
        description=d.get('description'), fingerprint=d.get('fingerprint'),
        owner_id=d.get('owner_id'), metadata=d.get('metadata', {}),
        updated_at=d.get('updated_at'),
    )


def _parse_cred_summary(d: dict[str, Any]) -> CredentialSummary:
    return CredentialSummary(
        id=d['id'], type=d['type'], issued_at=d['issued_at'],
        revoked=d['revoked'], prefix=d.get('prefix'),
        expires_at=d.get('expires_at'),
    )


def _parse_verify_cred(d: dict[str, Any] | None) -> VerifyCredential | None:
    if d is None:
        return None
    return VerifyCredential(
        id=d['id'], type=d['type'], issued_at=d['issued_at'],
        revoked=d['revoked'], cert_fingerprint=d.get('cert_fingerprint'),
        expires_at=d.get('expires_at'),
    )


def _parse_audit_chain(d: dict[str, Any] | None) -> AuditChain | None:
    if d is None:
        return None
    return AuditChain(
        stub=d.get('stub', True), entries=d.get('entries', 0),
        chain_id=d.get('chain_id'), note=d.get('note', ''),
    )


class AISClient:
    """Synchronous HTTP client for the Agent Identity Systems API."""

    def __init__(
        self,
        base_url: str,
        api_key:  str | None = None,
        timeout:  float      = 10.0,
    ) -> None:
        headers: dict[str, str] = {'Content-Type': 'application/json'}
        if api_key:
            headers['Authorization'] = f'Bearer {api_key}'
        self._http = httpx.Client(
            base_url=base_url.rstrip('/'),
            headers=headers,
            timeout=timeout,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> 'AISClient':
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── Private ──────────────────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path:   str,
        json:   dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response = self._http.request(method, path, json=json)
        body: dict[str, Any] = response.json()
        if response.is_error:
            raise AISError(response.status_code, body)
        return body

    # ── Public API ────────────────────────────────────────────────────────────

    def verify(self, agent_id: str) -> VerifyResponse:
        """
        Verify an agent's authorization status.
        Returns 200 for all known agents — authorized may be False.
        Raises AISError(404) for unknown agent_id.
        """
        d = self._request('GET', f'/verify/{agent_id}')
        return VerifyResponse(
            agentId=d['agentId'], verified=d['verified'],
            authorized=d['authorized'], query_ms=d['query_ms'], ts=d['ts'],
            status=d.get('status'), risk_tier=d.get('risk_tier'),
            fingerprint=d.get('fingerprint'),
            credential=_parse_verify_cred(d.get('credential')),
            audit_chain=_parse_audit_chain(d.get('audit_chain')),
        )

    def register(self, input: RegisterAgentInput | dict[str, Any]) -> RegisterAgentResponse:
        """
        Register a new agent and issue an api_key credential.
        api_key in the response is plaintext and shown exactly once.
        """
        if isinstance(input, RegisterAgentInput):
            payload: dict[str, Any] = {
                'name': input.name,
                'risk_tier': input.risk_tier,
            }
            if input.description is not None:
                payload['description'] = input.description
            if input.owner_id is not None:
                payload['owner_id'] = input.owner_id
            if input.metadata:
                payload['metadata'] = input.metadata
        else:
            payload = input

        d = self._request('POST', '/agents', json=payload)
        c = d['credential']
        return RegisterAgentResponse(
            agent=_parse_agent(d['agent']),
            credential=IssuedCredential(
                type=c['type'], prefix=c['prefix'], api_key_id=c['api_key_id'],
                scopes=c['scopes'], issued_at=c['issued_at'],
                expires_at=c.get('expires_at'),
            ),
            api_key=d['api_key'],
            warning=d['warning'],
        )

    def get_agent(self, agent_id: str) -> GetAgentResponse:
        """
        Retrieve agent record and active credential summaries.
        Plaintext keys are never returned.
        """
        d = self._request('GET', f'/agents/{agent_id}')
        return GetAgentResponse(
            agent=_parse_agent(d['agent']),
            credentials=[_parse_cred_summary(c) for c in d.get('credentials', [])],
        )

    def revoke_credential(
        self,
        agent_id:      str,
        credential_id: str,
        revoke_reason: str | None = None,
    ) -> RevokeCredentialResponse:
        """
        Revoke a credential by ID.
        After revocation, verify() will return authorized=False.
        """
        payload: dict[str, Any] = {'credential_id': credential_id}
        if revoke_reason is not None:
            payload['revoke_reason'] = revoke_reason

        d = self._request('POST', f'/agents/{agent_id}/credentials/revoke', json=payload)
        return RevokeCredentialResponse(
            credential_id=d['credential_id'], type=d['type'],
            agent_id=d['agent_id'], revoked=d['revoked'],
            revoked_at=d['revoked_at'], revoke_reason=d['revoke_reason'],
            issued_at=d['issued_at'], expires_at=d.get('expires_at'),
        )
