"""Credential resolution for wet-mcp.

Resolution order (relay only when ALL local sources are empty):
1. ENV VARS          -- User explicitly set (highest priority, skip everything)
2. RELAY CONFIG      -- Saved from previous relay setup (~/.config/mcp/config.enc)
3. RELAY SETUP       -- Interactive, ONLY when steps 1-2 are ALL empty (120s timeout)
4. LOCAL MODE        -- Fallback (ONNX embedding, SearXNG search)
"""

from __future__ import annotations

import os
import sys

from loguru import logger

DEFAULT_RELAY_URL = "https://wet-mcp.n24q02m.com"
SERVER_NAME = "wet-mcp"

CLOUD_KEYS = [
    "JINA_AI_API_KEY",
    "GEMINI_API_KEY",
    "OPENAI_API_KEY",
    "COHERE_API_KEY",
]

# 5 minutes: user needs time to copy URL, open browser, fill 4 keys
RELAY_TIMEOUT_S = 300.0


def load_config_from_file() -> dict[str, str] | None:
    """Try to load config from encrypted config file. Returns None if not found."""
    try:
        from mcp_relay_core.storage.config_file import read_config

        saved = read_config(SERVER_NAME)
        if saved and any(saved.get(k) for k in CLOUD_KEYS):
            logger.info("Config loaded from file")
            return saved
        return None
    except Exception:
        return None


def apply_config(config: dict[str, str]) -> None:
    """Apply config dict to environment variables."""
    for key, value in config.items():
        if value and key not in os.environ:
            os.environ[key] = value
            logger.debug("Applied relay config: {}", key)


async def ensure_config(
    *, force: bool = False, timeout: float | None = RELAY_TIMEOUT_S
) -> dict[str, str] | None:
    """Resolve config: env vars -> config file -> relay setup -> local fallback.

    Args:
        force: Skip env-var and config-file checks, go straight to relay.
        timeout: Relay poll timeout in seconds. None = no timeout (manual setup).

    Relay is ONLY triggered when steps 1-2 are ALL empty (unless ``force=True``).

    Returns:
        Config dict with API keys, or None if skipped/failed (local mode).
    """
    if not force:
        # 1. Check if env vars already provide cloud keys (highest priority)
        if any(os.environ.get(k) for k in CLOUD_KEYS):
            logger.info("Cloud API keys found in environment, skipping relay")
            return None  # env vars take priority, no relay needed

        # 2. Check saved relay config file
        config = load_config_from_file()
        if config is not None:
            apply_config(config)
            return config

    # 3. No local credentials found (or forced) -- trigger relay setup
    logger.info("Starting relay setup...")
    try:
        from mcp_relay_core.relay.client import create_session, poll_for_result

        from .relay_schema import RELAY_SCHEMA

        relay_url = os.environ.get("MCP_RELAY_URL", DEFAULT_RELAY_URL)
        session = await create_session(relay_url, SERVER_NAME, RELAY_SCHEMA)  # ty: ignore[invalid-argument-type]

        timeout_msg = f", {int(timeout)}s timeout" if timeout else ""
        print(
            f"\nConfigure cloud providers (optional{timeout_msg}):"
            f"\n{session.relay_url}"
            f"\nSkip to use local mode (ONNX embedding + SearXNG).\n",
            file=sys.stderr,
            flush=True,
        )

        config = await poll_for_result(relay_url, session, timeout_s=timeout)  # ty: ignore[invalid-argument-type]

        # Save to config file for future use
        from mcp_relay_core.storage.config_file import write_config

        write_config(SERVER_NAME, config)
        logger.info("Config saved successfully")

        apply_config(config)

        # Notify relay page: config saved (info, NOT complete — GDrive OAuth may follow)
        try:
            import httpx

            async with httpx.AsyncClient() as http:
                await http.post(
                    f"{relay_url}/api/sessions/{session.session_id}/messages",
                    json={
                        "type": "info",
                        "text": "API keys saved. Starting Google Drive sync setup...",
                    },
                )
        except Exception:
            pass

        # Trigger GDrive OAuth Device Code using default client ID from settings
        from wet_mcp.config import settings as _settings

        gdrive_ok = False
        if _settings.google_drive_client_id:
            logger.info("Starting Google Drive OAuth setup...")
            try:
                from wet_mcp.sync import setup_google_auth

                gdrive_ok = await setup_google_auth(
                    relay_url=relay_url,
                    session_id=session.session_id,
                )
            except Exception as e:
                logger.warning(f"GDrive OAuth setup failed: {e}")

        # NOW send complete message (after GDrive OAuth finishes or skips)
        try:
            async with httpx.AsyncClient() as http:
                msg = (
                    "Setup complete!"
                    if gdrive_ok
                    else "API keys saved. Google Drive sync can be configured later via config tool."
                )
                await http.post(
                    f"{relay_url}/api/sessions/{session.session_id}/messages",
                    json={"type": "complete", "text": msg},
                )
        except Exception:
            pass

        return config

    except RuntimeError as e:
        if "RELAY_SKIPPED" in str(e):
            logger.info("Relay setup skipped by user. Using local mode.")
        elif "timed out" in str(e).lower():
            logger.info("Relay setup timed out. Using local mode.")
        else:
            logger.debug("Relay setup ended: {}", e)
        return None
    except Exception as e:
        logger.debug("Relay setup unavailable: {}. Using local mode.", e)
        return None
