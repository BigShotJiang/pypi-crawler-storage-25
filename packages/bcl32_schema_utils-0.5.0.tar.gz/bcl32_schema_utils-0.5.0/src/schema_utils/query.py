"""SQLAlchemy query helpers driven by Pydantic schemas.

Requires the `sqlalchemy` extra: ``pip install bcl32-schema-utils[sqlalchemy]``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy.orm import load_only

if TYPE_CHECKING:
    from pydantic import BaseModel
    from sqlalchemy.orm import DeclarativeBase


def load_only_from_schema(
    model: type[DeclarativeBase],
    schema: type[BaseModel],
):
    """Build a SQLAlchemy ``load_only()`` option from a Pydantic schema.

    Loads only the columns named by the schema's fields; schema fields that
    aren't ORM columns (relationships, computed fields) are silently skipped.
    Keeps query and response in sync — add a field to the schema and it
    loads; remove it and it's deferred. Prevents silent perf regressions
    from new JSONB columns being added to the ORM model.

    Usage:

        from schema_utils import load_only_from_schema

        PART_LIST_OPTIONS = [
            load_only_from_schema(Part, PartListResponse),
            selectinload(Part.part_set_members),
        ]
        query = sa_select(Part).options(*PART_LIST_OPTIONS)
    """
    columns = [
        getattr(model, name)
        for name in schema.model_fields
        if name in model.__table__.c
    ]
    return load_only(*columns)
