"""bcl32-schema-utils — Pydantic schema to ModelData JSON generator.

Converts Pydantic model schemas into ModelData JSON consumed by React frontends.

Usage:

    # From a JSON registry + SQLAlchemy FK references
    from schema_utils import SchemaGenerator
    generator = SchemaGenerator.from_registry("./schema_registry.json", db_base=Base)

    # From an inline dict
    generator = SchemaGenerator.from_dict({
        "MyModel": {"model": MyPydanticModel, "route_prefix": "/my-models", "set_name": "My Models"},
    })

    # Generate
    all_schemas = generator.generate_all()
    single = generator.generate_model_data("MyModel")
    names = generator.model_names()
"""

from importlib.metadata import version

from .generator import SchemaGenerator
from .partial import partial_model

__all__ = [
    "SchemaGenerator",
    "generate_registry",
    "load_only_from_schema",
    "partial_model",
]


def __getattr__(name: str):
    if name == "generate_registry":
        from .generate_registry import generate_registry
        return generate_registry
    if name == "load_only_from_schema":
        from .query import load_only_from_schema
        return load_only_from_schema
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__version__ = version("bcl32-schema-utils")
