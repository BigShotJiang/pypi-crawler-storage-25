"""Type resolution and conversion utilities for Pydantic JSON schemas."""

import copy


def resolve_refs(schema: dict) -> dict:
    """Recursively inline all $ref pointers in a Pydantic JSON schema.

    Pydantic v2 emits shared types (e.g. enums) as $defs and references them
    via $ref. This flattens those references so every property is self-contained,
    which simplifies downstream type conversion and enum extraction.
    Sibling keys (default, description) are preserved during resolution.
    """
    defs = schema.get("$defs", {})

    def _resolve(node):
        if isinstance(node, dict):
            if "$ref" in node:
                ref_path = node["$ref"]  # e.g. "#/$defs/Status"
                def_name = ref_path.rsplit("/", 1)[-1]
                resolved = copy.deepcopy(defs[def_name])
                for k, v in node.items():
                    if k != "$ref":
                        resolved[k] = v
                return _resolve(resolved)
            return {k: _resolve(v) for k, v in node.items()}
        if isinstance(node, list):
            return [_resolve(item) for item in node]
        return node

    return _resolve(schema)


def convert_types(item: dict) -> str:
    """Map a Pydantic JSON-schema property to a UI type string.

    Handles Pydantic's nullable wrappers (anyOf with null), enum wrappers
    (allOf), and standard JSON-schema types. Returns one of: string, number,
    boolean, datetime, id, select, list, children, or object.
    """
    # json_schema_extra format lives at the top level, even for nullable (anyOf) fields
    if item.get("format") == "colour":
        return "colour"
    if item.get("format") == "colour_array":
        return "colour_array"

    if "anyOf" in item:
        # Filter out null type and Decimal string-pattern fallback
        real = [
            v for v in item["anyOf"]
            if v.get("type") != "null" and "pattern" not in v
        ]
        if real:
            return convert_types(real[0])
        return "object"

    if "allOf" in item:
        if "enum" in item["allOf"][0]:
            return "select"
        return "object"

    # Bare enum (after $ref resolution removes the allOf wrapper)
    if "enum" in item:
        return "select"

    prop_type = item.get("type")

    if prop_type == "array":
        items_type = item.get("items", {}).get("type")
        if items_type == "string":
            return "list"
        if items_type == "object":
            return "children"

    if prop_type == "string":
        fmt = item.get("format")
        if fmt == "date-time":
            return "datetime"
        if fmt == "uuid":
            return "id"
        return "string"

    if prop_type in ("integer", "float", "number"):
        return "number"

    if prop_type == "boolean":
        return "boolean"

    return prop_type or "object"


def get_title(item: dict) -> str:
    """Extract the human-readable title from a schema property."""
    if "allOf" in item:
        return item["allOf"][0].get("title", "")
    if "anyOf" in item:
        for branch in item["anyOf"]:
            title = branch.get("title", "")
            if title:
                return title
    return item.get("title", "")
