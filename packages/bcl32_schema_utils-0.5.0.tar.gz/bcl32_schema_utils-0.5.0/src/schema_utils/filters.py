"""Filter configuration helpers for ModelData attributes.

All filterable options-style attributes (list, select, toggle, colour,
colour_array, children, boolean) collapse onto the single ``options`` filter
type on the React side. This module sets ``filter_type`` and the auxiliary
config fields (source_kind, selection, display, value_key, label_key) so the
filter framework can render without case-by-case branches.
"""

# Data types that resolve to the unified `options` filter.
_OPTIONS_DATA_TYPES = frozenset({
    "list",
    "select",
    "toggle",
    "colour",
    "colour_array",
    "children",
    "boolean",
})

# Data types that resolve to their own dedicated filter type.
_SCALAR_FILTER_TYPES = frozenset({"string", "number", "datetime"})


def _source_kind(data_type: str) -> str:
    if data_type in ("list", "colour_array"):
        return "scalar-array"
    if data_type == "children":
        return "object-array"
    # select, colour, toggle, boolean — single scalar field on the row
    return "scalar"


def _default_display(data_type: str) -> str:
    if data_type == "select":
        return "dropdown"
    if data_type == "list":
        return "combobox"
    if data_type in ("colour", "colour_array"):
        return "swatch-grid"
    if data_type == "children":
        return "chip-toggle"
    if data_type == "boolean":
        return "toggle-buttons"
    if data_type == "toggle":
        return "toggle-buttons"
    return "combobox"


def _define_empty_filter(filter_type: str):
    """Return the empty/default filter value for a resolved filter type."""
    if filter_type == "string":
        return ""
    if filter_type == "datetime":
        return {"timespan_begin": "", "timespan_end": ""}
    if filter_type == "number":
        return {"min": "", "max": ""}
    # options
    return []


def _define_filter_rule(filter_type: str):
    """Return the default filter comparison operator for a resolved filter type."""
    if filter_type == "string":
        return "contains"
    if filter_type == "number":
        return ">"
    if filter_type == "options":
        return "any"
    return None


def define_filtering(entry: dict, overrides: dict | None = None) -> None:
    """Set filter, filter_empty, filter_rule, and the options config fields.

    When *overrides* contains a ``filterable`` key set to ``False``, the field
    is excluded from filtering. Inherently non-filterable types (``id``,
    ``object``) cannot be forced on.
    """
    if overrides and "filterable" in overrides and not overrides["filterable"]:
        entry["filter"] = False
        return

    data_type = entry["type"]
    if data_type in ("id", "object"):
        entry["filter"] = False
        return

    # `children` usually represents owned nested records (items, links,
    # weight logs) that aren't meaningful to filter on. Shared/taggable
    # relationships (e.g. systems on Part) opt in via overrides.
    if data_type == "children" and not (overrides and overrides.get("filterable")):
        entry["filter"] = False
        return

    if data_type in _OPTIONS_DATA_TYPES:
        filter_type = "options"
    elif data_type in _SCALAR_FILTER_TYPES:
        filter_type = data_type
    else:
        # Unknown type: opt out of filtering rather than guess.
        entry["filter"] = False
        return

    entry["filter"] = True
    entry["filter_type"] = filter_type
    entry["filter_empty"] = _define_empty_filter(filter_type)
    entry["filter_rule"] = _define_filter_rule(filter_type)

    if filter_type == "options":
        entry["source_kind"] = _source_kind(data_type)
        entry["selection"] = "multi"
        entry["display"] = _default_display(data_type)
        if data_type == "children":
            entry["value_key"] = "value"
            entry["label_key"] = "label"

    if overrides and overrides.get("primaryFilter"):
        entry["primaryFilter"] = True
    if overrides and overrides.get("display"):
        entry["display"] = overrides["display"]
    if overrides and "filterOrder" in overrides:
        entry["filterOrder"] = overrides["filterOrder"]
    if overrides and overrides.get("options_source"):
        entry["options_source"] = overrides["options_source"]
