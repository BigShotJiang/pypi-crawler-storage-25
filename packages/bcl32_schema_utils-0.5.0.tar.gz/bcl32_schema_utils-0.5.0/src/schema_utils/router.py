"""FastAPI router factory for schema endpoints."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .generator import SchemaGenerator

log = logging.getLogger(__name__)


def create_schema_router(generator: SchemaGenerator):
    """Create a FastAPI APIRouter with schema endpoints.

    Returns a router with:
        GET /models  — list of registered model names
        GET /all     — full ModelData for all models
        GET /{model_name} — ModelData for a single model

    Errors are raised as HTTPException(detail={code, message, details}). Consumers
    with a structured exception handler (e.g. one that recognises a dict `detail`
    with a `code` key) will flatten the envelope to the response body; consumers
    without one get FastAPI's default `{"detail": {...}}` wrapping, which is
    still parseable.
    """
    from fastapi import APIRouter, HTTPException

    router = APIRouter()

    @router.get("/models")
    def get_models() -> list[str]:
        return generator.model_names()

    @router.get("/all")
    def get_all_schemas() -> list[dict]:
        return generator.generate_all()

    @router.get("/{model_name}")
    def get_schema(model_name: str) -> dict:
        if model_name not in generator.model_names():
            log.warning("schema_model_not_found", extra={"model_name": model_name})
            raise HTTPException(
                status_code=404,
                detail={
                    "code": "schema_model_not_found",
                    "message": f"Model '{model_name}' not found",
                    "details": {"model_name": model_name},
                },
            )
        return generator.generate_model_data(model_name)

    return router
