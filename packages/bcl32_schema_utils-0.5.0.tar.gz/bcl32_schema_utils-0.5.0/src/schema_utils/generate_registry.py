"""Auto-generate schema_registry.json by introspecting SQLAlchemy models.

Walks the SQLAlchemy mapper registry, attempts to import a matching
``{ClassName}Response`` Pydantic schema for each model, and emits a
registry entry for every model that has one.  Models without a Response
schema (junction tables, logs, non-CRUD entities) are silently skipped.

Custom values (``display_field``, ``chart_filters``) can be preserved
from an existing registry file via ``--existing``.

CLI
---
::

    python -m schema_utils.generate_registry \\
        --db-module database:Base \\
        --output schema_registry.json \\
        [--existing schema_registry.json]
"""

from __future__ import annotations

import argparse
import importlib
import json
import re
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Naming-convention helpers
# ---------------------------------------------------------------------------

def _pascal_to_snake(name: str) -> str:
    """StorageContainer → storage_container, MLModel → ml_model"""
    name = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name).lower()


def _pascal_to_words(name: str) -> str:
    """StorageContainer → Storage Container, MLModel → ML Model"""
    name = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name)


def _pluralize(word: str) -> str:
    """Naive English pluralisation (covers the project's model names)."""
    if word.endswith("y") and word[-2] not in "aeiou":
        return word[:-1] + "ies"
    if word.endswith(("s", "sh", "ch", "x", "z")):
        return word + "es"
    return word + "s"


def _pluralize_phrase(phrase: str) -> str:
    """Pluralise only the last word of a multi-word phrase."""
    parts = phrase.rsplit(" ", 1)
    if len(parts) == 1:
        return _pluralize(parts[0])
    return parts[0] + " " + _pluralize(parts[1])


# ---------------------------------------------------------------------------
# Core generator
# ---------------------------------------------------------------------------

_OVERRIDE_KEYS = ("display_field", "chart_filters")


def generate_registry(
    db_base,
    existing_path: Path | None = None,
    schemas_package: str = "schemas",
) -> list[dict]:
    """Return a list of registry-entry dicts derived from *db_base*.

    Parameters
    ----------
    db_base:
        The SQLAlchemy ``DeclarativeBase`` subclass whose mapper registry
        will be walked.
    existing_path:
        Optional path to an existing ``schema_registry.json``.  If given,
        values for ``display_field`` and ``chart_filters`` are merged in
        so that manual overrides are preserved.
    schemas_package:
        The Python package prefix used to import schema modules
        (default ``"schemas"``).
    """
    # Load existing overrides keyed by model_name
    overrides: dict[str, dict] = {}
    if existing_path is not None and existing_path.exists():
        existing = json.loads(existing_path.read_text())
        for entry in existing:
            overrides[entry["model_name"]] = {
                k: entry[k] for k in _OVERRIDE_KEYS if k in entry
            }

    entries: list[dict] = []

    for mapper in db_base.registry.mappers:
        cls = mapper.class_
        class_name: str = cls.__name__

        # Derive the expected schema module + class name
        snake = _pascal_to_snake(class_name)
        module_path = f"{schemas_package}.{snake}"
        response_class_name = f"{class_name}Response"

        # Try to import — skip models without a Response schema
        try:
            mod = importlib.import_module(module_path)
        except ModuleNotFoundError:
            continue
        if not hasattr(mod, response_class_name):
            continue

        table_name: str = mapper.persist_selectable.name
        route_prefix = table_name.replace("_", "-")
        words = _pascal_to_words(class_name)
        set_name = _pluralize_phrase(words)

        entry: dict = {
            "model_name": class_name,
            "set_name": set_name,
            "schema_module": module_path,
            "schema_class": response_class_name,
            "route_prefix": route_prefix,
            "table_name": table_name,
            "display_field": "name",
            "chart_filters": [],
        }

        # Merge manual overrides from existing file
        if class_name in overrides:
            entry.update(overrides[class_name])

        entries.append(entry)

    # Stable output ordering
    entries.sort(key=lambda e: e["model_name"])
    return entries


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _resolve_attribute(spec: str):
    """Import ``module:attribute`` and return the attribute value."""
    module_path, _, attr_name = spec.partition(":")
    if not attr_name:
        print(f"error: --db-module must be module:attribute (got {spec!r})", file=sys.stderr)
        sys.exit(1)
    mod = importlib.import_module(module_path)
    return getattr(mod, attr_name)


def cli_main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Auto-generate schema_registry.json from SQLAlchemy models.",
    )
    parser.add_argument(
        "--db-module",
        required=True,
        help="module:attribute for the SQLAlchemy Base class (e.g. database:Base)",
    )
    parser.add_argument(
        "--output",
        required=True,
        type=Path,
        help="Path to write the generated registry JSON",
    )
    parser.add_argument(
        "--existing",
        type=Path,
        default=None,
        help="Path to an existing registry to merge custom values from",
    )
    parser.add_argument(
        "--schemas-package",
        default="schemas",
        help="Python package prefix for schema imports (default: schemas)",
    )

    args = parser.parse_args(argv)

    db_base = _resolve_attribute(args.db_module)
    entries = generate_registry(
        db_base,
        existing_path=args.existing,
        schemas_package=args.schemas_package,
    )

    args.output.write_text(json.dumps(entries, indent=2) + "\n")
    print(f"wrote {len(entries)} entries → {args.output}")


if __name__ == "__main__":
    cli_main()
