"""Utility functions for the pkg_infra package.

This module provides helper functions that can be used throughout the pkg_infra
package, such as timestamp generation and other general utilities.
"""

import datetime

__all__ = [
    'get_timestamp_now',
]


def get_timestamp_now() -> str:
    """Get the current UTC timestamp with an explicit ``Z`` suffix.

    Returns:
        str: The current UTC timestamp formatted as ``YYYYMMDDTHHMMSSZ``.
    """
    return datetime.datetime.now(datetime.timezone.utc).strftime(
        '%Y%m%dT%H%M%SZ',
    )
