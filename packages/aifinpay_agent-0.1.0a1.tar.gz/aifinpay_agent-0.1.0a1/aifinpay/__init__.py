"""
AiFinPay agent SDK — non-custodial x402 payment client.

Quick start:

    from aifinpay import Agent

    agent = Agent.new()                 # generate fresh Ed25519 keypair locally
    print("Fund:", agent.address)

    agent.wait_for_funding(min_usd_cents=100)
    invoice = agent.reserve_seat(amount_usd=1.00, asset="USDC")
    receipt = agent.send_signed(invoice)

    # any HTTP call to AiFinPay-protected endpoints auto-handles x402:
    resp = agent.request("GET", "https://aifinpay.company/api/stats")
"""

from .client import Agent
from .errors import AiFinPayError, FundingTimeoutError, X402Error

__version__ = "0.1.0a1"
__all__ = ["Agent", "AiFinPayError", "FundingTimeoutError", "X402Error"]
