class AiFinPayError(Exception):
    """Base class for all SDK errors."""


class X402Error(AiFinPayError):
    """Raised when the x402 challenge/response flow fails."""


class FundingTimeoutError(AiFinPayError):
    """Raised when polling for funding exceeds the timeout."""


class SeatNotFoundError(AiFinPayError):
    """Raised when the agent has no Seat PDA on-chain."""
