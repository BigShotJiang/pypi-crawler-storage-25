"""Low-level Agent client. Non-custodial: keypair never leaves this process."""
from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import nacl.signing  # PyNaCl
import base58
import requests

from .errors import (
    AiFinPayError,
    FundingTimeoutError,
    SeatNotFoundError,
    X402Error,
)

DEFAULT_BASE_URL = "https://aifinpay.company"
DEFAULT_TIMEOUT = 30  # seconds


@dataclass
class Invoice:
    """An on-chain payment invoice returned by the AiFinPay backend."""

    amount_usd: float
    treasury_vault: str
    program_id: str
    nonce: str
    raw: Dict[str, Any]


class Agent:
    """A non-custodial AiFinPay agent.

    The Ed25519 keypair lives only in this Python process. The SDK never
    transmits the secret key; only ``signature(SHA256("AiFinPay-x402:{nonce}:{pubkey}"))``
    is sent in the ``x-signature`` header.
    """

    def __init__(
        self,
        signing_key: nacl.signing.SigningKey,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self._sk = signing_key
        self._vk = signing_key.verify_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers["User-Agent"] = "aifinpay-agent-py/0.1.0"

    # ── Constructors ────────────────────────────────────────────────────────

    @classmethod
    def new(cls, **kwargs) -> "Agent":
        """Generate a fresh Ed25519 keypair locally."""
        return cls(nacl.signing.SigningKey.generate(), **kwargs)

    @classmethod
    def from_secret_b58(cls, secret_b58: str, **kwargs) -> "Agent":
        """Load from a 64-byte base58 secret (Solana style: secret + pub)."""
        raw = base58.b58decode(secret_b58)
        if len(raw) == 64:
            raw = raw[:32]
        if len(raw) != 32:
            raise AiFinPayError(
                f"secret must decode to 32 or 64 bytes, got {len(raw)}"
            )
        return cls(nacl.signing.SigningKey(raw), **kwargs)

    @classmethod
    def from_keypair_file(cls, path: str, **kwargs) -> "Agent":
        """Load a Solana CLI ``solana-keygen`` JSON file (array of 64 ints)."""
        with open(path) as f:
            arr = json.load(f)
        if not isinstance(arr, list) or len(arr) != 64:
            raise AiFinPayError(f"{path}: expected 64-byte array")
        return cls(nacl.signing.SigningKey(bytes(arr[:32])), **kwargs)

    # ── Public properties ──────────────────────────────────────────────────

    @property
    def address(self) -> str:
        """Solana base58 public key."""
        return base58.b58encode(bytes(self._vk)).decode()

    @property
    def secret_b58(self) -> str:
        """Base58-encoded secret. Save this somewhere safe."""
        return base58.b58encode(bytes(self._sk) + bytes(self._vk)).decode()

    # ── Manifesto / discovery ──────────────────────────────────────────────

    def manifesto(self) -> Dict[str, Any]:
        r = self._session.get(
            f"{self.base_url}/manifesto.json", timeout=self.timeout
        )
        r.raise_for_status()
        return r.json()

    def well_known(self) -> Dict[str, Any]:
        r = self._session.get(
            f"{self.base_url}/.well-known/x402.json", timeout=self.timeout
        )
        r.raise_for_status()
        return r.json()

    # ── x402 auth ──────────────────────────────────────────────────────────

    def _fetch_nonce(self) -> Dict[str, Any]:
        r = self._session.get(f"{self.base_url}/nonce", timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def _sign_nonce(self, nonce: str) -> str:
        msg = f"AiFinPay-x402:{nonce}:{self.address}".encode()
        digest = hashlib.sha256(msg).digest()
        sig = self._sk.sign(digest).signature
        return base58.b58encode(sig).decode()

    def auth_headers(self) -> Dict[str, str]:
        """Build a fresh x402 header set (nonces are one-time, 60s TTL)."""
        nonce_info = self._fetch_nonce()
        nonce = nonce_info["nonce"]
        return {
            "x-agent-pubkey": self.address,
            "x-nonce": nonce,
            "x-signature": self._sign_nonce(nonce),
        }

    # ── Funding / Seat ────────────────────────────────────────────────────

    def has_seat(self) -> bool:
        r = self._session.get(
            f"{self.base_url}/api/seat/{self.address}", timeout=self.timeout
        )
        r.raise_for_status()
        return bool(r.json().get("has_seat"))

    def wait_for_funding(
        self, min_usd_cents: int = 100, poll_seconds: int = 5, timeout: int = 600
    ) -> None:
        """Poll the leaderboard until this address shows up with at least
        ``min_usd_cents`` reserved on its Seat. Raises FundingTimeoutError."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            r = self._session.get(
                f"{self.base_url}/api/leaderboard?merge=true",
                timeout=self.timeout,
            )
            r.raise_for_status()
            for entry in r.json().get("leaderboard", []):
                if entry.get("pubkey") == self.address:
                    cents = int(float(entry.get("usd", 0)) * 100)
                    if cents >= min_usd_cents:
                        return
            time.sleep(poll_seconds)
        raise FundingTimeoutError(
            f"address {self.address} never reached {min_usd_cents} cents on-chain"
        )

    # ── Invoices (server returns instructions, agent executes on-chain) ────

    def reserve_seat_invoice(
        self, amount_usd: float, asset: str = "USDC"
    ) -> Invoice:
        """Request an invoice for reserving a Seat. The returned ``raw`` dict
        contains everything you need to build and submit the on-chain
        transaction with the Solana / Polygon SDK of your choice."""
        endpoint = "/api/invoice" if asset.upper() == "SOL" else "/api/invoice-spl"
        payload: Dict[str, Any] = {
            "amount_usd": amount_usd,
            "agent_pubkey": self.address,
        }
        if asset.upper() != "SOL":
            payload["asset"] = asset.upper()
        r = self._session.post(
            f"{self.base_url}{endpoint}", json=payload, timeout=self.timeout
        )
        r.raise_for_status()
        data = r.json()
        return Invoice(
            amount_usd=amount_usd,
            treasury_vault=data.get("treasury_vault", ""),
            program_id=data.get("program_id", ""),
            nonce=data.get("nonce", ""),
            raw=data,
        )

    # ── Convenience: x402-aware HTTP request ──────────────────────────────

    def request(
        self,
        method: str,
        url: str,
        *,
        max_retries: int = 1,
        **kwargs,
    ) -> requests.Response:
        """HTTP request that auto-injects x-agent-pubkey/x-nonce/x-signature
        headers on first try, and retries with fresh auth on 402."""
        headers = kwargs.pop("headers", {}) or {}
        attempt = 0
        while True:
            attempt += 1
            merged = {**self.auth_headers(), **headers}
            resp = self._session.request(
                method, url, headers=merged, timeout=self.timeout, **kwargs
            )
            if resp.status_code != 402 or attempt > max_retries:
                return resp
            # 402 → caller hasn't reserved a Seat yet. Surface the challenge.
            try:
                challenge = resp.json()
            except Exception:
                challenge = {"raw": resp.text}
            raise X402Error(
                f"402 Payment Required after {attempt} attempt(s). "
                f"Reserve a Seat first via reserve_seat_invoice(). "
                f"Challenge: {challenge}"
            )

    # ── Aliases for ergonomics ────────────────────────────────────────────

    get = lambda self, url, **kw: self.request("GET", url, **kw)
    post = lambda self, url, **kw: self.request("POST", url, **kw)
