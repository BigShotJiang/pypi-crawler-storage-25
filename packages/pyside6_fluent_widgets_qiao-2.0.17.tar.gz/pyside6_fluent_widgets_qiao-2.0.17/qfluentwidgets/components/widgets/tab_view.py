# coding: utf-8
from copy import deepcopy
from enum import Enum
from typing import Dict, List, Union
from uuid import uuid1
from PySide6.QtCore import Qt, Signal, Property, QRectF, QSize, QPoint, QPropertyAnimation, QEasingCurve, QRect
from PySide6.QtGui import QPainter, QColor, QIcon, QPainterPath, QLinearGradient, QPen, QBrush, QMouseEvent
from PySide6.QtWidgets import QWidget, QGraphicsDropShadowEffect, QHBoxLayout, QVBoxLayout, QApplication, QStackedWidget

from ...common.icon import FluentIcon, FluentIconBase, drawIcon
from ...common.style_sheet import isDarkTheme, FluentStyleSheet
from ...common.font import setFont
from ...common.router import qrouter
from .button import TransparentToolButton, PushButton
from .scroll_area import SingleDirectionScrollArea
from .tool_tip import ToolTipFilter


class TabCloseButtonDisplayMode(Enum):
    """Tab 关闭按钮的显示模式
    该枚举用于控制标签页关闭按钮何时可见，可根据交互习惯或界面空间选择始终显示、悬停显示或始终隐藏
    """
    ALWAYS = 0
    ON_HOVER = 1
    NEVER = 2


def checkIndex(*default):
    """用于索引检查的装饰器
    
    Args:
        *default: 索引越界时返回的默认值
    """

    def outer(func):

        def inner(tabBar, index: int, *args, **kwargs):
            if 0 <= index < len(tabBar.items):
                return func(tabBar, index, *args, **kwargs)

            value = deepcopy(default)
            if len(value) == 0:
                return None
            elif len(value) == 1:
                return value[0]

            return value

        return inner

    return outer


class TabToolButton(TransparentToolButton):
    """Tab 工具按钮
    用于标签栏的功能性图标按钮，如关闭、新建标签等操作
    通常嵌入 TabBar 或 TabItem 中使用，提供紧凑的点击交互区域
    """

    def _postInit(self):
        self.setFixedSize(32, 24)
        self.setIconSize(QSize(12, 12))

    def _drawIcon(self, icon, painter: QPainter, rect: QRectF, state=QIcon.Off):
        color = '#eaeaea' if isDarkTheme() else '#484848'
        icon = icon.icon(color=color)
        super()._drawIcon(icon, painter, rect, state)


class TabItem(PushButton):
    """Tab 项
    表示标签栏中的一个可选项，支持显示图标、文本和关闭按钮
    负责响应鼠标悬停、选中等交互状态，并发送对应的切换和关闭信号
    """

    closed = Signal()
    doubleClicked = Signal()

    def _postInit(self):
        super()._postInit()
        self.borderRadius = 5
        self.isSelected = False
        self.isShadowEnabled = True
        self.closeButtonDisplayMode = TabCloseButtonDisplayMode.ALWAYS

        self._routeKey = None
        self.textColor = None
        self.lightSelectedBackgroundColor = QColor(249, 249, 249)
        self.darkSelectedBackgroundColor = QColor(40, 40, 40)

        self.closeButton = TabToolButton(FluentIcon.CLOSE, self)
        self.shadowEffect = QGraphicsDropShadowEffect(self)

        self.slideAni = QPropertyAnimation(self, b'pos', self)

        self.__initWidget()

    def __initWidget(self):
        setFont(self, 12)
        self.setFixedHeight(36)
        self.setMaximumWidth(240)
        self.setMinimumWidth(64)
        self.installEventFilter(ToolTipFilter(self, showDelay=1000))
        self.setAttribute(Qt.WA_LayoutUsesWidgetRect)

        self.closeButton.setIconSize(QSize(10, 10))

        self.shadowEffect.setBlurRadius(5)
        self.shadowEffect.setOffset(0, 1)
        self.setGraphicsEffect(self.shadowEffect)
        self.setSelected(False)

        self.closeButton.clicked.connect(self.closed)

    def slideTo(self, x: int, duration=250):
        self.slideAni.setStartValue(self.pos())
        self.slideAni.setEndValue(QPoint(x, self.y()))
        self.slideAni.setDuration(duration)
        self.slideAni.setEasingCurve(QEasingCurve.InOutQuad)
        self.slideAni.start()

    def setShadowEnabled(self, isEnabled: bool):
        """设置阴影是否启用
        
        Args:
            isEnabled: 是否启用阴影
        """
        if isEnabled == self.isShadowEnabled:
            return

        self.isShadowEnabled = isEnabled
        self.shadowEffect.setColor(QColor(0, 0, 0, 50*self._canShowShadow()))

    def _canShowShadow(self):
        return self.isSelected and self.isShadowEnabled

    def setRouteKey(self, key: str):
        self._routeKey = key

    def routeKey(self):
        return self._routeKey

    def setBorderRadius(self, radius: int):
        self.borderRadius = radius
        self.update()

    def setSelected(self, isSelected: bool):
        self.isSelected = isSelected

        self.shadowEffect.setColor(QColor(0, 0, 0, 50*self._canShowShadow()))
        self.update()

        if isSelected:
            self.raise_()

        if self.closeButtonDisplayMode == TabCloseButtonDisplayMode.ON_HOVER:
            self.closeButton.setVisible(isSelected)

    def setCloseButtonDisplayMode(self, mode: TabCloseButtonDisplayMode):
        """设置关闭按钮的显示模式
        
        Args:
            mode: 关闭按钮显示模式
        """
        if mode == self.closeButtonDisplayMode:
            return

        self.closeButtonDisplayMode = mode

        if mode == TabCloseButtonDisplayMode.NEVER:
            self.closeButton.hide()
        elif mode == TabCloseButtonDisplayMode.ALWAYS:
            self.closeButton.show()
        else:
            self.closeButton.setVisible(self.isHover or self.isSelected)

    def setTextColor(self, color: QColor):
        self.textColor = QColor(color)
        self.update()

    def setSelectedBackgroundColor(self, light: QColor, dark: QColor):
        """设置选中状态的背景色
        
        Args:
            light: 浅色模式下的背景色
            dark: 深色模式下的背景色
        """
        self.lightSelectedBackgroundColor = QColor(light)
        self.darkSelectedBackgroundColor = QColor(dark)
        self.update()

    def resizeEvent(self, e):
        self.closeButton.move(
            self.width()-6-self.closeButton.width(), int(self.height()/2-self.closeButton.height()/2))

    def enterEvent(self, e):
        super().enterEvent(e)
        if self.closeButtonDisplayMode == TabCloseButtonDisplayMode.ON_HOVER:
            self.closeButton.show()

    def leaveEvent(self, e):
        super().leaveEvent(e)
        if self.closeButtonDisplayMode == TabCloseButtonDisplayMode.ON_HOVER and not self.isSelected:
            self.closeButton.hide()

    def mousePressEvent(self, e):
        super().mousePressEvent(e)
        self._forwardMouseEvent(e)

    def mouseMoveEvent(self, e):
        super().mouseMoveEvent(e)
        self._forwardMouseEvent(e)

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)
        self._forwardMouseEvent(e)

    def mouseDoubleClickEvent(self, e: QMouseEvent):
        if e.button() == Qt.MouseButton.LeftButton:
            self.doubleClicked.emit()

        return super().mouseDoubleClickEvent(e)

    def _forwardMouseEvent(self, e: QMouseEvent):
        pos = self.mapToParent(e.pos())
        event = QMouseEvent(e.type(), pos, e.button(),
                            e.buttons(), e.modifiers())
        QApplication.sendEvent(self.parent(), event)

    def sizeHint(self):
        return QSize(self.maximumWidth(), 36)

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHints(QPainter.Antialiasing)

        if self.isSelected:
            self._drawSelectedBackground(painter)
        else:
            self._drawNotSelectedBackground(painter)

        # 绘制图标
        if not self.isSelected:
            painter.setOpacity(0.79 if isDarkTheme() else 0.61)

        drawIcon(self._icon, painter, QRectF(10, 10, 16, 16))

        # 绘制文本
        self._drawText(painter)

    def _drawSelectedBackground(self, painter: QPainter):
        w, h = self.width(), self.height()
        r = self.borderRadius
        d = 2 * r

        isDark = isDarkTheme()

        # 绘制top 边框
        path = QPainterPath()
        path.arcMoveTo(1, h - d - 1, d, d, 225)
        path.arcTo(1, h - d - 1, d, d, 225, -45)
        path.lineTo(1, r)
        path.arcTo(1, 1, d, d, -180, -90)
        path.lineTo(w - r, 1)
        path.arcTo(w - d - 1, 1, d, d, 90, -90)
        path.lineTo(w - 1, h - r)
        path.arcTo(w - d - 1, h - d - 1, d, d, 0, -45)

        topBorderColor = QColor(0, 0, 0, 20)
        if isDark:
            if self.isPressed:
                topBorderColor = QColor(255, 255, 255, 18)
            elif self.isHover:
                topBorderColor = QColor(255, 255, 255, 13)
        else:
            topBorderColor = QColor(0, 0, 0, 16)

        painter.strokePath(path, topBorderColor)

        # 绘制bottom 边框
        path = QPainterPath()
        path.arcMoveTo(1, h - d - 1, d, d, 225)
        path.arcTo(1, h - d - 1, d, d, 225, 45)
        path.lineTo(w - r - 1, h - 1)
        path.arcTo(w - d - 1, h - d - 1, d, d, 270, 45)

        bottomBorderColor = topBorderColor
        if not isDark:
            bottomBorderColor = QColor(0, 0, 0, 63)

        painter.strokePath(path, bottomBorderColor)

        # 绘制背景
        painter.setPen(Qt.NoPen)
        rect = self.rect().adjusted(1, 1, -1, -1)
        painter.setBrush(
            self.darkSelectedBackgroundColor if isDark else self.lightSelectedBackgroundColor)
        painter.drawRoundedRect(rect, r, r)

    def _drawNotSelectedBackground(self, painter: QPainter):
        if not (self.isPressed or self.isHover):
            return

        isDark = isDarkTheme()

        if self.isPressed:
            color = QColor(255, 255, 255, 12) if isDark else QColor(0, 0, 0, 7)
        else:
            color = QColor(255, 255, 255, 15) if isDark else QColor(
                0, 0, 0, 10)

        painter.setBrush(color)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(self.rect().adjusted(
            1, 1, -1, -1), self.borderRadius, self.borderRadius)

    def _drawText(self, painter: QPainter):
        tw = self.fontMetrics().boundingRect(self.text()).width()

        if self.icon().isNull():
            dw = 47 if self.closeButton.isVisible() else 20
            rect = QRectF(10, 0, self.width() - dw, self.height())
        else:
            dw = 70 if self.closeButton.isVisible() else 45
            rect = QRectF(33, 0, self.width() - dw, self.height())

        pen = QPen()
        color = Qt.white if isDarkTheme() else Qt.black
        color = self.textColor or color
        rw = rect.width()

        if tw > rw:
            gradient = QLinearGradient(rect.x(), 0, tw+rect.x(), 0)
            gradient.setColorAt(0, color)
            gradient.setColorAt(max(0, (rw - 10) / tw), color)
            gradient.setColorAt(max(0, rw / tw), Qt.transparent)
            gradient.setColorAt(1, Qt.transparent)
            pen.setBrush(QBrush(gradient))
        else:
            pen.setColor(color)

        painter.setPen(pen)
        painter.setFont(self.font())
        painter.drawText(rect, Qt.AlignVCenter | Qt.AlignLeft, self.text())


class TabBar(SingleDirectionScrollArea):
    """Tab 栏
    用于横向展示和管理一组 TabItem，支持添加、移除、切换和重排序标签页
    适用于多文档或分页视图场景，常与 TabWidget 搭配使用以实现完整的多页切换功能
    """

    currentChanged = Signal(int)
    tabBarClicked = Signal(int)
    tabBarDoubleClicked = Signal(int)
    tabCloseRequested = Signal(int)
    tabAddRequested = Signal()
    tabMoved = Signal(int, int)  # (from, to)

    def __init__(self, parent=None):
        """初始化 TabBar
        
        Args:
            parent: 父控件。若为 None，则作为独立窗口显示；否则嵌入父控件并随其释放
        """
        super().__init__(parent=parent, orient=Qt.Horizontal)
        self.items = []  # type: 列表[TabItem]
        self.itemMap = {} # type: Dict[str, TabItem]

        self._currentIndex = -1

        self._isMovable = False
        self._isScrollable = False
        self._isTabShadowEnabled = True

        self._tabMaxWidth = 240
        self._tabMinWidth = 64

        self.dragPos = QPoint()
        self.isDraging = False

        self.lightSelectedBackgroundColor = QColor(249, 249, 249)
        self.darkSelectedBackgroundColor = QColor(40, 40, 40)
        self.closeButtonDisplayMode = TabCloseButtonDisplayMode.ALWAYS

        self.view = QWidget(self)
        self.hBoxLayout = QHBoxLayout(self.view)
        self.itemLayout = QHBoxLayout()
        self.widgetLayout = QHBoxLayout()

        self.addButton = TabToolButton(FluentIcon.ADD, self)

        self.__initWidget()

    def __initWidget(self):
        self.setFixedHeight(46)
        self.setWidget(self.view)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.hBoxLayout.setSizeConstraint(QHBoxLayout.SetMaximumSize)

        self.addButton.clicked.connect(self.tabAddRequested)

        self.view.setObjectName('view')
        FluentStyleSheet.TAB_VIEW.apply(self)
        FluentStyleSheet.TAB_VIEW.apply(self.view)

        self.__initLayout()

    def __initLayout(self):
        self.hBoxLayout.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        self.itemLayout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.widgetLayout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        self.itemLayout.setContentsMargins(5, 5, 5, 5)
        self.widgetLayout.setContentsMargins(0, 0, 0, 0)
        self.hBoxLayout.setContentsMargins(0, 0, 0, 0)

        self.itemLayout.setSizeConstraint(QHBoxLayout.SetMinAndMaxSize)

        self.hBoxLayout.setSpacing(0)
        self.itemLayout.setSpacing(0)

        self.hBoxLayout.addLayout(self.itemLayout)
        self.hBoxLayout.addSpacing(3)

        self.widgetLayout.addWidget(self.addButton, 0, Qt.AlignLeft)
        self.hBoxLayout.addLayout(self.widgetLayout)
        self.hBoxLayout.addStretch(1)

    def setAddButtonVisible(self, isVisible: bool):
        self.addButton.setVisible(isVisible)

    def addTab(self, routeKey: str, text: str, icon: Union[QIcon, str, FluentIconBase] = None, onClick=None):
        """添加标签页
        
        Args:
            routeKey: 标签页的唯一标识
            text: 标签页文本
            icon: 标签页图标
            onClick: 点击信号的槽函数
        """
        return self.insertTab(-1, routeKey, text, icon, onClick)

    def insertTab(self, index: int, routeKey: str, text: str, icon: Union[QIcon, str, FluentIconBase] = None,
                  onClick=None):
        """插入标签页
        
        Args:
            index: 标签页插入位置
            routeKey: 标签页的唯一标识
            text: 标签页文本
            icon: 标签页图标
            onClick: 点击信号的槽函数
        """
        if routeKey in self.itemMap:
            raise ValueError(f"The route key `{routeKey}` is duplicated.")

        if index == -1:
            index = len(self.items)

        # 调整当前 索引
        if index <= self.currentIndex() and self.currentIndex() >= 0:
            self._currentIndex += 1

        item = TabItem(text, self.view, icon)
        item.setRouteKey(routeKey)

        # 设置tab的大小
        w = self.tabMaximumWidth() if self.isScrollable() else self.tabMinimumWidth()
        item.setMinimumWidth(w)
        item.setMaximumWidth(self.tabMaximumWidth())

        item.setShadowEnabled(self.isTabShadowEnabled())
        item.setCloseButtonDisplayMode(self.closeButtonDisplayMode)
        item.setSelectedBackgroundColor(
            self.lightSelectedBackgroundColor, self.darkSelectedBackgroundColor)

        item.pressed.connect(self._onItemPressed)
        item.doubleClicked.connect(lambda: self.tabBarDoubleClicked.emit(self.items.index(item)))
        item.closed.connect(lambda: self.tabCloseRequested.emit(self.items.index(item)))
        if onClick:
            item.pressed.connect(onClick)

        self.itemLayout.insertWidget(index, item, 1)
        self.items.insert(index, item)
        self.itemMap[routeKey] = item

        if len(self.items) == 1:
            self.setCurrentIndex(0)

        return item

    def removeTab(self, index: int):
        if not 0 <= index < len(self.items):
            return

        # 调整当前 索引
        if index < self.currentIndex():
            self._currentIndex -= 1
        elif index == self.currentIndex():
            if self.currentIndex() > 0:
                self.setCurrentIndex(self.currentIndex() - 1)
                self.currentChanged.emit(self.currentIndex())
            elif len(self.items) == 1:
                self._currentIndex = -1
            else:
                self.setCurrentIndex(1)
                self._currentIndex = 0
                self.currentChanged.emit(0)

        # 移除 tab
        item = self.items.pop(index)
        self.itemMap.pop(item.routeKey())
        self.hBoxLayout.removeWidget(item)
        qrouter.remove(item.routeKey())
        item.deleteLater()

        # 移除 shadow
        self.update()

    def removeTabByKey(self, routeKey: str):
        if routeKey not in self.itemMap:
            return

        self.removeTab(self.items.index(self.tab(routeKey)))

    def setCurrentIndex(self, index: int):
        """设置当前索引
        
        Args:
            index: 当前索引
        """
        if index == self._currentIndex:
            return

        if self.currentIndex() >= 0:
            self.items[self.currentIndex()].setSelected(False)

        self._currentIndex = index
        self.items[index].setSelected(True)

    def setCurrentTab(self, routeKey: str):
        if routeKey not in self.itemMap:
            return

        self.setCurrentIndex(self.items.index(self.tab(routeKey)))

    def currentIndex(self):
        return self._currentIndex

    def currentTab(self):
        return self.tabItem(self.currentIndex())

    def _onItemPressed(self):
        for item in self.items:
            item.setSelected(item is self.sender())

        index = self.items.index(self.sender())
        self.tabBarClicked.emit(index)

        if index != self.currentIndex():
            self.setCurrentIndex(index)
            self.currentChanged.emit(index)

    def setCloseButtonDisplayMode(self, mode: TabCloseButtonDisplayMode):
        """设置关闭按钮的显示模式
        
        Args:
            mode: 关闭按钮显示模式
        """
        if mode == self.closeButtonDisplayMode:
            return

        self.closeButtonDisplayMode = mode
        for item in self.items:
            item.setCloseButtonDisplayMode(mode)

    @checkIndex()
    def tabItem(self, index: int):
        return self.items[index]

    def tab(self, routeKey: str):
        return self.itemMap.get(routeKey, None)

    def tabRegion(self) -> QRect:
        """返回所有标签页的边界区域"""
        return self.itemLayout.geometry()

    @checkIndex()
    def tabRect(self, index: int):
        """返回指定索引标签页的可视区域
        
        Args:
            index: 标签页索引
        """
        x = 0
        for i in range(index):
            x += self.tabItem(i).width()

        rect = self.tabItem(index).geometry()
        rect.moveLeft(x)
        return rect

    @checkIndex()
    def tabData(self, index: int):
        return self.tabItem(index).property("data")

    @checkIndex()
    def setTabData(self, index: int, data):
        self.tabItem(index).setProperty("data", data)

    @checkIndex('')
    def tabText(self, index: int):
        return self.tabItem(index).text()

    @checkIndex()
    def tabIcon(self, index: int):
        return self.tabItem(index).icon()

    @checkIndex('')
    def tabToolTip(self, index: int):
        return self.tabItem(index).toolTip()

    @checkIndex(False)
    def isTabEnabled(self, index: int):
        return self.tabItem(index).isEnabled()

    @checkIndex()
    def setTabEnabled(self, index: int, isEnabled: bool):
        self.tabItem(index).setEnabled(isEnabled)

    def setTabsClosable(self, isClosable: bool):
        """设置标签页是否可关闭
        
        Args:
            isClosable: 是否可关闭
        """
        if isClosable:
            self.setCloseButtonDisplayMode(TabCloseButtonDisplayMode.ALWAYS)
        else:
            self.setCloseButtonDisplayMode(TabCloseButtonDisplayMode.NEVER)

    def tabsClosable(self):
        return self.closeButtonDisplayMode != TabCloseButtonDisplayMode.NEVER

    @checkIndex()
    def setTabIcon(self, index: int, icon: Union[QIcon, FluentIconBase, str]):
        """设置标签页图标
        
        Args:
            index: 标签页索引
            icon: 图标
        """
        self.tabItem(index).setIcon(icon)

    @checkIndex()
    def setTabText(self, index: int, text: str):
        """设置标签页文本
        
        Args:
            index: 标签页索引
            text: 文本
        """
        self.tabItem(index).setText(text)

    @checkIndex(False)
    def isTabVisible(self, index: int):
        return self.tabItem(index).isVisible(index)

    @checkIndex()
    def setTabVisible(self, index: int, isVisible: bool):
        """设置标签页的可见性
        
        Args:
            index: 标签页索引
            isVisible: 是否可见
        """
        self.tabItem(index).setVisible(isVisible)

        if isVisible and self.currentIndex() < 0:
            self.setCurrentIndex(0)
        elif not isVisible:
            if self.currentIndex() > 0:
                self.setCurrentIndex(self.currentIndex() - 1)
                self.currentChanged.emit(self.currentIndex())
            elif len(self.items) == 1:
                self._currentIndex = -1
            else:
                self.setCurrentIndex(1)
                self._currentIndex = 0
                self.currentChanged.emit(0)

    @checkIndex()
    def setTabTextColor(self, index: int, color: QColor):
        """设置标签页文本颜色
        
        Args:
            index: 标签页索引
            color: 文本颜色
        """
        self.tabItem(index).setTextColor(color)

    @checkIndex()
    def setTabToolTip(self, index: int, toolTip: str):
        """设置标签页工具提示
        
        Args:
            index: 标签页索引
            toolTip: 工具提示文本
        """
        self.tabItem(index).setToolTip(toolTip)

    def setTabSelectedBackgroundColor(self, light: QColor, dark: QColor):
        """设置标签页选中状态的背景色
        
        Args:
            light: 浅色模式下的背景色
            dark: 深色模式下的背景色
        """
        self.lightSelectedBackgroundColor = QColor(light)
        self.darkSelectedBackgroundColor = QColor(dark)

        for item in self.items:
            item.setSelectedBackgroundColor(light, dark)

    def setTabShadowEnabled(self, isEnabled: bool):
        """设置标签页阴影是否启用
        
        Args:
            isEnabled: 是否启用阴影
        """
        if isEnabled == self.isTabShadowEnabled():
            return

        self._isTabShadowEnabled = isEnabled
        for item in self.items:
            item.setShadowEnabled(isEnabled)

    def isTabShadowEnabled(self):
        return self._isTabShadowEnabled

    def paintEvent(self, e):
        painter = QPainter(self.viewport())
        painter.setRenderHints(QPainter.Antialiasing)

        # 绘制separators
        if isDarkTheme():
            color = QColor(255, 255, 255, 21)
        else:
            color = QColor(0, 0, 0, 15)

        painter.setPen(color)

        for i, item in enumerate(self.items):
            canDraw = not (item.isHover or item.isSelected)
            if i < len(self.items) - 1:
                nextItem = self.items[i + 1]
                if nextItem.isHover or nextItem.isSelected:
                    canDraw = False

            if canDraw:
                x = item.geometry().right()
                y = self.height() // 2 - 8
                painter.drawLine(x, y, x, y + 16)

    def setMovable(self, movable: bool):
        self._isMovable = movable

    def isMovable(self):
        return self._isMovable

    def setScrollable(self, scrollable: bool):
        self._isScrollable = scrollable
        w = self._tabMaxWidth if scrollable else self._tabMinWidth
        for item in self.items:
            item.setMinimumWidth(w)

    def setTabMaximumWidth(self, width: int):
        """设置标签页的最大宽度
        
        Args:
            width: 最大宽度
        """
        if width == self._tabMaxWidth:
            return

        self._tabMaxWidth = width
        for item in self.items:
            item.setMaximumWidth(width)

    def setTabMinimumWidth(self, width: int):
        """设置标签页的最小宽度
        
        Args:
            width: 最小宽度
        """
        if width == self._tabMinWidth:
            return

        self._tabMinWidth = width

        if not self.isScrollable():
            for item in self.items:
                item.setMinimumWidth(width)

    def tabMaximumWidth(self):
        return self._tabMaxWidth

    def tabMinimumWidth(self):
        return self._tabMinWidth

    def isScrollable(self):
        return self._isScrollable

    def count(self):
        """返回标签页数量"""
        return len(self.items)

    def clear(self):
        """移除所有标签页"""
        while self.count() > 0:
            self.removeTab(self.count() - 1)

    def mousePressEvent(self, e: QMouseEvent):
        super().mousePressEvent(e)
        if not self.isMovable() or e.button() != Qt.LeftButton or \
                not self.itemLayout.geometry().contains(e.pos()):
            return

        self.dragPos = e.pos()

    def mouseMoveEvent(self, e: QMouseEvent):
        super().mouseMoveEvent(e)

        if not self.isMovable() or self.count() <= 1 or not self.itemLayout.geometry().contains(e.pos()):
            return

        index = self.currentIndex()
        item = self.tabItem(index)
        dx = e.pos().x() - self.dragPos.x()
        self.dragPos = e.pos()

        # first tab can't move left
        if index == 0 and dx < 0 and item.x() <= 0:
            return

        # last tab can't move right
        if index == self.count() - 1 and dx > 0 and item.geometry().right() >= self.itemLayout.sizeHint().width():
            return

        item.move(item.x() + dx, item.y())
        self.isDraging = True

        # move left sibling 项 到 right
        if dx < 0 and index > 0:
            siblingIndex = index - 1

            if item.x() < self.tabItem(siblingIndex).geometry().center().x():
                self._swapItem(siblingIndex)

        # move right sibling 项 到 left
        elif dx > 0 and index < self.count() - 1:
            siblingIndex = index + 1

            if item.geometry().right() > self.tabItem(siblingIndex).geometry().center().x():
                self._swapItem(siblingIndex)

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)

        if not self.isMovable() or not self.isDraging:
            return

        self.isDraging = False

        item = self.tabItem(self.currentIndex())
        x = self.tabRect(self.currentIndex()).x()
        duration = int(abs(item.x() - x) * 250 / item.width())
        item.slideTo(x, duration)
        item.slideAni.finished.connect(self._adjustLayout)

    def _adjustLayout(self):
        self.sender().finished.disconnect()

        for item in self.items:
            self.itemLayout.removeWidget(item)

        for item in self.items:
            self.itemLayout.addWidget(item)

    def _swapItem(self, index: int):
        items = self.items
        swappedItem = self.tabItem(index)
        x = self.tabRect(self.currentIndex()).x()

        oldIndex = self.currentIndex()
        items[oldIndex], items[index] = items[index], items[oldIndex]
        self._currentIndex = index
        swappedItem.slideTo(x)

        self.tabMoved.emit(oldIndex, index)

    movable = Property(bool, isMovable, setMovable)
    scrollable = Property(bool, isScrollable, setScrollable)
    tabMaxWidth = Property(int, tabMaximumWidth, setTabMaximumWidth)
    tabMinWidth = Property(int, tabMinimumWidth, setTabMinimumWidth)
    tabShadowEnabled = Property(bool, isTabShadowEnabled, setTabShadowEnabled)


class TabWidget(QWidget):
    """Tab 控件
    提供包含标签栏和内容区的多页面容器，集成 TabBar 与堆叠面板实现页面切换
    适用于需要在同一窗口内组织多个关联视图或配置页的场景，支持动态增删标签页
    """

    currentChanged = Signal(int)
    tabBarClicked = Signal(int)
    tabCloseRequested = Signal(int)
    tabAddRequested = Signal()
    tabBarDoubleClicked = Signal(int)

    def __init__(self, parent=None):
        """初始化 TabWidget
        
        Args:
            parent: 父控件。若为 None，则作为独立窗口显示；否则嵌入父控件并随其释放
        """
        super().__init__(parent)
        self.tabBar = TabBar(self)
        self.stackedWidget = QStackedWidget(self)
        self.vBoxLayout = QVBoxLayout(self)

        self.__initWidget()

    def __initWidget(self):
        self.vBoxLayout.addWidget(self.tabBar, 0, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.stackedWidget, 1)
        self.vBoxLayout.setSpacing(1)
        self.vBoxLayout.setContentsMargins(0, 0, 0, 0)

        self._connectTabBarSignalToSlot()

    def addPage(self, widget: QWidget, label: str, icon: Union[QIcon, str, FluentIconBase] = None, routeKey=None) -> int:
        """添加页面到标签部件并返回标签页索引
        
        Args:
            widget: 新标签页对应的部件
            label: 标签页标题
            icon: 标签页图标
            routeKey: 新标签页的路由键，如果未提供将自动生成唯一 UUID
        
        Returns:
            标签页索引
        """
        return self.insertTab(-1, widget, label, icon, routeKey)

    def addTab(self, widget: QWidget, label: str, icon: Union[QIcon, str, FluentIconBase] = None, routeKey=None) -> int:
        """添加标签页并返回其索引
        
        Args:
            widget: 新标签页对应的部件
            label: 标签页标题
            icon: 标签页图标
            routeKey: 新标签页的路由键，如果未提供将自动生成唯一 UUID
        
        Returns:
            标签页索引
        """
        return self.insertTab(-1, widget, label, icon, routeKey)

    def insertTab(self, index: int, widget: QWidget, label: str, icon: Union[QIcon, str, FluentIconBase] = None, routeKey=None) -> int:
        """在指定位置插入标签页并返回其索引
        
        Args:
            index: 插入位置
            widget: 新标签页对应的部件
            label: 标签页标题
            icon: 标签页图标
            routeKey: 新标签页的路由键，如果未提供将自动生成唯一 UUID
        
        Returns:
            标签页索引
        """
        if self.stackedWidget.indexOf(widget) >= 0:
            return -1

        # generate unique 路由键
        routeKey = routeKey or uuid1().hex
        widget.setProperty('routeKey', routeKey)

        # 创建新标签页.
        self.tabBar.insertTab(index, routeKey, label, icon)
        self.stackedWidget.insertWidget(index, widget)

        return self.stackedWidget.indexOf(widget)

    def removeTab(self, index: int):
        """从堆叠部件中移除指定索引的标签页，页面部件本身不会被删除
        
        Args:
            index: 要移除的部件索引
        """
        if not 0 <= index < self.stackedWidget.count():
            return

        self.stackedWidget.removeWidget(self.stackedWidget.widget(index))
        self.tabBar.removeTab(index)

    def clear(self):
        """移除所有页面，但不会删除它们"""
        while self.stackedWidget.count():
            self.stackedWidget.removeWidget(self.stackedWidget.widget(0))

        self.tabBar.clear()

    def widget(self, index: int):
        """返回指定索引的标签页，如果索引越界则返回 None
        
        Args:
            index: 标签页索引
        """
        return self.stackedWidget.widget(index)

    def currentWidget(self) -> QWidget:
        """返回当前显示的页面"""
        return self.stackedWidget.currentWidget()

    def currentIndex(self):
        """返回当前标签页索引，如果没有当前部件则返回 -1"""
        return self.stackedWidget.currentIndex()

    def setTabBar(self, tabBar):
        """使用新的标签栏替换原始标签栏，注意必须在添加任何标签页之前调用，否则行为未定义
        
        Args:
            tabBar: 新的标签栏
        """
        if tabBar == self.tabBar:
            return

        if self.tabBar:
            self.vBoxLayout.removeWidget(self.tabBar)
            self.tabBar.deleteLater()
            self.tabBar.hide()

        self.tabBar = tabBar
        self.vBoxLayout.insertWidget(0, self.tabBar)
        self._connectTabBarSignalToSlot()

    def isMovable(self):
        """返回用户是否可以在标签栏区域内移动标签页"""
        return self.tabBar.isMovable()

    def setMovable(self, movable: bool):
        self.tabBar.setMovable(movable)

    def isTabEnabled(self, index: int):
        return self.tabBar.isTabEnabled(index)

    def setTabEnabled(self, index: int, isEnabled: bool):
        self.tabBar.setTabEnabled(index, isEnabled)

    def isTabVisible(self, index: int):
        return self.tabBar.isTabVisible(index)

    def setTabVisible(self, index: int, isVisible: bool):
        self.tabBar.setTabVisible(index, isVisible)

    def tabText(self, index: int):
        return self.tabBar.tabText(index)

    def tabIcon(self, index: int):
        return self.tabBar.tabIcon(index)

    def tabToolTip(self, index: int):
        return self.tabBar.tabToolTip(index)

    def setTabsClosable(self, closable: bool):
        self.tabBar.setTabsClosable(closable)

    def tabsClosable(self) -> bool:
        return self.tabBar.tabsClosable()

    def setTabIcon(self, index: int, icon: Union[QIcon, FluentIconBase, str]):
        self.tabBar.setTabIcon(index, icon)

    def setTabText(self, index: int, text: str):
        self.tabBar.setTabText(index, text)

    def setTabToolTip(self, index: int, tip: str):
        self.tabBar.setTabToolTip(index, tip)

    def setTabTextColor(self, index: int, color):
        self.tabBar.setTabTextColor(index, color)

    def setTabSelectedBackgroundColor(self, light, dark):
        self.tabBar.setTabSelectedBackgroundColor(light, dark)

    def setTabShadowEnabled(self, enabled: bool):
        self.tabBar.setTabShadowEnabled(enabled)

    def setScrollable(self, scrollable: bool):
        self.tabBar.setScrollable(scrollable)

    def isScrollable(self) -> bool:
        return self.tabBar.isScrollable()

    def setTabMaximumWidth(self, width: int):
        self.tabBar.setTabMaximumWidth(width)

    def setTabMinimumWidth(self, width: int):
        self.tabBar.setTabMinimumWidth(width)

    def tabMaximumWidth(self) -> int:
        return self.tabBar.tabMaximumWidth()

    def tabMinimumWidth(self) -> int:
        return self.tabBar.tabMinimumWidth()

    def tabData(self, index: int):
        return self.tabBar.tabData(index)

    def setTabData(self, index: int, data):
        self.tabBar.setTabData(index, data)

    def count(self) -> int:
        """返回标签栏中的标签页数量"""
        return self.stackedWidget.count()

    def setCurrentIndex(self, index: int):
        """设置当前索引
        
        Args:
            index: 当前索引
        """
        self.tabBar.setCurrentIndex(index)
        self.stackedWidget.setCurrentIndex(index)

    def setCurrentWidget(self, widget: QWidget):
        """将当前标签页切换到包含该部件的标签
        
        Args:
            widget: 目标部件
        """
        index = self.stackedWidget.indexOf(widget)
        if index != -1:
            self.setCurrentIndex(index)

    def setCloseButtonDisplayMode(self, mode: TabCloseButtonDisplayMode):
        self.tabBar.setCloseButtonDisplayMode(mode)

    def _connectTabBarSignalToSlot(self):
        self.tabBar.tabCloseRequested.connect(self.tabCloseRequested)
        self.tabBar.tabBarClicked.connect(self.tabBarClicked)
        self.tabBar.tabBarDoubleClicked.connect(self.tabBarDoubleClicked)
        self.tabBar.tabAddRequested.connect(self.tabAddRequested)
        self.tabBar.currentChanged.connect(self._onCurrentTabChanged)
        self.tabBar.tabMoved.connect(self._onTabMoved)

    def _onTabMoved(self, fromIndex: int, toIndex: int):
        widget = self.stackedWidget.widget(fromIndex)
        self.stackedWidget.removeWidget(widget)
        self.stackedWidget.insertWidget(toIndex, widget)
        self.stackedWidget.setCurrentIndex(toIndex)

    def _onCurrentTabChanged(self, index: int):
        self.stackedWidget.setCurrentIndex(index)
        self.currentChanged.emit(index)
