# coding: utf-8
from enum import Enum
from PySide6.QtCore import (QEvent, QEasingCurve, Qt, Signal, QPropertyAnimation, Property, QRectF,
                          QTimer, QPoint, QObject)
from PySide6.QtGui import QPainter, QColor, QMouseEvent
from PySide6.QtWidgets import (QWidget, QToolButton, QAbstractScrollArea, QGraphicsOpacityEffect,
                             QHBoxLayout, QVBoxLayout, QApplication, QAbstractItemView, QListView)

from ...common.icon import FluentIcon
from ...common.style_sheet import isDarkTheme
from ...common.smooth_scroll import SmoothScroll

class ArrowButton(QToolButton):
    """Arrow 按钮，用于滚动条两端控制滚动方向
    
    通常在 ScrollBar 内部使用，点击后会以固定步长微调滚动位置，支持上下左右四个方向
    """

    def __init__(self, icon: FluentIcon, parent=None):
        """创建 ArrowButton 实例
        
        Args:
            icon: 按钮显示的箭头图标，决定按钮方向
            parent: 父级 QWidget 实例
        """
        super().__init__(parent=parent)
        self.setFixedSize(10, 10)
        self.lightColor = QColor(0, 0, 0, 114)
        self.darkColor = QColor(255, 255, 255, 139)
        self._icon = icon
        self.opacity = 1

    def setOpacity(self, opacity):
        self.opacity = opacity
        self.update()

    def setLightColor(self, color):
        self.lightColor = QColor(color)
        self.update()

    def setDarkColor(self, color):
        self.darkColor = QColor(color)
        self.update()

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHints(QPainter.Antialiasing)

        color = self.darkColor if isDarkTheme() else self.lightColor
        painter.setOpacity(self.opacity * color.alpha() / 255)

        s = 7 if self.isDown() else 8
        x = (self.width() - s) / 2
        self._icon.render(painter, QRectF(x, x, s, s), fill=color.name())


class ScrollBarGroove(QWidget):
    """滚动条 groove，作为 handle 滑动的轨道背景
    
    负责渲染滚动条轨道的视觉区域，与 ScrollBarHandle 配合完成滚动交互，通常不需要单独使用
    """

    def __init__(self, orient: Qt.Orientation, parent):
        """创建 ScrollBarGroove 实例
        
        Args:
            orient: 滚动条方向，Qt.Orientation 的 Horizontal 或 Vertical
            parent: 父级 QWidget 实例
        """
        super().__init__(parent=parent)
        self._opacity = 1
        self.lightBackgroundColor = QColor(252, 252, 252, 217)
        self.darkBackgroundColor = QColor(44, 44, 44, 245)

        if orient == Qt.Vertical:
            self.setFixedWidth(12)
            self.upButton = ArrowButton(FluentIcon.CARE_UP_SOLID, self)
            self.downButton = ArrowButton(FluentIcon.CARE_DOWN_SOLID, self)
            self.setLayout(QVBoxLayout(self))
            self.layout().addWidget(self.upButton, 0, Qt.AlignHCenter)
            self.layout().addStretch(1)
            self.layout().addWidget(self.downButton, 0, Qt.AlignHCenter)
            self.layout().setContentsMargins(0, 3, 0, 3)
        else:
            self.setFixedHeight(12)
            self.upButton = ArrowButton(FluentIcon.CARE_LEFT_SOLID, self)
            self.downButton = ArrowButton(FluentIcon.CARE_RIGHT_SOLID, self)
            self.setLayout(QHBoxLayout(self))
            self.layout().addWidget(self.upButton, 0, Qt.AlignVCenter)
            self.layout().addStretch(1)
            self.layout().addWidget(self.downButton, 0, Qt.AlignVCenter)
            self.layout().setContentsMargins(3, 0, 3, 0)

        self.opacityAni = QPropertyAnimation(self, b'opacity', self)
        self.setOpacity(0)

    def setLightBackgroundColor(self, color):
        self.lightBackgroundColor = QColor(color)
        self.update()

    def setDarkBackgroundColor(self, color):
        self.darkBackgroundColor = QColor(color)
        self.update()

    def fadeIn(self):
        self.opacityAni.stop()
        self.opacityAni.setStartValue(self.opacity)
        self.opacityAni.setEndValue(1)
        self.opacityAni.setDuration(150)
        self.opacityAni.start()

    def fadeOut(self):
        self.opacityAni.stop()
        self.opacityAni.setStartValue(self.opacity)
        self.opacityAni.setEndValue(0)
        self.opacityAni.setDuration(150)
        self.opacityAni.start()

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHints(QPainter.Antialiasing)
        painter.setOpacity(self.opacity)
        painter.setPen(Qt.NoPen)

        painter.setBrush(self.darkBackgroundColor if isDarkTheme() else self.lightBackgroundColor)
        painter.drawRoundedRect(self.rect(), 6, 6)

    def setOpacity(self, opacity: float):
        self._opacity = opacity
        self.upButton.setOpacity(opacity)
        self.downButton.setOpacity(opacity)
        self.update()

    def getOpacity(self) -> float:
        return self._opacity

    opacity = Property(float, getOpacity, setOpacity)


class ScrollBarHandle(QWidget):
    """滚动条 handle，用户直接拖拽以改变滚动位置的滑块
    
    跟随鼠标拖拽在 groove 上移动，其长度通常与可视区域和总内容的比例相关，支持悬停和按下状态样式切换
    """

    def __init__(self, orient: Qt.Orientation, parent=None):
        """创建 ScrollBarHandle 实例
        
        Args:
            orient: 滚动条方向，Qt.Orientation 的 Horizontal 或 Vertical
            parent: 父级 QWidget 实例
        """
        super().__init__(parent)
        self._opacity = 1
        self.opacityAni = QPropertyAnimation(self, b'opacity', self)
        self.lightColor = QColor(0, 0, 0, 114)
        self.darkColor = QColor(255, 255, 255, 139)
        self.orient = orient
        if orient == Qt.Vertical:
            self.setFixedWidth(3)
        else:
            self.setFixedHeight(3)

    def setLightColor(self, color):
        self.lightColor = QColor(color)
        self.update()

    def setDarkColor(self, color):
        self.darkColor = QColor(color)
        self.update()

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHints(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)

        r = self.width() / 2 if self.orient == Qt.Vertical else self.height() / 2
        painter.setOpacity(self.opacity)
        painter.setBrush(self.darkColor if isDarkTheme() else self.lightColor)
        painter.drawRoundedRect(self.rect(), r, r)

    def fadeIn(self):
        self.opacityAni.stop()
        self.opacityAni.setStartValue(self.opacity)
        self.opacityAni.setEndValue(1)
        self.opacityAni.setDuration(150)
        self.opacityAni.start()

    def fadeOut(self):
        self.opacityAni.stop()
        self.opacityAni.setStartValue(self.opacity)
        self.opacityAni.setEndValue(0)
        self.opacityAni.setDuration(150)
        self.opacityAni.start()

    def setOpacity(self, opacity: float):
        self._opacity = opacity
        self.update()

    def getOpacity(self) -> float:
        return self._opacity

    opacity = Property(float, getOpacity, setOpacity)


class ScrollBarHandleDisplayMode(Enum):
    """滚动条 handle 显示模式枚举
    
    用于控制 handle 的可见性策略，如始终显示、仅悬停时显示等，可通过 setHandleVisibleMode 应用到 ScrollBar 上
    """

    ALWAYS = 0
    ON_HOVER = 1


class ScrollBar(QWidget):
    """Fluent 风格滚动条，替代系统原生滚动条
    
    提供美观的统一视觉风格，支持自定义 handle 显示模式、动画效果以及丰富的状态样式，适用于 ListView、TableView 等需要滚动功能的组件
    """

    rangeChanged = Signal(tuple)
    valueChanged = Signal(int)
    sliderPressed = Signal()
    sliderReleased = Signal()
    sliderMoved = Signal()

    def __init__(self, orient: Qt.Orientation, parent: QAbstractScrollArea):
        """创建 ScrollBar 实例
        
        Args:
            orient: 滚动条方向，Qt.Orientation 的 Horizontal 或 Vertical
            parent: 父级 QWidget 实例
        """
        super().__init__(parent)
        self.groove = ScrollBarGroove(orient, self)
        self.handle = ScrollBarHandle(orient, self)

        self._orientation = orient
        self._singleStep = 1
        self._pageStep = 50
        self._padding = 14

        self._minimum = 0
        self._maximum = 0
        self._value = 0

        self._isPressed = False
        self._isEnter = False
        self._isExpanded = False
        self._pressedPos = QPoint()
        self._isForceHidden = False
        self.handleDisplayMode = ScrollBarHandleDisplayMode.ALWAYS

        if orient == Qt.Vertical:
            self.partnerBar = parent.verticalScrollBar()
            QAbstractScrollArea.setVerticalScrollBarPolicy(parent, Qt.ScrollBarAlwaysOff)
        else:
            self.partnerBar = parent.horizontalScrollBar()
            QAbstractScrollArea.setHorizontalScrollBarPolicy(parent, Qt.ScrollBarAlwaysOff)

        self.__initWidget(parent)

    def __initWidget(self, parent):
        self.groove.upButton.clicked.connect(self._onPageUp)
        self.groove.downButton.clicked.connect(self._onPageDown)
        self.groove.opacityAni.valueChanged.connect(self._onOpacityAniValueChanged)

        self.partnerBar.rangeChanged.connect(self.setRange)
        self.partnerBar.valueChanged.connect(self._onValueChanged)
        self.valueChanged.connect(self.partnerBar.setValue)

        parent.installEventFilter(self)

        self.setRange(self.partnerBar.minimum(), self.partnerBar.maximum())
        self.setVisible(self.maximum() > 0 and not self._isForceHidden)
        self._adjustPos(self.parent().size())

    def _onPageUp(self):
        self.setValue(self.value() - self.pageStep())

    def _onPageDown(self):
        self.setValue(self.value() + self.pageStep())

    def _onValueChanged(self, value):
        self.val = value

    def value(self):
        return self._value

    @Property(int, notify=valueChanged)
    def val(self):
        return self._value

    @val.setter
    def val(self, value: int):
        if value == self.value():
            return

        value = max(self.minimum(), min(value, self.maximum()))
        self._value = value
        self.valueChanged.emit(value)

        # 调整滑块位置.
        self._adjustHandlePos()

    def minimum(self):
        return self._minimum

    def maximum(self):
        return self._maximum

    def orientation(self):
        return self._orientation

    def pageStep(self):
        return self._pageStep

    def singleStep(self):
        return self._singleStep

    def isSliderDown(self):
        return self._isPressed

    def setValue(self, value: int):
        self.val = value

    def setMinimum(self, min: int):
        if min == self.minimum():
            return

        self._minimum = min
        self.rangeChanged.emit((min, self.maximum()))

    def setMaximum(self, max: int):
        if max == self.maximum():
            return

        self._maximum = max
        self.rangeChanged.emit((self.minimum(), max))

    def setRange(self, min: int, max: int):
        if min > max or (min == self.minimum() and max == self.maximum()):
            return

        self.setMinimum(min)
        self.setMaximum(max)

        self._adjustHandleSize()
        self._adjustHandlePos()
        self.setVisible(max > 0 and not self._isForceHidden)

        self.rangeChanged.emit((min, max))

    def setPageStep(self, step: int):
        if step >= 1:
            self._pageStep = step

    def setSingleStep(self, step: int):
        if step >= 1:
            self._singleStep = step

    def setSliderDown(self, isDown: bool):
        self._isPressed = True
        if isDown:
            self.sliderPressed.emit()
        else:
            self.sliderReleased.emit()

    def setHandleColor(self, light, dark):
        """设置 handle 的颜色
        
        Args:
            light (QColor | str | Qt.GlobalColor): 亮色主题下的颜色
            dark (QColor | str | Qt.GlobalColor): 暗色主题下的颜色
        """
        self.handle.setLightColor(light)
        self.handle.setDarkColor(dark)

    def setArrowColor(self, light, dark):
        """设置 arrow 的颜色
        
        Args:
            light (QColor | str | Qt.GlobalColor): 亮色主题下的颜色
            dark (QColor | str | Qt.GlobalColor): 暗色主题下的颜色
        """
        self.groove.upButton.setLightColor(light)
        self.groove.upButton.setDarkColor(dark)
        self.groove.downButton.setLightColor(light)
        self.groove.downButton.setDarkColor(dark)

    def setGrooveColor(self, light, dark):
        """设置 groove 的颜色
        
        Args:
            light (QColor | str | Qt.GlobalColor): 亮色主题下的颜色
            dark (QColor | str | Qt.GlobalColor): 暗色主题下的颜色
        """
        self.groove.setLightBackgroundColor(light)
        self.groove.setDarkBackgroundColor(dark)

    def setHandleDisplayMode(self, mode: ScrollBarHandleDisplayMode):
        """设置 handle 的显示模式
        
        Args:
            mode (ScrollBarHandleDisplayMode): 显示模式
        """
        if mode == self.handleDisplayMode:
            return

        self.handleDisplayMode = mode
        if mode == ScrollBarHandleDisplayMode.ON_HOVER and not self._isEnter:
            self.handle.fadeOut()
        elif mode == ScrollBarHandleDisplayMode.ALWAYS:
            self.handle.fadeIn()

    def expand(self):
        """展开滚动条"""
        if self._isExpanded or not self._isEnter:
            return

        self._isExpanded = True
        self.groove.fadeIn()
        self.handle.fadeIn()

    def collapse(self):
        """折叠滚动条"""
        if not self._isExpanded or self._isEnter:
            return

        self._isExpanded = False
        self.groove.fadeOut()

        if self.handleDisplayMode == ScrollBarHandleDisplayMode.ON_HOVER:
            self.handle.fadeOut()

    def enterEvent(self, e):
        self._isEnter = True
        QTimer.singleShot(200, self.expand)

    def leaveEvent(self, e):
        self._isEnter = False
        QTimer.singleShot(200, self.collapse)

    def eventFilter(self, obj, e: QEvent):
        if obj is not self.parent():
            return super().eventFilter(obj, e)

        # 调整滑块位置.
        if e.type() == QEvent.Resize:
            self._adjustPos(e.size())

        return super().eventFilter(obj, e)

    def resizeEvent(self, e):
        self.groove.resize(self.size())

    def mousePressEvent(self, e: QMouseEvent):
        super().mousePressEvent(e)
        self._isPressed = True
        self._pressedPos = e.pos()

        if self.childAt(e.pos()) is self.handle or not self._isSlideResion(e.pos()):
            return

        if self.orientation() == Qt.Vertical:
            if e.pos().y() > self.handle.geometry().bottom():
                value = e.pos().y() - self.handle.height() - self._padding
            else:
                value = e.pos().y() - self._padding
        else:
            if e.pos().x() > self.handle.geometry().right():
                value = e.pos().x() - self.handle.width() - self._padding
            else:
                value = e.pos().x() - self._padding

        self.setValue(int(value / max(self._slideLength(), 1) * self.maximum()))
        self.sliderPressed.emit()

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)
        self._isPressed = False
        self.sliderReleased.emit()

    def mouseMoveEvent(self, e: QMouseEvent):
        if self.orientation() == Qt.Vertical:
            dv = e.pos().y() - self._pressedPos.y()
        else:
            dv = e.pos().x() - self._pressedPos.x()

        # don't use `self.setValue()`, 因为 it could be reimplemented
        dv = int(dv / max(self._slideLength(), 1) * (self.maximum() - self.minimum()))
        ScrollBar.setValue(self, self.value() + dv)

        self._pressedPos = e.pos()
        self.sliderMoved.emit()

    def _adjustPos(self, size):
        if self.orientation() == Qt.Vertical:
            self.resize(12, size.height() - 2)
            self.move(size.width() - 13, 1)
        else:
            self.resize(size.width() - 2, 12)
            self.move(1, size.height() - 13)

    def _adjustHandleSize(self):
        p = self.parent()
        if self.orientation() == Qt.Vertical:
            total = self.maximum() - self.minimum() + p.height()
            s = int(self._grooveLength() * p.height() / max(total, 1))
            self.handle.setFixedHeight(max(30, s))
        else:
            total = self.maximum() - self.minimum() + p.width()
            s = int(self._grooveLength() * p.width() / max(total, 1))
            self.handle.setFixedWidth(max(30, s))

    def _adjustHandlePos(self):
        total = max(self.maximum() - self.minimum(), 1)
        delta = int(self.value() / total * self._slideLength())

        if self.orientation() == Qt.Vertical:
            x = self.width() - self.handle.width() - 3
            self.handle.move(x, self._padding + delta)
        else:
            y = self.height() - self.handle.height() - 3
            self.handle.move(self._padding + delta, y)

    def _grooveLength(self):
        if self.orientation() == Qt.Vertical:
            return self.height() - 2 * self._padding

        return self.width() - 2 * self._padding

    def _slideLength(self):
        if self.orientation() == Qt.Vertical:
            return self._grooveLength() - self.handle.height()

        return self._grooveLength() - self.handle.width()

    def _isSlideResion(self, pos: QPoint):
        if self.orientation() == Qt.Vertical:
            return self._padding <= pos.y() <= self.height() - self._padding

        return self._padding <= pos.x() <= self.width() - self._padding

    def _onOpacityAniValueChanged(self):
        opacity = self.groove.opacity
        if self.orientation() == Qt.Vertical:
            self.handle.setFixedWidth(int(3 + opacity * 3))
        else:
            self.handle.setFixedHeight(int(3 + opacity * 3))

        self._adjustHandlePos()

    def setForceHidden(self, isHidden: bool):
        """设置是否强制隐藏滚动条
        
        Args:
            isHidden: 是否强制隐藏
        """
        self._isForceHidden = isHidden
        self.setVisible(self.maximum() > 0 and not isHidden)

    def wheelEvent(self, e):
        QApplication.sendEvent(self.parent().viewport(), e)


class SmoothScrollBar(ScrollBar):
    """支持平滑动画的滚动条
    
    在 ScrollBar 基础上增加了动画插值，使滚动位置变化更加流畅自然，适合对滚动体验有较高要求的场景
    """

    def __init__(self, orient: Qt.Orientation, parent):
        """创建 SmoothScrollBar 实例
        
        Args:
            orient: 滚动条方向，Qt.Orientation 的 Horizontal 或 Vertical
            parent: 父级 QWidget 实例
        """
        super().__init__(orient, parent)
        self.duration = 500
        self.ani = QPropertyAnimation()
        self.ani.setTargetObject(self)
        self.ani.setPropertyName(b"val")
        self.ani.setEasingCurve(QEasingCurve.OutCubic)
        self.ani.setDuration(self.duration)

        self.__value = self.value()

    def setValue(self, value, useAni=True):
        if value == self.value():
            return

        # 停止running 动画
        self.ani.stop()

        if not useAni:
            self.val = value
            return

        # 调整动画时长.
        dv = abs(value - self.value())
        if dv < 50:
            self.ani.setDuration(int(self.duration * dv / 70))
        else:
            self.ani.setDuration(self.duration)

        self.ani.setStartValue(self.value())
        self.ani.setEndValue(value)
        self.ani.start()

    def scrollValue(self, value, useAni=True):
        """滚动指定距离
        
        Args:
            value: 滚动距离
            useAni: 是否使用动画
        """
        self.__value += value
        self.__value = max(self.minimum(), self.__value)
        self.__value = min(self.maximum(), self.__value)
        self.setValue(self.__value, useAni)

    def scrollTo(self, value, useAni=True):
        """滚动到指定位置
        
        Args:
            value: 目标位置
            useAni: 是否使用动画
        """
        self.__value = value
        self.__value = max(self.minimum(), self.__value)
        self.__value = min(self.maximum(), self.__value)
        self.setValue(self.__value, useAni)

    def resetValue(self, value):
        self.__value = value

    def mousePressEvent(self, e):
        self.ani.stop()
        super().mousePressEvent(e)
        self.__value = self.value()

    def mouseMoveEvent(self, e):
        self.ani.stop()
        super().mouseMoveEvent(e)
        self.__value = self.value()

    def setScrollAnimation(self, duration, easing=QEasingCurve.OutCubic):
        """设置滚动动画
        
        Args:
            duration (int): 滚动动画持续时间
            easing (QEasingCurve): 动画缓动曲线
        """
        self.duration = duration
        self.ani.setDuration(duration)
        self.ani.setEasingCurve(easing)


class SmoothScrollDelegate(QObject):
    """平滑滚动委托，为普通滚动区域注入平滑滚动能力
    
    通过拦截滚轮事件并委托给 SmoothScrollBar 处理，无需修改原有组件结构即可让 QScrollArea、QTextEdit 等控件获得平滑滚动效果
    """

    def __init__(self, parent: QAbstractScrollArea, useAni=False):
        """初始化平滑滚动委托
        
        Args:
            parent (QAbstractScrollArea): 被代理的滚动区域
            useAni (bool): 是否使用 QPropertyAnimation 实现平滑滚动
        """
        super().__init__(parent)
        self.useAni = useAni
        self.vScrollBar = SmoothScrollBar(Qt.Vertical, parent)
        self.hScrollBar = SmoothScrollBar(Qt.Horizontal, parent)
        self.verticalSmoothScroll = SmoothScroll(parent, Qt.Vertical)
        self.horizonSmoothScroll = SmoothScroll(parent, Qt.Horizontal)

        if isinstance(parent, QAbstractItemView):
            parent.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
            parent.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        if isinstance(parent, QListView):
            parent.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
            parent.horizontalScrollBar().setStyleSheet("QScrollBar:horizontal{height: 0px}")

        parent.viewport().installEventFilter(self)
        parent.setVerticalScrollBarPolicy = self.setVerticalScrollBarPolicy
        parent.setHorizontalScrollBarPolicy = self.setHorizontalScrollBarPolicy

    def eventFilter(self, obj, e: QEvent):
        if e.type() == QEvent.Type.Wheel:
            # Check 如果 vertical 滚动 is at its limit
            verticalAtEnd = (e.angleDelta().y() < 0 and self.vScrollBar.value() == self.vScrollBar.maximum()) or \
                            (e.angleDelta().y() > 0 and self.vScrollBar.value() == self.vScrollBar.minimum())

            # Check 如果 horizontal 滚动 is at its limit
            horizontalAtEnd = (e.angleDelta().x() < 0 and self.hScrollBar.value() == self.hScrollBar.maximum()) or \
                              (e.angleDelta().x() > 0 and self.hScrollBar.value() == self.hScrollBar.minimum())

            if verticalAtEnd or horizontalAtEnd:
                return False

            if e.angleDelta().y() != 0:
                if not self.useAni:
                    self.verticalSmoothScroll.wheelEvent(e)
                else:
                    self.vScrollBar.scrollValue(-e.angleDelta().y())
            else:
                if not self.useAni:
                    self.horizonSmoothScroll.wheelEvent(e)
                else:
                    self.hScrollBar.scrollValue(-e.angleDelta().x())

            e.setAccepted(True)
            return True

        return super().eventFilter(obj, e)

    def setVerticalScrollBarPolicy(self, policy):
        QAbstractScrollArea.setVerticalScrollBarPolicy(self.parent(), Qt.ScrollBarAlwaysOff)
        self.vScrollBar.setForceHidden(policy == Qt.ScrollBarAlwaysOff)

    def setHorizontalScrollBarPolicy(self, policy):
        QAbstractScrollArea.setHorizontalScrollBarPolicy(self.parent(), Qt.ScrollBarAlwaysOff)
        self.hScrollBar.setForceHidden(policy == Qt.ScrollBarAlwaysOff)
