# coding: utf-8
from PySide6.QtCore import QSize, Qt, Signal, QPoint, QRectF, QPropertyAnimation, Property, QEasingCurve
from PySide6.QtGui import QColor, QMouseEvent, QPainter, QPainterPath
from PySide6.QtWidgets import QProxyStyle, QSlider, QStyle, QStyleOptionSlider, QWidget

from ...common.style_sheet import FluentStyleSheet, themeColor, isDarkTheme
from ...common.color import autoFallbackThemeColor
from ...common.overload import singledispatchmethod



class SliderHandle(QWidget):
    """自定义绘制的滑块手柄控件，用于拖拽调节数值的可视化交互元素
    
    该类通常作为 Slider 或 ClickableSlider 的内部组件使用，支持鼠标悬停、按下等状态的样式实时切换。当需要实现自定义外观的滑块手柄（如空心圆环、渐变填充等）时，可配合 HollowHandleStyle 等样式类进行扩展，也适用于需要独立控制手柄渲染逻辑的多滑块场景
    """

    pressed = Signal()
    released = Signal()

    def __init__(self, parent: QSlider):
        """初始化滑块手柄实例
        
        Args:
            parent: 父级 QWidget 实例。指定父控件可确保手柄在滑块槽内正确嵌套并继承事件传递链，通常由 Slider 内部自动创建和设置
        """
        super().__init__(parent=parent)
        self.setFixedSize(22, 22)
        self._radius = 5
        self.lightHandleColor = QColor()
        self.darkHandleColor = QColor()
        self.radiusAni = QPropertyAnimation(self, b'radius', self)
        self.radiusAni.setDuration(100)

    @Property(int)
    def radius(self):
        return self._radius

    @radius.setter
    def radius(self, r):
        self._radius = r
        self.update()

    def setHandleColor(self, light, dark):
        self.lightHandleColor = QColor(light)
        self.darkHandleColor = QColor(dark)
        self.update()

    def enterEvent(self, e):
        self._startAni(6)

    def leaveEvent(self, e):
        self._startAni(5)

    def mousePressEvent(self, e):
        self._startAni(4)
        self.pressed.emit()

    def mouseReleaseEvent(self, e):
        self._startAni(6)
        self.released.emit()

    def _startAni(self, radius):
        self.radiusAni.stop()
        self.radiusAni.setStartValue(self.radius)
        self.radiusAni.setEndValue(radius)
        self.radiusAni.start()

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHints(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)

        # 绘制outer circle
        isDark = isDarkTheme()
        painter.setPen(QColor(0, 0, 0, 90 if isDark else 25))
        painter.setBrush(QColor(69, 69, 69) if isDark else Qt.GlobalColor.white)
        painter.drawEllipse(self.rect().adjusted(1, 1, -1, -1))

        # 绘制innert circle
        painter.setBrush(autoFallbackThemeColor(self.lightHandleColor, self.darkHandleColor))
        painter.drawEllipse(QPoint(11, 11), self.radius, self.radius)



class Slider(QSlider):
    """支持点击定位和 Fluent 风格渲染的滑块控件
    
    继承自 QSlider 并扩展了鼠标直接点击跳转的能力，无需拖拽手柄即可快速定位数值。支持水平与垂直两种方向，适用于音量调节、亮度控制、进度选择等需要连续数值输入的场景。可通过 setPageStep() 和 setSingleStep() 调整步进精度，配合样式代理可进一步自定义槽道与手柄的视觉效果
    
    构造函数重载:
        * Slider(parent: QWidget = None)
        * Slider(orient: Qt.Orientation, parent: QWidget = None)
    """

    clicked = Signal(int)

    @singledispatchmethod
    def __init__(self, parent: QWidget = None):
        """初始化滑块控件
        
        Args:
            parent: 父级 QWidget 实例，默认为 None。指定父控件后滑块将嵌入对应容器的布局体系中；若为 None，则作为独立控件存在，通常需要手动管理其几何位置与生命周期
        """
        super().__init__(parent)
        self._postInit()

    @__init__.register
    def _(self, orientation: Qt.Orientation, parent: QWidget = None):
        super().__init__(orientation, parent=parent)
        self._postInit()

    def _postInit(self):
        self.handle = SliderHandle(self)
        self._pressedPos = QPoint()
        self.lightGrooveColor = QColor()
        self.darkGrooveColor = QColor()
        self.setOrientation(self.orientation())

        self.handle.pressed.connect(self.sliderPressed)
        self.handle.released.connect(self.sliderReleased)
        self.valueChanged.connect(self._adjustHandlePos)

    def setThemeColor(self, light, dark):
        self.lightGrooveColor = QColor(light)
        self.darkGrooveColor = QColor(dark)
        self.handle.setHandleColor(light, dark)
        self.update()

    def setOrientation(self, orientation: Qt.Orientation) -> None:
        super().setOrientation(orientation)
        if orientation == Qt.Orientation.Horizontal:
            self.setMinimumHeight(22)
        else:
            self.setMinimumWidth(22)

    def mousePressEvent(self, e: QMouseEvent):
        self._pressedPos = e.pos()
        self.setValue(self._posToValue(e.pos()))
        self.clicked.emit(self.value())

    def mouseMoveEvent(self, e: QMouseEvent):
        self.setValue(self._posToValue(e.pos()))
        self._pressedPos = e.pos()
        self.sliderMoved.emit(self.value())

    @property
    def grooveLength(self):
        l = self.width() if self.orientation() == Qt.Orientation.Horizontal else self.height()
        return l - self.handle.width()

    def _adjustHandlePos(self):
        total = max(self.maximum() - self.minimum(), 1)
        delta = int((self.value() - self.minimum()) / total * self.grooveLength)

        if self.orientation() == Qt.Orientation.Vertical:
            self.handle.move(0, delta)
        else:
            self.handle.move(delta, 0)

    def _posToValue(self, pos: QPoint):
        pd = self.handle.width() / 2
        gs = max(self.grooveLength, 1)
        v = pos.x() if self.orientation() == Qt.Orientation.Horizontal else pos.y()
        return int((v - pd) / gs * (self.maximum() - self.minimum()) + self.minimum())

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHints(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(255, 255, 255, 115) if isDarkTheme() else QColor(0, 0, 0, 100))

        if self.orientation() == Qt.Orientation.Horizontal:
            self._drawHorizonGroove(painter)
            self._drawHorizonTick(painter)
        else:
            self._drawVerticalGroove(painter)
            self._drawVerticalTick(painter)

    def _drawHorizonTick(self, painter: QPainter):
        pass

    def _drawVerticalTick(self, painter: QPainter):
        pass

    def _drawHorizonGroove(self, painter: QPainter):
        w, r = self.width(), self.handle.width() / 2
        painter.drawRoundedRect(QRectF(r, r-2, w-r*2, 4), 2, 2)

        if self.maximum() - self.minimum() == 0:
            return

        painter.setBrush(autoFallbackThemeColor(self.lightGrooveColor, self.darkGrooveColor))
        aw = (self.value() - self.minimum()) / (self.maximum() - self.minimum()) * (w - r*2)
        painter.drawRoundedRect(QRectF(r, r-2, aw, 4), 2, 2)

    def _drawVerticalGroove(self, painter: QPainter):
        h, r = self.height(), self.handle.width() / 2
        painter.drawRoundedRect(QRectF(r-2, r, 4, h-2*r), 2, 2)

        if self.maximum() - self.minimum() == 0:
            return

        painter.setBrush(autoFallbackThemeColor(self.lightGrooveColor, self.darkGrooveColor))
        ah = (self.value() - self.minimum()) / (self.maximum() - self.minimum()) * (h - r*2)
        painter.drawRoundedRect(QRectF(r-2, r, 4, ah), 2, 2)

    def resizeEvent(self, e):
        self._adjustHandlePos()


class ClickableSlider(QSlider):
    """支持点击直接定位的滑块控件
    
    继承自 Slider 并优化了鼠标点击交互逻辑，点击滑块槽任意位置时手柄会直接跳转至对应数值，而非仅响应手柄拖拽区域。适用于需要频繁快速调节数值的场景（如视频进度条、缩放比例控制等），可显著提升用户操作效率。外观与行为遵循 Fluent Design 规范，支持水平与垂直方向
    """

    clicked = Signal(int)

    def mousePressEvent(self, e: QMouseEvent):
        super().mousePressEvent(e)

        if self.orientation() == Qt.Horizontal:
            value = int(e.pos().x() / self.width() * self.maximum())
        else:
            value = int((self.height()-e.pos().y()) /
                        self.height() * self.maximum())

        self.setValue(value)
        self.clicked.emit(self.value())



class HollowHandleStyle(QProxyStyle):
    """空心圆环样式的滑块手柄渲染策略
    
    该类定义了滑块手柄的中空视觉效果，通过仅绘制外轮廓而不填充中心区域的方式呈现轻量、现代的 Fluent 风格。适用于需要与实心手柄形成视觉层级区分、或界面整体采用极简/浅色主题的场景。通常作为参数传入 Slider 或 SliderHandle 的样式设置接口，也可作为自定义样式的基类进行扩展
    """

    def __init__(self, config: dict = None):
        """初始化
        
        Args:
            config: 样式配置
        """
        super().__init__()
        self.config = {
            "groove.height": 3,
            "sub-page.color": QColor(255, 255, 255),
            "add-page.color": QColor(255, 255, 255, 64),
            "handle.color": QColor(255, 255, 255),
            "handle.ring-width": 4,
            "handle.hollow-radius": 6,
            "handle.margin": 4
        }
        config = config if config else {}
        self.config.update(config)

        # 获取 处理 大小
        w = self.config["handle.margin"]+self.config["handle.ring-width"] + \
            self.config["handle.hollow-radius"]
        self.config["handle.size"] = QSize(2*w, 2*w)

    def subControlRect(self, cc: QStyle.ComplexControl, opt: QStyleOptionSlider, sc: QStyle.SubControl, widget: QSlider):
        """获取子控件所占的矩形区域
        
        Args:
            cc: 复杂控件类型
            opt: 滑动条选项
            sc: 子控件类型
            widget: 滑动条控件
        """
        if cc != self.ComplexControl.CC_Slider or widget.orientation() != Qt.Horizontal \
                or sc == self.SubControl.SC_SliderTickmarks:
            return super().subControlRect(cc, opt, sc, widget)

        rect = widget.rect()

        if sc == self.SubControl.SC_SliderGroove:
            h = self.config["groove.height"]
            grooveRect = QRectF(0, (rect.height()-h)//2, rect.width(), h)
            return grooveRect.toRect()

        elif sc == self.SubControl.SC_SliderHandle:
            size = self.config["handle.size"]
            x = self.sliderPositionFromValue(
                widget.minimum(), widget.maximum(), widget.value(), rect.width())

            # solve situation that 处理 runs out 的 slider
            x *= (rect.width()-size.width())/rect.width()
            sliderRect = QRectF(x, 0, size.width(), size.height())
            return sliderRect.toRect()

    def drawComplexControl(self, cc: QStyle.ComplexControl, opt: QStyleOptionSlider, painter: QPainter, widget: QSlider):
        """绘制子控件
        
        Args:
            cc: 复杂控件类型
            opt: 滑动条选项
            painter: 绘制器
            widget: 滑动条控件
        """
        if cc != self.ComplexControl.CC_Slider or widget.orientation() != Qt.Horizontal:
            return super().drawComplexControl(cc, opt, painter, widget)

        grooveRect = self.subControlRect(cc, opt, self.SubControl.SC_SliderGroove, widget)
        handleRect = self.subControlRect(cc, opt, self.SubControl.SC_SliderHandle, widget)
        painter.setRenderHints(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)

        # 绘制groove
        painter.save()
        painter.translate(grooveRect.topLeft())

        # 绘制已覆盖部分.
        w = handleRect.x()-grooveRect.x()
        h = self.config['groove.height']
        painter.setBrush(self.config["sub-page.color"])
        painter.drawRect(0, 0, w, h)

        # 绘制未覆盖部分.
        x = w+self.config['handle.size'].width()
        painter.setBrush(self.config["add-page.color"])
        painter.drawRect(x, 0, grooveRect.width()-w, h)
        painter.restore()

        # 绘制处理
        ringWidth = self.config["handle.ring-width"]
        hollowRadius = self.config["handle.hollow-radius"]
        radius = ringWidth + hollowRadius

        path = QPainterPath()
        path.moveTo(0, 0)
        center = handleRect.center() + QPoint(1, 1)
        path.addEllipse(center, radius, radius)
        path.addEllipse(center, hollowRadius, hollowRadius)

        handleColor = self.config["handle.color"]  # type:QColor
        handleColor.setAlpha(255 if opt.activeSubControls !=
                             self.SubControl.SC_SliderHandle else 153)
        painter.setBrush(handleColor)
        painter.drawPath(path)

        # press 处理
        if widget.isSliderDown():
            handleColor.setAlpha(255)
            painter.setBrush(handleColor)
            painter.drawEllipse(handleRect)
