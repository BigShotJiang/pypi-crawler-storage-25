# coding: utf-8
"""提供可展开折叠的自定义布局类

该模块包含 ExpandLayout，用于垂直管理一组可展开控件，根据子控件的展开状态动态调整整体尺寸，常用于设置面板、分组列表等场景
"""

from PySide6.QtCore import QSize, QPoint, Qt, QEvent, QRect
from PySide6.QtGui import QResizeEvent
from PySide6.QtWidgets import QLayout, QWidget


class ExpandLayout(QLayout):
    """垂直可展开布局
    
    用于排列支持展开/折叠的子控件，并根据各控件的展开状态自动计算总高度，适用于需要动态展示或隐藏详细内容的设置面板、折叠列表等界面，一般与 ExpandGroupSettingCard 配合使用
    """

    def __init__(self, parent=None):
        """初始化布局
        
        Args:
            parent (QWidget | None): 父控件，默认为 None，若指定了父控件，布局将自动安装到该控件上并跟随其尺寸变化
        """
        super().__init__(parent)
        self.__items = []
        self.__widgets = []

    def addWidget(self, widget: QWidget):
        if widget in self.__widgets:
            return

        self.__widgets.append(widget)
        widget.installEventFilter(self)

    def addItem(self, item):
        self.__items.append(item)

    def count(self):
        return len(self.__items)

    def itemAt(self, index):
        if 0 <= index < len(self.__items):
            return self.__items[index]

        return None

    def takeAt(self, index):
        if 0 <= index < len(self.__items):
            self.__widgets.pop(index)
            return self.__items.pop(index)

        return None

    def expandingDirections(self):
        return Qt.Vertical

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        """根据宽度计算最小高度

        Args:
            width: 布局宽度

        Returns:
            对应的最小高度
        """
        return self.__doLayout(QRect(0, 0, width, 0), False)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self.__doLayout(rect, True)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()

        for w in self.__widgets:
            size = size.expandedTo(w.minimumSize())

        m = self.contentsMargins()
        size += QSize(m.left()+m.right(), m.top()+m.bottom())

        return size

    def __doLayout(self, rect, move):
        """根据窗口大小调整部件位置

        Args:
            rect: 布局矩形
            move: 是否移动部件

        Returns:
            布局总高度
        """
        margin = self.contentsMargins()
        x = rect.x() + margin.left()
        y = rect.y() + margin.top()
        width = rect.width() - margin.left() - margin.right()

        for i, w in enumerate(self.__widgets):
            if w.isHidden():
                continue

            y += (i>0)*self.spacing()
            if move:
                w.setGeometry(QRect(QPoint(x, y), QSize(width, w.height())))

            y += w.height()

        return y - rect.y()

    def eventFilter(self, obj, e):
        if obj in self.__widgets:
            if e.type() == QEvent.Resize:
                ds = e.size() - e.oldSize()  # type:QSize
                if ds.height() != 0 and ds.width() == 0:
                    w = self.parentWidget()
                    w.resize(w.width(), w.height() + ds.height())

        return super().eventFilter(obj, e)