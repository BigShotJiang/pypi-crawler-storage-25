
DEFAULT_ENCODING_STR = "utf-8"

def str_to_bytes(s:str, encoding="utf-8", error_handing="ignore"):
    return s.encode(encoding, errors=error_handing)

def bytes_to_str(b:bytes, encoding="utf-8", error_handling="ignore"):
    return b.decode(encoding, errors=error_handling)