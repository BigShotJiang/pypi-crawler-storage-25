
from romayneutils.helpers_util import dprint

from stealthium import StealthChrome

from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.chrome.options import Options

# A simple set of configuration options to use for creating a chrome webdriver.
def get_driver(verbose:bool = False) -> WebDriver:
    dprint("Loading webdriver...", do_print=verbose)
    options:Options = Options()
    options.add_argument('--remote-debugging-pipe')
    #options.add_argument(rf'--user-data-dir="C:\Users\Romayne\AppData\Local\Google\Chrome\User Data"')
    options.add_argument(rf'--profile-directory=Profile 1')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.binary_location = rf'C:\Program Files\Google\Chrome\Application\chrome.exe'
    driver:WebDriver = StealthChrome(options=options, headless=False)
    dprint("Waiting for webdriver to load...", do_print=verbose)
    driver.implicitly_wait(5)
    dprint("Successfully loaded webdriver.", do_print=verbose)
    return driver
