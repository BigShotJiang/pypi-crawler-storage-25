
print("DEPRECIATED")

"""
def make_request(url, write = True, outfile:str = "general_api_output.txt", encoding="utf-8", method = "a", params = {}):
    response = get(url, params)
    decoded_content = response.content.decode(encoding, errors="ignore")
    if (write):
        write_file_contents(outfile, decoded_content, method)
    return decoded_content, response.status_code

def get_request_url(request_type):
    from config import request_urls, api_url
    if request_type not in request_urls.keys():
        raise NotImplementedError(f"{request_type} not implemented into config dict request_urls")
    return f"{api_url}{request_urls[request_type]}"
"""