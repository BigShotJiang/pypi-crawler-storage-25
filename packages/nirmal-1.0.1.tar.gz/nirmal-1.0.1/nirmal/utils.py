"""
utils.py — Utility helpers for the nirmal package.
"""

import re


# Pre-compiled regex patterns for performance
_BACKTICK_FENCE_RE = re.compile(r"^```[a-zA-Z]*\n?", re.MULTILINE)
_CLOSING_FENCE_RE  = re.compile(r"^```\s*$",          re.MULTILINE)


def clean_markdown(text: str) -> str:
    """
    Remove common markdown code-fence artifacts from streamed AI output.

    The backend instructs the model not to wrap output in triple backticks,
    but this function acts as a safety net in case the model disobeys.

    Args:
        text (str): A raw streamed chunk of text from the AI.

    Returns:
        str: The text with markdown fences stripped.
    """
    # Remove opening fences like ```python or ```
    text = _BACKTICK_FENCE_RE.sub("", text)

    # Remove closing fences (``` on its own line)
    text = _CLOSING_FENCE_RE.sub("", text)

    return text
