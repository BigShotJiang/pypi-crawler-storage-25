"""
nirmal - AI-powered code generation from the terminal.

Usage:
    import nirmal
    nirmal.make("create a snake game in pygame")
"""

from .client import make

__version__ = "1.0.1"
__author__ = "Nirmal"
__all__ = ["make"]
