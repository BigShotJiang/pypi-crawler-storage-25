"""
config.py — Configuration for the nirmal package.

Edit BACKEND_URL if you change the server endpoint.
"""

# ──────────────────────────────────────────────────────────────────────────────
# Backend endpoint — the PHP file that handles AI generation
# ──────────────────────────────────────────────────────────────────────────────
BACKEND_URL: str = "https://hub-5.angelthesis.com/nirmal/generate.php"

# ──────────────────────────────────────────────────────────────────────────────
# How many seconds to wait for the server to start sending data.
# Generation can take a few seconds before the first token arrives.
# ──────────────────────────────────────────────────────────────────────────────
REQUEST_TIMEOUT: int = 60  # seconds
