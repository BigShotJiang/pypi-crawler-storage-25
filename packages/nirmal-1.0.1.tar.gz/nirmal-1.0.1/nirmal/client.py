"""
client.py — Core module for nirmal.

Sends the user's prompt to the nirmal PHP backend,
streams the AI-generated code back, and prints it live to the terminal.
"""

import sys
import requests

from .config import BACKEND_URL, REQUEST_TIMEOUT


def make(prompt: str) -> None:
    """
    Generate code from a natural-language prompt and stream it to the terminal.

    Args:
        prompt (str): A plain-English description of the code you want.

    Example:
        import nirmal
        nirmal.make("create a snake game in pygame")
    """

    if not prompt or not prompt.strip():
        print("[nirmal] Error: Prompt cannot be empty.", file=sys.stderr)
        return

    # Payload sent to the PHP backend as a POST request
    payload = {"prompt": prompt.strip()}

    try:
        # Open a streaming HTTP connection to the backend
        with requests.post(
            BACKEND_URL,
            data=payload,
            stream=True,               # Enable streaming response
            timeout=REQUEST_TIMEOUT,
        ) as response:

            # Handle non-200 HTTP responses gracefully
            if response.status_code != 200:
                print(
                    f"\n[nirmal] Server error: HTTP {response.status_code}",
                    file=sys.stderr,
                )
                try:
                    print(response.text, file=sys.stderr)
                except Exception:
                    pass
                return

            # Stream raw bytes directly to stdout — no decoding, no cleaning,
            # no reformatting. Whatever the AI sends arrives exactly as-is.
            # This preserves every space, tab, and newline perfectly.
            for raw_chunk in response.iter_content(chunk_size=None):
                if raw_chunk:
                    sys.stdout.buffer.write(raw_chunk)
                    sys.stdout.buffer.flush()

            # Ensure terminal ends on a clean new line
            sys.stdout.buffer.write(b"\n")
            sys.stdout.buffer.flush()

    except requests.exceptions.ConnectionError:
        print(
            "\n[nirmal] Connection error: Could not reach the backend server.\n"
            f"  URL: {BACKEND_URL}\n"
            "  Check your internet connection or the server URL in config.py.",
            file=sys.stderr,
        )

    except requests.exceptions.Timeout:
        print(
            "\n[nirmal] Timeout: The server took too long to respond.\n"
            "  Try again or increase REQUEST_TIMEOUT in config.py.",
            file=sys.stderr,
        )

    except requests.exceptions.RequestException as exc:
        print(f"\n[nirmal] Unexpected request error: {exc}", file=sys.stderr)

    except KeyboardInterrupt:
        print("\n\n[nirmal] Generation interrupted by user.", file=sys.stderr)
