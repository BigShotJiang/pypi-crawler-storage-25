# nirmal ⚡

> AI-powered code generation, streamed live to your terminal.

```python
import nirmal

nirmal.make("create a snake game in pygame")
```

Code starts appearing instantly — character by character — as the AI writes it in real time.

---

## Installation

```bash
pip install nirmal
```

Requires Python 3.8+.

---

## Quick Start

```python
import nirmal

# Generate a complete script from a single sentence
nirmal.make("build a REST API with FastAPI that has CRUD routes for a todo list")
```

That's it. The generated code streams directly into your terminal.

---

## More Examples

```python
import nirmal

# Games
nirmal.make("create a tetris clone using pygame")

# Web
nirmal.make("build a flask web app with user login and a dashboard")

# Scripts
nirmal.make("write a python script that watches a folder and renames files by date")

# Data
nirmal.make("create a pandas script that reads a CSV, cleans missing values, and plots a bar chart")

# Automation
nirmal.make("write a selenium script that logs into a website and scrapes product prices")
```

---

## How It Works

```
Your Python code
     │
     ▼
nirmal.make("your prompt")
     │
     ▼  POST /nirmal/generate.php
PHP Backend (Hostinger)
     │
     ▼  Groq API  (llama-3.3-70b-versatile)
Streaming AI response
     │
     ▼  Chunk by chunk
Live terminal output ✓
```

1. You call `nirmal.make()` with a plain-English description.
2. The package sends a POST request to the PHP backend.
3. The backend forwards the prompt to Groq with streaming enabled.
4. Each token is forwarded back to Python as it arrives.
5. Python prints each chunk live — no waiting for the full response.

---

## Configuration

If you host your own backend, edit `nirmal/config.py`:

```python
BACKEND_URL    = "https://your-domain.com/nirmal/generate.php"
REQUEST_TIMEOUT = 60  # seconds
```

---

## Package Structure

```
nirmal/
├── nirmal/
│   ├── __init__.py   ← public API (make)
│   ├── client.py     ← streaming HTTP client
│   ├── config.py     ← endpoint + timeout settings
│   └── utils.py      ← markdown cleanup helper
├── backend/
│   ├── generate.php  ← PHP streaming proxy to Groq
│   └── .htaccess     ← security rules for Hostinger
├── pyproject.toml    ← pip package config
├── README.md
└── LICENSE
```

---

## Publishing to PyPI

### 1. Install build tools

```bash
pip install build twine
```

### 2. Build the distribution

```bash
cd nirmal-project
python -m build
```

This creates `dist/nirmal-1.0.0.tar.gz` and `dist/nirmal-1.0.0-py3-none-any.whl`.

### 3. Upload to PyPI

```bash
twine upload dist/*
```

You'll need a [PyPI account](https://pypi.org/account/register/) and an API token.

### 4. Install from PyPI

```bash
pip install nirmal
```

---

## Deploying the PHP Backend on Hostinger

### 1. Connect via FTP or File Manager

Log in to Hostinger → **hPanel → File Manager** (or use FileZilla).

### 2. Upload the backend files

Upload `backend/generate.php` and `backend/.htaccess` to:

```
public_html/nirmal/
```

### 3. Set your Groq API key

Open `generate.php` and replace the placeholder:

```php
define('GROQ_API_KEY', 'your-real-groq-api-key-here');
```

Get your key at [console.groq.com](https://console.groq.com).

### 4. Test the endpoint

```bash
curl -X POST https://hub-5.angelthesis.com/nirmal/generate.php \
     -d "prompt=print hello world in python"
```

You should see code stream back in your terminal.

---

## Security Recommendations

| Concern | Recommendation |
|---|---|
| API key exposure | Never commit `generate.php` with a real key. Use environment variables if possible. |
| Open access | Add a shared secret token validated in `generate.php` (see code comments). |
| Rate limiting | Hostinger plans support `.htaccess` rate limiting; see `.htaccess` comments. |
| HTTPS | Always use HTTPS — Hostinger provides free SSL via Let's Encrypt. |
| Input length | `generate.php` caps prompt length at 2000 characters server-side. |

---

## License

MIT — see [LICENSE](LICENSE).
