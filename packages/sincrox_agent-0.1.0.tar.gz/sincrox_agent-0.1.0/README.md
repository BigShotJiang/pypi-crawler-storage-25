# SincroX Agent

Lightweight SQL bridge that runs next to your database. Connects your database to the [SincroX](https://sincrox.com) platform securely — only SELECT queries are allowed, with HMAC authentication and configurable timeouts.

## Quick Install

```bash
curl -fsSL https://sincrox.com/install.sh | bash
```

Or with Docker directly:

```bash
docker run -d \
  --name sincrox-agent \
  --restart unless-stopped \
  -e DATABASE_URL="postgresql://user:pass@host:5432/db" \
  -e HMAC_SECRET="your-secret-from-dashboard" \
  -p 8001:8001 \
  ghcr.io/eljoesb/sincrox-agent:latest
```

Or with pip:

```bash
pip install sincrox-agent

DATABASE_URL="postgresql://..." HMAC_SECRET="..." sincrox-agent
```

## Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DATABASE_URL` | Yes | — | Database connection string (PostgreSQL, MySQL, or MSSQL) |
| `HMAC_SECRET` | Yes | — | Shared secret from your SincroX dashboard (min 32 chars) |
| `AGENT_PORT` | No | `8001` | Port the agent listens on |
| `AGENT_HOST` | No | `0.0.0.0` | Host to bind to |
| `QUERY_TIMEOUT_SECONDS` | No | `10` | Max query execution time |
| `MAX_ROWS` | No | `1000` | Max rows returned per query |

## Supported Databases

- PostgreSQL (`postgresql://...`)
- MySQL (`mysql+pymysql://...`)
- SQL Server (`mssql+pyodbc://...`)

## Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/health` | None | Health check |
| POST | `/introspect` | HMAC | Returns database schema |
| POST | `/execute` | HMAC | Executes a SELECT query |

## Security

- Only `SELECT` and `WITH` (CTE) queries are allowed
- All other SQL operations (INSERT, UPDATE, DELETE, DROP, etc.) are blocked
- Requests are authenticated via HMAC-SHA256 signatures
- Query timeout and row limits are enforced
