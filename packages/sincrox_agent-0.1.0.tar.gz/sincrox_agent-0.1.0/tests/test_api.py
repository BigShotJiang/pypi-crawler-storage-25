import hashlib
import hmac
import json
import time
from unittest.mock import patch

import pytest

from .conftest import sign_request


class TestHMACAuth:
    async def test_missing_headers(self, client):
        resp = await client.post("/execute", json={"sql": "SELECT 1"})
        assert resp.status_code == 401

    async def test_invalid_signature(self, client):
        body = json.dumps({"sql": "SELECT 1"})
        resp = await client.post(
            "/execute",
            content=body,
            headers={
                "Content-Type": "application/json",
                "X-QM-Signature": "invalidsig",
                "X-QM-Timestamp": str(int(time.time())),
            },
        )
        assert resp.status_code == 401

    async def test_expired_timestamp(self, client):
        body, _, signature = sign_request({"sql": "SELECT 1"})
        old_ts = str(int(time.time()) - 600)
        # Resign with old timestamp
        message = f"{old_ts}.".encode() + body.encode()
        from querymind_agent.config import settings
        sig = hmac.new(settings.hmac_secret.encode(), message, hashlib.sha256).hexdigest()
        resp = await client.post(
            "/execute",
            content=body,
            headers={
                "Content-Type": "application/json",
                "X-QM-Signature": sig,
                "X-QM-Timestamp": old_ts,
            },
        )
        assert resp.status_code == 401


class TestExecuteEndpoint:
    async def test_valid_select(self, client):
        with patch("querymind_agent.app.execute_query") as mock_exec:
            mock_exec.return_value = {
                "columns": ["id", "nombre"],
                "rows": [[1, "test"]],
                "row_count": 1,
                "truncated": False,
            }
            body, ts, sig = sign_request({"sql": "SELECT id, nombre FROM clientes"})
            resp = await client.post(
                "/execute",
                content=body,
                headers={
                    "Content-Type": "application/json",
                    "X-QM-Signature": sig,
                    "X-QM-Timestamp": ts,
                },
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["row_count"] == 1
            assert data["columns"] == ["id", "nombre"]

    async def test_blocked_delete(self, client):
        body, ts, sig = sign_request({"sql": "DELETE FROM clientes WHERE id = 1"})
        resp = await client.post(
            "/execute",
            content=body,
            headers={
                "Content-Type": "application/json",
                "X-QM-Signature": sig,
                "X-QM-Timestamp": ts,
            },
        )
        assert resp.status_code == 400
        assert "Only SELECT" in resp.json()["detail"]

    async def test_blocked_drop(self, client):
        body, ts, sig = sign_request({"sql": "DROP TABLE pacientes"})
        resp = await client.post(
            "/execute",
            content=body,
            headers={
                "Content-Type": "application/json",
                "X-QM-Signature": sig,
                "X-QM-Timestamp": ts,
            },
        )
        assert resp.status_code == 400

    async def test_health(self, client):
        resp = await client.get("/health")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}
