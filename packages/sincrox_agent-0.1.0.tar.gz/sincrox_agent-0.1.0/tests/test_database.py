import pytest

from querymind_agent.database import execute_query


class TestInmobiliaria:
    def test_all_propiedades(self, inmobiliaria_engine):
        result = execute_query("SELECT * FROM propiedades", engine=inmobiliaria_engine)
        assert result["row_count"] == 6
        assert "precio" in result["columns"]
        assert result["truncated"] is False

    def test_propiedades_disponibles_bogota(self, inmobiliaria_engine):
        sql = "SELECT tipo, precio FROM propiedades WHERE ciudad = 'Bogotá' AND estado = 'disponible'"
        result = execute_query(sql, engine=inmobiliaria_engine)
        assert result["row_count"] == 1
        assert result["rows"][0][1] == 320000000

    def test_contratos_con_valor(self, inmobiliaria_engine):
        sql = "SELECT c.valor, cl.nombre FROM contratos c JOIN clientes cl ON c.cliente_id = cl.id"
        result = execute_query(sql, engine=inmobiliaria_engine)
        assert result["row_count"] == 2

    def test_comision_agentes(self, inmobiliaria_engine):
        sql = """
            SELECT a.nombre, a.comision_pct, c.valor, (c.valor * a.comision_pct / 100) AS comision
            FROM contratos c
            JOIN propiedades p ON c.propiedad_id = p.id
            JOIN agentes a ON p.agente_id = a.id
        """
        result = execute_query(sql, engine=inmobiliaria_engine)
        assert result["row_count"] == 2
        assert "comision" in result["columns"]


class TestIPS:
    def test_all_pacientes(self, ips_engine):
        result = execute_query("SELECT * FROM pacientes", engine=ips_engine)
        assert result["row_count"] == 4

    def test_consultas_por_especialidad(self, ips_engine):
        sql = """
            SELECT m.especialidad, COUNT(*) AS total, SUM(c.valor) AS ingresos
            FROM consultas c JOIN medicos m ON c.medico_id = m.id
            GROUP BY m.especialidad
        """
        result = execute_query(sql, engine=ips_engine)
        assert result["row_count"] == 3

    def test_citas_confirmadas(self, ips_engine):
        sql = "SELECT p.nombre, ci.fecha FROM citas ci JOIN pacientes p ON ci.paciente_id = p.id WHERE ci.estado = 'confirmada'"
        result = execute_query(sql, engine=ips_engine)
        assert result["row_count"] == 2

    def test_medicamentos_bajo_stock(self, ips_engine):
        sql = "SELECT nombre, stock FROM medicamentos WHERE stock < 500"
        result = execute_query(sql, engine=ips_engine)
        assert result["row_count"] == 1
        assert result["rows"][0][0] == "Losartán 50mg"


class TestDistribuidor:
    def test_all_productos(self, distribuidor_engine):
        result = execute_query("SELECT * FROM productos", engine=distribuidor_engine)
        assert result["row_count"] == 5

    def test_margen_por_producto(self, distribuidor_engine):
        sql = """
            SELECT nombre, precio_venta - precio_compra AS margen,
                   ROUND((precio_venta - precio_compra) * 100.0 / precio_compra, 1) AS margen_pct
            FROM productos
        """
        result = execute_query(sql, engine=distribuidor_engine)
        assert result["row_count"] == 5
        assert "margen" in result["columns"]

    def test_pedidos_por_cliente(self, distribuidor_engine):
        sql = """
            SELECT c.nombre, COUNT(p.id) AS num_pedidos, SUM(p.total) AS total_compras
            FROM pedidos p JOIN clientes c ON p.cliente_id = c.id
            GROUP BY c.nombre
        """
        result = execute_query(sql, engine=distribuidor_engine)
        assert result["row_count"] == 4

    def test_productos_mas_vendidos(self, distribuidor_engine):
        sql = """
            SELECT pr.nombre, SUM(pi.cantidad) AS total_unidades
            FROM pedido_items pi JOIN productos pr ON pi.producto_id = pr.id
            GROUP BY pr.nombre ORDER BY total_unidades DESC
        """
        result = execute_query(sql, engine=distribuidor_engine)
        assert result["row_count"] == 5
        assert result["rows"][0][0] == "Arroz Diana 5kg"


class TestRowCap:
    def test_truncation(self, inmobiliaria_engine):
        result = execute_query(
            "SELECT * FROM propiedades", engine=inmobiliaria_engine, max_rows=2
        )
        assert result["row_count"] == 2
        assert result["truncated"] is True
