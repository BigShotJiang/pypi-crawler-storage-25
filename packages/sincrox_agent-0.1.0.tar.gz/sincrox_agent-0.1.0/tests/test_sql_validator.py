import pytest

from querymind_agent.sql_validator import SQLValidationError, validate_select_only


class TestValidQueries:
    def test_simple_select(self):
        assert validate_select_only("SELECT * FROM propiedades") == "SELECT * FROM propiedades"

    def test_select_with_where(self):
        sql = "SELECT nombre, precio FROM productos WHERE categoria = 'granos'"
        assert validate_select_only(sql) == sql

    def test_select_with_join(self):
        sql = "SELECT p.nombre, c.fecha FROM consultas c JOIN pacientes p ON c.paciente_id = p.id"
        assert validate_select_only(sql) == sql

    def test_cte_query(self):
        sql = "WITH ventas AS (SELECT * FROM pedidos) SELECT * FROM ventas"
        assert validate_select_only(sql) == sql

    def test_strips_trailing_semicolon(self):
        assert validate_select_only("SELECT 1;") == "SELECT 1"

    def test_strips_whitespace(self):
        assert validate_select_only("  SELECT 1  ") == "SELECT 1"

    def test_string_with_semicolon(self):
        sql = "SELECT * FROM clientes WHERE nombre = 'O;Brien'"
        assert validate_select_only(sql) == sql


class TestBlockedQueries:
    @pytest.mark.parametrize("sql", [
        "INSERT INTO propiedades VALUES (99, 'casa', 'Bogotá', 100, 50, 'disponible', 1)",
        "UPDATE pacientes SET nombre = 'x' WHERE id = 1",
        "DELETE FROM pedidos WHERE id = 1",
        "DROP TABLE clientes",
        "ALTER TABLE medicos ADD COLUMN x TEXT",
        "CREATE TABLE hack (id INT)",
        "TRUNCATE TABLE visitas",
        "GRANT ALL ON propiedades TO public",
        "EXEC sp_executesql 'SELECT 1'",
    ])
    def test_forbidden_keywords(self, sql):
        with pytest.raises(SQLValidationError, match="Only SELECT"):
            validate_select_only(sql)

    def test_empty_query(self):
        with pytest.raises(SQLValidationError, match="Empty query"):
            validate_select_only("")

    def test_comments_blocked(self):
        with pytest.raises(SQLValidationError, match="comments"):
            validate_select_only("SELECT 1 -- comment")

    def test_block_comment_blocked(self):
        with pytest.raises(SQLValidationError, match="comments"):
            validate_select_only("SELECT /* hack */ 1")

    def test_multiple_statements(self):
        with pytest.raises(SQLValidationError):
            validate_select_only("SELECT 1; DROP TABLE clientes")

    def test_non_select_start(self):
        with pytest.raises(SQLValidationError, match="must start with SELECT"):
            validate_select_only("SHOW TABLES")
