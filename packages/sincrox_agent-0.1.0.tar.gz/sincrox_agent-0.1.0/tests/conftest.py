import hashlib
import hmac
import json
import os
import time

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import create_engine, text

os.environ.setdefault("DATABASE_URL", "sqlite:///")
os.environ.setdefault("HMAC_SECRET", "test-secret-key-must-be-at-least-32-chars-long")

from querymind_agent.app import app
from querymind_agent.config import settings
from querymind_agent.database import reset_engine


HMAC_SECRET = settings.hmac_secret


def sign_request(payload: dict) -> tuple[str, str, str]:
    body = json.dumps(payload).encode()
    timestamp = str(int(time.time()))
    message = f"{timestamp}.".encode() + body
    signature = hmac.new(HMAC_SECRET.encode(), message, hashlib.sha256).hexdigest()
    return body.decode(), timestamp, signature


@pytest.fixture()
def sqlite_engine():
    engine = create_engine("sqlite:///:memory:")
    yield engine
    engine.dispose()


@pytest.fixture()
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ---------------------------------------------------------------------------
# Contexto 1: Inmobiliaria
# ---------------------------------------------------------------------------
INMOBILIARIA_DDL = """
CREATE TABLE agentes (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    comision_pct REAL NOT NULL
);
CREATE TABLE clientes (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    presupuesto REAL,
    tipo_busqueda TEXT
);
CREATE TABLE propiedades (
    id INTEGER PRIMARY KEY,
    tipo TEXT NOT NULL,
    ciudad TEXT NOT NULL,
    precio REAL NOT NULL,
    area_m2 REAL NOT NULL,
    estado TEXT NOT NULL,
    agente_id INTEGER REFERENCES agentes(id)
);
CREATE TABLE visitas (
    id INTEGER PRIMARY KEY,
    propiedad_id INTEGER REFERENCES propiedades(id),
    cliente_id INTEGER REFERENCES clientes(id),
    fecha TEXT NOT NULL,
    resultado TEXT
);
CREATE TABLE contratos (
    id INTEGER PRIMARY KEY,
    propiedad_id INTEGER REFERENCES propiedades(id),
    cliente_id INTEGER REFERENCES clientes(id),
    valor REAL NOT NULL,
    fecha_firma TEXT NOT NULL
);
"""

INMOBILIARIA_DATA = """
INSERT INTO agentes VALUES (1, 'Carlos Mendieta', 3.5);
INSERT INTO agentes VALUES (2, 'Laura Gutiérrez', 4.0);
INSERT INTO agentes VALUES (3, 'Roberto Salazar', 3.0);

INSERT INTO clientes VALUES (1, 'Ana María López', 350000000, 'apartamento');
INSERT INTO clientes VALUES (2, 'Jorge Hernández', 800000000, 'casa');
INSERT INTO clientes VALUES (3, 'Valentina Ríos', 200000000, 'apartaestudio');
INSERT INTO clientes VALUES (4, 'Miguel Ángel Torres', 1500000000, 'finca');

INSERT INTO propiedades VALUES (1, 'apartamento', 'Bogotá', 320000000, 72.5, 'disponible', 1);
INSERT INTO propiedades VALUES (2, 'casa', 'Medellín', 750000000, 180.0, 'disponible', 2);
INSERT INTO propiedades VALUES (3, 'apartaestudio', 'Bogotá', 185000000, 38.0, 'vendida', 1);
INSERT INTO propiedades VALUES (4, 'finca', 'Rionegro', 1200000000, 5000.0, 'disponible', 3);
INSERT INTO propiedades VALUES (5, 'apartamento', 'Cali', 280000000, 65.0, 'disponible', 2);
INSERT INTO propiedades VALUES (6, 'casa', 'Bogotá', 950000000, 220.0, 'reservada', 3);

INSERT INTO visitas VALUES (1, 1, 1, '2025-11-01', 'interesado');
INSERT INTO visitas VALUES (2, 2, 2, '2025-11-03', 'segunda_visita');
INSERT INTO visitas VALUES (3, 3, 3, '2025-10-28', 'compró');
INSERT INTO visitas VALUES (4, 5, 1, '2025-11-05', 'no_interesado');
INSERT INTO visitas VALUES (5, 4, 4, '2025-11-10', 'interesado');

INSERT INTO contratos VALUES (1, 3, 3, 185000000, '2025-11-02');
INSERT INTO contratos VALUES (2, 6, 2, 920000000, '2025-11-15');
"""


# ---------------------------------------------------------------------------
# Contexto 2: IPS / Clínica
# ---------------------------------------------------------------------------
IPS_DDL = """
CREATE TABLE pacientes (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    fecha_nacimiento TEXT NOT NULL,
    eps TEXT NOT NULL
);
CREATE TABLE medicos (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    especialidad TEXT NOT NULL
);
CREATE TABLE consultas (
    id INTEGER PRIMARY KEY,
    paciente_id INTEGER REFERENCES pacientes(id),
    medico_id INTEGER REFERENCES medicos(id),
    fecha TEXT NOT NULL,
    diagnostico TEXT,
    valor REAL NOT NULL
);
CREATE TABLE citas (
    id INTEGER PRIMARY KEY,
    paciente_id INTEGER REFERENCES pacientes(id),
    medico_id INTEGER REFERENCES medicos(id),
    fecha TEXT NOT NULL,
    estado TEXT NOT NULL
);
CREATE TABLE medicamentos (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    stock INTEGER NOT NULL,
    precio_unitario REAL NOT NULL
);
"""

IPS_DATA = """
INSERT INTO pacientes VALUES (1, 'María Fernanda Castillo', '1985-03-15', 'Sura');
INSERT INTO pacientes VALUES (2, 'Andrés Felipe Moreno', '1992-07-22', 'Nueva EPS');
INSERT INTO pacientes VALUES (3, 'Lucía Esperanza Vargas', '1968-11-30', 'Sanitas');
INSERT INTO pacientes VALUES (4, 'Santiago Restrepo', '2001-01-10', 'Compensar');

INSERT INTO medicos VALUES (1, 'Dr. Hernán Mejía', 'medicina general');
INSERT INTO medicos VALUES (2, 'Dra. Catalina Vélez', 'pediatría');
INSERT INTO medicos VALUES (3, 'Dr. Óscar Ramírez', 'cardiología');

INSERT INTO consultas VALUES (1, 1, 1, '2025-11-01', 'gripe estacional', 85000);
INSERT INTO consultas VALUES (2, 2, 3, '2025-11-02', 'hipertensión leve', 150000);
INSERT INTO consultas VALUES (3, 3, 1, '2025-11-03', 'control general', 85000);
INSERT INTO consultas VALUES (4, 1, 3, '2025-11-10', 'arritmia sinusal', 180000);
INSERT INTO consultas VALUES (5, 4, 2, '2025-11-12', 'revisión rutinaria', 90000);

INSERT INTO citas VALUES (1, 1, 1, '2025-12-01', 'confirmada');
INSERT INTO citas VALUES (2, 2, 3, '2025-12-03', 'pendiente');
INSERT INTO citas VALUES (3, 3, 1, '2025-12-05', 'cancelada');
INSERT INTO citas VALUES (4, 4, 2, '2025-12-10', 'confirmada');

INSERT INTO medicamentos VALUES (1, 'Acetaminofén 500mg', 1200, 800);
INSERT INTO medicamentos VALUES (2, 'Losartán 50mg', 350, 1500);
INSERT INTO medicamentos VALUES (3, 'Amoxicilina 500mg', 800, 2200);
INSERT INTO medicamentos VALUES (4, 'Metformina 850mg', 600, 1100);
"""


# ---------------------------------------------------------------------------
# Contexto 3: Distribuidor mayorista
# ---------------------------------------------------------------------------
DISTRIBUIDOR_DDL = """
CREATE TABLE vendedores (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    zona TEXT NOT NULL,
    meta_mensual REAL NOT NULL
);
CREATE TABLE productos (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    categoria TEXT NOT NULL,
    precio_compra REAL NOT NULL,
    precio_venta REAL NOT NULL,
    stock INTEGER NOT NULL
);
CREATE TABLE clientes (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    ciudad TEXT NOT NULL,
    limite_credito REAL NOT NULL
);
CREATE TABLE pedidos (
    id INTEGER PRIMARY KEY,
    cliente_id INTEGER REFERENCES clientes(id),
    fecha TEXT NOT NULL,
    estado TEXT NOT NULL,
    total REAL NOT NULL
);
CREATE TABLE pedido_items (
    id INTEGER PRIMARY KEY,
    pedido_id INTEGER REFERENCES pedidos(id),
    producto_id INTEGER REFERENCES productos(id),
    cantidad INTEGER NOT NULL,
    precio_unitario REAL NOT NULL
);
"""

DISTRIBUIDOR_DATA = """
INSERT INTO vendedores VALUES (1, 'Felipe Arango', 'Antioquia', 50000000);
INSERT INTO vendedores VALUES (2, 'Diana Marcela Ruiz', 'Cundinamarca', 60000000);
INSERT INTO vendedores VALUES (3, 'Camilo Restrepo', 'Valle del Cauca', 45000000);

INSERT INTO productos VALUES (1, 'Arroz Diana 5kg', 'granos', 12000, 16500, 5000);
INSERT INTO productos VALUES (2, 'Aceite Girasol 3L', 'aceites', 18000, 25000, 3200);
INSERT INTO productos VALUES (3, 'Azúcar Manuelita 2.5kg', 'granos', 7500, 10800, 4100);
INSERT INTO productos VALUES (4, 'Atún Van Camps 160g', 'enlatados', 4200, 6300, 8500);
INSERT INTO productos VALUES (5, 'Leche Alquería 1L', 'lácteos', 3800, 5200, 12000);

INSERT INTO clientes VALUES (1, 'Supermercados El Éxito', 'Medellín', 200000000);
INSERT INTO clientes VALUES (2, 'Tiendas D1 Centro', 'Bogotá', 150000000);
INSERT INTO clientes VALUES (3, 'MiniMarket La Esquina', 'Cali', 30000000);
INSERT INTO clientes VALUES (4, 'Distribuidora Pacífico', 'Buenaventura', 80000000);

INSERT INTO pedidos VALUES (1, 1, '2025-11-01', 'entregado', 8250000);
INSERT INTO pedidos VALUES (2, 2, '2025-11-03', 'entregado', 5400000);
INSERT INTO pedidos VALUES (3, 3, '2025-11-05', 'pendiente', 1890000);
INSERT INTO pedidos VALUES (4, 1, '2025-11-10', 'en_tránsito', 12500000);
INSERT INTO pedidos VALUES (5, 4, '2025-11-12', 'pendiente', 3150000);

INSERT INTO pedido_items VALUES (1, 1, 1, 300, 16500);
INSERT INTO pedido_items VALUES (2, 1, 2, 100, 25000);
INSERT INTO pedido_items VALUES (3, 2, 3, 500, 10800);
INSERT INTO pedido_items VALUES (4, 3, 5, 200, 5200);
INSERT INTO pedido_items VALUES (5, 3, 4, 150, 6300);
INSERT INTO pedido_items VALUES (6, 4, 1, 500, 16500);
INSERT INTO pedido_items VALUES (7, 4, 2, 200, 25000);
INSERT INTO pedido_items VALUES (8, 5, 4, 500, 6300);
"""


def _seed_db(engine, ddl: str, data: str):
    with engine.connect() as conn:
        for stmt in ddl.strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                conn.execute(text(stmt))
        for stmt in data.strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                conn.execute(text(stmt))
        conn.commit()


@pytest.fixture()
def inmobiliaria_engine(sqlite_engine):
    _seed_db(sqlite_engine, INMOBILIARIA_DDL, INMOBILIARIA_DATA)
    return sqlite_engine


@pytest.fixture()
def ips_engine(sqlite_engine):
    _seed_db(sqlite_engine, IPS_DDL, IPS_DATA)
    return sqlite_engine


@pytest.fixture()
def distribuidor_engine(sqlite_engine):
    _seed_db(sqlite_engine, DISTRIBUIDOR_DDL, DISTRIBUIDOR_DATA)
    return sqlite_engine
