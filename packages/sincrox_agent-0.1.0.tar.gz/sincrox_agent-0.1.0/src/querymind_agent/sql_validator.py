import re
import sqlalchemy

_FORBIDDEN_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|GRANT|REVOKE|EXEC|EXECUTE|MERGE|CALL)\b",
    re.IGNORECASE,
)

_COMMENT_PATTERNS = re.compile(r"(--|/\*|\*/|#)")


class SQLValidationError(Exception):
    pass


def validate_select_only(sql: str) -> str:
    stripped = sql.strip().rstrip(";").strip()

    if not stripped:
        raise SQLValidationError("Empty query")

    if _COMMENT_PATTERNS.search(stripped):
        raise SQLValidationError("SQL comments are not allowed")

    if _FORBIDDEN_KEYWORDS.search(stripped):
        raise SQLValidationError("Only SELECT queries are allowed")

    # Must start with SELECT or WITH (for CTEs)
    first_word = stripped.split()[0].upper()
    if first_word not in ("SELECT", "WITH"):
        raise SQLValidationError(
            f"Query must start with SELECT or WITH, got: {first_word}"
        )

    # Block multiple statements (semicolons inside)
    # Remove string literals before checking for semicolons
    no_strings = re.sub(r"'[^']*'", "", stripped)
    if ";" in no_strings:
        raise SQLValidationError("Multiple statements are not allowed")

    return stripped
