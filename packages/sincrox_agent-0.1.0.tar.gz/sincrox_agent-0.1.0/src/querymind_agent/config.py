from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str
    hmac_secret: str
    agent_host: str = "0.0.0.0"
    agent_port: int = 8001
    query_timeout_seconds: int = 10
    max_rows: int = 1000

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()  # type: ignore[call-arg]
