from typing import Any

from pydantic import BaseModel


class ExecuteRequest(BaseModel):
    sql: str


class ExecuteResponse(BaseModel):
    columns: list[str]
    rows: list[list[Any]]
    row_count: int
    truncated: bool


class ColumnInfo(BaseModel):
    name: str
    type: str
    nullable: bool
    primary_key: bool
    allowed_values: list[str] = []


class ForeignKeyInfo(BaseModel):
    constrained_columns: list[str]
    referred_table: str
    referred_columns: list[str]


class TableInfo(BaseModel):
    name: str
    columns: list[ColumnInfo]
    foreign_keys: list[ForeignKeyInfo]


class IntrospectResponse(BaseModel):
    tables: list[TableInfo]


class ErrorResponse(BaseModel):
    detail: str
