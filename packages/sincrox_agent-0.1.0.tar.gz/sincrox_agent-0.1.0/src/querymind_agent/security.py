import hashlib
import hmac
import time

from fastapi import HTTPException, Request

_MAX_TIMESTAMP_DRIFT_SECONDS = 300  # 5 minutes


def compute_hmac(secret: str, payload: bytes, timestamp: str) -> str:
    message = f"{timestamp}.".encode() + payload
    return hmac.new(secret.encode(), message, hashlib.sha256).hexdigest()


async def verify_hmac(request: Request, secret: str) -> bytes:
    signature = request.headers.get("X-QM-Signature")
    timestamp = request.headers.get("X-QM-Timestamp")

    if not signature or not timestamp:
        raise HTTPException(status_code=401, detail="Missing HMAC headers")

    try:
        ts = int(timestamp)
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid timestamp")

    if abs(time.time() - ts) > _MAX_TIMESTAMP_DRIFT_SECONDS:
        raise HTTPException(status_code=401, detail="Request timestamp expired")

    body = await request.body()
    expected = compute_hmac(secret, body, timestamp)

    if not hmac.compare_digest(signature, expected):
        raise HTTPException(status_code=401, detail="Invalid HMAC signature")

    return body
