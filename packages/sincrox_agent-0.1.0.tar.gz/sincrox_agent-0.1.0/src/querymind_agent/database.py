from typing import Any

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import Engine

from .config import settings

_engine: Engine | None = None


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = create_engine(
            settings.database_url,
            pool_pre_ping=True,
            pool_size=5,
            max_overflow=10,
        )
    return _engine


def reset_engine() -> None:
    global _engine
    if _engine is not None:
        _engine.dispose()
        _engine = None


def execute_query(
    sql: str,
    engine: Engine | None = None,
    timeout: int | None = None,
    max_rows: int | None = None,
) -> dict[str, Any]:
    if engine is None:
        engine = get_engine()
    if timeout is None:
        timeout = settings.query_timeout_seconds
    if max_rows is None:
        max_rows = settings.max_rows

    wrapped = f"SELECT * FROM ({sql}) AS _qm_sub LIMIT {max_rows + 1}"

    with engine.connect() as conn:
        result = conn.execution_options(timeout=timeout).execute(text(wrapped))
        rows = result.fetchmany(max_rows + 1)
        columns = list(result.keys())

    truncated = len(rows) > max_rows
    if truncated:
        rows = rows[:max_rows]

    return {
        "columns": columns,
        "rows": [list(r) for r in rows],
        "row_count": len(rows),
        "truncated": truncated,
    }


def _get_enum_values(engine: Engine) -> dict[str, list[str]]:
    """Return a mapping of enum type names to their allowed values."""
    query = text("""
        SELECT t.typname, e.enumlabel
        FROM pg_type t
        JOIN pg_enum e ON t.oid = e.enumtypid
        ORDER BY t.typname, e.enumsortorder
    """)
    result: dict[str, list[str]] = {}
    try:
        with engine.connect() as conn:
            for row in conn.execute(query):
                result.setdefault(row[0], []).append(row[1])
    except Exception:
        pass
    return result


def _get_column_enum_types(engine: Engine) -> dict[tuple[str, str], str]:
    """Return a mapping of (table_name, column_name) -> enum type name."""
    query = text("""
        SELECT c.relname AS table_name,
               a.attname AS column_name,
               t.typname AS type_name
        FROM pg_attribute a
        JOIN pg_class c ON a.attrelid = c.oid
        JOIN pg_type t ON a.atttypid = t.oid
        JOIN pg_enum e ON t.oid = e.enumtypid
        WHERE c.relkind = 'r'
          AND a.attnum > 0
          AND NOT a.attisdropped
        GROUP BY c.relname, a.attname, t.typname
    """)
    result: dict[tuple[str, str], str] = {}
    try:
        with engine.connect() as conn:
            for row in conn.execute(query):
                result[(row[0], row[1])] = row[2]
    except Exception:
        pass
    return result


def introspect_schema(engine: Engine | None = None) -> dict[str, Any]:
    if engine is None:
        engine = get_engine()

    insp = inspect(engine)

    enum_values = _get_enum_values(engine)
    column_enum_types = _get_column_enum_types(engine)

    tables = []

    for table_name in insp.get_table_names():
        columns = []
        for col in insp.get_columns(table_name):
            col_name = col["name"]
            allowed: list[str] = []
            enum_type = column_enum_types.get((table_name, col_name))
            if enum_type and enum_type in enum_values:
                allowed = enum_values[enum_type]

            columns.append({
                "name": col_name,
                "type": str(col["type"]),
                "nullable": col.get("nullable", True),
                "primary_key": False,
                "allowed_values": allowed,
            })

        pk = insp.get_pk_constraint(table_name)
        pk_cols = pk.get("constrained_columns", []) if pk else []
        for col in columns:
            if col["name"] in pk_cols:
                col["primary_key"] = True

        foreign_keys = []
        for fk in insp.get_foreign_keys(table_name):
            foreign_keys.append({
                "constrained_columns": fk["constrained_columns"],
                "referred_table": fk["referred_table"],
                "referred_columns": fk["referred_columns"],
            })

        tables.append({
            "name": table_name,
            "columns": columns,
            "foreign_keys": foreign_keys,
        })

    return {"tables": tables}
