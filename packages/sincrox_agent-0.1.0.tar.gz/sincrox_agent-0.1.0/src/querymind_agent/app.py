import json
import logging

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse

from .config import settings
from .database import execute_query, introspect_schema
from .schemas import ExecuteRequest, ExecuteResponse, IntrospectResponse, ErrorResponse
from .security import verify_hmac
from .sql_validator import SQLValidationError, validate_select_only

logger = logging.getLogger("querymind_agent")

app = FastAPI(
    title="SincroX Agent",
    description="Local agent that executes validated SELECT queries against customer databases",
    version="0.1.0",
)


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post(
    "/introspect",
    response_model=IntrospectResponse,
    responses={401: {"model": ErrorResponse}},
)
async def introspect(request: Request):
    await verify_hmac(request, settings.hmac_secret)
    try:
        result = introspect_schema()
    except Exception as e:
        logger.exception("Schema introspection failed")
        raise HTTPException(status_code=500, detail=f"Introspection error: {e}")
    return result


@app.post(
    "/execute",
    response_model=ExecuteResponse,
    responses={400: {"model": ErrorResponse}, 401: {"model": ErrorResponse}},
)
async def execute(request: Request):
    body = await verify_hmac(request, settings.hmac_secret)

    try:
        payload = ExecuteRequest.model_validate_json(body)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid request body")

    try:
        sql = validate_select_only(payload.sql)
    except SQLValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

    try:
        result = execute_query(sql)
    except Exception as e:
        logger.exception("Query execution failed")
        raise HTTPException(status_code=400, detail=f"Query execution error: {e}")

    return result
