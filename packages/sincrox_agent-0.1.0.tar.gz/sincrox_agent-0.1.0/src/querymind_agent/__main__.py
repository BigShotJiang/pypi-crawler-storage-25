import uvicorn

from .config import settings


def main():
    """Entry point for `sincrox-agent` CLI command."""
    uvicorn.run(
        "querymind_agent.app:app",
        host=settings.agent_host,
        port=settings.agent_port,
    )


if __name__ == "__main__":
    main()
