"""
publicmcp/cli.py — CLI entry point.

Commands:
    publicmcp init   — create a starter business.json
    publicmcp serve  — start the PUBLICMCP server
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import click
import uvicorn

from publicmcp import __version__


@click.group()
@click.version_option(version=__version__, prog_name="publicmcp")
def cli():
    """PUBLICMCP — business identity MCP server.

    Build a spec-compliant MCP server for your business in minutes.

    \b
    Quickstart:
        publicmcp init            # create business.json
        publicmcp serve           # start server on :8000

    Spec: https://github.com/joeprovence/publicmcp/blob/main/SPEC.md
    """


# ---------------------------------------------------------------------------
# publicmcp init
# ---------------------------------------------------------------------------

@cli.command()
@click.option(
    "--output", "-o",
    default="business.json",
    show_default=True,
    help="Output path for the business.json template.",
)
@click.option(
    "--force", "-f",
    is_flag=True,
    default=False,
    help="Overwrite existing file without prompting.",
)
def init(output: str, force: bool) -> None:
    """Create a starter business.json template.

    Generates a spec-compliant business.json with placeholder values.
    Edit the file, then run 'publicmcp serve' to start your server.
    """
    output_path = Path(output)

    if output_path.exists() and not force:
        click.confirm(
            f"{output_path} already exists. Overwrite?",
            abort=True,
        )

    template_path = Path(__file__).parent / "templates" / "business.json"
    shutil.copy(template_path, output_path)

    click.echo(f"Created {output_path}")
    click.echo("")
    click.echo("Next steps:")
    click.echo(f"  1. Edit {output_path} with your business details")
    click.echo("  2. Run: publicmcp serve")
    click.echo("  3. Connect your AI client to: http://localhost:8000/mcp")
    click.echo("")
    click.echo("Spec: https://github.com/joeprovence/publicmcp/blob/main/SPEC.md")


# ---------------------------------------------------------------------------
# publicmcp serve
# ---------------------------------------------------------------------------

@cli.command()
@click.option(
    "--business", "-b",
    default="business.json",
    show_default=True,
    help="Path to your business.json file.",
)
@click.option(
    "--host",
    default="0.0.0.0",
    show_default=True,
    help="Host to bind to.",
)
@click.option(
    "--port", "-p",
    default=8000,
    show_default=True,
    type=int,
    help="Port to listen on.",
)
@click.option(
    "--domain",
    default="",
    help=(
        "Public domain name (e.g. mcp.yourdomain.com). "
        "Used in the discovery endpoint URL. "
        "Defaults to the domain in your business.json website field."
    ),
)
@click.option(
    "--reload",
    is_flag=True,
    default=False,
    help="Enable auto-reload on business.json changes (dev mode).",
)
def serve(
    business: str,
    host: str,
    port: int,
    domain: str,
    reload: bool,
) -> None:
    """Start the PUBLICMCP server.

    Reads business.json and starts a FastMCP server with 6 tools and 1 prompt.
    Browsers are redirected to your publicmcp_page landing. AI agents get MCP.

    \b
    Endpoints:
        /mcp                       — MCP (streamable-http)
        /.well-known/publicmcp.json — discovery
        /info                      — plain-text summary
    """
    business_path = Path(business)

    if not business_path.is_file():
        click.echo(
            f"Error: {business_path} not found.\n"
            "Run 'publicmcp init' to create a starter business.json.",
            err=True,
        )
        sys.exit(1)

    # Validate JSON before starting
    try:
        with open(business_path) as f:
            biz = json.load(f)
    except json.JSONDecodeError as exc:
        click.echo(f"Error: Invalid JSON in {business_path}: {exc}", err=True)
        sys.exit(1)

    # Resolve domain: CLI flag > website field > localhost
    if not domain:
        website = biz.get("website", "")
        domain = (
            website
            .removeprefix("https://")
            .removeprefix("http://")
            .removeprefix("www.")
            .rstrip("/")
            or "localhost"
        )

    # Spec compliance pre-check
    missing = [
        field for field in ("name", "services", "locations")
        if not biz.get(field)
    ]
    if missing:
        click.echo(
            f"Warning: business.json is missing required fields: {', '.join(missing)}\n"
            "Server will start but may not pass spec compliance.",
            err=True,
        )

    # Import here to keep startup fast
    from publicmcp.server import build_app

    app = build_app(business_path=business_path, domain=domain)

    click.echo(f"PUBLICMCP v{__version__} — {biz.get('name', 'unnamed')}")
    click.echo(f"  MCP endpoint : http://{host}:{port}/mcp")
    click.echo(f"  Discovery    : http://{host}:{port}/.well-known/publicmcp.json")
    click.echo(f"  Info         : http://{host}:{port}/info")
    click.echo(f"  Business     : {business_path.resolve()}")
    click.echo(f"  Domain       : {domain}")
    click.echo("")

    uvicorn.run(
        app,
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )
