def main() -> None:
    print("Hello from pagina!")
