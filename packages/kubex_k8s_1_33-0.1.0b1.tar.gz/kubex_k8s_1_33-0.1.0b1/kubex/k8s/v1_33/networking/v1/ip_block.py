from pydantic import Field

from kubex_core.models.base import BaseK8sModel


class IPBlock(BaseK8sModel):
    """IPBlock describes a particular CIDR (Ex. "192.168.1.0/24","2001:db8::/64") that is allowed to the pods matched by a NetworkPolicySpec's podSelector. The except entry describes CIDRs that should not be included within this rule."""

    cidr: str = Field(
        ...,
        alias="cidr",
        description='cidr is a string representing the IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64"',
    )
    except_: list[str] | None = Field(
        default=None,
        alias="except",
        description='except is a slice of CIDRs that should not be included within an IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64" Except values will be rejected if they are outside the cidr range',
    )
