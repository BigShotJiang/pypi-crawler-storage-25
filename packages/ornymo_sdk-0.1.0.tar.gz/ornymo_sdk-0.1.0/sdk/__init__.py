from pathlib import Path

project = "ornymo-sdk"

pyproject = f"""
[build-system]
requires = ["setuptools", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "{project}"
version = "0.1.0"
description = "SDK for Ornymo API"
authors = [{{ name = "hasna" }}]
readme = "README.md"
requires-python = ">=3.10"
dependencies = [
    "requests"
]

[tool.setuptools]
packages = ["sdk"]
"""

Path("pyproject.toml").write_text(pyproject.strip())
print("pyproject.toml created")