""" bootty """


def main() -> None:
    print("  bootty  ")
