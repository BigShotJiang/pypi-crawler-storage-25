# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2018-2026 BioInception PVT LTD
# Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
# See the NOTICE file for attribution, trademark, and algorithm IP terms.
"""
SMSD -- Substructure & Maximum Common Substructure search for chemical graphs.

Copyright (c) 2018-2026 BioInception PVT LTD
Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
Licensed under Apache 2.0.

Quick start::

    from smsd import parse_smiles, find_mcs, is_substructure, similarity

    benzene = parse_smiles("c1ccccc1")
    phenol  = parse_smiles("c1ccc(O)cc1")

    assert is_substructure(benzene, phenol)

    mcs = find_mcs(benzene, phenol)
    print(f"MCS size: {len(mcs)}")

    sim = similarity(benzene, phenol)
    print(f"Similarity: {sim:.3f}")
"""

__version__ = "6.1.1"
__author__ = "Syed Asad Rahman"

from smsd._smsd import (
    # Types
    ChemOptions,
    McsOptions,
    MolGraph,
    MolGraphBuilder,
    # Enums
    BondOrderMode,
    AromaticityMode,
    RingFusionMode,
    # SMILES / SMARTS
    parse_smiles,
    to_smiles,
    to_smarts,
    # Substructure
    is_substructure,
    find_substructure,
    # MCS
    find_mcs,
    find_all_mcs,
    # MCS SMILES extraction
    mcs_to_smiles,
    find_mcs_smiles,
    # RASCAL
    similarity_upper_bound,
    screen_targets,
    # Fingerprints
    path_fingerprint,
    mcs_fingerprint,
    fingerprint_subset,
    analyze_fp_quality,
    # GPU / compute backend query (CUDA on Linux/Windows, Metal on macOS)
    gpu_is_available,
    gpu_device_info,
)


# ---------------------------------------------------------------------------
# Convenience helpers that wrap the raw C++ bindings with Pythonic defaults
# ---------------------------------------------------------------------------

def similarity(mol1, mol2):
    """Compute RASCAL similarity upper bound between two molecules.

    Accepts either MolGraph objects or SMILES strings.

    Returns:
        float: Tanimoto-like similarity in [0.0, 1.0].
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    return similarity_upper_bound(g1, g2)


def mcs(mol1, mol2, *, tautomer_aware=False, timeout_ms=10000, **kwargs):
    """Find Maximum Common Substructure between two molecules.

    Accepts either MolGraph objects or SMILES strings.

    Args:
        mol1: First molecule (MolGraph or SMILES string).
        mol2: Second molecule (MolGraph or SMILES string).
        tautomer_aware: Use tautomer-aware matching.
        timeout_ms: Timeout in milliseconds.
        **kwargs: Additional McsOptions fields (e.g. connected_only=False).

    Returns:
        dict: Mapping from mol1 atom indices to mol2 atom indices.
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    chem = ChemOptions.tautomer_profile() if tautomer_aware else ChemOptions()
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return find_mcs(g1, g2, chem, opts)


def all_mcs(mol1, mol2, *, max_results=10, tautomer_aware=False, timeout_ms=10000, **kwargs):
    """Find multiple distinct MCS mappings of the maximum size.

    Accepts either MolGraph objects or SMILES strings. Returns up to
    ``max_results`` distinct atom-atom mappings that all share the same
    (maximum) MCS size. Useful for scaffold analysis and SAR studies.

    Args:
        mol1: First molecule (MolGraph or SMILES string).
        mol2: Second molecule (MolGraph or SMILES string).
        max_results: Maximum number of distinct mappings to return (default 10).
        tautomer_aware: Use tautomer-aware matching.
        timeout_ms: Timeout in milliseconds.
        **kwargs: Additional McsOptions fields (e.g. connected_only=False).

    Returns:
        list[dict]: List of mappings from mol1 atom indices to mol2 atom indices.
            Each mapping has the same (maximum) size.
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    chem = ChemOptions.tautomer_profile() if tautomer_aware else ChemOptions()
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return find_all_mcs(g1, g2, chem, opts, max_results)


def mcs_smiles(mol1, mol2, *, tautomer_aware=False, timeout_ms=10000, **kwargs):
    """Find MCS between two molecules and return it as a canonical SMILES string.

    Accepts either MolGraph objects or SMILES strings.

    Args:
        mol1: First molecule (MolGraph or SMILES string).
        mol2: Second molecule (MolGraph or SMILES string).
        tautomer_aware: Use tautomer-aware matching.
        timeout_ms: Timeout in milliseconds.
        **kwargs: Additional McsOptions fields (e.g. connected_only=False).

    Returns:
        str: Canonical SMILES of the MCS, or "" if no common substructure.
    """
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)
    chem = ChemOptions.tautomer_profile() if tautomer_aware else ChemOptions()
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return find_mcs_smiles(g1, g2, chem, opts, timeout_ms)


def substructure_search(query, target, *, timeout_ms=10000):
    """Find a substructure mapping of query in target.

    Accepts either MolGraph objects or SMILES strings.

    Returns:
        list: List of (query_atom, target_atom) pairs, or empty list if not
        a substructure.
    """
    q = _ensure_mol(query)
    t = _ensure_mol(target)
    return find_substructure(q, t, ChemOptions(), timeout_ms)


def topological_torsion(mol, fp_size=2048):
    """Compute a topological torsion fingerprint (Nilakantan et al. 1987).

    Enumerates all 4-atom linear paths A-B-C-D in the molecule and hashes
    their atom types (atomicNum, heavyDeg, piElectrons, ring) using FNV-1a
    with canonical ordering.

    Args:
        mol: MolGraph or SMILES string.
        fp_size: Fingerprint size in bits (default 2048).

    Returns:
        list[int]: Sorted list of set bit positions.
    """
    from smsd._smsd import topological_torsion as _tt  # type: ignore[import]
    g = _ensure_mol(mol)
    return _tt(g, fp_size)


def fingerprint(mol, *, kind="mcs", path_length=7, fp_size=2048):
    """Compute a molecular fingerprint.

    Args:
        mol: MolGraph or SMILES string.
        kind: "path" for simple path fingerprint, "mcs" for MCS-aware.
        path_length: Maximum bond path length (default 7).
        fp_size: Fingerprint size in bits (default 2048).

    Returns:
        list[int]: Sorted list of set bit positions.
    """
    g = _ensure_mol(mol)
    if kind == "path":
        return path_fingerprint(g, path_length, fp_size)
    elif kind == "mcs":
        return mcs_fingerprint(g, path_length, fp_size)
    else:
        raise ValueError(f"Unknown fingerprint kind: {kind!r}. Use 'path' or 'mcs'.")


def tanimoto(fp1, fp2, fp_size=2048):
    """Compute Tanimoto coefficient between two fingerprints.

    Args:
        fp1: List of set bit positions (from fingerprint()).
        fp2: List of set bit positions (from fingerprint()).
        fp_size: Fingerprint size in bits.

    Returns:
        float: Tanimoto similarity in [0.0, 1.0].
    """
    s1 = set(fp1)
    s2 = set(fp2)
    intersection = len(s1 & s2)
    union = len(s1 | s2)
    if union == 0:
        return 1.0
    return intersection / union


def batch_substructure(query, targets, *, timeout_ms=10000):
    """Check whether query is a substructure of each molecule in targets.

    Automatically dispatches to multi-core OpenMP via the C++ extension.
    Pass pre-parsed MolGraph objects for best performance (avoids per-call
    SMILES parsing).

    Args:
        query:      MolGraph or SMILES string.
        targets:    List of MolGraph or SMILES strings.
        timeout_ms: Per-pair timeout in milliseconds.

    Returns:
        list[bool]: True at index i when query is a substructure of targets[i].
    """
    from smsd._smsd import batch_substructure as _batch_sub  # type: ignore[import]
    q = _ensure_mol(query)
    ts = [_ensure_mol(t) for t in targets]
    return _batch_sub(q, ts, ChemOptions(), timeout_ms)


def batch_mcs(query, targets, *, timeout_ms=10000, **kwargs):
    """Compute MCS between query and every molecule in targets in parallel.

    Dispatches to multi-core OpenMP automatically.

    Args:
        query:      MolGraph or SMILES string.
        targets:    List of MolGraph or SMILES strings.
        timeout_ms: Per-pair timeout in milliseconds.
        **kwargs:   Extra McsOptions fields (e.g. connected_only=False).

    Returns:
        list[dict]: MCS atom mappings (query → target index) for each target.
    """
    from smsd._smsd import batch_mcs as _batch_mcs  # type: ignore[import]
    q = _ensure_mol(query)
    ts = [_ensure_mol(t) for t in targets]
    opts = McsOptions()
    opts.timeout_ms = timeout_ms
    for k, v in kwargs.items():
        setattr(opts, k, v)
    return _batch_mcs(q, ts, ChemOptions(), opts)


def _ensure_mol(obj):
    """Convert a SMILES string to MolGraph, or return MolGraph as-is."""
    if isinstance(obj, str):
        return parse_smiles(obj)
    if isinstance(obj, MolGraph):
        return obj
    raise TypeError(
        f"Expected MolGraph or SMILES string, got {type(obj).__name__}"
    )


# ---------------------------------------------------------------------------
# RDKit interoperability helpers (RDKit is an optional dependency)
# ---------------------------------------------------------------------------

class _RdkitResult:
    """Wrapper holding a MolGraph + its SMSD→RDKit index mapping."""
    __slots__ = ('graph', 'index_map')
    def __init__(self, graph, index_map):
        self.graph = graph
        self.index_map = index_map  # list: index_map[smsd_idx] = rdkit_idx


# Cache keyed by id(rdkit_mol) → _RdkitResult.
# Per-Mol-object cache avoids the problem of different Mol objects with
# the same canonical SMILES having different atom orderings.
_rdkit_cache = {}
_mol_graph_cache = {}  # SMILES → MolGraph (for parse_smiles caching only)


def _compute_index_map(rdkit_mol, canonical_smi):
    """Compute deterministic SMSD→RDKit atom index mapping.

    Uses RDKit's _smilesAtomOutputOrder property which records the exact
    order atoms appear in the canonical SMILES string. This is the ground
    truth for SMILES parse order = SMSD's internal atom order.

    The mapping: index_map[smsd_idx] = rdkit_idx
    """
    from rdkit import Chem

    n = rdkit_mol.GetNumAtoms()

    # RDKit records which original atom appears at each position in the
    # canonical SMILES via the _smilesAtomOutputOrder property.
    # We must call MolToSmiles first to populate this property.
    _ = Chem.MolToSmiles(rdkit_mol)  # ensures property is set
    try:
        output_order = list(rdkit_mol.GetPropsAsDict()
                            .get('_smilesAtomOutputOrder', []))
    except Exception:
        output_order = []

    if output_order and len(output_order) >= n:
        # output_order[smiles_position] = rdkit_atom_idx
        # SMSD parses the canonical SMILES, so smsd_idx = smiles_position
        # But output_order may include implicit H indices beyond n — filter them
        index_map = []
        for rdkit_idx in output_order:
            if rdkit_idx < n:
                index_map.append(rdkit_idx)
        # Pad if needed (shouldn't happen for valid molecules)
        while len(index_map) < n:
            index_map.append(len(index_map))
        return index_map
    else:
        # Fallback: use GetSubstructMatch on re-parsed canonical SMILES
        mol_from_smi = Chem.MolFromSmiles(canonical_smi)
        if mol_from_smi is not None:
            match = rdkit_mol.GetSubstructMatch(mol_from_smi)
            if match and len(match) == n:
                return list(match)
        # Last resort: identity
        return list(range(n))


def from_rdkit(mol, use_cache=True):
    """Convert an RDKit Mol to SMSD MolGraph via SMILES round-trip.

    Returns a MolGraph. The SMSD→RDKit index mapping is stored internally
    and used by :func:`translate_mapping` and :func:`mcs_rdkit_native`.

    Each distinct RDKit Mol object gets its own mapping (no cross-Mol
    cache collisions). The cache is keyed by ``id(mol)`` and automatically
    evicted when the cache exceeds 10K entries.

    Example::

        from rdkit import Chem
        import smsd

        mol = Chem.MolFromSmiles("c1ccccc1")
        g = smsd.from_rdkit(mol)
    """
    try:
        from rdkit import Chem
    except ImportError:
        raise ImportError(
            "RDKit is required for from_rdkit(). "
            "Install with: pip install rdkit"
        )

    mol_id = id(mol)
    if use_cache:
        cached = _rdkit_cache.get(mol_id)
        if cached is not None:
            return cached.graph

    smi = Chem.MolToSmiles(mol)

    # Parse SMILES (with MolGraph caching for the parse itself)
    if smi in _mol_graph_cache:
        g = _mol_graph_cache[smi]
    else:
        g = parse_smiles(smi)
        _mol_graph_cache[smi] = g

    # Compute deterministic index mapping for THIS specific Mol object
    index_map = _compute_index_map(mol, smi)
    result = _RdkitResult(g, index_map)

    _graph_to_result[id(g)] = result  # O(1) reverse lookup for get_index_map

    if use_cache:
        if len(_rdkit_cache) > 10000:
            _rdkit_cache.clear()
            _graph_to_result.clear()
        _rdkit_cache[mol_id] = result

    return g


_graph_to_result = {}  # id(MolGraph) → _RdkitResult (O(1) reverse lookup)


def get_index_map(g):
    """Return the SMSD→RDKit atom index mapping for a MolGraph from from_rdkit().

    Returns a list where ``result[smsd_idx] = rdkit_idx``, or None if the
    MolGraph was not created by from_rdkit().
    """
    r = _graph_to_result.get(id(g))
    return r.index_map if r is not None else None


def translate_mapping(mapping, g_query=None, g_target=None):
    """Translate an MCS mapping from SMSD indices to RDKit indices.

    Args:
        mapping: dict of {smsd_query_idx: smsd_target_idx} from find_mcs()
        g_query: the query MolGraph (from from_rdkit())
        g_target: the target MolGraph (from from_rdkit())

    Returns:
        dict of {rdkit_query_idx: rdkit_target_idx}
    """
    q_map = get_index_map(g_query) if g_query is not None else None
    t_map = get_index_map(g_target) if g_target is not None else None

    result = {}
    for smsd_q, smsd_t in mapping.items():
        rdkit_q = q_map[smsd_q] if q_map and smsd_q < len(q_map) else smsd_q
        rdkit_t = t_map[smsd_t] if t_map and smsd_t < len(t_map) else smsd_t
        result[rdkit_q] = rdkit_t
    return result


def mcs_rdkit_native(mol1, mol2, **kwargs):
    """Find MCS between two RDKit Mols, returning RDKit-compatible atom indices.

    Returns a dict where keys are atom indices in mol1 and values are atom
    indices in mol2 — matching RDKit's atom ordering (not SMSD's internal order).

    Example::

        from rdkit import Chem
        import smsd

        m1 = Chem.MolFromSmiles("c1ccccc1")
        m2 = Chem.MolFromSmiles("c1ccc(O)cc1")
        mapping = smsd.mcs_rdkit_native(m1, m2)
        for q, t in mapping.items():
            assert m1.GetAtomWithIdx(q).GetAtomicNum() == m2.GetAtomWithIdx(t).GetAtomicNum()
    """
    g1 = from_rdkit(mol1)
    g2 = from_rdkit(mol2)
    smsd_mapping = find_mcs(g1, g2, **kwargs)
    rdkit_mapping = translate_mapping(smsd_mapping, g1, g2)

    # Safety: filter out-of-bounds indices and element mismatches
    n1, n2 = mol1.GetNumAtoms(), mol2.GetNumAtoms()
    validated = {}
    for q, t in rdkit_mapping.items():
        if q < n1 and t < n2:
            if mol1.GetAtomWithIdx(q).GetAtomicNum() == mol2.GetAtomWithIdx(t).GetAtomicNum():
                validated[q] = t
    return validated


def clear_cache():
    """Clear all from_rdkit() caches."""
    _rdkit_cache.clear()
    _mol_graph_cache.clear()
    _graph_to_result.clear()


def mcs_rdkit(mol1, mol2, **kwargs):
    """Find Maximum Common Substructure between two RDKit Mol objects.

    Accepts any keyword arguments supported by :func:`mcs` (e.g.
    ``tautomer_aware``, ``timeout_ms``).

    Example::

        from rdkit import Chem
        import smsd

        m1 = Chem.MolFromSmiles("c1ccccc1")
        m2 = Chem.MolFromSmiles("c1ccc(O)cc1")
        result = smsd.mcs_rdkit(m1, m2)
    """
    g1 = from_rdkit(mol1)
    g2 = from_rdkit(mol2)
    return mcs(g1, g2, **kwargs)


def substructure_rdkit(query_mol, target_mol, **kwargs):
    """Check substructure relationship between two RDKit Mol objects.

    Accepts any keyword arguments supported by :func:`substructure_search`
    (e.g. ``timeout_ms``).

    Example::

        from rdkit import Chem
        import smsd

        benzene = Chem.MolFromSmiles("c1ccccc1")
        phenol  = Chem.MolFromSmiles("c1ccc(O)cc1")
        result = smsd.substructure_rdkit(benzene, phenol)
    """
    gq = from_rdkit(query_mol)
    gt = from_rdkit(target_mol)
    return substructure_search(gq, gt, **kwargs)


# =========================================================================
# Export & Depiction — plug into RDKit, matplotlib, or Jupyter
# =========================================================================


def to_rdkit(mol_or_smiles):
    """Convert SMSD MolGraph (or SMILES string) to an RDKit Mol object.

    Example::

        import smsd
        g = smsd.parse_smiles("c1ccccc1")
        rdkit_mol = smsd.to_rdkit(g)

        # Now use RDKit for drawing, fingerprints, descriptors, etc.
        from rdkit.Chem import Draw
        Draw.MolToImage(rdkit_mol)
    """
    try:
        from rdkit import Chem
    except ImportError:
        raise ImportError(
            "RDKit is required for to_rdkit(). "
            "Install with: pip install rdkit"
        )
    if isinstance(mol_or_smiles, str):
        smi = mol_or_smiles
    elif hasattr(mol_or_smiles, "__class__") and "MolGraph" in type(mol_or_smiles).__name__:
        smi = to_smiles(mol_or_smiles)
    else:
        raise TypeError(f"Expected MolGraph or SMILES string, got {type(mol_or_smiles)}")
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        raise ValueError(f"RDKit could not parse SMILES: {smi}")
    return mol


def depict_mcs(mol1, mol2, *, tautomer_aware=False, timeout_ms=10000,
               size=(600, 300), highlight_color=(0.5, 0.8, 1.0)):
    """Find MCS and return an RDKit image with matched atoms highlighted.

    Works in Jupyter notebooks (auto-displays) and scripts (returns PIL Image).

    Example::

        import smsd
        img = smsd.depict_mcs("c1ccccc1", "c1ccc(O)cc1")
        img.save("mcs.png")  # or just display in Jupyter
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import Draw, AllChem
    except ImportError:
        raise ImportError(
            "RDKit is required for depict_mcs(). "
            "Install with: pip install rdkit"
        )

    # Parse inputs
    g1 = _ensure_mol(mol1)
    g2 = _ensure_mol(mol2)

    # Find MCS
    mapping = mcs(g1, g2, tautomer_aware=tautomer_aware, timeout_ms=timeout_ms)

    # Convert to RDKit mols for drawing
    smi1 = to_smiles(g1) if not isinstance(mol1, str) else mol1
    smi2 = to_smiles(g2) if not isinstance(mol2, str) else mol2
    rdmol1 = Chem.MolFromSmiles(smi1)
    rdmol2 = Chem.MolFromSmiles(smi2)
    if rdmol1 is None or rdmol2 is None:
        raise ValueError("Could not convert molecules for depiction")

    AllChem.Compute2DCoords(rdmol1)
    AllChem.Compute2DCoords(rdmol2)

    # Highlight matched atoms
    q_atoms = list(mapping.keys()) if mapping else []
    t_atoms = list(mapping.values()) if mapping else []

    img = Draw.MolsToGridImage(
        [rdmol1, rdmol2],
        molsPerRow=2,
        subImgSize=(size[0] // 2, size[1]),
        highlightAtomLists=[q_atoms, t_atoms],
        legends=[f"Query ({len(q_atoms)} matched)", f"Target ({len(t_atoms)} matched)"],
    )
    return img


def depict_substructure(query, target, *, timeout_ms=10000,
                        size=(600, 300)):
    """Find substructure and return an RDKit image with matched atoms highlighted.

    Example::

        import smsd
        img = smsd.depict_substructure("c1ccccc1", "c1ccc(O)cc1")
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import Draw, AllChem
    except ImportError:
        raise ImportError(
            "RDKit is required for depict_substructure(). "
            "Install with: pip install rdkit"
        )

    gq = _ensure_mol(query)
    gt = _ensure_mol(target)

    result = substructure_search(gq, gt, timeout_ms=timeout_ms)
    mapping = result if isinstance(result, dict) else {}

    smi_q = to_smiles(gq) if not isinstance(query, str) else query
    smi_t = to_smiles(gt) if not isinstance(target, str) else target
    rdmol_q = Chem.MolFromSmiles(smi_q)
    rdmol_t = Chem.MolFromSmiles(smi_t)
    if rdmol_q is None or rdmol_t is None:
        raise ValueError("Could not convert molecules for depiction")

    AllChem.Compute2DCoords(rdmol_q)
    AllChem.Compute2DCoords(rdmol_t)

    q_atoms = list(mapping.keys()) if mapping else []
    t_atoms = list(mapping.values()) if mapping else []

    img = Draw.MolsToGridImage(
        [rdmol_q, rdmol_t],
        molsPerRow=2,
        subImgSize=(size[0] // 2, size[1]),
        highlightAtomLists=[q_atoms, t_atoms],
        legends=[f"Query", f"Target ({len(t_atoms)} matched)"],
    )
    return img


def to_svg(mol_or_smiles, *, size=(300, 200)):
    """Generate SVG depiction of a molecule using RDKit.

    Example::

        svg = smsd.to_svg("c1ccccc1")
        with open("benzene.svg", "w") as f:
            f.write(svg)
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import Draw, AllChem, rdMolDraw2D
    except ImportError:
        raise ImportError(
            "RDKit is required for to_svg(). "
            "Install with: pip install rdkit"
        )

    if isinstance(mol_or_smiles, str):
        mol = Chem.MolFromSmiles(mol_or_smiles)
    elif hasattr(mol_or_smiles, "__class__") and "MolGraph" in type(mol_or_smiles).__name__:
        mol = Chem.MolFromSmiles(to_smiles(mol_or_smiles))
    else:
        mol = mol_or_smiles  # assume RDKit mol

    if mol is None:
        raise ValueError("Could not parse molecule for SVG depiction")

    AllChem.Compute2DCoords(mol)
    drawer = rdMolDraw2D.MolDraw2DSVG(size[0], size[1])
    drawer.DrawMolecule(mol)
    drawer.FinishDrawing()
    return drawer.GetDrawingText()


def export_sdf(molecules, filename):
    """Export a list of SMSD MolGraphs (or SMILES strings) to an SDF file via RDKit.

    Example::

        mols = [smsd.parse_smiles(s) for s in ["CCO", "c1ccccc1", "CC(=O)O"]]
        smsd.export_sdf(mols, "output.sdf")
    """
    try:
        from rdkit import Chem
        from rdkit.Chem import AllChem
    except ImportError:
        raise ImportError(
            "RDKit is required for export_sdf(). "
            "Install with: pip install rdkit"
        )

    writer = Chem.SDWriter(filename)
    for mol in molecules:
        if isinstance(mol, str):
            rdmol = Chem.MolFromSmiles(mol)
        elif hasattr(mol, "__class__") and "MolGraph" in type(mol).__name__:
            rdmol = Chem.MolFromSmiles(to_smiles(mol))
        else:
            rdmol = mol
        if rdmol is not None:
            AllChem.Compute2DCoords(rdmol)
            writer.write(rdmol)
    writer.close()


__all__ = [
    # Types
    "ChemOptions",
    "McsOptions",
    "MolGraph",
    "MolGraphBuilder",
    # Enums
    "BondOrderMode",
    "AromaticityMode",
    "RingFusionMode",
    # SMILES / SMARTS
    "parse_smiles",
    "to_smiles",
    "to_smarts",
    # Substructure
    "is_substructure",
    "find_substructure",
    "substructure_search",
    # MCS
    "find_mcs",
    "find_all_mcs",
    "mcs",
    "all_mcs",
    # MCS SMILES extraction
    "mcs_to_smiles",
    "find_mcs_smiles",
    "mcs_smiles",
    # Similarity
    "similarity",
    "similarity_upper_bound",
    "screen_targets",
    # Fingerprints
    "fingerprint",
    "path_fingerprint",
    "mcs_fingerprint",
    "fingerprint_subset",
    "analyze_fp_quality",
    "tanimoto",
    "topological_torsion",
    # Parallel batch
    "batch_substructure",
    "batch_mcs",
    # GPU / compute backend
    "gpu_is_available",
    "gpu_device_info",
    # RDKit interoperability
    "from_rdkit",
    "get_index_map",
    "translate_mapping",
    "mcs_rdkit_native",
    "clear_cache",
    "to_rdkit",
    "mcs_rdkit",
    "substructure_rdkit",
    # Export & depiction (RDKit-powered)
    "depict_mcs",
    "depict_substructure",
    "to_svg",
    "export_sdf",
]
