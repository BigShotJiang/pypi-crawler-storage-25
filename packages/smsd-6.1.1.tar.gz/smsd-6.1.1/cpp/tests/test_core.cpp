/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 *
 * Consolidated core test suite -- substructure, MCS, ring perception,
 * chemistry, advanced features, and 5.7.0 feature tests.
 *
 * Merges: test_main.cpp, test_advanced.cpp, test_chemistry.cpp, test_rings.cpp
 */

#include "smsd/smsd.hpp"
#include "smsd/smiles_parser.hpp"
#include "smsd/ring_finder.hpp"
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>

// ============================================================================
// Test harness
// ============================================================================

static int g_pass = 0, g_fail = 0;

#define RUN_TEST(name) do { \
    std::cout << "  [" #name "] "; \
    try { test_##name(); g_pass++; std::cout << "PASS\n"; } \
    catch (const std::exception& e) { g_fail++; std::cout << "FAIL: " << e.what() << "\n"; } \
    catch (...) { g_fail++; std::cout << "FAIL (unknown)\n"; } \
} while(0)

#define TEST_ASSERT(cond, msg) do { \
    if (!(cond)) { \
        std::fprintf(stderr, "FAIL: %s  [%s:%d]\n", msg, __FILE__, __LINE__); \
        g_fail++; \
    } else { \
        g_pass++; \
    } \
} while(0)

#define TEST_ASSERT_EQ(actual, expected, msg) do { \
    auto _a = (actual); auto _e = (expected); \
    if (_a != _e) { \
        std::fprintf(stderr, "FAIL: %s  (got %d, expected %d)  [%s:%d]\n", \
                     msg, static_cast<int>(_a), static_cast<int>(_e), __FILE__, __LINE__); \
        g_fail++; \
    } else { \
        g_pass++; \
    } \
} while(0)

#define TEST_ASSERT_GEQ(actual, minimum, msg) do { \
    auto _a = (actual); auto _m = (minimum); \
    if (_a < _m) { \
        std::fprintf(stderr, "FAIL: %s  (got %d, expected >= %d)  [%s:%d]\n", \
                     msg, static_cast<int>(_a), static_cast<int>(_m), __FILE__, __LINE__); \
        g_fail++; \
    } else { \
        g_pass++; \
    } \
} while(0)

// ============================================================================
// Molecule builders (manual graph construction)
// ============================================================================

static void finalize(smsd::MolGraph& g, int bondOrd, bool bondRing, bool bondArom) {
    int n = g.n;
    int words = (n + 63) >> 6;
    g.adjLong.assign(n, std::vector<uint64_t>(words, 0));
    g.useDense = (n <= 200);
    if (g.useDense) {
        g.bondOrdMatrix.assign(n, std::vector<int>(n, 0));
        g.bondRingMatrix.assign(n, std::vector<bool>(n, false));
        g.bondAromMatrix.assign(n, std::vector<bool>(n, false));
    }
    for (int i = 0; i < n; ++i) {
        for (int j : g.neighbors[i]) {
            g.adjLong[i][j >> 6] |= uint64_t(1) << (j & 63);
            if (g.useDense) {
                g.bondOrdMatrix[i][j] = bondOrd;
                g.bondRingMatrix[i][j] = bondRing;
                g.bondAromMatrix[i][j] = bondArom;
            }
        }
    }
    g.morganRank.assign(n, 0);
    g.tautomerClass.assign(n, -1);
    g.orbit.resize(n);
    g.ringCount.assign(n, 0);
    g.tetraChirality.assign(n, 0);
    g.canonicalLabel.resize(n);
    for (int i = 0; i < n; ++i) {
        g.morganRank[i] = g.label[i];
        g.orbit[i] = i;
        g.canonicalLabel[i] = i;
    }
}

static smsd::MolGraph makeBenzene() {
    smsd::MolGraph g;
    g.n = 6;
    g.atomicNum = {6,6,6,6,6,6};
    g.formalCharge = {0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true};
    g.ring = {true,true,true,true,true,true};
    g.massNumber = {0,0,0,0,0,0};
    g.label.resize(6);
    g.degree.resize(6);
    g.neighbors.resize(6);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1;
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    finalize(g, 4, true, true);
    return g;
}

static smsd::MolGraph makePhenol() {
    smsd::MolGraph g;
    g.n = 7;
    g.atomicNum = {6,6,6,6,6,6,8};
    g.formalCharge = {0,0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true,false};
    g.ring = {true,true,true,true,true,true,false};
    g.massNumber = {0,0,0,0,0,0,0};
    g.label.resize(7);
    g.degree.resize(7);
    g.neighbors.resize(7);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1;
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    g.neighbors[0].push_back(6); g.degree[0] = 3;
    g.label[6] = (8 << 2);
    g.neighbors[6] = {0}; g.degree[6] = 1;
    finalize(g, 4, true, true);
    g.bondOrdMatrix[0][6] = 1; g.bondOrdMatrix[6][0] = 1;
    g.bondRingMatrix[0][6] = false; g.bondRingMatrix[6][0] = false;
    g.bondAromMatrix[0][6] = false; g.bondAromMatrix[6][0] = false;
    return g;
}

static smsd::MolGraph makeToluene() {
    smsd::MolGraph g;
    g.n = 7;
    g.atomicNum = {6,6,6,6,6,6,6};
    g.formalCharge = {0,0,0,0,0,0,0};
    g.aromatic = {true,true,true,true,true,true,false};
    g.ring = {true,true,true,true,true,true,false};
    g.massNumber = {0,0,0,0,0,0,0};
    g.label.resize(7);
    g.degree.resize(7);
    g.neighbors.resize(7);
    for (int i = 0; i < 6; ++i) {
        g.label[i] = (6 << 2) | 2 | 1;
        g.neighbors[i] = {(i+5)%6, (i+1)%6};
        g.degree[i] = 2;
    }
    g.neighbors[0].push_back(6); g.degree[0] = 3;
    g.label[6] = (6 << 2);
    g.neighbors[6] = {0}; g.degree[6] = 1;
    finalize(g, 4, true, true);
    g.bondOrdMatrix[0][6] = 1; g.bondOrdMatrix[6][0] = 1;
    g.bondRingMatrix[0][6] = false; g.bondRingMatrix[6][0] = false;
    g.bondAromMatrix[0][6] = false; g.bondAromMatrix[6][0] = false;
    return g;
}

// ============================================================================
// SECTION 1: Basic substructure tests (from test_main.cpp)
// ============================================================================

void test_benzene_self_sub() {
    auto benz = makeBenzene();
    smsd::ChemOptions opts;
    assert(smsd::isSubstructure(benz, benz, opts));
}

void test_benzene_in_phenol() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    assert(smsd::isSubstructure(benz, phen, opts));
}

void test_phenol_not_in_benzene() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    assert(!smsd::isSubstructure(phen, benz, opts));
}

void test_benzene_phenol_mcs() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions chem;
    smsd::McsOptions opts;
    auto mcs = smsd::findMCS(benz, phen, chem, opts);
    assert(static_cast<int>(mcs.size()) == 6);
    std::cout << "MCS=" << mcs.size() << " ";
}

void test_rascal() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    double sim = smsd::similarityUpperBound(benz, phen);
    assert(sim > 0.5);
    std::cout << "sim=" << sim << " ";
}

void test_performance() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    auto t0 = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 10000; ++i) {
        smsd::isSubstructure(benz, phen, opts);
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    double us = std::chrono::duration<double, std::micro>(t1 - t0).count() / 10000;
    std::cout << us << "us/call ";
    assert(us < 100);
}

// ============================================================================
// SECTION 2: Advanced feature tests (from test_advanced.cpp)
// ============================================================================

void test_findNMCS() {
    auto benz = makeBenzene();
    auto tol  = makeToluene();
    auto phen = makePhenol();
    std::vector<smsd::MolGraph> molecules = {benz, tol, phen};
    smsd::ChemOptions opts;
    auto nmcs = smsd::findNMCS(molecules, opts, 1.0, 10000);
    std::cout << "NMCS size=" << nmcs.size() << " ";
    assert(static_cast<int>(nmcs.size()) == 6);
}

void test_validateMapping_correct() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;
    auto mcs = smsd::findMCS(benz, phen, opts, mopts);
    assert(!mcs.empty());
    auto errors = smsd::validateMapping(benz, phen, mcs, opts);
    std::cout << "errors=" << errors.size() << " ";
    assert(errors.empty());
}

void test_validateMapping_incorrect() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    std::map<int,int> badMapping;
    badMapping[0] = 6;
    auto errors = smsd::validateMapping(benz, phen, badMapping, opts);
    std::cout << "errors=" << errors.size() << " ";
    assert(!errors.empty());
}

void test_isMappingMaximal_full() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;
    auto mcs = smsd::findMCS(benz, phen, opts, mopts);
    assert(static_cast<int>(mcs.size()) == 6);
    bool maximal = smsd::isMappingMaximal(benz, phen, mcs, opts);
    std::cout << "maximal=" << maximal << " ";
    assert(maximal);
}

void test_isMappingMaximal_partial() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;
    auto mcs = smsd::findMCS(benz, phen, opts, mopts);
    assert(static_cast<int>(mcs.size()) >= 2);
    std::map<int,int> partial = mcs;
    partial.erase(partial.begin());
    bool maximal = smsd::isMappingMaximal(benz, phen, partial, opts);
    std::cout << "maximal=" << maximal << " ";
    assert(!maximal);
}

void test_murckoScaffold_toluene() {
    auto tol = makeToluene();
    auto scaffold = smsd::murckoScaffold(tol);
    std::cout << "scaffold_atoms=" << scaffold.n << " ";
    assert(scaffold.n == 6);
}

void test_murckoScaffold_benzene() {
    auto benz = makeBenzene();
    auto scaffold = smsd::murckoScaffold(benz);
    std::cout << "scaffold_atoms=" << scaffold.n << " ";
    assert(scaffold.n == 6);
}

void test_findScaffoldMCS() {
    auto tol  = makeToluene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    smsd::McsOptions mopts;
    auto scaffMcs = smsd::findScaffoldMCS(tol, phen, opts, mopts);
    std::cout << "scaffoldMCS_size=" << scaffMcs.size() << " ";
    assert(static_cast<int>(scaffMcs.size()) == 6);
}

void test_decomposeRGroups_toluene() {
    auto benz = makeBenzene();
    auto tol  = makeToluene();
    smsd::ChemOptions opts;
    std::vector<smsd::MolGraph> molecules = {tol};
    auto results = smsd::decomposeRGroups(benz, molecules, opts, 10000);
    assert(results.size() == 1);
    auto& decomp = results[0];
    std::cout << "core=" << decomp.core.n << " rgroups=" << decomp.rgroups.size() << " ";
    assert(decomp.core.n == 6);
    assert(decomp.rgroups.size() == 1);
    auto it = decomp.rgroups.find("R1");
    assert(it != decomp.rgroups.end());
    assert(it->second.n == 1);
    assert(it->second.atomicNum[0] == 6);
}

void test_decomposeRGroups_phenol() {
    auto benz = makeBenzene();
    auto phen = makePhenol();
    smsd::ChemOptions opts;
    std::vector<smsd::MolGraph> molecules = {phen};
    auto results = smsd::decomposeRGroups(benz, molecules, opts, 10000);
    assert(results.size() == 1);
    auto& decomp = results[0];
    std::cout << "core=" << decomp.core.n << " rgroups=" << decomp.rgroups.size() << " ";
    assert(decomp.core.n == 6);
    assert(decomp.rgroups.size() == 1);
    auto it = decomp.rgroups.find("R1");
    assert(it != decomp.rgroups.end());
    assert(it->second.n == 1);
    assert(it->second.atomicNum[0] == 8);
}

void test_mapReaction() {
    auto benz1 = makeBenzene();
    auto benz2 = makeBenzene();
    smsd::ChemOptions opts;
    auto mapping = smsd::mapReaction(benz1, benz2, opts, 10000);
    std::cout << "reaction_map_size=" << mapping.size() << " ";
    assert(static_cast<int>(mapping.size()) == 6);
}

void test_extractSubgraph() {
    auto phen = makePhenol();
    std::vector<int> indices = {0, 1, 2, 3, 4, 5};
    auto sub = smsd::extractSubgraph(phen, indices);
    std::cout << "sub_atoms=" << sub.n << " ";
    assert(sub.n == 6);
    for (int i = 0; i < sub.n; ++i) {
        assert(sub.atomicNum[i] == 6);
    }
}

// ============================================================================
// SECTION 3: Chemistry tests (from test_chemistry.cpp)
// ============================================================================

void test_ring_fusion_strict_naphthalene_biphenyl() {
    auto naphthalene = smsd::parseSMILES("c1ccc2ccccc2c1");
    auto biphenyl    = smsd::parseSMILES("c1ccc(-c2ccccc2)cc1");
    smsd::ChemOptions chem;
    chem.ringFusionMode = smsd::ChemOptions::RingFusionMode::STRICT;
    chem.ringMatchesRingOnly = true;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;
    auto mcs = smsd::findMCS(naphthalene, biphenyl, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " ";
    assert(mcsSize < 10);
}

void test_crown_ether_substructure() {
    auto crown6 = smsd::parseSMILES("C1COCCOCCOCCOCCOCCO1");
    auto query  = smsd::parseSMILES("COCCOC");
    smsd::ChemOptions opts;
    bool isSub = smsd::isSubstructure(query, crown6, opts);
    std::cout << "sub=" << (isSub ? "true" : "false") << " ";
    assert(isSub);
}

void test_tautomer_keto_enol_mcs() {
    auto keto = smsd::parseSMILES("CC(=O)C");
    auto enol = smsd::parseSMILES("CC(O)=C");
    smsd::ChemOptions chem = smsd::ChemOptions::tautomerProfile();
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;
    auto mcs = smsd::findMCS(keto, enol, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " ";
    assert(mcsSize == 4);
}

void test_adamantane_self_match() {
    auto adam = smsd::parseSMILES("C1C2CC3CC1CC(C2)C3");
    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;
    auto mcs = smsd::findMCS(adam, adam, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " n=" << adam.n << " ";
    assert(mcsSize == adam.n);
}

void test_cubane_self_match() {
    auto cubane = smsd::parseSMILES("C12C3C4C1C5C4C3C25");
    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;
    auto mcs = smsd::findMCS(cubane, cubane, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " n=" << cubane.n << " ";
    assert(mcsSize == cubane.n);
}

void test_atp_adp_mcs() {
    auto atp = smsd::parseSMILES(
        "c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N");
    auto adp = smsd::parseSMILES(
        "c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)O)O)O)N");
    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 30000;
    auto mcs = smsd::findMCS(atp, adp, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " ";
    assert(mcsSize >= 27);
}

// ============================================================================
// SECTION 4: Ring finder tests (from test_rings.cpp)
// ============================================================================

static void runRingTests() {
    std::printf("  -- Ring finder tests --\n");

    // Benzene: 1 ring, 1 RCB, 1 URF
    {
        auto g = smsd::parseSMILES("c1ccccc1");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "benzene MCB=1");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 1, "benzene RCB=1");
        auto urfs = smsd::computeURFs(g);
        TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 1, "benzene URF=1");
    }

    // Naphthalene: MCB=2, RCB=2, URF=2
    {
        auto g = smsd::parseSMILES("c1ccc2ccccc2c1");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 2, "naphthalene MCB=2");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 2, "naphthalene RCB=2");
        auto urfs = smsd::computeURFs(g);
        TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 2, "naphthalene URF=2");
    }

    // Cubane: MCB=5, RCB=6, URF=1
    {
        auto g = smsd::parseSMILES("C12C3C4C1C5C4C3C25");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 5, "cubane MCB=5");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 6, "cubane RCB=6");
        auto urfs = smsd::computeURFs(g);
        TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 1, "cubane URF=1");
    }

    // Adamantane: MCB=3, RCB=4
    {
        auto g = smsd::parseSMILES("C1C2CC3CC1CC(C2)C3");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 3, "adamantane MCB=3");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 4, "adamantane RCB=4");
    }

    // Norbornane: MCB=2, RCB=2
    {
        auto g = smsd::parseSMILES("C1CC2CC1CC2");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 2, "norbornane MCB=2");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 2, "norbornane RCB=2");
    }

    // Spiro[4.4]nonane: MCB=2, RCB=2, URF=2
    {
        auto g = smsd::parseSMILES("C1CCC2(C1)CCCC2");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 2, "spiro MCB=2");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 2, "spiro RCB=2");
        auto urfs = smsd::computeURFs(g);
        TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 2, "spiro URF=2");
    }

    // Anthracene: MCB=3, RCB>=3
    {
        auto g = smsd::parseSMILES("c1ccc2cc3ccccc3cc2c1");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 3, "anthracene MCB=3");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_GEQ(static_cast<int>(rcb.size()), 3, "anthracene RCB>=3");
    }

    // Butane (acyclic): MCB=0
    {
        auto g = smsd::parseSMILES("CCCC");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 0, "butane MCB=0");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 0, "butane RCB=0");
        auto urfs = smsd::computeURFs(g);
        TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 0, "butane URF=0");
    }

    // Cyclopropane: MCB=1, ring size=3
    {
        auto g = smsd::parseSMILES("C1CC1");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "cyclopropane MCB=1");
        TEST_ASSERT_EQ(static_cast<int>(mcb[0].size()), 3, "cyclopropane ring size=3");
    }

    // bfsPath basic test
    {
        auto g = smsd::parseSMILES("CCCC");
        auto path = smsd::bfsPath(g, 0, 3, -1, -1);
        TEST_ASSERT_EQ(static_cast<int>(path.size()), 4, "bfsPath linear 0->3 len=4");
        TEST_ASSERT_EQ(path.front(), 0, "bfsPath start=0");
        TEST_ASSERT_EQ(path.back(), 3, "bfsPath end=3");
        auto trivial = smsd::bfsPath(g, 0, 0, -1, -1);
        TEST_ASSERT_EQ(static_cast<int>(trivial.size()), 1, "bfsPath trivial size=1");
        auto benz = smsd::parseSMILES("C1CCCCC1");
        auto p2 = smsd::bfsPath(benz, 0, 1, 0, 1);
        TEST_ASSERT(static_cast<int>(p2.size()) > 2, "bfsPath benzene avoids direct edge");
    }

    // Empty graph
    {
        smsd::MolGraph g;
        g.n = 0;
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 0, "empty MCB=0");
        auto rcb = smsd::computeRelevantCycles(g);
        TEST_ASSERT_EQ(static_cast<int>(rcb.size()), 0, "empty RCB=0");
        auto urfs = smsd::computeURFs(g);
        TEST_ASSERT_EQ(static_cast<int>(urfs.size()), 0, "empty URF=0");
    }

    // Cyclohexane: MCB=1, ring size=6
    {
        auto g = smsd::parseSMILES("C1CCCCC1");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "cyclohexane MCB=1");
        TEST_ASSERT_EQ(static_cast<int>(mcb[0].size()), 6, "cyclohexane ring size=6");
    }

    // Disconnected: ethane + cyclopropane
    {
        auto g = smsd::parseSMILES("CC.C1CC1");
        auto mcb = smsd::computeRings(g);
        TEST_ASSERT_EQ(static_cast<int>(mcb.size()), 1, "disconnected MCB=1");
    }
}

// ============================================================================
// SECTION 5: v5.7.0 feature tests
// ============================================================================

// Tree-DP: branched molecule MCS (isobutane vs neopentane)
// Isobutane CC(C)C has 4 atoms; neopentane CC(C)(C)C has 5 atoms.
// Both are acyclic (trees). The MCS should be the isobutane skeleton (4 atoms)
// since isobutane is a subgraph of neopentane.
void test_tree_dp_branched_mcs() {
    auto isobutane  = smsd::parseSMILES("CC(C)C");
    auto neopentane = smsd::parseSMILES("CC(C)(C)C");

    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 10000;

    auto mcs = smsd::findMCS(isobutane, neopentane, chem, mcsOpts);
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " ";

    // Isobutane (4 atoms) should map completely into neopentane
    assert(mcsSize == 4);
}

// LFUB degree-aware: induced MCS uses tighter bound.
// When opts.induced=true, the MCS must be an induced subgraph.
// For neopentane (degree-4 center) vs isobutane (degree-3 center),
// the induced MCS should be smaller than the non-induced MCS because
// the degree-4 center in neopentane has no degree-3 equivalent in an
// induced mapping.
void test_lfub_induced_tighter_bound() {
    auto isobutane  = smsd::parseSMILES("CC(C)C");
    auto neopentane = smsd::parseSMILES("CC(C)(C)C");

    smsd::ChemOptions chem;
    smsd::McsOptions normalOpts;
    normalOpts.timeoutMs = 10000;
    normalOpts.induced = false;

    smsd::McsOptions inducedOpts;
    inducedOpts.timeoutMs = 10000;
    inducedOpts.induced = true;

    auto mcsNormal  = smsd::findMCS(isobutane, neopentane, chem, normalOpts);
    auto mcsInduced = smsd::findMCS(isobutane, neopentane, chem, inducedOpts);

    int normalSize  = static_cast<int>(mcsNormal.size());
    int inducedSize = static_cast<int>(mcsInduced.size());
    std::cout << "normal=" << normalSize << " induced=" << inducedSize << " ";

    // Induced MCS should be <= non-induced MCS
    assert(inducedSize <= normalSize);
    // Non-induced should still find 4 atoms
    assert(normalSize == 4);
    // Induced MCS must be at least 3 (the three-carbon chain is always induced)
    assert(inducedSize >= 3);
}

// Tier 2 pKa: DMSO solvent changes tautomer weights.
// In DMSO, keto-enol equilibrium shifts toward enol, lowering the tautomer
// weight. We verify that the tautomerWeight values differ between AQUEOUS
// and DMSO solvents for an acetone/enol pair.
void test_tier2_pka_dmso_solvent() {
    // Build keto form (acetone) in aqueous and DMSO
    auto keto_aq   = smsd::parseSMILES("CC(=O)C");
    auto keto_dmso = smsd::parseSMILES("CC(=O)C");

    // Apply DMSO solvent correction to the second molecule
    keto_dmso.computeTautomerClasses();
    keto_dmso.applySolventCorrection(smsd::ChemOptions::Solvent::DMSO);

    // The aqueous molecule already had tautomer classes computed during parse.
    // Check that at least one tautomeric atom has a different weight in DMSO.
    bool foundDifference = false;
    for (int i = 0; i < keto_aq.n; ++i) {
        if (keto_aq.tautomerClass[i] >= 0 &&
            !keto_aq.tautomerWeight.empty() &&
            !keto_dmso.tautomerWeight.empty()) {
            float wAq   = keto_aq.tautomerWeight[i];
            float wDmso = keto_dmso.tautomerWeight[i];
            if (std::abs(wAq - wDmso) > 0.001f) {
                foundDifference = true;
                std::cout << "atom" << i << " aq=" << wAq << " dmso=" << wDmso << " ";
            }
        }
    }
    assert(foundDifference);
}

// Chain fast-path: PEG-12 vs PEG-16 should complete in <100ms.
void test_chain_fastpath_peg() {
    // Use simple, shorter PEG strings instead
    std::string peg12 = "OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO";    // ~12 EG units
    std::string peg16 = "OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO"; // ~16 EG units

    auto g1 = smsd::parseSMILES(peg12);
    auto g2 = smsd::parseSMILES(peg16);

    smsd::ChemOptions chem;
    smsd::McsOptions mcsOpts;
    mcsOpts.timeoutMs = 5000;

    auto t0 = std::chrono::high_resolution_clock::now();
    auto mcs = smsd::findMCS(g1, g2, chem, mcsOpts);
    auto t1 = std::chrono::high_resolution_clock::now();

    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    int mcsSize = static_cast<int>(mcs.size());
    std::cout << "MCS=" << mcsSize << " time=" << ms << "ms ";

    // PEG-12 should map fully into PEG-16 (all atoms of the shorter chain)
    assert(mcsSize == g1.n);
    // Chain fast-path should complete well under 100ms
    assert(ms < 100.0);
}

// Lenient parser: ParseOptions{.lenient=true} on malformed SMILES.
// A malformed SMILES with unbalanced parentheses should throw in strict mode
// but produce a partial result (or empty) in lenient mode.
void test_lenient_parser_malformed() {
    // Strict mode: should throw
    bool threw = false;
    try {
        smsd::parseSMILES("CC(=O");  // unbalanced paren
    } catch (const std::exception&) {
        threw = true;
    }
    assert(threw);

    // Lenient mode: should not throw
    smsd::ParseOptions opts;
    opts.lenient = true;
    bool lenientThrew = false;
    smsd::MolGraph result;
    try {
        result = smsd::parseSMILES("CC(=O", opts);
    } catch (const std::exception&) {
        lenientThrew = true;
    }
    std::cout << "strict_threw=true lenient_threw=" << (lenientThrew ? "true" : "false")
              << " lenient_atoms=" << result.n << " ";
    assert(!lenientThrew);
    // Lenient should recover at least some atoms
    assert(result.n >= 2);
}

// ============================================================================
// main
// ============================================================================

int main() {
    std::cout << "=== SMSD Core Test Suite ===\n\n";

    std::cout << "-- Basic substructure & MCS --\n";
    RUN_TEST(benzene_self_sub);
    RUN_TEST(benzene_in_phenol);
    RUN_TEST(phenol_not_in_benzene);
    RUN_TEST(benzene_phenol_mcs);
    RUN_TEST(rascal);
    RUN_TEST(performance);

    std::cout << "\n-- Advanced features --\n";
    RUN_TEST(findNMCS);
    RUN_TEST(validateMapping_correct);
    RUN_TEST(validateMapping_incorrect);
    RUN_TEST(isMappingMaximal_full);
    RUN_TEST(isMappingMaximal_partial);
    RUN_TEST(murckoScaffold_toluene);
    RUN_TEST(murckoScaffold_benzene);
    RUN_TEST(findScaffoldMCS);
    RUN_TEST(decomposeRGroups_toluene);
    RUN_TEST(decomposeRGroups_phenol);
    RUN_TEST(mapReaction);
    RUN_TEST(extractSubgraph);

    std::cout << "\n-- Chemistry (SMILES-based) --\n";
    RUN_TEST(ring_fusion_strict_naphthalene_biphenyl);
    RUN_TEST(crown_ether_substructure);
    RUN_TEST(tautomer_keto_enol_mcs);
    RUN_TEST(adamantane_self_match);
    RUN_TEST(cubane_self_match);
    RUN_TEST(atp_adp_mcs);

    std::cout << "\n-- Ring perception --\n";
    runRingTests();

    std::cout << "\n-- v5.7.0 features --\n";
    RUN_TEST(tree_dp_branched_mcs);
    RUN_TEST(lfub_induced_tighter_bound);
    RUN_TEST(tier2_pka_dmso_solvent);
    RUN_TEST(chain_fastpath_peg);
    RUN_TEST(lenient_parser_malformed);
    RUN_TEST(ethanol_self_mcs);
    RUN_TEST(piperazine_self_mcs);
    RUN_TEST(mcs_bound_invariant);

    std::cout << "\n================================================\n";
    std::cout << g_pass << " passed, " << g_fail << " failed\n";
    return g_fail > 0 ? 1 : 0;
}

// ===========================================================================
// MCS Chemical Validity Tests
// ===========================================================================

void ethanol_self_mcs() {
    auto eth = smsd::parseSMILES("CCO");
    ASSERT_EQ(eth.n, 3); // 3 heavy atoms
    auto mcs = smsd::findMCS(eth, eth, smsd::ChemOptions{}, smsd::McsOptions{});
    ASSERT_EQ(static_cast<int>(mcs.size()), 3);
}

void piperazine_self_mcs() {
    auto pip = smsd::parseSMILES("C1CNCCN1");
    ASSERT_EQ(pip.n, 6); // 4C + 2N = 6 heavy atoms
    auto mcs = smsd::findMCS(pip, pip, smsd::ChemOptions{}, smsd::McsOptions{});
    ASSERT_EQ(static_cast<int>(mcs.size()), 6); // must be 6, not 17
}

void mcs_bound_invariant() {
    // MCS size must never exceed min(n1, n2)
    const char* pairs[][2] = {
        {"CCO", "CCCO"},
        {"c1ccccc1", "c1ccc2ccccc2c1"},
        {"C1CNCCN1", "C1CN(c2ccccc2)CCN1"},
        {"CC(=O)O", "CC(=O)Oc1ccccc1"},
    };
    for (auto& pair : pairs) {
        auto g1 = smsd::parseSMILES(pair[0]);
        auto g2 = smsd::parseSMILES(pair[1]);
        auto mcs = smsd::findMCS(g1, g2, smsd::ChemOptions{}, smsd::McsOptions{});
        int minN = std::min(g1.n, g2.n);
        ASSERT_TRUE(static_cast<int>(mcs.size()) <= minN);
    }
}
