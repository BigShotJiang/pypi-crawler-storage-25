#!/usr/bin/env python3
"""Provision or update a local Atlas user without Cognito calls."""

from __future__ import annotations

import argparse
import json
import uuid

from app.db.engine import SessionLocal
from app.domain.enums import AccessScope, SystemGroup
from app.domain.services.groups import GroupCreate, UserGroupService
from app.domain.services.users import UserCreate, UserService, UserUpdate


def _scope_for_group(group: str) -> AccessScope:
    if group == SystemGroup.ADMIN.value:
        return AccessScope.SYSTEM
    if group == SystemGroup.LSMC_STAFF.value:
        return AccessScope.CROSS_TENANT
    return AccessScope.TENANT


def _ensure_group(svc: UserGroupService, group_code: str) -> str:
    existing = svc.get_group_by_code(group_code)
    if existing is not None:
        return existing.euid
    created, _created_revision = svc.create_group(
        GroupCreate(
            group_code=group_code,
            name=group_code.replace("_", " ").title(),
            description="Created by provision_local_user.py",
            access_scope=_scope_for_group(group_code),
        ),
        created_by=None,
    )
    return created.euid


def main() -> int:
    parser = argparse.ArgumentParser(description="Provision a local Atlas user")
    parser.add_argument("--email", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--tenant-id", required=True)
    parser.add_argument("--role", action="append", default=[], help="Exact role list")
    parser.add_argument("--group", action="append", default=[], help="Group code to ensure")
    parser.add_argument("--json", action="store_true", help="Print JSON only")
    args = parser.parse_args()

    tenant_id = uuid.UUID(str(args.tenant_id).strip())
    email = str(args.email).strip().lower()
    deterministic_sub = str(uuid.uuid5(uuid.NAMESPACE_URL, f"atlas-local-user:{email}"))
    roles = [str(role).strip().upper() for role in args.role if str(role).strip()]

    session = SessionLocal()
    try:
        user_svc = UserService(session)
        existing = user_svc.get_by_email(email)
        if existing is None:
            user = user_svc.create(
                UserCreate(
                    email=email,
                    name=args.name.strip(),
                    tenant_id=tenant_id,
                    roles=roles,
                    cognito_sub=deterministic_sub,
                )
            )
        else:
            if existing.tenant_id != tenant_id:
                raise ValueError(
                    f"User {email} already exists in tenant {existing.tenant_id}, expected {tenant_id}"
                )
            user = user_svc.update(
                existing.euid,
                UserUpdate(
                    name=args.name.strip(),
                    roles=roles or list(existing.roles or []),
                    is_active=True,
                ),
            )

        group_svc = UserGroupService(session, tenant_id)
        user_sub = uuid.UUID(str(user.cognito_sub))
        ensured_groups: list[str] = []
        for raw_group in args.group:
            group_code = str(raw_group).strip().upper()
            if not group_code:
                continue
            group_euid = _ensure_group(group_svc, group_code)
            group_svc.add_user_to_group(user_sub, group_euid, None)
            ensured_groups.append(group_code)

        session.commit()
        payload = {
            "euid": user.euid,
            "email": user.email,
            "tenant_id": str(user.tenant_id),
            "cognito_sub": str(user.cognito_sub),
            "roles": list(user.roles or []),
            "groups": ensured_groups,
        }
    except Exception as exc:
        session.rollback()
        print(f"Provision failed: {exc}")
        return 1
    finally:
        session.close()

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(json.dumps(payload, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
