#!/usr/bin/env python3
"""Create or resolve the local Day In The Life baseline objects."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from datetime import date
from typing import Any

from app.db.engine import SessionLocal
from app.domain.enums import AccessScope, SystemGroup
from app.domain.services.groups import GroupCreate, UserGroupService
from app.domain.services.orgs import (
    OrganizationCreate,
    OrganizationService,
    SiteCreate,
    SiteService,
)
from app.domain.services.people import (
    ClinicianCreate,
    ClinicianService,
    PatientCreate,
    PatientService,
)
from app.domain.services.test_definitions import (
    TestDefinitionCreate,
    TestDefinitionService,
    TestDefinitionUpdate,
)

SITE_NAME = "LSMC Main Site"
SITE_CODE = "LSMC-MAIN"
PATIENT_FIRST = "Jane"
PATIENT_LAST = "Doe"
PATIENT_MRN = "JANE-DOE-DEMO"
CLINICIAN_FIRST = "Jeff"
CLINICIAN_LAST = "Ma"
CLINICIAN_NPI = "1999999999"
ASSAY_CODE = "WGS-short-read"
ASSAY_NAME = "ILMN short read"


@dataclass
class SeedObject:
    euid: str
    name: str


def _latest_revision(obj: Any) -> Any | None:
    revisions = getattr(obj, "revisions", None)
    if isinstance(revisions, list) and revisions:
        return revisions[-1]
    return None


def _display_name(obj: Any) -> str:
    revision = _latest_revision(obj)
    if revision is not None:
        for attr in ("display_name", "name", "site_code"):
            value = str(getattr(revision, attr, "") or "").strip()
            if value:
                return value
    for attr in ("display_name", "name", "euid"):
        value = str(getattr(obj, attr, "") or "").strip()
        if value:
            return value
    return "unknown"


def _scope_for_group(group: str) -> AccessScope:
    if group == SystemGroup.ADMIN.value:
        return AccessScope.SYSTEM
    if group == SystemGroup.LSMC_STAFF.value:
        return AccessScope.CROSS_TENANT
    return AccessScope.TENANT


def _ensure_system_groups(db, tenant_id) -> None:
    svc = UserGroupService(db, tenant_id)
    for group_code in SystemGroup:
        existing = svc.get_group_by_code(group_code.value)
        if existing is not None:
            continue
        svc.create_group(
            GroupCreate(
                group_code=group_code.value,
                name=group_code.value.replace("_", " ").title(),
                description=f"System group {group_code.value}",
                access_scope=_scope_for_group(group_code.value),
            ),
            created_by=None,
        )


def _ensure_organization(db) -> tuple[Any, Any]:
    org_svc = OrganizationService(db)
    orgs = org_svc.list_all(active_only=False)
    if orgs:
        current = orgs[0]
        org_with_revision = org_svc.get_with_revision(current.euid)
        if org_with_revision is not None:
            return org_with_revision

    created = org_svc.create(
        OrganizationCreate(
            name="lsmc-default-org",
            display_name="LSMC Default Org",
            org_type="clinic",
            initial_site_name=SITE_NAME,
            initial_site_code=SITE_CODE,
        ),
        created_by=None,
    )
    org_with_revision = org_svc.get_with_revision(created.euid)
    assert org_with_revision is not None
    return org_with_revision


def _ensure_site(db, organization_euid: str) -> Any:
    site_svc = SiteService(db)
    for site in site_svc.list_by_organization(organization_euid, active_only=False):
        revision = _latest_revision(site)
        site_code = str(getattr(revision, "site_code", "") or "").strip()
        site_name = str(getattr(revision, "name", "") or "").strip()
        if site_code == SITE_CODE or site_name == SITE_NAME:
            return site
    return site_svc.create(
        SiteCreate(
            organization_id=organization_euid,
            name=SITE_NAME,
            site_code=SITE_CODE,
        ),
        created_by=None,
    )


def _ensure_patient(db, tenant_id, site_euid: str) -> tuple[Any, Any]:
    patient_svc = PatientService(db, tenant_id)
    for patient, revision in patient_svc.search_by_name(
        f"{PATIENT_FIRST} {PATIENT_LAST}", limit=20
    ):
        if (
            str(getattr(revision, "first_name", "") or "").strip() == PATIENT_FIRST
            and str(getattr(revision, "last_name", "") or "").strip() == PATIENT_LAST
        ):
            return patient, revision
    return patient_svc.create(
        PatientCreate(
            first_name=PATIENT_FIRST,
            last_name=PATIENT_LAST,
            date_of_birth=date(1985, 1, 1),
            mrn=PATIENT_MRN,
            site_id=site_euid,
            clinical_notes="Local Day In The Life demo baseline patient",
        ),
        created_by=None,
    )


def _ensure_clinician(db, tenant_id, site_euid: str) -> tuple[Any, Any]:
    clinician_svc = ClinicianService(db, tenant_id)
    existing = clinician_svc.get_by_npi(CLINICIAN_NPI)
    if existing is not None:
        return existing
    for clinician, revision in clinician_svc.search_by_name(
        f"{CLINICIAN_FIRST} {CLINICIAN_LAST}", limit=20
    ):
        if (
            str(getattr(revision, "first_name", "") or "").strip() == CLINICIAN_FIRST
            and str(getattr(revision, "last_name", "") or "").strip() == CLINICIAN_LAST
        ):
            return clinician, revision
    return clinician_svc.create(
        ClinicianCreate(
            first_name=CLINICIAN_FIRST,
            last_name=CLINICIAN_LAST,
            credentials="MD",
            specialty="Medical Genetics",
            npi=CLINICIAN_NPI,
            email="jeff.ma@lsmc.local",
            site_id=site_euid,
        ),
        created_by=None,
    )


def _ensure_assay(db) -> Any:
    svc = TestDefinitionService(db)
    assay = svc.get_by_code(ASSAY_CODE)
    if assay is None:
        return svc.create(
            TestDefinitionCreate(
                code=ASSAY_CODE,
                name=ASSAY_NAME,
                description="Local Day In The Life demo assay",
                category="genomics",
                technology="illumina_short_read",
                specimen_types=["whole_blood"],
            )
        )
    if assay.name != ASSAY_NAME or getattr(assay, "is_active", True) is False:
        assay = svc.update(
            assay.euid,
            TestDefinitionUpdate(
                name=ASSAY_NAME,
                description="Local Day In The Life demo assay",
                category="genomics",
                technology="illumina_short_read",
                specimen_types=["whole_blood"],
                is_active=True,
            ),
        )
    return assay


def main() -> int:
    parser = argparse.ArgumentParser(description="Seed local Day In The Life baseline objects")
    parser.add_argument("--json", action="store_true", help="Print JSON only")
    args = parser.parse_args()

    session = SessionLocal()
    try:
        organization, org_revision = _ensure_organization(session)
        _ensure_system_groups(session, organization.uid)
        site = _ensure_site(session, organization.euid)
        patient, patient_revision = _ensure_patient(session, organization.uid, site.euid)
        clinician, clinician_revision = _ensure_clinician(session, organization.uid, site.euid)
        assay = _ensure_assay(session)
        session.commit()

        payload = {
            "organization": asdict(
                SeedObject(euid=organization.euid, name=_display_name(organization))
            ),
            "site": asdict(SeedObject(euid=site.euid, name=_display_name(site))),
            "patient": asdict(
                SeedObject(
                    euid=patient.euid,
                    name=" ".join(
                        [
                            str(getattr(patient_revision, "first_name", "") or "").strip(),
                            str(getattr(patient_revision, "last_name", "") or "").strip(),
                        ]
                    ).strip(),
                )
            ),
            "clinician": asdict(
                SeedObject(
                    euid=clinician.euid,
                    name=" ".join(
                        [
                            str(getattr(clinician_revision, "first_name", "") or "").strip(),
                            str(getattr(clinician_revision, "last_name", "") or "").strip(),
                        ]
                    ).strip(),
                )
            ),
            "assay": {
                "euid": assay.euid,
                "code": assay.code,
                "name": assay.name,
            },
            "tenant_id": str(organization.uid),
        }
    except Exception as exc:
        session.rollback()
        print(f"Seed failed: {exc}")
        return 1
    finally:
        session.close()

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"organization={payload['organization']['euid']} {payload['organization']['name']}")
        print(f"site={payload['site']['euid']} {payload['site']['name']}")
        print(f"patient={payload['patient']['euid']} {payload['patient']['name']}")
        print(f"clinician={payload['clinician']['euid']} {payload['clinician']['name']}")
        print(f"assay={payload['assay']['code']} {payload['assay']['name']}")
        print(json.dumps(payload, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
