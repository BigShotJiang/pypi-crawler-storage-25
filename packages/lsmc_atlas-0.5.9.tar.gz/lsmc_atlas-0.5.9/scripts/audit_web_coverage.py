"""Audit which web routes have test coverage."""

import sys

sys.path.insert(0, ".")

from app.main import app

# Get all web routes (non-API, non-auth, non-static)
web_routes = []
for route in app.routes:
    if hasattr(route, "path") and hasattr(route, "methods"):
        path = route.path
        # Skip API, auth, internal, static, docs
        if any(
            path.startswith(p)
            for p in [
                "/api/",
                "/auth/",
                "/internal/",
                "/static",
                "/docs",
                "/redoc",
                "/openapi",
                "/webhooks",
                "/api-clients",
                "/user-tokens",
                "/admin/user-tokens",
            ]
        ):
            continue
        for method in route.methods:
            if method in ("GET", "POST"):
                web_routes.append((method, path))

web_routes.sort(key=lambda x: (x[1], x[0]))

# Read all test files
test_files = [
    "tests/test_web_crud.py",
    "tests/test_ext_admin.py",
    "tests/test_api_smoke.py",
]
test_content = ""
for f in test_files:
    try:
        with open(f) as fh:
            test_content += fh.read()
    except FileNotFoundError:
        pass


# For each web route, check if it appears in tests
# We'll normalize paths by replacing {param} with a wildcard
def route_in_tests(method: str, path: str) -> bool:
    """Check if a route has any test coverage."""
    # Exact path match
    if path in test_content:
        return True
    # Check for path with f-string substitution (remove leading /)
    segments = path.split("/")
    # Build a regex-like search: replace {param} with any non-/ chars
    static_parts = []
    for seg in segments:
        if seg.startswith("{"):
            continue  # skip param segments for search
        if seg:
            static_parts.append(seg)
    # If we have >=2 static parts, search for them together
    if len(static_parts) >= 2:
        pattern = "/".join(static_parts)
        if pattern in test_content:
            return True
    # Check for method + partial path
    if method == "POST":
        # POST routes might use client.post("path")
        if static_parts and f'client.post("/{"/".join(static_parts)}' in test_content:
            return True
    return False


print(f"Total web routes: {len(web_routes)}")
print()

tested = []
untested = []
for method, path in web_routes:
    if route_in_tests(method, path):
        tested.append((method, path))
    else:
        untested.append((method, path))

print(f"Tested: {len(tested)}")
print(f"Untested: {len(untested)}")
print()
print("=== UNTESTED WEB ROUTES ===")
for method, path in untested:
    print(f"  {method:4s} {path}")
