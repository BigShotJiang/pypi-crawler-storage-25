#!/usr/bin/env python
"""Find which routes have tests and which don't."""

import re
import sys
from pathlib import Path

sys.path.insert(0, ".")
from app.main import app  # noqa: E402

# Collect all routes
all_routes = {}
for route in app.routes:
    if hasattr(route, "methods") and hasattr(route, "path"):
        for method in route.methods:
            if method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                path = route.path
                if path in ("/docs", "/redoc", "/openapi.json", "/health"):
                    continue
                if path.startswith("/auth/"):
                    continue
                all_routes[f"{method} {path}"] = False

# Scan test files for route references
test_dir = Path("tests")
for tf in test_dir.glob("test_*.py"):
    content = tf.read_text()
    for route_key in all_routes:
        method, path = route_key.split(" ", 1)
        # Convert path params to regex pattern
        pattern = re.sub(r"\{[^}]+\}", r"[^/]+", re.escape(path))
        # Check if the path appears in test file
        if re.search(pattern, content):
            # Also check the method is used
            method_lower = method.lower()
            if method_lower == "delete":
                check = ".delete(" in content or ".delete_(" in content
            elif method_lower == "patch":
                check = ".patch(" in content
            else:
                check = f".{method_lower}(" in content
            if check:
                all_routes[route_key] = True

# Report
api_tested = []
api_untested = []
web_tested = []
web_untested = []

for route_key, tested in sorted(all_routes.items()):
    method, path = route_key.split(" ", 1)
    is_api = path.startswith("/api/") or path.startswith("/internal/")
    if is_api:
        (api_tested if tested else api_untested).append(route_key)
    else:
        (web_tested if tested else web_untested).append(route_key)

print(f"=== API: {len(api_tested)}/{len(api_tested) + len(api_untested)} tested ===")
print(f"\n--- API UNTESTED ({len(api_untested)}) ---")
for r in api_untested:
    print(f"  [ ] {r}")

print(f"\n=== WEB: {len(web_tested)}/{len(web_tested) + len(web_untested)} tested ===")
print(f"\n--- WEB UNTESTED ({len(web_untested)}) ---")
for r in web_untested:
    print(f"  [ ] {r}")

print(f"\nTOTAL: {len(api_tested) + len(web_tested)}/{len(all_routes)} routes tested")
print(f"MISSING: {len(api_untested) + len(web_untested)} routes need tests")
