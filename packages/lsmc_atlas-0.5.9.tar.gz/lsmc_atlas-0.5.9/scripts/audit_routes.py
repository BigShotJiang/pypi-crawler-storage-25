#!/usr/bin/env python
"""Audit all registered routes in the LSMC Atlas app."""

import sys

sys.path.insert(0, ".")

from app.main import app  # noqa: E402

api_routes = []
web_routes = []
for route in app.routes:
    if hasattr(route, "methods") and hasattr(route, "path"):
        for method in route.methods:
            if method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                path = route.path
                if path in ("/docs", "/redoc", "/openapi.json", "/health"):
                    continue
                if path.startswith("/api/") or path.startswith("/internal/"):
                    api_routes.append(f"{method:6s} {path}")
                elif path.startswith("/auth/"):
                    continue
                else:
                    web_routes.append(f"{method:6s} {path}")

print(f"=== API ROUTES ({len(api_routes)}) ===")
for r in sorted(api_routes):
    print(r)
print(f"\n=== WEB ROUTES ({len(web_routes)}) ===")
for r in sorted(web_routes):
    print(r)
