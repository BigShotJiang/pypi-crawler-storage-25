#!/usr/bin/env python3
"""Seed development data for LSMC Atlas.

Creates realistic sample data for development and demo purposes:
- 2 Organizations (Acme Genetics, Mountain View Hospital)
- Sites, Clinicians, Patients
- Orders with TestOrders
- Shipments, TestKits, BioSpecimens
- 1 Released Package

Usage:
    python scripts/seed_dev_data.py

This script can be run multiple times - it will skip existing data.
"""

import sys
import uuid
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from app.persistence.tapdb.orm_models import (
    Artifact,
    BioSpecimen,
    BioSpecimenRevision,
    BioSpecimenStatus,
    Clinician,
    ClinicianRevision,
    Order,
    OrderRevision,
    OrderStatus,
    OrderType,
    Organization,
    OrganizationRevision,
    Patient,
    PatientRevision,
    ReleasePackage,
    ReleasePackageRevision,
    ReleasePackageStatus,
    Shipment,
    ShipmentRevision,
    ShipmentStatus,
    Site,
    SiteRevision,
    TestKit,
    TestKitRevision,
    TestOrder,
    TestOrderRevision,
    TestOrderStatus,
)
from app.persistence.tapdb.orm_models.events import (
    ContainmentAction,
    ContainmentEvent,
    LinkAction,
    LinkEvent,
)
from app.persistence.tapdb.orm_models.groups import (
    AccessScope,
    SystemGroup,
    UserGroup,
    UserGroupRevision,
)
from app.settings import settings

# Fixed UUIDs for reproducibility
ORG1_ID = uuid.UUID("11111111-1111-1111-1111-111111111111")
ORG2_ID = uuid.UUID("22222222-2222-2222-2222-222222222222")
SITE1_ID = uuid.UUID("11111111-2222-3333-4444-555555555555")
SITE2_ID = uuid.UUID("22222222-3333-4444-5555-666666666666")
PATIENT1_ID = uuid.UUID("aaaa1111-1111-1111-1111-111111111111")
PATIENT2_ID = uuid.UUID("aaaa2222-2222-2222-2222-222222222222")
PATIENT3_ID = uuid.UUID("aaaa3333-3333-3333-3333-333333333333")
CLINICIAN1_ID = uuid.UUID("cccc1111-1111-1111-1111-111111111111")
CLINICIAN2_ID = uuid.UUID("cccc2222-2222-2222-2222-222222222222")
ORDER1_ID = uuid.UUID("dddd1111-1111-1111-1111-111111111111")
ORDER2_ID = uuid.UUID("dddd2222-2222-2222-2222-222222222222")
ORDER3_ID = uuid.UUID("dddd3333-3333-3333-3333-333333333333")
TEST_ORDER1_ID = uuid.UUID("eeee1111-1111-1111-1111-111111111111")
TEST_ORDER2_ID = uuid.UUID("eeee2222-2222-2222-2222-222222222222")
TEST_ORDER3_ID = uuid.UUID("eeee3333-3333-3333-3333-333333333333")
SHIPMENT1_ID = uuid.UUID("ffff1111-1111-1111-1111-111111111111")
SHIPMENT2_ID = uuid.UUID("ffff2222-2222-2222-2222-222222222222")
TESTKIT1_ID = uuid.UUID("1111aaaa-1111-1111-1111-111111111111")
TESTKIT2_ID = uuid.UUID("1111bbbb-2222-2222-2222-222222222222")
SPECIMEN1_ID = uuid.UUID("2222aaaa-1111-1111-1111-111111111111")
SPECIMEN2_ID = uuid.UUID("2222bbbb-2222-2222-2222-222222222222")
SPECIMEN3_ID = uuid.UUID("2222cccc-3333-3333-3333-333333333333")
MANIFEST1_ID = uuid.UUID("3333aaaa-1111-1111-1111-111111111111")
ARTIFACT1_ID = uuid.UUID("4444aaaa-1111-1111-1111-111111111111")
ARTIFACT2_ID = uuid.UUID("4444bbbb-2222-2222-2222-222222222222")
RELEASE1_ID = uuid.UUID("5555aaaa-1111-1111-1111-111111111111")

# Dev tenant IDs (matches settings.dev_tenant_id default)
DEV_TENANT_ID = uuid.UUID("00000000-0000-0000-0000-000000000001")
DEV_PATIENT_ID = uuid.UUID("00000000-aaaa-0000-0000-000000000001")
DEV_CLINICIAN_ID = uuid.UUID("00000000-cccc-0000-0000-000000000001")
DEV_ORDER1_ID = uuid.UUID("00000000-dddd-0000-0000-000000000001")
DEV_ORDER2_ID = uuid.UUID("00000000-dddd-0000-0000-000000000002")
DEV_TEST_ORDER1_ID = uuid.UUID("00000000-eeee-0000-0000-000000000001")
DEV_TEST_ORDER2_ID = uuid.UUID("00000000-eeee-0000-0000-000000000002")
DEV_SHIPMENT_ID = uuid.UUID("00000000-ffff-0000-0000-000000000001")
DEV_TESTKIT_ID = uuid.UUID("00000000-1111-aaaa-0000-000000000001")
DEV_SPECIMEN_ID = uuid.UUID("00000000-2222-aaaa-0000-000000000001")

# System group UUIDs (system-wide, no tenant)
GROUP_CUSTOMER_ID = uuid.UUID("00000000-0000-0000-aaaa-000000000001")
GROUP_LSMC_STAFF_ID = uuid.UUID("00000000-0000-0000-aaaa-000000000002")
GROUP_ADMIN_ID = uuid.UUID("00000000-0000-0000-aaaa-000000000003")
GROUP_API_ACCESS_ID = uuid.UUID("00000000-0000-0000-aaaa-000000000004")


def seed_system_groups(session: Session) -> None:
    """Create system groups if they don't exist."""
    existing = session.execute(
        text("SELECT id FROM user_group WHERE id = :id"), {"id": str(GROUP_API_ACCESS_ID)}
    ).first()
    if existing:
        print("  System groups already exist, skipping...")
        return

    # Define system groups with their metadata
    system_groups = [
        {
            "id": GROUP_CUSTOMER_ID,
            "code": SystemGroup.CUSTOMER.value,
            "name": "Customer",
            "description": "External customers - access limited to own tenant/organization",
            "access_scope": AccessScope.TENANT.value,
            "default_roles": ["EXTERNAL_USER"],
        },
        {
            "id": GROUP_LSMC_STAFF_ID,
            "code": SystemGroup.LSMC_STAFF.value,
            "name": "LSMC Staff",
            "description": "Internal LSMC staff - cross-tenant access for intake operations",
            "access_scope": AccessScope.CROSS_TENANT.value,
            "default_roles": ["INTERNAL_USER"],
        },
        {
            "id": GROUP_ADMIN_ID,
            "code": SystemGroup.ADMIN.value,
            "name": "Administrators",
            "description": "Full system access including admin tools",
            "access_scope": AccessScope.SYSTEM.value,
            "default_roles": ["ADMIN"],
        },
        {
            "id": GROUP_API_ACCESS_ID,
            "code": SystemGroup.API_ACCESS.value,
            "name": "API Access",
            "description": "Users who can create personal API tokens for programmatic access",
            "access_scope": AccessScope.TENANT.value,
            "default_roles": [],  # No additional roles; tokens inherit user's roles
        },
    ]

    for grp in system_groups:
        # Create group identity
        group = UserGroup(
            id=grp["id"],
            tenant_id=None,  # System-wide groups have no tenant
            group_code=grp["code"],
        )
        session.add(group)
        session.flush()

        # Create initial revision
        revision = UserGroupRevision(
            group_id=grp["id"],
            revision_no=1,
            name=grp["name"],
            description=grp["description"],
            access_scope=grp["access_scope"],
            default_roles=grp["default_roles"],
            is_system_group=True,
            is_active=True,
            note="Created by seed script",
        )
        session.add(revision)

    print(f"  Created {len(system_groups)} system groups")


def seed_organizations(session: Session) -> None:
    """Create organizations if they don't exist."""
    existing = session.execute(
        text("SELECT id FROM organization WHERE id = :id"), {"id": str(ORG1_ID)}
    ).first()
    if existing:
        print("  Organizations already exist, skipping...")
        return

    # Organization 1: Acme Genetics (Clinical lab)
    org1 = Organization(id=ORG1_ID)
    session.add(org1)
    session.flush()

    org1_rev = OrganizationRevision(
        organization_id=ORG1_ID,
        revision_no=1,
        name="acme-genetics",
        display_name="Acme Genetics Laboratory",
        org_type="clinic",
        contact_email="lab@acmegenetics.example.com",
        contact_phone="+1-555-123-4567",
        address={
            "street": "100 Genome Way",
            "city": "San Francisco",
            "state": "CA",
            "zip": "94105",
            "country": "USA",
        },
        is_active=True,
    )
    session.add(org1_rev)

    # Organization 2: Mountain View Hospital
    org2 = Organization(id=ORG2_ID)
    session.add(org2)
    session.flush()

    org2_rev = OrganizationRevision(
        organization_id=ORG2_ID,
        revision_no=1,
        name="mountain-view-hospital",
        display_name="Mountain View Hospital",
        org_type="clinic",
        contact_email="genetics@mvhospital.example.com",
        contact_phone="+1-555-987-6543",
        address={
            "street": "500 Hospital Blvd",
            "city": "Mountain View",
            "state": "CA",
            "zip": "94040",
            "country": "USA",
        },
        is_active=True,
    )
    session.add(org2_rev)
    print("  Created 2 organizations")


def seed_sites(session: Session) -> None:
    """Create sites."""
    existing = session.execute(
        text("SELECT id FROM site WHERE id = :id"), {"id": str(SITE1_ID)}
    ).first()
    if existing:
        print("  Sites already exist, skipping...")
        return

    site1 = Site(id=SITE1_ID, organization_id=ORG1_ID)
    session.add(site1)
    session.flush()
    site1_rev = SiteRevision(
        site_id=SITE1_ID,
        revision_no=1,
        name="Acme Main Lab",
        site_code="ACME-001",
        contact_email="lab@acme.com",
        contact_phone="+1-555-0100",
        is_active=True,
    )
    session.add(site1_rev)

    site2 = Site(id=SITE2_ID, organization_id=ORG2_ID)
    session.add(site2)
    session.flush()
    site2_rev = SiteRevision(
        site_id=SITE2_ID,
        revision_no=1,
        name="MVH Genetics Department",
        site_code="MVH-001",
        contact_email="genetics@mvh.org",
        contact_phone="+1-555-0200",
        is_active=True,
    )
    session.add(site2_rev)
    print("  Created 2 sites")


def seed_clinicians(session: Session) -> None:
    """Create clinicians."""
    existing = session.execute(
        text("SELECT id FROM clinician WHERE id = :id"), {"id": str(CLINICIAN1_ID)}
    ).first()
    if existing:
        print("  Clinicians already exist, skipping...")
        return

    clin1 = Clinician(id=CLINICIAN1_ID, tenant_id=ORG1_ID)
    session.add(clin1)
    session.flush()
    clin1_rev = ClinicianRevision(
        clinician_id=CLINICIAN1_ID,
        revision_no=1,
        first_name="Sarah",
        last_name="Chen",
        credentials="MD, PhD",
        npi="1234567890",
        specialty="Medical Genetics",
        email="s.chen@acmegenetics.example.com",
        phone="+1-555-111-2222",
        site_id=SITE1_ID,
        is_active=True,
    )
    session.add(clin1_rev)

    clin2 = Clinician(id=CLINICIAN2_ID, tenant_id=ORG2_ID)
    session.add(clin2)
    session.flush()
    clin2_rev = ClinicianRevision(
        clinician_id=CLINICIAN2_ID,
        revision_no=1,
        first_name="Michael",
        last_name="Rodriguez",
        credentials="MD",
        npi="0987654321",
        specialty="Oncology",
        email="m.rodriguez@mvhospital.example.com",
        phone="+1-555-333-4444",
        site_id=SITE2_ID,
        is_active=True,
    )
    session.add(clin2_rev)
    print("  Created 2 clinicians")


def seed_patients(session: Session) -> None:
    """Create patients."""
    existing = session.execute(
        text("SELECT id FROM patient WHERE id = :id"), {"id": str(PATIENT1_ID)}
    ).first()
    if existing:
        print("  Patients already exist, skipping...")
        return

    # Patient 1: Org1
    pat1 = Patient(id=PATIENT1_ID, tenant_id=ORG1_ID)
    session.add(pat1)
    session.flush()
    pat1_rev = PatientRevision(
        patient_id=PATIENT1_ID,
        revision_no=1,
        first_name="Emily",
        last_name="Johnson",
        date_of_birth=date(1985, 3, 15),
        sex="F",
        mrn="MRN-ACM-001",
        email="emily.johnson@example.com",
        phone="+1-555-100-1001",
    )
    session.add(pat1_rev)

    # Patient 2: Org1
    pat2 = Patient(id=PATIENT2_ID, tenant_id=ORG1_ID)
    session.add(pat2)
    session.flush()
    pat2_rev = PatientRevision(
        patient_id=PATIENT2_ID,
        revision_no=1,
        first_name="Robert",
        last_name="Smith",
        date_of_birth=date(1972, 8, 22),
        sex="M",
        mrn="MRN-ACM-002",
        email="robert.smith@example.com",
    )
    session.add(pat2_rev)

    # Patient 3: Org2
    pat3 = Patient(id=PATIENT3_ID, tenant_id=ORG2_ID)
    session.add(pat3)
    session.flush()
    pat3_rev = PatientRevision(
        patient_id=PATIENT3_ID,
        revision_no=1,
        first_name="Maria",
        last_name="Garcia",
        date_of_birth=date(1990, 11, 5),
        sex="F",
        mrn="MRN-MVH-001",
    )
    session.add(pat3_rev)
    print("  Created 3 patients")


def seed_orders(session: Session) -> None:
    """Create orders with test orders."""
    existing = session.execute(
        text('SELECT id FROM "order" WHERE id = :id'), {"id": str(ORDER1_ID)}
    ).first()
    if existing:
        print("  Orders already exist, skipping...")
        return

    datetime.now()

    # Order 1: Org1, Patient1 - Submitted order
    ord1 = Order(id=ORDER1_ID, tenant_id=ORG1_ID, order_number="ORD-1")
    session.add(ord1)
    session.flush()
    ord1_rev = OrderRevision(
        order_id=ORDER1_ID,
        revision_no=1,
        patient_id=PATIENT1_ID,
        clinician_id=CLINICIAN1_ID,
        status=OrderStatus.SUBMITTED.value,
        is_stat=False,
        clinical_notes="Family history of breast cancer",
        icd10_codes=["Z80.3"],
    )
    session.add(ord1_rev)

    # TestOrder for Order1
    to1 = TestOrder(id=TEST_ORDER1_ID, tenant_id=ORG1_ID, order_id=ORDER1_ID)
    session.add(to1)
    session.flush()
    to1_rev = TestOrderRevision(
        test_order_id=TEST_ORDER1_ID,
        revision_no=1,
        status=TestOrderStatus.PENDING.value,
        fulfillment_route_codes=["WGS-001"],
        product_code="LSMC-WGS-STANDARD",
    )
    session.add(to1_rev)

    # Order 2: Org1, Patient2 - Active order (in processing)
    ord2 = Order(id=ORDER2_ID, tenant_id=ORG1_ID, order_number="ORD-2")
    session.add(ord2)
    session.flush()
    ord2_rev = OrderRevision(
        order_id=ORDER2_ID,
        revision_no=1,
        patient_id=PATIENT2_ID,
        clinician_id=CLINICIAN1_ID,
        status=OrderStatus.ACTIVE.value,
        is_stat=True,
        clinical_notes="Suspected hereditary cancer syndrome",
    )
    session.add(ord2_rev)

    to2 = TestOrder(id=TEST_ORDER2_ID, tenant_id=ORG1_ID, order_id=ORDER2_ID)
    session.add(to2)
    session.flush()
    to2_rev = TestOrderRevision(
        test_order_id=TEST_ORDER2_ID,
        revision_no=1,
        status=TestOrderStatus.IN_PROGRESS.value,
        fulfillment_route_codes=["WGS-001", "RNA-SEQ-001"],
        product_code="LSMC-HYBRID",
    )
    session.add(to2_rev)

    # Order 3: Org2, Patient3 - Draft order
    ord3 = Order(id=ORDER3_ID, tenant_id=ORG2_ID, order_number="ORD-3")
    session.add(ord3)
    session.flush()
    ord3_rev = OrderRevision(
        order_id=ORDER3_ID,
        revision_no=1,
        patient_id=PATIENT3_ID,
        clinician_id=CLINICIAN2_ID,
        status=OrderStatus.DRAFT.value,
        is_stat=False,
    )
    session.add(ord3_rev)

    to3 = TestOrder(id=TEST_ORDER3_ID, tenant_id=ORG2_ID, order_id=ORDER3_ID)
    session.add(to3)
    session.flush()
    to3_rev = TestOrderRevision(
        test_order_id=TEST_ORDER3_ID,
        revision_no=1,
        status=TestOrderStatus.PENDING.value,
        fulfillment_route_codes=["PANEL-ONCO-50"],
        product_code="LSMC-PANEL-ONCOLOGY",
    )
    session.add(to3_rev)
    print("  Created 3 orders with test orders")


def seed_shipments_and_specimens(session: Session) -> None:
    """Create shipments, test kits, and biospecimens."""
    existing = session.execute(
        text("SELECT id FROM shipment WHERE id = :id"), {"id": str(SHIPMENT1_ID)}
    ).first()
    if existing:
        print("  Shipments already exist, skipping...")
        return

    now = datetime.now()

    # Shipment 1: Org1 - Received
    ship1 = Shipment(id=SHIPMENT1_ID, tenant_id=ORG1_ID, shipment_number="SHP-1")
    session.add(ship1)
    session.flush()
    ship1_rev = ShipmentRevision(
        shipment_id=SHIPMENT1_ID,
        revision_no=1,
        status=ShipmentStatus.RECEIVED.value,
        carrier="FedEx",
        tracking_number="794644790149",
        origin_address={"city": "San Francisco", "state": "CA"},
        destination_address={"city": "Seattle", "state": "WA", "facility": "LSMC Lab"},
        shipped_at=now - timedelta(days=2),
        received_at=now - timedelta(hours=12),
    )
    session.add(ship1_rev)

    # TestKit 1 in Shipment 1
    tk1 = TestKit(id=TESTKIT1_ID, tenant_id=ORG1_ID, kit_barcode="TK-2026-001-A")
    session.add(tk1)
    session.flush()
    tk1_rev = TestKitRevision(
        test_kit_id=TESTKIT1_ID,
        revision_no=1,
        kit_type="WGS_BLOOD",
        status="RECEIVED",
    )
    session.add(tk1_rev)

    # BioSpecimen 1 - Matched to TestOrder1
    spec1 = BioSpecimen(id=SPECIMEN1_ID, tenant_id=ORG1_ID, specimen_barcode="SP-2026-001-A")
    session.add(spec1)
    session.flush()
    spec1_rev = BioSpecimenRevision(
        biospecimen_id=SPECIMEN1_ID,
        revision_no=1,
        specimen_type="BLOOD",
        collection_date=now - timedelta(days=3),
        status=BioSpecimenStatus.MATCHED.value,
        condition="GOOD",
        volume_ml=10.0,
    )
    session.add(spec1_rev)

    # BioSpecimen 2 - Matched to TestOrder2
    spec2 = BioSpecimen(id=SPECIMEN2_ID, tenant_id=ORG1_ID, specimen_barcode="SP-2026-002-A")
    session.add(spec2)
    session.flush()
    spec2_rev = BioSpecimenRevision(
        biospecimen_id=SPECIMEN2_ID,
        revision_no=1,
        specimen_type="SALIVA",
        collection_date=now - timedelta(days=5),
        status=BioSpecimenStatus.ACTIVE.value,
        condition="GOOD",
    )
    session.add(spec2_rev)

    # Containment: TestKit1 in Shipment1
    cont1 = ContainmentEvent(
        tenant_id=ORG1_ID,
        container_type="shipment",
        container_id=SHIPMENT1_ID,
        contained_type="test_kit",
        contained_id=TESTKIT1_ID,
        action=ContainmentAction.ADD.value,
    )
    session.add(cont1)

    # Containment: Specimen1 in TestKit1
    cont2 = ContainmentEvent(
        tenant_id=ORG1_ID,
        container_type="test_kit",
        container_id=TESTKIT1_ID,
        contained_type="biospecimen",
        contained_id=SPECIMEN1_ID,
        action=ContainmentAction.ADD.value,
    )
    session.add(cont2)

    # Link: Specimen1 -> TestOrder1
    link1 = LinkEvent(
        tenant_id=ORG1_ID,
        source_type="biospecimen",
        source_id=SPECIMEN1_ID,
        target_type="test_order",
        target_id=TEST_ORDER1_ID,
        action=LinkAction.LINK.value,
    )
    session.add(link1)

    # Link: Specimen2 -> TestOrder2
    link2 = LinkEvent(
        tenant_id=ORG1_ID,
        source_type="biospecimen",
        source_id=SPECIMEN2_ID,
        target_type="test_order",
        target_id=TEST_ORDER2_ID,
        action=LinkAction.LINK.value,
    )
    session.add(link2)

    # Shipment 2: Org2 - In Transit
    ship2 = Shipment(id=SHIPMENT2_ID, tenant_id=ORG2_ID, shipment_number="SHP-2")
    session.add(ship2)
    session.flush()
    ship2_rev = ShipmentRevision(
        shipment_id=SHIPMENT2_ID,
        revision_no=1,
        status=ShipmentStatus.IN_TRANSIT.value,
        carrier="UPS",
        tracking_number="1Z999AA10123456784",
    )
    session.add(ship2_rev)

    # TestKit 2 in Shipment 2
    tk2 = TestKit(id=TESTKIT2_ID, tenant_id=ORG2_ID, kit_barcode="TK-2026-002-A")
    session.add(tk2)
    session.flush()
    tk2_rev = TestKitRevision(
        test_kit_id=TESTKIT2_ID,
        revision_no=1,
        kit_type="ONCO_PANEL",
        status="SHIPPED",
    )
    session.add(tk2_rev)

    # BioSpecimen 3 - Expected for Org2
    spec3 = BioSpecimen(id=SPECIMEN3_ID, tenant_id=ORG2_ID, specimen_barcode="SP-2026-003-A")
    session.add(spec3)
    session.flush()
    spec3_rev = BioSpecimenRevision(
        biospecimen_id=SPECIMEN3_ID,
        revision_no=1,
        specimen_type="BLOOD",
        status=BioSpecimenStatus.EXPECTED.value,
    )
    session.add(spec3_rev)

    # Containment: TestKit2 in Shipment2
    cont3 = ContainmentEvent(
        tenant_id=ORG2_ID,
        container_type="shipment",
        container_id=SHIPMENT2_ID,
        contained_type="test_kit",
        contained_id=TESTKIT2_ID,
        action=ContainmentAction.ADD.value,
    )
    session.add(cont3)
    print("  Created 2 shipments, 2 test kits, 3 biospecimens")


def seed_release_package(session: Session) -> None:
    """Create a released package with artifacts."""
    existing = session.execute(
        text("SELECT id FROM release_package WHERE id = :id"), {"id": str(RELEASE1_ID)}
    ).first()
    if existing:
        print("  Release packages already exist, skipping...")
        return

    now = datetime.now()

    # Artifact 1: Report PDF
    art1 = Artifact(
        id=ARTIFACT1_ID,
        tenant_id=ORG1_ID,
        source_system="lims-main",
        source_uid="RPT-2026-00001",
        filename="WGS_Report_Johnson_Emily_2026.pdf",
        content_type="application/pdf",
        size_bytes=2_500_000,
        checksum_algorithm="sha256",
        checksum="a" * 64,  # Placeholder
        artifact_type="report_pdf",
        artifact_metadata={"patient_name": "Emily Johnson", "report_type": "WGS Clinical Report"},
    )
    session.add(art1)

    # Artifact 2: VCF file
    art2 = Artifact(
        id=ARTIFACT2_ID,
        tenant_id=ORG1_ID,
        source_system="lims-main",
        source_uid="VCF-2026-00001",
        filename="Johnson_Emily_variants.vcf.gz",
        content_type="application/gzip",
        size_bytes=150_000_000,
        checksum_algorithm="sha256",
        checksum="b" * 64,  # Placeholder
        artifact_type="vcf",
    )
    session.add(art2)

    # Release Package
    rel1 = ReleasePackage(
        id=RELEASE1_ID,
        tenant_id=ORG1_ID,
        package_number="REL-1",
        order_id=ORDER1_ID,
    )
    session.add(rel1)
    session.flush()

    rel1_rev = ReleasePackageRevision(
        release_package_id=RELEASE1_ID,
        revision_no=1,
        status=ReleasePackageStatus.RELEASED.value,
        artifact_ids=[ARTIFACT1_ID, ARTIFACT2_ID],
        released_at=now - timedelta(hours=2),
        release_notes="Initial release - WGS analysis complete",
    )
    session.add(rel1_rev)
    print("  Created 1 release package with 2 artifacts")


def seed_dev_tenant_data(session: Session) -> None:
    """Create sample data for the dev tenant (00000000-0000-0000-0000-000000000001).

    This tenant is used when AUTH_MODE=dev, allowing developers to test without Cognito.
    """
    from app.persistence.tapdb.orm_models.core import Organization, OrganizationRevision

    # Check if dev tenant org exists, create if not
    existing_org = session.execute(
        text("SELECT id FROM organization WHERE id = :id"), {"id": str(DEV_TENANT_ID)}
    ).first()
    if not existing_org:
        org = Organization(id=DEV_TENANT_ID, created_by=DEV_TENANT_ID)
        session.add(org)
        session.flush()
        org_rev = OrganizationRevision(
            organization_id=DEV_TENANT_ID,
            revision_no=1,
            name="dev-tenant",
            display_name="Dev Tenant (Local Development)",
            org_type="clinic",
            is_active=True,
        )
        session.add(org_rev)

    # Check if dev tenant already has orders with test orders
    existing = session.execute(
        text('SELECT id FROM "order" WHERE id = :id'), {"id": str(DEV_ORDER1_ID)}
    ).first()
    if existing:
        print("  Dev tenant data already exists, skipping...")
        return

    now = datetime.now(UTC)

    # Patient for dev tenant
    pat = Patient(id=DEV_PATIENT_ID, tenant_id=DEV_TENANT_ID)
    session.add(pat)
    session.flush()
    pat_rev = PatientRevision(
        patient_id=DEV_PATIENT_ID,
        revision_no=1,
        first_name="Test",
        last_name="Patient",
        date_of_birth=date(1985, 6, 15),
        sex="M",
        mrn="DEV-001",
    )
    session.add(pat_rev)

    # Clinician for dev tenant
    clin = Clinician(id=DEV_CLINICIAN_ID, tenant_id=DEV_TENANT_ID)
    session.add(clin)
    session.flush()
    clin_rev = ClinicianRevision(
        clinician_id=DEV_CLINICIAN_ID,
        revision_no=1,
        first_name="Dev",
        last_name="Clinician",
        npi="1234567890",
        email="dev.clinician@example.com",
        credentials="MD",
        is_active=True,
    )
    session.add(clin_rev)

    # Order 1 with TestOrder (SUBMITTED status)
    ord1 = Order(id=DEV_ORDER1_ID, tenant_id=DEV_TENANT_ID, order_number="ORD-4")
    session.add(ord1)
    session.flush()
    ord1_rev = OrderRevision(
        order_id=DEV_ORDER1_ID,
        revision_no=1,
        patient_id=DEV_PATIENT_ID,
        clinician_id=DEV_CLINICIAN_ID,
        order_type=OrderType.CLINICAL.value,
        status=OrderStatus.SUBMITTED.value,
        is_stat=False,
        clinical_notes="Dev test order for whole genome sequencing",
    )
    session.add(ord1_rev)

    to1 = TestOrder(id=DEV_TEST_ORDER1_ID, tenant_id=DEV_TENANT_ID, order_id=DEV_ORDER1_ID)
    session.add(to1)
    session.flush()
    to1_rev = TestOrderRevision(
        test_order_id=DEV_TEST_ORDER1_ID,
        revision_no=1,
        status=TestOrderStatus.PENDING.value,
        fulfillment_route_codes=["WGS-001"],
        product_code="LSMC-WGS-STANDARD",
    )
    session.add(to1_rev)

    # Order 2 with TestOrder (IN_PROGRESS status)
    ord2 = Order(id=DEV_ORDER2_ID, tenant_id=DEV_TENANT_ID, order_number="ORD-5")
    session.add(ord2)
    session.flush()
    ord2_rev = OrderRevision(
        order_id=DEV_ORDER2_ID,
        revision_no=1,
        patient_id=DEV_PATIENT_ID,
        clinician_id=DEV_CLINICIAN_ID,
        order_type=OrderType.CLINICAL.value,
        status=OrderStatus.ACTIVE.value,
        is_stat=True,
        clinical_notes="STAT hybrid sequencing order",
    )
    session.add(ord2_rev)

    to2 = TestOrder(id=DEV_TEST_ORDER2_ID, tenant_id=DEV_TENANT_ID, order_id=DEV_ORDER2_ID)
    session.add(to2)
    session.flush()
    to2_rev = TestOrderRevision(
        test_order_id=DEV_TEST_ORDER2_ID,
        revision_no=1,
        status=TestOrderStatus.IN_PROGRESS.value,
        fulfillment_route_codes=["WGS-001", "RNA-SEQ-001"],
        product_code="LSMC-HYBRID",
    )
    session.add(to2_rev)

    # Shipment for dev tenant
    ship = Shipment(id=DEV_SHIPMENT_ID, tenant_id=DEV_TENANT_ID, shipment_number="SHP-3")
    session.add(ship)
    session.flush()
    ship_rev = ShipmentRevision(
        shipment_id=DEV_SHIPMENT_ID,
        revision_no=1,
        status=ShipmentStatus.RECEIVED.value,
        carrier="FedEx",
        tracking_number="DEV123456789",
        shipped_at=now - timedelta(days=2),
        delivered_at=now - timedelta(days=1),
        received_at=now - timedelta(hours=12),
    )
    session.add(ship_rev)

    # TestKit for dev tenant
    tk = TestKit(id=DEV_TESTKIT_ID, tenant_id=DEV_TENANT_ID, kit_barcode="TK-DEV-001")
    session.add(tk)
    session.flush()
    tk_rev = TestKitRevision(
        test_kit_id=DEV_TESTKIT_ID,
        revision_no=1,
        kit_type="WGS_BLOOD",
        status="RECEIVED",
    )
    session.add(tk_rev)

    # BioSpecimen for dev tenant
    spec = BioSpecimen(id=DEV_SPECIMEN_ID, tenant_id=DEV_TENANT_ID, specimen_barcode="SP-DEV-001")
    session.add(spec)
    session.flush()
    spec_rev = BioSpecimenRevision(
        biospecimen_id=DEV_SPECIMEN_ID,
        revision_no=1,
        specimen_type="WHOLE_BLOOD",
        status=BioSpecimenStatus.MATCHED.value,
        condition="GOOD",
        volume_ml=10.0,
    )
    session.add(spec_rev)

    # Containment: TestKit in Shipment
    cont1 = ContainmentEvent(
        tenant_id=DEV_TENANT_ID,
        container_type="shipment",
        container_id=DEV_SHIPMENT_ID,
        contained_type="testkit",
        contained_id=DEV_TESTKIT_ID,
        action=ContainmentAction.ADD.value,
    )
    session.add(cont1)

    # Containment: Specimen in TestKit
    cont2 = ContainmentEvent(
        tenant_id=DEV_TENANT_ID,
        container_type="testkit",
        container_id=DEV_TESTKIT_ID,
        contained_type="biospecimen",
        contained_id=DEV_SPECIMEN_ID,
        action=ContainmentAction.ADD.value,
    )
    session.add(cont2)

    # Link: Specimen -> TestOrder1
    link1 = LinkEvent(
        tenant_id=DEV_TENANT_ID,
        source_type="biospecimen",
        source_id=DEV_SPECIMEN_ID,
        target_type="test_order",
        target_id=DEV_TEST_ORDER1_ID,
        action=LinkAction.LINK.value,
    )
    session.add(link1)

    print("  Created dev tenant sample data (1 patient, 1 clinician, 2 orders, 1 shipment)")


def main():
    """Main entry point."""
    print("\n" + "=" * 60)
    print("LSMC Atlas - Seeding Development Data")
    print("=" * 60 + "\n")

    db_url = str(settings.database_url)
    print(f"Database: {db_url.split('@')[-1] if '@' in db_url else db_url}")

    engine = create_engine(db_url)

    with Session(engine) as session:
        try:
            print("\nCreating seed data...")
            seed_system_groups(session)
            seed_organizations(session)
            seed_sites(session)
            seed_clinicians(session)
            seed_patients(session)
            seed_orders(session)
            seed_shipments_and_specimens(session)
            seed_release_package(session)
            seed_dev_tenant_data(session)

            session.commit()
            print("\n✅ Seed data created successfully!")

        except Exception as e:
            session.rollback()
            print(f"\n❌ Error: {e}")
            raise

    print("\n" + "=" * 60)
    print("Summary:")
    print("  - 4 System Groups (CUSTOMER, LSMC_STAFF, ADMIN, API_ACCESS)")
    print("  - 3 Organizations (Acme Genetics, Mountain View Hospital, Dev Tenant)")
    print("  - 2 Sites")
    print("  - 3 Clinicians")
    print("  - 4 Patients")
    print("  - 5 Orders with TestOrders")
    print("  - 3 Shipments with TestKits")
    print("  - 4 BioSpecimens")
    print("  - 1 Released Package with 2 Artifacts")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
