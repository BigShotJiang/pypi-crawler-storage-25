#!/usr/bin/env python3
"""Get a session cookie by authenticating with Cognito and completing OAuth flow."""

import base64
import hashlib
import hmac
import os
import re
import sys

import boto3
import httpx

# Cognito config – read from environment variables; never hard-code secrets.
COGNITO_REGION = os.environ.get("COGNITO_REGION", "us-west-2")
COGNITO_CLIENT_ID = os.environ["COGNITO_CLIENT_ID"]
COGNITO_CLIENT_SECRET = os.environ["COGNITO_CLIENT_SECRET"]
COGNITO_DOMAIN = os.environ["COGNITO_DOMAIN"]
EMAIL = os.environ["COGNITO_EMAIL"]
PASSWORD = os.environ["COGNITO_PASSWORD"]
BASE_URL = os.environ.get("ATLAS_BASE_URL", "http://localhost:8915")
REDIRECT_URI = os.environ.get("ATLAS_REDIRECT_URI", f"{BASE_URL}/auth/callback")


def get_secret_hash(username: str) -> str:
    message = username + COGNITO_CLIENT_ID
    secret = COGNITO_CLIENT_SECRET.encode("utf-8")
    dig = hmac.new(secret, message.encode("utf-8"), hashlib.sha256).digest()
    return base64.b64encode(dig).decode()


def main():
    print("Step 1: Get OAuth state from Atlas login endpoint...")

    # Create client that follows redirects but captures cookies
    with httpx.Client(follow_redirects=False, timeout=30) as client:
        # Hit the login endpoint to get the OAuth state
        resp = client.get(f"{BASE_URL}/auth/login")
        if resp.status_code != 302:
            print(f"Expected redirect, got {resp.status_code}")
            sys.exit(1)

        # Get the session cookie that contains the OAuth state
        session_cookie = resp.cookies.get("lsmc_session")
        if not session_cookie:
            print("No session cookie received")
            sys.exit(1)

        # Extract state from redirect URL
        location = resp.headers.get("location", "")
        state_match = re.search(r"state=([^&]+)", location)
        if not state_match:
            print(f"No state in redirect URL: {location}")
            sys.exit(1)
        state = state_match.group(1)
        print(f"  Got OAuth state: {state[:20]}...")

        print("\nStep 2: Authenticate with Cognito...")
        cognito = boto3.client("cognito-idp", region_name=COGNITO_REGION)

        try:
            auth_resp = cognito.initiate_auth(
                ClientId=COGNITO_CLIENT_ID,
                AuthFlow="USER_PASSWORD_AUTH",
                AuthParameters={
                    "USERNAME": EMAIL,
                    "PASSWORD": PASSWORD,
                    "SECRET_HASH": get_secret_hash(EMAIL),
                },
            )
            _tokens = auth_resp["AuthenticationResult"]  # noqa: F841
            print(f"  Authenticated as {EMAIL}")
        except Exception as e:
            print(f"  Cognito auth failed: {e}")
            sys.exit(1)

        print("\nStep 3: Exchange tokens for authorization code...")
        # Use Cognito's /oauth2/authorize endpoint with the tokens
        # Actually, we need to use the hosted UI flow which requires browser interaction
        # OR we can try to call the callback directly with a code

        # The problem is: Cognito's USER_PASSWORD_AUTH gives us tokens directly,
        # but the app expects an authorization code to exchange for tokens.
        # We can't easily get an auth code without browser interaction.

        print("  Note: Direct token-to-session exchange not supported.")
        print("  The app requires browser-based OAuth flow.")
        print("  Use a browser to complete Cognito login at /auth/login.")


if __name__ == "__main__":
    main()
