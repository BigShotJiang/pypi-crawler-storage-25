"""Seed minimal Atlas TapDB overlay data.

This script is intentionally TapDB-only and does not rely on legacy ORM tables.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import uuid

from app.db.engine import SessionLocal
from app.domain.enums import AccessScope
from app.domain.services.groups import GroupCreate, UserGroupService
from app.domain.services.orgs import (
    OrganizationCreate,
    OrganizationService,
    SiteCreate,
    SiteService,
)
from app.integrations.tapdb_template_seed import seed_atlas_templates


def _bootstrap_seed_path() -> Path:
    return Path(__file__).resolve().parents[1] / "config" / "bootstrap_seed.json"


def _load_bootstrap_seed() -> dict:
    return json.loads(_bootstrap_seed_path().read_text(encoding="utf-8"))


def _parse_optional_uuid(value: object) -> uuid.UUID | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    return uuid.UUID(raw)


def _existing_orgs_by_name(org_svc: OrganizationService) -> dict[str, tuple[object, object]]:
    existing: dict[str, tuple[object, object]] = {}
    for org in org_svc.list_all(active_only=False):
        resolved = org_svc.get_with_revision(org.euid)
        if resolved is None:
            continue
        org_record, revision = resolved
        existing[str(revision.name)] = (org_record, revision)
    return existing


def _resolve_requested_org_uid(
    item: dict,
    *,
    tenant_uuid: uuid.UUID | None,
    organization_count: int,
) -> uuid.UUID | None:
    item_uid = _parse_optional_uuid(item.get("uid"))
    if item_uid and tenant_uuid and item_uid != tenant_uuid:
        raise RuntimeError(
            "Bootstrap seed org uid does not match --tenant-uuid for organization "
            f"{item.get('name')!r}"
        )
    if item_uid:
        return item_uid
    if tenant_uuid is None:
        return None
    if organization_count != 1:
        raise RuntimeError(
            "--tenant-uuid requires exactly one bootstrap organization unless each organization "
            "defines its own uid"
        )
    return tenant_uuid


def _ensure_orgs(db, payload: dict, *, tenant_uuid: uuid.UUID | None = None) -> list:
    org_svc = OrganizationService(db)
    site_svc = SiteService(db)
    existing = _existing_orgs_by_name(org_svc)
    ensured = []
    organizations = list(payload.get("organizations", []))

    for item in organizations:
        name = str(item.get("name") or "").strip()
        display_name = str(item.get("display_name") or name).strip()
        org_type = str(item.get("org_type") or "clinic").strip() or "clinic"
        initial_site = dict(item.get("initial_site") or {})
        site_name = str(initial_site.get("name") or "Default Site").strip()
        site_code = str(initial_site.get("site_code") or "DEFAULT").strip()
        requested_uid = _resolve_requested_org_uid(
            item,
            tenant_uuid=tenant_uuid,
            organization_count=len(organizations),
        )
        existing_entry = existing.get(name)
        if existing_entry is None:
            org = org_svc.create(
                OrganizationCreate(
                    name=name,
                    uid=requested_uid,
                    display_name=display_name,
                    org_type=org_type,
                    initial_site_name=site_name,
                    initial_site_code=site_code,
                ),
                created_by=None,
            )
            resolved = org_svc.get_with_revision(org.euid)
            if resolved is not None:
                existing[name] = resolved
        else:
            org, _revision = existing_entry
            if requested_uid is not None:
                existing_uid = getattr(org, "uid", None)
                if existing_uid is None:
                    raise RuntimeError(f"Existing organization {name!r} does not expose a tenant UUID")
                if existing_uid != requested_uid:
                    raise RuntimeError(
                        f"Bootstrap organization {name!r} already exists with tenant UUID "
                        f"{existing_uid}, not requested {requested_uid}"
                    )
            sites = site_svc.list_by_organization(org.euid, active_only=False)
            if not any(
                str((site.revisions[-1].site_code if getattr(site, "revisions", None) else "") or "").strip()
                == site_code
                for site in sites
            ):
                site_svc.create(
                    SiteCreate(
                        organization_id=org.euid,
                        name=site_name,
                        site_code=site_code,
                    ),
                    created_by=None,
                )
        ensured.append(org)

    return ensured


def _ensure_system_groups(db, tenant_id, payload: dict):
    svc = UserGroupService(db, tenant_id)
    for item in payload.get("system_groups", []):
        group_code = str(item.get("group_code") or "").strip()
        existing = svc.get_group_by_code(group_code)
        if existing is not None:
            continue
        svc.create_group(
            GroupCreate(
                group_code=group_code,
                name=str(item.get("name") or group_code.replace("_", " ").title()),
                description=str(item.get("description") or f"System group {group_code}"),
                access_scope=AccessScope(str(item.get("access_scope") or "TENANT")),
                default_roles=None,
            ),
            created_by=None,
        )


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--tenant-uuid",
        help="Explicit tenant UUID for the bootstrap Atlas organization.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    tenant_uuid = _parse_optional_uuid(args.tenant_uuid) if args.tenant_uuid else None
    session = SessionLocal()
    try:
        seed = _load_bootstrap_seed()
        seed_atlas_templates(session)
        orgs = _ensure_orgs(session, seed, tenant_uuid=tenant_uuid)
        for org in orgs:
            _ensure_system_groups(session, org.uid, seed)
        session.commit()
        print("TapDB seed overlay complete.")
        return 0
    except Exception as exc:  # pragma: no cover
        session.rollback()
        print(f"TapDB seed overlay failed: {exc}")
        return 1
    finally:
        session.close()


if __name__ == "__main__":
    raise SystemExit(main())
