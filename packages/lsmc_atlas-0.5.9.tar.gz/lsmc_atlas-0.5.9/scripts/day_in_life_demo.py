#!/usr/bin/env python3
"""Run the concrete local "Day In The Life" demo workflow."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create one deterministic Atlas + Bloom day-in-the-life demo run.",
    )
    parser.add_argument("--demo-key", required=True, help="Stable key used for deterministic names")
    parser.add_argument(
        "--actor-email",
        default="john@daylilyinformatics.com",
        help="Atlas/Bloom actor email",
    )
    parser.add_argument("--patient-euid", default="PAT-1T", help="Atlas patient EUID")
    parser.add_argument("--clinician-euid", default="CNP-1H", help="Atlas clinician EUID")
    parser.add_argument("--site-euid", default="STX-1K", help="Atlas site EUID")
    parser.add_argument(
        "--assay-route-code",
        default="WGS-short-read",
        help="Atlas test-definition code",
    )
    parser.add_argument(
        "--assay-name",
        default="ILMN short read",
        help="Atlas test-definition display name",
    )
    parser.add_argument(
        "--extraction-well",
        default="A1",
        help="Destination extraction well on the 96-well plate",
    )
    parser.add_argument(
        "--atlas-base-url",
        default="https://localhost:8915",
        help="Atlas GUI base URL for preflight and live graph links",
    )
    parser.add_argument(
        "--graph-depth",
        default=8,
        type=int,
        help="Atlas/Bloom graph depth for the exported DAG",
    )
    parser.add_argument(
        "--output-root",
        default=None,
        help="Optional override for artifact output root",
    )
    parser.add_argument(
        "--no-screenshot",
        action="store_true",
        help="Skip Playwright screenshot generation",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print the final manifest as JSON in addition to the summary",
    )
    return parser


def main() -> int:
    repo_root = Path(__file__).resolve().parents[1]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

    from app.db.engine import SessionLocal
    from app.domain.services.day_in_life_demo import (
        DayInLifeDemoConfig,
        DayInLifeDemoError,
        DayInLifeDemoRunner,
    )

    parser = build_parser()
    args = parser.parse_args()
    default_output_root = DayInLifeDemoConfig(demo_key=args.demo_key).output_root

    config = DayInLifeDemoConfig(
        demo_key=args.demo_key,
        actor_email=args.actor_email,
        patient_euid=args.patient_euid,
        clinician_euid=args.clinician_euid,
        site_euid=args.site_euid,
        assay_route_code=args.assay_route_code,
        assay_name=args.assay_name,
        extraction_well=args.extraction_well,
        render_screenshot=not args.no_screenshot,
        atlas_base_url=args.atlas_base_url,
        output_root=Path(args.output_root) if args.output_root else default_output_root,
    )

    db = SessionLocal()
    try:
        runner = DayInLifeDemoRunner(
            db,
            atlas_base_url=args.atlas_base_url,
            graph_depth=args.graph_depth,
        )
        result = runner.run(config)
    except DayInLifeDemoError as exc:
        rollback = getattr(db, "rollback", None)
        if callable(rollback):
            rollback()
        print(f"Day In The Life demo failed: {exc}", file=sys.stderr)
        return 1
    finally:
        db.close()

    manifest = result.manifest
    atlas = manifest.get("atlas") or {}
    bloom = manifest.get("bloom") or {}
    artifacts = manifest.get("artifacts") or {}

    print(f"Demo key: {manifest.get('demo_key')}")
    print(
        f"TRF/Test: {((atlas.get('trf') or {}).get('euid') or '?')} / "
        f"{((atlas.get('test') or {}).get('euid') or '?')}"
    )
    print(
        f"Shipment/Kit: {((atlas.get('shipment') or {}).get('euid') or '?')} / "
        f"{((atlas.get('testkit') or {}).get('euid') or '?')}"
    )
    print(
        f"Tube/Specimen: {bloom.get('container_euid') or '?'} / {bloom.get('specimen_euid') or '?'}"
    )
    print(f"Run: {bloom.get('run_euid') or '?'} (flowcell={bloom.get('flowcell_id') or '?'})")
    print(f"Manifest: {artifacts.get('manifest_path') or result.artifacts.manifest_path}")
    print(
        f"Graph JSON: {artifacts.get('graph_elements_path') or result.artifacts.graph_elements_path}"
    )
    print(f"DAG HTML: {artifacts.get('dag_html_path') or result.artifacts.html_path}")
    print(f"DAG PNG: {artifacts.get('dag_png_path') or result.artifacts.png_path}")
    print(f"Live graph URL: {artifacts.get('live_graph_url') or ''}")

    if args.json:
        print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
