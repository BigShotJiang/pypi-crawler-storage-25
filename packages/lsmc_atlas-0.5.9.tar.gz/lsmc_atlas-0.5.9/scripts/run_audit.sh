#!/bin/bash
source ./activate
python scripts/audit_test_coverage.py
