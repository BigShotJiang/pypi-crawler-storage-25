from __future__ import annotations

import uuid

import pytest

from app.domain.services.external_objects import (
    OrgBloomConfigService,
    OrgBloomConfigUpsert,
    SiteBloomConfigService,
    SiteBloomConfigUpsert,
)
from app.settings import Settings


def test_settings_reject_non_https_bloom_base_url():
    with pytest.raises(ValueError, match="absolute https:// URL"):
        Settings(bloom_base_url="http://bloom.local")


def test_org_bloom_config_service_rejects_non_https_url():
    service = OrgBloomConfigService(db=None)

    with pytest.raises(ValueError, match="absolute https:// URL"):
        service.upsert(
            organization_id=str(uuid.uuid4()),
            data=OrgBloomConfigUpsert(
                enabled=True,
                bloom_base_url="http://bloom.local",
                bloom_api_key_secret_ref="env:BLOOM_KEY",
            ),
        )


def test_site_bloom_config_service_rejects_non_https_url():
    service = SiteBloomConfigService(db=None)

    with pytest.raises(ValueError, match="absolute https:// URL"):
        service.upsert(
            site_id="SITE-1",
            organization_id=uuid.uuid4(),
            data=SiteBloomConfigUpsert(
                enabled=True,
                bloom_base_url="http://bloom.local",
                bloom_api_key_secret_ref="env:BLOOM_KEY",
            ),
        )
