"""Integration tests for assay workflow API routes."""

from __future__ import annotations

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.domain.enums import FulfillmentRunState, OrderPatientRole
from app.domain.services.fulfillment_runs import (
    FulfillmentRunService,
    ResultsSetService,
    TransitionData,
)
from app.domain.services.order_relationships import OrderPatientLink
from app.domain.services.people import PatientCreate, PatientService
from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.fixture
def setup_order_with_assay_runs(db_session: Session, tenant_id: str):
    """Create order/test-order/assay-runs fixture using TapDB services."""
    tid = uuid.UUID(tenant_id)
    ensure_tapdb_org(db_session, tid)

    patient, _ = PatientService(db_session, tid).create(
        PatientCreate(first_name="API", last_name="TestPatient"),
        created_by=uuid.uuid4(),
    )
    order, _ = TrfService(db_session, tid).create(
        data=TrfCreate(order_type="CLINICAL"),
        tests=[
            TestCreate(
                product_code="WGS-001",
                fulfillment_route_codes=["WGS", "CNV"],
                specimen_type_required="blood-whole",
            )
        ],
        patient_links=[OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)],
        created_by=uuid.uuid4(),
    )

    test_order_rows = TestService(db_session, tid).list_for_trf(order.euid)
    assert test_order_rows
    test_order, _, _ = test_order_rows[0]

    assay_svc = FulfillmentRunService(db_session, tid)
    assay_runs = [ar for ar, _ in assay_svc.list_for_trf(order.euid)]
    assert len(assay_runs) == 2
    for ar in assay_runs:
        assay_svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.ORDERED, note="fixture setup"),
            transition_by=None,
        )

    return {"order": order, "test_order": test_order, "assay_runs": assay_runs, "tenant_id": tid}


@pytest.mark.db
class TestAssayRunsAPI:
    def test_list_assay_runs_by_order(
        self, internal_client: TestClient, setup_order_with_assay_runs
    ):
        data = setup_order_with_assay_runs
        response = internal_client.get(f"/api/fulfillment-runs?trf_euid={data['order'].euid}")
        assert response.status_code == status.HTTP_200_OK
        runs = response.json()
        assert len(runs) == 2
        fulfillment_route_codes = {r["fulfillment_route_code"] for r in runs}
        assert fulfillment_route_codes == {"WGS", "CNV"}

    def test_get_single_assay_run(self, internal_client: TestClient, setup_order_with_assay_runs):
        data = setup_order_with_assay_runs
        ar_id = str(data["assay_runs"][0].euid)
        response = internal_client.get(f"/api/fulfillment-runs/{ar_id}")
        assert response.status_code == status.HTTP_200_OK
        run = response.json()
        assert run["euid"] == ar_id
        assert run["status"] == "ORDERED"
        assert "next_valid_transitions" in run
        assert "RECEIVED" in run["next_valid_transitions"]
        assert "CANCELLED" in run["next_valid_transitions"]

    def test_transition_assay_run(self, internal_client: TestClient, setup_order_with_assay_runs):
        data = setup_order_with_assay_runs
        ar_id = str(data["assay_runs"][0].euid)
        response = internal_client.post(
            f"/api/fulfillment-runs/{ar_id}/transition",
            json={"next_state": "RECEIVED", "note": "Specimen received at lab"},
        )
        assert response.status_code == status.HTTP_200_OK
        assert response.json()["status"] == "RECEIVED"

    def test_transition_invalid_state_rejected(
        self, internal_client: TestClient, setup_order_with_assay_runs
    ):
        data = setup_order_with_assay_runs
        ar_id = str(data["assay_runs"][0].euid)
        response = internal_client.post(
            f"/api/fulfillment-runs/{ar_id}/transition",
            json={"next_state": "RESULTED"},
        )
        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_transition_idempotent(self, internal_client: TestClient, setup_order_with_assay_runs):
        data = setup_order_with_assay_runs
        ar_id = str(data["assay_runs"][0].euid)
        response1 = internal_client.post(
            f"/api/fulfillment-runs/{ar_id}/transition",
            json={"next_state": "RECEIVED"},
        )
        assert response1.status_code == status.HTTP_200_OK
        rev1 = response1.json()["revision_no"]

        response2 = internal_client.post(
            f"/api/fulfillment-runs/{ar_id}/transition",
            json={"next_state": "RECEIVED"},
        )
        assert response2.status_code == status.HTTP_200_OK
        rev2 = response2.json()["revision_no"]
        assert rev1 == rev2


@pytest.mark.db
class TestResultsAPI:
    def test_create_result(
        self, internal_client: TestClient, setup_order_with_assay_runs, db_session: Session
    ):
        data = setup_order_with_assay_runs
        ar = data["assay_runs"][0]
        svc = FulfillmentRunService(db_session, data["tenant_id"])
        svc.transition(
            ar.euid, TransitionData(target_state=FulfillmentRunState.RECEIVED), transition_by=None
        )
        svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.ACCESSIONED),
            transition_by=None,
        )
        svc.transition(
            ar.euid,
            TransitionData(target_state=FulfillmentRunState.IN_PROGRESS),
            transition_by=None,
        )

        response = internal_client.post(
            f"/api/fulfillment-runs/{ar.euid}/result",
            json={
                "result_payload": {"variants": [{"gene": "BRCA1"}]},
                "artifact_ids": [],
            },
        )
        assert response.status_code == status.HTTP_200_OK
        result = response.json()
        assert result["version_no"] == 1
        assert "variants" in result["result_payload"]


@pytest.mark.db
class TestResultsSetsAPI:
    def test_list_results_sets(
        self, internal_client: TestClient, setup_order_with_assay_runs, db_session: Session
    ):
        data = setup_order_with_assay_runs
        order = data["order"]
        test_order = data["test_order"]
        tid = data["tenant_id"]
        ResultsSetService(db_session, tid).get_or_create_for_test(test_order.euid, created_by=None)

        response = internal_client.get(
            f"/api/results-sets?trf_euid={order.euid}&include_unpublished=true"
        )
        assert response.status_code == status.HTTP_200_OK
        sets = response.json()
        assert len(sets) == 1
        assert sets[0]["trf_euid"] == str(order.euid)
        assert sets[0]["test_euid"] == str(test_order.euid)

    def test_get_results_set(
        self, internal_client: TestClient, setup_order_with_assay_runs, db_session: Session
    ):
        data = setup_order_with_assay_runs
        test_order = data["test_order"]
        tid = data["tenant_id"]
        rs = ResultsSetService(db_session, tid).get_or_create_for_test(
            test_order.euid, created_by=None
        )

        response = internal_client.get(f"/api/results-sets/{rs.euid}")
        assert response.status_code == status.HTTP_200_OK
        result = response.json()
        assert result["euid"] == str(rs.euid)
        assert result["test_euid"] == str(test_order.euid)
        assert result["published_at"] is None

    def test_publish_results_set(
        self, internal_client: TestClient, setup_order_with_assay_runs, db_session: Session
    ):
        data = setup_order_with_assay_runs
        test_order = data["test_order"]
        tid = data["tenant_id"]
        rs = ResultsSetService(db_session, tid).get_or_create_for_test(
            test_order.euid, created_by=None
        )

        response = internal_client.post(f"/api/results-sets/{rs.euid}/publish", json={})
        assert response.status_code == status.HTTP_200_OK
        assert response.json()["published_at"] is not None

    def test_publish_idempotent(
        self, internal_client: TestClient, setup_order_with_assay_runs, db_session: Session
    ):
        data = setup_order_with_assay_runs
        test_order = data["test_order"]
        tid = data["tenant_id"]
        rs = ResultsSetService(db_session, tid).get_or_create_for_test(
            test_order.euid, created_by=None
        )

        response1 = internal_client.post(f"/api/results-sets/{rs.euid}/publish", json={})
        assert response1.status_code == status.HTTP_200_OK
        published_at1 = response1.json()["published_at"]

        response2 = internal_client.post(f"/api/results-sets/{rs.euid}/publish", json={})
        assert response2.status_code == status.HTTP_200_OK
        published_at2 = response2.json()["published_at"]
        assert published_at1 == published_at2


@pytest.mark.db
class TestExternalUserVisibility:
    def test_external_cannot_list_assay_runs(self, client: TestClient, setup_order_with_assay_runs):
        data = setup_order_with_assay_runs
        response = client.get(f"/api/fulfillment-runs?trf_euid={data['order'].euid}")
        assert response.status_code in [status.HTTP_403_FORBIDDEN, status.HTTP_401_UNAUTHORIZED]

    def test_external_cannot_access_unpublished_results_set(
        self, client: TestClient, setup_order_with_assay_runs, db_session: Session
    ):
        data = setup_order_with_assay_runs
        test_order = data["test_order"]
        tid = data["tenant_id"]
        rs = ResultsSetService(db_session, tid).get_or_create_for_test(
            test_order.euid, created_by=None
        )

        response = client.get(f"/api/results-sets/{rs.euid}")
        assert response.status_code in [
            status.HTTP_403_FORBIDDEN,
            status.HTTP_401_UNAUTHORIZED,
            status.HTTP_404_NOT_FOUND,
        ]
