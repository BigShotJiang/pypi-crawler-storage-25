from __future__ import annotations
from types import SimpleNamespace

from fastapi.responses import RedirectResponse
from starlette.requests import Request
from starlette.testclient import TestClient

import app.settings as settings_mod
from app.main import app
from app.web.routes.pages import get_template_context
from app.web.templates import templates


def _build_request(path: str = "/") -> Request:
    scope = {
        "type": "http",
        "method": "GET",
        "path": path,
        "headers": [],
        "query_string": b"",
        "scheme": "https",
        "server": ("testserver", 443),
        "client": ("testclient", 50000),
        "root_path": "",
        "session": {},
    }
    return Request(scope)


def test_get_settings_reads_cognito_from_yaml_not_env(tmp_path, monkeypatch) -> None:
    config_dir = tmp_path / "lsmc-atlas"
    config_dir.mkdir(parents=True)
    config_path = config_dir / "config.yaml"
    config_path.write_text(
        """
authentication:
  mode: "cognito"
  cognito:
    region: "us-east-1"
    user_pool_id: "yaml-pool"
    app_client_id: "yaml-client"
    client_name: "atlas"
    domain: "yaml.auth.us-east-1.amazoncognito.com"
    redirect_uri: "https://atlas.example.com/auth/callback"
    logout_url: "https://atlas.example.com/"
deployment:
  name: "staging"
  color: "#123456"
  is_production: false
""",
        encoding="utf-8",
    )

    monkeypatch.setattr(settings_mod, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(settings_mod, "CONFIG_FILE", config_path)
    monkeypatch.setenv("COGNITO_USER_POOL_ID", "env-pool")
    monkeypatch.setenv("COGNITO_APP_CLIENT_ID", "env-client")
    monkeypatch.setenv("COGNITO_DOMAIN", "env.auth.us-east-1.amazoncognito.com")
    settings_mod.get_settings.cache_clear()
    try:
        loaded = settings_mod.get_settings()
    finally:
        settings_mod.get_settings.cache_clear()

    assert loaded.cognito_user_pool_id == "yaml-pool"
    assert loaded.cognito_app_client_id == "yaml-client"
    assert loaded.cognito_domain == "yaml.auth.us-east-1.amazoncognito.com"
    assert loaded.deployment_name == "staging"
    assert loaded.deployment_color == "#123456"
    assert loaded.deployment_is_production is False


def test_template_context_and_base_template_include_deployment_banner(monkeypatch) -> None:
    monkeypatch.setattr(settings_mod.settings, "deployment_name", "staging", raising=False)
    monkeypatch.setattr(settings_mod.settings, "deployment_color", "#123456", raising=False)
    monkeypatch.setattr(settings_mod.settings, "deployment_is_production", False, raising=False)

    request = _build_request("/")
    context = get_template_context(request)
    rendered = templates.env.get_template("base.html").render(**context)

    assert context["deployment"]["name"] == "staging"
    assert "STAGING" in rendered
    assert "#123456" in rendered
    assert "/static/favicon.ico" in rendered
    assert "/static/favicon.png" in rendered
    assert 'href="/login"' in rendered


def test_favicon_route_redirects_to_ico() -> None:
    with TestClient(app) as client:
        response = client.get("/favicon.ico", follow_redirects=False)
    assert response.status_code in (307, 308)
    assert response.headers["location"] == "/static/favicon.ico"


def test_dashboard_template_includes_brand_hero() -> None:
    request = _build_request("/")
    context = get_template_context(request)
    context.update(
        {
            "user": SimpleNamespace(
                email="dashboard@lsmc.bio",
                name="Dashboard User",
                roles=["EXTERNAL_USER"],
                is_internal=False,
                is_admin=False,
                can_write=True,
            ),
            "stats": {
                "orders_total": 12,
                "orders_active": 4,
                "shipments_in_transit": 2,
                "results_ready": 3,
            },
            "recent_orders": [],
            "pending_exceptions": [],
            "show_api_docs": False,
        }
    )

    rendered = templates.env.get_template("dashboard.html").render(**context)
    assert "brand-hero dashboard-hero" in rendered
    assert "Clinical sequencing portal" in rendered


def test_support_templates_include_brand_mark() -> None:
    request = _build_request("/support")
    base_context = get_template_context(request)
    base_context["user"] = SimpleNamespace(
        email="support@lsmc.bio",
        name="Support User",
        roles=["EXTERNAL_USER"],
        is_internal=False,
        is_admin=False,
        can_write=True,
    )

    list_context = {
        **base_context,
        "tickets": [],
        "status_filter": None,
        "type_filter": None,
    }
    list_rendered = templates.env.get_template("support/list.html").render(**list_context)
    assert "Need help with a TRF, specimen, or result?" in list_rendered
    assert "brand-mark" in list_rendered

    create_context = {
        **base_context,
        "site_options": [],
        "selected_site_id": None,
        "prefill_subject": None,
        "prefill_description": None,
        "prefill_ticket_type": None,
        "prefill_priority": None,
        "prefill_trace_id": None,
        "error": None,
    }
    create_rendered = templates.env.get_template("support/create.html").render(**create_context)
    assert "Create a support ticket" in create_rendered
    assert "brand-mark" in create_rendered
