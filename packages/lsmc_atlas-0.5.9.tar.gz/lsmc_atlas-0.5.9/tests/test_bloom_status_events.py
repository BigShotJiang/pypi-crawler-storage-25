"""Unit tests for Bloom TestOrder status rollup behavior."""

from __future__ import annotations

from app.domain.services.bloom_status_events import compute_order_status_from_tests
from app.persistence.tapdb.orm_models.ordering import OrderStatus


def test_rollup_on_hold_takes_precedence():
    result = compute_order_status_from_tests(["IN_PROGRESS", "ON_HOLD"])
    assert result == OrderStatus.QC_HOLD


def test_rollup_all_terminal_with_completed_results_ready():
    result = compute_order_status_from_tests(["COMPLETED", "FAILED"])
    assert result == OrderStatus.RESULTS_READY


def test_rollup_all_terminal_without_completed_closed_no_results():
    result = compute_order_status_from_tests(["FAILED", "CANCELED", "REJECTED"])
    assert result == OrderStatus.CLOSED_NO_RESULTS


def test_rollup_in_progress_when_any_child_in_progress_or_specimen_received():
    result = compute_order_status_from_tests(["PENDING", "SPECIMEN_RECEIVED"])
    assert result == OrderStatus.IN_PROGRESS


def test_rollup_pending_only_defaults_ordered():
    result = compute_order_status_from_tests(["PENDING"])
    assert result == OrderStatus.ORDERED
