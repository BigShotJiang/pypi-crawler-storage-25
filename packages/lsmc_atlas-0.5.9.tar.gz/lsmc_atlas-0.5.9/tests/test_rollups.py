"""Tests for Order status rollup logic (Step 7).

As of Step 7, order status is derived from assay run states.
These tests verify that:
1. Order status is correctly derived from FulfillmentRunState values
2. Terminal states (CANCELED, REJECTED) are preserved
3. Release state affects order status (RELEASED, AMENDED)
4. Edge cases are handled properly
"""

import uuid

from app.domain.policies.fulfillment_state_machine import FulfillmentRunState
from app.domain.policies.rollups import OrderRollupState, compute_order_status
from app.persistence.tapdb.orm_models.ordering import OrderStatus

# --- Order Status Computation Tests (Step 7) ---


class TestOrderStatusComputation:
    """Test Order status computation from assay states."""

    def test_draft_order_stays_draft_no_assays(self):
        """Draft order with no assays stays DRAFT."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.DRAFT.value,
            assay_states=[],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.DRAFT

    def test_draft_order_stays_draft_all_draft_assays(self):
        """Draft order with all assays in DRAFT stays DRAFT."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.DRAFT.value,
            assay_states=[FulfillmentRunState.DRAFT, FulfillmentRunState.DRAFT],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.DRAFT

    def test_ordered_when_assays_ordered(self):
        """Order is ORDERED when any assay is ORDERED."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.DRAFT.value,
            assay_states=[FulfillmentRunState.ORDERED, FulfillmentRunState.ORDERED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.ORDERED

    def test_ordered_when_assays_received(self):
        """Order is ORDERED when assays are RECEIVED (awaiting accessioning)."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.ORDERED.value,
            assay_states=[FulfillmentRunState.RECEIVED, FulfillmentRunState.ORDERED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.ORDERED

    def test_in_progress_when_assays_accessioned(self):
        """Order is IN_PROGRESS when any assay is ACCESSIONED."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.ORDERED.value,
            assay_states=[FulfillmentRunState.ACCESSIONED, FulfillmentRunState.RECEIVED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.IN_PROGRESS

    def test_in_progress_when_assays_in_progress(self):
        """Order is IN_PROGRESS when any assay is IN_PROGRESS."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.IN_PROGRESS.value,
            assay_states=[FulfillmentRunState.IN_PROGRESS, FulfillmentRunState.ACCESSIONED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.IN_PROGRESS

    def test_qc_hold_when_any_assay_qc_hold(self):
        """Order is QC_HOLD when any assay is QC_HOLD."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.IN_PROGRESS.value,
            assay_states=[FulfillmentRunState.IN_PROGRESS, FulfillmentRunState.QC_HOLD],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.QC_HOLD

    def test_results_ready_when_all_assays_resulted(self):
        """Order is RESULTS_READY when all assays are in terminal states with results."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.IN_PROGRESS.value,
            assay_states=[FulfillmentRunState.RESULTED, FulfillmentRunState.RESULTED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.RESULTS_READY

    def test_results_ready_with_mixed_terminal_with_results(self):
        """Order is RESULTS_READY when all assays terminal and at least one has results."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.IN_PROGRESS.value,
            assay_states=[
                FulfillmentRunState.RESULTED,
                FulfillmentRunState.CANCELLED,
                FulfillmentRunState.AMENDED,
            ],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.RESULTS_READY

    def test_closed_no_results_when_all_cancelled(self):
        """Order is CLOSED_NO_RESULTS when all assays terminal with no results."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.IN_PROGRESS.value,
            assay_states=[FulfillmentRunState.CANCELLED, FulfillmentRunState.FAILED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.CLOSED_NO_RESULTS

    def test_released_when_results_ready_and_released_package(self):
        """Order is RELEASED when results ready and already released."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.RELEASED.value,
            assay_states=[FulfillmentRunState.RESULTED, FulfillmentRunState.RESULTED],
            has_released_package=True,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.RELEASED

    def test_amended_when_results_ready_with_package_but_not_released_status(self):
        """Order is AMENDED when results ready with package but status wasn't RELEASED."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.RESULTS_READY.value,
            assay_states=[FulfillmentRunState.RESULTED, FulfillmentRunState.AMENDED],
            has_released_package=True,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.AMENDED

    def test_canceled_stays_canceled(self):
        """Canceled order stays CANCELED regardless of assay states."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.CANCELED.value,
            assay_states=[FulfillmentRunState.CANCELLED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.CANCELED

    def test_rejected_stays_rejected(self):
        """Rejected order stays REJECTED regardless of assay states."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.REJECTED.value,
            assay_states=[FulfillmentRunState.FAILED],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.REJECTED


class TestDerivedOrderStatusPriority:
    """Test priority rules for derived order status."""

    def test_qc_hold_takes_priority_over_in_progress(self):
        """QC_HOLD takes priority over IN_PROGRESS."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.IN_PROGRESS.value,
            assay_states=[
                FulfillmentRunState.IN_PROGRESS,
                FulfillmentRunState.QC_HOLD,
                FulfillmentRunState.ACCESSIONED,
            ],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.QC_HOLD

    def test_in_progress_takes_priority_over_ordered(self):
        """IN_PROGRESS takes priority over ORDERED."""
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.ORDERED.value,
            assay_states=[FulfillmentRunState.ORDERED, FulfillmentRunState.IN_PROGRESS],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.IN_PROGRESS

    def test_terminal_states_override_assay_derivation(self):
        """CANCELED/REJECTED override assay-based derivation."""
        # CANCELED with active assays - stays CANCELED
        state = OrderRollupState(
            order_id=uuid.uuid4(),
            current_status=OrderStatus.CANCELED.value,
            assay_states=[FulfillmentRunState.IN_PROGRESS],
            has_released_package=False,
        )
        status = compute_order_status(state)
        assert status == OrderStatus.CANCELED
