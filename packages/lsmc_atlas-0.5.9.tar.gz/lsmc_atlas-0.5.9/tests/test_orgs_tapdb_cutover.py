"""Unit tests for TapDB cutover behavior in org/site services."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from types import SimpleNamespace

from app.domain.services.orgs import (
    OrganizationCreate,
    OrganizationService,
    OrganizationUpdate,
    SiteCreate,
    SiteService,
    SiteUpdate,
)


@dataclass
class _MockDB:
    pass


class _FakeOrgRepo:
    def __init__(self):
        self.calls: list[str] = []

    def create_org(self, data, created_by):
        self.calls.append("create_org")
        return SimpleNamespace(euid="org")

    def get_org_by_id(self, org_id):
        self.calls.append("get_org_by_id")
        return {"id": org_id}

    def get_org_with_revision(self, org_id):
        self.calls.append("get_org_with_revision")
        return ({"id": org_id}, {"revision_no": 1})

    def list_orgs(self, active_only=True):
        self.calls.append("list_orgs")
        return [{"id": "org"}]

    def update_org(self, org_id, data, updated_by):
        self.calls.append("update_org")
        return {"id": org_id}

    def create_site(self, data, created_by):
        self.calls.append("create_site")
        return {"id": "site"}

    def get_site_by_id(self, site_id):
        self.calls.append("get_site_by_id")
        return {"id": site_id}

    def list_sites_by_org(self, org_id, active_only=True):
        self.calls.append("list_sites_by_org")
        return [{"id": "site"}]

    def update_site(self, site_id, data, updated_by):
        self.calls.append("update_site")
        return {"id": site_id}


def test_org_and_site_services_delegate_to_tapdb_repo(monkeypatch):
    repo = _FakeOrgRepo()
    org_svc = OrganizationService(_MockDB())
    site_svc = SiteService(_MockDB())

    monkeypatch.setattr(org_svc, "_repo", lambda: repo)
    monkeypatch.setattr(site_svc, "_repo", lambda: repo)

    org_id = uuid.uuid4()
    site_id = uuid.uuid4()

    created_org = org_svc.create(OrganizationCreate(name="Org"), created_by=None)
    assert created_org.euid == "org"
    assert org_svc.get_by_id(org_id) == {"id": org_id}
    assert org_svc.get_with_revision(org_id) == ({"id": org_id}, {"revision_no": 1})
    assert org_svc.list_all(active_only=False) == [{"id": "org"}]
    assert org_svc.update(org_id, OrganizationUpdate(name="Updated"), updated_by=None) == {
        "id": org_id
    }

    assert site_svc.create(
        SiteCreate(organization_id=org_id, name="Site"),
        created_by=None,
    ) == {"id": "site"}
    assert site_svc.get_by_id(site_id) == {"id": site_id}
    assert site_svc.list_by_organization(org_id, active_only=False) == [{"id": "site"}]
    assert site_svc.update(site_id, SiteUpdate(name="New Name"), updated_by=None) == {"id": site_id}

    assert repo.calls == [
        "create_org",
        "create_site",
        "get_org_by_id",
        "get_org_with_revision",
        "list_orgs",
        "update_org",
        "create_site",
        "get_site_by_id",
        "list_sites_by_org",
        "get_site_by_id",
        "update_site",
    ]
