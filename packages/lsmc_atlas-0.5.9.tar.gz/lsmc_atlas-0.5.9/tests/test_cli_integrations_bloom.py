"""Unit tests for Atlas Bloom integration CLI commands."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

from app.cli import integrations


class _FakeSession:
    def __init__(self):
        self.committed = False
        self.closed = False

    def commit(self):
        self.committed = True

    def close(self):
        self.closed = True


def test_provision_client_includes_lookup_endpoint(monkeypatch):
    captured: dict[str, object] = {}
    fake_session = _FakeSession()

    class FakeApiClientService:
        def __init__(self, db, tenant_id):
            captured["tenant_id"] = tenant_id

        def create(self, data, created_by=None):
            captured["data"] = data
            return (
                SimpleNamespace(id=uuid.uuid4(), client_name=data.client_name),
                SimpleNamespace(),
                "test-api-key",
            )

    monkeypatch.setattr(integrations, "SessionLocal", lambda: fake_session)
    monkeypatch.setattr(integrations, "APIClientService", FakeApiClientService)

    integrations.provision_bloom_client(org_id=str(uuid.uuid4()), client_name="atlas-bloom")

    created = captured["data"]
    assert "/api/integrations/bloom/v1" in created.allowed_endpoints
    assert "/api/integrations/bloom/v1/lookups" in created.allowed_endpoints
    assert fake_session.committed is True
    assert fake_session.closed is True


def test_verify_config_checks_categories_and_by_reference(monkeypatch):
    fake_session = _FakeSession()
    calls: list[tuple[str, object]] = []

    class FakeOrgBloomConfigService:
        def __init__(self, db):
            self.db = db

        def get(self, organization_id):
            return SimpleNamespace(
                enabled=True,
                bloom_base_url="https://bloom.local",
                bloom_api_key_secret_ref="env:FAKE_BLOOM_API_KEY",
            )

    class FakeBloomClient:
        def __init__(self, *, base_url, api_key, **_kwargs):
            self.base_url = base_url
            self.api_key = api_key

        def list_object_categories(self):
            calls.append(("LIST", "categories"))
            return [{"category": "container"}]

        def find_external_specimens_by_reference(self, refs):
            calls.append(("FIND", refs))
            return []

    monkeypatch.setattr(integrations, "SessionLocal", lambda: fake_session)
    monkeypatch.setattr(integrations, "OrgBloomConfigService", FakeOrgBloomConfigService)
    monkeypatch.setattr(integrations, "BloomClient", FakeBloomClient)
    monkeypatch.setattr(integrations, "resolve_secret_value", lambda _ref: "secret-value")

    integrations.verify_bloom_config(org_id=str(uuid.uuid4()))

    assert ("LIST", "categories") in calls
    assert any(call[0] == "FIND" for call in calls)
    assert fake_session.closed is True


def test_poll_once_invokes_polling_service(monkeypatch):
    fake_session = _FakeSession()
    invoked: dict[str, object] = {}
    tenant_id = uuid.uuid4()

    class FakePollingService:
        def __init__(self, db, provided_tenant_id):
            invoked["tenant_id"] = provided_tenant_id

        def poll_all_active_trfs(self):
            return SimpleNamespace(
                tenant_id=str(invoked["tenant_id"]),
                trfs_polled=4,
                synced_items=7,
            )

    monkeypatch.setattr(integrations, "SessionLocal", lambda: fake_session)
    monkeypatch.setattr("app.domain.services.bloom_polling.BloomPollingService", FakePollingService)

    integrations.bloom_poll_once(org_id=str(tenant_id))

    assert invoked["tenant_id"] == tenant_id
    assert fake_session.committed is True
    assert fake_session.closed is True


def test_provision_client_global_query_status_mode(monkeypatch):
    captured: dict[str, object] = {}
    fake_session = _FakeSession()

    class FakeApiClientService:
        def __init__(self, db, tenant_id):
            captured["tenant_id"] = tenant_id

        def create(self, data, created_by=None):
            captured["data"] = data
            return (
                SimpleNamespace(id=uuid.uuid4(), client_name=data.client_name),
                SimpleNamespace(),
                "test-api-key",
            )

    monkeypatch.setattr(integrations, "SessionLocal", lambda: fake_session)
    monkeypatch.setattr(integrations, "APIClientService", FakeApiClientService)

    integrations.provision_bloom_client(
        org_id=str(uuid.uuid4()),
        client_name="atlas-bloom-global",
        mode=integrations.BloomClientMode.GLOBAL_QUERY_STATUS,
    )

    created = captured["data"]
    assert "cross_tenant:read" in created.permissions
    assert "cross_tenant:write" in created.permissions
    assert "/api/integrations/bloom/v1/lookups/containers" in created.allowed_endpoints
    assert "/api/integrations/bloom/v1/tests" in created.allowed_endpoints
    assert "/api/integrations/bloom/v1/lookups/trfs" in created.allowed_endpoints
    assert "/api/integrations/bloom/v1/patients" not in created.allowed_endpoints
    assert fake_session.committed is True
    assert fake_session.closed is True
