"""Contract and UI coverage for Atlas observability surfaces."""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user, get_current_user_web
from app.db.engine import get_db
from app.domain.services.user_api_tokens import TokenCreate, UserAPITokenService
from app.domain.services.users import UserCreate, UserService
from app.main import app
from app.settings import settings
from tests.tapdb_test_helpers import ensure_tapdb_org

DAYHOFF_SCHEMA_ROOT = Path("/Users/jmajor/.codex/worktrees/cbc5/dayhoff/contracts/observability")


def _load_schema(name: str) -> dict[str, Any]:
    return json.loads((DAYHOFF_SCHEMA_ROOT / name).read_text())


def _assert_required_shape(payload: dict[str, Any], schema: dict[str, Any]) -> None:
    for key in schema.get("required", []):
        assert key in payload, f"missing required key {key}"
    projection_schema = schema.get("properties", {}).get("projection")
    if projection_schema and "projection" in payload:
        for key in projection_schema.get("required", []):
            assert key in payload["projection"], f"missing projection key {key}"


@pytest.fixture
def observability_client(db_session) -> TestClient:
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


def test_observability_contract_endpoints_match_shared_frame(observability_client: TestClient) -> None:
    headers = {"Authorization": f"Bearer {settings.internal_api_key}"}

    # Seed a little traffic first so rollups have non-empty content.
    observability_client.get("/healthz")
    observability_client.get("/readyz")
    observability_client.get("/obs_services", headers=headers)

    schema_map = {
        "/health": "health.schema.json",
        "/obs_services": "obs_services.schema.json",
        "/api_health": "api_health.schema.json",
        "/endpoint_health": "endpoint_health.schema.json",
        "/db_health": "db_health.schema.json",
        "/auth_health": "auth_health.schema.json",
    }

    for path, schema_name in schema_map.items():
        response = observability_client.get(path, headers=headers)
        assert response.status_code == 200, f"{path} returned {response.status_code}"
        payload = response.json()
        _assert_required_shape(payload, _load_schema(schema_name))
        assert payload["service"] == "atlas"
        assert payload["contract_version"] == "v3"


def test_my_health_matches_shared_schema_for_authenticated_user(
    observability_client: TestClient,
    db_session,
) -> None:
    tenant_id = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_id, name="observability-contract", display_name="Observability")
    user = UserService(db_session).create(
        UserCreate(
            cognito_sub=str(uuid.uuid4()),
            email="observer@example.com",
            name="Observer",
            tenant_id=tenant_id,
            roles=["EXTERNAL_USER"],
        )
    )
    token, _, plaintext = UserAPITokenService(db_session, tenant_id).create(
        user_id=uuid.UUID(user.cognito_sub),
        data=TokenCreate(token_name="Observability Contract Token"),
        created_by=uuid.UUID(user.cognito_sub),
    )
    assert token is not None

    response = observability_client.get("/my_health", headers={"Authorization": f"Bearer {plaintext}"})
    assert response.status_code == 200
    payload = response.json()
    _assert_required_shape(payload, _load_schema("my_health.schema.json"))
    assert payload["service"] == "atlas"
    assert payload["contract_version"] == "v3"
    assert payload["principal"]["auth_mode"] == "user_api_token"
    assert payload["principal"]["service_principal"] is False
    assert payload["principal"]["email"] == "observer@example.com"


def test_endpoint_health_uses_route_templates_not_raw_instances(observability_client: TestClient) -> None:
    headers = {"Authorization": f"Bearer {settings.internal_api_key}"}

    observability_client.get("/healthz")
    observability_client.get("/readyz")
    observability_client.get("/obs_services", headers=headers)
    response = observability_client.get("/endpoint_health", headers=headers)

    assert response.status_code == 200
    route_templates = {item["route_template"] for item in response.json()["items"]}
    assert "/healthz" in route_templates
    assert "/readyz" in route_templates
    assert "/obs_services" in route_templates


def test_obs_services_advertises_my_health_as_authenticated_self(
    observability_client: TestClient,
) -> None:
    headers = {"Authorization": f"Bearer {settings.internal_api_key}"}
    response = observability_client.get("/obs_services", headers=headers)

    assert response.status_code == 200
    advertised = {
        item["path"]: {"auth": item["auth"], "kind": item["kind"]}
        for item in response.json()["endpoints"]
    }
    assert advertised["/healthz"] == {"auth": "none", "kind": "liveness"}
    assert advertised["/health"] == {
        "auth": "operator_or_service_token",
        "kind": "summary",
    }
    assert advertised["/my_health"] == {"auth": "authenticated_self", "kind": "self"}


def test_my_health_rejects_internal_service_token(observability_client: TestClient) -> None:
    response = observability_client.get(
        "/my_health",
        headers={"Authorization": f"Bearer {settings.internal_api_key}"},
    )
    assert response.status_code == 401


def test_my_health_supports_dependency_overrides_for_authenticated_user(
    db_session,
    internal_user: CurrentUser,
) -> None:
    def override_get_db():
        yield db_session

    def override_get_current_user():
        return internal_user

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user
    try:
        with TestClient(app) as client:
            response = client.get("/my_health")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    payload = response.json()
    assert payload["principal"]["email"] == internal_user.email
    assert payload["principal"]["auth_mode"] == internal_user.auth_mode


def test_admin_observability_page_renders(db_session, internal_user: CurrentUser) -> None:
    def override_get_db():
        yield db_session

    def override_get_current_user_web():
        return internal_user

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user_web] = override_get_current_user_web
    try:
        with TestClient(app) as client:
            response = client.get("/admin/observability")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    assert "Observability" in response.text
    assert "/db_health" in response.text
