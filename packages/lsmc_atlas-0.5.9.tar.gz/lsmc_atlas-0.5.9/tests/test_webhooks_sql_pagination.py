from __future__ import annotations

import uuid

from sqlalchemy.dialects import postgresql

from app.persistence.tapdb.webhooks import TapdbWebhookRepository, _build_subscription_select


def test_webhooks_subscription_select_filters_tenant_and_paginates():
    tenant_id = uuid.uuid4()
    stmt = _build_subscription_select(tenant_id=tenant_id, skip=5, limit=10)
    sql = str(
        stmt.compile(dialect=postgresql.dialect(), compile_kwargs={"literal_binds": True})
    ).lower()

    assert "order by" in sql
    assert "created_dt" in sql
    assert "desc" in sql
    assert "limit" in sql
    assert "offset" in sql
    assert "tenant_id" in sql


def test_webhooks_list_subscriptions_does_not_scan_instances_for_template(monkeypatch):
    class _FakeScalars:
        def all(self):
            return []

    class _FakeResult:
        def scalars(self):
            return _FakeScalars()

    class _FakeSession:
        def execute(self, _stmt):
            return _FakeResult()

    repo = TapdbWebhookRepository(_FakeSession())

    def _boom(*_args, **_kwargs):
        raise AssertionError("_instances_for_template should not be called")

    monkeypatch.setattr(repo, "_instances_for_template", _boom)
    repo.list_subscriptions(tenant_id=uuid.uuid4(), skip=0, limit=10)
