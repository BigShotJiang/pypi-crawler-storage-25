import tomllib
from pathlib import Path


def test_pyproject_declares_pydantic_settings_dependency() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    pyproject = tomllib.loads((repo_root / "pyproject.toml").read_text(encoding="utf-8"))
    dependencies = pyproject["project"]["dependencies"]

    assert any(dep.startswith("pydantic-settings") for dep in dependencies)
