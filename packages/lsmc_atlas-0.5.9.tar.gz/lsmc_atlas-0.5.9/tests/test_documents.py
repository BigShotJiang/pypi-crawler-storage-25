"""Tests for the documents API — tenant isolation via TapDB.

The TapDB document backend does not yet implement per-user restricted_to_user_id
filtering (see TODO in DocumentService.list_documents).  These tests verify that
tenant-scoped isolation works correctly: documents created for tenant A are
invisible to a user whose CurrentUser.tenant_id is tenant B.
"""

import uuid

import pytest
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.persistence.tapdb.documents import TapdbDocumentRepository
from tests.tapdb_test_helpers import ensure_tapdb_org
from tests.test_api_smoke import _make_client

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _seed_document(db_session: Session, tenant_id: uuid.UUID, filename: str):
    """Create a document via TapDB and return the (doc, rev) tuple."""
    repo = TapdbDocumentRepository(db_session)
    payload = type(
        "_Payload",
        (),
        {
            "filename": filename,
            "content_type": "application/pdf",
            "size_bytes": 100,
            "s3_bucket": "test-bucket",
            "s3_key": f"somewhere/{filename}",
            "document_type": "other",
            "note": None,
        },
    )()
    return repo.create_document(tenant_id=tenant_id, data=payload, created_by=None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.db
def test_document_tenant_isolation(db_session: Session, test_user: CurrentUser):
    """Documents for another tenant must not appear in the listing."""
    # Set up tenant for the test user
    ensure_tapdb_org(db_session, test_user.tenant_id, name="doc-test-org")
    db_session.flush()

    # Create a document owned by the user's tenant
    doc_own, _ = _seed_document(db_session, test_user.tenant_id, "own_tenant.pdf")

    # Create a document owned by a *different* tenant
    other_tenant = uuid.uuid4()
    ensure_tapdb_org(db_session, other_tenant, name="other-org")
    db_session.flush()
    doc_other, _ = _seed_document(db_session, other_tenant, "other_tenant.pdf")

    client = _make_client(db_session, test_user)
    resp = client.get("/api/documents")
    assert resp.status_code == 200

    returned_euids = {d["euid"] for d in resp.json()["items"]}
    assert doc_own.euid in returned_euids
    assert doc_other.euid not in returned_euids


@pytest.mark.db
def test_document_internal_user_sees_own_tenant(db_session: Session, internal_user: CurrentUser):
    """Internal users see documents scoped to their tenant."""
    ensure_tapdb_org(db_session, internal_user.tenant_id, name="int-doc-org")
    db_session.flush()

    doc, _ = _seed_document(db_session, internal_user.tenant_id, "internal_doc.pdf")

    client = _make_client(db_session, internal_user)
    resp = client.get("/api/documents")
    assert resp.status_code == 200

    returned_euids = {d["euid"] for d in resp.json()["items"]}
    assert doc.euid in returned_euids
