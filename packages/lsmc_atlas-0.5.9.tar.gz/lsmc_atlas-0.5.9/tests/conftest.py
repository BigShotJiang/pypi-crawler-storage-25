"""Pytest configuration and shared fixtures for LSMC Atlas tests."""

import os
import uuid
from collections.abc import Generator
from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

# Ensure DEBUG=true for tests so session cookies work over HTTP (testserver)
# This must be set before importing settings to avoid https_only cookie issues
os.environ.setdefault("DEBUG", "true")

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from app.settings import settings
from tests.tapdb_test_helpers import ensure_tapdb_org

# Test database URL - use PostgreSQL if available (for full tests)
# Otherwise skip DB-dependent tests
_db_url = os.environ.get("TEST_DATABASE_URL")
if not _db_url:
    try:
        _db_url = str(settings.database_url) if settings.database_url else None
    except Exception:
        _db_url = None
TEST_DATABASE_URL = _db_url


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line("markers", "postgres: mark test as requiring PostgreSQL")
    config.addinivalue_line("markers", "db: mark test as requiring database")


@pytest.fixture(scope="session")
def test_engine():
    """Create test database engine using PostgreSQL."""
    if not TEST_DATABASE_URL:
        pytest.skip("No database URL configured")

    engine = create_engine(TEST_DATABASE_URL)

    yield engine

    engine.dispose()


@pytest.fixture(scope="function")
def db_session(test_engine) -> Generator[Session, None, None]:
    """Create a test database session with transaction rollback."""
    TestingSessionLocal = sessionmaker(bind=test_engine, autocommit=False, autoflush=False)
    connection = test_engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)

    try:
        yield session
    finally:
        session.close()
        transaction.rollback()
        connection.close()


# Alias for postgres-specific tests
@pytest.fixture(scope="function")
def pg_session(db_session) -> Generator[Session, None, None]:
    """Alias for db_session - used by postgres-specific tests."""
    yield db_session


@pytest.fixture
def tenant_id() -> str:
    """Default tenant ID for tests."""
    return str(uuid.uuid4())


@pytest.fixture
def other_tenant_id() -> str:
    """Second tenant ID for isolation tests."""
    return str(uuid.uuid4())


@pytest.fixture
def test_user(tenant_id: str) -> CurrentUser:
    """Create a test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="test@example.com",
        name="Test User",
        tenant_id=uuid.UUID(tenant_id),
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def internal_user(tenant_id: str) -> CurrentUser:
    """Create an internal test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="internal@lsmc.bio",
        name="Internal User",
        tenant_id=uuid.UUID(tenant_id),
        roles=[Role.INTERNAL_USER.value],
    )


@pytest.fixture
def admin_user(tenant_id: str) -> CurrentUser:
    """Create an admin test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="admin@lsmc.bio",
        name="Admin User",
        tenant_id=uuid.UUID(tenant_id),
        roles=[Role.ADMIN.value],
    )


@pytest.fixture
def client(db_session: Session, test_user: CurrentUser) -> Generator[TestClient, None, None]:
    """Create a test client with DB session override and authenticated user."""
    from app.auth.dependencies import get_current_user

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_current_user():
        return test_user

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user

    with TestClient(app) as c:
        yield c

    app.dependency_overrides.clear()


@pytest.fixture
def internal_client(
    db_session: Session, internal_user: CurrentUser
) -> Generator[TestClient, None, None]:
    """Create a test client with internal user authentication and API key."""
    from app.api.routes.internal import verify_internal_api_key
    from app.auth.dependencies import get_current_user

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_current_user():
        return internal_user

    async def override_verify_internal_api_key():
        return "test-api-key"

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user
    app.dependency_overrides[verify_internal_api_key] = override_verify_internal_api_key

    with TestClient(app) as c:
        yield c

    app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def reset_rate_limiters():
    """Reset rate limiter state before each test to prevent 429 errors."""
    from app.auth.rate_limiting import reset_all_limiters

    reset_all_limiters()
    yield
    reset_all_limiters()


@pytest.fixture(autouse=True)
def _clear_dependency_overrides():
    """Ensure app.dependency_overrides is cleared after every test.

    Many tests manually call ``app.dependency_overrides.clear()`` at the end,
    but if a test fails before reaching that call, stale overrides leak into
    subsequent tests.  This autouse fixture guarantees cleanup unconditionally.
    """
    yield
    app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def mock_cognito_admin(monkeypatch):
    """Mock Cognito admin operations for all tests.

    Prevents actual AWS API calls and provides deterministic cognito_sub values.
    The mock admin_create_user returns a unique sub for each call.
    """
    _counter = {"n": 0}

    def fake_admin_create_user(email, name=None, *, suppress_invitation=False):
        _counter["n"] += 1
        return f"mock-cognito-sub-{_counter['n']}"

    def fake_admin_add_user_to_group(username, group_name):
        pass

    def fake_admin_disable_user(username):
        pass

    def fake_admin_enable_user(username):
        pass

    monkeypatch.setattr("app.auth.cognito_admin.admin_create_user", fake_admin_create_user)
    monkeypatch.setattr(
        "app.auth.cognito_admin.admin_add_user_to_group",
        fake_admin_add_user_to_group,
    )
    monkeypatch.setattr("app.auth.cognito_admin.admin_disable_user", fake_admin_disable_user)
    monkeypatch.setattr("app.auth.cognito_admin.admin_enable_user", fake_admin_enable_user)


def _as_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    if hasattr(value, "uid"):
        return _as_uuid(value.uid)
    if hasattr(value, "tenant_id"):
        return _as_uuid(value.tenant_id)
    try:
        return uuid.UUID(str(value))
    except (TypeError, ValueError):
        return None


@pytest.fixture(autouse=True)
def ensure_tapdb_tenant_records(request):
    """Keep test tenants present in TapDB for services that validate org existence."""
    if "db" not in request.keywords and "postgres" not in request.keywords:
        yield
        return

    try:
        db_session = request.getfixturevalue("db_session")
    except Exception:
        yield
        return

    candidate_fixture_names = [
        "tenant",
        "tenant_id",
        "other_tenant_id",
        "test_tenant_id",
        "other_tenant_id_ext",
        "test_tenant",
        "setup_tenant",
        "setup_other_tenant",
        "tenant_uuid",
    ]
    seen: set[uuid.UUID] = set()
    for fixture_name in candidate_fixture_names:
        if fixture_name not in request.fixturenames:
            continue
        try:
            value = request.getfixturevalue(fixture_name)
        except Exception:
            continue
        tenant_uuid = _as_uuid(value)
        if tenant_uuid is None or tenant_uuid in seen:
            continue
        ensure_tapdb_org(db_session, tenant_uuid)
        seen.add(tenant_uuid)

    yield
