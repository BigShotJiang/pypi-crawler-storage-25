"""Smoke tests for all API routes.

Every API endpoint gets at least one test to verify it doesn't return 500.
Organized by authentication requirement.
"""

import uuid
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.api.routes.internal import verify_internal_api_key
from app.auth.dependencies import (
    CurrentUser,
    get_current_user,
    get_current_user_or_token,
    get_current_user_web,
)
from app.auth.middleware import csrf_protect
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def tenant_uuid() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def setup_org(db_session: Session, tenant_uuid: uuid.UUID) -> uuid.UUID:
    """Ensure TapDB org exists for tenant-scoped smoke flows."""
    ensure_tapdb_org(db_session, tenant_uuid, name="smoke-org", display_name="Smoke Org")
    db_session.flush()
    return tenant_uuid


@pytest.fixture
def ext_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="smoke@acme.com",
        name="Smoke User",
        tenant_id=tenant_uuid,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def int_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="smoke@lsmc.bio",
        name="Smoke Internal",
        tenant_id=tenant_uuid,
        roles=[Role.INTERNAL_USER.value],
    )


def _make_client(db_session: Session, user: CurrentUser, internal_key: bool = False) -> TestClient:
    """Build a TestClient with given user, optionally overriding internal API key."""

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_user():
        return user

    async def override_csrf():
        pass

    async def override_api_key():
        return "test-key"

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[get_current_user_or_token] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    if internal_key:
        app.dependency_overrides[verify_internal_api_key] = override_api_key

    return TestClient(app)


@pytest.fixture(autouse=True)
def _clear_overrides():
    yield
    app.dependency_overrides.clear()


# =============================================================================
# 1. Regular-auth API GET (list endpoints — no path params)
# =============================================================================

REGULAR_GET_LIST = [
    "/api/patients",
    "/api/shipments",
    "/api/testkits",
    "/api/clinicians",
    "/api/organizations",
    "/api/releases",
    "/api/support",
    "/api/themes/",
    "/api/themes/current",
    "/api/graph/data",
]


@pytest.mark.db
@pytest.mark.parametrize("path", REGULAR_GET_LIST)
def test_api_regular_get_list(db_session, ext_user, setup_org, path):
    """GET list endpoints return 200 with empty results."""
    client = _make_client(db_session, ext_user)
    resp = client.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 403, 410)


# =============================================================================
# 2. Regular-auth API GET (detail endpoints — with path params, expect 404)
# =============================================================================

_uid = str(uuid.uuid4())
_fake_num = "TRF-FAKE-001"

REGULAR_GET_DETAIL = [
    f"/api/trfs/tests/{_uid}",
    f"/api/organizations/{_uid}",
    f"/api/organizations/{_uid}/sites",
    f"/api/organizations/{_uid}/users",
    f"/api/patients/{_uid}",
    "/api/patients/by-mrn/FAKEMRN999",
    f"/api/releases/{_fake_num}",
    f"/api/releases/by-trf/{_fake_num}",
    f"/api/shipments/{_fake_num}",
    f"/api/support/{_uid}",
    f"/api/clinicians/{_uid}",
    "/api/clinicians/by-npi/FAKENPI999",
    "/api/graph/object/GRAPH-FAKE-001",
]


@pytest.mark.db
@pytest.mark.parametrize("path", REGULAR_GET_DETAIL)
def test_api_regular_get_detail(db_session, ext_user, setup_org, path):
    """GET detail endpoints return 404 for non-existent resources (never 500)."""
    client = _make_client(db_session, ext_user)
    resp = client.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 404, 403, 422)


# =============================================================================
# 3. Regular-auth API POST (create / action endpoints)
# =============================================================================


@pytest.mark.db
def test_api_create_trf(db_session, ext_user, setup_org):
    """POST /api/trfs — validation error or success (never 500)."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/trfs", json={})
    assert resp.status_code != 500, f"returned 500: {resp.text[:200]}"
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_create_order_under_trf(db_session, ext_user, setup_org):
    """POST /api/trfs/{id}/tests — 404/422 for non-existent TRF."""
    client = _make_client(db_session, ext_user)
    resp = client.post(f"/api/trfs/{_uid}/tests", json={})
    assert resp.status_code != 500, f"returned 500: {resp.text[:200]}"
    assert resp.status_code in (201, 404, 422, 400)


@pytest.mark.db
def test_api_link_orders(db_session, ext_user, setup_org):
    """POST /api/trfs/tests/{id}/links — 404/422 for non-existent order."""
    client = _make_client(db_session, ext_user)
    resp = client.post(f"/api/trfs/tests/{_uid}/links", json={})
    assert resp.status_code != 500, f"returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 404, 422, 400)


@pytest.mark.db
def test_api_create_patient(db_session, ext_user, setup_org):
    """POST /api/patients — validation error expected."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/patients", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_create_shipment(db_session, ext_user, setup_org):
    """POST /api/shipments — validation error expected."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/shipments", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_create_testkit(db_session, ext_user, setup_org):
    """POST /api/testkits — validation error expected."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/testkits", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_create_support_ticket(db_session, ext_user, setup_org):
    """POST /api/support — validation error expected."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/support", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_org_create_site(db_session, ext_user, setup_org):
    """POST /api/organizations/{id}/sites — 422 or 404."""
    client = _make_client(db_session, ext_user)
    resp = client.post(f"/api/organizations/{_uid}/sites", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 404, 422, 403)


@pytest.mark.db
def test_api_legacy_orders_alias_removed(db_session, ext_user, setup_org):
    """Legacy /api/orders surface is retired."""
    client = _make_client(db_session, ext_user)
    resp = client.get("/api/orders")
    assert resp.status_code in (404, 405)


@pytest.mark.db
def test_api_biospecimens_surface_retired(db_session, ext_user, setup_org):
    """Legacy /api/biospecimens surface is removed."""
    client = _make_client(db_session, ext_user)
    resp = client.get("/api/biospecimens")
    assert resp.status_code == 404


@pytest.mark.db
def test_api_org_create_user(db_session, ext_user, setup_org):
    """POST /api/organizations/{id}/users — 422 or 403."""
    client = _make_client(db_session, ext_user)
    resp = client.post(f"/api/organizations/{_uid}/users", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 404, 422, 403)


@pytest.mark.db
def test_api_shipment_contents(db_session, ext_user, setup_org):
    """POST /api/shipments/{num}/contents — 404 or 422."""
    client = _make_client(db_session, ext_user)
    resp = client.post(f"/api/shipments/{_fake_num}/contents", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 404, 422)


@pytest.mark.db
def test_api_delete_shipment_contents(db_session, ext_user, setup_org):
    """DELETE /api/shipments/{num}/contents — 404 or 422."""
    client = _make_client(db_session, ext_user)
    resp = client.request("DELETE", f"/api/shipments/{_fake_num}/contents", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 204, 404, 422)


@pytest.mark.db
def test_api_patch_patient(db_session, ext_user, setup_org):
    """PATCH /api/patients/{id} — 404."""
    client = _make_client(db_session, ext_user)
    resp = client.patch(f"/api/patients/{_uid}", json={"first_name": "X"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_patch_clinician(db_session, ext_user, setup_org):
    """PATCH /api/clinicians/{id} — 404."""
    client = _make_client(db_session, ext_user)
    resp = client.patch(f"/api/clinicians/{_uid}", json={"first_name": "X"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_patch_organization(db_session, ext_user, setup_org):
    """PATCH /api/organizations/{id} — 404 or 403."""
    client = _make_client(db_session, ext_user)
    resp = client.patch(f"/api/organizations/{_uid}", json={"display_name": "X"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422, 403)


@pytest.mark.db
def test_api_patch_support_ticket(db_session, ext_user, setup_org):
    """PATCH /api/support/{id} — 404."""
    client = _make_client(db_session, ext_user)
    resp = client.patch(f"/api/support/{_uid}", json={"status": "RESOLVED"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_user_preferences(db_session, ext_user, setup_org):
    """POST /api/user/preferences — set preferences."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/user/preferences", json={"datetime_format": "standard"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 201, 404, 422)


@pytest.mark.db
def test_api_user_preferences_display_timezone(db_session, ext_user, setup_org):
    """POST /api/user/preferences — set display timezone."""
    client = _make_client(db_session, ext_user)
    resp = client.post(
        "/api/user/preferences",
        json={"display_timezone": "America/Los_Angeles"},
    )
    assert resp.status_code != 500
    assert resp.status_code in (200, 201, 404, 422)


@pytest.mark.db
def test_api_user_preferences_display_timezone_invalid_falls_back(db_session, ext_user, setup_org):
    """POST /api/user/preferences — invalid timezone should still normalize safely."""
    client = _make_client(db_session, ext_user)
    resp = client.post(
        "/api/user/preferences",
        json={"display_timezone": "Invalid/Timezone"},
    )
    assert resp.status_code != 500
    assert resp.status_code in (200, 201, 404, 422)


@pytest.mark.db
def test_api_select_theme(db_session, ext_user, setup_org):
    """POST /api/themes/select — set theme."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/themes/select", json={"theme_id": "default"})
    assert resp.status_code != 500


@pytest.mark.db
def test_api_create_clinician_user(db_session, ext_user, setup_org):
    """POST /api/clinicians/{id}/users — 404 or 422."""
    client = _make_client(db_session, ext_user)
    resp = client.post(f"/api/clinicians/{_uid}/users", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 404, 422, 403)


@pytest.mark.db
def test_api_search_v2_query(db_session, ext_user, setup_org):
    """POST /api/search/v2/query — should never 500."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/search/v2/query", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 403)


@pytest.mark.db
def test_api_search_v2_query_alias(db_session, ext_user, setup_org):
    """POST /api/v1/search/v2/query — should never 500."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/v1/search/v2/query", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 403)


@pytest.mark.db
def test_api_search_v2_export(db_session, ext_user, setup_org):
    """POST /api/search/v2/export — should never 500."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/api/search/v2/export", json={"format": "json"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 403)


# =============================================================================
# 4. Internal-auth API routes (require_internal / require_internal_api)
#    These use get_current_user_web with internal role check.
# =============================================================================

INTERNAL_GET_LIST = [
    "/api/documents",
    "/api/exceptions",
    "/api/intake/exceptions",
    "/api/manifests",
    "/api/barcode/status",
    "/api/barcode/printers",
    "/api/tracking/status",
]


@pytest.mark.db
@pytest.mark.parametrize("path", INTERNAL_GET_LIST)
def test_api_internal_get_list(db_session, int_user, setup_org, path):
    """Internal GET list endpoints return 200."""
    client = _make_client(db_session, int_user)
    resp = client.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 403, 404, 410)


INTERNAL_GET_DETAIL = [
    f"/api/documents/{_uid}",
    f"/api/documents/linked/order/{_uid}",
    f"/api/documents/{_uid}/download",
    f"/api/exceptions/{_uid}",
    f"/api/intake/candidates/{_uid}",
    f"/api/manifests/{_fake_num}",
    f"/api/tracking/shipment/{_uid}",
    "/api/tracking/track/FAKETRACK123",
]


@pytest.mark.db
@pytest.mark.parametrize("path", INTERNAL_GET_DETAIL)
def test_api_internal_get_detail(db_session, int_user, setup_org, path):
    """Internal GET detail endpoints return 404 for non-existent resources."""
    client = _make_client(db_session, int_user)
    resp = client.get(path)
    assert resp.status_code not in (500,), f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 404, 403, 410, 422, 503)  # 503 for optional deps like FedEx


@pytest.mark.db
def test_api_create_document(db_session, int_user, setup_org):
    """POST /api/documents — validation error (no file)."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/documents")
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_link_document(db_session, int_user, setup_org):
    """POST /api/documents/{id}/link — 404 or 422."""
    client = _make_client(db_session, int_user)
    resp = client.post(f"/api/documents/{_uid}/link", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_create_exception(db_session, int_user, setup_org):
    """POST /api/exceptions — validation error."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/exceptions", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_patch_exception(db_session, int_user, setup_org):
    """PATCH /api/exceptions/{id} — 404."""
    client = _make_client(db_session, int_user)
    resp = client.patch(f"/api/exceptions/{_uid}", json={"note": "test"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


EXCEPTION_ACTIONS = [
    f"/api/exceptions/{_uid}/assign",
    f"/api/exceptions/{_uid}/close",
    f"/api/exceptions/{_uid}/escalate",
    f"/api/exceptions/{_uid}/resolve",
]


@pytest.mark.db
@pytest.mark.parametrize("path", EXCEPTION_ACTIONS)
def test_api_exception_actions(db_session, int_user, setup_org, path):
    """POST exception action endpoints — 404 or 422."""
    client = _make_client(db_session, int_user)
    resp = client.post(path, json={"note": "test"})
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_intake_scan(db_session, int_user, setup_org):
    """POST /api/intake/scan — validation or 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/intake/scan", json={"barcode": "TEST123"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400, 404)


@pytest.mark.db
def test_api_intake_match(db_session, int_user, setup_org):
    """POST /api/intake/match — legacy endpoint removed."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/intake/match", json={})
    assert resp.status_code != 500
    assert resp.status_code == 404


@pytest.mark.db
def test_api_intake_unmatch(db_session, int_user, setup_org):
    """POST /api/intake/unmatch — legacy endpoint removed."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/intake/unmatch", json={})
    assert resp.status_code != 500
    assert resp.status_code == 404


@pytest.mark.db
def test_api_intake_receive_shipment(db_session, int_user, setup_org):
    """POST /api/intake/receive-shipment — 404 or 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/intake/receive-shipment", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400, 404)


@pytest.mark.db
def test_api_intake_receive_specific(db_session, int_user, setup_org):
    """POST /api/intake/shipments/{num}/receive — 404 or 422."""
    client = _make_client(db_session, int_user)
    resp = client.post(f"/api/intake/shipments/{_fake_num}/receive", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_manifest_parse(db_session, int_user, setup_org):
    """POST /api/manifests/parse — 422 (no file)."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/manifests/parse")
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400)


@pytest.mark.db
def test_api_manifest_upload(db_session, int_user, setup_org):
    """POST /api/manifests/upload — 422 (no file)."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/manifests/upload")
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


# --- Barcode routes (require_internal_api) ---


@pytest.mark.db
def test_api_barcode_print(db_session, int_user, setup_org):
    """POST /api/barcode/print — 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/barcode/print", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400, 503)  # 503 if zebra_day not installed


@pytest.mark.db
def test_api_barcode_print_biospecimen(db_session, int_user, setup_org):
    """POST /api/barcode/print/biospecimen — legacy endpoint removed."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/barcode/print/biospecimen", json={})
    assert resp.status_code != 500
    assert resp.status_code == 404


@pytest.mark.db
def test_api_barcode_print_testkit(db_session, int_user, setup_org):
    """POST /api/barcode/print/testkit — 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/barcode/print/testkit", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400, 503)  # 503 if zebra_day not installed


@pytest.mark.db
def test_api_barcode_discover(db_session, int_user, setup_org):
    """POST /api/barcode/discover — 503 (mocked to avoid real network probe)."""
    client = _make_client(db_session, int_user)
    # Mock discover_printers to avoid a real network scan that hangs on
    # socket timeouts when zebra_day is installed.
    with patch(
        "app.domain.services.barcode_printing.BarcodePrintService.discover_printers",
        side_effect=RuntimeError("zebra_day network probe mocked out in tests"),
    ):
        resp = client.post("/api/barcode/discover?ip_stub=192.168.1")
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400, 503)  # 503 if zebra_day not installed


# --- Tracking routes (mixed: require_internal_api + get_current_user) ---


@pytest.mark.db
def test_api_tracking_shipment_update(db_session, int_user, setup_org):
    """POST /api/tracking/shipment/update — 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/tracking/shipment/update", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400)


# --- API Client routes (require_internal) ---


INTERNAL_API_CLIENT_GET = [
    "/api-clients",
    f"/api-clients/{_uid}",
    f"/api-clients/{_uid}/usage",
]


@pytest.mark.db
@pytest.mark.parametrize("path", INTERNAL_API_CLIENT_GET)
def test_api_client_get(db_session, int_user, setup_org, path):
    """GET api-client endpoints return 200/404."""
    client = _make_client(db_session, int_user)
    resp = client.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 404, 403)


@pytest.mark.db
def test_api_client_create(db_session, int_user, setup_org):
    """POST /api-clients — 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api-clients", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_client_update(db_session, int_user, setup_org):
    """PATCH /api-clients/{id} — 404."""
    client = _make_client(db_session, int_user)
    resp = client.patch(f"/api-clients/{_uid}", json={"name": "X"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_client_rotate_key(db_session, int_user, setup_org):
    """POST /api-clients/{id}/rotate-key — 404."""
    client = _make_client(db_session, int_user)
    resp = client.post(f"/api-clients/{_uid}/rotate-key")
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


# --- Groups routes (RequireInternalStaff / RequireInternal) ---


GROUPS_GET = [
    "/api/groups/",
    "/api/groups/FAKEGROUP",
    "/api/groups/system-groups",
]


@pytest.mark.db
@pytest.mark.parametrize("path", GROUPS_GET)
def test_api_groups_get(db_session, int_user, setup_org, path):
    """GET group endpoints return 200/404."""
    client = _make_client(db_session, int_user)
    resp = client.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 404, 403)


@pytest.mark.db
def test_api_groups_create(db_session, int_user, setup_org):
    """POST /api/groups/ — 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/groups/", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400, 404)  # 404 if groups router not mounted


@pytest.mark.db
def test_api_groups_add_member(db_session, int_user, setup_org):
    """POST /api/groups/{code}/members — 404 or 422."""
    client = _make_client(db_session, int_user)
    resp = client.post("/api/groups/FAKEGROUP/members", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 404, 422)


# --- Audit routes (RequireAuditExport) ---


@pytest.mark.db
def test_api_audit_export_types(db_session, int_user, setup_org):
    """GET /api/audit/export-types — 200 or 403."""
    client = _make_client(db_session, int_user)
    resp = client.get("/api/audit/export-types")
    assert resp.status_code != 500
    assert resp.status_code in (200, 403, 404)  # 404 if audit router not mounted


@pytest.mark.db
def test_api_audit_export(db_session, int_user, setup_org):
    """GET /api/audit/export/{type} — 200 or 403."""
    client = _make_client(db_session, int_user)
    resp = client.get("/api/audit/export/orders")
    assert resp.status_code != 500
    assert resp.status_code in (200, 403, 404, 422)


# --- Webhook routes (get_current_user) ---


@pytest.mark.db
def test_api_webhook_event_types(db_session, ext_user, setup_org):
    """GET /webhooks/event-types — 200."""
    client = _make_client(db_session, ext_user)
    resp = client.get("/webhooks/event-types")
    assert resp.status_code != 500
    assert resp.status_code in (200, 403)


@pytest.mark.db
def test_api_webhook_list(db_session, ext_user, setup_org):
    """GET /webhooks — 200."""
    client = _make_client(db_session, ext_user)
    resp = client.get("/webhooks")
    assert resp.status_code != 500
    assert resp.status_code in (200, 403)


@pytest.mark.db
def test_api_webhook_get(db_session, ext_user, setup_org):
    """GET /webhooks/{id} — 404."""
    client = _make_client(db_session, ext_user)
    resp = client.get(f"/webhooks/{_uid}")
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 403)


@pytest.mark.db
def test_api_webhook_create(db_session, ext_user, setup_org):
    """POST /webhooks — 422."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/webhooks", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_webhook_update(db_session, ext_user, setup_org):
    """PATCH /webhooks/{id} — 404 or 422."""
    client = _make_client(db_session, ext_user)
    resp = client.patch(f"/webhooks/{_uid}", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_webhook_logs(db_session, ext_user, setup_org):
    """GET /webhooks/{id}/logs — 404."""
    client = _make_client(db_session, ext_user)
    resp = client.get(f"/webhooks/{_uid}/logs")
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 403)


# --- User token routes (get_current_user) ---


@pytest.mark.db
def test_api_user_tokens_list(db_session, ext_user, setup_org):
    """GET /user-tokens — 200."""
    client = _make_client(db_session, ext_user)
    resp = client.get("/user-tokens")
    assert resp.status_code != 500
    assert resp.status_code in (200, 403)


@pytest.mark.db
def test_api_user_tokens_create(db_session, ext_user, setup_org):
    """POST /user-tokens — 422."""
    client = _make_client(db_session, ext_user)
    resp = client.post("/user-tokens", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_user_tokens_revoke(db_session, ext_user, setup_org):
    """DELETE /user-tokens/{id} — 404 or 422."""
    client = _make_client(db_session, ext_user)
    resp = client.request("DELETE", f"/user-tokens/{_uid}", json={"reason": "test"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_user_tokens_usage(db_session, ext_user, setup_org):
    """GET /user-tokens/{id}/usage — 404."""
    client = _make_client(db_session, ext_user)
    resp = client.get(f"/user-tokens/{_uid}/usage")
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 403)


# --- Admin token routes (require_role(ADMIN)) ---


@pytest.fixture
def admin_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="admin@lsmc.bio",
        name="Smoke Admin",
        tenant_id=tenant_uuid,
        roles=[Role.ADMIN.value],
    )


@pytest.mark.db
def test_api_admin_tokens_list(db_session, admin_user, setup_org):
    """GET /admin/user-tokens — 200."""
    client = _make_client(db_session, admin_user)
    resp = client.get("/admin/user-tokens")
    assert resp.status_code != 500
    assert resp.status_code in (200, 403)


@pytest.mark.db
def test_api_admin_tokens_revoke(db_session, admin_user, setup_org):
    """DELETE /admin/user-tokens/{id} — 404 or 422."""
    client = _make_client(db_session, admin_user)
    resp = client.request("DELETE", f"/admin/user-tokens/{_uid}", json={"reason": "test"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_admin_tokens_usage(db_session, admin_user, setup_org):
    """GET /admin/user-tokens/{id}/usage — 404."""
    client = _make_client(db_session, admin_user)
    resp = client.get(f"/admin/user-tokens/{_uid}/usage")
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 403)


# =============================================================================
# 5. Internal API key routes (verify_internal_api_key)
#    These use X-API-Key header, not user session.
# =============================================================================


INTERNAL_KEY_GET = [
    "/api/fulfillment-runs",
    f"/api/fulfillment-runs/{_uid}",
    "/api/results-sets?trf_euid=" + _uid,
    f"/api/results-sets/{_uid}",
    f"/internal/trfs/{_uid}?tenant_id={_uid}",
]


@pytest.mark.db
@pytest.mark.parametrize("path", INTERNAL_KEY_GET)
def test_api_internal_key_get(db_session, int_user, setup_org, path):
    """GET internal-api-key endpoints return 200/404."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 400, 404, 403, 422)


@pytest.mark.db
def test_api_assay_run_transition(db_session, int_user, setup_org):
    """POST /api/fulfillment-runs/{id}/transition — 404 or 422."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post(f"/api/fulfillment-runs/{_uid}/transition", json={"to_state": "RUNNING"})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_assay_run_result(db_session, int_user, setup_org):
    """POST /api/fulfillment-runs/{id}/result — 404 or 422."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post(f"/api/fulfillment-runs/{_uid}/result", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 201, 404, 422)


@pytest.mark.db
def test_api_assay_run_amend(db_session, int_user, setup_org):
    """POST /api/fulfillment-runs/{id}/amend — 404 or 422."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post(f"/api/fulfillment-runs/{_uid}/amend", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_results_set_publish(db_session, int_user, setup_org):
    """POST /api/results-sets/{id}/publish — 404 or 422."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post(f"/api/results-sets/{_uid}/publish")
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)


@pytest.mark.db
def test_api_internal_push_artifact(db_session, int_user, setup_org):
    """POST /internal/artifacts is removed in Dewey cutover mode."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post("/internal/artifacts", json={})
    assert resp.status_code != 500
    assert resp.status_code == 404


@pytest.mark.db
def test_api_internal_push_artifacts_bulk(db_session, int_user, setup_org):
    """POST /internal/artifacts/bulk is removed in Dewey cutover mode."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post("/internal/artifacts/bulk", json={})
    assert resp.status_code != 500
    assert resp.status_code == 404


@pytest.mark.db
def test_api_internal_status_updates(db_session, int_user, setup_org):
    """POST /internal/status-updates — 422."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post("/internal/status-updates", json={})
    assert resp.status_code != 500
    assert resp.status_code in (200, 422, 400)


@pytest.mark.db
def test_api_internal_create_release(db_session, int_user, setup_org):
    """POST /internal/releases — 422."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post("/internal/releases", json={})
    assert resp.status_code != 500
    assert resp.status_code in (201, 422, 400)


@pytest.mark.db
def test_api_internal_release_package(db_session, int_user, setup_org):
    """POST /internal/releases/{id}/release — 404 or 422."""
    client = _make_client(db_session, int_user, internal_key=True)
    resp = client.post(f"/internal/releases/{_uid}/release?tenant_id={_uid}")
    assert resp.status_code != 500
    assert resp.status_code in (200, 404, 422)
