"""Security regression tests — batch 3.

Covers:
  NEW-1  Open redirect validation (_safe_redirect_url)
"""

from __future__ import annotations

from app.web.routes.pages import _safe_redirect_url

# ---------------------------------------------------------------------------
# NEW-1 — Open redirect validation
# ---------------------------------------------------------------------------


def test_safe_redirect_rejects_absolute_url():
    assert _safe_redirect_url("https://evil.com") == "/trfs/new"


def test_safe_redirect_rejects_protocol_relative():
    assert _safe_redirect_url("//evil.com") == "/trfs/new"


def test_safe_redirect_rejects_empty():
    assert _safe_redirect_url("") == "/trfs/new"


def test_safe_redirect_accepts_relative_path():
    assert _safe_redirect_url("/trfs/new") == "/trfs/new"


def test_safe_redirect_accepts_nested_path():
    assert _safe_redirect_url("/shipments/new?foo=bar") == "/shipments/new?foo=bar"
