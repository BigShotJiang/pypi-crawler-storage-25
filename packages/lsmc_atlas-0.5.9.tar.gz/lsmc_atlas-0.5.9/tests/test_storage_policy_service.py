"""Unit tests for persisted Atlas storage policy service behavior."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest

import app.domain.services.storage_policies as storage_mod
from app.domain.services.orgs import OrganizationService, SiteService
from app.domain.services.storage_policies import StoragePolicyService, StoragePolicyUpsert

pytestmark = pytest.mark.db


def test_org_and_site_policy_resolution_and_clear(db_session, tenant_id):
    org = OrganizationService(db_session).get_by_uid(uuid.UUID(str(tenant_id)))
    assert org is not None
    sites = SiteService(db_session).list_by_organization(org.euid, active_only=False)
    assert sites
    site = sites[0]

    svc = StoragePolicyService(db_session)
    org_policy = svc.upsert_org_policy(
        organization_euid=org.euid,
        data=StoragePolicyUpsert(
            bucket="org-bucket",
            region="us-west-2",
            base_prefix="org-base",
            access_mode="lsmc_managed",
            enabled=True,
        ),
    )
    assert org_policy.bucket == "org-bucket"

    effective_org = svc.resolve_effective_policy(organization_euid=org.euid, site_euid=site.euid)
    assert effective_org.scope == "organization"
    assert effective_org.policy.bucket == "org-bucket"

    site_policy = svc.upsert_site_policy(
        organization_euid=org.euid,
        site_euid=site.euid,
        data=StoragePolicyUpsert(
            bucket="site-bucket",
            region="us-east-1",
            base_prefix="site-base",
            access_mode="customer_bucket",
            enabled=True,
        ),
    )
    assert site_policy.bucket == "site-bucket"

    effective_site = svc.resolve_effective_policy(organization_euid=org.euid, site_euid=site.euid)
    assert effective_site.scope == "site"
    assert effective_site.policy.bucket == "site-bucket"

    assert svc.clear_site_policy(organization_euid=org.euid, site_euid=site.euid) is True
    effective_after_clear = svc.resolve_effective_policy(
        organization_euid=org.euid,
        site_euid=site.euid,
    )
    assert effective_after_clear.scope == "organization"
    assert effective_after_clear.policy.bucket == "org-bucket"


def test_effective_policy_missing_raises(db_session, tenant_id):
    org = OrganizationService(db_session).get_by_uid(uuid.UUID(str(tenant_id)))
    assert org is not None

    svc = StoragePolicyService(db_session)
    with pytest.raises(ValueError, match="No enabled storage policy"):
        svc.resolve_effective_policy(organization_euid=org.euid, site_euid=None)


def test_canonical_path_generation(db_session, tenant_id):
    org = OrganizationService(db_session).get_by_uid(uuid.UUID(str(tenant_id)))
    assert org is not None
    sites = SiteService(db_session).list_by_organization(org.euid, active_only=False)
    assert sites
    site = sites[0]

    svc = StoragePolicyService(db_session)
    svc.upsert_org_policy(
        organization_euid=org.euid,
        data=StoragePolicyUpsert(
            bucket="atlas-bucket",
            region="us-west-2",
            base_prefix="root",
            enabled=True,
        ),
    )

    patient_target = svc.build_target(
        scope="patient",
        organization_euid=org.euid,
        site_euid=None,
        patient_euid="PAT-1",
        trf_euid=None,
        test_euid=None,
        filename="file.txt",
    )
    assert patient_target.key == "root/patients/PAT-1/file.txt"

    trf_target = svc.build_target(
        scope="trf",
        organization_euid=org.euid,
        site_euid=site.euid,
        patient_euid=None,
        trf_euid="TRF-1",
        test_euid=None,
        filename="trf.json",
    )
    assert trf_target.key == f"root/sites/{site.euid}/trfs/TRF-1/trf.json"

    test_target = svc.build_target(
        scope="test",
        organization_euid=org.euid,
        site_euid=site.euid,
        patient_euid=None,
        trf_euid="TRF-1",
        test_euid="TST-1",
        filename="result.vcf.gz",
    )
    assert test_target.key == f"root/sites/{site.euid}/trfs/TRF-1/tests/TST-1/result.vcf.gz"


def test_ursa_return_target_resolves_and_validates_linkage(monkeypatch, db_session, tenant_id):
    org = OrganizationService(db_session).get_by_uid(uuid.UUID(str(tenant_id)))
    assert org is not None
    sites = SiteService(db_session).list_by_organization(org.euid, active_only=False)
    assert sites
    site = sites[0]

    svc = StoragePolicyService(db_session)
    svc.upsert_org_policy(
        organization_euid=org.euid,
        data=StoragePolicyUpsert(
            bucket="return-bucket",
            region="us-west-2",
            base_prefix="ret",
            enabled=True,
        ),
    )

    class FakeTrfService:
        def __init__(self, db, tenant):
            _ = (db, tenant)

        def get_by_id(self, trf_euid, cross_tenant=False):
            _ = cross_tenant
            return SimpleNamespace(euid=trf_euid, site_id=site.euid), SimpleNamespace()

    class FakeTestService:
        def __init__(self, db, tenant):
            _ = (db, tenant)

        def get_by_id(self, test_euid, cross_tenant=False):
            _ = cross_tenant
            return SimpleNamespace(euid=test_euid, order_id="TRF-1", site_id=site.euid)

    monkeypatch.setattr(storage_mod, "TrfService", FakeTrfService)
    monkeypatch.setattr(storage_mod, "TestService", FakeTestService)

    target = svc.resolve_ursa_return_target(
        atlas_tenant_id=str(tenant_id),
        atlas_trf_euid="TRF-1",
        atlas_test_euid="TST-1",
    )

    assert target.bucket == "return-bucket"
    assert target.key_prefix == f"ret/sites/{site.euid}/trfs/TRF-1/tests/TST-1"
    assert (
        target.storage_uri_prefix
        == f"s3://return-bucket/ret/sites/{site.euid}/trfs/TRF-1/tests/TST-1/"
    )

    class MismatchTestService(FakeTestService):
        def get_by_id(self, test_euid, cross_tenant=False):
            _ = cross_tenant
            return SimpleNamespace(euid=test_euid, order_id="TRF-OTHER", site_id=site.euid)

    monkeypatch.setattr(storage_mod, "TestService", MismatchTestService)
    with pytest.raises(ValueError, match="does not belong"):
        svc.resolve_ursa_return_target(
            atlas_tenant_id=str(tenant_id),
            atlas_trf_euid="TRF-1",
            atlas_test_euid="TST-1",
        )
