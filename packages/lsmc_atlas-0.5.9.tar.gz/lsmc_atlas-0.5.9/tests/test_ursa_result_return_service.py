"""Unit tests for the Ursa result-return service."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest

import app.domain.services.ursa_integration as service_mod
from app.domain.services.ursa_integration import (
    UrsaArtifactInput,
    UrsaResultReturnRequest,
    UrsaResultReturnService,
)


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


def _request(tenant_id: uuid.UUID) -> UrsaResultReturnRequest:
    return UrsaResultReturnRequest(
        atlas_tenant_id=str(tenant_id),
        atlas_trf_euid="TRF-1",
        atlas_test_euid="TST-1",
        atlas_test_fulfillment_item_euid="TPC-1",
        analysis_euid="AN-1",
        run_euid="RUN-1",
        sequenced_library_assignment_euid="SQA-1",
        flowcell_id="FLOW-1",
        lane="1",
        library_barcode="LIB-1",
        analysis_type="WGS",
        result_status="COMPLETED",
        review_state="APPROVED",
        source_system="daylily-ursa",
        result_payload={"variants": []},
        artifacts=[
            UrsaArtifactInput(
                artifact_euid="AT-1",
                artifact_type="vcf",
            )
        ],
    )


def test_apply_creates_result_and_artifacts(monkeypatch, tenant_id):
    transitions = []
    created_results = []

    class FakeOrderService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def get(self, order_euid, cross_tenant=False):
            assert order_euid == "TRF-1"
            return SimpleNamespace(euid="TRF-1"), SimpleNamespace()

    class FakeTestOrderService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def get_by_id(self, test_order_euid, cross_tenant=False):
            assert test_order_euid == "TST-1"
            return SimpleNamespace(euid="TST-1", order_id="TRF-1")

    class FakeProcessItemService:
        def __init__(self, db, provided_tenant_id):
            assert provided_tenant_id == tenant_id

        def get(self, fulfillment_item_euid):
            assert fulfillment_item_euid == "TPC-1"
            return SimpleNamespace(euid="TPC-1", test_euid="TST-1")

    class FakeAssayRunService:
        def __init__(self, db, provided_tenant_id):
            self.state = service_mod.FulfillmentRunState.DRAFT

        def list_for_test_order(self, test_order_id):
            return []

        def create(self, data, created_by=None):
            assert data.fulfillment_route_code == "WGS"
            return SimpleNamespace(euid="ASR-1"), SimpleNamespace()

        def get_current_state(self, fulfillment_run_euid):
            assert fulfillment_run_euid == "ASR-1"
            return self.state

        def transition(self, fulfillment_run_euid, data, transition_by=None):
            transitions.append(data.target_state.value)
            self.state = data.target_state
            return SimpleNamespace(euid=fulfillment_run_euid), SimpleNamespace(
                status=data.target_state.value
            )

    class FakeAssayResultService:
        def __init__(self, db, provided_tenant_id):
            pass

        def list_for_assay_run(self, fulfillment_run_euid):
            return []

        def get_by_analysis_euid(self, fulfillment_run_euid, analysis_euid):
            return None

        def create(self, fulfillment_run_euid, data, created_by=None):
            created_results.append(data)
            return SimpleNamespace(euid="RES-1")

    class FakeResultsSetService:
        def __init__(self, db, provided_tenant_id):
            pass

        def get_or_create_for_test(self, test_euid, created_by=None):
            assert test_euid == "TST-1"
            return SimpleNamespace(euid="RS-1", published_at=None)

        def add_fulfillment_run(self, results_set_euid, fulfillment_run_euid):
            return SimpleNamespace()

    class FakeDeweyClient:
        def __init__(self, *args, **kwargs):
            pass

        def get_artifact(self, artifact_euid):
            assert artifact_euid == "AT-1"
            return {"artifact_euid": artifact_euid}

    class FakeTapdbOrderRepository:
        def __init__(self, db):
            pass

        def get_latest_test_revision(self, test_order_euid):
            assert test_order_euid == "TST-1"
            return SimpleNamespace(fulfillment_route_codes=["WGS"], product_code="WGS")

    monkeypatch.setattr(service_mod, "TrfService", FakeOrderService)
    monkeypatch.setattr(service_mod, "TestService", FakeTestOrderService)
    monkeypatch.setattr(service_mod, "TestFulfillmentItemService", FakeProcessItemService)
    monkeypatch.setattr(service_mod, "FulfillmentRunService", FakeAssayRunService)
    monkeypatch.setattr(service_mod, "FulfillmentOutputService", FakeAssayResultService)
    monkeypatch.setattr(service_mod, "ResultsSetService", FakeResultsSetService)
    monkeypatch.setattr(service_mod, "DeweyClient", FakeDeweyClient)
    monkeypatch.setattr(service_mod, "TapdbTrfRepository", FakeTapdbOrderRepository)
    monkeypatch.setattr(service_mod.settings, "dewey_enabled", True)
    monkeypatch.setattr(service_mod.settings, "dewey_base_url", "https://dewey.example")
    monkeypatch.setattr(service_mod.settings, "dewey_api_token", "token-1")
    monkeypatch.setattr(service_mod.settings, "dewey_request_timeout_seconds", 5.0)
    monkeypatch.setattr(service_mod.settings, "dewey_verify_ssl", True)

    svc = UrsaResultReturnService(db=object(), tenant_id=tenant_id)
    result = svc.apply(_request(tenant_id))

    assert result.idempotent_replay is False
    assert result.fulfillment_run_euid == "ASR-1"
    assert result.fulfillment_output_euid == "RES-1"
    assert result.artifact_euids == ["AT-1"]
    assert transitions == ["ORDERED", "RECEIVED", "ACCESSIONED", "IN_PROGRESS", "RESULTED"]
    assert created_results[0].artifact_ids == ["AT-1"]
    assert created_results[0].result_payload == {"variants": []}
    assert created_results[0].analysis_context["analysis_euid"] == "AN-1"


def test_apply_replays_existing_analysis_result(monkeypatch, tenant_id):
    created_results = []

    class FakeOrderService:
        def __init__(self, db, provided_tenant_id):
            pass

        def get(self, order_euid, cross_tenant=False):
            return SimpleNamespace(euid="TRF-1"), SimpleNamespace()

    class FakeTestOrderService:
        def __init__(self, db, provided_tenant_id):
            pass

        def get_by_id(self, test_order_euid, cross_tenant=False):
            return SimpleNamespace(euid="TST-1", order_id="TRF-1")

    class FakeProcessItemService:
        def __init__(self, db, provided_tenant_id):
            pass

        def get(self, fulfillment_item_euid):
            return SimpleNamespace(euid="TPC-1", test_euid="TST-1")

    class FakeAssayRunService:
        def __init__(self, db, provided_tenant_id):
            pass

        def list_for_test_order(self, test_order_id):
            return [
                (
                    SimpleNamespace(euid="ASR-1", fulfillment_route_code="WGS"),
                    SimpleNamespace(status="RESULTED"),
                )
            ]

        def get_current_state(self, fulfillment_run_euid):
            return service_mod.FulfillmentRunState.RESULTED

        def transition(self, fulfillment_run_euid, data, transition_by=None):
            raise AssertionError("transition should not run on idempotent replay")

    existing_result = SimpleNamespace(euid="RES-EXISTING")

    class FakeAssayResultService:
        def __init__(self, db, provided_tenant_id):
            pass

        def list_for_assay_run(self, fulfillment_run_euid):
            return [existing_result]

        def get_by_analysis_euid(self, fulfillment_run_euid, analysis_euid):
            assert fulfillment_run_euid == "ASR-1"
            assert analysis_euid == "AN-1"
            return existing_result

        def create(self, fulfillment_run_euid, data, created_by=None):
            created_results.append(data)
            return SimpleNamespace(euid="SHOULD-NOT-HAPPEN")

    class FakeResultsSetService:
        def __init__(self, db, provided_tenant_id):
            pass

        def get_latest_for_fulfillment_run(self, fulfillment_run_euid):
            assert fulfillment_run_euid == "ASR-1"
            return SimpleNamespace(euid="RS-EXISTING")

    class FakeDeweyClient:
        def __init__(self, *args, **kwargs):
            pass

        def get_artifact(self, artifact_euid):
            assert artifact_euid == "AT-1"
            return {"artifact_euid": artifact_euid}

    class FakeTapdbOrderRepository:
        def __init__(self, db):
            pass

        def get_latest_test_revision(self, test_order_euid):
            return SimpleNamespace(fulfillment_route_codes=["WGS"], product_code="WGS")

    monkeypatch.setattr(service_mod, "TrfService", FakeOrderService)
    monkeypatch.setattr(service_mod, "TestService", FakeTestOrderService)
    monkeypatch.setattr(service_mod, "TestFulfillmentItemService", FakeProcessItemService)
    monkeypatch.setattr(service_mod, "FulfillmentRunService", FakeAssayRunService)
    monkeypatch.setattr(service_mod, "FulfillmentOutputService", FakeAssayResultService)
    monkeypatch.setattr(service_mod, "ResultsSetService", FakeResultsSetService)
    monkeypatch.setattr(service_mod, "DeweyClient", FakeDeweyClient)
    monkeypatch.setattr(service_mod, "TapdbTrfRepository", FakeTapdbOrderRepository)
    monkeypatch.setattr(service_mod.settings, "dewey_enabled", True)
    monkeypatch.setattr(service_mod.settings, "dewey_base_url", "https://dewey.example")
    monkeypatch.setattr(service_mod.settings, "dewey_api_token", "token-1")
    monkeypatch.setattr(service_mod.settings, "dewey_request_timeout_seconds", 5.0)
    monkeypatch.setattr(service_mod.settings, "dewey_verify_ssl", True)

    svc = UrsaResultReturnService(db=object(), tenant_id=tenant_id)
    result = svc.apply(_request(tenant_id))

    assert result.idempotent_replay is True
    assert result.fulfillment_output_euid == "RES-EXISTING"
    assert result.artifact_euids == ["AT-1"]
    assert result.results_set_euid == "RS-EXISTING"
    assert created_results == []
