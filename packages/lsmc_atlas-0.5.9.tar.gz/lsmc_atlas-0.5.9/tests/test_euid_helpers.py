from __future__ import annotations

import pytest
from daylily_tapdb.euid import format_euid

from app.persistence.tapdb.euid_helpers import InvalidEUID, require_valid_euid


def test_require_valid_euid_defaults_to_runtime_sandbox(monkeypatch):
    monkeypatch.delenv("MERIDIAN_ENVIRONMENT", raising=False)
    monkeypatch.delenv("LSMC_ENV", raising=False)
    monkeypatch.delenv("MERIDIAN_SANDBOX_PREFIX", raising=False)

    sandbox_euid = format_euid("GX", 1, sandbox="T")
    assert require_valid_euid(sandbox_euid) == sandbox_euid


def test_require_valid_euid_respects_explicit_runtime_prefix(monkeypatch):
    monkeypatch.setenv("MERIDIAN_ENVIRONMENT", "sandbox")
    monkeypatch.setenv("MERIDIAN_SANDBOX_PREFIX", "S")

    sandbox_euid = format_euid("GX", 1, sandbox="S")
    wrong_prefix = format_euid("GX", 1, sandbox="T")

    assert require_valid_euid(sandbox_euid) == sandbox_euid
    with pytest.raises(InvalidEUID):
        require_valid_euid(wrong_prefix)


def test_require_valid_euid_production_rejects_sandbox(monkeypatch):
    monkeypatch.setenv("MERIDIAN_ENVIRONMENT", "production")
    monkeypatch.setenv("MERIDIAN_SANDBOX_PREFIX", "")

    sandbox_euid = format_euid("GX", 1, sandbox="S")
    with pytest.raises(InvalidEUID):
        require_valid_euid(sandbox_euid)
