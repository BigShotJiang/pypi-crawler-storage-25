"""Security regression tests — batch 2.

Covers:
  SEC-43  File upload size limit (413 on oversized uploads)
  SEC-44  Session periodic DB re-validation (deactivated users evicted)
  NEW-3   SSRF webhook URL validation
"""

import io
import socket
import uuid
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user
from app.auth.rbac import Role
from app.db.engine import get_db
from app.domain.services.webhooks import _validate_webhook_url
from app.main import app
from app.settings import settings

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TENANT = uuid.uuid4()
_SUB = str(uuid.uuid4())


def _internal_user() -> CurrentUser:
    return CurrentUser(
        sub=_SUB,
        email="internal@lsmc.bio",
        name="Internal Tester",
        tenant_id=_TENANT,
        roles=[Role.INTERNAL_USER.value],
    )


# ---------------------------------------------------------------------------
# SEC-43 — File upload size limit
# ---------------------------------------------------------------------------


class TestUploadSizeLimit:
    """POST /api/documents upload must enforce max_upload_size_bytes."""

    def _make_client(self) -> TestClient:
        """Return a TestClient with auth + DB overrides for documents router."""
        from app.auth.dependencies import require_internal

        def _override_db():
            db = MagicMock()
            try:
                yield db
            finally:
                pass

        app.dependency_overrides[get_db] = _override_db
        app.dependency_overrides[get_current_user] = _internal_user
        app.dependency_overrides[require_internal] = _internal_user
        return TestClient(app)

    def _cleanup(self):
        app.dependency_overrides.clear()

    def test_upload_rejects_oversized_file(self):
        """A file larger than max_upload_size_bytes must return 413."""
        client = self._make_client()
        try:
            with patch.object(settings, "max_upload_size_bytes", 100):
                oversized = b"x" * 200
                resp = client.post(
                    "/api/documents",
                    files={"file": ("big.bin", io.BytesIO(oversized), "application/octet-stream")},
                )
                assert resp.status_code == 413, f"Expected 413, got {resp.status_code}"
        finally:
            self._cleanup()

    def test_upload_accepts_file_within_limit(self):
        """A small file must NOT trigger the 413 size guard.

        It may fail downstream (e.g. S3 not configured) but must not be 413.
        """
        client = self._make_client()
        try:
            with patch.object(settings, "max_upload_size_bytes", 1000):
                small = b"hello"
                resp = client.post(
                    "/api/documents",
                    files={"file": ("tiny.txt", io.BytesIO(small), "text/plain")},
                )
                assert resp.status_code != 413, "Small file should not be rejected as too large"
        finally:
            self._cleanup()


# ---------------------------------------------------------------------------
# SEC-44 — Session periodic DB re-validation
# ---------------------------------------------------------------------------


class TestSessionRevalidation:
    """_get_current_user_from_session must re-check DB periodically."""

    def _make_request(self, session_data: dict) -> MagicMock:
        req = MagicMock()
        req.session = dict(session_data)  # mutable copy
        return req

    def test_session_revalidation_clears_deactivated_user(self):
        """Session with stale _last_db_validated and deactivated user is cleared."""
        from app.auth.dependencies import _get_current_user_from_session
        from app.auth.session import get_server_instance_id

        stale_ts = (datetime.utcnow() - timedelta(minutes=10)).isoformat()
        session_data = {
            "user_sub": _SUB,
            "email": "test@example.com",
            "name": "Test",
            "tenant_id": str(_TENANT),
            "roles": [Role.INTERNAL_USER.value],
            "server_instance_id": get_server_instance_id(),
            "_last_db_validated": stale_ts,
        }
        req = self._make_request(session_data)

        # Mock DB to return a deactivated user profile
        fake_profile = MagicMock()
        fake_profile.is_active = False

        fake_result = MagicMock()
        fake_result.scalar_one_or_none.return_value = fake_profile

        fake_db = MagicMock()
        fake_db.execute.return_value = fake_result

        with patch("app.db.engine.SessionLocal", return_value=fake_db):
            result = _get_current_user_from_session(req)

        assert result is None, "Deactivated user session should be cleared"
        assert req.session == {} or "user_sub" not in req.session

    def test_session_revalidation_skips_when_recent(self):
        """Session validated <5 min ago should NOT re-query DB."""
        from app.auth.dependencies import _get_current_user_from_session
        from app.auth.session import get_server_instance_id

        recent_ts = (datetime.utcnow() - timedelta(minutes=1)).isoformat()
        session_data = {
            "user_sub": _SUB,
            "email": "recent@example.com",
            "name": "Recent",
            "tenant_id": str(_TENANT),
            "roles": [Role.INTERNAL_USER.value],
            "server_instance_id": get_server_instance_id(),
            "_last_db_validated": recent_ts,
        }
        req = self._make_request(session_data)

        with patch("app.db.engine.SessionLocal") as mock_session_local:
            result = _get_current_user_from_session(req)

        # SessionLocal should never have been called
        mock_session_local.assert_not_called()
        assert result is not None, "Recent session should return a CurrentUser"
        assert result.email == "recent@example.com"


# ---------------------------------------------------------------------------
# NEW-3 — SSRF webhook URL validation
# ---------------------------------------------------------------------------


class TestWebhookUrlValidation:
    """_validate_webhook_url must block private/loopback/metadata IPs."""

    def test_webhook_url_rejects_private_ip(self):
        with pytest.raises(ValueError, match="restricted"):
            _validate_webhook_url("http://192.168.1.1/hook")

    def test_webhook_url_rejects_loopback(self):
        with pytest.raises(ValueError, match="restricted"):
            _validate_webhook_url("http://127.0.0.1/hook")

    def test_webhook_url_rejects_metadata_endpoint(self):
        with pytest.raises(ValueError, match="restricted"):
            _validate_webhook_url("http://169.254.169.254/latest/meta-data/")

    def test_webhook_url_rejects_non_http_scheme(self):
        with pytest.raises(ValueError, match="scheme"):
            _validate_webhook_url("ftp://example.com/hook")

    def test_webhook_url_accepts_public_url(self):
        """A URL resolving to a public IP should pass validation."""
        fake_addrinfo = [
            (socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, "", ("93.184.216.34", 443)),
        ]
        with patch("app.domain.services.webhooks.socket.getaddrinfo", return_value=fake_addrinfo):
            # Should not raise
            _validate_webhook_url("https://hooks.example.com/webhook")
