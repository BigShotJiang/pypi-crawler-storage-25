"""Web tests for the Atlas accessioning workbench."""

from __future__ import annotations

import uuid
from datetime import date
from urllib.parse import quote

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import (
    CurrentUser,
    get_current_user,
    get_current_user_web,
    require_internal,
    require_read_write_web,
)
from app.auth.middleware import csrf_protect
from app.db.engine import get_db
from app.domain.services.accessioning_workbench import (
    AccessioningWorkbenchService,
    ReceiptRegistrationRequest,
)
from app.domain.services.orgs import SiteService
from app.domain.services.people import PatientCreate, PatientService
from app.domain.services.shipments import (
    ShipmentCreate,
    ShipmentService,
)
from app.domain.services.shipments import (
    TestKitCreate as AtlasTestKitCreate,
)
from app.domain.services.shipments import (
    TestKitService as AtlasTestKitService,
)
from app.domain.services.trfs import (
    TestCreate as AtlasTestCreate,
)
from app.domain.services.trfs import (
    TestService as AtlasTestService,
)
from app.domain.services.trfs import (
    TrfCreate,
    TrfService,
)
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def web_user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="accessioning-web@test.org",
        name="Accessioning Web User",
        tenant_id=tenant_id,
        roles=["INTERNAL_USER"],
    )


@pytest.fixture
def tenant_org(db_session: Session, tenant_id: uuid.UUID):
    return ensure_tapdb_org(
        db_session,
        tenant_id,
        name="accessioning-web-org",
        display_name="Accessioning Web Org",
        site_name="Workbench Site",
        site_code="WB",
    )


@pytest.fixture
def site(tenant_org, db_session: Session):
    return SiteService(db_session).list_by_organization(tenant_org.euid)[0]


@pytest.fixture
def fake_bloom(monkeypatch):
    from app.domain.services import bloom_bridge
    from app.integrations.bloom_client import BloomOperationResult

    class FakeBloomClient:
        def __init__(self):
            self.created_tubes: list[dict[str, object]] = []
            self.accepted_material: list[dict[str, object]] = []

        def create_empty_tube(self, payload, *, idempotency_key=None):
            number = len(self.created_tubes) + 1
            container_euid = f"CNT-WEB-{number:04d}"
            self.created_tubes.append({"payload": payload, "idempotency_key": idempotency_key})
            return BloomOperationResult(
                external_euid=container_euid,
                status="active",
                raw={
                    "container_euid": container_euid,
                    "status": "active",
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

        def register_accepted_material(self, payload, *, idempotency_key=None):
            number = len(self.accepted_material) + 1
            specimen_euid = f"SP-WEB-{number:04d}"
            self.accepted_material.append({"payload": payload, "idempotency_key": idempotency_key})
            return BloomOperationResult(
                external_euid=specimen_euid,
                status="active",
                raw={
                    "specimen_euid": specimen_euid,
                    "container_euid": payload.get("container_euid"),
                    "status": "active",
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

        def move_material_to_queue(
            self,
            container_euid,
            queue_name,
            *,
            metadata=None,
            idempotency_key=None,
        ):
            return {
                "container_euid": container_euid,
                "current_queue": queue_name,
                "metadata": metadata or {},
                "idempotency_key": idempotency_key,
                "idempotent_replay": False,
            }

    fake = FakeBloomClient()

    def _fake_get_client(self, site_id=None):  # noqa: ARG001
        return fake

    monkeypatch.setattr(
        bloom_bridge.ContainerSpecimenBridgeService,
        "_get_bloom_client",
        _fake_get_client,
    )
    return fake


@pytest.fixture
def web_client(db_session: Session, web_user: CurrentUser):
    def override_get_db():
        yield db_session

    def override_user():
        return web_user

    async def override_csrf():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[require_internal] = override_user
    app.dependency_overrides[require_read_write_web] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf

    with TestClient(app) as client:
        yield client

    app.dependency_overrides.clear()


def _service(db_session: Session, tenant_id: uuid.UUID) -> AccessioningWorkbenchService:
    return AccessioningWorkbenchService(db_session, tenant_id)


def _create_patient(db_session: Session, tenant_id: uuid.UUID, site_euid: str, actor_id: uuid.UUID):
    return PatientService(db_session, tenant_id).create(
        PatientCreate(
            first_name="Web",
            last_name="Patient",
            date_of_birth=date(1991, 1, 1),
            mrn="MRN-WEB-1",
            site_id=site_euid,
        ),
        created_by=actor_id,
    )[0]


def _create_trf_and_test(
    db_session: Session,
    tenant_id: uuid.UUID,
    site_euid: str,
    actor_id: uuid.UUID,
    *,
    patient_euid: str,
):
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderPatientLink

    trf, _revision = TrfService(db_session, tenant_id).create(
        TrfCreate(site_id=site_euid),
        tests=[
            AtlasTestCreate(
                product_code="WGS",
                fulfillment_route_codes=["WGS"],
                specimen_type_required="blood-whole",
                site_id=site_euid,
            )
        ],
        patient_links=[OrderPatientLink(patient_euid=patient_euid, role=OrderPatientRole.PROBAND)],
        created_by=actor_id,
    )
    test = AtlasTestService(db_session, tenant_id).list_for_trf(trf.euid)[0][0]
    return trf, test


def _find_node_by_kind(node: dict, kind: str) -> dict | None:
    if node.get("kind") == kind:
        return node
    for child in node.get("children", []):
        found = _find_node_by_kind(child, kind)
        if found is not None:
            return found
    return None


def test_accessioning_dashboard_renders_for_internal_users(
    web_client: TestClient,
    tenant_org,
):
    response = web_client.get("/accessioning")

    assert response.status_code == 200
    assert "Accessioning Workbench" in response.text
    assert "/accessioning" in response.text


def test_receipt_post_redirects_to_combined_mode_work_item(
    web_client: TestClient,
    db_session: Session,
    web_user: CurrentUser,
    tenant_org,
    site,
):
    response = web_client.post(
        "/accessioning/receipt",
        data={
            "mode": "combined",
            "tracking_number": "TRACK-WEB-001",
            "carrier": "UPS",
            "origin_site_id": site.euid,
            "received_by": "web-operator",
            "package_condition": "OK",
        },
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert "mode=combined" in response.headers["location"]

    rows = _service(db_session, web_user.tenant_id).list_queue("PACKAGE_PROCESSING_PENDING")
    assert any(row["shipment_number"] for row in rows)


def test_minimal_receipt_post_redirects_to_minimal_editor(
    web_client: TestClient,
    db_session: Session,
    web_user: CurrentUser,
    tenant_org,
    site,
):
    response = web_client.post(
        "/accessioning/minimal/receipt",
        data={
            "tracking_number": "TRACK-WEB-MINIMAL",
            "carrier": "UPS",
            "origin_site_id": site.euid,
            "received_by": "web-operator",
        },
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert "/accessioning/minimal/work-items/" in response.headers["location"]

    page = web_client.get(response.headers["location"])
    assert page.status_code == 200
    assert "Minimal Accessioning" in page.text
    assert "Done For Now / Send To Review" in page.text


def test_minimal_capture_htmx_flow_and_review_redirect(
    web_client: TestClient,
    db_session: Session,
    web_user: CurrentUser,
    tenant_org,
    site,
):
    actor_id = web_user.sub_uuid or uuid.uuid4()
    svc = _service(db_session, web_user.tenant_id)
    item, _revision = svc.register_receipt(
        ReceiptRegistrationRequest(
            tracking_number="TRACK-WEB-MINIMAL-HTMX",
            carrier="UPS",
            origin_site_id=site.euid,
            received_by="receiver",
        ),
        actor_id=actor_id,
    )

    editor = svc.get_minimal_editor(item.euid)
    response = web_client.post(
        f"/accessioning/minimal/work-items/{item.euid}/nodes/{editor['root_node']['node_id']}/children",
        data={
            "kind": "TestKit",
            "site_euid": site.euid,
            "origin_site_id": site.euid,
        },
        headers={"HX-Request": "true"},
    )
    assert response.status_code == 200
    assert 'id="minimal-editor"' in response.text

    editor = svc.get_minimal_editor(item.euid)
    kit_node = _find_node_by_kind(editor["root_node"], "Kit")
    assert kit_node is not None

    response = web_client.post(
        f"/accessioning/minimal/work-items/{item.euid}/nodes/{kit_node['node_id']}/children",
        data={
            "kind": "TRF",
            "route_code": "WGS",
            "product_code": "WGS",
            "specimen_type_required": "blood-whole",
            "site_euid": site.euid,
        },
        headers={"HX-Request": "true"},
    )
    assert response.status_code == 200
    assert "TRF" in response.text
    assert "WGS" in response.text

    review_response = web_client.post(
        f"/accessioning/minimal/work-items/{item.euid}/review",
        data={},
        follow_redirects=False,
    )
    assert review_response.status_code == 303
    assert (
        review_response.headers["location"]
        == f"/accessioning/work-items/{quote(item.euid, safe='')}?mode=queue"
    )


def test_testkit_pages_show_euid_fallback_when_barcode_is_blank(
    web_client: TestClient,
    db_session: Session,
    web_user: CurrentUser,
    tenant_org,
    site,
):
    kit = AtlasTestKitService(db_session, web_user.tenant_id).create(
        AtlasTestKitCreate(
            kit_barcode=None,
            kit_type="COLLECTION",
            origin_site_id=site.euid,
        ),
        created_by=web_user.sub_uuid,
    )

    detail_page = web_client.get(f"/testkits/{kit.euid}")
    list_page = web_client.get("/testkits")

    assert detail_page.status_code == 200
    assert kit.euid in detail_page.text
    assert "Not yet assigned" in detail_page.text
    assert list_page.status_code == 200
    assert "EUID fallback" in list_page.text


def test_shipment_add_kit_allows_blank_barcode_and_mints_euid(
    web_client: TestClient,
    db_session: Session,
    web_user: CurrentUser,
    tenant_org,
):
    shipment, _revision = ShipmentService(db_session, web_user.tenant_id).create(
        ShipmentCreate(),
        created_by=web_user.sub_uuid,
    )

    response = web_client.post(
        f"/shipments/{shipment.shipment_number}/add-kit",
        data={"kit_barcode": "", "kit_type": "COLLECTION"},
        follow_redirects=False,
    )

    assert response.status_code == 303
    kits = AtlasTestKitService(db_session, web_user.tenant_id).list_kits(
        limit=50, cross_tenant=False
    )
    assert any(kit.kit_barcode is None for kit in kits)


def test_work_item_forms_register_link_and_accept_material(
    web_client: TestClient,
    db_session: Session,
    web_user: CurrentUser,
    tenant_org,
    site,
    fake_bloom,
):
    actor_id = web_user.sub_uuid or uuid.uuid4()
    svc = _service(db_session, web_user.tenant_id)
    patient = _create_patient(db_session, web_user.tenant_id, site.euid, actor_id)
    trf, test = _create_trf_and_test(
        db_session,
        web_user.tenant_id,
        site.euid,
        actor_id,
        patient_euid=patient.euid,
    )
    item, _revision = svc.register_receipt(
        ReceiptRegistrationRequest(
            tracking_number="TRACK-WEB-ACCEPT",
            carrier="UPS",
            origin_site_id=site.euid,
            received_by="receiver",
        ),
        actor_id=actor_id,
    )

    response = web_client.post(
        f"/accessioning/work-items/{item.euid}/contents",
        data={
            "mode": "queue",
            "content_type": "Tube",
            "site_euid": site.euid,
            "collection_site_euid": site.euid,
            "label_print_requested": "true",
            "label_print_context": "bench-printer-web",
            "tube_image_metadata": "tube-web-front.jpg",
            "package_image_metadata": "package-web-top.jpg",
            "registration_token": "web-tube-1",
        },
        follow_redirects=False,
    )
    assert response.status_code == 303

    response = web_client.post(
        f"/accessioning/work-items/{item.euid}/links",
        data={
            "mode": "queue",
            "trf_euid": trf.euid,
            "test_euid": test.euid,
            "patient_euid": patient.euid,
            "collection_site_euid": site.euid,
            "role_lines": f"{patient.euid}:PROBAND",
        },
        follow_redirects=False,
    )
    assert response.status_code == 303

    response = web_client.post(
        f"/accessioning/work-items/{item.euid}/outcome",
        data={
            "mode": "queue",
            "outcome": "ACCEPTED",
            "patient_euid": patient.euid,
            "starting_queue": "extraction_prod",
        },
        follow_redirects=False,
    )
    assert response.status_code == 303

    detail = svc.get_work_item(item.euid)
    page = web_client.get(f"/accessioning/work-items/{item.euid}")

    assert detail["outcome_summary"]["outcome"] == "ACCEPTED"
    assert detail["outcome_summary"]["accepted"] is True
    assert len(fake_bloom.accepted_material) == 1
    assert page.status_code == 200
    assert test.euid in page.text
    assert "bench-printer-web" in page.text
    assert "tube-web-front.jpg" in page.text
    assert "package-web-top.jpg" in page.text
