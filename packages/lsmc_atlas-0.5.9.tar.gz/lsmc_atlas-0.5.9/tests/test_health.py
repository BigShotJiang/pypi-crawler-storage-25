"""Tests for Atlas health and observability endpoints."""

import pytest
from fastapi.testclient import TestClient

from app.db.engine import get_db
from app.main import app
from app.settings import settings


@pytest.fixture
def client(db_session) -> TestClient:
    """Create a test client with DB override for readiness probes."""

    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.mark.parametrize("path", ["/healthz", "/readyz"])
def test_public_probe_endpoints(client: TestClient, path: str) -> None:
    """Probe endpoints remain unauthenticated for deploy/runtime checks."""
    response = client.get(path)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "version" in data


def test_structured_health_requires_auth(client: TestClient) -> None:
    response = client.get("/health")
    assert response.status_code == 401


def test_structured_health_accepts_service_token(client: TestClient) -> None:
    response = client.get(
        "/health",
        headers={"Authorization": f"Bearer {settings.internal_api_key}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["service"] == "atlas"
    assert "projection" in data
    assert data["projection"]["state"] == "ready"


def test_global_healthcheck_route_removed(client: TestClient) -> None:
    """Atlas no longer exposes cross-service aggregation; Kahlo owns that surface."""
    assert client.get("/global_healthcheck").status_code == 404
    assert client.get("/global_healthcheck?type=json").status_code == 404
