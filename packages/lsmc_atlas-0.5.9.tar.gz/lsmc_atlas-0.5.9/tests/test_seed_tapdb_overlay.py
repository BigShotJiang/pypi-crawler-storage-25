from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest

from scripts import seed_tapdb_overlay


class _FakeOrgService:
    def __init__(self, existing=None):
        self._existing = list(existing or [])
        self.created: list[object] = []

    def list_all(self, active_only=False):
        _ = active_only
        return [org for org, _rev in self._existing]

    def get_with_revision(self, org_id):
        for org, rev in self._existing:
            if org.euid == org_id:
                return (org, rev)
        for created in self.created:
            if created.euid == org_id:
                rev = SimpleNamespace(name=created.name)
                return (created, rev)
        return None

    def create(self, payload, created_by=None):
        _ = created_by
        created = SimpleNamespace(euid="ORG-1", uid=payload.uid, name=payload.name)
        self.created.append(created)
        return created


class _FakeSiteService:
    def __init__(self):
        self.created: list[object] = []

    def list_by_organization(self, _org_id, active_only=False):
        _ = active_only
        return []

    def create(self, payload, created_by=None):
        _ = created_by
        self.created.append(payload)
        return payload


def test_ensure_orgs_uses_requested_tenant_uuid(monkeypatch):
    org_service = _FakeOrgService()
    site_service = _FakeSiteService()
    monkeypatch.setattr(seed_tapdb_overlay, "OrganizationService", lambda _db: org_service)
    monkeypatch.setattr(seed_tapdb_overlay, "SiteService", lambda _db: site_service)

    tenant_uuid = uuid.UUID("44444444-4444-4444-4444-444444444444")
    payload = {
        "organizations": [
            {
                "name": "lsmc-default-org",
                "display_name": "LSMC Default Org",
                "initial_site": {"name": "Default Site", "site_code": "DEFAULT"},
            }
        ]
    }

    orgs = seed_tapdb_overlay._ensure_orgs(object(), payload, tenant_uuid=tenant_uuid)

    assert len(orgs) == 1
    assert org_service.created[0].uid == tenant_uuid


def test_ensure_orgs_rejects_existing_name_with_different_tenant_uuid(monkeypatch):
    existing_uuid = uuid.UUID("55555555-5555-5555-5555-555555555555")
    requested_uuid = uuid.UUID("66666666-6666-6666-6666-666666666666")
    org_service = _FakeOrgService(
        existing=[
            (
                SimpleNamespace(euid="ORG-EXISTING", uid=existing_uuid),
                SimpleNamespace(name="lsmc-default-org"),
            )
        ]
    )
    site_service = _FakeSiteService()
    monkeypatch.setattr(seed_tapdb_overlay, "OrganizationService", lambda _db: org_service)
    monkeypatch.setattr(seed_tapdb_overlay, "SiteService", lambda _db: site_service)

    payload = {
        "organizations": [
            {
                "name": "lsmc-default-org",
                "display_name": "LSMC Default Org",
                "initial_site": {"name": "Default Site", "site_code": "DEFAULT"},
            }
        ]
    }

    with pytest.raises(RuntimeError, match="already exists with tenant UUID"):
        seed_tapdb_overlay._ensure_orgs(object(), payload, tenant_uuid=requested_uuid)
