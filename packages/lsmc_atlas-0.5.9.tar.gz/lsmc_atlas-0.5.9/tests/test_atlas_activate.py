"""Behavior tests for the atlas activation script."""

from __future__ import annotations

import os
import stat
import subprocess
from pathlib import Path


def _run_source(script: Path, *, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["/bin/bash", "--noprofile", "--norc", "-lc", f'source "{script}"'],
        cwd=script.parent,
        env=env,
        capture_output=True,
        text=True,
    )


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


def test_activate_hard_fails_without_conda() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script = repo_root / "activate"
    env = os.environ.copy()
    env["PATH"] = "/usr/bin:/bin"
    env.pop("CONDA_DEFAULT_ENV", None)
    env.pop("CONDA_PREFIX", None)

    result = _run_source(script, env=env)

    assert result.returncode != 0
    assert "Atlas activation did not select the expected conda environment." in result.stdout
    assert (
        "Conda not found." in result.stdout
        or "Failed to create conda environment." in result.stdout
    )


def test_activate_hard_fails_when_conda_does_not_activate_env(tmp_path: Path) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script = repo_root / "activate"
    fake_conda_base = tmp_path / "conda-base"
    fake_conda_profile = fake_conda_base / "etc" / "profile.d"
    fake_conda_profile.mkdir(parents=True)
    (fake_conda_profile / "conda.sh").write_text("# fake conda init\n", encoding="utf-8")

    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    fake_conda = fake_bin / "conda"
    _write_executable(
        fake_conda,
        """#!/bin/sh
if [ "$1" = "info" ] && [ "$2" = "--base" ]; then
  printf '%s\\n' "$FAKE_CONDA_BASE"
  exit 0
fi
if [ "$1" = "info" ] && [ "$2" = "--envs" ]; then
  printf 'base                  *  /tmp/base\\n'
  printf 'LSMC_ATLAS               /tmp/envs/LSMC_ATLAS\\n'
  exit 0
fi
if [ "$1" = "activate" ] && [ "$2" = "LSMC_ATLAS" ]; then
  exit 0
fi
if [ "$1" = "env" ] && [ "$2" = "create" ]; then
  exit 0
fi
exit 0
""",
    )

    env = os.environ.copy()
    env["FAKE_CONDA_BASE"] = str(fake_conda_base)
    env["PATH"] = f"{fake_bin}:/usr/bin:/bin"
    env.pop("CONDA_DEFAULT_ENV", None)
    env.pop("CONDA_PREFIX", None)

    result = _run_source(script, env=env)

    assert result.returncode != 0
    assert "Atlas activation did not select the expected conda environment." in result.stdout
    assert "CONDA_DEFAULT_ENV=<unset>" in result.stdout
