"""Coverage-focused tests for Atlas CLI helper modules."""

from __future__ import annotations

import os
from pathlib import Path
from types import SimpleNamespace

import pytest
import typer

from app.auth import cognito as cognito_auth
from app.cli import quality as quality_cli
from app.cli import server as server_cli
from app.cli import test as test_cli


def _proc_result(code: int = 0) -> SimpleNamespace:
    return SimpleNamespace(returncode=code)


def test_quality_lint_adds_fix_flag(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []

    def fake_run(cmd: list[str], **_kwargs: object) -> SimpleNamespace:
        calls.append(cmd)
        return _proc_result(0)

    monkeypatch.setattr(quality_cli.subprocess, "run", fake_run)

    with pytest.raises(typer.Exit) as exc:
        quality_cli.lint(fix=True)

    assert exc.value.exit_code == 0
    assert calls[0][-1] == "--fix"


def test_quality_format_runs_fixup_when_success(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[list[str], dict[str, object]]] = []

    def fake_run(cmd: list[str], **kwargs: object) -> SimpleNamespace:
        calls.append((cmd, kwargs))
        return _proc_result(0)

    monkeypatch.setattr(quality_cli.subprocess, "run", fake_run)

    with pytest.raises(typer.Exit) as exc:
        quality_cli.format_code(check=False)

    assert exc.value.exit_code == 0
    assert len(calls) == 2
    assert "format" in calls[0][0]
    assert calls[1][0][:5] == [quality_cli.sys.executable, "-m", "ruff", "check", "--fix"]
    assert calls[1][1]["capture_output"] is True


def test_quality_format_check_only_skips_fixup(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []
    monkeypatch.setattr(
        quality_cli.subprocess,
        "run",
        lambda cmd, **_kwargs: calls.append(cmd) or _proc_result(0),
    )

    with pytest.raises(typer.Exit) as exc:
        quality_cli.format_code(check=True)

    assert exc.value.exit_code == 0
    assert len(calls) == 1
    assert calls[0][-1] == "--check"


def test_quality_check_all_reports_failures(monkeypatch: pytest.MonkeyPatch) -> None:
    results = iter([_proc_result(0), _proc_result(1), _proc_result(0)])
    monkeypatch.setattr(quality_cli.subprocess, "run", lambda *_args, **_kwargs: next(results))

    with pytest.raises(typer.Exit) as exc:
        quality_cli.check_all()

    assert exc.value.exit_code == 1


def test_quality_templates_reformat_flag(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []
    monkeypatch.setattr(
        quality_cli.subprocess,
        "run",
        lambda cmd, **_kwargs: calls.append(cmd) or _proc_result(0),
    )

    with pytest.raises(typer.Exit) as exc:
        quality_cli.templates(fix=True)

    assert exc.value.exit_code == 0
    assert calls[0][-1] == "--reformat"


def test_test_run_builds_expected_args(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []
    monkeypatch.setattr(
        test_cli.subprocess,
        "run",
        lambda cmd, **_kwargs: calls.append(cmd) or _proc_result(0),
    )

    with pytest.raises(typer.Exit) as exc:
        test_cli.run(verbose=False, pattern="auth", path="tests/test_auth.py")

    assert exc.value.exit_code == 0
    cmd = calls[0]
    assert cmd[:3] == [test_cli.sys.executable, "-m", "pytest"]
    assert "tests/test_auth.py" in cmd
    assert "--tb=short" in cmd
    assert cmd[-2:] == ["-k", "auth"]


def test_test_coverage_adds_html_and_unit_markers(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[list[str]] = []
    monkeypatch.setattr(
        test_cli.subprocess,
        "run",
        lambda cmd, **_kwargs: calls.append(cmd) or _proc_result(0),
    )

    with pytest.raises(typer.Exit) as exc:
        test_cli.coverage(html=True, unit_only=True)

    assert exc.value.exit_code == 0
    cmd = calls[0]
    assert "--cov-report=html" in cmd
    assert "-m" in cmd
    assert "not db and not postgres" in cmd


def test_test_watch_handles_missing_pytest_watch(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_run(*_args: object, **_kwargs: object) -> None:
        raise FileNotFoundError

    monkeypatch.setattr(test_cli.subprocess, "run", fake_run)

    with pytest.raises(typer.Exit) as exc:
        test_cli.watch(pattern="")

    assert exc.value.exit_code == 1


def test_server_source_env_file_loads_values(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    env_file = tmp_path / ".env"
    env_file.write_text("A=1\nB='two'\n# comment\n", encoding="utf-8")

    monkeypatch.setattr(server_cli, "PROJECT_ROOT", tmp_path)
    monkeypatch.delenv("A", raising=False)
    monkeypatch.delenv("B", raising=False)

    assert server_cli._source_env_file() is True
    assert os.environ["A"] == "1"
    assert os.environ["B"] == "two"


def test_server_get_pid_clears_stale_pid_file(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    pid_file = tmp_path / "server.pid"
    pid_file.write_text("777", encoding="utf-8")
    monkeypatch.setattr(server_cli, "PID_FILE", pid_file)

    def fake_kill(_pid: int, _sig: int) -> None:
        raise ProcessLookupError

    monkeypatch.setattr(server_cli.os, "kill", fake_kill)

    assert server_cli._get_pid(pid_file) is None
    assert not pid_file.exists()


def test_server_get_latest_log_returns_newest(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setattr(server_cli, "LOG_DIR", tmp_path)
    (tmp_path / "server_20240101_000000.log").write_text("old", encoding="utf-8")
    newest = tmp_path / "server_20240102_000000.log"
    newest.write_text("new", encoding="utf-8")

    assert server_cli._get_latest_log() == newest


def test_server_stop_handles_no_running_server(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(server_cli, "_get_pid", lambda _pid_file: None)
    server_cli.stop()


def test_server_stop_permission_error_exits(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(server_cli, "_get_pid", lambda _pid_file: 123)

    def fake_kill(_pid: int, _sig: int) -> None:
        raise PermissionError

    monkeypatch.setattr(server_cli.os, "kill", fake_kill)

    with pytest.raises(typer.Exit) as exc:
        server_cli.stop()

    assert exc.value.exit_code == 1


def test_server_validate_login_url_flags_invalid_scheme(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        cognito_auth,
        "build_login_url",
        lambda **_kwargs: (
            "ftp://example.com/oauth2/authorize?client_id=x&redirect_uri=https://localhost:8915/auth/callback"
        ),
    )

    issues = server_cli._validate_generated_login_authorize_url(8915)
    assert any("http/https" in issue for issue in issues)


def test_server_validate_login_url_flags_missing_client_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        cognito_auth,
        "build_login_url",
        lambda **_kwargs: (
            "https://example.com/oauth2/authorize?redirect_uri=https://localhost:8915/auth/callback"
        ),
    )

    issues = server_cli._validate_generated_login_authorize_url(8915)
    assert any("client_id" in issue for issue in issues)
