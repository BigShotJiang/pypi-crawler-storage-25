"""API contract tests for Atlas graph viewer routes."""

from __future__ import annotations

import uuid

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user
from app.auth.rbac import Role
from app.db.engine import get_db
from app.domain.services.graph_viewer import GraphObjectNotFoundError, GraphPermissionError
from app.main import app


class DummyGraphService:
    """Deterministic fake graph service for route tests."""

    init_calls: list[dict[str, str | bool]] = []

    def __init__(self, _db, tenant_id, *, can_cross_tenant):
        self.tenant_id = tenant_id
        self.can_cross_tenant = can_cross_tenant
        DummyGraphService.init_calls.append(
            {
                "tenant_id": str(tenant_id),
                "can_cross_tenant": bool(can_cross_tenant),
            }
        )

    def get_graph_data(self, *, start_euid, depth, requested_tenant_id, projection="raw"):
        if (
            requested_tenant_id is not None
            and requested_tenant_id != self.tenant_id
            and not self.can_cross_tenant
        ):
            raise GraphPermissionError("Cross-tenant graph access requires cross_tenant:read")

        if start_euid == "UNKNOWN":
            return {
                "elements": {"nodes": [], "edges": []},
                "meta": {
                    "start_euid": start_euid,
                    "depth": depth,
                    "tenant_id": str(requested_tenant_id or self.tenant_id),
                    "node_count": 0,
                    "edge_count": 0,
                    "truncated": False,
                },
            }

        return {
            "elements": {
                "nodes": [
                    {
                        "data": {
                            "id": "PAT-1",
                            "euid": "PAT-1",
                            "name": "Patient One",
                            "type": "people",
                            "obj_type": "people",
                            "category": "atlas",
                            "subtype": "patient",
                            "version": "1.0",
                            "bstatus": "active",
                            "color": "#8B00FF",
                        }
                    }
                ],
                "edges": [
                    {
                        "data": {
                            "id": "LIN-1",
                            "source": "KIT-1",
                            "target": "PAT-1",
                            "relationship_type": "belongs_to",
                        }
                    }
                ],
            },
            "meta": {
                "start_euid": start_euid,
                "depth": depth,
                "projection": projection,
                "tenant_id": str(requested_tenant_id or self.tenant_id),
                "node_count": 1,
                "edge_count": 1,
                "truncated": False,
            },
        }

    def get_object_detail(self, *, euid, requested_tenant_id):
        if (
            requested_tenant_id is not None
            and requested_tenant_id != self.tenant_id
            and not self.can_cross_tenant
        ):
            raise GraphPermissionError("Cross-tenant graph access requires cross_tenant:read")

        if euid == "missing":
            raise GraphObjectNotFoundError("Object not found: missing")

        if euid == "LIN-1":
            return {
                "record_type": "lineage",
                "uuid": "2",
                "euid": "LIN-1",
                "name": "Lineage",
                "type": "lineage",
                "obj_type": "lineage",
                "category": "lineage",
                "subtype": "lineage",
                "version": "1.0",
                "bstatus": "active",
                "json_addl": {},
                "created_dt": "2026-03-02T00:00:00+00:00",
                "modified_dt": "2026-03-02T00:00:00+00:00",
                "source": "KIT-1",
                "target": "PAT-1",
                "relationship_type": "belongs_to",
            }

        return {
            "record_type": "instance",
            "uuid": "1",
            "euid": euid,
            "name": "Node",
            "type": "people",
            "obj_type": "people",
            "category": "atlas",
            "subtype": "patient",
            "version": "1.0",
            "bstatus": "active",
            "json_addl": {"a": 1},
            "created_dt": "2026-03-02T00:00:00+00:00",
            "modified_dt": "2026-03-02T00:00:00+00:00",
            "external_refs": [
                {
                    "label": "bloom:specimen:BL-SP-1",
                    "system": "bloom",
                    "root_euid": "BL-SP-1",
                    "external_object_id": "EXB-1",
                    "tenant_id": "SITE-1",
                    "href": "https://bloom.local/euid_details?euid=BL-SP-1",
                    "graph_expandable": True,
                    "ref_index": 0,
                }
            ],
        }

    def get_external_graph(self, *, source_euid, ref_index, depth, requested_tenant_id):
        if source_euid == "missing":
            raise GraphObjectNotFoundError("Object not found: missing")
        if ref_index == 9:
            raise GraphPermissionError("External graph access denied")
        return {
            "elements": {
                "nodes": [
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::BL-SP-1",
                            "remote_euid": "BL-SP-1",
                            "is_external": True,
                        }
                    }
                ],
                "edges": [
                    {
                        "data": {
                            "id": "bridge::PAT-1::bloom::SITE-1::BL-SP-1",
                            "is_external_bridge": True,
                        }
                    }
                ],
            },
            "meta": {"source_euid": source_euid, "ref_index": ref_index, "depth": depth},
        }

    def get_external_object_detail(self, *, source_euid, ref_index, euid, requested_tenant_id):
        if source_euid == "missing":
            raise GraphObjectNotFoundError("Object not found: missing")
        if ref_index == 9:
            raise GraphPermissionError("External graph access denied")
        return {"euid": euid, "external_refs": []}


@pytest.fixture(autouse=True)
def _clear_overrides():
    DummyGraphService.init_calls.clear()
    yield
    app.dependency_overrides.clear()


def _make_user(*roles: Role) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="graph-test@lsmc.bio",
        name="Graph Test",
        tenant_id=uuid.uuid4(),
        roles=[role.value for role in roles],
    )


def _client_with_user(user: CurrentUser) -> TestClient:
    def override_db():
        yield object()

    def override_user():
        return user

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_current_user] = override_user
    return TestClient(app)


@pytest.mark.db
def test_graph_data_schema(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/data?start_euid=PAT-1&depth=4")
    assert response.status_code == 200
    body = response.json()
    assert body["elements"]["nodes"][0]["data"]["id"] == "PAT-1"
    assert body["elements"]["edges"][0]["data"]["source"] == "KIT-1"
    assert body["meta"]["depth"] == 4
    assert body["meta"]["projection"] == "story"


@pytest.mark.db
def test_graph_data_raw_projection_passthrough(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/data?start_euid=PAT-1&depth=4&projection=raw")
    assert response.status_code == 200
    body = response.json()
    assert body["meta"]["projection"] == "raw"


@pytest.mark.db
def test_graph_data_unknown_start_returns_empty(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/data?start_euid=UNKNOWN")
    assert response.status_code == 200
    body = response.json()
    assert body["elements"]["nodes"] == []
    assert body["elements"]["edges"] == []


@pytest.mark.db
def test_graph_data_depth_bounds_enforced_422(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    assert client.get("/api/graph/data?depth=0").status_code == 422
    assert client.get("/api/graph/data?depth=11").status_code == 422


@pytest.mark.db
def test_graph_data_cross_tenant_without_permission_403(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    user = _make_user(Role.EXTERNAL_USER)
    client = _client_with_user(user)

    other_tenant = uuid.uuid4()
    response = client.get(f"/api/graph/data?tenant_id={other_tenant}")
    assert response.status_code == 403


@pytest.mark.db
def test_graph_data_cross_tenant_with_permission_works(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    user = _make_user(Role.INTERNAL_USER)
    client = _client_with_user(user)

    other_tenant = uuid.uuid4()
    response = client.get(f"/api/graph/data?tenant_id={other_tenant}")
    assert response.status_code == 200
    assert DummyGraphService.init_calls[-1]["can_cross_tenant"] is True


@pytest.mark.db
def test_graph_object_instance_payload(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/object/PAT-1")
    assert response.status_code == 200
    body = response.json()
    assert body["record_type"] == "instance"
    assert body["euid"] == "PAT-1"
    assert "json_addl" in body


@pytest.mark.db
def test_graph_object_lineage_payload(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/object/LIN-1")
    assert response.status_code == 200
    body = response.json()
    assert body["record_type"] == "lineage"
    assert body["source"] == "KIT-1"
    assert body["target"] == "PAT-1"
    assert body["relationship_type"] == "belongs_to"


@pytest.mark.db
def test_graph_object_unknown_404(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/object/missing")
    assert response.status_code == 404


def test_graph_api_requires_auth():
    client = TestClient(app)
    response = client.get("/api/graph/data")
    assert response.status_code == 401


@pytest.mark.db
def test_graph_object_instance_payload_includes_external_refs(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/object/PAT-1")
    assert response.status_code == 200
    body = response.json()
    assert body["external_refs"][0]["system"] == "bloom"
    assert body["external_refs"][0]["external_object_id"] == "EXB-1"
    assert body["external_refs"][0]["ref_index"] == 0


@pytest.mark.db
def test_external_graph_merge_route(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/external?source_euid=PAT-1&ref_index=0&depth=3")
    assert response.status_code == 200
    body = response.json()
    assert body["elements"]["nodes"][0]["data"]["is_external"] is True
    assert body["elements"]["edges"][0]["data"]["is_external_bridge"] is True


@pytest.mark.db
def test_external_graph_object_proxy_route(monkeypatch):
    monkeypatch.setattr("app.api.routes.graph.GraphViewerService", DummyGraphService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/api/graph/external/object?source_euid=PAT-1&ref_index=0&euid=BL-SP-1")
    assert response.status_code == 200
    assert response.json()["euid"] == "BL-SP-1"
