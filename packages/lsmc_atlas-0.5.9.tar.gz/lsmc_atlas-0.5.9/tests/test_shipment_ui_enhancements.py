from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def other_tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def web_user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="shipment-ui@test.org",
        name="Shipment UI Tester",
        tenant_id=tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def other_web_user(other_tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="other-shipment-ui@test.org",
        name="Other Shipment UI Tester",
        tenant_id=other_tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def setup_tenant(db_session: Session, tenant_id: uuid.UUID):
    ensure_tapdb_org(
        db_session,
        tenant_id,
        name="shipment-ui-org",
        display_name="Shipment UI Org",
    )
    db_session.flush()


@pytest.fixture
def setup_other_tenant(db_session: Session, other_tenant_id: uuid.UUID):
    ensure_tapdb_org(
        db_session,
        other_tenant_id,
        name="shipment-ui-other-org",
        display_name="Shipment UI Other Org",
    )
    db_session.flush()


@pytest.fixture
def fake_bloom(monkeypatch: pytest.MonkeyPatch):
    from app.domain.services import bloom_bridge
    from app.integrations.bloom_client import BloomOperationResult

    class FakeBloomClient:
        def __init__(self):
            self.created_containers = 0

        def create_object(self, payload, *, idempotency_key=None):
            return self.create_empty_tube(payload, idempotency_key=idempotency_key)

        def create_empty_tube(self, payload, *, idempotency_key=None):
            self.created_containers += 1
            container_euid = f"CNT-{1000 + self.created_containers}"
            return BloomOperationResult(
                external_euid=container_euid,
                status="active",
                raw={
                    "container_euid": container_euid,
                    "status": "active",
                    "created": True,
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

    fake = FakeBloomClient()

    def _fake_get_client(self, site_id=None):  # noqa: ARG001
        return fake

    monkeypatch.setattr(
        bloom_bridge.ContainerSpecimenBridgeService,
        "_get_bloom_client",
        _fake_get_client,
    )
    return fake


def _client(db_session: Session, user: CurrentUser) -> TestClient:
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        yield db_session

    def override_user():
        return user

    async def override_csrf():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    return TestClient(app)


def _create_patient(db: Session, tenant_id: uuid.UUID, actor: uuid.UUID | None):
    from datetime import date

    from app.domain.services.people import PatientCreate, PatientService

    return PatientService(db, tenant_id, actor).create(
        PatientCreate(first_name="Pat", last_name="Ient", date_of_birth=date(1990, 1, 1)),
        created_by=actor,
    )[0]


def _create_trf_and_test(
    db: Session,
    tenant_id: uuid.UUID,
    actor: uuid.UUID | None,
    *,
    patient_euid: str | None = None,
):
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderPatientLink
    from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService

    links = []
    if patient_euid:
        links = [OrderPatientLink(patient_euid=patient_euid, role=OrderPatientRole.PROBAND)]

    trf, _trf_rev = TrfService(db, tenant_id).create(
        TrfCreate(order_type="CLINICAL"),
        tests=[
            TestCreate(
                product_code="WGS-001",
                fulfillment_route_codes=["WGS"],
                specimen_type_required="blood-whole",
            )
        ],
        patient_links=links,
        created_by=actor,
    )
    test = TestService(db, tenant_id).list_for_trf(trf.euid)[0][0]
    return trf, test


def _create_shipment(
    db: Session,
    tenant_id: uuid.UUID,
    actor: uuid.UUID | None,
    *,
    tracking_number: str = "395579987149",
):
    from app.domain.services.shipments import ShipmentCreate, ShipmentService

    return ShipmentService(db, tenant_id).create(
        ShipmentCreate(carrier="FedEx", tracking_number=tracking_number),
        created_by=actor,
    )[0]


def _create_testkit(db: Session, tenant_id: uuid.UUID, actor: uuid.UUID | None):
    from app.domain.services.shipments import TestKitCreate, TestKitService

    return TestKitService(db, tenant_id).create(
        TestKitCreate(kit_barcode=f"KIT-{uuid.uuid4().hex[:8]}", kit_type="COLLECTION"),
        created_by=actor,
    )


def _create_direct_collection_tube(
    db: Session,
    tenant_id: uuid.UUID,
    actor: uuid.UUID | None,
    *,
    shipment_euid: str,
    external_euid: str,
):
    from app.domain.services.external_objects import (
        ExternalObjectRelationCreate,
        ExternalObjectService,
        ExternalObjectUpsert,
    )

    service = ExternalObjectService(db, tenant_id)
    external_object = service.upsert_external_object(
        ExternalObjectUpsert(
            provider="bloom",
            object_type="container",
            external_euid=external_euid,
            status="active",
            metadata={"container_template_code": "content/container/blood-whole/1.0"},
        ),
        actor_id=actor,
    )
    service.create_relation(
        ExternalObjectRelationCreate(
            external_object_id=external_object.euid,
            relation_type="belongs_to_shipment",
            local_entity_type="Shipment",
            local_entity_id=shipment_euid,
        ),
        actor_id=actor,
    )
    db.flush()
    return external_object


def _seed_shipment_hierarchy(
    db: Session,
    tenant_id: uuid.UUID,
    actor: uuid.UUID | None,
) -> dict[str, object]:
    from app.domain.enums import ShipmentStatus
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest
    from app.domain.services.shipments import ShipmentService
    from app.domain.services.testkit_trf_links import TestKitTrfLinkService

    patient = _create_patient(db, tenant_id, actor)
    shipment = _create_shipment(db, tenant_id, actor)
    kit = _create_testkit(db, tenant_id, actor)
    ShipmentService(db, tenant_id).add_item(
        shipment.euid,
        "TestKit",
        kit.euid,
        reason="Attach kit to shipment",
        created_by=actor,
    )

    kit_trf, kit_test = _create_trf_and_test(db, tenant_id, actor, patient_euid=patient.euid)
    loose_trf, loose_test = _create_trf_and_test(db, tenant_id, actor, patient_euid=patient.euid)
    TestKitTrfLinkService(db, tenant_id).link_trf(
        testkit_euid=kit.euid,
        trf_euid=kit_trf.euid,
        created_by=actor,
    )
    ShipmentService(db, tenant_id).add_item(
        shipment.euid,
        "TRF",
        loose_trf.euid,
        reason="Attach loose TRF to shipment",
        created_by=actor,
    )

    bridge = ContainerSpecimenBridgeService(db, tenant_id)
    kit_tube = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=kit_test.euid,
            testkit_euid=kit.euid,
            idempotency_key=f"kit-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    loose_tube = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=loose_test.euid,
            shipment_euid=shipment.euid,
            idempotency_key=f"loose-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    direct_tube = _create_direct_collection_tube(
        db,
        tenant_id,
        actor,
        shipment_euid=shipment.euid,
        external_euid="CNT-DIRECT-001",
    )

    ShipmentService(db, tenant_id).change_status(
        shipment.euid,
        ShipmentStatus.IN_TRANSIT,
        reason="UI regression test",
        updated_by=actor,
    )
    db.commit()
    return {
        "shipment": shipment,
        "kit": kit,
        "kit_trf": kit_trf,
        "kit_test": kit_test,
        "kit_tube": kit_tube,
        "loose_trf": loose_trf,
        "loose_test": loose_test,
        "loose_tube": loose_tube,
        "direct_tube": direct_tube,
    }


def test_shipments_list_renders_recursive_collection_counts(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    hierarchy = _seed_shipment_hierarchy(db_session, web_user.tenant_id, web_user.sub_uuid)

    client = _client(db_session, web_user)
    try:
        response = client.get("/shipments")
        assert response.status_code == 200
        assert hierarchy["shipment"].shipment_number in response.text
        shipment_row = response.text.split(hierarchy["shipment"].shipment_number, 1)[1]
        assert "1 kit" in shipment_row
        assert "(3 collections)" in shipment_row
    finally:
        app.dependency_overrides.clear()


def test_testkits_list_renders_collections_column(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    hierarchy = _seed_shipment_hierarchy(db_session, web_user.tenant_id, web_user.sub_uuid)

    client = _client(db_session, web_user)
    try:
        response = client.get("/testkits")
        assert response.status_code == 200
        assert "<th>Collections</th>" in response.text
        assert hierarchy["kit"].euid in response.text
        assert 'data-sort-value="1">1</td>' in response.text
    finally:
        app.dependency_overrides.clear()


def test_shipment_detail_renders_semantic_contents_and_refresh_for_external_viewer(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    hierarchy = _seed_shipment_hierarchy(db_session, web_user.tenant_id, web_user.sub_uuid)
    shipment = hierarchy["shipment"]

    client = _client(db_session, web_user)
    try:
        response = client.get(f"/shipments/{shipment.shipment_number}")
        assert response.status_code == 200
        assert shipment.euid in response.text
        assert "(395579987149)" in response.text
        assert "IN TRANSIT" in response.text
        assert "Refresh</button>" in response.text
        assert "Test Kits (1)" in response.text
        assert "TRFs (1)" in response.text
        assert "Collection Tubes (1)" in response.text
        assert hierarchy["kit"].euid in response.text
        assert hierarchy["loose_trf"].euid in response.text
        assert hierarchy["direct_tube"].external_euid in response.text

        test_kits_section = response.text.split("Test Kits (1)", 1)[1].split("TRFs (1)", 1)[0]
        assert "395579987149" not in test_kits_section
        assert hierarchy["kit"].euid in test_kits_section
    finally:
        app.dependency_overrides.clear()


def test_tracking_update_allows_authenticated_shipment_viewer(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    monkeypatch: pytest.MonkeyPatch,
):
    from app.domain.services import fedex_tracking as fedex_module

    shipment = _create_shipment(db_session, web_user.tenant_id, web_user.sub_uuid)
    db_session.commit()

    captured: dict[str, str] = {}

    class FakeTrackingService:
        def __init__(self, db, tenant_id, actor_id):  # noqa: ARG002
            pass

        def is_available(self):
            return True

        def update_shipment_tracking(self, shipment_id, tracking_number):
            captured["shipment_id"] = shipment_id
            captured["tracking_number"] = tracking_number
            return fedex_module.TrackingSummary(
                tracking_number=tracking_number,
                delivery_status="IN_TRANSIT",
            )

    monkeypatch.setattr("app.api.routes.tracking.FedExTrackingService", FakeTrackingService)

    client = _client(db_session, web_user)
    try:
        response = client.post(
            "/api/tracking/shipment/update",
            json={
                "shipment_id": shipment.euid,
                "tracking_number": "395579987149",
            },
        )
        assert response.status_code == 200, response.text
        assert captured == {
            "shipment_id": shipment.euid,
            "tracking_number": "395579987149",
        }
    finally:
        app.dependency_overrides.clear()


def test_tracking_update_rejects_unrelated_tenant(
    db_session: Session,
    web_user: CurrentUser,
    other_web_user: CurrentUser,
    setup_tenant,
    setup_other_tenant,
):
    shipment = _create_shipment(db_session, web_user.tenant_id, web_user.sub_uuid)
    db_session.commit()

    client = _client(db_session, other_web_user)
    try:
        response = client.post(
            "/api/tracking/shipment/update",
            json={
                "shipment_id": shipment.euid,
                "tracking_number": "395579987149",
            },
        )
        assert response.status_code == 404
    finally:
        app.dependency_overrides.clear()


def test_shipment_selector_orders_by_numeric_creation_not_euid(
    monkeypatch: pytest.MonkeyPatch,
):
    from app.web.routes import pages

    class FakeShipmentService:
        def __init__(self, db, tenant_id):  # noqa: ARG002
            pass

        def list_shipments(self, limit=100, cross_tenant=False):  # noqa: ARG002
            return [
                (
                    SimpleNamespace(euid="SHP-9", euid_seq=9, uid=9, shipment_number="SHP-0009"),
                    SimpleNamespace(status="DRAFT"),
                ),
                (
                    SimpleNamespace(
                        euid="SHP-10",
                        euid_seq=10,
                        uid=10,
                        shipment_number="SHP-0010",
                    ),
                    SimpleNamespace(status="IN_TRANSIT"),
                ),
            ]

    monkeypatch.setattr("app.domain.services.shipments.ShipmentService", FakeShipmentService)

    rows = pages._list_shipment_summaries(db=None, tenant_id=uuid.uuid4())

    assert [row["id"] for row in rows] == ["SHP-10", "SHP-9"]


def test_testkit_selector_orders_by_numeric_creation_not_euid(
    monkeypatch: pytest.MonkeyPatch,
):
    from app.web.routes import pages

    class FakeTestKitService:
        def __init__(self, db, tenant_id):  # noqa: ARG002
            pass

        def list_kits(self, limit=100, cross_tenant=False):  # noqa: ARG002
            return [
                SimpleNamespace(euid="TK-9", euid_seq=9, uid=9, kit_barcode="KIT-9"),
                SimpleNamespace(euid="TK-10", euid_seq=10, uid=10, kit_barcode="KIT-10"),
            ]

        def get_with_revision(self, kit_euid, cross_tenant=False):  # noqa: ARG002
            return (
                SimpleNamespace(euid=kit_euid),
                SimpleNamespace(origin_site_id=None),
            )

    monkeypatch.setattr("app.domain.services.shipments.TestKitService", FakeTestKitService)

    rows = pages._list_testkit_summaries(db=None, tenant_id=uuid.uuid4())

    assert [row["id"] for row in rows] == ["TK-10", "TK-9"]


def test_test_selector_orders_by_numeric_creation_not_euid(
    monkeypatch: pytest.MonkeyPatch,
):
    from app.web.routes import pages

    class FakeTrfService:
        def __init__(self, db, tenant_id):  # noqa: ARG002
            pass

        def list_trfs(self, limit=200, cross_tenant=False):  # noqa: ARG002
            return [(SimpleNamespace(euid="TRF-1", order_number="1001"), None)]

    class FakeTestService:
        def __init__(self, db, tenant_id):  # noqa: ARG002
            pass

        def list_for_trf(self, trf_euid, cross_tenant=False):  # noqa: ARG002
            assert trf_euid == "TRF-1"
            return [
                (
                    SimpleNamespace(euid="TST-9", euid_seq=9, uid=9),
                    SimpleNamespace(product_code="WGS-A"),
                    [],
                ),
                (
                    SimpleNamespace(euid="TST-10", euid_seq=10, uid=10),
                    SimpleNamespace(product_code="WGS-B"),
                    [],
                ),
            ]

    monkeypatch.setattr("app.domain.services.trfs.TrfService", FakeTrfService)
    monkeypatch.setattr("app.domain.services.trfs.TestService", FakeTestService)

    rows = pages._list_tenant_test_summaries(db=None, tenant_id=uuid.uuid4())

    assert [row["id"] for row in rows] == ["TST-10", "TST-9"]


def test_sortable_table_asset_is_included_on_shipments_testkits_and_patients(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    _seed_shipment_hierarchy(db_session, web_user.tenant_id, web_user.sub_uuid)
    _create_patient(db_session, web_user.tenant_id, web_user.sub_uuid)
    db_session.commit()

    client = _client(db_session, web_user)
    try:
        for path in ("/shipments", "/testkits", "/patients"):
            response = client.get(path)
            assert response.status_code == 200
            assert "/static/js/table_sort.js" in response.text
            assert 'data-sortable-table="true"' in response.text
    finally:
        app.dependency_overrides.clear()
