"""Unit tests for TapDB cutover behavior in ManifestService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from types import SimpleNamespace

from app.domain.services.manifests import ManifestItem, ManifestService


@dataclass
class _MockDB:
    def add(self, _obj):
        return None

    def commit(self):
        return None


class _FakeManifestRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.tenant_id = tenant_id
        self.manifest = SimpleNamespace(
            id=uuid.uuid4(),
            euid=f"MAN-{uuid.uuid4().int % 10000}",
            tenant_id=tenant_id,
            manifest_number="MAN-1",
            created_at=datetime.now(UTC),
            created_by=uuid.uuid4(),
        )
        self.revision = SimpleNamespace(
            revision_id=uuid.uuid4(),
            manifest_id=self.manifest.euid,
            revision_no=1,
            items=[],
            shipment_id=None,
            created_at=datetime.now(UTC),
            created_by=self.manifest.created_by,
            note=None,
        )

    def generate_next_manifest_number(self):
        self.calls.append("generate_next_manifest_number")
        return "MAN-1"

    def create_manifest(self, tenant_id, manifest_number, items, shipment_id, created_by, note):
        self.calls.append("create_manifest")
        self.manifest.manifest_number = manifest_number
        self.revision.items = items
        self.revision.shipment_id = shipment_id
        self.revision.note = note
        return self.manifest, self.revision

    def get_manifest_with_revision(self, manifest_id, tenant_id):
        self.calls.append("get_manifest_with_revision")
        if manifest_id != self.manifest.euid:
            return None
        return self.manifest, self.revision

    def get_manifest_by_number(self, manifest_number, tenant_id):
        self.calls.append("get_manifest_by_number")
        if manifest_number != self.manifest.manifest_number:
            return None
        return self.manifest, self.revision

    def list_manifests(self, tenant_id, skip=0, limit=50):
        self.calls.append("list_manifests")
        return [(self.manifest, self.revision)]


def test_manifest_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = ManifestService(_MockDB(), tenant_id=tenant_id, user_id=str(uuid.uuid4()))
    repo = _FakeManifestRepo(tenant_id)
    monkeypatch.setattr(svc, "_repo", lambda: repo)

    result = svc.create_manifest(
        [
            ManifestItem(specimen_barcode="BC-1", specimen_type="BLOOD"),
            ManifestItem(specimen_barcode="BC-2", specimen_type="SALIVA"),
        ],
        shipment_id=uuid.uuid4(),
        created_by=uuid.uuid4(),
    )

    assert result.manifest_number == "MAN-1"
    assert result.items_created == 2
    assert result.materials_registered == 0
    assert result.errors is None

    assert svc.get_manifest(repo.manifest.euid) is not None
    assert svc.get_by_manifest_number("MAN-1") is not None
    assert len(svc.list_manifests()) == 1

    assert repo.calls == [
        "generate_next_manifest_number",
        "create_manifest",
        "get_manifest_with_revision",
        "get_manifest_by_number",
        "list_manifests",
    ]
