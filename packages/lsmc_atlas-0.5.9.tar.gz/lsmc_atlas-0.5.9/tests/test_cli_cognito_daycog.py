"""Unit tests for the Atlas daycog-backed Cognito CLI."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from app.auth.cognito_uri_validation import (
    CognitoClientNameValidationResult,
    CognitoURIValidationResult,
)
from app.cli import cognito as cognito_cli

runner = CliRunner()


def _atlas_contract() -> dict[str, str]:
    return {
        "region": "us-west-2",
        "user_pool_id": "us-west-2_pool123",
        "app_client_id": "client-123",
        "app_client_secret": "",
        "client_name": "atlas",
        "domain": "atlas.auth.us-west-2.amazoncognito.com",
        "redirect_uri": "https://localhost:8915/auth/callback",
        "logout_url": "https://localhost:8915/",
        "aws_profile": "lsmc",
        "aws_region": "us-west-2",
    }


def test_contract_from_daycog_values_defaults_client_name() -> None:
    contract = cognito_cli._contract_from_daycog_values(
        {
            "COGNITO_REGION": "us-west-2",
            "COGNITO_USER_POOL_ID": "us-west-2_pool123",
            "COGNITO_APP_CLIENT_ID": "client-123",
            "COGNITO_DOMAIN": "atlas.auth.us-west-2.amazoncognito.com",
            "COGNITO_CALLBACK_URL": "https://localhost:8915/auth/callback",
            "COGNITO_LOGOUT_URL": "https://localhost:8915/",
            "AWS_PROFILE": "lsmc",
            "AWS_REGION": "us-west-2",
        }
    )

    assert contract["client_name"] == "atlas"
    assert contract["user_pool_id"] == "us-west-2_pool123"
    assert contract["redirect_uri"] == "https://localhost:8915/auth/callback"


def test_write_and_read_atlas_cognito_contract(monkeypatch, tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    monkeypatch.setattr(cognito_cli, "get_config_file_path", lambda: config_path)

    expected = _atlas_contract()
    cognito_cli._write_atlas_cognito_contract(expected)

    assert cognito_cli._atlas_cognito_contract() == expected


def test_cognito_import_writes_full_contract_from_daycog(monkeypatch, tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    monkeypatch.setattr(cognito_cli, "get_config_file_path", lambda: config_path)
    monkeypatch.setattr(
        cognito_cli,
        "_resolve_daycog_context",
        lambda **_kwargs: {
            "COGNITO_REGION": "us-west-2",
            "COGNITO_USER_POOL_ID": "us-west-2_pool123",
            "COGNITO_APP_CLIENT_ID": "client-123",
            "COGNITO_CLIENT_NAME": "atlas",
            "COGNITO_DOMAIN": "atlas.auth.us-west-2.amazoncognito.com",
            "COGNITO_CALLBACK_URL": "https://localhost:8915/auth/callback",
            "COGNITO_LOGOUT_URL": "https://localhost:8915/",
            "AWS_PROFILE": "lsmc",
            "AWS_REGION": "us-west-2",
        },
    )

    result = runner.invoke(
        cognito_cli.cognito_app,
        [
            "import",
            "--pool-name",
            "daylily-ursa-users",
            "--region",
            "us-west-2",
            "--client-name",
            "atlas",
            "--no-refresh",
        ],
    )

    assert result.exit_code == 0
    loaded = cognito_cli._atlas_cognito_contract()
    assert loaded["user_pool_id"] == "us-west-2_pool123"
    assert loaded["app_client_id"] == "client-123"
    assert loaded["client_name"] == "atlas"
    assert loaded["domain"] == "atlas.auth.us-west-2.amazoncognito.com"


def test_cognito_status_uses_daycog_values_without_daycog_env_files(
    monkeypatch,
    tmp_path: Path,
) -> None:
    config_path = tmp_path / "config.yaml"
    monkeypatch.setattr(cognito_cli, "get_config_file_path", lambda: config_path)
    cognito_cli._write_atlas_cognito_contract(_atlas_contract())
    monkeypatch.setattr(
        cognito_cli,
        "_resolve_daycog_context",
        lambda **_kwargs: {
            "COGNITO_USER_POOL_ID": "us-west-2_pool123",
            "COGNITO_APP_CLIENT_ID": "client-123",
            "COGNITO_CLIENT_NAME": "atlas",
            "COGNITO_CALLBACK_URL": "https://localhost:8915/auth/callback",
            "COGNITO_LOGOUT_URL": "https://localhost:8915/",
        },
    )
    monkeypatch.setattr(
        cognito_cli,
        "validate_cognito_uri_ports",
        lambda **_kwargs: CognitoURIValidationResult(expected_port=8915),
    )
    monkeypatch.setattr(
        cognito_cli,
        "validate_cognito_app_client_name",
        lambda **_kwargs: CognitoClientNameValidationResult(expected_client_name="atlas"),
    )

    result = runner.invoke(cognito_cli.cognito_app, ["status", "--port", "8915", "--no-check-aws"])

    assert result.exit_code == 0
    assert "Resolved matching daycog context" in result.output
    assert "URI validation passed" in result.output
    assert "Client-name validation passed" in result.output
