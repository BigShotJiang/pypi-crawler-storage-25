"""Shared TapDB helpers for test setup."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from app.domain.services.orgs import SiteCreate, SiteService
from app.integrations.tapdb_template_seed import seed_atlas_templates
from app.persistence.tapdb.orgs import (
    ORG_REV_TEMPLATE_CODE,
    ORG_TEMPLATE_CODE,
    TapdbOrgRepository,
)


def ensure_tapdb_org(
    db,
    org_id: uuid.UUID,
    *,
    name: str | None = None,
    display_name: str | None = None,
    org_type: str = "clinic",
    site_name: str | None = None,
    site_code: str | None = None,
):
    """Ensure a deterministic organization record exists in TapDB for tests.

    Returns the TapDB org instance (so callers can access ``.euid``).
    """
    repo = TapdbOrgRepository(db)
    existing = repo.get_org_by_uid(org_id)
    if existing is not None:
        existing_sites = SiteService(db).list_by_organization(existing.euid, active_only=False)
        if not existing_sites:
            SiteService(db).create(
                SiteCreate(
                    organization_id=existing.euid,
                    name=(
                        site_name or f"{(display_name or name or 'Default').strip()} Site"
                    ).strip(),
                    site_code=site_code or f"DF-{str(org_id)[:8].upper()}",
                ),
                created_by=None,
            )
        return existing

    seed_atlas_templates(db)
    repo._ensure_templates()  # noqa: SLF001 - test helper needs deterministic org IDs
    now = datetime.now(UTC)
    resolved_name = (name or f"tenant-{str(org_id)[:8]}").strip() or f"tenant-{str(org_id)[:8]}"
    resolved_display_name = (display_name or resolved_name).strip() or resolved_name

    org_instance = repo.factory.create_instance(
        session=db,
        template_code=ORG_TEMPLATE_CODE,
        name=resolved_name,
        properties={
            "id": str(org_id),
            "created_by": None,
        },
        tenant_id=org_id,
    )
    rev_instance = repo.factory.create_instance(
        session=db,
        template_code=ORG_REV_TEMPLATE_CODE,
        name=resolved_name,
        properties={
            "revision_id": str(uuid.uuid4()),
            "organization_id": str(org_instance.euid),
            "revision_no": 1,
            "name": resolved_name,
            "display_name": resolved_display_name,
            "org_type": org_type,
            "contact_email": None,
            "contact_phone": None,
            "owner_user_id": None,
            "address": None,
            "is_active": True,
            "created_by": None,
            "created_at": now.isoformat(),
            "note": "test-helper upsert",
        },
    )
    repo.factory.link_instances(
        session=db,
        parent=org_instance,
        child=rev_instance,
        relationship_type="revision",
    )
    SiteService(db).create(
        SiteCreate(
            organization_id=str(org_instance.euid),
            name=(site_name or f"{resolved_display_name} Site").strip(),
            site_code=site_code or f"DF-{str(org_id)[:8].upper()}",
        ),
        created_by=None,
    )
    db.flush()
    return org_instance
