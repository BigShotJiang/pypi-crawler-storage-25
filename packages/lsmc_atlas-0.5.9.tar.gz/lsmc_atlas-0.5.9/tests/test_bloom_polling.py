"""Tests for Bloom polling fallback behavior."""

from __future__ import annotations

import asyncio
import uuid
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace

import app.domain.services.bloom_polling as bloom_polling


def test_polling_dedupes_items_and_persists_checkpoint(monkeypatch):
    tenant_id = uuid.uuid4()

    class FakeBridge:
        def __init__(self, db, provided_tenant_id):
            self.tenant_id = provided_tenant_id

        def list_specimens_by_reference(self, refs, actor_id=None):
            if refs.atlas_trf_euid == "TRF-1":
                return [
                    {
                        "specimen_euid": "SP-1001",
                        "status": "active",
                        "atlas_refs": {"atlas_trf_euid": "TRF-1"},
                    },
                    {
                        "specimen_euid": "SP-1001",
                        "status": "active",
                        "atlas_refs": {"atlas_trf_euid": "TRF-1"},
                    },
                    {
                        "specimen_euid": "SP-1002",
                        "status": "received",
                        "atlas_refs": {"atlas_trf_euid": "TRF-1"},
                    },
                ]
            return [
                {
                    "specimen_euid": "SP-1001",
                    "status": "active",
                    "atlas_refs": {"atlas_trf_euid": "TRF-1"},
                },
                {
                    "specimen_euid": "SP-1003",
                    "status": "active",
                    "atlas_refs": {"atlas_trf_euid": "TRF-2"},
                },
            ]

    class FakeOrgBloomConfigService:
        upsert_calls: list[tuple[uuid.UUID, object]] = []

        def __init__(self, db):
            self.db = db

        def get(self, organization_id):
            return SimpleNamespace(
                enabled=True,
                bloom_base_url="https://bloom.local",
                bloom_api_key_secret_ref="env:FAKE_BLOOM_KEY",
                bloom_webhook_secret_ref=None,
                bloom_service_user="atlas-org-user",
                last_verified_at=None,
                metadata={"existing": True},
            )

        def upsert(self, organization_id, data, actor_id=None):
            self.__class__.upsert_calls.append((organization_id, data))
            return None

    monkeypatch.setattr(bloom_polling, "ContainerSpecimenBridgeService", FakeBridge)
    monkeypatch.setattr(bloom_polling, "OrgBloomConfigService", FakeOrgBloomConfigService)

    service = bloom_polling.BloomPollingService(db=object(), tenant_id=tenant_id)
    result = service.poll_for_trf_euids(["TRF-1", "TRF-2"])

    assert result.trfs_polled == 2
    assert result.synced_items == 3
    assert len(FakeOrgBloomConfigService.upsert_calls) == 1

    saved_org_id, saved_upsert = FakeOrgBloomConfigService.upsert_calls[0]
    assert saved_org_id == tenant_id
    checkpoint = (saved_upsert.metadata or {}).get("polling_checkpoint") or {}
    assert checkpoint["trfs_polled"] == 2
    assert checkpoint["synced_items"] == 3
    assert checkpoint["last_polled_at"]
    assert saved_upsert.metadata["existing"] is True


def test_run_bloom_polling_job_continues_after_per_org_error(monkeypatch):
    tenant_ok = uuid.uuid4()
    tenant_fail = uuid.uuid4()
    polled: list[uuid.UUID] = []

    class FakeDb:
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    fake_db = FakeDb()

    class FakeOrgBloomConfigService:
        def __init__(self, db):
            self.db = db

        def list_enabled(self):
            return [
                SimpleNamespace(organization_id=tenant_fail),
                SimpleNamespace(organization_id=tenant_ok),
            ]

    class FakeBloomPollingService:
        def __init__(self, db, tenant_id):
            self.tenant_id = tenant_id

        def poll_all_active_trfs(self):
            if self.tenant_id == tenant_fail:
                raise RuntimeError("simulated poll failure")
            polled.append(self.tenant_id)

    monkeypatch.setattr(bloom_polling, "OrgBloomConfigService", FakeOrgBloomConfigService)
    monkeypatch.setattr(bloom_polling, "BloomPollingService", FakeBloomPollingService)

    with ThreadPoolExecutor(max_workers=1) as executor:
        executor.submit(asyncio.run, bloom_polling.run_bloom_polling_job(lambda: fake_db)).result()

    assert polled == [tenant_ok]
    assert fake_db.closed is True
