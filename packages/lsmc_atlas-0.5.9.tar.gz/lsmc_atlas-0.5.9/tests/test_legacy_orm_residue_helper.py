"""Smoke test for legacy ORM residue reporting helper."""

from __future__ import annotations

import subprocess
from pathlib import Path


def test_legacy_orm_residue_report_helper_runs() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script = repo_root / "scripts" / "report_legacy_orm_residue.sh"
    result = subprocess.run(
        [str(script)], capture_output=True, text=True, cwd=repo_root, check=True
    )

    assert "legacy_orm_files_remaining=" in result.stdout
    assert "legacy_orm_lines_remaining=" in result.stdout
    assert "legacy_orm_files_list_begin" in result.stdout
    assert "legacy_orm_files_list_end" in result.stdout
