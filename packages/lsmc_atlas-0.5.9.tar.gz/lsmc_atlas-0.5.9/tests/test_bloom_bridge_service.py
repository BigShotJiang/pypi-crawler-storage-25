"""Focused unit tests for Atlas Bloom bridge material handoff semantics."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.domain.services.bloom_bridge import AcceptedMaterialRequest, ContainerSpecimenBridgeService
from app.integrations.bloom_client import BloomOperationResult


def test_resolve_tube_test_context_enforces_single_trf_and_multi_test_atomicity():
    service = object.__new__(ContainerSpecimenBridgeService)

    def _resolve_test_context(*, test_euid: str):
        mapping = {
            "TST-1": ("TRF-1", "TST-1"),
            "TST-2": ("TRF-1", "TST-2"),
            "TST-3": ("TRF-2", "TST-3"),
        }
        return mapping[test_euid]

    service._resolve_test_context = _resolve_test_context

    trf_euid, test_euids = ContainerSpecimenBridgeService._resolve_tube_test_context(
        service,
        test_euid="TST-1",
        test_euids=["TST-2", "TST-1"],
    )
    assert trf_euid == "TRF-1"
    assert test_euids == ["TST-1", "TST-2"]

    with pytest.raises(ValueError, match="same TRF"):
        ContainerSpecimenBridgeService._resolve_tube_test_context(
            service,
            test_euid="TST-1",
            test_euids=["TST-3"],
        )


def test_persist_material_relations_scopes_specimen_links_to_patient_and_containment_only():
    service = object.__new__(ContainerSpecimenBridgeService)
    persisted: list[dict[str, object]] = []
    validated: list[tuple[str | None, str | None, str | None]] = []

    class _FakeExternalObjects:
        def validate_specimen_relation_payload(
            self, *, collection_event_id=None, patient_id=None, container_euid
        ):
            validated.append((collection_event_id, patient_id, container_euid))

    service.external_objects = _FakeExternalObjects()
    service._persist_relation = lambda **kwargs: persisted.append(kwargs)

    ContainerSpecimenBridgeService._persist_material_relations(
        service,
        container_external_object_id="EXB-C",
        specimen_external_object_id="EXB-S",
        container_euid="CNT-1",
        trf_euid="TRF-1",
        test_euids=["TST-1", "TST-2"],
        fulfillment_item_euids=["TPI-1", "TPI-2"],
        patient_euid="PAT-1",
        testkit_euid="KIT-1",
        shipment_euid=None,
        actor_id=None,
    )

    assert validated == [(None, "PAT-1", "CNT-1")]

    specimen_relations = [r for r in persisted if r["external_object_id"] == "EXB-S"]
    assert {r["relation_type"] for r in specimen_relations} == {
        "belongs_to_patient",
        "contained_in",
    }

    container_relations = [r for r in persisted if r["external_object_id"] == "EXB-C"]
    container_types = [r["relation_type"] for r in container_relations]
    assert "belongs_to_trf" in container_types
    assert "belongs_to_testkit" in container_types
    assert container_types.count("belongs_to_test") == 2
    assert container_types.count("belongs_to_test_fulfillment_item") == 2


def test_register_accepted_material_queues_container_and_includes_patient_context():
    service = object.__new__(ContainerSpecimenBridgeService)
    service.tenant_id = "TEN-1"

    persist_order: list[str] = []
    persisted_relations: list[dict[str, object]] = []

    class _FakeClient:
        def __init__(self):
            self.register_payload = None
            self.register_idempotency = None
            self.queue_calls: list[dict[str, object]] = []

        def register_accepted_material(self, payload, *, idempotency_key=None):
            self.register_payload = payload
            self.register_idempotency = idempotency_key
            return BloomOperationResult(
                external_euid="SP-2001",
                status="active",
                raw={
                    "specimen_euid": "SP-2001",
                    "container_euid": "CNT-2001",
                    "status": "active",
                    "created": True,
                },
            )

        def move_material_to_queue(
            self,
            material_euid,
            queue_name,
            *,
            metadata=None,
            idempotency_key=None,
        ):
            self.queue_calls.append(
                {
                    "material_euid": material_euid,
                    "queue_name": queue_name,
                    "metadata": metadata or {},
                    "idempotency_key": idempotency_key,
                }
            )
            return {"current_queue": queue_name, "idempotent_replay": False}

    fake_client = _FakeClient()

    service._validate_template_code = lambda _template_code: None
    service._resolve_link_targets = lambda _data: (
        "TRF-1",
        ["TST-1"],
        "PAT-1",
        "KIT-1",
        None,
        "SITE-1",
    )

    def _resolve_fulfillment_items(**_kwargs):
        return ["TPI-1"]

    service._resolve_fulfillment_item_euids = _resolve_fulfillment_items
    service._get_bloom_client = lambda _site_id=None: fake_client

    def _persist_external_object(*, object_type, bloom_result, actor_id=None, is_deleted=False):
        _ = (actor_id, is_deleted)
        persist_order.append(object_type)
        if object_type == "container":
            return SimpleNamespace(euid="EXB-C", external_euid=bloom_result.external_euid)
        return SimpleNamespace(euid="EXB-S", external_euid=bloom_result.external_euid)

    service._persist_external_object = _persist_external_object
    service._persist_material_relations = lambda **kwargs: persisted_relations.append(kwargs)

    result = ContainerSpecimenBridgeService.register_accepted_material(
        service,
        AcceptedMaterialRequest(
            trf_euid="TRF-1",
            test_euids=["TST-1"],
            patient_euid="PAT-1",
            testkit_euid="KIT-1",
            specimen_template_code="content/specimen/blood-whole/1.0",
            starting_queue="extraction_prod",
            queue_metadata={"origin": "intake"},
            idempotency_key="idem-2001",
        ),
        actor_id=None,
    )

    assert persist_order == ["container", "specimen"]
    assert fake_client.register_payload["atlas_context"]["atlas_patient_euid"] == "PAT-1"
    assert fake_client.register_payload["atlas_context"]["atlas_testkit_euid"] == "KIT-1"
    assert fake_client.register_payload["atlas_context"]["atlas_organization_site_euid"] == "SITE-1"
    assert fake_client.register_payload["atlas_context"].get("atlas_shipment_euid") in {
        None,
        "",
    }
    assert fake_client.queue_calls[0]["material_euid"] == "CNT-2001"
    assert fake_client.queue_calls[0]["queue_name"] == "extraction_prod"
    assert fake_client.queue_calls[0]["idempotency_key"] == "idem-2001:queue"

    assert persisted_relations[0]["container_external_object_id"] == "EXB-C"
    assert persisted_relations[0]["specimen_external_object_id"] == "EXB-S"
    assert result.container_euid == "CNT-2001"
    assert result.specimen_euid == "SP-2001"
    assert result.current_queue == "extraction_prod"
