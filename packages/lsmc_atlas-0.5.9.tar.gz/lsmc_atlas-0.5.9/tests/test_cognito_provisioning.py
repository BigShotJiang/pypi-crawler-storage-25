"""Tests for admin-initiated Cognito user provisioning flow.

Covers:
1. cognito_admin.py functions (mocked boto3 client)
2. UserService.invite() — happy path, validation, rollback
3. UserService.deactivate() — Cognito sync
4. _invert_group_role_map helper
"""

import uuid
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError
from sqlalchemy.orm import Session

from app.auth.cognito_admin import (
    CognitoAdminError,
    UserAlreadyExistsError,
    admin_add_user_to_group,
    admin_create_user,
    admin_disable_user,
    admin_enable_user,
)
from app.domain.enums import AuditAction
from app.domain.services.audit import AuditFilter, AuditService
from app.domain.services.users import UserCreate, UserService, _invert_group_role_map
from tests.tapdb_test_helpers import ensure_tapdb_org

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def tenant(db_session: Session) -> SimpleNamespace:
    """Create a test organization/tenant."""
    org_id = uuid.uuid4()
    ensure_tapdb_org(db_session, org_id, name="test-org", display_name="Test Org")
    db_session.commit()
    return SimpleNamespace(id=org_id, uid=org_id)


@pytest.fixture
def admin_uuid() -> uuid.UUID:
    return uuid.uuid4()


# =============================================================================
# Tests: cognito_admin.py functions (with real boto3 mocking)
# =============================================================================


class TestCognitoAdminFunctions:
    """Tests for the cognito_admin.py wrapper functions.

    These tests override the autouse mock_cognito_admin fixture by
    patching the boto3 client directly.
    """

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_create_user_returns_sub(self, mock_get_client):
        """AdminCreateUser returns the Cognito sub."""
        mock_client = MagicMock()
        mock_client.admin_create_user.return_value = {
            "User": {
                "Attributes": [
                    {"Name": "sub", "Value": "abc-123-def"},
                    {"Name": "email", "Value": "user@example.com"},
                ]
            }
        }
        mock_get_client.return_value = mock_client

        result = admin_create_user("user@example.com", name="Test User")

        assert result == "abc-123-def"
        mock_client.admin_create_user.assert_called_once()
        call_kwargs = mock_client.admin_create_user.call_args[1]
        assert call_kwargs["Username"] == "user@example.com"
        assert "MessageAction" not in call_kwargs  # omitted → Cognito sends default invite

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_create_user_suppress_invitation(self, mock_get_client):
        """suppress_invitation=True sets MessageAction=SUPPRESS."""
        mock_client = MagicMock()
        mock_client.admin_create_user.return_value = {
            "User": {"Attributes": [{"Name": "sub", "Value": "xyz-789"}]}
        }
        mock_get_client.return_value = mock_client

        admin_create_user("user@example.com", suppress_invitation=True)

        call_kwargs = mock_client.admin_create_user.call_args[1]
        assert call_kwargs["MessageAction"] == "SUPPRESS"

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_create_user_already_exists(self, mock_get_client):
        """UsernameExistsException raises UserAlreadyExistsError."""
        mock_client = MagicMock()
        mock_client.admin_create_user.side_effect = ClientError(
            {"Error": {"Code": "UsernameExistsException", "Message": "exists"}},
            "AdminCreateUser",
        )
        mock_get_client.return_value = mock_client

        with pytest.raises(UserAlreadyExistsError, match="already exists"):
            admin_create_user("dupe@example.com")

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_create_user_other_error(self, mock_get_client):
        """Other ClientErrors raise CognitoAdminError."""
        mock_client = MagicMock()
        mock_client.admin_create_user.side_effect = ClientError(
            {"Error": {"Code": "InternalErrorException", "Message": "boom"}},
            "AdminCreateUser",
        )
        mock_get_client.return_value = mock_client

        with pytest.raises(CognitoAdminError):
            admin_create_user("user@example.com")

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_create_user_no_sub_returned(self, mock_get_client):
        """Missing sub in response raises CognitoAdminError."""
        mock_client = MagicMock()
        mock_client.admin_create_user.return_value = {
            "User": {"Attributes": [{"Name": "email", "Value": "user@example.com"}]}
        }
        mock_get_client.return_value = mock_client

        with pytest.raises(CognitoAdminError, match="sub attribute"):
            admin_create_user("user@example.com")

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_add_user_to_group_success(self, mock_get_client):
        """AdminAddUserToGroup succeeds."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        admin_add_user_to_group("user@example.com", "lsmc-customers")

        mock_client.admin_add_user_to_group.assert_called_once()

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_add_user_to_group_error(self, mock_get_client):
        """AdminAddUserToGroup raises CognitoAdminError on failure."""
        mock_client = MagicMock()
        mock_client.admin_add_user_to_group.side_effect = ClientError(
            {"Error": {"Code": "ResourceNotFoundException", "Message": "no group"}},
            "AdminAddUserToGroup",
        )
        mock_get_client.return_value = mock_client

        with pytest.raises(CognitoAdminError):
            admin_add_user_to_group("user@example.com", "nonexistent-group")

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_disable_user_success(self, mock_get_client):
        """AdminDisableUser succeeds."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        admin_disable_user("user@example.com")

        mock_client.admin_disable_user.assert_called_once()

    @patch("app.auth.cognito_admin._get_client")
    def test_admin_enable_user_success(self, mock_get_client):
        """AdminEnableUser succeeds."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        admin_enable_user("user@example.com")

        mock_client.admin_enable_user.assert_called_once()


# =============================================================================
# Tests: UserService.invite()
# =============================================================================


class TestUserServiceInvite:
    """Tests for UserService.invite() method.

    These tests use the autouse mock_cognito_admin fixture from conftest.py.
    """

    @pytest.mark.db
    def test_invite_happy_path(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID
    ):
        """invite() creates user in Cognito and persists UserProfile."""
        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="invited@example.com",
            name="Invited User",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
        )

        user = svc.invite(data)

        assert user.euid is not None
        assert user.email == "invited@example.com"
        assert user.name == "Invited User"
        assert user.tenant_id == tenant.uid
        assert user.roles == ["EXTERNAL_USER"]
        assert user.is_active is True
        # cognito_sub is set by the mock
        assert user.cognito_sub is not None
        assert user.cognito_sub.startswith("mock-cognito-sub-")

    @pytest.mark.db
    def test_invite_creates_audit_event(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID
    ):
        """invite() logs an INVITE_USER audit event."""
        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="audited@example.com",
            name="Audited User",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
        )

        user = svc.invite(data)

        events = AuditService(db_session, tenant_id=tenant.uid).list_events(
            filter=AuditFilter(
                action=AuditAction.INVITE_USER.value,
                entity_type="UserProfile",
                entity_id=user.euid,
            ),
            limit=5,
        )
        assert events
        assert events[0].user_id == str(admin_uuid)
        assert events[0].details["email"] == "audited@example.com"

    @pytest.mark.db
    def test_invite_duplicate_email_raises(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID
    ):
        """invite() raises ValueError for duplicate email in same tenant."""
        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="dupe@example.com",
            name="First",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
        )
        svc.invite(data)

        with pytest.raises(ValueError, match="already exists"):
            svc.invite(data)

    @pytest.mark.db
    def test_invite_invalid_tenant_raises(self, db_session: Session, admin_uuid: uuid.UUID):
        """invite() raises ValueError for non-existent tenant."""
        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="orphan@example.com",
            name="Orphan",
            tenant_id=uuid.uuid4(),
            roles=["EXTERNAL_USER"],
        )

        with pytest.raises(ValueError, match="not found"):
            svc.invite(data)

    @pytest.mark.db
    def test_invite_invalid_role_raises(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID
    ):
        """invite() raises ValueError for invalid role."""
        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="badrole@example.com",
            name="Bad Role",
            tenant_id=tenant.uid,
            roles=["SUPERADMIN"],
        )

        with pytest.raises(ValueError, match="Invalid role"):
            svc.invite(data)

    @pytest.mark.db
    def test_invite_rollback_on_db_failure(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID, monkeypatch
    ):
        """If DB commit fails after Cognito creation, Cognito user is disabled."""
        disable_calls = []

        def tracking_disable(username):
            disable_calls.append(username)

        monkeypatch.setattr("app.auth.cognito_admin.admin_disable_user", tracking_disable)

        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="rollback@example.com",
            name="Rollback User",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
        )

        # Patch commit to raise after Cognito creation

        def failing_commit():
            raise RuntimeError("DB failure")

        monkeypatch.setattr(db_session, "commit", failing_commit)

        with pytest.raises(RuntimeError, match="DB failure"):
            svc.invite(data)

        # Verify Cognito user was disabled as rollback
        assert len(disable_calls) == 1
        assert disable_calls[0] == "rollback@example.com"


# =============================================================================
# Tests: UserService.deactivate() — Cognito sync
# =============================================================================


class TestUserServiceDeactivateCognitoSync:
    """Tests for deactivation calling admin_disable_user."""

    @pytest.mark.db
    def test_deactivate_calls_cognito_disable(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID, monkeypatch
    ):
        """deactivate() calls admin_disable_user for the user's email."""
        disable_calls = []

        def tracking_disable(username):
            disable_calls.append(username)

        monkeypatch.setattr("app.auth.cognito_admin.admin_disable_user", tracking_disable)

        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="deactivatable@example.com",
            name="Deactivatable",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
            cognito_sub=f"test-sub-{uuid.uuid4()}",
        )
        user = svc.create(data)

        svc.deactivate(user.euid)

        assert len(disable_calls) == 1
        assert disable_calls[0] == "deactivatable@example.com"
        refreshed = svc.get_by_id(user.euid)
        assert refreshed is not None
        assert refreshed.is_active is False

    @pytest.mark.db
    def test_deactivate_continues_if_cognito_fails(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID, monkeypatch
    ):
        """deactivate() still deactivates in Atlas if Cognito call fails."""

        def failing_disable(username):
            raise CognitoAdminError("Cognito down")

        monkeypatch.setattr("app.auth.cognito_admin.admin_disable_user", failing_disable)

        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="resilient@example.com",
            name="Resilient",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
            cognito_sub=f"test-sub-{uuid.uuid4()}",
        )
        user = svc.create(data)

        result = svc.deactivate(user.euid)

        assert result is not None
        assert result.is_active is False


# =============================================================================
# Tests: UserService.activate() — Cognito sync
# =============================================================================


class TestUserServiceActivateCognitoSync:
    """Tests for activation calling admin_enable_user."""

    @pytest.mark.db
    def test_activate_calls_cognito_enable(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID, monkeypatch
    ):
        """activate() calls admin_enable_user for the user's email."""
        enable_calls = []

        def tracking_enable(username):
            enable_calls.append(username)

        monkeypatch.setattr("app.auth.cognito_admin.admin_enable_user", tracking_enable)

        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="activatable@example.com",
            name="Activatable",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
            cognito_sub=f"test-sub-{uuid.uuid4()}",
        )
        user = svc.create(data)
        # Deactivate first so activate has work to do
        svc.deactivate(user.euid)
        refreshed = svc.get_by_id(user.euid)
        assert refreshed is not None
        assert refreshed.is_active is False

        # Clear tracked calls from deactivate setup
        enable_calls.clear()

        svc.activate(user.euid)

        assert len(enable_calls) == 1
        assert enable_calls[0] == "activatable@example.com"
        refreshed = svc.get_by_id(user.euid)
        assert refreshed is not None
        assert refreshed.is_active is True

    @pytest.mark.db
    def test_activate_continues_if_cognito_fails(
        self, db_session: Session, tenant: SimpleNamespace, admin_uuid: uuid.UUID, monkeypatch
    ):
        """activate() still activates in Atlas if Cognito call fails."""

        def failing_enable(username):
            raise CognitoAdminError("Cognito down")

        monkeypatch.setattr("app.auth.cognito_admin.admin_enable_user", failing_enable)

        svc = UserService(db_session, admin_uuid)
        data = UserCreate(
            email="resilient-activate@example.com",
            name="Resilient Activate",
            tenant_id=tenant.uid,
            roles=["EXTERNAL_USER"],
            cognito_sub=f"test-sub-{uuid.uuid4()}",
        )
        user = svc.create(data)
        # Deactivate first (need to mock disable too since enable mock would interfere)
        monkeypatch.setattr("app.auth.cognito_admin.admin_disable_user", lambda _username: None)
        svc.deactivate(user.euid)
        refreshed = svc.get_by_id(user.euid)
        assert refreshed is not None
        assert refreshed.is_active is False

        result = svc.activate(user.euid)

        assert result is not None
        assert result.is_active is True


# =============================================================================
# Tests: _invert_group_role_map helper
# =============================================================================


class TestInvertGroupRoleMap:
    """Tests for the _invert_group_role_map helper function."""

    def test_returns_role_to_group_mapping(self):
        """Mapping contains expected roles from DEFAULT_COGNITO_GROUP_ROLE_MAP."""
        mapping = _invert_group_role_map()

        # EXTERNAL_USER should map to the canonical customer group
        assert "EXTERNAL_USER" in mapping
        assert mapping["EXTERNAL_USER"] == "lsmc-customers"

        # ADMIN should map to a canonical admin group
        assert "ADMIN" in mapping
        assert mapping["ADMIN"] in {"platform-admin", "atlas-admin"}

    def test_first_group_wins_for_duplicate_roles(self):
        """When a role appears in multiple groups, first match is kept."""
        mapping = _invert_group_role_map()

        # Each role should map to exactly one group
        for _role, group in mapping.items():
            assert isinstance(group, str)
            assert len(group) > 0
