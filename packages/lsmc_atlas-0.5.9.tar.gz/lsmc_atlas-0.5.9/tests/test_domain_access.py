from __future__ import annotations

from contextlib import asynccontextmanager
import uuid

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user, get_current_user_web
from app.auth.middleware import csrf_protect
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import create_app
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.fixture
def client(monkeypatch: pytest.MonkeyPatch) -> TestClient:
    @asynccontextmanager
    async def _no_op_lifespan(_app):
        yield

    monkeypatch.setattr("app.main.lifespan", _no_op_lifespan)
    app = create_app()
    with TestClient(app, raise_server_exceptions=False) as test_client:
        yield test_client


def _create_local_browser_client(monkeypatch, db_session, tenant_id) -> TestClient:
    @asynccontextmanager
    async def _no_op_lifespan(_app):
        yield

    monkeypatch.setattr("app.main.lifespan", _no_op_lifespan)
    monkeypatch.setattr("app.main.settings.debug", False, raising=False)
    monkeypatch.setattr("app.main.settings.database_target", "local", raising=False)

    app = create_app()

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_current_user():
        return CurrentUser(
            sub="test-admin-sub",
            email="admin@lsmc.bio",
            name="Atlas Admin",
            tenant_id=tenant_id,
            roles=[Role.ADMIN.value],
        )

    async def override_csrf_protect():
        pass

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user
    app.dependency_overrides[get_current_user_web] = override_get_current_user
    app.dependency_overrides[csrf_protect] = override_csrf_protect
    return TestClient(app, raise_server_exceptions=False)


def test_atlas_allows_approved_origin_preflight(client: TestClient) -> None:
    response = client.options(
        "/health",
        headers={
            "Origin": "https://portal.lsmc.bio",
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "https://portal.lsmc.bio"


def test_atlas_rejects_disallowed_origin(client: TestClient) -> None:
    response = client.options(
        "/health",
        headers={
            "Origin": "https://evil.example.com",
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 403
    assert response.text == "Origin not allowed"


def test_atlas_rejects_disallowed_host(client: TestClient) -> None:
    """Host filtering is now handled upstream (load balancer / security groups).

    TrustedHostMiddleware uses allowed_hosts=['*'], so arbitrary Host headers
    are permitted at the application layer.
    """
    response = client.get("/health", headers={"host": "evil.example.com"})

    # Middleware allows all hosts now — filtering is done at infra layer.
    # /health itself is authenticated, so host acceptance still results in an auth failure.
    assert response.status_code == 401


@pytest.mark.db
@pytest.mark.parametrize(
    ("path", "data"),
    [
        (
            "/admin/organizations/create",
            {
                "name": "Local Origin Org",
                "display_name": "Local Origin Org",
                "org_type": "clinic",
                "initial_site_name": "Primary Site",
            },
        ),
        (
            "/admin/users/create",
            {
                "email": "local-origin-user@test.com",
                "name": "Local Origin User",
                "cognito_group": "lsmc-customers",
            },
        ),
    ],
)
def test_local_admin_posts_accept_localhost_origin(
    monkeypatch: pytest.MonkeyPatch, db_session, path: str, data: dict[str, str]
) -> None:
    tenant_id = uuid.uuid4()
    tenant_org = ensure_tapdb_org(
        db_session,
        tenant_id,
        name="local-origin-tenant",
        display_name="Local Origin Tenant",
    )
    db_session.flush()

    request_data = dict(data)
    if path == "/admin/users/create":
        request_data["tenant_id"] = str(tenant_org.euid)

    with _create_local_browser_client(monkeypatch, db_session, tenant_org.uid) as client:
        response = client.post(
            path,
            headers={"Origin": "https://localhost:8915"},
            data=request_data,
            follow_redirects=False,
        )

    assert response.status_code in (302, 303), response.text


@pytest.mark.db
def test_local_dashboard_accepts_localhost_origin(
    monkeypatch: pytest.MonkeyPatch, db_session
) -> None:
    tenant_id = uuid.uuid4()
    tenant_org = ensure_tapdb_org(
        db_session,
        tenant_id,
        name="local-dashboard-tenant",
        display_name="Local Dashboard Tenant",
    )
    db_session.flush()

    with _create_local_browser_client(monkeypatch, db_session, tenant_org.uid) as client:
        response = client.get("/", headers={"Origin": "https://localhost:8915"})

    assert response.status_code == 200


@pytest.mark.db
def test_local_admin_posts_still_reject_disallowed_origin(
    monkeypatch: pytest.MonkeyPatch, db_session
) -> None:
    tenant_id = uuid.uuid4()
    tenant_org = ensure_tapdb_org(
        db_session,
        tenant_id,
        name="disallowed-origin-tenant",
        display_name="Disallowed Origin Tenant",
    )
    db_session.flush()

    with _create_local_browser_client(monkeypatch, db_session, tenant_org.uid) as client:
        response = client.post(
            "/admin/organizations/create",
            headers={"Origin": "https://evil.example.com"},
            data={
                "name": "Blocked Org",
                "display_name": "Blocked Org",
                "org_type": "clinic",
                "initial_site_name": "Blocked Site",
            },
            follow_redirects=False,
        )

    assert response.status_code == 403
    assert response.text == "Origin not allowed"


def test_production_like_runtime_still_rejects_localhost_origin(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    @asynccontextmanager
    async def _no_op_lifespan(_app):
        yield

    monkeypatch.setattr("app.main.lifespan", _no_op_lifespan)
    monkeypatch.setattr("app.main.settings.debug", False, raising=False)
    monkeypatch.setattr("app.main.settings.database_target", "aurora", raising=False)

    app = create_app()
    with TestClient(app, raise_server_exceptions=False) as client:
        response = client.options(
            "/health",
            headers={
                "Origin": "https://localhost:8915",
                "Access-Control-Request-Method": "GET",
            },
        )

    assert response.status_code == 403
    assert response.text == "Origin not allowed"
