"""Unit tests for TapDB-backed theme route behavior."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import get_current_user
from app.db.engine import get_db
from app.main import app

pytestmark = pytest.mark.db


class _FakeThemeRepo:
    def __init__(self):
        self.calls: list[tuple[str, tuple, dict]] = []

    def get_current_theme(self, tenant_id):
        self.calls.append(("get_current_theme", (tenant_id,), {}))
        return SimpleNamespace(
            theme="bold",
            custom_css="/* custom */",
            font_choice="kanit",
            font_config={"code": "kanit"},
        )

    def select_theme(self, tenant_id, theme, created_by, font_choice=None):
        self.calls.append(("select_theme", (tenant_id, theme, created_by, font_choice), {}))
        return SimpleNamespace(
            theme=theme or "bold",
            custom_css=None,
            font_choice=font_choice or "kanit",
            font_config={"code": font_choice or "kanit"},
        )


def test_theme_routes_use_tapdb_repo(monkeypatch):
    fake_repo = _FakeThemeRepo()

    from app.api.routes import themes as themes_route

    monkeypatch.setattr(themes_route, "TapdbThemeRepository", lambda _db: fake_repo)

    tenant_id = uuid.uuid4()
    user = SimpleNamespace(
        tenant_id=tenant_id,
        sub_uuid=uuid.uuid4(),
        sub=str(uuid.uuid4()),
    )

    def override_user():
        return user

    def override_db():
        yield object()

    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_db] = override_db

    with TestClient(app) as client:
        current = client.get("/api/themes/current")
        assert current.status_code == 200
        assert current.json() == {"theme": "bold", "custom_css": "/* custom */", "font": "kanit"}

        select_resp = client.post(
            "/api/themes/select",
            data={"theme": "professional"},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        assert select_resp.status_code == 200
        assert select_resp.json() == {
            "status": "success",
            "theme": "professional",
            "font": "kanit",
        }

    app.dependency_overrides.clear()

    call_names = [item[0] for item in fake_repo.calls]
    assert call_names == ["get_current_theme", "select_theme"]
