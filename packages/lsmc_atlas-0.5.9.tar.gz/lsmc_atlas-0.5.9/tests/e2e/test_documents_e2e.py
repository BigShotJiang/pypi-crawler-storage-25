import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_document_indexing(page: Page, base_url: str):
    """Verify document OCR indexing queues."""
    response = page.goto(f"{base_url}/trfs/DUMMY_TRF/indexing")
    assert response is not None
    # Assuming no auth session exists, it might redirect or 404
    # The goal is that the routing doesn't 500
    if response.status == 200:
        expect(page.locator("body")).to_be_visible()
        # The indexing view usually has an image viewer or iframe for the document
        expect(page.locator("img, iframe").first).to_be_attached(timeout=5000)


@pytest.mark.e2e
def test_document_views(page: Page, base_url: str):
    """Verify viewing raw document artifacts securely."""
    response = page.goto(f"{base_url}/documents/DUMMY_DOC/view")
    assert response is not None
    if response.status == 200:
        expect(page.locator("body")).to_be_visible()
