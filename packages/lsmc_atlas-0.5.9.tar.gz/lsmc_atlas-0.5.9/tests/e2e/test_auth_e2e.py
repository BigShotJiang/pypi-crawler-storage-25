import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_login_page(page: Page, base_url: str):
    """Verify login page renders correctly."""
    page.goto(f"{base_url}/auth/login")
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_authenticated_landing(page: Page, base_url: str):
    """Verify authenticated user is served a valid page (not a 500 or crash).

    Since auth_setup.py pre-authenticates the browser, navigating to a
    protected route should land on the page itself (not redirect to login).
    """
    response = page.goto(f"{base_url}/my-organization")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()
