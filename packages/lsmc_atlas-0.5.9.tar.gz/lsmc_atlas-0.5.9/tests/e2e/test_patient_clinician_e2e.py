import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_patients_listing(page: Page, base_url: str):
    """Verify patient listing page loads without errors."""
    response = page.goto(f"{base_url}/patients")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_patient_creation(page: Page, base_url: str):
    """Verify patient creation form loads without errors."""
    response = page.goto(f"{base_url}/patients/new")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()
    # The form should always be present regardless of data
    expect(page.locator("form").first).to_be_visible()


@pytest.mark.e2e
def test_clinicians_listing(page: Page, base_url: str):
    """Verify clinicians listing page loads without errors."""
    response = page.goto(f"{base_url}/clinicians")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_clinician_assignment(page: Page, base_url: str):
    """Verify clinician user assignment route responds gracefully."""
    response = page.goto(f"{base_url}/clinicians/123/users/new")
    assert response is not None
    # May be 404 for a non-existent clinician — that's expected
    assert response.status in (200, 404)
