# E2E Testing with Playwright

This directory contains the end-to-end (E2E) testing suite for LSMC Atlas, powered by [Playwright](https://playwright.dev/python/docs/intro) and `pytest`.

## Test Philosophy

These tests are **Layer 1 smoke tests** — they verify that every route loads without crashing (no 500s, no 404s) and the core page structure renders correctly. They are **data-agnostic**, meaning they do not depend on seeded database records. This makes them reliable in any environment (local dev, CI, staging).

For data-dependent assertions (e.g. verifying table rows populate), a future Layer 2 suite with database seeding fixtures would be needed.

## Prerequisites

1.  **Local Server**: You must have the Atlas server running locally on port 8915 (the default port).
    ```bash
    conda activate LSMC_ATLAS
    atlas server start --port 8915
    ```
2.  **Playwright Browsers**: Ensure the Playwright browser binaries are installed in your environment.
    ```bash
    conda activate LSMC_ATLAS
    playwright install chromium
    ```

## Running the Tests

To run the suite, you must provide valid credentials for a test user. The test suite uses these credentials to log into AWS Cognito once before running the tests, and then shares the authenticated session state across all tests to speed up execution.

### 1. Set Credentials

Set the following environment variables in your terminal:

```bash
export E2E_USER_EMAIL="your_test_email@example.com"
export E2E_USER_PASSWORD="your_test_password"
```

### 2. Execute Pytest

Run the tests using `pytest`:

```bash
conda activate LSMC_ATLAS
pytest tests/e2e/ -v
```

### Running Specific Tests

To run a specific test file:
```bash
pytest tests/e2e/test_auth_e2e.py -v
```

To run a specific test function:
```bash
pytest tests/e2e/test_auth_e2e.py::test_login_page -v
```

### Headed Mode (Debugging)

If you want to watch the browser execute the tests visually (useful for debugging failing selectors):
```bash
pytest tests/e2e/ --headed -v
```

## How Authentication Works

1.  When `pytest` starts, the `setup_auth` fixture in `conftest.py` triggers a subprocess.
2.  The subprocess runs `auth_setup.py`, which launches a hidden Chromium browser, navigates to the Atlas login page, and fills in the Cognito credentials.
3.  Once successfully redirected back to Atlas, the local storage and cookies are saved to `.auth/state.json`.
4.  Playwright loads this saved state into the browser context for all subsequent tests, bypassing the login screen.

## Test Reference

### `test_example_e2e.py` — Server Reachability

| Test | Route | Description |
|------|-------|-------------|
| `test_atlas_login_page_loads` | `/` | Verifies the Atlas server is reachable and the base URL returns 200 OK with a visible page body. |

### `test_auth_e2e.py` — Authentication

| Test | Route | Description |
|------|-------|-------------|
| `test_login_page` | `/auth/login` | Verifies the Cognito login page renders correctly. |
| `test_authenticated_landing` | `/my-organization` | Verifies that an authenticated user can access a protected route (not redirected to login). |

### `test_admin_tools_e2e.py` — Admin Tools

| Test | Route | Description |
|------|-------|-------------|
| `test_admin_groups` | `/admin/groups` | Verifies the system group management page loads (200). |
| `test_api_clients` | `/api-clients` | Verifies the API client management page loads (200). |
| `test_webhook_subscriptions` | `/webhooks` | Verifies the webhook subscription page loads (200). |

### `test_trf_e2e.py` — Test Request Forms (TRFs / Orders)

| Test | Route | Description |
|------|-------|-------------|
| `test_trf_listing` | `/trfs` | Verifies the TRF list page loads and displays a heading with "TRF". |
| `test_trf_creation` | `/trfs/new` | Verifies the TRF creation form loads with a `<form>` element. |
| `test_trf_detail_editing` | `/trfs/{id}/edit` | Verifies the TRF edit route responds gracefully (200 or 404 for missing IDs). |

### `test_patient_clinician_e2e.py` — Patients & Clinicians

| Test | Route | Description |
|------|-------|-------------|
| `test_patients_listing` | `/patients` | Verifies the patient listing page loads (200). |
| `test_patient_creation` | `/patients/new` | Verifies the patient creation form loads with a `<form>` element. |
| `test_clinicians_listing` | `/clinicians` | Verifies the clinician listing page loads (200). |
| `test_clinician_assignment` | `/clinicians/{id}/users/new` | Verifies the clinician user assignment route responds gracefully (200 or 404). |

### `test_organization_e2e.py` — Organization Management

| Test | Route | Description |
|------|-------|-------------|
| `test_organization_dashboard` | `/my-organization` | Verifies the org dashboard loads with an `<h1>` heading. |
| `test_organization_sites` | `/my-organization/sites` | Verifies the sites listing page loads without crashing. |
| `test_organization_users` | `/my-organization/users` | Verifies the user management page loads with a table or list. |

### `test_logistics_e2e.py` — Logistics & Shipping

| Test | Route | Description |
|------|-------|-------------|
| `test_shipment_operations` | `/shipments` | Verifies the shipment tracking page loads (200). |
| `test_collection_events` | `/collection-events` | Verifies the collection events page loads (200). |
| `test_container_tubes` | `/tubes/{id}` | Verifies the tube detail route responds gracefully (200 or 404). |
| `test_bloom_intake` | `/intake` | Verifies the Bloom intake page loads (200). |
| `test_results_delivery` | `/results` | Verifies the results delivery page loads (200). |
| `test_manifest_uploads` | `/manifests/new` | Verifies the manifest route responds gracefully (200 or 410 if deprecated). |

### `test_documents_e2e.py` — Document Management

| Test | Route | Description |
|------|-------|-------------|
| `test_document_indexing` | `/trfs/{id}/indexing` | Verifies the document OCR indexing route doesn't 500 (200 or 404). |
| `test_document_views` | `/documents/{id}/view` | Verifies the document viewer route doesn't 500 (200 or 404). |

### `test_search_graph_e2e.py` — Search & Graph

| Test | Route | Description |
|------|-------|-------------|
| `test_search_v2` | `/search` | Verifies the unified search page loads with a search input, and submits a test query. |
| `test_graph_viewer` | `/graph` | Verifies the TapDB graph visualization page loads with a canvas or Cytoscape container. |