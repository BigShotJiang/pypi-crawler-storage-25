import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_search_v2(page: Page, base_url: str):
    """Verify unified search functionality and facets across tenants."""
    page.goto(f"{base_url}/search")
    expect(page.locator("body")).to_be_visible()

    # Look for the primary search input box
    search_input = page.locator("input[type='search'], input[placeholder*='Search']").first
    expect(search_input).to_be_visible(timeout=5000)

    # We should have a button to submit or it submits on type
    search_input.fill("test query")
    search_input.press("Enter")


@pytest.mark.e2e
def test_graph_viewer(page: Page, base_url: str):
    """Verify cytoscape TapDB graph visualization loads properly."""
    page.goto(f"{base_url}/graph")
    expect(page.locator("body")).to_be_visible()

    # DAG viewer usually features a canvas element or cytoscape container
    expect(page.locator("canvas, #cy, .cytoscape-container").first).to_be_attached(timeout=10000)
