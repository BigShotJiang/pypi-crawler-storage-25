"""Layer 2 E2E tests — data-dependent workflow verification.

These tests seed data via the Atlas REST API (using the authenticated Playwright
session) and then verify the UI displays it correctly.  They are marked with both
``@pytest.mark.e2e`` and ``@pytest.mark.layer2`` for selective execution.

Isolation strategy:
- Each test uses unique ``E2E-<tag>`` identifiers so records never collide.
- The append-only model means no teardown/cleanup is needed.
"""

import re

import pytest
from playwright.sync_api import Page, expect

# ---------------------------------------------------------------------------
# Patient workflow tests
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.layer2
def test_patient_appears_in_listing(page: Page, base_url: str, seeded_patient):
    """A seeded patient should appear in the patient listing table."""
    patient = seeded_patient
    page.goto(f"{base_url}/patients")
    expect(page.locator("body")).to_be_visible()

    # Use the patient-list search to narrow results
    search_input = page.locator("input[name='search']")
    expect(search_input).to_be_visible(timeout=5000)
    search_input.fill(patient["last_name"])
    page.locator("button[type='submit']").first.click()

    # The table should contain a row with the patient's name
    table = page.locator("table.table")
    expect(table).to_be_visible(timeout=5000)
    row = table.locator("tbody tr", has_text=patient["last_name"])
    expect(row).to_be_visible(timeout=5000)

    # Verify key columns
    expect(row.locator("td").first).to_contain_text(patient["first_name"])
    if patient.get("mrn"):
        expect(row).to_contain_text(patient["mrn"])


@pytest.mark.e2e
@pytest.mark.layer2
def test_patient_detail_displays_correctly(page: Page, base_url: str, seeded_patient):
    """Navigate to the patient detail page and verify demographics."""
    patient = seeded_patient
    page.goto(f"{base_url}/patients/{patient['id']}")
    expect(page.locator("body")).to_be_visible()

    # Page title should include the patient's full name
    heading = page.locator("h1.page-title")
    expect(heading).to_contain_text(patient["first_name"])
    expect(heading).to_contain_text(patient["last_name"])

    # Demographics card
    detail = page.locator(".detail-list").first
    expect(detail).to_contain_text(patient["date_of_birth"])
    if patient.get("mrn"):
        expect(page.locator(".detail-list").first).to_contain_text(patient["mrn"])


@pytest.mark.e2e
@pytest.mark.layer2
def test_patient_create_via_ui(page: Page, base_url: str, e2e_run_id):
    """Fill out the new-patient form and verify the patient is created."""
    from tests.e2e.conftest import _e2e_tag

    tag = _e2e_tag()
    first = f"UIFirst{tag}"
    last = f"UILast{tag}"
    dob = "1985-06-20"

    page.goto(f"{base_url}/patients/new?redirect=/patients")
    expect(page.locator("form")).to_be_visible(timeout=5000)

    page.fill("#first_name", first)
    page.fill("#last_name", last)
    page.fill("#date_of_birth", dob)
    page.select_option("#sex", "M")
    page.fill("#mrn", f"E2E-UI-{e2e_run_id}-{tag}")

    page.locator("button[type='submit']").click()

    # After successful creation, we should be redirected to /patients
    page.wait_for_url(re.compile(r"/patients"), timeout=10000)

    # Search for the new patient
    search_input = page.locator("input[name='search']")
    if search_input.is_visible():
        search_input.fill(last)
        page.locator("button[type='submit']").first.click()
        table = page.locator("table.table")
        expect(table).to_be_visible(timeout=5000)
        expect(table.locator("tbody tr", has_text=last)).to_be_visible(timeout=5000)


# ---------------------------------------------------------------------------
# TRF / Order workflow tests
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.layer2
def test_trf_appears_in_listing(page: Page, base_url: str, seeded_trf):
    """A seeded TRF should appear in the TRF listing."""
    trf = seeded_trf
    page.goto(f"{base_url}/trfs")
    expect(page.locator("body")).to_be_visible()

    table = page.locator("table.table")
    expect(table).to_be_visible(timeout=5000)
    row = table.locator("tbody tr", has_text=trf["trf_euid"])
    expect(row).to_be_visible(timeout=5000)


@pytest.mark.e2e
@pytest.mark.layer2
def test_trf_detail_shows_clinician(page: Page, base_url: str, seeded_trf, seeded_clinician):
    """The TRF detail page should display the linked clinician."""
    page.goto(f"{base_url}/trfs/{seeded_trf['trf_euid']}")
    expect(page.locator("body")).to_be_visible()

    # The clinician name should be visible somewhere on the detail page
    body_text = page.locator("body")
    expect(body_text).to_contain_text(seeded_clinician["last_name"], timeout=5000)


@pytest.mark.e2e
@pytest.mark.layer2
def test_trf_with_test_shows_patient_link(
    page: Page, base_url: str, seeded_trf_with_test, seeded_patient
):
    """A TRF with an attached Test should show the linked patient."""
    trf = seeded_trf_with_test["trf"]
    page.goto(f"{base_url}/trfs/{trf['trf_euid']}")
    expect(page.locator("body")).to_be_visible()

    # The patient name should appear on the TRF detail (linked via the Test)
    body = page.locator("body")
    expect(body).to_contain_text(seeded_patient["last_name"], timeout=5000)


# ---------------------------------------------------------------------------
# Search integration tests
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.layer2
def test_search_finds_seeded_patient(page: Page, base_url: str, seeded_patient):
    """Unified search should return results matching a seeded patient name."""
    patient = seeded_patient
    page.goto(f"{base_url}/search")
    expect(page.locator("body")).to_be_visible()

    search_input = page.locator("input[name='q']")
    expect(search_input).to_be_visible(timeout=5000)
    search_input.fill(patient["last_name"])
    page.locator("button[type='submit']").first.click()

    # Wait for results
    results_area = page.locator("table.table")
    expect(results_area).to_be_visible(timeout=10000)

    # At least one row should contain the patient name
    expect(results_area.locator("tbody tr").first).to_be_visible(timeout=5000)


@pytest.mark.e2e
@pytest.mark.layer2
def test_search_finds_seeded_trf(page: Page, base_url: str, seeded_trf):
    """Unified search should return results matching a TRF EUID."""
    trf_euid = seeded_trf["trf_euid"]
    page.goto(f"{base_url}/search")

    search_input = page.locator("input[name='q']")
    expect(search_input).to_be_visible(timeout=5000)
    search_input.fill(trf_euid)
    page.locator("button[type='submit']").first.click()

    results = page.locator("table.table")
    expect(results).to_be_visible(timeout=10000)
    expect(results.locator("tbody tr", has_text=trf_euid).first).to_be_visible(timeout=5000)


# ---------------------------------------------------------------------------
# Clinician workflow tests
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.layer2
def test_clinician_appears_in_listing(page: Page, base_url: str, seeded_clinician):
    """A seeded clinician should appear in the clinicians listing."""
    page.goto(f"{base_url}/clinicians")
    expect(page.locator("body")).to_be_visible()

    table = page.locator("table.table")
    expect(table).to_be_visible(timeout=5000)
    row = table.locator("tbody tr", has_text=seeded_clinician["last_name"])
    expect(row).to_be_visible(timeout=5000)
    expect(row).to_contain_text(seeded_clinician["first_name"])


@pytest.mark.e2e
@pytest.mark.layer2
def test_clinician_detail_page(page: Page, base_url: str, seeded_clinician):
    """Clinician detail page should render correctly for a seeded clinician."""
    page.goto(f"{base_url}/clinicians/{seeded_clinician['id']}")
    expect(page.locator("body")).to_be_visible()

    heading = page.locator("h1.page-title")
    expect(heading).to_contain_text(seeded_clinician["last_name"], timeout=5000)


# ---------------------------------------------------------------------------
# Cross-entity relationship tests
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.layer2
def test_patient_detail_shows_linked_orders(
    page: Page, base_url: str, seeded_trf_with_test, seeded_patient
):
    """Patient detail page should list orders linked through Tests."""
    page.goto(f"{base_url}/patients/{seeded_patient['id']}")
    expect(page.locator("body")).to_be_visible()

    # The TRF EUID should appear in the patient's orders/tests section
    trf_euid = seeded_trf_with_test["trf"]["trf_euid"]
    body = page.locator("body")
    expect(body).to_contain_text(trf_euid, timeout=5000)
