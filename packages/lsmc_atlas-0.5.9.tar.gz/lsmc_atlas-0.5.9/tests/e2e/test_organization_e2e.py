import re

import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_organization_dashboard(page: Page, base_url: str):
    """Verify org dashboard navigation and key elements."""
    # Assuming authenticated session via fixture in the future
    # For now, we simulate the navigation to the org dashboard
    page.goto(f"{base_url}/my-organization")

    # Wait for the main content to load
    expect(page.locator("body")).to_be_visible()

    # We expect some heading indicating the organization context
    # Use generic locators that would fail gracefully if the page 500s or is unauthorized
    heading = page.locator("h1").first
    expect(heading).to_be_visible()


@pytest.mark.e2e
def test_organization_sites(page: Page, base_url: str):
    """Verify site creation flows and listing."""
    page.goto(f"{base_url}/my-organization/sites")
    expect(page.locator("body")).to_be_visible()

    # Check if a 'New Site' or similar button is present
    # This verifies the user has permissions to see the action
    page.get_by_role("link", name=re.compile(r"New|Add", re.IGNORECASE))

    # We just ensure the page renders without crashing.
    # In a fully seeded environment, we would click the button and fill the form:
    # new_site_btn.click()
    # expect(page).to_have_url(f"{base_url}/my-organization/sites/new")
    # page.get_by_label("Site Name").fill("Test Site")
    # page.get_by_role("button", name="Submit").click()


@pytest.mark.e2e
def test_organization_users(page: Page, base_url: str):
    """Verify user management views render a data table."""
    page.goto(f"{base_url}/my-organization/users")
    expect(page.locator("body")).to_be_visible()

    # Expect a table or list of users to be present
    expect(page.locator("table, .user-list, [data-testid='user-table']").first).to_be_attached()
