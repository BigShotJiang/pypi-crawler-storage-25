import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_shipment_operations(page: Page, base_url: str):
    """Verify shipment tracking page loads without errors."""
    response = page.goto(f"{base_url}/shipments")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_collection_events(page: Page, base_url: str):
    """Verify collection events page loads without errors."""
    response = page.goto(f"{base_url}/collection-events")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_container_tubes(page: Page, base_url: str):
    """Verify tube detail route responds gracefully for unknown IDs."""
    response = page.goto(f"{base_url}/tubes/DUMMY_CONTAINER")
    assert response is not None
    # May be 404 for a non-existent container — that's expected
    assert response.status in (200, 404)


@pytest.mark.e2e
def test_bloom_intake(page: Page, base_url: str):
    """Verify intake page loads without errors."""
    response = page.goto(f"{base_url}/intake")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_results_delivery(page: Page, base_url: str):
    """Verify results page loads without errors."""
    response = page.goto(f"{base_url}/results")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_manifest_uploads(page: Page, base_url: str):
    """Verify manifest route responds gracefully (may be deprecated)."""
    response = page.goto(f"{base_url}/manifests/new")
    assert response is not None
    # Route may return 200 (active) or 410 (deprecated) — both are valid
    assert response.status in (200, 410)
    expect(page.locator("body")).to_be_visible()
