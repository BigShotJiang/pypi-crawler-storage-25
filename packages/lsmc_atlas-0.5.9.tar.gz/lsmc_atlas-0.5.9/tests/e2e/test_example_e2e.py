import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_atlas_login_page_loads(page: Page, base_url: str):
    """
    Verify that the Atlas web server is reachable and UI loads basic content.
    Requires server to be running on `base_url` (default http://localhost:8915).
    """
    # Navigate to the base URL
    response = page.goto(base_url)

    # Assert network success
    assert response is not None
    assert response.ok, f"Expected 200 OK from server at {base_url}, but got {response.status}"

    # Playwright will wait until the page is fully loaded, then we can check title or content
    # Look for common Atlas elements. Usually there's a login form or a title indicating the app.
    # Note: If there's a specific title or h1 tag this application uses, we assert it here.
    # For a general check, we'll verify the page title is not completely empty, or wait for the body.
    expect(page.locator("body")).to_be_visible()
