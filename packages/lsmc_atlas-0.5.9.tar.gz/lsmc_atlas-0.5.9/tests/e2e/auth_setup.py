import os

from playwright.sync_api import expect, sync_playwright


def setup_auth():
    auth_file = ".auth/state.json"
    os.makedirs(".auth", exist_ok=True)

    email = os.getenv("E2E_USER_EMAIL")
    password = os.getenv("E2E_USER_PASSWORD")
    base_url = os.getenv("ATLAS_BASE_URL", "https://localhost:8915")

    if not email or not password:
        print("E2E_USER_EMAIL and E2E_USER_PASSWORD must be set. Skipping auth generation.")
        return

    with sync_playwright() as p:
        browser = p.chromium.launch()
        context = browser.new_context(ignore_https_errors=True)
        page = context.new_page()

        # Navigate to login which redirects to Cognito
        page.goto(f"{base_url}/auth/login")

        # Wait for Cognito inputs. Use :visible pseudo-selector because Cognito renders multiple hidden versions.
        user_input = page.locator(
            "input[name='username']:visible, input[type='email']:visible"
        ).first
        pass_input = page.locator(
            "input[name='password']:visible, input[type='password']:visible"
        ).first
        submit_btn = page.locator(
            "input[name='signInSubmitButton']:visible, button[type='submit']:visible"
        ).first

        expect(user_input).to_be_visible(timeout=10000)
        user_input.fill(email)
        pass_input.fill(password)
        submit_btn.click()

        # Wait to be redirected back to the Atlas app dashboard or homepage
        page.wait_for_url(f"{base_url}/**", timeout=15000)

        # Save cookies and local storage
        context.storage_state(path=auth_file)
        print(f"Authentication state saved to {auth_file}")
        browser.close()


if __name__ == "__main__":
    setup_auth()
