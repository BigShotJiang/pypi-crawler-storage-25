import os
import subprocess
import uuid

import pytest

# ---------------------------------------------------------------------------
# Layer 1 fixtures (authentication & browser context)
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def setup_auth(base_url):
    """Authenticate once per session against Cognito and save the storage state."""
    auth_file = ".auth/state.json"

    email = os.getenv("E2E_USER_EMAIL")
    password = os.getenv("E2E_USER_PASSWORD")

    if not email or not password:
        pytest.skip("E2E_USER_EMAIL and E2E_USER_PASSWORD must be set to run E2E Auth.")

    # Run the separate script to avoid asyncio loop errors with pytest-playwright
    # and sync_playwright.
    subprocess.run(["python", "tests/e2e/auth_setup.py"], check=True)

    return auth_file


@pytest.fixture(scope="session")
def browser_context_args(browser_context_args, setup_auth):
    """Override Playwright browser context to load the saved auth state."""
    return {**browser_context_args, "ignore_https_errors": True, "storage_state": setup_auth}


@pytest.fixture(scope="session")
def base_url():
    """
    Override the base_url for playwright.
    By default, atlas server starts on port 8915 using HTTPS.
    You can override this by setting the ATLAS_BASE_URL environment variable.
    """
    return os.getenv("ATLAS_BASE_URL", "https://localhost:8915")


# ---------------------------------------------------------------------------
# Layer 2 fixtures — API-based data seeding
# ---------------------------------------------------------------------------
# E2E tests run against a live Atlas server, so data is seeded via the REST
# API using the authenticated Playwright session.  Each seeded record uses a
# unique identifier prefix ("E2E-<short-uuid>") to guarantee isolation across
# parallel runs and to make test data easy to identify.
#
# Because the data model is append-only, there is no teardown / cleanup.
# ---------------------------------------------------------------------------


def _e2e_tag() -> str:
    """Return a short unique tag for this test run."""
    return uuid.uuid4().hex[:8].upper()


@pytest.fixture(scope="session")
def e2e_run_id():
    """A unique tag shared across all tests in a single session."""
    return _e2e_tag()


@pytest.fixture()
def seeded_patient(page, base_url, e2e_run_id):
    """Create a patient via the REST API and return the response dict.

    The patient is identifiable by an MRN of ``E2E-<run_id>`` so it can be
    located in search and listing views.
    """
    tag = _e2e_tag()
    payload = {
        "first_name": f"E2EFirst{tag}",
        "last_name": f"E2ELast{tag}",
        "date_of_birth": "1990-01-15",
        "sex": "F",
        "mrn": f"E2E-{e2e_run_id}-{tag}",
        "email": f"e2e-{tag}@test.lsmc.bio",
        "phone": "(555) 000-0000",
        "city": "TestCity",
        "state": "NY",
        "postal_code": "10001",
        "country": "US",
    }
    resp = page.request.post(f"{base_url}/api/patients", data=payload)
    assert resp.status == 201, f"Patient seed failed: {resp.status} {resp.text()}"
    return resp.json()


@pytest.fixture()
def seeded_clinician(page, base_url, e2e_run_id):
    """Create a clinician via the REST API and return the response dict."""
    tag = _e2e_tag()
    payload = {
        "first_name": f"DrFirst{tag}",
        "last_name": f"DrLast{tag}",
        "credentials": "MD",
        "npi": f"E2E{tag}",
        "email": f"dr-{tag}@test.lsmc.bio",
        "specialty": "Genetics",
    }
    resp = page.request.post(f"{base_url}/api/clinicians", data=payload)
    assert resp.status == 201, f"Clinician seed failed: {resp.status} {resp.text()}"
    return resp.json()


@pytest.fixture()
def seeded_trf(page, base_url, seeded_clinician):
    """Create a TRF (order) via the REST API and return the response dict."""
    payload = {
        "clinician_id": seeded_clinician["id"],
        "trf_type": "CLINICAL",
        "clinical_notes": "E2E test TRF",
    }
    resp = page.request.post(f"{base_url}/api/trfs", data=payload)
    assert resp.status == 201, f"TRF seed failed: {resp.status} {resp.text()}"
    return resp.json()


@pytest.fixture()
def seeded_trf_with_test(page, base_url, seeded_trf, seeded_patient):
    """Create a TRF with an attached Test (linked to a patient).

    Returns a dict with keys ``trf`` and ``test``.
    """
    trf_euid = seeded_trf["trf_euid"]
    payload = {
        "patients": [{"patient_euid": seeded_patient["id"], "role": "PROBAND"}],
        "fulfillment_routes": [
            {
                "fulfillment_route_code": "WGS-SR",
                "fulfillment_route_name": "Whole Genome Short Read",
            }
        ],
        "specimen_type": "blood",
        "priority": "NORMAL",
        "clinical_notes": "E2E test order",
    }
    resp = page.request.post(f"{base_url}/api/trfs/{trf_euid}/tests", data=payload)
    assert resp.status == 201, f"Test seed failed: {resp.status} {resp.text()}"
    return {"trf": seeded_trf, "test": resp.json()}
