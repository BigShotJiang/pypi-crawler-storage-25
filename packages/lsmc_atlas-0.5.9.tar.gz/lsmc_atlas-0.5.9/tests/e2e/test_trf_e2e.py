import re

import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_trf_listing(page: Page, base_url: str):
    """Verify the primary TRF operations view."""
    page.goto(f"{base_url}/trfs")
    expect(page.locator("body")).to_be_visible()

    # Verify page title has TRF or Test Request Form
    expect(
        page.locator("h1, h2").filter(has_text=re.compile(r"TRF", re.IGNORECASE)).first
    ).to_be_visible(timeout=5000)


@pytest.mark.e2e
def test_trf_creation(page: Page, base_url: str):
    """Verify TRF request generation forms."""
    page.goto(f"{base_url}/trfs/new")
    expect(page.locator("body")).to_be_visible()

    # The form should exist and have a submit action
    expect(page.locator("form").first).to_be_attached()


@pytest.mark.e2e
def test_trf_detail_editing(page: Page, base_url: str):
    """Verify ability to edit specific TRF attributes."""
    # Assuming TRF ID 'DUMMY_EUID'
    response = page.goto(f"{base_url}/trfs/DUMMY_EUID/edit")
    assert response is not None
    # Depending on auth and data state, we might get a 404. We just assert playwright can interact.
    if response.status == 200:
        expect(page.locator("form").first).to_be_visible()
