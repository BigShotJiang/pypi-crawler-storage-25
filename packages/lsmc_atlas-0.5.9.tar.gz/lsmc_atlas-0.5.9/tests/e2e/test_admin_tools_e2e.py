import pytest
from playwright.sync_api import Page, expect


@pytest.mark.e2e
def test_admin_groups(page: Page, base_url: str):
    """Verify admin group configuration page loads without errors."""
    response = page.goto(f"{base_url}/admin/groups")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_api_clients(page: Page, base_url: str):
    """Verify API client management page loads without errors."""
    response = page.goto(f"{base_url}/api-clients")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()


@pytest.mark.e2e
def test_webhook_subscriptions(page: Page, base_url: str):
    """Verify webhook subscription page loads without errors."""
    response = page.goto(f"{base_url}/webhooks")
    assert response is not None
    assert response.status == 200
    expect(page.locator("body")).to_be_visible()
