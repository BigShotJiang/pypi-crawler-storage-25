"""Unit tests for Atlas users CLI (TapDB-only)."""

from __future__ import annotations

import uuid

import pytest
import typer

from app.auth.rbac import Role
from app.domain.services.users import UserCreate, UserService
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


def test_cli_make_admin_updates_roles_without_legacy_tables(monkeypatch, db_session):
    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-tenant")

    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="someone@example.com",
            name="Someone",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value],
            cognito_sub="mock-sub-1",
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)

    users_cli.make_admin(created.email, tenant_id=None, auto_provision=False)

    updated = svc.get_by_email(created.email)
    assert updated is not None
    assert Role.ADMIN.value in (updated.roles or [])


def test_cli_make_admin_auto_provisions_when_user_missing(monkeypatch, db_session):
    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-tenant-2")

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)
    monkeypatch.setattr(
        "app.auth.cognito_admin.admin_find_user_by_email",
        lambda email: {
            "username": "Google_123",
            "sub": "mock-google-sub",
            "email": email,
            "name": "John D",
            "attributes": {"sub": "mock-google-sub", "email": email},
        },
    )

    email = "missing.user@example.com"
    users_cli.make_admin(email, tenant_id=str(tenant_uuid), auto_provision=True)

    svc = UserService(db_session)
    user = svc.get_by_email(email)
    assert user is not None
    assert user.cognito_sub == "mock-google-sub"
    assert Role.ADMIN.value in (user.roles or [])


def test_cli_users_does_not_shell_out(monkeypatch, db_session):
    """Regression guard: atlas users commands must not call subprocess-run scripts."""
    import subprocess

    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-tenant-3")

    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="noshell@example.com",
            name="No Shell",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value],
            cognito_sub="mock-sub-2",
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)

    def boom(*_args, **_kwargs):
        raise AssertionError("subprocess.run should not be called by atlas users commands")

    monkeypatch.setattr(subprocess, "run", boom)

    users_cli.make_admin(created.email, tenant_id=None, auto_provision=False)


def test_cli_roles_add_assigns_role(monkeypatch, db_session):
    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-roles")

    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="roles-add@example.com",
            name="Roles Add",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value],
            cognito_sub=str(uuid.uuid4()),
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)
    users_cli.roles_add(created.email, "INTERNAL_USER")

    updated = svc.get_by_email(created.email)
    assert updated is not None
    assert Role.INTERNAL_USER.value in (updated.roles or [])


def test_cli_roles_set_replaces_role_list(monkeypatch, db_session):
    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-roles-set")

    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="roles-set@example.com",
            name="Roles Set",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value, Role.ADMIN.value],
            cognito_sub=str(uuid.uuid4()),
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)
    users_cli.roles_set(created.email, ["INTERNAL_USER", "ADMIN"])

    updated = svc.get_by_email(created.email)
    assert updated is not None
    assert updated.roles == [Role.INTERNAL_USER.value, Role.ADMIN.value]


def test_cli_groups_add_grants_membership(monkeypatch, db_session):
    from app.cli import users as users_cli
    from app.domain.services.groups import UserGroupService

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-groups")

    user_sub = uuid.uuid4()
    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="groups-add@example.com",
            name="Groups Add",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value],
            cognito_sub=str(user_sub),
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)
    users_cli.groups_add(created.email, "API_ACCESS")

    group_svc = UserGroupService(db_session, tenant_uuid)
    group_info = group_svc.get_group_by_code("API_ACCESS")
    assert group_info is not None
    members = group_svc.list_group_members(group_info.euid)
    assert any(str(getattr(membership, "user_id", "")) == str(user_sub) for membership in members)


def test_get_user_by_identifier_prefers_id_then_email():
    from app.cli import users as users_cli

    class _Svc:
        def __init__(self):
            self.calls = []

        def get_by_id(self, value):
            self.calls.append(("id", value))
            return "USER-ID-RESULT" if value == "by-id" else None

        def get_by_email(self, value):
            self.calls.append(("email", value))
            return "USER-EMAIL-RESULT" if value == "by-email" else None

    svc = _Svc()
    assert users_cli._get_user_by_identifier(svc, "by-id") == "USER-ID-RESULT"
    assert users_cli._get_user_by_identifier(svc, "by-email") == "USER-EMAIL-RESULT"
    assert users_cli._get_user_by_identifier(svc, "missing") is None


def test_cli_roles_add_rejects_blank_role():
    from app.cli import users as users_cli

    with pytest.raises(typer.Exit):
        users_cli.roles_add("user@example.com", "   ")


def test_cli_groups_add_rejects_blank_group_code():
    from app.cli import users as users_cli

    with pytest.raises(typer.Exit):
        users_cli.groups_add("user@example.com", "   ")


def test_cli_groups_add_rejects_non_uuid_cognito_sub(monkeypatch, db_session):
    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-groups-invalid-sub")
    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="groups-bad-sub@example.com",
            name="Groups Bad Sub",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value],
            cognito_sub="not-a-uuid",
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)
    with pytest.raises(typer.Exit):
        users_cli.groups_add(created.email, "API_ACCESS")


def test_cli_remove_admin_removes_role(monkeypatch, db_session):
    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-remove-admin")
    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="remove-admin@example.com",
            name="Remove Admin",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value, Role.ADMIN.value],
            cognito_sub=str(uuid.uuid4()),
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)
    users_cli.remove_admin(created.email)
    updated = svc.get_by_email(created.email)
    assert updated is not None
    assert Role.ADMIN.value not in (updated.roles or [])


def test_cli_make_ext_admin_and_remove_ext_admin(monkeypatch, db_session):
    from app.cli import users as users_cli

    tenant_uuid = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_uuid, name="cli-users-ext-admin")
    svc = UserService(db_session)
    created = svc.create(
        UserCreate(
            email="ext-admin@example.com",
            name="External Admin",
            tenant_id=tenant_uuid,
            roles=[Role.EXTERNAL_USER.value],
            cognito_sub=str(uuid.uuid4()),
        )
    )

    monkeypatch.setattr(users_cli, "SessionLocal", lambda: db_session)
    users_cli.make_ext_admin(created.email, tenant_id=None, auto_provision=False)
    promoted = svc.get_by_email(created.email)
    assert promoted is not None
    assert Role.EXTERNAL_USER_ADMIN.value in (promoted.roles or [])

    users_cli.remove_ext_admin(created.email)
    demoted = svc.get_by_email(created.email)
    assert demoted is not None
    assert Role.EXTERNAL_USER_ADMIN.value not in (demoted.roles or [])
