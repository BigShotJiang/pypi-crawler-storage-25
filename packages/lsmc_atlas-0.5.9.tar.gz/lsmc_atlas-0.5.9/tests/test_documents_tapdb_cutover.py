"""Unit tests for TapDB cutover behavior in DocumentService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from types import SimpleNamespace

from app.domain.services.documents import DocumentService, DocumentUpload


@dataclass
class _MockDB:
    def add(self, _obj):
        return None

    def commit(self):
        return None


class _FakeS3Client:
    def put_object(self, **kwargs):
        return {"ETag": "etag"}

    def generate_presigned_url(self, op, Params, ExpiresIn):
        return f"https://example.com/{Params['Bucket']}/{Params['Key']}"


class _FakeDocumentRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.document = SimpleNamespace(
            id=uuid.uuid4(),
            euid=f"DOC-{uuid.uuid4().int % 10000}",
            tenant_id=tenant_id,
            created_at=datetime.now(UTC),
            created_by=uuid.uuid4(),
        )
        self.revision = SimpleNamespace(
            revision_id=uuid.uuid4(),
            document_id=self.document.euid,
            revision_no=1,
            filename="report.pdf",
            content_type="application/pdf",
            size_bytes=0,
            s3_bucket="bucket",
            s3_key="key",
            document_type="report",
            created_at=datetime.now(UTC),
            created_by=self.document.created_by,
            note=None,
        )

    def create_document(self, tenant_id, data, created_by, restricted_to_user_id=None):
        self.calls.append("create_document")
        self.revision.filename = data.filename
        self.revision.content_type = data.content_type
        self.revision.size_bytes = data.size_bytes
        self.revision.s3_bucket = data.s3_bucket or "bucket"
        self.revision.s3_key = data.s3_key or "key"
        self.revision.document_type = data.document_type
        return self.document, self.revision

    def get_document(self, document_euid, tenant_id, user_id=None, is_internal=False):
        self.calls.append("get_document")
        if document_euid != self.document.euid:
            return None
        return self.document, self.revision

    def list_documents(
        self, tenant_id, skip=0, limit=50, document_type=None, user_id=None, is_internal=False
    ):
        self.calls.append("list_documents")
        return [(self.document, self.revision)]

    def add_link_event(
        self,
        tenant_id,
        action,
        source_type,
        source_id,
        target_type,
        target_id,
        created_by,
    ):
        self.calls.append("add_link_event")

    def get_linked_documents(self, tenant_id, entity_type, entity_id):
        self.calls.append("get_linked_documents")
        return [(self.document, self.revision)]


def test_document_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = DocumentService(_MockDB(), tenant_id=tenant_id, user_id=str(uuid.uuid4()))
    repo = _FakeDocumentRepo(tenant_id)

    monkeypatch.setattr(svc, "_repo", lambda: repo)
    svc._s3_client = _FakeS3Client()

    uploaded = svc.upload(
        DocumentUpload(
            filename="report.pdf",
            content=b"hello world",
            content_type="application/pdf",
            document_type="report",
        ),
        created_by=uuid.uuid4(),
    )
    assert uploaded.document_euid == repo.document.euid

    doc = svc.get(repo.document.euid)
    assert doc is not None

    docs = svc.list_documents(limit=10)
    assert len(docs) == 1

    url = svc.get_download_url(repo.document.euid)
    assert url is not None
    from urllib.parse import urlparse

    _parsed = urlparse(url)
    assert _parsed.scheme == "https"
    assert _parsed.hostname == "example.com"

    target_id = uuid.uuid4()
    svc.link_to_entity(repo.document.euid, "ORDER", target_id, created_by=uuid.uuid4())
    svc.unlink_from_entity(repo.document.euid, "ORDER", target_id, created_by=uuid.uuid4())

    linked = svc.get_linked_documents("ORDER", target_id)
    assert len(linked) == 1

    svc.audit_download(repo.document.euid, downloaded_by=uuid.uuid4())

    assert repo.calls == [
        "create_document",
        "get_document",
        "list_documents",
        "get_document",
        "add_link_event",
        "add_link_event",
        "get_linked_documents",
        "get_document",
    ]
