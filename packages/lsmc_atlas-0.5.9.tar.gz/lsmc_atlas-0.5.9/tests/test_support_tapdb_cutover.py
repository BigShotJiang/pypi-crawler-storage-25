"""Unit tests for TapDB cutover behavior in SupportTicketService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest

from app.domain.services.support import SupportTicketService, TicketCreate, TicketUpdate


@dataclass
class _MockDB:
    def add(self, _obj):
        return None

    def commit(self):
        return None


class _FakeSupportRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.ticket = SimpleNamespace(
            id=uuid.uuid4(),
            euid=f"TKT-{uuid.uuid4().int % 10000}",
            tenant_id=tenant_id,
            ticket_number="TKT-1",
            created_at=datetime.now(UTC),
            created_by=uuid.uuid4(),
        )
        self.revision = SimpleNamespace(
            id=uuid.uuid4(),
            ticket_id=self.ticket.euid,
            revision_no=1,
            subject="Need help",
            description="Issue details",
            ticket_type="TECHNICAL",
            priority="NORMAL",
            status="OPEN",
            assigned_to=None,
            related_order_id=None,
            related_shipment_id=None,
            resolution_notes=None,
            resolved_at=None,
            resolved_by=None,
            created_at=datetime.now(UTC),
            created_by=self.ticket.created_by,
        )

    def generate_next_ticket_number(self):
        self.calls.append("generate_next_ticket_number")
        return "TKT-1"

    def create_ticket(self, tenant_id, ticket_number, data, created_by):
        self.calls.append("create_ticket")
        self.ticket.ticket_number = ticket_number
        self.revision.subject = data.subject
        self.revision.description = data.description
        self.revision.ticket_type = data.ticket_type
        self.revision.priority = data.priority
        self.revision.status = data.status
        return self.ticket, self.revision

    def get_ticket_with_revision(self, ticket_id, tenant_id):
        self.calls.append("get_ticket_with_revision")
        if ticket_id != self.ticket.euid:
            return None
        return self.ticket, self.revision

    def get_ticket_by_number(self, ticket_number, tenant_id):
        self.calls.append("get_ticket_by_number")
        if ticket_number != self.ticket.ticket_number:
            return None
        return self.ticket, self.revision

    def list_tickets(
        self, tenant_id, skip=0, limit=50, status=None, ticket_type=None, assigned_to=None
    ):
        self.calls.append("list_tickets")
        return [(self.ticket, self.revision)]

    def update_ticket(self, ticket_id, tenant_id, data, updated_by):
        self.calls.append("update_ticket")
        if data.status is not None:
            self.revision.status = data.status
        if data.assigned_to is not None:
            self.revision.assigned_to = data.assigned_to
        if data.priority is not None:
            self.revision.priority = data.priority
        return self.ticket, self.revision

    def resolve_ticket(self, ticket_id, tenant_id, resolution_notes, resolver_id):
        self.calls.append("resolve_ticket")
        self.revision.status = "RESOLVED"
        self.revision.resolution_notes = resolution_notes
        self.revision.resolved_by = resolver_id
        self.revision.resolved_at = datetime.now(UTC)
        return self.ticket, self.revision


def test_support_ticket_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = SupportTicketService(_MockDB(), tenant_id=tenant_id, user_id=uuid.uuid4())
    repo = _FakeSupportRepo(tenant_id)
    monkeypatch.setattr(
        "app.domain.services.site_scope.resolve_tenant_site_euid",
        lambda _db, _tenant_id, site_euid, **_kwargs: site_euid or "STX-TEST",
    )
    monkeypatch.setattr(svc, "_repo", lambda: repo)

    created = svc.create(
        TicketCreate(
            subject="Need help",
            description="Issue details",
            ticket_type="TECHNICAL",
            priority="NORMAL",
        ),
        created_by=uuid.uuid4(),
    )
    assert created[0].ticket_number == "TKT-1"

    assert svc.get_by_id(repo.ticket.euid) is not None
    assert svc.get_by_ticket_number("TKT-1") is not None
    assert len(svc.list_tickets()) == 1

    updated = svc.update(
        repo.ticket.euid,
        TicketUpdate(priority="HIGH", status="IN_PROGRESS"),
        updated_by=uuid.uuid4(),
    )
    assert updated is not None
    assert updated[1].status == "IN_PROGRESS"

    assigned_to = uuid.uuid4()
    assigned = svc.assign(repo.ticket.euid, assigned_to=assigned_to, updated_by=uuid.uuid4())
    assert assigned is not None
    assert assigned[1].assigned_to == assigned_to

    resolved = svc.resolve(repo.ticket.euid, resolution_notes="Done", updated_by=uuid.uuid4())
    assert resolved is not None
    assert resolved[1].status == "RESOLVED"
    assert resolved[1].resolution_notes == "Done"

    assert repo.calls == [
        "generate_next_ticket_number",
        "create_ticket",
        "get_ticket_with_revision",
        "get_ticket_by_number",
        "list_tickets",
        "update_ticket",
        "update_ticket",
        "resolve_ticket",
    ]


def test_support_ticket_service_validates_enums(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = SupportTicketService(_MockDB(), tenant_id=tenant_id)
    monkeypatch.setattr(svc, "_repo", lambda: _FakeSupportRepo(tenant_id))

    with pytest.raises(ValueError, match="Invalid ticket type"):
        svc.create(TicketCreate(subject="x", description="x", ticket_type="NOPE"))

    with pytest.raises(ValueError, match="Invalid priority"):
        svc.create(
            TicketCreate(
                subject="x",
                description="x",
                ticket_type="TECHNICAL",
                priority="SUPER_HIGH",
            )
        )
