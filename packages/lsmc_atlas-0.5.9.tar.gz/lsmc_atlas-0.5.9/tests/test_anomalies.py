"""Tests for Atlas-local anomaly persistence, auth, redaction, and UI."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.api.routes import anomalies as api_anomalies
from app.auth.dependencies import CurrentUser, get_current_user_web
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from app.observability.anomalies import AnomalyRecord, TapdbAnomalyRepository
from app.settings import settings
from app.web.routes import anomalies as web_anomalies


class _FakeSession:
    def add(self, _obj) -> None:
        return None

    def flush(self) -> None:
        return None

    def commit(self) -> None:
        return None


def _build_fake_persistence_repository() -> TapdbAnomalyRepository:
    repository = TapdbAnomalyRepository(_FakeSession())
    instances: list[SimpleNamespace] = []
    counter = {"value": 0}

    def create_instance(*, template_code: str, name: str, properties: dict, session) -> SimpleNamespace:
        counter["value"] += 1
        category, type_, subtype, version = template_code.strip("/").split("/")
        instance = SimpleNamespace(
            euid=f"ANM-{counter['value']:04d}",
            name=name,
            json_addl={"properties": properties},
            created_dt=datetime.now(UTC),
            category=category,
            type=type_,
            subtype=subtype,
            version=version,
            is_deleted=False,
        )
        instances.append(instance)
        return instance

    repository._ensure_template = lambda: None  # type: ignore[method-assign]
    repository._list_instances = lambda: list(instances)  # type: ignore[method-assign]
    repository.factory = SimpleNamespace(create_instance=create_instance)
    return repository


def _sample_record() -> AnomalyRecord:
    now = datetime.now(UTC).isoformat()
    return AnomalyRecord(
        id="ANM-0001",
        service="atlas",
        environment="test",
        category="database",
        severity="error",
        fingerprint="fp-sample",
        summary="Atlas database probe failed",
        first_seen_at=now,
        last_seen_at=now,
        occurrence_count=2,
        redacted_context={"token": "[redacted]", "sql": "[redacted-sql]"},
        source_view_url="/admin/anomalies/ANM-0001",
    )


class _StubAnomalyRepository:
    def __init__(self, _db):
        self._record = _sample_record()

    def list(self, *, skip: int = 0, limit: int = 100) -> list[AnomalyRecord]:
        return [self._record][skip : skip + limit]

    def get(self, anomaly_id: str) -> AnomalyRecord | None:
        if anomaly_id == self._record.id:
            return self._record
        return None


@pytest.fixture
def anomaly_client():
    def override_get_db():
        yield None

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app, raise_server_exceptions=False) as client:
        yield client
    app.dependency_overrides.clear()


@pytest.fixture
def internal_web_user() -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="atlas-anomaly-admin@lsmc.bio",
        name="Atlas Anomaly Admin",
        tenant_id=uuid.uuid4(),
        roles=[Role.ADMIN.value, Role.INTERNAL_USER.value],
    )


def test_anomaly_repository_upserts_and_redacts_context() -> None:
    repository = _build_fake_persistence_repository()
    context = {
        "authorization": "Bearer super-secret-token",
        "nested": {
            "cookie": "session=abc123",
            "path": "/documents/123456/details",
            "sql": "SELECT * FROM users WHERE id = 123456 AND email = 'secret@example.com'",
        },
        "items": [
            {"password": "open-sesame"},
            "/patients/987654321",
        ],
    }

    first = repository.record(
        category="database",
        severity="error",
        fingerprint="fp-db-probe",
        summary="Atlas database probe failed",
        redacted_context=context,
    )
    second = repository.record(
        category="database",
        severity="error",
        fingerprint="fp-db-probe",
        summary="Atlas database probe failed",
        redacted_context=context,
    )

    assert second.id == first.id
    assert len(repository.list()) == 1
    assert second.occurrence_count == 2
    assert second.redacted_context["authorization"] == "[redacted]"
    assert second.redacted_context["nested"]["cookie"] == "[redacted]"
    assert second.redacted_context["nested"]["path"] == "/documents/{id}/details"
    assert second.redacted_context["nested"]["sql"] == "[redacted-sql]"
    assert second.redacted_context["items"][0]["password"] == "[redacted]"
    assert second.redacted_context["items"][1] == "/patients/{id}"


def test_anomalies_api_requires_auth(anomaly_client: TestClient) -> None:
    response = anomaly_client.get("/api/anomalies")

    assert response.status_code == 401


def test_anomalies_api_lists_and_reads_records(monkeypatch, anomaly_client: TestClient) -> None:
    monkeypatch.setattr(api_anomalies, "TapdbAnomalyRepository", _StubAnomalyRepository)
    headers = {"Authorization": f"Bearer {settings.internal_api_key}"}

    list_response = anomaly_client.get("/api/anomalies", headers=headers)
    detail_response = anomaly_client.get("/api/anomalies/ANM-0001", headers=headers)
    missing_response = anomaly_client.get("/api/anomalies/ANM-DOES-NOT-EXIST", headers=headers)

    assert list_response.status_code == 200
    list_payload = list_response.json()
    assert list_payload["service"] == "atlas"
    assert list_payload["count"] == 1
    item = list_payload["items"][0]
    assert set(item) == {
        "id",
        "service",
        "environment",
        "category",
        "severity",
        "fingerprint",
        "summary",
        "first_seen_at",
        "last_seen_at",
        "occurrence_count",
        "redacted_context",
        "source_view_url",
    }
    assert item["redacted_context"]["token"] == "[redacted]"
    assert item["redacted_context"]["sql"] == "[redacted-sql]"

    assert detail_response.status_code == 200
    assert detail_response.json()["item"]["id"] == "ANM-0001"

    assert missing_response.status_code == 404


def test_obs_services_advertises_anomaly_capability(anomaly_client: TestClient) -> None:
    response = anomaly_client.get(
        "/obs_services",
        headers={"Authorization": f"Bearer {settings.internal_api_key}"},
    )

    assert response.status_code == 200
    payload = response.json()
    endpoints = {entry["path"]: entry for entry in payload["endpoints"]}
    assert endpoints["/api/anomalies"]["kind"] == "anomaly_list"
    assert endpoints["/api/anomalies/{anomaly_id}"]["kind"] == "anomaly_detail"
    assert "atlas.anomalies_v1" in payload["extensions"]


def test_admin_anomalies_view_requires_internal(anomaly_client: TestClient) -> None:
    response = anomaly_client.get("/admin/anomalies", follow_redirects=False)

    assert response.status_code in (302, 401)


def test_admin_anomalies_view_renders_redacted_record(
    monkeypatch,
    anomaly_client: TestClient,
    internal_web_user: CurrentUser,
) -> None:
    monkeypatch.setattr(web_anomalies, "TapdbAnomalyRepository", _StubAnomalyRepository)

    def override_get_current_user_web():
        return internal_web_user

    app.dependency_overrides[get_current_user_web] = override_get_current_user_web
    try:
        list_response = anomaly_client.get("/admin/anomalies")
        detail_response = anomaly_client.get("/admin/anomalies/ANM-0001")
        missing_response = anomaly_client.get("/admin/anomalies/ANM-DOES-NOT-EXIST")
    finally:
        app.dependency_overrides.pop(get_current_user_web, None)

    assert list_response.status_code == 200
    assert "Operational Anomalies" in list_response.text
    assert "Atlas database probe failed" in list_response.text

    assert detail_response.status_code == 200
    assert "ANM-0001" in detail_response.text
    assert "[redacted]" in detail_response.text
    assert "[redacted-sql]" in detail_response.text

    assert missing_response.status_code == 404
