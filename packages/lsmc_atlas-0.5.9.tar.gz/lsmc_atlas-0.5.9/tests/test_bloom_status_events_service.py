"""Integration-style tests for Bloom status-event application service."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import pytest
from sqlalchemy.orm import Session

from app.domain.enums import TestOrderStatus as OrderTestStatus
from app.domain.services.bloom_status_events import BloomStatusEventService
from app.domain.services.trfs import (
    TestCreate as TrfTestCreate,
)
from app.domain.services.trfs import (
    TestService as TrfTestService,
)
from app.domain.services.trfs import TrfCreate, TrfService
from tests.tapdb_test_helpers import ensure_tapdb_org


def _assert_tapdb_euid_prefix(value: str, prefix: str) -> None:
    clean = str(value or "").strip()
    assert clean
    assert clean.split(":", 1)[-1].startswith(prefix)


@pytest.mark.db
def test_apply_status_event_returns_revision_euids_and_is_idempotent(db_session: Session):
    tenant_id = uuid.uuid4()
    ensure_tapdb_org(db_session, tenant_id, name="status-events", display_name="Status Events")

    trf_svc = TrfService(db_session, tenant_id)
    test_svc = TrfTestService(db_session, tenant_id)
    trf, _trf_revision = trf_svc.create(
        TrfCreate(order_type="CLINICAL"),
        tests=[
            TrfTestCreate(
                product_code="WGS-001",
                fulfillment_route_codes=["WGS"],
                specimen_type_required="blood-whole",
            )
        ],
        created_by=uuid.uuid4(),
    )
    test_rows = test_svc.list_for_trf(trf.euid)
    assert test_rows
    test, _test_revision, _assays = test_rows[0]

    svc = BloomStatusEventService(db_session, tenant_id)
    first = svc.apply_test_status_event(
        test_euid=test.euid,
        event_id="evt-status-001",
        idempotency_key="idem-status-001",
        status=OrderTestStatus.IN_PROGRESS.value,
        occurred_at=datetime.now(UTC),
        reason="integration test",
    )

    assert first.applied is True
    assert first.idempotent_replay is False
    assert first.status_event_id is not None
    _assert_tapdb_euid_prefix(first.status_event_id, "TSR-")
    assert first.trf_status_event_id is not None
    _assert_tapdb_euid_prefix(first.trf_status_event_id, "TRR-")
    assert first.test_status == OrderTestStatus.IN_PROGRESS.value

    second = svc.apply_test_status_event(
        test_euid=test.euid,
        event_id="evt-status-001",
        idempotency_key="idem-status-001-replay",
        status=OrderTestStatus.IN_PROGRESS.value,
        occurred_at=datetime.now(UTC),
        reason="integration test replay",
    )

    assert second.applied is False
    assert second.idempotent_replay is True
    assert second.status_event_id == first.status_event_id
