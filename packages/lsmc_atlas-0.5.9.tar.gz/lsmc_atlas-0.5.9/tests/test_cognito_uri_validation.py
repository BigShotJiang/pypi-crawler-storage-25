"""Tests for Cognito URI port validation helpers."""

from __future__ import annotations

from pathlib import Path

from app.auth import cognito_uri_validation as uri_validation


def _write_env(path: Path, values: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    body = "\n".join(f"{k}={v}" for k, v in values.items()) + "\n"
    path.write_text(body, encoding="utf-8")


def test_validate_cognito_uri_ports_passes_for_matching_local_ports(tmp_path: Path) -> None:
    daycog_dir = tmp_path / "daycog"
    _write_env(
        daycog_dir / "lsmc-atlas-gui-users.us-east-1.env",
        {
            "COGNITO_USER_POOL_ID": "us-east-1_pool123",
            "COGNITO_APP_CLIENT_ID": "client-123",
            "COGNITO_CALLBACK_URL": "https://localhost:8915/auth/callback",
            "COGNITO_LOGOUT_URL": "https://localhost:8915/",
        },
    )

    result = uri_validation.validate_cognito_uri_ports(
        expected_port=8915,
        pool_id="us-east-1_pool123",
        app_client_id="client-123",
        region="us-east-1",
        settings_redirect_uri="https://localhost:8915/auth/callback",
        settings_logout_uri="https://localhost:8915/",
        daycog_config_dir=daycog_dir,
        include_aws=False,
    )

    assert result.ok
    assert result.issues == []


def test_validate_cognito_uri_ports_flags_local_port_mismatches(tmp_path: Path) -> None:
    daycog_dir = tmp_path / "daycog"
    _write_env(
        daycog_dir / "lsmc-atlas-gui-users.us-east-1.env",
        {
            "COGNITO_USER_POOL_ID": "us-east-1_pool123",
            "COGNITO_APP_CLIENT_ID": "client-123",
            "COGNITO_CALLBACK_URL": "https://localhost:8912/auth/callback",
            "COGNITO_LOGOUT_URL": "https://localhost:8915/",
        },
    )

    result = uri_validation.validate_cognito_uri_ports(
        expected_port=8915,
        pool_id="us-east-1_pool123",
        app_client_id="client-123",
        region="us-east-1",
        settings_redirect_uri="https://localhost:8912/auth/callback",
        settings_logout_uri="https://localhost:8915/",
        daycog_config_dir=daycog_dir,
        include_aws=False,
    )

    assert not result.ok
    assert any("does not match Atlas port 8915" in issue.message for issue in result.issues)


def test_validate_cognito_uri_ports_includes_aws_uris(monkeypatch) -> None:
    def _fake_fetch(*, pool_id: str, app_client_id: str, region: str, profile: str | None):
        assert pool_id == "us-east-1_pool123"
        assert app_client_id == "client-123"
        assert region == "us-east-1"
        assert profile == "lsmc"
        return [
            uri_validation.CognitoURIRecord(
                source="AWS:CallbackURLs[0]",
                uri="https://localhost:8912/auth/callback",
            ),
            uri_validation.CognitoURIRecord(
                source="AWS:LogoutURLs[0]",
                uri="https://localhost:8915/",
            ),
            uri_validation.CognitoURIRecord(
                source="AWS:CallbackURLs[1]",
                uri="https://atlas.example.com/auth/callback",
            ),
        ]

    monkeypatch.setattr(uri_validation, "_fetch_aws_uri_records", _fake_fetch)

    result = uri_validation.validate_cognito_uri_ports(
        expected_port=8915,
        pool_id="us-east-1_pool123",
        app_client_id="client-123",
        region="us-east-1",
        profile="lsmc",
        settings_redirect_uri="https://localhost:8915/auth/callback",
        daycog_config_dir=Path("/path/that/does/not/exist"),
        include_aws=True,
    )

    assert not result.ok
    assert any(issue.source == "AWS:CallbackURLs[0]" for issue in result.issues)


def test_validate_cognito_app_client_name_passes_for_atlas(tmp_path: Path, monkeypatch) -> None:
    daycog_dir = tmp_path / "daycog"
    _write_env(
        daycog_dir / "lsmc-atlas-gui-users.us-east-1.env",
        {
            "COGNITO_USER_POOL_ID": "us-east-1_pool123",
            "COGNITO_APP_CLIENT_ID": "client-123",
            "COGNITO_CLIENT_NAME": "atlas",
        },
    )

    monkeypatch.setattr(uri_validation, "_fetch_aws_client_name", lambda **_kwargs: "atlas")

    result = uri_validation.validate_cognito_app_client_name(
        expected_client_name="atlas",
        pool_id="us-east-1_pool123",
        app_client_id="client-123",
        region="us-east-1",
        profile="lsmc",
        settings_client_name="atlas",
        daycog_config_dir=daycog_dir,
        include_aws=True,
    )

    assert result.ok
    assert result.issues == []


def test_validate_cognito_app_client_name_flags_mismatch(tmp_path: Path, monkeypatch) -> None:
    daycog_dir = tmp_path / "daycog"
    _write_env(
        daycog_dir / "lsmc-atlas-gui-users.us-east-1.env",
        {
            "COGNITO_USER_POOL_ID": "us-east-1_pool123",
            "COGNITO_APP_CLIENT_ID": "client-123",
            "COGNITO_CLIENT_NAME": "lsmc-atlas-gui-client",
        },
    )

    monkeypatch.setattr(
        uri_validation,
        "_fetch_aws_client_name",
        lambda **_kwargs: "lsmc-atlas-gui-client",
    )

    result = uri_validation.validate_cognito_app_client_name(
        expected_client_name="atlas",
        pool_id="us-east-1_pool123",
        app_client_id="client-123",
        region="us-east-1",
        profile="lsmc",
        settings_client_name="atlas",
        daycog_config_dir=daycog_dir,
        include_aws=True,
    )

    assert not result.ok
    assert any("expected 'atlas'" in issue.message for issue in result.issues)
