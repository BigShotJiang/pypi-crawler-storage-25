"""Tests for unified search v2 API endpoints."""

from __future__ import annotations

import uuid

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from app.search.contracts import SearchFacets, SearchQueryResponse, SearchResultItem


def _make_user(*roles: Role) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="search-test@lsmc.bio",
        name="Search Test",
        tenant_id=uuid.uuid4(),
        roles=[role.value for role in roles],
    )


class DummySearchService:
    """Deterministic fake for route contract tests."""

    init_calls: list[dict] = []

    def __init__(self, _db, tenant_id, *, cross_tenant):
        self.tenant_id = tenant_id
        self.cross_tenant = cross_tenant
        DummySearchService.init_calls.append(
            {"tenant_id": str(tenant_id), "cross_tenant": bool(cross_tenant)}
        )

    def query(self, request):
        item = SearchResultItem(
            record_type="instance",
            source_kind="tapdb.generic_instance",
            uid=123,
            euid="PAT-1",
            name="Jane Doe",
            created_at="2026-03-02T00:00:00+00:00",
            modified_at="2026-03-02T00:00:00+00:00",
            category="atlas",
            type="people",
            subtype="patient",
            version="1.0",
            is_deleted=False,
            metadata={"tenant_id": str(self.tenant_id)},
        )
        return SearchQueryResponse(
            items=[item],
            facets=SearchFacets(instance=1, template=0, lineage=0, audit=0),
            total=1,
            page=request.page,
            page_size=request.page_size,
            has_more=False,
            timing_ms=1,
        )

    def collect_export_rows(self, request):
        rows = [
            SearchResultItem(
                record_type="audit",
                source_kind="tapdb.audit_log",
                uid=456,
                euid="ADT-1",
                name="UPDATE:generic_instance",
                created_at="2026-03-02T00:00:00+00:00",
                modified_at="2026-03-02T00:00:00+00:00",
                category="atlas",
                type="generic_instance",
                subtype="name",
                version="",
                is_deleted=False,
                metadata={"operation_type": "UPDATE"},
            )
        ]
        return rows[: request.max_rows], 2, False


@pytest.fixture(autouse=True)
def _clear_overrides():
    DummySearchService.init_calls.clear()
    yield
    app.dependency_overrides.clear()


def _client_with_user(user: CurrentUser) -> TestClient:
    def override_db():
        yield object()

    def override_user():
        return user

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_current_user] = override_user
    return TestClient(app)


@pytest.mark.db
def test_search_v2_query_success(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post("/api/search/v2/query", json={"q": "jane"})
    assert response.status_code == 200
    body = response.json()
    assert body["total"] == 1
    assert body["items"][0]["record_type"] == "instance"
    assert body["items"][0]["euid"] == "PAT-1"


@pytest.mark.db
def test_search_v2_query_invalid_filter_path_422(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post(
        "/api/search/v2/query",
        json={
            "property_filters": [{"path": "properties..bad", "op": "eq", "value": "x"}],
        },
    )
    assert response.status_code == 422


@pytest.mark.db
def test_search_v2_query_invalid_filter_op_422(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post(
        "/api/search/v2/query",
        json={
            "property_filters": [{"path": "properties.status", "op": "regex", "value": "x"}],
        },
    )
    assert response.status_code == 422


@pytest.mark.db
def test_search_v2_alias_query_deprecation_headers(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post("/api/v1/search/v2/query", json={"q": "abc"})
    assert response.status_code == 200
    assert response.headers.get("Deprecation") == "true"
    assert response.headers.get("Sunset") == "Wed, 30 Sep 2026 00:00:00 GMT"
    assert "</api/search/v2/query>" in (response.headers.get("Link") or "")


@pytest.mark.db
def test_search_v2_export_json(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post("/api/search/v2/export", json={"format": "json"})
    assert response.status_code == 200
    body = response.json()
    assert body["row_count"] == 1
    assert body["items"][0]["record_type"] == "audit"


@pytest.mark.db
def test_search_v2_export_tsv(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post("/api/search/v2/export", json={"format": "tsv"})
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/tab-separated-values")
    assert response.headers.get("X-Row-Count") == "1"
    assert "record_type" in response.text


@pytest.mark.db
def test_search_v2_export_max_rows_validation(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post("/api/search/v2/export", json={"format": "json", "max_rows": 10001})
    assert response.status_code == 422


@pytest.mark.db
def test_search_v2_alias_export_deprecation_headers(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post("/api/v1/search/v2/export", json={"format": "json"})
    assert response.status_code == 200
    assert response.headers.get("Deprecation") == "true"
    assert "</api/search/v2/export>" in (response.headers.get("Link") or "")


@pytest.mark.db
def test_search_v2_cross_tenant_flag_external_false(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.post("/api/search/v2/query", json={})
    assert response.status_code == 200
    assert DummySearchService.init_calls[-1]["cross_tenant"] is False


@pytest.mark.db
def test_search_v2_cross_tenant_flag_internal_true(monkeypatch):
    monkeypatch.setattr("app.api.routes.search_v2.UnifiedSearchService", DummySearchService)
    client = _client_with_user(_make_user(Role.INTERNAL_USER))

    response = client.post("/api/search/v2/query", json={})
    assert response.status_code == 200
    assert DummySearchService.init_calls[-1]["cross_tenant"] is True


def test_search_v2_requires_auth():
    client = TestClient(app)
    response = client.post("/api/search/v2/query", json={})
    assert response.status_code == 401
