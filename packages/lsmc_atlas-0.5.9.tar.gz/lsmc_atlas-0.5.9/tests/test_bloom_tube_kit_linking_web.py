"""Web + service tests for Atlas Bloom tube and kit/TRF linking flows."""

from __future__ import annotations

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def web_user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="tubekit@test.org",
        name="Tube Kit Tester",
        tenant_id=tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def internal_web_user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="internal-tubekit@test.org",
        name="Internal Tube Kit Tester",
        tenant_id=tenant_id,
        roles=[Role.INTERNAL_USER.value],
    )


@pytest.fixture
def setup_tenant(db_session: Session, tenant_id: uuid.UUID):
    ensure_tapdb_org(db_session, tenant_id, name="tube-kit-org", display_name="Tube Kit Org")
    db_session.flush()


@pytest.fixture
def fake_bloom(monkeypatch):
    from app.domain.services import bloom_bridge
    from app.integrations.bloom_client import BloomOperationResult

    class FakeBloomClient:
        def __init__(self):
            self.created_containers = 0
            self.created_specimens = 0
            self.created_tube_payloads: list[dict[str, object]] = []
            self.register_material_payloads: list[dict[str, object]] = []
            self.updated_tubes: list[dict[str, object]] = []
            self.updated_specimens: list[dict[str, object]] = []

        def create_object(self, payload, *, idempotency_key=None):
            return self.create_empty_tube(payload, idempotency_key=idempotency_key)

        def create_empty_tube(self, payload, *, idempotency_key=None):
            self.created_containers += 1
            self.created_tube_payloads.append(
                {"payload": payload, "idempotency_key": idempotency_key}
            )
            container_euid = f"CNT-{1000 + self.created_containers}"
            return BloomOperationResult(
                external_euid=container_euid,
                status="active",
                raw={
                    "euid": container_euid,
                    "container_euid": container_euid,
                    "status": "active",
                    "created": True,
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

        def update_tube(self, container_euid, payload):
            self.updated_tubes.append({"container_euid": container_euid, "payload": payload})
            return BloomOperationResult(
                external_euid=container_euid,
                status=str(payload.get("status") or "active"),
                raw={
                    "container_euid": container_euid,
                    "status": str(payload.get("status") or "active"),
                    "created": False,
                    "payload": payload,
                },
            )

        def update_beta_specimen(self, specimen_euid, payload):
            self.updated_specimens.append({"specimen_euid": specimen_euid, "payload": payload})
            return BloomOperationResult(
                external_euid=specimen_euid,
                status=str(payload.get("status") or "active"),
                raw={
                    "specimen_euid": specimen_euid,
                    "status": str(payload.get("status") or "active"),
                    "created": False,
                    "payload": payload,
                },
            )

        def register_accepted_material(self, payload, *, idempotency_key=None):
            self.created_specimens += 1
            self.register_material_payloads.append(
                {"payload": payload, "idempotency_key": idempotency_key}
            )
            specimen_euid = f"SP-{2000 + self.created_specimens}"
            return BloomOperationResult(
                external_euid=specimen_euid,
                status="active",
                raw={
                    "specimen_euid": specimen_euid,
                    "container_euid": payload.get("container_euid"),
                    "status": "active",
                    "created": True,
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

    fake = FakeBloomClient()

    def _fake_get_client(self, site_id=None):  # noqa: ARG001
        return fake

    monkeypatch.setattr(
        bloom_bridge.ContainerSpecimenBridgeService, "_get_bloom_client", _fake_get_client
    )
    return fake


def _client(db_session: Session, user: CurrentUser) -> TestClient:
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        yield db_session

    def override_user():
        return user

    async def override_csrf():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    return TestClient(app)


def _create_patient(db: Session, tenant_id: uuid.UUID, actor: uuid.UUID):
    from datetime import date

    from app.domain.services.people import PatientCreate, PatientService

    return PatientService(db, tenant_id, actor).create(
        PatientCreate(first_name="Pat", last_name="Ient", date_of_birth=date(1990, 1, 1)),
        created_by=actor,
    )[0]


def _create_trf_and_test(
    db: Session, tenant_id: uuid.UUID, actor: uuid.UUID, patient_euid: str | None = None
):
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderPatientLink
    from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService

    links = []
    if patient_euid:
        links = [OrderPatientLink(patient_euid=patient_euid, role=OrderPatientRole.PROBAND)]

    trf, _trf_rev = TrfService(db, tenant_id).create(
        TrfCreate(order_type="CLINICAL"),
        tests=[
            TestCreate(
                product_code="WGS-001",
                fulfillment_route_codes=["WGS"],
                specimen_type_required="blood-whole",
            )
        ],
        patient_links=links,
        created_by=actor,
    )
    test = TestService(db, tenant_id).list_for_trf(trf.euid)[0][0]
    return trf, test


def _create_shipment(db: Session, tenant_id: uuid.UUID, actor: uuid.UUID):
    from app.domain.services.shipments import ShipmentCreate, ShipmentService

    return ShipmentService(db, tenant_id).create(
        ShipmentCreate(carrier="UPS", tracking_number=f"TRK-{uuid.uuid4().hex[:6]}"),
        created_by=actor,
    )[0]


def _create_testkit(db: Session, tenant_id: uuid.UUID, actor: uuid.UUID):
    from app.domain.services.shipments import TestKitCreate, TestKitService

    return TestKitService(db, tenant_id).create(
        TestKitCreate(kit_barcode=f"KIT-{uuid.uuid4().hex[:8]}", kit_type="COLLECTION"),
        created_by=actor,
    )


def _configure_org_bloom(db: Session, tenant_id: uuid.UUID, *, base_url: str = "https://bloom.local"):
    from app.domain.services.external_objects import OrgBloomConfigService, OrgBloomConfigUpsert

    OrgBloomConfigService(db).upsert(
        tenant_id,
        OrgBloomConfigUpsert(
            enabled=True,
            bloom_base_url=base_url,
            bloom_api_key_secret_ref="blm_" + "0" * 32,
            bloom_webhook_secret_ref="test-webhook-secret",
            bloom_service_user="atlas-test-user",
        ),
    )
    db.flush()


def _relation_types_for_external_object(
    db: Session, tenant_id: uuid.UUID, external_object_euid: str
) -> set[str]:
    repo = TapdbExternalObjectRepository(db)
    ext = repo.get_external_object_by_euid(
        tenant_id=tenant_id,
        provider="bloom",
        object_type="container",
        external_euid=external_object_euid,
    ) or repo.get_external_object_by_euid(
        tenant_id=tenant_id,
        provider="bloom",
        object_type="specimen",
        external_euid=external_object_euid,
    )
    assert ext is not None
    relations = repo.list_relations_for_external_object(ext.euid)
    return {rel.relation_type for rel in relations}


def test_bridge_tube_only_and_tube_plus_specimen(
    db_session: Session, web_user: CurrentUser, setup_tenant, fake_bloom
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest
    from app.domain.services.collection_events import CollectionEventService

    actor = web_user.sub_uuid
    patient = _create_patient(db_session, web_user.tenant_id, actor)
    trf, test = _create_trf_and_test(
        db_session,
        web_user.tenant_id,
        actor,
        patient_euid=patient.euid,
    )

    bridge = ContainerSpecimenBridgeService(db_session, web_user.tenant_id)
    shipment = _create_shipment(db_session, web_user.tenant_id, actor)
    testkit = _create_testkit(db_session, web_user.tenant_id, actor)

    tube_only = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(test_euid=test.euid, idempotency_key=f"test-{uuid.uuid4().hex}"),
        actor_id=actor,
    )
    assert tube_only.specimen_euid is None
    assert tube_only.trf_euid == trf.euid
    tube_only_ctx = fake_bloom.created_tube_payloads[-1]["payload"]["atlas_context"]
    assert "collection_event_snapshot" not in tube_only_ctx

    from_shipment = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            shipment_euid=shipment.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    from_testkit = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            testkit_euid=testkit.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    from_shipment_and_testkit = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            shipment_euid=shipment.euid,
            testkit_euid=testkit.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )

    with_specimen = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            patient_euid=patient.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    assert with_specimen.specimen_euid is not None
    assert with_specimen.collection_event_euid is not None
    specimen_ctx = fake_bloom.register_material_payloads[-1]["payload"]["atlas_context"]
    assert specimen_ctx["collection_event_snapshot"]["collection_event_euid"] == (
        with_specimen.collection_event_euid
    )

    db_session.commit()

    event = CollectionEventService(db_session, web_user.tenant_id).get(
        with_specimen.collection_event_euid
    )
    assert event is not None
    assert event[0].patient_id == patient.euid
    assert event[0].container_euid == with_specimen.container_euid
    assert event[0].specimen_euid == with_specimen.specimen_euid

    container_relations = _relation_types_for_external_object(
        db_session,
        web_user.tenant_id,
        with_specimen.container_euid,
    )
    assert {"belongs_to_test", "has_collection_event"}.issubset(container_relations)
    assert "belongs_to_shipment" in _relation_types_for_external_object(
        db_session, web_user.tenant_id, from_shipment.container_euid
    )
    assert "belongs_to_testkit" in _relation_types_for_external_object(
        db_session, web_user.tenant_id, from_testkit.container_euid
    )
    assert {
        "belongs_to_shipment",
        "belongs_to_testkit",
        "belongs_to_test",
    }.issubset(
        _relation_types_for_external_object(
            db_session,
            web_user.tenant_id,
            from_shipment_and_testkit.container_euid,
        )
    )

    specimen_relations = _relation_types_for_external_object(
        db_session,
        web_user.tenant_id,
        with_specimen.specimen_euid,
    )
    assert {"belongs_to_collection_event", "contained_in"}.issubset(specimen_relations)

    assert fake_bloom.created_containers >= 2
    assert fake_bloom.created_specimens >= 1


def test_bridge_allows_shipment_plus_testkit_anchor_combination(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest

    actor = web_user.sub_uuid
    _trf, test = _create_trf_and_test(db_session, web_user.tenant_id, actor)
    shipment = _create_shipment(db_session, web_user.tenant_id, actor)
    kit = _create_testkit(db_session, web_user.tenant_id, actor)

    bridge = ContainerSpecimenBridgeService(db_session, web_user.tenant_id)
    result = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            shipment_euid=shipment.euid,
            testkit_euid=kit.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    db_session.commit()
    relation_types = _relation_types_for_external_object(
        db_session,
        web_user.tenant_id,
        result.container_euid,
    )
    assert {"belongs_to_test", "belongs_to_shipment", "belongs_to_testkit"}.issubset(relation_types)


def test_shipment_add_specimen_route_and_detail_regression(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    actor = web_user.sub_uuid
    _trf, test = _create_trf_and_test(db_session, web_user.tenant_id, actor)
    shipment = _create_shipment(db_session, web_user.tenant_id, actor)

    client = _client(db_session, web_user)
    try:
        form_resp = client.get(f"/shipments/{shipment.shipment_number}/add-specimen")
        assert form_resp.status_code == status.HTTP_200_OK
        assert test.euid in form_resp.text
        assert 'name="collection_site_euid"' in form_resp.text

        submit_resp = client.post(
            f"/shipments/{shipment.shipment_number}/add-specimen",
            data={"test_euid": test.euid},
            follow_redirects=False,
        )
        assert submit_resp.status_code == status.HTTP_303_SEE_OTHER
        assert submit_resp.headers["location"].endswith(f"/shipments/{shipment.shipment_number}")

        repo = TapdbExternalObjectRepository(db_session)
        shipment_relations = repo.list_relations_for_local_entity(
            tenant_id=web_user.tenant_id,
            local_entity_type="Shipment",
            local_entity_id=shipment.euid,
        )
        assert any(rel.relation_type == "belongs_to_shipment" for rel in shipment_relations)
        test_relations = repo.list_relations_for_local_entity(
            tenant_id=web_user.tenant_id,
            local_entity_type="Test",
            local_entity_id=test.euid,
        )
        assert any(rel.relation_type == "belongs_to_test" for rel in test_relations)

        detail_resp = client.get(f"/shipments/{shipment.shipment_number}")
        assert detail_resp.status_code == status.HTTP_200_OK
        assert "/search/biospecimens" not in detail_resp.text
        assert "showAddSpecimenModal" not in detail_resp.text
    finally:
        app.dependency_overrides.clear()


def test_testkit_link_unlink_and_create_tube_routes(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    from app.domain.services.testkit_trf_links import TestKitTrfLinkService

    actor = web_user.sub_uuid
    trf1, test1 = _create_trf_and_test(db_session, web_user.tenant_id, actor)
    trf2, _test2 = _create_trf_and_test(db_session, web_user.tenant_id, actor)
    testkit = _create_testkit(db_session, web_user.tenant_id, actor)

    client = _client(db_session, web_user)
    try:
        detail = client.get(f"/testkits/{testkit.euid}")
        assert detail.status_code == status.HTTP_200_OK
        assert f"/testkits/{testkit.euid}/link-trf" in detail.text
        assert f"/testkits/{testkit.euid}/create-bloom-tube" in detail.text

        for trf_euid in (trf1.euid, trf2.euid, trf1.euid):
            resp = client.post(
                f"/testkits/{testkit.euid}/link-trf",
                data={"trf_euid": trf_euid},
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_303_SEE_OTHER

        link_svc = TestKitTrfLinkService(db_session, web_user.tenant_id)
        linked = link_svc.list_linked_trfs(testkit_euid=testkit.euid)
        assert {row.trf_euid for row in linked} == {trf1.euid, trf2.euid}

        unlink_resp = client.post(
            f"/testkits/{testkit.euid}/unlink-trf",
            data={"trf_euid": trf1.euid},
            follow_redirects=False,
        )
        assert unlink_resp.status_code == status.HTTP_303_SEE_OTHER
        linked_after_unlink = link_svc.list_linked_trfs(testkit_euid=testkit.euid)
        assert {row.trf_euid for row in linked_after_unlink} == {trf2.euid}

        tube_resp = client.post(
            f"/testkits/{testkit.euid}/create-bloom-tube",
            data={"test_euid": test1.euid},
            follow_redirects=False,
        )
        assert tube_resp.status_code == status.HTTP_303_SEE_OTHER

        linked_after_tube = link_svc.list_linked_trfs(testkit_euid=testkit.euid)
        assert {row.trf_euid for row in linked_after_tube} == {trf1.euid, trf2.euid}
    finally:
        app.dependency_overrides.clear()


def test_trf_request_material_route_supports_optional_patient(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    actor = web_user.sub_uuid
    patient = _create_patient(db_session, web_user.tenant_id, actor)
    _trf, test = _create_trf_and_test(
        db_session,
        web_user.tenant_id,
        actor,
        patient_euid=patient.euid,
    )

    client = _client(db_session, web_user)
    try:
        tube_only_resp = client.post(
            f"/trfs/tests/{test.euid}/request-material",
            data={},
            follow_redirects=False,
        )
        assert tube_only_resp.status_code == status.HTTP_303_SEE_OTHER

        with_patient_resp = client.post(
            f"/trfs/tests/{test.euid}/request-material",
            data={"patient_euid": patient.euid},
            follow_redirects=False,
        )
        assert with_patient_resp.status_code == status.HTTP_303_SEE_OTHER
    finally:
        app.dependency_overrides.clear()


def test_tube_detail_and_collection_event_edit_routes(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest

    actor = web_user.sub_uuid
    patient = _create_patient(db_session, web_user.tenant_id, actor)
    _trf, test = _create_trf_and_test(
        db_session,
        web_user.tenant_id,
        actor,
        patient_euid=patient.euid,
    )
    bridge = ContainerSpecimenBridgeService(db_session, web_user.tenant_id)
    result = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            patient_euid=patient.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    db_session.commit()

    client = _client(db_session, web_user)
    try:
        tube_resp = client.get(f"/tubes/{result.container_euid}")
        assert tube_resp.status_code == status.HTTP_200_OK
        assert result.collection_event_euid in tube_resp.text

        event_resp = client.get(f"/collection-events/{result.collection_event_euid}")
        assert event_resp.status_code == status.HTTP_200_OK
        assert result.specimen_euid in event_resp.text

        edit_resp = client.post(
            f"/collection-events/{result.collection_event_euid}/edit",
            data={
                "collection_type": "venipuncture",
                "collected_by": "Nurse Atlas",
                "expected_name": "Pat Ient",
            },
            follow_redirects=False,
        )
        assert edit_resp.status_code == status.HTTP_303_SEE_OTHER
        assert edit_resp.headers["location"].endswith(
            f"/collection-events/{result.collection_event_euid}"
        )
        assert fake_bloom.updated_specimens
        snapshot = fake_bloom.updated_specimens[-1]["payload"]["atlas_context"][
            "collection_event_snapshot"
        ]
        assert snapshot["collection_type"] == "venipuncture"
        assert snapshot["expected_name"] == "Pat Ient"
    finally:
        app.dependency_overrides.clear()


def test_tube_detail_shows_bloom_link_for_internal_users(
    db_session: Session,
    internal_web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
    monkeypatch,
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest

    actor = internal_web_user.sub_uuid
    patient = _create_patient(db_session, internal_web_user.tenant_id, actor)
    _trf, test = _create_trf_and_test(
        db_session,
        internal_web_user.tenant_id,
        actor,
        patient_euid=patient.euid,
    )
    _configure_org_bloom(db_session, internal_web_user.tenant_id)
    bridge = ContainerSpecimenBridgeService(db_session, internal_web_user.tenant_id)
    result = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            patient_euid=patient.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    db_session.commit()

    monkeypatch.setattr(
        "app.integrations.bloom_client.BloomClient.get_object_detail",
        lambda self, object_euid: {
            "euid": object_euid,
            "status": "queued",
            "created_at": "2026-03-29T12:34:56Z",
        },
    )

    client = _client(db_session, internal_web_user)
    try:
        tube_resp = client.get(f"/tubes/{result.container_euid}")
        assert tube_resp.status_code == status.HTTP_200_OK
        assert "Bloom Status" in tube_resp.text
        assert "queued" in tube_resp.text
        assert "2026-03-29T12:34:56Z" in tube_resp.text
        assert (
            f'href="https://bloom.local/euid_details?euid={result.container_euid}"'
            in tube_resp.text
        )
        assert "Open in Bloom" in tube_resp.text
    finally:
        app.dependency_overrides.clear()


def test_tube_detail_hides_bloom_link_for_external_users(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
    monkeypatch,
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest

    actor = web_user.sub_uuid
    patient = _create_patient(db_session, web_user.tenant_id, actor)
    _trf, test = _create_trf_and_test(
        db_session,
        web_user.tenant_id,
        actor,
        patient_euid=patient.euid,
    )
    _configure_org_bloom(db_session, web_user.tenant_id)
    bridge = ContainerSpecimenBridgeService(db_session, web_user.tenant_id)
    result = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            test_euid=test.euid,
            patient_euid=patient.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    db_session.commit()

    monkeypatch.setattr(
        "app.integrations.bloom_client.BloomClient.get_object_detail",
        lambda self, object_euid: {
            "euid": object_euid,
            "status": "received",
            "created_at": "2026-03-29T10:11:12Z",
        },
    )

    client = _client(db_session, web_user)
    try:
        tube_resp = client.get(f"/tubes/{result.container_euid}")
        assert tube_resp.status_code == status.HTTP_200_OK
        assert "Bloom Status" in tube_resp.text
        assert "received" in tube_resp.text
        assert "2026-03-29T10:11:12Z" in tube_resp.text
        assert "Open in Bloom" not in tube_resp.text
        assert "euid_details?euid=" not in tube_resp.text
    finally:
        app.dependency_overrides.clear()


def test_query_context_uses_collection_event_patient_for_site_only_tube(
    db_session: Session,
    web_user: CurrentUser,
    setup_tenant,
    fake_bloom,
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest
    from app.domain.services.bloom_query_context import BloomQueryContextService
    from app.domain.services.site_scope import list_tenant_site_options

    actor = web_user.sub_uuid
    patient = _create_patient(db_session, web_user.tenant_id, actor)
    site_options = list_tenant_site_options(db_session, web_user.tenant_id)
    assert len(site_options) == 1

    bridge = ContainerSpecimenBridgeService(db_session, web_user.tenant_id)
    result = bridge.create_tube_with_optional_specimen(
        TubeCreationRequest(
            site_euid=site_options[0].id,
            patient_euid=patient.euid,
            idempotency_key=f"test-{uuid.uuid4().hex}",
        ),
        actor_id=actor,
    )
    db_session.commit()

    context = BloomQueryContextService(
        db_session, web_user.tenant_id
    ).get_trf_context_for_container(result.container_euid)
    assert context["patient"]["patient_euid"] == patient.euid
    assert context["trf"] == {}
    assert context["tests"] == []
    assert context["links"]["site_euid"] == site_options[0].id
