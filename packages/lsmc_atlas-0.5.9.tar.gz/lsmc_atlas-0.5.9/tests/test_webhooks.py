"""Tests for webhook service."""

import asyncio
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.domain.services.webhooks import (
    WebhookEvent,
    WebhookService,
    deliver_webhook_async,
)


class TestWebhookEvent:
    """Tests for WebhookEvent dataclass."""

    def test_webhook_event_creation(self):
        """Test creating a webhook event."""
        event = WebhookEvent(
            event_type="order.created",
            event_id=uuid.uuid4(),
            payload={"order_id": "123", "status": "SUBMITTED"},
            timestamp=datetime.utcnow(),
        )
        assert event.event_type == "order.created"
        assert isinstance(event.event_id, uuid.UUID)
        assert event.payload["order_id"] == "123"


class TestWebhookServiceSignature:
    """Tests for webhook signature generation."""

    def test_generate_signature(self):
        """Test HMAC signature generation."""
        # Create a mock db session
        mock_db = MagicMock()
        tenant_id = uuid.uuid4()

        service = WebhookService(mock_db, tenant_id, "test-user")

        # Test signature generation
        payload = '{"event_type": "test", "data": {}}'
        secret = "test-secret-key"
        signature = service._generate_signature(payload, secret)

        # Signature should be a hex string
        assert isinstance(signature, str)
        assert len(signature) == 64  # SHA256 produces 64 hex chars

    def test_signature_consistency(self):
        """Test that same payload+secret always produces same signature."""
        mock_db = MagicMock()
        tenant_id = uuid.uuid4()
        service = WebhookService(mock_db, tenant_id)

        payload = '{"event_type": "test"}'
        secret = "my-secret"

        sig1 = service._generate_signature(payload, secret)
        sig2 = service._generate_signature(payload, secret)

        assert sig1 == sig2

    def test_different_secrets_different_signatures(self):
        """Test that different secrets produce different signatures."""
        mock_db = MagicMock()
        tenant_id = uuid.uuid4()
        service = WebhookService(mock_db, tenant_id)

        payload = '{"event_type": "test"}'

        sig1 = service._generate_signature(payload, "secret1")
        sig2 = service._generate_signature(payload, "secret2")

        assert sig1 != sig2


class TestDeliverWebhookAsync:
    """Tests for async webhook delivery."""

    @staticmethod
    def _run(coro):
        with ThreadPoolExecutor(max_workers=1) as executor:
            return executor.submit(asyncio.run, coro).result()

    def test_deliver_webhook_async_success(self):
        """Test successful async webhook delivery."""
        event = WebhookEvent(
            event_type="order.created",
            event_id=uuid.uuid4(),
            payload={"order_id": "test-123"},
            timestamp=datetime.utcnow(),
        )

        # Mock successful HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.is_success = True

        with patch("app.domain.services.webhooks.httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_class.return_value = mock_client

            result = self._run(
                deliver_webhook_async(
                    tenant_id=uuid.uuid4(),
                    subscription_id=uuid.uuid4(),
                    url="https://example.com/webhook",
                    secret="test-secret",
                    event=event,
                    timeout_seconds=30,
                    max_retries=3,
                )
            )

        assert result["success"] is True
        assert result["attempt"] == 1
        assert result["status_code"] == 200
        assert result["error"] is None

    def test_deliver_webhook_async_retry_on_failure(self):
        """Test async webhook delivery retries on failure."""
        event = WebhookEvent(
            event_type="order.created",
            event_id=uuid.uuid4(),
            payload={"order_id": "test-123"},
            timestamp=datetime.utcnow(),
        )

        # Mock failing HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.is_success = False

        with patch("app.domain.services.webhooks.httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_class.return_value = mock_client

            # Use short retry count for faster test
            with patch("app.domain.services.webhooks.asyncio.sleep", new_callable=AsyncMock):
                result = self._run(
                    deliver_webhook_async(
                        tenant_id=uuid.uuid4(),
                        subscription_id=uuid.uuid4(),
                        url="https://example.com/webhook",
                        secret="test-secret",
                        event=event,
                        timeout_seconds=5,
                        max_retries=2,
                    )
                )

        assert result["success"] is False
        assert result["attempt"] == 2  # Should have tried max_retries times
        assert result["status_code"] == 500
        assert result["error"] == "HTTP 500"

    def test_deliver_webhook_async_handles_exception(self):
        """Test async webhook delivery handles network exceptions."""
        event = WebhookEvent(
            event_type="order.created",
            event_id=uuid.uuid4(),
            payload={"order_id": "test-123"},
            timestamp=datetime.utcnow(),
        )

        with patch("app.domain.services.webhooks.httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(side_effect=Exception("Connection refused"))
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_class.return_value = mock_client

            with patch("app.domain.services.webhooks.asyncio.sleep", new_callable=AsyncMock):
                result = self._run(
                    deliver_webhook_async(
                        tenant_id=uuid.uuid4(),
                        subscription_id=uuid.uuid4(),
                        url="https://example.com/webhook",
                        secret="test-secret",
                        event=event,
                        timeout_seconds=5,
                        max_retries=2,
                    )
                )

        assert result["success"] is False
        assert result["attempt"] == 2
        assert result["status_code"] is None
        assert "Connection refused" in result["error"]

    def test_deliver_webhook_async_success_after_retry(self):
        """Test async webhook delivery succeeds after initial failure."""
        event = WebhookEvent(
            event_type="order.created",
            event_id=uuid.uuid4(),
            payload={"order_id": "test-123"},
            timestamp=datetime.utcnow(),
        )

        # First call fails, second succeeds
        fail_response = MagicMock()
        fail_response.status_code = 503
        fail_response.is_success = False

        success_response = MagicMock()
        success_response.status_code = 200
        success_response.is_success = True

        with patch("app.domain.services.webhooks.httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(side_effect=[fail_response, success_response])
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_class.return_value = mock_client

            with patch("app.domain.services.webhooks.asyncio.sleep", new_callable=AsyncMock):
                result = self._run(
                    deliver_webhook_async(
                        tenant_id=uuid.uuid4(),
                        subscription_id=uuid.uuid4(),
                        url="https://example.com/webhook",
                        secret="test-secret",
                        event=event,
                        timeout_seconds=5,
                        max_retries=3,
                    )
                )

        assert result["success"] is True
        assert result["attempt"] == 2  # Succeeded on second attempt
        assert result["status_code"] == 200

    def test_deliver_webhook_async_includes_headers(self):
        """Test async webhook delivery includes custom headers."""
        event = WebhookEvent(
            event_type="order.created",
            event_id=uuid.uuid4(),
            payload={"order_id": "test-123"},
            timestamp=datetime.utcnow(),
        )

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.is_success = True

        with patch("app.domain.services.webhooks.httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client_class.return_value = mock_client

            self._run(
                deliver_webhook_async(
                    tenant_id=uuid.uuid4(),
                    subscription_id=uuid.uuid4(),
                    url="https://example.com/webhook",
                    secret="test-secret",
                    event=event,
                    headers={"X-Custom-Header": "custom-value"},
                )
            )

            # Verify headers were passed
            call_kwargs = mock_client.post.call_args.kwargs
            assert "X-Custom-Header" in call_kwargs["headers"]
            assert call_kwargs["headers"]["X-Custom-Header"] == "custom-value"
            # Also verify standard webhook headers
            assert "X-Webhook-Signature" in call_kwargs["headers"]
            assert "X-Webhook-Event-Type" in call_kwargs["headers"]
            assert call_kwargs["headers"]["X-Webhook-Event-Type"] == "order.created"


class TestWebhookServiceNoBlocking:
    """Tests to verify no blocking operations in sync delivery."""

    def test_sync_delivery_does_not_block_on_retries(self):
        """Test that sync _deliver_to_subscription doesn't block with time.sleep."""
        import time

        class FakeRepo:
            def log_delivery(self, **kwargs):
                return kwargs

        mock_db = MagicMock()
        tenant_id = uuid.uuid4()
        service = WebhookService(mock_db, tenant_id)
        service._repo = lambda: FakeRepo()

        # Create mock subscription and revision
        subscription = MagicMock()
        subscription.euid = f"WHSUB-{uuid.uuid4().hex[:8]}"

        revision = MagicMock()
        revision.url = "https://example.com/webhook"
        revision.secret = "test-secret"
        revision.headers = None
        revision.timeout_seconds = 5
        revision.max_retries = 3

        event = WebhookEvent(
            event_type="order.created",
            event_id=uuid.uuid4(),
            payload={"test": "data"},
            timestamp=datetime.utcnow(),
        )

        # Mock httpx.post to fail
        with patch("app.domain.services.webhooks.httpx.post") as mock_post:
            mock_response = MagicMock()
            mock_response.status_code = 500
            mock_response.is_success = False
            mock_response.text = "Internal Server Error"
            mock_post.return_value = mock_response

            start_time = time.time()
            service._deliver_to_subscription(subscription, revision, event)
            elapsed = time.time() - start_time

        # Should complete quickly - no blocking sleep
        # With old code using time.sleep(2) + time.sleep(4), would take >6 seconds
        assert elapsed < 1.0, f"Sync delivery took {elapsed}s - should not block"
