"""Runtime behavior tests for Atlas server CLI."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from app.cli import server

runner = CliRunner()


def test_server_start_rejects_background_reload() -> None:
    result = runner.invoke(server.server_app, ["start", "--background", "--reload"])

    assert result.exit_code == 1
    assert "does not support auto-reload" in result.stdout


def test_server_status_reports_healthy(monkeypatch) -> None:
    monkeypatch.setattr(server, "_get_pid", lambda _path: 12345)
    monkeypatch.setattr(server, "_get_latest_log", lambda prefix="server": Path("/tmp/atlas.log"))
    monkeypatch.setattr(
        server,
        "_probe_server_health",
        lambda **_kwargs: (True, "https://localhost:8915/healthz"),
    )

    result = runner.invoke(server.server_app, ["status"])

    assert result.exit_code == 0
    assert "healthy" in result.stdout
    assert "https://localhost:8915/healthz" in result.stdout


def test_server_status_reports_unhealthy(monkeypatch) -> None:
    monkeypatch.setattr(server, "_get_pid", lambda _path: 12345)
    monkeypatch.setattr(server, "_get_latest_log", lambda prefix="server": None)
    monkeypatch.setattr(server, "_probe_server_health", lambda **_kwargs: (False, None))

    result = runner.invoke(server.server_app, ["status"])

    assert result.exit_code == 0
    assert "unhealthy" in result.stdout
    assert "https://localhost:8915" in result.stdout
    assert "Health probe" in result.stdout
