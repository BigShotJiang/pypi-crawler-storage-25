"""Tests for admin System Group management web UI.

Tests cover:
1. Group list page renders all system groups
2. Group detail page shows members
3. Add member by email (success + user-not-found)
4. Remove member (deactivate membership)
5. Authorization: non-admin users are rejected
6. Service methods: list_group_members, remove_user_from_group
"""

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import (
    CurrentUser,
    get_current_user,
    get_current_user_web,
)
from app.auth.middleware import csrf_protect
from app.auth.rbac import Role
from app.db.engine import get_db
from app.domain.enums import AccessScope, SystemGroup
from app.domain.services.groups import GroupCreate, UserGroupService
from app.domain.services.users import UserCreate, UserService
from app.main import app
from app.web.routes.pages import require_admin
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.fixture
def tenant_uuid() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def setup_org(db_session: Session, tenant_uuid: uuid.UUID) -> uuid.UUID:
    ensure_tapdb_org(db_session, tenant_uuid, name="test-org", display_name="Test Org")
    db_session.flush()
    return tenant_uuid


@pytest.fixture
def admin_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="admin@lsmc.bio",
        name="Admin User",
        tenant_id=tenant_uuid,
        roles=[Role.ADMIN.value],
    )


@pytest.fixture
def ext_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="external@clinic.com",
        name="External User",
        tenant_id=tenant_uuid,
        roles=[Role.EXTERNAL_USER.value],
    )


def _client(db_session: Session, user: CurrentUser) -> TestClient:
    """Build a TestClient with given user and overridden dependencies."""

    def override_db():
        try:
            yield db_session
        finally:
            pass

    def override_user():
        return user

    async def override_csrf():
        pass

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    app.dependency_overrides[require_admin] = override_user
    return TestClient(app)


@pytest.fixture(autouse=True)
def _clear_overrides():
    yield
    app.dependency_overrides.clear()


def _seed_group(db_session: Session, group_code: str, tenant_id: uuid.UUID | None):
    """Create a TapDB-backed group for testing."""
    svc = UserGroupService(db_session, tenant_id)
    existing = svc.get_group_by_code(group_code)
    if existing is not None:
        return existing
    group, _ = svc.create_group(
        GroupCreate(
            group_code=group_code,
            name=group_code.replace("_", " ").title(),
            description=f"{group_code} system group",
            access_scope=AccessScope.SYSTEM,
        ),
        created_by=None,
    )
    return group


def _seed_user_profile(db_session: Session, tenant_id: uuid.UUID, email: str):
    """Create a TapDB-backed user profile for testing."""
    svc = UserService(db_session)
    return svc.create(
        UserCreate(
            cognito_sub=str(uuid.uuid4()),
            tenant_id=tenant_id,
            email=email,
            name="Test User",
            roles=[Role.EXTERNAL_USER.value],
        )
    )


# ---------------------------------------------------------------------------
# GET /admin/groups — list page
# ---------------------------------------------------------------------------


@pytest.mark.db
def test_groups_list_page_renders(db_session, admin_user, setup_org):
    """GET /admin/groups returns 200 with group list."""
    _seed_group(db_session, SystemGroup.ADMIN.value, None)
    c = _client(db_session, admin_user)
    resp = c.get("/admin/groups")
    assert resp.status_code == status.HTTP_200_OK
    assert "System Groups" in resp.text
    assert "ADMIN" in resp.text


# ---------------------------------------------------------------------------
# GET /admin/groups/{code} — detail page
# ---------------------------------------------------------------------------


@pytest.mark.db
def test_group_detail_page_renders(db_session, admin_user, setup_org):
    """GET /admin/groups/ADMIN shows group detail with member table."""
    _seed_group(db_session, SystemGroup.ADMIN.value, admin_user.tenant_id)
    c = _client(db_session, admin_user)
    resp = c.get("/admin/groups/ADMIN")
    assert resp.status_code == status.HTTP_200_OK
    assert "Members" in resp.text
    assert "Add Member" in resp.text


@pytest.mark.db
def test_group_detail_404_for_unknown(db_session, admin_user, setup_org):
    """GET /admin/groups/NONEXISTENT returns 404."""
    c = _client(db_session, admin_user)
    resp = c.get("/admin/groups/NONEXISTENT")
    assert resp.status_code == status.HTTP_404_NOT_FOUND


# ---------------------------------------------------------------------------
# POST /admin/groups/{code}/add-member
# ---------------------------------------------------------------------------


@pytest.mark.db
def test_add_member_success(db_session, admin_user, setup_org, tenant_uuid):
    """Adding a valid user email creates a membership."""
    _seed_group(db_session, SystemGroup.CUSTOMER.value, admin_user.tenant_id)
    _seed_user_profile(db_session, tenant_uuid, "member@clinic.com")
    c = _client(db_session, admin_user)

    resp = c.post(
        "/admin/groups/CUSTOMER/add-member",
        data={"user_email": "member@clinic.com"},
        follow_redirects=True,
    )
    assert resp.status_code == status.HTTP_200_OK
    # The redirect should land on the group detail page showing the member
    assert "member@clinic.com" in resp.text


@pytest.mark.db
def test_add_member_unknown_email(db_session, admin_user, setup_org):
    """Adding a nonexistent email redirects with error flash."""
    _seed_group(db_session, SystemGroup.CUSTOMER.value, admin_user.tenant_id)
    c = _client(db_session, admin_user)

    resp = c.post(
        "/admin/groups/CUSTOMER/add-member",
        data={"user_email": "nobody@nowhere.com"},
        follow_redirects=False,
    )
    assert resp.status_code == status.HTTP_303_SEE_OTHER


# ---------------------------------------------------------------------------
# POST /admin/groups/{code}/remove-member
# ---------------------------------------------------------------------------


@pytest.mark.db
def test_remove_member_redirects(db_session, admin_user, setup_org, tenant_uuid):
    """POST remove-member returns 303 redirect."""
    _seed_group(db_session, SystemGroup.CUSTOMER.value, admin_user.tenant_id)
    c = _client(db_session, admin_user)
    resp = c.post(
        "/admin/groups/CUSTOMER/remove-member",
        data={"user_id": str(uuid.uuid4())},
        follow_redirects=False,
    )
    assert resp.status_code == status.HTTP_303_SEE_OTHER
    assert "/admin/groups/CUSTOMER" in resp.headers.get("location", "")


@pytest.mark.db
def test_service_remove_member_deactivates(db_session, admin_user, setup_org, tenant_uuid):
    """Service-level: remove_user_from_group deactivates membership (append-only)."""
    group = _seed_group(db_session, SystemGroup.CUSTOMER.value, admin_user.tenant_id)
    profile = _seed_user_profile(db_session, tenant_uuid, "removeme@clinic.com")

    svc = UserGroupService(db_session, tenant_uuid)
    svc.add_user_to_group(
        user_id=uuid.UUID(profile.cognito_sub),
        group_euid=group.euid,
        added_by=admin_user.sub_uuid,
    )

    result = svc.remove_user_from_group(
        user_id=uuid.UUID(profile.cognito_sub),
        group_euid=group.euid,
        removed_by=admin_user.sub_uuid,
    )
    assert result is not None
    assert result.is_active is False
    assert result.deactivated_by == admin_user.sub_uuid

    # Verify membership still exists (not deleted)
    members = svc.list_group_members(group.euid)
    matching = [m for m in members if m.user_id == uuid.UUID(profile.cognito_sub)]
    assert len(matching) == 1
    assert matching[0].is_active is False


# ---------------------------------------------------------------------------
# Service-level tests
# ---------------------------------------------------------------------------


@pytest.mark.db
def test_service_list_group_members(db_session, admin_user, setup_org, tenant_uuid):
    """UserGroupService.list_group_members returns memberships."""
    group = _seed_group(db_session, SystemGroup.ADMIN.value, admin_user.tenant_id)
    profile = _seed_user_profile(db_session, tenant_uuid, "svc@test.com")

    svc = UserGroupService(db_session, tenant_uuid)
    svc.add_user_to_group(
        user_id=uuid.UUID(profile.cognito_sub),
        group_euid=group.euid,
        added_by=admin_user.sub_uuid,
    )

    members = svc.list_group_members(group.euid)
    matching = [m for m in members if m.user_id == uuid.UUID(profile.cognito_sub)]
    assert len(matching) == 1
    assert matching[0].is_active is True


@pytest.mark.db
def test_service_remove_nonexistent_member(db_session, admin_user, setup_org, tenant_uuid):
    """Removing a non-member returns None."""
    group = _seed_group(db_session, SystemGroup.ADMIN.value, None)
    svc = UserGroupService(db_session, tenant_uuid)
    result = svc.remove_user_from_group(
        user_id=uuid.uuid4(), group_euid=group.euid, removed_by=admin_user.sub_uuid
    )
    assert result is None
