"""Unit tests for TapDB cutover behavior in APIClientService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from app.domain.services import api_clients as api_clients_service
from app.domain.services.api_clients import APIClientCreate, APIClientService, APIClientUpdate


@dataclass
class _MockDB:
    def add(self, _obj):
        return None

    def commit(self):
        return None

    def refresh(self, _obj):
        return None


class _FakeRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.tenant_id = tenant_id
        self.client = type(
            "ClientRecord",
            (),
            {
                "euid": f"ACLI-{uuid.uuid4().hex[:8]}",
                "tenant_id": tenant_id,
                "client_name": "Test Client",
                "created_at": None,
            },
        )()
        self.revision = type(
            "RevisionRecord",
            (),
            {
                "revision_no": 1,
                "is_active": True,
                "permissions": ["order:read"],
                "allowed_endpoints": None,
                "rate_limit_per_minute": None,
                "ip_allowed_list": None,
                "expires_at": None,
                "note": None,
                "api_key": "hashed-key",
                "client_id": self.client.euid,
            },
        )()

    def create(self, tenant_id, data, hashed_api_key, created_by):
        self.calls.append("create")
        self.client.client_name = data.client_name
        self.revision.api_key = hashed_api_key
        return self.client, self.revision

    def get(self, client_id, tenant_id):
        self.calls.append("get")
        if client_id != self.client.euid:
            return None
        return self.client, self.revision

    def list(self, tenant_id, skip=0, limit=100):
        self.calls.append("list")
        return [(self.client, self.revision)]

    def update(self, tenant_id, client_id, data, updated_by):
        self.calls.append("update")
        if data.permissions is not None:
            self.revision.permissions = data.permissions
        return self.client, self.revision

    def rotate_key(self, tenant_id, client_id, hashed_api_key, rotated_by):
        self.calls.append("rotate_key")
        self.revision.api_key = hashed_api_key
        return self.client, self.revision

    def validate_api_key(self, tenant_id, hashed_api_key):
        self.calls.append("validate_api_key")
        if hashed_api_key == self.revision.api_key:
            return self.client, self.revision
        return None

    def log_usage(
        self,
        tenant_id,
        client_id,
        endpoint,
        method,
        status_code,
        ip_address=None,
        request_size_bytes=None,
        response_size_bytes=None,
        duration_ms=None,
    ):
        self.calls.append("log_usage")

    def get_usage_logs(self, tenant_id, client_id=None, limit=100):
        self.calls.append("get_usage_logs")
        return [{"id": "log"}]


def test_api_client_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = APIClientService(_MockDB(), tenant_id)
    repo = _FakeRepo(tenant_id)

    monkeypatch.setattr(api_clients_service, "generate_api_key", lambda: "plain-key")
    monkeypatch.setattr(
        "app.domain.services.site_scope.resolve_tenant_site_euid",
        lambda _db, _tenant_id, site_euid, **_kwargs: site_euid or "STX-TEST",
    )
    monkeypatch.setattr(svc, "_repo", lambda: repo)

    created = svc.create(
        APIClientCreate(client_name="TapDB Client", permissions=["order:read"]),
        created_by=uuid.uuid4(),
    )
    assert created[0].client_name == "TapDB Client"
    assert created[2] == "plain-key"

    got = svc.get(repo.client.euid)
    assert got is not None

    listed = svc.list()
    assert len(listed) == 1

    updated = svc.update(
        repo.client.euid,
        APIClientUpdate(permissions=["order:write"]),
        updated_by=uuid.uuid4(),
    )
    assert updated is not None
    assert updated[1].permissions == ["order:write"]

    rotated = svc.rotate_key(repo.client.euid, rotated_by=uuid.uuid4())
    assert rotated is not None
    assert rotated[2] == "plain-key"

    validated = svc.validate_api_key("plain-key")
    assert validated is not None

    svc.log_usage(repo.client.euid, "/api/patients", "GET", 200)
    logs = svc.get_usage_logs(client_id=repo.client.euid)
    assert logs == [{"id": "log"}]

    assert repo.calls == [
        "create",
        "get",
        "list",
        "update",
        "rotate_key",
        "validate_api_key",
        "log_usage",
        "get_usage_logs",
    ]
