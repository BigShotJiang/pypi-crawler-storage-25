"""Comprehensive integration tests for LSMC Atlas web UI CRUD flows.

Tests cover:
1. Entity creation flows (Patient, Order, Shipment, Clinician, etc.)
2. Display/read flows (list pages, detail pages, dashboard)
3. Edit/update flows (patient updates, order modifications)
4. Deletion/removal flows (append-only model, reversal events)
5. Authentication and authorization (tenant isolation, roles)
6. Error handling and validation
"""

import re
import uuid
from types import SimpleNamespace

import pytest
from daylily_tapdb.models.instance import generic_instance
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from app.persistence.tapdb.orm_models.events import AuditAction, AuditEvent, LinkAction
from app.persistence.tapdb.orm_models.people import (
    Clinician,
    Patient,
)
from tests.tapdb_test_helpers import ensure_tapdb_org

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def test_tenant_id() -> uuid.UUID:
    """Generate a consistent tenant ID for tests."""
    return uuid.uuid4()


@pytest.fixture
def other_tenant_id() -> uuid.UUID:
    """Generate a second tenant ID for isolation tests."""
    return uuid.uuid4()


@pytest.fixture
def external_user(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create an external (customer) test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="customer@acme-genetics.com",
        name="Test Customer",
        tenant_id=test_tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def internal_user(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create an internal (LSMC staff) test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="staff@lsmc.bio",
        name="LSMC Staff",
        tenant_id=test_tenant_id,
        roles=[Role.INTERNAL_USER.value],
    )


@pytest.fixture
def admin_user(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create an admin test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="admin@lsmc.bio",
        name="Admin User",
        tenant_id=test_tenant_id,
        roles=[Role.ADMIN.value],
    )


@pytest.fixture
def external_user_admin(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create an external user admin (org admin) test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="orgadmin@acme-genetics.com",
        name="Org Admin",
        tenant_id=test_tenant_id,
        roles=[Role.EXTERNAL_USER_ADMIN.value],
    )


@pytest.fixture
def read_only_user(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create a read-only test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="readonly@acme-genetics.com",
        name="Read Only User",
        tenant_id=test_tenant_id,
        roles=[Role.READ_ONLY.value],
    )


@pytest.fixture
def other_tenant_user(other_tenant_id: uuid.UUID) -> CurrentUser:
    """Create a user in a different tenant for isolation tests."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="other@other-org.com",
        name="Other Tenant User",
        tenant_id=other_tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


def create_test_client(db_session: Session, user: CurrentUser) -> TestClient:
    """Create a test client with given user and DB session."""
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_current_user():
        return user

    async def override_csrf_protect():
        """Skip CSRF protection in tests."""
        pass

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user
    app.dependency_overrides[get_current_user_web] = override_get_current_user
    app.dependency_overrides[csrf_protect] = override_csrf_protect

    return TestClient(app)


@pytest.fixture
def setup_tenant(db_session: Session, test_tenant_id: uuid.UUID) -> SimpleNamespace:
    """Create organization/tenant in DB for FK constraints."""
    org = ensure_tapdb_org(
        db_session, test_tenant_id, name="test-tenant", display_name="Test Tenant"
    )
    db_session.flush()
    return SimpleNamespace(id=test_tenant_id, euid=org.euid)


@pytest.fixture
def setup_other_tenant(db_session: Session, other_tenant_id: uuid.UUID) -> SimpleNamespace:
    """Create second organization/tenant for isolation tests."""
    org = ensure_tapdb_org(
        db_session, other_tenant_id, name="other-tenant", display_name="Other Tenant"
    )
    db_session.flush()
    return SimpleNamespace(id=other_tenant_id, euid=org.euid)


# =============================================================================
# 1. ENTITY CREATION FLOWS
# =============================================================================


class TestPatientCreation:
    """Tests for patient creation via POST /patients/new."""

    @pytest.mark.db
    def test_patient_create_success(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test successful patient creation with valid data."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/patients/new",
            data={
                "first_name": "John",
                "last_name": "Doe",
                "date_of_birth": "1985-06-15",
                "sex": "M",
                "email": "john.doe@example.com",
                "phone": "555-123-4567",
                "address_line1": "123 Main St",
                "city": "Boston",
                "state": "MA",
                "postal_code": "02101",
                "country": "US",
            },
            follow_redirects=False,
        )

        # Should redirect on success
        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == "/patients"

        # Verify patient was created in TapDB-backed service
        from app.domain.services.people import PatientService

        patient_svc = PatientService(db_session, external_user.tenant_id, external_user.sub_uuid)
        patients = patient_svc.list_patients(limit=20)
        assert len(patients) == 1
        patient, revision = patients[0]
        assert revision.first_name == "John"
        assert revision.last_name == "Doe"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_create_missing_required_fields(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test patient creation fails with missing required fields."""
        client = create_test_client(db_session, external_user)

        # Missing first_name and last_name
        response = client.post(
            "/patients/new",
            data={
                "date_of_birth": "1985-06-15",
            },
            follow_redirects=False,
        )

        # FastAPI returns 422 for validation errors
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_create_form_loads_date_picker_helper(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Patient create page includes global date picker helper script."""
        client = create_test_client(db_session, external_user)
        response = client.get("/patients/new")

        assert response.status_code == status.HTTP_200_OK
        assert 'id="atlas-date-picker-helper"' in response.text
        assert 'data-date-picker-helper="enabled"' in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_create_invalid_date_format(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test patient creation with invalid date format."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/patients/new",
            data={
                "first_name": "John",
                "last_name": "Doe",
                "date_of_birth": "not-a-date",
            },
            follow_redirects=False,
        )

        # Should redirect back to form with error
        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/patients/new" in response.headers.get("location", "")

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_create_with_custom_redirect(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test patient creation redirects to specified URL."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/patients/new",
            data={
                "first_name": "Jane",
                "last_name": "Smith",
                "date_of_birth": "1990-01-15",
                "redirect_url": "/shipments/new",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/shipments/new" in response.headers.get("location", "")

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_create_from_trf_redirects_back_to_trf(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Patient creation started from TRF flow returns to TRF form."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/patients/new",
            data={
                "first_name": "Flow",
                "last_name": "Patient",
                "date_of_birth": "1994-02-03",
                "redirect_url": "/trfs/new",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == "/trfs/new"

        app.dependency_overrides.clear()


class TestPatientManagement:
    """Tests for patient management (list, detail, edit, search)."""

    @pytest.fixture
    def sample_patient(
        self, db_session: Session, setup_tenant, external_user: CurrentUser
    ) -> Patient:
        """Create a sample patient for tests."""
        patient = _create_test_patient(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Test",
            last_name="Patient",
            mrn="MRN12345",
        )
        return patient

    @pytest.mark.db
    def test_patient_list_with_search(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Test patient search filters results."""
        client = create_test_client(db_session, external_user)

        # Search should find the patient
        response = client.get("/patients?search=Test")

        assert response.status_code == status.HTTP_200_OK
        assert "Test" in response.text
        assert "Patient" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_list_search_no_results(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Test patient search with no matching results."""
        client = create_test_client(db_session, external_user)

        # Search for non-existent patient
        response = client.get("/patients?search=NonExistent12345")

        assert response.status_code == status.HTTP_200_OK
        assert "No patients found" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_edit_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Test patient edit form loads with existing data."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/patients/{sample_patient.euid}/edit")

        assert response.status_code == status.HTTP_200_OK
        assert "Test" in response.text
        assert "Patient" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_edit_submit_creates_revision(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Test patient edit creates new revision (append-only)."""
        client = create_test_client(db_session, external_user)

        from app.domain.services.people import PatientService

        patient_svc = PatientService(db_session, external_user.tenant_id, external_user.sub_uuid)
        result = patient_svc.get_by_id(sample_patient.euid)
        assert result is not None
        _patient, initial_revision = result
        assert initial_revision.revision_no == 1

        response = client.post(
            f"/patients/{sample_patient.euid}/edit",
            data={
                "first_name": "Updated",
                "last_name": "Name",
                "date_of_birth": "1990-01-01",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        result = patient_svc.get_by_id(sample_patient.euid)
        assert result is not None
        _patient, updated_revision = result
        assert updated_revision.revision_no == 2
        assert updated_revision.first_name == "Updated"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_detail_shows_linked_orders(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Test patient detail page shows linked orders."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        # Create an order for this patient
        order_svc = TrfService(db_session, external_user.tenant_id)
        order, _ = order_svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=sample_patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.get(f"/patients/{sample_patient.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert order.order_number in response.text

        app.dependency_overrides.clear()


class TestOrderCreation:
    """Tests for order creation via POST /trfs/new."""

    @pytest.fixture
    def sample_patient(
        self, db_session: Session, setup_tenant, external_user: CurrentUser
    ) -> Patient:
        """Create a sample patient for order tests."""
        return _create_test_patient(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Test",
            last_name="Patient",
        )

    @pytest.mark.db
    def test_order_create_success(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Test successful order creation."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/trfs/new",
            data={
                "patient_id": str(sample_patient.euid),
                "order_type": "CLINICAL",
                "clinical_notes": "Test order notes",
                "test_orders[0][fulfillment_route_code]": "WGS",
                "test_orders[0][specimen_type]": "blood-whole",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        location = response.headers.get("location", "")
        assert "/trfs/" in location
        assert location != "/trfs/new"

        from app.domain.services.trfs import TrfService

        order_svc = TrfService(db_session, external_user.tenant_id)
        orders = order_svc.list_trfs(limit=20)
        assert len(orders) == 1

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_create_backfills_legacy_clinician_from_tapdb(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Order create succeeds when clinician exists in TapDB but not legacy table."""
        clinician = _create_test_clinician(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Taylor",
            last_name="Doctor",
            email="taylor.doctor@example.com",
        )
        client = create_test_client(db_session, external_user)
        response = client.post(
            "/trfs/new",
            data={
                "patient_id": str(sample_patient.euid),
                "clinician_id": str(clinician.euid),
                "order_type": "CLINICAL",
                "test_orders[0][fulfillment_route_code]": "WGS",
                "test_orders[0][specimen_type]": "blood-whole",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        location = response.headers.get("location", "")
        assert "/trfs/" in location
        assert location != "/trfs/new"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_create_missing_patient(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test order creation fails without patient_id."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/trfs/new",
            data={
                "order_type": "CLINICAL",
            },
            follow_redirects=False,
        )

        # Should redirect back to form with error (web form pattern)
        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/trfs/new" in response.headers.get("location", "")

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_create_invalid_patient_id(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test order creation with non-existent patient ID."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/trfs/new",
            data={
                "patient_id": str(uuid.uuid4()),  # Non-existent
                "order_type": "CLINICAL",
            },
            follow_redirects=False,
        )

        # Should redirect back with error (FK violation or validation)
        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/trfs/new" in response.headers.get("location", "")

        app.dependency_overrides.clear()


class TestShipmentCreation:
    """Tests for shipment creation via POST /shipments/new."""

    @pytest.mark.db
    def test_shipment_create_success(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test successful shipment creation."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/shipments/new",
            data={
                "carrier": "FedEx",
                "tracking_number": "123456789",
                "special_instructions": "Keep refrigerated",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        location = response.headers.get("location", "")
        assert "/shipments/" in location

        # Verify shipment was created
        from app.domain.services.shipments import ShipmentService

        shipments = ShipmentService(db_session, external_user.tenant_id).list_shipments()
        assert len(shipments) == 1

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_shipment_create_minimal_data(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test shipment creation with minimal data."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/shipments/new",
            data={},
            follow_redirects=False,
        )

        # Should succeed with no required fields
        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/shipments/" in response.headers.get("location", "")

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_shipment_create_accepts_origin_site_euid(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Origin site selection accepts canonical site EUID."""
        from app.domain.services.orgs import SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Origin Site",
                site_code="ORIG-01",
                address={"city": "Seattle", "state": "WA"},
            ),
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)
        response = client.post(
            "/shipments/new",
            data={
                "carrier": "FEDEX",
                "tracking_number": "395579987149",
                "origin_site_id": site.euid,
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/shipments/" in response.headers.get("location", "")

        app.dependency_overrides.clear()


class TestShipmentAddKit:
    """Tests for shipment add-kit behavior."""

    @pytest.mark.db
    def test_add_kit_existing_barcode_is_get_or_create(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """If a kit barcode already exists, add-kit should not try to create a duplicate."""
        from app.domain.services.shipments import (
            ShipmentCreate,
            ShipmentService,
            TestKitCreate,
            TestKitService,
        )

        client = create_test_client(db_session, external_user)

        # Arrange: create shipment + existing kit
        shipment_svc = ShipmentService(db_session, external_user.tenant_id)
        shipment, _rev = shipment_svc.create(ShipmentCreate(), created_by=external_user.sub_uuid)

        kit_svc = TestKitService(db_session, external_user.tenant_id)
        kit = kit_svc.create(
            TestKitCreate(kit_barcode="K-1", kit_type=None),
            created_by=external_user.sub_uuid,
        )

        # Act
        resp = client.post(
            f"/shipments/{shipment.shipment_number}/add-kit",
            data={"kit_barcode": "K-1", "kit_type": ""},
            follow_redirects=False,
        )

        # Assert: success redirect and no duplicate kit created
        assert resp.status_code == status.HTTP_303_SEE_OTHER
        kits = kit_svc.list_kits(limit=50, cross_tenant=False)
        assert sum(1 for row in kits if getattr(row, "kit_barcode", None) == "K-1") == 1
        assert any(
            item.get("type") == "TestKit" and item.get("id") == str(kit.euid)
            for item in shipment_svc.get_contents(shipment.euid)
        )

        app.dependency_overrides.clear()


class TestClinicianCreation:
    """Tests for clinician creation via POST /clinicians/new."""

    @pytest.mark.db
    def test_clinician_create_success(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test successful clinician creation."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/clinicians/new",
            data={
                "first_name": "Jane",
                "last_name": "Smith",
                "credentials": "MD, PhD",
                "specialty": "Oncology",
                "npi": "1234567890",
                "email": "jane.smith@hospital.org",
                "phone": "555-987-6543",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        location = response.headers.get("location", "")
        assert "/trfs/new" in location  # Default redirect

        # Verify clinician was created in TapDB-backed service
        from app.domain.services.people import ClinicianService

        clinician_svc = ClinicianService(
            db_session, external_user.tenant_id, external_user.sub_uuid
        )
        clinicians = clinician_svc.list_clinicians(limit=20, active_only=False)
        assert len(clinicians) == 1
        _clinician, revision = clinicians[0]
        assert revision.first_name == "Jane"
        assert revision.credentials == "MD, PhD"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_clinician_create_missing_name(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test clinician creation fails without name."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/clinicians/new",
            data={
                "credentials": "MD",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

        app.dependency_overrides.clear()


class TestClinicianUserManagement:
    """Tests for clinician user management functionality (Part 1 of the clinician management feature)."""

    @pytest.mark.db
    def test_clinician_detail_shows_users(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test clinician detail page shows organization users."""
        from app.domain.services.users import UserCreate, UserService

        # Create a clinician
        clinician = _create_test_clinician(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Jane",
            last_name="Doe",
        )

        # Create a user in the same organization
        UserService(db_session).create(
            UserCreate(
                cognito_sub=str(uuid.uuid4()),
                tenant_id=external_user.tenant_id,
                email="staff@acme.com",
                name="Staff Member",
                roles=["EXTERNAL_USER"],
            )
        )
        db_session.commit()

        client = create_test_client(db_session, external_user)
        response = client.get(f"/clinicians/{clinician.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "staff@acme.com" in response.text
        assert "Organization Users" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_clinician_user_create_form_loads(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant
    ):
        """Test that the user creation form loads for org admin users."""
        # Create a clinician
        clinician = _create_test_clinician(
            db_session,
            external_user_admin.tenant_id,
            external_user_admin.sub_uuid,
            first_name="Jane",
            last_name="Doe",
        )
        db_session.commit()

        client = create_test_client(db_session, external_user_admin)
        response = client.get(f"/clinicians/{clinician.euid}/users/new")

        assert response.status_code == status.HTTP_200_OK
        assert "Invite User" in response.text
        assert "email" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_clinician_user_create_submit(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant
    ):
        """Test creating a user for a clinician's organization (requires org admin)."""
        from app.domain.services.users import UserService

        # Create a clinician
        clinician = _create_test_clinician(
            db_session,
            external_user_admin.tenant_id,
            external_user_admin.sub_uuid,
            first_name="Jane",
            last_name="Doe",
        )
        db_session.commit()

        client = create_test_client(db_session, external_user_admin)
        response = client.post(
            f"/clinicians/{clinician.euid}/users/new",
            data={
                "email": "newuser@acme.com",
                "name": "New User",
                "roles": ["EXTERNAL_USER"],
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert f"/clinicians/{clinician.euid}" in response.headers.get("location", "")

        # Verify user was created
        user = UserService(db_session).get_by_email("newuser@acme.com")
        assert user is not None
        assert user.cognito_sub is not None  # Set by mock Cognito
        assert user.tenant_id == external_user_admin.tenant_id

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_external_user_cannot_assign_admin_role(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test that regular external users are blocked from user creation (org admin required)."""
        # Create a clinician
        clinician = _create_test_clinician(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Jane",
            last_name="Doe",
        )
        db_session.commit()

        client = create_test_client(db_session, external_user)
        response = client.post(
            f"/clinicians/{clinician.euid}/users/new",
            data={
                "email": "admin@acme.com",
                "roles": ["ADMIN"],
            },
            follow_redirects=False,
        )

        # Regular external users are blocked by org admin route guard
        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_user_can_assign_admin_role(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test that admin users (org admins) can assign ADMIN role."""
        from app.domain.services.users import UserService

        # Create a clinician
        clinician = _create_test_clinician(
            db_session,
            admin_user.tenant_id,
            admin_user.sub_uuid,
            first_name="Jane",
            last_name="Doe",
        )
        db_session.commit()

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/clinicians/{clinician.euid}/users/new",
            data={
                "email": "admin@acme.com",
                "name": "Admin User",
                "roles": ["ADMIN"],
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert f"/clinicians/{clinician.euid}" in response.headers.get("location", "")

        # Verify user was created with ADMIN role
        user = UserService(db_session).get_by_email("admin@acme.com")
        assert user is not None
        assert "ADMIN" in user.roles

        app.dependency_overrides.clear()


class TestClinicianUserAPI:
    """Tests for clinician user API endpoint (POST /api/clinicians/{clinician_id}/users)."""

    @pytest.mark.db
    def test_api_create_clinician_user_success(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test creating a user via API endpoint."""
        from app.domain.services.users import UserService

        # Create a clinician
        clinician = _create_test_clinician(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Jane",
            last_name="Doe",
        )
        db_session.commit()

        client = create_test_client(db_session, external_user)
        response = client.post(
            f"/api/clinicians/{clinician.euid}/users",
            json={
                "email": "apiuser@acme.com",
                "name": "API User",
                "roles": ["EXTERNAL_USER"],
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["email"] == "apiuser@acme.com"
        assert str(external_user.tenant_id) == data["tenant_id"]

        # Verify user was created
        user = UserService(db_session).get_by_email("apiuser@acme.com")
        assert user is not None

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_api_create_user_clinician_not_found(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test API returns 404 for non-existent clinician."""
        client = create_test_client(db_session, external_user)
        fake_id = uuid.uuid4()
        response = client.post(
            f"/api/clinicians/{fake_id}/users",
            json={
                "email": "user@acme.com",
                "roles": ["EXTERNAL_USER"],
            },
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_api_external_user_cannot_assign_internal_role(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test API blocks external users from assigning INTERNAL_USER role."""
        # Create a clinician
        clinician = _create_test_clinician(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Jane",
            last_name="Doe",
        )
        db_session.commit()

        client = create_test_client(db_session, external_user)
        response = client.post(
            f"/api/clinicians/{clinician.euid}/users",
            json={
                "email": "internal@acme.com",
                "roles": ["INTERNAL_USER"],
            },
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()


class TestOrganizationManagement:
    """Tests for organization management features (Part 2)."""

    @pytest.mark.db
    def test_admin_organization_detail_page_loads(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin can view organization detail page."""
        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "Acme" in response.text or "organization" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_org_bloom_detail_shows_validate_and_required_fields(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin org Bloom card renders validate action and required field descriptions."""
        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "Validate Credentials" in response.text
        assert "bloom_base_url" in response.text
        assert "bloom_api_key_secret_ref" in response.text
        assert "bloom_webhook_secret_ref" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_org_page_checks_bloom_connection_status_on_load(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant, monkeypatch
    ):
        """Admin org page performs Bloom credential check on load and renders healthy status."""
        from app.domain.services.external_objects import (
            OrgBloomConfigService,
            OrgBloomConfigUpsert,
        )
        from app.web.routes import pages as pages_routes

        OrgBloomConfigService(db_session).upsert(
            setup_tenant.id,
            OrgBloomConfigUpsert(
                enabled=True,
                bloom_base_url="https://healthcheck-admin-bloom.local",
                bloom_api_key_secret_ref="env:HEALTHCHECK_ADMIN_BLOOM_API_KEY",
            ),
            actor_id=admin_user.sub_uuid,
        )

        captured: dict[str, str] = {}

        def _fake_validate(*, bloom_base_url: str, bloom_api_key_secret_ref: str) -> None:
            captured["bloom_base_url"] = bloom_base_url
            captured["bloom_api_key_secret_ref"] = bloom_api_key_secret_ref

        monkeypatch.setattr(pages_routes, "_check_bloom_connection_health", _fake_validate)

        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert captured == {
            "bloom_base_url": "https://healthcheck-admin-bloom.local",
            "bloom_api_key_secret_ref": "env:HEALTHCHECK_ADMIN_BLOOM_API_KEY",
        }
        assert 'id="bloom-connection-status"' in response.text
        assert 'data-bloom-connection-status="healthy"' in response.text
        assert "Connection OK" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_org_bloom_validate_action_does_not_persist(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant, monkeypatch
    ):
        """Validate action checks submitted credentials without overwriting saved config."""
        from app.domain.services.external_objects import (
            OrgBloomConfigService,
            OrgBloomConfigUpsert,
        )
        from app.web.routes import pages as pages_routes

        org_cfg_svc = OrgBloomConfigService(db_session)
        org_cfg_svc.upsert(
            setup_tenant.id,
            OrgBloomConfigUpsert(
                enabled=True,
                bloom_base_url="https://saved-bloom.local",
                bloom_api_key_secret_ref="env:SAVED_BLOOM_API_KEY",
                bloom_webhook_secret_ref="env:SAVED_BLOOM_WEBHOOK",
            ),
            actor_id=admin_user.sub_uuid,
        )

        captured: dict[str, str] = {}

        def _fake_validate(*, bloom_base_url: str, bloom_api_key_secret_ref: str) -> None:
            captured["bloom_base_url"] = bloom_base_url
            captured["bloom_api_key_secret_ref"] = bloom_api_key_secret_ref

        monkeypatch.setattr(pages_routes, "_validate_bloom_credentials", _fake_validate)

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/integrations/bloom",
            data={
                "action": "validate",
                "enabled": "true",
                "bloom_base_url": "https://validate-bloom.local",
                "bloom_api_key_secret_ref": "env:VALIDATE_BLOOM_API_KEY",
                "bloom_webhook_secret_ref": "env:VALIDATE_BLOOM_WEBHOOK",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == f"/admin/organizations/{setup_tenant.euid}"
        assert captured == {
            "bloom_base_url": "https://validate-bloom.local",
            "bloom_api_key_secret_ref": "env:VALIDATE_BLOOM_API_KEY",
        }

        saved_cfg = org_cfg_svc.get(setup_tenant.id)
        assert saved_cfg is not None
        assert saved_cfg.bloom_base_url == "https://saved-bloom.local"
        assert saved_cfg.bloom_api_key_secret_ref == "env:SAVED_BLOOM_API_KEY"
        assert saved_cfg.bloom_webhook_secret_ref == "env:SAVED_BLOOM_WEBHOOK"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_detail_not_found(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin gets 404 for non-existent organization."""
        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{uuid.uuid4()}")

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organizations_search(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin organizations list with search filter."""
        client = create_test_client(db_session, admin_user)
        response = client.get("/admin/organizations?search=Acme")

        assert response.status_code == status.HTTP_200_OK
        assert "Acme" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_can_soft_delete_organization(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin can soft-delete an organization from admin route."""
        from app.domain.services.orgs import OrganizationService, SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Delete Cascade Site",
                site_code="DEL-ORG-01",
            ),
            created_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/delete",
            data={},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location") == "/admin/organizations"

        org_svc = OrganizationService(db_session)
        assert org_svc.get_by_id(setup_tenant.euid) is None

        # Related sites should also be soft-deleted.
        assert SiteService(db_session).get_by_id(site.euid) is None

        list_response = client.get("/admin/organizations")
        assert list_response.status_code == status.HTTP_200_OK
        assert setup_tenant.euid not in list_response.text

        detail_response = client.get(f"/admin/organizations/{setup_tenant.euid}")
        assert detail_response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_delete_requires_admin(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Non-admin users cannot delete organizations."""
        from app.domain.services.orgs import OrganizationService

        client = create_test_client(db_session, external_user)
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/delete",
            data={},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN
        assert OrganizationService(db_session).get_by_id(setup_tenant.euid) is not None

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_site_create_form_loads(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin can access site creation form for specific organization."""
        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}/sites/new")

        assert response.status_code == status.HTTP_200_OK
        assert "site" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_create_requires_initial_site(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Organization create enforces an initial site name."""
        from app.domain.services.orgs import OrganizationService

        unique_name = f"org-no-site-{uuid.uuid4().hex[:8]}"
        client = create_test_client(db_session, admin_user)
        response = client.post(
            "/admin/organizations/create",
            data={
                "name": unique_name,
                "display_name": "No Site Org",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_200_OK
        assert "Initial site name is required" in response.text

        org_svc = OrganizationService(db_session)
        was_created = False
        for org in org_svc.list_all(active_only=False):
            org_result = org_svc.get_with_revision(org.euid)
            if org_result and org_result[1].name == unique_name:
                was_created = True
                break
        assert was_created is False

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_create_creates_initial_site(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Organization create persists both organization and first site."""
        from app.domain.services.orgs import OrganizationService, SiteService

        unique_name = f"org-with-site-{uuid.uuid4().hex[:8]}"
        site_name = "Primary Onboarded Site"
        client = create_test_client(db_session, admin_user)
        response = client.post(
            "/admin/organizations/create",
            data={
                "name": unique_name,
                "display_name": "With Site Org",
                "initial_site_name": site_name,
                "initial_site_code": "ONB-001",
                "initial_site_city": "San Diego",
                "initial_site_state": "CA",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        org_svc = OrganizationService(db_session)
        created_org_euid = None
        for org in org_svc.list_all(active_only=False):
            org_result = org_svc.get_with_revision(org.euid)
            if org_result and org_result[1].name == unique_name:
                created_org_euid = org.euid
                break
        assert created_org_euid is not None

        sites = SiteService(db_session).list_by_organization(created_org_euid, active_only=False)
        assert len(sites) == 1
        assert sites[0].revisions
        assert sites[0].revisions[-1].name == site_name

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_user_create_form_loads(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin can access user creation form for specific organization."""
        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}/users/new")

        assert response.status_code == status.HTTP_200_OK
        assert "cognito group" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_user_create_uses_org_euid_route_param(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Posting user create under /admin/organizations/{org_euid}/users/new binds org tenant."""
        from app.domain.services.users import UserService

        email = f"org-euid-user-{uuid.uuid4().hex[:8]}@acme.com"
        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/users/new",
            data={
                "email": email,
                "name": "Org EUID User",
                "cognito_group": "lsmc-customers",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == f"/admin/organizations/{setup_tenant.euid}"

        created_user = UserService(db_session).get_by_email(email)
        assert created_user is not None
        assert created_user.tenant_id == setup_tenant.id

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_owner_accepts_fuzzy_email(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Organization owner input resolves email and stores owner EUID."""
        from app.domain.services.orgs import OrganizationService
        from app.domain.services.users import UserCreate, UserService

        owner = UserService(db_session, admin_user.sub_uuid).create(
            UserCreate(
                cognito_sub=str(uuid.uuid4()),
                email="owner-fuzzy@acme.com",
                name="Owner Fuzzy",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER_ADMIN"],
            )
        )

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/edit",
            data={
                "name": "acme-clinic",
                "display_name": "Acme Genetics",
                "org_type": "clinic",
                "is_active": "true",
                "owner_user_id": owner.email,
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        result = OrganizationService(db_session).get_with_revision(setup_tenant.euid)
        assert result is not None
        _org, revision = result
        assert revision.owner_user_id == owner.euid

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_owner_rejects_cross_org_assignment(
        self,
        db_session: Session,
        admin_user: CurrentUser,
        setup_tenant,
        setup_other_tenant,
        other_tenant_id: uuid.UUID,
    ):
        """Owner assignment enforces single-organization membership."""
        from app.domain.services.users import UserCreate, UserService

        foreign_user = UserService(db_session, admin_user.sub_uuid).create(
            UserCreate(
                cognito_sub=str(uuid.uuid4()),
                email="owner-foreign@acme.com",
                name="Owner Foreign",
                tenant_id=other_tenant_id,
                roles=["EXTERNAL_USER"],
            )
        )
        assert foreign_user is not None

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/edit",
            data={
                "name": "acme-clinic",
                "display_name": "Acme Genetics",
                "org_type": "clinic",
                "is_active": "true",
                "owner_user_id": foreign_user.email,
            },
        )

        assert response.status_code == status.HTTP_200_OK
        assert "same organization" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_edit_owner_displays_full_identity(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Edit form shows owner as EUID | email | name and avoids None contact values."""
        from app.domain.services.orgs import OrganizationService, OrganizationUpdate
        from app.domain.services.users import UserCreate, UserService

        owner = UserService(db_session, admin_user.sub_uuid).create(
            UserCreate(
                cognito_sub=str(uuid.uuid4()),
                email="owner-display@acme.com",
                name="Owner Display",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER_ADMIN"],
            )
        )

        OrganizationService(db_session).update(
            setup_tenant.euid,
            OrganizationUpdate(
                owner_user_id=owner.euid,
                contact_email=None,
                contact_phone=None,
            ),
            updated_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}/edit")

        assert response.status_code == status.HTTP_200_OK
        assert f"{owner.euid} | {owner.email} | {owner.name}" in response.text

        email_match = re.search(r'name="contact_email"[^>]*value="([^"]*)"', response.text)
        assert email_match is not None
        assert email_match.group(1) == owner.email

        phone_match = re.search(r'name="contact_phone"[^>]*value="([^"]*)"', response.text)
        assert phone_match is not None
        assert phone_match.group(1) == ""

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_owner_accepts_display_string(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Owner update accepts EUID | email | name input format."""
        from app.domain.services.orgs import OrganizationService
        from app.domain.services.users import UserCreate, UserService

        owner = UserService(db_session, admin_user.sub_uuid).create(
            UserCreate(
                cognito_sub=str(uuid.uuid4()),
                email="owner-display-format@acme.com",
                name="Owner Format",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER_ADMIN"],
            )
        )

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/edit",
            data={
                "name": "acme-clinic",
                "display_name": "Acme Genetics",
                "org_type": "clinic",
                "is_active": "true",
                "owner_user_id": f"{owner.euid} | {owner.email} | {owner.name}",
                "contact_email": "",
                "contact_phone": "",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        result = OrganizationService(db_session).get_with_revision(setup_tenant.euid)
        assert result is not None
        _org, revision = result
        assert revision.owner_user_id == owner.euid

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_edit_owner_display_handles_case_drift(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Edit form resolves owner profile even if stored owner EUID casing drifted."""
        from app.domain.services.orgs import OrganizationService, OrganizationUpdate
        from app.domain.services.users import UserCreate, UserService

        owner = UserService(db_session, admin_user.sub_uuid).create(
            UserCreate(
                cognito_sub=str(uuid.uuid4()),
                email="owner-case-drift@acme.com",
                name="Owner Case Drift",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER_ADMIN"],
            )
        )

        OrganizationService(db_session).update(
            setup_tenant.euid,
            OrganizationUpdate(owner_user_id=owner.euid.lower()),
            updated_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}/edit")

        assert response.status_code == status.HTTP_200_OK
        assert f"{owner.euid} | {owner.email} | {owner.name}" in response.text

        app.dependency_overrides.clear()


class TestMyOrganization:
    """Tests for my-organization pages (external user self-service)."""

    @pytest.mark.db
    def test_my_organization_page_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test external user can view their organization page."""
        client = create_test_client(db_session, external_user)
        response = client.get("/my-organization")

        assert response.status_code == status.HTTP_200_OK
        assert "Acme" in response.text or "organization" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_users_page_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test external user can view their organization users."""
        client = create_test_client(db_session, external_user)
        response = client.get("/my-organization/users")

        assert response.status_code == status.HTTP_200_OK
        assert "users" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_sites_page_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test external user can view their organization sites."""
        client = create_test_client(db_session, external_user)
        response = client.get("/my-organization/sites")

        assert response.status_code == status.HTTP_200_OK
        assert "sites" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_user_create_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test regular external user is blocked from user creation form (org admin only)."""
        client = create_test_client(db_session, external_user)
        response = client.get("/my-organization/users/new")

        # User creation now requires EXTERNAL_USER_ADMIN role
        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_org_admin_user_create_success(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant
    ):
        """Org admins invite users through canonical Cognito groups, not raw role checkboxes."""
        from app.domain.services.users import UserService

        client = create_test_client(db_session, external_user_admin)
        email = f"tenant-user-{uuid.uuid4().hex[:8]}@acme.com"

        response = client.post(
            "/my-organization/users/new",
            data={
                "email": email,
                "name": "Tenant User",
                "cognito_group": "lsmc-customers",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == "/my-organization/users"

        created_user = UserService(db_session).get_by_email(email)
        assert created_user is not None
        assert created_user.tenant_id == setup_tenant.id

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_site_create_form_loads(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant
    ):
        """Test org admin can access site creation form."""
        client = create_test_client(db_session, external_user_admin)
        response = client.get("/my-organization/sites/new")

        assert response.status_code == status.HTTP_200_OK
        assert "site" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_site_create_attaches_to_current_organization(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant
    ):
        """Org-admin site creation attaches to organization EUID scope."""
        from app.domain.services.orgs import SiteService

        client = create_test_client(db_session, external_user_admin)
        response = client.post(
            "/my-organization/sites/new",
            data={
                "name": "Org Admin Attached Site",
                "site_code": "ORG-ADM-01",
                "city": "San Francisco",
                "state": "CA",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == "/my-organization/sites"

        sites = SiteService(db_session).list_by_organization(setup_tenant.euid, active_only=False)
        created_site = next(
            (
                site
                for site in sites
                if site.revisions and site.revisions[-1].name == "Org Admin Attached Site"
            ),
            None,
        )
        assert created_site is not None

        site_instance = (
            db_session.query(generic_instance)
            .filter(generic_instance.euid == created_site.euid)
            .one()
        )
        site_props = (site_instance.json_addl or {}).get("properties", {})
        assert site_props.get("organization_id") == setup_tenant.euid
        assert str(site_props.get("organization_id")) != str(setup_tenant.id)

        list_response = client.get("/my-organization/sites")
        assert list_response.status_code == status.HTTP_200_OK
        assert "Org Admin Attached Site" in list_response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_bloom_validate_action_does_not_persist(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant, monkeypatch
    ):
        """Org-admin validate action checks submitted credentials without saving changes."""
        from app.domain.services.external_objects import (
            OrgBloomConfigService,
            OrgBloomConfigUpsert,
        )
        from app.web.routes import pages as pages_routes

        org_cfg_svc = OrgBloomConfigService(db_session)
        org_cfg_svc.upsert(
            setup_tenant.id,
            OrgBloomConfigUpsert(
                enabled=True,
                bloom_base_url="https://saved-myorg-bloom.local",
                bloom_api_key_secret_ref="env:SAVED_MYORG_BLOOM_API_KEY",
                bloom_webhook_secret_ref="env:SAVED_MYORG_BLOOM_WEBHOOK",
            ),
            actor_id=external_user_admin.sub_uuid,
        )

        captured: dict[str, str] = {}

        def _fake_validate(*, bloom_base_url: str, bloom_api_key_secret_ref: str) -> None:
            captured["bloom_base_url"] = bloom_base_url
            captured["bloom_api_key_secret_ref"] = bloom_api_key_secret_ref

        monkeypatch.setattr(pages_routes, "_validate_bloom_credentials", _fake_validate)

        client = create_test_client(db_session, external_user_admin)
        response = client.post(
            "/my-organization/integrations/bloom",
            data={
                "action": "validate",
                "enabled": "true",
                "bloom_base_url": "https://validate-myorg-bloom.local",
                "bloom_api_key_secret_ref": "env:VALIDATE_MYORG_BLOOM_API_KEY",
                "bloom_webhook_secret_ref": "env:VALIDATE_MYORG_BLOOM_WEBHOOK",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == "/my-organization"
        assert captured == {
            "bloom_base_url": "https://validate-myorg-bloom.local",
            "bloom_api_key_secret_ref": "env:VALIDATE_MYORG_BLOOM_API_KEY",
        }

        saved_cfg = org_cfg_svc.get(setup_tenant.id)
        assert saved_cfg is not None
        assert saved_cfg.bloom_base_url == "https://saved-myorg-bloom.local"
        assert saved_cfg.bloom_api_key_secret_ref == "env:SAVED_MYORG_BLOOM_API_KEY"
        assert saved_cfg.bloom_webhook_secret_ref == "env:SAVED_MYORG_BLOOM_WEBHOOK"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_my_organization_page_checks_bloom_connection_status_on_load(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, monkeypatch
    ):
        """My-organization page performs Bloom credential check on load and renders healthy status."""
        from app.domain.services.external_objects import (
            OrgBloomConfigService,
            OrgBloomConfigUpsert,
        )
        from app.web.routes import pages as pages_routes

        OrgBloomConfigService(db_session).upsert(
            setup_tenant.id,
            OrgBloomConfigUpsert(
                enabled=True,
                bloom_base_url="https://healthcheck-myorg-bloom.local",
                bloom_api_key_secret_ref="env:HEALTHCHECK_MYORG_BLOOM_API_KEY",
            ),
            actor_id=external_user.sub_uuid,
        )

        captured: dict[str, str] = {}

        def _fake_validate(*, bloom_base_url: str, bloom_api_key_secret_ref: str) -> None:
            captured["bloom_base_url"] = bloom_base_url
            captured["bloom_api_key_secret_ref"] = bloom_api_key_secret_ref

        monkeypatch.setattr(pages_routes, "_check_bloom_connection_health", _fake_validate)

        client = create_test_client(db_session, external_user)
        response = client.get("/my-organization")

        assert response.status_code == status.HTTP_200_OK
        assert captured == {
            "bloom_base_url": "https://healthcheck-myorg-bloom.local",
            "bloom_api_key_secret_ref": "env:HEALTHCHECK_MYORG_BLOOM_API_KEY",
        }
        assert 'id="bloom-connection-status"' in response.text
        assert 'data-bloom-connection-status="healthy"' in response.text
        assert "Connection OK" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_site_service_get_by_id_canonicalizes_legacy_tenant_uuid_link(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant
    ):
        """Legacy site org UUID links are canonicalized to org EUID on read."""
        from app.domain.services.orgs import SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Legacy Linked Site",
                site_code="LEG-ORG-01",
            ),
            created_by=external_user_admin.sub_uuid,
        )
        site_instance = (
            db_session.query(generic_instance).filter(generic_instance.euid == site.euid).one()
        )
        site_props = dict((site_instance.json_addl or {}).get("properties") or {})
        site_props["organization_id"] = str(setup_tenant.id)
        site_instance.json_addl = {**(site_instance.json_addl or {}), "properties": site_props}
        db_session.commit()

        loaded_site = SiteService(db_session).get_by_id(site.euid)
        assert loaded_site is not None
        assert loaded_site.organization_id == setup_tenant.euid

        app.dependency_overrides.clear()


class TestOrganizationUserAPI:
    """Tests for organization user API endpoints."""

    @pytest.mark.db
    def test_api_list_organization_users(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test listing users in an organization via API."""
        client = create_test_client(db_session, external_user)
        response = client.get(f"/api/organizations/{setup_tenant.euid}/users")

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "items" in data
        assert "total" in data

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_api_create_organization_user_success(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test creating a user in an organization via API."""
        from app.domain.services.users import UserService

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/api/organizations/{setup_tenant.euid}/users",
            json={
                "email": "newuser@acme.com",
                "name": "New User",
                "roles": ["EXTERNAL_USER"],
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["email"] == "newuser@acme.com"
        assert "EXTERNAL_USER" in data["roles"]

        # Verify user was created
        user = UserService(db_session).get_by_email("newuser@acme.com")
        assert user is not None

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_api_external_user_cannot_assign_admin_role(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test external users cannot assign ADMIN or INTERNAL_USER roles via API."""
        client = create_test_client(db_session, external_user)
        response = client.post(
            f"/api/organizations/{setup_tenant.euid}/users",
            json={
                "email": "admin@acme.com",
                "roles": ["ADMIN"],
            },
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_api_update_organization(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test updating an organization via API."""
        client = create_test_client(db_session, admin_user)
        response = client.patch(
            f"/api/organizations/{setup_tenant.euid}",
            json={
                "display_name": "Updated Acme Corp",
            },
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["display_name"] == "Updated Acme Corp"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_api_update_organization_non_admin_forbidden(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test non-admin users cannot update organizations via API."""
        client = create_test_client(db_session, external_user)
        response = client.patch(
            f"/api/organizations/{external_user.tenant_id}",
            json={
                "display_name": "Hacked Name",
            },
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()


# =============================================================================
# 2. DISPLAY/READ FLOWS
# =============================================================================


class TestDashboard:
    """Tests for dashboard page."""

    @pytest.mark.db
    def test_dashboard_loads_for_external_user(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test dashboard page loads for external users."""
        client = create_test_client(db_session, external_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK
        assert "dashboard" in response.text.lower() or "order" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_dashboard_loads_for_internal_user(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test dashboard page loads for internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_dashboard_renders_non_zero_tapdb_counts_for_tenant(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Dashboard counters should reflect TapDB-backed TRF/shipment data."""
        from app.domain.enums import OrderPatientRole, ShipmentStatus
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.shipments import ShipmentCreate, ShipmentService
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        patient = _create_test_patient(db_session, external_user.tenant_id, external_user.sub_uuid)
        trf_svc = TrfService(db_session, external_user.tenant_id)
        trf_svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=external_user.sub_uuid,
        )

        shipment_svc = ShipmentService(db_session, external_user.tenant_id)
        shipment, _shipment_revision = shipment_svc.create(
            ShipmentCreate(carrier="FedEx", tracking_number="1234567890"),
            created_by=external_user.sub_uuid,
        )
        shipment_svc.change_status(
            shipment.euid,
            ShipmentStatus.IN_TRANSIT,
            updated_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)
        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK
        assert re.search(
            r'<div class="stat-value">\s*1\s*</div>\s*<div class="stat-label">Total TRFs</div>',
            response.text,
        )
        assert re.search(
            r'<div class="stat-value">\s*1\s*</div>\s*<div class="stat-label">Shipments In Transit</div>',
            response.text,
        )

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_dashboard_welcome_uses_email(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Dashboard subtitle greets users by email."""
        client = create_test_client(db_session, external_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK
        assert f"Welcome back, {external_user.email}" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_internal_nav_uses_lsmc_menu_and_manage_documents(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Internal nav exposes LSMC links and no legacy Entities menu."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK
        assert "LSMC ▾" in response.text
        assert "Intake Exceptions" in response.text
        assert "TapDB GUI" in response.text
        assert "Documents" in response.text
        assert "Entities ▾" not in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_external_nav_hides_lsmc_menu(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """LSMC menu is shown only to LSMC users (internal/admin)."""
        client = create_test_client(db_session, external_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK
        assert "LSMC ▾" not in response.text
        assert "Intake Scan & Match" not in response.text
        assert "LIMS ↗" not in response.text
        assert "Bloom ↗" not in response.text
        assert "TapDB GUI" not in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_dashboard_loads_for_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test dashboard page loads for admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()


class TestListPages:
    """Tests for list pages."""

    @pytest.mark.db
    def test_orders_list_page(self, db_session: Session, external_user: CurrentUser, setup_tenant):
        """Test orders list page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/trfs")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_orders_list_with_status_filter(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test orders list with status filter."""
        client = create_test_client(db_session, external_user)

        response = client.get("/trfs?status=DRAFT")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patients_list_page(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test patients list page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/patients")

        assert response.status_code == status.HTTP_200_OK
        assert "Patients" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_shipments_list_page(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test shipments list page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/shipments")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_list_page(self, db_session: Session, external_user: CurrentUser, setup_tenant):
        """Test results list page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/results")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_set_pages_render_from_tapdb(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Results-set list/detail pages should render TapDB-backed set/run/result/artifact data."""
        from app.domain.services.fulfillment_runs import (
            FulfillmentOutputService,
            FulfillmentRunService,
            ResultCreate,
            ResultsSetService,
        )
        from app.domain.services.releases import ArtifactCreate, ReleaseService
        from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService

        trf_svc = TrfService(db_session, internal_user.tenant_id)
        test_svc = TestService(db_session, internal_user.tenant_id)
        assay_run_svc = FulfillmentRunService(db_session, internal_user.tenant_id)
        result_svc = FulfillmentOutputService(db_session, internal_user.tenant_id)
        rs_svc = ResultsSetService(db_session, internal_user.tenant_id)
        release_svc = ReleaseService(db_session, internal_user.tenant_id)

        trf, _trf_rev = trf_svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            created_by=internal_user.sub_uuid,
        )
        test_rows = test_svc.list_for_trf(trf.euid)
        assert test_rows
        test, _test_rev, _assay_rows = test_rows[0]
        assay_runs = assay_run_svc.list_for_test_order(test.euid)
        assert assay_runs
        assay_run, _assay_rev = assay_runs[0]

        artifact = release_svc.register_artifact(
            ArtifactCreate(
                source_system="daylily-ursa",
                source_uid=f"analysis:{assay_run.euid}",
                filename="result.json",
                checksum="abc123",
                artifact_type="json",
                s3_bucket="bucket",
                s3_key="results/result.json",
            ),
            created_by=internal_user.sub_uuid,
        )
        result_svc.create(
            fulfillment_run_euid=assay_run.euid,
            data=ResultCreate(
                result_payload={"result": "PASS"},
                artifact_ids=[artifact.euid],
            ),
            created_by=internal_user.sub_uuid,
        )

        rs = rs_svc.get_or_create_for_test(test.euid, created_by=internal_user.sub_uuid)
        rs_svc.add_fulfillment_run(rs.euid, assay_run.euid)
        db_session.commit()

        client = create_test_client(db_session, internal_user)
        list_response = client.get("/results-sets")
        assert list_response.status_code == status.HTTP_200_OK
        assert trf.order_number in list_response.text

        detail_response = client.get(f"/results-sets/{rs.euid}")
        assert detail_response.status_code == status.HTTP_200_OK
        assert assay_run.fulfillment_route_code in detail_response.text
        assert artifact.filename in detail_response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_documents_upload_redirects_to_shipment_by_euid(
        self,
        db_session: Session,
        internal_user: CurrentUser,
        setup_tenant,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """Entity-linked document uploads should redirect using TapDB shipment lookup."""
        from types import SimpleNamespace

        import app.domain.services.documents as documents_module
        from app.domain.services.shipments import ShipmentCreate, ShipmentService

        shipment_svc = ShipmentService(db_session, internal_user.tenant_id)
        shipment, _revision = shipment_svc.create(
            ShipmentCreate(carrier="FedEx", tracking_number="TRACK-1"),
            created_by=internal_user.sub_uuid,
        )

        def _fake_upload(self, data, created_by=None):  # noqa: ANN001, ANN002
            return SimpleNamespace(document_euid="DOC-TEST-1")

        def _fake_link_to_entity(self, document_euid, entity_type, entity_id, created_by=None):  # noqa: ANN001
            assert document_euid == "DOC-TEST-1"
            assert entity_type == "Shipment"
            assert entity_id == shipment.euid
            return None

        monkeypatch.setattr(documents_module.DocumentService, "upload", _fake_upload)
        monkeypatch.setattr(
            documents_module.DocumentService, "link_to_entity", _fake_link_to_entity
        )

        client = create_test_client(db_session, internal_user)
        response = client.post(
            "/documents/upload",
            data={
                "document_type": "OTHER",
                "entity_type": "Shipment",
                "entity_id": shipment.euid,
            },
            files={"file": ("notes.txt", b"hello", "text/plain")},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers["location"] == f"/shipments/{shipment.shipment_number}"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_api_tokens_page_uses_tapdb_token_user_resolution(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin API tokens page should render token owner email without orm_models lookups."""
        from app.auth.rbac import Role
        from app.domain.enums import TokenScope
        from app.domain.services.user_api_tokens import TokenCreate, UserAPITokenService
        from app.domain.services.users import UserCreate, UserService

        user_svc = UserService(db_session, admin_user.sub_uuid)
        if not user_svc.get_by_cognito_sub(admin_user.sub):
            user_svc.create(
                UserCreate(
                    email=admin_user.email,
                    name=admin_user.name,
                    tenant_id=admin_user.tenant_id,
                    roles=[Role.ADMIN.value],
                    cognito_sub=admin_user.sub,
                )
            )

        token_svc = UserAPITokenService(db_session, admin_user.tenant_id)
        token_svc.create(
            user_id=admin_user.sub_uuid,
            data=TokenCreate(
                token_name="Ops Token",
                expires_in_days=30,
                scope=TokenScope.ATLAS_ADMIN.value,
            ),
            created_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.get("/admin/api-tokens")

        assert response.status_code == status.HTTP_200_OK
        assert "Ops Token" in response.text
        assert admin_user.email in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_list_pages_include_tapdb_euid_links(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Key list views render clickable TapDB object links."""
        from app.domain.services.shipments import ShipmentCreate, ShipmentService
        from app.domain.services.trfs import TrfCreate, TrfService

        patient = _create_test_patient(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Tapdb",
            last_name="Link",
        )
        order, _order_rev = TrfService(db_session, external_user.tenant_id).create(
            TrfCreate(order_type="CLINICAL"),
            created_by=external_user.sub_uuid,
        )
        shipment, _shipment_rev = ShipmentService(db_session, external_user.tenant_id).create(
            ShipmentCreate(),
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)
        orders_response = client.get("/trfs")
        patients_response = client.get("/patients")
        shipments_response = client.get("/shipments")

        assert orders_response.status_code == status.HTTP_200_OK
        assert patients_response.status_code == status.HTTP_200_OK
        assert shipments_response.status_code == status.HTTP_200_OK
        assert f"/trfs/{order.euid}" in orders_response.text
        assert f"/tapdb/object/{patient.euid}" in patients_response.text
        assert f"/tapdb/object/{shipment.euid}" in shipments_response.text

        app.dependency_overrides.clear()


class TestDetailPages:
    """Tests for detail pages."""

    @pytest.fixture
    def sample_patient(
        self, db_session: Session, setup_tenant, external_user: CurrentUser
    ) -> Patient:
        """Create a sample patient."""
        return _create_test_patient(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Test",
            last_name="Patient",
        )

    @pytest.mark.db
    def test_patient_detail_page(
        self, db_session: Session, external_user: CurrentUser, setup_tenant, sample_patient
    ):
        """Test patient detail page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/patients/{sample_patient.euid}")

        assert response.status_code == status.HTTP_200_OK
        # Check for patient name in response
        assert "Test" in response.text or "Patient" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_patient_detail_not_found(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test patient detail with non-existent ID."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/patients/{uuid.uuid4()}")

        # Should return 404
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_detail_page(self, db_session: Session, external_user: CurrentUser, setup_tenant):
        """Test order detail page loads."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        # Create a patient first
        patient = _create_test_patient(db_session, external_user.tenant_id, external_user.sub_uuid)

        # Create an order
        svc = TrfService(db_session, external_user.tenant_id)
        order, _ = svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.get(f"/trfs/{order.order_number}")

        assert response.status_code == status.HTTP_200_OK
        assert order.order_number in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_shipment_detail_page(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test shipment detail page returns 404 for non-existent shipment."""
        client = create_test_client(db_session, external_user)

        # Non-existent shipment should return 404
        response = client.get(f"/shipments/{uuid.uuid4()}")

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()


class TestAdminPages:
    """Tests for admin pages."""

    @pytest.mark.db
    def test_admin_index_requires_admin(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test admin index requires admin role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/admin")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_index_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin index accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_index_shows_interfaces_and_library_info(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin index exposes Bloom-style interface and dependency metadata."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin")

        assert response.status_code == status.HTTP_200_OK
        assert "System Interfaces" in response.text
        assert "Library Dependencies" in response.text
        assert "daylily-tapdb" in response.text
        assert "/tapdb" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_tapdb_route_denies_external_user(
        self,
        monkeypatch,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
    ):
        """Mounted /tapdb enforces admin/internal session gate."""
        if not any(getattr(route, "path", None) == "/tapdb" for route in app.routes):
            pytest.skip("TapDB admin app not mounted in this test environment")

        monkeypatch.setattr(
            "app.auth.dependencies._get_current_user_from_session",
            lambda _request: external_user,
        )
        client = create_test_client(db_session, external_user)
        response = client.get("/tapdb", follow_redirects=False)

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_tapdb_route_allows_internal_user(
        self,
        monkeypatch,
        db_session: Session,
        internal_user: CurrentUser,
        setup_tenant,
    ):
        """Mounted /tapdb allows internal users."""
        if not any(getattr(route, "path", None) == "/tapdb" for route in app.routes):
            pytest.skip("TapDB admin app not mounted in this test environment")

        monkeypatch.setattr(
            "app.auth.dependencies._get_current_user_from_session",
            lambda _request: internal_user,
        )
        client = create_test_client(db_session, internal_user)
        response = client.get("/tapdb", follow_redirects=False)

        assert response.status_code != status.HTTP_403_FORBIDDEN
        assert response.status_code in (
            status.HTTP_200_OK,
            status.HTTP_302_FOUND,
            status.HTTP_307_TEMPORARY_REDIRECT,
        )

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_settings_accessible_to_external_user(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test settings page is accessible to external users (self-service settings)."""
        client = create_test_client(db_session, external_user)

        response = client.get("/admin/settings")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_settings_accessible(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test settings page accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/settings")

        assert response.status_code == status.HTTP_200_OK
        assert "theme" in response.text.lower() or "settings" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_audit_requires_admin(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test audit page requires admin role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/admin/audit")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_audit_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test audit page accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/audit")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organizations_requires_admin(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test organizations page requires admin role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/admin/organizations")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organizations_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test organizations page accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/organizations")

        assert response.status_code == status.HTTP_200_OK
        assert "organization" in response.text.lower()
        assert f"/tapdb/object/{setup_tenant.euid}" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_assays_requires_admin(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test assays page requires admin role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/admin/test-definitions")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_assays_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test test-definitions page accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/test-definitions")

        assert response.status_code == status.HTTP_200_OK
        assert "test configuration" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test users page accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/users")

        assert response.status_code == status.HTTP_200_OK
        assert "user" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_requires_admin(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test users page requires admin role (not just internal)."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/admin/users")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()


# =============================================================================
# 3. INTERNAL-ONLY FLOWS
# =============================================================================


class TestIntakeFlows:
    """Tests for intake flows (internal users only)."""

    @pytest.mark.db
    def test_intake_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test intake page requires internal role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/intake")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_intake_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test intake page accessible to internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/intake")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_scan_match_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test scan & match page requires internal role."""
        client = create_test_client(db_session, external_user)

        # The scan-match page is at /intake (not /intake/scan-match)
        response = client.get("/intake")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exceptions_queue_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test exceptions queue requires internal role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/exceptions")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifests_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test manifests page requires internal role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/manifests")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()


class TestReleasePackageCreation:
    """Tests for release package creation (internal users only)."""

    @pytest.mark.db
    def test_results_create_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test release creation requires internal role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/results/create")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_create_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test release creation accessible to internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/results/create")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()


# =============================================================================
# 4. TENANT ISOLATION TESTS
# =============================================================================


class TestTenantIsolation:
    """Tests for multi-tenant data isolation."""

    @pytest.fixture
    def tenant_a_patient(
        self, db_session: Session, setup_tenant, external_user: CurrentUser
    ) -> Patient:
        """Create a patient in tenant A."""
        return _create_test_patient(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Tenant A",
            last_name="Patient",
        )

    @pytest.fixture
    def tenant_b_patient(
        self, db_session: Session, setup_other_tenant, other_tenant_user: CurrentUser
    ) -> Patient:
        """Create a patient in tenant B."""
        return _create_test_patient(
            db_session,
            other_tenant_user.tenant_id,
            other_tenant_user.sub_uuid,
            first_name="Tenant B",
            last_name="Patient",
        )

    @pytest.mark.db
    def test_external_user_cannot_see_other_tenant_patient(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        setup_other_tenant,
        tenant_b_patient,
    ):
        """Test external user cannot access patient from another tenant."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/patients/{tenant_b_patient.euid}")

        # Should return 404 (not found in user's tenant scope)
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_user_can_see_own_tenant_patient(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        tenant_a_patient,
    ):
        """Test user can access patient from their own tenant."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/patients/{tenant_a_patient.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "Tenant A" in response.text

        app.dependency_overrides.clear()


# =============================================================================
# 5. APPEND-ONLY / REVERSAL EVENT TESTS
# =============================================================================


class TestAppendOnlyModel:
    """Tests verifying append-only data model and reversal events."""

    @pytest.mark.db
    def test_patient_update_creates_new_revision(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test that updating a patient creates a new revision (no overwrites)."""
        from app.domain.services.people import PatientService, PatientUpdate
        from app.persistence.tapdb.people import PATIENT_REV_TEMPLATE_CODE, TapdbPeopleRepository

        patient = _create_test_patient(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Original",
            last_name="Name",
        )
        repo = TapdbPeopleRepository(db_session)

        def _count_patient_revisions(patient_id: uuid.UUID) -> int:
            total = 0
            for instance in repo._instances_for_template(PATIENT_REV_TEMPLATE_CODE):  # noqa: SLF001
                props = (instance.json_addl or {}).get("properties", {})
                if str(props.get("patient_id")) == str(patient_id):
                    total += 1
            return total

        initial_count = _count_patient_revisions(patient.euid)
        assert initial_count == 1

        PatientService(db_session, external_user.tenant_id, external_user.sub_uuid).update(
            patient.euid,
            PatientUpdate(first_name="Updated", note="Updated first name"),
            updated_by=external_user.sub_uuid,
        )

        assert _count_patient_revisions(patient.euid) == initial_count + 1
        latest = repo.get_latest_patient_revision(patient.euid)
        assert latest is not None
        assert latest.first_name == "Updated"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_link_event_records_entity_linking(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test that link events are created for entity relationships."""
        from app.persistence.tapdb.documents import TapdbDocumentRepository

        repo = TapdbDocumentRepository(db_session)
        # Create a link event
        source_id = uuid.uuid4()
        target_id = uuid.uuid4()
        repo.add_link_event(
            tenant_id=external_user.tenant_id,
            action=LinkAction.LINK.value,
            source_type="EXTERNAL_OBJECT",
            source_id=source_id,
            target_type="TESTORDER",
            target_id=target_id,
            created_by=uuid.UUID(external_user.sub),
        )

        # Verify link event exists
        events = repo.get_link_events_for_target(
            tenant_id=external_user.tenant_id,
            target_type="TESTORDER",
            target_id=target_id,
            source_type="EXTERNAL_OBJECT",
        )
        assert len(events) == 1
        assert events[0].action == LinkAction.LINK.value

        # Create an UNLINK event (reversal, not DELETE)
        repo.add_link_event(
            tenant_id=external_user.tenant_id,
            action=LinkAction.UNLINK.value,
            source_type="EXTERNAL_OBJECT",
            source_id=source_id,
            target_type="TESTORDER",
            target_id=target_id,
            created_by=uuid.UUID(external_user.sub),
        )

        # Both events should exist (append-only)
        all_events = repo.get_link_events_for_target(
            tenant_id=external_user.tenant_id,
            target_type="TESTORDER",
            target_id=target_id,
            source_type="EXTERNAL_OBJECT",
        )
        assert len(all_events) == 2

        app.dependency_overrides.clear()


# =============================================================================
# 6. ERROR HANDLING AND VALIDATION
# =============================================================================


class TestErrorHandling:
    """Tests for error handling and validation."""

    @pytest.mark.db
    def test_404_for_nonexistent_entity(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test 404 returned for non-existent entity ID."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/patients/{uuid.uuid4()}")

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_invalid_uuid_format(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test error handling for invalid UUID format."""
        client = create_test_client(db_session, external_user)

        response = client.get("/patients/not-a-valid-uuid")

        # Should return 422 (validation error) or 404
        assert response.status_code in [
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            status.HTTP_404_NOT_FOUND,
        ]

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_form_validation_error_missing_field(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test form validation error for missing required field."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/patients/new",
            data={"first_name": "John"},  # Missing last_name
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_custom_404_page_for_browser(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test custom 404 page is returned for browser requests (issue #10)."""
        client = create_test_client(db_session, external_user)

        response = client.get("/this-page-does-not-exist")

        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert "Page Not Found" in response.text
        assert "Go to Dashboard" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_404_json_for_api_requests(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test 404 returns JSON for API requests (issue #10)."""
        client = create_test_client(db_session, external_user)

        response = client.get(
            "/api/this-does-not-exist",
            headers={"accept": "application/json"},
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND
        data = response.json()
        assert data["detail"] == "Not found"

        app.dependency_overrides.clear()


class TestFormPages:
    """Tests for form pages (GET requests)."""

    @pytest.mark.db
    def test_new_patient_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test new patient form page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/patients/new")

        assert response.status_code == status.HTTP_200_OK
        assert "patient" in response.text.lower() or "form" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_new_order_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test new order form page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/trfs/new")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_new_order_form_shows_patient_dob(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test that the new order form shows patient date of birth (issue #12)."""
        from datetime import date

        from app.domain.services.people import PatientCreate, PatientService

        # Create a patient with a known DOB in TapDB-backed service
        PatientService(db_session, external_user.tenant_id).create(
            PatientCreate(
                first_name="Jane",
                last_name="Smith",
                date_of_birth=date(1990, 3, 15),
            ),
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.get("/trfs/new")

        assert response.status_code == status.HTTP_200_OK
        # The dropdown should show the patient DOB
        assert "1990-03-15" in response.text
        assert "Jane Smith" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_new_shipment_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test new shipment form page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/shipments/new")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_new_clinician_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test new clinician form page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/clinicians/new")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()


# =============================================================================
# 7. HTMX / DYNAMIC INTERACTIONS (Scan & Match)
# =============================================================================


class TestHTMXInteractions:
    """Tests for HTMX-based dynamic interactions."""

    @pytest.mark.db
    def test_barcode_lookup_endpoint(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test barcode lookup HTMX endpoint."""
        client = create_test_client(db_session, internal_user)

        # Test barcode lookup (may return empty result)
        response = client.post(
            "/htmx/scan-match/lookup",
            data={"barcode": "TEST123456"},
            headers={"HX-Request": "true"},
        )

        # Should return 200 with HTMX partial
        assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_intake_scan_match_page_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test scan & match page loads for internal users."""
        client = create_test_client(db_session, internal_user)

        # The scan-match page is at /intake (not /intake/scan-match)
        response = client.get("/intake")

        assert response.status_code == status.HTTP_200_OK
        # Should contain scan/match related content
        assert "scan" in response.text.lower() or "match" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_intake_print_labels_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test intake print labels page requires internal role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/intake/print")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_intake_print_labels_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test intake print labels page accessible to internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/intake/print")

        assert response.status_code == status.HTTP_200_OK
        # Should contain print-related content
        assert "print" in response.text.lower() or "label" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_intake_exceptions_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test intake exceptions page requires internal role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/intake/exceptions")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_intake_exceptions_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test intake exceptions page accessible to internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/intake/exceptions")

        assert response.status_code == status.HTTP_200_OK
        # Should contain exception-related content
        assert "exception" in response.text.lower() or "queue" in response.text.lower()

        app.dependency_overrides.clear()


# =============================================================================
# 8. READ-ONLY USER TESTS
# =============================================================================


class TestReadOnlyUser:
    """Tests for read-only user restrictions."""

    @pytest.mark.db
    def test_read_only_can_view_dashboard(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user can view dashboard."""
        client = create_test_client(db_session, read_only_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_can_view_patient_list(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user can view patient list."""
        client = create_test_client(db_session, read_only_user)

        response = client.get("/patients")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_can_view_orders(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user can view orders."""
        client = create_test_client(db_session, read_only_user)

        response = client.get("/trfs")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_cannot_create_order(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user gets 403 when POSTing to create order."""
        client = create_test_client(db_session, read_only_user)

        response = client.post(
            "/trfs/new",
            data={"patient_id": str(uuid.uuid4()), "order_type": "CLINICAL"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_cannot_create_patient(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user gets 403 when POSTing to create patient."""
        client = create_test_client(db_session, read_only_user)

        response = client.post(
            "/patients/new",
            data={
                "first_name": "John",
                "last_name": "Doe",
                "date_of_birth": "1985-06-15",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_cannot_create_clinician(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user gets 403 when POSTing to create clinician."""
        client = create_test_client(db_session, read_only_user)

        response = client.post(
            "/clinicians/new",
            data={
                "first_name": "Jane",
                "last_name": "Smith",
                "credentials": "MD",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_cannot_create_shipment(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user gets 403 when POSTing to create shipment."""
        client = create_test_client(db_session, read_only_user)

        response = client.post(
            "/shipments/new",
            data={"carrier": "FedEx", "tracking_number": "123456789"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_cannot_edit_patient(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user gets 403 when POSTing to edit patient."""
        client = create_test_client(db_session, read_only_user)

        fake_patient_id = uuid.uuid4()
        response = client.post(
            f"/patients/{fake_patient_id}/edit",
            data={
                "first_name": "John",
                "last_name": "Doe",
                "date_of_birth": "1985-06-15",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_cannot_view_create_form(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user gets 403 when accessing order create form."""
        client = create_test_client(db_session, read_only_user)

        response = client.get("/trfs/new")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_dashboard_no_create_buttons(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user dashboard does not show 'New TRF' button."""
        client = create_test_client(db_session, read_only_user)

        response = client.get("/")

        assert response.status_code == status.HTTP_200_OK
        assert "New TRF" not in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_read_only_order_list_no_create_buttons(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test read-only user order list does not show '+ New TRF' button."""
        client = create_test_client(db_session, read_only_user)

        response = client.get("/trfs")

        assert response.status_code == status.HTTP_200_OK
        assert "+ New TRF" not in response.text

        app.dependency_overrides.clear()


# =============================================================================
# 9. DOCUMENT UPLOAD TESTS
# =============================================================================


class TestDocumentUpload:
    """Tests for document upload flows."""

    @pytest.mark.db
    def test_document_upload_form_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test document upload endpoint exists (internal only)."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        # Create a patient first
        patient = _create_test_patient(db_session, internal_user.tenant_id, internal_user.sub_uuid)

        # Create an order
        svc = TrfService(db_session, internal_user.tenant_id)
        order, _ = svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        # Document upload is a POST endpoint for internal users
        # Just verify the order detail page loads (documents would be shown there)
        response = client.get(f"/trfs/{order.order_number}")

        assert response.status_code == status.HTTP_200_OK
        # Order detail page should load successfully
        assert order.order_number in response.text

        app.dependency_overrides.clear()


# =============================================================================
# 10. EXCEPTION QUEUE TESTS (Internal)
# =============================================================================


class TestExceptionQueue:
    """Tests for exception queue operations."""

    @pytest.mark.db
    def test_exceptions_list_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exceptions list GUI route is deprecated for internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/exceptions")

        assert response.status_code == status.HTTP_410_GONE
        assert response.headers.get("x-atlas-deprecated") == "true"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exceptions_list_denied_to_external(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test exceptions list denied to external users."""
        client = create_test_client(db_session, external_user)

        response = client.get("/exceptions")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()


# =============================================================================
# 11. AUDIT LOG TESTS
# =============================================================================


class TestAuditLogging:
    """Tests for audit event creation."""

    @pytest.mark.db
    @pytest.mark.skip(reason="Audit event creation not yet implemented in patient create flow")
    def test_audit_event_created_on_patient_create(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test that audit event is created when patient is created."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/patients/new",
            data={
                "first_name": "Audit",
                "last_name": "Test",
            },
            follow_redirects=False,
        )

        # Verify patient was created
        assert response.status_code == status.HTTP_303_SEE_OTHER

        # Check for audit event (may not be created for all actions)
        (
            db_session.query(AuditEvent)
            .filter_by(tenant_id=external_user.tenant_id)
            .filter_by(action=AuditAction.CREATE)
            .all()
        )
        # Note: Audit event creation depends on service implementation
        # This test documents expected behavior
        # assert len(audit_events) >= 1

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_can_view_audit_log(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin can view audit log page."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/audit")

        assert response.status_code == status.HTTP_200_OK
        assert "audit" in response.text.lower()

        app.dependency_overrides.clear()


# =============================================================================
# 12. MANIFEST UPLOAD TESTS (Internal)
# =============================================================================


class TestManifestUpload:
    """Tests for manifest upload flows."""

    @pytest.mark.db
    def test_manifests_page_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test manifests page requires internal role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/manifests")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifests_page_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test manifests GUI route is deprecated for internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/manifests")

        assert response.status_code == status.HTTP_410_GONE
        assert response.headers.get("x-atlas-deprecated") == "true"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifest_upload_form_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test manifest upload GUI route is deprecated."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/manifests/upload")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()


# =============================================================================
# 13. SUPPORT TICKET TESTS
# =============================================================================


class TestSupportTicketRoutes:
    """Tests for support ticket web routes."""

    @pytest.mark.db
    def test_support_list_page_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test support list page loads for external users."""
        client = create_test_client(db_session, external_user)

        response = client.get("/support")

        assert response.status_code == status.HTTP_200_OK
        assert "support" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_support_create_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test support ticket create form loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/support/create")

        assert response.status_code == status.HTTP_200_OK
        assert "create" in response.text.lower() or "new" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_support_create_success(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test successful support ticket creation."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/support/create",
            data={
                "subject": "Test Support Ticket",
                "description": "This is a test ticket description",
                "ticket_type": "TECHNICAL",
                "priority": "NORMAL",
            },
            follow_redirects=False,
        )

        # Should redirect on success
        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/support/" in response.headers.get("location", "")

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_support_detail_page_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test support ticket detail page loads."""
        from app.domain.services.support import SupportTicketService, TicketCreate

        # Create a ticket first
        svc = SupportTicketService(db_session, external_user.tenant_id, external_user.sub_uuid)
        ticket, _ = svc.create(
            TicketCreate(
                subject="Test Ticket",
                description="Test description",
                ticket_type="TECHNICAL",
                priority="NORMAL",
            ),
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.get(f"/support/{ticket.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "Test Ticket" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_support_resolve_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test that resolving a ticket requires internal user role."""
        from app.domain.services.support import SupportTicketService, TicketCreate

        # Create a ticket
        svc = SupportTicketService(db_session, external_user.tenant_id, external_user.sub_uuid)
        ticket, _ = svc.create(
            TicketCreate(
                subject="Test Ticket",
                description="Test description",
                ticket_type="TECHNICAL",
                priority="NORMAL",
            ),
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.post(
            f"/support/{ticket.euid}/resolve",
            data={"resolution_notes": "Resolved by test"},
            follow_redirects=False,
        )

        # External users should be forbidden
        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_support_resolve_success_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test internal user can resolve a ticket."""
        from app.domain.services.support import SupportTicketService, TicketCreate

        # Create a ticket
        svc = SupportTicketService(db_session, internal_user.tenant_id, internal_user.sub_uuid)
        ticket, _ = svc.create(
            TicketCreate(
                subject="Test Ticket",
                description="Test description",
                ticket_type="TECHNICAL",
                priority="NORMAL",
            ),
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/support/{ticket.euid}/resolve",
            data={"resolution_notes": "Resolved by internal user"},
            follow_redirects=False,
        )

        # Should redirect on success
        assert response.status_code == status.HTTP_303_SEE_OTHER

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_support_list_with_filters(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test support list page with status and type filters."""
        client = create_test_client(db_session, external_user)

        response = client.get("/support?status=OPEN&ticket_type=TECHNICAL")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()


# =============================================================================
# 14. EXCEPTION WORKFLOW TESTS
# =============================================================================


class TestExceptionWorkflowRoutes:
    """Tests for exception workflow web routes."""

    @pytest.mark.db
    def test_exceptions_list_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test exceptions list requires internal user role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/exceptions")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exceptions_list_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exceptions list GUI route is deprecated for internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/exceptions")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exception_detail_page_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exception detail GUI route is deprecated."""
        from app.domain.services.exceptions import ExceptionCreate, ExceptionService
        from app.persistence.tapdb.orm_models.exceptions import ExceptionType

        # Create an exception first
        svc = ExceptionService(db_session, internal_user.tenant_id, internal_user.sub)
        exception, _ = svc.create(
            ExceptionCreate(
                exception_type=ExceptionType.MISSING_ID,
                note="Test exception",
            ),
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.get(f"/exceptions/{exception.exception_number}")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exception_assign_success(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exception assign GUI route is deprecated."""
        from app.domain.services.exceptions import ExceptionCreate, ExceptionService
        from app.persistence.tapdb.orm_models.exceptions import ExceptionType

        # Create an exception
        svc = ExceptionService(db_session, internal_user.tenant_id, internal_user.sub)
        exception, _ = svc.create(
            ExceptionCreate(
                exception_type=ExceptionType.MISSING_ID,
                note="Test exception",
            ),
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/exceptions/{exception.exception_number}/assign",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exception_resolve_success(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exception resolve GUI route is deprecated."""
        from app.domain.services.exceptions import ExceptionCreate, ExceptionService
        from app.persistence.tapdb.orm_models.exceptions import ExceptionType

        # Create an exception
        svc = ExceptionService(db_session, internal_user.tenant_id, internal_user.sub)
        exception, _ = svc.create(
            ExceptionCreate(
                exception_type=ExceptionType.MISSING_ID,
                note="Test exception",
            ),
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/exceptions/{exception.exception_number}/resolve",
            data={"resolution_notes": "Resolved by test"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exception_escalate_success(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exception escalate GUI route is deprecated."""
        from app.domain.services.exceptions import ExceptionCreate, ExceptionService
        from app.persistence.tapdb.orm_models.exceptions import ExceptionType

        # Create an exception
        svc = ExceptionService(db_session, internal_user.tenant_id, internal_user.sub)
        exception, _ = svc.create(
            ExceptionCreate(
                exception_type=ExceptionType.MISSING_ID,
                note="Test exception",
            ),
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/exceptions/{exception.exception_number}/escalate",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exception_close_success(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exception close GUI route is deprecated."""
        from app.domain.services.exceptions import ExceptionCreate, ExceptionService
        from app.persistence.tapdb.orm_models.exceptions import ExceptionType

        # Create an exception
        svc = ExceptionService(db_session, internal_user.tenant_id, internal_user.sub)
        exception, _ = svc.create(
            ExceptionCreate(
                exception_type=ExceptionType.MISSING_ID,
                note="Test exception",
            ),
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/exceptions/{exception.exception_number}/close",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_exception_detail_not_found(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test exception detail GUI route remains deprecated for non-existent exceptions."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/exceptions/EXC-999999")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()


# =============================================================================
# 15. ORDER EDIT/SUBMIT TESTS
# =============================================================================


def _create_test_patient(
    db_session: Session,
    tenant_id,
    user_id,
    *,
    first_name: str = "Test",
    last_name: str = "Patient",
    date_of_birth=None,
    mrn: str | None = None,
):
    """Create a patient in TapDB and ensure a legacy shadow row for mixed order paths."""
    from datetime import date

    from app.domain.services.people import PatientCreate, PatientService

    dob = date_of_birth or date(1990, 1, 1)
    svc = PatientService(db_session, tenant_id)
    patient, revision = svc.create(
        PatientCreate(
            first_name=first_name,
            last_name=last_name,
            date_of_birth=dob,
            mrn=mrn,
        ),
        created_by=user_id,
    )

    return patient


def _create_test_clinician(
    db_session: Session,
    tenant_id,
    user_id,
    *,
    first_name: str = "Jane",
    last_name: str = "Doe",
    credentials: str | None = None,
    email: str | None = None,
):
    """Create a clinician and ensure a legacy shadow row for mixed order paths."""
    from app.domain.services.people import ClinicianCreate, ClinicianService

    svc = ClinicianService(db_session, tenant_id, user_id)
    clinician, revision = svc.create(
        ClinicianCreate(
            first_name=first_name,
            last_name=last_name,
            credentials=credentials,
            email=email,
        ),
        created_by=user_id,
    )

    return clinician


class TestOrderEditSubmitRoutes:
    """Tests for order edit and submit web routes."""

    @pytest.mark.db
    def test_order_edit_form_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test order edit form loads for draft order."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        # Create a patient first
        patient = _create_test_patient(db_session, external_user.tenant_id, external_user.sub_uuid)

        # Create a draft order
        svc = TrfService(db_session, external_user.tenant_id)
        order, _ = svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.get(f"/trfs/{order.order_number}/edit")

        assert response.status_code == status.HTTP_200_OK
        assert order.order_number in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_edit_form_not_found(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test order edit form returns 404 for non-existent order."""
        client = create_test_client(db_session, external_user)

        response = client.get("/trfs/ORD-999999/edit")

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_trf_submit_route_is_removed(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """The deprecated submit route is hard-removed."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        # Create a patient first
        patient = _create_test_patient(db_session, external_user.tenant_id, external_user.sub_uuid)

        # Create a draft order
        svc = TrfService(db_session, external_user.tenant_id)
        order, _ = svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.post(
            f"/trfs/{order.order_number}/submit",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_trf_submit_not_found(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Posting to the retired submit route returns 404."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            "/trfs/ORD-999999/submit",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_trf_status_update_route_replaces_submit(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """TRF status is updated through the status route, not submit."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        # Create a patient first
        patient = _create_test_patient(db_session, external_user.tenant_id, external_user.sub_uuid)

        svc = TrfService(db_session, external_user.tenant_id)
        order, _ = svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)
        response = client.post(
            f"/trfs/{order.order_number}/status",
            data={"status": "ACTIVE"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        _, revision = svc.get_by_number(order.order_number)
        assert revision.status == "ACTIVE"

        app.dependency_overrides.clear()


# =============================================================================
# 15b. ORDER STATE TRANSITION TESTS
# =============================================================================


class TestOrderTransitionAllRoute:
    """Tests for POST /trfs/{order_number}/transition-all."""

    def _create_order_with_assay_runs(self, db_session, tenant_id, user_id):
        """Helper: create an order with a test order and two assay runs in DRAFT state."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import (
            TestCreate,
            TrfCreate,
            TrfService,
        )

        patient = _create_test_patient(db_session, tenant_id, user_id)
        svc = TrfService(db_session, tenant_id)
        order, _ = svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS", "CNV"],
                    product_name="Whole Genome Sequencing",
                ),
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=user_id,
        )
        return order

    @pytest.mark.db
    def test_transition_all_draft_to_ordered(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Transition all assay runs from DRAFT to ORDERED (internal only)."""
        order = self._create_order_with_assay_runs(
            db_session, internal_user.tenant_id, internal_user.sub_uuid
        )
        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/trfs/{order.order_number}/transition-all",
            data={"next_state": "ORDERED"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        # Verify assay runs are now ORDERED
        from app.domain.services.fulfillment_runs import FulfillmentRunService

        ar_svc = FulfillmentRunService(db_session, internal_user.tenant_id)
        assay_runs = ar_svc.list_for_trf(order.euid)
        for _, ar_rev in assay_runs:
            assert ar_rev.status == "ORDERED"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_transition_all_skips_ineligible(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Transition-all skips assay runs that cannot make the transition (internal only)."""
        from app.domain.services.fulfillment_runs import FulfillmentRunService, TransitionData
        from app.persistence.tapdb.orm_models.assay_workflow import FulfillmentRunState

        order = self._create_order_with_assay_runs(
            db_session, internal_user.tenant_id, internal_user.sub_uuid
        )

        # Move only the first assay run to ORDERED
        ar_svc = FulfillmentRunService(db_session, internal_user.tenant_id)
        assay_runs = ar_svc.list_for_trf(order.euid)
        first_ar, _ = assay_runs[0]
        ar_svc.transition(
            first_ar.euid,
            TransitionData(target_state=FulfillmentRunState.ORDERED),
            transition_by=internal_user.sub_uuid,
        )
        db_session.flush()

        # Now transition-all to RECEIVED — only the ORDERED one can go there
        client = create_test_client(db_session, internal_user)
        response = client.post(
            f"/trfs/{order.order_number}/transition-all",
            data={"next_state": "RECEIVED"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        # Verify: one RECEIVED, one still DRAFT
        assay_runs = ar_svc.list_for_trf(order.euid)
        statuses = sorted(ar_rev.status for _, ar_rev in assay_runs)
        assert "DRAFT" in statuses
        assert "RECEIVED" in statuses

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_transition_all_not_found(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Transition-all on nonexistent order returns 404 (internal only)."""
        client = create_test_client(db_session, internal_user)

        response = client.post(
            "/trfs/ORD-NONEXIST/transition-all",
            data={"next_state": "ORDERED"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_transition_all_invalid_state(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Transition-all with invalid target state shows error flash (internal only)."""
        order = self._create_order_with_assay_runs(
            db_session, internal_user.tenant_id, internal_user.sub_uuid
        )
        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/trfs/{order.order_number}/transition-all",
            data={"next_state": "BOGUS_STATE"},
            follow_redirects=False,
        )

        # Should redirect back to order page (with error flash)
        assert response.status_code == status.HTTP_303_SEE_OTHER

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_transition_all_with_note(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Transition-all passes note to assay run transitions (internal only)."""
        order = self._create_order_with_assay_runs(
            db_session, internal_user.tenant_id, internal_user.sub_uuid
        )
        client = create_test_client(db_session, internal_user)

        response = client.post(
            f"/trfs/{order.order_number}/transition-all",
            data={"next_state": "ORDERED", "note": "Batch submit"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        # Verify note was recorded on revisions
        from app.domain.services.fulfillment_runs import FulfillmentRunService

        ar_svc = FulfillmentRunService(db_session, internal_user.tenant_id)
        assay_runs = ar_svc.list_for_trf(order.euid)
        for _, ar_rev in assay_runs:
            assert ar_rev.note == "Batch submit"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_detail_includes_transitions(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Order detail page includes available transitions for internal users."""
        order = self._create_order_with_assay_runs(
            db_session, internal_user.tenant_id, internal_user.sub_uuid
        )
        client = create_test_client(db_session, internal_user)

        response = client.get(f"/trfs/{order.order_number}")

        assert response.status_code == status.HTTP_200_OK
        # DRAFT assay runs should show ORDERED and CANCELLED as transitions
        assert "ORDERED" in response.text
        assert "CANCELLED" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_detail_hides_transitions_for_external(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Order detail page hides transition controls from external users."""
        order = self._create_order_with_assay_runs(
            db_session, external_user.tenant_id, external_user.sub_uuid
        )
        client = create_test_client(db_session, external_user)

        response = client.get(f"/trfs/{order.order_number}")

        assert response.status_code == status.HTTP_200_OK
        # External users should NOT see the transition panel
        assert "transition-all" not in response.text
        assert "Transition All" not in response.text

        app.dependency_overrides.clear()


class TestOrderStatusEditing:
    """Tests for order/test-order status editing on detail page."""

    def _create_order_with_test_order(self, db_session, tenant_id, user_id):
        """Create an order with one test-order and one assay."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import (
            TestCreate,
            TrfCreate,
            TrfService,
        )

        patient = _create_test_patient(db_session, tenant_id, user_id)
        svc = TrfService(db_session, tenant_id)
        order, _ = svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    product_name="Whole Genome Sequencing",
                ),
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=user_id,
        )
        return order

    @pytest.mark.db
    def test_order_detail_hides_submit_and_shows_tests_ordered(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Order detail reflects updated UI labels and controls."""
        order = self._create_order_with_test_order(
            db_session, external_user.tenant_id, external_user.sub_uuid
        )
        client = create_test_client(db_session, external_user)

        response = client.get(f"/trfs/{order.order_number}")

        assert response.status_code == status.HTTP_200_OK
        assert "Submit Order" not in response.text
        assert "Tests Ordered" in response.text
        assert "Change TRF Status" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_order_status_update_route(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """POST /trfs/{order_number}/status updates latest order revision."""
        from app.domain.services.trfs import TrfService

        order = self._create_order_with_test_order(
            db_session, external_user.tenant_id, external_user.sub_uuid
        )
        client = create_test_client(db_session, external_user)

        response = client.post(
            f"/trfs/{order.order_number}/status",
            data={"status": "ACTIVE"},
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        svc = TrfService(db_session, external_user.tenant_id)
        _, revision = svc.get_by_number(order.order_number)
        assert revision.status == "ACTIVE"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_test_order_status_update_route(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """POST /trfs/{order_number}/tests/{id}/status updates revision."""
        from app.domain.services.trfs import TestService

        order = self._create_order_with_test_order(
            db_session, external_user.tenant_id, external_user.sub_uuid
        )
        to_svc = TestService(db_session, external_user.tenant_id)
        test_orders = to_svc.list_for_trf(order.euid)
        test_order_id = test_orders[0][0].euid
        client = create_test_client(db_session, external_user)

        response = client.post(
            f"/trfs/tests/{test_order_id}/status",
            data={"status": "CANCELED"},
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_303_SEE_OTHER

        updated_test_orders = to_svc.list_for_trf(order.euid)
        updated_status = next(
            rev.status for to, rev, _assays in updated_test_orders if to.euid == test_order_id
        )
        assert updated_status == "CANCELED"

        app.dependency_overrides.clear()


# =============================================================================
# 16. USER ADMIN TESTS
# =============================================================================


class TestUserAdminRoutes:
    """Tests for user admin web routes."""

    @pytest.mark.db
    def test_admin_users_list_requires_admin(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test admin users list requires admin role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/admin/users")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_list_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin users list accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/users")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_create_form_loads(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin user create form loads."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/users/create")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_create_success(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test creating a new user."""
        client = create_test_client(db_session, admin_user)

        response = client.post(
            "/admin/users/create",
            data={
                "email": "newuser@test.com",
                "name": "New User",
                "tenant_id": str(admin_user.tenant_id),
                "cognito_group": "lsmc-customers",
            },
            follow_redirects=False,
        )

        # Should redirect on success
        assert response.status_code == status.HTTP_303_SEE_OTHER

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_edit_form_loads(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin user edit form loads."""
        from app.domain.services.users import UserCreate, UserService

        # Create a user first
        user_svc = UserService(db_session, admin_user.sub_uuid)
        user = user_svc.create(
            UserCreate(
                cognito_sub=f"test-sub-{uuid.uuid4()}",
                email="edituser@test.com",
                name="Edit User",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER"],
            )
        )

        client = create_test_client(db_session, admin_user)

        response = client.get(f"/admin/users/{user.euid}/edit")

        assert response.status_code == status.HTTP_200_OK
        assert "edituser@test.com" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_list_uses_euid_links(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Users list links to EUID edit paths and TapDB object view."""
        from app.domain.services.users import UserCreate, UserService

        user = UserService(db_session, admin_user.sub_uuid).create(
            UserCreate(
                cognito_sub=str(uuid.uuid4()),
                email="listlinks@test.com",
                name="List Links",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER"],
            )
        )

        client = create_test_client(db_session, admin_user)
        response = client.get("/admin/users")

        assert response.status_code == status.HTTP_200_OK
        assert f"/admin/users/{user.euid}/edit" in response.text
        assert f"/tapdb/object/{user.euid}" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_deactivate(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test deactivating a user."""
        from app.domain.services.users import UserCreate, UserService

        # Create a user first
        user_svc = UserService(db_session, admin_user.sub_uuid)
        user = user_svc.create(
            UserCreate(
                cognito_sub=f"test-sub-{uuid.uuid4()}",
                email="deactivate@test.com",
                name="Deactivate User",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER"],
            )
        )

        client = create_test_client(db_session, admin_user)

        response = client.post(
            f"/admin/users/{user.euid}/deactivate",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_users_activate(self, db_session: Session, admin_user: CurrentUser, setup_tenant):
        """Test activating a user."""
        from app.domain.services.users import UserCreate, UserService

        # Create and deactivate a user
        user_svc = UserService(db_session, admin_user.sub_uuid)
        user = user_svc.create(
            UserCreate(
                cognito_sub=f"test-sub-{uuid.uuid4()}",
                email="activate@test.com",
                name="Activate User",
                tenant_id=admin_user.tenant_id,
                roles=["EXTERNAL_USER"],
            )
        )
        user_svc.deactivate(user.euid)

        client = create_test_client(db_session, admin_user)

        response = client.post(
            f"/admin/users/{user.euid}/activate",
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        app.dependency_overrides.clear()


# =============================================================================
# 17. MANIFEST TESTS
# =============================================================================


class TestManifestRoutes:
    """Tests for manifest web routes."""

    @pytest.mark.db
    def test_manifests_list_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test manifests list requires internal user role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/manifests")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifests_list_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test manifests list GUI route is deprecated for internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/manifests")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifest_upload_page_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test manifest upload GUI route is deprecated."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/manifests/upload")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifest_detail_page_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test manifest detail GUI route is deprecated."""
        from app.domain.services.manifests import ManifestItem, ManifestService

        # Create a manifest first
        svc = ManifestService(db_session, internal_user.tenant_id, internal_user.sub)
        result = svc.create_manifest(
            items=[
                ManifestItem(
                    specimen_barcode="TEST-001",
                    specimen_type="Blood",
                )
            ],
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.get(f"/manifests/{result.manifest_number}")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifest_detail_not_found(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test manifest detail GUI route remains deprecated for non-existent manifests."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/manifests/MAN-999999")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()


# =============================================================================
# 18. RESULTS/RELEASE PACKAGE TESTS
# =============================================================================


class TestResultsRoutes:
    """Tests for results/release package web routes."""

    @pytest.mark.db
    def test_results_list_page_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test results list page loads."""
        client = create_test_client(db_session, external_user)

        response = client.get("/results")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_create_form_requires_internal(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test results create form requires internal user role."""
        client = create_test_client(db_session, external_user)

        response = client.get("/results/create")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_create_form_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test results create form loads for internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/results/create")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_create_success(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test creating a release package."""
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderPatientLink
        from app.domain.services.trfs import TestCreate, TrfCreate, TrfService

        # Create a patient first
        patient = _create_test_patient(db_session, internal_user.tenant_id, internal_user.sub_uuid)

        # Create an order first
        order_svc = TrfService(db_session, internal_user.tenant_id)
        order, _ = order_svc.create(
            TrfCreate(order_type="CLINICAL"),
            tests=[
                TestCreate(
                    product_code="WGS-001",
                    fulfillment_route_codes=["WGS"],
                    specimen_type_required="blood-whole",
                )
            ],
            patient_links=[
                OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)
            ],
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)

        response = client.post(
            "/results/create",
            data={
                "order_id": str(order.euid),
                "release_notes": "Test release",
                "action": "draft",
            },
            follow_redirects=False,
        )

        # Should redirect on success
        assert response.status_code == status.HTTP_303_SEE_OTHER

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_detail_page_loads(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test results detail page loads."""
        from app.domain.services.releases import ReleasePackageCreate, ReleaseService

        # Create a release package first
        svc = ReleaseService(db_session, external_user.tenant_id)
        package = svc.create_package(
            ReleasePackageCreate(release_notes="Test package"),
            created_by=external_user.sub_uuid,
        )

        client = create_test_client(db_session, external_user)

        response = client.get(f"/results/{package.package_number}")

        assert response.status_code == status.HTTP_200_OK
        assert package.package_number in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_results_detail_not_found(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test results detail returns 404 for non-existent package."""
        client = create_test_client(db_session, external_user)

        response = client.get("/results/REL-999999")

        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()


# =============================================================================
# 17. TESTKITS CRUD TESTS (Writable Roles)
# =============================================================================


class TestTestKitsCRUD:
    """Tests for test kits CRUD operations."""

    @pytest.mark.db
    def test_testkits_list_requires_write_access(
        self, db_session: Session, read_only_user: CurrentUser, setup_tenant
    ):
        """Test testkits list rejects read-only users."""
        client = create_test_client(db_session, read_only_user)

        response = client.get("/testkits")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_list_accessible_to_external_rw(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test testkits list is accessible to external read/write users."""
        client = create_test_client(db_session, external_user)

        response = client.get("/testkits")

        assert response.status_code == status.HTTP_200_OK
        assert "test kit" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_list_accessible_to_external_admin(
        self, db_session: Session, external_user_admin: CurrentUser, setup_tenant
    ):
        """Test testkits list is accessible to external admins."""
        client = create_test_client(db_session, external_user_admin)

        response = client.get("/testkits")

        assert response.status_code == status.HTTP_200_OK
        assert "test kit" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_list_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test testkits list accessible to internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/testkits")

        assert response.status_code == status.HTTP_200_OK
        assert "test kit" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_list_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test testkits list is accessible to internal admins."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/testkits")

        assert response.status_code == status.HTTP_200_OK
        assert "test kit" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_create_form_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test testkits create form loads."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/testkits/create")

        assert response.status_code == status.HTTP_200_OK
        assert "kit_barcode" in response.text.lower() or "barcode" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_create_form_populates_origin_site_options(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test test kit form shows origin site options for tenant sites."""
        from app.domain.services.orgs import SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Kit Origin Site",
                site_code="KIT-ORIG-01",
            ),
            created_by=internal_user.sub_uuid,
        )

        client = create_test_client(db_session, internal_user)
        response = client.get("/testkits/create")

        assert response.status_code == status.HTTP_200_OK
        assert site.euid in response.text
        assert "Kit Origin Site" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_create_form_shows_add_site_link_when_none_exist(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test test kit form renders origin-site selector from required default site."""
        client = create_test_client(db_session, admin_user)
        response = client.get("/testkits/create")

        assert response.status_code == status.HTTP_200_OK
        assert 'name="origin_site_id"' in response.text
        assert "-- Select Site --" in response.text
        assert "No active sites found for this organization." not in response.text
        assert f"/admin/organizations/{setup_tenant.euid}/sites/new" not in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_create_success(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test successful testkit creation redirects to detail page."""
        client = create_test_client(db_session, internal_user)

        response = client.post(
            "/testkits/create",
            data={
                "kit_barcode": "KIT-TEST-001",
                "kit_type": "COLLECTION",
                "expiration_date": "2027-01-01",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        location = response.headers.get("location", "")
        # Should redirect to /testkits/{euid}
        assert "/testkits/" in location
        # Should not redirect back to create form
        assert "create" not in location

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_testkits_create_missing_barcode(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test testkit creation fails without barcode."""
        client = create_test_client(db_session, internal_user)

        response = client.post(
            "/testkits/create",
            data={
                "kit_type": "COLLECTION",
            },
            follow_redirects=False,
        )

        # Should redirect back to form with error
        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert "/testkits/create" in response.headers.get("location", "")

        app.dependency_overrides.clear()


# =============================================================================
# 18. BIOSPECIMENS CRUD TESTS (Internal)
# =============================================================================


class TestBioSpecimensCRUD:
    """Tests for biospecimen routes after Bloom ownership cutover."""

    @pytest.mark.db
    def test_biospecimens_root_is_gone(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Biospecimen routes are removed and should return 404."""
        client = create_test_client(db_session, external_user)
        response = client.get("/biospecimens")
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_biospecimens_create_is_gone(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Create route is retired in Atlas and owned by Bloom integration."""
        client = create_test_client(db_session, internal_user)
        response = client.get("/biospecimens/create")
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_biospecimens_create_post_is_gone(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """POST create should be explicitly retired."""
        client = create_test_client(db_session, internal_user)
        response = client.post(
            "/biospecimens/create",
            data={"specimen_barcode": "SPEC-TEST-001", "specimen_type": "Blood"},
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_biospecimens_edit_is_gone(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Edit route is retired in Atlas and should return 404."""
        client = create_test_client(db_session, internal_user)
        fake_id = uuid.uuid4()
        response = client.get(f"/biospecimens/{fake_id}/edit")
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_biospecimens_update_is_gone(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """POST update to retired biospecimen route returns 404."""
        client = create_test_client(db_session, internal_user)
        fake_id = uuid.uuid4()
        response = client.post(
            f"/biospecimens/{fake_id}/edit",
            data={"status": "RECEIVED"},
            follow_redirects=False,
        )
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()


# =============================================================================
# 19. DOCUMENTS CRUD TESTS (Internal)
# =============================================================================


class TestDocumentsCRUD:
    """Tests for documents CRUD operations."""

    @pytest.mark.db
    def test_documents_list_accessible_to_external_user(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test documents list is accessible to external users (tenant-scoped)."""
        client = create_test_client(db_session, external_user)

        response = client.get("/documents")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_documents_list_accessible_to_internal(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test documents list accessible to internal users."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/documents")

        assert response.status_code == status.HTTP_200_OK
        assert "document" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_documents_upload_form_loads(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test documents upload form loads."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/documents/upload")

        assert response.status_code == status.HTTP_200_OK
        assert "upload" in response.text.lower()

        app.dependency_overrides.clear()


# =============================================================================
# 20. MANIFEST TEMPLATE CSV DOWNLOAD
# =============================================================================


class TestManifestTemplateDownload:
    """Tests for deprecated manifest template GUI route."""

    @pytest.mark.db
    def test_manifest_template_download(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test manifest template route returns 410 deprecation."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/manifests/template.csv")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_manifest_template_publicly_accessible(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test manifest template route is deprecated for non-internal users too."""
        client = create_test_client(db_session, external_user)

        response = client.get("/manifests/template.csv")

        assert response.status_code == status.HTTP_410_GONE

        app.dependency_overrides.clear()


# =============================================================================
# 21. ADMIN SITES TESTS
# =============================================================================


class TestAdminSites:
    """Tests for admin origin sites management."""

    @pytest.mark.db
    def test_admin_sites_requires_admin(
        self, db_session: Session, internal_user: CurrentUser, setup_tenant
    ):
        """Test admin sites requires admin role."""
        client = create_test_client(db_session, internal_user)

        response = client.get("/admin/sites")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_sites_accessible_to_admin(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin sites accessible to admin users."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/sites")

        assert response.status_code == status.HTTP_200_OK
        assert "site" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_sites_create_form_loads(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin sites create form loads."""
        client = create_test_client(db_session, admin_user)

        response = client.get("/admin/sites/create")

        assert response.status_code == status.HTTP_200_OK

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_sites_create_attaches_to_admin_tenant_organization(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin /admin/sites/create persists site under admin tenant org EUID."""
        from app.domain.services.orgs import SiteService

        client = create_test_client(db_session, admin_user)
        response = client.post(
            "/admin/sites/create",
            data={
                "name": "Admin Attached Site",
                "site_code": "ADM-ATT-01",
                "city": "Seattle",
                "state": "WA",
            },
            follow_redirects=False,
        )

        assert response.status_code in [status.HTTP_302_FOUND, status.HTTP_303_SEE_OTHER]
        assert "/admin/sites" in response.headers.get("location", "")

        sites = SiteService(db_session).list_by_organization(setup_tenant.euid, active_only=False)
        created_site = next(
            (
                site
                for site in sites
                if site.revisions and site.revisions[-1].name == "Admin Attached Site"
            ),
            None,
        )
        assert created_site is not None

        site_instance = (
            db_session.query(generic_instance)
            .filter(generic_instance.euid == created_site.euid)
            .one()
        )
        site_props = (site_instance.json_addl or {}).get("properties", {})
        assert site_props.get("organization_id") == setup_tenant.euid
        assert str(site_props.get("organization_id")) != str(setup_tenant.id)

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_sites_list_shows_sites_and_edit_actions(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin sites page renders sites table rows with organization and edit actions."""
        from app.domain.services.orgs import SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Listed Admin Site",
                site_code="LIST-ADM-01",
            ),
            created_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.get("/admin/sites")

        assert response.status_code == status.HTTP_200_OK
        assert "Listed Admin Site" in response.text
        assert f"/admin/organizations/{setup_tenant.euid}" in response.text
        assert f"/admin/sites/{site.euid}/edit" in response.text
        assert "Edit Site" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_organization_sites_link_to_site_detail(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Organization detail renders site EUID and detail link."""
        from app.domain.services.orgs import SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Org Linked Site",
                site_code="OLS-01",
                address={"city": "San Diego", "state": "CA"},
            ),
            created_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/organizations/{setup_tenant.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert f"/admin/organizations/{setup_tenant.euid}/sites/new" in response.text
        assert f"/admin/sites/{site.euid}" in response.text
        assert f"/admin/sites/{site.euid}/edit" in response.text
        assert f"/tapdb/object/{site.euid}" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_site_detail_page_loads(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin site detail route renders for site EUID."""
        from app.domain.services.orgs import SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Detail Site",
                site_code="DS-01",
                address={"city": "Portland", "state": "OR"},
            ),
            created_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/sites/{site.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert site.euid in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_site_bloom_detail_shows_validate_and_required_fields(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin site Bloom card renders validate action and required field descriptions."""
        from app.domain.services.orgs import SiteCreate, SiteService

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Bloom Detail Site",
                site_code="BDS-01",
            ),
            created_by=admin_user.sub_uuid,
        )

        client = create_test_client(db_session, admin_user)
        response = client.get(f"/admin/sites/{site.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "Validate Credentials" in response.text
        assert "bloom_base_url" in response.text
        assert "bloom_api_key_secret_ref" in response.text
        assert "bloom_webhook_secret_ref" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_site_bloom_validate_action_does_not_persist(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant, monkeypatch
    ):
        """Validate action checks submitted site credentials without saving them."""
        from app.domain.services.external_objects import (
            SiteBloomConfigService,
            SiteBloomConfigUpsert,
        )
        from app.domain.services.orgs import SiteCreate, SiteService
        from app.web.routes import pages as pages_routes

        site = SiteService(db_session).create(
            SiteCreate(
                organization_id=setup_tenant.euid,
                name="Validate Site",
                site_code="VLD-01",
            ),
            created_by=admin_user.sub_uuid,
        )

        site_cfg_svc = SiteBloomConfigService(db_session)
        site_cfg_svc.upsert(
            site.euid,
            setup_tenant.id,
            SiteBloomConfigUpsert(
                enabled=True,
                bloom_base_url="https://saved-site-bloom.local",
                bloom_api_key_secret_ref="env:SAVED_SITE_BLOOM_API_KEY",
                bloom_webhook_secret_ref="env:SAVED_SITE_BLOOM_WEBHOOK",
            ),
            actor_id=admin_user.sub_uuid,
        )

        captured: dict[str, str] = {}

        def _fake_validate(*, bloom_base_url: str, bloom_api_key_secret_ref: str) -> None:
            captured["bloom_base_url"] = bloom_base_url
            captured["bloom_api_key_secret_ref"] = bloom_api_key_secret_ref

        monkeypatch.setattr(pages_routes, "_validate_bloom_credentials", _fake_validate)

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/sites/{site.euid}/integrations/bloom",
            data={
                "action": "validate",
                "enabled": "true",
                "bloom_base_url": "https://validate-site-bloom.local",
                "bloom_api_key_secret_ref": "env:VALIDATE_SITE_BLOOM_API_KEY",
                "bloom_webhook_secret_ref": "env:VALIDATE_SITE_BLOOM_WEBHOOK",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER
        assert response.headers.get("location", "") == f"/admin/sites/{site.euid}"
        assert captured == {
            "bloom_base_url": "https://validate-site-bloom.local",
            "bloom_api_key_secret_ref": "env:VALIDATE_SITE_BLOOM_API_KEY",
        }

        saved_cfg = site_cfg_svc.get(site.euid)
        assert saved_cfg is not None
        assert saved_cfg.bloom_base_url == "https://saved-site-bloom.local"
        assert saved_cfg.bloom_api_key_secret_ref == "env:SAVED_SITE_BLOOM_API_KEY"
        assert saved_cfg.bloom_webhook_secret_ref == "env:SAVED_SITE_BLOOM_WEBHOOK"

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_site_edit_rejects_deactivating_last_active_site(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Admin cannot deactivate the only active site for an organization."""
        from app.domain.services.orgs import SiteService

        site_svc = SiteService(db_session)
        existing_sites = site_svc.list_by_organization(setup_tenant.euid, active_only=True)
        assert existing_sites
        site = existing_sites[0]

        client = create_test_client(db_session, admin_user)
        response = client.post(
            f"/admin/sites/{site.euid}/edit",
            data={
                "name": "Only Active Site",
                "site_code": "ONLY-01",
                "is_active": "false",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_200_OK

        refreshed_site = site_svc.get_by_id(site.euid)
        assert refreshed_site is not None
        assert refreshed_site.revisions
        assert refreshed_site.revisions[-1].is_active is True

        app.dependency_overrides.clear()


# =============================================================================
# CLINICIAN & ORGANIZATION TENANT ISOLATION TESTS
# =============================================================================


class TestClinicianTenantIsolation:
    """Tests for clinician tenant isolation - users cannot access other tenants' clinicians."""

    @pytest.fixture
    def tenant_a_clinician(
        self, db_session: Session, setup_tenant, external_user: CurrentUser
    ) -> Clinician:
        """Create a clinician in tenant A."""
        return _create_test_clinician(
            db_session,
            external_user.tenant_id,
            external_user.sub_uuid,
            first_name="Tenant A",
            last_name="Clinician",
            credentials="MD",
        )

    @pytest.fixture
    def tenant_b_clinician(
        self, db_session: Session, setup_other_tenant, other_tenant_user: CurrentUser
    ) -> Clinician:
        """Create a clinician in tenant B."""
        return _create_test_clinician(
            db_session,
            other_tenant_user.tenant_id,
            other_tenant_user.sub_uuid,
            first_name="Tenant B",
            last_name="Clinician",
            credentials="MD, PhD",
        )

    @pytest.mark.db
    def test_external_user_cannot_see_other_tenant_clinician(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        setup_other_tenant,
        tenant_b_clinician,
    ):
        """Test external user cannot access clinician from another tenant."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/clinicians/{tenant_b_clinician.euid}")

        # Should return 404 (not found in user's tenant scope)
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_user_can_see_own_tenant_clinician(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        tenant_a_clinician,
    ):
        """Test user can access clinician from their own tenant."""
        client = create_test_client(db_session, external_user)

        response = client.get(f"/clinicians/{tenant_a_clinician.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "Tenant A" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_clinician_list_only_shows_own_tenant(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        setup_other_tenant,
        tenant_a_clinician,
        tenant_b_clinician,
    ):
        """Test clinician list only shows clinicians from user's tenant."""
        client = create_test_client(db_session, external_user)

        response = client.get("/clinicians")

        assert response.status_code == status.HTTP_200_OK
        assert "Tenant A" in response.text
        assert "Tenant B" not in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_cannot_create_user_under_other_tenant_clinician(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        setup_other_tenant,
        tenant_b_clinician,
    ):
        """Test cannot create user under a clinician from another tenant."""
        client = create_test_client(db_session, external_user)

        response = client.post(
            f"/api/clinicians/{tenant_b_clinician.euid}/users",
            json={
                "email": "hacker@evil.com",
                "roles": ["EXTERNAL_USER"],
            },
        )

        # Should return 404 (clinician not found in user's tenant)
        assert response.status_code == status.HTTP_404_NOT_FOUND

        app.dependency_overrides.clear()


class TestOrganizationTenantIsolation:
    """Tests for organization tenant isolation - external users can only access their own org."""

    @pytest.mark.db
    def test_external_user_cannot_access_other_organization(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        setup_other_tenant,
        other_tenant_id: uuid.UUID,
    ):
        """Test external user cannot access organization detail for another tenant."""
        client = create_test_client(db_session, external_user)

        # External users use /my-organization, not /admin/organizations/{id}
        # But let's test the admin endpoint is forbidden
        response = client.get(f"/admin/organizations/{setup_other_tenant.euid}")

        # External users should get 403 on admin routes
        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_external_user_can_only_see_own_organization_via_my_org(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
    ):
        """Test external user can only access their own organization via /my-organization."""
        client = create_test_client(db_session, external_user)

        response = client.get("/my-organization")

        assert response.status_code == status.HTTP_200_OK
        # Verify it's their organization (Test Tenant)
        assert "Test Tenant" in response.text or "organization" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_can_view_any_organization(
        self,
        db_session: Session,
        admin_user: CurrentUser,
        setup_tenant,
        setup_other_tenant,
        other_tenant_id: uuid.UUID,
    ):
        """Test admin can view any organization."""
        client = create_test_client(db_session, admin_user)

        response = client.get(f"/admin/organizations/{setup_other_tenant.euid}")

        assert response.status_code == status.HTTP_200_OK
        assert "organization" in response.text.lower()

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_external_user_cannot_list_all_organizations(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
    ):
        """Test external user cannot access organization list (admin only)."""
        client = create_test_client(db_session, external_user)

        response = client.get("/admin/organizations")

        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()


class TestClinicianSearchFilter:
    """Tests for clinician search and filter functionality."""

    @pytest.fixture
    def multiple_clinicians(
        self, db_session: Session, setup_tenant, external_user: CurrentUser
    ) -> list[Clinician]:
        """Create multiple clinicians for search testing."""
        clinicians = []
        names = [
            ("John", "Smith", "MD"),
            ("Jane", "Doe", "PhD"),
            ("Robert", "Johnson", "MD, PhD"),
        ]

        for first_name, last_name, credentials in names:
            clinician = _create_test_clinician(
                db_session,
                external_user.tenant_id,
                external_user.sub_uuid,
                first_name=first_name,
                last_name=last_name,
                credentials=credentials,
            )
            clinicians.append(clinician)
        return clinicians

    @pytest.mark.db
    def test_clinician_search_by_name(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        multiple_clinicians,
    ):
        """Test searching clinicians by name."""
        client = create_test_client(db_session, external_user)

        response = client.get("/clinicians?search=Smith")

        assert response.status_code == status.HTTP_200_OK
        assert "John" in response.text
        assert "Smith" in response.text
        # Should not show unrelated clinicians
        assert "Jane" not in response.text or "Doe" not in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_clinician_search_no_results(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        multiple_clinicians,
    ):
        """Test searching clinicians with no matches."""
        client = create_test_client(db_session, external_user)

        response = client.get("/clinicians?search=NonExistent")

        assert response.status_code == status.HTTP_200_OK
        # Should show empty state or no results message
        assert "No clinicians" in response.text or "0" in response.text

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_clinician_search_case_insensitive(
        self,
        db_session: Session,
        external_user: CurrentUser,
        setup_tenant,
        multiple_clinicians,
    ):
        """Test clinician search is case-insensitive."""
        client = create_test_client(db_session, external_user)

        response = client.get("/clinicians?search=SMITH")

        assert response.status_code == status.HTTP_200_OK
        assert "John" in response.text

        app.dependency_overrides.clear()


class TestIntegrationWorkflow:
    """Integration tests for full workflows."""

    @pytest.mark.db
    def test_admin_create_site_then_create_user(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test admin workflow: create site, then create user."""
        client = create_test_client(db_session, admin_user)

        # Step 1: Create a site
        response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/sites/new",
            data={
                "name": "Integration Test Site",
                "site_code": "ITS-001",
                "address_line1": "123 Test St",
                "city": "Test City",
                "state": "CA",
                "postal_code": "90210",
            },
            follow_redirects=False,
        )

        # Should redirect after successful creation
        assert response.status_code in [status.HTTP_302_FOUND, status.HTTP_303_SEE_OTHER]

        # Step 2: Create a user in the organization
        response = client.post(
            f"/api/organizations/{setup_tenant.euid}/users",
            json={
                "email": "integration@acme.com",
                "name": "Integration User",
                "roles": ["EXTERNAL_USER"],
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["email"] == "integration@acme.com"

        # Verify user was created with correct tenant
        from app.domain.services.users import UserService

        user = UserService(db_session).get_by_email("integration@acme.com")
        assert user is not None
        assert user.tenant_id == admin_user.tenant_id

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_creates_assay_and_site_in_default_org(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test default-org workflow: create assay and add site."""
        from app.domain.services.orgs import SiteService
        from app.domain.services.test_definitions import TestDefinitionService

        client = create_test_client(db_session, admin_user)

        assay_response = client.post(
            "/admin/test-definitions/create",
            data={
                "code": "INT-DEF-ASY-1",
                "name": "Default Org Assay",
                "specimen_types": "blood, saliva, BLOOD",
            },
            follow_redirects=False,
        )
        assert assay_response.status_code == status.HTTP_303_SEE_OTHER

        assay = TestDefinitionService(db_session).get_by_code("INT-DEF-ASY-1")
        assert assay is not None
        assert assay.specimen_types == ["BLOOD", "SALIVA"]

        site_response = client.post(
            f"/admin/organizations/{setup_tenant.euid}/sites/new",
            data={
                "name": "Default Org Integration Site",
                "site_code": "DOI-001",
                "address_line1": "100 Default St",
                "city": "Los Angeles",
                "state": "CA",
                "postal_code": "90001",
            },
            follow_redirects=False,
        )
        assert site_response.status_code in [status.HTTP_302_FOUND, status.HTTP_303_SEE_OTHER]

        sites = SiteService(db_session).list_by_organization(setup_tenant.euid, active_only=False)
        assert any(
            site.revisions and site.revisions[-1].name == "Default Org Integration Site"
            for site in sites
        )

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_admin_creates_two_users_in_default_org(
        self, db_session: Session, admin_user: CurrentUser, setup_tenant
    ):
        """Test default-org workflow: create two users for the organization."""
        from app.domain.services.users import UserService

        client = create_test_client(db_session, admin_user)
        emails = [
            "default-org-user-1@acme.com",
            "default-org-user-2@acme.com",
        ]

        for idx, email in enumerate(emails, start=1):
            response = client.post(
                f"/api/organizations/{setup_tenant.euid}/users",
                json={
                    "email": email,
                    "name": f"Default Org User {idx}",
                    "roles": ["EXTERNAL_USER"],
                },
            )
            assert response.status_code == status.HTTP_201_CREATED

        user_svc = UserService(db_session)
        for email in emails:
            user = user_svc.get_by_email(email)
            assert user is not None
            assert user.tenant_id == admin_user.tenant_id

        users = user_svc.list_users(tenant_id=admin_user.tenant_id, limit=200)
        matched = [user for user in users if user.email in emails]
        assert len(matched) == 2

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_create_two_clinicians_in_default_org(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test default-org workflow: create two clinicians/providers."""
        from app.domain.services.people import ClinicianService

        client = create_test_client(db_session, external_user)
        payloads = [
            {
                "first_name": "Physical",
                "last_name": "One",
                "credentials": "MD",
                "npi": "1111111111",
                "email": "physical.one@clinic.org",
            },
            {
                "first_name": "Physical",
                "last_name": "Two",
                "credentials": "DO",
                "npi": "2222222222",
                "email": "physical.two@clinic.org",
            },
        ]

        for payload in payloads:
            response = client.post("/clinicians/new", data=payload, follow_redirects=False)
            assert response.status_code == status.HTTP_303_SEE_OTHER

        clinician_svc = ClinicianService(
            db_session, external_user.tenant_id, external_user.sub_uuid
        )
        clinicians = clinician_svc.list_clinicians(limit=100, active_only=False)
        created_names = {(rev.first_name, rev.last_name) for _clinician, rev in clinicians}
        assert ("Physical", "One") in created_names
        assert ("Physical", "Two") in created_names

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_external_user_self_service_workflow(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test external user self-service workflow: view org, create site, view users."""
        client = create_test_client(db_session, external_user)

        # Step 1: View my organization
        response = client.get("/my-organization")
        assert response.status_code == status.HTTP_200_OK

        # Step 2: View sites list
        response = client.get("/my-organization/sites")
        assert response.status_code == status.HTTP_200_OK

        # Step 3: Site creation requires EXTERNAL_USER_ADMIN — regular user blocked
        response = client.post(
            "/my-organization/sites/new",
            data={
                "name": "Self Service Site",
                "site_code": "SSS-001",
                "address_line1": "456 Self St",
                "city": "Self City",
                "state": "NY",
                "postal_code": "10001",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

        # Step 4: View users list (read-only for regular external users)
        response = client.get("/my-organization/users")
        assert response.status_code == status.HTTP_200_OK

        # Step 5: User creation requires EXTERNAL_USER_ADMIN — regular user blocked
        response = client.get("/my-organization/users/new")
        assert response.status_code == status.HTTP_403_FORBIDDEN

        app.dependency_overrides.clear()

    @pytest.mark.db
    def test_clinician_user_management_workflow(
        self, db_session: Session, external_user: CurrentUser, setup_tenant
    ):
        """Test workflow: create clinician, then create user under clinician."""
        client = create_test_client(db_session, external_user)

        # Step 1: Create a clinician
        response = client.post(
            "/clinicians/new",
            data={
                "first_name": "Workflow",
                "last_name": "Doctor",
                "credentials": "MD",
                "npi": "9876543210",
                "email": "workflow@hospital.org",
            },
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_303_SEE_OTHER

        # Step 2: Find the created clinician
        from app.domain.services.people import ClinicianService

        clinician_svc = ClinicianService(
            db_session, external_user.tenant_id, external_user.sub_uuid
        )
        clinicians = clinician_svc.list_clinicians(limit=10, active_only=False)
        assert clinicians
        clinician, _ = clinicians[0]

        # Step 3: View clinician detail
        response = client.get(f"/clinicians/{clinician.euid}")
        assert response.status_code == status.HTTP_200_OK
        assert "Workflow" in response.text

        # Step 4: Create user under clinician via API
        response = client.post(
            f"/api/clinicians/{clinician.euid}/users",
            json={
                "email": "staff@workflow-clinic.com",
                "name": "Clinic Staff",
                "roles": ["EXTERNAL_USER"],
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["tenant_id"] == str(external_user.tenant_id)

        app.dependency_overrides.clear()


# =============================================================================
# HELPER FUNCTIONS FOR CLEANUP
# =============================================================================


def cleanup_overrides():
    """Clean up dependency overrides after test."""
    app.dependency_overrides.clear()
