from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest
from sqlalchemy.orm import Session

from app.domain.enums import OrderPatientRole
from app.domain.services.external_objects import (
    ExternalObjectRelationCreate,
    ExternalObjectService,
    ExternalObjectUpsert,
)
from app.domain.services.graph_viewer import GraphViewerService
from app.domain.services.order_relationships import OrderPatientLink
from app.domain.services.orgs import SiteService
from app.domain.services.people import PatientCreate, PatientService
from app.domain.services.shipments import TestKitCreate as AtlasTestKitCreate
from app.domain.services.shipments import TestKitService as AtlasTestKitService
from app.domain.services.testkit_trf_links import (
    TestKitTrfLinkService as AtlasTestKitTrfLinkService,
)
from app.domain.services.trfs import TestCreate as AtlasTestCreate
from app.domain.services.trfs import TestService as AtlasTestService
from app.domain.services.trfs import TrfCreate, TrfService
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def actor_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def tenant_org(db_session: Session, tenant_id: uuid.UUID):
    return ensure_tapdb_org(
        db_session,
        tenant_id,
        name="graph-org",
        display_name="Graph Org",
        site_name="Graph Site",
        site_code="GRF",
    )


@pytest.fixture
def site(tenant_org, db_session: Session):
    return SiteService(db_session).list_by_organization(tenant_org.euid)[0]


def test_graph_viewer_uses_exb_bridge_and_canonical_containment(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
    monkeypatch,
):
    patient = PatientService(db_session, tenant_id).create(
        PatientCreate(
            first_name="Jane",
            last_name="Doe",
            date_of_birth=None,
            mrn="MRN-GRAPH-1",
            site_id=site.euid,
        ),
        created_by=actor_id,
    )[0]
    trf, _trf_revision = TrfService(db_session, tenant_id).create(
        TrfCreate(
            site_id=site.euid,
            clinical_notes="graph test",
        ),
        tests=[
            AtlasTestCreate(
                product_code="WGS-short-read",
                product_name="ILMN short read",
                fulfillment_route_codes=["WGS-short-read"],
                specimen_type_required="whole_blood",
                site_id=site.euid,
            )
        ],
        patient_links=[OrderPatientLink(patient_euid=patient.euid, role=OrderPatientRole.PROBAND)],
        created_by=actor_id,
    )
    test = AtlasTestService(db_session, tenant_id).list_for_trf(trf.euid)[0][0]

    testkit = AtlasTestKitService(db_session, tenant_id).create(
        AtlasTestKitCreate(
            kit_barcode="KIT-GRAPH-001",
            kit_type="COLLECTION",
            origin_site_id=site.euid,
        ),
        created_by=actor_id,
    )
    AtlasTestKitTrfLinkService(db_session, tenant_id).link_trf(
        testkit_euid=testkit.euid,
        trf_euid=trf.euid,
        created_by=actor_id,
    )

    external_objects = ExternalObjectService(db_session, tenant_id)
    external_object = external_objects.upsert_external_object(
        ExternalObjectUpsert(
            provider="bloom",
            object_type="container",
            external_euid="CX-PY",
            metadata={"site_id": site.euid},
        ),
        actor_id=actor_id,
    )
    AtlasTestKitService(db_session, tenant_id).add_item(
        testkit.euid,
        "ExternalObject",
        external_object.euid,
        created_by=actor_id,
    )
    external_objects.create_relation(
        ExternalObjectRelationCreate(
            external_object_id=external_object.euid,
            relation_type="belongs_to_testkit",
            local_entity_type="TestKit",
            local_entity_id=testkit.euid,
            metadata={"site_id": site.euid},
        ),
        actor_id=actor_id,
    )

    monkeypatch.setattr(
        "app.domain.services.graph_viewer.BloomConfigResolverService",
        lambda _db: SimpleNamespace(
            get_effective=lambda **_kwargs: SimpleNamespace(
                bloom_base_url="https://localhost:8912",
                bloom_api_key_secret_ref="plain:demo-token",
            )
        ),
    )
    monkeypatch.setattr(
        "app.domain.services.graph_viewer.resolve_secret_value", lambda _ref: "demo-token"
    )

    service = GraphViewerService(db_session, tenant_id, can_cross_tenant=False)
    graph = service.get_graph_data(
        start_euid=test.euid,
        depth=4,
        requested_tenant_id=None,
    )

    edge_data = [dict(edge.get("data") or {}) for edge in graph["elements"]["edges"]]
    test_to_trf = [
        edge
        for edge in edge_data
        if edge.get("source") == test.euid and edge.get("target") == trf.euid
    ]
    test_to_testkit = [
        edge
        for edge in edge_data
        if edge.get("source") == test.euid and edge.get("target") == testkit.euid
    ]
    trf_to_testkit = [
        edge
        for edge in edge_data
        if edge.get("source") == trf.euid and edge.get("target") == testkit.euid
    ]

    assert [edge.get("relationship_type") for edge in test_to_trf] == ["contained_in"]
    assert [edge.get("relationship_type") for edge in test_to_testkit] == ["contained_in"]
    assert trf_to_testkit == []

    node_by_id = {node["data"]["id"]: node["data"] for node in graph["elements"]["nodes"]}
    assert node_by_id[testkit.euid]["name"] == f"{testkit.euid} | KIT-GRAPH-001"
    assert node_by_id[test.euid]["href"] == f"/trfs/tests/{test.euid}"
    assert node_by_id[patient.euid]["href"] == f"/patients/{patient.euid}"
    assert node_by_id[external_object.euid]["name"] == f"{external_object.euid} | bloom | CX-PY"
    assert node_by_id[external_object.euid]["href"] == f"/tapdb/object/{external_object.euid}"
    assert node_by_id[external_object.euid]["system"] == "atlas"

    test_detail = service.get_object_detail(euid=test.euid, requested_tenant_id=None)
    assert test_detail["external_refs"] == []

    exb_detail = service.get_object_detail(euid=external_object.euid, requested_tenant_id=None)
    assert exb_detail["external_refs"][0]["external_object_id"] == external_object.euid
    assert exb_detail["external_refs"][0]["system"] == "bloom"
    assert exb_detail["external_refs"][0]["root_euid"] == "CX-PY"

    class FakeBloomClient:
        def get_graph_data(self, *, start_euid: str, depth: int) -> dict[str, object]:
            assert start_euid == "CX-PY"
            assert depth in {3, 4}
            return {
                "elements": {
                    "nodes": [
                        {
                            "data": {
                                "id": "CX-PY",
                                "euid": "CX-PY",
                                "name": "tube",
                                "type": "container",
                                "obj_type": "tube",
                            }
                        }
                    ],
                    "edges": [],
                }
            }

    monkeypatch.setattr(service, "_build_bloom_client", lambda _ref: FakeBloomClient())
    merged = service.get_external_graph(
        source_euid=external_object.euid,
        ref_index=0,
        depth=3,
        requested_tenant_id=None,
    )

    bridge_edges = [
        dict(edge.get("data") or {})
        for edge in merged["elements"]["edges"]
        if (edge.get("data") or {}).get("is_external_bridge")
    ]
    assert len(bridge_edges) == 1
    assert bridge_edges[0]["source"] == external_object.euid
    assert bridge_edges[0]["target"] == f"ext::bloom::{site.euid}::CX-PY"
    external_node = merged["elements"]["nodes"][0]["data"]
    assert external_node["href"] == "https://localhost:8912/euid_details?euid=CX-PY"
    assert external_node["system"] == "bloom"

    story = service.get_graph_data(
        start_euid=test.euid,
        depth=4,
        requested_tenant_id=None,
        projection="story",
    )
    story_edge_keys = {
        (
            edge["data"]["source"],
            edge["data"]["target"],
            edge["data"]["relationship_type"],
        )
        for edge in story["elements"]["edges"]
    }
    story_node_ids = {node["data"]["id"] for node in story["elements"]["nodes"]}

    assert story["meta"]["projection"] == "story"
    assert (trf.euid, test.euid, "contains_test") in story_edge_keys
    assert (patient.euid, test.euid, "order_patient") in story_edge_keys
    assert (test.euid, testkit.euid, "fulfilled_by_testkit") not in story_edge_keys
    assert (
        external_object.euid,
        f"ext::bloom::{site.euid}::CX-PY",
        "external_reference",
    ) not in story_edge_keys
    assert f"ext::bloom::{site.euid}::CX-PY" not in story_node_ids


def test_story_projection_adds_parallel_bloom_container_and_content_lineage():
    payload = {
        "elements": {
            "nodes": [
                {"data": {"id": "RGX-18", "subtype": "organization", "system": "atlas"}},
                {"data": {"id": "STX-2H", "subtype": "site", "system": "atlas"}},
                {"data": {"id": "CNP-1H", "subtype": "clinician", "system": "atlas"}},
                {"data": {"id": "PAT-1T", "subtype": "patient", "system": "atlas"}},
                {"data": {"id": "TRF-14", "subtype": "trf", "system": "atlas"}},
                {"data": {"id": "TST-1Q", "subtype": "test", "system": "atlas"}},
                {"data": {"id": "SHP-1C", "subtype": "shipment", "system": "atlas"}},
                {"data": {"id": "TKT-13", "subtype": "testkit", "system": "atlas"}},
                {"data": {"id": "CEV-1V", "subtype": "collection-event", "system": "atlas"}},
                {"data": {"id": "EXB-1A", "subtype": "external-object", "system": "atlas"}},
                {"data": {"id": "EXB-28", "subtype": "external-object", "system": "atlas"}},
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-19",
                        "system": "bloom",
                        "name": "Tube CX-19",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-1R",
                        "system": "bloom",
                        "name": "Specimen MX-1R",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-2P",
                        "system": "bloom",
                        "name": "Extraction MX-2P",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-27",
                        "system": "bloom",
                        "name": "Plate CX-27",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CWX-1W",
                        "system": "bloom",
                        "name": "A1 well",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::DAT-G4",
                        "system": "bloom",
                        "name": "Library DAT-G4",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-2S",
                        "system": "bloom",
                        "name": "Seq lib MX-2S",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-31",
                        "system": "bloom",
                        "name": "Library plate CX-31",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CWX-2A",
                        "system": "bloom",
                        "name": "B1 library well",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-3M",
                        "system": "bloom",
                        "name": "Pool MX-3M",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-35",
                        "system": "bloom",
                        "name": "Pool tube CX-35",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::GX-G1",
                        "system": "bloom",
                        "name": "Run GX-G1",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::GX-JX",
                        "system": "bloom",
                        "name": "FASTQ R1",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::GX-KV",
                        "system": "bloom",
                        "name": "FASTQ R2",
                    }
                },
            ],
            "edges": [
                {
                    "data": {
                        "id": "e1",
                        "source": "RGX-18",
                        "target": "STX-2H",
                        "relationship_type": "contains_site",
                    }
                },
                {
                    "data": {
                        "id": "e2",
                        "source": "STX-2H",
                        "target": "TRF-14",
                        "relationship_type": "ordering_site",
                    }
                },
                {
                    "data": {
                        "id": "e3",
                        "source": "CNP-1H",
                        "target": "TRF-14",
                        "relationship_type": "ordering_clinician",
                    }
                },
                {
                    "data": {
                        "id": "e4",
                        "source": "PAT-1T",
                        "target": "TST-1Q",
                        "relationship_type": "order_patient",
                    }
                },
                {
                    "data": {
                        "id": "e5",
                        "source": "TST-1Q",
                        "target": "TRF-14",
                        "relationship_type": "contained_in",
                    }
                },
                {
                    "data": {
                        "id": "e6",
                        "source": "TST-1Q",
                        "target": "TKT-13",
                        "relationship_type": "contained_in",
                    }
                },
                {
                    "data": {
                        "id": "e7",
                        "source": "TKT-13",
                        "target": "SHP-1C",
                        "relationship_type": "contained_in",
                    }
                },
                {
                    "data": {
                        "id": "e8",
                        "source": "TST-1Q",
                        "target": "EXB-1A",
                        "relationship_type": "external_relation:belongs_to_test",
                    }
                },
                {
                    "data": {
                        "id": "e9",
                        "source": "EXB-28",
                        "target": "EXB-1A",
                        "relationship_type": "external_relation:contained_in",
                    }
                },
                {
                    "data": {
                        "id": "e10",
                        "source": "CEV-1V",
                        "target": "EXB-28",
                        "relationship_type": "external_relation:belongs_to_collection_event",
                    }
                },
                {
                    "data": {
                        "id": "e11",
                        "source": "EXB-1A",
                        "target": "ext::bloom::STX-2H::CX-19",
                        "relationship_type": "external_reference",
                    }
                },
                {
                    "data": {
                        "id": "e12",
                        "source": "EXB-28",
                        "target": "ext::bloom::STX-2H::MX-1R",
                        "relationship_type": "external_reference",
                    }
                },
                {
                    "data": {
                        "id": "e13",
                        "source": "ext::bloom::STX-2H::MX-1R",
                        "target": "ext::bloom::STX-2H::CX-19",
                        "relationship_type": "contains",
                    }
                },
                {
                    "data": {
                        "id": "e14",
                        "source": "ext::bloom::STX-2H::MX-1R",
                        "target": "ext::bloom::STX-2H::MX-2P",
                        "relationship_type": "beta_extraction_output",
                    }
                },
                {
                    "data": {
                        "id": "e15",
                        "source": "ext::bloom::STX-2H::MX-2P",
                        "target": "ext::bloom::STX-2H::CWX-1W",
                        "relationship_type": "contains",
                    }
                },
                {
                    "data": {
                        "id": "e16",
                        "source": "ext::bloom::STX-2H::CX-27",
                        "target": "ext::bloom::STX-2H::CWX-1W",
                        "relationship_type": "generic",
                    }
                },
                {
                    "data": {
                        "id": "e17",
                        "source": "ext::bloom::STX-2H::MX-2P",
                        "target": "ext::bloom::STX-2H::DAT-G4",
                        "relationship_type": "beta_library_prep_output",
                    }
                },
                {
                    "data": {
                        "id": "e18",
                        "source": "ext::bloom::STX-2H::MX-2P",
                        "target": "ext::bloom::STX-2H::MX-2S",
                        "relationship_type": "beta_library_material_output",
                    }
                },
                {
                    "data": {
                        "id": "e19",
                        "source": "ext::bloom::STX-2H::CWX-2A",
                        "target": "ext::bloom::STX-2H::MX-2S",
                        "relationship_type": "contains",
                    }
                },
                {
                    "data": {
                        "id": "e20",
                        "source": "ext::bloom::STX-2H::CX-31",
                        "target": "ext::bloom::STX-2H::CWX-2A",
                        "relationship_type": "generic",
                    }
                },
                {
                    "data": {
                        "id": "e21",
                        "source": "ext::bloom::STX-2H::MX-2S",
                        "target": "ext::bloom::STX-2H::MX-3M",
                        "relationship_type": "beta_pool_member",
                    }
                },
                {
                    "data": {
                        "id": "e22",
                        "source": "ext::bloom::STX-2H::CX-35",
                        "target": "ext::bloom::STX-2H::MX-3M",
                        "relationship_type": "contains",
                    }
                },
                {
                    "data": {
                        "id": "e23",
                        "source": "ext::bloom::STX-2H::MX-3M",
                        "target": "ext::bloom::STX-2H::GX-G1",
                        "relationship_type": "beta_sequencing_run",
                    }
                },
                {
                    "data": {
                        "id": "e24",
                        "source": "ext::bloom::STX-2H::GX-G1",
                        "target": "ext::bloom::STX-2H::GX-JX",
                        "relationship_type": "beta_run_artifact",
                    }
                },
                {
                    "data": {
                        "id": "e25",
                        "source": "ext::bloom::STX-2H::GX-G1",
                        "target": "ext::bloom::STX-2H::GX-KV",
                        "relationship_type": "beta_run_artifact",
                    }
                },
            ],
        },
        "meta": {},
    }

    story = GraphViewerService._project_story_graph(payload, start_euid="TST-1Q")
    edge_keys = {
        (
            edge["data"]["source"],
            edge["data"]["target"],
            edge["data"]["relationship_type"],
        )
        for edge in story["elements"]["edges"]
    }

    assert (
        "ext::bloom::STX-2H::CX-19",
        "ext::bloom::STX-2H::CWX-1W",
        "container_parent_of",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::CWX-1W",
        "ext::bloom::STX-2H::CWX-2A",
        "container_parent_of",
    ) in edge_keys
    assert ("ext::bloom::STX-2H::CX-31", "ext::bloom::STX-2H::CWX-2A", "contains_well") in edge_keys
    assert (
        "ext::bloom::STX-2H::CWX-2A",
        "ext::bloom::STX-2H::CX-35",
        "container_parent_of",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::MX-2P",
        "ext::bloom::STX-2H::MX-2S",
        "content_parent_of",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::MX-2S",
        "ext::bloom::STX-2H::MX-3M",
        "content_parent_of",
    ) in edge_keys
    assert ("CEV-1V", "TST-1Q", "collected_for_test") in edge_keys
    assert (
        "ext::bloom::STX-2H::MX-2P",
        "ext::bloom::STX-2H::DAT-G4",
        "library_prep_output",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::DAT-G4",
        "ext::bloom::STX-2H::MX-2S",
        "library_material_output",
    ) in edge_keys
