"""Web route tests for unified search page."""

from __future__ import annotations

import uuid

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user_web
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from app.search.contracts import SearchFacets, SearchQueryResponse, SearchResultItem


def _make_user() -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="web-search@lsmc.bio",
        name="Web Search",
        tenant_id=uuid.uuid4(),
        roles=[Role.EXTERNAL_USER.value],
    )


class DummyWebSearchService:
    def __init__(self, _db, _tenant_id, *, cross_tenant):
        self.cross_tenant = cross_tenant

    def query(self, request):
        items = [
            SearchResultItem(
                record_type="instance",
                source_kind="tapdb.generic_instance",
                uid=111,
                euid="PAT-1",
                name="Jane Doe",
                created_at="2026-03-02T00:00:00+00:00",
                modified_at="2026-03-02T00:00:00+00:00",
                category="atlas",
                type="people",
                subtype="patient",
                version="1.0",
                is_deleted=False,
                metadata={},
            )
        ]
        return SearchQueryResponse(
            items=items,
            facets=SearchFacets(instance=1, template=0, lineage=0, audit=0),
            total=2,
            page=request.page,
            page_size=request.page_size,
            has_more=True,
            timing_ms=3,
        )


@pytest.fixture(autouse=True)
def _clear_overrides():
    yield
    app.dependency_overrides.clear()


def _client_with_user(user: CurrentUser) -> TestClient:
    def override_db():
        yield object()

    def override_user():
        return user

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_current_user_web] = override_user
    return TestClient(app)


@pytest.mark.db
def test_search_page_renders(monkeypatch):
    monkeypatch.setattr("app.web.routes.search.UnifiedSearchService", DummyWebSearchService)
    client = _client_with_user(_make_user())

    response = client.get("/search")
    assert response.status_code == 200
    assert "Unified Search" in response.text
    assert "Run a search to see unified results" in response.text


@pytest.mark.db
def test_search_page_with_query_renders_results(monkeypatch):
    monkeypatch.setattr("app.web.routes.search.UnifiedSearchService", DummyWebSearchService)
    client = _client_with_user(_make_user())

    response = client.get("/search?q=jane&scope=instance")
    assert response.status_code == 200
    assert "Jane Doe" in response.text
    assert "instance: 1" in response.text


@pytest.mark.db
def test_search_page_has_pagination_links(monkeypatch):
    monkeypatch.setattr("app.web.routes.search.UnifiedSearchService", DummyWebSearchService)
    client = _client_with_user(_make_user())

    response = client.get("/search?q=x&page=2&scope=instance")
    assert response.status_code == 200
    assert "Previous" in response.text
    assert "Next" in response.text


def test_search_page_requires_auth_redirect():
    client = TestClient(app)
    response = client.get("/search", follow_redirects=False)
    assert response.status_code == 302
    assert response.headers.get("location") == "/login"
