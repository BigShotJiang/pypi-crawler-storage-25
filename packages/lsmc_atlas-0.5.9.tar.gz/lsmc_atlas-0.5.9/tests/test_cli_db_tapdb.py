"""Unit tests for atlas db TapDB orchestration."""

from __future__ import annotations

from types import SimpleNamespace

from app.cli import db as db_cli


def test_build_local_uses_tapdb_bootstrap(monkeypatch):
    tapdb_calls: list[list[str]] = []
    overlay_calls: list[tuple[int, int, str]] = []

    monkeypatch.setattr(
        db_cli,
        "run_tapdb_cli",
        lambda **kwargs: (
            tapdb_calls.append(kwargs["args"])
            or SimpleNamespace(stdout="", stderr="", returncode=0)
        ),
    )
    monkeypatch.setattr(
        db_cli,
        "export_database_url_for_target",
        lambda **_kwargs: "postgresql+psycopg2://atlas@localhost:5432/atlas_dev",
    )
    monkeypatch.setattr(
        db_cli,
        "_apply_atlas_overlay",
        lambda *, start_step, total_steps, tenant_uuid="": overlay_calls.append(
            (start_step, total_steps, tenant_uuid)
        ),
    )

    db_cli.build(
        target="local",
        cluster="",
        region="us-west-2",
        profile="lsmc",
        namespace="lsmc-atlas",
        tenant_uuid="11111111-1111-1111-1111-111111111111",
    )

    assert tapdb_calls[0] == ["bootstrap", "local", "--no-gui"]
    assert overlay_calls == [(3, 3, "11111111-1111-1111-1111-111111111111")]


def test_reset_uses_tapdb_delete_then_bootstrap(monkeypatch):
    tapdb_calls: list[list[str]] = []
    overlay_calls: list[tuple[int, int, str]] = []

    monkeypatch.setattr(
        db_cli,
        "run_tapdb_cli",
        lambda **kwargs: (
            tapdb_calls.append(kwargs["args"])
            or SimpleNamespace(stdout="", stderr="", returncode=0)
        ),
    )
    monkeypatch.setattr(
        db_cli,
        "export_database_url_for_target",
        lambda **_kwargs: "postgresql+psycopg2://atlas@localhost:5432/atlas_dev",
    )
    monkeypatch.setattr(
        db_cli,
        "_apply_atlas_overlay",
        lambda *, start_step, total_steps, tenant_uuid="": overlay_calls.append(
            (start_step, total_steps, tenant_uuid)
        ),
    )

    db_cli.reset(
        force=True,
        target="local",
        cluster="",
        region="us-west-2",
        profile="lsmc",
        namespace="lsmc-atlas",
        tenant_uuid="22222222-2222-2222-2222-222222222222",
    )

    assert tapdb_calls[0] == ["db", "delete", "dev", "--force"]
    assert tapdb_calls[1] == ["bootstrap", "local", "--no-gui"]
    assert overlay_calls == [(4, 4, "22222222-2222-2222-2222-222222222222")]


def test_seed_passes_tenant_uuid_to_overlay_script(monkeypatch):
    captured: list[list[str]] = []

    monkeypatch.setattr(
        db_cli,
        "_prepare_database_url",
        lambda **_kwargs: "postgresql+psycopg2://atlas@localhost:5432/atlas_dev",
    )
    monkeypatch.setattr(
        db_cli,
        "_run_step",
        lambda cmd, *, step_name: captured.append(cmd),
    )

    db_cli.seed(tenant_uuid="33333333-3333-3333-3333-333333333333")

    assert captured == [
        [
            db_cli.sys.executable,
            "scripts/seed_tapdb_overlay.py",
            "--tenant-uuid",
            "33333333-3333-3333-3333-333333333333",
        ]
    ]


def test_nuke_routes_destructive_action_through_tapdb(monkeypatch):
    tapdb_calls: list[list[str]] = []

    monkeypatch.setattr(
        db_cli,
        "run_tapdb_cli",
        lambda **kwargs: (
            tapdb_calls.append(kwargs["args"])
            or SimpleNamespace(stdout="", stderr="", returncode=0)
        ),
    )

    db_cli.nuke(
        force=True,
        target="local",
        region="us-west-2",
        profile="lsmc",
        namespace="lsmc-atlas",
    )

    assert tapdb_calls == [["db", "delete", "dev", "--force"]]
