"""Tests for FedEx tracking service."""

import uuid
from datetime import datetime

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def simple_client() -> TestClient:
    """Create a test client without DB dependencies."""
    return TestClient(app)


class TestFedExTrackingService:
    """Tests for FedExTrackingService."""

    def test_service_available_flag_when_not_installed(self):
        """Test that FEDEX_AVAILABLE is False when fedex_tracking_day is not installed."""
        from app.domain.services.fedex_tracking import FEDEX_AVAILABLE

        # In test env, fedex_tracking_day is typically not installed
        assert isinstance(FEDEX_AVAILABLE, bool)

    def test_service_is_available_method(self):
        """Test is_available method returns expected value."""
        from app.domain.services.fedex_tracking import (
            FEDEX_AVAILABLE,
            FedExTrackingService,
        )

        service = FedExTrackingService(db=None, tenant_id=uuid.uuid4())
        assert service.is_available() == FEDEX_AVAILABLE

    def test_track_returns_unavailable_status_when_library_not_installed(self):
        """Test track returns summary with error when service unavailable."""
        from app.domain.services.fedex_tracking import (
            FEDEX_AVAILABLE,
            FedExTrackingService,
        )

        if FEDEX_AVAILABLE:
            pytest.skip("fedex_tracking_day is installed, skipping unavailable test")

        service = FedExTrackingService(db=None, tenant_id=uuid.uuid4())
        result = service.track("123456789012")

        assert result is not None
        assert result.delivery_status == "UNAVAILABLE"
        assert result.error == "daylily-carrier-tracking library not installed"

    def test_tracking_event_dataclass(self):
        """Test TrackingEvent dataclass creation."""
        from app.domain.services.fedex_tracking import TrackingEvent

        event = TrackingEvent(
            timestamp=datetime.utcnow(),
            event_type="DL",
            event_description="Delivered to front door",
            city="Boston",
            state="MA",
            country_code="US",
        )

        assert event.event_type == "DL"
        assert event.city == "Boston"
        assert event.state == "MA"

    def test_tracking_summary_dataclass(self):
        """Test TrackingSummary dataclass creation."""
        from app.domain.services.fedex_tracking import TrackingEvent, TrackingSummary

        event = TrackingEvent(
            timestamp=datetime.utcnow(),
            event_type="DL",
            event_description="Delivered to front door",
            city="Boston",
            state="MA",
            country_code="US",
        )

        summary = TrackingSummary(
            tracking_number="123456789012",
            delivery_status="Delivered",
            origin_city="Los Angeles",
            origin_state="CA",
            origin_country="US",
            destination_city="Boston",
            destination_state="MA",
            destination_country="US",
            ship_date=datetime(2024, 1, 15),
            pickup_date=datetime(2024, 1, 15),
            delivery_date=datetime(2024, 1, 17),
            transit_time_seconds=172800,  # 2 days
            service_type="FEDEX_GROUND",
            service_description="FedEx Ground",
            events=[event],
            raw_response={"test": "data"},
        )

        assert summary.tracking_number == "123456789012"
        assert summary.delivery_status == "Delivered"
        assert len(summary.events) == 1
        assert summary.events[0].city == "Boston"

    def test_get_latest_tracking_returns_none_in_live_only_mode(self):
        """Runtime hard-cut uses live-only tracking; no snapshot retrieval."""
        from app.domain.services.fedex_tracking import FedExTrackingService

        service = FedExTrackingService(db=None, tenant_id=uuid.uuid4())
        assert service.get_latest_tracking(uuid.uuid4()) is None

    def test_update_shipment_tracking_audits_live_only_without_snapshot_writes(self, monkeypatch):
        """Tracking updates should audit live mode and avoid persisted snapshot assumptions."""
        from app.domain.services import fedex_tracking as fedex_module

        class DummyDB:
            def __init__(self):
                self.committed = False
                self.rolled_back = False

            def commit(self):
                self.committed = True

            def rollback(self):
                self.rolled_back = True

        db = DummyDB()
        tenant_id = uuid.uuid4()
        service = fedex_module.FedExTrackingService(db=db, tenant_id=tenant_id)

        summary = fedex_module.TrackingSummary(
            tracking_number="123456789012",
            delivery_status="IN_TRANSIT",
        )
        monkeypatch.setattr(service, "track", lambda _tracking_number: summary)

        audit_calls: list[dict] = []

        class FakeAuditService:
            def __init__(self, _db, tenant_id=None):
                self.tenant_id = tenant_id

            def log(self, **kwargs):
                audit_calls.append(kwargs)

        monkeypatch.setattr(fedex_module, "AuditService", FakeAuditService)

        shipment_id = uuid.uuid4()
        result = service.update_shipment_tracking(shipment_id, "123456789012")

        assert result.delivery_status == "IN_TRANSIT"
        assert db.committed is True
        assert db.rolled_back is False
        assert len(audit_calls) == 1
        assert audit_calls[0]["entity_type"] == "Shipment"
        assert audit_calls[0]["entity_id"] == str(shipment_id)
        assert audit_calls[0]["details"]["tracking_mode"] == "live_only"


class TestTrackingAPI:
    """Tests for tracking API endpoints."""

    def test_tracking_status_endpoint(self, simple_client: TestClient):
        """Test GET /api/tracking/status returns status info."""
        response = simple_client.get("/api/tracking/status")
        assert response.status_code in (200, 401, 403)

    def test_tracking_endpoint_requires_auth(self, simple_client: TestClient):
        """Test GET /api/tracking/track/{number} requires authentication or returns service status.

        Possible responses:
        - 200: Authenticated and service returned data
        - 401: Not authenticated
        - 403: Forbidden (wrong role)
        - 503: Service unavailable (FedEx tracking library not installed)
        """
        response = simple_client.get("/api/tracking/track/123456789012")
        assert response.status_code in (200, 401, 403, 503)
