"""Hard-cut identity guards for Atlas Bloom integration."""

from __future__ import annotations

from types import SimpleNamespace

import pytest
from pydantic import ValidationError

import app.api.routes.bloom_integration as bloom_routes
from app.domain.services.bloom_bridge import (
    ContainerSpecimenBridgeService,
    _sanitize_bloom_metadata,
)
from app.domain.services.external_objects import ExternalObjectUpsert
from app.integrations.bloom_client import BloomOperationResult


def test_accepted_material_request_rejects_package_number_alias():
    with pytest.raises(ValidationError):
        bloom_routes.AcceptedMaterialRequestBody(
            trf_euid="TRF-1001",
            test_euids=["TST-1001"],
            patient_euid="PAT-1001",
            shipment_euid="SHP-1001",
            starting_queue="extraction_prod",
            package_number="SHP-2001",
        )


def test_external_object_upsert_disallows_external_uuid_field():
    with pytest.raises(TypeError):
        ExternalObjectUpsert(
            provider="bloom",
            object_type="specimen",
            external_euid="SP-1001",
            external_uuid="legacy-uuid",
        )


def test_sanitize_bloom_metadata_drops_foreign_uuid_fields():
    cleaned = _sanitize_bloom_metadata(
        {
            "specimen_euid": "SP-2001",
            "container_euid": "CN-2001",
            "uuid": "legacy",
            "specimen_uuid": "legacy-spec",
            "container_uuid": "legacy-container",
            "external_uuid": "legacy-external",
            "status": "active",
        }
    )
    assert cleaned == {
        "specimen_euid": "SP-2001",
        "container_euid": "CN-2001",
        "status": "active",
    }


def test_bridge_persist_external_object_uses_euid_only_and_sanitized_metadata():
    service = object.__new__(ContainerSpecimenBridgeService)
    captured: dict[str, object] = {}

    class _FakeExternalObjects:
        def upsert_external_object(self, data, actor_id=None):
            captured["data"] = data
            captured["actor_id"] = actor_id
            return SimpleNamespace(euid="EXB-1")

    service.external_objects = _FakeExternalObjects()
    service.PROVIDER = "bloom"

    result = BloomOperationResult(
        external_euid="SP-2001",
        status="active",
        raw={
            "specimen_euid": "SP-2001",
            "container_euid": "CN-2001",
            "uuid": "legacy-uuid",
        },
    )
    ContainerSpecimenBridgeService._persist_external_object(
        service,
        object_type="specimen",
        bloom_result=result,
        actor_id=None,
    )

    data = captured["data"]
    assert isinstance(data, ExternalObjectUpsert)
    assert data.external_euid == "SP-2001"
    assert data.metadata == {"specimen_euid": "SP-2001", "container_euid": "CN-2001"}
