from __future__ import annotations

import uuid

import pytest

from app.domain.services.test_fulfillment_items import TestFulfillmentItemService
from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService
from app.persistence.tapdb.euid_helpers import get_instance_by_euid
from app.persistence.tapdb.test_fulfillment_items import TEST_FULFILLMENT_ITEM_TEMPLATE_CODE
from tests.tapdb_test_helpers import ensure_tapdb_org


@pytest.mark.db
def test_process_item_uses_graph_relation_for_parent_test(db_session):
    tenant_id = uuid.uuid4()
    actor_id = uuid.uuid4()
    ensure_tapdb_org(
        db_session,
        tenant_id,
        name="fulfillment-item-org",
        display_name="Process Item Org",
    )
    trf_service = TrfService(db_session, tenant_id)
    trf, _trf_revision = trf_service.create(
        TrfCreate(order_type="CLINICAL"),
        tests=[TestCreate(product_code="WGS", fulfillment_route_codes=["WGS"])],
        created_by=actor_id,
    )
    test_service = TestService(db_session, tenant_id)
    test, _test_revision, _assays = test_service.list_for_trf(trf.euid)[0]

    service = TestFulfillmentItemService(db_session, tenant_id)
    fulfillment_item = service.ensure_default_for_test(test_euid=test.euid, created_by=actor_id)

    raw = get_instance_by_euid(
        db_session, TEST_FULFILLMENT_ITEM_TEMPLATE_CODE, fulfillment_item.euid
    )
    assert raw is not None
    properties = dict((raw.json_addl or {}).get("properties") or {})
    assert "test_euid" not in properties

    resolved = service.get(fulfillment_item.euid)
    assert resolved is not None
    assert resolved.test_euid == test.euid
