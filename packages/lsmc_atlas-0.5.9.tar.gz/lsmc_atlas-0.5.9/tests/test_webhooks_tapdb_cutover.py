"""Unit tests for TapDB cutover behavior in WebhookService."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from types import SimpleNamespace

from app.domain.services import webhooks as webhooks_service
from app.domain.services.webhooks import (
    WebhookEvent,
    WebhookService,
    WebhookSubscriptionCreate,
    WebhookSubscriptionUpdate,
)


@dataclass
class _MockDB:
    pass


class _FakeWebhookRepo:
    def __init__(self, tenant_id: uuid.UUID):
        self.calls: list[str] = []
        self.subscription = SimpleNamespace(
            id=uuid.uuid4(),
            tenant_id=tenant_id,
            subscription_name="Orders Hook",
            created_at=datetime.utcnow(),
            euid="WHS-001",
        )
        self.revision = SimpleNamespace(
            subscription_id=self.subscription.euid,
            revision_id=uuid.uuid4(),
            revision_no=1,
            url="https://example.com/webhook",
            secret="secret",
            event_types=["order.created"],
            is_active=True,
            headers=None,
            timeout_seconds=30,
            max_retries=3,
            note=None,
        )
        self.logs = [
            SimpleNamespace(
                id=uuid.uuid4(),
                subscription_id=self.subscription.euid,
                event_type="order.created",
                event_id=uuid.uuid4(),
                url=self.revision.url,
                attempt_number=1,
                http_status=200,
                error_message=None,
                delivered_at=datetime.utcnow(),
            )
        ]

    def create_subscription(self, tenant_id, data, created_by):
        self.calls.append("create_subscription")
        self.subscription.subscription_name = data.subscription_name
        self.revision.url = data.url
        self.revision.secret = data.secret
        self.revision.event_types = data.event_types
        self.revision.timeout_seconds = data.timeout_seconds
        self.revision.max_retries = data.max_retries
        return self.subscription, self.revision

    def get_subscription(self, subscription_id, tenant_id):
        self.calls.append("get_subscription")
        if subscription_id != self.subscription.euid:
            return None
        return self.subscription, self.revision

    def list_subscriptions(self, tenant_id, skip=0, limit=100):
        self.calls.append("list_subscriptions")
        return [(self.subscription, self.revision)]

    def update_subscription(self, tenant_id, subscription_id, data, updated_by):
        self.calls.append("update_subscription")
        if data.url is not None:
            self.revision.url = data.url
        if data.event_types is not None:
            self.revision.event_types = data.event_types
        if data.is_active is not None:
            self.revision.is_active = data.is_active
        return self.subscription, self.revision

    def list_active_subscriptions_for_event(self, tenant_id, event_type):
        self.calls.append("list_active_subscriptions_for_event")
        if self.revision.is_active and event_type in self.revision.event_types:
            return [(self.subscription, self.revision)]
        return []

    def log_delivery(self, **kwargs):
        self.calls.append("log_delivery")

    def get_delivery_logs(self, tenant_id, subscription_id=None, event_type=None, limit=100):
        self.calls.append("get_delivery_logs")
        return self.logs


def test_webhook_service_delegates_to_tapdb_repo(monkeypatch):
    tenant_id = uuid.uuid4()
    svc = WebhookService(_MockDB(), tenant_id)
    repo = _FakeWebhookRepo(tenant_id)

    monkeypatch.setattr(
        "app.domain.services.site_scope.resolve_tenant_site_euid",
        lambda _db, _tenant_id, site_euid, **_kwargs: site_euid or "STX-TEST",
    )
    monkeypatch.setattr(svc, "_repo", lambda: repo)
    monkeypatch.setattr(webhooks_service, "_validate_webhook_url", lambda _url: None)

    created = svc.create(
        WebhookSubscriptionCreate(
            subscription_name="Orders Hook",
            url="https://example.com/webhook",
            secret="secret",
            event_types=["order.created"],
        ),
        created_by=uuid.uuid4(),
    )
    assert created[0].subscription_name == "Orders Hook"

    fetched = svc.get(repo.subscription.euid)
    assert fetched is not None

    listed = svc.list()
    assert len(listed) == 1

    updated = svc.update(
        repo.subscription.euid,
        WebhookSubscriptionUpdate(url="https://example.com/updated"),
        updated_by=uuid.uuid4(),
    )
    assert updated is not None
    assert updated[1].url == "https://example.com/updated"

    event = WebhookEvent(
        event_type="order.created",
        event_id=uuid.uuid4(),
        payload={"order_number": "ORD-1"},
        timestamp=datetime.utcnow(),
    )

    class _Resp:
        status_code = 200
        is_success = True
        text = "ok"

    monkeypatch.setattr(webhooks_service.httpx, "post", lambda *_args, **_kwargs: _Resp())

    svc.deliver(event)

    logs = svc.get_delivery_logs(subscription_id=repo.subscription.euid, limit=10)
    assert logs == repo.logs

    assert "create_subscription" in repo.calls
    assert "get_subscription" in repo.calls
    assert "list_subscriptions" in repo.calls
    assert "update_subscription" in repo.calls
    assert "list_active_subscriptions_for_event" in repo.calls
    assert "log_delivery" in repo.calls
    assert "get_delivery_logs" in repo.calls
