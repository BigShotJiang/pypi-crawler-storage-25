"""Unit tests for Bloom client endpoint mapping and retry behavior."""

from __future__ import annotations

import json

import pytest

import app.integrations.bloom_client as bloom_client
from app.integrations.bloom_client import BloomClient, BloomClientError, resolve_secret_value


def test_bloom_client_uses_beta_material_contract_paths(monkeypatch):
    calls: list[dict[str, object]] = []

    def fake_request(self, method, path, *, payload=None, idempotency_key=None, params=None):
        calls.append(
            {
                "method": method,
                "path": path,
                "payload": payload,
                "idempotency_key": idempotency_key,
                "params": params,
            }
        )
        if path == "/api/v1/external/atlas/beta/materials":
            return {
                "specimen_euid": "SP-1001",
                "container_euid": "CNT-1001",
                "status": "active",
                "created": True,
            }
        if path == "/api/v1/external/atlas/beta/queues/extraction_prod/items/CNT-1001":
            return {
                "material_euid": "CNT-1001",
                "queue_euid": "Q-1",
                "queue_name": "extraction_prod",
                "current_queue": "extraction_prod",
            }
        if path == "/api/v1/external/atlas/beta/queues/extraction_prod/items/CNT-1001/claim":
            return {
                "claim_euid": "CLM-1001",
                "material_euid": "CNT-1001",
                "queue_name": "extraction_prod",
                "work_item_euid": "WI-1001",
                "status": "active",
                "metadata": {},
            }
        if path == "/api/v1/external/atlas/beta/claims/CLM-1001/release":
            return {
                "claim_euid": "CLM-1001",
                "material_euid": "CNT-1001",
                "queue_name": "extraction_prod",
                "work_item_euid": "WI-1001",
                "status": "completed",
                "metadata": {},
            }
        if path == "/api/v1/external/atlas/beta/materials/CNT-1001/reservations":
            return {
                "reservation_euid": "RSV-1001",
                "material_euid": "CNT-1001",
                "status": "active",
                "metadata": {},
            }
        if path == "/api/v1/external/atlas/beta/reservations/RSV-1001/release":
            return {
                "reservation_euid": "RSV-1001",
                "material_euid": "CNT-1001",
                "status": "released",
                "metadata": {},
            }
        if path == "/api/v1/external/atlas/beta/materials/CNT-1001/consume":
            return {
                "consumption_event_euid": "CNS-1001",
                "material_euid": "CNT-1001",
                "consumed": True,
                "metadata": {},
            }
        if path == "/api/v1/external/specimens/by-reference":
            return {"items": [{"specimen_euid": "SP-1001"}]}
        if path == "/api/v1/content/SP-1001":
            return {}
        return {"euid": "GEN-1", "status": "active"}

    monkeypatch.setattr(BloomClient, "_request", fake_request)
    client = BloomClient(base_url="https://bloom.local", api_key="test-api-key")

    material = client.register_accepted_material(
        {
            "atlas_refs": {
                "atlas_tenant_id": "TEN-1",
                "atlas_trf_euid": "TRF-1",
                "atlas_test_euid": "TST-1",
            }
        },
        idempotency_key="idem-accept-1",
    )
    queued = client.move_material_to_queue(
        "CNT-1001",
        "extraction_prod",
        metadata={"atlas_trf_euid": "TRF-1"},
        idempotency_key="idem-queue-1",
    )
    claim = client.claim_material_in_queue(
        "CNT-1001",
        "extraction_prod",
        metadata={"operator": "qa"},
        idempotency_key="idem-claim-1",
    )
    released_claim = client.release_claim(
        "CLM-1001",
        reason="completed",
        idempotency_key="idem-claim-release-1",
    )
    reservation = client.reserve_material(
        "CNT-1001",
        reason="manual_hold",
        idempotency_key="idem-reserve-1",
    )
    released_reservation = client.release_reservation(
        "RSV-1001",
        reason="hold_cleared",
        idempotency_key="idem-reserve-release-1",
    )
    consumed = client.consume_material(
        "CNT-1001",
        reason="stage:extraction",
        idempotency_key="idem-consume-1",
    )
    listed = client.find_external_specimens_by_reference({"atlas_trf_euid": "TRF-1"})
    deleted = client.delete_content("SP-1001")

    assert material.external_euid == "SP-1001"
    assert queued["current_queue"] == "extraction_prod"
    assert claim["claim_euid"] == "CLM-1001"
    assert released_claim["status"] == "completed"
    assert reservation["reservation_euid"] == "RSV-1001"
    assert released_reservation["status"] == "released"
    assert consumed["consumption_event_euid"] == "CNS-1001"
    assert listed == [{"specimen_euid": "SP-1001"}]
    assert deleted.external_euid == "SP-1001"
    assert deleted.status == "deleted"

    expected_paths = [
        "/api/v1/external/atlas/beta/materials",
        "/api/v1/external/atlas/beta/queues/extraction_prod/items/CNT-1001",
        "/api/v1/external/atlas/beta/queues/extraction_prod/items/CNT-1001/claim",
        "/api/v1/external/atlas/beta/claims/CLM-1001/release",
        "/api/v1/external/atlas/beta/materials/CNT-1001/reservations",
        "/api/v1/external/atlas/beta/reservations/RSV-1001/release",
        "/api/v1/external/atlas/beta/materials/CNT-1001/consume",
        "/api/v1/external/specimens/by-reference",
        "/api/v1/content/SP-1001",
    ]
    assert [call["path"] for call in calls] == expected_paths
    assert calls[0]["idempotency_key"] == "idem-accept-1"
    assert calls[1]["idempotency_key"] == "idem-queue-1"
    assert calls[2]["idempotency_key"] == "idem-claim-1"
    assert calls[3]["idempotency_key"] == "idem-claim-release-1"
    assert calls[4]["idempotency_key"] == "idem-reserve-1"
    assert calls[5]["idempotency_key"] == "idem-reserve-release-1"
    assert calls[6]["idempotency_key"] == "idem-consume-1"
    assert calls[7]["params"] == {"atlas_trf_euid": "TRF-1"}


def test_bloom_client_retries_http_424(monkeypatch):
    class FakeResponse:
        def __init__(self, status_code: int, payload: dict[str, object]):
            self.status_code = status_code
            self._payload = payload

        @property
        def text(self) -> str:
            return json.dumps(self._payload)

        def json(self):
            return self._payload

    class FakeHttpClient:
        calls = 0

        def __init__(self, timeout=None, verify=None, **_kwargs):
            self.timeout = timeout
            self.verify = verify

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def request(self, method, url, json=None, headers=None, params=None):
            self.__class__.calls += 1
            if self.__class__.calls == 1:
                return FakeResponse(424, {"detail": "upstream dependency not ready"})
            return FakeResponse(200, {"specimen_euid": "SP-2001", "status": "active"})

    monkeypatch.setattr(bloom_client.httpx, "Client", FakeHttpClient)
    client = BloomClient(
        base_url="https://bloom.local",
        api_key="test-api-key",
        max_retries=1,
        retry_backoff_seconds=0,
    )

    result = client.register_accepted_material(
        {
            "atlas_refs": {
                "atlas_tenant_id": "TEN-1",
                "atlas_trf_euid": "TRF-1",
                "atlas_test_euid": "TST-1",
            }
        }
    )

    assert result.external_euid == "SP-2001"
    assert FakeHttpClient.calls == 2


def test_resolve_secret_value_accepts_direct_bloom_token():
    # Use a clearly-fake test token (not a real credential)
    token = "blm_" + "0" * 32  # nosec B105 - intentional fake test token
    assert resolve_secret_value(token) == token
    assert resolve_secret_value(f"  {token}  ") == token


def test_resolve_secret_value_missing_env_still_errors(monkeypatch):
    missing_key = "ATLAS_BLOOM_KEY_MISSING"
    monkeypatch.delenv(missing_key, raising=False)

    with pytest.raises(BloomClientError, match="Missing environment variable"):
        resolve_secret_value(f"env:{missing_key}")


def test_bloom_client_rejects_non_https_base_url():
    with pytest.raises(BloomClientError, match="absolute https:// URL"):
        BloomClient(base_url="http://bloom.local", api_key="test-api-key")


def test_bloom_client_graph_routes(monkeypatch):
    calls: list[dict[str, object]] = []

    def fake_request(self, method, path, *, payload=None, idempotency_key=None, params=None):
        calls.append(
            {
                "method": method,
                "path": path,
                "payload": payload,
                "idempotency_key": idempotency_key,
                "params": params,
            }
        )
        if path == "/api/v1/graph/data":
            return {"elements": {"nodes": [], "edges": []}}
        return {"euid": "BL-SP-1", "external_refs": []}

    monkeypatch.setattr(BloomClient, "_request", fake_request)
    client = BloomClient(base_url="https://bloom.local", api_key="test-api-key")

    graph_payload = client.get_graph_data(start_euid="BL-SP-1", depth=3)
    object_payload = client.get_graph_object_detail(euid="BL-SP-1")

    assert graph_payload["elements"]["nodes"] == []
    assert object_payload["euid"] == "BL-SP-1"
    assert calls == [
        {
            "method": "GET",
            "path": "/api/v1/graph/data",
            "payload": None,
            "idempotency_key": None,
            "params": {"start_euid": "BL-SP-1", "depth": 3},
        },
        {
            "method": "GET",
            "path": "/api/v1/graph/object/BL-SP-1",
            "payload": None,
            "idempotency_key": None,
            "params": None,
        },
    ]


def test_bloom_client_beta_lab_execution_routes(monkeypatch):
    calls: list[dict[str, object]] = []

    def fake_request(self, method, path, *, payload=None, idempotency_key=None, params=None):
        calls.append(
            {
                "method": method,
                "path": path,
                "payload": payload,
                "idempotency_key": idempotency_key,
                "params": params,
            }
        )
        if path == "/api/v1/external/atlas/beta/extractions":
            return {
                "source_specimen_euid": "SP-1",
                "plate_euid": "PLT-1",
                "well_euid": "WELL-1",
                "well_name": "A1",
                "extraction_output_euid": "EXT-1",
                "atlas_test_fulfillment_item_euid": "TFI-1",
                "current_queue": "post_extract_qc",
            }
        if path == "/api/v1/external/atlas/beta/post-extract-qc":
            return {
                "extraction_output_euid": "EXT-1",
                "qc_passed": True,
                "current_queue": "ilmn_lib_prep",
            }
        if path == "/api/v1/external/atlas/beta/library-prep":
            return {
                "source_extraction_output_euid": "EXT-1",
                "library_prep_output_euid": "LIB-1",
                "library_material_euid": "MX-LIB-1",
                "library_container_euid": "CX-LIB-1",
                "library_plate_euid": "CX-LIB-1",
                "library_well_euid": "CWX-LIB-1",
                "atlas_test_fulfillment_item_euid": "TFI-1",
                "current_queue": "ilmn_seq_pool",
            }
        if path == "/api/v1/external/atlas/beta/pools":
            return {
                "pool_euid": "POOL-1",
                "pool_container_euid": "POOL-CNT-1",
                "current_queue": "ilmn_start_seq_run",
                "member_euids": ["LIB-1"],
            }
        if path == "/api/v1/external/atlas/beta/runs":
            return {
                "run_euid": "RUN-1",
                "pool_euid": "POOL-1",
                "flowcell_id": "FC-1",
                "run_folder": "RUN-1/",
                "status": "completed",
                "artifact_count": 2,
                "assignment_count": 1,
            }
        if path == "/api/v1/external/atlas/beta/runs/RUN-1/resolve":
            return {
                "run_euid": "RUN-1",
                "flowcell_id": "FC-1",
                "lane": "L001",
                "library_barcode": "LIBBC-1",
                "sequenced_library_assignment_euid": "ASSIGN-1",
                "atlas_tenant_id": "TEN-1",
                "atlas_trf_euid": "TRF-1",
                "atlas_test_euid": "TST-1",
                "atlas_test_fulfillment_item_euid": "TFI-1",
            }
        return {}

    monkeypatch.setattr(BloomClient, "_request", fake_request)
    client = BloomClient(base_url="https://bloom.local", api_key="test-api-key")

    extraction = client.create_extraction(
        {
            "source_specimen_euid": "SP-1",
            "well_name": "A1",
            "extraction_type": "gdna",
        },
        idempotency_key="idem-extract-1",
    )
    qc = client.record_post_extract_qc(
        {
            "extraction_output_euid": "EXT-1",
            "passed": True,
            "next_queue": "ilmn_lib_prep",
        },
        idempotency_key="idem-qc-1",
    )
    library_prep = client.create_library_prep(
        {
            "source_extraction_output_euid": "EXT-1",
            "platform": "ILMN",
        },
        idempotency_key="idem-libprep-1",
    )
    pool = client.create_pool(
        {
            "member_euids": ["LIB-1"],
            "platform": "ILMN",
        },
        idempotency_key="idem-pool-1",
    )
    run = client.create_run(
        {
            "pool_euid": "POOL-1",
            "platform": "ILMN",
            "flowcell_id": "FC-1",
            "assignments": [
                {
                    "lane": "L001",
                    "library_barcode": "LIBBC-1",
                    "library_prep_output_euid": "LIB-1",
                }
            ],
            "artifacts": [],
        },
        idempotency_key="idem-run-1",
    )
    resolved = client.resolve_run_assignment(
        "RUN-1",
        flowcell_id="FC-1",
        lane="L001",
        library_barcode="LIBBC-1",
    )

    assert extraction["extraction_output_euid"] == "EXT-1"
    assert qc["current_queue"] == "ilmn_lib_prep"
    assert library_prep["library_prep_output_euid"] == "LIB-1"
    assert library_prep["library_material_euid"] == "MX-LIB-1"
    assert library_prep["library_container_euid"] == "CX-LIB-1"
    assert library_prep["library_plate_euid"] == "CX-LIB-1"
    assert library_prep["library_well_euid"] == "CWX-LIB-1"
    assert pool["pool_euid"] == "POOL-1"
    assert run["run_euid"] == "RUN-1"
    assert resolved["atlas_test_euid"] == "TST-1"
    assert [call["path"] for call in calls] == [
        "/api/v1/external/atlas/beta/extractions",
        "/api/v1/external/atlas/beta/post-extract-qc",
        "/api/v1/external/atlas/beta/library-prep",
        "/api/v1/external/atlas/beta/pools",
        "/api/v1/external/atlas/beta/runs",
        "/api/v1/external/atlas/beta/runs/RUN-1/resolve",
    ]
    assert calls[5]["params"] == {
        "flowcell_id": "FC-1",
        "lane": "L001",
        "library_barcode": "LIBBC-1",
    }


def test_bloom_client_object_detail_route(monkeypatch):
    calls: list[dict[str, object]] = []

    def fake_request(self, method, path, *, payload=None, idempotency_key=None, params=None):
        calls.append(
            {
                "method": method,
                "path": path,
                "payload": payload,
                "idempotency_key": idempotency_key,
                "params": params,
            }
        )
        return {
            "euid": "CNT-1001",
            "status": "queued",
            "created_at": "2026-03-29T12:34:56Z",
            "type": "container",
            "subtype": "tube",
            "json_addl": {"source": "atlas"},
        }

    monkeypatch.setattr(BloomClient, "_request", fake_request)
    client = BloomClient(base_url="https://bloom.local", api_key="test-api-key")

    detail = client.get_object_detail("CNT-1001")

    assert detail["euid"] == "CNT-1001"
    assert detail["status"] == "queued"
    assert detail["created_at"] == "2026-03-29T12:34:56Z"
    assert calls == [
        {
            "method": "GET",
            "path": "/api/v1/objects/CNT-1001",
            "payload": None,
            "idempotency_key": None,
            "params": None,
        }
    ]
