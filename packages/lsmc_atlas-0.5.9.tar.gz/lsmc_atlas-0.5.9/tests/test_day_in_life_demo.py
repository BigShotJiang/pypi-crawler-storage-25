from __future__ import annotations

import json
import uuid
from types import SimpleNamespace

import pytest

import app.domain.services.day_in_life_demo as day_in_life_demo
from app.domain.services.day_in_life_demo import (
    DEFAULT_BLOOM_BASE_URL,
    DayInLifeDemoConfig,
    DayInLifeDemoError,
    DayInLifeDemoRunner,
    build_atlas_context_elements,
    build_day_in_life_story_graph,
    merge_graph_payloads,
    render_day_in_life_dag_html,
)
from app.integrations.bloom_client import BloomClientError


def test_merge_graph_payloads_dedupes_ids_without_synthetic_nodes():
    local_payload = {
        "elements": {
            "nodes": [{"data": {"id": "AT-TEST-1", "name": "Atlas Test"}}],
            "edges": [{"data": {"id": "AT-EDGE-1", "source": "AT-TEST-1", "target": "AT-TRF-1"}}],
        },
        "meta": {"start_euid": "AT-TEST-1"},
    }
    external_payloads = [
        {
            "elements": {
                "nodes": [
                    {"data": {"id": "AT-TEST-1", "name": "duplicate local"}},
                    {"data": {"id": "ext::bloom::RUN-ART-1", "name": "reads_R1.fastq.gz"}},
                ],
                "edges": [
                    {"data": {"id": "AT-EDGE-1", "source": "AT-TEST-1", "target": "AT-TRF-1"}},
                    {
                        "data": {
                            "id": "bridge::AT-TEST-1::bloom::RUN-ART-1",
                            "source": "AT-TEST-1",
                            "target": "ext::bloom::RUN-ART-1",
                        }
                    },
                ],
            }
        }
    ]
    merged = merge_graph_payloads(local_payload, external_payloads)

    node_ids = {node["data"]["id"] for node in merged["elements"]["nodes"]}
    edge_ids = {edge["data"]["id"] for edge in merged["elements"]["edges"]}

    assert "AT-TEST-1" in node_ids
    assert "ext::bloom::RUN-ART-1" in node_ids
    assert len(node_ids) == len(merged["elements"]["nodes"])
    assert "AT-EDGE-1" in edge_ids
    assert "bridge::AT-TEST-1::bloom::RUN-ART-1" in edge_ids


def test_identify_fastq_nodes_detects_dewey_registration():
    class FakeBloomClient:
        def get_graph_object_detail(self, *, euid: str) -> dict[str, object]:
            if euid == "RUN-ART-1":
                return {"json_addl": {"properties": {"dewey_artifact_euid": "AT-DEWEY-1"}}}
            return {"json_addl": {"properties": {}}}

    runner = DayInLifeDemoRunner(db=object())
    payloads = [
        {
            "elements": {
                "nodes": [
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-1",
                            "remote_euid": "RUN-1",
                            "name": "demo-run | RUN-1",
                            "type": "generic",
                            "obj_type": "generic",
                        }
                    },
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-ART-1",
                            "remote_euid": "RUN-ART-1",
                            "name": "reads_R1.fastq.gz",
                            "type": "data",
                            "obj_type": "run_artifact",
                        }
                    },
                ],
                "edges": [
                    {
                        "data": {
                            "id": "edge-1",
                            "source": "ext::bloom::SITE-1::RUN-ART-1",
                            "target": "ext::bloom::SITE-1::RUN-1",
                            "relationship_type": "beta_run_artifact",
                        }
                    }
                ],
            }
        }
    ]

    fastq_node_ids, dewey_registered = runner._identify_fastq_nodes(
        payloads,
        bloom_client=FakeBloomClient(),
        run_euid="RUN-1",
        demo_key="demo-run",
    )

    assert fastq_node_ids == ["ext::bloom::SITE-1::RUN-ART-1"]
    assert dewey_registered is True


def test_identify_fastq_nodes_tolerates_bloom_detail_failures():
    class FakeBloomClient:
        def get_graph_object_detail(self, *, euid: str) -> dict[str, object]:
            raise BloomClientError(f"not found: {euid}")

    runner = DayInLifeDemoRunner(db=object())
    payloads = [
        {
            "elements": {
                "nodes": [
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-2",
                            "remote_euid": "RUN-2",
                            "name": "demo-run | RUN-2",
                            "type": "generic",
                            "obj_type": "generic",
                        }
                    },
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-ART-2",
                            "remote_euid": "RUN-ART-2",
                            "name": "reads_R2.fastq.gz",
                            "type": "data",
                            "obj_type": "run_artifact",
                        }
                    },
                ],
                "edges": [
                    {
                        "data": {
                            "id": "edge-2",
                            "source": "ext::bloom::SITE-1::RUN-ART-2",
                            "target": "ext::bloom::SITE-1::RUN-2",
                            "relationship_type": "beta_run_artifact",
                        }
                    }
                ],
            }
        }
    ]

    fastq_node_ids, dewey_registered = runner._identify_fastq_nodes(
        payloads,
        bloom_client=FakeBloomClient(),
        run_euid="RUN-2",
        demo_key="demo-run",
    )

    assert fastq_node_ids == ["ext::bloom::SITE-1::RUN-ART-2"]
    assert dewey_registered is False


def test_identify_fastq_nodes_ignores_unrelated_runs():
    class FakeBloomClient:
        def get_graph_object_detail(self, *, euid: str) -> dict[str, object]:
            return {"json_addl": {"properties": {}}}

    runner = DayInLifeDemoRunner(db=object())
    payloads = [
        {
            "elements": {
                "nodes": [
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-CURRENT",
                            "remote_euid": "RUN-CURRENT",
                            "name": "current-demo-run | RUN-CURRENT",
                            "type": "generic",
                            "obj_type": "generic",
                        }
                    },
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-ART-CURRENT",
                            "remote_euid": "RUN-ART-CURRENT",
                            "name": "current-demo_R1.fastq.gz",
                            "type": "data",
                            "obj_type": "run_artifact",
                        }
                    },
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-OLD",
                            "remote_euid": "RUN-OLD",
                            "name": "old-demo-run | RUN-OLD",
                            "type": "generic",
                            "obj_type": "generic",
                        }
                    },
                    {
                        "data": {
                            "id": "ext::bloom::SITE-1::RUN-ART-OLD",
                            "remote_euid": "RUN-ART-OLD",
                            "name": "old-demo_R1.fastq.gz",
                            "type": "data",
                            "obj_type": "run_artifact",
                        }
                    },
                ],
                "edges": [
                    {
                        "data": {
                            "id": "edge-current",
                            "source": "ext::bloom::SITE-1::RUN-ART-CURRENT",
                            "target": "ext::bloom::SITE-1::RUN-CURRENT",
                            "relationship_type": "beta_run_artifact",
                        }
                    },
                    {
                        "data": {
                            "id": "edge-old",
                            "source": "ext::bloom::SITE-1::RUN-ART-OLD",
                            "target": "ext::bloom::SITE-1::RUN-OLD",
                            "relationship_type": "beta_run_artifact",
                        }
                    },
                ],
            }
        }
    ]

    fastq_node_ids, dewey_registered = runner._identify_fastq_nodes(
        payloads,
        bloom_client=FakeBloomClient(),
        run_euid="RUN-CURRENT",
        demo_key="current-demo",
    )

    assert fastq_node_ids == ["ext::bloom::SITE-1::RUN-ART-CURRENT"]
    assert dewey_registered is False


def test_build_merged_graph_falls_back_to_bloom_client_when_external_ref_lacks_config(
    monkeypatch,
):
    tenant_id = uuid.uuid4()
    namespace_calls: list[tuple[str, int, str, str | None]] = []
    bloom_graph_calls: list[tuple[str, int]] = []

    class FakeGraphViewerService:
        def __init__(self, _db, resolved_tenant_id, *, can_cross_tenant):
            assert resolved_tenant_id == tenant_id
            assert can_cross_tenant is False

        def get_graph_data(self, *, start_euid: str, depth: int, requested_tenant_id):
            assert start_euid == "TST-1"
            assert depth == 8
            assert requested_tenant_id is None
            return {
                "elements": {
                    "nodes": [
                        {"data": {"id": "TST-1", "euid": "TST-1", "system": "atlas"}},
                        {"data": {"id": "EXB-1", "euid": "EXB-1", "system": "atlas"}},
                    ],
                    "edges": [
                        {
                            "data": {
                                "id": "edge-local",
                                "source": "TST-1",
                                "target": "EXB-1",
                                "relationship_type": "linked_material",
                            }
                        }
                    ],
                },
                "meta": {"start_euid": "TST-1"},
            }

        def get_object_detail(self, *, euid: str, requested_tenant_id):
            assert requested_tenant_id is None
            if euid == "TST-1":
                return {"external_refs": []}
            if euid == "EXB-1":
                return {
                    "external_refs": [
                        {
                            "label": "EXB-1 | bloom | RUN-1",
                            "system": "bloom",
                            "root_euid": "RUN-1",
                            "external_object_id": "EXB-1",
                            "tenant_id": None,
                            "href": None,
                            "graph_expandable": False,
                            "ref_index": 0,
                            "reason": "Missing Bloom graph metadata: bloom config",
                        }
                    ]
                }
            raise AssertionError(f"unexpected euid: {euid}")

        def _namespace_external_graph(self, payload, *, ref, ref_index: int, source_euid: str):
            namespace_calls.append((ref.root_euid, ref_index, source_euid, ref.tenant_id))
            assert source_euid == "EXB-1"
            assert ref.system == "bloom"
            assert ref.root_euid == "RUN-1"
            assert ref.tenant_id == "SITE-1"
            assert ref.href == "https://localhost:8912/euid_details?euid=RUN-1"
            assert ref.graph_expandable is True
            assert ref.reason is None
            return {
                "elements": {
                    "nodes": [
                        {
                            "data": {
                                "id": "ext::bloom::SITE-1::RUN-1",
                                "remote_euid": "RUN-1",
                                "name": "demo-run | RUN-1",
                                "type": "generic",
                                "obj_type": "generic",
                                "system": "bloom",
                                "href": "https://localhost:8912/euid_details?euid=RUN-1",
                            }
                        },
                        {
                            "data": {
                                "id": "ext::bloom::SITE-1::RUN-ART-1",
                                "remote_euid": "RUN-ART-1",
                                "name": "demo-run_R1.fastq.gz",
                                "type": "data",
                                "obj_type": "run_artifact",
                                "system": "bloom",
                                "href": "https://localhost:8912/euid_details?euid=RUN-ART-1",
                            }
                        },
                    ],
                    "edges": [
                        {
                            "data": {
                                "id": "bridge::EXB-1::bloom::SITE-1::RUN-1",
                                "source": "EXB-1",
                                "target": "ext::bloom::SITE-1::RUN-1",
                                "relationship_type": "external_reference",
                            }
                        },
                        {
                            "data": {
                                "id": "edge-run-artifact",
                                "source": "ext::bloom::SITE-1::RUN-ART-1",
                                "target": "ext::bloom::SITE-1::RUN-1",
                                "relationship_type": "beta_run_artifact",
                            }
                        },
                    ],
                },
                "meta": {"system": "bloom", "tenant_id": "SITE-1"},
            }

    class FakeBloomClient:
        def get_graph_data(self, *, start_euid: str, depth: int) -> dict[str, object]:
            bloom_graph_calls.append((start_euid, depth))
            assert start_euid == "RUN-1"
            assert depth == 8
            return {
                "elements": {
                    "nodes": [
                        {"data": {"id": "RUN-1", "euid": "RUN-1"}},
                        {"data": {"id": "RUN-ART-1", "euid": "RUN-ART-1"}},
                    ],
                    "edges": [
                        {
                            "data": {
                                "id": "edge-run-artifact",
                                "source": "RUN-ART-1",
                                "target": "RUN-1",
                                "relationship_type": "beta_run_artifact",
                            }
                        }
                    ],
                }
            }

        def get_graph_object_detail(self, *, euid: str) -> dict[str, object]:
            assert euid == "RUN-ART-1"
            return {"json_addl": {"properties": {}}}

    monkeypatch.setattr(day_in_life_demo, "GraphViewerService", FakeGraphViewerService)

    runner = DayInLifeDemoRunner(db=object())
    merged_graph, graph_meta = runner._build_merged_graph(
        tenant_id=tenant_id,
        test_euid="TST-1",
        run_euid="RUN-1",
        demo_key="demo-run",
        bloom_client=FakeBloomClient(),
        site_euid="SITE-1",
        bloom_base_url="https://localhost:8912",
    )

    node_ids = {node["data"]["id"] for node in merged_graph["elements"]["nodes"]}

    assert bloom_graph_calls == [("RUN-1", 8)]
    assert namespace_calls == [("RUN-1", 0, "EXB-1", "SITE-1")]
    assert "ext::bloom::SITE-1::RUN-1" in node_ids
    assert "ext::bloom::SITE-1::RUN-ART-1" in node_ids
    assert graph_meta["external_graph_count"] == 1
    assert graph_meta["fastq_node_ids"] == ["ext::bloom::SITE-1::RUN-ART-1"]
    assert graph_meta["dewey_registered"] is False


def test_build_atlas_context_elements_adds_context_chain():
    manifest = {
        "patient": {"euid": "PAT-1T", "name": "Jane Doe"},
        "clinician": {"euid": "CNP-1H", "name": "Jeff Ma"},
        "site": {"euid": "STX-1K", "name": "LSMC Main Site"},
        "organization": {"euid": "RGX-18", "name": "LSMC"},
        "atlas": {
            "trf": {"euid": "TRF-22"},
            "test_fulfillment_item": {"euid": "TFM-2G"},
            "collection_event": {"euid": "CEV-2S"},
        },
    }

    nodes, edges = build_atlas_context_elements(manifest)

    node_ids = {node["data"]["id"] for node in nodes}
    edge_ids = {edge["data"]["id"] for edge in edges}

    assert {"PAT-1T", "CNP-1H", "STX-1K", "RGX-18"} <= node_ids
    assert "context-edge::RGX-18::contains_site::STX-1K" in edge_ids
    assert "context-edge::STX-1K::ordering_site::TRF-22" in edge_ids
    assert "context-edge::CNP-1H::ordering_clinician::TRF-22" in edge_ids
    assert "context-edge::PAT-1T::patient_subject::TFM-2G" not in edge_ids
    assert "context-edge::PAT-1T::collected_from_patient::CEV-2S" not in edge_ids
    node_by_id = {node["data"]["id"]: node["data"] for node in nodes}
    assert node_by_id["PAT-1T"]["href"] == "/patients/PAT-1T"
    assert node_by_id["STX-1K"]["href"] == "/admin/sites/STX-1K"


def test_build_day_in_life_story_graph_keeps_canonical_story_shape():
    merged_graph = {
        "elements": {
            "nodes": [
                {
                    "data": {
                        "id": "RGX-18",
                        "system": "atlas",
                        "href": "/admin/organizations/RGX-18",
                    }
                },
                {"data": {"id": "STX-2H", "system": "atlas", "href": "/admin/sites/STX-2H"}},
                {"data": {"id": "CNP-1H", "system": "atlas", "href": "/clinicians/CNP-1H"}},
                {"data": {"id": "PAT-1T", "system": "atlas", "href": "/patients/PAT-1T"}},
                {"data": {"id": "TRF-14", "system": "atlas", "href": "/trfs/TRF-14"}},
                {"data": {"id": "TST-1Q", "system": "atlas", "href": "/trfs/tests/TST-1Q"}},
                {"data": {"id": "SHP-1C", "system": "atlas", "href": "/tapdb/object/SHP-1C"}},
                {"data": {"id": "TKT-13", "system": "atlas", "href": "/tapdb/object/TKT-13"}},
                {"data": {"id": "CEV-1V", "system": "atlas", "href": "/collection-events/CEV-1V"}},
                {"data": {"id": "EXB-1A", "system": "atlas", "href": "/tapdb/object/EXB-1A"}},
                {"data": {"id": "EXB-28", "system": "atlas", "href": "/tapdb/object/EXB-28"}},
                {"data": {"id": "TFM-1J", "system": "atlas", "href": "/tapdb/object/TFM-1J"}},
                {"data": {"id": "DCM-15", "system": "atlas", "href": "/tapdb/object/DCM-15"}},
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-19",
                        "system": "bloom",
                        "remote_euid": "CX-19",
                        "href": "https://localhost:8912/euid_details?euid=CX-19",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-1R",
                        "system": "bloom",
                        "remote_euid": "MX-1R",
                        "href": "https://localhost:8912/euid_details?euid=MX-1R",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-2P",
                        "system": "bloom",
                        "remote_euid": "MX-2P",
                        "href": "https://localhost:8912/euid_details?euid=MX-2P",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-27",
                        "system": "bloom",
                        "remote_euid": "CX-27",
                        "href": "https://localhost:8912/euid_details?euid=CX-27",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CWX-1W",
                        "system": "bloom",
                        "remote_euid": "CWX-1W",
                        "href": "https://localhost:8912/euid_details?euid=CWX-1W",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::DAT-G4",
                        "system": "bloom",
                        "remote_euid": "DAT-G4",
                        "href": "https://localhost:8912/euid_details?euid=DAT-G4",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-2S",
                        "system": "bloom",
                        "remote_euid": "MX-2S",
                        "href": "https://localhost:8912/euid_details?euid=MX-2S",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-31",
                        "system": "bloom",
                        "remote_euid": "CX-31",
                        "href": "https://localhost:8912/euid_details?euid=CX-31",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CWX-2A",
                        "system": "bloom",
                        "remote_euid": "CWX-2A",
                        "href": "https://localhost:8912/euid_details?euid=CWX-2A",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::MX-3M",
                        "system": "bloom",
                        "remote_euid": "MX-3M",
                        "href": "https://localhost:8912/euid_details?euid=MX-3M",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::CX-35",
                        "system": "bloom",
                        "remote_euid": "CX-35",
                        "href": "https://localhost:8912/euid_details?euid=CX-35",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::GX-G1",
                        "system": "bloom",
                        "remote_euid": "GX-G1",
                        "href": "https://localhost:8912/euid_details?euid=GX-G1",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::GX-JX",
                        "system": "bloom",
                        "remote_euid": "GX-JX",
                        "href": "https://localhost:8912/euid_details?euid=GX-JX",
                    }
                },
                {
                    "data": {
                        "id": "ext::bloom::STX-2H::GX-KV",
                        "system": "bloom",
                        "remote_euid": "GX-KV",
                        "href": "https://localhost:8912/euid_details?euid=GX-KV",
                    }
                },
            ],
            "edges": [
                {
                    "data": {
                        "id": "raw-extra-1",
                        "source": "TRF-14",
                        "target": "EXB-1A",
                        "relationship_type": "external_relation:belongs_to_trf",
                    }
                },
                {
                    "data": {
                        "id": "raw-extra-2",
                        "source": "PAT-1T",
                        "target": "EXB-28",
                        "relationship_type": "external_relation:belongs_to_patient",
                    }
                },
                {
                    "data": {
                        "id": "raw-extra-3",
                        "source": "TFM-1J",
                        "target": "TST-1Q",
                        "relationship_type": "fulfillment_item",
                    }
                },
            ],
        },
        "meta": {},
    }
    manifest = {
        "patient": {"euid": "PAT-1T"},
        "clinician": {"euid": "CNP-1H"},
        "site": {"euid": "STX-2H"},
        "organization": {"euid": "RGX-18"},
        "atlas": {
            "trf": {"euid": "TRF-14"},
            "test": {"euid": "TST-1Q"},
            "shipment": {"euid": "SHP-1C"},
            "testkit": {"euid": "TKT-13"},
            "collection_event": {"euid": "CEV-1V"},
            "test_fulfillment_item": {"euid": "TFM-1J"},
            "paperwork": {"euid": "DCM-15"},
        },
        "bloom": {
            "container_external_object_id": "EXB-1A",
            "specimen_external_object_id": "EXB-28",
            "container_euid": "CX-19",
            "specimen_euid": "MX-1R",
            "extraction_output_euid": "MX-2P",
            "plate_euid": "CX-27",
            "well_euid": "CWX-1W",
            "library_prep_output_euid": "DAT-G4",
            "library_material_euid": "MX-2S",
            "library_container_euid": "CX-31",
            "library_plate_euid": "CX-31",
            "library_well_euid": "CWX-2A",
            "pool_euid": "MX-3M",
            "pool_container_euid": "CX-35",
            "run_euid": "GX-G1",
        },
        "graph_meta": {
            "fastq_node_ids": [
                "ext::bloom::STX-2H::GX-JX",
                "ext::bloom::STX-2H::GX-KV",
            ]
        },
    }

    story_graph = build_day_in_life_story_graph(merged_graph, manifest=manifest)
    node_ids = {node["data"]["id"] for node in story_graph["elements"]["nodes"]}
    edge_keys = {
        (edge["data"]["source"], edge["data"]["target"], edge["data"]["relationship_type"])
        for edge in story_graph["elements"]["edges"]
    }

    assert "TFM-1J" not in node_ids
    assert "DCM-15" not in node_ids
    assert ("RGX-18", "STX-2H", "contains_site") in edge_keys
    assert ("TRF-14", "TST-1Q", "contains_test") in edge_keys
    assert ("PAT-1T", "TST-1Q", "order_patient") in edge_keys
    assert ("PAT-1T", "CEV-1V", "collection_event") in edge_keys
    assert ("CEV-1V", "TST-1Q", "collected_for_test") in edge_keys
    assert ("TST-1Q", "EXB-1A", "tube_bridge") in edge_keys
    assert ("CEV-1V", "EXB-28", "material_bridge") in edge_keys
    assert ("EXB-28", "EXB-1A", "contained_in") in edge_keys
    assert ("EXB-1A", "ext::bloom::STX-2H::CX-19", "external_reference") in edge_keys
    assert ("EXB-28", "ext::bloom::STX-2H::MX-1R", "external_reference") in edge_keys
    assert (
        "ext::bloom::STX-2H::MX-2P",
        "ext::bloom::STX-2H::MX-2S",
        "content_parent_of",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::MX-2S",
        "ext::bloom::STX-2H::MX-3M",
        "content_parent_of",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::CX-19",
        "ext::bloom::STX-2H::CWX-1W",
        "container_parent_of",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::CWX-1W",
        "ext::bloom::STX-2H::CWX-2A",
        "container_parent_of",
    ) in edge_keys
    assert ("ext::bloom::STX-2H::CX-31", "ext::bloom::STX-2H::CWX-2A", "contains_well") in edge_keys
    assert (
        "ext::bloom::STX-2H::CWX-2A",
        "ext::bloom::STX-2H::CX-35",
        "container_parent_of",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::MX-2P",
        "ext::bloom::STX-2H::DAT-G4",
        "library_prep_output",
    ) in edge_keys
    assert (
        "ext::bloom::STX-2H::DAT-G4",
        "ext::bloom::STX-2H::MX-2S",
        "library_material_output",
    ) in edge_keys
    assert ("ext::bloom::STX-2H::MX-2S", "ext::bloom::STX-2H::CWX-2A", "contained_in") in edge_keys
    assert ("TRF-14", "EXB-1A", "external_relation:belongs_to_trf") not in edge_keys
    assert ("PAT-1T", "EXB-28", "external_relation:belongs_to_patient") not in edge_keys
    assert "ext::bloom::STX-2H::DAT-G4" in node_ids
    assert "ext::bloom::STX-2H::MX-2S" in node_ids
    assert "ext::bloom::STX-2H::CX-31" in node_ids
    assert "ext::bloom::STX-2H::CWX-2A" in node_ids


def test_render_day_in_life_dag_html_includes_layout_controls_and_real_page_links():
    html = render_day_in_life_dag_html(
        title="Day In Life",
        manifest={
            "demo_key": "demo-1",
            "patient": {"name": "Jane Doe"},
            "clinician": {"name": "Jeff Ma"},
            "site": {"name": "Main Site"},
            "organization": {"name": "LSMC"},
            "atlas": {"trf": {"euid": "TRF-1"}, "test": {"euid": "TST-1"}},
            "artifacts": {"live_graph_url": "https://localhost:8915/graph?start_euid=TST-1"},
            "stages": [],
        },
        merged_graph={
            "elements": {
                "nodes": [
                    {
                        "data": {
                            "id": "TST-1",
                            "name": "TST-1",
                            "href": "/trfs/tests/TST-1",
                            "system": "atlas",
                        }
                    }
                ],
                "edges": [],
            }
        },
    )

    assert 'id="layout-select"' in html
    assert '<option value="story">story</option>' in html
    assert '<option value="cose">cose</option>' in html
    assert '<option value="hierarchical">hierarchical</option>' in html
    assert 'const defaultLayoutName = hasStoryPositions ? "story" : "dagre";' in html
    assert 'name: "preset"' in html
    assert "window.location.assign(href)" in html
    assert 'relationship_type = "content_parent_of"' in html
    assert 'relationship_type = "container_parent_of"' in html
    assert "analysis_placeholder" not in html
    assert "result_set_placeholder" not in html


def test_preflight_requires_bloom_service_user_match(monkeypatch):
    tenant_id = uuid.uuid4()
    actor_id = uuid.uuid4()

    monkeypatch.setattr(
        DayInLifeDemoRunner,
        "_check_local_service",
        staticmethod(lambda *_args, **_kwargs: None),
    )

    class FakeUserService:
        def __init__(self, _db):
            pass

        def get_by_email(self, _email):
            return SimpleNamespace(id=actor_id, tenant_id=tenant_id)

    class FakePatientService:
        def __init__(self, _db, _tenant_id, _actor_id=None):
            pass

        def get_by_id(self, euid):
            return SimpleNamespace(euid=euid), SimpleNamespace(first_name="Jane", last_name="Doe")

    class FakeClinicianService:
        def __init__(self, _db, _tenant_id, _actor_id=None):
            pass

        def get_by_id(self, euid):
            return SimpleNamespace(euid=euid), SimpleNamespace(first_name="Jeff", last_name="Ma")

    class FakeSiteService:
        def __init__(self, _db):
            pass

        def get_by_id(self, euid):
            return SimpleNamespace(euid=euid, organization_id="RGX-TEST", name="Default Site")

    class FakeOrganizationService:
        def __init__(self, _db):
            pass

        def get_with_revision(self, org_id):
            assert org_id == "RGX-TEST"
            return SimpleNamespace(euid=org_id), SimpleNamespace(name="Demo Org")

        def get_with_revision_by_uid(self, _tenant_id):
            return None

    class FakeTestDefinitionService:
        def __init__(self, _db):
            pass

        def get_by_code(self, _code):
            return SimpleNamespace(name="ILMN short read", is_active=True)

    class FakeBloomConfigResolverService:
        def __init__(self, _db):
            pass

        def get_effective(self, *, organization_id, site_id):
            assert organization_id == tenant_id
            assert site_id == "STX-1K"
            return SimpleNamespace(
                enabled=True,
                bloom_base_url=DEFAULT_BLOOM_BASE_URL,
                bloom_service_user="someone-else@example.com",
                bloom_api_key_secret_ref="plain:test-token",
            )

    monkeypatch.setattr(day_in_life_demo, "UserService", FakeUserService)
    monkeypatch.setattr(day_in_life_demo, "PatientService", FakePatientService)
    monkeypatch.setattr(day_in_life_demo, "ClinicianService", FakeClinicianService)
    monkeypatch.setattr(day_in_life_demo, "SiteService", FakeSiteService)
    monkeypatch.setattr(day_in_life_demo, "OrganizationService", FakeOrganizationService)
    monkeypatch.setattr(day_in_life_demo, "TestDefinitionService", FakeTestDefinitionService)
    monkeypatch.setattr(
        day_in_life_demo,
        "BloomConfigResolverService",
        FakeBloomConfigResolverService,
    )
    monkeypatch.setattr(day_in_life_demo, "resolve_secret_value", lambda _ref: "blm_test")
    monkeypatch.setattr(day_in_life_demo, "BloomClient", lambda **_kwargs: SimpleNamespace())

    runner = DayInLifeDemoRunner(db=object())
    with pytest.raises(DayInLifeDemoError, match="service user does not match"):
        runner._preflight(DayInLifeDemoConfig(demo_key="demo-preflight"))


def test_run_refreshes_existing_manifest_artifacts(tmp_path, monkeypatch):
    config = DayInLifeDemoConfig(
        demo_key="existing-demo",
        output_root=tmp_path,
        render_screenshot=True,
    )
    runner = DayInLifeDemoRunner(db=object())
    artifacts = runner._artifact_paths(config)
    artifacts.output_dir.mkdir(parents=True, exist_ok=True)
    artifacts.html_path.write_text("<html></html>", encoding="utf-8")
    manifest = {
        "demo_key": "existing-demo",
        "artifacts": {"dag_html_path": str(artifacts.html_path)},
    }
    artifacts.manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

    refresh_calls: list[tuple[dict[str, object], dict[str, object]]] = []
    preflight_payload = {"tenant_id": uuid.uuid4(), "bloom_client": object()}

    monkeypatch.setattr(runner, "_preflight", lambda _config: preflight_payload)

    def _refresh_existing_artifacts(*, manifest, preflight, **_kwargs):
        refresh_calls.append((manifest, preflight))
        return manifest

    monkeypatch.setattr(
        runner,
        "_refresh_existing_artifacts",
        _refresh_existing_artifacts,
    )

    result = runner.run(config)

    assert result.manifest == manifest
    assert refresh_calls == [(manifest, preflight_payload)]
