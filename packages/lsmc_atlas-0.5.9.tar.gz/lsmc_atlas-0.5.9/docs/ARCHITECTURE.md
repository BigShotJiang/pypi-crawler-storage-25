# LSMC Atlas Architecture (TapDB-Only)

## Overview
Atlas is a FastAPI + Jinja/HTMX application that uses TapDB as the sole persistence authority.

## Core Components
- Web/API: FastAPI application in `app/main.py`
- Auth: Cognito + daycog-resolved pool/app configuration
- Persistence: TapDB runtime + TapDB-backed repositories in `app/persistence/tapdb/`
- Domain services: `app/domain/services/`
- UI: server-rendered templates and static assets under `app/web/`

## Persistence Model
- Atlas runtime resolves `DATABASE_URL` from TapDB configuration.
- Domain repositories use TapDB-managed instance/template/lineage/audit primitives.
- Atlas does not own direct DB lifecycle scripts or migration frameworks.

## Runtime Defaults
- `AWS_PROFILE=lsmc`
- `AWS_REGION=us-west-2`
- `TAPDB_DATABASE_NAME=lsmc-atlas`

## Lifecycle Operations
- Atlas-specific overlay build/reset/nuke operations are executed through `atlas db ...`.
- Low-level DB/runtime lifecycle is executed through `tapdb ...`.
- Atlas Cognito diagnostics/bind/import remain in `atlas cognito ...`, but Cognito pool/app/user lifecycle is executed through `daycog ...`.
- No raw local database tooling commands are used by Atlas CLI/runtime.

## Integrations
- Bloom integration endpoints under `/api/integrations/bloom/v1/*`
- Unified search (`/search`, `/api/search/v2/*`) over TapDB sources
- Read-only graph viewer (`/graph`, `/api/graph/*`) over TapDB lineage/object data

## Testing and Guardrails
- Route-surface coverage test ensures API/web routes are covered by tests.
- Cutover guards enforce no reintroduction of removed legacy import patterns.
