# Atlas Tube + Collection Event Hard Cut

Status: implementation plan
Date: 2026-03-08

## Summary

- Atlas will treat specimen tubes as UI and linkage around Bloom-owned `container` objects.
- Atlas will add a new first-class `CollectionEvent` object that is created when an empty tube is filled with a patient specimen.
- Tubes may directly link to any combination of Atlas `Test`, `Shipment`, `TestKit`, and `Organization.site`.
- Bloom remains source of truth for tube and specimen state; Atlas mirrors Bloom via external-object mappings and Atlas-owned collection-event metadata.

## Atlas Changes

- Add a TapDB-backed `CollectionEvent` service and repository shape with:
  - `patient_euid`
  - `site_euid`
  - `collected_at`
  - `collection_type`
  - `collected_by`
  - `expected_mrn`
  - `expected_dob`
  - `expected_name`
  - `expected_label_text`
- Refactor Bloom bridge flows to support:
  - empty tube creation with one or more direct anchors
  - filling an existing empty tube
  - status update for an existing tube
  - link and unlink operations for `Test`, `Shipment`, `TestKit`, and `Site`
- Replace Atlas-local direct specimen-to-patient linkage with:
  - specimen external object -> collection event
  - container external object -> collection event
  - collection event -> patient
- Add Atlas UI surfaces for:
  - shared tube-management panel on test, shipment, test kit, and site pages
  - dedicated tube detail/edit pages
  - collection-event list/detail/edit routes and templates
  - patient detail projection of related collection events

## Bloom Changes

- Extend the Atlas beta lab contract so empty tubes can be created without TRF or process-item context.
- Add support for specimen-side external reference type `atlas_collection_event`.
- Add support for container-side external reference type `atlas_test`.
- Add container patch/update support for status and Atlas direct-link reference changes after creation.
- Add fill flow support for existing empty containers.

## Validation Rules

- Tube create requires at least one direct anchor from `Test`, `Shipment`, `TestKit`, or `Site`.
- Tubes may hold at most one direct link per anchor type.
- Fill requires `patient_euid` and `site_euid`.
- `CollectionEvent.collected_at` defaults to current time when omitted.
- Patient association becomes immutable after fill.
- Direct tube links remain editable after fill.
- Collection-event site may differ from direct tube site and both are shown in Atlas.

## Verification

- Bloom contract tests for empty tube create, fill existing tube, and patching container refs/status.
- Atlas service tests for collection-event creation, tube linking, and context resolution.
- Atlas web tests for shared tube UI, dedicated tube pages, and collection-event CRUD.
- Full DB reset/seed and targeted test runs after implementation.
