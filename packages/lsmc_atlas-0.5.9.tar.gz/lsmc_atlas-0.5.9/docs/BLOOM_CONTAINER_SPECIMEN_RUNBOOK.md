# Bloom Material Intake Runbook

Status: current beta runbook
Date: 2026-03-08

## Purpose

Operational guide for Atlas accepted-material handoff into Bloom.

## Preconditions

- Atlas env active: `source ./activate`
- An enabled Bloom config exists at one of these scopes:
  - organization
  - site
- Site config, when enabled, overrides organization config.
- Bloom secret refs resolve in the runtime environment.

## CLI Checks

- Show organization config:
  - `atlas integrations bloom show-config --org <org-uuid>`
- Show site config:
  - `atlas integrations bloom show-config --site <site-euid>`
- Verify organization config:
  - `atlas integrations bloom verify-config --org <org-uuid>`
- Verify site-effective config:
  - `atlas integrations bloom verify-config --site <site-euid>`

## Beta Flow

1. Create Atlas customer context:
   - patient
   - clinician
   - TRF
   - one or more `TRF.test` children (atomic fulfillment unit)
   - shipment and/or test kit (at least one required; both allowed)
2. Record Atlas intake outcome:
   - `ACCEPTED`
   - `HOLD`
   - `REJECTED`
3. Only `ACCEPTED` material is handed to Bloom.
4. Atlas sends the accepted-material request with an `Idempotency-Key`.
5. Bloom returns container/specimen identity and Atlas stores explicit external links.

## Lookup Checks

- TRF lookup:
  - `GET /api/integrations/bloom/v1/lookups/trfs/{trf_euid}`
- patient lookup:
  - `GET /api/integrations/bloom/v1/lookups/patients/{patient_euid}`
- test kit lookup:
  - `GET /api/integrations/bloom/v1/lookups/testkits/{testkit_euid}`
- container->TRF context lookup:
  - `GET /api/integrations/bloom/v1/lookups/containers/{container_euid}/trf-context`
  - Compatibility: `test_orders` remains available as TRF-wide rollup.
  - Direct-link semantics: `container_test_orders` and `container_test_fulfillment_items` are the authoritative container-linked processing set.

## Polling Fallback

- Run manual polling:
  - `atlas integrations bloom poll-once --org <org-uuid>`
- Atlas dedupes status event ingestion.

## Retry Rules

- Retry accepted-material handoff with the same `Idempotency-Key`.
- `400`, `401`, and `404` require payload/auth/data correction.
- Retryable Bloom failures should be replayed with the same request identity.

## Hard-Cut Notes

- Atlas does not create or own Bloom materials.
- Atlas does not preserve the retired container/specimen ownership model.
- There is no legacy compatibility payload mode.
- `TRF` is rollup context only; operational/fulfillment/reporting decisions are anchored to `TRF.test`.
