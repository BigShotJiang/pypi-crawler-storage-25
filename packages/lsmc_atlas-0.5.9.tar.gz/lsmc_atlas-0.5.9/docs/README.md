# LSMC Atlas Docs

## Current Reference Docs

- [../README.md](../README.md): current repo overview
- [ARCHITECTURE.md](ARCHITECTURE.md): current runtime and persistence architecture
- [atlas_bloom_contract.md](atlas_bloom_contract.md): current Atlas-Bloom integration contract
- [SEARCH_V2.md](SEARCH_V2.md): unified search behavior
- [GRAPH_VIEWER.md](GRAPH_VIEWER.md): graph explorer behavior
- [AUTHENTICATION.md](AUTHENTICATION.md): authentication model
- [TOKEN_SCOPES.md](TOKEN_SCOPES.md): token scopes and permissions

## Historical / Planning Docs

Execution plans, refactor plans, runbooks, and audits remain in this directory for background. They are not the primary source of truth for the current product surface.

When a planning doc disagrees with code or the repo `README.md`, prefer the code and the current reference docs listed above.
