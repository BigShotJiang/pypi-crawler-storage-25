# Atlas Unified Search V2

Atlas now provides a Bloom-patterned unified search interface rooted in TapDB models.

## Endpoints

Canonical:

- `POST /api/search/v2/query`
- `POST /api/search/v2/export`

Compatibility aliases (deprecated):

- `POST /api/v1/search/v2/query`
- `POST /api/v1/search/v2/export`

Alias responses include:

- `Deprecation: true`
- `Sunset: Wed, 30 Sep 2026 00:00:00 GMT`
- `Link: </api/search/v2/...>; rel="successor-version"`

## GUI

- `/search` is the unified search page for authenticated users.
- Existing workflow-local search endpoints remain active in this release.

## Scope Coverage

V2 supports mixed-result search over:

- `instance` (`generic_instance`)
- `template` (`generic_template`)
- `lineage` (`generic_instance_lineage`)
- `audit` (`audit_log`)

Results are normalized into one list with facets:

- `facets.instance`
- `facets.template`
- `facets.lineage`
- `facets.audit`

## Request Schema (`/query`)

```json
{
  "q": "optional string, max 256",
  "scopes": ["instance", "template", "lineage", "audit"],
  "page": 1,
  "page_size": 25,
  "sort_field": "created_at",
  "sort_dir": "desc",
  "include_deleted": false,
  "property_filters": [
    {"path": "properties.status", "op": "eq", "value": "ACTIVE"}
  ]
}
```

Rules:

- `scopes` defaults to all scopes.
- `page` range: `1..200`
- `page_size` range: `1..100`
- `sort_field`: `created_at | modified_at | name | euid`
- `sort_dir`: `asc | desc`
- `property_filters[].op`: `eq | neq | contains | in | exists | gte | lte`
- `property_filters[].path` uses dot notation, max depth 5, `[A-Za-z0-9_]` path segments only.

## Response Schema (`/query`)

```json
{
  "items": [
    {
      "record_type": "instance",
      "source_kind": "tapdb.generic_instance",
      "uuid": "123",
      "euid": "PAT-1",
      "name": "Jane Doe",
      "created_at": "2026-03-02T10:00:00+00:00",
      "modified_at": "2026-03-02T10:05:00+00:00",
      "category": "atlas",
      "type": "people",
      "subtype": "patient",
      "version": "1.0",
      "is_deleted": false,
      "metadata": {}
    }
  ],
  "facets": {"instance": 1, "template": 0, "lineage": 0, "audit": 0},
  "total": 1,
  "page": 1,
  "page_size": 25,
  "has_more": false,
  "timing_ms": 8
}
```

## Export

`POST /api/search/v2/export` accepts query payload plus:

- `format`: `json | tsv`
- `max_rows`: default `1000`, hard cap `10000`

JSON export response:

- `items`
- `row_count`
- `timing_ms`
- `truncated`

TSV export response:

- `text/tab-separated-values`
- `Content-Disposition` filename header
- `X-Row-Count`
- `X-Truncated`
- `X-Timing-Ms`

## Tenant Scoping

- Non-cross-tenant users are tenant-scoped in `instance`, `lineage`, and `audit`.
- Users with `cross_tenant:read` can search across tenants.
- `template` scope is global.

## Performance and Safety Guardrails

- Bounded request payloads and pagination.
- Hard export cap.
- Deterministic sorting with stable tie-breakers.
- Invalid property filter paths/operators are rejected with `422`.
- Scope query failures degrade to empty results for that scope instead of returning a `500`.
