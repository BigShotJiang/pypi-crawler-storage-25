# GUI Object Matrix Execution Plan

## Scope
- Repository: `lsmc-atlas` under `/Users/jmajor/projects/lims3`.
- Goal: Add one integration-style GUI test that creates one record for each GUI-creatable object type and verifies persistence via service-layer reads.

## Steps
1. Add `tests/test_gui_object_creation_matrix.py`.
2. Reuse the web-test dependency override pattern (`get_db`, authenticated user deps, CSRF bypass).
3. Seed a tenant fixture using `ensure_tapdb_org` so all tenant-scoped routes have valid org context.
4. Execute create flows through GUI POST routes for:
   - Organization (with required initial site), Site, User, Assay
   - Patient, Clinician, TRF, Test Kit, Shipment, Family
   - Support Ticket, API Client, Webhook Subscription, Results Package
5. For each flow, assert persistence using the corresponding domain service.
6. Run targeted test module, then full test suite.

## Constraints
- Keep all operations rooted in `/Users/jmajor/projects/lims3/lsmc-atlas`.
- Do not add migrations or alter public API contracts.
