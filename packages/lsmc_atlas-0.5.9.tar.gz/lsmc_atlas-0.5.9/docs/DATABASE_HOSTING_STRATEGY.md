# Atlas Database Hosting Strategy (TapDB-Only)

## Decision
Atlas is TapDB-first and TapDB-only for runtime persistence operations.

## Runtime Modes
- Local development: TapDB `dev` runtime
- Cloud runtime: TapDB `prod` runtime targets through TapDB-managed infrastructure

## Operational Commands
Use Atlas for Atlas-specific overlay operations and TapDB directly for shared runtime lifecycle:
- `atlas db build --target local`
- `atlas db reset --target local`
- `atlas db nuke --target local`
- `tapdb ...`

## Defaults
- AWS profile: `lsmc`
- AWS region: `us-west-2`
- TapDB namespace: `lsmc-atlas`

## Non-Goals
- Atlas does not own direct database lifecycle scripts.
- Atlas does not manage migration frameworks for a separate legacy schema.

## Compliance Guard
The repository includes cutover guard tests to prevent reintroduction of removed legacy import and migration patterns.
