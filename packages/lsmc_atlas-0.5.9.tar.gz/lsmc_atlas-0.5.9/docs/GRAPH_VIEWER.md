# Atlas Graph Viewer V1

Atlas now includes a read-only lineage/object graph explorer rooted in TapDB data.

## Routes

- Web:
  - `GET /graph`
  - `GET /dag` (307 redirect alias to `/graph`, query params preserved)
- API:
  - `GET /api/graph/data`
  - `GET /api/graph/object/{euid}`

## Access Model

- All graph routes require authenticated Atlas user context.
- Tenant-scoped by default (`current_user.tenant_id`).
- Cross-tenant queries require `cross_tenant:read` and explicit `tenant_id` query param.

## API Contracts

### `GET /api/graph/data`

Query params:

- `start_euid` (optional)
- `depth` (default `4`, min `1`, max `10`)
- `tenant_id` (optional UUID, only for cross-tenant users)

Response shape:

```json
{
  "elements": {
    "nodes": [{"data": {"id": "AX123", "euid": "AX123", "name": "..."}}],
    "edges": [{"data": {"id": "LX123", "source": "CHILD", "target": "PARENT"}}]
  },
  "meta": {
    "start_euid": "AX123",
    "depth": 4,
    "tenant_id": "...",
    "node_count": 120,
    "edge_count": 210,
    "truncated": false
  }
}
```

Behavior:

- Directionality is `child -> parent`.
- Unknown or out-of-scope `start_euid` returns empty graph with `200`.
- Deleted records are excluded.
- Payload caps are enforced by settings with `meta.truncated=true` when hit.

### `GET /api/graph/object/{euid}`

Query params:

- `tenant_id` (optional UUID, same rules as above)

Returns object detail for visible `instance`, `template`, or `lineage` records.
For lineage, payload includes `source`, `target`, and `relationship_type`.

Error semantics:

- `401`: unauthenticated
- `403`: cross-tenant access denied
- `404`: object not found in visible tenant scope
- `422`: invalid query params

## Viewer UX

- Layouts: `dagre`, `cose`, `breadthfirst`, `circle`, `grid`
- Triple-left-click node: child-wave highlight
- Triple-right-click node: parent-wave highlight
- Side panel shows rich detail payload and `json_addl`
- Read-only mode: no create/delete lineage/object actions

## Configuration

The following keys are available under `external` in Atlas config:

- `graph_default_depth` (default `4`)
- `graph_max_depth` (default `10`)
- `graph_max_nodes` (default `500`)
- `graph_max_edges` (default `2000`)

## Troubleshooting

- Empty graph with known EUID:
  - verify tenant scope and `tenant_id` selection
  - confirm object is not deleted
  - confirm object has tenant metadata in TapDB `json_addl`
- `403` on cross-tenant query:
  - user token/session lacks `cross_tenant:read`
- Graph appears partial:
  - check `meta.truncated` and raise `graph_max_nodes`/`graph_max_edges` if needed
