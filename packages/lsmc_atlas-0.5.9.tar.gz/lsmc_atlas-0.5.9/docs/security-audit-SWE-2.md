# Security Audit — LSMC Atlas (SWE-2)

**Branch:** SWE-2/address-infosec-findings
**Linear Ticket:** SWE-2
**Date:** 2026-02-28
**Scope:** Full codebase security review — authentication, authorization, input validation, session management, SSRF, open redirects, XSS, injection, tenant isolation, logging.

---

## Original Findings Assessment (SEC-40 through SEC-56)

Assessment of SEC-40 through SEC-56 findings. Verdict for each: **FIX** (true gap), **ACCEPT** (acknowledged risk, not worth fixing now), or **PUSH BACK** (finding is inaccurate or overstated).

---

### HIGH Severity

#### SEC-40 — CSRF Bypass via Bearer Header Prefix
**Finding:** `csrf_protect()` skips CSRF when `Authorization: Bearer` is present. Attacker could add `Bearer xxx` to bypass CSRF while session cookie still authenticates.
**Code reality:** Confirmed at `middleware.py:84`. The skip is `startswith("Bearer ")` — any value works.
**Mitigations already in place:**
- `SameSite=Lax` cookie blocks cross-origin POST (the main CSRF vector)
- `HttpOnly` prevents JS cookie theft
- The CSRF bypass only matters if an attacker can make a cross-origin POST that also sets a custom `Authorization` header — browsers block custom headers on cross-origin requests unless CORS preflight allows it, and Atlas has no permissive CORS policy.
**Verdict: ⚠️ PUSH BACK (partial).** The `SameSite=Lax` + no permissive CORS makes this unexploitable in modern browsers. The suggested fix (restrict to `Bearer lsmc_`) is trivial and worth doing, but the CVSS 7.1 is overstated. Real risk is ~LOW. Fix it anyway since it's a one-liner.

---

#### SEC-41 — Timing-Unsafe API Key Comparison + Default Key
**Finding:** Internal API key uses `!=` comparison (timing leak) and defaults to `"dev-internal-key"`.
**Code reality:** Confirmed at `internal.py:32` and `settings.py:251`.
**Assessment:**
- **Timing attack:** Theoretically real but practically very hard to exploit over a network (noise dwarfs signal). Still, `hmac.compare_digest` is trivial to add — no reason not to.
- **Default key:** This is the real concern. If someone deploys without setting `INTERNAL_API_KEY`, the internal endpoints (artifact push, status updates, release creation) are wide open. This gates LIMS-to-Atlas communication.
**Verdict: ✅ FIX.** The default key is a genuine deployment risk. The timing attack is theoretical but the fix is free. Both should be addressed.

---

#### SEC-42 — Rate Limit Bypass via X-Forwarded-For Spoofing
**Finding:** `get_client_ip()` trusts `X-Forwarded-For` from any client.
**Code reality:** Confirmed at `rate_limiting.py:155-163`.
**Verdict: ⚠️ PUSH BACK (partial).** Standard for apps behind a proxy. Document that Atlas MUST be behind a trusted proxy. CVSS 7.5 assumes direct exposure.

---

#### SEC-43 — Unrestricted File Upload Size
**Finding:** `await file.read()` with no size limit at `documents.py:135`.
**Verdict: ✅ FIX.** Genuine DoS vector. Easy remediation with chunked reading + size cap.

---

### MEDIUM Severity

#### SEC-44 — Session Persistence After Account Changes
**Finding:** Sessions are never re-validated against the DB; a deactivated user stays logged in until session expires.
**Code reality:** Confirmed at `dependencies.py:100-129`.
**Verdict: ✅ FIX (lower priority).** Add periodic DB re-check (e.g., every 5 minutes via session timestamp).

---

#### SEC-45 — Dead Entity-Level Permission System
**Finding:** `permissions.py` imports `role_has_permission` from `rbac.py` which doesn't exist.
**Verdict: ✅ FIX.** Broken dead code. Either complete it properly or remove it.

---

#### SEC-46 — CSRF Validation Gap for Multipart Forms
**Verdict: ⚠️ PUSH BACK.** SameSite=Lax + HTMX headers = protected. Not practically exploitable.

---

#### SEC-47 — Missing Security Headers
**Finding:** No `X-Frame-Options`, `CSP`, `HSTS`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy`.
**Verdict: ✅ FIX.** Standard best practice for CLIA/CAP/HIPAA context.

---

#### SEC-48 — Path Traversal in Document S3 Keys
**Verdict: ⚠️ PUSH BACK.** S3 is not a filesystem. Path traversal doesn't apply.

---

### LOW Severity

#### SEC-49 — Role Name Leakage in 403 Responses
**Verdict: ⚠️ PUSH BACK.** Finding is factually wrong — leaks required roles (API contract), not user roles.

#### SEC-50 — Write Amplification on Token Last-Used Updates
**Verdict: ⚠️ PUSH BACK.** Performance issue, not security.

#### SEC-51 — OAuth State Parameter Logged
**Verdict: ✅ ACCEPT.** Fix opportunistically.

#### SEC-52 — Unvalidated entity_type in Document Routes
**Verdict: ✅ FIX (low priority).** Add enum validation.

#### SEC-53 — Hardcoded Database Credentials in Bootstrap Script
**Verdict: ⚠️ PUSH BACK.** Dev-only script, standard practice.

#### SEC-54 — Email Addresses Logged at INFO Level
**Verdict: ✅ ACCEPT.** Address via log retention policies.

#### SEC-55 — Verbose Error Logging with exc_info=True
**Verdict: ⚠️ PUSH BACK.** Normal logging practice.

#### SEC-56 — API Key Hash-Before-Compare Pattern (INFORMATIONAL)
**Verdict: ✅ No action needed.** Positive observation.

---

## Independent Security Assessment — Additional Findings

Comprehensive code review independent of the SEC-40–56 tickets.

---

### NEW-1 — Open Redirect in Patient/Clinician Creation (MEDIUM)
**Location:** `app/web/routes/pages.py` lines 2012, 2043 (patient) and 2316, 2336 (clinician)
**Issue:** `redirect_url` from form data used in `RedirectResponse` without validation.
**Fix:** Validate redirect_url starts with `/`, reject absolute URLs and `//`.

---

### NEW-2 — Admin Settings Page Missing Admin Check (LOW-MEDIUM)
**Location:** `app/web/routes/pages.py` lines 5713-5718
**Issue:** `/admin/settings` uses `get_current_user_web` instead of `require_admin`.
**Fix:** Change to `Depends(require_admin)`.

---

### NEW-3 — SSRF in Webhook Delivery (MEDIUM)
**Location:** `app/domain/services/webhooks.py` — `WebhookService.deliver_event`
**Issue:** No validation of webhook URLs against private/internal IP ranges.
**Fix:** Validate URLs against RFC 1918/link-local/loopback. Require HTTPS in production.

---

### NEW-4 — Sensitive OAuth State Logged (LOW — overlaps SEC-51)
**Location:** `app/api/routes/auth.py` lines 180-188
**Fix:** Redact state values in logs.

---

### NEW-5 — No Session Regeneration After Login (LOW — DISMISSED)
**Assessment:** Starlette signed cookies prevent fixation. No action needed.

### NEW-6 — Flash Messages Include User-Controlled Data (INFORMATIONAL — DISMISSED)
**Assessment:** Jinja2 autoescaping prevents XSS. No action needed.

---

## Positive Findings (Things Done Right)

| Area | Assessment |
|------|------------|
| **Tenant Isolation** | Consistently enforced. All domain services take `tenant_id` in constructor and filter queries. |
| **CSRF Protection** | SameSite=Lax cookies + CSRF token middleware + HTMX header injection. Multi-layered. |
| **Session Security** | HttpOnly, Secure (in prod), SameSite=Lax, signed cookies. |
| **API Token Security** | SHA256 hash-before-compare. Tokens never stored in plaintext. |
| **XSS Protection** | Jinja2 autoescaping active. Zero `|safe` filter usage. |
| **SQL Injection** | SQLAlchemy ORM used consistently. Parameterized queries for raw SQL. |
| **Admin Routes** | All admin routes (except `/admin/settings`) properly use `Depends(require_admin)`. |

---

## Consolidated Fix Plan

### Round 1 — Must Fix (10 items)

| # | Source | Issue | Severity | Effort |
|---|--------|-------|----------|--------|
| 1 | SEC-41 | Default internal API key + timing-unsafe comparison | HIGH | Small |
| 2 | SEC-43 | Unrestricted file upload size (DoS) | HIGH | Small |
| 3 | SEC-40 | CSRF Bearer prefix bypass (one-liner) | LOW (overstated) | Trivial |
| 4 | SEC-47 | Missing security headers middleware | MED | Small |
| 5 | SEC-44 | Session re-validation after account changes | MED | Medium |
| 6 | SEC-45 | Dead/broken permission system code | MED | Medium |
| 7 | SEC-52 | Unvalidated entity_type in document routes | LOW | Trivial |
| 8 | NEW-1 | Open redirect in patient/clinician creation | MED | Trivial |
| 9 | NEW-2 | Admin settings page missing admin check | LOW-MED | Trivial |
| 10 | NEW-3 | SSRF in webhook delivery | MED | Small |

### Round 2 — Backlog

| # | Source | Issue | Action |
|---|--------|-------|--------|
| 1 | SEC-51/NEW-4 | OAuth state logged | Redact in next logging cleanup |
| 2 | SEC-42 | X-Forwarded-For trust | Document proxy requirement |
| 3 | SEC-54 | Email PII in logs | Address via log retention policy |

### Dismissed (no action needed)

SEC-46, SEC-48, SEC-49, SEC-50, SEC-53, SEC-55, SEC-56, NEW-5, NEW-6
