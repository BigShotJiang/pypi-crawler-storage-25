# Atlas Site-Scoped Linkage Hard Cutover Execution Plan

## Goal
Refactor Atlas tenant-object linkage so only `Site` and `OrganizationUser` directly link to `Organization`, and all other tenant-scoped creates/updates resolve through a site in the tenant organization.

## Change Groups

1. Shared site resolution contract
- Add shared resolver for tenant-scoped writes.
- Enforce:
  - one-site org: auto-select
  - multi-site org: explicit site required
  - cross-tenant site IDs rejected

2. Domain + persistence linkage updates
- Add `site_id`/`site_euid` semantics to tenant create DTOs and TapDB properties.
- Update create/update services to resolve site linkage before persistence.
- Keep internal `tenant_id` UUID auth boundary unchanged.

3. Web/API surface updates
- Add site selector to tenant object create/edit forms and handlers.
- Keep org and org-user flows org-centric.
- Ensure webhook/API-client EUID routing correctness in web templates/routes.

4. Invariants + fixtures/seed
- Enforce org creation always produces an initial site.
- Enforce org cannot deactivate its last active site.
- Update test fixture helpers and seed overlay to guarantee at least one site per org.

5. Test coverage
- Add site-scope invariant tests for auto-select, explicit multi-site selection, cross-tenant rejection, and last-site guard.
- Update GUI matrix tests to provide explicit site IDs in multi-site scenarios.

## Verification
- Run targeted test slices first for touched services/web routes.
- Run broader suite after targeted fixes.
