# Organization Soft Delete Execution Plan

## Scope
Enable LSMC admins to delete organizations via admin web UI, implemented as TapDB soft delete (`is_deleted=true`) in Atlas.

## Plan
1. Add persistence + service support
- Add `TapdbOrgRepository.soft_delete_org(org_id)` to mark organization instance deleted.
- Add `OrganizationService.soft_delete(org_id)` wrapper.

2. Add admin route
- Add POST route `/admin/organizations/{org_id}/delete` guarded by `require_admin` + CSRF.
- Redirect back to organization list with flash success/error.

3. Wire UI affordances
- Add delete action in admin organization detail page.
- Add delete action per-row in admin organizations list.

4. Tests
- Add CRUD tests:
  - admin can soft-delete an organization and it disappears from admin list + cannot open detail.
  - non-admin cannot call delete route.
- Add smoke POST coverage for `/admin/organizations/{id}/delete`.

5. Verification
- Run `ruff` on modified Python files.
- Run targeted pytest for org management + smoke admin organization routes.
