# API Token Scopes

API tokens in Atlas carry a **scope** that constrains the token's effective
permissions, regardless of the creating user's actual roles. This prevents
over-privileged tokens from being issued.

## Available Scopes

| Scope | Max Effective Role | Tenant Isolation | Description |
|-------|-------------------|------------------|-------------|
| `ext_org` | `EXTERNAL_USER` | Strictly tenant-scoped | For external integrations within one organization |
| `lsmc_internal` | `INTERNAL_USER` | Cross-tenant allowed | For LSMC internal tooling and LIMS integration |
| `atlas_admin` | No constraint | Full access | For system administration scripts |

## Scope Enforcement

When a request authenticates via API token, the function
`_constrain_roles_by_scope()` in `app/auth/dependencies.py` caps the
effective roles:

- **`ext_org`**: Roles are intersected with `EXTERNAL_USER`-level
  permissions. The token can only access resources within the token
  owner's tenant.
- **`lsmc_internal`**: Roles are capped at `INTERNAL_USER` level. The
  token can access cross-tenant data but cannot perform admin actions.
- **`atlas_admin`**: No additional constraints; the token inherits the
  full set of roles assigned to the user.

## Who Can Create Each Scope

| Scope | Required Role to Create |
|-------|------------------------|
| `ext_org` | `EXTERNAL_USER_ADMIN` or `ADMIN` |
| `lsmc_internal` | `INTERNAL_USER` or `ADMIN` |
| `atlas_admin` | `ADMIN` only |

This is enforced by `validate_scope_for_creator()` in
`app/domain/services/user_api_tokens.py`.

## Default Scope

If no scope is specified when creating a token, it defaults to `ext_org`
(the most restrictive scope).

## API Usage

### Create a token with scope

```bash
curl -u "user:password" \
  -X POST \
  -H "Content-Type: application/json" \
  -d '{"name": "My Integration Token", "scope": "ext_org"}' \
  http://localhost:8915/user-tokens
```

### Token scope in responses

The scope is included in all token detail responses:

```json
{
  "id": "...",
  "name": "My Integration Token",
  "scope": "ext_org",
  "created_at": "2026-02-14T12:00:00Z"
}
```

## Security Notes

- Tokens with `ext_org` scope are the only type external org admins can
  create. This prevents privilege escalation through token creation.
- An `EXTERNAL_USER_ADMIN` **cannot** create `lsmc_internal` or
  `atlas_admin` tokens — only `ext_org`.
- Token scope is stored on the token identity row and is immutable after
  creation (append-only model).
- Scope validation happens at both creation time (who can create which
  scope) and authentication time (effective role capping).

