# LSMC Atlas — Manual RBAC Testing Guide

This guide uses `daycog` for Cognito lifecycle and `atlas` for Atlas-local
provisioning. Raw AWS CLI Cognito mutations are no longer the primary operator
path.

## Prerequisites

- `source ../../daylily/daylily-cognito/activate`
- `source ../activate`
- `AWS_PROFILE=lsmc`
- `AWS_REGION=us-west-2`
- shared pool `daylily-ursa-users`
- Atlas running at `https://localhost:8915`

## 1. Ensure Groups

```bash
daycog ensure-group platform-admin --description "Cross-service platform admins"
daycog ensure-group atlas-admin --description "Atlas admins"
daycog ensure-group lsmc-staff --description "Atlas internal staff"
daycog ensure-group lsmc-customers --description "Atlas external users"
daycog ensure-group lsmc-customer-admins --description "Atlas external org admins"
daycog ensure-group lsmc-readonly --description "Atlas read-only users"
```

## 2. Create Users

```bash
daycog add-user test-customer@lsmc.bio --password 'TestUser1!'
daycog add-user test-customer-admin@lsmc.bio --password 'TestUser1!'
daycog add-user test-staff@lsmc.bio --password 'TestUser1!'
daycog add-user test-admin@lsmc.bio --password 'TestUser1!'
daycog add-user test-readonly@lsmc.bio --password 'TestUser1!'

daycog set-password --email test-customer@lsmc.bio --password 'TestUser1!'
daycog set-password --email test-customer-admin@lsmc.bio --password 'TestUser1!'
daycog set-password --email test-staff@lsmc.bio --password 'TestUser1!'
daycog set-password --email test-admin@lsmc.bio --password 'TestUser1!'
daycog set-password --email test-readonly@lsmc.bio --password 'TestUser1!'
```

## 3. Assign Groups

```bash
daycog add-user-to-group --email test-customer@lsmc.bio --group lsmc-customers
daycog add-user-to-group --email test-customer-admin@lsmc.bio --group lsmc-customer-admins
daycog add-user-to-group --email test-staff@lsmc.bio --group lsmc-staff
daycog add-user-to-group --email test-admin@lsmc.bio --group atlas-admin
daycog add-user-to-group --email test-readonly@lsmc.bio --group lsmc-readonly
```

## 4. Provision Atlas-Local Users

Use the Atlas CLI or UI flows to create the matching Atlas-side user/profile
records, org membership, and site membership required for your tenant test
cases. Atlas owns tenant-local user truth; `daycog` owns Cognito identity.

## 5. Login Checks

Use the Atlas Hosted UI login at `https://localhost:8915/login` and verify:

- `test-admin@lsmc.bio` gets full admin access
- `test-staff@lsmc.bio` gets internal staff access
- `test-customer-admin@lsmc.bio` gets external admin access
- `test-customer@lsmc.bio` gets external user access
- `test-readonly@lsmc.bio` is restricted to read-only views

## 6. Role Mapping Reference

| Cognito Group          | Atlas Roles                              |
| ---------------------- | ---------------------------------------- |
| `platform-admin`       | `ADMIN`                                  |
| `atlas-admin`          | `ADMIN`                                  |
| `lsmc-staff`           | `INTERNAL_USER`                          |
| `lsmc-customers`       | `EXTERNAL_USER`                          |
| `lsmc-customer-admins` | `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN`   |
| `lsmc-readonly`        | `READ_ONLY`                              |
