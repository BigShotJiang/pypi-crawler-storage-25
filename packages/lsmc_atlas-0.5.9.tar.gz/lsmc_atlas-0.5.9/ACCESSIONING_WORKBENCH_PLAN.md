# Atlas Accessioning Workbench Plan

## Goal
- Build an Atlas-native accessioning workbench at `/accessioning` for Stage 1 receipt, Stage 2 package processing, and Stage 3 matching/outcomes.
- Keep Atlas as workflow authority and Bloom as the physical-material subsystem.

## Working Decisions
- Default UX is queue mode with a combined-mode toggle on the same page.
- Preferred no-order flow is provisional TRF plus Test creation in Atlas with accession provenance metadata.
- HOLD items remain visible in the workbench and continue to reuse the existing exception queue behavior.
- Persist accession queue/work state in a new TapDB-backed work-item model; reuse existing lineage and link-event patterns for relationships.

## Execution Checklist
- [x] Seed tracked implementation plan in-repo.
- [x] Add TapDB-backed accessioning work-item persistence and queue/state enums.
- [x] Add reusable local entity-link helper service for shipment/kit/document/Test/TRF links.
- [x] Add accessioning orchestration service for receipt, package processing, matching, provisional order creation, and outcome handling.
- [x] Extend shipment revisions with receipt metadata needed by the workbench.
- [x] Extend TRF/Test revisions with accession provenance metadata for provisional orders.
- [x] Generalize logistics containment to support nested shipments, nested kits, and workbench manifest items.
- [x] Add `/accessioning` web routes, HTMX queue partials, and work-item detail workflow.
- [x] Add internal navigation entry for the new workbench without removing existing intake routes.
- [x] Add service tests, web tests, and regression coverage for receipt, processing, matching, no-order, and outcomes.
- [x] Run targeted verification and update this note with any implementation deviations.

## Expected Files
- `app/persistence/tapdb/accessioning.py`
- `app/domain/services/accessioning_workbench.py`
- `app/domain/services/entity_links.py`
- `app/web/routes/accessioning.py`
- `app/web/templates/accessioning/index.html`
- `app/web/templates/accessioning/work_item.html`
- `app/web/templates/accessioning/_queue_list.html`
- `app/web/templates/accessioning/_match_results.html`

## Notes
- Do not break `/intake`, `/intake/exceptions`, `/shipments/{shipment}/receive`, `/shipments/{shipment}/add-specimen`, or current Bloom bridge behavior.
- Keep writes auditable and retry-safe; repeated scans and receipt registration must be no-ops when state is already current.
- Implementation deviation: provisional-order creation now falls back to HOLD automatically when the minimum site/patient/test-route context is missing, rather than raising directly out of the UI flow.
- Implementation note: hand-delivery retries are deduplicated through the accessioning work-item state when no tracking number exists.
- Implementation note: Stage 2 now records explicit label-print placeholders plus tube/package image metadata placeholders on manifest items.
- Implementation note: unlabeled tube registration uses a per-form registration token plus manifest fingerprinting so retry/replay does not create duplicate Bloom containers.
- Implementation note: accessioning search now supports direct DOB lookups in `YYYY-MM-DD` form in addition to the existing MRN/name/TRF/Test/shipment/kit/tube/XID paths.
- Developer note: see `ACCESSIONING_WORKBENCH_README.md`.
- Verification run:
  - `pytest -q tests/test_accessioning_workbench_service.py`
  - `pytest -q tests/test_accessioning_workbench_web.py`
  - `pytest -q tests/test_accessioning_workbench_matching.py`
  - `pytest -q tests/test_intake_outcomes.py`
  - `pytest -q tests/test_bloom_tube_kit_linking_web.py`
  - `pytest -q tests/test_route_surface_coverage.py`
