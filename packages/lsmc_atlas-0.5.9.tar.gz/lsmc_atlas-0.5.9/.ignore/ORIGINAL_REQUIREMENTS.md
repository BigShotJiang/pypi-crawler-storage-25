
# Prompt First Response

LSMC Customer Portal for Clinical Services

(Requirements specification — exhaustive, tightly worded; no implementation details)

0) Working name

“Portal” is accurate but generic. A name that signals ordering + sample logistics + results + data tends to land best.

Shortlist (recommended):

LSMC Connect — implies integration, status visibility, and bidirectional exchange (orders ↔ results ↔ APIs).

LSMC Submit — strong for ordering + sample submission; weaker for results/data marketplace.

LSMC Exchange — emphasizes secure transfer (orders, manifests, results, data).

LSMC Command — feels operational; good for enterprise collaborators; less patient-friendly.

LSMC Hub — approachable; slightly generic but clear.

I’ll refer to the system as LSMC Connect below (swap later).

1) Purpose, scope, and principles
1.1 Purpose

LSMC Connect is the digital point of entry for clinical sequencing services: it enables authorized submitters to place digital orders, prepare shipments/specimens for reliable matching, and receive reports/data/status with compliance-grade auditability. It also supports LSMC staff intake matching and client APIs for automation.

1.2 Primary outcomes

The system MUST:

Eliminate paper TRFs by default via complete digital requisitions.

Make sample-to-order matching deterministic whenever a scannable UID is present; safe and efficient when it isn’t.

Provide a single, trusted “source of truth” for:

LSMC Order ID

Submitter Order ID (external)

Specimen/container identifiers

Status and expected TAT

Released clinical report(s) and associated deliverables

Provide secure programmatic access (API + webhooks) for enterprise clients.

1.3 Non-goals (explicit)

Replace the internal LIS/LIMS accessioning workflow end-to-end.

Define wet-lab/bioinformatics pipelines.

Serve as the EHR; only capture the subset needed for ordering, identification, billing, and reporting.

1.4 Compliance baseline (what the system MUST solicit/retain)

At minimum, the digital requisition MUST solicit CLIA “test request” elements, including: authorized requester identity, patient identifier, sex + age/DOB, tests ordered, specimen source (when appropriate), and collection date/time (when appropriate).
The system MUST support ≥2 patient identifiers on specimen labeling/identification workflows (and on screen during intake matching), consistent with widely adopted patient safety expectations.
Because LSMC accepts specimens from NYS, workflows SHOULD include controls to ensure NYS-permit/test-approval rules are satisfied for NY-origin specimens.

2) Actors, tenants, and permissions
2.1 Tenancy model

LSMC Connect MUST be multi-tenant:

Client Organization (Tenant): clinic, hospital, biobank, diagnostic company, collaborator network, or other submitter entity.

LSMC Internal: staff and admins.

Data isolation MUST be enforced at tenant boundary, except where LSMC staff need cross-tenant access for operations.

2.2 User types

External

Ordering Provider user (physician/authorized clinician or delegated staff)

Collaborator submitter user (biobank/partner ops)

Billing user (client-side)

Data user (client-side, results/data access)

API user (service account; non-human)

Internal

Intake/Receiving staff

Customer support staff

Billing/RCM staff

Lab operations staff (status updates, exceptions)

Compliance/Audit staff

System admin

Future

Patient user (only where allowed by policy + release rules)

2.3 Role-based access control (RBAC)

RBAC MUST support:

Role assignment at organization level and optionally site/location level.

Fine-grained permissions: create order, edit draft, submit, cancel, view PHI, view reports, download raw data, manage billing, manage users, manage API keys, view audit logs, etc.

“Break-glass” internal access (with justification + elevated audit logging) for urgent operational needs.

2.4 Authentication requirements

MFA MUST be available; MUST be required for internal staff and strongly recommended for external clinical users.

SSO (SAML/OIDC) SHOULD be supported for enterprise clients.

API auth MUST support OAuth2 client credentials or signed API keys; token scoping required.

3) Core concepts and identifiers (the backbone)
3.1 IDs

The system MUST manage and display distinct identifiers:

LSMC Order ID (canonical, immutable)

Submitter Order ID (external reference; optional but strongly recommended)

Specimen ID (expected specimen identity within an order)

Container ID (physical tube/container UID; scannable barcode/QR)

Kit ID (scannable UID for a kit)

Shipment ID (LSMC-side shipment record)

Plate ID (for 96-well plates; scannable)

Manifest ID/version (for uploaded manifests)

3.2 Canonical matching hierarchy (requirements)

When intake staff receive samples, matching MUST follow this precedence:

Deterministic match by scanning Container ID or Specimen ID or LSMC Order ID barcode/QR.

If absent, shipment-scoped match using tracking + ship-from to narrow candidate orders.

If absent, manifest-based match (plate well → order/specimen mapping).

If absent, fuzzy match using patient identifiers + collection metadata, yielding ranked candidates with confidence and requiring human confirmation.

If no safe match: route to Exception Queue.

4) End-to-end lifecycle (high-level, minimal but complete)
4.1 Order lifecycle states (client-visible)

Order MUST expose a concise state model for clients and API consumers:

Draft (not submitted)

Submitted (digital requisition complete; awaiting specimen)

Shipment Planned (optional; shipment record created)

In Transit (optional; tracking present)

Received (package received at LSMC; specimen(s) pending match/acceptance)

Accepted / In Process (specimen matched + accepted into workflow)

On Hold (missing info, labeling issue, or discrepancy)

Completed – Report Ready

Released (report delivered to authorized recipients)

Amended (updated report issued; versioned)

Canceled (client canceled before acceptance) / Rejected (specimen not acceptable)

Internally you can map to richer LIS states, but the portal MUST keep the client state model stable.

4.2 Specimen/container lifecycle (client-visible)

Expected (declared on order)

Labeled (UID assigned; label printed)

Collected (collection time recorded)

Shipped

Received

Matched

Accepted / Rejected

Consumed / Stored / Returned (if applicable)

5) Functional modules (requirements)
5.1 Ordering & digital TRF module

Goal: Replace paper TRFs while remaining compatible with accessioning needs.

Requirements

Provide a guided order wizard with progressive disclosure.

Support single order entry and bulk order entry (CSV upload, API, or manifest-driven).

Support multiple specimens per order (e.g., tumor/normal, longitudinal draws).

Support attachments (path report, clinical notes) with PHI controls.

Generate a digital TRF view and a printable requisition (for exceptional paper workflows).

Capture all CLIA test request elements at minimum.

5.2 Specimen labeling & identifiers module

Goal: Make matching fast, safe, and scan-first.

Requirements

Allow submitter to choose labeling mode per specimen:

LSMC-issued UID (preferred): portal generates Container IDs / Specimen IDs; user prints labels.

Submitter-issued UID: submitter provides external container IDs; portal stores mapping.

No UID (discouraged): fuzzy match required; triggers warnings and higher exception risk.

Label content rules MUST be configurable by product/test and policy, but SHOULD enforce:

At least two patient identifiers on the container label/workflow.

Clear association to LSMC Order ID or Specimen/Container ID.

Provide label print formats (small tube labels; QR/barcode).

Provide “label reprint” with audit trail.

5.3 Shipping, kits, and manifests module

Goal: Tie the physical world to the digital order graph.

Requirements

Create Shipment records with:

ship-from organization/site, ship-to LSMC address, carrier, tracking, ship date

contents summary (kits, containers, plates)

Support 0–* kits per shipment; 0–* specimens per kit.

Support packing slips and manifests:

human-readable packing list

machine-readable manifest (CSV/JSON)

Plate workflow MUST support:

Plate ID + well map

Upload manifest mapping well → (order/specimen/external id)

5.4 Intake matching support module (LSMC staff-facing)

Goal: The “first act” on receipt: match each biospecimen to orders safely and quickly.

Requirements

Provide a Scan & Match screen optimized for speed:

scan Container ID / Specimen ID / Order ID / Kit ID / Plate ID

immediate resolution or candidate list

Provide a ranked candidate match UX for fuzzy matches:

show top candidates with highlighted fields (match/mismatch)

require explicit confirmation

enforce “cannot match” → exception queue

Provide a Create Order from Intake path (for paper TRF exceptions):

capture minimum required requisition fields

attach scanned TRF as document

mark as “entered from paper” for audit and analytics

Provide Exception Queues with reason codes:

missing/invalid identifiers

multiple possible matches

mismatch between tube label and order

missing required clinical/billing data

specimen condition issues (if recorded)

Every link/unlink MUST be audited (who/when/why).

5.5 Results & deliverables module

Goal: Secure delivery of clinical reports and associated artifacts.

Requirements

Support report objects that are:

versioned (original + amendments)

immutable after release (except via amendment workflow)

downloadable (PDF at minimum)

Support release rules:

default release to ordering provider / organization

optional CC recipients

patient release optional and policy-gated

Support optional “data deliverables”:

structured results (JSON)

raw/processed files (FASTQ/BAM/VCF) if offered

Provide “results retrieval” both via UI and API (permission-scoped).

5.6 Status, TAT, and proactive notifications module

Goal: Clients should automate around your operational timeline.

Requirements

Show:

current state

timestamps for key milestones (submitted/received/accepted/released)

estimated completion date (TAT) with confidence/notes

Notification preferences per user/org:

email + in-app notifications

webhook events for API clients

Provide client-visible timeline per order.

5.7 Billing & payer module (optional now, but model it)

Goal: Allow multiple billing models without breaking clinical flow.

Requirements

Billing responsibility MUST be selectable per order:

Bill client org

Bill patient

Bill third party (biobank/sponsor/etc.)

Insurance capture SHOULD support:

payer, member ID, group ID

subscriber relationship

images of card (optional)

prior authorization fields (optional)

Support invoices, payments, and adjustments (at least view/download; payment collection optional).

Billing data MUST be permission-controlled and minimally exposed to non-billing users.

5.8 Support, complaints/praise, and communications module

Requirements

Allow clients to:

open cases (complaint, inquiry, praise)

attach files

message securely about an order

Allow LSMC staff to:

request missing info (structured request types)

track SLA and resolution categories

Link tickets to orders/shipments/specimens.

5.9 Analysis-only products & data management module (optional but aligned)

Goal: If offered, this becomes the storefront + workspace for post-sequencing services.

Requirements

“Catalog” of add-on analyses available to that tenant.

Ability to purchase/request analysis on a dataset/order.

Data retention tier selection (if offered): store duration, access controls.

Clear separation between clinical report vs research/analysis outputs (different disclaimers, visibility, and access).

6) Data capture requirements (digital TRF + beyond)
6.1 Required data groups (minimum clinical order)

These MUST exist for a submitted order, though some fields may be “required if applicable” by test:

A) Requester / authorized person (CLIA)

Requesting authorized person name + identifiers (NPI/license as applicable)

Requesting organization/site

Contact method for urgent/panic communications (where applicable)

B) Patient identification (CLIA)

Patient name OR unique patient identifier

Sex

Age or DOB

C) Test(s) ordered

Test code/name

Priority (routine/stat)

Panel/version (if relevant)

D) Specimen info

Specimen source (when appropriate)

Collection date/time (when appropriate)

Specimen type and container type (for logistics)

E) Additional test-relevant info

Any extra clinical data needed for accurate testing/interpretation, test-specific.

6.2 Strongly recommended fields (to reduce exceptions and rework)

Submitter Order ID (external)

MRN (if applicable)

Collection site/facility

Diagnosis / ICD-10 (when useful)

Indication / phenotype summary

Tumor type, tissue site, % tumor (if oncology workflows)

Treatment status / key meds (when interpretation sensitive)

Consents/attestations checkbox + signer identity

6.3 Insurance/billing fields (if used)

Bill-to party + billing contact

Insurance payer, member ID, group ID

Subscriber name/DOB/relationship

Prior authorization ID (if applicable)

Self-pay agreement and payment method (if applicable)

6.4 Attachments

Support documents upload with types (path report, LOI, clinical note, consent form, etc.)

Virus scanning, file type restrictions, and retention policy.

7) Page and UI requirements

Design goal: minimal, fast, scan-friendly, enterprise-grade. Visual inspiration SHOULD mirror LSMC’s website: bold headline hierarchy, minimal navigation, monochrome/industrial imagery, and clean layouts.

7.1 Global UI requirements

Responsive (desktop-first for clinical staff; mobile-friendly for status/notifications).

Left nav (app) + top header; avoid deep nesting.

Search always available (Order ID, patient ID, external ID, container ID).

“Status pill” language consistent across UI and API.

“Print” and “Scan” flows are one-click where relevant.

Accessibility: WCAG 2.1 AA (practical minimum).

8) Full page inventory (by role)

Each page lists Purpose → Key components → Actions.

A) External Client Pages (Ordering Providers / Collaborators)
A1) Sign-in

Purpose: secure access.
Components: email/SSO, MFA step, org selection (if multi-tenant user).
Actions: sign in, reset password, MFA enrollment.

A2) Dashboard

Purpose: at-a-glance operations and alerts.
Components:

Orders summary (by state)

Shipments in transit

Holds needing action (missing info)

Recent results released
Actions: create order, create shipment, view holds, download recent reports.

A3) Order list (search + filters)

Purpose: find orders quickly.
Components: search bar; filters (date range, status, test, patient ID, external order ID).
Actions: open order, export list (CSV), bulk actions (cancel drafts, tag).

A4) Create order (wizard)

Purpose: digital TRF capture.
Components (steps):

Requester (provider + site + contacts)

Patient (identifiers)

Test(s)

Specimen plan (expected specimens; labeling mode)

Clinical info (test-specific)

Billing (optional/conditional)

Review & submit (attestation/e-sign)
Actions: save draft, validate completeness, submit, generate labels, generate requisition PDF.

A5) Order detail

Purpose: single source of truth per order.
Components:

Header: LSMC Order ID + External ID + status + estimated completion

Timeline (submitted/received/accepted/released)

Specimens table (expected vs received, container IDs)

Documents (uploaded + generated)

Results section (locked until released)

Messages/tickets
Actions: edit (pre-acceptance), add attachments, add shipment, cancel (rules), download requisition, reprint labels, open support case.

A6) Create shipment

Purpose: bind physical package to digital orders.
Components: ship-from site, carrier, tracking, ship date, contents selector (orders/specimens/kits/plate), packing slip/manifest preview.
Actions: create shipment record, print packing slip, download manifest, mark shipped, update tracking.

A7) Shipments list + shipment detail

Purpose: track transit and contents.
Actions: edit tracking, re-download documents, view received status.

A8) Kits catalog / resupply

Purpose: request collection kits and consumables (as offered).
Components: kit types, quantities, shipping address, order history.
Actions: place resupply order, track kit shipments.

A9) Results list

Purpose: find released reports quickly.
Components: filters by date/test/provider, “released vs amended”.
Actions: download PDF, download structured results (if enabled), view amendment history.

A10) Data delivery (optional tiered)

Purpose: download/manage FASTQ/BAM/VCF and derived outputs.
Components: per-order dataset inventory, checksums, access expiry, usage.
Actions: generate download links, request redelivery, request archive/restore.

A11) Support center

Purpose: reduce email chaos.
Components: tickets list, categories (complaint/praise/question/missing info), knowledge base links.
Actions: open ticket, attach files, comment, close.

A12) Organization settings

Purpose: tenant admin self-service.
Components: sites/addresses, users/roles, default notification settings, default billing settings, external IDs mapping preferences.
Actions: invite user, disable user, set defaults.

A13) API access (for client admins)

Purpose: self-serve integrations.
Components: API clients, scopes, key rotation, webhook config, event logs.
Actions: create/rotate key, configure webhooks, view usage/errors.

B) Patient Pages (future / policy-gated)
B1) Patient invite + identity verification

Purpose: ensure correct patient access.
Actions: accept invite, verify identity, consent to portal terms.

B2) Patient dashboard

Purpose: view orders and next steps.
Actions: see status, instructions, messages.

B3) Patient forms (conditional)

Purpose: insurance, consent, demographics (if you choose).
Actions: upload insurance card, sign consent, pay (if applicable).

B4) Patient results

Purpose: view released reports (only if authorized).
Actions: download report, read explanations/FAQs, request support.

(Recommendation: keep patient access as a separately toggled product feature, with strict release rules.)

C) LSMC Staff Pages (intake + support + admin ops)
C1) Intake: Receive shipment

Purpose: log incoming package and narrow matching scope.
Components: carrier tracking lookup, ship-from selection, package contents count, photos (optional).
Actions: mark received, route to scan/match.

C2) Intake: Scan & Match (core “first act”)

Purpose: link each physical specimen/container to the right order/specimen record.
Components:

scan input (barcode/QR)

auto-resolve panel

candidate matches list (ranked)

discrepancy flags
Actions: link, unlink (permissioned), create order (exception path), send missing-info request, route to exception queue.

C3) Intake: Plate ingest

Purpose: ingest 96-well shipments with manifest.
Components: scan plate ID, upload/verify manifest, well map view.
Actions: accept manifest, auto-link wells, flag conflicts.

C4) Exception queues

Purpose: operational safety net.
Components: queues by reason + SLA age + client org.
Actions: resolve, request info, reject, escalate, annotate.

C5) Paper TRF entry

Purpose: support rare “paper arrives first” scenarios.
Actions: create order, attach scanned TRF, mark as paper-derived, generate LSMC IDs and labels.

C6) Customer support console

Purpose: respond to client needs with full context.
Components: global search, order view, ticket view, templated responses.
Actions: message client, request missing fields, log call notes, update non-clinical fields.

C7) Results release management (high-level)

Purpose: ensure correct delivery rules and audit.
Actions: confirm recipients, release report, issue amendment, revoke mistaken release (policy + audit).

C8) Billing operations (if used)

Purpose: manage payer workflows.
Actions: verify insurance fields, update billing status, post payments, generate invoices.

D) LSMC Admin Pages
D1) Tenant management

Actions: create org, configure contracts, enable modules (kits, data, patient access), set retention and defaults.

D2) Test catalog management

Purpose: define orderable products.
Actions: create/update tests, specimen requirements, required fields, TAT ranges, pricing tiers.

D3) User and role management

Actions: manage internal users, permissions, break-glass policy.

D4) Audit & compliance center

Purpose: CLIA/CAP-grade traceability.
Actions: search audit logs, export access logs, review changes to requisitions, verify report immutability.

D5) System configuration

Actions: label templates, manifest schemas, notification templates, integration settings.

E) API User Experience (UI + programmatic)
E1) API documentation page

Requirements: interactive docs; endpoint list; schemas; examples; event types; error codes.

E2) API keys & scopes

Requirements: rotate keys, restrict scopes, IP allowlists (optional), usage metrics.

E3) Webhooks & event replay

Requirements: configure endpoints, sign payloads, retry policies, event replay, DLQ visibility.

9) Supporting visuals (text-renderable)
9.1 System context
flowchart LR
  subgraph External
    DR[Ordering Provider / Clinic]
    CO[Collaborator / Biobank]
    PT[Patient (future)]
    CS[Client System (API)]
  end

  subgraph LSMC_Connect["LSMC Connect (Customer Portal + API)"]
    UI[Web UI]
    API[REST/GraphQL API]
    WH[Webhooks]
  end

  subgraph Internal
    LIS[LIS/LIMS / Accessioning System]
    OPS[Lab Ops + Bioinformatics]
    REP[Report Signing/Release]
  end

  DR --> UI
  CO --> UI
  PT --> UI
  CS --> API

  UI <--> LIS
  API <--> LIS

  LIS --> OPS --> REP --> LIS
  LIS --> UI
  WH --> CS

9.2 Order → shipment → intake match (the critical seam)
flowchart TD
  A[Order Submitted\n(digital TRF complete)] --> B[UIDs Assigned\n(order/specimen/container)]
  B --> C[Shipment Created\n(tracking + manifest)]
  C --> D[Package Arrives at LSMC]
  D --> E[Scan & Match]
  E -->|UID match| F[Linked + Accepted]
  E -->|Manifest match| F
  E -->|Fuzzy match| G[Candidate List + Confirm]
  G -->|Confirmed| F
  G -->|Not safe| H[Exception Queue]
  H --> I[Resolve: request info / create order / reject]

9.3 Sitemap (high-level)
flowchart LR
  L[Login] --> D[Dashboard]
  D --> O[Orders]
  O --> OC[Create Order]
  O --> OD[Order Detail]
  D --> S[Shipments]
  S --> SC[Create Shipment]
  D --> R[Results]
  D --> K[Kits]
  D --> H[Support]
  D --> A[Account/Org Settings]
  A --> U[Users & Roles]
  A --> P[API & Webhooks]

10) Object model (domain model)
10.1 Entity list (definitions)

Organization

type: clinic, hospital, biobank, partner, internal

addresses/sites

default billing + shipping preferences

enabled modules (kits, raw data, patient access)

User

belongs to organization

roles/permissions

MFA + auth methods

contact info + notification prefs

Provider (Authorized Person)

identity (name)

NPI/license (as applicable)

organization/site affiliations

Patient

identifiers (name, DOB, sex, MRN/external patient ID)

contact info (optional)

guardians (optional)

privacy flags (patient portal enabled?)

Order

LSMC Order ID (immutable)

external order ID (optional)

ordering organization + requester

tests ordered (1..n)

patient reference

clinical info (structured + free text)

billing arrangement

status + timestamps

attachments

OrderTest (line item)

test code/version

priority

specimen requirements

TAT class

SpecimenExpected

belongs to order

specimen type/source

collection metadata (date/time, site)

required attributes (test-specific)

expected container count

Container (Physical)

container ID (barcode/QR)

links to SpecimenExpected (when matched)

label data snapshot (what was on tube at receipt)

received condition flags (optional)

Kit

kit ID

kit type

assigned organization/site

contains 0..n containers

Shipment

shipment ID

carrier + tracking

ship-from org/site

ship-to LSMC

contents: kits/containers/plates

manifests/documents

received timestamp

Plate

plate ID

plate type (96-well etc.)

wells (A1..H12)

associated manifest version

PlateWell

well position

external sample ID

mapped order/specimen/container IDs

Manifest

schema/version

file (document)

parsed rows + validation results

Document

type: requisition PDF, clinical attachment, manifest, insurance image, etc.

storage pointer + checksum

access policy + retention class

Report

report ID + version

order ID

status: draft/signed/released/amended

PDF + optional structured result blob

release recipients + timestamps

DataAsset

order ID

file type (FASTQ/BAM/VCF/etc.)

access controls + expiry

checksums

BillingAccount

bill-to party (org/patient/third party)

invoicing preferences

payments (optional)

InsurancePolicy

payer + member + group

subscriber info

coverage metadata

Ticket (Support Case)

category (complaint/praise/inquiry)

linked order/shipment

messages + status

AuditEvent

actor, timestamp, action, object, before/after (where allowed)

immutable log

ApiClient / WebhookSubscription

keys, scopes, rotation

webhook endpoints + signing secrets

delivery logs

10.2 Relationship diagram (ER)
erDiagram
  ORGANIZATION ||--o{ USER : has
  ORGANIZATION ||--o{ SITE : has
  USER ||--o{ AUDIT_EVENT : generates

  ORGANIZATION ||--o{ ORDER : submits
  PROVIDER ||--o{ ORDER : requests
  PATIENT ||--o{ ORDER : subject_of

  ORDER ||--o{ ORDER_TEST : includes
  ORDER ||--o{ SPECIMEN_EXPECTED : expects
  SPECIMEN_EXPECTED ||--o{ CONTAINER : realized_as

  ORGANIZATION ||--o{ SHIPMENT : sends
  SHIPMENT ||--o{ KIT : contains
  KIT ||--o{ CONTAINER : contains

  SHIPMENT ||--o{ PLATE : may_include
  PLATE ||--o{ PLATE_WELL : has
  MANIFEST ||--o{ PLATE_WELL : maps
  SHIPMENT ||--o{ MANIFEST : includes

  ORDER ||--o{ DOCUMENT : has
  SHIPMENT ||--o{ DOCUMENT : has
  ORDER ||--o{ REPORT : produces
  ORDER ||--o{ DATA_ASSET : produces

  ORDER ||--o{ TICKET : discussed_in
  API_CLIENT ||--o{ WEBHOOK_SUBSCRIPTION : has
  ORGANIZATION ||--o{ API_CLIENT : owns

11) Key validations and exception logic (tight, high-impact)
11.1 Submission-time validation (external)

Block submission if missing CLIA-required requisition elements.

Warn (but allow) if:

no scannable UID assigned

shipment not created

specimen requirements incomplete (test-specific)

11.2 Intake-time validation (internal)

If tube label identifiers conflict with order patient identifiers beyond a configurable threshold → On Hold + Exception.

If multiple candidate matches within close score range → Exception (no auto-match).

If plate manifest fails schema or has duplicate wells/order IDs → reject manifest or partial ingest with explicit review.

11.3 Report release validation

Must confirm authorized recipient set.

Must freeze report version + hash/checksum at release.

Amendments create new immutable version; prior remains accessible with “superseded” label.

12) Security, privacy, audit, and retention requirements

PHI/PII access minimization: default views show only what the role needs.

Comprehensive audit logs for:

order create/submit/edit

specimen matching/linking/unlinking

report release/amendment

downloads of reports/data

admin permission changes

Session security: short-lived tokens, idle timeout, device-aware risk controls.

Export controls: “Export PHI” actions permissioned and logged.

Retention policies configurable by artifact type (order records, reports, raw data, logs).

13) What you may be conflating (and how to keep it clean)

You’re not wrong to bundle these—clients experience it as one surface area—but internally it helps to keep these as modules with crisp boundaries:

Clinical Ordering & Results (core, regulated surface)

Logistics (kits/shipping/manifests) (regulated-adjacent; high operational value)

Data & Add-on Analyses (commercial product surface; different disclaimers/controls)

Support/Billing (shared services)

Key separation rule: clinical reports and release controls must remain pristine even if the data marketplace evolves quickly.

14) “Minimum sleek” starting point (if you were forced to ship fast)

If tonight’s build needs a sharply scoped “phase 1” without painting you into a corner, the tightest set is:

External: Login, Dashboard, Create Order, Order Detail, Orders List, Create Shipment, Shipments List, Results List/Detail, Support

Internal: Receive Shipment, Scan & Match, Exception Queue, Paper TRF Entry (minimal), Customer Support Console

Admin: Tenant + User mgmt, Test Catalog (minimal), Audit Log viewer

API: Order status + results retrieval + webhooks (read-first)

Everything else stays modelled but feature-flagged.


# Original Prompt

Please compile an ehaustive, but tightly worded, specification for a 'client portal' for LSMC's clinical services.  This is the digital point of entry for drs and patients(maybe at some point) who send us biosepimens to sequence .  This is a CLIA/CAP/NYS clinical lab in CA. The captured info will be about the ordering Dr, the test ordered, some amount of clnical information re: the order and patient, the patient info, insurance info?, patient or dr billing info (or ohter third party collaborator like a biobank! in which case, we need to model this as well.

A subset of the data captured in an order will be what would classically be considered a TRF. We are hoping to avoid paper TRFs, but will likley still need a path where if they are received, we enter the order info upon beginning accessioning.

But before anything reaches us, a digital order is expected to be placed.  Then, when the shipping package, containing 0-* kits, containing 0-* biospecimens and any random paperwork... the first act, is to match the patient biospecimen, one at a time to existing orders. Make a link if found, and either create an order and make a link or move to an error queue.  I do not wish to get too into the accessioning process, but want to ask you to produce specifications and minimal, sleek, web UI portal feature/page requirements for Drs, patients, LSMC staff, admins and API users.  Understanding how the next in line system accepts these incoming things is important.

Drs (and collaborator sites, soon patients?) create an order  and enter a bunch of info. in an ideal world, they link the order to a scannable UID on the biospeciment container/tube.  Making the lookup to an order easy.  If this is not done, we must rely on fuzzy matching the data taken of the biospecimen tubes (there must be 3 unique identifiers of the patient: name, dob, gender, MRN, etc.... and match the order system using these data).  In the case of large collaborators, the format of receiving samples might be far nicer, 96well plates with a manifest of well-id to order-id.

Importantly, the order-id allows us to query back to the originator for info (manually or programatically) and our LSMC order-id allows clear communication with customer service, but also if clients want programatic api access to ask for an order: its state, TAT, other high level processing details tha might be useful... or even the client might automate from our api data... say, a day before results are expected they can reach out to preemptively schedule with a patient or something.

The portal might also serve as the results/data delivery interface. Where clients can log in and requeist or download results for orderids.
The might do things like file complaints/ praise
Order resupply of kits, etc

In fact, the portal would be the natural place for our analysis only clnical products to be available as well.  both running new pay-to-play analyses as well as managing their data if they choose to pay us to manage their results / seq data.



I would love to think of a more meaninfgul name than 'portal' to describe this system, more meaningful than 'customer or client portal' these are so overloaded.  Though Customer Portal would be my choice of the 3

SO!  please produce clear, concise, comprehensive requirements document and supporting visuals to describe the ideal system (requirements in this document , not implementation).  Please consider if I am missing any important features or if i am conflating things too much.  Then, please define all of the webpages and actions those pages enable for this customer portal to be fully features (again, not getting into implementation)... include words regarding the look and feel (and draw inspiration for the look and feel from our new website NEW->> https://lsmc.com ), and finally, produce the object model for this system.

with all of these things, I'll review, discuss with you and then we can work on an implementation document to feed to augment to build a portal tonight!

thank you :-)


# My response to the prompt reply

I like LSMC Hub



This portal will not be the UID authority for any data or reports (but ! we will need a containing object for 'data' or 'report' release which has a UID, the same data might be released multiple times unchanged, and i'd want to know about this , and will be assigning package UIDs which may or may not get fedex/ups/other carrier tracking numbers associated by cusotmer or us.

All of these systems should be append only no delete.
On identifiers, the list you have is a great start, two chanes:
BioSpecimenID, not Specimen
TestKitID not Kit ID
PatientID (and relationshipts to family patients)
OrderID and 

I like giving manifests a uid.  A

And,there is going to need to be a lot of others too, right? Patient/Source ID, Clinican ID (metadata like address, specialty, npi...), Ordering ORganization ID, Patient metadata (billing, address,etc)

The status of the 'order' is going to be a rollup of all of the order-
Add to statuses of order:
Abandoned
The 

Specimen will be generated from the LIMS, but for now will live here, add status 'MIA', 'Active'

some changes and an addition to Order object
Order.product_orders = 1-* TestOrder= 1-* Assay (where Assay will live in a product specification owning system eventually.  The funky thing is a kit might contain multiple product orders and the kit contain multiple biospecimens for the patient/source... with some biospecimens only linnked to one product, but possibly some biospecimens linked to multiple products/orders/assays <--- this is one of the harder things to model

Tldr; the shipment-kit-biospecimen-document relationship is that there might be gaps, and things can be inside things. A shipment might contains multiple shipments, and one shipment may just be biospecimens and not kits, another kits with biospeciments. any of these thngs might contain materials from multiple patients, and the order needs to be llined to the right thing so that we can work back to determine paitnet, dr, client, etc

Shipment -> 0* Kits &| 0-* BioSpecimens &| 0-* Documents
Kits -> 0* Biospecimen &| 0-* Documents


OK!!! Lets build a website!!!


hell yeah!  lets create detailed augment implementation instructions.  I want to stick to a simpler vs fancier tech stack. Ideally, similar to my other projects: cognito for auth/user mgmt, fastapi/jinja2 for API and UI, the analysis and analysis data management UI will come from the things being built as part of daylily-ephemeral-cluster, so just assume that is a link out. But i want to build a more comprehensive first attempt than less.  Please look to https://lsmc.com (refresh your cache!!!) for styling inspiration. run on mac and ubuntu...

Please leverage all of the augment code fetures, so .augment/rules/ and so on

go! and thank you
