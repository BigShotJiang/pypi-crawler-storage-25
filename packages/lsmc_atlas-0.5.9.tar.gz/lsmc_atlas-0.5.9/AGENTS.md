# Atlas CLI Policy

## Session Setup

Always start by activating the repo environment:

```bash
source ./activate
```

## Command Ownership

- Use `atlas ...` as the primary interface for normal Atlas work.
- Use `tapdb ...` only when Atlas explicitly delegates low-level DB/runtime lifecycle to TapDB.
- Use `daycog ...` only when Atlas explicitly delegates Cognito lifecycle to Daycog.

## No Circumvention Policy

- Do not bypass `atlas`, `tapdb`, or `daycog` with raw tools just because something is missing or broken.
- Do not treat direct `python -m ...`, raw `postgres`, raw AWS CLI mutations, or direct config-file edits as automatic fallbacks.
- If the intended CLI path is broken or incomplete, stop, diagnose, and ask for permission before circumventing it.
- Prefer patience and repair of the intended CLI workflow over inventing a shortcut.

## Atlas Examples

- Start with `source ./activate`
- Use `atlas db build --target local`
- Use `atlas server start --port 8915`
- Use `atlas cognito import` or `atlas cognito status`
- Use `daycog ...` directly for Cognito pool/app/user lifecycle when Atlas docs or CLI indicate that ownership
