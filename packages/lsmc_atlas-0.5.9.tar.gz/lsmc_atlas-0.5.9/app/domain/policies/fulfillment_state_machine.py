"""
Assay Lifecycle State Machine Policy.

Implements the canonical 10-state assay lifecycle with explicit transitions.
No skipping states. Terminal states cannot transition (except FAILED → AMENDED).
"""

from enum import StrEnum


class FulfillmentRunState(StrEnum):
    """
    Canonical assay lifecycle states (10 states).

    Progression: DRAFT → ORDERED → RECEIVED → ACCESSIONED → IN_PROGRESS → RESULTED/QC_HOLD/FAILED
    Terminal: CANCELLED, FAILED (mostly), AMENDED
    """

    DRAFT = "DRAFT"
    ORDERED = "ORDERED"
    RECEIVED = "RECEIVED"
    ACCESSIONED = "ACCESSIONED"
    IN_PROGRESS = "IN_PROGRESS"
    QC_HOLD = "QC_HOLD"
    FAILED = "FAILED"
    RESULTED = "RESULTED"
    AMENDED = "AMENDED"
    CANCELLED = "CANCELLED"


# Allowed transitions (exact per spec)
# Each key maps to the set of states it can transition TO
ALLOWED_TRANSITIONS: dict[FulfillmentRunState, set[FulfillmentRunState]] = {
    FulfillmentRunState.DRAFT: {FulfillmentRunState.ORDERED, FulfillmentRunState.CANCELLED},
    FulfillmentRunState.ORDERED: {FulfillmentRunState.RECEIVED, FulfillmentRunState.CANCELLED},
    FulfillmentRunState.RECEIVED: {
        FulfillmentRunState.ACCESSIONED,
        FulfillmentRunState.FAILED,
        FulfillmentRunState.CANCELLED,
    },
    FulfillmentRunState.ACCESSIONED: {FulfillmentRunState.IN_PROGRESS, FulfillmentRunState.FAILED},
    FulfillmentRunState.IN_PROGRESS: {
        FulfillmentRunState.RESULTED,
        FulfillmentRunState.QC_HOLD,
        FulfillmentRunState.FAILED,
    },
    FulfillmentRunState.QC_HOLD: {
        FulfillmentRunState.IN_PROGRESS,
        FulfillmentRunState.FAILED,
        FulfillmentRunState.RESULTED,
    },
    FulfillmentRunState.FAILED: {FulfillmentRunState.AMENDED},  # Rare; must record justification
    FulfillmentRunState.RESULTED: {FulfillmentRunState.AMENDED},
    FulfillmentRunState.AMENDED: set(),  # Terminal
    FulfillmentRunState.CANCELLED: set(),  # Terminal
}

# Terminal states (cannot transition out, except FAILED → AMENDED)
TERMINAL_STATES: set[FulfillmentRunState] = {
    FulfillmentRunState.CANCELLED,
    FulfillmentRunState.FAILED,
    FulfillmentRunState.AMENDED,
}

# For order status rollup: these states indicate the assay has "finished"
ORDER_TERMINAL_FOR_ROLLUP: set[FulfillmentRunState] = {
    FulfillmentRunState.RESULTED,
    FulfillmentRunState.AMENDED,
    FulfillmentRunState.CANCELLED,
    FulfillmentRunState.FAILED,
}


class TransitionError(Exception):
    """Raised when an invalid state transition is attempted."""

    def __init__(self, current: FulfillmentRunState, next_state: FulfillmentRunState, reason: str):
        self.current = current
        self.next_state = next_state
        self.reason = reason
        super().__init__(f"Cannot transition from {current.value} to {next_state.value}: {reason}")


def validate_transition(
    current: FulfillmentRunState,
    next_state: FulfillmentRunState,
    *,
    qc_override: bool = False,
) -> None:
    """
    Validate an assay state transition.

    Args:
        current: The current state of the assay.
        next_state: The desired next state.
        qc_override: If True, allows QC_HOLD → RESULTED transition.

    Raises:
        TransitionError: If the transition is not allowed.

    Notes:
        - No skipping states: only explicitly defined edges are allowed.
        - Terminal states (CANCELLED, AMENDED) cannot transition out.
        - FAILED can only transition to AMENDED (rare, requires justification).
        - QC_HOLD → RESULTED requires qc_override=True.
    """
    # Idempotent: same state is always allowed
    if current == next_state:
        return

    # Check if transition is in allowed set
    allowed = ALLOWED_TRANSITIONS.get(current, set())
    if next_state not in allowed:
        if current in TERMINAL_STATES:
            raise TransitionError(current, next_state, f"{current.value} is a terminal state")
        raise TransitionError(
            current,
            next_state,
            f"transition not allowed; valid transitions from {current.value}: {[s.value for s in allowed]}",
        )

    # Special case: QC_HOLD → RESULTED requires explicit override
    if current == FulfillmentRunState.QC_HOLD and next_state == FulfillmentRunState.RESULTED:
        if not qc_override:
            raise TransitionError(
                current,
                next_state,
                "QC_HOLD → RESULTED requires explicit qc_override=True",
            )


class DerivedOrderStatus(StrEnum):
    """
    Derived order status values (computed from assay states).

    These are NOT stored directly on the order; they're computed on read.
    """

    DRAFT = "DRAFT"
    ORDERED = "ORDERED"
    IN_PROGRESS = "IN_PROGRESS"
    QC_HOLD = "QC_HOLD"
    RESULTS_READY = "RESULTS_READY"
    CLOSED_NO_RESULTS = "CLOSED_NO_RESULTS"


def derive_order_status(assay_states: list[FulfillmentRunState]) -> DerivedOrderStatus:
    """
    Compute the derived order status from a list of assay states.

    Priority logic:
    1. If no assays OR all assays DRAFT → DRAFT
    2. If all assays in ORDER_TERMINAL_FOR_ROLLUP:
        - if any in {RESULTED, AMENDED} → RESULTS_READY
        - else → CLOSED_NO_RESULTS
    3. If any QC_HOLD → QC_HOLD
    4. If any in {ACCESSIONED, IN_PROGRESS} → IN_PROGRESS
    5. If any in {ORDERED, RECEIVED} → ORDERED
    6. Else → ORDERED (safe fallback; should be unreachable)

    Args:
        assay_states: List of current assay states for all assays in an order.

    Returns:
        The derived order status.
    """
    # Empty or all DRAFT
    if not assay_states:
        return DerivedOrderStatus.DRAFT

    state_set = set(assay_states)

    # All DRAFT?
    if state_set == {FulfillmentRunState.DRAFT}:
        return DerivedOrderStatus.DRAFT

    # All terminal (for rollup purposes)?
    if state_set.issubset(ORDER_TERMINAL_FOR_ROLLUP):
        # Check if any have results
        has_results = (
            FulfillmentRunState.RESULTED in state_set or FulfillmentRunState.AMENDED in state_set
        )
        if has_results:
            return DerivedOrderStatus.RESULTS_READY
        else:
            return DerivedOrderStatus.CLOSED_NO_RESULTS

    # Any in QC_HOLD?
    if FulfillmentRunState.QC_HOLD in state_set:
        return DerivedOrderStatus.QC_HOLD

    # Any in progress-like states?
    progress_states = {FulfillmentRunState.ACCESSIONED, FulfillmentRunState.IN_PROGRESS}
    if state_set & progress_states:
        return DerivedOrderStatus.IN_PROGRESS

    # Any ordered/received?
    ordered_states = {FulfillmentRunState.ORDERED, FulfillmentRunState.RECEIVED}
    if state_set & ordered_states:
        return DerivedOrderStatus.ORDERED

    # Safe fallback (should be unreachable)
    return DerivedOrderStatus.ORDERED


def is_terminal(state: FulfillmentRunState) -> bool:
    """Check if an assay state is terminal."""
    return state in TERMINAL_STATES


def can_transition(current: FulfillmentRunState, next_state: FulfillmentRunState) -> bool:
    """
    Check if a transition is possible (without raising an exception).

    Note: This does not check qc_override requirement for QC_HOLD → RESULTED.
    """
    if current == next_state:
        return True
    allowed = ALLOWED_TRANSITIONS.get(current, set())
    return next_state in allowed
