"""LSMC Hub - Permission Policies.

Provides tenant-scoped permission checks and role-based access control
for domain entities.
"""

import uuid
from dataclasses import dataclass
from enum import StrEnum

from sqlalchemy.orm import Session

from app.auth.rbac import Permission, Role


class EntityType(StrEnum):
    """Entity types for permission checks."""

    ORDER = "Order"
    TEST_ORDER = "TestOrder"
    PATIENT = "Patient"
    CLINICIAN = "Clinician"
    ORGANIZATION = "Organization"
    SITE = "Site"
    SHIPMENT = "Shipment"
    TEST_KIT = "TestKit"
    RELEASE_PACKAGE = "ReleasePackage"
    ARTIFACT = "Artifact"


@dataclass
class PermissionContext:
    """Context for permission evaluation."""

    user_id: uuid.UUID
    user_tenant_id: uuid.UUID
    user_roles: list[Role]
    is_internal: bool
    entity_type: EntityType | None = None
    entity_id: uuid.UUID | None = None
    entity_tenant_id: uuid.UUID | None = None


def check_tenant_access(ctx: PermissionContext) -> bool:
    """
    Check if user has access to the entity's tenant.

    Rules:
    - Internal users (INTERNAL_USER, ADMIN) can access all tenants
    - External users can only access their own tenant
    """
    if ctx.is_internal:
        return True

    if ctx.entity_tenant_id is None:
        return True  # Entity is not tenant-scoped

    return ctx.user_tenant_id == ctx.entity_tenant_id


def check_permission(ctx: PermissionContext, permission: Permission) -> bool:
    """Check if user has the required permission.

    Combines role-based permission check with tenant access check.

    Note: Currently unused but structurally correct for future use
    by route handlers and middleware that need entity-level permission checks.
    """
    from app.auth.rbac import has_permission

    if not check_tenant_access(ctx):
        return False

    # has_permission expects list[str]; convert Role enums to their string values
    role_strings = [r.value if hasattr(r, "value") else str(r) for r in ctx.user_roles]
    return has_permission(role_strings, permission)


def get_entity_permission_map() -> dict[EntityType, dict[str, Permission]]:
    """Get permission mapping for each entity type and action."""
    return {
        EntityType.ORDER: {
            "create": Permission.ORDER_CREATE,
            "read": Permission.ORDER_READ,
            "update": Permission.ORDER_UPDATE,
            "submit": Permission.ORDER_SUBMIT,
        },
        EntityType.PATIENT: {
            "create": Permission.PATIENT_CREATE,
            "read": Permission.PATIENT_READ,
            "update": Permission.PATIENT_UPDATE,
        },
        EntityType.SHIPMENT: {
            "create": Permission.SHIPMENT_CREATE,
            "read": Permission.SHIPMENT_READ,
            "update": Permission.SHIPMENT_UPDATE,
        },
        EntityType.RELEASE_PACKAGE: {
            "read": Permission.RELEASE_READ,
            "download": Permission.RELEASE_DOWNLOAD,
        },
    }


class PermissionService:
    """Service for permission checks on entities.

    Note: Currently unused but structurally correct for future use
    by route handlers and middleware that need entity-level permission checks.
    """

    def __init__(self, db: Session):
        self.db = db

    def can_access_entity(
        self,
        user_id: uuid.UUID,
        user_tenant_id: uuid.UUID,
        user_roles: list[Role],
        is_internal: bool,
        entity_type: EntityType,
        entity_id: uuid.UUID,
        action: str,
    ) -> bool:
        """Check if user can perform action on entity."""
        # Get entity tenant
        entity_tenant_id = self._get_entity_tenant(entity_type, entity_id)

        ctx = PermissionContext(
            user_id=user_id,
            user_tenant_id=user_tenant_id,
            user_roles=user_roles,
            is_internal=is_internal,
            entity_type=entity_type,
            entity_id=entity_id,
            entity_tenant_id=entity_tenant_id,
        )

        # Get required permission
        perm_map = get_entity_permission_map()
        entity_perms = perm_map.get(entity_type, {})
        required_perm = entity_perms.get(action)

        if not required_perm:
            return False

        return check_permission(ctx, required_perm)

    def filter_by_tenant(
        self,
        user_tenant_id: uuid.UUID,
        is_internal: bool,
        entity_type: EntityType,
    ) -> uuid.UUID | None:
        """
        Get tenant filter for queries.

        Returns tenant_id to filter by, or None if no filter needed (internal users).
        """
        if is_internal:
            return None  # Internal users see all tenants
        return user_tenant_id

    def _get_entity_tenant(
        self,
        entity_type: EntityType,
        entity_id: uuid.UUID,
    ) -> uuid.UUID | None:
        """Get the tenant ID for an entity.

        This policy helper is currently unused in route wiring. During the TapDB
        cutover we no longer perform legacy ORM lookups here.
        """
        if entity_type == EntityType.ORGANIZATION:
            return entity_id

        return None


def require_entity_permission(
    db: Session,
    user_id: uuid.UUID,
    user_tenant_id: uuid.UUID,
    user_roles: list[Role],
    is_internal: bool,
    entity_type: EntityType,
    entity_id: uuid.UUID,
    action: str,
) -> None:
    """Require permission to access an entity.

    Raises PermissionError if access denied.

    Note: Currently unused but structurally correct for future use
    by route handlers that need to gate access to specific entities.
    """
    svc = PermissionService(db)
    if not svc.can_access_entity(
        user_id=user_id,
        user_tenant_id=user_tenant_id,
        user_roles=user_roles,
        is_internal=is_internal,
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
    ):
        raise PermissionError(f"Access denied: cannot {action} {entity_type.value} {entity_id}")
