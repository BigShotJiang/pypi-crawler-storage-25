"""LSMC Hub - Order Status Rollup Policy (TapDB-only runtime)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime

from app.domain.enums import OrderStatus, ReleasePackageStatus
from app.domain.policies.fulfillment_state_machine import (
    DerivedOrderStatus,
    FulfillmentRunState,
    derive_order_status,
)
from app.domain.services.fulfillment_runs import FulfillmentRunService
from app.domain.services.releases import ReleaseService
from app.domain.services.trfs import TrfService


@dataclass
class OrderRollupState:
    """Current state for order rollup computation."""

    order_id: uuid.UUID | str
    current_status: str
    assay_states: list[FulfillmentRunState]
    has_released_package: bool
    last_activity: datetime | None = None


_DERIVED_TO_ORDER_STATUS: dict[DerivedOrderStatus, OrderStatus] = {
    DerivedOrderStatus.DRAFT: OrderStatus.DRAFT,
    DerivedOrderStatus.ORDERED: OrderStatus.ORDERED,
    DerivedOrderStatus.IN_PROGRESS: OrderStatus.IN_PROGRESS,
    DerivedOrderStatus.QC_HOLD: OrderStatus.QC_HOLD,
    DerivedOrderStatus.RESULTS_READY: OrderStatus.RESULTS_READY,
    DerivedOrderStatus.CLOSED_NO_RESULTS: OrderStatus.CLOSED_NO_RESULTS,
}


def compute_order_status(state: OrderRollupState) -> OrderStatus:
    """Compute order status from assay states."""
    if state.current_status == OrderStatus.CANCELED.value:
        return OrderStatus.CANCELED
    if state.current_status == OrderStatus.REJECTED.value:
        return OrderStatus.REJECTED

    derived = derive_order_status(state.assay_states)
    if derived == DerivedOrderStatus.RESULTS_READY and state.has_released_package:
        if state.current_status == OrderStatus.RELEASED.value:
            return OrderStatus.RELEASED
        return OrderStatus.AMENDED

    return _DERIVED_TO_ORDER_STATUS.get(derived, OrderStatus.DRAFT)


class OrderRollupService:
    """Service for computing and updating order status rollups."""

    def __init__(self, db, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id

    @staticmethod
    def _normalize_order_euid(order_id: uuid.UUID | str) -> str:
        return str(order_id)

    def get_rollup_state(self, order_id: uuid.UUID | str) -> OrderRollupState | None:
        """Get current rollup state for an order."""
        order_euid = self._normalize_order_euid(order_id)
        trf_result = TrfService(self.db, self.tenant_id).get_by_id(order_euid, cross_tenant=False)
        if trf_result is None:
            return None
        trf, latest_trf_revision = trf_result
        if latest_trf_revision is None:
            return None

        assay_svc = FulfillmentRunService(self.db, trf.tenant_id)
        assay_states = self._get_assay_states(assay_svc, trf.euid)
        has_released = self._has_released_package(trf.euid, trf.tenant_id)
        last_activity = self._get_last_activity(
            trf.euid, latest_trf_revision.created_at, trf.tenant_id
        )

        return OrderRollupState(
            order_id=trf.euid,
            current_status=latest_trf_revision.status,
            assay_states=assay_states,
            has_released_package=has_released,
            last_activity=last_activity,
        )

    def compute_and_update(
        self,
        order_id: uuid.UUID | str,
        updated_by: uuid.UUID | None = None,
    ) -> OrderStatus | None:
        """Compute rollup status and update order status if changed."""
        state = self.get_rollup_state(order_id)
        if not state:
            return None

        computed_status = compute_order_status(state)
        if computed_status.value != state.current_status:
            TrfService(self.db, self.tenant_id).change_status(
                str(state.order_id),
                computed_status,
                reason="Status rollup: derived from assay states",
                updated_by=updated_by,
            )
        return computed_status

    @staticmethod
    def _get_assay_states(
        assay_svc: FulfillmentRunService, order_euid: str
    ) -> list[FulfillmentRunState]:
        rows = assay_svc.list_for_trf(order_euid)
        states: list[FulfillmentRunState] = []
        for _assay, revision in rows:
            if revision is None:
                continue
            try:
                states.append(FulfillmentRunState(revision.status))
            except ValueError:
                continue
        return states

    def _has_released_package(self, order_euid: str, tenant_id: uuid.UUID) -> bool:
        releases = ReleaseService(self.db, tenant_id).list_packages(
            order_id=order_euid,
            limit=500,
            cross_tenant=False,
        )
        return any(
            (revision is not None and revision.status == ReleasePackageStatus.RELEASED.value)
            for _package, revision in releases
        )

    def _get_last_activity(
        self,
        order_euid: str,
        trf_revision_created_at: datetime | None,
        tenant_id: uuid.UUID,
    ) -> datetime | None:
        candidates: list[datetime] = []
        if trf_revision_created_at:
            candidates.append(trf_revision_created_at)

        assay_rows = FulfillmentRunService(self.db, tenant_id).list_for_trf(order_euid)
        for _assay, revision in assay_rows:
            if revision and revision.created_at:
                candidates.append(revision.created_at)

        for _package, revision in ReleaseService(self.db, tenant_id).list_packages(
            order_id=order_euid,
            limit=500,
            cross_tenant=False,
        ):
            if revision and revision.created_at:
                candidates.append(revision.created_at)

        if not candidates:
            return None
        return max(candidates)
