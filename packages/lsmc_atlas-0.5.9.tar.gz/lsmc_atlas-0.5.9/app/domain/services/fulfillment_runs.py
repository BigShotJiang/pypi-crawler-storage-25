"""Assay workflow services backed by TapDB repositories."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from sqlalchemy.orm import Session

from app.domain.enums import AuditAction, FulfillmentRunState
from app.domain.policies.fulfillment_state_machine import (
    FulfillmentRunState as PolicyFulfillmentRunState,
)
from app.domain.policies.fulfillment_state_machine import (
    TransitionError,
    validate_transition,
)
from app.domain.services.audit import AuditService
from app.domain.services.webhook_emitter import (
    emit_assay_run_status_changed,
    emit_results_set_published,
)
from app.persistence.tapdb.fulfillment_run_repo import (
    TapdbFulfillmentOutputRecord as FulfillmentOutput,
)
from app.persistence.tapdb.fulfillment_run_repo import (
    TapdbFulfillmentRunRecord as FulfillmentRun,
)
from app.persistence.tapdb.fulfillment_run_repo import (
    TapdbFulfillmentRunRepository,
)
from app.persistence.tapdb.fulfillment_run_repo import (
    TapdbFulfillmentRunRevisionRecord as FulfillmentRunRevision,
)
from app.persistence.tapdb.fulfillment_run_repo import (
    TapdbResultsSetAssayRecord as ResultsSetAssay,
)
from app.persistence.tapdb.fulfillment_run_repo import (
    TapdbResultsSetRecord as ResultsSet,
)
from app.persistence.tapdb.trfs import TapdbTrfRepository


class FulfillmentRunError(Exception):
    """Base exception for assay workflow errors."""


class FulfillmentRunNotFoundError(FulfillmentRunError):
    """Raised when an assay run is not found."""


class InvalidTransitionError(FulfillmentRunError):
    """Raised when a state transition is invalid."""

    def __init__(self, message: str, current_state: str, target_state: str):
        super().__init__(message)
        self.current_state = current_state
        self.target_state = target_state


class ResultsSetNotFoundError(FulfillmentRunError):
    """Raised when a results set is not found."""


@dataclass
class FulfillmentRunCreate:
    """Data for creating an assay run."""

    order_id: str
    test_order_id: str
    fulfillment_route_code: str


@dataclass
class TransitionData:
    """Data for an assay state transition."""

    target_state: FulfillmentRunState
    qc_override: bool = False
    qc_hold_reason: str | None = None
    accession_id: str | None = None
    note: str | None = None


@dataclass
class ResultCreate:
    """Data for creating an assay result."""

    result_payload: dict[str, Any] | None = None
    artifact_ids: list[str] | None = None
    analysis_context: dict[str, Any] | None = None


@dataclass
class AmendmentCreate:
    """Data for creating an amendment result."""

    original_result_euid: str
    amend_reason: str
    result_payload: dict[str, Any] | None = None
    artifact_ids: list[str] | None = None
    analysis_context: dict[str, Any] | None = None


class FulfillmentRunService:
    """Service for assay run operations."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._repo_cache: TapdbFulfillmentRunRepository | None = None

    def _repo(self) -> TapdbFulfillmentRunRepository:
        if self._repo_cache is None:
            self._repo_cache = TapdbFulfillmentRunRepository(self.db)
        return self._repo_cache

    def create(
        self,
        data: FulfillmentRunCreate,
        created_by: uuid.UUID | None = None,
    ) -> tuple[FulfillmentRun, FulfillmentRunRevision]:
        existing = self._repo().get_fulfillment_run_by_test_order_and_code(
            test_order_id=data.test_order_id,
            fulfillment_route_code=data.fulfillment_route_code,
            tenant_id=self.tenant_id,
        )
        if existing is not None:
            return existing

        created = self._repo().create_fulfillment_run(
            tenant_id=self.tenant_id,
            order_id=data.order_id,
            test_order_id=data.test_order_id,
            fulfillment_route_code=data.fulfillment_route_code,
            created_by=created_by,
        )
        self._log_audit(
            action=AuditAction.CREATE,
            entity_type="FulfillmentRun",
            entity_euid=created[0].euid,
            user_id=created_by,
            details={
                "order_id": data.order_id,
                "test_order_id": data.test_order_id,
                "fulfillment_route_code": data.fulfillment_route_code,
            },
        )
        return created

    def get(
        self, fulfillment_run_euid: str
    ) -> tuple[FulfillmentRun, FulfillmentRunRevision] | None:
        return self._repo().get_fulfillment_run_with_revision(
            fulfillment_run_euid=fulfillment_run_euid,
            tenant_id=self.tenant_id,
        )

    def get_current_state(self, fulfillment_run_euid: str) -> FulfillmentRunState | None:
        revision = self._repo().get_latest_fulfillment_run_revision(fulfillment_run_euid)
        if revision is None:
            return None
        try:
            return FulfillmentRunState(revision.status)
        except ValueError:
            return None

    def list_for_trf(self, order_id: str) -> list[tuple[FulfillmentRun, FulfillmentRunRevision]]:
        return self._repo().list_fulfillment_runs_for_order(
            order_id=order_id, tenant_id=self.tenant_id
        )

    def list_for_test_order(
        self, test_order_id: str
    ) -> list[tuple[FulfillmentRun, FulfillmentRunRevision]]:
        return self._repo().list_fulfillment_runs_for_test_order(
            test_order_id=test_order_id,
            tenant_id=self.tenant_id,
        )

    def transition(
        self,
        fulfillment_run_euid: str,
        data: TransitionData,
        transition_by: uuid.UUID | None = None,
    ) -> tuple[FulfillmentRun, FulfillmentRunRevision]:
        current = self.get(fulfillment_run_euid)
        if current is None:
            raise FulfillmentRunNotFoundError(f"Assay run {fulfillment_run_euid} not found")
        assay_run, latest = current

        current_state = PolicyFulfillmentRunState(latest.status)
        target_state = PolicyFulfillmentRunState(data.target_state.value)
        if current_state == target_state:
            return assay_run, latest

        try:
            validate_transition(current_state, target_state, qc_override=data.qc_override)
        except TransitionError as exc:
            raise InvalidTransitionError(
                str(exc),
                current_state=current_state.value,
                target_state=target_state.value,
            ) from exc

        if data.target_state == FulfillmentRunState.QC_HOLD and not data.qc_hold_reason:
            raise InvalidTransitionError(
                "QC_HOLD requires a qc_hold_reason",
                current_state=current_state.value,
                target_state=target_state.value,
            )

        revision = self._repo().create_fulfillment_run_revision(
            fulfillment_run_euid=fulfillment_run_euid,
            status=data.target_state.value,
            accession_id=data.accession_id
            if data.accession_id is not None
            else latest.accession_id,
            qc_hold_reason=(
                data.qc_hold_reason if data.qc_hold_reason is not None else latest.qc_hold_reason
            ),
            qc_override=data.qc_override,
            note=data.note,
            created_by=transition_by,
        )
        if revision is None:
            raise FulfillmentRunNotFoundError(f"Assay run {fulfillment_run_euid} not found")

        self._log_audit(
            action=AuditAction.STATUS_CHANGE,
            entity_type="FulfillmentRun",
            entity_euid=fulfillment_run_euid,
            user_id=transition_by,
            details={
                "from": current_state.value,
                "to": target_state.value,
                "note": data.note,
            },
        )

        try:
            emit_assay_run_status_changed(
                db=self.db,
                tenant_id=self.tenant_id,
                fulfillment_run_id=fulfillment_run_euid,  # type: ignore[arg-type]  # webhook migration pending
                order_id=assay_run.order_id,  # type: ignore[arg-type]  # webhook migration pending
                order_number=self._get_order_number(assay_run.order_id),
                previous_status=current_state.value,
                new_status=target_state.value,
                qc_hold_reason=(
                    data.qc_hold_reason
                    if data.target_state == FulfillmentRunState.QC_HOLD
                    else None
                ),
            )
        except Exception:
            # Webhook emission is best effort and should not fail transitions.
            pass

        return assay_run, revision

    def bulk_transition(
        self,
        fulfillment_run_euids: list[str],
        target_state: FulfillmentRunState,
        transition_by: uuid.UUID | None = None,
        note: str | None = None,
    ) -> list[tuple[FulfillmentRun, FulfillmentRunRevision]]:
        rows: list[tuple[FulfillmentRun, FulfillmentRunRevision]] = []
        for euid in fulfillment_run_euids:
            rows.append(
                self.transition(
                    euid,
                    TransitionData(target_state=target_state, note=note),
                    transition_by=transition_by,
                )
            )
        return rows

    def _get_order_number(self, order_id: str) -> str:
        trf = TapdbTrfRepository(self.db).get_trf_by_id(trf_id=order_id, tenant_id=None)
        return trf.order_number if trf else f"UNKNOWN-{order_id}"

    def _log_audit(
        self,
        *,
        action: AuditAction,
        entity_type: str,
        entity_euid: str,
        user_id: uuid.UUID | None,
        details: dict[str, Any] | None = None,
    ) -> None:
        merged_details = dict(details or {})
        merged_details["euid"] = entity_euid
        try:
            AuditService(
                self.db, tenant_id=self.tenant_id, user_id=str(user_id) if user_id else None
            ).log(
                action=action,
                entity_type=entity_type,
                entity_id=None,
                details=merged_details,
                user_id=user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()


class FulfillmentOutputService:
    """Service for assay result operations."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._repo_cache: TapdbFulfillmentRunRepository | None = None

    def _repo(self) -> TapdbFulfillmentRunRepository:
        if self._repo_cache is None:
            self._repo_cache = TapdbFulfillmentRunRepository(self.db)
        return self._repo_cache

    def create(
        self,
        fulfillment_run_euid: str,
        data: ResultCreate,
        created_by: uuid.UUID | None = None,
    ) -> FulfillmentOutput:
        existing = self._repo().list_fulfillment_outputs_for_run(
            fulfillment_run_euid, self.tenant_id
        )
        return self._repo().create_fulfillment_output(
            tenant_id=self.tenant_id,
            fulfillment_run_euid=fulfillment_run_euid,
            version_no=len(existing) + 1,
            result_payload=data.result_payload or {},
            artifact_ids=data.artifact_ids,
            analysis_context=data.analysis_context,
            created_by=created_by,
        )

    def create_amendment(
        self,
        fulfillment_run_euid: str,
        data: AmendmentCreate,
        created_by: uuid.UUID | None = None,
    ) -> FulfillmentOutput:
        original = self._repo().get_fulfillment_output(data.original_result_euid, self.tenant_id)
        if original is None:
            raise FulfillmentRunError(f"Original result {data.original_result_euid} not found")
        existing = self._repo().list_fulfillment_outputs_for_run(
            fulfillment_run_euid, self.tenant_id
        )
        return self._repo().create_fulfillment_output(
            tenant_id=self.tenant_id,
            fulfillment_run_euid=fulfillment_run_euid,
            version_no=len(existing) + 1,
            result_payload=data.result_payload or {},
            artifact_ids=data.artifact_ids,
            analysis_context=data.analysis_context,
            created_by=created_by,
            amends_result_euid=data.original_result_euid,
            amend_reason=data.amend_reason,
        )

    def get(self, result_euid: str) -> FulfillmentOutput | None:
        return self._repo().get_fulfillment_output(result_euid, self.tenant_id)

    def get_latest_for_assay_run(self, fulfillment_run_euid: str) -> FulfillmentOutput | None:
        return self._repo().get_latest_fulfillment_output_for_run(
            fulfillment_run_euid, self.tenant_id
        )

    def list_for_assay_run(self, fulfillment_run_euid: str) -> list[FulfillmentOutput]:
        return self._repo().list_fulfillment_outputs_for_run(fulfillment_run_euid, self.tenant_id)

    def get_by_analysis_euid(
        self,
        fulfillment_run_euid: str,
        analysis_euid: str,
    ) -> FulfillmentOutput | None:
        return self._repo().get_fulfillment_output_by_analysis_euid(
            fulfillment_run_euid=fulfillment_run_euid,
            analysis_euid=analysis_euid,
            tenant_id=self.tenant_id,
        )


class ResultsSetService:
    """Service for results set operations."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._repo_cache: TapdbFulfillmentRunRepository | None = None

    def _repo(self) -> TapdbFulfillmentRunRepository:
        if self._repo_cache is None:
            self._repo_cache = TapdbFulfillmentRunRepository(self.db)
        return self._repo_cache

    def get_or_create_for_test(
        self,
        test_euid: str,
        created_by: uuid.UUID | None = None,
    ) -> ResultsSet:
        return self._repo().get_or_create_results_set(
            tenant_id=self.tenant_id,
            test_euid=test_euid,
            created_by=created_by,
        )

    def get(self, results_set_euid: str) -> ResultsSet | None:
        return self._repo().get_results_set_by_euid(
            results_set_euid=results_set_euid,
            tenant_id=self.tenant_id,
        )

    def add_fulfillment_run(
        self,
        results_set_euid: str,
        fulfillment_run_euid: str,
    ) -> ResultsSetAssay:
        if self.get(results_set_euid) is None:
            raise ResultsSetNotFoundError(f"Results set {results_set_euid} not found")
        return self._repo().add_fulfillment_run_to_results_set(
            results_set_euid=results_set_euid,
            fulfillment_run_euid=fulfillment_run_euid,
        )

    def publish(
        self,
        results_set_euid: str,
        published_by: uuid.UUID | None = None,
        note: str | None = None,
    ) -> ResultsSet:
        results_set = self._repo().publish_results_set(
            results_set_euid=results_set_euid,
            tenant_id=self.tenant_id,
            published_by=published_by,
            note=note,
        )
        if results_set is None:
            raise ResultsSetNotFoundError(f"Results set {results_set_euid} not found")

        try:
            emit_results_set_published(
                db=self.db,
                tenant_id=self.tenant_id,
                results_set_id=results_set.euid,  # type: ignore[arg-type]  # webhook migration pending
                order_id=self._get_order_id_for_test(results_set.test_euid),  # type: ignore[arg-type]
                order_number=self._get_order_number_for_test(results_set.test_euid),
                fulfillment_run_count=len(
                    self.get_fulfillment_runs_for_results_set(results_set.euid)
                ),
            )
        except Exception:
            # Webhook emission is best effort and should not fail publishing.
            pass
        return results_set

    def list_for_trf(
        self,
        trf_euid: str,
        include_unpublished: bool = False,
    ) -> list[ResultsSet]:
        return self._repo().list_results_sets_for_trf(
            trf_euid=trf_euid,
            tenant_id=self.tenant_id,
            include_unpublished=include_unpublished,
        )

    def list_for_test(
        self,
        test_euid: str,
        include_unpublished: bool = False,
    ) -> list[ResultsSet]:
        return self._repo().list_results_sets_for_test(
            test_euid=test_euid,
            tenant_id=self.tenant_id,
            include_unpublished=include_unpublished,
        )

    def get_fulfillment_runs_for_results_set(self, results_set_euid: str) -> list[FulfillmentRun]:
        return self._repo().list_fulfillment_runs_for_results_set(
            results_set_euid=results_set_euid,
            tenant_id=self.tenant_id,
        )

    def list_for_fulfillment_run(self, fulfillment_run_euid: str) -> list[ResultsSet]:
        return self._repo().list_results_sets_for_fulfillment_run(
            fulfillment_run_euid=fulfillment_run_euid,
            tenant_id=self.tenant_id,
        )

    def get_latest_for_fulfillment_run(self, fulfillment_run_euid: str) -> ResultsSet | None:
        rows = self.list_for_fulfillment_run(fulfillment_run_euid)
        return rows[0] if rows else None

    def _get_order_id_for_test(self, test_euid: str) -> str:
        test = TapdbTrfRepository(self.db).get_test_by_id(test_id=test_euid, tenant_id=None)
        return str(test.order_id) if test is not None else ""

    def _get_order_number_for_test(self, test_euid: str) -> str:
        order_id = self._get_order_id_for_test(test_euid)
        trf = TapdbTrfRepository(self.db).get_trf_by_id(trf_id=order_id, tenant_id=None)
        return trf.order_number if trf else f"UNKNOWN-{order_id}"
