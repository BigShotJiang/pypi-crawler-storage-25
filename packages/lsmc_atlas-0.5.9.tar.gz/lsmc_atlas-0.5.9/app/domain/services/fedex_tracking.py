"""LSMC Hub - FedEx Tracking Service.

Integrates daylily-carrier-tracking library for enhanced shipment tracking.
Captures:
- Origin state/location
- Transit time calculations
- Intermediate tracking events
- Delivery confirmation details
"""

import logging
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.domain.enums import AuditAction
from app.domain.services.audit import AuditService

logger = logging.getLogger(__name__)


# Try to import daylily_carrier_tracking, gracefully handle if not installed
try:
    from daylily_carrier_tracking import FedexTracker

    FEDEX_AVAILABLE = True
except ImportError:
    FEDEX_AVAILABLE = False
    FedexTracker = None  # type: ignore
    logger.warning("daylily-carrier-tracking not installed. FedEx tracking will be disabled.")


@dataclass
class TrackingEvent:
    """A single tracking event from FedEx."""

    timestamp: datetime | None
    event_type: str
    event_description: str
    city: str | None = None
    state: str | None = None
    country_code: str | None = None
    exception_code: str | None = None
    exception_description: str | None = None


@dataclass
class TrackingSummary:
    """Summarized tracking information for a shipment."""

    tracking_number: str
    delivery_status: str
    origin_city: str | None = None
    origin_state: str | None = None
    origin_country: str | None = None
    destination_city: str | None = None
    destination_state: str | None = None
    destination_country: str | None = None
    ship_date: datetime | None = None
    pickup_date: datetime | None = None
    delivery_date: datetime | None = None
    transit_time_seconds: int | None = None
    service_type: str | None = None
    service_description: str | None = None
    events: list[TrackingEvent] | None = None
    raw_response: dict | None = None
    error: str | None = None


class FedExTrackingService:
    """Service for tracking FedEx shipments."""

    def __init__(
        self,
        db,
        tenant_id: uuid.UUID,
        actor_id: str | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.actor_id = actor_id
        self._tracker: Any = None

    def _get_tracker(self) -> Any:
        """Get or create the FedEx tracker instance.

        The FedexTracker from daylily-carrier-tracking requires configuration.
        It will look for config at:
        1. ~/.config/daylily-carrier-tracking/fedex_prod.yaml (preferred)
        2. ~/.config/fedex/fedex_prod.yaml (legacy yaml_config_day)

        Alternatively, you can set FEDEX_OAUTH_URL, FEDEX_CLIENT_ID, FEDEX_CLIENT_SECRET
        environment variables and pass them as a config dict.
        """
        if not FEDEX_AVAILABLE:
            raise RuntimeError("daylily-carrier-tracking library is not installed")
        if self._tracker is None:
            import os

            # Check for environment variable override
            oauth_url = os.environ.get("FEDEX_OAUTH_URL")
            client_id = os.environ.get("FEDEX_CLIENT_ID")
            client_secret = os.environ.get("FEDEX_CLIENT_SECRET")

            if oauth_url and client_id and client_secret:
                # Use environment variables
                config = {
                    "oauth_url": oauth_url,
                    "client_id": client_id,
                    "client_secret": client_secret,
                }
                self._tracker = FedexTracker(config=config)
            else:
                # Use config file (will look in ~/.config/daylily-carrier-tracking/)
                self._tracker = FedexTracker(
                    config_proj_name="fedex",
                    config_proj_env="prod",
                )
        return self._tracker

    def is_available(self) -> bool:
        """Check if FedEx tracking is available."""
        return FEDEX_AVAILABLE

    def track(self, tracking_number: str) -> TrackingSummary:
        """Track a single FedEx tracking number."""
        if not FEDEX_AVAILABLE:
            return TrackingSummary(
                tracking_number=tracking_number,
                delivery_status="UNAVAILABLE",
                error="daylily-carrier-tracking library not installed",
            )

        try:
            tracker = self._get_tracker()

            # Get full JSON response using new API (returns tuple of raw_dict, meta)
            raw_response, _meta = tracker.track_raw(tracking_number)

            # Get summarized ops_meta data using new API
            summary_data = tracker.track_ops_meta(tracking_number)

            # Parse events from raw response
            events = self._parse_events(raw_response)

            # Parse origin/destination from raw response
            origin_info = self._parse_origin(raw_response)
            dest_info = self._parse_destination(raw_response)
            service_info = self._parse_service(raw_response)

            # Parse dates
            pickup_dt = self._parse_datetime(summary_data.get("Pickup_dt"))
            delivery_dt = self._parse_datetime(summary_data.get("Delivery_dt"))
            ship_dt = self._parse_datetime(summary_data.get("Ship_dt"))

            # Calculate transit time
            transit_seconds = None
            if pickup_dt and delivery_dt:
                transit_seconds = int((delivery_dt - pickup_dt).total_seconds())
            elif summary_data.get("Transit_Time_sec") and summary_data["Transit_Time_sec"] != "":
                try:
                    transit_seconds = int(summary_data["Transit_Time_sec"])
                except (ValueError, TypeError):
                    pass

            return TrackingSummary(
                tracking_number=tracking_number,
                delivery_status=summary_data.get("Delivery_Status", "UNKNOWN"),
                origin_city=origin_info.get("city"),
                origin_state=origin_info.get("state") or summary_data.get("Origin_state"),
                origin_country=origin_info.get("country"),
                destination_city=dest_info.get("city"),
                destination_state=dest_info.get("state") or summary_data.get("Destination_state"),
                destination_country=dest_info.get("country"),
                ship_date=ship_dt,
                pickup_date=pickup_dt,
                delivery_date=delivery_dt,
                transit_time_seconds=transit_seconds,
                service_type=service_info.get("type"),
                service_description=service_info.get("description"),
                events=events,
                raw_response=raw_response,
            )

        except Exception as e:
            logger.error(
                "Error tracking %s: %s", str(tracking_number).replace("\n", "").replace("\r", ""), e
            )
            return TrackingSummary(
                tracking_number=tracking_number,
                delivery_status="ERROR",
                error=str(e),
            )

    def _parse_datetime(self, dt_str: str | None) -> datetime | None:
        """Parse a datetime string from FedEx API."""
        if not dt_str:
            return None
        try:
            # Try ISO format with timezone
            return datetime.fromisoformat(dt_str.replace("+00:00", "Z").rstrip("Z"))
        except (ValueError, AttributeError):
            return None

    def _parse_events(self, raw_response: dict) -> list[TrackingEvent]:
        """Parse tracking events from raw FedEx response."""
        events = []
        try:
            track_results = (
                raw_response.get("output", {})
                .get("completeTrackResults", [{}])[0]
                .get("trackResults", [{}])[0]
            )
            scan_events = track_results.get("scanEvents", [])

            for event in scan_events:
                location = event.get("scanLocation", {})
                events.append(
                    TrackingEvent(
                        timestamp=self._parse_datetime(event.get("date")),
                        event_type=event.get("eventType", ""),
                        event_description=event.get("eventDescription", ""),
                        city=location.get("city"),
                        state=location.get("stateOrProvinceCode"),
                        country_code=location.get("countryCode"),
                        exception_code=event.get("exceptionCode"),
                        exception_description=event.get("exceptionDescription"),
                    )
                )
        except (KeyError, IndexError, TypeError) as e:
            logger.debug(f"Error parsing events: {e}")
        return events

    def _parse_origin(self, raw_response: dict) -> dict:
        """Parse origin location from raw FedEx response."""
        try:
            track_results = (
                raw_response.get("output", {})
                .get("completeTrackResults", [{}])[0]
                .get("trackResults", [{}])[0]
            )
            origin = (
                track_results.get("originLocation", {})
                .get("locationContactAndAddress", {})
                .get("address", {})
            )
            return {
                "city": origin.get("city"),
                "state": origin.get("stateOrProvinceCode"),
                "country": origin.get("countryCode"),
            }
        except (KeyError, IndexError, TypeError):
            return {}

    def _parse_destination(self, raw_response: dict) -> dict:
        """Parse destination location from raw FedEx response."""
        try:
            track_results = (
                raw_response.get("output", {})
                .get("completeTrackResults", [{}])[0]
                .get("trackResults", [{}])[0]
            )
            dest = (
                track_results.get("destinationLocation", {})
                .get("locationContactAndAddress", {})
                .get("address", {})
            )
            return {
                "city": dest.get("city"),
                "state": dest.get("stateOrProvinceCode"),
                "country": dest.get("countryCode"),
            }
        except (KeyError, IndexError, TypeError):
            return {}

    def _parse_service(self, raw_response: dict) -> dict:
        """Parse service details from raw FedEx response."""
        try:
            track_results = (
                raw_response.get("output", {})
                .get("completeTrackResults", [{}])[0]
                .get("trackResults", [{}])[0]
            )
            service = track_results.get("serviceDetail", {})
            return {
                "type": service.get("type"),
                "description": service.get("description"),
            }
        except (KeyError, IndexError, TypeError):
            return {}

    def update_shipment_tracking(
        self, shipment_id: str | uuid.UUID, tracking_number: str
    ) -> TrackingSummary:
        """
        Track a shipment using live carrier data.

        Runtime hard-cut behavior:
        - fetch live carrier status
        - audit the lookup
        - do not persist tracking snapshots/events
        """
        summary = self.track(tracking_number)
        actor_uuid: uuid.UUID | None = None
        if self.actor_id:
            try:
                actor_uuid = uuid.UUID(str(self.actor_id))
            except (ValueError, TypeError):
                actor_uuid = None
        try:
            AuditService(self.db, tenant_id=self.tenant_id).log(
                action=AuditAction.VIEW,
                entity_type="Shipment",
                entity_id=str(shipment_id),
                user_id=actor_uuid,
                details={
                    "action": "TRACKING_UPDATED",
                    "tracking_number": tracking_number,
                    "delivery_status": summary.delivery_status,
                    "tracking_mode": "live_only",
                },
            )
            commit = getattr(self.db, "commit", None)
            if callable(commit):
                commit()
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.warning("Unable to audit shipment tracking lookup", exc_info=True)

        return summary

    def get_latest_tracking(self, shipment_id: str | uuid.UUID) -> TrackingSummary | None:
        """Live-only mode: no persisted tracking snapshot is available."""
        _ = shipment_id
        return None
