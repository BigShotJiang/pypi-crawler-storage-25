"""TapDB-backed graph viewer service for read-only Atlas graph exploration."""

from __future__ import annotations

import uuid
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from typing import Any
from urllib.parse import urlencode

from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from sqlalchemy import and_, desc, or_, select
from sqlalchemy.orm import Session, aliased

from app.domain.services.external_objects import BloomConfigResolverService, ExternalObjectService
from app.domain.services.story_graph_projection import BloomStoryContext, add_bloom_story_edges
from app.integrations.bloom_client import BloomClient, BloomClientError, resolve_secret_value
from app.persistence.tapdb.collection_events import COLLECTION_EVENT_TEMPLATE_CODE
from app.persistence.tapdb.documents import DOCUMENT_TEMPLATE_CODE
from app.persistence.tapdb.euid_helpers import get_child_instances
from app.persistence.tapdb.external_objects import EXTERNAL_OBJECT_TEMPLATE_CODE
from app.persistence.tapdb.logistics import SHIPMENT_TEMPLATE_CODE, TEST_KIT_TEMPLATE_CODE
from app.persistence.tapdb.orgs import (
    ORG_REV_TEMPLATE_CODE,
    ORG_TEMPLATE_CODE,
    SITE_REV_TEMPLATE_CODE,
    SITE_TEMPLATE_CODE,
)
from app.persistence.tapdb.people import (
    CLINICIAN_REV_TEMPLATE_CODE,
    CLINICIAN_TEMPLATE_CODE,
    PATIENT_REV_TEMPLATE_CODE,
    PATIENT_TEMPLATE_CODE,
)
from app.persistence.tapdb.trfs import TEST_TEMPLATE_CODE, TRF_TEMPLATE_CODE, TapdbTrfRepository
from app.settings import settings


class GraphViewerError(RuntimeError):
    """Base graph viewer exception."""


class GraphPermissionError(GraphViewerError):
    """Raised when a graph request violates tenant permission rules."""


class GraphObjectNotFoundError(GraphViewerError):
    """Raised when a graph object cannot be resolved in visible scope."""


class GraphExternalReferenceError(GraphViewerError):
    """Raised when an external graph reference cannot be resolved."""


class GraphExternalFetchError(GraphViewerError):
    """Raised when an external graph fetch fails."""


_CATEGORY_COLORS: dict[str, str] = {
    "workflow": "#19f0a0",
    "workflow_step": "#8cf254",
    "container": "#9c6bff",
    "content": "#3fd5ff",
    "equipment": "#ff7448",
    "data": "#ffe86b",
    "actor": "#ff8ed1",
    "action": "#ffab45",
    "test_requisition": "#ffc56e",
    "health_event": "#ff6a7a",
    "file": "#79ec8f",
    "subject": "#8fb2ff",
}
_DEFAULT_NODE_COLOR = "#8a8a8a"


@dataclass(frozen=True)
class ExternalGraphRef:
    label: str
    system: str
    root_euid: str
    external_object_id: str | None
    tenant_id: str | None
    href: str | None
    graph_expandable: bool
    reason: str | None
    base_url: str | None
    api_key_secret_ref: str | None

    def to_public_dict(self, *, ref_index: int) -> dict[str, Any]:
        payload = {
            "label": self.label,
            "system": self.system,
            "root_euid": self.root_euid,
            "external_object_id": self.external_object_id,
            "tenant_id": self.tenant_id,
            "href": self.href,
            "graph_expandable": self.graph_expandable,
            "ref_index": ref_index,
        }
        if self.reason:
            payload["reason"] = self.reason
        return payload


def _as_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (TypeError, ValueError):
        return None


def _as_json_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _iso(value: Any) -> str | None:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, str):
        raw = value.strip()
        return raw or None
    return None


def _clean_str(value: Any) -> str:
    return str(value or "").strip()


def _dedupe_graph_elements(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []
    for element in elements:
        data = dict(element.get("data") or {})
        element_id = _clean_str(data.get("id"))
        if not element_id or element_id in seen:
            continue
        seen.add(element_id)
        deduped.append({"data": data})
    return deduped


def _merge_graph_payloads(
    local_payload: dict[str, Any],
    external_payloads: list[dict[str, Any]],
) -> dict[str, Any]:
    nodes = list((local_payload.get("elements") or {}).get("nodes") or [])
    edges = list((local_payload.get("elements") or {}).get("edges") or [])
    for payload in external_payloads:
        elements = payload.get("elements") or {}
        nodes.extend(list(elements.get("nodes") or []))
        edges.extend(list(elements.get("edges") or []))
    return {
        "elements": {
            "nodes": _dedupe_graph_elements(nodes),
            "edges": _dedupe_graph_elements(edges),
        },
        "meta": {
            **dict(local_payload.get("meta") or {}),
            "external_graph_count": len(external_payloads),
        },
    }


def _atlas_page_link(*, euid: str, template_code: str | None) -> tuple[str, str]:
    clean_euid = _clean_str(euid)
    clean_template = _clean_str(template_code)
    if not clean_euid:
        return "", "unknown"

    if clean_template == TRF_TEMPLATE_CODE:
        return f"/trfs/{clean_euid}", "trf_detail"
    if clean_template == TEST_TEMPLATE_CODE:
        return f"/trfs/tests/{clean_euid}", "test_detail"
    if clean_template == PATIENT_TEMPLATE_CODE:
        return f"/patients/{clean_euid}", "patient_detail"
    if clean_template == CLINICIAN_TEMPLATE_CODE:
        return f"/clinicians/{clean_euid}", "clinician_detail"
    if clean_template == COLLECTION_EVENT_TEMPLATE_CODE:
        return f"/collection-events/{clean_euid}", "collection_event_detail"
    if clean_template == ORG_TEMPLATE_CODE:
        return f"/admin/organizations/{clean_euid}", "organization_detail"
    if clean_template == SITE_TEMPLATE_CODE:
        return f"/admin/sites/{clean_euid}", "site_detail"
    if clean_template in {
        EXTERNAL_OBJECT_TEMPLATE_CODE,
        TEST_KIT_TEMPLATE_CODE,
        SHIPMENT_TEMPLATE_CODE,
        DOCUMENT_TEMPLATE_CODE,
    }:
        return f"/tapdb/object/{clean_euid}", "tapdb_object"
    return f"/tapdb/object/{clean_euid}", "tapdb_object"


def _instance_tenant_id(instance: generic_instance) -> uuid.UUID | None:
    json_addl = _as_json_dict(instance.json_addl)
    direct = _as_uuid(json_addl.get("tenant_id"))
    if direct is not None:
        return direct

    properties = _as_json_dict(json_addl.get("properties"))
    return _as_uuid(properties.get("tenant_id"))


class GraphViewerService:
    """Builds graph viewer payloads from TapDB instance/lineage/template records."""

    def __init__(self, db: Session, tenant_id: uuid.UUID, *, can_cross_tenant: bool):
        self.db = db
        self.tenant_id = tenant_id
        self.can_cross_tenant = can_cross_tenant

    def resolve_tenant_scope(self, requested_tenant_id: uuid.UUID | None) -> uuid.UUID:
        """Resolve effective tenant scope for the request."""
        if requested_tenant_id is None:
            return self.tenant_id
        if requested_tenant_id == self.tenant_id:
            return requested_tenant_id
        if not self.can_cross_tenant:
            raise GraphPermissionError("Cross-tenant graph access requires cross_tenant:read")
        return requested_tenant_id

    def get_graph_data(
        self,
        *,
        start_euid: str | None,
        depth: int,
        requested_tenant_id: uuid.UUID | None,
        projection: str = "raw",
    ) -> dict[str, Any]:
        """Return Cytoscape graph elements and metadata."""
        tenant_scope = self.resolve_tenant_scope(requested_tenant_id)
        effective_depth = max(1, min(depth, settings.graph_max_depth))

        if (start_euid or "").strip():
            nodes, edges, truncated = self._build_start_graph(
                start_euid=(start_euid or "").strip(),
                depth=effective_depth,
                tenant_scope=tenant_scope,
            )
        else:
            nodes, edges, truncated = self._build_recent_graph(tenant_scope=tenant_scope)

        payload = {
            "elements": {
                "nodes": nodes,
                "edges": edges,
            },
            "meta": {
                "start_euid": (start_euid or "").strip() or None,
                "depth": effective_depth,
                "tenant_id": str(tenant_scope),
                "node_count": len(nodes),
                "edge_count": len(edges),
                "truncated": truncated,
            },
        }
        if _clean_str(projection).lower() == "story" and (start_euid or "").strip():
            return self._build_story_graph(
                local_payload=payload,
                start_euid=(start_euid or "").strip(),
                depth=effective_depth,
                requested_tenant_id=requested_tenant_id,
            )
        return payload

    def get_object_detail(
        self,
        *,
        euid: str,
        requested_tenant_id: uuid.UUID | None,
    ) -> dict[str, Any]:
        """Return detail payload for an instance/template/lineage object."""
        tenant_scope = self.resolve_tenant_scope(requested_tenant_id)
        clean_euid = (euid or "").strip()
        if not clean_euid:
            raise GraphObjectNotFoundError("Object not found")

        instance = (
            self.db.execute(
                select(generic_instance).where(
                    and_(
                        generic_instance.euid == clean_euid,
                        generic_instance.is_deleted.is_(False),
                    )
                )
            )
            .scalars()
            .first()
        )
        if instance is not None and self._instance_visible(instance, tenant_scope):
            return self._instance_detail(instance)

        template = (
            self.db.execute(
                select(generic_template).where(
                    and_(
                        generic_template.euid == clean_euid,
                        generic_template.is_deleted.is_(False),
                    )
                )
            )
            .scalars()
            .first()
        )
        if template is not None:
            return self._template_detail(template)

        lineage_row = self._find_visible_lineage(clean_euid, tenant_scope)
        if lineage_row is not None:
            lineage, parent, child = lineage_row
            return self._lineage_detail(lineage=lineage, parent=parent, child=child)

        raise GraphObjectNotFoundError(f"Object not found: {clean_euid}")

    def get_external_graph(
        self,
        *,
        source_euid: str,
        ref_index: int,
        depth: int,
        requested_tenant_id: uuid.UUID | None,
    ) -> dict[str, Any]:
        tenant_scope = self.resolve_tenant_scope(requested_tenant_id)
        source = self._find_visible_instance_by_euid(source_euid, tenant_scope)
        if source is None:
            raise GraphObjectNotFoundError(f"Object not found: {source_euid}")

        ref = self._external_ref_by_index(source, tenant_scope, ref_index)
        if not ref.graph_expandable:
            raise GraphExternalReferenceError(ref.reason or "External graph unavailable")

        client = self._build_bloom_client(ref)
        effective_depth = max(1, min(depth, settings.graph_max_depth))
        try:
            payload = client.get_graph_data(start_euid=ref.root_euid, depth=effective_depth)
        except BloomClientError as exc:
            raise GraphExternalFetchError(str(exc)) from exc
        return self._namespace_external_graph(
            payload,
            ref=ref,
            ref_index=ref_index,
            source_euid=source.euid,
        )

    def get_external_object_detail(
        self,
        *,
        source_euid: str,
        ref_index: int,
        euid: str,
        requested_tenant_id: uuid.UUID | None,
    ) -> dict[str, Any]:
        tenant_scope = self.resolve_tenant_scope(requested_tenant_id)
        source = self._find_visible_instance_by_euid(source_euid, tenant_scope)
        if source is None:
            raise GraphObjectNotFoundError(f"Object not found: {source_euid}")

        ref = self._external_ref_by_index(source, tenant_scope, ref_index)
        if not ref.graph_expandable:
            raise GraphExternalReferenceError(ref.reason or "External object unavailable")

        client = self._build_bloom_client(ref)
        try:
            return client.get_graph_object_detail(euid=euid)
        except BloomClientError as exc:
            raise GraphExternalFetchError(str(exc)) from exc

    def _build_story_graph(
        self,
        *,
        local_payload: dict[str, Any],
        start_euid: str,
        depth: int,
        requested_tenant_id: uuid.UUID | None,
    ) -> dict[str, Any]:
        external_payloads: list[dict[str, Any]] = []
        merged_refs: set[tuple[str, int]] = set()
        local_nodes = list((local_payload.get("elements") or {}).get("nodes") or [])
        for node in local_nodes:
            node_data = dict(node.get("data") or {})
            source_euid = _clean_str(node_data.get("euid") or node_data.get("id"))
            if not source_euid:
                continue
            detail = self.get_object_detail(
                euid=source_euid, requested_tenant_id=requested_tenant_id
            )
            for ref in list(detail.get("external_refs") or []):
                ref_index = int(ref.get("ref_index") or 0)
                key = (source_euid, ref_index)
                if key in merged_refs or not ref.get("graph_expandable"):
                    continue
                merged_refs.add(key)
                try:
                    external_payloads.append(
                        self.get_external_graph(
                            source_euid=source_euid,
                            ref_index=ref_index,
                            depth=depth,
                            requested_tenant_id=requested_tenant_id,
                        )
                    )
                except (
                    GraphExternalReferenceError,
                    GraphExternalFetchError,
                    GraphObjectNotFoundError,
                ):
                    continue

        merged = _merge_graph_payloads(local_payload, external_payloads)
        projected = self._project_story_graph(merged, start_euid=start_euid)
        projected_meta = dict(projected.get("meta") or {})
        projected_meta.update(
            {
                "projection": "story",
                "external_graph_count": len(external_payloads),
            }
        )
        projected["meta"] = projected_meta
        return projected

    @staticmethod
    def _project_story_graph(
        payload: dict[str, Any],
        *,
        start_euid: str,
    ) -> dict[str, Any]:
        nodes = list((payload.get("elements") or {}).get("nodes") or [])
        edges = list((payload.get("elements") or {}).get("edges") or [])
        node_by_id: dict[str, dict[str, Any]] = {}
        for node in nodes:
            data = dict(node.get("data") or {})
            node_id = _clean_str(data.get("id"))
            if node_id:
                node_by_id[node_id] = {"data": data}

        def node_subtype(node_id: str) -> str:
            return _clean_str(
                (node_by_id.get(node_id) or {}).get("data", {}).get("subtype")
            ).lower()

        def node_system(node_id: str) -> str:
            return _clean_str((node_by_id.get(node_id) or {}).get("data", {}).get("system")).lower()

        def edge_matches(
            *,
            relationship_type: str | None = None,
            source: str | None = None,
            target: str | None = None,
        ) -> list[dict[str, Any]]:
            rel = _clean_str(relationship_type)
            src = _clean_str(source)
            tgt = _clean_str(target)
            matches: list[dict[str, Any]] = []
            for edge in edges:
                data = dict(edge.get("data") or {})
                if rel and _clean_str(data.get("relationship_type")) != rel:
                    continue
                if src and _clean_str(data.get("source")) != src:
                    continue
                if tgt and _clean_str(data.get("target")) != tgt:
                    continue
                matches.append(data)
            return matches

        def first_target(
            source: str, relationship_type: str, *, target_subtype: str | None = None
        ) -> str:
            for edge in edge_matches(relationship_type=relationship_type, source=source):
                target = _clean_str(edge.get("target"))
                if not target:
                    continue
                if target_subtype and node_subtype(target) != target_subtype:
                    continue
                return target
            return ""

        def first_source(
            target: str, relationship_type: str, *, source_subtype: str | None = None
        ) -> str:
            for edge in edge_matches(relationship_type=relationship_type, target=target):
                source = _clean_str(edge.get("source"))
                if not source:
                    continue
                if source_subtype and node_subtype(source) != source_subtype:
                    continue
                return source
            return ""

        def first_external_ref(external_object_id: str) -> str:
            return first_target(external_object_id, "external_reference")

        def any_between(left: str, right: str, relationship_type: str) -> bool:
            return bool(
                edge_matches(relationship_type=relationship_type, source=left, target=right)
                or edge_matches(relationship_type=relationship_type, source=right, target=left)
            )

        def first_neighbor(
            node_id: str, relationship_type: str, *, system: str | None = None
        ) -> str:
            for edge in edge_matches(relationship_type=relationship_type):
                source = _clean_str(edge.get("source"))
                target = _clean_str(edge.get("target"))
                if node_id not in {source, target}:
                    continue
                other = target if source == node_id else source
                if system and node_system(other) != system:
                    continue
                return other
            return ""

        def all_sources(
            target: str, relationship_type: str, *, source_subtype: str | None = None
        ) -> list[str]:
            results: list[str] = []
            for edge in edge_matches(relationship_type=relationship_type, target=target):
                source = _clean_str(edge.get("source"))
                if not source:
                    continue
                if source_subtype and node_subtype(source) != source_subtype:
                    continue
                if source not in results:
                    results.append(source)
            return results

        def all_targets(source: str, relationship_type: str) -> list[str]:
            results: list[str] = []
            for edge in edge_matches(relationship_type=relationship_type, source=source):
                target = _clean_str(edge.get("target"))
                if target and target not in results:
                    results.append(target)
            return results

        test_ids: list[str] = []
        start_clean = _clean_str(start_euid)
        if node_subtype(start_clean) == "test":
            test_ids = [start_clean]
        elif node_subtype(start_clean) == "trf":
            test_ids = all_sources(start_clean, "contained_in", source_subtype="test")
        elif node_subtype(start_clean) == "patient":
            test_ids = all_sources(start_clean, "order_patient")
        elif node_subtype(start_clean) == "testkit":
            test_ids = all_sources(start_clean, "contained_in", source_subtype="test")
        elif node_system(start_clean) == "bloom":
            bridge_id = first_source(start_clean, "external_reference")
            if bridge_id:
                test_id = first_source(
                    bridge_id, "external_relation:belongs_to_test", source_subtype="test"
                )
                if test_id:
                    test_ids = [test_id]
        elif node_subtype(start_clean) == "external-object":
            test_id = first_source(
                start_clean, "external_relation:belongs_to_test", source_subtype="test"
            )
            if test_id:
                test_ids = [test_id]
        if not test_ids and start_clean in node_by_id:
            test_ids = [start_clean]

        selected_node_ids: list[str] = []
        selected_edge_ids: set[str] = set()
        story_edges: list[dict[str, Any]] = []

        def keep_node(node_id: str) -> None:
            clean = _clean_str(node_id)
            if clean and clean in node_by_id and clean not in selected_node_ids:
                selected_node_ids.append(clean)

        def add_story_edge(source: str, target: str, relationship_type: str) -> None:
            clean_source = _clean_str(source)
            clean_target = _clean_str(target)
            clean_rel = _clean_str(relationship_type)
            if not clean_source or not clean_target or not clean_rel:
                return
            keep_node(clean_source)
            keep_node(clean_target)
            edge_id = f"story-edge::{clean_source}::{clean_rel}::{clean_target}"
            if edge_id in selected_edge_ids:
                return
            selected_edge_ids.add(edge_id)
            story_edges.append(
                {
                    "data": {
                        "id": edge_id,
                        "source": clean_source,
                        "target": clean_target,
                        "relationship_type": clean_rel,
                        "is_story": True,
                    }
                }
            )

        for test_id in test_ids:
            keep_node(test_id)
            trf_id = first_target(test_id, "contained_in", target_subtype="trf")
            patient_ids = all_targets(test_id, "order_patient")
            testkit_id = first_target(test_id, "contained_in", target_subtype="testkit")
            tube_bridge_id = first_target(test_id, "external_relation:belongs_to_test")

            if trf_id:
                add_story_edge(trf_id, test_id, "contains_test")
                site_id = first_source(trf_id, "ordering_site", source_subtype="site")
                if site_id:
                    add_story_edge(site_id, trf_id, "ordering_site")
                    org_id = first_source(site_id, "contains_site", source_subtype="organization")
                    if org_id:
                        add_story_edge(org_id, site_id, "contains_site")
                for clinician_id in all_sources(
                    trf_id, "ordering_clinician", source_subtype="clinician"
                ):
                    add_story_edge(clinician_id, trf_id, "ordering_clinician")

            for patient_id in patient_ids:
                add_story_edge(patient_id, test_id, "order_patient")

            if testkit_id:
                add_story_edge(test_id, testkit_id, "fulfilled_by_testkit")
                shipment_id = first_target(testkit_id, "contained_in", target_subtype="shipment")
                if shipment_id:
                    add_story_edge(shipment_id, testkit_id, "contains_testkit")

            specimen_bridge_id = ""
            if tube_bridge_id:
                add_story_edge(test_id, tube_bridge_id, "tube_bridge")
                for edge in edge_matches(relationship_type="external_relation:contained_in"):
                    left = _clean_str(edge.get("source"))
                    right = _clean_str(edge.get("target"))
                    if tube_bridge_id == left and node_subtype(right) == "external-object":
                        specimen_bridge_id = right
                        break
                    if tube_bridge_id == right and node_subtype(left) == "external-object":
                        specimen_bridge_id = left
                        break

            collection_event_id = ""
            if specimen_bridge_id:
                collection_event_id = first_source(
                    specimen_bridge_id,
                    "external_relation:belongs_to_collection_event",
                    source_subtype="collection-event",
                )
            if not collection_event_id and tube_bridge_id:
                collection_event_id = first_source(
                    tube_bridge_id,
                    "external_relation:has_collection_event",
                    source_subtype="collection-event",
                )

            if collection_event_id and patient_ids:
                add_story_edge(patient_ids[0], collection_event_id, "collection_event")
            if collection_event_id:
                add_story_edge(collection_event_id, test_id, "collected_for_test")
            if collection_event_id and specimen_bridge_id:
                add_story_edge(collection_event_id, specimen_bridge_id, "material_bridge")
            if specimen_bridge_id and tube_bridge_id:
                add_story_edge(specimen_bridge_id, tube_bridge_id, "contained_in")

            remote_tube_id = first_external_ref(tube_bridge_id) if tube_bridge_id else ""
            remote_specimen_id = (
                first_external_ref(specimen_bridge_id) if specimen_bridge_id else ""
            )
            if tube_bridge_id and remote_tube_id:
                add_story_edge(tube_bridge_id, remote_tube_id, "external_reference")
            if specimen_bridge_id and remote_specimen_id:
                add_story_edge(specimen_bridge_id, remote_specimen_id, "external_reference")
            specimen_container_id = ""
            if (
                remote_specimen_id
                and remote_tube_id
                and any_between(remote_specimen_id, remote_tube_id, "contains")
            ):
                specimen_container_id = remote_tube_id

            extraction_output_id = ""
            if remote_specimen_id:
                extraction_output_id = first_source(
                    remote_specimen_id,
                    "beta_extraction_output",
                ) or first_target(remote_specimen_id, "beta_extraction_output")
            well_id = ""
            if extraction_output_id:
                for edge in edge_matches(relationship_type="contains"):
                    source = _clean_str(edge.get("source"))
                    target = _clean_str(edge.get("target"))
                    if (
                        extraction_output_id == source
                        and "well"
                        in _clean_str(
                            (node_by_id.get(target) or {}).get("data", {}).get("name")
                        ).lower()
                    ):
                        well_id = target
                        break
                    if (
                        extraction_output_id == target
                        and "well"
                        in _clean_str(
                            (node_by_id.get(source) or {}).get("data", {}).get("name")
                        ).lower()
                    ):
                        well_id = source
                        break
            plate_id = ""
            if extraction_output_id and well_id:
                plate_id = first_target(well_id, "generic") or first_source(well_id, "generic")

            library_prep_id = ""
            if extraction_output_id:
                library_prep_id = first_source(
                    extraction_output_id,
                    "beta_library_prep_output",
                ) or first_target(extraction_output_id, "beta_library_prep_output")

            library_material_id = ""
            if extraction_output_id:
                library_material_id = first_source(
                    extraction_output_id,
                    "beta_library_material_output",
                ) or first_target(extraction_output_id, "beta_library_material_output")

            library_container_id = ""
            library_container_parent_id = ""
            if library_material_id:
                library_container_id = first_target(
                    library_material_id, "contains"
                ) or first_source(
                    library_material_id,
                    "contains",
                )
            if library_container_id:
                library_container_parent_id = first_target(
                    library_container_id, "generic"
                ) or first_source(library_container_id, "generic")
                if not library_container_parent_id:
                    library_container_parent_id = first_target(
                        library_container_id, "contains"
                    ) or first_source(library_container_id, "contains")

            pool_id = ""
            if library_material_id:
                pool_id = first_source(library_material_id, "beta_pool_member") or first_target(
                    library_material_id,
                    "beta_pool_member",
                )
            if not pool_id and library_prep_id:
                pool_id = first_source(library_prep_id, "beta_pool_member") or first_target(
                    library_prep_id,
                    "beta_pool_member",
                )
            pool_tube_id = ""
            run_id = ""
            fastq_ids: list[str] = []
            if pool_id:
                pool_tube_id = first_target(pool_id, "contains") or first_source(
                    pool_id, "contains"
                )
                run_id = first_source(pool_id, "beta_sequencing_run") or first_target(
                    pool_id, "beta_sequencing_run"
                )
                if run_id:
                    for edge in edge_matches(relationship_type="beta_run_artifact"):
                        source = _clean_str(edge.get("source"))
                        target = _clean_str(edge.get("target"))
                        if target == run_id:
                            fastq_ids.append(source)
                        elif source == run_id:
                            fastq_ids.append(target)

            add_bloom_story_edges(
                add_story_edge,
                context=BloomStoryContext(
                    specimen_content_id=remote_specimen_id,
                    specimen_container_id=specimen_container_id,
                    extraction_output_id=extraction_output_id,
                    extraction_container_id=well_id,
                    extraction_container_parent_id=plate_id,
                    library_prep_output_id=library_prep_id,
                    library_material_id=library_material_id,
                    library_container_id=library_container_id,
                    library_container_parent_id=library_container_parent_id,
                    pool_content_id=pool_id,
                    pool_container_id=pool_tube_id,
                    run_id=run_id,
                    fastq_ids=tuple(fastq_ids),
                ),
            )

        projected_nodes = [
            node_by_id[node_id] for node_id in selected_node_ids if node_id in node_by_id
        ]
        meta = dict(payload.get("meta") or {})
        meta.update(
            {
                "story_graph": True,
                "story_node_count": len(projected_nodes),
                "story_edge_count": len(story_edges),
            }
        )
        return {
            "elements": {
                "nodes": projected_nodes,
                "edges": story_edges,
            },
            "meta": meta,
        }

    def _build_start_graph(
        self,
        *,
        start_euid: str,
        depth: int,
        tenant_scope: uuid.UUID,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], bool]:
        start_obj = (
            self.db.execute(
                select(generic_instance).where(
                    and_(
                        generic_instance.euid == start_euid,
                        generic_instance.is_deleted.is_(False),
                    )
                )
            )
            .scalars()
            .first()
        )
        if start_obj is None or not self._instance_visible(start_obj, tenant_scope):
            return [], [], False

        max_nodes = max(1, settings.graph_max_nodes)
        max_edges = max(1, settings.graph_max_edges)

        node_map: dict[str, dict[str, Any]] = {}
        edge_map: dict[str, dict[str, Any]] = {}
        queued_ids: set[str] = {start_obj.euid}
        queue: deque[tuple[generic_instance, int]] = deque([(start_obj, 0)])
        truncated = False

        while queue and not truncated:
            current, level = queue.popleft()
            current_id = current.euid
            if not current_id or current_id in node_map:
                continue

            if len(node_map) >= max_nodes:
                truncated = True
                break

            node_map[current_id] = self._node_payload(current)

            if level >= depth:
                continue

            for lineage, parent, child in self._adjacent_visible_lineage(
                instance_uid=current.uid,
                tenant_scope=tenant_scope,
            ):
                edge_id = lineage.euid or f"lineage-{lineage.uid}"
                if edge_id not in edge_map:
                    if len(edge_map) >= max_edges:
                        truncated = True
                        break
                    edge_map[edge_id] = self._edge_payload(
                        lineage=lineage,
                        parent=parent,
                        child=child,
                    )

                neighbor = child if parent.uid == current.uid else parent
                neighbor_id = neighbor.euid
                if not neighbor_id:
                    continue
                if neighbor_id in node_map or neighbor_id in queued_ids:
                    continue

                if len(node_map) + len(queued_ids) >= max_nodes:
                    truncated = True
                    continue

                queue.append((neighbor, level + 1))
                queued_ids.add(neighbor_id)

        nodes = sorted(node_map.values(), key=lambda item: item["data"]["id"])
        visible_node_ids = {node["data"]["id"] for node in nodes}
        edges = [
            edge
            for edge in edge_map.values()
            if edge["data"].get("source") in visible_node_ids
            and edge["data"].get("target") in visible_node_ids
        ]
        edges.sort(key=lambda item: item["data"]["id"])
        return nodes, edges, truncated

    def _build_recent_graph(
        self,
        *,
        tenant_scope: uuid.UUID,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], bool]:
        max_nodes = max(1, settings.graph_max_nodes)
        max_edges = max(1, settings.graph_max_edges)

        candidates = self._fetch_recent_visible_instances(
            tenant_scope=tenant_scope,
            limit=max_nodes + 1,
        )
        node_truncated = len(candidates) > max_nodes
        instances = candidates[:max_nodes]

        node_map = {inst.euid: self._node_payload(inst) for inst in instances if inst.euid}
        if not node_map:
            return [], [], node_truncated

        lineage_rows = self._lineage_for_instance_set(
            instance_uids=[inst.uid for inst in instances if inst.euid],
            tenant_scope=tenant_scope,
            limit=max_edges + 1,
        )
        edge_truncated = len(lineage_rows) > max_edges

        edge_map: dict[str, dict[str, Any]] = {}
        for lineage, parent, child in lineage_rows[:max_edges]:
            edge_id = lineage.euid or f"lineage-{lineage.uid}"
            edge_payload = self._edge_payload(lineage=lineage, parent=parent, child=child)
            source = edge_payload["data"]["source"]
            target = edge_payload["data"]["target"]
            if source in node_map and target in node_map:
                edge_map[edge_id] = edge_payload

        nodes = sorted(node_map.values(), key=lambda item: item["data"]["id"])
        edges = sorted(edge_map.values(), key=lambda item: item["data"]["id"])
        return nodes, edges, node_truncated or edge_truncated

    def _instance_visible(self, instance: generic_instance, tenant_scope: uuid.UUID) -> bool:
        instance_tenant_id = _instance_tenant_id(instance)
        if instance_tenant_id is None:
            return False
        return instance_tenant_id == tenant_scope

    def _fetch_recent_visible_instances(
        self,
        *,
        tenant_scope: uuid.UUID,
        limit: int,
    ) -> list[generic_instance]:
        batch_size = max(200, min(2000, limit * 3))
        offset = 0
        found: list[generic_instance] = []

        while len(found) < limit and offset <= batch_size * 20:
            stmt = (
                select(generic_instance)
                .where(generic_instance.is_deleted.is_(False))
                .order_by(
                    desc(generic_instance.modified_dt),
                    desc(generic_instance.created_dt),
                    desc(generic_instance.uid),
                )
                .offset(offset)
                .limit(batch_size)
            )
            batch = self.db.execute(stmt).scalars().all()
            if not batch:
                break

            for instance in batch:
                if not instance.euid:
                    continue
                if not self._instance_visible(instance, tenant_scope):
                    continue
                found.append(instance)
                if len(found) >= limit:
                    break

            offset += batch_size

        return found

    def _adjacent_visible_lineage(
        self,
        *,
        instance_uid: int,
        tenant_scope: uuid.UUID,
    ) -> list[tuple[generic_instance_lineage, generic_instance, generic_instance]]:
        parent_alias = aliased(generic_instance)
        child_alias = aliased(generic_instance)

        stmt = (
            select(generic_instance_lineage, parent_alias, child_alias)
            .join(parent_alias, parent_alias.uid == generic_instance_lineage.parent_instance_uid)
            .join(child_alias, child_alias.uid == generic_instance_lineage.child_instance_uid)
            .where(
                and_(
                    generic_instance_lineage.is_deleted.is_(False),
                    parent_alias.is_deleted.is_(False),
                    child_alias.is_deleted.is_(False),
                    or_(
                        generic_instance_lineage.parent_instance_uid == instance_uid,
                        generic_instance_lineage.child_instance_uid == instance_uid,
                    ),
                )
            )
            .order_by(desc(generic_instance_lineage.created_dt), desc(generic_instance_lineage.uid))
        )

        rows = self.db.execute(stmt).all()
        visible: list[tuple[generic_instance_lineage, generic_instance, generic_instance]] = []
        for lineage, parent, child in rows:
            if not self._instance_visible(parent, tenant_scope):
                continue
            if not self._instance_visible(child, tenant_scope):
                continue
            if not parent.euid or not child.euid:
                continue
            visible.append((lineage, parent, child))
        return visible

    def _lineage_for_instance_set(
        self,
        *,
        instance_uids: list[int],
        tenant_scope: uuid.UUID,
        limit: int,
    ) -> list[tuple[generic_instance_lineage, generic_instance, generic_instance]]:
        if not instance_uids:
            return []

        parent_alias = aliased(generic_instance)
        child_alias = aliased(generic_instance)

        stmt = (
            select(generic_instance_lineage, parent_alias, child_alias)
            .join(parent_alias, parent_alias.uid == generic_instance_lineage.parent_instance_uid)
            .join(child_alias, child_alias.uid == generic_instance_lineage.child_instance_uid)
            .where(
                and_(
                    generic_instance_lineage.is_deleted.is_(False),
                    parent_alias.is_deleted.is_(False),
                    child_alias.is_deleted.is_(False),
                    generic_instance_lineage.parent_instance_uid.in_(instance_uids),
                    generic_instance_lineage.child_instance_uid.in_(instance_uids),
                )
            )
            .order_by(desc(generic_instance_lineage.created_dt), desc(generic_instance_lineage.uid))
            .limit(limit)
        )

        rows = self.db.execute(stmt).all()
        visible: list[tuple[generic_instance_lineage, generic_instance, generic_instance]] = []
        for lineage, parent, child in rows:
            if not self._instance_visible(parent, tenant_scope):
                continue
            if not self._instance_visible(child, tenant_scope):
                continue
            if not parent.euid or not child.euid:
                continue
            visible.append((lineage, parent, child))
        return visible

    def _find_visible_lineage(
        self,
        euid: str,
        tenant_scope: uuid.UUID,
    ) -> tuple[generic_instance_lineage, generic_instance, generic_instance] | None:
        parent_alias = aliased(generic_instance)
        child_alias = aliased(generic_instance)

        stmt = (
            select(generic_instance_lineage, parent_alias, child_alias)
            .join(parent_alias, parent_alias.uid == generic_instance_lineage.parent_instance_uid)
            .join(child_alias, child_alias.uid == generic_instance_lineage.child_instance_uid)
            .where(
                and_(
                    generic_instance_lineage.euid == euid,
                    generic_instance_lineage.is_deleted.is_(False),
                    parent_alias.is_deleted.is_(False),
                    child_alias.is_deleted.is_(False),
                )
            )
        )

        row = self.db.execute(stmt).first()
        if row is None:
            return None

        lineage, parent, child = row
        if not self._instance_visible(parent, tenant_scope):
            return None
        if not self._instance_visible(child, tenant_scope):
            return None
        if not parent.euid or not child.euid:
            return None
        return lineage, parent, child

    def _find_visible_instance_by_euid(
        self,
        euid: str,
        tenant_scope: uuid.UUID,
    ) -> generic_instance | None:
        clean_euid = _clean_str(euid)
        if not clean_euid:
            return None
        instance = (
            self.db.execute(
                select(generic_instance).where(
                    and_(
                        generic_instance.euid == clean_euid,
                        generic_instance.is_deleted.is_(False),
                    )
                )
            )
            .scalars()
            .first()
        )
        if instance is None or not self._instance_visible(instance, tenant_scope):
            return None
        return instance

    def _external_ref_by_index(
        self,
        instance: generic_instance,
        tenant_scope: uuid.UUID,
        ref_index: int,
    ) -> ExternalGraphRef:
        refs = self._resolve_external_refs_for_instance(instance, tenant_scope)
        if ref_index < 0 or ref_index >= len(refs):
            raise GraphExternalReferenceError("External reference not found")
        return refs[ref_index]

    def _resolve_external_refs_for_instance(
        self,
        instance: generic_instance,
        tenant_scope: uuid.UUID | None,
    ) -> list[ExternalGraphRef]:
        if tenant_scope is None or not instance.euid:
            return []
        if self._instance_template_code(instance) != EXTERNAL_OBJECT_TEMPLATE_CODE:
            return []

        external_objects = ExternalObjectService(self.db, tenant_scope)
        resolver = BloomConfigResolverService(self.db)
        external_object = external_objects.get_external_object_by_id(instance.euid)
        if external_object is None or external_object.is_deleted:
            return []
        if _clean_str(getattr(external_object, "provider", "")) != "bloom":
            return []

        object_meta = external_object.metadata if isinstance(external_object.metadata, dict) else {}
        site_id = _clean_str(object_meta.get("site_id")) or None
        if site_id is None:
            for relation in external_objects.list_relations_for_external_object(instance.euid):
                relation_meta = relation.metadata if isinstance(relation.metadata, dict) else {}
                site_id = _clean_str(relation_meta.get("site_id")) or None
                if site_id is not None:
                    break
        config = resolver.get_effective(
            organization_id=tenant_scope,
            site_id=site_id,
        )

        root_euid = _clean_str(getattr(external_object, "external_euid", ""))
        href = None
        if config is not None and config.bloom_base_url and root_euid:
            href = f"{config.bloom_base_url}/euid_details?{urlencode({'euid': root_euid})}"

        missing: list[str] = []
        if not root_euid:
            missing.append("root_euid")
        if config is None:
            missing.append("bloom config")
        else:
            if not config.bloom_base_url:
                missing.append("bloom_base_url")
            if not config.bloom_api_key_secret_ref:
                missing.append("bloom_api_key_secret_ref")
            else:
                try:
                    resolve_secret_value(config.bloom_api_key_secret_ref)
                except BloomClientError:
                    missing.append("resolved Bloom API key")

        reason = None
        graph_expandable = True
        if missing:
            graph_expandable = False
            reason = "Missing Bloom graph metadata: " + ", ".join(missing)

        ref = ExternalGraphRef(
            label=self._external_ref_label(
                external_object_id=instance.euid,
                system="bloom",
                root_euid=root_euid,
            ),
            system="bloom",
            root_euid=root_euid,
            external_object_id=instance.euid,
            tenant_id=site_id,
            href=href,
            graph_expandable=graph_expandable,
            reason=reason,
            base_url=config.bloom_base_url if config is not None else None,
            api_key_secret_ref=(config.bloom_api_key_secret_ref if config is not None else None),
        )
        return [ref]

    def _build_bloom_client(self, ref: ExternalGraphRef) -> BloomClient:
        if not ref.base_url or not ref.api_key_secret_ref:
            raise GraphExternalReferenceError(ref.reason or "External graph unavailable")
        api_key = resolve_secret_value(ref.api_key_secret_ref)
        return BloomClient(
            base_url=ref.base_url,
            api_key=api_key,
            timeout_seconds=settings.bloom_request_timeout_seconds,
            max_retries=settings.bloom_max_retries,
            verify_ssl=settings.bloom_verify_ssl,
        )

    def _namespace_external_graph(
        self,
        payload: dict[str, Any],
        *,
        ref: ExternalGraphRef,
        ref_index: int,
        source_euid: str,
    ) -> dict[str, Any]:
        elements = _as_json_dict(payload.get("elements"))
        nodes = elements.get("nodes") if isinstance(elements.get("nodes"), list) else []
        edges = elements.get("edges") if isinstance(elements.get("edges"), list) else []
        namespace = f"ext::{ref.system}::{ref.tenant_id or 'global'}"

        def namespaced_id(raw_id: Any) -> str:
            return f"{namespace}::{_clean_str(raw_id)}"

        namespaced_nodes: list[dict[str, Any]] = []
        for node in nodes:
            if not isinstance(node, dict):
                continue
            data = _as_json_dict(node.get("data"))
            remote_euid = _clean_str(data.get("euid") or data.get("id"))
            if not remote_euid:
                continue
            node_data = dict(data)
            node_data["id"] = namespaced_id(remote_euid)
            node_data["remote_euid"] = remote_euid
            node_data["name"] = self._remote_node_display_name(ref.system, node_data)
            node_data["is_external"] = True
            node_data["system"] = ref.system
            node_data["external_system"] = ref.system
            node_data["external_tenant_id"] = ref.tenant_id
            node_data["source_ref_index"] = ref_index
            node_data["external_source_euid"] = source_euid
            if ref.base_url:
                node_data["href"] = (
                    f"{ref.base_url.rstrip('/')}/euid_details?{urlencode({'euid': remote_euid})}"
                )
                node_data["page_kind"] = "euid_details"
            namespaced_nodes.append({"data": node_data})

        namespaced_edges: list[dict[str, Any]] = []
        for edge in edges:
            if not isinstance(edge, dict):
                continue
            data = _as_json_dict(edge.get("data"))
            remote_edge_id = _clean_str(data.get("id"))
            edge_source = _clean_str(data.get("source"))
            edge_target = _clean_str(data.get("target"))
            if not remote_edge_id or not edge_source or not edge_target:
                continue
            edge_data = dict(data)
            edge_data["id"] = namespaced_id(remote_edge_id)
            edge_data["source"] = namespaced_id(edge_source)
            edge_data["target"] = namespaced_id(edge_target)
            edge_data["remote_euid"] = remote_edge_id
            edge_data["is_external"] = True
            edge_data["external_system"] = ref.system
            edge_data["external_tenant_id"] = ref.tenant_id
            edge_data["source_ref_index"] = ref_index
            edge_data["external_source_euid"] = source_euid
            namespaced_edges.append({"data": edge_data})

        namespaced_edges.append(
            {
                "data": {
                    "id": (
                        f"bridge::{source_euid}::{ref.system}::"
                        f"{ref.tenant_id or 'global'}::{ref.root_euid}"
                    ),
                    "source": source_euid,
                    "target": namespaced_id(ref.root_euid),
                    "relationship_type": "external_reference",
                    "is_external_bridge": True,
                    "external_system": ref.system,
                    "external_tenant_id": ref.tenant_id,
                    "source_ref_index": ref_index,
                    "external_source_euid": source_euid,
                }
            }
        )

        return {
            "elements": {
                "nodes": namespaced_nodes,
                "edges": namespaced_edges,
            },
            "meta": {
                "source_euid": source_euid,
                "root_euid": ref.root_euid,
                "system": ref.system,
                "tenant_id": ref.tenant_id,
                "ref_index": ref_index,
                "node_count": len(namespaced_nodes),
                "edge_count": len(namespaced_edges),
            },
        }

    def _node_payload(self, instance: generic_instance) -> dict[str, Any]:
        display_label = self._instance_display_label(instance)
        template_code = self._instance_template_code(instance)
        href, page_kind = _atlas_page_link(euid=instance.euid, template_code=template_code)
        data = {
            "id": instance.euid,
            "euid": instance.euid,
            "name": self._local_node_name(instance.euid, display_label),
            "display_label": display_label or instance.euid,
            "type": instance.type,
            "obj_type": instance.type,
            "category": instance.category,
            "subtype": instance.subtype,
            "version": instance.version,
            "bstatus": instance.bstatus,
            "color": _CATEGORY_COLORS.get(instance.category, _DEFAULT_NODE_COLOR),
            "system": "atlas",
            "href": href,
            "page_kind": page_kind,
        }
        if template_code == EXTERNAL_OBJECT_TEMPLATE_CODE:
            external_object = ExternalObjectService(
                self.db, self.tenant_id
            ).get_external_object_by_id(instance.euid)
            if external_object is not None:
                data["external_system"] = external_object.provider
                data["external_euid"] = external_object.external_euid
        return {"data": data}

    def _edge_payload(
        self,
        *,
        lineage: generic_instance_lineage,
        parent: generic_instance,
        child: generic_instance,
    ) -> dict[str, Any]:
        return {
            "data": {
                "id": lineage.euid or f"lineage-{lineage.uid}",
                "source": child.euid,
                "target": parent.euid,
                "relationship_type": lineage.relationship_type or "generic",
            }
        }

    def _instance_detail(self, instance: generic_instance) -> dict[str, Any]:
        display_label = self._instance_display_label(instance)
        return {
            "record_type": "instance",
            "uid": instance.uid,
            "euid": instance.euid,
            "name": self._local_node_name(instance.euid, display_label),
            "display_label": display_label or instance.euid,
            "type": instance.type,
            "obj_type": instance.type,
            "category": instance.category,
            "subtype": instance.subtype,
            "version": instance.version,
            "bstatus": instance.bstatus,
            "json_addl": _as_json_dict(instance.json_addl),
            "created_dt": _iso(instance.created_dt),
            "modified_dt": _iso(instance.modified_dt),
            "external_refs": [
                ref.to_public_dict(ref_index=index)
                for index, ref in enumerate(
                    self._resolve_external_refs_for_instance(
                        instance, _instance_tenant_id(instance)
                    )
                )
            ],
        }

    @staticmethod
    def _instance_template_code(instance: generic_instance) -> str:
        return f"{instance.category}/{instance.type}/{instance.subtype}/{instance.version}/"

    @staticmethod
    def _local_node_name(euid: str, display_label: str | None) -> str:
        clean_euid = _clean_str(euid)
        clean_label = _clean_str(display_label)
        if clean_label and clean_label != clean_euid:
            return f"{clean_euid} | {clean_label}"
        return clean_euid or clean_label

    @staticmethod
    def _external_ref_label(*, external_object_id: str, system: str, root_euid: str) -> str:
        parts = [_clean_str(external_object_id), _clean_str(system), _clean_str(root_euid)]
        return " | ".join(part for part in parts if part)

    def _instance_display_label(self, instance: generic_instance) -> str | None:
        template_code = self._instance_template_code(instance)
        props = _as_json_dict(_as_json_dict(instance.json_addl).get("properties"))
        if template_code == PATIENT_TEMPLATE_CODE:
            revision_props = self._latest_child_properties(instance, PATIENT_REV_TEMPLATE_CODE)
            patient_name = " ".join(
                part
                for part in [
                    _clean_str(revision_props.get("first_name")),
                    _clean_str(revision_props.get("last_name")),
                ]
                if part
            )
            return patient_name or None
        if template_code == CLINICIAN_TEMPLATE_CODE:
            revision_props = self._latest_child_properties(instance, CLINICIAN_REV_TEMPLATE_CODE)
            clinician_name = " ".join(
                part
                for part in [
                    _clean_str(revision_props.get("first_name")),
                    _clean_str(revision_props.get("last_name")),
                ]
                if part
            )
            return clinician_name or None
        if template_code == SITE_TEMPLATE_CODE:
            revision_props = self._latest_child_properties(instance, SITE_REV_TEMPLATE_CODE)
            return _clean_str(revision_props.get("name")) or None
        if template_code == ORG_TEMPLATE_CODE:
            revision_props = self._latest_child_properties(instance, ORG_REV_TEMPLATE_CODE)
            return (
                _clean_str(revision_props.get("display_name"))
                or _clean_str(revision_props.get("name"))
                or None
            )
        if template_code == TEST_KIT_TEMPLATE_CODE:
            return _clean_str(props.get("kit_barcode")) or None
        if template_code == SHIPMENT_TEMPLATE_CODE:
            shipment_number = _clean_str(props.get("shipment_number"))
            return shipment_number or None
        if template_code == TRF_TEMPLATE_CODE:
            return _clean_str(props.get("order_number")) or None
        if template_code == TEST_TEMPLATE_CODE:
            revision = TapdbTrfRepository(self.db).get_latest_test_revision(instance.euid)
            if revision is not None:
                return _clean_str(revision.product_name or revision.product_code) or None
            return None
        if template_code == EXTERNAL_OBJECT_TEMPLATE_CODE:
            external_object = ExternalObjectService(
                self.db, self.tenant_id
            ).get_external_object_by_id(instance.euid)
            if external_object is not None:
                provider = _clean_str(external_object.provider)
                external_euid = _clean_str(external_object.external_euid)
                parts = [provider, external_euid]
                return " | ".join(part for part in parts if part) or None
            provider = _clean_str(props.get("provider"))
            external_euid = _clean_str(props.get("external_euid"))
            parts = [provider, external_euid]
            return " | ".join(part for part in parts if part) or None
        fallback = (
            _clean_str(props.get("filename"))
            or _clean_str(props.get("display_name"))
            or _clean_str(instance.name)
        )
        return fallback or None

    def _latest_child_properties(
        self,
        instance: generic_instance,
        child_template_code: str,
    ) -> dict[str, Any]:
        children = get_child_instances(self.db, instance, child_template_code)
        if not children:
            return {}
        latest = children[0]
        return _as_json_dict(_as_json_dict(latest.json_addl).get("properties"))

    @staticmethod
    def _remote_node_display_name(system: str, node_data: dict[str, Any]) -> str:
        remote_euid = _clean_str(node_data.get("remote_euid") or node_data.get("euid"))
        base_name = _clean_str(node_data.get("name"))
        object_label = _clean_str(node_data.get("obj_type") or node_data.get("type"))
        if base_name and base_name != remote_euid:
            return f"{base_name} | {remote_euid}"
        if object_label and remote_euid:
            return f"{system} {object_label} | {remote_euid}"
        return remote_euid or base_name or system

    def _template_detail(self, template: generic_template) -> dict[str, Any]:
        return {
            "record_type": "template",
            "uid": template.uid,
            "euid": template.euid,
            "name": template.name,
            "type": template.type,
            "obj_type": template.type,
            "category": template.category,
            "subtype": template.subtype,
            "version": template.version,
            "bstatus": template.bstatus,
            "json_addl": _as_json_dict(template.json_addl),
            "created_dt": _iso(template.created_dt),
            "modified_dt": _iso(template.modified_dt),
        }

    def _lineage_detail(
        self,
        *,
        lineage: generic_instance_lineage,
        parent: generic_instance,
        child: generic_instance,
    ) -> dict[str, Any]:
        return {
            "record_type": "lineage",
            "uid": lineage.uid,
            "euid": lineage.euid,
            "name": lineage.name,
            "type": lineage.type,
            "obj_type": lineage.type,
            "category": lineage.category,
            "subtype": lineage.subtype,
            "version": lineage.version,
            "bstatus": lineage.bstatus,
            "json_addl": _as_json_dict(lineage.json_addl),
            "created_dt": _iso(lineage.created_dt),
            "modified_dt": _iso(lineage.modified_dt),
            "source": child.euid,
            "target": parent.euid,
            "relationship_type": lineage.relationship_type or "generic",
            "parent_instance_uid": parent.uid,
            "child_instance_uid": child.uid,
        }
