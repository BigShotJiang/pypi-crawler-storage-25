"""LSMC Hub - Webhook Service.

Provides operations for:
- Managing webhook subscriptions
- Delivering webhook events
- Retry logic with exponential backoff
- HMAC signature generation
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import ipaddress
import json
import logging
import socket
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any
from urllib.parse import urlparse

import httpx

from app.persistence.tapdb.webhooks import TapdbWebhookRepository

logger = logging.getLogger(__name__)


def _validate_webhook_url(url: str) -> None:
    """Validate webhook URL to prevent SSRF attacks.

    Rejects URLs targeting:
    - Private IP ranges (RFC 1918: 10.x, 172.16-31.x, 192.168.x)
    - Loopback (127.x, ::1)
    - Link-local (169.254.x, fe80::)
    - AWS metadata endpoint (169.254.169.254)
    - Non-HTTP(S) schemes
    - Hostnames that resolve to private IPs

    Raises:
        ValueError: If URL targets a private/restricted address
    """
    parsed = urlparse(url)

    # Only allow http and https
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Webhook URL scheme must be http or https, got: {parsed.scheme}")

    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Webhook URL must have a hostname")

    # Resolve hostname to IP and check against blocked ranges
    try:
        addr_infos = socket.getaddrinfo(hostname, parsed.port or 443, proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        raise ValueError(f"Cannot resolve webhook hostname: {hostname}")

    for _family, _, _, _, sockaddr in addr_infos:
        ip = ipaddress.ip_address(sockaddr[0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise ValueError(
                f"Webhook URL resolves to restricted IP address: {ip} (hostname: {hostname})"
            )


@dataclass
class WebhookSubscriptionCreate:
    """Data for creating a webhook subscription."""

    subscription_name: str
    url: str
    secret: str
    event_types: list[str]
    headers: dict | None = None
    timeout_seconds: int = 30
    max_retries: int = 3
    site_id: str | None = None


@dataclass
class WebhookSubscriptionUpdate:
    """Data for updating a webhook subscription."""

    url: str | None = None
    secret: str | None = None
    event_types: list[str] | None = None
    is_active: bool | None = None
    headers: dict | None = None
    timeout_seconds: int | None = None
    max_retries: int | None = None
    note: str | None = None


@dataclass
class WebhookEvent:
    """Webhook event to deliver."""

    event_type: str
    event_id: str
    payload: dict
    timestamp: datetime


class WebhookService:
    """Service for webhook operations."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: str | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: TapdbWebhookRepository | None = None

    def _repo(self) -> TapdbWebhookRepository:
        if self._tapdb_repo is None:
            self._tapdb_repo = TapdbWebhookRepository(self.db)
        return self._tapdb_repo

    def create(
        self,
        data: WebhookSubscriptionCreate,
        created_by: uuid.UUID | None = None,
    ):
        """Create a new webhook subscription."""
        _validate_webhook_url(data.url)
        from app.domain.services.site_scope import resolve_tenant_site_euid

        data.site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.site_id)
        return self._repo().create_subscription(
            tenant_id=self.tenant_id,
            data=data,
            created_by=created_by,
        )

    def get(self, subscription_id: str):
        """Get a webhook subscription by ID."""
        return self._repo().get_subscription(
            subscription_id=subscription_id,
            tenant_id=self.tenant_id,
        )

    def list(self, skip: int = 0, limit: int = 100):
        """List all webhook subscriptions for tenant."""
        return self._repo().list_subscriptions(
            tenant_id=self.tenant_id,
            skip=skip,
            limit=limit,
        )

    def update(
        self,
        subscription_id: str,
        data: WebhookSubscriptionUpdate,
        updated_by: uuid.UUID | None = None,
    ):
        """Update a webhook subscription (creates new revision)."""
        if data.url is not None:
            _validate_webhook_url(data.url)
        return self._repo().update_subscription(
            tenant_id=self.tenant_id,
            subscription_id=subscription_id,
            data=data,
            updated_by=updated_by,
        )

    def _generate_signature(self, payload: str, secret: str) -> str:
        """Generate HMAC SHA256 signature for webhook payload."""
        return hmac.new(
            secret.encode("utf-8"),
            payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def deliver(
        self,
        event: WebhookEvent,
        max_retries: int | None = None,
    ) -> None:
        """Deliver a webhook event to all subscribed endpoints.

        This method finds all active subscriptions for the event type
        and delivers the event to each endpoint with retry logic.
        """
        subscriptions = self._repo().list_active_subscriptions_for_event(
            tenant_id=self.tenant_id,
            event_type=event.event_type,
        )

        for subscription, revision in subscriptions:
            self._deliver_to_subscription(subscription, revision, event, max_retries)

    def _deliver_to_subscription(
        self,
        subscription: Any,
        revision: Any,
        event: WebhookEvent,
        max_retries: int | None = None,
    ) -> None:
        """Deliver event to a single subscription (synchronous, single attempt).

        For production use, prefer deliver_async() with BackgroundTasks.
        """
        max_attempts = max_retries if max_retries is not None else revision.max_retries
        payload_dict: dict = {}

        for attempt in range(1, max_attempts + 1):
            try:
                payload_dict = {
                    "event_type": event.event_type,
                    "event_id": str(event.event_id),
                    "timestamp": event.timestamp.isoformat(),
                    "data": event.payload,
                }
                payload_str = json.dumps(payload_dict, sort_keys=True)

                signature = self._generate_signature(payload_str, revision.secret)

                headers = {
                    "Content-Type": "application/json",
                    "X-Webhook-Signature": f"sha256={signature}",
                    "X-Webhook-Event-Type": event.event_type,
                    "X-Webhook-Event-ID": str(event.event_id),
                }
                if revision.headers:
                    headers.update(revision.headers)

                _validate_webhook_url(revision.url)

                response = httpx.post(
                    revision.url,
                    content=payload_str,
                    headers=headers,
                    timeout=revision.timeout_seconds,
                )

                self._repo().log_delivery(
                    tenant_id=self.tenant_id,
                    subscription_id=subscription.id,
                    event_type=event.event_type,
                    event_id=event.event_id,
                    payload=payload_dict,
                    url=revision.url,
                    attempt_number=attempt,
                    http_status=response.status_code,
                    response_body=response.text[:1000] if response.text else None,
                    error_message=None if response.is_success else f"HTTP {response.status_code}",
                )

                if response.is_success:
                    logger.info(
                        f"Webhook delivered successfully: event={event.event_type}, "
                        f"subscription={subscription.id}, attempt={attempt}"
                    )
                    break
                else:
                    logger.warning(
                        f"Webhook delivery failed: event={event.event_type}, "
                        f"subscription={subscription.id}, attempt={attempt}, "
                        f"status={response.status_code}"
                    )

            except Exception as e:
                logger.error(
                    f"Webhook delivery error: event={event.event_type}, "
                    f"subscription={subscription.id}, attempt={attempt}, error={e}"
                )
                self._repo().log_delivery(
                    tenant_id=self.tenant_id,
                    subscription_id=subscription.id,
                    event_type=event.event_type,
                    event_id=event.event_id,
                    payload=payload_dict,
                    url=revision.url,
                    attempt_number=attempt,
                    http_status=None,
                    response_body=None,
                    error_message=str(e)[:1000],
                )

            # Note: No blocking sleep here - for retries with backoff, use deliver_async()
            # This method does a single synchronous attempt per call
            if attempt < max_attempts:
                # For sync delivery, we skip retries to avoid blocking
                # Use deliver_async() for proper retry with backoff
                logger.warning(
                    f"Skipping retry in sync mode for subscription={subscription.id}. "
                    "Use deliver_async() for proper retry with backoff."
                )
                break

    def get_delivery_logs(
        self,
        subscription_id: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
    ):
        """Get webhook delivery logs."""
        return self._repo().get_delivery_logs(
            tenant_id=self.tenant_id,
            subscription_id=subscription_id,
            event_type=event_type,
            limit=limit,
        )


async def deliver_webhook_async(
    tenant_id: uuid.UUID,
    subscription_id: str,
    url: str,
    secret: str,
    event: WebhookEvent,
    headers: dict | None = None,
    timeout_seconds: int = 30,
    max_retries: int = 3,
) -> dict:
    """Deliver a webhook event asynchronously with retry logic.

    This function is designed to be used with FastAPI's BackgroundTasks
    or called from an async context. It uses httpx.AsyncClient for
    non-blocking HTTP requests and asyncio.sleep for non-blocking backoff.

    Args:
        tenant_id: Tenant ID for logging
        subscription_id: Subscription ID for logging
        url: Webhook endpoint URL
        secret: HMAC secret for signature
        event: Webhook event to deliver
        headers: Optional additional headers
        timeout_seconds: Request timeout
        max_retries: Maximum number of retry attempts

    Returns:
        Dict with delivery result including success status and attempt count
    """
    # Prepare payload
    payload_dict = {
        "event_type": event.event_type,
        "event_id": str(event.event_id),
        "timestamp": event.timestamp.isoformat(),
        "data": event.payload,
    }
    payload_str = json.dumps(payload_dict, sort_keys=True)

    # Generate signature
    signature = hmac.new(
        secret.encode("utf-8"),
        payload_str.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    # Prepare headers
    request_headers = {
        "Content-Type": "application/json",
        "X-Webhook-Signature": f"sha256={signature}",
        "X-Webhook-Event-Type": event.event_type,
        "X-Webhook-Event-ID": str(event.event_id),
    }
    if headers:
        request_headers.update(headers)

    # Validate URL before making request (SSRF prevention)
    _validate_webhook_url(url)

    last_error: str | None = None
    last_status: int | None = None

    async with httpx.AsyncClient() as client:
        for attempt in range(1, max_retries + 1):
            try:
                response = await client.post(
                    url,
                    content=payload_str,
                    headers=request_headers,
                    timeout=timeout_seconds,
                )

                last_status = response.status_code

                if response.is_success:
                    logger.info(
                        f"Webhook delivered successfully: event={event.event_type}, "
                        f"subscription={subscription_id}, attempt={attempt}"
                    )
                    return {
                        "success": True,
                        "attempt": attempt,
                        "status_code": response.status_code,
                        "error": None,
                    }
                else:
                    last_error = f"HTTP {response.status_code}"
                    logger.warning(
                        f"Webhook delivery failed: event={event.event_type}, "
                        f"subscription={subscription_id}, attempt={attempt}, "
                        f"status={response.status_code}"
                    )

            except Exception as e:
                last_error = str(e)
                logger.error(
                    f"Webhook delivery error: event={event.event_type}, "
                    f"subscription={subscription_id}, attempt={attempt}, error={e}"
                )

            # Exponential backoff before retry (non-blocking)
            if attempt < max_retries:
                backoff_seconds = 2**attempt  # 2, 4, 8, 16, ...
                logger.debug(
                    f"Webhook retry backoff: {backoff_seconds}s before attempt {attempt + 1}"
                )
                await asyncio.sleep(backoff_seconds)

    return {
        "success": False,
        "attempt": max_retries,
        "status_code": last_status,
        "error": last_error,
    }
