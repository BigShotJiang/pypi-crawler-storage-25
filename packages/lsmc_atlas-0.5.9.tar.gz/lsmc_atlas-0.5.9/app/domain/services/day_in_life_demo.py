"""Concrete local "A Day In The Life" demo orchestration."""

from __future__ import annotations

import copy
import json
import os
import re
import socket
import ssl
import subprocess
import time
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import httpx

from app.domain.enums import OrderPatientRole, TestOrderStatus
from app.domain.services.accessioning_workbench import (
    AccessioningWorkbenchService,
    CaptureReadyForReviewRequest,
    MinimalChildRegistrationRequest,
    ReceiptRegistrationRequest,
)
from app.domain.services.bloom_bridge import (
    AcceptedMaterialRequest,
    ContainerSpecimenBridgeService,
    TubeCreationRequest,
)
from app.domain.services.bloom_status_events import BloomStatusEventService
from app.domain.services.collection_events import CollectionEventCreate, CollectionEventService
from app.domain.services.documents import DocumentPlaceholder, DocumentService
from app.domain.services.external_objects import (
    BloomConfigResolverService,
    ExternalObjectRelationCreate,
    ExternalObjectService,
)
from app.domain.services.graph_viewer import ExternalGraphRef, GraphViewerService
from app.domain.services.order_relationships import OrderPatientLink
from app.domain.services.orgs import OrganizationService, SiteService
from app.domain.services.people import ClinicianService, PatientService
from app.domain.services.shipments import (
    ShipmentCreate,
    ShipmentService,
    TestKitService,
)
from app.domain.services.story_graph_projection import BloomStoryContext, add_bloom_story_edges
from app.domain.services.test_definitions import TestDefinitionService
from app.domain.services.test_fulfillment_items import TestFulfillmentItemService
from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService
from app.domain.services.users import UserService
from app.integrations.bloom_client import BloomClient, BloomClientError, resolve_secret_value
from app.settings import settings

_REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_ATLAS_BASE_URL = "https://localhost:8915"
DEFAULT_BLOOM_BASE_URL = "https://localhost:8912"
DEFAULT_GRAPH_DEPTH = 8


class DayInLifeDemoError(RuntimeError):
    """Raised when the local day-in-life demo cannot proceed."""


@dataclass(slots=True)
class DayInLifeDemoConfig:
    demo_key: str
    actor_email: str = "john@daylilyinformatics.com"
    patient_euid: str = "PAT-1T"
    clinician_euid: str = "CNP-1H"
    site_euid: str = "STX-1K"
    assay_route_code: str = "WGS-short-read"
    assay_name: str = "ILMN short read"
    extraction_well: str = "A1"
    render_screenshot: bool = True
    atlas_base_url: str = DEFAULT_ATLAS_BASE_URL
    output_root: Path = _REPO_ROOT / "output" / "day_in_life"


@dataclass(slots=True)
class DayInLifeDemoArtifacts:
    output_dir: Path
    manifest_path: Path
    graph_elements_path: Path
    html_path: Path
    png_path: Path


@dataclass(slots=True)
class DayInLifeDemoResult:
    config: DayInLifeDemoConfig
    manifest: dict[str, Any]
    artifacts: DayInLifeDemoArtifacts


def _slugify(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", str(value or "").strip().lower())
    return cleaned.strip("-._") or "demo"


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _name_pair(obj: Any, revision: Any | None = None) -> str:
    if revision is not None:
        first = str(getattr(revision, "first_name", "") or "").strip()
        last = str(getattr(revision, "last_name", "") or "").strip()
        full = " ".join(part for part in [first, last] if part)
        if full:
            return full
        for attr in ("display_name", "name", "site_code", "euid"):
            value = str(getattr(revision, attr, "") or "").strip()
            if value:
                return value
    for attr in ("name", "display_name", "email", "euid"):
        value = str(getattr(obj, attr, "") or "").strip()
        if value:
            return value
    return "unknown"


def _latest_revision(obj: Any) -> Any | None:
    revisions = getattr(obj, "revisions", None)
    if isinstance(revisions, list) and revisions:
        return revisions[-1]
    return None


def _dedupe_elements(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []
    for element in elements:
        data = dict(element.get("data") or {})
        element_id = str(data.get("id") or "").strip()
        if not element_id or element_id in seen:
            continue
        seen.add(element_id)
        deduped.append({"data": data})
    return deduped


def merge_graph_payloads(
    local_payload: dict[str, Any],
    external_payloads: list[dict[str, Any]],
) -> dict[str, Any]:
    nodes = list((local_payload.get("elements") or {}).get("nodes") or [])
    edges = list((local_payload.get("elements") or {}).get("edges") or [])
    for payload in external_payloads:
        elements = payload.get("elements") or {}
        nodes.extend(list(elements.get("nodes") or []))
        edges.extend(list(elements.get("edges") or []))
    return {
        "elements": {
            "nodes": _dedupe_elements(nodes),
            "edges": _dedupe_elements(edges),
        },
        "meta": {
            "local_start_euid": (local_payload.get("meta") or {}).get("start_euid"),
            "external_graph_count": len(external_payloads),
        },
    }


def _context_href(*, subtype: str, euid: str) -> tuple[str, str]:
    clean_euid = str(euid or "").strip()
    if not clean_euid:
        return "", "unknown"
    if subtype == "patient":
        return f"/patients/{clean_euid}", "patient_detail"
    if subtype == "clinician":
        return f"/clinicians/{clean_euid}", "clinician_detail"
    if subtype == "site":
        return f"/admin/sites/{clean_euid}", "site_detail"
    if subtype == "organization":
        return f"/admin/organizations/{clean_euid}", "organization_detail"
    return f"/tapdb/object/{clean_euid}", "tapdb_object"


def build_atlas_context_elements(
    manifest: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    patient = dict(manifest.get("patient") or {})
    clinician = dict(manifest.get("clinician") or {})
    site = dict(manifest.get("site") or {})
    organization = dict(manifest.get("organization") or {})
    atlas = dict(manifest.get("atlas") or {})

    trf_euid = str(((atlas.get("trf") or {}).get("euid")) or "").strip()

    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []

    def display_name(euid: str, label: str) -> str:
        clean_euid = str(euid or "").strip()
        clean_label = str(label or "").strip()
        if clean_label and clean_label != clean_euid:
            return f"{clean_euid} | {clean_label}"
        return clean_euid or clean_label

    def add_node(euid: str, *, name: str, obj_type: str, subtype: str, color: str) -> None:
        clean_euid = str(euid or "").strip()
        if not clean_euid:
            return
        href, page_kind = _context_href(subtype=subtype, euid=clean_euid)
        nodes.append(
            {
                "data": {
                    "id": clean_euid,
                    "euid": clean_euid,
                    "name": display_name(clean_euid, str(name or clean_euid)),
                    "type": obj_type,
                    "obj_type": obj_type,
                    "category": "atlas",
                    "subtype": subtype,
                    "color": color,
                    "is_context": True,
                    "system": "atlas",
                    "href": href,
                    "page_kind": page_kind,
                }
            }
        )

    def add_edge(source: str, target: str, relationship_type: str) -> None:
        clean_source = str(source or "").strip()
        clean_target = str(target or "").strip()
        if not clean_source or not clean_target:
            return
        edges.append(
            {
                "data": {
                    "id": f"context-edge::{clean_source}::{relationship_type}::{clean_target}",
                    "source": clean_source,
                    "target": clean_target,
                    "relationship_type": relationship_type,
                    "is_context": True,
                }
            }
        )

    add_node(
        str(patient.get("euid") or ""),
        name=str(patient.get("name") or patient.get("euid") or ""),
        obj_type="people",
        subtype="patient",
        color="#8a8a8a",
    )
    add_node(
        str(clinician.get("euid") or ""),
        name=str(clinician.get("name") or clinician.get("euid") or ""),
        obj_type="people",
        subtype="clinician",
        color="#94a3b8",
    )
    add_node(
        str(site.get("euid") or ""),
        name=str(site.get("name") or site.get("euid") or ""),
        obj_type="core",
        subtype="site",
        color="#38bdf8",
    )
    add_node(
        str(organization.get("euid") or ""),
        name=str(organization.get("name") or organization.get("euid") or ""),
        obj_type="core",
        subtype="organization",
        color="#c084fc",
    )

    add_edge(str(organization.get("euid") or ""), str(site.get("euid") or ""), "contains_site")
    add_edge(str(site.get("euid") or ""), trf_euid, "ordering_site")
    add_edge(str(clinician.get("euid") or ""), trf_euid, "ordering_clinician")

    return nodes, edges


def build_day_in_life_story_graph(
    merged_graph: dict[str, Any],
    *,
    manifest: dict[str, Any],
) -> dict[str, Any]:
    nodes = list((merged_graph.get("elements") or {}).get("nodes") or [])
    nodes_by_id: dict[str, dict[str, Any]] = {}
    remote_node_ids: dict[str, str] = {}
    for node in nodes:
        data = dict(node.get("data") or {})
        node_id = str(data.get("id") or "").strip()
        if not node_id:
            continue
        nodes_by_id[node_id] = {"data": data}
        remote_euid = str(data.get("remote_euid") or "").strip()
        if remote_euid:
            remote_node_ids.setdefault(remote_euid, node_id)

    patient_id = str(((manifest.get("patient") or {}).get("euid")) or "").strip()
    clinician_id = str(((manifest.get("clinician") or {}).get("euid")) or "").strip()
    site_id = str(((manifest.get("site") or {}).get("euid")) or "").strip()
    organization_id = str(((manifest.get("organization") or {}).get("euid")) or "").strip()

    atlas = dict(manifest.get("atlas") or {})
    bloom = dict(manifest.get("bloom") or {})
    graph_meta = dict(manifest.get("graph_meta") or {})

    trf_id = str(((atlas.get("trf") or {}).get("euid")) or "").strip()
    test_id = str(((atlas.get("test") or {}).get("euid")) or "").strip()
    shipment_id = str(((atlas.get("shipment") or {}).get("euid")) or "").strip()
    testkit_id = str(((atlas.get("testkit") or {}).get("euid")) or "").strip()
    collection_event_id = str(((atlas.get("collection_event") or {}).get("euid")) or "").strip()

    tube_bridge_id = str(bloom.get("container_external_object_id") or "").strip()
    specimen_bridge_id = str(bloom.get("specimen_external_object_id") or "").strip()

    bloom_tube_id = remote_node_ids.get(str(bloom.get("container_euid") or "").strip(), "")
    bloom_specimen_id = remote_node_ids.get(str(bloom.get("specimen_euid") or "").strip(), "")
    extraction_output_id = remote_node_ids.get(
        str(bloom.get("extraction_output_euid") or "").strip(), ""
    )
    plate_id = remote_node_ids.get(str(bloom.get("plate_euid") or "").strip(), "")
    well_id = remote_node_ids.get(str(bloom.get("well_euid") or "").strip(), "")
    library_prep_id = remote_node_ids.get(
        str(bloom.get("library_prep_output_euid") or "").strip(), ""
    )
    library_material_id = remote_node_ids.get(
        str(bloom.get("library_material_euid") or "").strip(), ""
    )
    library_plate_id = remote_node_ids.get(
        str(bloom.get("library_plate_euid") or bloom.get("library_container_euid") or "").strip(),
        "",
    )
    library_well_id = remote_node_ids.get(str(bloom.get("library_well_euid") or "").strip(), "")
    pool_id = remote_node_ids.get(str(bloom.get("pool_euid") or "").strip(), "")
    pool_tube_id = remote_node_ids.get(str(bloom.get("pool_container_euid") or "").strip(), "")
    run_id = remote_node_ids.get(str(bloom.get("run_euid") or "").strip(), "")
    fastq_ids = [
        str(node_id or "").strip()
        for node_id in list(graph_meta.get("fastq_node_ids") or [])
        if str(node_id or "").strip()
    ]

    desired_order = [
        organization_id,
        site_id,
        clinician_id,
        patient_id,
        trf_id,
        test_id,
        shipment_id,
        testkit_id,
        collection_event_id,
        tube_bridge_id,
        specimen_bridge_id,
        bloom_tube_id,
        bloom_specimen_id,
        extraction_output_id,
        plate_id,
        well_id,
        library_prep_id,
        library_material_id,
        library_plate_id,
        library_well_id,
        pool_id,
        pool_tube_id,
        run_id,
        *fastq_ids,
    ]

    kept_nodes: list[dict[str, Any]] = []
    seen_node_ids: set[str] = set()
    for node_id in desired_order:
        if not node_id or node_id in seen_node_ids:
            continue
        payload = nodes_by_id.get(node_id)
        if payload is None:
            continue
        kept_nodes.append(payload)
        seen_node_ids.add(node_id)

    story_edges: list[dict[str, Any]] = []
    seen_edge_ids: set[str] = set()

    def add_edge(source: str, target: str, relationship_type: str) -> None:
        clean_source = str(source or "").strip()
        clean_target = str(target or "").strip()
        clean_rel = str(relationship_type or "").strip()
        if not clean_source or not clean_target or not clean_rel:
            return
        if clean_source not in seen_node_ids or clean_target not in seen_node_ids:
            return
        edge_id = f"story-edge::{clean_source}::{clean_rel}::{clean_target}"
        if edge_id in seen_edge_ids:
            return
        seen_edge_ids.add(edge_id)
        story_edges.append(
            {
                "data": {
                    "id": edge_id,
                    "source": clean_source,
                    "target": clean_target,
                    "relationship_type": clean_rel,
                    "is_story": True,
                }
            }
        )

    add_edge(organization_id, site_id, "contains_site")
    add_edge(site_id, trf_id, "ordering_site")
    add_edge(clinician_id, trf_id, "ordering_clinician")
    add_edge(trf_id, test_id, "contains_test")
    add_edge(patient_id, test_id, "order_patient")
    add_edge(patient_id, collection_event_id, "collection_event")
    add_edge(collection_event_id, test_id, "collected_for_test")
    add_edge(test_id, testkit_id, "fulfilled_by_testkit")
    add_edge(shipment_id, testkit_id, "contains_testkit")
    add_edge(test_id, tube_bridge_id, "tube_bridge")
    add_edge(collection_event_id, specimen_bridge_id, "material_bridge")
    add_edge(specimen_bridge_id, tube_bridge_id, "contained_in")
    add_edge(tube_bridge_id, bloom_tube_id, "external_reference")
    add_edge(specimen_bridge_id, bloom_specimen_id, "external_reference")
    add_bloom_story_edges(
        add_edge,
        context=BloomStoryContext(
            specimen_content_id=bloom_specimen_id,
            specimen_container_id=bloom_tube_id,
            extraction_output_id=extraction_output_id,
            extraction_container_id=well_id,
            extraction_container_parent_id=plate_id,
            library_prep_output_id=library_prep_id,
            library_material_id=library_material_id,
            library_container_id=library_well_id,
            library_container_parent_id=library_plate_id,
            pool_content_id=pool_id,
            pool_container_id=pool_tube_id,
            run_id=run_id,
            fastq_ids=tuple(fastq_ids),
        ),
    )

    meta = dict(merged_graph.get("meta") or {})
    meta.update(
        {
            "story_graph": True,
            "story_node_count": len(kept_nodes),
            "story_edge_count": len(story_edges),
        }
    )
    return {
        "elements": {
            "nodes": kept_nodes,
            "edges": story_edges,
        },
        "meta": meta,
    }


def apply_day_in_life_story_positions(
    graph_payload: dict[str, Any],
    *,
    manifest: dict[str, Any],
) -> dict[str, Any]:
    positioned = copy.deepcopy(graph_payload)
    nodes = list((positioned.get("elements") or {}).get("nodes") or [])

    atlas = dict(manifest.get("atlas") or {})
    bloom = dict(manifest.get("bloom") or {})
    graph_meta = dict(manifest.get("graph_meta") or {})

    organization_id = str(((manifest.get("organization") or {}).get("euid")) or "").strip()
    site_id = str(((manifest.get("site") or {}).get("euid")) or "").strip()
    clinician_id = str(((manifest.get("clinician") or {}).get("euid")) or "").strip()
    patient_id = str(((manifest.get("patient") or {}).get("euid")) or "").strip()
    trf_id = str(((atlas.get("trf") or {}).get("euid")) or "").strip()
    test_id = str(((atlas.get("test") or {}).get("euid")) or "").strip()
    shipment_id = str(((atlas.get("shipment") or {}).get("euid")) or "").strip()
    testkit_id = str(((atlas.get("testkit") or {}).get("euid")) or "").strip()
    collection_event_id = str(((atlas.get("collection_event") or {}).get("euid")) or "").strip()
    tube_bridge_id = str(bloom.get("container_external_object_id") or "").strip()
    specimen_bridge_id = str(bloom.get("specimen_external_object_id") or "").strip()

    remote_by_euid = {
        str((node.get("data") or {}).get("remote_euid") or "").strip(): str(
            (node.get("data") or {}).get("id") or ""
        ).strip()
        for node in nodes
        if str((node.get("data") or {}).get("remote_euid") or "").strip()
    }

    bloom_tube_id = remote_by_euid.get(str(bloom.get("container_euid") or "").strip(), "")
    bloom_specimen_id = remote_by_euid.get(str(bloom.get("specimen_euid") or "").strip(), "")
    extraction_output_id = remote_by_euid.get(
        str(bloom.get("extraction_output_euid") or "").strip(), ""
    )
    plate_id = remote_by_euid.get(str(bloom.get("plate_euid") or "").strip(), "")
    well_id = remote_by_euid.get(str(bloom.get("well_euid") or "").strip(), "")
    library_prep_id = remote_by_euid.get(
        str(bloom.get("library_prep_output_euid") or "").strip(), ""
    )
    library_material_id = remote_by_euid.get(
        str(bloom.get("library_material_euid") or "").strip(), ""
    )
    library_plate_id = remote_by_euid.get(
        str(bloom.get("library_plate_euid") or bloom.get("library_container_euid") or "").strip(),
        "",
    )
    library_well_id = remote_by_euid.get(str(bloom.get("library_well_euid") or "").strip(), "")
    pool_id = remote_by_euid.get(str(bloom.get("pool_euid") or "").strip(), "")
    pool_tube_id = remote_by_euid.get(str(bloom.get("pool_container_euid") or "").strip(), "")
    run_id = remote_by_euid.get(str(bloom.get("run_euid") or "").strip(), "")
    fastq_ids = [
        str(node_id or "").strip()
        for node_id in list(graph_meta.get("fastq_node_ids") or [])
        if str(node_id or "").strip()
    ]

    positions = {
        organization_id: {"x": 140, "y": 90},
        site_id: {"x": 300, "y": 180},
        clinician_id: {"x": 470, "y": 180},
        trf_id: {"x": 430, "y": 310},
        shipment_id: {"x": 620, "y": 220},
        testkit_id: {"x": 770, "y": 260},
        patient_id: {"x": 1020, "y": 210},
        test_id: {"x": 700, "y": 420},
        collection_event_id: {"x": 1210, "y": 340},
        tube_bridge_id: {"x": 860, "y": 560},
        specimen_bridge_id: {"x": 1400, "y": 470},
        bloom_tube_id: {"x": 970, "y": 730},
        bloom_specimen_id: {"x": 1540, "y": 700},
        plate_id: {"x": 620, "y": 880},
        well_id: {"x": 980, "y": 930},
        extraction_output_id: {"x": 1540, "y": 900},
        library_prep_id: {"x": 1950, "y": 900},
        library_material_id: {"x": 1540, "y": 1080},
        library_plate_id: {"x": 980, "y": 1120},
        library_well_id: {"x": 1180, "y": 1030},
        pool_tube_id: {"x": 980, "y": 1310},
        pool_id: {"x": 1540, "y": 1270},
        run_id: {"x": 1540, "y": 1470},
    }
    if fastq_ids:
        positions[fastq_ids[0]] = {"x": 1360, "y": 1660}
    if len(fastq_ids) > 1:
        positions[fastq_ids[1]] = {"x": 1750, "y": 1660}

    for node in nodes:
        data = dict(node.get("data") or {})
        node_id = str(data.get("id") or "").strip()
        position = positions.get(node_id)
        if position:
            node["position"] = position

    return positioned


def render_day_in_life_dag_html(
    *,
    title: str,
    manifest: dict[str, Any],
    merged_graph: dict[str, Any],
) -> str:
    manifest_json = json.dumps(manifest, indent=2, sort_keys=True)
    elements_json = json.dumps(merged_graph.get("elements") or {}, indent=2, sort_keys=True)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title}</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.28.1/cytoscape.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/dagre@0.8.5/dist/dagre.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/cytoscape-dagre@2.5.0/cytoscape-dagre.min.js"></script>
  <style>
    :root {{
      --bg: #071018;
      --panel: rgba(11, 22, 35, 0.9);
      --panel-border: rgba(148, 163, 184, 0.24);
      --text: #e2e8f0;
      --muted: #94a3b8;
      --accent: #f59e0b;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: ui-monospace, "SFMono-Regular", Menlo, monospace;
      background:
        radial-gradient(circle at top left, rgba(14, 116, 144, 0.18), transparent 35%),
        radial-gradient(circle at bottom right, rgba(245, 158, 11, 0.14), transparent 30%),
        var(--bg);
      color: var(--text);
    }}
    .shell {{
      display: grid;
      gap: 16px;
      grid-template-columns: minmax(0, 2.2fr) minmax(280px, 0.8fr);
      min-height: 100vh;
      padding: 18px;
    }}
    .panel {{
      background: var(--panel);
      border: 1px solid var(--panel-border);
      border-radius: 18px;
      overflow: hidden;
      box-shadow: 0 22px 54px rgba(0, 0, 0, 0.28);
      backdrop-filter: blur(10px);
    }}
    .graph-toolbar {{
      display: flex;
      gap: 12px;
      align-items: center;
      justify-content: space-between;
      padding: 14px 18px;
      border-bottom: 1px solid rgba(148, 163, 184, 0.12);
      background: rgba(8, 15, 24, 0.82);
    }}
    .graph-toolbar label {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: var(--muted);
    }}
    .graph-toolbar select,
    .graph-toolbar button {{
      border: 1px solid rgba(148, 163, 184, 0.24);
      border-radius: 10px;
      background: rgba(15, 23, 42, 0.72);
      color: var(--text);
      padding: 8px 10px;
      font: inherit;
    }}
    .graph-toolbar button {{
      cursor: pointer;
    }}
    .toolbar-actions {{
      display: flex;
      gap: 8px;
      align-items: center;
    }}
    .toolbar-note {{
      font-size: 11px;
      color: var(--muted);
    }}
    #cy {{
      width: 100%;
      height: calc(100vh - 104px);
      min-height: 792px;
    }}
    .sidebar {{
      display: grid;
      gap: 16px;
      align-content: start;
    }}
    .section {{
      padding: 18px;
      border-bottom: 1px solid rgba(148, 163, 184, 0.12);
    }}
    .section:last-child {{
      border-bottom: 0;
    }}
    h1, h2 {{
      margin: 0 0 12px 0;
      line-height: 1.15;
    }}
    h1 {{ font-size: 20px; }}
    h2 {{
      font-size: 13px;
      letter-spacing: 0.08em;
      color: var(--muted);
      text-transform: uppercase;
    }}
    .meta-grid {{
      display: grid;
      grid-template-columns: 110px 1fr;
      gap: 8px 12px;
      font-size: 12px;
    }}
    .meta-grid dt {{
      color: var(--muted);
    }}
    .meta-grid dd {{
      margin: 0;
      word-break: break-word;
    }}
    .legend {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      font-size: 12px;
    }}
    .legend span {{
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border-radius: 999px;
      border: 1px solid rgba(148, 163, 184, 0.22);
      padding: 6px 10px;
    }}
    .swatch {{
      width: 10px;
      height: 10px;
      border-radius: 50%;
      display: inline-block;
    }}
    .timeline {{
      display: grid;
      gap: 10px;
      font-size: 12px;
    }}
    .timeline-item {{
      padding: 10px 12px;
      border-radius: 12px;
      border: 1px solid rgba(148, 163, 184, 0.18);
      background: rgba(15, 23, 42, 0.42);
    }}
    .timeline-item strong {{
      display: block;
      margin-bottom: 4px;
    }}
    a {{
      color: #7dd3fc;
      text-decoration: none;
    }}
    a:hover {{
      text-decoration: underline;
    }}
    pre {{
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
      font-size: 11px;
      line-height: 1.45;
      color: #cbd5e1;
    }}
    .manifest-section {{
      max-height: 36vh;
      overflow: auto;
    }}
    @media (max-width: 1200px) {{
      .shell {{ grid-template-columns: 1fr; }}
      #cy {{ height: 60vh; min-height: 520px; }}
      .manifest-section {{ max-height: none; }}
    }}
  </style>
</head>
<body>
  <div class="shell">
    <div class="panel">
      <div class="graph-toolbar">
        <label>Layout
          <select id="layout-select">
            <option value="story">story</option>
            <option value="dagre">dagre</option>
            <option value="cose">cose</option>
            <option value="hierarchical">hierarchical</option>
            <option value="circle">circle</option>
            <option value="grid">grid</option>
          </select>
        </label>
        <div class="toolbar-actions">
          <button id="fit-graph" type="button">Fit</button>
          <span class="toolbar-note">Click a node to open its Atlas or Bloom page.</span>
        </div>
      </div>
      <div id="cy"></div>
    </div>
    <div class="sidebar">
      <section class="panel section">
        <h1>{title}</h1>
        <dl class="meta-grid">
          <dt>Demo Key</dt><dd>{manifest.get("demo_key", "")}</dd>
          <dt>TRF</dt><dd>{(((manifest.get("atlas") or {{}}).get("trf")) or {{}}).get("euid", "")}</dd>
          <dt>Test</dt><dd>{(((manifest.get("atlas") or {{}}).get("test")) or {{}}).get("euid", "")}</dd>
          <dt>Patient</dt><dd>{(((manifest.get("patient") or {{}}).get("name")) or "")}</dd>
          <dt>Clinician</dt><dd>{(((manifest.get("clinician") or {{}}).get("name")) or "")}</dd>
          <dt>Site</dt><dd>{(((manifest.get("site") or {{}}).get("name")) or "")}</dd>
          <dt>Organization</dt><dd>{(((manifest.get("organization") or {{}}).get("name")) or "")}</dd>
          <dt>Graph URL</dt><dd><a href="{((manifest.get("artifacts") or {{}}).get("live_graph_url") or "")}">{((manifest.get("artifacts") or {{}}).get("live_graph_url") or "")}</a></dd>
        </dl>
      </section>
      <section class="panel section">
        <h2>Legend</h2>
        <div class="legend">
          <span><i class="swatch" style="background:#6f7a92"></i>Atlas/local</span>
          <span><i class="swatch" style="background:#c1a967"></i>Bloom/external</span>
          <span><i class="swatch" style="background:#f7c948"></i>Bridge</span>
          <span><i class="swatch" style="background:#38bdf8"></i>Context</span>
        </div>
      </section>
      <section class="panel section">
        <h2>Timeline</h2>
        <div class="timeline" id="timeline"></div>
      </section>
      <section class="panel section manifest-section">
        <h2>Manifest</h2>
        <pre>{manifest_json}</pre>
      </section>
    </div>
  </div>
  <script>
    const manifest = {manifest_json};
    const graphPayload = {elements_json};
    const stages = Array.isArray(manifest.stages) ? manifest.stages : [];
    const timeline = document.getElementById("timeline");
    const layoutSelect = document.getElementById("layout-select");
    const fitButton = document.getElementById("fit-graph");
    timeline.innerHTML = stages.map((stage) => `
      <div class="timeline-item">
        <strong>${{stage.stage || "stage"}}</strong>
        <div>${{stage.system || ""}}${{stage.queue_name ? " :: " + stage.queue_name : ""}}</div>
        <div style="color:#94a3b8;margin-top:4px;">${{stage.occurred_at || ""}}</div>
      </div>
    `).join("");

    if (window.cytoscapeDagre && typeof window.cytoscape.use === "function") {{
      window.cytoscape.use(window.cytoscapeDagre);
    }}

    const hasStoryPositions = (graphPayload.nodes || []).some((node) => !!node.position);

    const layoutPresets = {{
      story: {{ name: "preset", animate: false, fit: false }},
      dagre: {{ name: "dagre", rankDir: "BT", rankSep: 90, nodeSep: 45, fit: false }},
      cose: {{ name: "cose", animate: false, padding: 30, fit: false }},
      hierarchical: {{ name: "breadthfirst", directed: true, spacingFactor: 1.15, padding: 30, fit: false }},
      circle: {{ name: "circle", animate: false, padding: 30, fit: false }},
      grid: {{ name: "grid", animate: false, padding: 30, fit: false }},
    }};

    const defaultLayoutName = hasStoryPositions ? "story" : "dagre";
    if (layoutSelect) {{
      layoutSelect.value = defaultLayoutName;
    }}

    const cy = window.cytoscape({{
      container: document.getElementById("cy"),
      elements: [...(graphPayload.nodes || []), ...(graphPayload.edges || [])],
      layout: layoutPresets[defaultLayoutName],
      style: [
        {{
          selector: "node",
          style: {{
            "background-color": "data(color)",
            "label": "data(name)",
            "color": "#eff6ff",
            "font-size": 11,
            "text-wrap": "wrap",
            "text-max-width": 120,
            "border-width": 1.5,
            "border-color": "#dbeafe",
            "width": 40,
            "height": 40
          }}
        }},
        {{
          selector: "node[href]",
          style: {{
            "cursor": "pointer"
          }}
        }},
        {{
          selector: "node[is_external]",
          style: {{
            "border-color": "#fbbf24",
            "border-width": 2.5,
            "shape": "round-rectangle"
          }}
        }},
        {{
          selector: "node[is_context]",
          style: {{
            "shape": "round-hexagon",
            "border-width": 2.5,
            "border-color": "#e2e8f0"
          }}
        }},
        {{
          selector: "edge",
          style: {{
            "curve-style": "bezier",
            "width": 2,
            "line-color": "#6b7280",
            "target-arrow-shape": "triangle",
            "target-arrow-color": "#6b7280",
            "arrow-scale": 0.8
          }}
        }},
        {{
          selector: "edge[is_external_bridge]",
          style: {{
            "line-color": "#f7c948",
            "target-arrow-color": "#f7c948",
            "line-style": "dashed",
            "width": 2.4
          }}
        }},
        {{
          selector: "edge[is_context]",
          style: {{
            "line-color": "#38bdf8",
            "target-arrow-color": "#38bdf8",
            "width": 2.2
          }}
        }},
        {{
          selector: 'edge[relationship_type = "content_parent_of"]',
          style: {{
            "line-color": "#34d399",
            "target-arrow-color": "#34d399",
            "line-style": "dashed",
            "width": 2.8
          }}
        }},
        {{
          selector: 'edge[relationship_type = "container_parent_of"]',
          style: {{
            "line-color": "#60a5fa",
            "target-arrow-color": "#60a5fa",
            "line-style": "dotted",
            "width": 2.8
          }}
        }}
      ]
    }});

    function fitGraph() {{
      cy.fit(undefined, 80);
    }}

    function runLayout(layoutName) {{
      const key = Object.prototype.hasOwnProperty.call(layoutPresets, layoutName) ? layoutName : "dagre";
      const layout = cy.layout(layoutPresets[key]);
      layout.on("layoutstop", () => {{
        fitGraph();
      }});
      layout.run();
    }}

    cy.on("tap", "node", (event) => {{
      const href = String(event.target.data("href") || "").trim();
      if (href) {{
        window.location.assign(href);
      }}
    }});

    if (layoutSelect) {{
      layoutSelect.addEventListener("change", () => {{
        runLayout(layoutSelect.value || "dagre");
      }});
    }}

    if (fitButton) {{
      fitButton.addEventListener("click", fitGraph);
    }}

    cy.once("layoutstop", () => {{
      fitGraph();
      window.__DAY_IN_LIFE_READY = true;
    }});
  </script>
</body>
</html>
"""


class DayInLifeDemoRunner:
    """Runs one concrete local day-in-life example and exports its artifacts."""

    def __init__(
        self,
        db,
        *,
        atlas_base_url: str = DEFAULT_ATLAS_BASE_URL,
        graph_depth: int = DEFAULT_GRAPH_DEPTH,
    ):
        self.db = db
        self.atlas_base_url = atlas_base_url.rstrip("/")
        self.graph_depth = max(2, min(graph_depth, settings.graph_max_depth))

    def run(self, config: DayInLifeDemoConfig) -> DayInLifeDemoResult:
        normalized = DayInLifeDemoConfig(
            demo_key=_slugify(config.demo_key),
            actor_email=config.actor_email,
            patient_euid=config.patient_euid,
            clinician_euid=config.clinician_euid,
            site_euid=config.site_euid,
            assay_route_code=config.assay_route_code,
            assay_name=config.assay_name,
            extraction_well=config.extraction_well,
            render_screenshot=config.render_screenshot,
            atlas_base_url=config.atlas_base_url,
            output_root=Path(config.output_root),
        )
        artifacts = self._artifact_paths(normalized)
        existing = self._load_existing_manifest(artifacts.manifest_path)
        if existing is not None:
            preflight = self._preflight(normalized)
            refreshed = self._refresh_existing_artifacts(
                normalized=normalized,
                manifest=existing,
                preflight=preflight,
                artifacts=artifacts,
            )
            return DayInLifeDemoResult(config=normalized, manifest=refreshed, artifacts=artifacts)

        preflight = self._preflight(normalized)
        stages: list[dict[str, Any]] = []
        state: dict[str, Any] = {}

        trf, test, test_revision = self._create_order_context(normalized, preflight, stages)
        state["trf"] = trf
        state["test"] = test
        state["test_revision"] = test_revision
        fulfillment_item = TestFulfillmentItemService(
            self.db, preflight["tenant_id"]
        ).ensure_default_for_test(
            test_euid=test.euid,
            created_by=preflight["actor_uuid"],
        )
        state["fulfillment_item"] = fulfillment_item

        shipment = ShipmentService(self.db, preflight["tenant_id"]).create(
            ShipmentCreate(
                carrier="FedEx",
                tracking_number=self._tracking_number(normalized.demo_key),
                origin_site_id=normalized.site_euid,
                special_instructions=f"Day In The Life demo shipment ({normalized.demo_key})",
            ),
            created_by=preflight["actor_uuid"],
        )[0]
        kit, _created = TestKitService(self.db, preflight["tenant_id"]).get_or_create_by_barcode(
            kit_barcode=self._kit_barcode(normalized.demo_key),
            kit_type="Demo blood collection kit",
            origin_site_id=normalized.site_euid,
            created_by=preflight["actor_uuid"],
        )
        state["shipment"] = shipment
        state["kit"] = kit
        stages.append(
            self._stage(
                "shipment_created",
                system="atlas",
                tracking_number=shipment.shipment_number,
                shipment_euid=shipment.euid,
                testkit_euid=kit.euid,
            )
        )

        bridge = ContainerSpecimenBridgeService(self.db, preflight["tenant_id"])
        tube = bridge.create_empty_tube(
            TubeCreationRequest(
                test_euid=test.euid,
                site_euid=normalized.site_euid,
                collection_site_euid=normalized.site_euid,
                origin_site_id=normalized.site_euid,
                container_template_code="container/tube/tube-generic-10ml/1.0",
                idempotency_key=f"dil:{normalized.demo_key}:tube",
            ),
            actor_id=preflight["actor_uuid"],
        )
        state["tube"] = tube
        stages.append(
            self._stage(
                "tube_created",
                system="atlas",
                container_euid=tube.container_euid,
                container_external_object_id=tube.container_external_object_euid,
            )
        )

        collection_events = CollectionEventService(self.db, preflight["tenant_id"])
        collection_event, collection_event_revision = collection_events.create(
            CollectionEventCreate(
                patient_euid=normalized.patient_euid,
                site_euid=normalized.site_euid,
                container_euid=tube.container_euid,
                specimen_euid=None,
                collected_at=datetime.now(UTC),
                collection_type="venipuncture",
                collected_by=preflight["actor_email"],
                expected_name=preflight["patient_name"],
                expected_label_text=tube.container_euid,
            ),
            created_by=preflight["actor_uuid"],
        )
        state["collection_event"] = collection_event
        self._ensure_relation(
            tenant_id=preflight["tenant_id"],
            external_object_id=tube.container_external_object_euid,
            relation_type="has_collection_event",
            local_entity_type="CollectionEvent",
            local_entity_id=collection_event.euid,
            actor_id=preflight["actor_uuid"],
        )
        stages.append(
            self._stage(
                "collection_event_recorded",
                system="atlas",
                collection_event_euid=collection_event.euid,
                collected_at=collection_event_revision.collected_at.isoformat()
                if getattr(collection_event_revision, "collected_at", None)
                else _now_iso(),
            )
        )

        paperwork = DocumentService(self.db, preflight["tenant_id"]).create_placeholder(
            DocumentPlaceholder(
                filename=f"dil-{normalized.demo_key}-paperwork.txt",
                document_type="paperwork",
                note=f"Day In The Life paperwork placeholder ({normalized.demo_key})",
            ),
            created_by=preflight["actor_uuid"],
        )[0]
        state["paperwork"] = paperwork

        work_item = self._run_minimal_accessioning(
            normalized=normalized,
            preflight=preflight,
            shipment=shipment,
            kit=kit,
            tube=tube,
            paperwork=paperwork,
            trf=trf,
            stages=stages,
        )
        state["work_item"] = work_item

        accepted_material = bridge.register_accepted_material(
            AcceptedMaterialRequest(
                trf_euid=trf.euid,
                test_euids=[test.euid],
                patient_euid=normalized.patient_euid,
                shipment_euid=shipment.euid,
                testkit_euid=kit.euid,
                origin_site_id=normalized.site_euid,
                specimen_template_code="content/specimen/blood-whole/1.0",
                specimen_name=f"dil-{normalized.demo_key}-specimen",
                container_euid=tube.container_euid,
                starting_queue="extraction_prod",
                queue_metadata={
                    "demo_key": normalized.demo_key,
                    "stage": "eligible_for_extraction",
                },
                idempotency_key=f"dil:{normalized.demo_key}:accepted-material",
            ),
            actor_id=preflight["actor_uuid"],
        )
        state["accepted_material"] = accepted_material
        collection_events.attach_specimen(
            collection_event.euid,
            accepted_material.specimen_euid,
            updated_by=preflight["actor_uuid"],
        )
        self._ensure_relation(
            tenant_id=preflight["tenant_id"],
            external_object_id=accepted_material.specimen_external_object_euid,
            relation_type="belongs_to_collection_event",
            local_entity_type="CollectionEvent",
            local_entity_id=collection_event.euid,
            actor_id=preflight["actor_uuid"],
        )
        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.SPECIMEN_RECEIVED,
            stage_name="specimen_received",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "queue_name": accepted_material.current_queue,
            },
        )
        stages.append(
            self._stage(
                "specimen_received",
                system="bloom",
                queue_name=accepted_material.current_queue,
                container_euid=accepted_material.container_euid,
                specimen_euid=accepted_material.specimen_euid,
            )
        )

        bloom_client = preflight["bloom_client"]
        extraction_claim = self._claim_first_available(
            bloom_client=bloom_client,
            queue_name="extraction_prod",
            candidate_materials=[accepted_material.specimen_euid, accepted_material.container_euid],
            idempotency_key=f"dil:{normalized.demo_key}:claim:extraction",
            metadata={"demo_key": normalized.demo_key, "stage": "extraction"},
        )
        extraction = bloom_client.create_extraction(
            {
                "source_specimen_euid": accepted_material.specimen_euid,
                "well_name": normalized.extraction_well,
                "plate_template_code": "container/plate/fixed-plate-96/1.0",
                "plate_name": f"dil-{normalized.demo_key}-extract-plate",
                "extraction_type": "gdna",
                "atlas_test_fulfillment_item_euid": fulfillment_item.euid,
                "claim_euid": extraction_claim["claim"]["claim_euid"],
                "consume_source": True,
                "metadata": {"demo_key": normalized.demo_key, "stage": "extraction"},
            },
            idempotency_key=f"dil:{normalized.demo_key}:extraction",
        )
        state["extraction"] = extraction
        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="extraction",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "plate_euid": extraction["plate_euid"],
                "well_euid": extraction["well_euid"],
                "well_name": extraction["well_name"],
            },
        )
        stages.append(
            self._stage(
                "extraction",
                system="bloom",
                queue_name=extraction["current_queue"],
                claim_mode="explicit",
                claim_euid=extraction_claim["claim"]["claim_euid"],
                claimed_material_euid=extraction_claim["material_euid"],
                plate_euid=extraction["plate_euid"],
                well_euid=extraction["well_euid"],
                extraction_output_euid=extraction["extraction_output_euid"],
            )
        )

        post_extract_qc = bloom_client.record_post_extract_qc(
            {
                "extraction_output_euid": extraction["extraction_output_euid"],
                "passed": True,
                "next_queue": "ilmn_lib_prep",
                "metrics": {"dna_concentration_ng_ul": 18.4, "integrity_score": 9.6},
                "metadata": {"demo_key": normalized.demo_key, "stage": "post_extract_qc"},
            },
            idempotency_key=f"dil:{normalized.demo_key}:post-extract-qc",
        )
        state["post_extract_qc"] = post_extract_qc
        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="post_extract_qc_pass",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "next_queue": post_extract_qc["current_queue"],
            },
        )
        stages.append(
            self._stage(
                "post_extract_qc_pass",
                system="bloom",
                queue_name=post_extract_qc["current_queue"],
                claim_mode="implicit",
                extraction_output_euid=post_extract_qc["extraction_output_euid"],
            )
        )

        library_prep_claim = bloom_client.claim_material_in_queue(
            extraction["extraction_output_euid"],
            "ilmn_lib_prep",
            metadata={"demo_key": normalized.demo_key, "stage": "library_prep"},
            idempotency_key=f"dil:{normalized.demo_key}:claim:library-prep",
        )
        library_prep = bloom_client.create_library_prep(
            {
                "source_extraction_output_euid": extraction["extraction_output_euid"],
                "platform": "ILMN",
                "output_name": f"dil-{normalized.demo_key}-library-prep",
                "claim_euid": library_prep_claim["claim_euid"],
                "consume_source": True,
                "metadata": {"demo_key": normalized.demo_key, "stage": "library_prep"},
            },
            idempotency_key=f"dil:{normalized.demo_key}:library-prep",
        )
        state["library_prep"] = library_prep
        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="library_prep",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "library_prep_output_euid": library_prep["library_prep_output_euid"],
            },
        )
        stages.append(
            self._stage(
                "library_prep",
                system="bloom",
                queue_name=library_prep["current_queue"],
                claim_mode="explicit",
                claim_euid=library_prep_claim["claim_euid"],
                library_prep_output_euid=library_prep["library_prep_output_euid"],
                library_material_euid=library_prep.get("library_material_euid"),
                library_container_euid=library_prep.get("library_container_euid"),
                library_plate_euid=library_prep.get("library_plate_euid"),
                library_well_euid=library_prep.get("library_well_euid"),
            )
        )

        pool_member_euid = str(
            library_prep.get("library_material_euid") or library_prep["library_prep_output_euid"]
        ).strip()
        pool_claim = bloom_client.claim_material_in_queue(
            pool_member_euid,
            "ilmn_seq_pool",
            metadata={"demo_key": normalized.demo_key, "stage": "pool"},
            idempotency_key=f"dil:{normalized.demo_key}:claim:pool",
        )
        pool = bloom_client.create_pool(
            {
                "member_euids": [pool_member_euid],
                "platform": "ILMN",
                "pool_name": f"dil-{normalized.demo_key}-pool",
                "claim_euid": pool_claim["claim_euid"],
                "consume_members": True,
                "metadata": {"demo_key": normalized.demo_key, "stage": "pool"},
            },
            idempotency_key=f"dil:{normalized.demo_key}:pool",
        )
        state["pool"] = pool
        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="pooled",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={"demo_key": normalized.demo_key, "pool_euid": pool["pool_euid"]},
        )
        stages.append(
            self._stage(
                "pooled",
                system="bloom",
                queue_name=pool["current_queue"],
                claim_mode="explicit",
                claim_euid=pool_claim["claim_euid"],
                pool_member_euid=pool_member_euid,
                pool_euid=pool["pool_euid"],
                pool_container_euid=pool["pool_container_euid"],
            )
        )

        library_barcode = self._library_barcode(normalized.demo_key)
        flowcell_id = self._flowcell_id(normalized.demo_key)
        run_claim = bloom_client.claim_material_in_queue(
            pool["pool_euid"],
            "ilmn_start_seq_run",
            metadata={"demo_key": normalized.demo_key, "stage": "run_loading"},
            idempotency_key=f"dil:{normalized.demo_key}:claim:run",
        )
        run = bloom_client.create_run(
            {
                "pool_euid": pool["pool_euid"],
                "platform": "ILMN",
                "flowcell_id": flowcell_id,
                "run_name": self._run_name(normalized.demo_key),
                "status": "completed",
                "claim_euid": run_claim["claim_euid"],
                "consume_pool": True,
                "metadata": {"demo_key": normalized.demo_key, "stage": "run_loading"},
                "assignments": [
                    {
                        "lane": "L001",
                        "library_barcode": library_barcode,
                        "library_prep_output_euid": library_prep["library_prep_output_euid"],
                    }
                ],
                "artifacts": [
                    {
                        "artifact_type": "fastq",
                        "bucket": "day-in-life-demo",
                        "filename": f"{normalized.demo_key}_L001_R1.fastq.gz",
                        "lane": "L001",
                        "library_barcode": library_barcode,
                        "metadata": {"read": "R1", "demo_key": normalized.demo_key},
                    },
                    {
                        "artifact_type": "fastq",
                        "bucket": "day-in-life-demo",
                        "filename": f"{normalized.demo_key}_L001_R2.fastq.gz",
                        "lane": "L001",
                        "library_barcode": library_barcode,
                        "metadata": {"read": "R2", "demo_key": normalized.demo_key},
                    },
                ],
            },
            idempotency_key=f"dil:{normalized.demo_key}:run",
        )
        state["run"] = run
        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="run_loading",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "run_euid": run["run_euid"],
                "flowcell_id": flowcell_id,
            },
        )
        stages.append(
            self._stage(
                "run_loading",
                system="bloom",
                claim_mode="explicit",
                claim_euid=run_claim["claim_euid"],
                run_euid=run["run_euid"],
                flowcell_id=run["flowcell_id"],
                artifact_count=run["artifact_count"],
                assignment_count=run["assignment_count"],
            )
        )

        resolution = self._resolve_run_assignment(
            bloom_client=bloom_client,
            run_euid=run["run_euid"],
            flowcell_id=flowcell_id,
            lane="L001",
            library_barcode=library_barcode,
            test=test,
            fulfillment_item=fulfillment_item,
            tenant_id=preflight["tenant_id"],
            trf=trf,
        )
        state["resolution"] = resolution
        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="fastq_produced",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "run_euid": run["run_euid"],
                "lane": "L001",
                "library_barcode": library_barcode,
            },
        )
        stages.append(
            self._stage(
                "fastq_produced",
                system="bloom",
                run_euid=run["run_euid"],
                lane="L001",
                library_barcode=library_barcode,
                atlas_test_euid=resolution["atlas_test_euid"],
                atlas_test_fulfillment_item_euid=resolution["atlas_test_fulfillment_item_euid"],
            )
        )

        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="run_qc_verified",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "run_euid": run["run_euid"],
                "flowcell_id": flowcell_id,
                "lane": "L001",
                "library_barcode": library_barcode,
            },
        )
        stages.append(
            self._stage(
                "run_qc_verified",
                system="bloom-derived",
                queue_name="eligible_for_run_qc",
                run_euid=run["run_euid"],
                flowcell_id=flowcell_id,
                lane="L001",
                library_barcode=library_barcode,
            )
        )

        self._apply_test_status(
            preflight=preflight,
            test_euid=test.euid,
            status=TestOrderStatus.IN_PROGRESS,
            stage_name="analysis_eligible",
            container_euid=accepted_material.container_euid,
            specimen_euid=accepted_material.specimen_euid,
            metadata={
                "demo_key": normalized.demo_key,
                "run_euid": run["run_euid"],
                "flowcell_id": flowcell_id,
                "lane": "L001",
            },
        )
        stages.append(
            self._stage(
                "analysis_eligible",
                system="ursa-placeholder",
                queue_name="eligible_for_2ndary_analysis",
                run_euid=run["run_euid"],
                flowcell_id=flowcell_id,
                lane="L001",
                library_barcode=library_barcode,
            )
        )

        artifacts.output_dir.mkdir(parents=True, exist_ok=True)
        merged_graph, graph_meta = self._build_merged_graph(
            tenant_id=preflight["tenant_id"],
            test_euid=test.euid,
            run_euid=run["run_euid"],
            demo_key=normalized.demo_key,
            bloom_client=bloom_client,
            site_euid=preflight["site"].euid,
            bloom_base_url=DEFAULT_BLOOM_BASE_URL,
        )
        manifest = self._build_manifest(
            normalized=normalized,
            preflight=preflight,
            state=state,
            stages=stages,
            graph_meta=graph_meta,
            artifacts=artifacts,
        )
        manifest = self._ensure_manifest_context(manifest, preflight=preflight)
        merged_graph = self._augment_graph_with_context(merged_graph, manifest=manifest)
        merged_graph = build_day_in_life_story_graph(
            merged_graph,
            manifest=manifest,
        )
        merged_graph = apply_day_in_life_story_positions(
            merged_graph,
            manifest=manifest,
        )
        artifacts.graph_elements_path.write_text(
            json.dumps(merged_graph, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        artifacts.html_path.write_text(
            render_day_in_life_dag_html(
                title=f"Day In The Life :: {normalized.demo_key}",
                manifest=manifest,
                merged_graph=merged_graph,
            ),
            encoding="utf-8",
        )
        if normalized.render_screenshot:
            self._render_screenshot(artifacts.html_path, artifacts.png_path)
        artifacts.manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        return DayInLifeDemoResult(config=normalized, manifest=manifest, artifacts=artifacts)

    def _artifact_paths(self, config: DayInLifeDemoConfig) -> DayInLifeDemoArtifacts:
        output_dir = Path(config.output_root) / _slugify(config.demo_key)
        return DayInLifeDemoArtifacts(
            output_dir=output_dir,
            manifest_path=output_dir / "manifest.json",
            graph_elements_path=output_dir / "graph-elements.json",
            html_path=output_dir / "dag.html",
            png_path=output_dir / "dag.png",
        )

    @staticmethod
    def _load_existing_manifest(path: Path) -> dict[str, Any] | None:
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None

    def _refresh_existing_artifacts(
        self,
        *,
        normalized: DayInLifeDemoConfig,
        manifest: dict[str, Any],
        preflight: dict[str, Any],
        artifacts: DayInLifeDemoArtifacts,
    ) -> dict[str, Any]:
        test_euid = str(
            (((manifest.get("atlas") or {}).get("test")) or {}).get("euid") or ""
        ).strip()
        run_euid = str(((manifest.get("bloom") or {}).get("run_euid")) or "").strip()
        if not test_euid or not run_euid:
            raise DayInLifeDemoError("Existing demo manifest is missing test or run identifiers")
        merged_graph, graph_meta = self._build_merged_graph(
            tenant_id=preflight["tenant_id"],
            test_euid=test_euid,
            run_euid=run_euid,
            demo_key=str(manifest.get("demo_key") or normalized.demo_key),
            bloom_client=preflight["bloom_client"],
            site_euid=preflight["site"].euid,
            bloom_base_url=DEFAULT_BLOOM_BASE_URL,
        )
        refreshed = copy.deepcopy(manifest)
        refreshed = self._ensure_manifest_context(refreshed, preflight=preflight)
        refreshed.setdefault("artifacts", {})
        refreshed["artifacts"].update(
            {
                "output_dir": str(artifacts.output_dir),
                "manifest_path": str(artifacts.manifest_path),
                "graph_elements_path": str(artifacts.graph_elements_path),
                "dag_html_path": str(artifacts.html_path),
                "dag_png_path": str(artifacts.png_path),
                "live_graph_url": (
                    f"{normalized.atlas_base_url.rstrip('/')}/graph?"
                    + urlencode(
                        {
                            "start_euid": test_euid,
                            "depth": self.graph_depth,
                            "tenant_id": str(preflight["tenant_id"]),
                            "projection": "story",
                        }
                    )
                ),
            }
        )
        refreshed["graph_meta"] = graph_meta
        refreshed.setdefault("bloom", {})
        refreshed["bloom"]["dewey_note"] = (
            "FASTQ artifacts include Dewey artifact links."
            if graph_meta.get("dewey_registered")
            else "FASTQ artifacts are present in Bloom run_artifact records; no Dewey link was detected in this localhost run."
        )
        merged_graph = self._augment_graph_with_context(merged_graph, manifest=refreshed)
        merged_graph = build_day_in_life_story_graph(
            merged_graph,
            manifest=refreshed,
        )
        merged_graph = apply_day_in_life_story_positions(
            merged_graph,
            manifest=refreshed,
        )
        artifacts.output_dir.mkdir(parents=True, exist_ok=True)
        artifacts.graph_elements_path.write_text(
            json.dumps(merged_graph, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        artifacts.html_path.write_text(
            render_day_in_life_dag_html(
                title=f"Day In The Life :: {normalized.demo_key}",
                manifest=refreshed,
                merged_graph=merged_graph,
            ),
            encoding="utf-8",
        )
        if normalized.render_screenshot:
            self._render_screenshot(artifacts.html_path, artifacts.png_path)
        artifacts.manifest_path.write_text(
            json.dumps(refreshed, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        return refreshed

    def _preflight(self, config: DayInLifeDemoConfig) -> dict[str, Any]:
        self._check_local_service(config.atlas_base_url, label="Atlas GUI")
        self._check_local_service(DEFAULT_BLOOM_BASE_URL, label="Bloom GUI")

        user = UserService(self.db).get_by_email(config.actor_email)
        if user is None:
            raise DayInLifeDemoError(f"Actor user not found: {config.actor_email}")
        actor_uuid = self._as_uuid(getattr(user, "cognito_sub", None) or getattr(user, "sub", None))
        if actor_uuid is None:
            actor_uuid = self._as_uuid(getattr(user, "id", None))
        if actor_uuid is None:
            actor_uuid = self._as_uuid(getattr(user, "uid", None))
        if actor_uuid is None:
            raise DayInLifeDemoError(f"Actor user {config.actor_email} is missing a UUID identity")

        tenant_id = getattr(user, "tenant_id", None)
        if not isinstance(tenant_id, uuid.UUID):
            raise DayInLifeDemoError(f"Actor user {config.actor_email} is missing tenant_id")

        patient = PatientService(self.db, tenant_id, actor_uuid).get_by_id(config.patient_euid)
        if patient is None:
            raise DayInLifeDemoError(f"Patient not found: {config.patient_euid}")
        clinician = ClinicianService(self.db, tenant_id, actor_uuid).get_by_id(
            config.clinician_euid
        )
        if clinician is None:
            raise DayInLifeDemoError(f"Clinician not found: {config.clinician_euid}")
        site = SiteService(self.db).get_by_id(config.site_euid)
        if site is None:
            raise DayInLifeDemoError(f"Site not found: {config.site_euid}")
        site_revision = _latest_revision(site)
        site_name = _name_pair(site, site_revision)

        organization_service = OrganizationService(self.db)
        organization_euid = str(getattr(site, "organization_id", "") or "").strip()
        organization_with_revision = None
        if organization_euid:
            organization_with_revision = organization_service.get_with_revision(organization_euid)
        if organization_with_revision is None:
            organization_with_revision = organization_service.get_with_revision_by_uid(tenant_id)
        if organization_with_revision is None:
            raise DayInLifeDemoError(
                f"Organization could not be resolved for tenant {tenant_id} / site {config.site_euid}"
            )
        organization, organization_revision = organization_with_revision
        organization_name = _name_pair(organization, organization_revision)

        assay = TestDefinitionService(self.db).get_by_code(config.assay_route_code)
        if assay is None:
            raise DayInLifeDemoError(f"Assay not found: {config.assay_route_code}")
        if str(getattr(assay, "name", "") or "").strip() != config.assay_name:
            raise DayInLifeDemoError(
                f"Assay {config.assay_route_code} does not match expected name {config.assay_name!r}"
            )
        if getattr(assay, "is_active", True) is False:
            raise DayInLifeDemoError(f"Assay {config.assay_route_code} is inactive")

        bloom_cfg = BloomConfigResolverService(self.db).get_effective(
            organization_id=tenant_id,
            site_id=config.site_euid,
        )
        if bloom_cfg is None or not bloom_cfg.enabled:
            raise DayInLifeDemoError(
                f"Bloom integration is not enabled for tenant {tenant_id} / site {config.site_euid}"
            )
        if str(bloom_cfg.bloom_base_url).rstrip("/") != DEFAULT_BLOOM_BASE_URL:
            raise DayInLifeDemoError(
                f"Bloom base URL mismatch: expected {DEFAULT_BLOOM_BASE_URL}, got {bloom_cfg.bloom_base_url}"
            )
        if str(bloom_cfg.bloom_service_user or "").strip().lower() != config.actor_email.lower():
            raise DayInLifeDemoError(
                "Bloom integration service user does not match the requested actor "
                f"({bloom_cfg.bloom_service_user!r} != {config.actor_email!r})"
            )
        if not bloom_cfg.bloom_api_key_secret_ref:
            raise DayInLifeDemoError("Bloom integration config is missing bloom_api_key_secret_ref")

        bloom_client = BloomClient(
            base_url=bloom_cfg.bloom_base_url,
            api_key=resolve_secret_value(bloom_cfg.bloom_api_key_secret_ref),
            timeout_seconds=settings.bloom_request_timeout_seconds,
            max_retries=settings.bloom_max_retries,
            verify_ssl=settings.bloom_verify_ssl,
        )
        patient_obj, patient_revision = patient
        clinician_obj, clinician_revision = clinician
        return {
            "actor_user": user,
            "actor_uuid": actor_uuid,
            "actor_email": config.actor_email,
            "tenant_id": tenant_id,
            "patient": patient_obj,
            "patient_revision": patient_revision,
            "patient_name": _name_pair(patient_obj, patient_revision),
            "clinician": clinician_obj,
            "clinician_revision": clinician_revision,
            "clinician_name": _name_pair(clinician_obj, clinician_revision),
            "site": site,
            "site_revision": site_revision,
            "site_name": site_name,
            "organization": organization,
            "organization_revision": organization_revision,
            "organization_name": organization_name,
            "assay": assay,
            "bloom_config": bloom_cfg,
            "bloom_client": bloom_client,
        }

    @staticmethod
    def _as_uuid(value: Any) -> uuid.UUID | None:
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value))
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _localhost_insecure_ssl_context() -> ssl.SSLContext:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        return context

    @staticmethod
    def _check_local_service(url: str, *, label: str) -> None:
        try:
            response = httpx.get(
                url,
                follow_redirects=False,
                timeout=10.0,
                verify=DayInLifeDemoRunner._localhost_insecure_ssl_context(),
            )
        except httpx.HTTPError as exc:
            raise DayInLifeDemoError(f"{label} is not reachable at {url}: {exc}") from exc
        if response.status_code >= 500:
            raise DayInLifeDemoError(f"{label} returned {response.status_code} from {url}")

    def _create_order_context(
        self,
        config: DayInLifeDemoConfig,
        preflight: dict[str, Any],
        stages: list[dict[str, Any]],
    ) -> tuple[Any, Any, Any]:
        trf, _trf_revision = TrfService(self.db, preflight["tenant_id"]).create(
            TrfCreate(
                clinician_id=config.clinician_euid,
                site_id=config.site_euid,
                clinical_notes=f"Day In The Life demo ({config.demo_key})",
            ),
            tests=[
                TestCreate(
                    product_code=config.assay_route_code,
                    product_name=config.assay_name,
                    fulfillment_route_codes=[config.assay_route_code],
                    site_id=config.site_euid,
                    specimen_type_required="whole_blood",
                    specimen_type="whole_blood",
                    clinical_notes=f"Day In The Life demo ({config.demo_key})",
                )
            ],
            patient_links=[
                OrderPatientLink(
                    patient_euid=config.patient_euid,
                    role=OrderPatientRole.PROBAND,
                )
            ],
            created_by=preflight["actor_uuid"],
        )
        tests = TestService(self.db, preflight["tenant_id"]).list_for_trf(
            trf.euid, cross_tenant=False
        )
        if len(tests) != 1:
            raise DayInLifeDemoError(
                f"Expected exactly one test on demo TRF {trf.euid}, found {len(tests)}"
            )
        test, test_revision, _routes = tests[0]
        stages.append(
            self._stage(
                "test_created",
                system="atlas",
                trf_euid=trf.euid,
                trf_number=getattr(trf, "order_number", trf.euid),
                test_euid=test.euid,
                assay_code=test_revision.product_code,
            )
        )
        return trf, test, test_revision

    def _run_minimal_accessioning(
        self,
        *,
        normalized: DayInLifeDemoConfig,
        preflight: dict[str, Any],
        shipment: Any,
        kit: Any,
        tube: Any,
        paperwork: Any,
        trf: Any,
        stages: list[dict[str, Any]],
    ):
        accessioning = AccessioningWorkbenchService(self.db, preflight["tenant_id"])
        work_item, _revision = accessioning.register_receipt(
            ReceiptRegistrationRequest(
                tracking_number=self._tracking_number(normalized.demo_key),
                carrier="FedEx",
                origin_site_id=normalized.site_euid,
                notes=f"Day In The Life receipt ({normalized.demo_key})",
                received_by=preflight["actor_email"],
                mode="minimal",
            ),
            actor_id=preflight["actor_uuid"],
        )
        editor = accessioning.get_minimal_editor(work_item.euid)
        root_node_id = str((editor.get("root_node") or {}).get("node_id") or "")
        if not root_node_id:
            raise DayInLifeDemoError(
                f"Minimal accessioning editor did not return a root node for {work_item.euid}"
            )

        accessioning.register_minimal_child(
            work_item.euid,
            MinimalChildRegistrationRequest(
                kind="Kit",
                parent_node_id=root_node_id,
                scan_value=self._kit_barcode(normalized.demo_key),
                kit_type="Demo blood collection kit",
                origin_site_id=normalized.site_euid,
            ),
            actor_id=preflight["actor_uuid"],
        )
        editor = accessioning.get_minimal_editor(work_item.euid)
        kit_node_id = self._find_node_id(editor["root_node"], "TestKit", kit.euid)
        if not kit_node_id:
            raise DayInLifeDemoError(
                f"Unable to locate kit node for {kit.euid} in work item {work_item.euid}"
            )

        accessioning.register_minimal_child(
            work_item.euid,
            MinimalChildRegistrationRequest(
                kind="Tube",
                parent_node_id=kit_node_id,
                scan_value=tube.container_external_object_euid,
                collection_site_euid=normalized.site_euid,
                origin_site_id=normalized.site_euid,
            ),
            actor_id=preflight["actor_uuid"],
        )
        accessioning.register_minimal_child(
            work_item.euid,
            MinimalChildRegistrationRequest(
                kind="Paperwork",
                parent_node_id=root_node_id,
                existing_euid=paperwork.euid,
                label=f"dil-{normalized.demo_key}-paperwork.txt",
                document_type="paperwork",
            ),
            actor_id=preflight["actor_uuid"],
        )
        accessioning.register_minimal_child(
            work_item.euid,
            MinimalChildRegistrationRequest(
                kind="TRF",
                parent_node_id=kit_node_id,
                existing_euid=trf.euid,
            ),
            actor_id=preflight["actor_uuid"],
        )
        accessioning.mark_capture_ready_for_review(
            work_item.euid,
            CaptureReadyForReviewRequest(
                note=f"Minimal capture complete for {normalized.demo_key}"
            ),
            actor_id=preflight["actor_uuid"],
        )
        stages.append(
            self._stage(
                "accessioning_captured",
                system="atlas",
                shipment_euid=shipment.euid,
                testkit_euid=kit.euid,
                tube_external_object_id=tube.container_external_object_euid,
                document_euid=paperwork.euid,
                work_item_euid=work_item.euid,
            )
        )
        return work_item

    @staticmethod
    def _find_node_id(node: dict[str, Any], entity_type: str, entity_id: str) -> str | None:
        if (
            str(node.get("entity_type") or "") == entity_type
            and str(node.get("entity_id") or "") == entity_id
        ):
            return str(node.get("node_id") or "")
        for child in list(node.get("children") or []):
            found = DayInLifeDemoRunner._find_node_id(child, entity_type, entity_id)
            if found:
                return found
        return None

    def _claim_first_available(
        self,
        *,
        bloom_client: BloomClient,
        queue_name: str,
        candidate_materials: list[str],
        idempotency_key: str,
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        errors: list[str] = []
        for material_euid in candidate_materials:
            if not str(material_euid or "").strip():
                continue
            try:
                claim = bloom_client.claim_material_in_queue(
                    material_euid,
                    queue_name,
                    metadata=metadata,
                    idempotency_key=f"{idempotency_key}:{material_euid}",
                )
                return {"material_euid": material_euid, "claim": claim}
            except BloomClientError as exc:
                errors.append(f"{material_euid}: {exc}")
        raise DayInLifeDemoError(
            f"Unable to claim a subject in {queue_name}: " + "; ".join(errors or ["no candidates"])
        )

    def _resolve_run_assignment(
        self,
        *,
        bloom_client: BloomClient,
        run_euid: str,
        flowcell_id: str,
        lane: str,
        library_barcode: str,
        test: Any,
        fulfillment_item: Any,
        tenant_id: uuid.UUID,
        trf: Any,
    ) -> dict[str, Any]:
        try:
            return bloom_client.resolve_run_assignment(
                run_euid,
                flowcell_id=flowcell_id,
                lane=lane,
                library_barcode=library_barcode,
            )
        except BloomClientError:
            return {
                "run_euid": run_euid,
                "flowcell_id": flowcell_id,
                "lane": lane,
                "library_barcode": library_barcode,
                "sequenced_library_assignment_euid": None,
                "atlas_tenant_id": str(tenant_id),
                "atlas_trf_euid": trf.euid,
                "atlas_test_euid": test.euid,
                "atlas_test_fulfillment_item_euid": fulfillment_item.euid,
                "resolution_mode": "derived_fallback",
            }

    def _apply_test_status(
        self,
        *,
        preflight: dict[str, Any],
        test_euid: str,
        status: TestOrderStatus,
        stage_name: str,
        container_euid: str | None,
        specimen_euid: str | None,
        metadata: dict[str, Any],
    ) -> None:
        BloomStatusEventService(self.db, preflight["tenant_id"]).apply_test_status_event(
            test_euid=test_euid,
            event_id=f"dil:{metadata.get('demo_key')}:{stage_name}",
            idempotency_key=f"dil:{metadata.get('demo_key')}:{stage_name}",
            status=status.value,
            occurred_at=datetime.now(UTC),
            reason=f"Day In The Life :: {stage_name}",
            container_euid=container_euid,
            specimen_euid=specimen_euid,
            metadata={"stage_name": stage_name, **metadata},
            actor_id=preflight["actor_uuid"],
        )

    def _build_merged_graph(
        self,
        *,
        tenant_id: uuid.UUID,
        test_euid: str,
        run_euid: str,
        demo_key: str,
        bloom_client: BloomClient,
        site_euid: str,
        bloom_base_url: str,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        graph_service = GraphViewerService(self.db, tenant_id, can_cross_tenant=False)
        local_payload = graph_service.get_graph_data(
            start_euid=test_euid,
            depth=self.graph_depth,
            requested_tenant_id=None,
        )
        local_nodes = list((local_payload.get("elements") or {}).get("nodes") or [])
        external_payloads: list[dict[str, Any]] = []
        merged_refs: set[tuple[str, int]] = set()
        for node in local_nodes:
            node_data = dict(node.get("data") or {})
            source_euid = str(node_data.get("euid") or node_data.get("id") or "").strip()
            if not source_euid:
                continue
            detail = graph_service.get_object_detail(euid=source_euid, requested_tenant_id=None)
            for ref in list(detail.get("external_refs") or []):
                ref_index = int(ref.get("ref_index") or 0)
                key = (source_euid, ref_index)
                if key in merged_refs:
                    continue
                merged_refs.add(key)
                try:
                    if ref.get("graph_expandable"):
                        external_payloads.append(
                            graph_service.get_external_graph(
                                source_euid=source_euid,
                                ref_index=ref_index,
                                depth=self.graph_depth,
                                requested_tenant_id=None,
                            )
                        )
                        continue

                    root_euid = str(ref.get("root_euid") or "").strip()
                    system = str(ref.get("system") or "").strip().lower()
                    reason = str(ref.get("reason") or "").strip().lower()
                    if not root_euid or system != "bloom" or "bloom config" not in reason:
                        continue

                    fallback_ref = ExternalGraphRef(
                        label=str(ref.get("label") or f"{source_euid} | bloom | {root_euid}"),
                        system="bloom",
                        root_euid=root_euid,
                        external_object_id=(
                            str(ref.get("external_object_id") or source_euid or "").strip() or None
                        ),
                        tenant_id=str(site_euid or "").strip() or None,
                        href=(
                            f"{bloom_base_url.rstrip('/')}/euid_details?{urlencode({'euid': root_euid})}"
                            if bloom_base_url
                            else None
                        ),
                        graph_expandable=True,
                        reason=None,
                        base_url=bloom_base_url,
                        api_key_secret_ref=None,
                    )
                    external_payloads.append(
                        graph_service._namespace_external_graph(
                            bloom_client.get_graph_data(
                                start_euid=root_euid,
                                depth=self.graph_depth,
                            ),
                            ref=fallback_ref,
                            ref_index=ref_index,
                            source_euid=source_euid,
                        )
                    )
                except Exception:
                    continue

        fastq_node_ids, dewey_registered = self._identify_fastq_nodes(
            external_payloads,
            bloom_client=bloom_client,
            run_euid=run_euid,
            demo_key=demo_key,
        )
        if not fastq_node_ids:
            fastq_node_ids = [run_euid]
        merged_graph = merge_graph_payloads(
            local_payload,
            external_payloads,
        )
        return merged_graph, {
            "external_graph_count": len(external_payloads),
            "fastq_node_ids": fastq_node_ids,
            "dewey_registered": dewey_registered,
        }

    @staticmethod
    def _collect_focus_ids(
        *,
        state: dict[str, Any],
        graph_meta: dict[str, Any],
        preflight: dict[str, Any],
    ) -> set[str]:
        selected_ids: set[str] = set()
        for key in (
            "trf",
            "test",
            "fulfillment_item",
            "shipment",
            "kit",
            "collection_event",
            "paperwork",
            "work_item",
        ):
            value = state.get(key)
            euid = str(getattr(value, "euid", "") or "").strip()
            if euid:
                selected_ids.add(euid)

        for payload in (
            preflight.get("patient"),
            preflight.get("clinician"),
            preflight.get("site"),
            preflight.get("organization"),
        ):
            euid = str(getattr(payload, "euid", "") or "").strip()
            if euid:
                selected_ids.add(euid)

        tube = state.get("tube")
        if tube is not None:
            for attr in ("container_euid", "container_external_object_euid"):
                value = str(getattr(tube, attr, "") or "").strip()
                if value:
                    selected_ids.add(value)

        accepted = state.get("accepted_material")
        if accepted is not None:
            for attr in (
                "container_euid",
                "container_external_object_euid",
                "specimen_euid",
                "specimen_external_object_euid",
            ):
                value = str(getattr(accepted, attr, "") or "").strip()
                if value:
                    selected_ids.add(value)

        for key in ("extraction", "library_prep", "pool", "run"):
            payload = state.get(key)
            if not isinstance(payload, dict):
                continue
            for field in payload.values():
                if isinstance(field, str) and field.strip():
                    selected_ids.add(field.strip())

        for node_id in list(graph_meta.get("fastq_node_ids") or []):
            clean = str(node_id or "").strip()
            if clean:
                selected_ids.add(clean)
        return selected_ids

    @staticmethod
    def _augment_graph_with_context(
        merged_graph: dict[str, Any],
        *,
        manifest: dict[str, Any],
    ) -> dict[str, Any]:
        context_nodes, context_edges = build_atlas_context_elements(manifest)
        nodes = list((merged_graph.get("elements") or {}).get("nodes") or [])
        edges = list((merged_graph.get("elements") or {}).get("edges") or [])
        nodes.extend(context_nodes)
        edges.extend(context_edges)
        meta = dict(merged_graph.get("meta") or {})
        meta["atlas_context_node_count"] = len(context_nodes)
        meta["atlas_context_edge_count"] = len(context_edges)
        return {
            "elements": {
                "nodes": _dedupe_elements(nodes),
                "edges": _dedupe_elements(edges),
            },
            "meta": meta,
        }

    @staticmethod
    def _focus_graph_for_demo(
        merged_graph: dict[str, Any],
        *,
        selected_ids: set[str],
    ) -> dict[str, Any]:
        nodes = list((merged_graph.get("elements") or {}).get("nodes") or [])
        edges = list((merged_graph.get("elements") or {}).get("edges") or [])

        kept_node_ids: set[str] = set()
        focused_nodes: list[dict[str, Any]] = []
        for node in nodes:
            data = dict(node.get("data") or {})
            node_id = str(data.get("id") or "").strip()
            candidates = {
                str(data.get("id") or "").strip(),
                str(data.get("euid") or "").strip(),
                str(data.get("remote_euid") or "").strip(),
            }
            keep = any(candidate and candidate in selected_ids for candidate in candidates)
            if not keep or not node_id:
                continue
            kept_node_ids.add(node_id)
            focused_nodes.append({"data": data})

        focused_edges: list[dict[str, Any]] = []
        for edge in edges:
            data = dict(edge.get("data") or {})
            source = str(data.get("source") or "").strip()
            target = str(data.get("target") or "").strip()
            if source in kept_node_ids and target in kept_node_ids:
                focused_edges.append({"data": data})

        meta = dict(merged_graph.get("meta") or {})
        meta.update(
            {
                "focused": True,
                "focused_node_count": len(focused_nodes),
                "focused_edge_count": len(focused_edges),
            }
        )
        return {
            "elements": {
                "nodes": focused_nodes,
                "edges": focused_edges,
            },
            "meta": meta,
        }

    @staticmethod
    def _collect_focus_ids_from_manifest(manifest: dict[str, Any]) -> set[str]:
        selected_ids: set[str] = set()
        atlas = manifest.get("atlas") or {}
        bloom = manifest.get("bloom") or {}
        for section in (
            "trf",
            "test",
            "test_fulfillment_item",
            "shipment",
            "testkit",
            "collection_event",
            "paperwork",
            "accession_work_item",
        ):
            payload = atlas.get(section) or {}
            value = str(payload.get("euid") or "").strip()
            if value:
                selected_ids.add(value)
        for section in ("patient", "clinician", "site", "organization"):
            payload = manifest.get(section) or {}
            value = str(payload.get("euid") or "").strip()
            if value:
                selected_ids.add(value)
        for key in (
            "container_external_object_id",
            "container_euid",
            "specimen_external_object_id",
            "specimen_euid",
            "plate_euid",
            "well_euid",
            "extraction_output_euid",
            "library_prep_output_euid",
            "library_material_euid",
            "library_container_euid",
            "library_plate_euid",
            "library_well_euid",
            "pool_euid",
            "pool_container_euid",
            "run_euid",
        ):
            value = str(bloom.get(key) or "").strip()
            if value:
                selected_ids.add(value)
        for node_id in list((manifest.get("graph_meta") or {}).get("fastq_node_ids") or []):
            clean = str(node_id or "").strip()
            if clean:
                selected_ids.add(clean)
        return selected_ids

    @staticmethod
    def _ensure_manifest_context(
        manifest: dict[str, Any],
        *,
        preflight: dict[str, Any],
    ) -> dict[str, Any]:
        ensured = copy.deepcopy(manifest)
        ensured["patient"] = {
            "euid": preflight["patient"].euid,
            "name": preflight["patient_name"],
        }
        ensured["clinician"] = {
            "euid": preflight["clinician"].euid,
            "name": preflight["clinician_name"],
        }
        ensured["site"] = {
            "euid": preflight["site"].euid,
            "name": preflight["site_name"],
        }
        ensured["organization"] = {
            "euid": preflight["organization"].euid,
            "name": preflight["organization_name"],
        }
        return ensured

    def _identify_fastq_nodes(
        self,
        external_payloads: list[dict[str, Any]],
        *,
        bloom_client: BloomClient,
        run_euid: str,
        demo_key: str,
    ) -> tuple[list[str], bool]:
        fastq_node_ids: list[str] = []
        dewey_registered = False
        run_id = str(run_euid or "").strip()
        demo_key_text = str(demo_key or "").strip().lower()
        for payload in external_payloads:
            nodes = list((payload.get("elements") or {}).get("nodes") or [])
            edges = list((payload.get("elements") or {}).get("edges") or [])
            run_node_ids: set[str] = set()
            candidate_nodes: dict[str, tuple[str, str]] = {}
            for node in nodes:
                data = dict(node.get("data") or {})
                node_id = str(data.get("id") or "").strip()
                remote_euid = str(data.get("remote_euid") or data.get("euid") or "").strip()
                if run_id and remote_euid == run_id and node_id:
                    run_node_ids.add(node_id)
                label_text = " ".join(
                    str(data.get(key) or "")
                    for key in ("name", "euid", "remote_euid", "type", "obj_type")
                ).lower()
                if "fastq" not in label_text and "run_artifact" not in label_text:
                    continue
                if node_id:
                    candidate_nodes[node_id] = (remote_euid, label_text)

            connected_fastq_node_ids: list[str] = []
            if run_node_ids:
                for edge in edges:
                    data = dict(edge.get("data") or {})
                    source = str(data.get("source") or "").strip()
                    target = str(data.get("target") or "").strip()
                    if source in candidate_nodes and target in run_node_ids:
                        connected_fastq_node_ids.append(source)
                    elif target in candidate_nodes and source in run_node_ids:
                        connected_fastq_node_ids.append(target)

            if not connected_fastq_node_ids:
                for node_id, (_remote_euid, label_text) in candidate_nodes.items():
                    if (
                        demo_key_text
                        and demo_key_text in label_text
                        or run_id
                        and run_id.lower() in label_text
                    ):
                        connected_fastq_node_ids.append(node_id)

            for node_id in connected_fastq_node_ids:
                remote_euid, _label_text = candidate_nodes.get(node_id, ("", ""))
                if node_id and node_id not in fastq_node_ids:
                    fastq_node_ids.append(node_id)
                if remote_euid and not dewey_registered:
                    try:
                        detail = bloom_client.get_graph_object_detail(euid=remote_euid)
                    except BloomClientError:
                        continue
                    dewey_registered = self._artifact_detail_has_dewey(detail)
        return fastq_node_ids, dewey_registered

    @staticmethod
    def _artifact_detail_has_dewey(detail: dict[str, Any]) -> bool:
        payload = detail.get("json_addl")
        if not isinstance(payload, dict):
            return False
        props = payload.get("properties")
        if not isinstance(props, dict):
            return False
        return bool(str(props.get("dewey_artifact_euid") or "").strip())

    def _build_manifest(
        self,
        *,
        normalized: DayInLifeDemoConfig,
        preflight: dict[str, Any],
        state: dict[str, Any],
        stages: list[dict[str, Any]],
        graph_meta: dict[str, Any],
        artifacts: DayInLifeDemoArtifacts,
    ) -> dict[str, Any]:
        graph_url = f"{normalized.atlas_base_url.rstrip('/')}/graph?" + urlencode(
            {
                "start_euid": state["test"].euid,
                "depth": self.graph_depth,
                "tenant_id": str(preflight["tenant_id"]),
                "projection": "story",
            }
        )
        dewey_note = (
            "FASTQ artifacts include Dewey artifact links."
            if graph_meta.get("dewey_registered")
            else "FASTQ artifacts are present in Bloom run_artifact records; no Dewey link was detected in this localhost run."
        )
        return {
            "demo_key": normalized.demo_key,
            "created_at": _now_iso(),
            "actor": {
                "email": normalized.actor_email,
                "tenant_id": str(preflight["tenant_id"]),
            },
            "patient": {
                "euid": preflight["patient"].euid,
                "name": preflight["patient_name"],
            },
            "clinician": {
                "euid": preflight["clinician"].euid,
                "name": preflight["clinician_name"],
            },
            "site": {
                "euid": normalized.site_euid,
                "name": preflight["site_name"],
            },
            "organization": {
                "euid": preflight["organization"].euid,
                "name": preflight["organization_name"],
            },
            "assay": {
                "code": normalized.assay_route_code,
                "name": normalized.assay_name,
            },
            "atlas": {
                "trf": {
                    "euid": state["trf"].euid,
                    "order_number": getattr(state["trf"], "order_number", state["trf"].euid),
                },
                "test": {
                    "euid": state["test"].euid,
                    "product_code": getattr(
                        state["test_revision"], "product_code", normalized.assay_route_code
                    ),
                },
                "test_fulfillment_item": {
                    "euid": state["fulfillment_item"].euid,
                },
                "shipment": {
                    "euid": state["shipment"].euid,
                    "shipment_number": getattr(
                        state["shipment"], "shipment_number", state["shipment"].euid
                    ),
                    "tracking_number": self._tracking_number(normalized.demo_key),
                },
                "testkit": {
                    "euid": state["kit"].euid,
                    "barcode": self._kit_barcode(normalized.demo_key),
                },
                "collection_event": {
                    "euid": state["collection_event"].euid,
                },
                "paperwork": {
                    "euid": state["paperwork"].euid,
                },
                "accession_work_item": {
                    "euid": state["work_item"].euid,
                },
            },
            "bloom": {
                "container_external_object_id": state["tube"].container_external_object_euid,
                "container_euid": state["tube"].container_euid,
                "specimen_external_object_id": state[
                    "accepted_material"
                ].specimen_external_object_euid,
                "specimen_euid": state["accepted_material"].specimen_euid,
                "plate_euid": state["extraction"]["plate_euid"],
                "well_euid": state["extraction"]["well_euid"],
                "extraction_output_euid": state["extraction"]["extraction_output_euid"],
                "library_prep_output_euid": state["library_prep"]["library_prep_output_euid"],
                "library_material_euid": state["library_prep"].get("library_material_euid"),
                "library_container_euid": state["library_prep"].get("library_container_euid"),
                "library_plate_euid": state["library_prep"].get("library_plate_euid"),
                "library_well_euid": state["library_prep"].get("library_well_euid"),
                "pool_euid": state["pool"]["pool_euid"],
                "pool_container_euid": state["pool"]["pool_container_euid"],
                "run_euid": state["run"]["run_euid"],
                "flowcell_id": state["run"]["flowcell_id"],
                "resolution": state["resolution"],
                "dewey_note": dewey_note,
            },
            "artifacts": {
                "output_dir": str(artifacts.output_dir),
                "manifest_path": str(artifacts.manifest_path),
                "graph_elements_path": str(artifacts.graph_elements_path),
                "dag_html_path": str(artifacts.html_path),
                "dag_png_path": str(artifacts.png_path),
                "live_graph_url": graph_url,
            },
            "graph_meta": graph_meta,
            "stages": stages,
        }

    def _stage(self, stage_name: str, *, system: str, **payload: Any) -> dict[str, Any]:
        return {"stage": stage_name, "system": system, "occurred_at": _now_iso(), **payload}

    def _ensure_relation(
        self,
        *,
        tenant_id: uuid.UUID,
        external_object_id: str,
        relation_type: str,
        local_entity_type: str,
        local_entity_id: str,
        actor_id: uuid.UUID | None,
    ) -> None:
        external_objects = ExternalObjectService(self.db, tenant_id)
        current = external_objects.list_relations_for_external_object(external_object_id)
        for relation in current:
            if (
                relation.relation_type == relation_type
                and relation.local_entity_type == local_entity_type
                and relation.local_entity_id == local_entity_id
            ):
                return
        external_objects.create_relation(
            ExternalObjectRelationCreate(
                external_object_id=external_object_id,
                relation_type=relation_type,
                local_entity_type=local_entity_type,
                local_entity_id=local_entity_id,
                metadata={},
            ),
            actor_id=actor_id,
        )

    @staticmethod
    def _tracking_number(demo_key: str) -> str:
        suffix = _slugify(demo_key).upper().replace("-", "")[:18]
        return f"DIL{suffix or 'DEMO'}"

    @staticmethod
    def _kit_barcode(demo_key: str) -> str:
        suffix = _slugify(demo_key).upper().replace("-", "")[:18]
        return f"KIT{suffix or 'DEMO'}"

    @staticmethod
    def _library_barcode(demo_key: str) -> str:
        suffix = _slugify(demo_key).upper().replace("-", "")[:14]
        return f"LIB{suffix or 'DEMO'}"

    @staticmethod
    def _flowcell_id(demo_key: str) -> str:
        suffix = _slugify(demo_key).upper().replace("-", "")[:12]
        return f"FC{suffix or 'DEMO'}"

    @staticmethod
    def _run_name(demo_key: str) -> str:
        suffix = _slugify(demo_key).upper().replace("-", "")[:14]
        return f"RU-{suffix or 'DEMO'}"

    def _render_screenshot(self, html_path: Path, png_path: Path) -> None:
        pwcli = os.environ.get("PWCLI", "").strip()
        if pwcli:
            base_cmd = [pwcli]
        else:
            base_cmd = ["npx", "--yes", "--package=@playwright/cli", "playwright-cli"]

        session_suffix = _slugify(html_path.parent.name).replace("-", "")[:10] or "demo"
        session_name = f"dil{session_suffix}"
        port = self._pick_free_port()
        server = subprocess.Popen(
            [
                os.environ.get("PYTHON", "python"),
                "-m",
                "http.server",
                str(port),
                "--bind",
                "127.0.0.1",
            ],
            cwd=str(html_path.parent),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        env = dict(os.environ)
        session_arg = f"-s={session_name}"
        page_url = f"http://127.0.0.1:{port}/{html_path.name}"
        try:
            self._wait_for_http_server(page_url)
            commands: list[list[str]] = [
                [*base_cmd, session_arg, "open", page_url],
                [*base_cmd, session_arg, "resize", "1680", "1200"],
                [
                    *base_cmd,
                    session_arg,
                    "run-code",
                    "async page => { await page.waitForFunction(() => window.__DAY_IN_LIFE_READY === true); }",
                ],
                [
                    *base_cmd,
                    session_arg,
                    "screenshot",
                    "--filename",
                    str(png_path),
                    "--full-page",
                ],
                [*base_cmd, session_arg, "close"],
            ]
            for command in commands:
                try:
                    subprocess.run(
                        command,
                        check=True,
                        cwd=str(html_path.parent),
                        env=env,
                        capture_output=True,
                        text=True,
                    )
                except (FileNotFoundError, subprocess.CalledProcessError) as exc:
                    raise DayInLifeDemoError(
                        f"Failed rendering {png_path.name} via Playwright CLI: {exc}"
                    ) from exc
        finally:
            server.terminate()
            try:
                server.wait(timeout=2)
            except subprocess.TimeoutExpired:
                server.kill()
        if not png_path.exists():
            raise DayInLifeDemoError(f"Playwright did not produce {png_path}")

    @staticmethod
    def _pick_free_port() -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])

    @staticmethod
    def _wait_for_http_server(url: str) -> None:
        for _ in range(40):
            try:
                response = httpx.get(url, timeout=1.0)
                if response.status_code < 500:
                    return
            except httpx.HTTPError:
                pass
            time.sleep(0.1)
        raise DayInLifeDemoError(f"Temporary DAG server did not become ready: {url}")
