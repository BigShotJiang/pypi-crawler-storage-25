"""Atlas boundary service for Bloom-owned materials."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from app.domain.services.external_objects import (
    BloomConfigResolverService,
    ExternalObjectRelationCreate,
    ExternalObjectService,
    ExternalObjectUpsert,
)
from app.domain.services.order_relationships import OrderRelationshipService
from app.domain.services.orgs import OrganizationService, SiteService
from app.domain.services.people import PatientService
from app.domain.services.shipments import ShipmentService, TestKitService
from app.domain.services.test_fulfillment_items import TestFulfillmentItemService
from app.domain.services.trfs import TestService, TrfService
from app.integrations.bloom_client import (
    BloomClient,
    BloomClientError,
    BloomOperationResult,
    resolve_secret_value,
)
from app.settings import settings

CANONICAL_STARTING_QUEUES = frozenset({"extraction_prod", "extraction_rnd"})


def _as_nonempty_str(value: str | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _dedupe_preserve_order(values: list[str] | None) -> list[str]:
    seen: set[str] = set()
    normalized: list[str] = []
    for value in values or []:
        clean = _as_nonempty_str(value)
        if clean is None or clean in seen:
            continue
        seen.add(clean)
        normalized.append(clean)
    return normalized


def _sanitize_bloom_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    """Drop non-authoritative foreign UUID fields from persisted external metadata."""
    blocked = {"uuid", "container_uuid", "specimen_uuid", "external_uuid"}
    return {key: value for key, value in (payload or {}).items() if key not in blocked}


def _sanitize_queue_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    """Drop related-object identifiers from queue-event metadata."""
    blocked_exact = {
        "atlas_tenant_id",
        "atlas_trf_euid",
        "atlas_test_euid",
        "atlas_test_euids",
        "atlas_test_fulfillment_item_euid",
        "atlas_test_fulfillment_item_euids",
        "atlas_patient_euid",
        "container_euid",
        "specimen_euid",
        "run_euid",
        "pool_euid",
        "plate_euid",
        "well_euid",
        "queue_euid",
        "origin_site_id",
    }
    blocked_suffixes = ("_euid", "_euids", "_id", "_ids")
    sanitized: dict[str, Any] = {}
    for key, value in (payload or {}).items():
        text = str(key or "").strip()
        if not text:
            continue
        lowered = text.lower()
        if lowered in blocked_exact or lowered.endswith(blocked_suffixes):
            continue
        sanitized[text] = value
    return sanitized


def _template_components(template_code: str) -> tuple[str, str, str, str]:
    parts = [part for part in str(template_code or "").strip().strip("/").split("/") if part]
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


@dataclass
class AtlasReferences:
    atlas_tenant_id: str | None = None
    atlas_trf_euid: str | None = None
    atlas_test_euid: str | None = None

    def normalized(self) -> dict[str, str]:
        refs: dict[str, str] = {}
        for key in ("atlas_tenant_id", "atlas_trf_euid", "atlas_test_euid"):
            value = _as_nonempty_str(getattr(self, key))
            if value:
                refs[key] = value
        return refs


@dataclass
class AcceptedMaterialRequest:
    trf_euid: str
    test_euids: list[str]
    patient_euid: str
    shipment_euid: str | None = None
    testkit_euid: str | None = None
    origin_site_id: str | None = None
    specimen_template_code: str = "content/specimen/blood-whole/1.0"
    specimen_name: str | None = None
    container_euid: str | None = None
    container_template_code: str = field(
        default_factory=lambda: settings.bloom_default_container_template_code
    )
    status: str = "active"
    properties: dict[str, Any] = field(default_factory=dict)
    starting_queue: str = "extraction_prod"
    queue_metadata: dict[str, Any] = field(default_factory=dict)
    idempotency_key: str | None = None


@dataclass
class AcceptedMaterialResult:
    container_external_object_euid: str
    specimen_external_object_euid: str
    container_euid: str | None
    specimen_euid: str
    starting_queue: str
    current_queue: str
    created: bool
    queue_idempotent_replay: bool
    fulfillment_item_euids: list[str]


@dataclass
class TubeCreationRequest:
    test_euid: str | None = None
    test_euids: list[str] | None = None
    patient_euid: str | None = None
    shipment_euid: str | None = None
    testkit_euid: str | None = None
    site_euid: str | None = None
    collection_site_euid: str | None = None
    origin_site_id: str | None = None
    specimen_template_code: str = "content/specimen/blood-whole/1.0"
    specimen_name: str | None = None
    container_euid: str | None = None
    container_template_code: str = field(
        default_factory=lambda: settings.bloom_default_container_template_code
    )
    collected_at: datetime | None = None
    collection_type: str | None = None
    collected_by: str | None = None
    expected_mrn: str | None = None
    expected_dob: str | None = None
    expected_name: str | None = None
    expected_label_text: str | None = None
    status: str = "active"
    properties: dict[str, Any] = field(default_factory=dict)
    idempotency_key: str | None = None


@dataclass
class TubeCreationResult:
    container_external_object_euid: str
    container_euid: str
    specimen_external_object_euid: str | None
    specimen_euid: str | None
    created: bool
    collection_event_euid: str | None = None
    trf_euid: str | None = None
    test_euid: str | None = None
    test_euids: list[str] = field(default_factory=list)


class ContainerSpecimenBridgeService:
    """Orchestrates Bloom beta accepted-material operations and Atlas mirrors."""

    PROVIDER = "bloom"

    def __init__(self, db: Any, tenant_id):
        self.db = db
        self.tenant_id = tenant_id
        self.external_objects = ExternalObjectService(db, tenant_id)
        self.config_resolver = BloomConfigResolverService(db)
        self.orders = TrfService(db, tenant_id)
        self.test_orders = TestService(db, tenant_id)
        self.patients = PatientService(db, tenant_id)
        self.shipments = ShipmentService(db, tenant_id)
        self.testkits = TestKitService(db, tenant_id)
        self.order_relationships = OrderRelationshipService(db, tenant_id)
        self.fulfillment_items = TestFulfillmentItemService(db, tenant_id)
        self.sites = SiteService(db)
        self.organizations = OrganizationService(db)

    def _get_bloom_client(self, site_id: str | None = None) -> BloomClient:
        cfg = self.config_resolver.get_effective(organization_id=self.tenant_id, site_id=site_id)
        if cfg is None or not cfg.enabled:
            raise BloomClientError(
                f"Bloom integration is not enabled for organization {self.tenant_id}"
            )
        if not cfg.bloom_base_url:
            raise BloomClientError("Bloom integration config missing bloom_base_url")
        if not cfg.bloom_api_key_secret_ref:
            raise BloomClientError("Bloom integration config missing bloom_api_key_secret_ref")

        api_key = resolve_secret_value(cfg.bloom_api_key_secret_ref)
        return BloomClient(
            base_url=cfg.bloom_base_url,
            api_key=api_key,
            timeout_seconds=settings.bloom_request_timeout_seconds,
            max_retries=settings.bloom_max_retries,
            verify_ssl=settings.bloom_verify_ssl,
        )

    def _validate_template_code(self, template_code: str) -> None:
        normalized = str(template_code or "").strip().strip("/")
        if normalized not in set(settings.bloom_allowed_specimen_template_codes):
            raise ValueError(
                "Unsupported specimen_template_code. Allowed: "
                + ", ".join(settings.bloom_allowed_specimen_template_codes)
            )

    def _persist_external_object(
        self,
        *,
        object_type: str,
        bloom_result: BloomOperationResult,
        actor_id=None,
        is_deleted: bool = False,
    ):
        return self.external_objects.upsert_external_object(
            ExternalObjectUpsert(
                provider=self.PROVIDER,
                object_type=object_type,
                external_euid=bloom_result.external_euid,
                status=bloom_result.status,
                is_deleted=is_deleted,
                metadata=_sanitize_bloom_metadata(bloom_result.raw),
                version=1,
            ),
            actor_id=actor_id,
        )

    def _ensure_trf(self, trf_euid: str) -> str:
        trf = self.orders.get_by_id(trf_euid, cross_tenant=False)
        if trf is None:
            raise ValueError(f"TRF not found: {trf_euid}")
        return trf[0].euid

    def _ensure_patient(self, patient_euid: str) -> str:
        patient = self.patients.get(patient_euid, cross_tenant=False)
        if patient is None:
            raise ValueError(f"Patient not found: {patient_euid}")
        return patient[0].euid

    def _ensure_testkit(self, testkit_euid: str | None) -> str | None:
        clean = _as_nonempty_str(testkit_euid)
        if clean is None:
            return None
        kit = self.testkits.get_with_revision(clean, cross_tenant=False)
        if kit is None:
            raise ValueError(f"TestKit not found: {testkit_euid}")
        return kit[0].euid

    def _ensure_shipment(self, shipment_euid: str | None) -> str | None:
        clean = _as_nonempty_str(shipment_euid)
        if clean is None:
            return None
        shipment = self.shipments.get(clean, cross_tenant=False)
        if shipment is None:
            raise ValueError(f"Shipment not found: {shipment_euid}")
        return shipment[0].euid

    def _ensure_site(self, site_id: str) -> str:
        site = self.sites.get_by_id(site_id)
        if site is None:
            raise ValueError(f"Site not found: {site_id}")
        organization = self.organizations.get_by_id(str(site.organization_id))
        if organization is None or organization.uid != self.tenant_id:
            raise ValueError(f"Site {site_id} does not belong to organization {self.tenant_id}")
        return site.euid

    def _resolve_tests(self, *, trf_euid: str, test_euids: list[str]) -> list[str]:
        normalized = _dedupe_preserve_order(test_euids)
        if not normalized:
            raise ValueError("test_euids must not be empty")

        resolved: list[str] = []
        for test_euid in normalized:
            test = self.test_orders.get_by_id(test_euid, cross_tenant=False)
            if test is None:
                raise ValueError(f"Test not found: {test_euid}")
            if str(test.order_id) != str(trf_euid):
                raise ValueError(f"Test {test_euid} does not belong to TRF {trf_euid}")
            resolved.append(test.euid)
        return resolved

    def _resolve_test_context(self, *, test_euid: str) -> tuple[str, str]:
        clean = _as_nonempty_str(test_euid)
        if clean is None:
            raise ValueError("test_euid is required")
        test = self.test_orders.get_by_id(clean, cross_tenant=False)
        if test is None:
            raise ValueError(f"Test not found: {test_euid}")
        trf_euid = self._ensure_trf(str(test.order_id))
        return trf_euid, test.euid

    def _resolve_tube_test_context(
        self,
        *,
        test_euid: str | None,
        test_euids: list[str] | None,
    ) -> tuple[str | None, list[str]]:
        requested_inputs: list[str] = []
        clean_test_euid = _as_nonempty_str(test_euid)
        if clean_test_euid is not None:
            requested_inputs.append(clean_test_euid)
        requested_inputs.extend(test_euids or [])
        requested = _dedupe_preserve_order(requested_inputs)
        if not requested:
            return None, []
        resolved_trf_euid: str | None = None
        resolved_test_euids: list[str] = []
        for requested_test_euid in requested:
            trf_euid, resolved_test_euid = self._resolve_test_context(test_euid=requested_test_euid)
            if resolved_trf_euid is None:
                resolved_trf_euid = trf_euid
            elif str(resolved_trf_euid) != str(trf_euid):
                raise ValueError("All requested tests for a tube must belong to the same TRF")
            resolved_test_euids.append(resolved_test_euid)
        return resolved_trf_euid, _dedupe_preserve_order(resolved_test_euids)

    def _resolve_origin_site_euid(
        self,
        *,
        shipment_euid: str | None,
        testkit_euid: str | None,
        origin_site_id: str | None,
    ) -> str | None:
        resolved_origin_site = _as_nonempty_str(origin_site_id)
        if shipment_euid is not None:
            shipment = self.shipments.get(shipment_euid, cross_tenant=False)
            if shipment is not None and shipment[1] is not None:
                resolved_origin_site = (
                    _as_nonempty_str(shipment[1].origin_site_id) or resolved_origin_site
                )
        if testkit_euid is not None:
            testkit = self.testkits.get_with_revision(testkit_euid, cross_tenant=False)
            if testkit is not None and testkit[1] is not None:
                resolved_origin_site = (
                    _as_nonempty_str(testkit[1].origin_site_id) or resolved_origin_site
                )
        if resolved_origin_site is None:
            return None
        return self._ensure_site(resolved_origin_site)

    def _resolve_direct_site_euid(
        self,
        *,
        site_euid: str | None,
    ) -> str | None:
        clean = _as_nonempty_str(site_euid)
        if clean is None:
            return None
        return self._ensure_site(clean)

    def _resolve_collection_site_euid(
        self,
        *,
        collection_site_euid: str | None,
        fallback_origin_site_id: str | None,
    ) -> str | None:
        from app.domain.services.site_scope import list_tenant_site_options

        requested = _as_nonempty_str(collection_site_euid) or _as_nonempty_str(
            fallback_origin_site_id
        )
        if requested is None:
            site_options = list_tenant_site_options(self.db, self.tenant_id)
            if len(site_options) == 1:
                requested = str(site_options[0].id)
        if requested is None:
            return None
        return self._ensure_site(requested)

    def _tube_anchor_state(
        self,
        data: TubeCreationRequest,
        *,
        require_anchor: bool,
    ) -> dict[str, Any]:
        trf_euid, test_euids = self._resolve_tube_test_context(
            test_euid=data.test_euid,
            test_euids=data.test_euids,
        )
        test_euid = test_euids[0] if test_euids else None

        patient_euid = (
            self._ensure_patient(data.patient_euid)
            if _as_nonempty_str(data.patient_euid) is not None
            else None
        )
        if patient_euid is not None and test_euids:
            self._validate_patient_for_tests(patient_euid=patient_euid, test_euids=test_euids)

        shipment_euid = self._ensure_shipment(data.shipment_euid)
        testkit_euid = self._ensure_testkit(data.testkit_euid)
        site_euid = self._resolve_direct_site_euid(site_euid=data.site_euid)
        collection_site_euid = self._resolve_collection_site_euid(
            collection_site_euid=data.collection_site_euid,
            fallback_origin_site_id=data.origin_site_id,
        )

        if require_anchor:
            self.external_objects.validate_container_relation_payload(
                trf_id=trf_euid,
                test_ids=test_euids,
                testkit_id=testkit_euid,
                shipment_id=shipment_euid,
                site_id=site_euid,
            )

        fulfillment_item_euids = (
            self._resolve_fulfillment_item_euids(test_euids=test_euids, actor_id=None)
            if test_euids
            else []
        )
        fulfillment_items = [
            {
                "atlas_test_euid": requested_test_euid,
                "atlas_test_fulfillment_item_euid": fulfillment_item_euid,
            }
            for requested_test_euid, fulfillment_item_euid in zip(
                test_euids, fulfillment_item_euids, strict=False
            )
        ]

        return {
            "test_euid": test_euid,
            "test_euids": test_euids,
            "trf_euid": trf_euid,
            "patient_euid": patient_euid,
            "shipment_euid": shipment_euid,
            "testkit_euid": testkit_euid,
            "site_euid": site_euid,
            "collection_site_euid": collection_site_euid,
            "fulfillment_item_euids": fulfillment_item_euids,
            "fulfillment_items": fulfillment_items,
        }

    def _resolve_bloom_site_for_tube(
        self,
        *,
        collection_site_euid: str | None,
        site_euid: str | None,
        shipment_euid: str | None,
        testkit_euid: str | None,
    ) -> str | None:
        if collection_site_euid is not None:
            return collection_site_euid
        if site_euid is not None:
            return site_euid
        return self._resolve_origin_site_euid(
            shipment_euid=shipment_euid,
            testkit_euid=testkit_euid,
            origin_site_id=None,
        )

    def _atlas_context_for_tube(
        self,
        *,
        anchor_state: dict[str, Any],
        collection_event_euid: str | None = None,
        collection_snapshot: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        patient_euid = anchor_state.get("patient_euid")
        if collection_event_euid is not None:
            patient_euid = None
        ctx: dict[str, Any] = {
            "atlas_tenant_id": str(self.tenant_id),
            "atlas_test_euid": anchor_state.get("test_euid"),
            "atlas_test_euids": list(anchor_state.get("test_euids") or []),
            "atlas_trf_euid": anchor_state.get("trf_euid"),
            "atlas_testkit_euid": anchor_state.get("testkit_euid"),
            "atlas_shipment_euid": anchor_state.get("shipment_euid"),
            "atlas_organization_site_euid": anchor_state.get("site_euid"),
            "atlas_patient_euid": patient_euid,
            "atlas_collection_event_euid": collection_event_euid,
            "collection_event_snapshot": collection_snapshot or None,
            "fulfillment_items": list(anchor_state.get("fulfillment_items") or []),
        }
        return {
            key: value
            for key, value in ctx.items()
            if value not in (None, "", []) or key == "fulfillment_items"
        }

    @staticmethod
    def _collection_snapshot_payload(event_obj, revision) -> dict[str, Any]:
        return {
            "collection_event_euid": event_obj.euid,
            "collected_at": revision.collected_at.isoformat() if revision.collected_at else None,
            "site_euid": event_obj.site_id,
            "collection_type": revision.collection_type,
            "collected_by": revision.collected_by,
            "expected_mrn": revision.expected_mrn,
            "expected_dob": revision.expected_dob,
            "expected_name": revision.expected_name,
            "expected_label_text": revision.expected_label_text,
        }

    def _relation_type_for_anchor(self, local_entity_type: str) -> str:
        mapping = {
            "Test": "belongs_to_test",
            "Shipment": "belongs_to_shipment",
            "TestKit": "belongs_to_testkit",
            "Site": "belongs_to_site",
            "CollectionEvent": "has_collection_event",
        }
        if local_entity_type not in mapping:
            raise ValueError(f"Unsupported anchor entity type: {local_entity_type}")
        return mapping[local_entity_type]

    def _sync_container_relations(
        self,
        *,
        external_object_id: str,
        anchor_state: dict[str, Any],
        collection_event_euid: str | None = None,
        actor_id=None,
    ) -> None:
        desired: dict[str, list[tuple[str, str, dict[str, Any] | None]]] = {
            "belongs_to_test": [],
            "belongs_to_test_fulfillment_item": [],
            "belongs_to_shipment": [],
            "belongs_to_testkit": [],
            "belongs_to_site": [],
            "has_collection_event": [],
        }
        for idx, test_euid in enumerate(anchor_state.get("test_euids") or []):
            desired["belongs_to_test"].append(("Test", test_euid, {"primary": idx == 0}))
        for idx, fulfillment_item_euid in enumerate(
            anchor_state.get("fulfillment_item_euids") or []
        ):
            desired["belongs_to_test_fulfillment_item"].append(
                ("TestFulfillmentItem", fulfillment_item_euid, {"primary": idx == 0})
            )
        if anchor_state.get("shipment_euid"):
            desired["belongs_to_shipment"].append(("Shipment", anchor_state["shipment_euid"], None))
        if anchor_state.get("testkit_euid"):
            desired["belongs_to_testkit"].append(("TestKit", anchor_state["testkit_euid"], None))
        if anchor_state.get("site_euid"):
            desired["belongs_to_site"].append(("Site", anchor_state["site_euid"], None))
        if collection_event_euid:
            desired["has_collection_event"].append(("CollectionEvent", collection_event_euid, None))

        current = self.external_objects.list_relations_for_external_object(external_object_id)
        managed_types = set(desired)
        desired_targets = {
            relation_type: {entity_id for _, entity_id, _ in relations}
            for relation_type, relations in desired.items()
        }
        for relation in current:
            if relation.relation_type not in managed_types:
                continue
            if relation.local_entity_id not in desired_targets.get(relation.relation_type, set()):
                self.external_objects.delete_relation(
                    external_object_id=external_object_id,
                    relation_type=relation.relation_type,
                    local_entity_id=relation.local_entity_id,
                )

        current = self.external_objects.list_relations_for_external_object(external_object_id)
        existing_targets = {
            (relation.relation_type, relation.local_entity_id)
            for relation in current
            if relation.relation_type in managed_types
        }
        for relation_type, relations in desired.items():
            for entity_type, entity_id, metadata in relations:
                if (relation_type, entity_id) in existing_targets:
                    continue
                self._persist_relation(
                    external_object_id=external_object_id,
                    relation_type=relation_type,
                    local_entity_type=entity_type,
                    local_entity_id=entity_id,
                    metadata=metadata,
                    actor_id=actor_id,
                )

    def _validate_patient_for_tests(
        self,
        *,
        patient_euid: str,
        test_euids: list[str],
    ) -> None:
        saw_links = False
        for test_euid in test_euids:
            links = self.order_relationships.list_order_patient_links(order_euid=test_euid)
            if not links:
                continue
            saw_links = True
            if any(link.patient_euid == patient_euid for link in links):
                return
        if not saw_links:
            return
        raise ValueError(f"Patient {patient_euid} is not linked to any requested tests")

    def _build_create_object_payload(
        self,
        *,
        template_code: str,
        name: str | None,
        properties: dict[str, Any] | None,
    ) -> dict[str, Any]:
        category, type_name, subtype, version = _template_components(template_code)
        payload: dict[str, Any] = {
            "category": category,
            "type": type_name,
            "subtype": subtype,
            "version": version,
        }
        clean_name = _as_nonempty_str(name)
        if clean_name:
            payload["name"] = clean_name
        clean_props = {k: v for k, v in dict(properties or {}).items() if v is not None}
        if clean_props:
            payload["properties"] = clean_props
        return payload

    def _resolve_link_targets(
        self,
        data: AcceptedMaterialRequest,
    ) -> tuple[str, list[str], str, str | None, str | None, str]:
        trf_euid = self._ensure_trf(data.trf_euid)
        patient_euid = self._ensure_patient(data.patient_euid)
        test_euids = self._resolve_tests(
            trf_euid=trf_euid,
            test_euids=data.test_euids,
        )
        self._validate_patient_for_tests(
            patient_euid=patient_euid,
            test_euids=test_euids,
        )
        testkit_euid = self._ensure_testkit(data.testkit_euid)
        shipment_euid = self._ensure_shipment(data.shipment_euid)
        origin_site_id = self._resolve_origin_site_euid(
            shipment_euid=shipment_euid,
            testkit_euid=testkit_euid,
            origin_site_id=data.origin_site_id,
        )
        self.external_objects.validate_container_relation_payload(
            trf_id=trf_euid,
            test_ids=test_euids,
            testkit_id=testkit_euid,
            shipment_id=shipment_euid,
        )
        if data.starting_queue not in CANONICAL_STARTING_QUEUES:
            raise ValueError(
                "starting_queue must be one of: " + ", ".join(sorted(CANONICAL_STARTING_QUEUES))
            )
        if origin_site_id is None:
            raise ValueError("Bloom material requests require an origin site")
        return (
            trf_euid,
            test_euids,
            patient_euid,
            testkit_euid,
            shipment_euid,
            origin_site_id,
        )

    def _persist_relation(
        self,
        *,
        external_object_id: str,
        relation_type: str,
        local_entity_type: str,
        local_entity_id: str,
        metadata: dict[str, Any] | None = None,
        actor_id=None,
    ) -> None:
        self.external_objects.create_relation(
            ExternalObjectRelationCreate(
                external_object_id=external_object_id,
                relation_type=relation_type,
                local_entity_type=local_entity_type,
                local_entity_id=local_entity_id,
                metadata=metadata or {},
            ),
            actor_id=actor_id,
        )

    def _persist_material_relations(
        self,
        *,
        container_external_object_id: str,
        specimen_external_object_id: str,
        container_euid: str | None,
        trf_euid: str,
        test_euids: list[str],
        fulfillment_item_euids: list[str],
        patient_euid: str,
        testkit_euid: str | None,
        shipment_euid: str | None,
        actor_id=None,
    ) -> None:
        self._persist_relation(
            external_object_id=container_external_object_id,
            relation_type="belongs_to_trf",
            local_entity_type="TRF",
            local_entity_id=trf_euid,
            actor_id=actor_id,
        )
        if testkit_euid is not None:
            self._persist_relation(
                external_object_id=container_external_object_id,
                relation_type="belongs_to_testkit",
                local_entity_type="TestKit",
                local_entity_id=testkit_euid,
                actor_id=actor_id,
            )
        if shipment_euid is not None:
            self._persist_relation(
                external_object_id=container_external_object_id,
                relation_type="belongs_to_shipment",
                local_entity_type="Shipment",
                local_entity_id=shipment_euid,
                actor_id=actor_id,
            )

        self.external_objects.validate_specimen_relation_payload(
            patient_id=patient_euid,
            container_euid=container_euid,
        )
        self._persist_relation(
            external_object_id=specimen_external_object_id,
            relation_type="belongs_to_patient",
            local_entity_type="Patient",
            local_entity_id=patient_euid,
            actor_id=actor_id,
        )
        self._persist_relation(
            external_object_id=specimen_external_object_id,
            relation_type="contained_in",
            local_entity_type="ExternalObject",
            local_entity_id=container_external_object_id,
            actor_id=actor_id,
        )

        for idx, test_euid in enumerate(test_euids):
            relation_metadata = {"primary": idx == 0}
            self._persist_relation(
                external_object_id=container_external_object_id,
                relation_type="belongs_to_test",
                local_entity_type="Test",
                local_entity_id=test_euid,
                metadata=relation_metadata,
                actor_id=actor_id,
            )

        for idx, fulfillment_item_euid in enumerate(fulfillment_item_euids):
            relation_metadata = {"primary": idx == 0}
            self._persist_relation(
                external_object_id=container_external_object_id,
                relation_type="belongs_to_test_fulfillment_item",
                local_entity_type="TestFulfillmentItem",
                local_entity_id=fulfillment_item_euid,
                metadata=relation_metadata,
                actor_id=actor_id,
            )

    def _resolve_fulfillment_item_euids(
        self,
        *,
        test_euids: list[str],
        actor_id=None,
    ) -> list[str]:
        fulfillment_item_euids: list[str] = []
        for test_euid in test_euids:
            fulfillment_item = self.fulfillment_items.ensure_default_for_test(
                test_euid=test_euid,
                created_by=actor_id,
            )
            fulfillment_item_euids.append(fulfillment_item.euid)
        return _dedupe_preserve_order(fulfillment_item_euids)

    def register_accepted_material(
        self,
        data: AcceptedMaterialRequest,
        actor_id=None,
    ) -> AcceptedMaterialResult:
        self._validate_template_code(data.specimen_template_code)
        (
            trf_euid,
            test_euids,
            patient_euid,
            testkit_euid,
            shipment_euid,
            origin_site_id,
        ) = self._resolve_link_targets(data)
        fulfillment_item_euids = self._resolve_fulfillment_item_euids(
            test_euids=test_euids,
            actor_id=actor_id,
        )
        atlas_context = {
            "atlas_tenant_id": str(self.tenant_id),
            "atlas_trf_euid": trf_euid,
            "atlas_test_euid": test_euids[0] if test_euids else None,
            "atlas_test_euids": list(test_euids),
            "atlas_patient_euid": patient_euid,
            "fulfillment_items": [
                {
                    "atlas_test_euid": test_euid,
                    "atlas_test_fulfillment_item_euid": fulfillment_item_euid,
                }
                for test_euid, fulfillment_item_euid in zip(
                    test_euids, fulfillment_item_euids, strict=False
                )
            ],
        }
        if testkit_euid:
            atlas_context["atlas_testkit_euid"] = testkit_euid
        if shipment_euid:
            atlas_context["atlas_shipment_euid"] = shipment_euid
        if origin_site_id:
            atlas_context["atlas_organization_site_euid"] = origin_site_id

        client = self._get_bloom_client(origin_site_id)
        bloom_result = client.register_accepted_material(
            {
                "specimen_template_code": data.specimen_template_code,
                "specimen_name": data.specimen_name,
                "container_euid": _as_nonempty_str(data.container_euid),
                "container_template_code": data.container_template_code,
                "status": data.status,
                "properties": dict(data.properties or {}),
                "atlas_context": atlas_context,
            },
            idempotency_key=data.idempotency_key,
        )
        container_euid = _as_nonempty_str(
            str(bloom_result.raw.get("container_euid"))
            if bloom_result.raw.get("container_euid")
            else None
        )
        if container_euid is None:
            container_euid = _as_nonempty_str(data.container_euid)
        if container_euid is None:
            raise BloomClientError("Bloom accepted-material response missing container_euid")

        container_object = self._persist_external_object(
            object_type="container",
            bloom_result=BloomOperationResult(
                external_euid=container_euid,
                status=str(bloom_result.raw.get("status") or data.status),
                raw=bloom_result.raw,
            ),
            actor_id=actor_id,
        )

        specimen_euid = _as_nonempty_str(
            str(bloom_result.raw.get("specimen_euid"))
            if bloom_result.raw.get("specimen_euid")
            else None
        )
        if specimen_euid is None:
            specimen_euid = _as_nonempty_str(bloom_result.external_euid)
        if specimen_euid is None:
            raise BloomClientError("Bloom accepted-material response missing specimen_euid")
        specimen_object = self._persist_external_object(
            object_type="specimen",
            bloom_result=BloomOperationResult(
                external_euid=specimen_euid,
                status=str(bloom_result.raw.get("status") or data.status),
                raw=bloom_result.raw,
            ),
            actor_id=actor_id,
        )

        self._persist_material_relations(
            container_external_object_id=container_object.euid,
            specimen_external_object_id=specimen_object.euid,
            container_euid=container_euid,
            trf_euid=trf_euid,
            test_euids=test_euids,
            fulfillment_item_euids=fulfillment_item_euids,
            patient_euid=patient_euid,
            testkit_euid=testkit_euid,
            shipment_euid=shipment_euid,
            actor_id=actor_id,
        )

        queue_result = client.move_material_to_queue(
            container_euid,
            data.starting_queue,
            metadata=_sanitize_queue_metadata(dict(data.queue_metadata or {})),
            idempotency_key=(f"{data.idempotency_key}:queue" if data.idempotency_key else None),
        )
        return AcceptedMaterialResult(
            container_external_object_euid=container_object.euid,
            specimen_external_object_euid=specimen_object.euid,
            container_euid=container_euid,
            specimen_euid=specimen_object.external_euid,
            starting_queue=data.starting_queue,
            current_queue=str(queue_result.get("current_queue") or data.starting_queue),
            created=bool(bloom_result.raw.get("created", True)),
            queue_idempotent_replay=bool(queue_result.get("idempotent_replay", False)),
            fulfillment_item_euids=fulfillment_item_euids,
        )

    def create_tube_with_optional_specimen(
        self,
        data: TubeCreationRequest,
        actor_id=None,
    ) -> TubeCreationResult:
        patient_euid = _as_nonempty_str(data.patient_euid)
        if patient_euid is None:
            return self.create_empty_tube(data, actor_id=actor_id)
        if _as_nonempty_str(data.container_euid) is None:
            empty_result = self.create_empty_tube(
                TubeCreationRequest(
                    test_euid=data.test_euid,
                    test_euids=data.test_euids,
                    shipment_euid=data.shipment_euid,
                    testkit_euid=data.testkit_euid,
                    site_euid=data.site_euid,
                    collection_site_euid=data.collection_site_euid,
                    origin_site_id=data.origin_site_id,
                    container_template_code=data.container_template_code,
                    status=data.status,
                    properties=dict(data.properties or {}),
                    idempotency_key=data.idempotency_key,
                ),
                actor_id=actor_id,
            )
            data = TubeCreationRequest(
                **{**data.__dict__, "container_euid": empty_result.container_euid}
            )
        return self.fill_tube(data, actor_id=actor_id)

    def create_empty_tube(
        self,
        data: TubeCreationRequest,
        actor_id=None,
    ) -> TubeCreationResult:
        anchor_state = self._tube_anchor_state(data, require_anchor=True)
        bloom_site_euid = self._resolve_bloom_site_for_tube(
            collection_site_euid=None,
            site_euid=anchor_state.get("site_euid"),
            shipment_euid=anchor_state.get("shipment_euid"),
            testkit_euid=anchor_state.get("testkit_euid"),
        )
        client = self._get_bloom_client(bloom_site_euid)
        atlas_context = self._atlas_context_for_tube(anchor_state=anchor_state)
        tube_result = client.create_empty_tube(
            {
                "container_template_code": data.container_template_code,
                "status": data.status,
                "properties": dict(data.properties or {}),
                "atlas_context": atlas_context,
            },
            idempotency_key=data.idempotency_key,
        )
        container_euid = _as_nonempty_str(
            tube_result.raw.get("container_euid") or tube_result.external_euid
        )
        if container_euid is None:
            raise BloomClientError("Bloom tube-create response missing container_euid")
        container_object = self._persist_external_object(
            object_type="container",
            bloom_result=BloomOperationResult(
                external_euid=container_euid,
                status=str(tube_result.raw.get("status") or data.status),
                raw=tube_result.raw,
            ),
            actor_id=actor_id,
        )
        self._sync_container_relations(
            external_object_id=container_object.euid,
            anchor_state=anchor_state,
            actor_id=actor_id,
        )
        return TubeCreationResult(
            container_external_object_euid=container_object.euid,
            container_euid=container_euid,
            specimen_external_object_euid=None,
            specimen_euid=None,
            trf_euid=anchor_state.get("trf_euid"),
            test_euid=anchor_state.get("test_euid"),
            test_euids=list(anchor_state.get("test_euids") or []),
            created=bool(tube_result.raw.get("created", True)),
        )

    def fill_tube(
        self,
        data: TubeCreationRequest,
        actor_id=None,
    ) -> TubeCreationResult:
        from app.domain.services.collection_events import (
            CollectionEventCreate,
            CollectionEventService,
        )

        self._validate_template_code(data.specimen_template_code)
        anchor_state = self._tube_anchor_state(data, require_anchor=True)
        patient_euid = anchor_state.get("patient_euid")
        if patient_euid is None:
            raise ValueError("patient_euid is required to fill a tube")
        collection_site_euid = anchor_state.get("collection_site_euid")
        if collection_site_euid is None:
            raise ValueError("collection_site_euid is required to fill a tube")

        container_euid = _as_nonempty_str(data.container_euid)
        if container_euid is None:
            raise ValueError("container_euid is required to fill a tube")

        existing_container = self.external_objects.get_external_object(
            provider=self.PROVIDER,
            object_type="container",
            external_euid=container_euid,
        )
        container_object_id = existing_container.euid if existing_container is not None else None
        if container_object_id is not None:
            existing_relations = self.external_objects.list_relations_for_external_object(
                container_object_id
            )
            if any(rel.relation_type == "has_collection_event" for rel in existing_relations):
                raise ValueError("Tube is already filled and linked to a collection event")

        collection_service = CollectionEventService(self.db, self.tenant_id)
        collected_at = data.collected_at or datetime.now(UTC)
        collection_event, _collection_revision = collection_service.create(
            CollectionEventCreate(
                patient_euid=patient_euid,
                site_euid=collection_site_euid,
                container_euid=container_euid,
                specimen_euid=None,
                collected_at=collected_at,
                collection_type=data.collection_type,
                collected_by=data.collected_by,
                expected_mrn=data.expected_mrn,
                expected_dob=data.expected_dob,
                expected_name=data.expected_name,
                expected_label_text=data.expected_label_text,
            ),
            created_by=actor_id,
        )

        collection_snapshot = self._collection_snapshot_payload(
            collection_event,
            type(
                "_RevisionProxy",
                (),
                {
                    "collected_at": collected_at,
                    "collection_type": data.collection_type,
                    "collected_by": data.collected_by,
                    "expected_mrn": data.expected_mrn,
                    "expected_dob": data.expected_dob,
                    "expected_name": data.expected_name,
                    "expected_label_text": data.expected_label_text,
                },
            )(),
        )
        bloom_site_euid = self._resolve_bloom_site_for_tube(
            collection_site_euid=collection_site_euid,
            site_euid=anchor_state.get("site_euid"),
            shipment_euid=anchor_state.get("shipment_euid"),
            testkit_euid=anchor_state.get("testkit_euid"),
        )
        client = self._get_bloom_client(bloom_site_euid)
        atlas_context = self._atlas_context_for_tube(
            anchor_state=anchor_state,
            collection_event_euid=collection_event.euid,
            collection_snapshot=collection_snapshot,
        )
        specimen_result = client.register_accepted_material(
            {
                "specimen_template_code": data.specimen_template_code,
                "specimen_name": data.specimen_name,
                "container_euid": container_euid,
                "container_template_code": data.container_template_code,
                "status": data.status,
                "properties": dict(data.properties or {}),
                "atlas_context": atlas_context,
            },
            idempotency_key=(f"{data.idempotency_key}:specimen" if data.idempotency_key else None),
        )
        specimen_euid = _as_nonempty_str(
            str(specimen_result.raw.get("specimen_euid"))
            if specimen_result.raw.get("specimen_euid")
            else specimen_result.external_euid
        )
        if specimen_euid is None:
            raise BloomClientError("Bloom accepted-material response missing specimen_euid")

        collection_service.attach_specimen(
            collection_event.euid,
            specimen_euid,
            updated_by=actor_id,
        )

        container_object = self._persist_external_object(
            object_type="container",
            bloom_result=BloomOperationResult(
                external_euid=container_euid,
                status=str(specimen_result.raw.get("status") or data.status),
                raw=specimen_result.raw,
            ),
            actor_id=actor_id,
        )
        specimen_object = self._persist_external_object(
            object_type="specimen",
            bloom_result=BloomOperationResult(
                external_euid=specimen_euid,
                status=str(specimen_result.raw.get("status") or data.status),
                raw=specimen_result.raw,
            ),
            actor_id=actor_id,
        )

        self._sync_container_relations(
            external_object_id=container_object.euid,
            anchor_state=anchor_state,
            collection_event_euid=collection_event.euid,
            actor_id=actor_id,
        )
        self.external_objects.validate_specimen_relation_payload(
            collection_event_id=collection_event.euid,
            patient_id=patient_euid,
            container_euid=container_euid,
        )
        self._persist_relation(
            external_object_id=specimen_object.euid,
            relation_type="belongs_to_collection_event",
            local_entity_type="CollectionEvent",
            local_entity_id=collection_event.euid,
            actor_id=actor_id,
        )
        self._persist_relation(
            external_object_id=specimen_object.euid,
            relation_type="contained_in",
            local_entity_type="ExternalObject",
            local_entity_id=container_object.euid,
            actor_id=actor_id,
        )

        return TubeCreationResult(
            container_external_object_euid=container_object.euid,
            container_euid=container_euid,
            specimen_external_object_euid=specimen_object.euid,
            specimen_euid=specimen_euid,
            collection_event_euid=collection_event.euid,
            trf_euid=anchor_state.get("trf_euid"),
            test_euid=anchor_state.get("test_euid"),
            test_euids=list(anchor_state.get("test_euids") or []),
            created=bool(specimen_result.raw.get("created", True)),
        )

    def sync_collection_event_snapshot(
        self,
        *,
        collection_event_id: str,
        actor_id=None,
    ) -> None:
        from app.domain.services.collection_events import CollectionEventService

        collection_result = CollectionEventService(self.db, self.tenant_id).get(collection_event_id)
        if collection_result is None:
            raise ValueError(f"Collection event not found: {collection_event_id}")
        event_obj, revision = collection_result
        specimen_euid = _as_nonempty_str(event_obj.specimen_euid)
        if specimen_euid is None:
            raise ValueError(
                f"Collection event {collection_event_id} is not yet linked to a Bloom specimen"
            )
        client = self._get_bloom_client(event_obj.site_id)
        client.update_beta_specimen(
            specimen_euid,
            {
                "atlas_context": {
                    "atlas_tenant_id": str(self.tenant_id),
                    "atlas_collection_event_euid": event_obj.euid,
                    "collection_event_snapshot": self._collection_snapshot_payload(
                        event_obj,
                        revision,
                    ),
                }
            },
        )

    def update_tube(
        self,
        *,
        container_euid: str,
        test_euid: str | None = None,
        test_euids: list[str] | None = None,
        shipment_euid: str | None = None,
        testkit_euid: str | None = None,
        site_euid: str | None = None,
        status: str | None = None,
        actor_id=None,
    ) -> TubeCreationResult:
        anchor_state = self._tube_anchor_state(
            TubeCreationRequest(
                test_euid=test_euid,
                test_euids=test_euids,
                shipment_euid=shipment_euid,
                testkit_euid=testkit_euid,
                site_euid=site_euid,
            ),
            require_anchor=True,
        )
        bloom_site_euid = self._resolve_bloom_site_for_tube(
            collection_site_euid=None,
            site_euid=anchor_state.get("site_euid"),
            shipment_euid=anchor_state.get("shipment_euid"),
            testkit_euid=anchor_state.get("testkit_euid"),
        )
        client = self._get_bloom_client(bloom_site_euid)
        atlas_context = self._atlas_context_for_tube(anchor_state=anchor_state)
        tube_result = client.update_tube(
            container_euid,
            {
                "status": status,
                "atlas_context": atlas_context,
            },
        )
        container_object = self._persist_external_object(
            object_type="container",
            bloom_result=BloomOperationResult(
                external_euid=container_euid,
                status=str(tube_result.raw.get("status") or status or "active"),
                raw=tube_result.raw,
            ),
            actor_id=actor_id,
        )
        existing_collection_event = [
            rel.local_entity_id
            for rel in self.external_objects.list_relations_for_external_object(
                container_object.euid
            )
            if rel.relation_type == "has_collection_event"
        ]
        self._sync_container_relations(
            external_object_id=container_object.euid,
            anchor_state=anchor_state,
            collection_event_euid=existing_collection_event[0]
            if existing_collection_event
            else None,
            actor_id=actor_id,
        )
        return TubeCreationResult(
            container_external_object_euid=container_object.euid,
            container_euid=container_euid,
            specimen_external_object_euid=None,
            specimen_euid=None,
            collection_event_euid=existing_collection_event[0]
            if existing_collection_event
            else None,
            trf_euid=anchor_state.get("trf_euid"),
            test_euid=anchor_state.get("test_euid"),
            test_euids=list(anchor_state.get("test_euids") or []),
            created=bool(tube_result.raw.get("created", True)),
        )

    def list_specimens_by_reference(
        self,
        atlas_refs: AtlasReferences,
        actor_id=None,
    ) -> list[dict[str, Any]]:
        client = self._get_bloom_client()
        results = client.find_external_specimens_by_reference(atlas_refs.normalized())
        deduped: dict[str, dict[str, Any]] = {}
        for item in results:
            specimen_euid = _as_nonempty_str(
                str(item.get("specimen_euid")) if item.get("specimen_euid") is not None else None
            ) or _as_nonempty_str(str(item.get("euid")) if item.get("euid") is not None else None)
            if specimen_euid is None:
                continue
            bloom_result = BloomOperationResult(
                external_euid=specimen_euid,
                status=str(item.get("status") or "active"),
                raw=item,
            )
            self._persist_external_object(
                object_type="specimen",
                bloom_result=bloom_result,
                actor_id=actor_id,
            )
            container_euid = _as_nonempty_str(
                str(item.get("container_euid")) if item.get("container_euid") is not None else None
            )
            if container_euid:
                self._persist_external_object(
                    object_type="container",
                    bloom_result=BloomOperationResult(
                        external_euid=container_euid,
                        status=str(item.get("status") or "active"),
                        raw=item,
                    ),
                    actor_id=actor_id,
                )
            deduped[specimen_euid] = item
        return list(deduped.values())

    def apply_bloom_event(
        self,
        *,
        event_type: str,
        event_payload: dict[str, Any],
        actor_id=None,
    ):
        object_type = "container" if event_type.startswith("container.") else "specimen"
        external_euid = (
            event_payload.get("euid")
            or event_payload.get("container_euid")
            or event_payload.get("specimen_euid")
        )
        if not external_euid:
            raise BloomClientError("Bloom event payload missing euid")
        status = str(event_payload.get("status") or "active")
        is_deleted = event_type.endswith(".deleted")
        result = BloomOperationResult(
            external_euid=str(external_euid),
            status=status,
            raw=event_payload,
        )
        return self._persist_external_object(
            object_type=object_type,
            bloom_result=result,
            actor_id=actor_id,
            is_deleted=is_deleted,
        )
