"""Ursa result-return integration service for the beta contract."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy.orm import Session

from app.domain.enums import FulfillmentRunState
from app.domain.services.fulfillment_runs import (
    FulfillmentOutputService,
    FulfillmentRunCreate,
    FulfillmentRunService,
    ResultCreate,
    ResultsSetService,
    TransitionData,
)
from app.domain.services.test_fulfillment_items import TestFulfillmentItemService
from app.domain.services.trfs import TestService, TrfService
from app.integrations.dewey_client import DeweyClient, DeweyClientError
from app.persistence.tapdb.trfs import TapdbTrfRepository
from app.settings import settings


@dataclass(frozen=True)
class UrsaArtifactInput:
    artifact_euid: str
    artifact_type: str | None = None
    storage_uri: str | None = None
    filename: str | None = None
    mime_type: str | None = None
    size_bytes: int | None = None
    checksum_sha256: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class UrsaResultReturnRequest:
    atlas_tenant_id: str
    atlas_trf_euid: str
    atlas_test_euid: str
    atlas_test_fulfillment_item_euid: str
    analysis_euid: str
    run_euid: str
    sequenced_library_assignment_euid: str
    flowcell_id: str
    lane: str
    library_barcode: str
    analysis_type: str
    result_status: str
    review_state: str
    source_system: str
    result_payload: dict[str, Any] = field(default_factory=dict)
    artifacts: list[UrsaArtifactInput] = field(default_factory=list)


@dataclass(frozen=True)
class UrsaResultReturnResult:
    fulfillment_run_euid: str
    fulfillment_output_euid: str
    artifact_euids: list[str]
    results_set_euid: str | None
    idempotent_replay: bool


class UrsaResultReturnService:
    """Applies Ursa analysis outputs into Atlas assay and artifact surfaces."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.orders = TrfService(db, tenant_id)
        self.test_orders = TestService(db, tenant_id)
        self.fulfillment_items = TestFulfillmentItemService(db, tenant_id)
        self.fulfillment_runs = FulfillmentRunService(db, tenant_id)
        self.fulfillment_outputs = FulfillmentOutputService(db, tenant_id)
        self.results_sets = ResultsSetService(db, tenant_id)
        self.order_repo = TapdbTrfRepository(db)
        self.dewey_client: DeweyClient | None = None
        if settings.dewey_enabled:
            self.dewey_client = DeweyClient(
                base_url=settings.dewey_base_url,
                token=settings.dewey_api_token,
                timeout_seconds=float(settings.dewey_request_timeout_seconds),
                verify_ssl=bool(settings.dewey_verify_ssl),
            )

    def apply(self, request: UrsaResultReturnRequest) -> UrsaResultReturnResult:
        if request.source_system != "daylily-ursa":
            raise ValueError("source_system must be daylily-ursa")
        if str(self.tenant_id) != str(request.atlas_tenant_id):
            raise ValueError("atlas_tenant_id does not match the authenticated tenant")
        if request.review_state.upper() != "APPROVED":
            raise ValueError("Only approved analyses can be returned to Atlas")

        trf_pair = self.orders.get(request.atlas_trf_euid, cross_tenant=False)
        if trf_pair is None:
            raise ValueError(f"TRF not found: {request.atlas_trf_euid}")
        trf, _trf_revision = trf_pair

        test = self.test_orders.get_by_id(request.atlas_test_euid, cross_tenant=False)
        if test is None:
            raise ValueError(f"Test not found: {request.atlas_test_euid}")
        if str(test.order_id) != str(trf.euid):
            raise ValueError(
                f"Test {request.atlas_test_euid} does not belong to TRF {request.atlas_trf_euid}"
            )
        fulfillment_item = self.fulfillment_items.get(request.atlas_test_fulfillment_item_euid)
        if fulfillment_item is None:
            raise ValueError(
                f"TestFulfillmentItem not found: {request.atlas_test_fulfillment_item_euid}"
            )
        if fulfillment_item.test_euid != test.euid:
            raise ValueError("TestFulfillmentItem does not belong to the supplied Atlas Test")

        fulfillment_run_euid = self._resolve_fulfillment_run(trf.euid, test.euid)
        artifact_euids = self._register_artifacts(request)

        existing = self._existing_result_for_analysis(fulfillment_run_euid, request.analysis_euid)
        if existing is not None:
            results_set = self.results_sets.get_latest_for_fulfillment_run(fulfillment_run_euid)
            return UrsaResultReturnResult(
                fulfillment_run_euid=fulfillment_run_euid,
                fulfillment_output_euid=existing.euid,
                artifact_euids=artifact_euids,
                results_set_euid=results_set.euid if results_set is not None else None,
                idempotent_replay=True,
            )

        results_set = self.results_sets.get_or_create_for_test(test.euid, created_by=None)
        self.results_sets.add_fulfillment_run(results_set.euid, fulfillment_run_euid)

        self._advance_fulfillment_run(
            fulfillment_run_euid,
            target_state=self._target_fulfillment_run_state(request),
        )

        result = self.fulfillment_outputs.create(
            fulfillment_run_euid,
            ResultCreate(
                result_payload=dict(request.result_payload or {}),
                artifact_ids=artifact_euids,
                analysis_context={
                    "analysis_euid": request.analysis_euid,
                    "source_system": request.source_system,
                    "run_euid": request.run_euid,
                    "sequenced_library_assignment_euid": request.sequenced_library_assignment_euid,
                    "flowcell_id": request.flowcell_id,
                    "lane": request.lane,
                    "library_barcode": request.library_barcode,
                    "analysis_type": request.analysis_type,
                    "review_state": request.review_state,
                    "result_status": request.result_status,
                    "atlas_trf_euid": request.atlas_trf_euid,
                    "atlas_test_euid": request.atlas_test_euid,
                    "atlas_test_fulfillment_item_euid": request.atlas_test_fulfillment_item_euid,
                },
            ),
            created_by=None,
        )

        return UrsaResultReturnResult(
            fulfillment_run_euid=fulfillment_run_euid,
            fulfillment_output_euid=result.euid,
            artifact_euids=artifact_euids,
            results_set_euid=results_set.euid,
            idempotent_replay=False,
        )

    def _resolve_fulfillment_run(self, trf_euid: str, test_euid: str) -> str:
        existing = sorted(
            self.fulfillment_runs.list_for_test_order(test_euid),
            key=lambda row: row[0].fulfillment_route_code,
        )
        if existing:
            return existing[0][0].euid

        revision = self.order_repo.get_latest_test_revision(test_euid)
        fulfillment_route_codes = list(getattr(revision, "fulfillment_route_codes", []) or [])
        fulfillment_route_code = (
            fulfillment_route_codes[0]
            if fulfillment_route_codes
            else getattr(revision, "product_code", None) or "GEN"
        )
        fulfillment_run, _revision = self.fulfillment_runs.create(
            FulfillmentRunCreate(
                order_id=trf_euid,
                test_order_id=test_euid,
                fulfillment_route_code=fulfillment_route_code,
            ),
            created_by=None,
        )
        return fulfillment_run.euid

    def _advance_fulfillment_run(
        self, fulfillment_run_euid: str, *, target_state: FulfillmentRunState
    ) -> None:
        current = self.fulfillment_runs.get_current_state(fulfillment_run_euid)
        if current is None:
            raise ValueError(f"FulfillmentRun not found: {fulfillment_run_euid}")
        if current == target_state:
            return
        if current in {FulfillmentRunState.CANCELLED, FulfillmentRunState.AMENDED}:
            raise ValueError(
                f"FulfillmentRun {fulfillment_run_euid} is terminal in state {current.value}"
            )

        if target_state == FulfillmentRunState.FAILED:
            sequence = [
                FulfillmentRunState.ORDERED,
                FulfillmentRunState.RECEIVED,
                FulfillmentRunState.FAILED,
            ]
        else:
            sequence = [
                FulfillmentRunState.ORDERED,
                FulfillmentRunState.RECEIVED,
                FulfillmentRunState.ACCESSIONED,
                FulfillmentRunState.IN_PROGRESS,
                target_state,
            ]

        if current == FulfillmentRunState.QC_HOLD and target_state == FulfillmentRunState.RESULTED:
            self.fulfillment_runs.transition(
                fulfillment_run_euid,
                TransitionData(
                    target_state=FulfillmentRunState.RESULTED,
                    note="Ursa result return",
                    qc_override=True,
                ),
                transition_by=None,
            )
            return

        for state in sequence:
            latest = self.fulfillment_runs.get_current_state(fulfillment_run_euid)
            if latest is None or latest == target_state:
                return
            if latest == state:
                continue
            self.fulfillment_runs.transition(
                fulfillment_run_euid,
                TransitionData(target_state=state, note="Ursa result return"),
                transition_by=None,
            )

    def _target_fulfillment_run_state(
        self, request: UrsaResultReturnRequest
    ) -> FulfillmentRunState:
        if request.result_status.upper() in {"FAILED", "ERROR"}:
            return FulfillmentRunState.FAILED
        return FulfillmentRunState.RESULTED

    def _existing_result_for_analysis(self, fulfillment_run_euid: str, analysis_euid: str):
        return self.fulfillment_outputs.get_by_analysis_euid(fulfillment_run_euid, analysis_euid)

    def _register_artifacts(self, request: UrsaResultReturnRequest) -> list[str]:
        if self.dewey_client is None:
            raise ValueError("dewey_enabled=true is required for Ursa artifact result return")

        artifact_euids: list[str] = []
        seen: set[str] = set()
        for artifact in request.artifacts:
            artifact_euid = str(artifact.artifact_euid or "").strip()
            if not artifact_euid:
                raise ValueError("Ursa artifact payload missing artifact_euid")
            if artifact_euid in seen:
                continue
            try:
                self.dewey_client.get_artifact(artifact_euid)
            except DeweyClientError as exc:
                raise ValueError(
                    f"Dewey artifact resolution failed for {artifact_euid}: {exc}"
                ) from exc
            seen.add(artifact_euid)
            artifact_euids.append(artifact_euid)
        return artifact_euids
