"""Atlas family services (TapDB-backed)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from app.domain.enums import AuditAction


@dataclass
class FamilyCreate:
    name: str
    notes: str | None = None
    site_id: str | None = None


class FamilyService:
    """Service for Family operations with tenant scoping."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.families import TapdbFamilyRepository

            self._tapdb_repo = TapdbFamilyRepository(self.db)
        return self._tapdb_repo

    def _log_audit_event(
        self,
        *,
        tenant_id: uuid.UUID,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        user_id: uuid.UUID | None,
        details: dict | None = None,
    ) -> None:
        """Best-effort audit logging via TapDB-backed AuditService."""
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db, tenant_id=tenant_id, user_id=str(user_id) if user_id else None
            ).log(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
                user_id=user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()

    def create(self, data: FamilyCreate, created_by: uuid.UUID | None = None):
        from app.domain.services.site_scope import resolve_tenant_site_euid

        resolved_site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.site_id)
        family, revision = self._repo().create_family(
            tenant_id=self.tenant_id,
            name=data.name,
            notes=data.notes,
            site_id=resolved_site_id,
            created_by=created_by,
        )
        self._log_audit_event(
            tenant_id=self.tenant_id,
            action=AuditAction.CREATE,
            entity_type="Family",
            entity_id=family.euid,
            user_id=created_by,
            details={"name": data.name},
        )
        return family, revision

    def get_by_id(self, family_id: str, cross_tenant: bool = False):
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_family_with_revision(family_euid=family_id, tenant_id=tenant_scope)

    def list_families(self, limit: int = 100, offset: int = 0, cross_tenant: bool = False):
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_families(tenant_id=tenant_scope, limit=limit, offset=offset)
