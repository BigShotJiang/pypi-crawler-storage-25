"""LSMC Hub - Dashboard Service (TapDB-only runtime)."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from datetime import datetime

from app.domain.enums import ExceptionStatus, OrderPatientRole, ReleasePackageStatus, ShipmentStatus
from app.domain.services.exceptions import ExceptionService
from app.domain.services.external_objects import ExternalObjectService
from app.domain.services.order_relationships import OrderRelationshipService
from app.domain.services.people import PatientService
from app.domain.services.releases import ReleaseService
from app.domain.services.shipments import ShipmentService
from app.domain.services.trfs import TestService, TrfService

logger = logging.getLogger(__name__)

_DASHBOARD_ACTIVE_ORDER_STATUSES = {
    "ACTIVE",
    "IN_PROGRESS",
    "ON_HOLD",
    "ORDERED",
    "QC_HOLD",
    "RECEIVING_IN_PROGRESS",
    "SUBMITTED",
}
_DASHBOARD_COMPLETED_ORDER_STATUSES = {
    "AMENDED",
    "CLOSED_NO_RESULTS",
    "COMPLETED_REPORT_READY",
    "RELEASED",
    "RESULTS_READY",
}


@dataclass
class DashboardStats:
    """Dashboard statistics."""

    orders_total: int
    orders_active: int
    orders_draft: int
    orders_completed: int
    shipments_total: int
    shipments_in_transit: int
    materials_total: int
    materials_received: int
    results_ready: int
    exceptions_open: int
    exceptions_assigned: int


@dataclass
class RecentOrder:
    """Recent order summary."""

    id: str
    order_number: str
    patient_name: str | None
    status: str
    created_at: str


@dataclass
class PendingException:
    """Pending exception summary."""

    id: str
    exception_number: str
    exception_type: str
    barcode: str | None
    issue: str
    created_at: str


class DashboardService:
    """Service for dashboard data."""

    def __init__(self, db, tenant_id: uuid.UUID, user_id: str | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    @staticmethod
    def _norm_status(value: str | None) -> str:
        return str(value or "").strip().upper()

    def get_stats(self, cross_tenant: bool = False) -> DashboardStats:
        """Calculate dashboard statistics from TapDB-backed services."""
        orders = TrfService(self.db, self.tenant_id).list_trfs(
            limit=10_000,
            cross_tenant=cross_tenant,
        )
        shipments = ShipmentService(self.db, self.tenant_id).list_shipments(
            limit=10_000,
            cross_tenant=cross_tenant,
        )
        exceptions = ExceptionService(self.db, self.tenant_id, self.user_id).list_exceptions(
            limit=10_000,
            cross_tenant=cross_tenant,
        )
        releases = ReleaseService(self.db, self.tenant_id).list_packages(
            limit=10_000,
            cross_tenant=cross_tenant,
        )

        orders_total = len(orders)
        orders_draft = 0
        orders_active = 0
        orders_completed = 0
        for _trf, revision in orders:
            status = self._norm_status(getattr(revision, "status", None))
            if status == "DRAFT":
                orders_draft += 1
            elif status in _DASHBOARD_COMPLETED_ORDER_STATUSES:
                orders_completed += 1
            elif status in _DASHBOARD_ACTIVE_ORDER_STATUSES:
                orders_active += 1

        shipments_total = len(shipments)
        shipments_in_transit = sum(
            1
            for _shipment, revision in shipments
            if self._norm_status(getattr(revision, "status", None))
            == ShipmentStatus.IN_TRANSIT.value
        )

        if cross_tenant:
            external_svc = ExternalObjectService(self.db, uuid.UUID(int=0))
            all_specimens = external_svc._repository().list_external_objects(  # pylint: disable=protected-access
                tenant_id=None,
                provider="bloom",
                object_type="specimen",
                include_deleted=False,
            )
        else:
            external_svc = ExternalObjectService(self.db, self.tenant_id)
            all_specimens = external_svc.list_external_objects(
                provider="bloom",
                object_type="specimen",
                include_deleted=False,
            )
        materials_total = len(all_specimens)
        materials_received = sum(
            1
            for specimen in all_specimens
            if self._norm_status(getattr(specimen, "status", None))
            in {"ACTIVE", "MATCHED", "RECEIVED"}
        )

        results_ready = sum(
            1
            for _package, revision in releases
            if self._norm_status(getattr(revision, "status", None))
            in {ReleasePackageStatus.APPROVED.value, ReleasePackageStatus.RELEASED.value}
        )

        exceptions_open = 0
        exceptions_assigned = 0
        for _exception, revision in exceptions:
            status = self._norm_status(getattr(revision, "status", None))
            if status == ExceptionStatus.OPEN.value:
                exceptions_open += 1
            elif status == ExceptionStatus.ASSIGNED.value:
                exceptions_assigned += 1

        return DashboardStats(
            orders_total=orders_total,
            orders_active=orders_active,
            orders_draft=orders_draft,
            orders_completed=orders_completed,
            shipments_total=shipments_total,
            shipments_in_transit=shipments_in_transit,
            materials_total=materials_total,
            materials_received=materials_received,
            results_ready=results_ready,
            exceptions_open=exceptions_open,
            exceptions_assigned=exceptions_assigned,
        )

    def _resolve_patient_name_for_trf(
        self,
        *,
        trf_euid: str,
        trf_revision,
        test_svc: TestService,
        patient_svc: PatientService,
        cross_tenant: bool,
    ) -> str | None:
        candidate_patient_euid: str | None = getattr(trf_revision, "patient_id", None)
        try:
            links_svc = OrderRelationshipService(self.db, self.tenant_id)
            test_rows = test_svc.list_for_trf(trf_euid, cross_tenant=cross_tenant)
            first_link: str | None = None
            proband_link: str | None = None
            for test, _test_rev, _assays in test_rows:
                links = links_svc.list_order_patient_links(order_euid=test.euid)
                for link in links:
                    if first_link is None:
                        first_link = link.patient_euid
                    if link.role == OrderPatientRole.PROBAND:
                        proband_link = link.patient_euid
                        break
                if proband_link is not None:
                    break
            candidate_patient_euid = proband_link or first_link or candidate_patient_euid
        except Exception:
            logger.debug("Unable to resolve patient link for TRF %s", trf_euid, exc_info=True)

        if not candidate_patient_euid:
            return None
        patient_result = patient_svc.get_by_id(candidate_patient_euid, cross_tenant=cross_tenant)
        if not patient_result:
            return None
        _patient, patient_revision = patient_result
        if patient_revision.first_name and patient_revision.last_name:
            return f"{patient_revision.first_name} {patient_revision.last_name}"
        return patient_revision.first_name or patient_revision.last_name or None

    def get_recent_orders(self, limit: int = 10, cross_tenant: bool = False) -> list[RecentOrder]:
        """Get recent TRFs ordered by created timestamp."""
        rows = TrfService(self.db, self.tenant_id).list_trfs(
            limit=max(limit * 5, 50),
            cross_tenant=cross_tenant,
        )
        rows.sort(key=lambda item: item[0].created_at or datetime.min, reverse=True)

        test_svc = TestService(self.db, self.tenant_id)
        patient_svc = PatientService(self.db, self.tenant_id)

        recent: list[RecentOrder] = []
        for trf, revision in rows[:limit]:
            patient_name = self._resolve_patient_name_for_trf(
                trf_euid=trf.euid,
                trf_revision=revision,
                test_svc=test_svc,
                patient_svc=patient_svc,
                cross_tenant=cross_tenant,
            )
            recent.append(
                RecentOrder(
                    id=str(trf.euid),
                    order_number=trf.order_number,
                    patient_name=patient_name,
                    status=revision.status if revision else "UNKNOWN",
                    created_at=(
                        trf.created_at.strftime("%Y-%m-%d %H:%M") if trf.created_at else ""
                    ),
                )
            )
        return recent

    def get_pending_exceptions(
        self, limit: int = 10, cross_tenant: bool = False
    ) -> list[PendingException]:
        """Get pending exceptions (OPEN/ASSIGNED/IN_PROGRESS)."""
        rows = ExceptionService(self.db, self.tenant_id, self.user_id).list_exceptions(
            limit=max(limit * 5, 50),
            cross_tenant=cross_tenant,
        )

        pending: list[PendingException] = []
        for exception, revision in rows:
            status = self._norm_status(getattr(revision, "status", None))
            if status not in {
                ExceptionStatus.OPEN.value,
                ExceptionStatus.ASSIGNED.value,
                ExceptionStatus.IN_PROGRESS.value,
            }:
                continue
            scanned_data = getattr(revision, "scanned_data", None)
            barcode = scanned_data.get("barcode") if isinstance(scanned_data, dict) else None
            exception_type = getattr(revision, "exception_type", None) or "UNKNOWN"
            pending.append(
                PendingException(
                    id=str(exception.euid),
                    exception_number=exception.exception_number,
                    exception_type=exception_type,
                    barcode=barcode,
                    issue=exception_type.replace("_", " ").title(),
                    created_at=(
                        exception.created_at.strftime("%Y-%m-%d %H:%M")
                        if getattr(exception, "created_at", None)
                        else ""
                    ),
                )
            )
            if len(pending) >= limit:
                break

        return pending
