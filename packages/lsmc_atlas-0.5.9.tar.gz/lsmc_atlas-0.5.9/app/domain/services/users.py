"""LSMC Hub - User Management Service.

Provides operations for UserProfile management with:
- Tenant scoping
- Role assignment
- User activation/deactivation
- Admin-initiated user invitation (Cognito AdminCreateUser)
- Audit logging
"""

import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from app.auth.rbac import Role
from app.domain.enums import AuditAction

logger = logging.getLogger(__name__)


@dataclass
class UserCreate:
    """Data for creating a new user.

    When used with UserService.create(), cognito_sub must be provided.
    When used with UserService.invite(), cognito_sub is set automatically
    by the Cognito AdminCreateUser API call.
    """

    email: str
    name: str | None
    tenant_id: uuid.UUID
    roles: list[str] = field(default_factory=list)
    cognito_sub: str | None = None
    cognito_group: str | None = None


@dataclass
class UserUpdate:
    """Data for updating a user."""

    email: str | None = None
    name: str | None = None
    roles: list[str] | None = None
    is_active: bool | None = None


class UserService:
    """Service for user profile operations."""

    def __init__(self, db: Any, admin_user_id: uuid.UUID | None = None):
        """Initialize user service.

        Note: UserService is not tenant-scoped for admins who need cross-tenant access.
        Individual methods enforce appropriate scoping.
        """
        self.db = db
        self.admin_user_id = admin_user_id
        self._tapdb_repo: Any | None = None
        self._tapdb_org_repo: Any | None = None

    def _repo(self) -> Any:
        if self._tapdb_repo is None:
            from app.persistence.tapdb.users import TapdbUserRepository

            self._tapdb_repo = TapdbUserRepository(self.db)
        return self._tapdb_repo

    def _org_repo(self) -> Any:
        if self._tapdb_org_repo is None:
            from app.persistence.tapdb.orgs import TapdbOrgRepository

            self._tapdb_org_repo = TapdbOrgRepository(self.db)
        return self._tapdb_org_repo

    def _log_audit_event(
        self,
        *,
        tenant_id: uuid.UUID,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Best-effort audit logging via TapDB-backed AuditService."""
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db,
                tenant_id=tenant_id,
                user_id=str(self.admin_user_id) if self.admin_user_id else None,
            ).log(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
                user_id=self.admin_user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.warning(
                "Audit logging failed for %s %s in tenant %s",
                entity_type,
                entity_id,
                tenant_id,
                exc_info=True,
            )

    def _validate_user_data(self, data: UserCreate) -> None:
        """Shared validation for create and invite flows."""
        tenant = self._org_repo().get_org_by_uid(data.tenant_id)
        if not tenant:
            raise ValueError(f"Tenant {data.tenant_id} not found")

        existing_email = self._repo().get_user_by_email_in_tenant(
            email=data.email,
            tenant_id=data.tenant_id,
        )
        if existing_email:
            raise ValueError(f"A user with email {data.email} already exists in this organization")

        valid_roles = {r.value for r in Role}
        for role in data.roles:
            if role not in valid_roles:
                raise ValueError(f"Invalid role: {role}")

    def create(
        self,
        data: UserCreate,
    ) -> Any:
        """Create a new user profile (requires cognito_sub).

        Use this for auto-provisioning or CLI scripts where the
        cognito_sub is already known. For admin-initiated invitation
        use ``invite()`` instead.
        """
        if not data.cognito_sub:
            raise ValueError(
                "cognito_sub is required for create(). Use invite() for admin provisioning."
            )

        self._validate_user_data(data)

        existing = self._repo().get_user_by_sub(data.cognito_sub)
        if existing:
            raise ValueError(f"User with cognito_sub {data.cognito_sub} already exists")

        user = self._repo().create_user(data)
        self._log_audit_event(
            tenant_id=data.tenant_id,
            action=AuditAction.CREATE,
            entity_type="UserProfile",
            entity_id=user.euid,
            details={"email": data.email, "roles": data.roles},
        )
        return user

    def invite(self, data: UserCreate) -> Any:
        """Admin-initiated user invitation.

        1. Validate email / roles / tenant.
        2. Create the user in Cognito via AdminCreateUser.
        3. (Optional) Assign Cognito groups matching the requested roles.
        4. Persist a UserProfile with the returned cognito_sub.
        5. Log an INVITE_USER audit event.

        If the database write fails after Cognito user creation, the
        Cognito user is disabled as a rollback measure and the error
        is re-raised.

        Returns:
            The newly created UserProfile.

        Raises:
            ValueError: On validation failures (bad tenant, duplicate, etc.).
            CognitoAdminError: If the Cognito API call fails.
        """
        from app.auth.cognito_admin import (
            CognitoAdminError,
            admin_add_user_to_group,
            admin_create_user,
            admin_disable_user,
        )

        self._validate_user_data(data)

        # --- Step 1: Create user in Cognito ---
        cognito_sub = admin_create_user(email=data.email, name=data.name)

        # --- Step 2: Assign Cognito group ---
        if data.cognito_group:
            # Use the explicitly specified group
            try:
                admin_add_user_to_group(data.email, data.cognito_group)
            except CognitoAdminError:
                logger.warning(
                    "Failed to add user %s to Cognito group %s — continuing",
                    data.email,
                    data.cognito_group,
                )
        else:
            # Fallback: reverse-map from roles (legacy path)
            role_to_group = _invert_group_role_map()
            for role in data.roles:
                group = role_to_group.get(role)
                if group:
                    try:
                        admin_add_user_to_group(data.email, group)
                    except CognitoAdminError:
                        logger.warning(
                            "Failed to add user %s to Cognito group %s — continuing",
                            data.email,
                            group,
                        )

        # --- Step 3: Persist UserProfile ---
        try:
            user = self._repo().create_user(
                UserCreate(
                    email=data.email,
                    name=data.name,
                    tenant_id=data.tenant_id,
                    roles=data.roles,
                    cognito_sub=cognito_sub,
                )
            )

            self._log_audit_event(
                tenant_id=data.tenant_id,
                action=AuditAction.INVITE_USER,
                entity_type="UserProfile",
                entity_id=user.euid,
                details={"email": data.email, "roles": data.roles},
            )
            return user

        except Exception:
            # Rollback: disable the Cognito user we just created
            self.db.rollback()
            try:
                admin_disable_user(data.email)
                logger.error(
                    "DB write failed after Cognito user creation for %s — "
                    "Cognito user has been disabled as rollback.",
                    data.email,
                )
            except CognitoAdminError:
                logger.critical(
                    "DB write AND Cognito rollback both failed for %s. "
                    "Manual cleanup required in Cognito.",
                    data.email,
                )
            raise

    def get_by_id(self, user_id: str) -> Any | None:
        """Get user by EUID."""
        return self._repo().get_user_by_id(user_id)

    def get_by_cognito_sub(self, cognito_sub: str) -> Any | None:
        """Get user by Cognito subject ID."""
        return self._repo().get_user_by_sub(cognito_sub)

    def get_by_email(self, email: str) -> Any | None:
        """Get user by email across tenants."""
        return self._repo().get_user_by_email(email)

    def list_by_cognito_subs(self, cognito_subs: list[str]) -> list[Any]:
        """Get users matching the provided Cognito subject IDs."""
        if not cognito_subs:
            return []
        return self._repo().list_users_by_subs(cognito_subs)

    def list_users(
        self,
        tenant_id: uuid.UUID | None = None,
        skip: int = 0,
        limit: int = 50,
        is_active: bool | None = None,
    ) -> list[Any]:
        """List users with optional tenant filtering."""
        return self._repo().list_users(
            tenant_id=tenant_id,
            skip=skip,
            limit=limit,
            is_active=is_active,
        )

    def update(
        self,
        user_id: uuid.UUID,
        data: UserUpdate,
    ) -> Any | None:
        """Update user profile."""
        user = self.get_by_id(user_id)
        if not user:
            return None

        if data.roles is not None:
            valid_roles = {r.value for r in Role}
            for role in data.roles:
                if role not in valid_roles:
                    raise ValueError(f"Invalid role: {role}")

        user = self._repo().update_user(user_id, data)
        if user is None:
            return None

        self._log_audit_event(
            tenant_id=user.tenant_id,
            action=AuditAction.UPDATE,
            entity_type="UserProfile",
            entity_id=user.euid,
            details={
                "email": data.email,
                "roles": data.roles,
                "is_active": data.is_active,
            },
        )
        return user

    def deactivate(self, user_id: uuid.UUID) -> Any | None:
        """Deactivate a user in Atlas and disable them in Cognito.

        The Cognito disable is best-effort: if it fails, the Atlas
        deactivation still proceeds and a warning is logged.
        """
        from app.auth.cognito_admin import CognitoAdminError, admin_disable_user

        user = self.get_by_id(user_id)
        if user:
            try:
                admin_disable_user(user.email)
            except CognitoAdminError:
                logger.warning(
                    "Failed to disable Cognito user (id=%s) — "
                    "proceeding with Atlas deactivation only.",
                    str(user_id).replace("\n", "").replace("\r", ""),
                )
        return self.update(user_id, UserUpdate(is_active=False))

    def activate(self, user_id: uuid.UUID) -> Any | None:
        """Activate a user in Atlas and enable them in Cognito.

        The Cognito enable is best-effort: if it fails, the Atlas
        activation still proceeds and a warning is logged.
        """
        from app.auth.cognito_admin import CognitoAdminError, admin_enable_user

        user = self.get_by_id(user_id)
        if user:
            try:
                admin_enable_user(user.email)
            except CognitoAdminError:
                logger.warning(
                    "Failed to enable Cognito user (id=%s) — "
                    "proceeding with Atlas activation only.",
                    str(user_id).replace("\n", "").replace("\r", ""),
                )
        return self.update(user_id, UserUpdate(is_active=True))

    def update_last_login(self, user_id: str) -> None:
        """Update last login timestamp."""
        user = self.get_by_id(user_id)
        if user:
            self._repo().set_last_login(user_id, datetime.now(UTC))

    def update_preferences(self, user_id: uuid.UUID, preferences: dict[str, Any]) -> Any | None:
        """Update user preferences payload."""
        user = self.get_by_id(user_id)
        if not user:
            return None
        return self._repo().update_preferences(user_id, preferences)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _invert_group_role_map() -> dict[str, str]:
    """Build a role -> first matching Cognito group mapping.

    Uses the configured ``cognito_group_role_map`` (from settings).
    If a role appears in multiple groups, the first match wins.

    Returns:
        Dict mapping Atlas role name -> Cognito group name.
    """
    from app.settings import settings as _settings

    mapping = _settings.get_cognito_group_role_mapping()
    inverted: dict[str, str] = {}
    for group, roles in mapping.items():
        for role in roles:
            if role not in inverted:
                inverted[role] = group
    return inverted
