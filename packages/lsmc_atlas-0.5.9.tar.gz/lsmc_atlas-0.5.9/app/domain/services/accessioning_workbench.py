"""Atlas-native accessioning workbench orchestration."""

from __future__ import annotations

import copy
import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from typing import Any
from urllib.parse import quote

from app.domain.enums import (
    AccessionQueue,
    AccessionStageStatus,
    AuditAction,
    ExceptionType,
    OrderPatientRole,
)
from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest
from app.domain.services.collection_events import CollectionEventCreate, CollectionEventService
from app.domain.services.documents import DocumentPlaceholder, DocumentService, DocumentUpload
from app.domain.services.entity_links import EntityLinkService
from app.domain.services.exceptions import ExceptionCreate, ExceptionService
from app.domain.services.external_objects import ExternalObjectRelationCreate, ExternalObjectService
from app.domain.services.intake import IntakeService, MaterialIntakeOutcome, MaterialOutcomeRequest
from app.domain.services.order_relationships import OrderPatientLink, OrderRelationshipService
from app.domain.services.orgs import OrganizationService, SiteService
from app.domain.services.people import (
    ClinicianCreate,
    ClinicianService,
    PatientCreate,
    PatientService,
)
from app.domain.services.shipments import (
    ShipmentCreate,
    ShipmentService,
    TestKitCreate,
    TestKitService,
)
from app.domain.services.test_fulfillment_items import TestFulfillmentItemService
from app.domain.services.testkit_trf_links import TestKitTrfLinkService
from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService
from app.persistence.tapdb.accessioning import (
    TapdbAccessioningRepository,
    TapdbAccessionWorkItemRecord,
    TapdbAccessionWorkItemRevisionRecord,
)
from app.search.contracts import SearchQueryRequest
from app.search.service import UnifiedSearchService

logger = logging.getLogger(__name__)

MINIMAL_MAX_DEPTH = 6
MINIMAL_ROOT_NODE_PREFIX = "root::"
MINIMAL_LEGACY_NODE_PREFIX = "legacy::"


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _as_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return list(value)
    return []


def _coerce_date(value: str | None) -> date | None:
    if value is None:
        return None
    cleaned = str(value).strip()
    if not cleaned:
        return None
    return date.fromisoformat(cleaned)


def _try_parse_date(value: str | None) -> date | None:
    try:
        return _coerce_date(value)
    except ValueError:
        return None


def _append_unique(rows: list[str], value: str | None) -> list[str]:
    clean = str(value or "").strip()
    if not clean:
        return rows
    if clean not in rows:
        rows.append(clean)
    return rows


@dataclass
class ReceiptRegistrationRequest:
    tracking_number: str | None = None
    carrier: str | None = None
    received_at: datetime | None = None
    received_by: str | None = None
    origin_site_id: str | None = None
    notes: str | None = None
    package_condition: str | None = None
    hand_delivery: bool = False
    mode: str = "queue"


@dataclass
class ContentRegistrationRequest:
    content_type: str
    parent_type: str = "Shipment"
    parent_id: str | None = None
    barcode: str | None = None
    label: str | None = None
    notes: str | None = None
    kit_type: str | None = None
    tracking_number: str | None = None
    carrier: str | None = None
    origin_site_id: str | None = None
    document_euid: str | None = None
    document_filename: str | None = None
    document_content_type: str | None = None
    document_bytes: bytes | None = None
    document_type: str | None = None
    site_euid: str | None = None
    collection_site_euid: str | None = None
    defer_matching: bool = False
    label_print_requested: bool = False
    label_print_context: str | None = None
    tube_image_metadata: str | None = None
    package_image_metadata: str | None = None
    registration_token: str | None = None


@dataclass
class ProvisionalPatientInput:
    role: str
    patient_euid: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    date_of_birth: str | None = None
    mrn: str | None = None


@dataclass
class ProvisionalOrderRequest:
    site_id: str
    fulfillment_route_code: str
    specimen_type_required: str | None = None
    clinician_euid: str | None = None
    clinician_first_name: str | None = None
    clinician_last_name: str | None = None
    clinician_credentials: str | None = None
    clinical_notes: str | None = None
    patients: list[ProvisionalPatientInput] = field(default_factory=list)


@dataclass
class LinkRequest:
    trf_euid: str | None = None
    test_euid: str | None = None
    patient_euid: str | None = None
    collection_site_euid: str | None = None
    role_links: list[tuple[str, str]] = field(default_factory=list)


@dataclass
class OutcomeRequest:
    outcome: str
    patient_euid: str | None = None
    reason: str | None = None
    starting_queue: str | None = None


@dataclass
class MinimalChildRegistrationRequest:
    kind: str
    parent_node_id: str
    scan_value: str | None = None
    label: str | None = None
    notes: str | None = None
    kit_type: str | None = None
    tracking_number: str | None = None
    carrier: str | None = None
    origin_site_id: str | None = None
    document_type: str | None = None
    site_euid: str | None = None
    collection_site_euid: str | None = None
    route_code: str | None = None
    product_code: str | None = None
    specimen_type_required: str | None = None
    existing_euid: str | None = None


@dataclass
class CaptureReadyForReviewRequest:
    note: str | None = None


class AccessioningWorkbenchService:
    """High-level orchestration for the Atlas accessioning workbench."""

    def __init__(self, db, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.repo = TapdbAccessioningRepository(db)
        self.shipments = ShipmentService(db, tenant_id)
        self.testkits = TestKitService(db, tenant_id)
        self.trfs = TrfService(db, tenant_id)
        self.tests = TestService(db, tenant_id)
        self.intake = IntakeService(db, tenant_id)
        self.external_objects = ExternalObjectService(db, tenant_id)
        self.documents = DocumentService(db, tenant_id)
        self.collection_events = CollectionEventService(db, tenant_id)
        self.exceptions = ExceptionService(db, tenant_id)
        self.entity_links = EntityLinkService(db, tenant_id)
        self.order_relationships = OrderRelationshipService(db, tenant_id)
        self.testkit_trf_links = TestKitTrfLinkService(db, tenant_id)
        self.patients = PatientService(db, tenant_id)
        self.clinicians = ClinicianService(db, tenant_id)
        self.sites = SiteService(db)
        self.organizations = OrganizationService(db)
        self.fulfillment_items = TestFulfillmentItemService(db, tenant_id)
        self.bridge = ContainerSpecimenBridgeService(db, tenant_id)

    def dashboard(self, *, mode: str) -> dict[str, Any]:
        return {
            "mode": mode,
            "counts": {
                AccessionQueue.RECEIPT_PENDING.value: len(self._list_receipt_candidates(limit=500)),
                AccessionQueue.PACKAGE_PROCESSING_PENDING.value: self.repo.count_work_items(
                    tenant_id=self.tenant_id,
                    queue=AccessionQueue.PACKAGE_PROCESSING_PENDING.value,
                ),
                AccessionQueue.MATCHING_PENDING.value: self.repo.count_work_items(
                    tenant_id=self.tenant_id,
                    queue=AccessionQueue.MATCHING_PENDING.value,
                ),
                AccessionQueue.HOLD_INVESTIGATE.value: self.repo.count_work_items(
                    tenant_id=self.tenant_id,
                    queue=AccessionQueue.HOLD_INVESTIGATE.value,
                ),
            },
            "receipt_items": self._list_receipt_candidates(limit=10),
            "package_items": self.list_queue(
                AccessionQueue.PACKAGE_PROCESSING_PENDING.value, limit=10
            ),
            "matching_items": self.list_queue(AccessionQueue.MATCHING_PENDING.value, limit=10),
            "hold_items": self.list_queue(AccessionQueue.HOLD_INVESTIGATE.value, limit=10),
        }

    def list_queue(self, queue: str, *, limit: int = 50) -> list[dict[str, Any]]:
        if queue == AccessionQueue.RECEIPT_PENDING.value:
            return self._list_receipt_candidates(limit=limit)
        rows = self.repo.list_work_items(
            tenant_id=self.tenant_id,
            queue=queue,
            limit=limit,
            offset=0,
        )
        return [self._queue_row(item, revision) for item, revision in rows]

    def get_work_item(self, work_item_id: str) -> dict[str, Any]:
        resolved = self.repo.get_work_item(work_item_id=work_item_id, tenant_id=self.tenant_id)
        if resolved is None:
            raise ValueError(f"Accession work item not found: {work_item_id}")
        item, revision = resolved
        shipment_result = self.shipments.get(item.shipment_euid, cross_tenant=False)
        shipment, shipment_revision = (
            shipment_result if shipment_result is not None else (None, None)
        )
        tree = self.shipments.get_container_tree(
            container_type="Shipment",
            container_id=item.shipment_euid,
        )
        matching_state = copy.deepcopy(revision.matching_state or {})
        linked_test = None
        linked_trf = None
        if matching_state.get("test_euid"):
            linked_test = self.tests.get_with_revision(
                matching_state["test_euid"], cross_tenant=False
            )
        if matching_state.get("trf_euid"):
            linked_trf = self.trfs.get_by_id(matching_state["trf_euid"], cross_tenant=False)
        return {
            "item": item,
            "revision": revision,
            "shipment": shipment,
            "shipment_revision": shipment_revision,
            "tree": tree,
            "manifest_items": _as_list((revision.package_manifest or {}).get("items")),
            "matching_state": matching_state,
            "outcome_summary": copy.deepcopy(revision.outcome_summary or {}),
            "linked_test": linked_test,
            "linked_trf": linked_trf,
        }

    def get_minimal_editor(self, work_item_id: str) -> dict[str, Any]:
        detail = self.get_work_item(work_item_id)
        item = detail["item"]
        revision = detail["revision"]
        shipment = detail["shipment"]
        manifest = copy.deepcopy(revision.package_manifest or {})
        root_tree = detail["tree"] or {
            "type": "Shipment",
            "id": item.shipment_euid,
            "label": shipment.shipment_number if shipment is not None else item.shipment_euid,
            "children": [],
        }
        minimal_nodes = self._minimal_manifest_nodes(manifest)
        root_node = self._decorate_minimal_tree(
            node=root_tree,
            manifest_nodes=minimal_nodes,
            work_item=item,
            depth=0,
        )
        root_node = self._inject_logical_trf_nodes(root_node, minimal_nodes)
        counts = {
            "packages": 0,
            "kits": 0,
            "trfs": 0,
            "tests": 0,
            "paperwork": 0,
            "tubes": 0,
        }
        for node in self._flatten_tree(root_node):
            kind = str(node.get("kind") or "")
            if kind == "Package":
                counts["packages"] += 1
            elif kind == "Kit":
                counts["kits"] += 1
            elif kind == "TRF":
                counts["trfs"] += 1
            elif kind == "Test":
                counts["tests"] += 1
            elif kind == "Paperwork":
                counts["paperwork"] += 1
            elif kind == "Tube":
                counts["tubes"] += 1
        return {
            **detail,
            "root_node": root_node,
            "minimal_nodes": minimal_nodes,
            "captured_counts": counts,
            "default_site_euid": self._default_site_euid(detail),
        }

    def register_minimal_child(
        self,
        work_item_id: str,
        request: MinimalChildRegistrationRequest,
        *,
        actor_id: uuid.UUID | None,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        item, revision = self._require_work_item(work_item_id)
        editor = self.get_minimal_editor(work_item_id)
        parent_node = self._find_tree_node_by_id(editor["root_node"], request.parent_node_id)
        if parent_node is None:
            raise ValueError(f"Parent node not found: {request.parent_node_id}")
        parent_entity_type = str(parent_node["entity_type"])
        parent_entity_id = str(parent_node["entity_id"])
        parent_depth = int(parent_node.get("depth") or 0)
        if parent_depth + 1 > MINIMAL_MAX_DEPTH:
            raise ValueError(
                f"Minimal accessioning supports up to {MINIMAL_MAX_DEPTH} nested levels"
            )

        child_kind = self._normalize_minimal_kind(request.kind)
        if (
            child_kind == "TRF"
            and str(request.route_code or "").strip()
            and parent_depth + 2 > MINIMAL_MAX_DEPTH
        ):
            raise ValueError(
                f"Minimal accessioning supports up to {MINIMAL_MAX_DEPTH} nested levels"
            )
        self._validate_minimal_parent_child(parent_entity_type, child_kind)
        resolved = self._resolve_or_create_minimal_entity(
            work_item=item,
            parent_node=parent_node,
            request=request,
            actor_id=actor_id,
            default_site_euid=editor.get("default_site_euid"),
        )

        manifest = copy.deepcopy(revision.package_manifest or {})
        manifest.setdefault("items", [])
        minimal_nodes = self._minimal_manifest_nodes(manifest)
        existing_node = self._find_minimal_node_by_entity(
            minimal_nodes,
            entity_type=resolved["entity_type"],
            entity_id=resolved["entity_id"],
        )
        if existing_node is not None:
            return revision

        storage_parent_type, storage_parent_id = self._minimal_storage_parent(
            parent_node=parent_node,
            child_kind=child_kind,
        )
        child_test_parent_type, child_test_parent_id = self._minimal_storage_parent(
            parent_node=parent_node,
            child_kind="Test",
        )

        if storage_parent_type is not None and storage_parent_id is not None:
            self.shipments.add_container_item(
                container_type=storage_parent_type,
                container_id=storage_parent_id,
                item_type=resolved["entity_type"],
                item_id=resolved["entity_id"],
                reason="Minimal accessioning capture",
                created_by=actor_id,
            )

        matching_state = copy.deepcopy(revision.matching_state or {})
        matching_state.setdefault("shipment_euid", item.shipment_euid)
        matching_state.setdefault("testkit_euids", [])
        matching_state.setdefault("document_euids", [])
        matching_state.setdefault("external_object_ids", [])
        matching_state.setdefault("captured_trf_euids", [])
        matching_state.setdefault(
            "captured_test_euids", list(matching_state.get("test_euids") or [])
        )
        matching_state.setdefault("test_euids", list(matching_state.get("test_euids") or []))

        node_record = {
            "node_id": f"min:{uuid.uuid4()}",
            "kind": resolved["kind"],
            "entity_type": resolved["entity_type"],
            "entity_id": resolved["entity_id"],
            "parent_type": parent_entity_type,
            "parent_id": parent_entity_id,
            "depth": parent_depth + 1,
            "label": resolved["label"],
            "resolution_source": resolved["resolution_source"],
            "notes": request.notes,
            "added_at": _now_iso(),
        }
        manifest.setdefault("minimal_nodes", []).append(node_record)
        manifest["items"].append(dict(node_record))
        for child_test in resolved.get("captured_test_nodes", []):
            if parent_depth + 2 > MINIMAL_MAX_DEPTH:
                break
            if (
                self._find_minimal_node_by_entity(
                    self._minimal_manifest_nodes(manifest),
                    entity_type="Test",
                    entity_id=str(child_test["entity_id"]),
                )
                is not None
            ):
                continue
            if child_test_parent_type is not None and child_test_parent_id is not None:
                self.shipments.add_container_item(
                    container_type=child_test_parent_type,
                    container_id=child_test_parent_id,
                    item_type="Test",
                    item_id=str(child_test["entity_id"]),
                    reason="Minimal accessioning capture",
                    created_by=actor_id,
                )
            child_record = {
                "node_id": f"min:{uuid.uuid4()}",
                "kind": "Test",
                "entity_type": "Test",
                "entity_id": str(child_test["entity_id"]),
                "parent_type": "TRF",
                "parent_id": resolved["entity_id"],
                "depth": parent_depth + 2,
                "label": str(child_test["label"]),
                "resolution_source": str(child_test["resolution_source"]),
                "notes": request.notes,
                "added_at": _now_iso(),
            }
            manifest["minimal_nodes"].append(child_record)
            manifest["items"].append(dict(child_record))

        self._record_minimal_matching_state(
            matching_state=matching_state,
            resolved=resolved,
        )
        self._apply_minimal_business_links(
            work_item=item,
            manifest=manifest,
            node_record=node_record,
            resolved=resolved,
            actor_id=actor_id,
        )
        self._apply_auto_primary_matching(matching_state)

        updated = self._create_revision(
            work_item_id,
            actor_id=actor_id,
            queue=revision.queue,
            stage_status=self._minimal_stage_status(matching_state),
            package_manifest=manifest,
            matching_state=matching_state,
            note=request.notes or f"captured {resolved['kind']}",
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.UPDATE,
            actor_id=actor_id,
            details={
                "stage": "minimal_capture",
                "node_id": node_record["node_id"],
                "kind": node_record["kind"],
                "entity_type": node_record["entity_type"],
                "entity_id": node_record["entity_id"],
                "parent_type": node_record["parent_type"],
                "parent_id": node_record["parent_id"],
                "resolution_source": node_record["resolution_source"],
            },
        )
        return updated

    def mark_capture_ready_for_review(
        self,
        work_item_id: str,
        request: CaptureReadyForReviewRequest,
        *,
        actor_id: uuid.UUID | None,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        item, revision = self._require_work_item(work_item_id)
        matching_state = copy.deepcopy(revision.matching_state or {})
        matching_state.setdefault("testkit_euids", [])
        matching_state.setdefault("document_euids", [])
        matching_state.setdefault("external_object_ids", [])
        matching_state.setdefault("captured_trf_euids", [])
        matching_state.setdefault(
            "captured_test_euids", list(matching_state.get("test_euids") or [])
        )
        matching_state.setdefault("test_euids", list(matching_state.get("test_euids") or []))
        self._apply_auto_primary_matching(matching_state)
        updated = self._create_revision(
            work_item_id,
            actor_id=actor_id,
            queue=AccessionQueue.MATCHING_PENDING.value,
            stage_status=self._minimal_stage_status(matching_state),
            matching_state=matching_state,
            note=request.note or "capture ready for review",
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.STATUS_CHANGE,
            actor_id=actor_id,
            details={
                "stage": "minimal_capture",
                "queue": AccessionQueue.MATCHING_PENDING.value,
                "stage_status": updated.stage_status,
            },
        )
        return updated

    def register_receipt(
        self,
        request: ReceiptRegistrationRequest,
        *,
        actor_id: uuid.UUID | None,
    ) -> tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord]:
        shipment_result = None
        tracking_number = str(request.tracking_number or "").strip() or None
        carrier = (
            "HAND_DELIVERY"
            if request.hand_delivery
            else (str(request.carrier or "").strip() or None)
        )

        if tracking_number is not None:
            shipment = self.shipments.get_by_tracking_number(tracking_number, cross_tenant=False)
            if shipment is not None:
                shipment_result = self.shipments.get(shipment.euid, cross_tenant=False)
        elif carrier == "HAND_DELIVERY":
            existing_hand_delivery = self._find_existing_hand_delivery_work_item(request)
            if existing_hand_delivery is not None:
                shipment_result = self.shipments.get(
                    existing_hand_delivery[0].shipment_euid,
                    cross_tenant=False,
                )

        if shipment_result is None:
            origin_address = self._origin_address_for_site(request.origin_site_id)
            shipment_result = self.shipments.create(
                ShipmentCreate(
                    carrier=carrier,
                    tracking_number=tracking_number,
                    origin_site_id=request.origin_site_id,
                    origin_address=origin_address,
                    special_instructions=request.notes,
                ),
                created_by=actor_id,
            )
        shipment, shipment_revision = shipment_result
        self.intake.receive_shipment(
            shipment.euid,
            created_by=actor_id,
            cross_tenant=False,
            received_by=request.received_by,
            package_condition=request.package_condition,
            note=request.notes,
        )

        work_item = self.repo.get_work_item_by_shipment(
            shipment_euid=shipment.euid,
            tenant_id=self.tenant_id,
        )
        existing_received_at = None
        if work_item is not None and request.received_at is None:
            existing_received_at = (work_item[1].receipt_metadata or {}).get("received_at")
        receipt_metadata = {
            "tracking_number": tracking_number,
            "carrier": carrier or shipment_revision.carrier,
            "received_at": existing_received_at
            or (request.received_at or datetime.now(UTC)).isoformat(),
            "received_by": request.received_by,
            "origin_site_id": request.origin_site_id or shipment_revision.origin_site_id,
            "notes": request.notes,
            "package_condition": request.package_condition,
            "shipment_number": shipment.shipment_number,
        }
        if work_item is None:
            created = self.repo.create_work_item(
                tenant_id=self.tenant_id,
                shipment_euid=shipment.euid,
                queue=AccessionQueue.PACKAGE_PROCESSING_PENDING.value,
                mode=request.mode,
                stage_status=AccessionStageStatus.REGISTERED_UNMATCHED.value,
                receipt_metadata=receipt_metadata,
                package_manifest={"items": []},
                matching_state={
                    "shipment_euid": shipment.euid,
                    "testkit_euids": [],
                    "document_euids": [],
                    "external_object_ids": [],
                    "captured_trf_euids": [],
                    "captured_test_euids": [],
                    "test_euids": [],
                },
                outcome_summary={},
                idempotency_keys={
                    "receipt": self._receipt_idempotency_key(
                        shipment.euid, tracking_number, carrier
                    )
                },
                created_by=actor_id,
                note=request.notes,
            )
            self.db.commit()
            self._log_work_item_audit(
                work_item_id=created[0].euid,
                action=AuditAction.CREATE,
                actor_id=actor_id,
                details={
                    "stage": "receipt",
                    "shipment_euid": shipment.euid,
                    "queue": AccessionQueue.PACKAGE_PROCESSING_PENDING.value,
                    "receipt_metadata": receipt_metadata,
                },
            )
            return created

        item, revision = work_item
        if (
            revision.queue == AccessionQueue.PACKAGE_PROCESSING_PENDING.value
            and revision.receipt_metadata == receipt_metadata
        ):
            return item, revision

        updated = self._create_revision(
            item.euid,
            actor_id=actor_id,
            queue=AccessionQueue.PACKAGE_PROCESSING_PENDING.value,
            mode=request.mode,
            stage_status=revision.stage_status or AccessionStageStatus.REGISTERED_UNMATCHED.value,
            receipt_metadata=receipt_metadata,
            note=request.notes,
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.UPDATE,
            actor_id=actor_id,
            details={
                "stage": "receipt",
                "shipment_euid": shipment.euid,
                "queue": AccessionQueue.PACKAGE_PROCESSING_PENDING.value,
                "receipt_metadata": receipt_metadata,
            },
        )
        return item, updated

    def register_content(
        self,
        work_item_id: str,
        request: ContentRegistrationRequest,
        *,
        actor_id: uuid.UUID | None,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        item, revision = self._require_work_item(work_item_id)
        manifest = copy.deepcopy(revision.package_manifest or {})
        manifest.setdefault("items", [])
        idempotency_keys = copy.deepcopy(revision.idempotency_keys or {})
        matching_state = copy.deepcopy(revision.matching_state or {})
        matching_state.setdefault("shipment_euid", item.shipment_euid)
        matching_state.setdefault("testkit_euids", [])
        matching_state.setdefault("document_euids", [])
        matching_state.setdefault("external_object_ids", [])

        parent_type = request.parent_type or "Shipment"
        parent_id = request.parent_id or item.shipment_euid
        registration_fingerprint = self._content_fingerprint(
            item=item,
            request=request,
            parent_type=parent_type,
            parent_id=parent_id,
        )
        duplicate_item = self._find_manifest_item_by_fingerprint(
            manifest_items=manifest["items"],
            fingerprint=registration_fingerprint,
        )
        if duplicate_item is not None:
            if request.defer_matching and revision.queue != AccessionQueue.MATCHING_PENDING.value:
                updated = self._create_revision(
                    work_item_id,
                    actor_id=actor_id,
                    queue=AccessionQueue.MATCHING_PENDING.value,
                    stage_status=revision.stage_status
                    or AccessionStageStatus.REGISTERED_UNMATCHED.value,
                    idempotency_keys=idempotency_keys,
                    note=f"reused existing {request.content_type} registration and routed to matching",
                )
                self.db.commit()
                self._log_work_item_audit(
                    work_item_id=item.euid,
                    action=AuditAction.UPDATE,
                    actor_id=actor_id,
                    details={
                        "stage": "package_processing",
                        "content_type": request.content_type,
                        "registration_fingerprint": registration_fingerprint,
                        "idempotent_replay": True,
                        "queue": AccessionQueue.MATCHING_PENDING.value,
                    },
                )
                return updated
            return revision
        manifest_item: dict[str, Any]

        if request.content_type == "ChildShipment":
            origin_address = self._origin_address_for_site(request.origin_site_id)
            child_shipment, _child_revision = self.shipments.create(
                ShipmentCreate(
                    carrier=request.carrier,
                    tracking_number=request.tracking_number,
                    origin_site_id=request.origin_site_id,
                    origin_address=origin_address,
                    special_instructions=request.notes,
                ),
                created_by=actor_id,
            )
            self.shipments.add_container_item(
                container_type=parent_type,
                container_id=parent_id,
                item_type="Shipment",
                item_id=child_shipment.euid,
                reason="Accessioning package processing",
                created_by=actor_id,
            )
            manifest_item = {
                "kind": "ChildShipment",
                "entity_type": "Shipment",
                "entity_id": child_shipment.euid,
                "label": child_shipment.shipment_number,
                "parent_type": parent_type,
                "parent_id": parent_id,
                "notes": request.notes,
            }
        elif request.content_type == "Kit":
            barcode = str(request.barcode or "").strip()
            if not barcode:
                raise ValueError("kit barcode is required")
            test_kit, _created = self.testkits.get_or_create_by_barcode(
                kit_barcode=barcode,
                kit_type=request.kit_type,
                origin_site_id=request.origin_site_id,
                created_by=actor_id,
            )
            if parent_type == "TestKit":
                self.testkits.add_item(
                    parent_id,
                    "TestKit",
                    test_kit.euid,
                    reason="Nested kit added during accessioning",
                    created_by=actor_id,
                )
            else:
                self.shipments.add_container_item(
                    container_type=parent_type,
                    container_id=parent_id,
                    item_type="TestKit",
                    item_id=test_kit.euid,
                    reason="Kit added during accessioning",
                    created_by=actor_id,
                )
            _append_unique(matching_state["testkit_euids"], test_kit.euid)
            manifest_item = {
                "kind": "Kit",
                "entity_type": "TestKit",
                "entity_id": test_kit.euid,
                "label": test_kit.display_label,
                "parent_type": parent_type,
                "parent_id": parent_id,
                "notes": request.notes,
            }
        elif request.content_type == "Document":
            document_euid = request.document_euid
            if (
                document_euid is None
                and request.document_bytes is not None
                and request.document_filename
            ):
                upload = self.documents.upload(
                    DocumentUpload(
                        filename=request.document_filename,
                        content=request.document_bytes,
                        content_type=request.document_content_type,
                        document_type=request.document_type,
                        note=request.notes,
                    ),
                    created_by=actor_id,
                )
                document_euid = upload.document_euid
            if not document_euid:
                raise ValueError("document upload or document_euid is required")
            self.documents.link_to_entity(
                document_euid,
                "Shipment",
                item.shipment_euid,
                created_by=actor_id,
            )
            self.shipments.add_container_item(
                container_type=parent_type,
                container_id=parent_id,
                item_type="Document",
                item_id=document_euid,
                reason="Document registered during accessioning",
                created_by=actor_id,
            )
            _append_unique(matching_state["document_euids"], document_euid)
            manifest_item = {
                "kind": "Document",
                "entity_type": "Document",
                "entity_id": document_euid,
                "label": request.document_filename or document_euid,
                "parent_type": parent_type,
                "parent_id": parent_id,
                "notes": request.notes,
            }
        elif request.content_type == "Tube":
            external_object_id, label = self._register_tube_content(
                work_item=item,
                parent_type=parent_type,
                parent_id=parent_id,
                request=request,
                registration_fingerprint=registration_fingerprint,
                actor_id=actor_id,
            )
            _append_unique(matching_state["external_object_ids"], external_object_id)
            manifest_item = {
                "kind": "Tube",
                "entity_type": "ExternalObject",
                "entity_id": external_object_id,
                "label": label,
                "parent_type": parent_type,
                "parent_id": parent_id,
                "notes": request.notes,
            }
        elif request.content_type == "Misc":
            manifest_item = {
                "kind": "Misc",
                "entity_type": "Misc",
                "entity_id": f"misc:{uuid.uuid4()}",
                "label": request.label or "Miscellaneous paperwork",
                "parent_type": parent_type,
                "parent_id": parent_id,
                "notes": request.notes,
            }
        else:
            raise ValueError(f"Unsupported content_type: {request.content_type}")

        if registration_fingerprint:
            manifest_item["registration_fingerprint"] = registration_fingerprint
            content_fingerprints = list(idempotency_keys.get("content_fingerprints") or [])
            _append_unique(content_fingerprints, registration_fingerprint)
            idempotency_keys["content_fingerprints"] = content_fingerprints
        if request.label_print_requested:
            manifest_item["label_print_requested"] = True
        if request.label_print_context:
            manifest_item["label_print_context"] = request.label_print_context
        if request.tube_image_metadata:
            manifest_item["tube_image_metadata"] = request.tube_image_metadata
        if request.package_image_metadata:
            manifest_item["package_image_metadata"] = request.package_image_metadata
        manifest_item["added_at"] = _now_iso()
        manifest["items"].append(manifest_item)
        new_queue = (
            AccessionQueue.MATCHING_PENDING.value if request.defer_matching else revision.queue
        )
        updated = self._create_revision(
            work_item_id,
            actor_id=actor_id,
            queue=new_queue,
            stage_status=revision.stage_status or AccessionStageStatus.REGISTERED_UNMATCHED.value,
            package_manifest=manifest,
            matching_state=matching_state,
            idempotency_keys=idempotency_keys,
            note=request.notes or f"registered {request.content_type}",
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.UPDATE,
            actor_id=actor_id,
            details={
                "stage": "package_processing",
                "content_type": request.content_type,
                "content_entity_type": manifest_item["entity_type"],
                "content_entity_id": manifest_item["entity_id"],
                "queue": new_queue,
                "registration_fingerprint": registration_fingerprint,
                "label_print_requested": bool(request.label_print_requested),
                "label_print_context": request.label_print_context,
                "tube_image_metadata": request.tube_image_metadata,
                "package_image_metadata": request.package_image_metadata,
            },
        )
        return updated

    def search_matches(self, query: str) -> dict[str, Any]:
        clean = str(query or "").strip()
        if not clean:
            return {
                "query": "",
                "tests": [],
                "trfs": [],
                "patients": [],
                "shipments": [],
                "testkits": [],
                "external_objects": [],
                "search_items": [],
            }

        tests: list[dict[str, Any]] = []
        trfs: list[dict[str, Any]] = []
        patients: list[dict[str, Any]] = []
        shipments: list[dict[str, Any]] = []
        testkits: list[dict[str, Any]] = []
        external_objects: list[dict[str, Any]] = []
        parsed_dob = _try_parse_date(clean)

        trf_result = self.trfs.get_by_id(clean, cross_tenant=False) or self.trfs.get_by_number(
            clean, cross_tenant=False
        )
        if trf_result is not None:
            trf, revision = trf_result
            trfs.append({"euid": trf.euid, "number": trf.order_number, "status": revision.status})

        test_result = self.tests.get_with_revision(clean, cross_tenant=False)
        if test_result is not None:
            test, revision = test_result
            tests.append(
                {
                    "euid": test.euid,
                    "trf_euid": test.order_id,
                    "product_code": revision.product_code,
                    "status": revision.status,
                }
            )

        shipment_result = self.shipments.get_by_shipment_number(clean, cross_tenant=False)
        if shipment_result is not None:
            shipment, revision = shipment_result
            shipments.append(
                {
                    "euid": shipment.euid,
                    "number": shipment.shipment_number,
                    "status": revision.status,
                }
            )
        tracking_result = self.shipments.get_by_tracking_number(clean, cross_tenant=False)
        if tracking_result is not None and all(
            row["euid"] != tracking_result.euid for row in shipments
        ):
            tracked = self.shipments.get(tracking_result.euid, cross_tenant=False)
            if tracked is not None:
                shipment, revision = tracked
                shipments.append(
                    {
                        "euid": shipment.euid,
                        "number": shipment.shipment_number,
                        "status": revision.status,
                    }
                )

        test_kit = self.testkits.get_by_barcode(clean, cross_tenant=False)
        if test_kit is None:
            test_kit = self.testkits.get_by_id(clean, cross_tenant=False)
        if test_kit is not None:
            testkits.append(
                {
                    "euid": test_kit.euid,
                    "barcode": test_kit.kit_barcode,
                    "display_label": test_kit.display_label,
                }
            )

        patient = self.patients.get_by_mrn(clean, cross_tenant=False)
        if patient is not None:
            patient_obj, patient_rev = patient
            patients.append(
                {
                    "euid": patient_obj.euid,
                    "name": f"{patient_rev.first_name} {patient_rev.last_name}".strip(),
                    "mrn": patient_rev.mrn,
                    "date_of_birth": patient_rev.date_of_birth.isoformat()
                    if patient_rev.date_of_birth
                    else None,
                }
            )
        for patient_obj, patient_rev in self.patients.search_by_name(
            clean, limit=10, cross_tenant=False
        ):
            if any(row["euid"] == patient_obj.euid for row in patients):
                continue
            patients.append(
                {
                    "euid": patient_obj.euid,
                    "name": f"{patient_rev.first_name} {patient_rev.last_name}".strip(),
                    "mrn": patient_rev.mrn,
                    "date_of_birth": patient_rev.date_of_birth.isoformat()
                    if patient_rev.date_of_birth
                    else None,
                }
            )
        if parsed_dob is not None:
            for patient_obj, patient_rev in self.patients.list_patients(
                limit=250, cross_tenant=False
            ):
                if patient_rev.date_of_birth != parsed_dob:
                    continue
                if any(row["euid"] == patient_obj.euid for row in patients):
                    continue
                patients.append(
                    {
                        "euid": patient_obj.euid,
                        "name": f"{patient_rev.first_name} {patient_rev.last_name}".strip(),
                        "mrn": patient_rev.mrn,
                        "date_of_birth": patient_rev.date_of_birth.isoformat(),
                    }
                )

        scan_result = self.intake.scan_barcode(clean, cross_tenant=False)
        if scan_result.found and scan_result.entity_type in {"BloomContainer", "BloomSpecimen"}:
            object_type = "container" if scan_result.entity_type == "BloomContainer" else "specimen"
            ext = self.external_objects.get_external_object("bloom", object_type, clean)
            if ext is not None:
                external_objects.append(
                    {
                        "euid": ext.euid,
                        "external_euid": ext.external_euid,
                        "object_type": ext.object_type,
                        "status": ext.status,
                    }
                )

        search_items = (
            UnifiedSearchService(
                self.db,
                self.tenant_id,
                cross_tenant=False,
            )
            .query(SearchQueryRequest(q=clean, page=1, page_size=10))
            .items
        )

        return {
            "query": clean,
            "tests": tests,
            "trfs": trfs,
            "patients": patients,
            "shipments": shipments,
            "testkits": testkits,
            "external_objects": external_objects,
            "search_items": search_items,
        }

    def link_work_item(
        self,
        work_item_id: str,
        request: LinkRequest,
        *,
        actor_id: uuid.UUID | None,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        item, revision = self._require_work_item(work_item_id)
        matching_state = copy.deepcopy(revision.matching_state or {})
        matching_state.setdefault("testkit_euids", [])
        matching_state.setdefault("document_euids", [])
        matching_state.setdefault("external_object_ids", [])

        test_euid = str(request.test_euid or "").strip() or None
        trf_euid = str(request.trf_euid or "").strip() or None
        if test_euid is not None:
            test = self.tests.get_by_id(test_euid, cross_tenant=False)
            if test is None:
                raise ValueError(f"Test not found: {test_euid}")
            if trf_euid is None:
                trf_euid = test.order_id
        if trf_euid is None:
            raise ValueError("trf_euid or test_euid is required")

        trf_result = self.trfs.get_by_id(trf_euid, cross_tenant=False)
        if trf_result is None:
            raise ValueError(f"TRF not found: {trf_euid}")
        _trf, _trf_revision = trf_result
        matched_test_ids: list[str] = []
        if test_euid is not None:
            matched_test_ids.append(test_euid)
        else:
            for matched_test, _test_revision, _routes in self.tests.list_for_trf(
                trf_euid, cross_tenant=False
            ):
                _append_unique(matched_test_ids, matched_test.euid)

        shipment_links_changed = False
        for matched_test_id in matched_test_ids:
            shipment_links_changed = (
                self.entity_links.link(
                    source_type="Shipment",
                    source_id=item.shipment_euid,
                    target_type="Test",
                    target_id=matched_test_id,
                    created_by=actor_id,
                )
                or shipment_links_changed
            )

        kit_ids = self._all_entity_ids_from_tree(
            self.shipments.get_container_tree(
                container_type="Shipment", container_id=item.shipment_euid
            ),
            entity_type="TestKit",
        )
        for kit_id in kit_ids:
            for matched_test_id in matched_test_ids:
                self.entity_links.link(
                    source_type="TestKit",
                    source_id=kit_id,
                    target_type="Test",
                    target_id=matched_test_id,
                    created_by=actor_id,
                )

        for document_euid in _as_list((revision.package_manifest or {}).get("items")):
            if document_euid.get("entity_type") != "Document":
                continue
            entity_id = str(document_euid.get("entity_id") or "")
            for matched_test_id in matched_test_ids:
                self.documents.link_to_entity(
                    entity_id, "Test", matched_test_id, created_by=actor_id
                )

        collection_event_ids: list[str] = _as_list(matching_state.get("collection_event_euids"))
        for external_object_id in matching_state.get("external_object_ids", []):
            if test_euid is not None:
                self.external_objects.create_relation(
                    ExternalObjectRelationCreate(
                        external_object_id=external_object_id,
                        relation_type="belongs_to_test",
                        local_entity_type="Test",
                        local_entity_id=test_euid,
                        metadata={},
                    ),
                    actor_id=actor_id,
                )
            self.external_objects.create_relation(
                ExternalObjectRelationCreate(
                    external_object_id=external_object_id,
                    relation_type="belongs_to_shipment",
                    local_entity_type="Shipment",
                    local_entity_id=item.shipment_euid,
                    metadata={},
                ),
                actor_id=actor_id,
            )
            if request.patient_euid and request.collection_site_euid:
                collection_event_id = self._ensure_collection_event(
                    external_object_id=external_object_id,
                    patient_euid=request.patient_euid,
                    collection_site_euid=request.collection_site_euid,
                    actor_id=actor_id,
                )
                _append_unique(collection_event_ids, collection_event_id)

        if test_euid is not None and request.role_links:
            links = [
                OrderPatientLink(patient_euid=patient_euid, role=OrderPatientRole(role))
                for patient_euid, role in request.role_links
                if patient_euid and role
            ]
            if links:
                self.order_relationships.ensure_order_patient_links(
                    order_euid=test_euid,
                    links=links,
                    replace=False,
                )

        matching_state["trf_euid"] = trf_euid
        if test_euid is not None:
            matching_state["test_euid"] = test_euid
            matching_state["test_euids"] = [test_euid]
        if request.patient_euid:
            matching_state["patient_euid"] = request.patient_euid
        if collection_event_ids:
            matching_state["collection_event_euids"] = collection_event_ids
        matching_state["shipment_linked"] = shipment_links_changed

        updated = self._create_revision(
            work_item_id,
            actor_id=actor_id,
            queue=AccessionQueue.MATCHING_PENDING.value,
            stage_status=AccessionStageStatus.REGISTERED_MATCHED.value,
            matching_state=matching_state,
            note="matching/linking updated",
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.LINK,
            actor_id=actor_id,
            details={
                "stage": "matching",
                "trf_euid": trf_euid,
                "test_euid": test_euid,
                "patient_euid": request.patient_euid,
                "collection_site_euid": request.collection_site_euid,
                "role_links": request.role_links,
                "collection_event_euids": collection_event_ids,
            },
        )
        return updated

    def create_provisional_order(
        self,
        work_item_id: str,
        request: ProvisionalOrderRequest,
        *,
        actor_id: uuid.UUID | None,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        item, revision = self._require_work_item(work_item_id)
        if not str(request.site_id or "").strip():
            return self._move_to_hold(
                work_item_id,
                actor_id=actor_id,
                reason="Site is required before creating a provisional order",
                exception_type=ExceptionType.RECEIVED_NO_ORDER,
            )
        if not str(request.fulfillment_route_code or "").strip():
            return self._move_to_hold(
                work_item_id,
                actor_id=actor_id,
                reason="Test route is required before creating a provisional order",
                exception_type=ExceptionType.RECEIVED_NO_ORDER,
            )
        if not request.patients:
            return self._move_to_hold(
                work_item_id,
                actor_id=actor_id,
                reason="At least one patient is required before creating a provisional order",
                exception_type=ExceptionType.RECEIVED_NO_ORDER,
            )

        patient_links: list[OrderPatientLink] = []
        created_patient_ids: list[str] = []
        try:
            for patient_input in request.patients:
                role = OrderPatientRole(
                    str(patient_input.role or OrderPatientRole.PROBAND.value).upper()
                )
                patient_euid = str(patient_input.patient_euid or "").strip() or None
                if patient_euid is None:
                    if not patient_input.first_name or not patient_input.last_name:
                        return self._move_to_hold(
                            work_item_id,
                            actor_id=actor_id,
                            reason=(
                                f"{role.value} requires an existing patient or first/last name "
                                "to create a provisional order"
                            ),
                            exception_type=ExceptionType.RECEIVED_NO_ORDER,
                        )
                    patient, _patient_rev = self.patients.create(
                        PatientCreate(
                            first_name=patient_input.first_name,
                            last_name=patient_input.last_name,
                            date_of_birth=_coerce_date(patient_input.date_of_birth),
                            mrn=patient_input.mrn,
                            site_id=request.site_id,
                        ),
                        created_by=actor_id,
                    )
                    patient_euid = patient.euid
                patient_links.append(OrderPatientLink(patient_euid=patient_euid, role=role))
                created_patient_ids.append(patient_euid)
            if not patient_links:
                return self._move_to_hold(
                    work_item_id,
                    actor_id=actor_id,
                    reason="At least one patient is required before creating a provisional order",
                    exception_type=ExceptionType.RECEIVED_NO_ORDER,
                )

            clinician_euid = str(request.clinician_euid or "").strip() or None
            if (
                clinician_euid is None
                and request.clinician_first_name
                and request.clinician_last_name
            ):
                clinician, _clinician_rev = self.clinicians.create(
                    ClinicianCreate(
                        first_name=request.clinician_first_name,
                        last_name=request.clinician_last_name,
                        credentials=request.clinician_credentials,
                        site_id=request.site_id,
                    ),
                    created_by=actor_id,
                )
                clinician_euid = clinician.euid

            trf, _trf_revision = self.trfs.create(
                TrfCreate(
                    clinician_id=clinician_euid,
                    clinical_notes=request.clinical_notes,
                    site_id=request.site_id,
                    created_during_accessioning=True,
                    accession_work_item_id=work_item_id,
                ),
                tests=[
                    TestCreate(
                        product_code=request.fulfillment_route_code,
                        fulfillment_route_codes=[request.fulfillment_route_code],
                        specimen_type_required=request.specimen_type_required,
                        clinical_notes=request.clinical_notes,
                        site_id=request.site_id,
                        created_during_accessioning=True,
                        accession_work_item_id=work_item_id,
                    )
                ],
                patient_links=patient_links,
                created_by=actor_id,
            )
        except ValueError as exc:
            return self._move_to_hold(
                work_item_id,
                actor_id=actor_id,
                reason=str(exc),
                exception_type=ExceptionType.RECEIVED_NO_ORDER,
            )
        test_rows = self.tests.list_for_trf(trf.euid, cross_tenant=False)
        if not test_rows:
            return self._move_to_hold(
                work_item_id,
                actor_id=actor_id,
                reason="Provisional TRF was created but no Test could be resolved",
                exception_type=ExceptionType.RECEIVED_NO_ORDER,
            )
        test, _test_revision, _routes = test_rows[0]

        updated = self.link_work_item(
            work_item_id,
            LinkRequest(
                trf_euid=trf.euid,
                test_euid=test.euid,
                patient_euid=created_patient_ids[0],
                role_links=[(link.patient_euid, link.role.value) for link in patient_links],
            ),
            actor_id=actor_id,
        )
        matching_state = copy.deepcopy(updated.matching_state or {})
        matching_state["provisional_order"] = True
        matching_state["created_during_accessioning"] = True
        matching_state["patient_euid"] = created_patient_ids[0]
        updated = self._create_revision(
            work_item_id,
            actor_id=actor_id,
            queue=AccessionQueue.MATCHING_PENDING.value,
            stage_status=AccessionStageStatus.REGISTERED_MATCHED.value,
            matching_state=matching_state,
            note="provisional order created",
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.CREATE,
            actor_id=actor_id,
            details={
                "stage": "provisional_order",
                "trf_euid": trf.euid,
                "test_euid": test.euid,
                "patient_euids": created_patient_ids,
                "site_id": request.site_id,
                "fulfillment_route_code": request.fulfillment_route_code,
                "created_during_accessioning": True,
            },
        )
        return updated

    def record_outcome(
        self,
        work_item_id: str,
        request: OutcomeRequest,
        *,
        actor_id: uuid.UUID | None,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        item, revision = self._require_work_item(work_item_id)
        matching_state = copy.deepcopy(revision.matching_state or {})
        patient_euid = (
            str(request.patient_euid or matching_state.get("patient_euid") or "").strip() or None
        )
        test_euids = list(
            matching_state.get("test_euids")
            or ([matching_state["test_euid"]] if matching_state.get("test_euid") else [])
        )
        trf_euid = str(matching_state.get("trf_euid") or "").strip() or None
        outcome = str(request.outcome or "").strip().upper()

        outcome_summary = {
            "outcome": outcome,
            "reason": request.reason,
            "recorded_at": _now_iso(),
        }
        queue = AccessionQueue.COMPLETED.value
        stage_status = outcome

        if outcome not in {
            AccessionStageStatus.ACCEPTED.value,
            AccessionStageStatus.HOLD.value,
            AccessionStageStatus.REJECTED.value,
        }:
            raise ValueError(f"Unsupported outcome: {outcome}")
        if (
            outcome in {AccessionStageStatus.HOLD.value, AccessionStageStatus.REJECTED.value}
            and not str(request.reason or "").strip()
        ):
            raise ValueError(f"{outcome} requires a reason")
        if (
            outcome == AccessionStageStatus.ACCEPTED.value
            and not str(request.starting_queue or "").strip()
        ):
            raise ValueError("ACCEPTED requires a starting queue")

        if outcome == AccessionStageStatus.HOLD.value and (trf_euid is None or not test_euids):
            hold_exception, _hold_revision = self.exceptions.create(
                ExceptionCreate(
                    exception_type=ExceptionType.RECEIVED_NO_ORDER,
                    shipment_id=item.shipment_euid,
                    note=request.reason or "Hold without matched order context",
                ),
                created_by=actor_id,
            )
            outcome_summary["exception_euid"] = hold_exception.euid
            outcome_summary["exception_number"] = hold_exception.exception_number
            queue = AccessionQueue.HOLD_INVESTIGATE.value
        else:
            if trf_euid is None or not test_euids:
                raise ValueError("matched TRF.test is required before recording this outcome")
            if patient_euid is None:
                raise ValueError("patient_euid is required before recording this outcome")

            result = self.intake.record_material_outcome(
                MaterialOutcomeRequest(
                    trf_euid=trf_euid,
                    test_euids=test_euids,
                    patient_euid=patient_euid,
                    outcome=MaterialIntakeOutcome(outcome),
                    shipment_euid=item.shipment_euid,
                    testkit_euid=(matching_state.get("testkit_euids") or [None])[0],
                    container_euid=self._primary_container_external_euid(matching_state),
                    starting_queue=request.starting_queue,
                    reason=request.reason,
                    idempotency_key=f"atlas-accession-workbench:{work_item_id}:{outcome}",
                ),
                actor_id=actor_id,
            )
            outcome_summary.update(
                {
                    "trf_euid": result.trf_euid,
                    "test_euids": result.test_euids,
                    "patient_euid": result.patient_euid,
                    "container_euid": result.container_euid,
                    "specimen_euid": result.specimen_euid,
                    "current_queue": result.current_queue,
                    "accepted": result.accepted,
                }
            )
            if outcome == AccessionStageStatus.HOLD.value:
                hold_exception, _hold_revision = self.exceptions.create(
                    ExceptionCreate(
                        exception_type=ExceptionType.OTHER,
                        shipment_id=item.shipment_euid,
                        order_id=trf_euid,
                        note=request.reason or "Accessioning hold",
                    ),
                    created_by=actor_id,
                )
                outcome_summary["exception_euid"] = hold_exception.euid
                outcome_summary["exception_number"] = hold_exception.exception_number
                queue = AccessionQueue.HOLD_INVESTIGATE.value

        updated = self._create_revision(
            work_item_id,
            actor_id=actor_id,
            queue=queue,
            stage_status=stage_status,
            outcome_summary=outcome_summary,
            note=request.reason or f"outcome recorded: {outcome}",
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.STATUS_CHANGE,
            actor_id=actor_id,
            details={
                "stage": "outcome",
                "outcome": outcome,
                "queue": queue,
                "patient_euid": patient_euid,
                "reason": request.reason,
                "starting_queue": request.starting_queue,
                "trf_euid": trf_euid,
                "test_euids": test_euids,
            },
        )
        return updated

    def _move_to_hold(
        self,
        work_item_id: str,
        *,
        actor_id: uuid.UUID | None,
        reason: str,
        exception_type: ExceptionType,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        item, revision = self._require_work_item(work_item_id)
        exception, _exception_revision = self.exceptions.create(
            ExceptionCreate(
                exception_type=exception_type,
                shipment_id=item.shipment_euid,
                note=reason,
            ),
            created_by=actor_id,
        )
        outcome_summary = copy.deepcopy(revision.outcome_summary or {})
        outcome_summary.update(
            {
                "outcome": AccessionStageStatus.HOLD.value,
                "reason": reason,
                "exception_euid": exception.euid,
                "exception_number": exception.exception_number,
                "recorded_at": _now_iso(),
            }
        )
        updated = self._create_revision(
            work_item_id,
            actor_id=actor_id,
            queue=AccessionQueue.HOLD_INVESTIGATE.value,
            stage_status=AccessionStageStatus.HOLD.value,
            outcome_summary=outcome_summary,
            note=reason,
        )
        self.db.commit()
        self._log_work_item_audit(
            work_item_id=item.euid,
            action=AuditAction.STATUS_CHANGE,
            actor_id=actor_id,
            details={
                "stage": "hold",
                "queue": AccessionQueue.HOLD_INVESTIGATE.value,
                "reason": reason,
                "exception_type": exception_type.value,
                "exception_euid": exception.euid,
            },
        )
        return updated

    def _register_tube_content(
        self,
        *,
        work_item: TapdbAccessionWorkItemRecord,
        parent_type: str,
        parent_id: str,
        request: ContentRegistrationRequest,
        registration_fingerprint: str | None,
        actor_id: uuid.UUID | None,
    ) -> tuple[str, str]:
        barcode = str(request.barcode or "").strip() or None
        if barcode:
            ext = self.external_objects.get_external_object("bloom", "container", barcode)
            if ext is None:
                raise ValueError(f"Bloom container not found: {barcode}")
            external_object_id = ext.euid
            label = ext.external_euid
        else:
            tube_result = self.bridge.create_empty_tube(
                TubeCreationRequest(
                    shipment_euid=work_item.shipment_euid if parent_type == "Shipment" else None,
                    testkit_euid=parent_id if parent_type == "TestKit" else None,
                    site_euid=request.site_euid,
                    collection_site_euid=request.collection_site_euid,
                    origin_site_id=request.origin_site_id,
                    idempotency_key=(
                        f"atlas-accession-tube:{registration_fingerprint or work_item.euid}:{parent_type}:{parent_id}"
                    ),
                ),
                actor_id=actor_id,
            )
            external_object_id = tube_result.container_external_object_euid
            label = tube_result.container_euid
        self.shipments.add_container_item(
            container_type=parent_type,
            container_id=parent_id,
            item_type="ExternalObject",
            item_id=external_object_id,
            reason="Tube registered during accessioning",
            created_by=actor_id,
        )
        return external_object_id, label

    @staticmethod
    def _normalize_minimal_kind(kind: str) -> str:
        mapping = {
            "Shipment": "Shipment",
            "Package": "Shipment",
            "TestKit": "TestKit",
            "Kit": "TestKit",
            "TRF": "TRF",
            "Test": "Test",
            "Document": "Document",
            "Paperwork": "Document",
            "ExternalObject": "ExternalObject",
            "Tube": "ExternalObject",
        }
        normalized = mapping.get(str(kind or "").strip(), str(kind or "").strip())
        if normalized not in {"Shipment", "TestKit", "TRF", "Test", "Document", "ExternalObject"}:
            raise ValueError(f"Unsupported minimal child kind: {kind}")
        return normalized

    @staticmethod
    def _minimal_kind_label(entity_type: str) -> str:
        return {
            "Shipment": "Package",
            "TestKit": "Kit",
            "TRF": "TRF",
            "Test": "Test",
            "Document": "Paperwork",
            "ExternalObject": "Tube",
        }.get(entity_type, entity_type)

    @staticmethod
    def _minimal_allowed_child_kinds(entity_type: str) -> list[dict[str, str]]:
        if entity_type == "Shipment":
            return [
                {"kind": "Shipment", "label": "Package"},
                {"kind": "TestKit", "label": "Kit"},
                {"kind": "ExternalObject", "label": "Tube"},
                {"kind": "Document", "label": "Paperwork"},
                {"kind": "TRF", "label": "TRF"},
            ]
        if entity_type == "TestKit":
            return [
                {"kind": "TestKit", "label": "Kit"},
                {"kind": "ExternalObject", "label": "Tube"},
                {"kind": "Document", "label": "Paperwork"},
                {"kind": "TRF", "label": "TRF"},
            ]
        if entity_type == "TRF":
            return [{"kind": "Test", "label": "Test"}]
        return []

    def _validate_minimal_parent_child(self, parent_type: str, child_kind: str) -> None:
        allowed = {row["kind"] for row in self._minimal_allowed_child_kinds(parent_type)}
        if child_kind not in allowed:
            raise ValueError(
                f"{self._minimal_kind_label(parent_type)} cannot contain {self._minimal_kind_label(child_kind)}"
            )

    @staticmethod
    def _minimal_legacy_node_id(entity_type: str, entity_id: str) -> str:
        return f"{MINIMAL_LEGACY_NODE_PREFIX}{entity_type}::{entity_id}"

    @staticmethod
    def _minimal_dom_id(node_id: str) -> str:
        sanitized = str(node_id or "").replace(":", "-").replace("/", "-")
        return sanitized.replace(".", "-")

    def _minimal_manifest_nodes(self, manifest: dict[str, Any]) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        seen: set[str] = set()
        for row in list(manifest.get("minimal_nodes") or []) + list(manifest.get("items") or []):
            if not isinstance(row, dict):
                continue
            node_id = str(row.get("node_id") or "").strip()
            entity_type = str(row.get("entity_type") or "").strip()
            entity_id = str(row.get("entity_id") or "").strip()
            if not node_id or not entity_type or not entity_id:
                continue
            if node_id in seen:
                continue
            seen.add(node_id)
            rows.append(copy.deepcopy(row))
        return rows

    def _decorate_minimal_tree(
        self,
        *,
        node: dict[str, Any],
        manifest_nodes: list[dict[str, Any]],
        work_item: TapdbAccessionWorkItemRecord,
        depth: int,
    ) -> dict[str, Any]:
        manifest_by_entity = {
            (str(row.get("entity_type")), str(row.get("entity_id"))): row for row in manifest_nodes
        }
        return self._decorate_minimal_tree_node(
            node=node,
            manifest_by_entity=manifest_by_entity,
            work_item=work_item,
            depth=depth,
        )

    def _decorate_minimal_tree_node(
        self,
        *,
        node: dict[str, Any],
        manifest_by_entity: dict[tuple[str, str], dict[str, Any]],
        work_item: TapdbAccessionWorkItemRecord,
        depth: int,
    ) -> dict[str, Any]:
        entity_type = str(node.get("type") or "")
        entity_id = str(node.get("id") or "")
        manifest_row = manifest_by_entity.get((entity_type, entity_id))
        if depth == 0 and entity_type == "Shipment" and entity_id == work_item.shipment_euid:
            node_id = f"{MINIMAL_ROOT_NODE_PREFIX}{entity_id}"
            resolution_source = "root"
        elif manifest_row is not None:
            node_id = str(manifest_row.get("node_id"))
            resolution_source = str(manifest_row.get("resolution_source") or "captured")
        else:
            node_id = self._minimal_legacy_node_id(entity_type, entity_id)
            resolution_source = "legacy"
        display_label = str((manifest_row or {}).get("label") or node.get("label") or entity_id)
        decorated = {
            "node_id": node_id,
            "url_node_id": quote(node_id, safe=""),
            "dom_id": self._minimal_dom_id(node_id),
            "kind": self._minimal_kind_label(entity_type),
            "entity_type": entity_type,
            "entity_id": entity_id,
            "label": display_label,
            "display_label": display_label,
            "resolution_source": resolution_source,
            "resolution_source_label": resolution_source.replace("_", " ").title(),
            "depth": depth,
            "is_root": depth == 0,
            "is_container": entity_type in {"Shipment", "TestKit", "TRF"},
            "allowed_child_kinds": self._minimal_allowed_child_kinds(entity_type),
            "href": self._minimal_entity_href(entity_type, node),
            "logical_parent_type": str((manifest_row or {}).get("parent_type") or ""),
            "logical_parent_id": str((manifest_row or {}).get("parent_id") or ""),
            "is_logical_only": False,
            "children": [],
        }
        for child in node.get("children", []) or []:
            decorated["children"].append(
                self._decorate_minimal_tree_node(
                    node=child,
                    manifest_by_entity=manifest_by_entity,
                    work_item=work_item,
                    depth=depth + 1,
                )
            )
        return decorated

    def _inject_logical_trf_nodes(
        self,
        node: dict[str, Any],
        manifest_nodes: list[dict[str, Any]],
    ) -> dict[str, Any]:
        manifest_by_parent: dict[tuple[str, str], list[dict[str, Any]]] = {}
        manifest_by_trf: dict[str, list[dict[str, Any]]] = {}
        for row in manifest_nodes:
            entity_type = str(row.get("entity_type") or "")
            parent_key = (str(row.get("parent_type") or ""), str(row.get("parent_id") or ""))
            manifest_by_parent.setdefault(parent_key, []).append(row)
            if entity_type == "Test" and str(row.get("parent_type") or "") == "TRF":
                manifest_by_trf.setdefault(str(row.get("parent_id") or ""), []).append(row)

        def _inject(current: dict[str, Any]) -> dict[str, Any]:
            current["children"] = [_inject(child) for child in list(current.get("children") or [])]
            parent_key = (
                str(current.get("entity_type") or ""),
                str(current.get("entity_id") or ""),
            )
            trf_rows = [
                row
                for row in manifest_by_parent.get(parent_key, [])
                if str(row.get("entity_type") or "") == "TRF"
            ]
            if not trf_rows:
                return current

            remaining_children = list(current["children"])
            logical_children: list[dict[str, Any]] = []
            for trf_row in trf_rows:
                trf_euid = str(trf_row.get("entity_id") or "")
                trf_node = {
                    "node_id": str(trf_row.get("node_id") or ""),
                    "url_node_id": quote(str(trf_row.get("node_id") or ""), safe=""),
                    "dom_id": self._minimal_dom_id(str(trf_row.get("node_id") or "")),
                    "kind": "TRF",
                    "entity_type": "TRF",
                    "entity_id": trf_euid,
                    "label": str(trf_row.get("label") or trf_euid),
                    "display_label": str(trf_row.get("label") or trf_euid),
                    "resolution_source": str(trf_row.get("resolution_source") or "captured"),
                    "resolution_source_label": str(trf_row.get("resolution_source") or "captured")
                    .replace("_", " ")
                    .title(),
                    "depth": int(current.get("depth") or 0) + 1,
                    "is_root": False,
                    "is_container": True,
                    "allowed_child_kinds": self._minimal_allowed_child_kinds("TRF"),
                    "href": f"/trfs/{trf_euid}",
                    "logical_parent_type": str(trf_row.get("parent_type") or ""),
                    "logical_parent_id": str(trf_row.get("parent_id") or ""),
                    "is_logical_only": True,
                    "children": [],
                }
                test_rows = manifest_by_trf.get(trf_euid, [])
                retained_children: list[dict[str, Any]] = []
                for child in remaining_children:
                    child_entity_type = str(child.get("entity_type") or "")
                    child_entity_id = str(child.get("entity_id") or "")
                    if child_entity_type == "Test" and any(
                        str(test_row.get("entity_id") or "") == child_entity_id
                        for test_row in test_rows
                    ):
                        child["depth"] = trf_node["depth"] + 1
                        trf_node["children"].append(child)
                    else:
                        retained_children.append(child)
                remaining_children = retained_children
                logical_children.append(trf_node)
            current["children"] = remaining_children + logical_children
            return current

        return _inject(copy.deepcopy(node))

    @staticmethod
    def _minimal_storage_parent(
        *,
        parent_node: dict[str, Any],
        child_kind: str,
    ) -> tuple[str | None, str | None]:
        parent_entity_type = str(parent_node.get("entity_type") or "")
        parent_entity_id = str(parent_node.get("entity_id") or "")
        if child_kind == "TRF":
            return None, None
        if child_kind == "Test" and parent_entity_type == "TRF":
            logical_parent_type = str(parent_node.get("logical_parent_type") or "")
            logical_parent_id = str(parent_node.get("logical_parent_id") or "")
            if logical_parent_type and logical_parent_id:
                return logical_parent_type, logical_parent_id
        return parent_entity_type, parent_entity_id

    @staticmethod
    def _minimal_entity_href(entity_type: str, node: dict[str, Any]) -> str | None:
        entity_id = str(node.get("id") or "")
        label = str(node.get("label") or entity_id)
        if entity_type == "Shipment" and label:
            return f"/shipments/{label}"
        if entity_type == "TestKit":
            return f"/testkits/{entity_id}"
        if entity_type == "TRF":
            return f"/trfs/{entity_id}"
        if entity_type == "Test":
            return f"/trfs/tests/{entity_id}"
        return None

    @staticmethod
    def _flatten_tree(node: dict[str, Any]) -> list[dict[str, Any]]:
        rows = [node]
        for child in node.get("children", []) or []:
            rows.extend(AccessioningWorkbenchService._flatten_tree(child))
        return rows

    def _find_tree_node_by_id(self, node: dict[str, Any], node_id: str) -> dict[str, Any] | None:
        if str(node.get("node_id")) == str(node_id):
            return node
        for child in node.get("children", []) or []:
            found = self._find_tree_node_by_id(child, node_id)
            if found is not None:
                return found
        return None

    @staticmethod
    def _find_minimal_node_by_entity(
        minimal_nodes: list[dict[str, Any]],
        *,
        entity_type: str,
        entity_id: str,
    ) -> dict[str, Any] | None:
        for row in minimal_nodes:
            if (
                str(row.get("entity_type")) == entity_type
                and str(row.get("entity_id")) == entity_id
            ):
                return row
        return None

    @staticmethod
    def _find_minimal_node_by_node_id(
        minimal_nodes: list[dict[str, Any]],
        *,
        node_id: str,
    ) -> dict[str, Any] | None:
        for row in minimal_nodes:
            if str(row.get("node_id")) == str(node_id):
                return row
        return None

    @staticmethod
    def _default_site_euid(detail: dict[str, Any]) -> str | None:
        receipt_site = (detail.get("revision").receipt_metadata or {}).get("origin_site_id")
        if receipt_site:
            return str(receipt_site)
        shipment_revision = detail.get("shipment_revision")
        if shipment_revision and getattr(shipment_revision, "origin_site_id", None):
            return str(shipment_revision.origin_site_id)
        return None

    def _ancestor_container_refs(
        self,
        *,
        work_item: TapdbAccessionWorkItemRecord,
        manifest: dict[str, Any],
        parent_type: str,
        parent_id: str,
    ) -> list[tuple[str, str]]:
        refs: list[tuple[str, str]] = []

        def _append_ref(kind: str, euid: str) -> None:
            candidate = (kind, euid)
            if candidate not in refs:
                refs.append(candidate)

        if parent_type in {"Shipment", "TestKit"}:
            _append_ref(parent_type, parent_id)
        current_parent_type = parent_type
        current_parent_id = parent_id
        nodes = self._minimal_manifest_nodes(manifest)
        while True:
            current = self._find_minimal_node_by_entity(
                nodes,
                entity_type=current_parent_type,
                entity_id=current_parent_id,
            )
            if current is None:
                break
            next_parent_type = str(current.get("parent_type") or "")
            next_parent_id = str(current.get("parent_id") or "")
            if next_parent_type in {"Shipment", "TestKit"} and next_parent_id:
                _append_ref(next_parent_type, next_parent_id)
            if not next_parent_type or not next_parent_id:
                break
            current_parent_type = next_parent_type
            current_parent_id = next_parent_id
        if work_item.shipment_euid:
            _append_ref("Shipment", work_item.shipment_euid)
        return refs

    def _resolve_minimal_site_euid(
        self,
        *,
        request: MinimalChildRegistrationRequest,
        default_site_euid: str | None,
    ) -> str | None:
        for candidate in (request.site_euid, request.origin_site_id, default_site_euid):
            clean = str(candidate or "").strip()
            if clean:
                return clean
        return None

    def _resolve_or_create_minimal_entity(
        self,
        *,
        work_item: TapdbAccessionWorkItemRecord,
        parent_node: dict[str, Any],
        request: MinimalChildRegistrationRequest,
        actor_id: uuid.UUID | None,
        default_site_euid: str | None = None,
    ) -> dict[str, Any]:
        kind = self._normalize_minimal_kind(request.kind)
        scan_value = str(request.scan_value or request.existing_euid or "").strip() or None
        parent_entity_type = str(parent_node["entity_type"])
        parent_entity_id = str(parent_node["entity_id"])
        resolved_site_euid = self._resolve_minimal_site_euid(
            request=request,
            default_site_euid=default_site_euid,
        )

        if kind == "Shipment":
            shipment_result = None
            if scan_value:
                shipment_result = self.shipments.get(scan_value, cross_tenant=False)
                if shipment_result is None:
                    shipment_result = self.shipments.get_by_shipment_number(
                        scan_value,
                        cross_tenant=False,
                    )
                if shipment_result is None:
                    shipment = self.shipments.get_by_tracking_number(scan_value, cross_tenant=False)
                    if shipment is not None:
                        shipment_result = self.shipments.get(shipment.euid, cross_tenant=False)
            if shipment_result is not None:
                shipment, _revision = shipment_result
                return {
                    "kind": "Package",
                    "entity_type": "Shipment",
                    "entity_id": shipment.euid,
                    "label": shipment.shipment_number,
                    "resolution_source": "matched_existing",
                    "captured_trf_euids": [],
                    "captured_test_euids": [],
                    "captured_test_nodes": [],
                }
            origin_site_id = str(request.origin_site_id or resolved_site_euid or "").strip() or None
            shipment, _revision = self.shipments.create(
                ShipmentCreate(
                    carrier=request.carrier,
                    tracking_number=str(request.tracking_number or scan_value or "").strip()
                    or None,
                    origin_site_id=origin_site_id,
                    origin_address=self._origin_address_for_site(origin_site_id),
                    special_instructions=request.notes,
                ),
                created_by=actor_id,
            )
            return {
                "kind": "Package",
                "entity_type": "Shipment",
                "entity_id": shipment.euid,
                "label": shipment.shipment_number,
                "resolution_source": "created_new",
                "captured_trf_euids": [],
                "captured_test_euids": [],
                "captured_test_nodes": [],
            }

        if kind == "TestKit":
            if scan_value:
                kit = self.testkits.get_by_id(
                    scan_value, cross_tenant=False
                ) or self.testkits.get_by_barcode(
                    scan_value,
                    cross_tenant=False,
                )
                if kit is not None:
                    return {
                        "kind": "Kit",
                        "entity_type": "TestKit",
                        "entity_id": kit.euid,
                        "label": kit.display_label,
                        "resolution_source": "matched_existing",
                        "captured_trf_euids": [],
                        "captured_test_euids": [],
                        "captured_test_nodes": [],
                    }
            kit = self.testkits.create(
                TestKitCreate(
                    kit_barcode=scan_value,
                    kit_type=request.kit_type,
                    origin_site_id=str(request.origin_site_id or resolved_site_euid or "").strip()
                    or None,
                ),
                created_by=actor_id,
            )
            return {
                "kind": "Kit",
                "entity_type": "TestKit",
                "entity_id": kit.euid,
                "label": kit.display_label,
                "resolution_source": "created_new" if scan_value else "minted_euid",
                "captured_trf_euids": [],
                "captured_test_euids": [],
                "captured_test_nodes": [],
            }

        if kind == "Document":
            if scan_value:
                existing = self.documents.get(scan_value)
                if existing is not None:
                    document, revision = existing
                    return {
                        "kind": "Paperwork",
                        "entity_type": "Document",
                        "entity_id": document.euid,
                        "label": revision.filename or document.euid,
                        "resolution_source": "matched_existing",
                        "captured_trf_euids": [],
                        "captured_test_euids": [],
                        "captured_test_nodes": [],
                    }
            filename = (
                str(request.label or "paperwork-placeholder").strip() or "paperwork-placeholder"
            )
            document, revision = self.documents.create_placeholder(
                DocumentPlaceholder(
                    filename=filename,
                    document_type=request.document_type,
                    note=request.notes,
                ),
                created_by=actor_id,
            )
            return {
                "kind": "Paperwork",
                "entity_type": "Document",
                "entity_id": document.euid,
                "label": revision.filename or document.euid,
                "resolution_source": "placeholder",
                "captured_trf_euids": [],
                "captured_test_euids": [],
                "captured_test_nodes": [],
            }

        if kind == "ExternalObject":
            if scan_value:
                ext = self.external_objects.get_external_object_by_id(scan_value)
                if ext is None:
                    ext = self.external_objects.get_external_object(
                        "bloom", "container", scan_value
                    )
                if ext is None:
                    ext = self.external_objects.get_external_object("bloom", "specimen", scan_value)
                if ext is None:
                    scan_result = self.intake.scan_barcode(scan_value, cross_tenant=False)
                    if scan_result.found and scan_result.entity_type == "BloomContainer":
                        ext = self.external_objects.get_external_object(
                            "bloom", "container", scan_value
                        )
                    elif scan_result.found and scan_result.entity_type == "BloomSpecimen":
                        ext = self.external_objects.get_external_object(
                            "bloom", "specimen", scan_value
                        )
                if ext is not None:
                    return {
                        "kind": "Tube",
                        "entity_type": "ExternalObject",
                        "entity_id": ext.euid,
                        "label": ext.external_euid,
                        "resolution_source": "matched_existing",
                        "captured_trf_euids": [],
                        "captured_test_euids": [],
                        "captured_test_nodes": [],
                    }
            tube_result = self.bridge.create_empty_tube(
                TubeCreationRequest(
                    shipment_euid=work_item.shipment_euid
                    if parent_entity_type == "Shipment"
                    else None,
                    testkit_euid=parent_entity_id if parent_entity_type == "TestKit" else None,
                    site_euid=resolved_site_euid,
                    collection_site_euid=str(
                        request.collection_site_euid or resolved_site_euid or ""
                    ).strip()
                    or None,
                    origin_site_id=str(request.origin_site_id or resolved_site_euid or "").strip()
                    or None,
                    idempotency_key=f"atlas-minimal-accession:{work_item.euid}:{parent_entity_type}:{parent_entity_id}:{uuid.uuid4()}",
                ),
                actor_id=actor_id,
            )
            return {
                "kind": "Tube",
                "entity_type": "ExternalObject",
                "entity_id": tube_result.container_external_object_euid,
                "label": tube_result.container_euid,
                "resolution_source": "created_new",
                "captured_trf_euids": [],
                "captured_test_euids": [],
                "captured_test_nodes": [],
            }

        if kind == "TRF":
            trf_result = None
            if scan_value:
                trf_result = self.trfs.get_by_id(
                    scan_value, cross_tenant=False
                ) or self.trfs.get_by_number(
                    scan_value,
                    cross_tenant=False,
                )
            if trf_result is not None:
                trf, _revision = trf_result
                tests = self.tests.list_for_trf(trf.euid, cross_tenant=False)
                return {
                    "kind": "TRF",
                    "entity_type": "TRF",
                    "entity_id": trf.euid,
                    "label": trf.order_number,
                    "resolution_source": "matched_existing",
                    "captured_trf_euids": [trf.euid],
                    "captured_test_euids": [test.euid for test, _revision, _routes in tests],
                    "captured_test_nodes": [
                        {
                            "entity_id": test.euid,
                            "label": test_revision.product_code or test.euid,
                            "resolution_source": "matched_existing",
                        }
                        for test, test_revision, _routes in tests
                    ],
                }
            trf, _revision = self.trfs.create(
                TrfCreate(
                    site_id=resolved_site_euid,
                    clinical_notes=request.notes,
                    created_during_accessioning=True,
                    accession_work_item_id=work_item.euid,
                ),
                tests=None,
                patient_links=None,
                created_by=actor_id,
            )
            captured_test_euids: list[str] = []
            captured_test_nodes: list[dict[str, str]] = []
            if str(request.route_code or "").strip():
                created_test = self.tests.create(
                    trf.euid,
                    TestCreate(
                        product_code=str(request.product_code or request.route_code or "").strip()
                        or None,
                        fulfillment_route_codes=[str(request.route_code).strip()],
                        specimen_type_required=request.specimen_type_required,
                        site_id=resolved_site_euid,
                        created_during_accessioning=True,
                        accession_work_item_id=work_item.euid,
                        clinical_notes=request.notes,
                    ),
                    created_by=actor_id,
                    cross_tenant=False,
                )
                if created_test is not None:
                    captured_test_euids.append(created_test[0].euid)
                    captured_test_nodes.append(
                        {
                            "entity_id": created_test[0].euid,
                            "label": created_test[1].product_code or created_test[0].euid,
                            "resolution_source": "created_new",
                        }
                    )
            return {
                "kind": "TRF",
                "entity_type": "TRF",
                "entity_id": trf.euid,
                "label": trf.order_number,
                "resolution_source": "created_new",
                "captured_trf_euids": [trf.euid],
                "captured_test_euids": captured_test_euids,
                "captured_test_nodes": captured_test_nodes,
            }

        if kind == "Test":
            if parent_entity_type != "TRF":
                raise ValueError("Tests must be captured inside a TRF")
            if scan_value:
                test_result = self.tests.get_with_revision(scan_value, cross_tenant=False)
                if test_result is not None:
                    test, revision = test_result
                    if str(test.order_id) != parent_entity_id:
                        raise ValueError(
                            f"Test {test.euid} does not belong to TRF {parent_entity_id}"
                        )
                    return {
                        "kind": "Test",
                        "entity_type": "Test",
                        "entity_id": test.euid,
                        "label": revision.product_code or test.euid,
                        "resolution_source": "matched_existing",
                        "captured_trf_euids": [parent_entity_id],
                        "captured_test_euids": [test.euid],
                        "captured_test_nodes": [],
                    }
            route_code = str(request.route_code or "").strip()
            if not route_code:
                raise ValueError("Creating a provisional Test requires at least one route code")
            created_test = self.tests.create(
                parent_entity_id,
                TestCreate(
                    product_code=str(request.product_code or route_code).strip() or None,
                    fulfillment_route_codes=[route_code],
                    specimen_type_required=request.specimen_type_required,
                    site_id=resolved_site_euid,
                    created_during_accessioning=True,
                    accession_work_item_id=work_item.euid,
                    clinical_notes=request.notes,
                ),
                created_by=actor_id,
                cross_tenant=False,
            )
            if created_test is None:
                raise ValueError("Unable to create provisional Test")
            test, revision = created_test
            return {
                "kind": "Test",
                "entity_type": "Test",
                "entity_id": test.euid,
                "label": revision.product_code or test.euid,
                "resolution_source": "created_new",
                "captured_trf_euids": [parent_entity_id],
                "captured_test_euids": [test.euid],
                "captured_test_nodes": [],
            }

        raise ValueError(f"Unsupported minimal child kind: {kind}")

    def _record_minimal_matching_state(
        self,
        *,
        matching_state: dict[str, Any],
        resolved: dict[str, Any],
    ) -> None:
        matching_state.setdefault("captured_trf_euids", [])
        matching_state.setdefault(
            "captured_test_euids", list(matching_state.get("test_euids") or [])
        )
        matching_state.setdefault("test_euids", list(matching_state.get("test_euids") or []))
        if resolved["entity_type"] == "TestKit":
            _append_unique(matching_state["testkit_euids"], resolved["entity_id"])
        elif resolved["entity_type"] == "Document":
            _append_unique(matching_state["document_euids"], resolved["entity_id"])
        elif resolved["entity_type"] == "ExternalObject":
            _append_unique(matching_state["external_object_ids"], resolved["entity_id"])
        for trf_euid in resolved.get("captured_trf_euids", []):
            _append_unique(matching_state["captured_trf_euids"], trf_euid)
        for test_euid in resolved.get("captured_test_euids", []):
            _append_unique(matching_state["captured_test_euids"], test_euid)
            _append_unique(matching_state["test_euids"], test_euid)

    def _apply_auto_primary_matching(self, matching_state: dict[str, Any]) -> None:
        captured = [
            str(test_euid).strip()
            for test_euid in (
                matching_state.get("captured_test_euids") or matching_state.get("test_euids") or []
            )
            if str(test_euid).strip()
        ]
        unique_tests: list[str] = []
        for test_euid in captured:
            if test_euid not in unique_tests:
                unique_tests.append(test_euid)
        matching_state["captured_test_euids"] = unique_tests
        matching_state["test_euids"] = list(unique_tests)
        if len(unique_tests) == 1:
            test = self.tests.get_by_id(unique_tests[0], cross_tenant=False)
            if test is not None:
                matching_state["test_euid"] = test.euid
                matching_state["trf_euid"] = test.order_id
                return
        matching_state.pop("test_euid", None)
        matching_state.pop("trf_euid", None)

    @staticmethod
    def _minimal_stage_status(matching_state: dict[str, Any]) -> str:
        return (
            AccessionStageStatus.REGISTERED_MATCHED.value
            if matching_state.get("test_euid")
            else AccessionStageStatus.REGISTERED_UNMATCHED.value
        )

    def _apply_minimal_business_links(
        self,
        *,
        work_item: TapdbAccessionWorkItemRecord,
        manifest: dict[str, Any],
        node_record: dict[str, Any],
        resolved: dict[str, Any],
        actor_id: uuid.UUID | None,
    ) -> None:
        parent_type = str(node_record["parent_type"])
        parent_id = str(node_record["parent_id"])
        ancestor_refs = self._ancestor_container_refs(
            work_item=work_item,
            manifest=manifest,
            parent_type=parent_type,
            parent_id=parent_id,
        )

        for test_euid in resolved.get("captured_test_euids", []):
            for source_type, source_id in ancestor_refs:
                self.entity_links.link(
                    source_type=source_type,
                    source_id=source_id,
                    target_type="Test",
                    target_id=test_euid,
                    created_by=actor_id,
                )

        if resolved["entity_type"] == "Document":
            self.documents.link_to_entity(
                resolved["entity_id"],
                "Shipment",
                work_item.shipment_euid,
                created_by=actor_id,
            )
        elif resolved["entity_type"] == "ExternalObject" and parent_type in {"Shipment", "TestKit"}:
            desired_relation = (
                "belongs_to_shipment" if parent_type == "Shipment" else "belongs_to_testkit"
            )
            relations = self.external_objects.list_relations_for_external_object(
                resolved["entity_id"]
            )
            if not any(
                relation.relation_type == desired_relation and relation.local_entity_id == parent_id
                for relation in relations
            ):
                self.external_objects.create_relation(
                    ExternalObjectRelationCreate(
                        external_object_id=resolved["entity_id"],
                        relation_type=desired_relation,
                        local_entity_type=parent_type,
                        local_entity_id=parent_id,
                        metadata={},
                    ),
                    actor_id=actor_id,
                )

    def _log_work_item_audit(
        self,
        *,
        work_item_id: str,
        action: AuditAction,
        actor_id: uuid.UUID | None,
        details: dict[str, Any],
    ) -> None:
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db,
                tenant_id=self.tenant_id,
                user_id=str(actor_id) if actor_id else None,
            ).log(
                action=action,
                entity_type="AccessionWorkItem",
                entity_id=work_item_id,
                details=details,
                user_id=actor_id,
            )
            self.db.commit()
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.warning(
                "Audit logging failed for AccessionWorkItem %s in tenant %s",
                work_item_id,
                self.tenant_id,
                exc_info=True,
            )

    def _ensure_collection_event(
        self,
        *,
        external_object_id: str,
        patient_euid: str,
        collection_site_euid: str,
        actor_id: uuid.UUID | None,
    ) -> str:
        current = self.external_objects.list_relations_for_external_object(external_object_id)
        for relation in current:
            if relation.relation_type == "has_collection_event":
                return relation.local_entity_id
        external_object = self.external_objects.get_external_object_by_id(external_object_id)
        if external_object is None:
            raise ValueError(f"External object not found: {external_object_id}")
        event, _revision = self.collection_events.create(
            CollectionEventCreate(
                patient_euid=patient_euid,
                site_euid=collection_site_euid,
                container_euid=external_object.external_euid,
                specimen_euid=None,
            ),
            created_by=actor_id,
        )
        self.external_objects.create_relation(
            ExternalObjectRelationCreate(
                external_object_id=external_object_id,
                relation_type="has_collection_event",
                local_entity_type="CollectionEvent",
                local_entity_id=event.euid,
                metadata={},
            ),
            actor_id=actor_id,
        )
        return event.euid

    def _primary_container_external_euid(self, matching_state: dict[str, Any]) -> str | None:
        external_object_ids = list(matching_state.get("external_object_ids") or [])
        if not external_object_ids:
            return None
        external_object = self.external_objects.get_external_object_by_id(external_object_ids[0])
        if external_object is None:
            return None
        return external_object.external_euid

    def _origin_address_for_site(self, site_id: str | None) -> dict[str, Any] | None:
        clean = str(site_id or "").strip() or None
        if clean is None:
            return None
        site = self.sites.get_by_id(clean)
        if site is None:
            return None
        latest = site.revisions[-1] if site.revisions else None
        if latest is None:
            return None
        return {
            "site_id": site.euid,
            "site_name": latest.name,
            "address": latest.address,
        }

    def _receipt_idempotency_key(
        self,
        shipment_euid: str,
        tracking_number: str | None,
        carrier: str | None,
    ) -> str:
        return f"atlas-accession-receipt:{shipment_euid}:{tracking_number or 'none'}:{carrier or 'none'}"

    def _require_work_item(
        self,
        work_item_id: str,
    ) -> tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord]:
        resolved = self.repo.get_work_item(work_item_id=work_item_id, tenant_id=self.tenant_id)
        if resolved is None:
            raise ValueError(f"Accession work item not found: {work_item_id}")
        return resolved

    def _content_fingerprint(
        self,
        *,
        item: TapdbAccessionWorkItemRecord,
        request: ContentRegistrationRequest,
        parent_type: str,
        parent_id: str,
    ) -> str | None:
        content_type = str(request.content_type or "").strip() or "Unknown"
        registration_token = str(request.registration_token or "").strip() or None
        if registration_token:
            return (
                f"{content_type}:{item.euid}:{parent_type}:{parent_id}:token:{registration_token}"
            )

        if content_type == "ChildShipment":
            tracking_number = str(request.tracking_number or "").strip() or None
            if tracking_number:
                return (
                    f"{content_type}:{item.euid}:{parent_type}:{parent_id}:"
                    f"tracking:{tracking_number}"
                )
        elif content_type == "Kit":
            barcode = str(request.barcode or "").strip() or None
            if barcode:
                return f"{content_type}:{item.euid}:{parent_type}:{parent_id}:barcode:{barcode}"
        elif content_type == "Document":
            document_euid = str(request.document_euid or "").strip() or None
            if document_euid:
                return (
                    f"{content_type}:{item.euid}:{parent_type}:{parent_id}:document:{document_euid}"
                )
            document_filename = str(request.document_filename or "").strip() or None
            if document_filename:
                return (
                    f"{content_type}:{item.euid}:{parent_type}:{parent_id}:"
                    f"filename:{document_filename}"
                )
        elif content_type == "Tube":
            barcode = str(request.barcode or "").strip() or None
            if barcode:
                return f"{content_type}:{item.euid}:{parent_type}:{parent_id}:barcode:{barcode}"
            return (
                f"{content_type}:{item.euid}:{parent_type}:{parent_id}:"
                f"site:{request.site_euid or 'none'}:"
                f"collection:{request.collection_site_euid or 'none'}:"
                f"label:{request.label or 'none'}:"
                f"notes:{request.notes or 'none'}"
            )
        elif content_type == "Misc":
            label = str(request.label or "").strip() or None
            notes = str(request.notes or "").strip() or None
            if label or notes:
                return (
                    f"{content_type}:{item.euid}:{parent_type}:{parent_id}:"
                    f"label:{label or 'none'}:notes:{notes or 'none'}"
                )
        return None

    @staticmethod
    def _find_manifest_item_by_fingerprint(
        *,
        manifest_items: list[dict[str, Any]],
        fingerprint: str | None,
    ) -> dict[str, Any] | None:
        if not fingerprint:
            return None
        for row in manifest_items:
            if str(row.get("registration_fingerprint") or "") == fingerprint:
                return row
        return None

    def _create_revision(
        self,
        work_item_id: str,
        *,
        actor_id: uuid.UUID | None,
        queue: str | None = None,
        mode: str | None = None,
        stage_status: str | None = None,
        receipt_metadata: dict[str, Any] | None = None,
        package_manifest: dict[str, Any] | None = None,
        matching_state: dict[str, Any] | None = None,
        outcome_summary: dict[str, Any] | None = None,
        idempotency_keys: dict[str, Any] | None = None,
        note: str | None = None,
    ) -> TapdbAccessionWorkItemRevisionRecord:
        _item, current = self._require_work_item(work_item_id)
        return (
            self.repo.create_work_item_revision(
                work_item_id=work_item_id,
                queue=queue or current.queue,
                mode=mode or current.mode,
                stage_status=stage_status or current.stage_status,
                receipt_metadata=copy.deepcopy(
                    receipt_metadata if receipt_metadata is not None else current.receipt_metadata
                ),
                package_manifest=copy.deepcopy(
                    package_manifest if package_manifest is not None else current.package_manifest
                ),
                matching_state=copy.deepcopy(
                    matching_state if matching_state is not None else current.matching_state
                ),
                outcome_summary=copy.deepcopy(
                    outcome_summary if outcome_summary is not None else current.outcome_summary
                ),
                idempotency_keys=copy.deepcopy(
                    idempotency_keys if idempotency_keys is not None else current.idempotency_keys
                ),
                created_by=actor_id,
                note=note,
            )
            or current
        )

    def _queue_row(
        self,
        item: TapdbAccessionWorkItemRecord,
        revision: TapdbAccessionWorkItemRevisionRecord,
    ) -> dict[str, Any]:
        shipment_result = self.shipments.get(item.shipment_euid, cross_tenant=False)
        shipment, shipment_revision = (
            shipment_result if shipment_result is not None else (None, None)
        )
        return {
            "work_item_id": item.euid,
            "shipment_euid": item.shipment_euid,
            "shipment_number": shipment.shipment_number
            if shipment is not None
            else item.shipment_euid,
            "shipment_status": shipment_revision.status if shipment_revision is not None else None,
            "queue": revision.queue,
            "stage_status": revision.stage_status,
            "received_at": (revision.receipt_metadata or {}).get("received_at"),
            "linked_test_euid": (revision.matching_state or {}).get("test_euid"),
            "outcome": (revision.outcome_summary or {}).get("outcome"),
        }

    def _list_receipt_candidates(self, *, limit: int) -> list[dict[str, Any]]:
        candidates: list[dict[str, Any]] = []
        existing = {
            item.shipment_euid: item.euid
            for item, _revision in self.repo.list_work_items(
                tenant_id=self.tenant_id,
                limit=10000,
                offset=0,
            )
        }
        for shipment, revision in self.shipments.list_shipments(limit=500, cross_tenant=False):
            if revision is None:
                continue
            if revision.status == "RECEIVED":
                continue
            candidates.append(
                {
                    "shipment_euid": shipment.euid,
                    "shipment_number": shipment.shipment_number,
                    "status": revision.status,
                    "tracking_number": revision.tracking_number,
                    "carrier": revision.carrier,
                    "existing_work_item_id": existing.get(shipment.euid),
                }
            )
        return candidates[:limit]

    def _all_entity_ids_from_tree(self, tree: dict[str, Any], *, entity_type: str) -> list[str]:
        found: list[str] = []

        def walk(node: dict[str, Any]) -> None:
            if node.get("type") == entity_type and node.get("id"):
                _append_unique(found, node["id"])
            for child in node.get("children", []):
                walk(child)

        walk(tree)
        return found

    def _find_existing_hand_delivery_work_item(
        self,
        request: ReceiptRegistrationRequest,
    ) -> tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord] | None:
        requested_received_at = request.received_at.isoformat() if request.received_at else None
        for item, revision in self.repo.list_work_items(
            tenant_id=self.tenant_id,
            limit=5000,
            offset=0,
        ):
            metadata = revision.receipt_metadata or {}
            if metadata.get("carrier") != "HAND_DELIVERY":
                continue
            if str(metadata.get("origin_site_id") or "") != str(request.origin_site_id or ""):
                continue
            if str(metadata.get("received_by") or "") != str(request.received_by or ""):
                continue
            if str(metadata.get("package_condition") or "") != str(request.package_condition or ""):
                continue
            if str(metadata.get("notes") or "") != str(request.notes or ""):
                continue
            if (
                requested_received_at is not None
                and metadata.get("received_at") != requested_received_at
            ):
                continue
            return item, revision
        return None
