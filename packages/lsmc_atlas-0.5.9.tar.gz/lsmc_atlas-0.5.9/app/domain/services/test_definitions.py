"""LSMC Hub - Assay Catalog Service.

Provides operations for managing the assay reference catalog.
AssayRef is a simple catalog table (not append-only with revisions).
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class TestDefinitionCreate:
    """Data for creating a new assay."""

    __test__ = False

    code: str
    name: str
    description: str | None = None
    category: str | None = None
    technology: str | None = None
    specimen_types: list[str] | None = None


@dataclass
class TestDefinitionUpdate:
    """Data for updating an assay."""

    __test__ = False

    name: str | None = None
    description: str | None = None
    category: str | None = None
    technology: str | None = None
    specimen_types: list[str] | None = None
    is_active: bool | None = None


class TestDefinitionService:
    """Service for assay catalog operations."""

    __test__ = False

    def __init__(self, db: Any):
        self.db = db
        self._tapdb_repo = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.test_definitions import TapdbTestDefinitionRepository

            self._tapdb_repo = TapdbTestDefinitionRepository(self.db)
        return self._tapdb_repo

    def create(self, data: TestDefinitionCreate):
        """Create a new assay in the catalog."""
        return self._repo().create(data)

    def get_by_euid(self, assay_euid: str):
        """Get assay by EUID."""
        return self._repo().get_by_euid(assay_euid)

    def get_by_code(self, code: str):
        """Get assay by code."""
        return self._repo().get_by_code(code)

    def list_all(
        self,
        active_only: bool = True,
        category: str | None = None,
        technology: str | None = None,
    ):
        """List all assays with optional filters."""
        return self._repo().list_all(
            active_only=active_only,
            category=category,
            technology=technology,
        )

    def update(
        self,
        assay_euid: str,
        data: TestDefinitionUpdate,
    ):
        """Update an assay."""
        return self._repo().update(assay_euid, data)

    def deactivate(self, assay_euid: str):
        """Deactivate an assay (soft delete)."""
        return self._repo().deactivate(assay_euid)

    def get_categories(self) -> list[str]:
        """Get distinct categories."""
        return self._repo().get_categories()

    def get_technologies(self) -> list[str]:
        """Get distinct technologies."""
        return self._repo().get_technologies()
