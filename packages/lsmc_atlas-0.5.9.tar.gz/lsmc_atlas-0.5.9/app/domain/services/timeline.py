"""LSMC Hub - Timeline Service (TapDB-only runtime)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime

from app.domain.services.audit import AuditService
from app.domain.services.trfs import TrfService


@dataclass
class TimelineEvent:
    """A single event in the timeline."""

    timestamp: datetime
    event_type: str
    action: str
    description: str
    user_id: str | None = None
    details: dict | None = None


class TimelineService:
    """Service for building entity timelines."""

    def __init__(self, db, tenant_id: uuid.UUID, user_id: str | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    def get_order_timeline(self, order_id: str) -> list[TimelineEvent]:
        """Get an order timeline from TapDB-backed TRF + audit history."""
        events: list[TimelineEvent] = []

        trf_result = TrfService(self.db, self.tenant_id).get_by_id(order_id, cross_tenant=False)
        if trf_result is not None:
            trf, revision = trf_result
            if revision is not None and revision.created_at is not None:
                events.append(
                    TimelineEvent(
                        timestamp=revision.created_at,
                        event_type="REVISION",
                        action=(revision.status or "UNKNOWN"),
                        description=f"TRF {trf.order_number} revision {revision.revision_no}",
                        user_id=str(revision.created_by) if revision.created_by else None,
                        details={"revision_no": revision.revision_no, "status": revision.status},
                    )
                )

        audit_events = AuditService(self.db, tenant_id=self.tenant_id).get_for_entity(
            "TRF",
            order_id,
            limit=500,
        )
        for event in audit_events:
            if event.created_at is None:
                continue
            events.append(
                TimelineEvent(
                    timestamp=event.created_at,
                    event_type="AUDIT",
                    action=event.action,
                    description=f"{event.action}: {event.entity_type or 'TRF'}",
                    user_id=event.user_id,
                    details=event.details,
                )
            )

        events.sort(key=lambda item: item.timestamp)
        return events
