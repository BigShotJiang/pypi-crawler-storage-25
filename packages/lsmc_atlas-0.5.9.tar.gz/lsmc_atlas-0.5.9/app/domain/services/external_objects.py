"""Service layer for Bloom external object mappings and integration config."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any


def _require_https_url(value: str, *, field_name: str) -> str:
    normalized = str(value or "").strip()
    if not normalized:
        raise ValueError(f"{field_name} is required")
    if not normalized.startswith("https://"):
        raise ValueError(f"{field_name} must use an absolute https:// URL")
    return normalized.rstrip("/")


@dataclass
class ExternalObjectUpsert:
    """Data needed to upsert an external object mapping."""

    provider: str
    object_type: str
    external_euid: str
    status: str = "active"
    is_deleted: bool = False
    metadata: dict[str, Any] | None = None
    version: int = 1


@dataclass
class ExternalObjectRelationCreate:
    """Data for mapping an external object to a local Atlas entity."""

    external_object_id: str
    relation_type: str
    local_entity_type: str
    local_entity_id: str
    metadata: dict[str, Any] | None = None


@dataclass
class OrgBloomConfigUpsert:
    """Data for per-organization Bloom integration settings."""

    enabled: bool
    bloom_base_url: str
    bloom_api_key_secret_ref: str
    bloom_webhook_secret_ref: str | None = None
    bloom_service_user: str | None = None
    last_verified_at: datetime | None = None
    metadata: dict[str, Any] | None = None


@dataclass
class SiteBloomConfigUpsert:
    """Data for per-site Bloom integration settings."""

    enabled: bool
    bloom_base_url: str
    bloom_api_key_secret_ref: str
    bloom_webhook_secret_ref: str | None = None
    bloom_service_user: str | None = None
    last_verified_at: datetime | None = None
    metadata: dict[str, Any] | None = None


@dataclass
class EffectiveBloomConfig:
    """Resolved Bloom configuration after applying site override rules."""

    scope: str
    organization_id: uuid.UUID
    site_id: str | None
    enabled: bool
    bloom_base_url: str
    bloom_api_key_secret_ref: str
    bloom_webhook_secret_ref: str | None = None
    bloom_service_user: str | None = None
    last_verified_at: datetime | None = None
    metadata: dict[str, Any] | None = None


class ExternalObjectService:
    """Application service for Bloom integration state."""

    def __init__(self, db: Any, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._repo: Any | None = None

    def _repository(self):
        if self._repo is None:
            from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

            self._repo = TapdbExternalObjectRepository(self.db)
        return self._repo

    def upsert_external_object(
        self,
        data: ExternalObjectUpsert,
        actor_id: uuid.UUID | None = None,
    ):
        return self._repository().create_or_update_external_object(
            tenant_id=self.tenant_id,
            provider=data.provider,
            object_type=data.object_type,
            external_euid=data.external_euid,
            status=data.status,
            is_deleted=data.is_deleted,
            metadata=data.metadata,
            version=data.version,
            actor_id=actor_id,
        )

    def get_external_object(self, provider: str, object_type: str, external_euid: str):
        return self._repository().get_external_object_by_euid(
            tenant_id=self.tenant_id,
            provider=provider,
            object_type=object_type,
            external_euid=external_euid,
        )

    def get_external_object_by_id(self, external_object_id: str):
        return self._repository().get_external_object_by_id(external_object_id)

    def list_external_objects(
        self,
        provider: str | None = None,
        object_type: str | None = None,
        include_deleted: bool = False,
    ):
        return self._repository().list_external_objects(
            tenant_id=self.tenant_id,
            provider=provider,
            object_type=object_type,
            include_deleted=include_deleted,
        )

    def create_relation(
        self,
        data: ExternalObjectRelationCreate,
        actor_id: uuid.UUID | None = None,
    ):
        return self._repository().create_relation(
            tenant_id=self.tenant_id,
            external_object_id=data.external_object_id,
            relation_type=data.relation_type,
            local_entity_type=data.local_entity_type,
            local_entity_id=data.local_entity_id,
            metadata=data.metadata,
            actor_id=actor_id,
        )

    def list_relations_for_external_object(self, external_object_id: str):
        return self._repository().list_relations_for_external_object(external_object_id)

    def list_relations_for_local_entity(self, local_entity_type: str, local_entity_id: str):
        return self._repository().list_relations_for_local_entity(
            tenant_id=self.tenant_id,
            local_entity_type=local_entity_type,
            local_entity_id=local_entity_id,
        )

    def delete_relation(
        self,
        *,
        external_object_id: str,
        relation_type: str,
        local_entity_id: str,
    ) -> bool:
        return self._repository().delete_relation(
            tenant_id=self.tenant_id,
            external_object_id=external_object_id,
            relation_type=relation_type,
            local_entity_id=local_entity_id,
        )

    def validate_container_relation_payload(
        self,
        *,
        trf_id: str | None = None,
        test_ids: list[str] | None = None,
        testkit_id: str | None = None,
        shipment_id: str | None = None,
        site_id: str | None = None,
    ) -> None:
        clean_trf_id = str(trf_id or "").strip() or None
        clean_test_ids = [
            str(test_id).strip() for test_id in (test_ids or []) if str(test_id).strip()
        ]
        clean_testkit_id = str(testkit_id or "").strip() or None
        clean_shipment_id = str(shipment_id or "").strip() or None
        clean_site_id = str(site_id or "").strip() or None
        if not any(
            (
                clean_trf_id,
                clean_test_ids,
                clean_testkit_id,
                clean_shipment_id,
                clean_site_id,
            )
        ):
            raise ValueError("container must be linked to at least one anchor")

    def validate_specimen_relation_payload(
        self,
        *,
        collection_event_id: str | None = None,
        patient_id: str | None = None,
        container_euid: str | None,
    ) -> None:
        if collection_event_id is None and patient_id is None:
            raise ValueError("specimen must be linked to a collection event")
        if not container_euid:
            raise ValueError("specimen must be linked to a container")


class OrgBloomConfigService:
    """Service for org-level Bloom integration settings."""

    def __init__(self, db: Any):
        self.db = db
        self._repo: Any | None = None

    def _repository(self):
        if self._repo is None:
            from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

            self._repo = TapdbExternalObjectRepository(self.db)
        return self._repo

    def upsert(
        self,
        organization_id: str,
        data: OrgBloomConfigUpsert,
        actor_id: uuid.UUID | None = None,
    ):
        bloom_base_url = _require_https_url(
            data.bloom_base_url,
            field_name="bloom_base_url",
        )
        return self._repository().upsert_org_bloom_config(
            organization_id=organization_id,
            enabled=data.enabled,
            bloom_base_url=bloom_base_url,
            bloom_api_key_secret_ref=data.bloom_api_key_secret_ref,
            bloom_webhook_secret_ref=data.bloom_webhook_secret_ref,
            bloom_service_user=data.bloom_service_user,
            last_verified_at=data.last_verified_at,
            metadata=data.metadata,
            actor_id=actor_id,
        )

    def get(self, organization_id: str):
        return self._repository().get_org_bloom_config(organization_id)

    def list_enabled(self):
        return self._repository().list_enabled_bloom_configs()

    def validate_enabled_configs(self) -> list[str]:
        errors: list[str] = []
        for cfg in self.list_enabled():
            missing: list[str] = []
            if not cfg.bloom_base_url:
                missing.append("bloom_base_url")
            if not cfg.bloom_api_key_secret_ref:
                missing.append("bloom_api_key_secret_ref")
            if missing:
                errors.append(
                    f"organization {cfg.organization_id}: missing required fields {', '.join(missing)}"
                )
        return errors

    def mark_webhook_event_received(
        self,
        *,
        provider: str,
        tenant_id: uuid.UUID,
        event_id: str,
    ) -> bool:
        return self._repository().mark_webhook_event_received(
            provider=provider,
            tenant_id=tenant_id,
            event_id=event_id,
        )


class SiteBloomConfigService:
    """Service for site-level Bloom integration settings."""

    def __init__(self, db: Any):
        self.db = db
        self._repo: Any | None = None

    def _repository(self):
        if self._repo is None:
            from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

            self._repo = TapdbExternalObjectRepository(self.db)
        return self._repo

    def upsert(
        self,
        site_id: str,
        organization_id: uuid.UUID,
        data: SiteBloomConfigUpsert,
        actor_id: uuid.UUID | None = None,
    ):
        bloom_base_url = _require_https_url(
            data.bloom_base_url,
            field_name="bloom_base_url",
        )
        return self._repository().upsert_site_bloom_config(
            site_id=site_id,
            organization_id=organization_id,
            enabled=data.enabled,
            bloom_base_url=bloom_base_url,
            bloom_api_key_secret_ref=data.bloom_api_key_secret_ref,
            bloom_webhook_secret_ref=data.bloom_webhook_secret_ref,
            bloom_service_user=data.bloom_service_user,
            last_verified_at=data.last_verified_at,
            metadata=data.metadata,
            actor_id=actor_id,
        )

    def get(self, site_id: str):
        return self._repository().get_site_bloom_config(site_id)

    def list_enabled(self, organization_id: uuid.UUID | None = None):
        return self._repository().list_enabled_site_bloom_configs(organization_id=organization_id)

    def validate_enabled_configs(self) -> list[str]:
        errors: list[str] = []
        for cfg in self.list_enabled():
            missing: list[str] = []
            if not cfg.bloom_base_url:
                missing.append("bloom_base_url")
            if not cfg.bloom_api_key_secret_ref:
                missing.append("bloom_api_key_secret_ref")
            if missing:
                errors.append(f"site {cfg.site_id}: missing required fields {', '.join(missing)}")
        return errors


class BloomConfigResolverService:
    """Resolve the effective Bloom configuration for an org and optional site."""

    def __init__(self, db: Any):
        self.db = db
        self.org_configs = OrgBloomConfigService(db)
        self.site_configs = SiteBloomConfigService(db)

    def get_effective(
        self,
        *,
        organization_id: uuid.UUID,
        site_id: str | None = None,
    ) -> EffectiveBloomConfig | None:
        if site_id:
            site_cfg = self.site_configs.get(site_id)
            if (
                site_cfg is not None
                and site_cfg.enabled
                and site_cfg.organization_id == organization_id
            ):
                return EffectiveBloomConfig(
                    scope="site",
                    organization_id=site_cfg.organization_id,
                    site_id=site_cfg.site_id,
                    enabled=site_cfg.enabled,
                    bloom_base_url=site_cfg.bloom_base_url,
                    bloom_api_key_secret_ref=site_cfg.bloom_api_key_secret_ref,
                    bloom_webhook_secret_ref=site_cfg.bloom_webhook_secret_ref,
                    bloom_service_user=site_cfg.bloom_service_user,
                    last_verified_at=site_cfg.last_verified_at,
                    metadata=site_cfg.metadata,
                )

        org_cfg = self.org_configs.get(organization_id)
        if org_cfg is None or not org_cfg.enabled:
            return None

        return EffectiveBloomConfig(
            scope="organization",
            organization_id=org_cfg.organization_id,
            site_id=None,
            enabled=org_cfg.enabled,
            bloom_base_url=org_cfg.bloom_base_url,
            bloom_api_key_secret_ref=org_cfg.bloom_api_key_secret_ref,
            bloom_webhook_secret_ref=org_cfg.bloom_webhook_secret_ref,
            bloom_service_user=org_cfg.bloom_service_user,
            last_verified_at=org_cfg.last_verified_at,
            metadata=org_cfg.metadata,
        )
