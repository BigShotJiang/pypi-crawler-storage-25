"""LSMC Hub - User API Token Service.

Provides operations for:
- Creating personal API tokens for users with API_ACCESS group membership
- Validating and authenticating with user API tokens
- Revoking tokens
- Tracking token usage
"""

from __future__ import annotations

import hmac
import secrets
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from app.auth.rbac import Role
from app.domain.enums import AuditAction, SystemGroup, TokenScope, TokenStatus
from app.domain.services.audit_utils import log_tapdb_audit_event
from app.persistence.tapdb.groups import TapdbUserGroupRepository
from app.persistence.tapdb.user_api_tokens import TapdbUserAPITokenRepository

# Token prefix for easy identification in logs
TOKEN_PREFIX = "lsmc_"


def generate_token() -> str:
    """Generate a secure random API token.

    Returns a prefixed token with 64-character hex string (256 bits of entropy).
    Format: lsmc_<64 hex chars>
    """
    return TOKEN_PREFIX + secrets.token_hex(32)


def hash_token(token: str) -> str:
    """Hash a token for storage.

    Uses HMAC-SHA256 with a static application key to avoid weak-hash
    findings while keeping the operation fast for token lookups.
    """
    _HMAC_KEY = b"atlas-user-token-key-v1"
    return hmac.new(_HMAC_KEY, token.encode(), "sha256").hexdigest()


def get_token_display_prefix(token: str) -> str:
    """Get a safe prefix of a token for display purposes.

    Returns the first 12 characters of the token (e.g., "lsmc_abc123...")
    """
    return token[:12] + "..."


# Mapping of token scopes to the roles allowed to create them
SCOPE_ALLOWED_CREATORS: dict[str, set[str]] = {
    TokenScope.EXT_ORG.value: {Role.EXTERNAL_USER_ADMIN.value, Role.ADMIN.value},
    TokenScope.LSMC_INTERNAL.value: {Role.INTERNAL_USER.value, Role.ADMIN.value},
    TokenScope.ATLAS_ADMIN.value: {Role.ADMIN.value},
}


@dataclass
class TokenCreate:
    """Data for creating a user API token."""

    token_name: str
    expires_in_days: int = 90  # Default 90 days
    scope: str = TokenScope.EXT_ORG.value  # Default to most restrictive scope


@dataclass
class TokenInfo:
    """Token information DTO."""

    id: str
    user_id: str
    token_name: str
    token_prefix: str
    status: str
    created_at: datetime
    expires_at: datetime
    last_used_at: datetime | None
    revoked_at: datetime | None
    revocation_reason: str | None
    is_expired: bool
    usage_count: int = 0


@dataclass
class TokenValidationResult:
    """Result of token validation."""

    is_valid: bool
    token_id: str | None = None
    user_id: str | None = None
    tenant_id: uuid.UUID | None = None
    scope: str | None = None  # TokenScope value
    error: str | None = None


class UserAPITokenService:
    """Service for user API token operations."""

    def __init__(self, db: Any, tenant_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self._token_repo: TapdbUserAPITokenRepository | None = None
        self._group_repo: TapdbUserGroupRepository | None = None

    def _repo(self) -> TapdbUserAPITokenRepository:
        if self._token_repo is None:
            self._token_repo = TapdbUserAPITokenRepository(self.db)
        return self._token_repo

    def _groups(self) -> TapdbUserGroupRepository:
        if self._group_repo is None:
            # Membership checks work across system and tenant groups.
            self._group_repo = TapdbUserGroupRepository(self.db, self.tenant_id)
        return self._group_repo

    def user_has_api_access(self, user_id: uuid.UUID) -> bool:
        """Check if user has API_ACCESS group membership."""
        api_group = self._groups().get_group_by_code(SystemGroup.API_ACCESS.value)
        if not api_group:
            return False
        memberships = self._groups().list_group_members(api_group.euid)
        return any(m.user_id == user_id and m.is_active for m in memberships)

    @staticmethod
    def validate_scope_for_creator(scope: str, creator_roles: list[str]) -> bool:
        """Check if a user with the given roles is allowed to create a token with this scope.

        Returns True if allowed, False otherwise.
        """
        allowed_roles = SCOPE_ALLOWED_CREATORS.get(scope)
        if allowed_roles is None:
            return False  # Unknown scope
        return bool(set(creator_roles) & allowed_roles)

    def create(
        self,
        user_id: uuid.UUID,
        data: TokenCreate,
        created_by: uuid.UUID | None = None,
    ):
        """Create a new API token for a user.

        Returns:
            Tuple of (token, revision, plaintext_token)
            The plaintext token is only returned once.
        """
        if not self.tenant_id:
            raise ValueError("tenant_id is required")

        # Validate scope
        scope = data.scope or TokenScope.EXT_ORG.value
        if scope not in {s.value for s in TokenScope}:
            raise ValueError(f"Invalid token scope: {scope}")

        plaintext_token = generate_token()
        hashed_token = hash_token(plaintext_token)
        token_prefix = get_token_display_prefix(plaintext_token)
        expires_at = datetime.now(UTC) + timedelta(days=data.expires_in_days)

        token, revision = self._repo().create_token(
            tenant_id=self.tenant_id,
            user_id=str(user_id),
            token_name=data.token_name,
            token_prefix=token_prefix,
            scope=scope,
            token_hash=hashed_token,
            expires_at=expires_at,
            created_by=str(created_by or user_id),
            note=f"Token created with {data.expires_in_days} day expiration",
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=created_by or user_id,
            action=AuditAction.CREATE,
            entity_type="UserAPIToken",
            entity_id=token.euid,
            details={
                "token_name": data.token_name,
                "expires_in_days": data.expires_in_days,
                "scope": scope,
            },
        )
        self.db.commit()

        return token, revision, plaintext_token

    def list_user_tokens(self, user_id: uuid.UUID) -> list[TokenInfo]:
        """List all tokens for a user."""
        tokens = self._repo().list_tokens(
            tenant_id=self.tenant_id,
            user_id=str(user_id),
            skip=0,
            limit=1_000_000,
        )

        now = datetime.now(UTC)
        results: list[TokenInfo] = []
        for token in tokens:
            revision = self._repo().get_latest_revision(token.euid)
            if not revision:
                continue
            usage_count = self._repo().count_usage(token.euid)
            is_expired = revision.expires_at < now or revision.status == TokenStatus.EXPIRED.value
            results.append(
                TokenInfo(
                    id=token.euid,
                    user_id=token.user_id,
                    token_name=token.token_name,
                    token_prefix=token.token_prefix,
                    status=revision.status,
                    created_at=token.created_at or datetime.now(UTC),
                    expires_at=revision.expires_at,
                    last_used_at=revision.last_used_at,
                    revoked_at=revision.revoked_at,
                    revocation_reason=revision.revocation_reason,
                    is_expired=is_expired,
                    usage_count=usage_count,
                )
            )
        return results

    def get_token(self, token_id: str):
        """Get a token by ID with latest revision."""
        return self._repo().get_token(token_id, self.tenant_id)

    def revoke(
        self,
        token_id: str,
        revoked_by: uuid.UUID,
        reason: str | None = None,
    ):
        """Revoke a token."""
        result = self.get_token(token_id)
        if not result:
            return None

        token, current_revision = result
        if current_revision.status == TokenStatus.REVOKED.value:
            return token, current_revision

        now = datetime.now(UTC)
        new_revision = self._repo().create_revision(
            token_id=token_id,
            revision_no=current_revision.revision_no + 1,
            token_hash=current_revision.token_hash,
            status=TokenStatus.REVOKED.value,
            expires_at=current_revision.expires_at,
            last_used_at=current_revision.last_used_at,
            revoked_at=now,
            revoked_by=str(revoked_by),
            revocation_reason=reason,
            created_by=str(revoked_by),
            note="Token revoked",
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=token.tenant_id,
            user_id=revoked_by,
            action=AuditAction.UPDATE,
            entity_type="UserAPIToken",
            entity_id=token_id,
            details={"action": "REVOKE", "reason": reason},
        )
        self.db.commit()

        return token, new_revision

    def validate(self, plaintext_token: str) -> TokenValidationResult:
        """Validate an API token and return validation result.

        This method does NOT require tenant_id to be set on the service.
        """
        if not plaintext_token.startswith(TOKEN_PREFIX):
            return TokenValidationResult(is_valid=False, error="Invalid token format")

        hashed_token = hash_token(plaintext_token)
        revision = self._repo().find_latest_revision_by_hash(hashed_token)
        if not revision:
            return TokenValidationResult(is_valid=False, error="Token not found")

        if revision.status == TokenStatus.REVOKED.value:
            return TokenValidationResult(is_valid=False, error="Token has been revoked")

        now = datetime.now(UTC)
        if revision.expires_at < now:
            return TokenValidationResult(is_valid=False, error="Token has expired")

        token_result = self._repo().get_token(revision.token_id, tenant_id=None)
        if not token_result:
            return TokenValidationResult(is_valid=False, error="Token not found")
        token, _ = token_result

        return TokenValidationResult(
            is_valid=True,
            token_id=token.euid,
            user_id=token.user_id,
            tenant_id=token.tenant_id,
            scope=getattr(token, "scope", None),
        )

    def update_last_used(self, token_id: str) -> None:
        """Update the last_used_at timestamp for a token.

        Creates a new revision with updated last_used_at.
        """
        result = self.get_token(token_id)
        if not result:
            # Validation paths call with tenantless service; retry without tenant filtering.
            result = self._repo().get_token(token_id, tenant_id=None)
        if not result:
            return

        _, current_revision = result
        now = datetime.now(UTC)

        self._repo().create_revision(
            token_id=token_id,
            revision_no=current_revision.revision_no + 1,
            token_hash=current_revision.token_hash,
            status=current_revision.status,
            expires_at=current_revision.expires_at,
            last_used_at=now,
            revoked_at=current_revision.revoked_at,
            revoked_by=current_revision.revoked_by,
            revocation_reason=current_revision.revocation_reason,
            created_by=None,
            note="Last used timestamp updated",
        )

    def log_usage(
        self,
        token_id: str,
        tenant_id: uuid.UUID,
        endpoint: str,
        http_method: str,
        response_status: int,
        ip_address: str | None = None,
        user_agent: str | None = None,
        request_metadata: dict | None = None,
    ) -> None:
        """Log API usage for a token."""
        self._repo().log_usage(
            tenant_id=tenant_id,
            token_id=token_id,
            endpoint=endpoint,
            http_method=http_method,
            response_status=response_status,
            ip_address=ip_address,
            user_agent=user_agent,
            request_metadata=request_metadata,
        )

    def get_usage_logs(
        self,
        token_id: str,
        limit: int = 100,
    ):
        """Get usage logs for a specific token."""
        return self._repo().get_usage_logs(token_id=token_id, limit=limit)

    def get_usage_stats(self, token_id: str) -> dict:
        """Get usage statistics for a token."""
        return self._repo().get_usage_stats(token_id)

    # Admin methods

    def list_all_tokens(
        self,
        user_id_filter: str | None = None,
        status_filter: str | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> list[TokenInfo]:
        """List all tokens (admin only).

        Requires tenant_id to be set on the service.
        """
        if not self.tenant_id:
            raise ValueError("tenant_id is required for admin operations")

        tokens = self._repo().list_tokens(
            tenant_id=self.tenant_id,
            user_id=user_id_filter,
            skip=skip,
            limit=limit,
        )

        now = datetime.now(UTC)
        results: list[TokenInfo] = []
        for token in tokens:
            revision = self._repo().get_latest_revision(token.euid)
            if not revision:
                continue
            if status_filter and revision.status != status_filter:
                continue

            usage_count = self._repo().count_usage(token.euid)
            is_expired = revision.expires_at < now or revision.status == TokenStatus.EXPIRED.value
            results.append(
                TokenInfo(
                    id=token.euid,
                    user_id=token.user_id,
                    token_name=token.token_name,
                    token_prefix=token.token_prefix,
                    status=revision.status,
                    created_at=token.created_at or datetime.now(UTC),
                    expires_at=revision.expires_at,
                    last_used_at=revision.last_used_at,
                    revoked_at=revision.revoked_at,
                    revocation_reason=revision.revocation_reason,
                    is_expired=is_expired,
                    usage_count=usage_count,
                )
            )

        return results

    def count_tokens(self, user_id: str | None = None) -> int:
        """Count tokens for a user or all tokens in tenant."""
        return self._repo().count_tokens(tenant_id=self.tenant_id, user_id=user_id)
