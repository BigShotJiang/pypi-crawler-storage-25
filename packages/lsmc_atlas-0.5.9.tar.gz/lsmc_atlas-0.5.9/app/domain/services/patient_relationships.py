"""Patient ↔ family and patient ↔ patient relationship services (TapDB lineage)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select

from app.persistence.tapdb.euid_helpers import get_instance_by_euid
from app.persistence.tapdb.families import FAMILY_TEMPLATE_CODE
from app.persistence.tapdb.people import PATIENT_TEMPLATE_CODE, TapdbPeopleRepository

# Relationship types (TapDB lineage)
REL_MEMBER_OF_FAMILY = "member_of_family"
REL_FATHER_OF = "father_of"
REL_MOTHER_OF = "mother_of"
REL_SIBLING_OF = "sibling_of"


@dataclass(frozen=True)
class PatientFamilyGraph:
    family_ids: list[str]
    father_id: str | None
    mother_id: str | None
    sibling_ids: list[str]


class PatientRelationshipService:
    """Graph-native patient relationships using TapDB lineage edges."""

    def __init__(self, db: Any, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._people_repo: TapdbPeopleRepository | None = None
        self._family_repo: Any | None = None

    def _people(self) -> TapdbPeopleRepository:
        if self._people_repo is None:
            self._people_repo = TapdbPeopleRepository(self.db)
        return self._people_repo

    def _families(self):
        if self._family_repo is None:
            from app.persistence.tapdb.families import TapdbFamilyRepository

            self._family_repo = TapdbFamilyRepository(self.db)
        return self._family_repo

    def _euid(self, instance: generic_instance) -> str:
        """Return the EUID string for the given instance."""
        return instance.euid

    def _find_patient_instance(self, patient_euid: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, PATIENT_TEMPLATE_CODE, patient_euid)

    def _find_family_instance(self, family_euid: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, FAMILY_TEMPLATE_CODE, family_euid)

    def _get_visible_instance_by_uid(self, instance_uid: int) -> generic_instance | None:
        stmt = (
            select(generic_instance)
            .where(generic_instance.uid == instance_uid, generic_instance.is_deleted.is_(False))
            .limit(1)
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def _ensure_link(
        self,
        *,
        parent: generic_instance,
        child: generic_instance,
        relationship_type: str,
        properties: dict[str, Any] | None = None,
    ) -> generic_instance_lineage:
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == parent.uid,
                generic_instance_lineage.child_instance_uid == child.uid,
                generic_instance_lineage.relationship_type == relationship_type,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is not None and not existing.is_deleted:
            return existing
        if existing is not None and existing.is_deleted:
            existing.is_deleted = False
            if properties:
                existing.json_addl = {"properties": dict(properties)}
            self.db.flush()
            return existing

        lineage = self.factory.link_instances(
            session=self.db,
            parent=parent,
            child=child,
            relationship_type=relationship_type,
        )
        if properties:
            lineage.json_addl = {"properties": dict(properties)}
        self.db.flush()
        return lineage

    def add_patient_to_family(self, *, patient_euid: str, family_euid: str) -> None:
        patient = self._find_patient_instance(patient_euid)
        if patient is None:
            raise ValueError(f"Patient not found: {patient_euid}")
        family = self._find_family_instance(family_euid)
        if family is None:
            raise ValueError(f"Family not found: {family_euid}")
        self._ensure_link(parent=family, child=patient, relationship_type=REL_MEMBER_OF_FAMILY)

    def set_father(self, *, child_patient_euid: str, father_patient_euid: str) -> None:
        child = self._find_patient_instance(child_patient_euid)
        father = self._find_patient_instance(father_patient_euid)
        if child is None:
            raise ValueError(f"Patient not found: {child_patient_euid}")
        if father is None:
            raise ValueError(f"Patient not found: {father_patient_euid}")
        self._ensure_link(parent=father, child=child, relationship_type=REL_FATHER_OF)

    def set_mother(self, *, child_patient_euid: str, mother_patient_euid: str) -> None:
        child = self._find_patient_instance(child_patient_euid)
        mother = self._find_patient_instance(mother_patient_euid)
        if child is None:
            raise ValueError(f"Patient not found: {child_patient_euid}")
        if mother is None:
            raise ValueError(f"Patient not found: {mother_patient_euid}")
        self._ensure_link(parent=mother, child=child, relationship_type=REL_MOTHER_OF)

    def add_sibling_pair(self, *, patient_euid_a: str, patient_euid_b: str) -> None:
        if patient_euid_a == patient_euid_b:
            raise ValueError("Cannot sibling-link a patient to itself")
        a = self._find_patient_instance(patient_euid_a)
        b = self._find_patient_instance(patient_euid_b)
        if a is None or b is None:
            raise ValueError("Patient not found")
        self._ensure_link(parent=b, child=a, relationship_type=REL_SIBLING_OF)
        self._ensure_link(parent=a, child=b, relationship_type=REL_SIBLING_OF)

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def get_patient_family_graph(self, patient_euid: str) -> PatientFamilyGraph:
        patient = self._find_patient_instance(patient_euid)
        if patient is None:
            raise ValueError(f"Patient not found: {patient_euid}")

        family_ids: list[str] = []
        father_id: str | None = None
        mother_id: str | None = None
        sibling_ids: list[str] = []

        stmt = select(generic_instance_lineage).where(
            generic_instance_lineage.child_instance_uid == patient.uid,
            generic_instance_lineage.is_deleted.is_(False),
            generic_instance_lineage.relationship_type.in_(
                [REL_MEMBER_OF_FAMILY, REL_FATHER_OF, REL_MOTHER_OF, REL_SIBLING_OF]
            ),
        )
        edges = list(self.db.execute(stmt).scalars().all())
        for edge in edges:
            parent_inst = self._get_visible_instance_by_uid(edge.parent_instance_uid)
            if parent_inst is None:
                continue

            if edge.relationship_type == REL_MEMBER_OF_FAMILY:
                family_ids.append(self._euid(parent_inst))
            elif edge.relationship_type == REL_FATHER_OF:
                father_id = self._euid(parent_inst)
            elif edge.relationship_type == REL_MOTHER_OF:
                mother_id = self._euid(parent_inst)
            elif edge.relationship_type == REL_SIBLING_OF:
                sibling_ids.append(self._euid(parent_inst))

        # de-dupe deterministically
        family_ids = sorted(set(family_ids))
        sibling_ids = sorted(set(sibling_ids))
        return PatientFamilyGraph(
            family_ids=family_ids,
            father_id=father_id,
            mother_id=mother_id,
            sibling_ids=sibling_ids,
        )

    def list_family_member_euids(self, family_euid: str) -> list[str]:
        family = self._find_family_instance(family_euid)
        if family is None:
            return []
        stmt = select(generic_instance_lineage).where(
            generic_instance_lineage.parent_instance_uid == family.uid,
            generic_instance_lineage.relationship_type == REL_MEMBER_OF_FAMILY,
            generic_instance_lineage.is_deleted.is_(False),
        )
        edges = list(self.db.execute(stmt).scalars().all())
        member_euids: list[str] = []
        for edge in edges:
            child_inst = self._get_visible_instance_by_uid(edge.child_instance_uid)
            if child_inst is None:
                continue
            template_code = f"{child_inst.category}/{child_inst.type}/{child_inst.subtype}/{child_inst.version}/"
            if template_code != PATIENT_TEMPLATE_CODE:
                continue
            member_euids.append(self._euid(child_inst))
        member_euids = sorted(set(member_euids))
        return member_euids
