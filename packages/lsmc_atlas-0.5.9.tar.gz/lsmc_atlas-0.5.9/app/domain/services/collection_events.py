"""Atlas collection event services."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from app.domain.enums import AuditAction


@dataclass
class CollectionEventCreate:
    patient_euid: str
    site_euid: str
    container_euid: str
    specimen_euid: str | None = None
    collected_at: datetime | None = None
    collection_type: str | None = None
    collected_by: str | None = None
    expected_mrn: str | None = None
    expected_dob: str | None = None
    expected_name: str | None = None
    expected_label_text: str | None = None


@dataclass
class CollectionEventUpdate:
    collected_at: datetime | None = None
    collection_type: str | None = None
    collected_by: str | None = None
    expected_mrn: str | None = None
    expected_dob: str | None = None
    expected_name: str | None = None
    expected_label_text: str | None = None
    note: str | None = None


class CollectionEventService:
    """Service for Atlas collection-event persistence."""

    def __init__(self, db: Any, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._repo: Any | None = None

    def _repo_impl(self):
        if self._repo is None:
            from app.persistence.tapdb.collection_events import TapdbCollectionEventRepository

            self._repo = TapdbCollectionEventRepository(self.db)
        return self._repo

    def _log_audit_event(
        self,
        *,
        action: AuditAction,
        entity_id: str,
        user_id: uuid.UUID | None,
        details: dict | None = None,
    ) -> None:
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db, tenant_id=self.tenant_id, user_id=str(user_id) if user_id else None
            ).log(
                action=action,
                entity_type="CollectionEvent",
                entity_id=entity_id,
                details=details,
                user_id=user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()

    def create(
        self,
        data: CollectionEventCreate,
        *,
        created_by: uuid.UUID | None = None,
    ):
        from app.domain.services.people import PatientService
        from app.domain.services.site_scope import resolve_tenant_site_euid

        patient = PatientService(self.db, self.tenant_id).get_by_id(
            data.patient_euid, cross_tenant=False
        )
        if patient is None:
            raise ValueError(f"Patient not found: {data.patient_euid}")
        resolved_site = resolve_tenant_site_euid(self.db, self.tenant_id, data.site_euid)
        event, revision = self._repo_impl().create(
            tenant_id=self.tenant_id,
            patient_id=data.patient_euid,
            site_id=resolved_site,
            container_euid=data.container_euid,
            specimen_euid=data.specimen_euid,
            data=CollectionEventCreate(
                **{
                    **data.__dict__,
                    "site_euid": resolved_site,
                    "collected_at": data.collected_at or datetime.now(UTC),
                }
            ),
            created_by=created_by,
        )
        self._log_audit_event(
            action=AuditAction.CREATE,
            entity_id=event.euid,
            user_id=created_by,
            details={
                "patient_euid": data.patient_euid,
                "site_euid": resolved_site,
                "container_euid": data.container_euid,
            },
        )
        return event, revision

    def get(self, collection_event_id: str):
        return self._repo_impl().get(
            collection_event_id=collection_event_id,
            tenant_id=self.tenant_id,
        )

    def list(
        self,
        *,
        patient_euid: str | None = None,
        container_euid: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ):
        return self._repo_impl().list(
            tenant_id=self.tenant_id,
            patient_id=patient_euid,
            container_euid=container_euid,
            limit=limit,
            offset=offset,
        )

    def update(
        self,
        collection_event_id: str,
        data: CollectionEventUpdate,
        *,
        updated_by: uuid.UUID | None = None,
    ):
        if data.collected_at is None:
            current = self.get(collection_event_id)
            if current is not None and current[1].collected_at is None:
                data.collected_at = datetime.now(UTC)
        result = self._repo_impl().update(
            tenant_id=self.tenant_id,
            collection_event_id=collection_event_id,
            data=data,
            updated_by=updated_by,
        )
        if result is None:
            return None
        event, revision = result
        self._log_audit_event(
            action=AuditAction.UPDATE,
            entity_id=collection_event_id,
            user_id=updated_by,
            details={"container_euid": event.container_euid},
        )
        return event, revision

    def attach_specimen(
        self,
        collection_event_id: str,
        specimen_euid: str,
        *,
        updated_by: uuid.UUID | None = None,
    ):
        event = self._repo_impl().set_specimen_euid(
            tenant_id=self.tenant_id,
            collection_event_id=collection_event_id,
            specimen_euid=specimen_euid,
        )
        if event is None:
            return None
        self._log_audit_event(
            action=AuditAction.UPDATE,
            entity_id=collection_event_id,
            user_id=updated_by,
            details={"specimen_euid": specimen_euid},
        )
        return event
