"""Helpers for building canonical story-graph projections."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class BloomStoryContext:
    specimen_content_id: str = ""
    specimen_container_id: str = ""
    extraction_output_id: str = ""
    extraction_container_id: str = ""
    extraction_container_parent_id: str = ""
    library_prep_output_id: str = ""
    library_material_id: str = ""
    library_container_id: str = ""
    library_container_parent_id: str = ""
    pool_content_id: str = ""
    pool_container_id: str = ""
    run_id: str = ""
    fastq_ids: tuple[str, ...] = ()


def add_bloom_story_edges(
    add_edge: Callable[[str, str, str], None],
    *,
    context: BloomStoryContext,
) -> None:
    """Emit the canonical Bloom-side story edges for a resolved run path."""

    specimen_content_id = str(context.specimen_content_id or "").strip()
    specimen_container_id = str(context.specimen_container_id or "").strip()
    extraction_output_id = str(context.extraction_output_id or "").strip()
    extraction_container_id = str(context.extraction_container_id or "").strip()
    extraction_container_parent_id = str(context.extraction_container_parent_id or "").strip()
    library_prep_output_id = str(context.library_prep_output_id or "").strip()
    library_material_id = str(context.library_material_id or "").strip()
    library_container_id = str(context.library_container_id or "").strip()
    library_container_parent_id = str(context.library_container_parent_id or "").strip()
    pool_content_id = str(context.pool_content_id or "").strip()
    pool_container_id = str(context.pool_container_id or "").strip()
    run_id = str(context.run_id or "").strip()
    fastq_ids = tuple(
        str(node_id or "").strip() for node_id in context.fastq_ids if str(node_id or "").strip()
    )

    if specimen_content_id and specimen_container_id:
        add_edge(specimen_content_id, specimen_container_id, "contained_in")

    if specimen_content_id and extraction_output_id:
        add_edge(specimen_content_id, extraction_output_id, "extraction_output")

    if extraction_output_id and extraction_container_id:
        add_edge(extraction_output_id, extraction_container_id, "aliquoted_to_well")

    if extraction_container_parent_id and extraction_container_id:
        add_edge(extraction_container_parent_id, extraction_container_id, "contains_well")

    if specimen_container_id and extraction_container_id:
        add_edge(specimen_container_id, extraction_container_id, "container_parent_of")

    if extraction_output_id and library_prep_output_id:
        add_edge(extraction_output_id, library_prep_output_id, "library_prep_output")

    if extraction_output_id and library_material_id:
        add_edge(extraction_output_id, library_material_id, "content_parent_of")

    if library_prep_output_id and library_material_id:
        add_edge(library_prep_output_id, library_material_id, "library_material_output")

    if library_material_id and library_container_id:
        add_edge(library_material_id, library_container_id, "contained_in")

    if library_container_parent_id and library_container_id:
        add_edge(library_container_parent_id, library_container_id, "contains_well")

    if extraction_container_id and library_container_id:
        add_edge(extraction_container_id, library_container_id, "container_parent_of")

    if library_material_id and pool_content_id:
        add_edge(library_material_id, pool_content_id, "content_parent_of")
    elif extraction_output_id and pool_content_id:
        add_edge(extraction_output_id, pool_content_id, "content_parent_of")

    if library_container_id and pool_container_id:
        add_edge(library_container_id, pool_container_id, "container_parent_of")
    elif extraction_container_id and pool_container_id:
        add_edge(extraction_container_id, pool_container_id, "container_parent_of")

    if pool_content_id and pool_container_id:
        add_edge(pool_content_id, pool_container_id, "contained_in")

    if pool_content_id and run_id:
        add_edge(pool_content_id, run_id, "sequenced_in")

    for fastq_id in fastq_ids:
        add_edge(run_id, fastq_id, "run_artifact")
