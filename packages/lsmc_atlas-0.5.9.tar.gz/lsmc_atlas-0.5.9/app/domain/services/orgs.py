"""LSMC Hub - Organization and Site Services.

Provides CRUD operations for Organizations and Sites.
"""

import uuid
from dataclasses import dataclass
from typing import Any


@dataclass
class OrganizationCreate:
    """Data for creating a new organization."""

    name: str
    uid: uuid.UUID | None = None
    display_name: str | None = None
    org_type: str = "clinic"
    contact_email: str | None = None
    contact_phone: str | None = None
    address: dict | None = None
    owner_user_id: str | None = None
    initial_site_name: str | None = None
    initial_site_code: str | None = None
    initial_site_contact_email: str | None = None
    initial_site_contact_phone: str | None = None
    initial_site_address: dict | None = None


@dataclass
class OrganizationUpdate:
    """Data for updating an organization (creates new revision)."""

    name: str | None = None
    display_name: str | None = None
    org_type: str | None = None
    contact_email: str | None = None
    contact_phone: str | None = None
    address: dict | None = None
    owner_user_id: str | None = None
    is_active: bool | None = None
    note: str | None = None


@dataclass
class SiteCreate:
    """Data for creating a new site."""

    organization_id: str
    name: str
    site_code: str | None = None
    address: dict | None = None
    contact_email: str | None = None
    contact_phone: str | None = None


@dataclass
class SiteUpdate:
    """Data for updating a site (creates new revision)."""

    name: str | None = None
    site_code: str | None = None
    address: dict | None = None
    contact_email: str | None = None
    contact_phone: str | None = None
    is_active: bool | None = None
    note: str | None = None


class OrganizationService:
    """Service for organization operations."""

    def __init__(self, db: Any):
        self.db = db
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.orgs import TapdbOrgRepository

            self._tapdb_repo = TapdbOrgRepository(self.db)
        return self._tapdb_repo

    def create(
        self,
        data: OrganizationCreate,
        created_by: uuid.UUID | None = None,
    ) -> Any:
        """Create a new organization and ensure it has an initial site."""
        organization = self._repo().create_org(data, created_by)

        site_name = (data.initial_site_name or "").strip()
        if not site_name:
            base_name = (data.display_name or data.name or "Primary").strip() or "Primary"
            site_name = f"{base_name} Site"

        site_payload = type(
            "SiteCreatePayload",
            (),
            {
                "organization_id": organization.euid,
                "name": site_name,
                "site_code": data.initial_site_code,
                "address": data.initial_site_address,
                "contact_email": data.initial_site_contact_email or data.contact_email,
                "contact_phone": data.initial_site_contact_phone or data.contact_phone,
            },
        )()
        self._repo().create_site(site_payload, created_by)
        return organization

    def get_by_id(self, org_id: str) -> Any | None:
        """Get organization by ID (EUID string)."""
        return self._repo().get_org_by_id(org_id)

    def get_by_uid(self, uid: uuid.UUID) -> Any | None:
        """Get organization by internal UUID (used as tenant_id)."""
        return self._repo().get_org_by_uid(uid)

    def resolve(self, org_id: str) -> Any | None:
        """Resolve organization by canonical EUID."""
        return self._repo().get_org_by_id(org_id)

    def get_with_revision(self, org_id: str) -> tuple[Any, Any] | None:
        """Get organization by ID (EUID string) with its latest revision."""
        return self._repo().get_org_with_revision(org_id)

    def get_with_revision_by_uid(self, uid: "uuid.UUID") -> tuple[Any, Any] | None:
        """Get organization by tenant_id UUID with its latest revision."""
        return self._repo().get_org_with_revision_by_uid(uid)

    def list_all(self, active_only: bool = True) -> list[Any]:
        """List all organizations."""
        return self._repo().list_orgs(active_only=active_only)

    def update(
        self,
        org_id: str,
        data: OrganizationUpdate,
        updated_by: uuid.UUID | None = None,
    ) -> Any | None:
        """Update organization by creating a new revision."""
        return self._repo().update_org(org_id, data, updated_by)

    def soft_delete(
        self,
        org_id: str,
        deleted_by: uuid.UUID | None = None,
    ) -> bool:
        """Soft-delete organization and related site instances."""
        return self._repo().soft_delete_org(org_id, deleted_by)


class SiteService:
    """Service for site operations."""

    def __init__(self, db: Any):
        self.db = db
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.orgs import TapdbOrgRepository

            self._tapdb_repo = TapdbOrgRepository(self.db)
        return self._tapdb_repo

    def create(
        self,
        data: SiteCreate,
        created_by: uuid.UUID | None = None,
    ) -> Any:
        """Create a new site with initial revision."""
        return self._repo().create_site(data, created_by)

    def get_by_id(self, site_id: str) -> Any | None:
        """Get site by ID (EUID string)."""
        return self._repo().get_site_by_id(site_id)

    def list_by_organization(
        self,
        org_id: str,
        active_only: bool = True,
    ) -> list[Any]:
        """List sites for an organization."""
        return self._repo().list_sites_by_org(org_id, active_only=active_only)

    def update(
        self,
        site_id: str,
        data: SiteUpdate,
        updated_by: uuid.UUID | None = None,
    ) -> Any | None:
        """Update site by creating a new revision."""
        current = self._repo().get_site_by_id(site_id)
        if current is None:
            return None

        latest = current.revisions[-1] if getattr(current, "revisions", None) else None
        requested_is_active = (
            data.is_active if data.is_active is not None else (latest.is_active if latest else True)
        )
        if latest and latest.is_active and not requested_is_active:
            active_sites = self._repo().list_sites_by_org(
                str(current.organization_id), active_only=True
            )
            if len(active_sites) <= 1:
                raise ValueError("Organization must have at least one active site")

        return self._repo().update_site(site_id, data, updated_by)
