"""Generic local Atlas entity linking backed by append-only link events."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.domain.enums import AuditAction, LinkAction
from app.persistence.tapdb.documents import TapdbDocumentRepository


@dataclass(frozen=True)
class EntityLink:
    action: str
    source_type: str
    source_id: str
    target_type: str
    target_id: str
    created_at: datetime | None
    created_by: uuid.UUID | None


class EntityLinkService:
    """Generic link/unlink service for Atlas-local entities."""

    def __init__(self, db: Any, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.repo = TapdbDocumentRepository(db)

    def link(
        self,
        *,
        source_type: str,
        source_id: str,
        target_type: str,
        target_id: str,
        created_by: uuid.UUID | None = None,
    ) -> bool:
        if self._is_link_active(
            source_type=source_type,
            source_id=source_id,
            target_type=target_type,
            target_id=target_id,
        ):
            return False

        self.repo.add_link_event(
            tenant_id=self.tenant_id,
            action=LinkAction.LINK.value,
            source_type=source_type,
            source_id=source_id,
            target_type=target_type,
            target_id=target_id,
            created_by=created_by,
        )
        self._audit(
            action=AuditAction.LINK,
            entity_type=source_type,
            entity_id=source_id,
            user_id=created_by,
            details={
                "target_type": target_type,
                "target_id": target_id,
            },
        )
        return True

    def unlink(
        self,
        *,
        source_type: str,
        source_id: str,
        target_type: str,
        target_id: str,
        removed_by: uuid.UUID | None = None,
    ) -> bool:
        if not self._is_link_active(
            source_type=source_type,
            source_id=source_id,
            target_type=target_type,
            target_id=target_id,
        ):
            return False

        self.repo.add_link_event(
            tenant_id=self.tenant_id,
            action=LinkAction.UNLINK.value,
            source_type=source_type,
            source_id=source_id,
            target_type=target_type,
            target_id=target_id,
            created_by=removed_by,
        )
        self._audit(
            action=AuditAction.UNLINK,
            entity_type=source_type,
            entity_id=source_id,
            user_id=removed_by,
            details={
                "target_type": target_type,
                "target_id": target_id,
            },
        )
        return True

    def list_active_for_source(
        self,
        *,
        source_type: str,
        source_id: str,
        target_type: str | None = None,
    ) -> list[EntityLink]:
        events = self.repo.get_link_events_for_source(
            tenant_id=self.tenant_id,
            source_type=source_type,
            source_id=source_id,
            target_type=target_type,
        )
        return self._active_links(events)

    def list_active_for_target(
        self,
        *,
        target_type: str,
        target_id: str,
        source_type: str | None = None,
    ) -> list[EntityLink]:
        events = self.repo.get_link_events_for_target(
            tenant_id=self.tenant_id,
            target_type=target_type,
            target_id=target_id,
            source_type=source_type,
        )
        return self._active_links(events)

    def _is_link_active(
        self,
        *,
        source_type: str,
        source_id: str,
        target_type: str,
        target_id: str,
    ) -> bool:
        return any(
            link.target_type == target_type and link.target_id == str(target_id)
            for link in self.list_active_for_source(
                source_type=source_type,
                source_id=source_id,
                target_type=target_type,
            )
        )

    @staticmethod
    def _active_links(events: list[Any]) -> list[EntityLink]:
        active: dict[tuple[str, str, str, str], EntityLink] = {}
        for event in events:
            key = (
                str(event.source_type),
                str(event.source_id),
                str(event.target_type),
                str(event.target_id),
            )
            link = EntityLink(
                action=str(event.action),
                source_type=str(event.source_type),
                source_id=str(event.source_id),
                target_type=str(event.target_type),
                target_id=str(event.target_id),
                created_at=event.created_at,
                created_by=getattr(event, "created_by", None),
            )
            if str(event.action) == LinkAction.LINK.value:
                active[key] = link
            elif key in active:
                del active[key]
        rows = list(active.values())
        rows.sort(key=lambda row: row.created_at or datetime.min)
        return rows

    def _audit(
        self,
        *,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        user_id: uuid.UUID | None,
        details: dict[str, Any],
    ) -> None:
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db,
                tenant_id=self.tenant_id,
                user_id=str(user_id) if user_id else None,
            ).log(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
                user_id=user_id,
            )
            self.db.commit()
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
