"""Test-anchored TRF membership projections for test kits."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime

from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.domain.services.shipments import TestKitService
from app.domain.services.trfs import TestService, TrfService
from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid
from app.persistence.tapdb.logistics import TEST_KIT_TEMPLATE_CODE, TapdbLogisticsRepository
from app.persistence.tapdb.trfs import TEST_TEMPLATE_CODE


@dataclass(frozen=True)
class LinkedTrf:
    trf_euid: str
    trf_number: str
    status: str | None
    linked_at: datetime | None


class TestKitTrfLinkService:
    """Project TRF membership for a test kit through contained Tests."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._logistics_repo: TapdbLogisticsRepository | None = None
        self._tests: TestService | None = None
        self._trfs: TrfService | None = None
        self._testkits: TestKitService | None = None

    def _repo(self) -> TapdbLogisticsRepository:
        if self._logistics_repo is None:
            self._logistics_repo = TapdbLogisticsRepository(self.db)
        return self._logistics_repo

    def _test_service(self) -> TestService:
        if self._tests is None:
            self._tests = TestService(self.db, self.tenant_id)
        return self._tests

    def _trf_service(self) -> TrfService:
        if self._trfs is None:
            self._trfs = TrfService(self.db, self.tenant_id)
        return self._trfs

    def _testkit_service(self) -> TestKitService:
        if self._testkits is None:
            self._testkits = TestKitService(self.db, self.tenant_id)
        return self._testkits

    @staticmethod
    def _instance_properties(instance: generic_instance) -> dict[str, str]:
        raw = instance.json_addl or {}
        props = raw.get("properties") if isinstance(raw, dict) else None
        return dict(props) if isinstance(props, dict) else {}

    def _instance_tenant_id(self, instance: generic_instance) -> uuid.UUID | None:
        value = self._instance_properties(instance).get("tenant_id")
        if isinstance(value, uuid.UUID):
            return value
        if isinstance(value, str) and value.strip():
            try:
                return uuid.UUID(value)
            except ValueError:
                return None
        return None

    def _assert_tenant_scope(self, instance: generic_instance, *, label: str) -> None:
        tenant_value = self._instance_tenant_id(instance)
        if tenant_value is not None and tenant_value != self.tenant_id:
            raise ValueError(f"Cross-tenant write denied for {label}")

    def _resolve_testkit_instance(self, testkit_euid: str) -> generic_instance:
        testkit = get_instance_by_euid(self.db, TEST_KIT_TEMPLATE_CODE, testkit_euid)
        if testkit is None:
            raise ValueError(f"TestKit not found: {testkit_euid}")
        self._assert_tenant_scope(testkit, label="test kit")
        return testkit

    def _tests_for_trf(self, trf_euid: str) -> list[tuple[str, str]]:
        rows = self._test_service().list_for_trf(trf_euid, cross_tenant=False)
        return [(test.euid, str(test.order_id)) for test, _revision, _routes in rows]

    def link_trf(self, *, testkit_euid: str, trf_euid: str, created_by: uuid.UUID | None) -> bool:
        """Link every current Test of a TRF into the test kit containment tree."""
        self._testkit_service().get_with_revision(testkit_euid, cross_tenant=False)
        tests = self._tests_for_trf(trf_euid)
        changed = False
        for test_euid, _order_id in tests:
            changed = (
                self._testkit_service().add_item(
                    testkit_euid,
                    "Test",
                    test_euid,
                    reason="TRF test linked to test kit",
                    created_by=created_by,
                )
                or changed
            )
        return changed

    def unlink_trf(self, *, testkit_euid: str, trf_euid: str, removed_by: uuid.UUID | None) -> bool:
        """Unlink every current Test of a TRF from the test kit containment tree."""
        self._testkit_service().get_with_revision(testkit_euid, cross_tenant=False)
        tests = self._tests_for_trf(trf_euid)
        changed = False
        for test_euid, _order_id in tests:
            changed = (
                self._repo().remove_item_from_container(
                    container_type="TestKit",
                    container_id=testkit_euid,
                    item_type="Test",
                    item_id=test_euid,
                    reason="TRF test unlinked from test kit",
                    created_by=removed_by,
                )
                or changed
            )
        if changed:
            self.db.commit()
        return changed

    def list_linked_trfs(self, *, testkit_euid: str) -> list[LinkedTrf]:
        """Derive the kit's linked TRFs from the Tests currently contained in it."""
        try:
            testkit = self._resolve_testkit_instance(testkit_euid)
        except ValueError:
            return []

        tests = get_child_instances(self.db, testkit, TEST_TEMPLATE_CODE)
        if not tests:
            return []

        link_times = self._test_link_times(testkit)
        trf_service = self._trf_service()
        linked_by_trf: dict[str, LinkedTrf] = {}
        for test_instance in tests:
            test = self._test_service().get_by_id(test_instance.euid, cross_tenant=False)
            if test is None:
                continue
            trf_euid = str(test.order_id or "").strip()
            if not trf_euid:
                continue
            trf_result = trf_service.get_by_id(trf_euid, cross_tenant=False)
            linked_at = link_times.get(test_instance.euid)
            if trf_result is None:
                candidate = LinkedTrf(
                    trf_euid=trf_euid,
                    trf_number=trf_euid,
                    status=None,
                    linked_at=linked_at,
                )
            else:
                trf, trf_revision = trf_result
                candidate = LinkedTrf(
                    trf_euid=trf.euid,
                    trf_number=trf.order_number,
                    status=trf_revision.status,
                    linked_at=linked_at,
                )
            existing = linked_by_trf.get(trf_euid)
            if existing is None:
                linked_by_trf[trf_euid] = candidate
                continue
            existing_time = existing.linked_at
            candidate_time = candidate.linked_at
            if existing_time is None or (
                candidate_time is not None and candidate_time < existing_time
            ):
                linked_by_trf[trf_euid] = candidate

        return [linked_by_trf[key] for key in sorted(linked_by_trf.keys())]

    def _test_link_times(self, testkit: generic_instance) -> dict[str, datetime | None]:
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == testkit.uid,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt.asc(), generic_instance_lineage.uid.asc())
        )
        edges = list(self.db.execute(stmt).scalars().all())
        if not edges:
            return {}

        child_uids = [edge.child_instance_uid for edge in edges]
        child_stmt = select(generic_instance).where(generic_instance.uid.in_(child_uids))
        children = {
            row.uid: row
            for row in self.db.execute(child_stmt).scalars().all()
            if not row.is_deleted
        }
        linked_at: dict[str, datetime | None] = {}
        for edge in edges:
            child = children.get(edge.child_instance_uid)
            if child is None or child.euid in linked_at:
                continue
            linked_at[child.euid] = edge.created_dt
        return linked_at
