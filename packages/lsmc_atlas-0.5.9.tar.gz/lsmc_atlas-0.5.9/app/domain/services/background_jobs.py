"""LSMC Hub - Background Job Services.

Provides background job functionality for periodic tasks like
tracking updates, cleanup operations, etc.
"""

import asyncio
import logging
from collections.abc import Callable

from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


class BackgroundJobScheduler:
    """Simple background job scheduler using asyncio."""

    def __init__(self):
        self._jobs: dict[str, asyncio.Task] = {}
        self._running = False

    async def start(self):
        """Start the scheduler."""
        self._running = True
        logger.info("Background job scheduler started")

    async def stop(self):
        """Stop the scheduler and cancel all jobs."""
        self._running = False
        for _job_id, task in self._jobs.items():
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._jobs.clear()
        logger.info("Background job scheduler stopped")

    def schedule_recurring(
        self,
        job_id: str,
        func: Callable,
        interval_seconds: int,
        *args,
        **kwargs,
    ):
        """Schedule a recurring job."""
        if job_id in self._jobs:
            logger.warning(f"Job {job_id} already exists, cancelling old job")
            self._jobs[job_id].cancel()

        async def run_recurring():
            while self._running:
                try:
                    await asyncio.sleep(interval_seconds)
                    if asyncio.iscoroutinefunction(func):
                        await func(*args, **kwargs)
                    else:
                        func(*args, **kwargs)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error in job {job_id}: {e}")

        task = asyncio.create_task(run_recurring())
        self._jobs[job_id] = task
        logger.info(f"Scheduled recurring job {job_id} every {interval_seconds}s")


# Global scheduler instance
_scheduler: BackgroundJobScheduler | None = None


def get_scheduler() -> BackgroundJobScheduler:
    """Get the global scheduler instance."""
    global _scheduler
    if _scheduler is None:
        _scheduler = BackgroundJobScheduler()
    return _scheduler


async def run_tracking_update_job(db_factory: Callable[[], Session]):
    """
    Background job to update FedEx tracking for all active shipments.

    This job:
    1. Finds shipments with tracking numbers that haven't been updated recently
    2. Fetches fresh tracking data from FedEx
    3. Stores the updated tracking information
    """
    from app.domain.services.fedex_tracking import FEDEX_AVAILABLE

    if not FEDEX_AVAILABLE:
        logger.debug("FedEx tracking not available, skipping update job")
        return

    # Runtime hard-cut: no persisted tracking snapshots, so periodic DB scan is disabled.
    # Per-shipment live lookups still happen on-demand in API/UI flows.
    logger.info("FedEx tracking updater is in live-only mode; skipping background DB polling job")
    db = db_factory()
    try:
        pass
    finally:
        close = getattr(db, "close", None)
        if callable(close):
            close()
