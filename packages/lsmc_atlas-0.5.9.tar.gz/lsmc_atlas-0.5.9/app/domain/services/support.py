"""LSMC Hub - Support Ticket Service.

Provides operations for support tickets with:
- Tenant scoping
- Append-only revision pattern
- Status tracking
- Assignment management
- Audit logging
"""

import uuid
from dataclasses import dataclass
from typing import Any

from app.domain.enums import AuditAction, TicketPriority, TicketStatus, TicketType
from app.domain.services.audit_utils import log_tapdb_audit_event


@dataclass
class TicketCreate:
    """Data for creating a new support ticket."""

    subject: str
    description: str
    ticket_type: str
    priority: str = "NORMAL"
    related_order_id: str | None = None
    related_shipment_id: str | None = None
    site_id: str | None = None


@dataclass
class TicketUpdate:
    """Data for updating a support ticket (creates new revision)."""

    subject: str | None = None
    description: str | None = None
    ticket_type: str | None = None
    priority: str | None = None
    status: str | None = None
    assigned_to: str | None = None
    resolution_notes: str | None = None


class SupportTicketService:
    """Service for support ticket operations."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.support import TapdbSupportRepository

            self._tapdb_repo = TapdbSupportRepository(self.db)
        return self._tapdb_repo

    def create(
        self,
        data: TicketCreate,
        created_by: uuid.UUID | None = None,
    ):
        """Create a new support ticket."""
        if data.ticket_type not in [t.value for t in TicketType]:
            raise ValueError(f"Invalid ticket type: {data.ticket_type}")
        if data.priority not in [p.value for p in TicketPriority]:
            raise ValueError(f"Invalid priority: {data.priority}")

        ticket_number = self._repo().generate_next_ticket_number()
        from app.domain.services.site_scope import resolve_tenant_site_euid

        resolved_site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.site_id)
        payload = type(
            "TicketCreatePayload",
            (),
            {
                "subject": data.subject,
                "description": data.description,
                "ticket_type": data.ticket_type,
                "priority": data.priority,
                "status": TicketStatus.OPEN.value,
                "assigned_to": None,
                "related_order_id": data.related_order_id,
                "related_shipment_id": data.related_shipment_id,
                "site_id": resolved_site_id,
                "resolution_notes": None,
                "resolved_at": None,
                "resolved_by": None,
            },
        )()

        actor = created_by or self.user_id
        ticket, revision = self._repo().create_ticket(
            tenant_id=self.tenant_id,
            ticket_number=ticket_number,
            data=payload,
            created_by=actor,
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=actor,
            action=AuditAction.CREATE,
            entity_type="SupportTicket",
            entity_id=ticket.euid,
            details={"ticket_number": ticket_number, "subject": data.subject},
        )

        self.db.commit()
        return ticket, revision

    def get_by_id(self, ticket_id: str):
        """Get ticket by ID with latest revision (tenant-scoped)."""
        return self._repo().get_ticket_with_revision(ticket_id=ticket_id, tenant_id=self.tenant_id)

    def get_by_ticket_number(self, ticket_number: str):
        """Get ticket by ticket number (tenant-scoped)."""
        return self._repo().get_ticket_by_number(
            ticket_number=ticket_number, tenant_id=self.tenant_id
        )

    def list_tickets(
        self,
        skip: int = 0,
        limit: int = 50,
        status: str | None = None,
        ticket_type: str | None = None,
        assigned_to: uuid.UUID | None = None,
    ):
        """List tickets with optional filtering (tenant-scoped)."""
        return self._repo().list_tickets(
            tenant_id=self.tenant_id,
            skip=skip,
            limit=limit,
            status=status,
            ticket_type=ticket_type,
            assigned_to=assigned_to,
        )

    def update(
        self,
        ticket_id: str,
        data: TicketUpdate,
        updated_by: uuid.UUID | None = None,
    ):
        """Update ticket by creating a new revision."""
        result = self._repo().update_ticket(
            ticket_id=ticket_id,
            tenant_id=self.tenant_id,
            data=data,
            updated_by=updated_by or self.user_id,
        )
        if not result:
            return None

        ticket, revision = result
        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=updated_by or self.user_id,
            action=AuditAction.UPDATE,
            entity_type="SupportTicket",
            entity_id=ticket_id,
            details={"ticket_number": ticket.ticket_number},
        )

        self.db.commit()
        return ticket, revision

    def assign(
        self,
        ticket_id: str,
        assigned_to: str,
        updated_by: uuid.UUID | None = None,
    ):
        """Assign ticket to a user."""
        return self.update(
            ticket_id,
            TicketUpdate(assigned_to=assigned_to, status=TicketStatus.ASSIGNED.value),
            updated_by=updated_by,
        )

    def resolve(
        self,
        ticket_id: str,
        resolution_notes: str,
        updated_by: uuid.UUID | None = None,
    ):
        """Resolve a ticket."""
        actor = updated_by or self.user_id
        result = self._repo().resolve_ticket(
            ticket_id=ticket_id,
            tenant_id=self.tenant_id,
            resolution_notes=resolution_notes,
            resolver_id=actor,
        )
        if not result:
            return None

        ticket, revision = result
        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=actor,
            action=AuditAction.UPDATE,
            entity_type="SupportTicket",
            entity_id=ticket_id,
            details={"ticket_number": ticket.ticket_number, "action": "resolved"},
        )

        self.db.commit()
        return ticket, revision
