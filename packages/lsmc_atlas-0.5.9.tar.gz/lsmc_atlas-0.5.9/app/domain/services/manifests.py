"""LSMC Hub - Manifest Service.

Provides operations for:
- Parsing manifest files (CSV, Excel)
- Creating manifest metadata records
- Validating manifest data
- Linking manifests to shipments
"""

import csv
import io
import uuid
from dataclasses import dataclass
from typing import Any

from app.domain.enums import AuditAction
from app.domain.services.audit_utils import log_tapdb_audit_event


@dataclass
class ManifestItem:
    """A single item in a manifest."""

    specimen_barcode: str
    specimen_type: str | None = None
    patient_id: str | None = None
    trf_euid: str | None = None
    collection_date: str | None = None
    notes: str | None = None
    row_number: int | None = None  # For error reporting


@dataclass
class ManifestParseResult:
    """Result of parsing a manifest file."""

    success: bool
    items: list[ManifestItem] | None = None
    errors: list[str] | None = None
    warnings: list[str] | None = None


@dataclass
class ManifestCreateResult:
    """Result of creating a manifest."""

    manifest_id: str
    manifest_number: str
    items_created: int
    materials_registered: int
    errors: list[str] | None = None


class ManifestService:
    """Service for managing manifests."""

    def __init__(self, db: Any, tenant_id: uuid.UUID, user_id: str | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._tapdb_repo: Any | None = None

    def _repo(self):
        if self._tapdb_repo is None:
            from app.persistence.tapdb.manifests import TapdbManifestRepository

            self._tapdb_repo = TapdbManifestRepository(self.db)
        return self._tapdb_repo

    def _generate_manifest_number(self) -> str:
        """Generate a unique manifest number (MAN-N)."""
        return self._repo().generate_next_manifest_number()

    def parse_csv(self, file_content: bytes) -> ManifestParseResult:
        """Parse a CSV manifest file."""
        try:
            content = file_content.decode("utf-8")
            reader = csv.DictReader(io.StringIO(content))

            items: list[ManifestItem] = []
            errors: list[str] = []
            warnings: list[str] = []

            if not reader.fieldnames:
                return ManifestParseResult(success=False, errors=["CSV file has no headers"])

            if "specimen_barcode" not in reader.fieldnames:
                return ManifestParseResult(
                    success=False,
                    errors=["CSV file must have 'specimen_barcode' column"],
                )

            for row_num, row in enumerate(reader, start=2):
                barcode = row.get("specimen_barcode", "").strip()
                if not barcode:
                    errors.append(f"Row {row_num}: Missing specimen_barcode")
                    continue

                items.append(
                    ManifestItem(
                        specimen_barcode=barcode,
                        specimen_type=row.get("specimen_type", "").strip() or None,
                        patient_id=row.get("patient_id", "").strip() or None,
                        trf_euid=row.get("trf_euid", "").strip() or None,
                        collection_date=row.get("collection_date", "").strip() or None,
                        notes=row.get("notes", "").strip() or None,
                        row_number=row_num,
                    )
                )

            if not items and not errors:
                errors.append("No valid items found in CSV")

            return ManifestParseResult(
                success=len(errors) == 0,
                items=items if items else None,
                errors=errors if errors else None,
                warnings=warnings if warnings else None,
            )

        except Exception as e:
            return ManifestParseResult(success=False, errors=[f"Failed to parse CSV: {str(e)}"])

    def parse_excel(self, file_content: bytes) -> ManifestParseResult:
        """Parse an Excel manifest file."""
        try:
            import openpyxl
        except ImportError:
            return ManifestParseResult(
                success=False,
                errors=["openpyxl not installed. Cannot parse Excel files."],
            )

        try:
            workbook = openpyxl.load_workbook(io.BytesIO(file_content))
            sheet = workbook.active

            headers = [cell.value for cell in sheet[1]]
            if "specimen_barcode" not in headers:
                return ManifestParseResult(
                    success=False,
                    errors=["Excel file must have 'specimen_barcode' column"],
                )

            col_indices = {header: idx for idx, header in enumerate(headers)}

            items: list[ManifestItem] = []
            errors: list[str] = []
            warnings: list[str] = []

            for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
                barcode_idx = col_indices.get("specimen_barcode")
                if barcode_idx is None:
                    continue

                barcode = str(row[barcode_idx]).strip() if row[barcode_idx] else ""
                if not barcode:
                    errors.append(f"Row {row_num}: Missing specimen_barcode")
                    continue

                items.append(
                    ManifestItem(
                        specimen_barcode=barcode,
                        specimen_type=(
                            str(row[col_indices["specimen_type"]]).strip()
                            if "specimen_type" in col_indices and row[col_indices["specimen_type"]]
                            else None
                        ),
                        patient_id=(
                            str(row[col_indices["patient_id"]]).strip()
                            if "patient_id" in col_indices and row[col_indices["patient_id"]]
                            else None
                        ),
                        trf_euid=(
                            str(row[col_indices["trf_euid"]]).strip()
                            if "trf_euid" in col_indices and row[col_indices["trf_euid"]]
                            else None
                        ),
                        collection_date=(
                            str(row[col_indices["collection_date"]]).strip()
                            if "collection_date" in col_indices
                            and row[col_indices["collection_date"]]
                            else None
                        ),
                        notes=(
                            str(row[col_indices["notes"]]).strip()
                            if "notes" in col_indices and row[col_indices["notes"]]
                            else None
                        ),
                        row_number=row_num,
                    )
                )

            if not items and not errors:
                errors.append("No valid items found in Excel file")

            return ManifestParseResult(
                success=len(errors) == 0,
                items=items if items else None,
                errors=errors if errors else None,
                warnings=warnings if warnings else None,
            )

        except Exception as e:
            return ManifestParseResult(success=False, errors=[f"Failed to parse Excel: {str(e)}"])

    def create_manifest(
        self,
        items: list[ManifestItem],
        shipment_id: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> ManifestCreateResult:
        """Create a manifest as Atlas-side intake metadata only."""
        items_data = [
            {
                "specimen_barcode": item.specimen_barcode,
                "specimen_type": item.specimen_type,
                "patient_id": item.patient_id,
                "trf_euid": item.trf_euid,
                "collection_date": item.collection_date,
                "notes": item.notes,
            }
            for item in items
        ]

        manifest_number = self._generate_manifest_number()
        manifest, _revision = self._repo().create_manifest(
            tenant_id=self.tenant_id,
            manifest_number=manifest_number,
            items=items_data,
            shipment_id=shipment_id,
            created_by=created_by,
            note=f"Manifest created with {len(items)} items",
        )

        log_tapdb_audit_event(
            self.db,
            tenant_id=self.tenant_id,
            user_id=created_by,
            action=AuditAction.CREATE,
            entity_type="MANIFEST",
            entity_id=manifest.euid,
            details={
                "manifest_number": manifest.manifest_number,
                "items_count": len(items),
                "materials_registered": 0,
            },
        )
        self.db.commit()

        return ManifestCreateResult(
            manifest_id=manifest.euid,
            manifest_number=manifest.manifest_number,
            items_created=len(items),
            materials_registered=0,
            errors=None,
        )

    def get_manifest(
        self,
        manifest_id: str,
        cross_tenant: bool = False,
    ):
        """Get manifest by ID with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_manifest_with_revision(
            manifest_id=manifest_id, tenant_id=tenant_scope
        )

    def get_by_manifest_number(
        self,
        manifest_number: str,
        cross_tenant: bool = False,
    ):
        """Get manifest by manifest_number with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_manifest_by_number(
            manifest_number=manifest_number,
            tenant_id=tenant_scope,
        )

    def list_manifests(
        self,
        skip: int = 0,
        limit: int = 50,
        cross_tenant: bool = False,
    ):
        """List manifests with optional cross-tenant access."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_manifests(tenant_id=tenant_scope, skip=skip, limit=limit)
