"""LSMC Hub - Webhook Emitter.

Helper functions for emitting webhook events from services.
Uses non-blocking async delivery to avoid blocking request threads.
"""

import asyncio
import logging
import uuid
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.domain.enums import WebhookEventType
from app.domain.services.webhooks import WebhookEvent, WebhookService, deliver_webhook_async

logger = logging.getLogger(__name__)


def emit_webhook(
    db: Session,
    tenant_id: uuid.UUID,
    event_type: str,
    event_id: str,
    payload: dict,
) -> None:
    """Emit a webhook event using non-blocking async delivery.

    This function finds all active subscriptions for the event type
    and schedules async delivery for each. It uses asyncio.create_task
    when called from an async context, or runs in a new event loop otherwise.

    Args:
        db: Database session
        tenant_id: Tenant ID
        event_type: Event type (e.g., "order.status.changed")
        event_id: ID of the entity that triggered the event
        payload: Event payload data
    """
    try:
        event = WebhookEvent(
            event_type=event_type,
            event_id=event_id,
            payload=payload,
            timestamp=datetime.now(UTC),
        )

        # Load subscriptions via TapDB-backed webhook service.
        webhook_svc = WebhookService(db, tenant_id)
        subscriptions = webhook_svc.list(skip=0, limit=1_000_000)

        for subscription, revision in subscriptions:
            if not revision or not revision.is_active:
                continue

            # Check if subscription is interested in this event type
            if event_type not in revision.event_types:
                continue

            # Schedule async delivery (non-blocking)
            _schedule_async_delivery(
                tenant_id=tenant_id,
                subscription_id=subscription.euid,
                url=revision.url,
                secret=revision.secret,
                event=event,
                headers=revision.headers,
                timeout_seconds=revision.timeout_seconds,
                max_retries=revision.max_retries,
            )

    except Exception as e:
        # Log error but don't fail the main operation
        logger.error(f"Webhook emission failed: {e}")


def _schedule_async_delivery(
    tenant_id: uuid.UUID,
    subscription_id: str,
    url: str,
    secret: str,
    event: WebhookEvent,
    headers: dict | None = None,
    timeout_seconds: int = 30,
    max_retries: int = 3,
) -> None:
    """Schedule async webhook delivery.

    Attempts to use the running event loop if available,
    otherwise creates a new one for the delivery.
    """
    try:
        # Try to get running event loop (we're in an async context)
        loop = asyncio.get_running_loop()
        # Schedule as a background task
        loop.create_task(
            deliver_webhook_async(
                tenant_id=tenant_id,
                subscription_id=subscription_id,
                url=url,
                secret=secret,
                event=event,
                headers=headers,
                timeout_seconds=timeout_seconds,
                max_retries=max_retries,
            )
        )
    except RuntimeError:
        # No running event loop - we're in a sync context
        # Run in a thread to avoid blocking
        import threading

        def run_async():
            asyncio.run(
                deliver_webhook_async(
                    tenant_id=tenant_id,
                    subscription_id=subscription_id,
                    url=url,
                    secret=secret,
                    event=event,
                    headers=headers,
                    timeout_seconds=timeout_seconds,
                    max_retries=max_retries,
                )
            )

        thread = threading.Thread(target=run_async, daemon=True)
        thread.start()


def emit_order_status_changed(
    db: Session,
    tenant_id: uuid.UUID,
    order_id: str,
    order_number: str,
    old_status: str,
    new_status: str,
) -> None:
    """Emit order.status.changed webhook event."""
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.ORDER_STATUS_CHANGED.value,
        order_id,
        {
            "order_id": order_id,
            "order_number": order_number,
            "old_status": old_status,
            "new_status": new_status,
        },
    )


def emit_order_created(
    db: Session,
    tenant_id: uuid.UUID,
    order_id: str,
    order_number: str,
) -> None:
    """Emit order.created webhook event."""
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.ORDER_CREATED.value,
        order_id,
        {
            "order_id": order_id,
            "order_number": order_number,
        },
    )


def emit_artifact_available(
    db: Session,
    tenant_id: uuid.UUID,
    artifact_id: uuid.UUID,
    source_system: str,
    source_uid: str,
    artifact_type: str,
) -> None:
    """Emit artifact.available webhook event."""
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.ARTIFACT_AVAILABLE.value,
        artifact_id,
        {
            "artifact_id": str(artifact_id),
            "source_system": source_system,
            "source_uid": source_uid,
            "artifact_type": artifact_type,
        },
    )


def emit_release_package_created(
    db: Session,
    tenant_id: uuid.UUID,
    package_id: uuid.UUID,
    package_number: str,
    order_id: uuid.UUID,
) -> None:
    """Emit release.package.created webhook event."""
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.RELEASE_PACKAGE_CREATED.value,
        package_id,
        {
            "package_id": str(package_id),
            "package_number": package_number,
            "order_id": str(order_id),
        },
    )


def emit_release_package_released(
    db: Session,
    tenant_id: uuid.UUID,
    package_id: uuid.UUID,
    package_number: str,
) -> None:
    """Emit release.package.released webhook event."""
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.RELEASE_PACKAGE_RELEASED.value,
        package_id,
        {
            "package_id": str(package_id),
            "package_number": package_number,
        },
    )


def emit_exception_created(
    db: Session,
    tenant_id: uuid.UUID,
    exception_id: uuid.UUID,
    exception_number: str,
    exception_type: str,
) -> None:
    """Emit exception.created webhook event."""
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.EXCEPTION_CREATED.value,
        exception_id,
        {
            "exception_id": str(exception_id),
            "exception_number": exception_number,
            "exception_type": exception_type,
        },
    )


def emit_exception_resolved(
    db: Session,
    tenant_id: uuid.UUID,
    exception_id: uuid.UUID,
    exception_number: str,
) -> None:
    """Emit exception.resolved webhook event."""
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.EXCEPTION_RESOLVED.value,
        exception_id,
        {
            "exception_id": str(exception_id),
            "exception_number": exception_number,
        },
    )


def emit_assay_run_status_changed(
    db: Session,
    tenant_id: uuid.UUID,
    fulfillment_run_id: uuid.UUID,
    order_id: uuid.UUID,
    order_number: str,
    previous_status: str,
    new_status: str,
    qc_hold_reason: str | None = None,
) -> None:
    """Emit fulfillment_run.status.changed webhook event.

    Called on each real assay transition (not idempotent same-state transitions).

    Args:
        db: Database session
        tenant_id: Tenant ID
        fulfillment_run_id: ID of the assay run that changed
        order_id: ID of the associated order
        order_number: Order number for easy reference
        previous_status: The previous assay state
        new_status: The new assay state
        qc_hold_reason: If transitioning to QC_HOLD, the reason
    """
    payload = {
        "fulfillment_run_id": str(fulfillment_run_id),
        "order_id": str(order_id),
        "order_number": order_number,
        "previous_status": previous_status,
        "new_status": new_status,
    }

    # Include qc_hold_reason if transitioning to QC_HOLD
    if new_status == "QC_HOLD" and qc_hold_reason:
        payload["qc_hold_reason"] = qc_hold_reason

    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.ASSAY_RUN_STATUS_CHANGED.value,
        fulfillment_run_id,
        payload,
    )


def emit_results_set_published(
    db: Session,
    tenant_id: uuid.UUID,
    results_set_id: uuid.UUID,
    order_id: uuid.UUID,
    order_number: str,
    fulfillment_run_count: int,
) -> None:
    """Emit results_set.published webhook event.

    Called when a results set is published for external visibility.

    Args:
        db: Database session
        tenant_id: Tenant ID
        results_set_id: ID of the results set that was published
        order_id: ID of the associated order
        order_number: Order number for easy reference
        fulfillment_run_count: Number of assay runs in the results set
    """
    emit_webhook(
        db,
        tenant_id,
        WebhookEventType.RESULTS_SET_PUBLISHED.value,
        results_set_id,
        {
            "results_set_id": str(results_set_id),
            "order_id": str(order_id),
            "order_number": order_number,
            "fulfillment_run_count": fulfillment_run_count,
        },
    )
