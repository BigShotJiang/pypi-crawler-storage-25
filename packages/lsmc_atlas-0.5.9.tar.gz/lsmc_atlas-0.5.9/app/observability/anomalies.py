"""Atlas-local anomaly persistence and redaction helpers."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from daylily_tapdb.templates.mutation import allow_template_mutations
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.observability.redaction import fingerprint_error, redact_path_instance, redact_sql_message
from app.settings import settings

ANOMALY_TEMPLATE_CODE = "atlas/ops/anomaly-record/1.0/"
ANOMALY_PREFIX = "ANM"


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _environment_name() -> str:
    return settings.deployment_name or settings.database_target or "dev"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def redact_context(value: Any) -> Any:
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, item in value.items():
            lowered = str(key).lower()
            if lowered in {"authorization", "cookie", "set-cookie", "token", "secret", "password"}:
                redacted[str(key)] = "[redacted]"
            else:
                redacted[str(key)] = redact_context(item)
        return redacted
    if isinstance(value, list):
        return [redact_context(item) for item in value]
    if isinstance(value, str):
        return redact_sql_message(redact_path_instance(value))
    return value


@dataclass
class AnomalyRecord:
    id: str
    service: str
    environment: str
    category: str
    severity: str
    fingerprint: str
    summary: str
    first_seen_at: str
    last_seen_at: str
    occurrence_count: int
    redacted_context: dict[str, Any]
    source_view_url: str


class TapdbAnomalyRepository:
    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._template_ready = False

    def record(
        self,
        *,
        category: str,
        severity: str,
        fingerprint: str,
        summary: str,
        redacted_context: dict[str, Any] | None = None,
    ) -> AnomalyRecord:
        self._ensure_template()
        normalized_context = redact_context(redacted_context or {})
        now = _utcnow().isoformat()
        environment = _environment_name()
        existing = self._find_existing(
            category=category,
            severity=severity,
            fingerprint=fingerprint,
            environment=environment,
        )
        if existing is None:
            instance = self.factory.create_instance(
                session=self.db,
                template_code=ANOMALY_TEMPLATE_CODE,
                name=summary[:120],
                properties={
                    "service": "atlas",
                    "environment": environment,
                    "category": category,
                    "severity": severity,
                    "fingerprint": fingerprint,
                    "summary": summary,
                    "first_seen_at": now,
                    "last_seen_at": now,
                    "occurrence_count": 1,
                    "redacted_context": normalized_context,
                },
            )
        else:
            props = self._properties(existing)
            props["last_seen_at"] = now
            props["occurrence_count"] = int(props.get("occurrence_count") or 0) + 1
            props["summary"] = summary
            props["redacted_context"] = normalized_context
            self._write_properties(existing, props)
            instance = existing
        self.db.commit()
        return self._to_record(instance)

    def list(self, *, skip: int = 0, limit: int = 100) -> list[AnomalyRecord]:
        rows = [self._to_record(instance) for instance in self._list_instances()]
        rows.sort(key=lambda row: row.last_seen_at, reverse=True)
        return rows[skip : skip + limit]

    def get(self, anomaly_id: str) -> AnomalyRecord | None:
        for instance in self._list_instances():
            if instance.euid == anomaly_id:
                return self._to_record(instance)
        return None

    def record_db_probe_failure(self, *, detail: str, latency_ms: float) -> AnomalyRecord:
        return self.record(
            category="database",
            severity="error",
            fingerprint=fingerprint_error(detail or "database-probe-failure"),
            summary="Atlas database probe failed",
            redacted_context={
                "detail": detail,
                "latency_ms": round(float(latency_ms), 3),
            },
        )

    def _ensure_template(self) -> None:
        if self._template_ready:
            return
        category, type_, subtype, version = _parse_template_code(ANOMALY_TEMPLATE_CODE)
        with allow_template_mutations():
            ensure_instance_prefix_sequence(self.db, ANOMALY_PREFIX)
            stmt = (
                select(generic_template)
                .where(
                    generic_template.category == category,
                    generic_template.type == type_,
                    generic_template.subtype == subtype,
                    generic_template.version == version,
                )
                .limit(1)
            )
            existing = self.db.execute(stmt).scalar_one_or_none()
            if existing is None:
                self.db.add(
                    generic_template(
                        name="Atlas Anomaly Record",
                        polymorphic_discriminator="data_template",
                        category=category,
                        type=type_,
                        subtype=subtype,
                        version=version,
                        instance_prefix=ANOMALY_PREFIX,
                        instance_polymorphic_identity="data_instance",
                        json_addl={"managed_by": "lsmc-atlas", "domain": "observability"},
                        bstatus="active",
                        is_singleton=False,
                        is_deleted=False,
                    )
                )
            elif existing.is_deleted:
                existing.is_deleted = False
            self.db.flush()
        self.templates.clear_cache()
        self._template_ready = True

    def _find_existing(
        self,
        *,
        category: str,
        severity: str,
        fingerprint: str,
        environment: str,
    ) -> generic_instance | None:
        for instance in self._list_instances():
            props = self._properties(instance)
            if (
                str(props.get("category") or "") == category
                and str(props.get("severity") or "") == severity
                and str(props.get("fingerprint") or "") == fingerprint
                and str(props.get("environment") or "") == environment
            ):
                return instance
        return None

    def _list_instances(self) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(ANOMALY_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _write_properties(self, instance: generic_instance, props: dict[str, Any]) -> None:
        raw = dict(instance.json_addl or {})
        raw["properties"] = props
        instance.json_addl = raw
        if hasattr(instance, "_sa_instance_state"):
            flag_modified(instance, "json_addl")

    def _to_record(self, instance: generic_instance) -> AnomalyRecord:
        props = self._properties(instance)
        return AnomalyRecord(
            id=instance.euid,
            service=str(props.get("service") or "atlas"),
            environment=str(props.get("environment") or settings.deployment_name or "unknown"),
            category=str(props.get("category") or "unknown"),
            severity=str(props.get("severity") or "unknown"),
            fingerprint=str(props.get("fingerprint") or ""),
            summary=str(props.get("summary") or instance.name or ""),
            first_seen_at=str(props.get("first_seen_at") or (instance.created_dt or _utcnow()).isoformat()),
            last_seen_at=str(props.get("last_seen_at") or (instance.created_dt or _utcnow()).isoformat()),
            occurrence_count=int(props.get("occurrence_count") or 0),
            redacted_context=dict(props.get("redacted_context") or {}),
            source_view_url=f"/admin/anomalies/{instance.euid}",
        )
