"""In-process observability rollups for Atlas."""

from __future__ import annotations

import time
from collections import Counter, deque
from dataclasses import dataclass, field
from datetime import UTC, datetime
from math import ceil
from threading import RLock
from typing import Any

from sqlalchemy import event

from app.settings import settings

from .redaction import fingerprint_error, fingerprint_sql, redact_path_instance, redact_sql_message


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _utcnow_iso() -> str:
    return _utcnow().isoformat()


def _percentile(values: list[float], quantile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, ceil(len(ordered) * quantile) - 1))
    return round(float(ordered[index]), 3)


@dataclass
class ProjectionMetadata:
    """Shared projection metadata block aligned with Kahlo."""

    state: str = "ready"
    stale: bool = False
    observed_at: str | None = None
    last_synced_at: str | None = None
    detail: str | None = None

    def model_dump(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "stale": self.stale,
            "observed_at": self.observed_at,
            "last_synced_at": self.last_synced_at,
            "detail": self.detail,
        }


@dataclass
class EndpointRollup:
    method: str
    route_template: str
    request_count: int = 0
    error_count: int = 0
    status_class_counts: Counter[str] = field(default_factory=Counter)
    durations_ms: deque[float] = field(default_factory=lambda: deque(maxlen=512))
    fingerprints: set[str] = field(default_factory=set)
    observed_at: str = field(default_factory=_utcnow_iso)

    def record(self, *, status_code: int, duration_ms: float, fingerprint: str) -> None:
        self.request_count += 1
        if status_code >= 500:
            self.error_count += 1
        self.status_class_counts[f"{status_code // 100}xx"] += 1
        self.durations_ms.append(float(duration_ms))
        if fingerprint:
            self.fingerprints.add(fingerprint)
        self.observed_at = _utcnow_iso()

    def to_dict(self) -> dict[str, Any]:
        durations = list(self.durations_ms)
        return {
            "method": self.method,
            "route_template": self.route_template,
            "request_count": self.request_count,
            "status_class_counts": dict(self.status_class_counts),
            "p50_ms": _percentile(durations, 0.50),
            "p95_ms": _percentile(durations, 0.95),
            "p99_ms": _percentile(durations, 0.99),
            "fingerprint_count": len(self.fingerprints),
            "error_count": self.error_count,
            "observed_at": self.observed_at,
        }


@dataclass
class FamilyRollup:
    family: str
    request_count: int = 0
    error_count: int = 0
    durations_ms: deque[float] = field(default_factory=lambda: deque(maxlen=512))
    observed_at: str = field(default_factory=_utcnow_iso)

    def record(self, *, status_code: int, duration_ms: float) -> None:
        self.request_count += 1
        if status_code >= 500:
            self.error_count += 1
        self.durations_ms.append(float(duration_ms))
        self.observed_at = _utcnow_iso()

    def to_dict(self) -> dict[str, Any]:
        durations = list(self.durations_ms)
        return {
            "family": self.family,
            "request_count": self.request_count,
            "error_count": self.error_count,
            "p50_ms": _percentile(durations, 0.50),
            "p95_ms": _percentile(durations, 0.95),
            "p99_ms": _percentile(durations, 0.99),
            "observed_at": self.observed_at,
        }


@dataclass
class DbQueryRollup:
    fingerprint: str
    statement_kind: str
    label: str
    request_count: int = 0
    error_count: int = 0
    durations_ms: deque[float] = field(default_factory=lambda: deque(maxlen=256))
    observed_at: str = field(default_factory=_utcnow_iso)

    def record(self, *, duration_ms: float, success: bool) -> None:
        self.request_count += 1
        if not success:
            self.error_count += 1
        self.durations_ms.append(float(duration_ms))
        self.observed_at = _utcnow_iso()

    def to_dict(self) -> dict[str, Any]:
        durations = list(self.durations_ms)
        return {
            "fingerprint": self.fingerprint,
            "statement_kind": self.statement_kind,
            "label": self.label,
            "request_count": self.request_count,
            "error_count": self.error_count,
            "p50_ms": _percentile(durations, 0.50),
            "p95_ms": _percentile(durations, 0.95),
            "p99_ms": _percentile(durations, 0.99),
            "observed_at": self.observed_at,
        }


class AtlasObservabilityStore:
    """Atlas-local in-memory rollups shared by API and GUI surfaces."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._started_at = _utcnow_iso()
        self._endpoint_rollups: dict[tuple[str, str], EndpointRollup] = {}
        self._family_rollups: dict[str, FamilyRollup] = {}
        self._db_rollups: dict[str, DbQueryRollup] = {}
        self._db_probes: deque[dict[str, Any]] = deque(maxlen=25)
        self._auth_recent: deque[dict[str, Any]] = deque(maxlen=25)
        self._auth_status_counts: Counter[str] = Counter()
        self._obs_services_snapshot = self._build_obs_services_snapshot()

    def _build_obs_services_snapshot(self) -> dict[str, Any]:
        return {
            "status": "ok",
            "endpoints": [
                {"path": "/healthz", "auth": "none", "kind": "liveness"},
                {"path": "/readyz", "auth": "none", "kind": "readiness"},
                {"path": "/health", "auth": "operator_or_service_token", "kind": "summary"},
                {"path": "/obs_services", "auth": "operator_or_service_token", "kind": "discovery"},
                {"path": "/api_health", "auth": "operator_or_service_token", "kind": "api_rollup"},
                {"path": "/endpoint_health", "auth": "operator_or_service_token", "kind": "endpoint_rollup"},
                {"path": "/db_health", "auth": "operator_or_service_token", "kind": "database"},
                {"path": "/my_health", "auth": "authenticated_self", "kind": "self"},
                {"path": "/auth_health", "auth": "operator_or_service_token", "kind": "auth"},
                {"path": "/api/anomalies", "auth": "operator_or_service_token", "kind": "anomaly_list"},
                {"path": "/api/anomalies/{anomaly_id}", "auth": "operator_or_service_token", "kind": "anomaly_detail"},
            ],
            "extensions": [
                "atlas.admin_observability_ui",
                "atlas.anomalies_v1",
            ],
            "observed_at": self._started_at,
        }

    def projection(self, *, observed_at: str | None = None, detail: str | None = None) -> ProjectionMetadata:
        seen_at = observed_at or self._started_at
        return ProjectionMetadata(
            state="ready",
            stale=False,
            observed_at=seen_at,
            last_synced_at=seen_at,
            detail=detail,
        )

    def record_http_request(
        self,
        *,
        method: str,
        route_template: str,
        status_code: int,
        duration_ms: float,
        path: str,
    ) -> None:
        fingerprint = fingerprint_error(path)
        family = self._classify_family(route_template)
        key = (method.upper(), route_template)
        with self._lock:
            endpoint_rollup = self._endpoint_rollups.setdefault(
                key,
                EndpointRollup(method=method.upper(), route_template=route_template),
            )
            endpoint_rollup.record(
                status_code=status_code,
                duration_ms=duration_ms,
                fingerprint=fingerprint,
            )
            family_rollup = self._family_rollups.setdefault(family, FamilyRollup(family=family))
            family_rollup.record(status_code=status_code, duration_ms=duration_ms)

    def record_db_query(self, *, statement: str, duration_ms: float, success: bool) -> None:
        normalized = redact_sql_message(statement)
        statement_kind = (statement or "").strip().split(None, 1)[0].upper() if statement else "UNKNOWN"
        fingerprint, label = fingerprint_sql(normalized or statement_kind)
        with self._lock:
            rollup = self._db_rollups.setdefault(
                fingerprint,
                DbQueryRollup(
                    fingerprint=fingerprint,
                    statement_kind=statement_kind or "UNKNOWN",
                    label=label or statement_kind or "UNKNOWN",
                ),
            )
            rollup.record(duration_ms=duration_ms, success=success)

    def record_db_probe(self, *, status: str, latency_ms: float, detail: str) -> None:
        with self._lock:
            self._db_probes.appendleft(
                {
                    "status": status,
                    "latency_ms": round(float(latency_ms), 3),
                    "detail": redact_sql_message(detail),
                    "fingerprint": fingerprint_error(detail),
                    "observed_at": _utcnow_iso(),
                }
            )

    def record_auth_event(
        self,
        *,
        status: str,
        mode: str,
        detail: str,
        service_principal: bool = False,
    ) -> None:
        event = {
            "status": status,
            "mode": mode,
            "detail": redact_path_instance(detail),
            "service_principal": service_principal,
            "fingerprint": fingerprint_error(detail),
            "observed_at": _utcnow_iso(),
        }
        with self._lock:
            self._auth_recent.appendleft(event)
            self._auth_status_counts[status] += 1

    def health_snapshot(self) -> dict[str, Any]:
        latest_db = self.latest_db_probe()
        latest_auth = self._auth_recent[0] if self._auth_recent else None
        database_status = str((latest_db or {}).get("status") or "unknown")
        overall_status = "ok" if database_status in {"ok", "unknown"} else "degraded"
        return {
            "status": overall_status,
            "checks": {
                "process": {"status": "ok", "observed_at": _utcnow_iso()},
                "database": latest_db
                or {
                    "status": "unknown",
                    "latency_ms": None,
                    "detail": None,
                    "observed_at": None,
                },
                "auth": {
                    "status": str((latest_auth or {}).get("status") or "unknown"),
                    "mode": str((latest_auth or {}).get("mode") or ""),
                    "cognito_configured": bool(settings.cognito_domain and settings.cognito_user_pool_id),
                    "observed_at": (latest_auth or {}).get("observed_at"),
                },
            },
        }

    def obs_services_snapshot(self) -> tuple[ProjectionMetadata, dict[str, Any]]:
        snapshot = dict(self._obs_services_snapshot)
        observed_at = str(snapshot.get("observed_at") or self._started_at)
        return self.projection(observed_at=observed_at), snapshot

    def api_health(self) -> tuple[ProjectionMetadata, list[dict[str, Any]]]:
        with self._lock:
            families = [rollup.to_dict() for rollup in self._family_rollups.values()]
        families.sort(key=lambda item: (-int(item["request_count"]), item["family"]))
        observed_at = families[0]["observed_at"] if families else self._started_at
        return self.projection(observed_at=observed_at), families

    def endpoint_health(self, *, offset: int, limit: int) -> tuple[ProjectionMetadata, dict[str, Any]]:
        with self._lock:
            items = [rollup.to_dict() for rollup in self._endpoint_rollups.values()]
        items.sort(key=lambda item: (-int(item["request_count"]), item["route_template"], item["method"]))
        total = len(items)
        sliced = items[offset : offset + limit]
        observed_at = sliced[0]["observed_at"] if sliced else (items[0]["observed_at"] if items else self._started_at)
        return self.projection(observed_at=observed_at), {
            "total": total,
            "offset": offset,
            "limit": limit,
            "items": sliced,
        }

    def latest_db_probe(self) -> dict[str, Any] | None:
        with self._lock:
            return dict(self._db_probes[0]) if self._db_probes else None

    def db_health(self) -> tuple[ProjectionMetadata, dict[str, Any]]:
        with self._lock:
            latest = dict(self._db_probes[0]) if self._db_probes else None
            recent_queries = [rollup.to_dict() for rollup in self._db_rollups.values()]
        recent_queries.sort(key=lambda item: (-float(item["p95_ms"]), -int(item["request_count"]), item["label"]))
        hottest = sorted(recent_queries, key=lambda item: (-int(item["request_count"]), item["label"]))[:5]
        slowest = sorted(recent_queries, key=lambda item: (-float(item["p95_ms"]), item["label"]))[:5]
        observed_at = (latest or {}).get("observed_at") or (recent_queries[0]["observed_at"] if recent_queries else self._started_at)
        return self.projection(observed_at=observed_at), {
            "status": str((latest or {}).get("status") or "unknown"),
            "latest": latest,
            "recent": recent_queries[:25],
            "slowest": slowest,
            "hottest": hottest,
            "observed_at": observed_at,
        }

    def auth_health(self) -> tuple[ProjectionMetadata, dict[str, Any]]:
        with self._lock:
            recent = list(self._auth_recent)
            status_counts = dict(self._auth_status_counts)
        latest = recent[0] if recent else None
        observed_at = str((latest or {}).get("observed_at") or self._started_at)
        return self.projection(observed_at=observed_at), {
            "status": str((latest or {}).get("status") or "unknown"),
            "mode": str((latest or {}).get("mode") or settings.auth_mode),
            "cognito_configured": bool(settings.cognito_domain and settings.cognito_user_pool_id),
            "cognito_domain": settings.cognito_domain or "",
            "user_pool_id": settings.cognito_user_pool_id or "",
            "app_client_id_present": bool(settings.cognito_app_client_id),
            "recent": recent,
            "status_counts": status_counts,
            "observed_at": observed_at,
        }

    def _classify_family(self, route_template: str) -> str:
        path = route_template or "/"
        if path.startswith("/api/"):
            parts = [part for part in path.split("/") if part]
            return parts[1] if len(parts) > 1 else "api"
        if path.startswith("/auth"):
            return "auth"
        if path.startswith("/internal"):
            return "internal"
        if path.startswith("/admin"):
            return "admin"
        if path in {"/health", "/healthz", "/readyz", "/obs_services", "/api_health", "/endpoint_health", "/db_health", "/my_health", "/auth_health"}:
            return "observability"
        return "web"


def install_sqlalchemy_observability(store: AtlasObservabilityStore, sqlalchemy_engine) -> Any:
    """Attach SQLAlchemy listeners for DB performance tracking."""
    if getattr(sqlalchemy_engine, "_atlas_observability_installed", False):
        return lambda: None

    start_key = "_atlas_observability_start"

    def before_cursor_execute(conn, _cursor, statement, _parameters, _context, _executemany):
        stack = conn.info.setdefault(start_key, [])
        stack.append((time.monotonic(), statement))

    def after_cursor_execute(conn, _cursor, statement, _parameters, _context, _executemany):
        stack = conn.info.get(start_key, [])
        start_time, started_statement = stack.pop() if stack else (time.monotonic(), statement)
        store.record_db_query(
            statement=str(started_statement or statement),
            duration_ms=(time.monotonic() - start_time) * 1000,
            success=True,
        )

    def handle_error(exception_context):
        conn = exception_context.connection
        stack = conn.info.get(start_key, []) if conn is not None else []
        start_time, started_statement = stack.pop() if stack else (
            time.monotonic(),
            exception_context.statement,
        )
        store.record_db_query(
            statement=str(started_statement or exception_context.statement or "unknown"),
            duration_ms=(time.monotonic() - start_time) * 1000,
            success=False,
        )

    event.listen(sqlalchemy_engine, "before_cursor_execute", before_cursor_execute)
    event.listen(sqlalchemy_engine, "after_cursor_execute", after_cursor_execute)
    event.listen(sqlalchemy_engine, "handle_error", handle_error)
    setattr(sqlalchemy_engine, "_atlas_observability_installed", True)

    def cleanup() -> None:
        if not getattr(sqlalchemy_engine, "_atlas_observability_installed", False):
            return
        event.remove(sqlalchemy_engine, "before_cursor_execute", before_cursor_execute)
        event.remove(sqlalchemy_engine, "after_cursor_execute", after_cursor_execute)
        event.remove(sqlalchemy_engine, "handle_error", handle_error)
        setattr(sqlalchemy_engine, "_atlas_observability_installed", False)

    return cleanup
