"""Shared observability payload builders for Atlas."""

from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import Request

from app import __version__
from app.auth.dependencies import CurrentUser
from app.auth.session import get_server_instance_id
from app.observability.store import ProjectionMetadata
from app.settings import settings

CONTRACT_VERSION = "v3"
SERVICE_NAME = "atlas"


def _environment_name() -> str:
    return settings.deployment_name or os.environ.get("ENVIRONMENT") or settings.database_target or "dev"


def _build_sha() -> str:
    return (
        os.environ.get("ATLAS_BUILD_SHA")
        or os.environ.get("BUILD_SHA")
        or os.environ.get("GIT_SHA")
        or ""
    )


def _session_expiry(request: Request) -> str | None:
    authenticated_at = str(request.session.get("authenticated_at") or "").strip()
    if not authenticated_at:
        return None
    try:
        parsed = datetime.fromisoformat(authenticated_at)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    expires_at = parsed + timedelta(seconds=int(settings.session_max_age))
    return expires_at.isoformat()


def base_frame(request: Request, *, status: str) -> dict[str, Any]:
    return {
        "contract_version": CONTRACT_VERSION,
        "service": SERVICE_NAME,
        "environment": _environment_name(),
        "instance_id": get_server_instance_id(),
        "observed_at": datetime.now(UTC).isoformat(),
        "status": status,
        "request_id": getattr(request.state, "request_id", ""),
        "correlation_id": getattr(request.state, "correlation_id", ""),
        "build": {
            "version": __version__,
            "sha": _build_sha(),
        },
    }


def _status_for_projection(projection: ProjectionMetadata, ready_status: str) -> str:
    return ready_status if projection.state == "ready" else "unknown"


def _with_projection(payload: dict[str, Any], projection: ProjectionMetadata) -> dict[str, Any]:
    payload["projection"] = projection.model_dump()
    return payload


def build_health_payload(
    request: Request,
    *,
    projection: ProjectionMetadata,
    health_snapshot: dict[str, Any],
) -> dict[str, Any]:
    payload = base_frame(
        request,
        status=_status_for_projection(projection, str(health_snapshot.get("status") or "unknown")),
    )
    payload["checks"] = dict(health_snapshot.get("checks") or {})
    return _with_projection(payload, projection)


def build_obs_services_payload(
    request: Request,
    *,
    projection: ProjectionMetadata,
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    payload = base_frame(
        request,
        status=_status_for_projection(projection, str(snapshot.get("status") or "ok")),
    )
    payload["endpoints"] = list(snapshot.get("endpoints") or [])
    payload["extensions"] = list(snapshot.get("extensions") or [])
    return _with_projection(payload, projection)


def build_api_health_payload(
    request: Request,
    *,
    projection: ProjectionMetadata,
    families: list[dict[str, Any]],
) -> dict[str, Any]:
    payload = base_frame(request, status=_status_for_projection(projection, "ok"))
    payload["families"] = families
    return _with_projection(payload, projection)


def build_endpoint_health_payload(
    request: Request,
    *,
    projection: ProjectionMetadata,
    total: int,
    offset: int,
    limit: int,
    items: list[dict[str, Any]],
) -> dict[str, Any]:
    payload = base_frame(request, status=_status_for_projection(projection, "ok"))
    payload["page"] = {"total": total, "offset": offset, "limit": limit}
    payload["items"] = items
    return _with_projection(payload, projection)


def build_db_health_payload(
    request: Request,
    *,
    projection: ProjectionMetadata,
    db_health: dict[str, Any],
) -> dict[str, Any]:
    payload = base_frame(
        request,
        status=_status_for_projection(projection, str(db_health.get("status") or "unknown")),
    )
    payload["database"] = db_health
    return _with_projection(payload, projection)


def build_auth_health_payload(
    request: Request,
    *,
    projection: ProjectionMetadata,
    auth_rollup: dict[str, Any],
) -> dict[str, Any]:
    payload = base_frame(
        request,
        status=_status_for_projection(projection, str(auth_rollup.get("status") or "unknown")),
    )
    payload["auth"] = {
        "mode": str(auth_rollup.get("mode") or ""),
        "cognito_configured": bool(auth_rollup.get("cognito_configured", False)),
        "cognito_domain": str(auth_rollup.get("cognito_domain") or ""),
        "user_pool_id": str(auth_rollup.get("user_pool_id") or ""),
        "app_client_id_present": bool(auth_rollup.get("app_client_id_present", False)),
        "recent": list(auth_rollup.get("recent") or []),
        "status_counts": dict(auth_rollup.get("status_counts") or {}),
    }
    return _with_projection(payload, projection)


def build_my_health_payload(request: Request, user: CurrentUser) -> dict[str, Any]:
    payload = base_frame(request, status="ok")
    payload["principal"] = {
        "subject": user.sub,
        "email": user.email,
        "name": user.name,
        "roles": user.roles,
        "auth_mode": user.auth_mode,
        "expires_at": user.expires_at or _session_expiry(request),
        "service_principal": user.service_principal,
    }
    return payload
