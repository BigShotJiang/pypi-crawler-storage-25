"""Redaction and fingerprint helpers for Atlas observability."""

from __future__ import annotations

import hashlib
import re

_UUID_RE = re.compile(
    r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"
)
_LONG_DIGIT_RE = re.compile(r"\b\d{4,}\b")
_SINGLE_QUOTE_RE = re.compile(r"'(?:''|[^'])*'")
_DOUBLE_QUOTE_RE = re.compile(r'"(?:""|[^"])*"')
_NUMBER_RE = re.compile(r"\b\d+(?:\.\d+)?\b")
_WHITESPACE_RE = re.compile(r"\s+")
_SQL_KEYWORD_RE = re.compile(r"\b(select|insert|update|delete|alter|create|drop|with)\b", re.I)


def hash_identifier(value: str) -> str:
    """Hash an identifier to avoid echoing raw caller-provided values."""
    normalized = str(value or "").strip()
    if not normalized:
        return ""
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def redact_path_instance(path: str) -> str:
    """Redact likely instance identifiers from a concrete path."""
    redacted = _UUID_RE.sub("{id}", str(path or "").strip())
    return _LONG_DIGIT_RE.sub("{id}", redacted)


def normalize_sql(statement: str) -> str:
    """Normalize SQL text so metrics can be grouped without raw literals."""
    text = str(statement or "").strip()
    if not text:
        return ""
    text = _SINGLE_QUOTE_RE.sub("?", text)
    text = _DOUBLE_QUOTE_RE.sub("?", text)
    text = _NUMBER_RE.sub("?", text)
    text = _WHITESPACE_RE.sub(" ", text)
    return text[:400]


def redact_sql_message(message: str) -> str:
    """Collapse SQL-heavy details into a redacted summary."""
    normalized = normalize_sql(message)
    if not normalized:
        return ""
    if _SQL_KEYWORD_RE.search(normalized):
        return "[redacted-sql]"
    return normalized


def fingerprint_sql(statement: str) -> tuple[str, str]:
    """Return a stable fingerprint and a short normalized label for SQL text."""
    normalized = normalize_sql(statement)
    label = normalized[:120] if normalized else "unknown"
    return hash_identifier(normalized or "unknown"), label


def fingerprint_error(value: str) -> str:
    """Generate a stable fingerprint for an error detail."""
    return hash_identifier(redact_sql_message(redact_path_instance(value)))
