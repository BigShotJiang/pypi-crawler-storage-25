"""LSMC Atlas - FastAPI Application Entry Point."""

import copy
import logging
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from time import monotonic

from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import HTTPException as StarletteHTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import text
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app import __version__
from app.api.routes import (
    api_clients,
    anomalies,
    audit,
    auth,
    barcode,
    bloom_integration,
    bloom_lookups,
    clinicians,
    dewey_integration,
    documents,
    exceptions,
    fulfillment_runs,
    graph,
    groups,
    intake,
    internal,
    manifests,
    orgs,
    observability,
    people,
    releases,
    search_v2,
    shipments,
    support,
    themes,
    tracking,
    trfs,
    ursa_integration,
    user_api_tokens,
    webhooks,
)
from app.auth.dependencies import CurrentUser, WebAuthRedirect, require_docs_access
from app.auth.middleware import setup_session_middleware
from app.auth.rbac import Role
from app.db.engine import SessionLocal, get_engine
from app.domain_access import (
    build_allowed_origin_regex,
    build_trusted_hosts,
    is_allowed_origin,
)
from app.observability.anomalies import TapdbAnomalyRepository
from app.observability import AtlasObservabilityStore, install_sqlalchemy_observability
from app.observability.redaction import hash_identifier, redact_path_instance
from app.settings import settings
from app.web.exception_handler import global_exception_handler
from app.web.routes import router as web_router


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan handler for startup/shutdown events.

    Background job scheduling can be disabled via ENABLE_BACKGROUND_JOBS=false.
    In production, you should:
    1. Set ENABLE_BACKGROUND_JOBS=false for web worker processes
    2. Run a dedicated worker process with ENABLE_BACKGROUND_JOBS=true

    Example production deployment:
        # Web workers (multiple instances)
        ENABLE_BACKGROUND_JOBS=false uvicorn app.main:app --workers 4

        # Dedicated job worker (single instance)
        ENABLE_BACKGROUND_JOBS=true uvicorn app.main:app --workers 1
    """
    import logging

    logger = logging.getLogger(__name__)

    cleanup_sql_observability = lambda: None
    try:
        cleanup_sql_observability = install_sqlalchemy_observability(
            app.state.observability,
            get_engine(),
        )
    except Exception as exc:
        logger.warning("Atlas SQL observability install skipped: %s", exc)

    # Validate enabled Bloom integration configs on startup.
    from app.domain.services.external_objects import OrgBloomConfigService

    startup_db = SessionLocal()
    try:
        bloom_errors = OrgBloomConfigService(startup_db).validate_enabled_configs()
        started = monotonic()
        try:
            startup_db.execute(text("SELECT 1"))
            app.state.observability.record_db_probe(
                status="ok",
                latency_ms=(monotonic() - started) * 1000,
                detail="startup",
            )
        except Exception as exc:
            app.state.observability.record_db_probe(
                status="error",
                latency_ms=(monotonic() - started) * 1000,
                detail=str(exc),
            )
            TapdbAnomalyRepository(startup_db).record_db_probe_failure(
                detail=str(exc),
                latency_ms=(monotonic() - started) * 1000,
            )
    finally:
        startup_db.close()
    if bloom_errors and settings.bloom_fail_fast_on_config:
        joined = "; ".join(bloom_errors)
        raise RuntimeError(f"Bloom integration config validation failed: {joined}")

    if settings.enable_background_jobs:
        from app.domain.services.background_jobs import (
            get_scheduler,
            run_tracking_update_job,
        )
        from app.domain.services.bloom_polling import run_bloom_polling_job

        # Startup
        scheduler = get_scheduler()
        await scheduler.start()

        # Schedule FedEx tracking updates
        scheduler.schedule_recurring(
            "fedex_tracking_update",
            run_tracking_update_job,
            interval_seconds=settings.tracking_update_interval,
            db_factory=SessionLocal,
        )
        if settings.bloom_polling_enabled:
            scheduler.schedule_recurring(
                "bloom_reference_polling",
                run_bloom_polling_job,
                interval_seconds=settings.bloom_poll_interval_seconds,
                db_factory=SessionLocal,
            )
        logger.info(
            "Background jobs enabled. Tracking interval: %ss, Bloom polling: %s (%ss)",
            settings.tracking_update_interval,
            settings.bloom_polling_enabled,
            settings.bloom_poll_interval_seconds,
        )

        yield

        # Shutdown
        await scheduler.stop()
        cleanup_sql_observability()
    else:
        logger.info("Background jobs disabled (ENABLE_BACKGROUND_JOBS=false)")
        try:
            yield
        finally:
            cleanup_sql_observability()


def _audit_docs_access(user: CurrentUser, path: str) -> None:
    """Log docs access at DEBUG level. No DB audit needed for non-PHI docs views."""
    _logger = logging.getLogger(__name__)
    _logger.debug(
        "API docs accessed: user=%s role=%s path=%s",
        user.email,
        ",".join(user.roles),
        path,
    )


def _filter_openapi_for_external_admin(schema: dict) -> dict:
    """Return a copy of the OpenAPI schema with internal/admin-only paths removed.

    EXTERNAL_USER_ADMIN should only see /api/* routes that are relevant to
    external organization administrators.  We strip:
    - /internal/*   (LIMS integration)
    - /webhooks/*   (webhook management)
    - /api-clients/* (internal API client management)
    - /admin/*      (admin-only token management)
    - /api/intake/* , /api/exceptions/* (internal intake operations)
    - /api/barcode/* (internal barcode printing)
    - /api/fulfillment-runs/*, /api/results-sets/* (internal fulfillment runtime)
    - /api/tracking/* (internal tracking)
    - /auth/*       (auth flow — not useful in docs for ext admins)
    """
    hidden_prefixes = (
        "/internal",
        "/webhooks",
        "/api-clients",
        "/admin/",
        "/api/intake",
        "/api/exceptions",
        "/api/barcode",
        "/api/fulfillment-runs",
        "/api/results-sets",
        "/api/tracking",
        "/auth/",
        "/health",
        "/healthz",
        "/readyz",
        "/api/anomalies",
        "/obs_services",
        "/api_health",
        "/endpoint_health",
        "/db_health",
        "/my_health",
        "/auth_health",
    )

    filtered = copy.deepcopy(schema)
    original_paths = filtered.get("paths", {})
    filtered["paths"] = {
        path: spec for path, spec in original_paths.items() if not path.startswith(hidden_prefixes)
    }
    return filtered


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    allow_local_domain_access = settings.allow_local_domain_access
    app = FastAPI(
        title="LSMC Atlas",
        description="Clinical Sequencing Customer Portal",
        version=__version__,
        # Disable ALL built-in docs — we serve role-gated versions below
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        lifespan=lifespan,
    )
    app.state.observability = AtlasObservabilityStore()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[],
        allow_origin_regex=build_allowed_origin_regex(allow_local=allow_local_domain_access),
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

    # Exception handler for web auth redirect
    @app.exception_handler(WebAuthRedirect)
    async def web_auth_redirect_handler(request: Request, exc: WebAuthRedirect) -> RedirectResponse:
        """Redirect unauthenticated web requests to login page."""
        return RedirectResponse(url="/login", status_code=302)

    # Global exception handler — registered as outermost middleware below

    # Custom HTTP error handlers — HTML for browser, JSON for API
    error_templates = Jinja2Templates(directory="app/web/templates")

    def _is_api(request: Request) -> bool:
        """Check if request expects JSON vs HTML (browser).

        Returns True for:
        - /api/* routes (REST API)
        - /auth/* routes (OAuth callbacks — not browsed directly by users)
        - Requests with Accept: application/json (without text/html)
        """
        path = request.url.path
        if path.startswith("/api/") or path.startswith("/auth/") or path in {
            "/health",
            "/healthz",
            "/readyz",
            "/obs_services",
            "/api_health",
            "/endpoint_health",
            "/db_health",
            "/my_health",
            "/auth_health",
        }:
            return True
        accept = request.headers.get("accept", "")
        return "application/json" in accept and "text/html" not in accept

    @app.exception_handler(401)
    async def unauthorized_handler(request: Request, exc: StarletteHTTPException):
        """Custom 401 — Authentication Required."""
        if _is_api(request):
            return JSONResponse(
                status_code=401,
                content={"detail": exc.detail or "Not authenticated"},
                headers=getattr(exc, "headers", None) or {},
            )
        return error_templates.TemplateResponse(
            request,
            "errors/401.html",
            status_code=401,
        )

    @app.exception_handler(403)
    async def forbidden_handler(request: Request, exc: StarletteHTTPException):
        """Custom 403 — Access Denied."""
        if _is_api(request):
            return JSONResponse(
                status_code=403,
                content={"detail": exc.detail or "Forbidden"},
            )
        return error_templates.TemplateResponse(
            request,
            "errors/403.html",
            status_code=403,
        )

    @app.exception_handler(404)
    async def not_found_handler(request: Request, exc: StarletteHTTPException):
        """Custom 404 — Not Found."""
        if _is_api(request):
            return JSONResponse(
                status_code=404,
                content={"detail": "Not found"},
            )
        return error_templates.TemplateResponse(
            request,
            "errors/404.html",
            status_code=404,
        )

    # Mount static files with no-cache headers for development
    from starlette.middleware.base import BaseHTTPMiddleware

    class NoCacheStaticMiddleware(BaseHTTPMiddleware):
        """Add no-cache headers for static files in development."""

        async def dispatch(self, request: Request, call_next):
            response = await call_next(request)
            if request.url.path.startswith("/static/"):
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
            return response

    app.add_middleware(NoCacheStaticMiddleware)

    class SecurityHeadersMiddleware(BaseHTTPMiddleware):
        """Add security headers to all responses."""

        async def dispatch(self, request: Request, call_next):
            response = await call_next(request)

            # Prevent clickjacking
            response.headers["X-Frame-Options"] = "DENY"

            # Prevent MIME type sniffing
            response.headers["X-Content-Type-Options"] = "nosniff"

            # XSS protection (legacy browsers)
            response.headers["X-XSS-Protection"] = "1; mode=block"

            # Referrer policy - don't leak full URL to external sites
            response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

            # Permissions policy - disable unnecessary browser features
            response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"

            # Content Security Policy
            response.headers["Content-Security-Policy"] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
                "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.googleapis.com; "
                "font-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.gstatic.com; "
                "img-src 'self' data:; "
                "connect-src 'self'; "
                "frame-ancestors 'none'"
            )

            # HSTS - only in production (when not in debug mode)
            if not settings.debug:
                response.headers["Strict-Transport-Security"] = (
                    "max-age=31536000; includeSubDomains"
                )

            return response

    app.add_middleware(SecurityHeadersMiddleware)

    class ObservabilityMiddleware(BaseHTTPMiddleware):
        """Capture request IDs, correlation IDs, and endpoint rollups."""

        async def dispatch(self, request: Request, call_next):
            request_id = request.headers.get("x-request-id", "") or os.urandom(8).hex()
            correlation_source = request.headers.get("x-correlation-id", "") or request_id
            request.state.request_id = request_id
            request.state.correlation_id = hash_identifier(correlation_source)
            started = monotonic()
            response = await call_next(request)

            response.headers["X-Request-ID"] = request_id
            response.headers["X-Correlation-ID"] = request.state.correlation_id

            if not request.url.path.startswith("/static/"):
                route = request.scope.get("route")
                route_template = getattr(route, "path", None) or redact_path_instance(request.url.path)
                app.state.observability.record_http_request(
                    method=request.method,
                    route_template=str(route_template),
                    status_code=response.status_code,
                    duration_ms=(monotonic() - started) * 1000,
                    path=str(request.url.path),
                )
            return response

    app.add_middleware(ObservabilityMiddleware)

    # Global exception middleware — registered after SessionMiddleware below
    # so it remains outermost and catches unhandled exceptions from downstream
    # middleware (including TapDB mount auth checks).
    class GlobalExceptionMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            try:
                return await call_next(request)
            except Exception as exc:
                return await global_exception_handler(request, exc)

    class AllowedOriginMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            origin = request.headers.get("origin")
            if origin and not is_allowed_origin(origin, allow_local=allow_local_domain_access):
                return PlainTextResponse("Origin not allowed", status_code=403)
            return await call_next(request)

    app.mount(
        "/static",
        StaticFiles(directory="app/web/static"),
        name="static",
    )

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon() -> RedirectResponse:
        return RedirectResponse(url="/static/favicon.ico", status_code=307)

    class TapdbMountAuthMiddleware(BaseHTTPMiddleware):
        """Protect mounted TapDB GUI with Atlas session auth."""

        async def dispatch(self, request: Request, call_next):
            path = request.url.path
            if not (path == "/tapdb" or path.startswith("/tapdb/")):
                return await call_next(request)

            from app.auth.dependencies import _get_current_user_from_session

            user = _get_current_user_from_session(request)
            if user is None:
                if path.startswith("/tapdb/api/"):
                    return JSONResponse(status_code=401, content={"detail": "Not authenticated"})
                return RedirectResponse(url="/login", status_code=302)

            if not (user.has_role(Role.ADMIN) or user.has_role(Role.INTERNAL_USER)):
                if path.startswith("/tapdb/api/"):
                    return JSONResponse(status_code=403, content={"detail": "Forbidden"})
                return HTMLResponse("<h1>403 Forbidden</h1>", status_code=403)

            return await call_next(request)

    app.add_middleware(TapdbMountAuthMiddleware)

    # Session middleware must run before middleware that accesses request.session
    # (e.g., TapDB mount auth checks). Add it after route/middleware definitions
    # so its execution order is ahead of those checks.
    setup_session_middleware(app)
    app.add_middleware(GlobalExceptionMiddleware)
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=build_trusted_hosts(allow_local=allow_local_domain_access),
    )
    app.add_middleware(AllowedOriginMiddleware)

    try:
        os.environ.setdefault("TAPDB_ADMIN_DISABLE_AUTH", "true")
        from admin.main import app as tapdb_admin_app

        app.mount("/tapdb", tapdb_admin_app)
    except Exception as exc:
        logging.getLogger(__name__).warning("TapDB UI mount skipped: %s", exc)

    # -----------------------------------------------------------------
    # Role-gated API documentation endpoints
    # Allowed: ADMIN, INTERNAL_USER, EXTERNAL_USER_ADMIN
    # EXTERNAL_USER_ADMIN gets a filtered schema (no internal routes)
    # -----------------------------------------------------------------

    @app.get("/docs", include_in_schema=False)
    async def custom_swagger_ui_html(
        current_user: CurrentUser = Depends(require_docs_access),
    ) -> HTMLResponse:
        """Swagger UI documentation (role-gated)."""
        _audit_docs_access(current_user, "/docs")
        return get_swagger_ui_html(
            openapi_url="/openapi.json",
            title=f"{app.title} - Swagger UI",
        )

    @app.get("/api/docs", include_in_schema=False)
    async def api_swagger_ui_html(
        current_user: CurrentUser = Depends(require_docs_access),
    ) -> HTMLResponse:
        """Swagger UI documentation at /api/docs (role-gated)."""
        _audit_docs_access(current_user, "/api/docs")
        return get_swagger_ui_html(
            openapi_url="/openapi.json",
            title=f"{app.title} - Swagger UI",
        )

    @app.get("/redoc", include_in_schema=False)
    async def custom_redoc_html(
        current_user: CurrentUser = Depends(require_docs_access),
    ) -> HTMLResponse:
        """ReDoc documentation (role-gated)."""
        _audit_docs_access(current_user, "/redoc")
        return get_redoc_html(
            openapi_url="/openapi.json",
            title=f"{app.title} - ReDoc",
        )

    @app.get("/api/redoc", include_in_schema=False)
    async def api_redoc_html(
        current_user: CurrentUser = Depends(require_docs_access),
    ) -> HTMLResponse:
        """ReDoc documentation at /api/redoc (role-gated)."""
        _audit_docs_access(current_user, "/api/redoc")
        return get_redoc_html(
            openapi_url="/openapi.json",
            title=f"{app.title} - ReDoc",
        )

    def _get_openapi_schema() -> dict:
        """Generate the OpenAPI schema (cached on app state)."""
        if not hasattr(app, "_openapi_schema_cache") or app._openapi_schema_cache is None:
            app._openapi_schema_cache = get_openapi(
                title=app.title,
                version=app.version,
                description=app.description,
                routes=app.routes,
            )
        return app._openapi_schema_cache

    @app.get("/openapi.json", include_in_schema=False)
    async def custom_openapi(
        current_user: CurrentUser = Depends(require_docs_access),
    ) -> JSONResponse:
        """OpenAPI schema (role-gated, filtered for EXTERNAL_USER_ADMIN).

        ADMIN / INTERNAL_USER see the full schema.
        EXTERNAL_USER_ADMIN sees a filtered schema without internal routes.
        """
        _audit_docs_access(current_user, "/openapi.json")

        schema = _get_openapi_schema()

        # Filter for external admin users
        if current_user.has_role(Role.EXTERNAL_USER_ADMIN) and not current_user.is_internal:
            schema = _filter_openapi_for_external_admin(schema)

        return JSONResponse(content=schema)

    # Include API routers
    app.include_router(auth.router)
    app.include_router(anomalies.router)
    app.include_router(observability.router)
    app.include_router(orgs.router)
    app.include_router(orgs.sites_router)
    app.include_router(people.router)
    app.include_router(clinicians.router)
    app.include_router(trfs.trf_router)
    app.include_router(shipments.router)
    app.include_router(shipments.testkits_router)
    app.include_router(manifests.router)
    app.include_router(documents.router)
    app.include_router(intake.router)
    app.include_router(exceptions.router)
    app.include_router(releases.router)
    app.include_router(releases.artifacts_router)
    app.include_router(webhooks.router)
    app.include_router(api_clients.router)
    app.include_router(support.router)
    app.include_router(internal.router)
    app.include_router(barcode.router)
    app.include_router(tracking.router)
    app.include_router(themes.router)
    app.include_router(themes.user_router)
    app.include_router(fulfillment_runs.router)
    app.include_router(fulfillment_runs.results_sets_router)
    app.include_router(user_api_tokens.router)
    app.include_router(user_api_tokens.admin_router)
    app.include_router(groups.router)
    app.include_router(audit.router)
    app.include_router(graph.router)
    app.include_router(search_v2.router)
    app.include_router(search_v2.alias_router)
    app.include_router(bloom_integration.router)
    app.include_router(bloom_lookups.router)
    app.include_router(dewey_integration.router)
    app.include_router(ursa_integration.router)

    # Include web routes (server-rendered pages)
    app.include_router(web_router)

    return app


# Create the application instance
app = create_app()
