"""LSMC Atlas - Application Settings.

Configuration is loaded in the following order (later sources override earlier):
1. Default values defined in the Settings class
2. YAML config file at ~/.config/lsmc-atlas/config.yaml (or XDG_CONFIG_HOME)
3. Environment variables for non-Cognito settings
4. .env file (deprecated, for backward compatibility)

The YAML config file is the preferred method for configuration.
Run `atlas config create` to create the config file from template.
"""

import json
import logging
import os
import secrets
import warnings
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)

# XDG Base Directory spec
XDG_CONFIG_HOME = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
CONFIG_DIR = XDG_CONFIG_HOME / "lsmc-atlas"
CONFIG_FILE = CONFIG_DIR / "config.yaml"

# Generate secure default secret key if not provided
_DEFAULT_SECRET_KEY = os.environ.get("SECRET_KEY") or secrets.token_urlsafe(64)


def _validate_optional_https_url(value: str, *, field_name: str) -> str:
    normalized = str(value or "").strip()
    if not normalized:
        return ""
    if not normalized.startswith("https://"):
        raise ValueError(f"{field_name} must use an absolute https:// URL")
    return normalized.rstrip("/")


def _load_yaml_config() -> dict[str, Any]:
    """Load configuration from YAML file if it exists.

    Returns:
        Dict of configuration values, or empty dict if file doesn't exist.
    """
    if not CONFIG_FILE.exists():
        return {}

    try:
        import yaml

        with open(CONFIG_FILE) as f:
            config = yaml.safe_load(f) or {}
        logger.debug(f"Loaded config from {CONFIG_FILE}")
        return config
    except ImportError:
        logger.warning("PyYAML not installed, cannot load YAML config file")
        return {}
    except Exception as e:
        logger.warning(f"Failed to load config from {CONFIG_FILE}: {e}")
        return {}


def _flatten_yaml_config(config: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    """Flatten nested YAML config to match environment variable names.

    Example:
        {"database": {"url": "..."}} -> {"database_url": "..."}
        {"authentication": {"cognito": {"region": "..."}}} -> {"cognito_region": "..."}
    """
    result: dict[str, Any] = {}

    # Special mappings for nested YAML structure to flat env var names
    section_mappings = {
        "application": {
            "app_name": "app_name",
            "debug": "debug",
            "secret_key": "secret_key",
        },
        "database": {
            "url": "database_url",
            "backend": "database_backend",
            "target": "database_target",
            "cluster_id": "database_cluster_id",
            "namespace": "database_namespace",
        },
        "authentication": {
            "mode": "auth_mode",
            "session_max_age": "session_max_age",
            "session_cookie_name": "session_cookie_name",
        },
        "authentication.cognito": {
            "region": "cognito_region",
            "user_pool_id": "cognito_user_pool_id",
            "app_client_id": "cognito_app_client_id",
            "app_client_secret": "cognito_app_client_secret",
            "client_name": "cognito_client_name",
            "domain": "cognito_domain",
            "redirect_uri": "cognito_redirect_uri",
            "logout_url": "cognito_logout_url",
            "aws_profile": "cognito_aws_profile",
            "aws_region": "cognito_aws_region",
            "auto_provision_users": "cognito_auto_provision_users",
            "default_tenant_id": "cognito_default_tenant_id",
            "group_role_map": "cognito_group_role_map",
            "allowed_email_domains": "allowed_email_domains",
            "blocked_email_domains": "blocked_email_domains",
        },
        "authentication.google": {
            "client_id": "google_client_id",
            "client_secret": "google_client_secret",
            "redirect_uri": "google_redirect_uri",
            "enabled": "google_oauth_enabled",
            "hd": "google_hd",
        },
        "aws": {
            "profile": "aws_profile",
            "region": "aws_region",
            "s3_bucket": "s3_bucket",
            "s3_region": "s3_region",
        },
        "internal_api": {
            "key": "internal_api_key",
        },
        "external": {
            "analysis_ui_url": "analysis_ui_url",
            "lims_ui_url": "lims_ui_url",
            "bloom_ui_url": "bloom_ui_url",
            "bloom_base_url": "bloom_base_url",
            "bloom_max_retries": "bloom_max_retries",
            "bloom_verify_ssl": "bloom_verify_ssl",
            "bloom_polling_enabled": "bloom_polling_enabled",
            "bloom_poll_interval_seconds": "bloom_poll_interval_seconds",
            "bloom_default_container_template_code": "bloom_default_container_template_code",
            "bloom_allowed_specimen_template_codes": "bloom_allowed_specimen_template_codes",
            "dewey_enabled": "dewey_enabled",
            "dewey_base_url": "dewey_base_url",
            "dewey_api_token": "dewey_api_token",
            "dewey_verify_ssl": "dewey_verify_ssl",
            "dewey_request_timeout_seconds": "dewey_request_timeout_seconds",
            "graph_default_depth": "graph_default_depth",
            "graph_max_depth": "graph_max_depth",
            "graph_max_nodes": "graph_max_nodes",
            "graph_max_edges": "graph_max_edges",
        },
        "captcha": {
            "provider": "captcha_provider",
            "site_key": "captcha_site_key",
            "secret_key": "captcha_secret_key",
            "score_threshold": "captcha_score_threshold",
        },
        "background_jobs": {
            "enabled": "enable_background_jobs",
            "tracking_update_interval": "tracking_update_interval",
        },
        "deployment": {
            "name": "deployment_name",
            "color": "deployment_color",
            "is_production": "deployment_is_production",
        },
    }

    def process_section(section_name: str, section_data: dict[str, Any]) -> None:
        if not isinstance(section_data, dict):
            return
        mapping = section_mappings.get(section_name, {})
        for key, value in section_data.items():
            if key in mapping:
                flat_key = mapping[key]
                # Handle dict values (like group_role_map) - convert to JSON string
                if isinstance(value, dict) and flat_key == "cognito_group_role_map":
                    result[flat_key] = json.dumps(value)
                elif value is not None and value != "":
                    result[flat_key] = value

    # Process top-level sections
    for section, data in config.items():
        if isinstance(data, dict):
            process_section(section, data)
            # Process nested sections (e.g., authentication.cognito)
            for nested_key, nested_data in data.items():
                if isinstance(nested_data, dict):
                    nested_section = f"{section}.{nested_key}"
                    process_section(nested_section, nested_data)

    return result


# Default mapping of Cognito User Pool Groups to LSMC Atlas roles
# Cognito groups are case-sensitive. This maps group names to role lists.
DEFAULT_COGNITO_GROUP_ROLE_MAP: dict[str, list[str]] = {
    # External customers - read/write access to their own tenant
    "lsmc-customers": ["EXTERNAL_USER"],
    # External customer admins - org-level management within their tenant
    "lsmc-customer-admins": ["EXTERNAL_USER", "EXTERNAL_USER_ADMIN"],
    # Read-only access (e.g., auditors, reviewers)
    "lsmc-readonly": ["READ_ONLY"],
    # Internal LSMC staff - can access all tenants for intake operations
    "lsmc-staff": ["INTERNAL_USER"],
    # Administrators - full access
    "platform-admin": ["ADMIN"],
    "atlas-admin": ["ADMIN"],
}


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Application
    app_name: str = "LSMC Atlas"
    debug: bool = False
    secret_key: str = Field(
        default=_DEFAULT_SECRET_KEY,
        min_length=32,
    )

    # Database
    # TapDB-only runtime: DATABASE_URL is resolved from TapDB config at startup.
    database_url: str = Field(default="")
    database_backend: Literal["tapdb"] = "tapdb"
    database_target: Literal["local", "aurora"] = "local"
    database_cluster_id: str = ""
    database_namespace: str = "lsmc-atlas"

    # Authentication
    auth_mode: Literal["cognito"] = "cognito"

    # Cognito settings (required when auth_mode="cognito")
    cognito_region: str = "us-west-2"
    cognito_user_pool_id: str = ""
    cognito_app_client_id: str = ""
    cognito_app_client_secret: str = ""
    cognito_client_name: str = ""
    cognito_domain: str = ""
    cognito_redirect_uri: str = "https://localhost:8915/auth/callback"
    cognito_logout_url: str = ""
    cognito_aws_profile: str = ""
    cognito_aws_region: str = ""

    # Cognito group-to-role mapping (JSON string, parsed to dict)
    # Example: '{"platform-admin": ["ADMIN"], "atlas-admin": ["ADMIN"]}'
    cognito_group_role_map: str = ""

    # Whether to auto-provision users on first login (if they don't exist in UserProfile)
    # When True, users will be created with default roles from their Cognito groups
    # When False, users must be pre-provisioned by an admin
    cognito_auto_provision_users: bool = False

    # Default tenant ID for auto-provisioned users (required if auto_provision is True)
    # In production, you would likely look this up from a custom Cognito attribute
    cognito_default_tenant_id: str = ""

    # Allowed email domains for authentication.
    # Empty list blocks all domains. Use ["*"] to allow all domains.
    # Example: ["lsmc.bio", "lsmc.com", "daylilyinformatics.com"]
    allowed_email_domains: list[str] = Field(default_factory=lambda: ["lsmc.com"])

    # Blocked email domains (takes precedence over allowed_email_domains).
    # Emails from these domains are always rejected, even if the domain is in allowed list.
    blocked_email_domains: list[str] = Field(default_factory=list)

    # Google OAuth settings (optional - enables "Sign in with Google" alongside Cognito)
    # When enabled, Google-authenticated users are auto-created in the Cognito user pool
    google_oauth_enabled: bool = False
    google_client_id: str = ""
    google_client_secret: str = ""
    google_redirect_uri: str = "https://localhost:8915/auth/google/callback"
    # Restrict Google login to a specific Google Workspace domain (optional)
    google_hd: str = ""

    # AWS
    aws_profile: str = "lsmc"
    aws_region: str = "us-west-2"
    s3_bucket: str = ""
    s3_region: str = "us-west-2"

    # External links
    analysis_ui_url: str = "https://localhost:8914"
    lims_ui_url: str = "https://localhost:8912"
    bloom_ui_url: str = "https://localhost:8913"
    bloom_base_url: str = ""
    bloom_request_timeout_seconds: float = 20.0
    bloom_max_retries: int = 2
    bloom_verify_ssl: bool = True
    bloom_fail_fast_on_config: bool = True
    bloom_polling_enabled: bool = False
    bloom_poll_interval_seconds: int = 60
    bloom_default_container_template_code: str = "container/tube/tube-generic-10ml/1.0"
    bloom_allowed_specimen_template_codes: list[str] = Field(
        default_factory=lambda: [
            "content/specimen/blood-whole/1.0",
            "content/specimen/buccal-swab/1.0",
        ]
    )
    dewey_enabled: bool = False
    dewey_base_url: str = ""
    dewey_api_token: str = ""
    dewey_verify_ssl: bool = True
    dewey_request_timeout_seconds: float = 10.0
    graph_default_depth: int = 4
    graph_max_depth: int = 10
    graph_max_nodes: int = 500
    graph_max_edges: int = 2000

    # Session
    session_max_age: int = 3600 * 8  # 8 hours
    session_cookie_name: str = "lsmc_atlas_session"

    # Deployment chrome
    deployment_name: str = ""
    deployment_color: str = "#0f766e"
    deployment_is_production: bool = False

    # Internal API authentication (for LIMS-to-Atlas communication)
    internal_api_key: str = Field(default_factory=lambda: secrets.token_urlsafe(32))

    # CAPTCHA settings
    captcha_provider: Literal["recaptcha", "hcaptcha", "simple"] = "simple"
    captcha_site_key: str = ""
    captcha_secret_key: str = ""
    captcha_score_threshold: float = 0.5

    # Background job settings
    # Set to False to disable background jobs in web workers (for production scaling)
    # In production, run a dedicated worker process with ENABLE_BACKGROUND_JOBS=true
    enable_background_jobs: bool = True
    # FedEx tracking update interval in seconds (default: 30 minutes)
    tracking_update_interval: int = 1800

    # Maximum file upload size in bytes (default: 50 MB)
    max_upload_size_bytes: int = 50 * 1024 * 1024  # 50 MB

    @field_validator("secret_key")
    @classmethod
    def validate_secret_key(cls, v: str) -> str:
        """Validate secret key - generate secure one if needed."""
        if v.startswith("change-me"):
            import warnings

            warnings.warn(
                "Using default SECRET_KEY. Set a secure value in production!",
                stacklevel=2,
            )
            # In development, auto-generate a secure key
            return secrets.token_urlsafe(64)
        return v

    @field_validator("internal_api_key")
    @classmethod
    def validate_internal_api_key(cls, v: str) -> str:
        """Warn if using default internal API key."""
        if v == "dev-internal-key":
            warnings.warn(
                "Using default INTERNAL_API_KEY ('dev-internal-key'). "
                "Set a secure value in production!",
                stacklevel=2,
            )
        return v

    @field_validator("bloom_base_url")
    @classmethod
    def validate_bloom_base_url(cls, v: str) -> str:
        return _validate_optional_https_url(v, field_name="bloom_base_url")

    @field_validator("dewey_base_url")
    @classmethod
    def validate_dewey_base_url(cls, v: str) -> str:
        return _validate_optional_https_url(v, field_name="dewey_base_url")

    @model_validator(mode="after")
    def validate_cross_system_integrations(self) -> "Settings":
        if self.dewey_enabled:
            if not str(self.dewey_base_url or "").strip():
                raise ValueError("dewey_base_url is required when dewey_enabled=true")
            if not str(self.dewey_api_token or "").strip():
                raise ValueError("dewey_api_token is required when dewey_enabled=true")
        return self

    @property
    def cognito_issuer(self) -> str:
        """Get the Cognito issuer URL."""
        return (
            f"https://cognito-idp.{self.cognito_region}.amazonaws.com/{self.cognito_user_pool_id}"
        )

    @property
    def cognito_jwks_url(self) -> str:
        """Get the Cognito JWKS URL."""
        return f"{self.cognito_issuer}/.well-known/jwks.json"

    @property
    def cognito_authorize_url(self) -> str:
        """Get the Cognito authorization URL."""
        return f"https://{self.cognito_domain}/oauth2/authorize"

    @property
    def cognito_token_url(self) -> str:
        """Get the Cognito token URL."""
        return f"https://{self.cognito_domain}/oauth2/token"

    @property
    def cognito_logout_endpoint(self) -> str:
        """Get the Cognito hosted-ui logout endpoint URL."""
        return f"https://{self.cognito_domain}/logout"

    @property
    def allow_local_domain_access(self) -> bool:
        """Allow localhost browser origins for local Atlas development/runtime.

        Atlas local mode commonly runs with debug disabled, so tying local-origin
        acceptance to debug alone breaks real browser form posts in local mode.
        Production-like targets keep the stricter domain-only policy.
        """
        return self.debug or self.database_target == "local"

    def get_cognito_group_role_mapping(self) -> dict[str, list[str]]:
        """Get the Cognito group-to-role mapping.

        Merges the default mapping with any custom mapping from the environment.
        Custom mappings override defaults for the same group name.

        Returns:
            Dict mapping Cognito group names to lists of LSMC Atlas roles
        """
        # Start with defaults
        mapping = DEFAULT_COGNITO_GROUP_ROLE_MAP.copy()

        # Override with custom mapping if provided
        if self.cognito_group_role_map:
            try:
                custom = json.loads(self.cognito_group_role_map)
                if isinstance(custom, dict):
                    mapping.update(custom)
            except json.JSONDecodeError:
                import logging

                logging.getLogger(__name__).warning(
                    "Failed to parse COGNITO_GROUP_ROLE_MAP as JSON, using defaults"
                )

        return mapping

    def map_cognito_groups_to_roles(self, cognito_groups: list[str]) -> list[str]:
        """Map Cognito User Pool groups to LSMC Atlas roles.

        Args:
            cognito_groups: List of Cognito group names from the user's token

        Returns:
            List of unique LSMC Atlas role names
        """
        mapping = self.get_cognito_group_role_mapping()
        roles: set[str] = set()

        for group in cognito_groups:
            if group in mapping:
                roles.update(mapping[group])

        # Return sorted for consistency
        return sorted(roles)

    def validate_email_domain(self, email: str) -> tuple[bool, str]:
        """Validate email domain against allowed/blocked domain lists.

        Args:
            email: Email address to validate

        Returns:
            Tuple of (is_valid, error_message).
            error_message is empty string if valid.
        """
        if not email:
            return False, "Email address is required"

        if "@" not in email:
            return False, "Invalid email address format"

        domain = email.split("@")[-1].strip().lower()
        if not domain:
            return False, "Invalid email address: missing domain"

        # Check blocked domains first (takes precedence)
        if self.blocked_email_domains:
            blocked_lower = [d.lower() for d in self.blocked_email_domains]
            if domain in blocked_lower:
                return False, f"Email domain '{domain}' is blocked"

        # Empty list = block all
        if not self.allowed_email_domains:
            return False, "Email domain authentication is not enabled"

        # ["*"] = allow all
        if self.allowed_email_domains == ["*"]:
            return True, ""

        # Check against allowed domains
        allowed_lower = [d.lower() for d in self.allowed_email_domains]
        if domain not in allowed_lower:
            allowed_str = ", ".join(self.allowed_email_domains)
            return False, f"Email domain '{domain}' is not allowed. Restricted to: {allowed_str}"

        return True, ""

    @property
    def deployment(self) -> dict[str, str | bool]:
        return {
            "name": self.deployment_name,
            "color": self.deployment_color,
            "is_production": self.deployment_is_production,
        }


def _check_env_file_deprecation() -> None:
    """Warn if using deprecated .env file without YAML config."""
    env_file = Path(".env")
    if env_file.exists() and not CONFIG_FILE.exists():
        warnings.warn(
            "Using .env file for configuration is deprecated. "
            f"Please migrate to {CONFIG_FILE}. "
            "Run 'atlas config create' to create the config file.",
            DeprecationWarning,
            stacklevel=3,
        )


def _apply_tapdb_database_defaults() -> None:
    """Backfill DATABASE_URL from TapDB config when using tapdb backend."""
    if os.environ.get("DATABASE_URL"):
        return

    backend = (os.environ.get("DATABASE_BACKEND", "tapdb") or "tapdb").strip().lower()
    if backend and backend != "tapdb":
        logger.warning("DATABASE_BACKEND=%s is unsupported; forcing tapdb", backend)
        os.environ["DATABASE_BACKEND"] = "tapdb"

    target = (os.environ.get("DATABASE_TARGET", "local") or "local").strip().lower()
    profile = (os.environ.get("AWS_PROFILE", "lsmc") or "lsmc").strip()
    region = (os.environ.get("AWS_REGION", "us-west-2") or "us-west-2").strip()
    namespace = (os.environ.get("DATABASE_NAMESPACE", "lsmc-atlas") or "lsmc-atlas").strip()

    try:
        from app.integrations.tapdb_runtime import TapDBRuntimeError, export_database_url_for_target

        export_database_url_for_target(
            target=target,
            profile=profile,
            region=region,
            namespace=namespace,
        )
    except (ImportError, TapDBRuntimeError) as exc:
        logger.debug("TapDB DATABASE_URL auto-resolution skipped: %s", exc)


COGNITO_YAML_ONLY_FIELDS = {
    "auth_mode",
    "cognito_region",
    "cognito_user_pool_id",
    "cognito_app_client_id",
    "cognito_app_client_secret",
    "cognito_client_name",
    "cognito_domain",
    "cognito_redirect_uri",
    "cognito_logout_url",
    "cognito_aws_profile",
    "cognito_aws_region",
    "cognito_group_role_map",
    "cognito_auto_provision_users",
    "cognito_default_tenant_id",
    "allowed_email_domains",
    "blocked_email_domains",
    "deployment_name",
    "deployment_color",
    "deployment_is_production",
}


def _settings_field_default(field_name: str) -> Any:
    field = Settings.model_fields[field_name]
    if field.default_factory is not None:
        return field.default_factory()
    return field.default


def _yaml_only_settings_seed(flat_config: dict[str, Any]) -> dict[str, Any]:
    seed: dict[str, Any] = {}
    for field_name in COGNITO_YAML_ONLY_FIELDS:
        if field_name in flat_config:
            seed[field_name] = flat_config[field_name]
        else:
            seed[field_name] = _settings_field_default(field_name)
    return seed


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance.

    Configuration is loaded in this order:
    1. Default values
    2. YAML config file (~/.config/lsmc-atlas/config.yaml)
    3. Environment variables (override YAML)
    4. .env file (deprecated fallback)

    Returns:
        Settings instance with merged configuration.
    """
    # Load YAML config and flatten to match env var names
    yaml_config = _load_yaml_config()
    flat_config = _flatten_yaml_config(yaml_config)

    # Atlas is tapdb-only. Keep env harmonized even if stale config carries
    # an old backend field value.
    effective_backend = "tapdb"
    os.environ["DATABASE_BACKEND"] = "tapdb"
    settings_seed = _yaml_only_settings_seed(flat_config)

    # Set environment variables from YAML (env vars still take precedence
    # because pydantic-settings reads env vars after we set these)
    for key, value in flat_config.items():
        if key in COGNITO_YAML_ONLY_FIELDS:
            continue
        env_key = key.upper()
        if (
            key == "database_url"
            and effective_backend == "tapdb"
            and "DATABASE_URL" not in os.environ
        ):
            # In tapdb-first mode, runtime URL must come from TapDB config.
            continue
        # Only set if not already in environment (preserves env var precedence)
        if env_key not in os.environ:
            if isinstance(value, bool):
                os.environ[env_key] = str(value).lower()
            elif isinstance(value, list):
                os.environ[env_key] = json.dumps(value)
            elif value is not None:
                os.environ[env_key] = str(value)

    # Resolve DATABASE_URL from TapDB config in tapdb-first mode.
    _apply_tapdb_database_defaults()

    # Check for deprecated .env usage
    _check_env_file_deprecation()

    return Settings(**settings_seed)


def get_config_file_path() -> Path:
    """Get the path to the config file."""
    return CONFIG_FILE


def get_config_dir() -> Path:
    """Get the path to the config directory."""
    return CONFIG_DIR


def config_file_exists() -> bool:
    """Check if the config file exists."""
    return CONFIG_FILE.exists()


# Global settings instance
settings = get_settings()
