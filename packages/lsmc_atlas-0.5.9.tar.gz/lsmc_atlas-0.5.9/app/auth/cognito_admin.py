"""LSMC Atlas — Cognito Admin Operations.

Uses daylily-cognito as the Cognito integration boundary for admin-initiated
user provisioning from Atlas services.
"""

import json
import logging
from typing import Any

from botocore.exceptions import ClientError
from daylily_cognito import CognitoAuth

from app.settings import settings

logger = logging.getLogger(__name__)


class CognitoAdminError(Exception):
    """Raised when a Cognito admin operation fails."""

    pass


class UserAlreadyExistsError(CognitoAdminError):
    """Raised when the user already exists in Cognito."""

    pass


def _attrs_to_dict(attrs: list[dict[str, Any]] | None) -> dict[str, str]:
    if not attrs:
        return {}
    out: dict[str, str] = {}
    for item in attrs:
        name = str(item.get("Name") or "").strip()
        if not name:
            continue
        out[name] = str(item.get("Value") or "")
    return out


def _has_google_identity(attrs: dict[str, str]) -> bool:
    identities_raw = (attrs.get("identities") or "").strip()
    if not identities_raw:
        return False
    try:
        parsed = json.loads(identities_raw)
    except json.JSONDecodeError:
        return False
    if not isinstance(parsed, list):
        return False
    for identity in parsed:
        if not isinstance(identity, dict):
            continue
        provider = str(identity.get("providerName") or "").strip().lower()
        if provider == "google":
            return True
    return False


def _get_client():
    """Get a Cognito IDP client via daylily-cognito."""
    auth = CognitoAuth(
        region=settings.cognito_region,
        user_pool_id=settings.cognito_user_pool_id,
        app_client_id=settings.cognito_app_client_id,
        app_client_secret=settings.cognito_app_client_secret or None,
        profile=settings.cognito_aws_profile or settings.aws_profile or None,
    )
    return auth.cognito


def admin_find_user_by_email(email: str) -> dict[str, Any] | None:
    """Find a Cognito user by email, returning a normalized dict.

    This is used by admin tooling to resolve Cognito ``sub`` for an existing
    user (including federated users like Google IdP) without creating users.

    Returns:
        Dict with keys: username, sub, email, name, attributes
        or None if no user matches.

    Raises:
        CognitoAdminError: On API failure or ambiguous matches.
    """
    normalized_email = str(email).strip()
    if not normalized_email:
        raise CognitoAdminError("Email is required")

    client = _get_client()
    try:
        response = client.list_users(
            UserPoolId=settings.cognito_user_pool_id,
            Filter=f'email = "{normalized_email}"',
            Limit=60,
        )
    except ClientError as exc:
        logger.error("Cognito ListUsers failed: %s", exc)
        raise CognitoAdminError(str(exc)) from exc

    users = response.get("Users") or []
    if not users:
        return None

    candidates: list[dict[str, Any]] = []
    for user in users:
        username = str(user.get("Username") or "").strip()
        attrs = _attrs_to_dict(user.get("Attributes"))
        sub = (attrs.get("sub") or "").strip()
        candidate = {
            "username": username,
            "sub": sub,
            "email": (attrs.get("email") or normalized_email).strip(),
            "name": (attrs.get("name") or attrs.get("preferred_username") or "").strip() or None,
            "attributes": attrs,
        }
        candidates.append(candidate)

    if len(candidates) == 1:
        return candidates[0]

    google_candidates = [c for c in candidates if _has_google_identity(c["attributes"])]
    if len(google_candidates) == 1:
        return google_candidates[0]

    # Ambiguous.  Provide enough info to disambiguate without dumping attributes.
    summary = ", ".join(
        f"{c.get('username') or '(unknown)'} (sub={c.get('sub') or 'n/a'})" for c in candidates
    )
    raise CognitoAdminError(f"Ambiguous Cognito users for email {normalized_email}: {summary}")


def admin_create_user(
    email: str,
    name: str | None = None,
    *,
    suppress_invitation: bool = False,
) -> str:
    """Create a user in Cognito via AdminCreateUser.

    Cognito sends an invitation email with a temporary password.
    The user is placed in FORCE_CHANGE_PASSWORD state.

    Args:
        email: User's email address (used as the Cognito username).
        name: Optional display name.
        suppress_invitation: If True, suppress the invitation email
            (caller handles notification).

    Returns:
        The Cognito ``sub`` (unique user identifier).

    Raises:
        UserAlreadyExistsError: If a Cognito user with that email exists.
        CognitoAdminError: On any other Cognito API failure.
    """
    client = _get_client()

    user_attributes = [
        {"Name": "email", "Value": email},
        {"Name": "email_verified", "Value": "true"},
    ]
    if name:
        user_attributes.append({"Name": "name", "Value": name})

    kwargs: dict[str, Any] = {
        "UserPoolId": settings.cognito_user_pool_id,
        "Username": email,
        "UserAttributes": user_attributes,
        "DesiredDeliveryMediums": ["EMAIL"],
    }
    # Only pass MessageAction when suppressing.  Omitting the key lets
    # Cognito send the default invitation email for new users.
    if suppress_invitation:
        kwargs["MessageAction"] = "SUPPRESS"

    try:
        response = client.admin_create_user(**kwargs)
    except ClientError as exc:
        code = exc.response["Error"]["Code"]
        if code == "UsernameExistsException":
            raise UserAlreadyExistsError(
                f"A Cognito user with email {email} already exists"
            ) from exc
        logger.error("Cognito AdminCreateUser failed: %s", exc)
        raise CognitoAdminError(str(exc)) from exc

    # Extract the sub from the returned user attributes
    attrs = {a["Name"]: a["Value"] for a in response["User"].get("Attributes", [])}
    cognito_sub = attrs.get("sub")
    if not cognito_sub:
        raise CognitoAdminError("Cognito did not return a sub attribute")

    logger.info("Created Cognito user %s (sub=%s)", email, cognito_sub)
    return cognito_sub


def admin_add_user_to_group(username: str, group_name: str) -> None:
    """Add a Cognito user to a group.

    Args:
        username: The Cognito username (email).
        group_name: The Cognito group name.

    Raises:
        CognitoAdminError: On API failure.
    """
    client = _get_client()
    try:
        client.admin_add_user_to_group(
            UserPoolId=settings.cognito_user_pool_id,
            Username=username,
            GroupName=group_name,
        )
        logger.info("Added user %s to Cognito group %s", username, group_name)
    except ClientError as exc:
        logger.error("Cognito AdminAddUserToGroup failed: %s", exc)
        raise CognitoAdminError(str(exc)) from exc


def admin_disable_user(username: str) -> None:
    """Disable a user in Cognito (prevents sign-in).

    Args:
        username: The Cognito username (email).

    Raises:
        CognitoAdminError: On API failure.
    """
    client = _get_client()
    try:
        client.admin_disable_user(
            UserPoolId=settings.cognito_user_pool_id,
            Username=username,
        )
        logger.info("Disabled Cognito user %s", username)
    except ClientError as exc:
        logger.error("Cognito AdminDisableUser failed: %s", exc)
        raise CognitoAdminError(str(exc)) from exc


def admin_enable_user(username: str) -> None:
    """Enable a previously disabled user in Cognito.

    Args:
        username: The Cognito username (email).

    Raises:
        CognitoAdminError: On API failure.
    """
    client = _get_client()
    try:
        client.admin_enable_user(
            UserPoolId=settings.cognito_user_pool_id,
            Username=username,
        )
        logger.info("Enabled Cognito user %s", username)
    except ClientError as exc:
        logger.error("Cognito AdminEnableUser failed: %s", exc)
        raise CognitoAdminError(str(exc)) from exc
