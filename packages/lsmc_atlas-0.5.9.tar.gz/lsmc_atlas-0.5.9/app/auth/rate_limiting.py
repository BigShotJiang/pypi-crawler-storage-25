"""LSMC Hub - Rate Limiting.

Provides DDoS protection and rate limiting for sensitive endpoints.
Uses in-memory storage with optional database persistence.
"""

import time
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field

from fastapi import HTTPException, Request, status


@dataclass
class RateLimitConfig:
    """Configuration for rate limiting."""

    requests_per_minute: int = 60
    requests_per_hour: int = 1000
    burst_limit: int = 10  # Max requests in a 1-second burst
    block_duration_seconds: int = 300  # Block duration after exceeding limits


@dataclass
class RateLimitState:
    """State for a single rate limit key."""

    minute_requests: list[float] = field(default_factory=list)
    hour_requests: list[float] = field(default_factory=list)
    blocked_until: float | None = None


class RateLimiter:
    """In-memory rate limiter with configurable limits."""

    def __init__(self, config: RateLimitConfig | None = None):
        self.config = config or RateLimitConfig()
        self._state: dict[str, RateLimitState] = defaultdict(RateLimitState)

    def _cleanup_old_requests(self, state: RateLimitState, now: float) -> None:
        """Remove requests older than the tracking window."""
        minute_ago = now - 60
        hour_ago = now - 3600
        state.minute_requests = [t for t in state.minute_requests if t > minute_ago]
        state.hour_requests = [t for t in state.hour_requests if t > hour_ago]

    def is_blocked(self, key: str) -> bool:
        """Check if a key is currently blocked."""
        state = self._state[key]
        if state.blocked_until and time.time() < state.blocked_until:
            return True
        if state.blocked_until and time.time() >= state.blocked_until:
            state.blocked_until = None
        return False

    def check_rate_limit(self, key: str) -> tuple[bool, str | None]:
        """Check if request is allowed.

        Returns:
            Tuple of (is_allowed, error_message)
        """
        now = time.time()
        state = self._state[key]

        # Check if blocked
        if self.is_blocked(key):
            remaining = int(state.blocked_until - now) if state.blocked_until else 0
            return False, f"Rate limit exceeded. Try again in {remaining} seconds."

        # Cleanup old requests
        self._cleanup_old_requests(state, now)

        # Check burst limit (requests in last second)
        second_ago = now - 1
        recent_requests = [t for t in state.minute_requests if t > second_ago]
        if len(recent_requests) >= self.config.burst_limit:
            state.blocked_until = now + self.config.block_duration_seconds
            return False, "Burst limit exceeded. Please slow down."

        # Check per-minute limit
        if len(state.minute_requests) >= self.config.requests_per_minute:
            state.blocked_until = now + self.config.block_duration_seconds
            return False, "Per-minute rate limit exceeded."

        # Check per-hour limit
        if len(state.hour_requests) >= self.config.requests_per_hour:
            state.blocked_until = now + self.config.block_duration_seconds
            return False, "Per-hour rate limit exceeded."

        # Request allowed - record it
        state.minute_requests.append(now)
        state.hour_requests.append(now)
        return True, None

    def get_remaining(self, key: str) -> dict:
        """Get remaining request counts."""
        state = self._state[key]
        now = time.time()
        self._cleanup_old_requests(state, now)
        return {
            "remaining_per_minute": max(
                0, self.config.requests_per_minute - len(state.minute_requests)
            ),
            "remaining_per_hour": max(0, self.config.requests_per_hour - len(state.hour_requests)),
        }

    def reset(self) -> None:
        """Reset all rate limit state. Useful for testing."""
        self._state.clear()


# Default rate limiters for different endpoint types
# In dev mode, use relaxed limits; in production, use stricter limits
from app.settings import settings  # noqa: E402

_dev_limiters: dict[str, RateLimiter] = {
    "default": RateLimiter(RateLimitConfig(requests_per_minute=600, requests_per_hour=10000)),
    "auth": RateLimiter(
        RateLimitConfig(requests_per_minute=100, requests_per_hour=500, burst_limit=20)
    ),
    # OAuth callbacks may legitimately be retried by browsers/IdP redirects.
    "auth_callback": RateLimiter(
        RateLimitConfig(requests_per_minute=300, requests_per_hour=2000, burst_limit=30)
    ),
    "api": RateLimiter(RateLimitConfig(requests_per_minute=600, requests_per_hour=10000)),
    "sensitive": RateLimiter(
        RateLimitConfig(requests_per_minute=50, requests_per_hour=200, burst_limit=10)
    ),
}

_prod_limiters: dict[str, RateLimiter] = {
    "default": RateLimiter(RateLimitConfig(requests_per_minute=60, requests_per_hour=1000)),
    "auth": RateLimiter(
        RateLimitConfig(requests_per_minute=10, requests_per_hour=50, burst_limit=3)
    ),
    # Keep callback protection, but avoid frequent false-positive lockouts.
    "auth_callback": RateLimiter(
        RateLimitConfig(requests_per_minute=60, requests_per_hour=500, burst_limit=10)
    ),
    "api": RateLimiter(RateLimitConfig(requests_per_minute=120, requests_per_hour=2000)),
    "sensitive": RateLimiter(
        RateLimitConfig(requests_per_minute=5, requests_per_hour=20, burst_limit=2)
    ),
}

_limiters = _dev_limiters if settings.debug else _prod_limiters


def get_limiter(limiter_type: str = "default") -> RateLimiter:
    """Get a rate limiter by type."""
    return _limiters.get(limiter_type, _limiters["default"])


def reset_all_limiters() -> None:
    """Reset all rate limiter state. Useful for testing."""
    for limiter in _dev_limiters.values():
        limiter.reset()
    for limiter in _prod_limiters.values():
        limiter.reset()


def get_client_ip(request: Request) -> str:
    """Extract client IP from request, considering proxies."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip
    return request.client.host if request.client else "unknown"


def rate_limit_dependency(limiter_type: str = "default") -> Callable:
    """Create a FastAPI dependency for rate limiting.

    Usage:
        @router.post("/login")
        async def login(
            request: Request,
            _: None = Depends(rate_limit_dependency("auth"))
        ):
            ...
    """

    async def check_rate_limit(request: Request) -> None:
        limiter = get_limiter(limiter_type)
        client_ip = get_client_ip(request)
        key = f"{limiter_type}:{client_ip}"

        allowed, error_msg = limiter.check_rate_limit(key)
        if not allowed:
            remaining = limiter.get_remaining(key)
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=error_msg,
                headers={
                    "Retry-After": str(limiter.config.block_duration_seconds),
                    "X-RateLimit-Remaining-Minute": str(remaining["remaining_per_minute"]),
                    "X-RateLimit-Remaining-Hour": str(remaining["remaining_per_hour"]),
                },
            )

    return check_rate_limit
