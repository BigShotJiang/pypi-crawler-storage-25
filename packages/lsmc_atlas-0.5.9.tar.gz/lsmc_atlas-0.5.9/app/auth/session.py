"""LSMC Hub - Session Management.

Manages server instance tracking for session invalidation on server restart.
"""

import secrets

# Server instance ID - changes on each server restart
# Used to invalidate sessions from previous server instances
_SERVER_INSTANCE_ID: str = secrets.token_urlsafe(16)


def get_server_instance_id() -> str:
    """Get the current server instance ID.

    This ID is generated once when the module is loaded and remains constant
    for the lifetime of the server process. When the server restarts, a new
    ID is generated, causing sessions from the previous instance to be invalidated.

    Returns:
        The current server instance ID (16-byte URL-safe base64 string)
    """
    return _SERVER_INSTANCE_ID
