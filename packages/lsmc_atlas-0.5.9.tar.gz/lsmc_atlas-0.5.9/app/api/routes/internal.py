"""LSMC Hub - Internal API Routes.

Internal API for LIMS and downstream systems to push data into Hub.
These endpoints use separate authentication (API keys or service tokens).
"""

import hmac
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.rate_limiting import rate_limit_dependency
from app.db.engine import get_db
from app.domain.services.releases import ReleasePackageCreate, ReleaseService
from app.domain.services.trfs import TestService, TrfService
from app.settings import settings

router = APIRouter(prefix="/internal", tags=["internal"])


# --- Internal Auth ---


async def verify_internal_api_key(
    x_api_key: Annotated[str | None, Header()] = None,
) -> str:
    """Verify internal API key for LIMS integration."""
    if not x_api_key or not hmac.compare_digest(x_api_key, settings.internal_api_key):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )
    return x_api_key


# --- Request Schemas ---


class StatusUpdateRequest(BaseModel):
    """Request to update Test status from LIMS."""

    tenant_id: uuid.UUID
    test_euid: str
    status: str = Field(..., pattern="^(IN_PROGRESS|COMPLETED|FAILED|CANCELED)$")
    lims_accession_id: str | None = None
    notes: str | None = None


class ReleaseCreateRequest(BaseModel):
    """Request to create a release package from LIMS."""

    tenant_id: uuid.UUID
    trf_euid: str
    release_type: str = Field("INITIAL", pattern="^(INITIAL|AMENDED|CORRECTED)$")
    artifact_ids: list[str] = Field(default_factory=list)
    notes: str | None = None


# --- Endpoints ---


@router.post(
    "/status-updates",
    dependencies=[Depends(verify_internal_api_key), Depends(rate_limit_dependency("api"))],
)
async def update_test_order_status(
    request: StatusUpdateRequest,
    db: Session = Depends(get_db),
) -> dict:
    """Update Test status from LIMS."""
    svc = TestService(db, request.tenant_id)

    # Map status string to enum
    from app.domain.enums import TestOrderStatus

    try:
        target_status = TestOrderStatus(request.status)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid status: {request.status}",
        )

    result = svc.change_status(
        request.test_euid,
        target_status,
        lims_accession_id=request.lims_accession_id,
        notes=request.notes,
    )

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Test not found",
        )

    return {
        "status": "updated",
        "test_euid": request.test_euid,
        "new_status": request.status,
    }


@router.post(
    "/releases",
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(verify_internal_api_key), Depends(rate_limit_dependency("api"))],
)
async def create_release_package(
    request: ReleaseCreateRequest,
    db: Session = Depends(get_db),
) -> dict:
    """Create and optionally release a package from LIMS."""
    svc = ReleaseService(db, request.tenant_id)

    package, revision = svc.create_package(
        ReleasePackageCreate(
            order_id=request.trf_euid,
            release_type=request.release_type,
            artifact_ids=request.artifact_ids,
            notes=request.notes,
        )
    )

    return {
        "status": "created",
        "package_id": str(package.id),
        "package_number": package.package_number,
    }


@router.post(
    "/releases/{package_id}/release",
    dependencies=[Depends(verify_internal_api_key), Depends(rate_limit_dependency("api"))],
)
async def release_package(
    package_id: str,
    tenant_id: uuid.UUID,
    db: Session = Depends(get_db),
) -> dict:
    """Mark a release package as released."""
    svc = ReleaseService(db, tenant_id)

    result = svc.release(package_id)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Release package not found",
        )

    if isinstance(result, tuple):
        package, revision = result
    else:
        package = result
        revision = svc._get_latest_revision(package.id)  # pylint: disable=protected-access

    return {
        "status": "released",
        "package_id": str(package.id),
        "package_number": package.package_number,
        "released_at": revision.released_at.isoformat()
        if revision and revision.released_at
        else None,
    }


@router.get(
    "/trfs/{trf_euid}",
    dependencies=[Depends(verify_internal_api_key)],
)
async def get_trf_for_lims(
    trf_euid: str,
    tenant_id: uuid.UUID,
    db: Session = Depends(get_db),
) -> dict:
    """Get TRF details for LIMS processing."""
    svc = TrfService(db, tenant_id)
    result = svc.get(trf_euid)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="TRF not found",
        )

    trf, trf_rev = result

    tests_svc = TestService(db, tenant_id)
    tests = tests_svc.list_for_trf(trf_euid)

    # Prefer graph-native Test↔Patient links. Fall back to legacy TRF revision.patient_id.
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderRelationshipService

    patient_euid: str | None = getattr(trf_rev, "patient_id", None)
    rel_svc = OrderRelationshipService(db, tenant_id)
    for test, _test_rev, _fulfillment_routes in tests:
        links = rel_svc.list_order_patient_links(order_euid=test.euid)
        if not links:
            continue
        proband = next(
            (lnk.patient_euid for lnk in links if lnk.role == OrderPatientRole.PROBAND),
            None,
        )
        patient_euid = proband or links[0].patient_euid
        break

    return {
        "trf_euid": trf.euid,
        "trf_number": trf.order_number,
        "tenant_id": str(trf.tenant_id),
        "status": trf_rev.status,
        "patient_euid": str(patient_euid) if patient_euid else "",
        "clinician_euid": str(trf_rev.clinician_id) if trf_rev.clinician_id else "",
        "tests": [
            {
                "test_euid": test.euid,
                "fulfillment_routes": [
                    {"code": route.fulfillment_route_code, "name": route.fulfillment_route_name}
                    for route in fulfillment_routes
                ],
                "status": test_rev.status if test_rev else "PENDING",
                "priority": test_rev.priority if test_rev else "NORMAL",
            }
            for test, test_rev, fulfillment_routes in tests
        ],
    }
