"""Assay workflow API routes."""

from __future__ import annotations

import logging
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.api.routes.internal import verify_internal_api_key
from app.db.engine import get_db
from app.domain.enums import FulfillmentRunState
from app.domain.policies.fulfillment_state_machine import (
    ALLOWED_TRANSITIONS,
    TransitionError,
    can_transition,
    is_terminal,
    validate_transition,
)
from app.domain.policies.fulfillment_state_machine import (
    FulfillmentRunState as PolicyFulfillmentRunState,
)
from app.domain.services.fulfillment_runs import (
    AmendmentCreate,
    FulfillmentOutputService,
    FulfillmentRunService,
    InvalidTransitionError,
    ResultCreate,
    ResultsSetService,
    TransitionData,
)
from app.persistence.tapdb.fulfillment_run_repo import TapdbFulfillmentRunRepository
from app.persistence.tapdb.trfs import TapdbTrfRepository

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/fulfillment-runs", tags=["assay-workflow"])
results_sets_router = APIRouter(prefix="/api/results-sets", tags=["results-sets"])


class FulfillmentRunResponse(BaseModel):
    euid: str
    trf_euid: str
    test_euid: str
    fulfillment_route_code: str
    status: str
    accession_id: str | None = None
    qc_hold_reason: str | None = None
    note: str | None = None
    revision_no: int
    created_at: str
    updated_at: str
    next_valid_transitions: list[str]
    is_terminal: bool


class TransitionRequest(BaseModel):
    next_state: str = Field(..., description="Target state for the transition")
    note: str | None = Field(None, description="Optional note for the transition")
    qc_hold_reason: str | None = Field(None, description="Required when transitioning to QC_HOLD")
    qc_override: bool = Field(False, description="Required for QC_HOLD → RESULTED transition")
    accession_id: str | None = Field(None, description="Accession ID for ACCESSIONED state")


class ResultRequest(BaseModel):
    result_payload: dict = Field(..., description="Result data as JSON")
    artifact_ids: list[str] | None = Field(None, description="List of artifact IDs")
    note: str | None = Field(None, description="Optional note")
    qc_override: bool = Field(False, description="Required if assay is in QC_HOLD")


class AmendRequest(BaseModel):
    amends_result_id: str = Field(..., description="ID of the result being amended")
    amend_reason: str = Field(..., min_length=1, description="Reason for amendment")
    result_payload: dict = Field(..., description="New result data")
    artifact_ids: list[str] | None = Field(None, description="List of artifact IDs")


class FulfillmentOutputResponse(BaseModel):
    euid: str
    fulfillment_run_euid: str
    version_no: int
    result_payload: dict
    artifact_ids: list[str] | None = None
    amends_result_euid: str | None = None
    amend_reason: str | None = None
    created_at: str
    created_by: str | None = None


class ResultsSetResponse(BaseModel):
    euid: str
    test_euid: str
    trf_euid: str | None = None
    published_at: str | None = None
    published_by: str | None = None
    note: str | None = None
    created_at: str
    fulfillment_run_count: int = 0


class PublishRequest(BaseModel):
    note: str | None = Field(None, description="Optional note for publishing")


def _build_assay_run_response(ar, ar_rev) -> FulfillmentRunResponse:
    current_state = FulfillmentRunState(ar_rev.status)
    next_transitions = list(
        ALLOWED_TRANSITIONS.get(PolicyFulfillmentRunState(current_state.value), set())
    )
    return FulfillmentRunResponse(
        euid=ar.euid,
        trf_euid=ar.order_id,
        test_euid=ar.test_order_id,
        fulfillment_route_code=ar.fulfillment_route_code,
        status=ar_rev.status,
        accession_id=ar_rev.accession_id,
        qc_hold_reason=ar_rev.qc_hold_reason,
        note=ar_rev.note,
        revision_no=ar_rev.revision_no,
        created_at=ar.created_at.isoformat() if ar.created_at else "",
        updated_at=ar_rev.created_at.isoformat() if ar_rev.created_at else "",
        next_valid_transitions=[s.value for s in next_transitions],
        is_terminal=is_terminal(PolicyFulfillmentRunState(current_state.value)),
    )


def _build_result_response(result) -> FulfillmentOutputResponse:
    return FulfillmentOutputResponse(
        euid=result.euid,
        fulfillment_run_euid=result.fulfillment_run_euid,
        version_no=result.version_no,
        result_payload=result.result_payload or {},
        artifact_ids=result.artifact_ids if result.artifact_ids else None,
        amends_result_euid=result.amends_result_euid if result.amends_result_euid else None,
        amend_reason=result.amend_reason,
        created_at=result.created_at.isoformat() if result.created_at else "",
        created_by=str(result.created_by) if result.created_by else None,
    )


def _build_results_set_response(
    rs,
    *,
    fulfillment_run_count: int = 0,
    trf_euid: str | None = None,
) -> ResultsSetResponse:
    return ResultsSetResponse(
        euid=rs.euid,
        test_euid=rs.test_euid,
        trf_euid=trf_euid,
        published_at=rs.published_at.isoformat() if rs.published_at else None,
        published_by=str(rs.published_by) if rs.published_by else None,
        note=rs.note,
        created_at=rs.created_at.isoformat() if rs.created_at else "",
        fulfillment_run_count=fulfillment_run_count,
    )


def _assay_repo(db: Session) -> TapdbFulfillmentRunRepository:
    return TapdbFulfillmentRunRepository(db)


def _trf_repo(db: Session) -> TapdbTrfRepository:
    return TapdbTrfRepository(db)


def _resolve_tenant_for_trf(db: Session, trf_euid: str) -> uuid.UUID:
    trf = _trf_repo(db).get_trf_by_id(trf_id=trf_euid, tenant_id=None)
    if trf is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="TRF not found")
    return trf.tenant_id


def _resolve_tenant_for_test(db: Session, test_euid: str) -> uuid.UUID:
    test = _trf_repo(db).get_test_by_id(test_id=test_euid, tenant_id=None)
    if test is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test not found")
    return test.tenant_id


def _get_assay_run_any_tenant(db: Session, fulfillment_run_euid: str):
    assay_run = _assay_repo(db).get_fulfillment_run_by_euid(
        fulfillment_run_euid=fulfillment_run_euid, tenant_id=None
    )
    if assay_run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assay run not found")
    return assay_run


def _get_results_set_any_tenant(db: Session, results_set_euid: str):
    results_set = _assay_repo(db).get_results_set_by_euid(
        results_set_euid=results_set_euid, tenant_id=None
    )
    if results_set is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Results set not found")
    return results_set


def _resolve_trf_euid_for_results_set(db: Session, test_euid: str) -> str | None:
    test = _trf_repo(db).get_test_by_id(test_id=test_euid, tenant_id=None)
    return str(test.order_id) if test is not None else None


@router.get("", response_model=list[FulfillmentRunResponse])
async def list_assay_runs(
    trf_euid: Annotated[str | None, Query(description="Filter by TRF EUID")] = None,
    test_euid: Annotated[str | None, Query(description="Filter by Test EUID")] = None,
    _api_key: str = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> list[FulfillmentRunResponse]:
    if not trf_euid and not test_euid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one of trf_euid or test_euid is required",
        )

    tenant_id = (
        _resolve_tenant_for_trf(db, trf_euid)
        if trf_euid is not None
        else _resolve_tenant_for_test(db, test_euid)
    )
    svc = FulfillmentRunService(db, tenant_id)
    rows = svc.list_for_trf(trf_euid) if trf_euid else svc.list_for_test_order(test_euid)
    return [_build_assay_run_response(ar, ar_rev) for ar, ar_rev in rows]


@router.get("/{fulfillment_run_euid}", response_model=FulfillmentRunResponse)
async def get_assay_run(
    fulfillment_run_euid: str,
    _api_key: str = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> FulfillmentRunResponse:
    assay_run = _get_assay_run_any_tenant(db, fulfillment_run_euid)
    svc = FulfillmentRunService(db, assay_run.tenant_id)
    result = svc.get(fulfillment_run_euid)
    if result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assay run not found")
    ar, ar_rev = result
    return _build_assay_run_response(ar, ar_rev)


@router.post("/{fulfillment_run_euid}/transition", response_model=FulfillmentRunResponse)
async def transition_assay_run(
    fulfillment_run_euid: str,
    request: TransitionRequest,
    _api_key: str = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> FulfillmentRunResponse:
    assay_run = _get_assay_run_any_tenant(db, fulfillment_run_euid)
    try:
        target_state = FulfillmentRunState(request.next_state)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid state: {request.next_state}. Valid states: {[s.value for s in FulfillmentRunState]}",
        ) from exc

    svc = FulfillmentRunService(db, assay_run.tenant_id)
    try:
        ar, ar_rev = svc.transition(
            fulfillment_run_euid,
            TransitionData(
                target_state=target_state,
                note=request.note,
                qc_hold_reason=request.qc_hold_reason,
                qc_override=request.qc_override,
                accession_id=request.accession_id,
            ),
            transition_by=None,
        )
    except InvalidTransitionError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid state transition.",
        ) from None
    db.commit()
    return _build_assay_run_response(ar, ar_rev)


@router.post("/{fulfillment_run_euid}/result", response_model=FulfillmentOutputResponse)
async def create_result(
    fulfillment_run_euid: str,
    request: ResultRequest,
    _api_key: str = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> FulfillmentOutputResponse:
    assay_run = _get_assay_run_any_tenant(db, fulfillment_run_euid)
    tenant_id = assay_run.tenant_id
    ar_svc = FulfillmentRunService(db, tenant_id)
    result_svc = FulfillmentOutputService(db, tenant_id)
    rs_svc = ResultsSetService(db, tenant_id)

    current = ar_svc.get(fulfillment_run_euid)
    if current is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assay run not found")
    _, ar_rev = current
    current_state = FulfillmentRunState(ar_rev.status)
    try:
        validate_transition(
            PolicyFulfillmentRunState(current_state.value),
            PolicyFulfillmentRunState(FulfillmentRunState.RESULTED.value),
            qc_override=request.qc_override,
        )
    except TransitionError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    fulfillment_output = result_svc.create(
        fulfillment_run_euid=fulfillment_run_euid,
        data=ResultCreate(
            result_payload=request.result_payload,
            artifact_ids=request.artifact_ids,
        ),
        created_by=None,
    )
    ar_svc.transition(
        fulfillment_run_euid,
        TransitionData(
            target_state=FulfillmentRunState.RESULTED,
            note=request.note,
            qc_override=request.qc_override,
        ),
        transition_by=None,
    )
    results_set = rs_svc.get_or_create_for_test(assay_run.test_order_id, created_by=None)
    rs_svc.add_fulfillment_run(results_set.euid, fulfillment_run_euid)
    db.commit()
    return _build_result_response(fulfillment_output)


@router.post("/{fulfillment_run_euid}/amend", response_model=FulfillmentOutputResponse)
async def amend_result(
    fulfillment_run_euid: str,
    request: AmendRequest,
    _api_key: str = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> FulfillmentOutputResponse:
    assay_run = _get_assay_run_any_tenant(db, fulfillment_run_euid)
    tenant_id = assay_run.tenant_id
    ar_svc = FulfillmentRunService(db, tenant_id)
    result_svc = FulfillmentOutputService(db, tenant_id)
    rs_svc = ResultsSetService(db, tenant_id)

    current = ar_svc.get(fulfillment_run_euid)
    if current is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assay run not found")
    _, ar_rev = current
    current_state = FulfillmentRunState(ar_rev.status)
    if not can_transition(
        PolicyFulfillmentRunState(current_state.value),
        PolicyFulfillmentRunState(FulfillmentRunState.AMENDED.value),
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot transition from {current_state.value} to AMENDED",
        )

    fulfillment_output = result_svc.create_amendment(
        fulfillment_run_euid=fulfillment_run_euid,
        data=AmendmentCreate(
            original_result_euid=request.amends_result_id,
            amend_reason=request.amend_reason,
            result_payload=request.result_payload,
            artifact_ids=request.artifact_ids,
        ),
        created_by=None,
    )
    ar_svc.transition(
        fulfillment_run_euid,
        TransitionData(
            target_state=FulfillmentRunState.AMENDED,
            note=f"Amendment: {request.amend_reason}",
        ),
        transition_by=None,
    )
    results_set = rs_svc.get_or_create_for_test(assay_run.test_order_id, created_by=None)
    rs_svc.add_fulfillment_run(results_set.euid, fulfillment_run_euid)
    db.commit()
    return _build_result_response(fulfillment_output)


@results_sets_router.get("", response_model=list[ResultsSetResponse])
async def list_results_sets(
    trf_euid: Annotated[str, Query(description="Filter by TRF EUID")],
    include_unpublished: Annotated[
        bool, Query(description="Include unpublished (internal only)")
    ] = False,
    _api_key: str | None = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> list[ResultsSetResponse]:
    tenant_id = _resolve_tenant_for_trf(db, trf_euid)
    svc = ResultsSetService(db, tenant_id)
    results_sets = svc.list_for_trf(trf_euid, include_unpublished=include_unpublished)
    responses: list[ResultsSetResponse] = []
    for rs in results_sets:
        fulfillment_runs = svc.get_fulfillment_runs_for_results_set(rs.euid)
        responses.append(
            _build_results_set_response(
                rs,
                fulfillment_run_count=len(fulfillment_runs),
                trf_euid=_resolve_trf_euid_for_results_set(db, rs.test_euid),
            )
        )
    return responses


@results_sets_router.get("/{results_set_euid}", response_model=ResultsSetResponse)
async def get_results_set(
    results_set_euid: str,
    _api_key: str = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> ResultsSetResponse:
    rs = _get_results_set_any_tenant(db, results_set_euid)
    svc = ResultsSetService(db, rs.tenant_id)
    fulfillment_runs = svc.get_fulfillment_runs_for_results_set(results_set_euid)
    return _build_results_set_response(
        rs,
        fulfillment_run_count=len(fulfillment_runs),
        trf_euid=_resolve_trf_euid_for_results_set(db, rs.test_euid),
    )


@results_sets_router.post("/{results_set_euid}/publish", response_model=ResultsSetResponse)
async def publish_results_set(
    results_set_euid: str,
    request: PublishRequest | None = None,
    _api_key: str = Depends(verify_internal_api_key),
    db: Session = Depends(get_db),
) -> ResultsSetResponse:
    rs = _get_results_set_any_tenant(db, results_set_euid)
    svc = ResultsSetService(db, rs.tenant_id)
    updated = svc.publish(
        results_set_euid, published_by=None, note=request.note if request else None
    )
    fulfillment_runs = svc.get_fulfillment_runs_for_results_set(results_set_euid)
    db.commit()
    return _build_results_set_response(
        updated,
        fulfillment_run_count=len(fulfillment_runs),
        trf_euid=_resolve_trf_euid_for_results_set(db, updated.test_euid),
    )
