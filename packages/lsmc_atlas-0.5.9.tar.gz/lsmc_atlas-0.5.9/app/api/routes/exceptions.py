"""LSMC Hub - Exception API Routes.

Internal API for managing intake exceptions.
"""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user, require_internal
from app.db.engine import get_db
from app.domain.enums import ExceptionStatus, ExceptionType
from app.domain.services.exceptions import ExceptionCreate, ExceptionService, ExceptionUpdate

router = APIRouter(
    prefix="/api/exceptions",
    tags=["exceptions"],
    dependencies=[Depends(require_internal)],
)


# --- Request/Response Schemas ---


class ExceptionCreateRequest(BaseModel):
    """Request to create an exception."""

    exception_type: ExceptionType
    trigger_entity_type: str | None = None
    trigger_entity_id: str | None = None
    scanned_data: dict | None = None
    order_id: str | None = None
    external_object_id: str | None = None
    shipment_id: str | None = None
    note: str | None = None


class ExceptionUpdateRequest(BaseModel):
    """Request to update an exception."""

    status: ExceptionStatus | None = None
    assigned_to: uuid.UUID | None = None
    resolution_notes: str | None = None
    note: str | None = None


class ExceptionAssignRequest(BaseModel):
    """Request to assign an exception."""

    assigned_to: uuid.UUID = Field(..., description="User ID to assign to")


class ExceptionResolveRequest(BaseModel):
    """Request to resolve an exception."""

    resolution_notes: str = Field(..., min_length=1, description="Resolution notes")


class ExceptionResponse(BaseModel):
    """Exception response."""

    id: str
    euid: str | None = None
    exception_number: str
    tenant_id: str
    exception_type: str
    status: str
    trigger_entity_type: str | None
    trigger_entity_id: str | None
    scanned_data: dict | None
    order_id: str | None
    external_object_id: str | None
    shipment_id: str | None
    assigned_to: str | None
    resolution_notes: str | None
    resolved_at: str | None
    resolved_by: str | None
    created_at: str
    revision_no: int


class ExceptionListResponse(BaseModel):
    """List of exceptions."""

    items: list[ExceptionResponse]
    total: int


# --- Helper Functions ---


def _exception_to_response(exception, revision) -> ExceptionResponse:
    """Convert exception + revision to response."""
    return ExceptionResponse(
        id=exception.euid,
        euid=exception.euid,
        exception_number=exception.exception_number,
        tenant_id=str(exception.tenant_id),
        exception_type=revision.exception_type,
        status=revision.status,
        trigger_entity_type=revision.trigger_entity_type,
        trigger_entity_id=str(revision.trigger_entity_id) if revision.trigger_entity_id else None,
        scanned_data=revision.scanned_data,
        order_id=str(revision.order_id) if revision.order_id else None,
        external_object_id=(
            str(revision.external_object_id)
            if getattr(revision, "external_object_id", None)
            else None
        ),
        shipment_id=str(revision.shipment_id) if revision.shipment_id else None,
        assigned_to=str(revision.assigned_to) if revision.assigned_to else None,
        resolution_notes=revision.resolution_notes,
        resolved_at=revision.resolved_at.isoformat() if revision.resolved_at else None,
        resolved_by=str(revision.resolved_by) if revision.resolved_by else None,
        created_at=exception.created_at.isoformat(),
        revision_no=revision.revision_no,
    )


# --- Endpoints ---


@router.get("", response_model=ExceptionListResponse)
async def list_exceptions(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
    status: str | None = Query(None, description="Filter by status"),
    exception_type: str | None = Query(None, description="Filter by exception type"),
) -> ExceptionListResponse:
    """List exceptions for tenant."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)
    exceptions = svc.list_exceptions(
        skip=skip,
        limit=limit,
        status_filter=status,
        exception_type_filter=exception_type,
        cross_tenant=cross_tenant,
    )

    items = [_exception_to_response(e, r) for e, r in exceptions]
    return ExceptionListResponse(items=items, total=len(items))


@router.get("/{exception_id}", response_model=ExceptionResponse)
async def get_exception(
    exception_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ExceptionResponse:
    """Get exception by EUID."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)
    result = svc.get(exception_id, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Exception not found")

    exception, revision = result
    return _exception_to_response(exception, revision)


@router.post("", response_model=ExceptionResponse, status_code=status.HTTP_201_CREATED)
async def create_exception(
    request: ExceptionCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ExceptionResponse:
    """Create a new exception."""
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)
    exception, revision = svc.create(
        ExceptionCreate(
            exception_type=request.exception_type,
            trigger_entity_type=request.trigger_entity_type,
            trigger_entity_id=request.trigger_entity_id,
            scanned_data=request.scanned_data,
            order_id=request.order_id,
            external_object_id=request.external_object_id,
            shipment_id=request.shipment_id,
            note=request.note,
        ),
        created_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )
    return _exception_to_response(exception, revision)


@router.patch("/{exception_id}", response_model=ExceptionResponse)
async def update_exception(
    exception_id: str,
    request: ExceptionUpdateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ExceptionResponse:
    """Update exception (creates new revision)."""
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)

    result = svc.update(
        exception_id,
        ExceptionUpdate(
            status=request.status,
            assigned_to=request.assigned_to,
            resolution_notes=request.resolution_notes,
            note=request.note,
        ),
        updated_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Exception not found")

    exception, revision = result
    return _exception_to_response(exception, revision)


@router.post("/{exception_id}/assign", response_model=ExceptionResponse)
async def assign_exception(
    exception_id: str,
    request: ExceptionAssignRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ExceptionResponse:
    """Assign exception to a user."""
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)

    result = svc.assign(
        exception_id,
        request.assigned_to,
        assigned_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Exception not found")

    exception, revision = result
    return _exception_to_response(exception, revision)


@router.post("/{exception_id}/resolve", response_model=ExceptionResponse)
async def resolve_exception(
    exception_id: str,
    request: ExceptionResolveRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ExceptionResponse:
    """Resolve an exception."""
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)

    result = svc.resolve(
        exception_id,
        request.resolution_notes,
        resolved_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Exception not found")

    exception, revision = result
    return _exception_to_response(exception, revision)


@router.post("/{exception_id}/escalate", response_model=ExceptionResponse)
async def escalate_exception(
    exception_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ExceptionResponse:
    """Escalate an exception."""
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)

    result = svc.escalate(
        exception_id,
        escalated_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Exception not found")

    exception, revision = result
    return _exception_to_response(exception, revision)


@router.post("/{exception_id}/close", response_model=ExceptionResponse)
async def close_exception(
    exception_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ExceptionResponse:
    """Close an exception."""
    svc = ExceptionService(db, current_user.tenant_id, current_user.sub)

    result = svc.close(
        exception_id,
        closed_by=uuid.UUID(current_user.sub) if current_user.sub else None,
    )

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Exception not found")

    exception, revision = result
    return _exception_to_response(exception, revision)
