"""Internal intake APIs for shipment receipt and material outcomes."""

from __future__ import annotations

import logging
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, model_validator
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user, require_internal_api
from app.db.engine import get_db
from app.domain.services.intake import (
    IntakeService,
    MaterialIntakeOutcome,
    MaterialOutcomeRequest,
    ScanResult,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/intake",
    tags=["intake"],
    dependencies=[Depends(require_internal_api)],
)


class ScanRequest(BaseModel):
    barcode: str = Field(..., min_length=1, max_length=200)
    scan_type: str | None = Field(None, pattern="^(TESTKIT|SHIPMENT|BLOOM|AUTO)$")


class ReceiveShipmentRequest(BaseModel):
    shipment_id: str
    received_by: str | None = None
    notes: str | None = None


class MaterialOutcomeRequestBody(BaseModel):
    trf_euid: str
    test_euids: list[str] = Field(min_length=1)
    patient_euid: str
    outcome: Literal["ACCEPTED", "HOLD", "REJECTED"]
    shipment_euid: str | None = None
    testkit_euid: str | None = None
    specimen_template_code: str = "content/specimen/blood-whole/1.0"
    specimen_name: str | None = None
    container_euid: str | None = None
    container_template_code: str | None = None
    properties: dict[str, str | int | float | bool | None] = Field(default_factory=dict)
    starting_queue: Literal["extraction_prod", "extraction_rnd"] | None = None
    queue_metadata: dict[str, str | int | float | bool | None] = Field(default_factory=dict)
    reason: str | None = None

    @model_validator(mode="after")
    def validate_links(self) -> MaterialOutcomeRequestBody:
        if not (self.shipment_euid or "").strip() and not (self.testkit_euid or "").strip():
            raise ValueError("At least one of shipment_euid or testkit_euid is required")
        if self.outcome == "ACCEPTED" and self.starting_queue is None:
            raise ValueError("starting_queue is required when outcome=ACCEPTED")
        return self


class ScanResultResponse(BaseModel):
    found: bool
    entity_type: str | None
    entity_id: str | None
    barcode: str
    details: dict | None


class MaterialOutcomeResponse(BaseModel):
    outcome: str
    accepted: bool
    trf_euid: str
    trf_status: str
    test_euids: list[str]
    fulfillment_item_euids: list[str]
    test_statuses: dict[str, str]
    patient_euid: str
    container_euid: str | None = None
    specimen_euid: str | None = None
    current_queue: str | None = None


@router.post("/scan", response_model=ScanResultResponse)
async def scan_barcode(
    request: ScanRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ScanResultResponse:
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = IntakeService(db, current_user.tenant_id)
    result: ScanResult = svc.scan_barcode(request.barcode, cross_tenant=cross_tenant)
    return ScanResultResponse(
        found=result.found,
        entity_type=result.entity_type,
        entity_id=str(result.entity_id) if result.entity_id else None,
        barcode=request.barcode,
        details=result.entity_details,
    )


@router.post("/outcomes", response_model=MaterialOutcomeResponse, status_code=status.HTTP_200_OK)
async def record_material_outcome(
    request: MaterialOutcomeRequestBody,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> MaterialOutcomeResponse:
    svc = IntakeService(db, current_user.tenant_id)
    try:
        result = svc.record_material_outcome(
            MaterialOutcomeRequest(
                trf_euid=request.trf_euid,
                test_euids=request.test_euids,
                patient_euid=request.patient_euid,
                outcome=MaterialIntakeOutcome(request.outcome),
                shipment_euid=request.shipment_euid,
                testkit_euid=request.testkit_euid,
                specimen_template_code=request.specimen_template_code,
                specimen_name=request.specimen_name,
                container_euid=request.container_euid,
                container_template_code=request.container_template_code,
                properties=request.properties,
                starting_queue=request.starting_queue,
                queue_metadata=request.queue_metadata,
                reason=request.reason,
                idempotency_key=(
                    f"atlas-intake:{request.trf_euid}:{request.outcome}:"
                    f"{','.join(request.test_euids)}"
                ),
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return MaterialOutcomeResponse(
        outcome=result.outcome,
        accepted=result.accepted,
        trf_euid=result.trf_euid,
        trf_status=result.trf_status,
        test_euids=result.test_euids,
        fulfillment_item_euids=result.fulfillment_item_euids,
        test_statuses=result.test_statuses,
        patient_euid=result.patient_euid,
        container_euid=result.container_euid,
        specimen_euid=result.specimen_euid,
        current_queue=result.current_queue,
    )


@router.post("/receive-shipment")
async def receive_shipment(
    request: ReceiveShipmentRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> dict:
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = IntakeService(db, current_user.tenant_id)
    shipment = svc.receive_shipment(
        request.shipment_id,
        created_by=current_user.sub_uuid,
        cross_tenant=cross_tenant,
    )
    if not shipment:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shipment not found")
    return {"status": "received", "shipment_id": str(request.shipment_id)}


@router.post("/shipments/{shipment_number}/receive")
async def receive_shipment_by_number(
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> dict:
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService, TestKitService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    shipment_svc = ShipmentService(db, current_user.tenant_id)
    shipment_result = shipment_svc.get_by_shipment_number(
        shipment_number, cross_tenant=cross_tenant
    )
    if not shipment_result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shipment {shipment_number} not found",
        )

    shipment, _ = shipment_result
    svc = IntakeService(db, current_user.tenant_id)
    result = svc.receive_shipment(
        shipment.euid,
        created_by=current_user.sub_uuid,
        cross_tenant=cross_tenant,
    )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Failed to receive shipment",
        )

    contents = shipment_svc.get_contents(shipment.euid)
    testkit_svc = TestKitService(db, current_user.tenant_id)
    testkits_received = 0
    for item in contents:
        if item["type"] != "TestKit":
            continue
        tk_result = testkit_svc.mark_received(
            item["id"],
            reason="Shipment received",
            updated_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )
        if tk_result:
            testkits_received += 1

    db.commit()
    return {
        "status": "received",
        "shipment_number": shipment_number,
        "shipment_id": getattr(shipment, "euid", None),
        "testkits_received": testkits_received,
        "materials_received": 0,
    }
