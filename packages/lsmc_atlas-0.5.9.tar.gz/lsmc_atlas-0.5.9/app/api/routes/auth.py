"""LSMC Atlas - Authentication Routes.

Routes:
- GET /auth/login - Redirect to Cognito hosted UI
- GET /auth/callback - Handle Cognito OAuth callback
- GET /auth/google/login - Redirect to Google OAuth
- GET /auth/google/callback - Handle Google OAuth callback
- POST /auth/logout - Clear session and redirect to Cognito logout
- GET /auth/me - Get current user info
"""

import logging
import secrets
import uuid
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.cognito import (
    CognitoAuthError,
    CognitoUserInfo,
    build_google_login_url,
    build_login_url,
    build_logout_url,
    exchange_code_for_tokens,
    exchange_google_code,
    get_google_userinfo,
    get_user_info_from_tokens,
)
from app.auth.dependencies import CurrentUser, get_current_user
from app.auth.rate_limiting import rate_limit_dependency
from app.auth.session import get_server_instance_id
from app.db.engine import get_db
from app.domain.services.orgs import OrganizationCreate, OrganizationService
from app.domain.services.users import UserCreate, UserService
from app.settings import settings
from app.web.templates import templates

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])

# Error reason messages for the /auth/error page
_ERROR_REASONS: dict[str, str] = {
    "blocked_domain": "Your email domain is not allowed to access this application.",
    "not_provisioned": "Your account has not been provisioned in LSMC Atlas. Please contact your administrator.",
    "account_disabled": "Your user account has been disabled. Please contact your administrator.",
}


def _build_error_redirect_uri(reason: str) -> str:
    """Build a full URL for /auth/error from the configured redirect URI.

    Derives the base URL from ``settings.cognito_redirect_uri``
    (e.g. ``https://localhost:8443/auth/callback`` → ``https://localhost:8443/auth/error``).
    """
    from urllib.parse import urlencode

    base = settings.cognito_redirect_uri.replace("/auth/callback", "")
    return f"{base}/auth/error?{urlencode({'reason': reason})}"


def _public_auth_template_context(request: Request) -> dict[str, object]:
    """Build a minimal standalone-page context for public auth views."""
    from app.persistence.tapdb.themes import DEFAULT_FONT_CHOICE, resolve_font_choice

    default_font_config = resolve_font_choice(DEFAULT_FONT_CHOICE)
    return {
        "request": request,
        "current_year": datetime.now(UTC).year,
        "deployment": settings.deployment,
        "user_theme": "default",
        "user_font": default_font_config["code"],
        "user_font_config": default_font_config,
    }


class UserInfo(BaseModel):
    """Current user information response."""

    sub: str
    email: str
    name: str | None
    tenant_id: str
    roles: list[str]
    is_internal: bool
    is_admin: bool


@router.get("/login", dependencies=[Depends(rate_limit_dependency("auth"))])
async def login(request: Request) -> RedirectResponse:
    """Initiate login flow.

    Redirects to Cognito hosted UI for authentication.
    """
    # Ensure the browser is on the same host as the configured callback URI.
    # If the user accessed via 127.0.0.1 or 0.0.0.0 but the callback goes to
    # "localhost", the session cookie would be set for the wrong domain and
    # will not be sent on the Cognito callback redirect, causing login failure.
    from urllib.parse import parse_qs, urlparse

    redirect_uri = (settings.cognito_redirect_uri or "").strip()
    cognito_domain = (settings.cognito_domain or "").strip()
    cognito_client_id = (settings.cognito_app_client_id or "").strip()

    missing_fields: list[str] = []
    if not redirect_uri:
        missing_fields.append("cognito_redirect_uri")
    if not cognito_domain:
        missing_fields.append("cognito_domain")
    if not cognito_client_id:
        missing_fields.append("cognito_app_client_id")
    if missing_fields:
        logger.error("Cognito login config incomplete: missing %s", ", ".join(missing_fields))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=(
                "Cognito login config is incomplete. Missing: "
                + ", ".join(missing_fields)
                + ". Run `atlas cognito status --port 8915`."
            ),
        )

    callback_parsed = urlparse(redirect_uri)
    if not callback_parsed.scheme or not callback_parsed.hostname:
        logger.error("Invalid COGNITO_REDIRECT_URI: %s", redirect_uri)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=(
                "Cognito redirect URI is invalid. "
                f"Expected absolute URL, got: {redirect_uri!r}. "
                "Run `atlas cognito status --port 8915`."
            ),
        )

    expected_host = callback_parsed.hostname or "localhost"
    expected_port = callback_parsed.port
    request_host = request.headers.get("host", "")

    # Normalise: strip port from request host for comparison
    req_hostname = request_host.split(":")[0]
    if req_hostname != expected_host:
        # Redirect the browser to the correct host so the cookie domain matches
        correct_url = f"{callback_parsed.scheme}://{expected_host}"
        if expected_port:
            correct_url += f":{expected_port}"
        correct_url += "/auth/login"
        logger.warning(
            "Host mismatch: browser on '%s', callback expects '%s'. Redirecting to %s",
            request_host,
            expected_host,
            correct_url,
        )
        return RedirectResponse(url=correct_url, status_code=status.HTTP_302_FOUND)

    req_port = request.url.port or (443 if request.url.scheme == "https" else 80)
    if (
        expected_host in {"localhost", "127.0.0.1", "0.0.0.0"}
        and expected_port is not None
        and req_port != expected_port
    ):
        logger.error(
            "Cognito callback port mismatch: request on port %s but configured redirect URI port is %s "
            "(redirect URI: %s)",
            req_port,
            expected_port,
            redirect_uri,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=(
                "Cognito redirect URI port mismatch. "
                f"Atlas is running on port {req_port} but COGNITO_REDIRECT_URI uses port {expected_port}. "
                f"Run `atlas cognito status --port {req_port}` and update callback/logout URLs."
            ),
        )

    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)
    request.session["oauth_state"] = state
    logger.info("OAuth login - generated state")

    login_url = build_login_url(state=state)
    login_query = parse_qs(urlparse(login_url).query)
    resolved_redirect_uri = login_query.get("redirect_uri", [""])[0]
    if not resolved_redirect_uri:
        logger.error("Generated Cognito authorize URL missing redirect_uri: %s", login_url)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=(
                "Generated Cognito authorize URL is missing redirect_uri. "
                "Run `atlas cognito status --port 8915` and verify app callback settings."
            ),
        )
    return RedirectResponse(url=login_url, status_code=status.HTTP_302_FOUND)


@router.get("/error", response_class=HTMLResponse)
async def auth_error(request: Request, reason: str = "unknown") -> HTMLResponse:
    """Render an error page when authentication is denied.

    The user lands here after the Cognito SSO session has been cleared,
    so refreshing the page will NOT start a new login loop.
    """
    message = _ERROR_REASONS.get(reason, "An authentication error occurred.")
    ctx = _public_auth_template_context(request)
    ctx.update(
        {
            "auth_badge": "Access Review",
            "auth_eyebrow": "LSMC Atlas",
            "auth_title": "This account could not complete sign-in.",
            "auth_description": (
                "Atlas access is provisioned per organization and user role. "
                "If you believe this is incorrect, contact the LSMC team."
            ),
            "auth_card_state": "error",
            "auth_card_kicker": "Access Denied",
            "auth_card_title": "Sign-in was blocked",
            "auth_card_copy": message,
            "auth_primary_href": "/login",
            "auth_primary_label": "Return to Sign In",
            "auth_secondary_prefix": "Still need help?",
            "auth_secondary_label": "support@lsmc.bio",
            "auth_secondary_href": "mailto:support@lsmc.bio",
            "auth_footer_note": "Customer portal for clinical sequencing operations.",
        }
    )
    return templates.TemplateResponse(
        request,
        "login.html",
        context=ctx,
        status_code=status.HTTP_403_FORBIDDEN,
    )


def _auto_provision_user(
    db: Session,
    cognito_user: CognitoUserInfo,
) -> object | None:
    """Auto-provision a new user from Cognito data.

    Args:
        db: Database session
        cognito_user: User info extracted from Cognito tokens

    Returns:
        New UserProfile or None if provisioning failed
    """
    org_svc = OrganizationService(db)
    tenant_id: uuid.UUID | None = None

    # Prefer explicit tenant from Cognito custom attribute.
    candidate_tenant = (cognito_user.tenant_id_from_attribute or "").strip()
    if candidate_tenant:
        try:
            candidate_uuid = uuid.UUID(candidate_tenant)
            try:
                if org_svc.get_by_uid(candidate_uuid):
                    tenant_id = candidate_uuid
                else:
                    logger.warning(
                        "Cognito tenant_id %s not found; continuing with fallback.", candidate_uuid
                    )
            except Exception:
                logger.warning(
                    "Unable to verify Cognito tenant_id %s", candidate_uuid, exc_info=True
                )
        except ValueError:
            logger.warning("Invalid Cognito tenant_id attribute format: %s", candidate_tenant)

    # Fall back to configured default tenant.
    if tenant_id is None:
        configured_tenant = (settings.cognito_default_tenant_id or "").strip()
        if configured_tenant:
            try:
                configured_uuid = uuid.UUID(configured_tenant)
                try:
                    if org_svc.get_by_uid(configured_uuid):
                        tenant_id = configured_uuid
                    else:
                        logger.warning(
                            "Configured default tenant %s not found; continuing with fallback.",
                            configured_uuid,
                        )
                except Exception:
                    logger.warning(
                        "Unable to verify configured default tenant %s",
                        configured_uuid,
                        exc_info=True,
                    )
            except ValueError:
                logger.warning("Invalid configured default tenant_id: %s", configured_tenant)

    # Fall back to first active organization in Atlas.
    if tenant_id is None:
        try:
            active_orgs = org_svc.list_all(active_only=True)
        except Exception:
            active_orgs = []
            logger.warning("Unable to list organizations for tenant fallback", exc_info=True)
        if active_orgs:
            tenant_id = active_orgs[0].uid
            logger.warning(
                "Using fallback tenant %s for auto-provisioned user %s",
                tenant_id,
                cognito_user.email,
            )

    # Last resort: bootstrap a tenant so authenticated users are not blocked.
    if tenant_id is None:
        try:
            bootstrap = org_svc.create(
                OrganizationCreate(
                    name=f"atlas-auto-provision-{datetime.now(UTC).strftime('%Y%m%d')}",
                    display_name="Atlas Auto Provisioned Tenant",
                    org_type="clinic",
                ),
                created_by=None,
            )
            tenant_id = bootstrap.uid
            logger.warning(
                "Created fallback tenant %s for user auto-provisioning",
                tenant_id,
            )
        except Exception:
            logger.error(
                "Cannot auto-provision user %s (%s): unable to resolve or create a tenant",
                cognito_user.email,
                cognito_user.sub,
                exc_info=True,
            )
            return None

    # Use roles from Cognito groups, or default to EXTERNAL_USER
    roles = cognito_user.roles if cognito_user.roles else ["EXTERNAL_USER"]

    user_svc = UserService(db)
    try:
        user_profile = user_svc.create(
            UserCreate(
                cognito_sub=cognito_user.sub,
                email=cognito_user.email,
                name=cognito_user.name,
                tenant_id=tenant_id,
                roles=roles,
            )
        )
    except ValueError as exc:
        logger.warning(
            "Cannot auto-provision user %s (%s): %s",
            cognito_user.email,
            cognito_user.sub,
            exc,
        )
        return None

    logger.info(
        "Auto-provisioned user %s (%s) with roles %s in tenant %s",
        cognito_user.email,
        cognito_user.sub,
        roles,
        tenant_id,
    )
    return user_profile


@router.get("/callback", dependencies=[Depends(rate_limit_dependency("auth_callback"))])
async def callback(
    request: Request,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
    db: Session = Depends(get_db),
) -> RedirectResponse:
    """Handle OAuth callback from Cognito.

    Exchanges authorization code for tokens, validates ID token,
    extracts Cognito groups, maps to roles, and creates session.
    Auto-provisions authenticated users that are missing Atlas profiles.
    """
    # Check for OAuth errors
    if error:
        safe_error = error.replace("\n", " ").replace("\r", " ")
        if error_description:
            safe_desc = error_description.replace("\n", " ").replace("\r", " ")
            logger.warning("OAuth error: %s - %s", safe_error, safe_desc)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"OAuth error: {safe_error} - {safe_desc}",
            )
        else:
            logger.warning("OAuth error: %s", safe_error)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"OAuth error: {safe_error}",
            )

    if not code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing authorization code",
        )

    # Verify state
    expected_state = request.session.get("oauth_state")
    logger.info("OAuth callback - session keys: %s", list(request.session.keys()))

    if not expected_state or state != expected_state:
        logger.warning(
            "Invalid OAuth state parameter. Session empty: %s",
            len(request.session) == 0,
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid state parameter",
        )

    # Clear state from session
    request.session.pop("oauth_state", None)

    try:
        user_svc = UserService(db)
        # Exchange code for tokens
        tokens = await exchange_code_for_tokens(code)
        id_token = tokens.get("id_token")
        access_token = tokens.get("access_token")

        if not id_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No ID token in response",
            )

        # Extract complete user info from tokens (includes group-to-role mapping)
        cognito_user = await get_user_info_from_tokens(id_token, access_token)

        # Validate email domain against allowed domains
        domain_valid, domain_error = settings.validate_email_domain(cognito_user.email)
        if not domain_valid:
            logger.warning("Authentication blocked for %s: %s", cognito_user.email, domain_error)
            return RedirectResponse(
                url=_build_error_redirect_uri("blocked_domain"),
                status_code=status.HTTP_302_FOUND,
            )

        logger.info(
            "Cognito login for %s (%s), groups=%s, mapped_roles=%s",
            cognito_user.email,
            cognito_user.sub,
            cognito_user.cognito_groups,
            cognito_user.roles,
        )

        # Look up user profile in database
        user_profile = user_svc.get_by_cognito_sub(cognito_user.sub)

        if not user_profile:
            # User authenticated in Cognito but missing from Atlas: auto-provision.
            user_profile = _auto_provision_user(db, cognito_user)

            if not user_profile:
                logger.warning("User %s (%s) not provisioned", cognito_user.email, cognito_user.sub)
                return RedirectResponse(
                    url=_build_error_redirect_uri("not_provisioned"),
                    status_code=status.HTTP_302_FOUND,
                )

        if not user_profile.is_active:
            logger.warning("Disabled user attempted login: %s", cognito_user.sub)
            return RedirectResponse(
                url=_build_error_redirect_uri("account_disabled"),
                status_code=status.HTTP_302_FOUND,
            )

        # Determine final roles:
        # - If user has roles stored in UserProfile, use those (admin-managed)
        # - Otherwise, fall back to Cognito group-mapped roles
        final_roles = user_profile.roles if user_profile.roles else cognito_user.roles
        if not final_roles:
            final_roles = ["EXTERNAL_USER"]  # Fallback default

        # Update last login timestamp
        user_svc.update_last_login(user_profile.euid)

        # Create session with server instance ID (for invalidation on restart)
        request.session.update(
            {
                "user_sub": cognito_user.sub,
                "email": cognito_user.email,
                "name": cognito_user.name,
                "tenant_id": str(user_profile.tenant_id),
                "roles": final_roles,
                "cognito_groups": cognito_user.cognito_groups,  # Store for debugging
                "auth_mode": "cognito",
                "authenticated_at": datetime.now(UTC).isoformat(),
                "server_instance_id": get_server_instance_id(),  # Track server instance
            }
        )

        logger.info("User %s logged in with roles %s", cognito_user.email, final_roles)
        return RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)

    except CognitoAuthError as e:
        logger.error("Cognito auth error: %s", e)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed. Please try again.",
        )


# ---------------------------------------------------------------------------
# Google OAuth routes
# ---------------------------------------------------------------------------


@router.get("/google/login", dependencies=[Depends(rate_limit_dependency("auth"))])
async def google_login(request: Request) -> RedirectResponse:
    """Initiate Google OAuth login flow.

    Redirects to Google's authorization page. Requires google_oauth_enabled=True
    and valid google_client_id / google_client_secret in settings.
    """
    if not settings.google_oauth_enabled:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Google OAuth is not enabled",
        )

    state = secrets.token_urlsafe(32)
    request.session["google_oauth_state"] = state

    google_url = build_google_login_url(state=state)
    return RedirectResponse(url=google_url, status_code=status.HTTP_302_FOUND)


@router.get("/google/callback", dependencies=[Depends(rate_limit_dependency("auth_callback"))])
async def google_callback(
    request: Request,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    db: Session = Depends(get_db),
) -> RedirectResponse:
    """Handle Google OAuth callback.

    Exchanges Google authorization code for tokens, fetches userinfo,
    validates email domain, looks up or auto-provisions user, creates session.
    """
    if not settings.google_oauth_enabled:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Google OAuth is not enabled",
        )

    if error:
        safe_error = error.replace("\n", " ").replace("\r", " ")
        logger.warning("Google OAuth error: %s", safe_error)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Google OAuth error: {safe_error}",
        )

    if not code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing authorization code",
        )

    # Verify CSRF state
    expected_state = request.session.get("google_oauth_state")
    if not expected_state or state != expected_state:
        logger.warning("Invalid Google OAuth state parameter")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid state parameter",
        )
    request.session.pop("google_oauth_state", None)

    try:
        user_svc = UserService(db)
        # Exchange code for Google tokens
        google_tokens = exchange_google_code(code)
        access_token = google_tokens.get("access_token")
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No access token in Google response",
            )

        # Fetch user profile from Google
        userinfo = get_google_userinfo(access_token)
        email = userinfo.get("email", "")
        name = userinfo.get("name") or userinfo.get("given_name", "")
        google_sub = userinfo.get("sub", "")

        if not email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Google account has no email",
            )

        # Validate email domain
        domain_valid, domain_error = settings.validate_email_domain(email)
        if not domain_valid:
            logger.warning("Google auth blocked for %s: %s", email, domain_error)
            error_uri = _build_error_redirect_uri("blocked_domain")
            return RedirectResponse(url=error_uri, status_code=status.HTTP_302_FOUND)

        logger.info("Google login for %s (sub=%s)", email, google_sub)

        # Look up user by email (Google users may not have a cognito_sub yet)
        user_profile = user_svc.get_by_email(email)

        if not user_profile:
            # Try auto-provisioning
            if settings.cognito_auto_provision_users:
                tenant_id_str = settings.cognito_default_tenant_id
                if tenant_id_str:
                    try:
                        tenant_id = uuid.UUID(tenant_id_str)
                    except ValueError:
                        logger.error("Invalid tenant_id format: %s", tenant_id_str)
                        raise HTTPException(
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail="Server configuration error",
                        )

                    try:
                        user_profile = user_svc.create(
                            UserCreate(
                                cognito_sub=f"google_{google_sub}",
                                email=email,
                                name=name,
                                tenant_id=tenant_id,
                                roles=["EXTERNAL_USER"],
                            )
                        )
                        logger.info(
                            "Auto-provisioned Google user %s in tenant %s", email, tenant_id
                        )
                    except ValueError as exc:
                        logger.warning("Cannot auto-provision Google user %s: %s", email, exc)

            if not user_profile:
                logger.warning("Google user %s not provisioned", email)
                error_uri = _build_error_redirect_uri("not_provisioned")
                return RedirectResponse(url=error_uri, status_code=status.HTTP_302_FOUND)

        if not user_profile.is_active:
            error_uri = _build_error_redirect_uri("account_disabled")
            return RedirectResponse(url=error_uri, status_code=status.HTTP_302_FOUND)

        # Update last login
        user_svc.update_last_login(user_profile.euid)

        final_roles = user_profile.roles if user_profile.roles else ["EXTERNAL_USER"]

        # Create session
        request.session.update(
            {
                "user_sub": user_profile.cognito_sub or f"google_{google_sub}",
                "email": email,
                "name": name,
                "tenant_id": str(user_profile.tenant_id),
                "roles": final_roles,
                "cognito_groups": [],
                "auth_mode": "google",
                "authenticated_at": datetime.now(UTC).isoformat(),
                "server_instance_id": get_server_instance_id(),
            }
        )

        logger.info("Google user %s logged in with roles %s", email, final_roles)
        return RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)

    except CognitoAuthError as e:
        logger.error("Google auth error: %s", e)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed. Please try again.",
        )


@router.post("/logout")
async def logout(request: Request) -> RedirectResponse:
    """Log out the current user.

    Clears local session and redirects to Cognito logout URL to clear SSO session.
    """
    # Prevent redirect loop if the user is already logged out locally.
    # This happens when Cognito redirects back to /auth/logout after clearing its session.
    if "user_sub" not in request.session:
        return RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)

    request.session.clear()

    # Generate a fresh OAuth state so the callback can validate CSRF
    # after the user re-authenticates through Cognito managed login.
    state = secrets.token_urlsafe(32)
    request.session["oauth_state"] = state

    logout_url = build_logout_url(state=state)
    logger.info("Logging out user, redirecting to Cognito: %s", logout_url)
    return RedirectResponse(url=logout_url, status_code=status.HTTP_302_FOUND)


@router.get("/logout")
async def logout_get(request: Request) -> RedirectResponse:
    """GET version of logout for browser link support."""
    return await logout(request)


@router.get("/me", response_model=UserInfo)
async def get_me(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> UserInfo:
    """Get current authenticated user information."""
    return UserInfo(
        sub=current_user.sub,
        email=current_user.email,
        name=current_user.name,
        tenant_id=str(current_user.tenant_id),
        roles=current_user.roles,
        is_internal=current_user.is_internal,
        is_admin=current_user.is_admin,
    )
