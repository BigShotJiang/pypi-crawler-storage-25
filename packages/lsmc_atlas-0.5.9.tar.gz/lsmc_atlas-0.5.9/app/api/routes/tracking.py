"""LSMC Hub - FedEx Tracking API Routes."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user, require_internal_api
from app.auth.rbac import Permission, has_permission
from app.db.engine import get_db
from app.domain.services.fedex_tracking import FedExTrackingService
from app.domain.services.shipments import ShipmentService

router = APIRouter(prefix="/api/tracking", tags=["tracking"])


# =============================================================================
# Request/Response Models
# =============================================================================


class TrackingEventResponse(BaseModel):
    """A single tracking event."""

    timestamp: str | None = None
    event_type: str
    event_description: str
    city: str | None = None
    state: str | None = None
    country_code: str | None = None
    exception_code: str | None = None
    exception_description: str | None = None


class TrackingSummaryResponse(BaseModel):
    """Tracking summary response."""

    tracking_number: str
    delivery_status: str
    origin_city: str | None = None
    origin_state: str | None = None
    origin_country: str | None = None
    destination_city: str | None = None
    destination_state: str | None = None
    destination_country: str | None = None
    ship_date: str | None = None
    pickup_date: str | None = None
    delivery_date: str | None = None
    transit_time_seconds: int | None = None
    transit_time_hours: float | None = None
    service_type: str | None = None
    service_description: str | None = None
    events: list[TrackingEventResponse] | None = None
    error: str | None = None


class ServiceStatusResponse(BaseModel):
    """Status of the tracking service."""

    available: bool


class TrackShipmentRequest(BaseModel):
    """Request to track a shipment."""

    shipment_id: str
    tracking_number: str


def _get_accessible_shipment(
    db: Session,
    current_user: CurrentUser,
    shipment_id: str,
):
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    shipment = ShipmentService(db, current_user.tenant_id).get_by_id(
        shipment_id,
        cross_tenant=cross_tenant,
    )
    if shipment is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shipment {shipment_id} not found",
        )
    return shipment


# =============================================================================
# Endpoints
# =============================================================================


@router.get("/status", response_model=ServiceStatusResponse)
def get_tracking_service_status(
    current_user: Annotated[CurrentUser, Depends(require_internal_api)],
    db: Session = Depends(get_db),
) -> ServiceStatusResponse:
    """Get the status of the FedEx tracking service."""
    svc = FedExTrackingService(db, current_user.tenant_id, current_user.sub)
    return ServiceStatusResponse(available=svc.is_available())


@router.get("/track/{tracking_number}", response_model=TrackingSummaryResponse)
def track_number(
    tracking_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> TrackingSummaryResponse:
    """Track a FedEx tracking number (does not store results)."""
    svc = FedExTrackingService(db, current_user.tenant_id, current_user.sub)

    if not svc.is_available():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="FedEx tracking service is not available",
        )

    summary = svc.track(tracking_number)

    return _summary_to_response(summary)


@router.post("/shipment/update", response_model=TrackingSummaryResponse)
def update_shipment_tracking(
    request: TrackShipmentRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> TrackingSummaryResponse:
    """Update tracking data for a shipment (stores results in database)."""
    shipment = _get_accessible_shipment(db, current_user, request.shipment_id)
    svc = FedExTrackingService(db, current_user.tenant_id, current_user.sub)

    if not svc.is_available():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="FedEx tracking service is not available",
        )

    summary = svc.update_shipment_tracking(
        shipment_id=shipment.euid,
        tracking_number=request.tracking_number,
    )

    return _summary_to_response(summary)


@router.get("/shipment/{shipment_id}", response_model=TrackingSummaryResponse | None)
def get_shipment_tracking(
    shipment_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> TrackingSummaryResponse | None:
    """Get stored tracking data for a shipment."""
    shipment = _get_accessible_shipment(db, current_user, shipment_id)
    svc = FedExTrackingService(db, current_user.tenant_id, current_user.sub)

    summary = svc.get_latest_tracking(shipment.euid)
    if not summary:
        return None

    return _summary_to_response(summary)


def _summary_to_response(summary) -> TrackingSummaryResponse:
    """Convert a TrackingSummary to API response."""
    transit_hours = None
    if summary.transit_time_seconds:
        transit_hours = round(summary.transit_time_seconds / 3600, 2)

    return TrackingSummaryResponse(
        tracking_number=summary.tracking_number,
        delivery_status=summary.delivery_status,
        origin_city=summary.origin_city,
        origin_state=summary.origin_state,
        origin_country=summary.origin_country,
        destination_city=summary.destination_city,
        destination_state=summary.destination_state,
        destination_country=summary.destination_country,
        ship_date=summary.ship_date.isoformat() if summary.ship_date else None,
        pickup_date=summary.pickup_date.isoformat() if summary.pickup_date else None,
        delivery_date=summary.delivery_date.isoformat() if summary.delivery_date else None,
        transit_time_seconds=summary.transit_time_seconds,
        transit_time_hours=transit_hours,
        service_type=summary.service_type,
        service_description=summary.service_description,
        events=[
            TrackingEventResponse(
                timestamp=e.timestamp.isoformat() if e.timestamp else None,
                event_type=e.event_type,
                event_description=e.event_description,
                city=e.city,
                state=e.state,
                country_code=e.country_code,
                exception_code=e.exception_code,
                exception_description=e.exception_description,
            )
            for e in (summary.events or [])
        ],
        error=summary.error,
    )
