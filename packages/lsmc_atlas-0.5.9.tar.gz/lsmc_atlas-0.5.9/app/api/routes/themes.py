"""LSMC Hub - Theme Management API Routes.

Provides endpoints for theme selection and configuration.
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

try:
    from daylily_tapdb.timezone_utils import normalize_display_timezone
except Exception:
    from zoneinfo import ZoneInfo

    def normalize_display_timezone(value: str | None, default: str = "UTC") -> str:
        candidate = str(value or "").strip()
        if not candidate:
            return default
        if candidate.upper() in {"UTC", "GMT", "GMT+00:00", "Z"}:
            return "UTC"
        try:
            return ZoneInfo(candidate).key
        except Exception:
            return default


try:
    from daylily_tapdb.user_store import set_display_timezone_by_login_or_email
except Exception:

    def set_display_timezone_by_login_or_email(*_args, **_kwargs) -> bool:
        return False


from app.auth.dependencies import get_current_user
from app.db.engine import get_db
from app.domain.services.users import UserService
from app.persistence.tapdb.themes import DEFAULT_FONT_CHOICE, FONT_CHOICES, TapdbThemeRepository

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/themes", tags=["themes"])


class ThemeInfo(BaseModel):
    """Theme information."""

    code: str
    name: str
    description: str


class ThemeSelectRequest(BaseModel):
    """Request to select a theme."""

    theme: str | None = None
    font: str | None = None


class ThemeCSSOverrides(BaseModel):
    """Custom CSS overrides."""

    custom_css: str | None = None


class FontInfo(BaseModel):
    """Font pairing information."""

    code: str
    name: str
    description: str
    body_family: str
    heading_family: str
    body_preview: str
    heading_preview: str


AVAILABLE_THEMES = [
    ThemeInfo(
        code="default",
        name="LSMC Default",
        description="Monochrome industrial design - the default LSMC experience",
    ),
    ThemeInfo(
        code="lsmc",
        name="LSMC Brand",
        description="Graphite brand palette with warm signal accents",
    ),
    ThemeInfo(
        code="bold", name="Bold", description="Striking minimal dark theme with neon signal accents"
    ),
    ThemeInfo(
        code="professional",
        name="Light",
        description="Lighter UI with CVD-friendly accent colors",
    ),
    ThemeInfo(code="minimal", name="Minimal", description="Solarized (dark) palette"),
]

AVAILABLE_FONT_CHOICES = [FontInfo(**item) for item in FONT_CHOICES]


@router.get("/", response_model=list[ThemeInfo])
async def list_themes() -> list[ThemeInfo]:
    """List all available themes."""
    return AVAILABLE_THEMES


@router.get("/current")
async def get_current_theme(
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    """Get the current user's theme preference (stored per tenant)."""
    if not current_user or not current_user.tenant_id:
        return {"theme": "default", "custom_css": None, "font": DEFAULT_FONT_CHOICE}

    state = TapdbThemeRepository(db).get_current_theme(current_user.tenant_id)
    return {"theme": state.theme, "custom_css": state.custom_css, "font": state.font_choice}


@router.post("/select")
async def select_theme(
    request: Request,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    """Set the current user's theme preference.

    Accepts both form data and JSON body for HTMX/JS compatibility.
    """
    import json
    from urllib.parse import parse_qs

    if not current_user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    # Read request body
    body_bytes = await request.body()
    theme = None
    font = None

    # Try form data first (most common from browser)
    if body_bytes:
        try:
            parsed = parse_qs(body_bytes.decode("utf-8"))
            theme = parsed.get("theme", [None])[0]
            font = parsed.get("font", [None])[0]
        except Exception:
            pass

    # Try JSON if form parsing didn't work
    if body_bytes and (not theme or not font):
        try:
            body = json.loads(body_bytes.decode("utf-8"))
            theme = theme or body.get("theme") or body.get("theme_id")
            font = font or body.get("font")
        except Exception:
            pass

    if not theme and not font:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing required field: theme or font",
        )

    # Validate theme
    valid_themes = [t.code for t in AVAILABLE_THEMES]
    if theme and theme not in valid_themes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid theme. Choose from: {', '.join(valid_themes)}",
        )

    valid_fonts = [f.code for f in AVAILABLE_FONT_CHOICES]
    if font and font not in valid_fonts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid font. Choose from: {', '.join(valid_fonts)}",
        )

    state = TapdbThemeRepository(db).select_theme(
        tenant_id=current_user.tenant_id,
        theme=theme,
        created_by=current_user.sub_uuid,
        font_choice=font,
    )

    return {"status": "success", "theme": state.theme, "font": state.font_choice}


# User Preferences Router
user_router = APIRouter(prefix="/api/user", tags=["user"])


class UserPreferencesUpdate(BaseModel):
    """Request to update user preferences."""

    datetime_format: str | None = None
    display_timezone: str | None = None


@user_router.post("/preferences")
async def update_user_preferences(
    request: Request,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    """Update user preferences (datetime format, etc.).

    Accepts JSON body:
    {
        "datetime_format": "standard" | "precise"
    }
    """
    import json

    if not current_user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)

    # Parse JSON body
    body_bytes = await request.body()
    if not body_bytes:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Request body required")

    try:
        data = json.loads(body_bytes.decode("utf-8"))
    except json.JSONDecodeError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid JSON body")

    # Validate datetime_format if provided
    datetime_format = data.get("datetime_format")
    if datetime_format and datetime_format not in ("standard", "precise"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid datetime_format. Choose 'standard' or 'precise'",
        )
    display_timezone_raw = data.get("display_timezone")
    display_timezone = None
    if display_timezone_raw is not None:
        display_timezone = normalize_display_timezone(display_timezone_raw)

    user_svc = UserService(db)
    user_profile = user_svc.get_by_cognito_sub(current_user.sub)

    if not user_profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User profile not found")

    # Update preferences (merge with existing)
    current_prefs = user_profile.preferences or {}

    if datetime_format:
        current_prefs["datetime_format"] = datetime_format
    if display_timezone is not None:
        current_prefs["display_timezone"] = display_timezone

    user_svc.update_preferences(user_profile.euid, current_prefs)

    # Shared cross-app preference persistence (TapDB system_user projection).
    if display_timezone is not None:
        lookup_email = (
            str(getattr(current_user, "email", "") or "").strip()
            or str(user_profile.email or "").strip()
        )
        if lookup_email:
            try:
                set_display_timezone_by_login_or_email(db, lookup_email, display_timezone)
            except Exception as exc:
                logger.warning(
                    "Failed to persist shared display timezone for %s: %s",
                    lookup_email,
                    exc,
                )

    return {"status": "success", "preferences": current_prefs}
