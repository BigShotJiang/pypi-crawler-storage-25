"""Read-only anomaly routes for Atlas operators."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_observability_user
from app.db.engine import get_db
from app.observability.anomalies import TapdbAnomalyRepository

router = APIRouter(prefix="/api/anomalies", tags=["anomalies"])


@router.get("")
def list_anomalies(
    db: Session = Depends(get_db),
    _user: Annotated[CurrentUser, Depends(get_observability_user)] = None,
) -> dict[str, object]:
    repository = TapdbAnomalyRepository(db)
    items = [record.__dict__ for record in repository.list()]
    return {
        "service": "atlas",
        "items": items,
        "count": len(items),
    }


@router.get("/{anomaly_id}")
def get_anomaly(
    anomaly_id: str,
    db: Session = Depends(get_db),
    _user: Annotated[CurrentUser, Depends(get_observability_user)] = None,
) -> dict[str, object]:
    repository = TapdbAnomalyRepository(db)
    record = repository.get(anomaly_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Anomaly not found")
    return {"service": "atlas", "item": record.__dict__}
