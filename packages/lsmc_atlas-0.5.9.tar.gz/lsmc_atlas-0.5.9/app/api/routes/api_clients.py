"""LSMC Hub - API Client Management API Routes.

Internal API for managing API clients and keys.
"""

from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import require_internal
from app.db.engine import get_db
from app.domain.services.api_clients import (
    APIClientCreate,
    APIClientService,
    APIClientUpdate,
)

router = APIRouter(prefix="/api-clients", tags=["api-clients"])


# --- Request/Response Models ---


class APIClientCreateRequest(BaseModel):
    """Request to create an API client."""

    client_name: str = Field(..., max_length=100)
    permissions: list[str] = Field(..., min_length=1)
    allowed_endpoints: list[str] | None = None
    rate_limit_per_minute: int | None = Field(None, ge=1, le=10000)
    ip_allowed_list: list[str] | None = None
    expires_at: datetime | None = None
    site_id: str | None = None


class APIClientUpdateRequest(BaseModel):
    """Request to update an API client."""

    is_active: bool | None = None
    permissions: list[str] | None = Field(None, min_length=1)
    allowed_endpoints: list[str] | None = None
    rate_limit_per_minute: int | None = Field(None, ge=1, le=10000)
    ip_allowed_list: list[str] | None = None
    expires_at: datetime | None = None
    note: str | None = None


class APIClientResponse(BaseModel):
    """Response for API client."""

    id: str
    tenant_id: str
    client_name: str
    created_at: datetime
    revision_no: int
    is_active: bool
    permissions: list[str]
    allowed_endpoints: list[str] | None
    rate_limit_per_minute: int | None
    ip_allowed_list: list[str] | None
    expires_at: datetime | None
    note: str | None

    class Config:
        from_attributes = True


class APIClientCreateResponse(APIClientResponse):
    """Response for creating an API client (includes plaintext API key)."""

    api_key: str  # Only returned once!


class UsageLogResponse(BaseModel):
    """Response for usage log."""

    id: str
    client_id: str
    endpoint: str
    method: str
    status_code: int
    ip_address: str | None
    request_size_bytes: int | None
    response_size_bytes: int | None
    duration_ms: int | None
    accessed_at: datetime

    class Config:
        from_attributes = True


# --- Endpoints ---


@router.post("", response_model=APIClientCreateResponse, status_code=status.HTTP_201_CREATED)
def create_api_client(
    req: APIClientCreateRequest,
    db: Session = Depends(get_db),
    current_user=Depends(require_internal),
):
    """Create a new API client.

    Returns the API key ONCE. Store it securely!
    """
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    svc = APIClientService(db, tenant_id)

    data = APIClientCreate(
        client_name=req.client_name,
        permissions=req.permissions,
        allowed_endpoints=req.allowed_endpoints,
        rate_limit_per_minute=req.rate_limit_per_minute,
        ip_allowed_list=req.ip_allowed_list,
        expires_at=req.expires_at,
        site_id=req.site_id,
    )

    client, revision, api_key = svc.create(data, created_by=user_id)

    return APIClientCreateResponse(
        id=client.euid,
        tenant_id=str(client.tenant_id),
        client_name=client.client_name,
        created_at=client.created_at,
        revision_no=revision.revision_no,
        is_active=revision.is_active,
        permissions=revision.permissions,
        allowed_endpoints=revision.allowed_endpoints,
        rate_limit_per_minute=revision.rate_limit_per_minute,
        ip_allowed_list=revision.ip_allowed_list,
        expires_at=revision.expires_at,
        note=revision.note,
        api_key=api_key,
    )


@router.get("", response_model=list[APIClientResponse])
def list_api_clients(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user=Depends(require_internal),
):
    """List all API clients for the tenant."""
    tenant_id = current_user.tenant_id
    svc = APIClientService(db, tenant_id)

    results = svc.list(skip=skip, limit=limit)

    return [
        APIClientResponse(
            id=client.euid,
            tenant_id=str(client.tenant_id),
            client_name=client.client_name,
            created_at=client.created_at,
            revision_no=revision.revision_no,
            is_active=revision.is_active,
            permissions=revision.permissions,
            allowed_endpoints=revision.allowed_endpoints,
            rate_limit_per_minute=revision.rate_limit_per_minute,
            ip_allowed_list=revision.ip_allowed_list,
            expires_at=revision.expires_at,
            note=revision.note,
        )
        for client, revision in results
    ]


@router.get("/{client_id}", response_model=APIClientResponse)
def get_api_client(
    client_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(require_internal),
):
    """Get an API client by EUID."""
    tenant_id = current_user.tenant_id
    svc = APIClientService(db, tenant_id)

    result = svc.get(client_id)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API client not found")

    client, revision = result

    return APIClientResponse(
        id=client.euid,
        tenant_id=str(client.tenant_id),
        client_name=client.client_name,
        created_at=client.created_at,
        revision_no=revision.revision_no,
        is_active=revision.is_active,
        permissions=revision.permissions,
        allowed_endpoints=revision.allowed_endpoints,
        rate_limit_per_minute=revision.rate_limit_per_minute,
        ip_allowed_list=revision.ip_allowed_list,
        expires_at=revision.expires_at,
        note=revision.note,
    )


@router.patch("/{client_id}", response_model=APIClientResponse)
def update_api_client(
    client_id: str,
    req: APIClientUpdateRequest,
    db: Session = Depends(get_db),
    current_user=Depends(require_internal),
):
    """Update an API client."""
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    svc = APIClientService(db, tenant_id)

    data = APIClientUpdate(
        is_active=req.is_active,
        permissions=req.permissions,
        allowed_endpoints=req.allowed_endpoints,
        rate_limit_per_minute=req.rate_limit_per_minute,
        ip_allowed_list=req.ip_allowed_list,
        expires_at=req.expires_at,
        note=req.note,
    )

    result = svc.update(client_id, data, updated_by=user_id)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API client not found")

    client, revision = result

    return APIClientResponse(
        id=client.euid,
        tenant_id=str(client.tenant_id),
        client_name=client.client_name,
        created_at=client.created_at,
        revision_no=revision.revision_no,
        is_active=revision.is_active,
        permissions=revision.permissions,
        allowed_endpoints=revision.allowed_endpoints,
        rate_limit_per_minute=revision.rate_limit_per_minute,
        ip_allowed_list=revision.ip_allowed_list,
        expires_at=revision.expires_at,
        note=revision.note,
    )


@router.post("/{client_id}/rotate-key", response_model=APIClientCreateResponse)
def rotate_api_key(
    client_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(require_internal),
):
    """Rotate the API key for a client.

    Returns the new API key ONCE. Store it securely!
    """
    tenant_id = current_user.tenant_id
    user_id = current_user.sub_uuid

    svc = APIClientService(db, tenant_id)

    result = svc.rotate_key(client_id, rotated_by=user_id)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API client not found")

    client, revision, api_key = result

    return APIClientCreateResponse(
        id=client.euid,
        tenant_id=str(client.tenant_id),
        client_name=client.client_name,
        created_at=client.created_at,
        revision_no=revision.revision_no,
        is_active=revision.is_active,
        permissions=revision.permissions,
        allowed_endpoints=revision.allowed_endpoints,
        rate_limit_per_minute=revision.rate_limit_per_minute,
        ip_allowed_list=revision.ip_allowed_list,
        expires_at=revision.expires_at,
        note=revision.note,
        api_key=api_key,
    )


@router.get("/{client_id}/usage", response_model=list[UsageLogResponse])
def get_api_client_usage(
    client_id: str,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user=Depends(require_internal),
):
    """Get usage logs for an API client."""
    tenant_id = current_user.tenant_id
    svc = APIClientService(db, tenant_id)

    # Verify client exists and belongs to tenant
    result = svc.get(client_id)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API client not found")

    logs = svc.get_usage_logs(client_id=client_id, limit=limit)

    return [UsageLogResponse.model_validate(log) for log in logs]
