"""Atlas TRF and Test API routes."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import RequireAuthOrToken
from app.auth.rbac import Permission, has_permission
from app.db.engine import get_db
from app.domain.enums import OrderPatientRole, OrderStatus
from app.domain.services.order_relationships import OrderPatientLink, OrderRelationshipService
from app.domain.services.trfs import TestCreate, TestService, TrfCreate, TrfService

trf_router = APIRouter(prefix="/api/trfs", tags=["trfs"])


class TrfCreateRequest(BaseModel):
    clinician_id: str | None = None
    trf_type: str = Field("CLINICAL", pattern="^(CLINICAL|RESEARCH|OTHER)$")
    clinical_notes: str | None = None
    site_id: str | None = None


class TestPatientRequest(BaseModel):
    patient_euid: str
    role: OrderPatientRole = OrderPatientRole.PROBAND


class FulfillmentRouteRequest(BaseModel):
    fulfillment_route_code: str = Field(..., min_length=1, max_length=50)
    fulfillment_route_name: str | None = None
    fulfillment_route_panel_code: str | None = None


class TrfTestCreateRequest(BaseModel):
    patients: list[TestPatientRequest] = Field(..., min_length=1)
    fulfillment_routes: list[FulfillmentRouteRequest] = Field(..., min_length=1)
    specimen_type: str | None = None
    priority: str = Field("NORMAL", pattern="^(NORMAL|STAT)$")
    clinical_notes: str | None = None
    site_id: str | None = None


class TestLinkRequest(BaseModel):
    target_test_euid: str
    link_type: str = Field("generic", min_length=1, max_length=50)


class FulfillmentRouteResponse(BaseModel):
    fulfillment_route_code: str
    fulfillment_route_name: str | None
    fulfillment_route_panel_code: str | None


class PatientLinkResponse(BaseModel):
    patient_euid: str
    role: str


class LinkedTestResponse(BaseModel):
    test_euid: str
    link_type: str


class TestResponse(BaseModel):
    id: str
    euid: str
    tenant_id: str
    trf_euid: str
    trf_number: str
    status: str
    specimen_type: str | None
    priority: str
    clinical_notes: str | None
    fulfillment_routes: list[FulfillmentRouteResponse]
    patients: list[PatientLinkResponse]
    linked_tests: list[LinkedTestResponse]
    created_at: str | None


class TrfResponse(BaseModel):
    id: str
    euid: str
    tenant_id: str
    trf_euid: str
    trf_number: str
    clinician_id: str
    trf_type: str
    status: str
    clinical_notes: str | None
    revision_no: int
    created_at: str


def _build_trf_response(trf, trf_rev) -> TrfResponse:
    return TrfResponse(
        id=trf.euid,
        euid=trf.euid,
        tenant_id=str(trf.tenant_id),
        trf_euid=trf.euid,
        trf_number=trf.order_number,
        clinician_id=str(trf_rev.clinician_id) if trf_rev and trf_rev.clinician_id else "",
        trf_type=trf_rev.order_type if trf_rev else "CLINICAL",
        status=trf_rev.status if trf_rev else OrderStatus.DRAFT.value,
        clinical_notes=trf_rev.clinical_notes if trf_rev else None,
        revision_no=trf_rev.revision_no if trf_rev else 1,
        created_at=trf.created_at.isoformat() if trf.created_at else "",
    )


def _build_test_response(trf, test, test_rev, rel_svc: OrderRelationshipService) -> TestResponse:
    patient_links = rel_svc.list_order_patient_links(order_euid=test.euid)
    linked_tests = rel_svc.list_linked_orders(source_order_euid=test.euid)
    return TestResponse(
        id=test.euid,
        euid=test.euid,
        tenant_id=str(test.tenant_id),
        trf_euid=trf.euid,
        trf_number=trf.order_number,
        status=test_rev.status,
        specimen_type=test_rev.specimen_type_required,
        priority=test_rev.priority,
        clinical_notes=test_rev.clinical_notes,
        fulfillment_routes=[
            FulfillmentRouteResponse(
                fulfillment_route_code=code,
                fulfillment_route_name=None,
                fulfillment_route_panel_code=None,
            )
            for code in (test_rev.fulfillment_route_codes or [])
        ],
        patients=[
            PatientLinkResponse(patient_euid=link.patient_euid, role=link.role.value)
            for link in patient_links
        ],
        linked_tests=[
            LinkedTestResponse(test_euid=link.order_euid, link_type=link.link_type)
            for link in linked_tests
        ],
        created_at=test.created_at.isoformat() if test.created_at else None,
    )


def _coerce_patient_links(payload_links: list[TestPatientRequest]) -> list[OrderPatientLink]:
    return [
        OrderPatientLink(patient_euid=item.patient_euid, role=item.role) for item in payload_links
    ]


def _ensure_same_tenant_write(current_user: RequireAuthOrToken, target_tenant: uuid.UUID) -> None:
    if current_user.tenant_id != target_tenant:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cross-tenant write forbidden",
        )


@trf_router.get("", response_model=list[TrfResponse])
async def list_trfs(
    current_user: RequireAuthOrToken,
    db: Session = Depends(get_db),
) -> list[TrfResponse]:
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    rows = TrfService(db, current_user.tenant_id).list_trfs(cross_tenant=cross_tenant)
    return [_build_trf_response(trf, trf_rev) for trf, trf_rev in rows]


@trf_router.post("", response_model=TrfResponse, status_code=status.HTTP_201_CREATED)
async def create_trf(
    request: TrfCreateRequest,
    current_user: RequireAuthOrToken,
    db: Session = Depends(get_db),
) -> TrfResponse:
    trf, trf_rev = TrfService(db, current_user.tenant_id).create(
        TrfCreate(
            clinician_id=request.clinician_id,
            order_type=request.trf_type,
            clinical_notes=request.clinical_notes,
            site_id=request.site_id,
        ),
        tests=None,
        patient_links=None,
        created_by=current_user.sub_uuid,
    )
    return _build_trf_response(trf, trf_rev)


@trf_router.get("/{trf_euid}", response_model=TrfResponse)
async def get_trf(
    trf_euid: str,
    current_user: RequireAuthOrToken,
    db: Session = Depends(get_db),
) -> TrfResponse:
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    result = TrfService(db, current_user.tenant_id).get_by_id(trf_euid, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"TRF {trf_euid} not found",
        )
    return _build_trf_response(*result)


@trf_router.get("/{trf_euid}/tests", response_model=list[TestResponse])
async def list_tests_for_trf(
    trf_euid: str,
    current_user: RequireAuthOrToken,
    db: Session = Depends(get_db),
) -> list[TestResponse]:
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    trf_result = TrfService(db, current_user.tenant_id).get_by_id(
        trf_euid, cross_tenant=cross_tenant
    )
    if not trf_result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"TRF {trf_euid} not found",
        )

    trf, _trf_rev = trf_result
    rel_svc = OrderRelationshipService(db, trf.tenant_id)
    rows = TestService(db, trf.tenant_id).list_for_trf(trf.euid, cross_tenant=cross_tenant)
    return [_build_test_response(trf, test, test_rev, rel_svc) for test, test_rev, _ in rows]


@trf_router.post(
    "/{trf_euid}/tests", response_model=TestResponse, status_code=status.HTTP_201_CREATED
)
async def create_test_under_trf(
    trf_euid: str,
    request: TrfTestCreateRequest,
    current_user: RequireAuthOrToken,
    db: Session = Depends(get_db),
) -> TestResponse:
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    trf_svc = TrfService(db, current_user.tenant_id)
    trf_result = trf_svc.get_by_id(trf_euid, cross_tenant=cross_tenant)
    if not trf_result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"TRF {trf_euid} not found",
        )

    trf, _trf_rev = trf_result
    _ensure_same_tenant_write(current_user, trf.tenant_id)

    patient_links = _coerce_patient_links(request.patients)
    test_create = TestCreate(
        fulfillment_route_codes=[
            str(item.fulfillment_route_code).strip()
            for item in request.fulfillment_routes
            if str(item.fulfillment_route_code).strip()
        ],
        specimen_type=request.specimen_type,
        priority=request.priority,
        clinical_notes=request.clinical_notes,
        site_id=request.site_id,
    )

    created = TestService(db, trf.tenant_id).create(
        trf.euid,
        test_create,
        created_by=current_user.sub_uuid,
        cross_tenant=cross_tenant,
    )
    if not created:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not create test",
        )

    test, test_rev = created
    rel_svc = OrderRelationshipService(db, trf.tenant_id)
    try:
        rel_svc.ensure_order_patient_links(
            order_euid=test.euid,
            links=patient_links,
            replace=True,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    db.commit()
    return _build_test_response(trf, test, test_rev, rel_svc)


@trf_router.get("/tests/{test_euid}", response_model=TestResponse)
async def get_test(
    test_euid: str,
    current_user: RequireAuthOrToken,
    db: Session = Depends(get_db),
) -> TestResponse:
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    test_svc = TestService(db, current_user.tenant_id)
    test = test_svc.get_by_id(test_euid, cross_tenant=cross_tenant)
    if test is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Test {test_euid} not found",
        )

    test_rev = test_svc._get_latest_revision(test_euid)  # noqa: SLF001
    if test_rev is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Test revision not found",
        )

    trf_result = TrfService(db, current_user.tenant_id).get_by_id(
        test.order_id,
        cross_tenant=cross_tenant,
    )
    if trf_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Parent TRF not found")
    trf, _trf_rev = trf_result

    rel_svc = OrderRelationshipService(db, test.tenant_id)
    return _build_test_response(trf, test, test_rev, rel_svc)


@trf_router.post("/tests/{test_euid}/links", response_model=LinkedTestResponse)
async def link_tests(
    test_euid: str,
    request: TestLinkRequest,
    current_user: RequireAuthOrToken,
    db: Session = Depends(get_db),
) -> LinkedTestResponse:
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    test_svc = TestService(db, current_user.tenant_id)

    source_test = test_svc.get_by_id(test_euid, cross_tenant=cross_tenant)
    if source_test is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Test {test_euid} not found",
        )

    target_test = test_svc.get_by_id(request.target_test_euid, cross_tenant=cross_tenant)
    if target_test is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Test {request.target_test_euid} not found",
        )

    _ensure_same_tenant_write(current_user, source_test.tenant_id)
    if source_test.tenant_id != target_test.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cross-tenant test link denied",
        )

    rel_svc = OrderRelationshipService(db, source_test.tenant_id)
    try:
        rel_svc.link_orders(
            source_order_euid=test_euid,
            target_order_euid=request.target_test_euid,
            link_type=request.link_type,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    db.commit()
    return LinkedTestResponse(test_euid=request.target_test_euid, link_type=request.link_type)
