"""Shared observability contract endpoints for Atlas."""

from __future__ import annotations

from time import monotonic
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from app import __version__
from app.auth.dependencies import CurrentUser, get_current_user, get_observability_user
from app.db.engine import get_db
from app.observability.anomalies import TapdbAnomalyRepository
from app.observability.contracts import (
    build_api_health_payload,
    build_auth_health_payload,
    build_db_health_payload,
    build_endpoint_health_payload,
    build_health_payload,
    build_my_health_payload,
    build_obs_services_payload,
)

router = APIRouter(tags=["observability"])


def _probe_database(db: Session) -> dict[str, object]:
    started = monotonic()
    try:
        db.execute(text("SELECT 1"))
        return {
            "status": "ok",
            "latency_ms": round((monotonic() - started) * 1000, 3),
            "detail": "ok",
        }
    except Exception as exc:
        return {
            "status": "error",
            "latency_ms": round((monotonic() - started) * 1000, 3),
            "detail": str(exc),
        }


@router.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


@router.get("/readyz")
def readyz(request: Request, db: Session = Depends(get_db)) -> JSONResponse:
    probe = _probe_database(db)
    request.app.state.observability.record_db_probe(
        status=str(probe["status"]),
        latency_ms=float(probe["latency_ms"]),
        detail=str(probe["detail"]),
    )
    if probe["status"] != "ok":
        TapdbAnomalyRepository(db).record_db_probe_failure(
            detail=str(probe["detail"]),
            latency_ms=float(probe["latency_ms"]),
        )
    payload = {
        "status": "ok" if probe["status"] == "ok" else "degraded",
        "version": request.app.version,
        "database": probe,
    }
    return JSONResponse(status_code=200 if probe["status"] == "ok" else 503, content=payload)


@router.get("/health")
def health(
    request: Request,
    _user: Annotated[CurrentUser, Depends(get_observability_user)],
) -> dict:
    projection = request.app.state.observability.projection(
        observed_at=request.app.state.observability.latest_db_probe().get("observed_at")
        if request.app.state.observability.latest_db_probe()
        else None
    )
    return build_health_payload(
        request,
        projection=projection,
        health_snapshot=request.app.state.observability.health_snapshot(),
    )


@router.get("/obs_services")
def obs_services(
    request: Request,
    _user: Annotated[CurrentUser, Depends(get_observability_user)],
) -> dict:
    projection, snapshot = request.app.state.observability.obs_services_snapshot()
    return build_obs_services_payload(request, projection=projection, snapshot=snapshot)


@router.get("/api_health")
def api_health(
    request: Request,
    _user: Annotated[CurrentUser, Depends(get_observability_user)],
) -> dict:
    projection, families = request.app.state.observability.api_health()
    return build_api_health_payload(request, projection=projection, families=families)


@router.get("/endpoint_health")
def endpoint_health(
    request: Request,
    offset: int = Query(0, ge=0),
    limit: int = Query(25, ge=1, le=200),
    _user: Annotated[CurrentUser, Depends(get_observability_user)] = None,
) -> dict:
    projection, payload = request.app.state.observability.endpoint_health(offset=offset, limit=limit)
    return build_endpoint_health_payload(
        request,
        projection=projection,
        total=int(payload["total"]),
        offset=int(payload["offset"]),
        limit=int(payload["limit"]),
        items=list(payload["items"]),
    )


@router.get("/db_health")
def db_health(
    request: Request,
    db: Session = Depends(get_db),
    _user: Annotated[CurrentUser, Depends(get_observability_user)] = None,
) -> dict:
    probe = _probe_database(db)
    request.app.state.observability.record_db_probe(
        status=str(probe["status"]),
        latency_ms=float(probe["latency_ms"]),
        detail=str(probe["detail"]),
    )
    if probe["status"] != "ok":
        TapdbAnomalyRepository(db).record_db_probe_failure(
            detail=str(probe["detail"]),
            latency_ms=float(probe["latency_ms"]),
        )
    projection, payload = request.app.state.observability.db_health()
    return build_db_health_payload(request, projection=projection, db_health=payload)


@router.get("/my_health")
def my_health(
    request: Request,
    user: Annotated[CurrentUser, Depends(get_current_user)],
) -> dict:
    return build_my_health_payload(request, user)


@router.get("/auth_health")
def auth_health(
    request: Request,
    _user: Annotated[CurrentUser, Depends(get_observability_user)],
) -> dict:
    projection, payload = request.app.state.observability.auth_health()
    return build_auth_health_payload(request, projection=projection, auth_rollup=payload)
