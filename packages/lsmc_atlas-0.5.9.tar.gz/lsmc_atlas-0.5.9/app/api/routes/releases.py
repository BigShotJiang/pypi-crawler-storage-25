"""LSMC Hub - Release Package & Artifact API Routes.

External API for viewing release packages and downloading artifacts.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user
from app.db.engine import get_db
from app.domain.services.audit import AuditService
from app.domain.services.releases import ReleaseService

router = APIRouter(prefix="/api/releases", tags=["releases"])


# --- Request/Response Schemas ---


class ArtifactResponse(BaseModel):
    """Artifact response."""

    id: str
    euid: str | None = None
    tenant_id: str
    source_system: str
    source_uid: str
    artifact_type: str
    filename: str | None
    mime_type: str | None
    size_bytes: int | None
    checksum_sha256: str | None
    storage_uri: str | None
    created_at: str


class ReleasePackageResponse(BaseModel):
    """Release package response."""

    id: str
    euid: str | None = None
    tenant_id: str
    trf_euid: str | None
    package_number: str
    status: str
    release_type: str
    released_at: str | None
    released_by: str | None
    artifacts: list[ArtifactResponse]
    revision_no: int
    created_at: str


class ReleasePackageListResponse(BaseModel):
    """List of release packages."""

    items: list[ReleasePackageResponse]
    total: int


class ReleasePackageSummaryResponse(BaseModel):
    """Release package summary for list views."""

    id: str
    euid: str | None = None
    package_number: str
    trf_euid: str | None
    status: str
    release_type: str
    artifact_count: int
    released_at: str | None
    created_at: str


class ReleasePackageSummaryListResponse(BaseModel):
    """List of release package summaries."""

    items: list[ReleasePackageSummaryResponse]
    total: int


def _artifact_to_response(artifact) -> ArtifactResponse:
    """Convert artifact to response."""
    return ArtifactResponse(
        id=artifact.euid,
        euid=getattr(artifact, "euid", None),
        tenant_id=str(artifact.tenant_id),
        source_system=artifact.source_system,
        source_uid=artifact.source_uid,
        artifact_type=artifact.artifact_type,
        filename=artifact.filename,
        mime_type=artifact.mime_type,
        size_bytes=artifact.size_bytes,
        checksum_sha256=artifact.checksum_sha256,
        storage_uri=artifact.storage_uri,
        created_at=artifact.created_at.isoformat(),
    )


def _release_to_response(release, revision, artifacts) -> ReleasePackageResponse:
    """Convert release package to response."""
    return ReleasePackageResponse(
        id=release.euid,
        euid=getattr(release, "euid", None),
        tenant_id=str(release.tenant_id),
        trf_euid=str(revision.order_id) if revision.order_id else None,
        package_number=release.package_number,
        status=revision.status,
        release_type=revision.release_type,
        released_at=revision.released_at.isoformat() if revision.released_at else None,
        released_by=revision.released_by,
        artifacts=[_artifact_to_response(a) for a in artifacts],
        revision_no=revision.revision_no,
        created_at=release.created_at.isoformat(),
    )


# --- Endpoints ---


@router.get("", response_model=ReleasePackageSummaryListResponse)
def list_releases(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
    trf_euid: str | None = None,
) -> ReleasePackageSummaryListResponse:
    """List release packages for tenant."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ReleaseService(db, current_user.tenant_id)
    releases = svc.list_packages(
        skip=skip, limit=limit, order_id=trf_euid, cross_tenant=cross_tenant
    )

    items = [
        ReleasePackageSummaryResponse(
            id=r.euid,
            euid=getattr(r, "euid", None),
            package_number=r.package_number,
            trf_euid=None,  # Would need join
            status=rev.status if rev else "DRAFT",
            release_type=rev.release_type if rev else "INITIAL",
            artifact_count=0,  # Would need count
            released_at=rev.released_at.isoformat() if rev and rev.released_at else None,
            created_at=r.created_at.isoformat(),
        )
        for r, rev in releases
    ]
    return ReleasePackageSummaryListResponse(items=items, total=len(items))


@router.get("/{package_number}", response_model=ReleasePackageResponse)
def get_release(
    package_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ReleasePackageResponse:
    """Get release package by package_number. Uses human-readable identifier in URL."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ReleaseService(db, current_user.tenant_id)
    result = svc.get_by_package_number(package_number, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Release package {package_number} not found",
        )

    release, revision = result
    artifacts = svc.get_artifacts(release.euid)

    return _release_to_response(release, revision, artifacts)


@router.get("/by-trf/{trf_euid}", response_model=ReleasePackageSummaryListResponse)
def get_releases_by_trf(
    trf_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ReleasePackageSummaryListResponse:
    """Get all release packages for a TRF by TRF EUID."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.trfs import TrfService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)

    trf_svc = TrfService(db, current_user.tenant_id)
    trf_result = trf_svc.get_by_id(trf_euid, cross_tenant=cross_tenant)
    if not trf_result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"TRF {trf_euid} not found",
        )

    trf, _rev = trf_result
    svc = ReleaseService(db, current_user.tenant_id)
    releases = svc.list_packages(order_id=trf.euid, cross_tenant=cross_tenant)

    items = [
        ReleasePackageSummaryResponse(
            id=r.euid,
            euid=getattr(r, "euid", None),
            package_number=r.package_number,
            trf_euid=trf_euid,
            status=rev.status if rev else "DRAFT",
            release_type=rev.release_type if rev else "INITIAL",
            artifact_count=0,
            released_at=rev.released_at.isoformat() if rev and rev.released_at else None,
            created_at=r.created_at.isoformat(),
        )
        for r, rev in releases
    ]
    return ReleasePackageSummaryListResponse(items=items, total=len(items))


# --- Artifact Endpoints ---

artifacts_router = APIRouter(prefix="/api/artifacts", tags=["artifacts"])


class ArtifactListResponse(BaseModel):
    """List of artifacts."""

    items: list[ArtifactResponse]
    total: int


@artifacts_router.get("", response_model=ArtifactListResponse)
def list_artifacts(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
    trf_euid: str | None = Query(None, description="Filter by TRF EUID"),
    fulfillment_run_id: str | None = Query(None, description="Filter by assay run ID"),
) -> ArtifactListResponse:
    """List artifacts for tenant, optionally filtered by TRF or assay run."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ReleaseService(db, current_user.tenant_id)
    artifacts = svc.list_artifacts(
        skip=skip,
        limit=limit,
        order_id=trf_euid,
        fulfillment_run_id=fulfillment_run_id,
        cross_tenant=cross_tenant,
    )

    items = [_artifact_to_response(a) for a in artifacts]
    return ArtifactListResponse(items=items, total=len(items))


@artifacts_router.get("/{artifact_id}", response_model=ArtifactResponse)
def get_artifact(
    artifact_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ArtifactResponse:
    """Get artifact metadata by ID (EUID)."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ReleaseService(db, current_user.tenant_id)
    artifact = svc.get_artifact(artifact_id, cross_tenant=cross_tenant)

    if not artifact:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Artifact not found")

    return _artifact_to_response(artifact)


@artifacts_router.get("/{artifact_id}/download-url")
def get_artifact_download_url(
    artifact_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> dict:
    """Get a presigned download URL for an artifact (EUID)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import AuditAction

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ReleaseService(db, current_user.tenant_id)
    artifact = svc.get_artifact(artifact_id, cross_tenant=cross_tenant)

    if not artifact:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Artifact not found")

    # Audit log the download request (PHI-sensitive)
    AuditService(db, tenant_id=current_user.tenant_id).log(
        action=AuditAction.DOWNLOAD,
        entity_type="Artifact",
        entity_id=artifact_id,
        details={
            "filename": artifact.filename,
            "artifact_type": artifact.artifact_type,
            "source_system": artifact.source_system,
            "source_uid": artifact.source_uid,
        },
        user_id=current_user.user_id,
    )

    # In production, this would generate a presigned S3 URL
    # For now, return the storage URI directly
    return {
        "artifact_id": str(artifact_id),
        "download_url": artifact.storage_uri,
        "filename": artifact.filename,
        "expires_in_seconds": 3600,
    }
