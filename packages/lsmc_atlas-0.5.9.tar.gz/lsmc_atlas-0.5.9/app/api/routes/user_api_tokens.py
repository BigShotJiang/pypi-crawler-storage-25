"""LSMC Hub - User API Token Routes.

API endpoints for user-facing API token management.
"""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import (
    CurrentUser,
    get_current_user,
    require_read_write,
    require_role,
)
from app.auth.rate_limiting import rate_limit_dependency
from app.auth.rbac import Role
from app.db.engine import get_db
from app.domain.services.user_api_tokens import TokenCreate, UserAPITokenService

router = APIRouter(prefix="/user-tokens", tags=["user-api-tokens"])
admin_router = APIRouter(prefix="/admin/user-tokens", tags=["admin-user-tokens"])


# --- Request/Response Schemas ---


class TokenCreateRequest(BaseModel):
    """Request to create a new API token."""

    token_name: str = Field(..., min_length=1, max_length=100)
    expires_in_days: int = Field(default=90, ge=1, le=365)
    scope: str = Field(default="ext_org", pattern="^(ext_org|lsmc_internal|atlas_admin)$")


class TokenResponse(BaseModel):
    """Response for token info (no secret)."""

    id: str
    token_name: str
    token_prefix: str
    status: str
    created_at: str
    expires_at: str
    last_used_at: str | None
    is_expired: bool
    usage_count: int


class TokenCreatedResponse(BaseModel):
    """Response when token is created (includes secret)."""

    id: str
    token_name: str
    token_prefix: str
    token: str  # The actual token - only shown once!
    expires_at: str
    message: str = "Save this token now. You will not be able to see it again."


class TokenRevokeRequest(BaseModel):
    """Request to revoke a token."""

    reason: str | None = None


class TokenUsageStats(BaseModel):
    """Token usage statistics."""

    total_requests: int
    endpoints: dict[str, int]
    status_codes: dict[str, int]
    last_request_at: str | None


# --- User Endpoints ---


@router.get(
    "",
    response_model=list[TokenResponse],
    dependencies=[Depends(rate_limit_dependency("api"))],
)
async def list_my_tokens(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> list[TokenResponse]:
    """List all API tokens for the current user."""
    svc = UserAPITokenService(db, current_user.tenant_id)
    tokens = svc.list_user_tokens(uuid.UUID(current_user.sub))

    return [
        TokenResponse(
            id=t.id,
            token_name=t.token_name,
            token_prefix=t.token_prefix,
            status=t.status,
            created_at=t.created_at.isoformat(),
            expires_at=t.expires_at.isoformat(),
            last_used_at=t.last_used_at.isoformat() if t.last_used_at else None,
            is_expired=t.is_expired,
            usage_count=t.usage_count,
        )
        for t in tokens
    ]


@router.post(
    "",
    response_model=TokenCreatedResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit_dependency("api")), Depends(require_read_write)],
)
async def create_token(
    request: TokenCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> TokenCreatedResponse:
    """Create a new API token.

    Requires API_ACCESS group membership.
    The token is only shown once - save it immediately!

    Scope controls the effective permissions of the token:
    - ext_org: tenant-scoped, max EXTERNAL_USER permissions
    - lsmc_internal: cross-tenant, max INTERNAL_USER permissions
    - atlas_admin: no constraint (full user roles)
    """
    user_id = uuid.UUID(current_user.sub)
    svc = UserAPITokenService(db, current_user.tenant_id)

    # Check API_ACCESS group membership
    if not svc.user_has_api_access(user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="API_ACCESS group membership required to create tokens",
        )

    # Validate scope for the user's roles
    if not svc.validate_scope_for_creator(request.scope, current_user.roles):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Your roles do not permit creating tokens with scope '{request.scope}'",
        )

    token, revision, plaintext_token = svc.create(
        user_id=user_id,
        data=TokenCreate(
            token_name=request.token_name,
            expires_in_days=request.expires_in_days,
            scope=request.scope,
        ),
        created_by=user_id,
    )

    return TokenCreatedResponse(
        id=token.euid,
        token_name=token.token_name,
        token_prefix=token.token_prefix,
        token=plaintext_token,
        expires_at=revision.expires_at.isoformat(),
    )


@router.delete(
    "/{token_id}",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(rate_limit_dependency("api")), Depends(require_read_write)],
)
async def revoke_token(
    token_id: str,
    request: TokenRevokeRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> dict:
    """Revoke an API token (by EUID).

    Users can only revoke their own tokens.
    """
    user_id = uuid.UUID(current_user.sub)
    svc = UserAPITokenService(db, current_user.tenant_id)

    # Check token ownership
    token_result = svc.get_token(token_id)
    if not token_result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Token not found")

    token, revision = token_result
    if str(token.user_id) != str(user_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your token")

    result = svc.revoke(token_id, revoked_by=user_id, reason=request.reason)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Token not found")

    return {"status": "revoked", "token_id": str(token_id)}


@router.get(
    "/{token_id}/usage",
    response_model=TokenUsageStats,
    dependencies=[Depends(rate_limit_dependency("api"))],
)
async def get_token_usage(
    token_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> TokenUsageStats:
    """Get usage statistics for a token (by EUID).

    Users can only view stats for their own tokens.
    """
    user_id = uuid.UUID(current_user.sub)
    svc = UserAPITokenService(db, current_user.tenant_id)

    # Check token ownership
    token_result = svc.get_token(token_id)
    if not token_result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Token not found")

    token, revision = token_result
    if str(token.user_id) != str(user_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your token")

    stats = svc.get_usage_stats(token_id)

    return TokenUsageStats(
        total_requests=stats["total_requests"],
        endpoints=stats["endpoints"],
        status_codes={str(k): v for k, v in stats["status_codes"].items()},
        last_request_at=stats["last_request_at"].isoformat() if stats["last_request_at"] else None,
    )


# --- Admin Endpoints ---


@admin_router.get(
    "",
    response_model=list[TokenResponse],
    dependencies=[Depends(rate_limit_dependency("api"))],
)
async def admin_list_all_tokens(
    current_user: Annotated[CurrentUser, Depends(require_role(Role.ADMIN))],
    db: Session = Depends(get_db),
    user_id: str | None = None,
    status_filter: str | None = None,
    skip: int = 0,
    limit: int = 100,
) -> list[TokenResponse]:
    """List all API tokens in the tenant (admin only)."""
    svc = UserAPITokenService(db, current_user.tenant_id)
    tokens = svc.list_all_tokens(
        user_id_filter=user_id,
        status_filter=status_filter,
        skip=skip,
        limit=limit,
    )

    return [
        TokenResponse(
            id=t.id,
            token_name=t.token_name,
            token_prefix=t.token_prefix,
            status=t.status,
            created_at=t.created_at.isoformat(),
            expires_at=t.expires_at.isoformat(),
            last_used_at=t.last_used_at.isoformat() if t.last_used_at else None,
            is_expired=t.is_expired,
            usage_count=t.usage_count,
        )
        for t in tokens
    ]


@admin_router.delete(
    "/{token_id}",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(rate_limit_dependency("api"))],
)
async def admin_revoke_token(
    token_id: str,
    request: TokenRevokeRequest,
    current_user: Annotated[CurrentUser, Depends(require_role(Role.ADMIN))],
    db: Session = Depends(get_db),
) -> dict:
    """Revoke any API token by EUID (admin only)."""
    admin_id = uuid.UUID(current_user.sub)
    svc = UserAPITokenService(db, current_user.tenant_id)

    result = svc.revoke(token_id, revoked_by=admin_id, reason=request.reason or "Revoked by admin")
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Token not found")

    return {"status": "revoked", "token_id": str(token_id)}


@admin_router.get(
    "/{token_id}/usage",
    response_model=TokenUsageStats,
    dependencies=[Depends(rate_limit_dependency("api"))],
)
async def admin_get_token_usage(
    token_id: str,
    current_user: Annotated[CurrentUser, Depends(require_role(Role.ADMIN))],
    db: Session = Depends(get_db),
) -> TokenUsageStats:
    """Get usage statistics for any token by EUID (admin only)."""
    svc = UserAPITokenService(db, current_user.tenant_id)

    stats = svc.get_usage_stats(token_id)

    return TokenUsageStats(
        total_requests=stats["total_requests"],
        endpoints=stats["endpoints"],
        status_codes={str(k): v for k, v in stats["status_codes"].items()},
        last_request_at=stats["last_request_at"].isoformat() if stats["last_request_at"] else None,
    )
