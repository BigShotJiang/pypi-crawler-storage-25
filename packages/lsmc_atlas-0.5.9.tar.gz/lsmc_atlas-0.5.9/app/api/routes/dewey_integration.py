"""Dewey integration endpoints for Atlas storage-target and release authorization seams."""

from __future__ import annotations

import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy.orm import Session

from app.api.routes.internal import verify_internal_api_key
from app.auth.rate_limiting import rate_limit_dependency
from app.db.engine import get_db
from app.domain.services.storage_policies import StoragePolicyService

router = APIRouter(prefix="/api/integrations/dewey/v1", tags=["integrations-dewey"])


class StorageTargetRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    atlas_tenant_id: str
    scope: Literal["patient", "trf", "test"]
    filename: str = Field(default="artifact.bin", min_length=1, max_length=512)
    atlas_site_euid: str | None = None
    atlas_patient_euid: str | None = None
    atlas_trf_euid: str | None = None
    atlas_test_euid: str | None = None

    @model_validator(mode="after")
    def validate_scope_fields(self) -> StorageTargetRequest:
        try:
            uuid.UUID(str(self.atlas_tenant_id))
        except ValueError as exc:
            raise ValueError("atlas_tenant_id must be a UUID string") from exc
        if self.scope == "patient" and not str(self.atlas_patient_euid or "").strip():
            raise ValueError("atlas_patient_euid is required for patient scope")
        if self.scope == "trf":
            if not str(self.atlas_site_euid or "").strip():
                raise ValueError("atlas_site_euid is required for trf scope")
            if not str(self.atlas_trf_euid or "").strip():
                raise ValueError("atlas_trf_euid is required for trf scope")
        if self.scope == "test":
            if not str(self.atlas_site_euid or "").strip():
                raise ValueError("atlas_site_euid is required for test scope")
            if not str(self.atlas_trf_euid or "").strip():
                raise ValueError("atlas_trf_euid is required for test scope")
            if not str(self.atlas_test_euid or "").strip():
                raise ValueError("atlas_test_euid is required for test scope")
        return self


class StorageTargetResponse(BaseModel):
    storage_policy_euid: str
    storage_policy_scope: Literal["organization", "site"]
    atlas_tenant_id: str
    organization_euid: str
    atlas_site_euid: str | None
    access_mode: str
    region: str
    bucket: str
    key: str
    storage_uri: str


class ReleaseAuthorizationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    atlas_tenant_id: str
    artifact_euid: str | None = None
    atlas_patient_euid: str | None = None
    atlas_trf_euid: str | None = None
    atlas_test_euid: str | None = None

    @model_validator(mode="after")
    def validate_tenant_id(self) -> ReleaseAuthorizationRequest:
        try:
            uuid.UUID(str(self.atlas_tenant_id))
        except ValueError as exc:
            raise ValueError("atlas_tenant_id must be a UUID string") from exc
        return self


class ReleaseAuthorizationResponse(BaseModel):
    authorized: bool
    reason: str


@router.post(
    "/storage-targets/resolve",
    response_model=StorageTargetResponse,
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(verify_internal_api_key), Depends(rate_limit_dependency("api"))],
)
async def resolve_storage_target(
    request: StorageTargetRequest,
    db: Session = Depends(get_db),
) -> StorageTargetResponse:
    service = StoragePolicyService(db)
    try:
        organization_euid = service.resolve_organization_euid_for_tenant(request.atlas_tenant_id)
        target = service.build_target(
            scope=request.scope,
            organization_euid=organization_euid,
            site_euid=request.atlas_site_euid,
            patient_euid=request.atlas_patient_euid,
            trf_euid=request.atlas_trf_euid,
            test_euid=request.atlas_test_euid,
            filename=request.filename,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return StorageTargetResponse(
        storage_policy_euid=target.effective_policy.policy.policy_euid,
        storage_policy_scope=target.effective_policy.scope,
        atlas_tenant_id=request.atlas_tenant_id,
        organization_euid=target.effective_policy.policy.organization_euid,
        atlas_site_euid=target.effective_policy.policy.site_euid,
        access_mode=target.effective_policy.policy.access_mode,
        region=target.effective_policy.policy.region,
        bucket=target.bucket,
        key=target.key,
        storage_uri=target.storage_uri,
    )


@router.post(
    "/authorizations/release",
    response_model=ReleaseAuthorizationResponse,
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(verify_internal_api_key), Depends(rate_limit_dependency("api"))],
)
async def authorize_release(
    request: ReleaseAuthorizationRequest,
    db: Session = Depends(get_db),
) -> ReleaseAuthorizationResponse:
    service = StoragePolicyService(db)
    authorized, reason = service.authorize_release(
        atlas_tenant_id=request.atlas_tenant_id,
        patient_euid=request.atlas_patient_euid,
        trf_euid=request.atlas_trf_euid,
        test_euid=request.atlas_test_euid,
    )
    return ReleaseAuthorizationResponse(authorized=authorized, reason=reason)
