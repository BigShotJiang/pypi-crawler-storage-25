"""Integration management commands for Atlas."""

from __future__ import annotations

import uuid
from enum import StrEnum
from typing import TYPE_CHECKING

import typer
from rich.console import Console
from rich.table import Table

from app.db.engine import SessionLocal
from app.domain.services.api_clients import APIClientCreate, APIClientService
from app.domain.services.external_objects import (
    BloomConfigResolverService,
    OrgBloomConfigService,
    OrgBloomConfigUpsert,
    SiteBloomConfigService,
    SiteBloomConfigUpsert,
)
from app.integrations.bloom_client import BloomClient, BloomClientError, resolve_secret_value
from app.settings import settings

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

console = Console()
integrations_app = typer.Typer(help="Integration operations")
bloom_app = typer.Typer(help="Bloom integration operations")
integrations_app.add_typer(bloom_app, name="bloom")


class BloomClientMode(StrEnum):
    """Provisioning mode for Bloom integration API clients."""

    ORG_FULL = "org-full"
    GLOBAL_QUERY_STATUS = "global-query-status"


def _parse_uuid(label: str, raw: str) -> uuid.UUID:
    try:
        return uuid.UUID(raw)
    except ValueError as exc:
        raise typer.BadParameter(f"Invalid {label}: {raw}") from exc


def _normalize_scope_arg(value: object) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        normalized = value.strip()
        return normalized or None
    return None


def _require_exactly_one_scope(org_id: str | None, site_id: str | None) -> None:
    org_scope = _normalize_scope_arg(org_id)
    site_scope = _normalize_scope_arg(site_id)
    if bool(org_scope) == bool(site_scope):
        raise typer.BadParameter("Provide exactly one of --org or --site")


def _resolve_site_scope(db, site_id: str):
    from app.domain.services.orgs import OrganizationService, SiteService

    site = SiteService(db).get_by_id(site_id.strip())
    if site is None:
        raise typer.BadParameter(f"Unknown site: {site_id}")

    organization = OrganizationService(db).get_by_id(site.organization_id)
    if organization is None or organization.uid is None:
        raise typer.BadParameter(f"Unable to resolve organization for site: {site_id}")

    return site, organization


@bloom_app.command("set-config")
def set_bloom_config(
    org_id: str | None = typer.Option(None, "--org", help="Organization (tenant) UUID"),
    site_id: str | None = typer.Option(None, "--site", help="Site EUID"),
    base_url: str = typer.Option(..., "--base-url", help="Bloom base URL"),
    api_key_secret_ref: str = typer.Option(
        ..., "--api-key-secret-ref", help="Bloom API key secret ref"
    ),
    webhook_secret_ref: str = typer.Option(
        "", "--webhook-secret-ref", help="Bloom webhook secret ref"
    ),
    service_user: str = typer.Option("", "--service-user", help="Per-org Bloom service user name"),
    enabled: bool = typer.Option(True, "--enabled/--disabled", help="Enable config"),
):
    """Create or update Bloom integration config for an organization or site."""
    _require_exactly_one_scope(org_id, site_id)
    db = SessionLocal()
    try:
        if org_id:
            tenant_id = _parse_uuid("org", org_id)
            record = OrgBloomConfigService(db).upsert(
                tenant_id,
                OrgBloomConfigUpsert(
                    enabled=enabled,
                    bloom_base_url=base_url.strip(),
                    bloom_api_key_secret_ref=api_key_secret_ref.strip(),
                    bloom_webhook_secret_ref=(webhook_secret_ref.strip() or None),
                    bloom_service_user=(service_user.strip() or None),
                ),
                actor_id=None,
            )
            scope_label = f"org {record.organization_id}"
        else:
            assert site_id is not None
            _site, organization = _resolve_site_scope(db, site_id)
            record = SiteBloomConfigService(db).upsert(
                site_id.strip(),
                organization.uid,
                SiteBloomConfigUpsert(
                    enabled=enabled,
                    bloom_base_url=base_url.strip(),
                    bloom_api_key_secret_ref=api_key_secret_ref.strip(),
                    bloom_webhook_secret_ref=(webhook_secret_ref.strip() or None),
                    bloom_service_user=(service_user.strip() or None),
                ),
                actor_id=None,
            )
            scope_label = f"site {record.site_id}"
        db.commit()
    finally:
        db.close()
    console.print(f"[green]✓[/green] Bloom config saved for {scope_label}")


@bloom_app.command("show-config")
def show_bloom_config(
    org_id: str | None = typer.Option(None, "--org", help="Organization (tenant) UUID"),
    site_id: str | None = typer.Option(None, "--site", help="Site EUID"),
):
    """Display Bloom integration config for an organization or site."""
    _require_exactly_one_scope(org_id, site_id)
    db = SessionLocal()
    try:
        if org_id:
            tenant_id = _parse_uuid("org", org_id)
            record = OrgBloomConfigService(db).get(tenant_id)
            title = f"Bloom Config: org {tenant_id}"
        else:
            assert site_id is not None
            site, organization = _resolve_site_scope(db, site_id)
            record = SiteBloomConfigService(db).get(site.euid)
            title = f"Bloom Config: site {site.euid}"
            effective = BloomConfigResolverService(db).get_effective(
                organization_id=organization.uid,
                site_id=site.euid,
            )
    finally:
        db.close()
    if record is None:
        if site_id:
            console.print(f"[yellow]No site Bloom config found for {site_id}[/yellow]")
        else:
            console.print(f"[yellow]No Bloom config found for org {org_id}[/yellow]")
        raise typer.Exit(0)

    table = Table(title=title)
    table.add_column("Field")
    table.add_column("Value")
    if site_id:
        table.add_row("scope", "site")
        table.add_row("site_id", site_id)
        table.add_row("organization_id", str(record.organization_id))
        if effective is not None:
            table.add_row("effective_source", effective.scope)
            table.add_row("effective_base_url", effective.bloom_base_url)
    else:
        table.add_row("scope", "organization")
    table.add_row("enabled", str(record.enabled))
    table.add_row("bloom_base_url", record.bloom_base_url)
    table.add_row("bloom_api_key_secret_ref", record.bloom_api_key_secret_ref)
    table.add_row("bloom_webhook_secret_ref", record.bloom_webhook_secret_ref or "")
    table.add_row("bloom_service_user", record.bloom_service_user or "")
    table.add_row(
        "last_verified_at", record.last_verified_at.isoformat() if record.last_verified_at else ""
    )
    console.print(table)


@bloom_app.command("verify-config")
def verify_bloom_config(
    org_id: str | None = typer.Option(None, "--org", help="Organization (tenant) UUID"),
    site_id: str | None = typer.Option(None, "--site", help="Site EUID"),
):
    """Verify config and Bloom API reachability for an organization or site."""
    _require_exactly_one_scope(org_id, site_id)
    db = SessionLocal()
    try:
        if org_id:
            tenant_id = _parse_uuid("org", org_id)
            record = OrgBloomConfigService(db).get(tenant_id)
            scope_label = f"org {tenant_id}"
        else:
            assert site_id is not None
            site, organization = _resolve_site_scope(db, site_id)
            tenant_id = organization.uid
            record = BloomConfigResolverService(db).get_effective(
                organization_id=organization.uid,
                site_id=site.euid,
            )
            scope_label = f"site {site.euid}"

        if record is None:
            console.print(f"[red]✗[/red] No enabled Bloom config found for {scope_label}")
            raise typer.Exit(1)

        api_key = resolve_secret_value(record.bloom_api_key_secret_ref)
        client = BloomClient(
            base_url=record.bloom_base_url,
            api_key=api_key,
            verify_ssl=settings.bloom_verify_ssl,
        )
        # Bloom doesn't guarantee a stable unauthenticated health endpoint.
        # Use small authenticated calls for reachability instead.
        client.list_object_categories()
        client.find_external_specimens_by_reference({"trf_euid": "VERIFY-SMOKE"})
        console.print(f"[green]✓[/green] Bloom integration verified for {scope_label}")
    except (BloomClientError, RuntimeError) as exc:
        console.print(f"[red]✗[/red] Bloom verification failed: {exc}")
        raise typer.Exit(1) from exc
    finally:
        db.close()


@bloom_app.command("provision-client")
def provision_bloom_client(
    org_id: str = typer.Option(..., "--org", help="Organization (tenant) UUID"),
    client_name: str = typer.Option("atlas-bloom", "--client-name", help="API client name"),
    mode: BloomClientMode = typer.Option(
        BloomClientMode.ORG_FULL,
        "--mode",
        help=(
            "Provisioning mode: "
            "'org-full' allows object-create + lookup routes; "
            "'global-query-status' restricts to container TRF lookups + test-order status events."
        ),
        case_sensitive=False,
    ),
):
    """Provision an Atlas API client for Bloom integration calls."""
    tenant_id = _parse_uuid("org", org_id)
    if mode == BloomClientMode.GLOBAL_QUERY_STATUS:
        permissions = [
            "bloom:atlas:write",
            "cross_tenant:read",
            "cross_tenant:write",
        ]
        allowed_endpoints = [
            "/api/integrations/bloom/v1/lookups/containers",
            "/api/integrations/bloom/v1/tests",
            "/api/integrations/bloom/v1/lookups/trfs",
            "/api/integrations/bloom/v1/lookups/patients",
            "/api/integrations/bloom/v1/lookups/testkits",
            "/api/integrations/bloom/v1/lookups/shipments",
        ]
    else:
        permissions = ["bloom:atlas:write"]
        allowed_endpoints = [
            "/api/integrations/bloom/v1",
            "/api/integrations/bloom/v1/lookups",
        ]

    db = SessionLocal()
    try:
        svc = APIClientService(db, tenant_id)
        client, _revision, api_key = svc.create(
            APIClientCreate(
                client_name=client_name,
                permissions=permissions,
                allowed_endpoints=allowed_endpoints,
                rate_limit_per_minute=1000,
                ip_allowed_list=None,
                expires_at=None,
            ),
            created_by=None,
        )
        db.commit()
    finally:
        db.close()

    console.print(f"[green]✓[/green] Provisioned Bloom API client {client.client_name}")
    console.print(f"mode={mode}")
    console.print(f"permissions={permissions}")
    console.print(f"allowed_endpoints={allowed_endpoints}")
    console.print(f"client_id={client.id}")
    console.print(f"api_key={api_key}")


@bloom_app.command("rotate-client-key")
def rotate_bloom_client_key(
    org_id: str = typer.Option(..., "--org", help="Organization (tenant) UUID"),
    client_id: str = typer.Option(..., "--client-id", help="API client UUID"),
):
    """Rotate API key for an org-scoped Bloom integration client."""
    tenant_id = _parse_uuid("org", org_id)
    parsed_client_id = _parse_uuid("client-id", client_id)
    db = SessionLocal()
    try:
        svc = APIClientService(db, tenant_id)
        result = svc.rotate_key(parsed_client_id, rotated_by=None)
        if result is None:
            console.print("[red]✗[/red] API client not found")
            raise typer.Exit(1)
        _client, _revision, api_key = result
        db.commit()
    finally:
        db.close()
    console.print("[green]✓[/green] API client key rotated")
    console.print(f"api_key={api_key}")


@bloom_app.command("register-webhook")
def register_bloom_webhook(
    org_id: str = typer.Option(..., "--org", help="Organization (tenant) UUID"),
    webhook_secret_ref: str = typer.Option(..., "--webhook-secret-ref", help="Webhook secret ref"),
):
    """Store webhook secret ref for Bloom event signature verification."""
    tenant_id = _parse_uuid("org", org_id)
    db = SessionLocal()
    try:
        svc = OrgBloomConfigService(db)
        cfg = svc.get(tenant_id)
        if cfg is None:
            console.print(f"[red]✗[/red] No Bloom config found for org {tenant_id}")
            raise typer.Exit(1)
        svc.upsert(
            tenant_id,
            OrgBloomConfigUpsert(
                enabled=cfg.enabled,
                bloom_base_url=cfg.bloom_base_url,
                bloom_api_key_secret_ref=cfg.bloom_api_key_secret_ref,
                bloom_webhook_secret_ref=webhook_secret_ref,
                bloom_service_user=cfg.bloom_service_user,
                last_verified_at=cfg.last_verified_at,
                metadata=cfg.metadata,
            ),
            actor_id=None,
        )
        db.commit()
    finally:
        db.close()
    console.print(f"[green]✓[/green] Webhook secret ref updated for org {tenant_id}")
    console.print(
        "Atlas receiver: /api/integrations/bloom/v1/events "
        "(expects X-Bloom-Signature and X-Bloom-Event-Id)"
    )


@bloom_app.command("status-sync")
def bloom_status_sync(
    org_id: str = typer.Option(..., "--org", help="Organization (tenant) UUID"),
):
    """Show current Atlas mirror state for Bloom external objects."""
    tenant_id = _parse_uuid("org", org_id)
    db = SessionLocal()
    try:
        from app.domain.services.external_objects import ExternalObjectService

        svc = ExternalObjectService(db, tenant_id)
        containers = svc.list_external_objects(provider="bloom", object_type="container")
        specimens = svc.list_external_objects(provider="bloom", object_type="specimen")
    finally:
        db.close()

    console.print(
        f"[green]✓[/green] Atlas mirror state for {tenant_id}: "
        f"{len(containers)} containers, {len(specimens)} specimens"
    )


@bloom_app.command("poll-once")
def bloom_poll_once(
    org_id: str = typer.Option(..., "--org", help="Organization (tenant) UUID"),
):
    """Run one Bloom by-reference polling cycle for the organization."""
    tenant_id = _parse_uuid("org", org_id)
    db = SessionLocal()
    try:
        from app.domain.services.bloom_polling import BloomPollingService

        result = BloomPollingService(db, tenant_id).poll_all_active_trfs()
        db.commit()
    finally:
        db.close()
    console.print(
        f"[green]✓[/green] Bloom poll complete for {result.tenant_id}: "
        f"trfs_polled={result.trfs_polled}, synced_items={result.synced_items}"
    )


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register integrations command group."""
    registry.add_typer_app(None, integrations_app, "integrations", "Integration operations")
