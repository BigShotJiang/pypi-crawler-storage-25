"""Cognito integration commands for LSMC Atlas.

Operational Cognito lifecycle is owned by the daylily-cognito CLI (`daycog`).
Atlas stores the resolved Cognito runtime contract in YAML and validates that
contract against daycog context data and AWS when asked.
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

import typer
from rich.console import Console

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

from app.auth.cognito_uri_validation import (
    ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
    CognitoClientNameValidationResult,
    CognitoURIValidationResult,
    validate_cognito_app_client_name,
    validate_cognito_uri_ports,
)
from app.settings import get_config_file_path, settings

cognito_app = typer.Typer(help="Atlas Cognito config commands (service lifecycle stays in daycog)")
console = Console()


def _load_atlas_config() -> dict[str, Any]:
    config_path = get_config_file_path()
    if not config_path.exists():
        return {}

    raw = config_path.read_text(encoding="utf-8")
    try:
        import yaml  # type: ignore

        return yaml.safe_load(raw) or {}
    except ModuleNotFoundError:
        return json.loads(raw) if raw.strip() else {}


def _save_atlas_config(config: dict[str, Any]) -> Path:
    config_path = get_config_file_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import yaml  # type: ignore

        config_path.write_text(
            yaml.safe_dump(config, sort_keys=False),
            encoding="utf-8",
        )
    except ModuleNotFoundError:
        config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")

    return config_path


def _atlas_cognito_contract() -> dict[str, str]:
    config = _load_atlas_config()
    auth = config.get("authentication") or {}
    cognito_cfg = auth.get("cognito") or {}
    return {
        "region": str(cognito_cfg.get("region") or "").strip(),
        "user_pool_id": str(cognito_cfg.get("user_pool_id") or "").strip(),
        "app_client_id": str(cognito_cfg.get("app_client_id") or "").strip(),
        "app_client_secret": str(cognito_cfg.get("app_client_secret") or "").strip(),
        "client_name": str(cognito_cfg.get("client_name") or "").strip(),
        "domain": str(cognito_cfg.get("domain") or "").strip(),
        "redirect_uri": str(cognito_cfg.get("redirect_uri") or "").strip(),
        "logout_url": str(cognito_cfg.get("logout_url") or "").strip(),
        "aws_profile": str(cognito_cfg.get("aws_profile") or "").strip(),
        "aws_region": str(cognito_cfg.get("aws_region") or "").strip(),
    }


def _write_atlas_cognito_contract(contract: dict[str, str]) -> Path:
    config = _load_atlas_config()
    auth = config.setdefault("authentication", {})
    auth["mode"] = "cognito"
    cognito_cfg = auth.setdefault("cognito", {})
    for field_name, value in contract.items():
        cognito_cfg[field_name] = value
    return _save_atlas_config(config)


def _run_daycog(args: list[str], *, env: dict[str, str] | None = None) -> str:
    cmd = ["daycog", *args]
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env or os.environ.copy(),
    )
    if result.returncode != 0:
        output = (result.stdout + "\n" + result.stderr).strip()
        raise RuntimeError(output or f"daycog failed ({result.returncode})")
    return (result.stdout or "").strip()


def _run_daycog_json(args: list[str], *, env: dict[str, str] | None = None) -> dict[str, Any]:
    output = _run_daycog(args, env=env)
    try:
        return json.loads(output)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"daycog did not return valid JSON: {output}") from exc


def _daycog_print_args(
    *,
    pool_name: str,
    pool_id: str,
    region: str,
    client_name: str,
    client_id: str,
) -> list[str]:
    args = ["config", "print", "--json"]
    if pool_id:
        args.extend(["--pool-id", pool_id])
    elif pool_name:
        args.extend(["--pool-name", pool_name])
    if region:
        args.extend(["--region", region])
    if client_name:
        args.extend(["--client-name", client_name])
    elif client_id:
        args.extend(["--client-id", client_id])
    return args


def _daycog_update_args(
    *,
    pool_name: str,
    pool_id: str,
    region: str,
    client_name: str,
    client_id: str,
    profile: str,
) -> list[str]:
    args = ["config", "update"]
    if pool_id:
        args.extend(["--pool-id", pool_id])
    elif pool_name:
        args.extend(["--pool-name", pool_name])
    if region:
        args.extend(["--region", region])
    if client_name:
        args.extend(["--client-name", client_name])
    elif client_id:
        args.extend(["--client-id", client_id])
    if profile:
        args.extend(["--profile", profile])
    return args


def _resolve_daycog_context(
    *,
    pool_name: str = "",
    pool_id: str = "",
    region: str = "",
    client_name: str = "",
    client_id: str = "",
    profile: str = "",
    refresh: bool = False,
) -> dict[str, str]:
    if refresh and (pool_name or pool_id):
        try:
            _run_daycog(
                _daycog_update_args(
                    pool_name=pool_name,
                    pool_id=pool_id,
                    region=region,
                    client_name=client_name,
                    client_id=client_id,
                    profile=profile,
                )
            )
        except RuntimeError:
            create_args = _daycog_update_args(
                pool_name=pool_name,
                pool_id=pool_id,
                region=region,
                client_name=client_name,
                client_id=client_id,
                profile=profile,
            )
            create_args[1] = "create"
            _run_daycog(create_args)

    payload = _run_daycog_json(
        _daycog_print_args(
            pool_name=pool_name,
            pool_id=pool_id,
            region=region,
            client_name=client_name,
            client_id=client_id,
        )
    )
    values = payload.get("values")
    if not isinstance(values, dict):
        raise RuntimeError("daycog context payload is missing a 'values' mapping")
    return {str(key): str(value) for key, value in values.items() if value is not None}


def _contract_from_daycog_values(values: dict[str, str]) -> dict[str, str]:
    region = (values.get("COGNITO_REGION") or values.get("AWS_REGION") or "").strip()
    return {
        "region": region,
        "user_pool_id": str(values.get("COGNITO_USER_POOL_ID") or "").strip(),
        "app_client_id": str(values.get("COGNITO_APP_CLIENT_ID") or "").strip(),
        "app_client_secret": str(values.get("COGNITO_APP_CLIENT_SECRET") or "").strip(),
        "client_name": (
            str(values.get("COGNITO_CLIENT_NAME") or "").strip()
            or ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME
        ),
        "domain": str(values.get("COGNITO_DOMAIN") or "").strip(),
        "redirect_uri": str(values.get("COGNITO_CALLBACK_URL") or "").strip(),
        "logout_url": str(values.get("COGNITO_LOGOUT_URL") or "").strip(),
        "aws_profile": str(values.get("AWS_PROFILE") or "").strip(),
        "aws_region": str(values.get("AWS_REGION") or "").strip() or region,
    }


def _require_complete_contract(contract: dict[str, str]) -> dict[str, str]:
    required_fields = [
        "region",
        "user_pool_id",
        "app_client_id",
        "domain",
        "redirect_uri",
        "logout_url",
    ]
    missing = [field_name for field_name in required_fields if not contract.get(field_name)]
    if missing:
        console.print("[red]✗[/red] Atlas Cognito config is incomplete")
        console.print("   Missing fields: [cyan]" + ", ".join(missing) + "[/cyan]")
        raise typer.Exit(1)
    if not contract.get("client_name"):
        contract["client_name"] = ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME
    return contract


def _resolve_expected_port(port: int | None, redirect_uri: str) -> int:
    if port is not None:
        return port
    parsed = urlparse(redirect_uri)
    if parsed.port:
        return parsed.port
    if parsed.scheme == "https":
        return 443
    if parsed.scheme == "http":
        return 80
    return 8915


def _print_uri_validation_result(result: CognitoURIValidationResult) -> None:
    if result.records:
        console.print("[bold]URI sources[/bold]")
        for record in result.records:
            console.print(f"  {record.source}: {record.uri}")
    if result.warnings:
        console.print("[yellow]Warnings[/yellow]")
        for warning in result.warnings:
            console.print(f"  {warning}")
    if result.issues:
        console.print("[red]URI issues[/red]")
        for issue in result.issues:
            console.print(f"  {issue.source}: {issue.message} ({issue.uri})")
    else:
        console.print("[green]✓[/green] URI validation passed")


def _print_client_name_validation_result(result: CognitoClientNameValidationResult) -> None:
    if result.records:
        console.print("[bold]Client-name sources[/bold]")
        for record in result.records:
            console.print(f"  {record.source}: {record.client_name or '(missing)'}")
    if result.warnings:
        console.print("[yellow]Warnings[/yellow]")
        for warning in result.warnings:
            console.print(f"  {warning}")
    if result.issues:
        console.print("[red]Client-name issues[/red]")
        for issue in result.issues:
            console.print(f"  {issue.source}: {issue.message} ({issue.client_name or '(missing)'})")
    else:
        console.print("[green]✓[/green] Client-name validation passed")


def _validate_contract(
    *,
    contract: dict[str, str],
    daycog_values: dict[str, str] | None,
    port: int | None,
    check_aws: bool,
) -> tuple[CognitoURIValidationResult, CognitoClientNameValidationResult]:
    expected_port = _resolve_expected_port(port, contract["redirect_uri"])
    profile = contract.get("aws_profile") or settings.aws_profile or None
    uri_validation = validate_cognito_uri_ports(
        expected_port=expected_port,
        pool_id=contract["user_pool_id"],
        app_client_id=contract["app_client_id"],
        region=contract["region"],
        profile=profile,
        settings_redirect_uri=contract["redirect_uri"],
        settings_logout_uri=contract["logout_url"],
        daycog_values=daycog_values,
        include_aws=check_aws,
    )
    client_name_validation = validate_cognito_app_client_name(
        expected_client_name=contract.get("client_name") or ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        pool_id=contract["user_pool_id"],
        app_client_id=contract["app_client_id"],
        region=contract["region"],
        profile=profile,
        settings_client_name=contract.get("client_name"),
        daycog_values=daycog_values,
        include_aws=check_aws,
    )
    return uri_validation, client_name_validation


@cognito_app.command("bind")
def cognito_bind(
    pool_id: str = typer.Option(..., "--pool-id", help="Existing Cognito user pool ID"),
    region: str = typer.Option(..., "--region", help="Cognito region"),
    app_client_id: str = typer.Option(..., "--app-client-id", help="App client ID"),
    domain: str = typer.Option(..., "--domain", help="Hosted UI domain"),
    redirect_uri: str = typer.Option(..., "--redirect-uri", help="Atlas redirect URI"),
    logout_url: str = typer.Option(..., "--logout-url", help="Atlas logout URL"),
    client_name: str = typer.Option(
        ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        "--client-name",
        help="Expected app client name",
    ),
    app_client_secret: str = typer.Option(
        "",
        "--app-client-secret",
        help="Optional app client secret",
    ),
    aws_profile: str = typer.Option("", "--aws-profile", help="AWS profile for diagnostics"),
    aws_region: str = typer.Option("", "--aws-region", help="AWS region override for diagnostics"),
) -> None:
    """Write an explicit Cognito contract into Atlas YAML config."""
    contract = _require_complete_contract(
        {
            "region": region.strip(),
            "user_pool_id": pool_id.strip(),
            "app_client_id": app_client_id.strip(),
            "app_client_secret": app_client_secret,
            "client_name": client_name.strip(),
            "domain": domain.strip(),
            "redirect_uri": redirect_uri.strip(),
            "logout_url": logout_url.strip(),
            "aws_profile": aws_profile.strip(),
            "aws_region": aws_region.strip() or region.strip(),
        }
    )
    cfg_path = _write_atlas_cognito_contract(contract)
    console.print("[green]✓[/green] Bound full Cognito contract in Atlas config")
    console.print(f"  Atlas config: [dim]{cfg_path}[/dim]")


@cognito_app.command("import")
def cognito_import(
    pool_name: str = typer.Option("", "--pool-name", help="Daycog pool name"),
    pool_id: str = typer.Option("", "--pool-id", help="Daycog pool ID"),
    region: str = typer.Option("", "--region", help="AWS region"),
    client_name: str = typer.Option(
        ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        "--client-name",
        help="Daycog app client name",
    ),
    client_id: str = typer.Option("", "--client-id", help="Daycog app client ID"),
    profile: str = typer.Option("", "--profile", help="AWS profile for daycog resolution"),
    refresh: bool = typer.Option(
        True,
        "--refresh/--no-refresh",
        help="Refresh the stored daycog context from AWS before importing",
    ),
) -> None:
    """Import the resolved Cognito contract from daycog into Atlas YAML."""
    values = _resolve_daycog_context(
        pool_name=pool_name.strip(),
        pool_id=pool_id.strip(),
        region=region.strip(),
        client_name=client_name.strip(),
        client_id=client_id.strip(),
        profile=profile.strip(),
        refresh=refresh,
    )
    contract = _require_complete_contract(_contract_from_daycog_values(values))
    cfg_path = _write_atlas_cognito_contract(contract)
    console.print("[green]✓[/green] Imported Cognito contract from daycog into Atlas config")
    console.print(f"  Atlas config: [dim]{cfg_path}[/dim]")


@cognito_app.command("sync-config")
def sync_config(
    refresh: bool = typer.Option(
        False,
        "--refresh/--no-refresh",
        help="Refresh the bound daycog context from AWS before syncing",
    ),
) -> None:
    """Sync Atlas YAML from the currently bound daycog pool/app context."""
    current = _require_complete_contract(_atlas_cognito_contract())
    values = _resolve_daycog_context(
        pool_id=current["user_pool_id"],
        region=current["region"],
        client_name=current.get("client_name") or ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        client_id=current.get("app_client_id") or "",
        profile=current.get("aws_profile") or "",
        refresh=refresh,
    )
    contract = _require_complete_contract(_contract_from_daycog_values(values))
    cfg_path = _write_atlas_cognito_contract(contract)
    console.print("[green]✓[/green] Synced Atlas Cognito config from daycog")
    console.print(f"  Atlas config: [dim]{cfg_path}[/dim]")


@cognito_app.command("status")
def cognito_status(
    port: int | None = typer.Option(
        None,
        "--port",
        help="Atlas app port used to validate localhost callback/logout URIs",
    ),
    check_aws: bool = typer.Option(
        True,
        "--check-aws/--no-check-aws",
        help="Validate URI values stored in the Cognito app client (AWS API)",
    ),
) -> None:
    """Show the Atlas Cognito contract and validate it."""
    contract = _require_complete_contract(_atlas_cognito_contract())
    console.print("[bold]Atlas Cognito config[/bold]")
    for field_name in [
        "region",
        "user_pool_id",
        "app_client_id",
        "client_name",
        "domain",
        "redirect_uri",
        "logout_url",
        "aws_profile",
        "aws_region",
    ]:
        console.print(f"  {field_name}: {contract.get(field_name) or '(missing)'}")

    daycog_values: dict[str, str] | None = None
    try:
        daycog_values = _resolve_daycog_context(
            pool_id=contract["user_pool_id"],
            region=contract["region"],
            client_name=contract.get("client_name") or ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
            client_id=contract["app_client_id"],
            profile=contract.get("aws_profile") or "",
            refresh=False,
        )
        console.print("[green]✓[/green] Resolved matching daycog context")
    except RuntimeError as exc:
        console.print(f"[yellow]⚠[/yellow] Could not resolve daycog context: {exc}")

    uri_validation, client_name_validation = _validate_contract(
        contract=contract,
        daycog_values=daycog_values,
        port=port,
        check_aws=check_aws,
    )
    _print_uri_validation_result(uri_validation)
    _print_client_name_validation_result(client_name_validation)
    if not uri_validation.ok or not client_name_validation.ok:
        raise typer.Exit(1)


@cognito_app.command("validate")
def cognito_validate(
    port: int | None = typer.Option(
        None,
        "--port",
        help="Atlas app port used to validate localhost callback/logout URIs",
    ),
    check_aws: bool = typer.Option(
        True,
        "--check-aws/--no-check-aws",
        help="Validate URI values stored in the Cognito app client (AWS API)",
    ),
) -> None:
    """Validate the bound Cognito contract against daycog and AWS."""
    contract = _require_complete_contract(_atlas_cognito_contract())
    daycog_values: dict[str, str] | None = None
    try:
        daycog_values = _resolve_daycog_context(
            pool_id=contract["user_pool_id"],
            region=contract["region"],
            client_name=contract.get("client_name") or ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
            client_id=contract["app_client_id"],
            profile=contract.get("aws_profile") or "",
            refresh=False,
        )
    except RuntimeError:
        daycog_values = None

    uri_validation, client_name_validation = _validate_contract(
        contract=contract,
        daycog_values=daycog_values,
        port=port,
        check_aws=check_aws,
    )
    _print_uri_validation_result(uri_validation)
    _print_client_name_validation_result(client_name_validation)
    if not uri_validation.ok or not client_name_validation.ok:
        raise typer.Exit(1)


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register the cognito command group."""
    _ = spec
    registry.add_typer_app(None, cognito_app, "cognito", "Atlas Cognito config commands")
