"""User management commands for LSMC Atlas CLI.

TapDB-only implementation. These commands must not rely on legacy SQL tables.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec

import uuid

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from app.db.engine import SessionLocal

console = Console()

users_app = typer.Typer(help="User management commands")
roles_app = typer.Typer(help="Role assignment commands")
groups_manage_app = typer.Typer(help="User group membership commands")


def _get_user_by_identifier(user_svc, user_identifier: str):
    return user_svc.get_by_id(user_identifier) or user_svc.get_by_email(user_identifier)


def _normalize_role_values(values: list[str]) -> list[str]:
    normalized: list[str] = []
    for value in values:
        candidate = (value or "").strip().upper()
        if candidate and candidate not in normalized:
            normalized.append(candidate)
    if not normalized:
        console.print("[red]✗[/red] At least one role is required")
        raise typer.Exit(1)
    return normalized


@users_app.command("list")
def list_users(
    tenant_id: str | None = typer.Option(None, "--tenant-id", "-t", help="Filter by tenant ID"),
    active_only: bool = typer.Option(False, "--active-only", "-a", help="Show only active users"),
):
    """List all users in the database."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserService

    console.print(Panel.fit("[bold blue]Atlas Users[/bold blue]", border_style="blue"))

    tenant_uuid: uuid.UUID | None = None
    if tenant_id:
        try:
            tenant_uuid = uuid.UUID(tenant_id)
        except ValueError as exc:
            console.print(f"[red]✗[/red] Invalid tenant ID: {tenant_id}")
            raise typer.Exit(1) from exc

    db = SessionLocal()
    try:
        org_svc = OrganizationService(db)
        org_name_map: dict[str, str] = {}
        for org in org_svc.list_all(active_only=False):
            rev = org_svc.get_with_revision(org.euid)
            if rev:
                _, org_rev = rev
                org_name_map[org.euid] = org_rev.display_name or org_rev.name
            else:
                org_name_map[org.euid] = org.euid

        user_svc = UserService(db)
        users = user_svc.list_users(
            tenant_id=tenant_uuid,
            skip=0,
            limit=10_000,
            is_active=True if active_only else None,
        )

        if not users:
            console.print("[yellow]No users found.[/yellow]")
            return

        table = Table(show_header=True, header_style="cyan")
        table.add_column("ID", style="dim", no_wrap=True)
        table.add_column("Email", no_wrap=True)
        table.add_column("Name")
        table.add_column("Roles")
        table.add_column("Active", justify="center")
        table.add_column("Org")

        for user in users:
            roles = ", ".join(user.roles or []) or "-"
            table.add_row(
                str(user.euid),
                user.email,
                user.name or "-",
                roles,
                "[green]Yes[/green]" if user.is_active else "[red]No[/red]",
                (org_name_map.get(str(user.tenant_id)) or str(user.tenant_id))[:32],
            )

        console.print(table)
        console.print(f"[green]Total:[/green] {len(users)} user(s)")
    finally:
        db.close()


@users_app.command("groups")
def list_groups():
    """List user groups (database + Cognito info)."""
    from app.domain.enums import SystemGroup
    from app.domain.services.groups import UserGroupService
    from app.domain.services.orgs import OrganizationService

    console.print(Panel.fit("[bold blue]Atlas User Groups[/bold blue]", border_style="blue"))

    db = SessionLocal()
    try:
        org_svc = OrganizationService(db)
        orgs = org_svc.list_all(active_only=False)
        if not orgs:
            console.print("[yellow]No organizations found.[/yellow]")
            return

        table = Table(show_header=True, header_style="cyan")
        table.add_column("Org")
        table.add_column("Group Code", no_wrap=True)
        table.add_column("Name")
        table.add_column("Scope", no_wrap=True)
        table.add_column("System", justify="center")
        table.add_column("Members", justify="right")

        row_count = 0
        for org in orgs:
            rev = org_svc.get_with_revision(org.euid)
            org_name = (rev[1].display_name or rev[1].name) if rev else org.euid
            svc = UserGroupService(db, uuid.UUID(org.euid))
            for group in SystemGroup:
                info = svc.get_group_by_code(group.value)
                if not info:
                    continue
                row_count += 1
                table.add_row(
                    org_name[:32],
                    info.group_code,
                    info.name,
                    info.access_scope,
                    "Yes" if info.is_system_group else "No",
                    str(info.member_count),
                )

        if row_count == 0:
            console.print("[yellow]No groups found in database.[/yellow]")
        else:
            console.print(table)
            console.print(f"[green]Total:[/green] {row_count} group(s)")

        console.print(
            "\n[dim]Note:[/dim] Cognito groups are managed in AWS. "
            "Atlas roles can also be mapped from Cognito groups during login."
        )
    finally:
        db.close()


@users_app.command("make-admin")
def make_admin(
    user: str = typer.Argument(..., help="User email or UUID"),
    tenant_id: str | None = typer.Option(
        None,
        "--tenant-id",
        "-t",
        help="Tenant ID to provision user into (used only when auto-provisioning).",
    ),
    auto_provision: bool = typer.Option(
        True,
        "--auto-provision/--no-auto-provision",
        help="If user is missing in Atlas DB, try to resolve Cognito sub by email and create profile.",
    ),
):
    """Add ADMIN role to a user."""
    from app.auth.cognito_admin import CognitoAdminError, admin_find_user_by_email
    from app.auth.rbac import Role
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserCreate, UserService, UserUpdate
    from app.settings import settings

    console.print(f"\n[bold blue]Making User Admin:[/bold blue] {user}")

    db = SessionLocal()
    try:
        user_svc = UserService(db)

        # Resolve identifier (EUID or email).
        user_record = user_svc.get_by_id(user) or user_svc.get_by_email(user)

        if user_record is None:
            if not auto_provision:
                console.print(f"[red]✗[/red] User not found in Atlas DB: {user}")
                raise typer.Exit(1)
            # Auto-provision requires a tenant.
            org_svc = OrganizationService(db)
            resolved_tenant: uuid.UUID | None = None

            if tenant_id:
                try:
                    candidate = uuid.UUID(tenant_id)
                except ValueError as exc:
                    console.print(f"[red]✗[/red] Invalid --tenant-id: {tenant_id}")
                    raise typer.Exit(1) from exc
                if org_svc.get_by_uid(candidate):
                    resolved_tenant = candidate
                else:
                    console.print(f"[red]✗[/red] Tenant not found: {candidate}")
                    raise typer.Exit(1)

            if resolved_tenant is None:
                configured = (settings.cognito_default_tenant_id or "").strip()
                if configured:
                    try:
                        candidate = uuid.UUID(configured)
                        if org_svc.get_by_uid(candidate):
                            resolved_tenant = candidate
                    except ValueError:
                        pass

            if resolved_tenant is None:
                orgs = org_svc.list_all(active_only=True)
                if orgs:
                    resolved_tenant = orgs[0].uid

            if resolved_tenant is None:
                console.print(
                    "[red]✗[/red] No organizations exist; run `atlas db seed` or `atlas db build` first."
                )
                raise typer.Exit(1)

            try:
                cognito = admin_find_user_by_email(user)
            except CognitoAdminError as exc:
                console.print(f"[red]✗[/red] Cognito lookup failed: {exc}")
                raise typer.Exit(1) from exc

            if cognito is None:
                console.print(
                    "[red]✗[/red] No Cognito user found for that email. "
                    "User must login once via SSO before provisioning."
                )
                raise typer.Exit(1)

            user_record = user_svc.create(
                UserCreate(
                    email=cognito["email"],
                    name=cognito.get("name"),
                    tenant_id=resolved_tenant,
                    roles=[Role.EXTERNAL_USER.value],
                    cognito_sub=cognito["sub"],
                )
            )

        if Role.ADMIN.value in (user_record.roles or []):
            console.print(f"[yellow]User {user_record.email} is already an admin.[/yellow]")
            return

        new_roles = list(dict.fromkeys([*(user_record.roles or []), Role.ADMIN.value]))
        user_svc.update(user_record.euid, UserUpdate(roles=new_roles))
        console.print(f"[green]✓[/green] Added ADMIN role to {user_record.email}")
    finally:
        db.close()


@users_app.command("remove-admin")
def remove_admin(
    user: str = typer.Argument(..., help="User email or UUID"),
):
    """Remove ADMIN role from a user."""
    from app.auth.rbac import Role
    from app.domain.services.users import UserService, UserUpdate

    console.print(f"\n[bold blue]Removing Admin:[/bold blue] {user}")
    db = SessionLocal()
    try:
        user_svc = UserService(db)
        user_record = user_svc.get_by_id(user) or user_svc.get_by_email(user)
        if not user_record:
            console.print(f"[red]✗[/red] User not found: {user}")
            raise typer.Exit(1)

        if Role.ADMIN.value not in (user_record.roles or []):
            console.print(f"[yellow]User {user_record.email} is not an admin.[/yellow]")
            return

        new_roles = [r for r in (user_record.roles or []) if r != Role.ADMIN.value]
        user_svc.update(user_record.euid, UserUpdate(roles=new_roles))
        console.print(f"[green]✓[/green] Removed ADMIN role from {user_record.email}")
    finally:
        db.close()


@users_app.command("create")
def create_user(
    email: str = typer.Argument(..., help="User email"),
    name: str = typer.Option("", "--name", "-n", help="User display name"),
    tenant_id: str | None = typer.Option(None, "--tenant-id", "-t", help="Tenant ID"),
    admin: bool = typer.Option(False, "--admin", "-a", help="Make user an admin"),
):
    """Create a new user in the database."""
    from app.auth.cognito_admin import CognitoAdminError, admin_find_user_by_email
    from app.auth.rbac import Role
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserCreate, UserService
    from app.settings import settings

    console.print(f"\n[bold blue]Creating User:[/bold blue] {email}")

    db = SessionLocal()
    try:
        org_svc = OrganizationService(db)
        resolved_tenant: uuid.UUID | None = None

        if tenant_id:
            try:
                candidate = uuid.UUID(tenant_id)
            except ValueError as exc:
                console.print(f"[red]✗[/red] Invalid --tenant-id: {tenant_id}")
                raise typer.Exit(1) from exc
            if org_svc.get_by_uid(candidate):
                resolved_tenant = candidate
            else:
                console.print(f"[red]✗[/red] Tenant not found: {candidate}")
                raise typer.Exit(1)

        if resolved_tenant is None:
            configured = (settings.cognito_default_tenant_id or "").strip()
            if configured:
                try:
                    candidate = uuid.UUID(configured)
                    if org_svc.get_by_uid(candidate):
                        resolved_tenant = candidate
                except ValueError:
                    pass

        if resolved_tenant is None:
            orgs = org_svc.list_all(active_only=True)
            if orgs:
                resolved_tenant = orgs[0].uid

        if resolved_tenant is None:
            console.print(
                "[red]✗[/red] No organizations exist; run `atlas db seed` or `atlas db build` first."
            )
            raise typer.Exit(1)

        user_svc = UserService(db)
        existing = user_svc.get_by_email(email)
        if existing is not None:
            console.print(f"[red]✗[/red] User already exists in Atlas DB: {email}")
            raise typer.Exit(1)

        try:
            cognito = admin_find_user_by_email(email)
        except CognitoAdminError as exc:
            console.print(f"[red]✗[/red] Cognito lookup failed: {exc}")
            raise typer.Exit(1) from exc

        if cognito is None:
            console.print(
                "[red]✗[/red] No Cognito user found for that email. "
                "Create the user in Cognito first (or have them login once), then rerun."
            )
            raise typer.Exit(1)

        roles = [Role.EXTERNAL_USER.value]
        if admin:
            roles.append(Role.ADMIN.value)

        created = user_svc.create(
            UserCreate(
                email=email,
                name=(name or cognito.get("name") or None),
                tenant_id=resolved_tenant,
                roles=roles,
                cognito_sub=cognito["sub"],
            )
        )
        console.print(f"[green]✓[/green] Created user {created.email} (euid={created.euid})")
    finally:
        db.close()


@users_app.command("info")
def user_info(
    user: str = typer.Argument(..., help="User email or UUID"),
):
    """Show detailed information about a user."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserService

    db = SessionLocal()
    try:
        user_svc = UserService(db)

        record = user_svc.get_by_id(user) or user_svc.get_by_email(user)
        if record is None:
            console.print(f"[red]✗[/red] User not found: {user}")
            raise typer.Exit(1)

        org_svc = OrganizationService(db)
        org = org_svc.get_with_revision(record.tenant_id)
        org_name = (org[1].display_name or org[1].name) if org else str(record.tenant_id)

        roles = ", ".join(record.roles or []) or "(none)"
        body = "\n".join(
            [
                f"[bold]euid[/bold]: {record.euid}",
                f"[bold]email[/bold]: {record.email}",
                f"[bold]name[/bold]: {record.name or '-'}",
                f"[bold]tenant_id[/bold]: {record.tenant_id}",
                f"[bold]tenant[/bold]: {org_name}",
                f"[bold]roles[/bold]: {roles}",
                f"[bold]active[/bold]: {'yes' if record.is_active else 'no'}",
                f"[bold]cognito_sub[/bold]: {record.cognito_sub}",
                f"[bold]euid[/bold]: {record.euid or '-'}",
                f"[bold]created_at[/bold]: {record.created_at or '-'}",
                f"[bold]last_login_at[/bold]: {record.last_login_at or '-'}",
            ]
        )
        console.print(Panel(body, title="User Info", border_style="cyan"))
    finally:
        db.close()


@users_app.command("make-ext-admin")
def make_ext_admin(
    user: str = typer.Argument(..., help="User email or UUID"),
    tenant_id: str | None = typer.Option(
        None,
        "--tenant-id",
        "-t",
        help="Tenant ID to provision user into (used only when auto-provisioning).",
    ),
    auto_provision: bool = typer.Option(
        True,
        "--auto-provision/--no-auto-provision",
        help="If user is missing in Atlas DB, try to resolve Cognito sub by email and create profile.",
    ),
):
    """Add EXTERNAL_USER_ADMIN role to a user."""
    from app.auth.cognito_admin import CognitoAdminError, admin_find_user_by_email
    from app.auth.rbac import Role
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserCreate, UserService, UserUpdate
    from app.settings import settings

    console.print(f"\n[bold blue]Making External Admin:[/bold blue] {user}")
    db = SessionLocal()
    try:
        user_svc = UserService(db)

        user_record = user_svc.get_by_id(user) or user_svc.get_by_email(user)

        if user_record is None:
            if not auto_provision:
                console.print(f"[red]✗[/red] User not found in Atlas DB: {user}")
                raise typer.Exit(1)

            org_svc = OrganizationService(db)
            resolved_tenant: uuid.UUID | None = None

            if tenant_id:
                try:
                    candidate = uuid.UUID(tenant_id)
                except ValueError as exc:
                    console.print(f"[red]✗[/red] Invalid --tenant-id: {tenant_id}")
                    raise typer.Exit(1) from exc
                if org_svc.get_by_uid(candidate):
                    resolved_tenant = candidate
                else:
                    console.print(f"[red]✗[/red] Tenant not found: {candidate}")
                    raise typer.Exit(1)

            if resolved_tenant is None:
                configured = (settings.cognito_default_tenant_id or "").strip()
                if configured:
                    try:
                        candidate = uuid.UUID(configured)
                        if org_svc.get_by_uid(candidate):
                            resolved_tenant = candidate
                    except ValueError:
                        pass

            if resolved_tenant is None:
                orgs = org_svc.list_all(active_only=True)
                if orgs:
                    resolved_tenant = orgs[0].uid

            if resolved_tenant is None:
                console.print(
                    "[red]✗[/red] No organizations exist; run `atlas db seed` or `atlas db build` first."
                )
                raise typer.Exit(1)

            try:
                cognito = admin_find_user_by_email(user)
            except CognitoAdminError as exc:
                console.print(f"[red]✗[/red] Cognito lookup failed: {exc}")
                raise typer.Exit(1) from exc

            if cognito is None:
                console.print(
                    "[red]✗[/red] No Cognito user found for that email. "
                    "User must login once via SSO before provisioning."
                )
                raise typer.Exit(1)

            user_record = user_svc.create(
                UserCreate(
                    email=cognito["email"],
                    name=cognito.get("name"),
                    tenant_id=resolved_tenant,
                    roles=[Role.EXTERNAL_USER.value],
                    cognito_sub=cognito["sub"],
                )
            )

        if Role.EXTERNAL_USER_ADMIN.value in (user_record.roles or []):
            console.print(
                f"[yellow]User {user_record.email} is already an external user admin.[/yellow]"
            )
            return

        new_roles = list(
            dict.fromkeys([*(user_record.roles or []), Role.EXTERNAL_USER_ADMIN.value])
        )
        user_svc.update(user_record.euid, UserUpdate(roles=new_roles))
        console.print(f"[green]✓[/green] Added EXTERNAL_USER_ADMIN role to {user_record.email}")
    finally:
        db.close()


@users_app.command("remove-ext-admin")
def remove_ext_admin(
    user: str = typer.Argument(..., help="User email or UUID"),
):
    """Remove EXTERNAL_USER_ADMIN role from a user."""
    from app.auth.rbac import Role
    from app.domain.services.users import UserService, UserUpdate

    console.print(f"\n[bold blue]Removing External Admin:[/bold blue] {user}")
    db = SessionLocal()
    try:
        user_svc = UserService(db)
        user_record = user_svc.get_by_id(user) or user_svc.get_by_email(user)
        if not user_record:
            console.print(f"[red]✗[/red] User not found: {user}")
            raise typer.Exit(1)

        if Role.EXTERNAL_USER_ADMIN.value not in (user_record.roles or []):
            console.print(
                f"[yellow]User {user_record.email} is not an external user admin.[/yellow]"
            )
            return

        new_roles = [r for r in (user_record.roles or []) if r != Role.EXTERNAL_USER_ADMIN.value]
        user_svc.update(user_record.euid, UserUpdate(roles=new_roles))
        console.print(f"[green]✓[/green] Removed EXTERNAL_USER_ADMIN role from {user_record.email}")
    finally:
        db.close()


# ── Plugin registration ──────────────────────────────────────────────────────


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register the users command group."""
    registry.add_typer_app(None, users_app, "users", "User management")
    registry.add_typer_app(None, roles_app, "roles", "Role assignment")
    registry.add_typer_app(None, groups_manage_app, "groups", "User group membership")


@roles_app.command("add")
def roles_add(
    user: str = typer.Argument(..., help="User email or EUID"),
    role: str = typer.Argument(..., help="Role to assign"),
):
    """Add a role to a user."""
    from app.domain.services.users import UserService, UserUpdate

    normalized_role = (role or "").strip().upper()
    if not normalized_role:
        console.print("[red]✗[/red] Role is required")
        raise typer.Exit(1)

    db = SessionLocal()
    try:
        user_svc = UserService(db)
        user_record = _get_user_by_identifier(user_svc, user)
        if not user_record:
            console.print(f"[red]✗[/red] User not found: {user}")
            raise typer.Exit(1)

        existing_roles = list(user_record.roles or [])
        if normalized_role in existing_roles:
            console.print(
                f"[yellow]{user_record.email} already has role {normalized_role}[/yellow]"
            )
            return

        updated_roles = list(dict.fromkeys([*existing_roles, normalized_role]))
        user_svc.update(user_record.euid, UserUpdate(roles=updated_roles))
        console.print(f"[green]✓[/green] Added role {normalized_role} to {user_record.email}")
    finally:
        db.close()


@roles_app.command("set")
def roles_set(
    user: str = typer.Argument(..., help="User email or EUID"),
    roles: list[str] = typer.Argument(..., help="Exact role set to apply"),
):
    """Replace a user's role list exactly."""
    from app.domain.services.users import UserService, UserUpdate

    normalized_roles = _normalize_role_values(list(roles or []))

    db = SessionLocal()
    try:
        user_svc = UserService(db)
        user_record = _get_user_by_identifier(user_svc, user)
        if not user_record:
            console.print(f"[red]✗[/red] User not found: {user}")
            raise typer.Exit(1)

        user_svc.update(user_record.euid, UserUpdate(roles=normalized_roles))
        console.print(
            f"[green]✓[/green] Set roles for {user_record.email} to {', '.join(normalized_roles)}"
        )
    finally:
        db.close()


@groups_manage_app.command("add")
def groups_add(
    user: str = typer.Argument(..., help="User email or EUID"),
    group: str = typer.Argument(..., help="Group code (e.g. API_ACCESS)"),
):
    """Add a user to a group."""
    from app.domain.enums import AccessScope, SystemGroup
    from app.domain.services.groups import GroupCreate, UserGroupService
    from app.domain.services.users import UserService

    group_code = (group or "").strip().upper()
    if not group_code:
        console.print("[red]✗[/red] Group code is required")
        raise typer.Exit(1)

    db = SessionLocal()
    try:
        user_svc = UserService(db)
        user_record = _get_user_by_identifier(user_svc, user)
        if not user_record:
            console.print(f"[red]✗[/red] User not found: {user}")
            raise typer.Exit(1)

        try:
            user_sub = uuid.UUID(str(user_record.cognito_sub))
        except ValueError as exc:
            console.print(f"[red]✗[/red] User cognito_sub is not a UUID: {user_record.cognito_sub}")
            raise typer.Exit(1) from exc

        group_svc = UserGroupService(db, user_record.tenant_id)
        group_info = group_svc.get_group_by_code(group_code)
        if group_info is None:
            access_scope = (
                AccessScope.SYSTEM
                if group_code in {member.value for member in SystemGroup}
                else AccessScope.TENANT
            )
            _group, _group_rev = group_svc.create_group(
                GroupCreate(
                    group_code=group_code,
                    name=group_code.replace("_", " ").title(),
                    description="Created via atlas groups add",
                    access_scope=access_scope,
                ),
                created_by=None,
            )
            group_info = group_svc.get_group_by_code(group_code)

        if group_info is None:
            console.print(f"[red]✗[/red] Unable to resolve group: {group_code}")
            raise typer.Exit(1)

        group_svc.add_user_to_group(user_sub, group_info.euid, None)
        console.print(
            f"[green]✓[/green] Added {user_record.email} to group {group_info.group_code}"
        )
    finally:
        db.close()
