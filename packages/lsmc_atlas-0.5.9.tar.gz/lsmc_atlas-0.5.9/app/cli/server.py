"""Server management commands for LSMC Atlas CLI."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cli_core_yo.registry import CommandRegistry
    from cli_core_yo.spec import CliSpec


import os
import ssl
import shutil
import signal
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import typer
from rich.console import Console

from app.auth.cognito_uri_validation import (
    ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
    validate_cognito_app_client_name,
    validate_cognito_uri_ports,
)
from app.integrations.tapdb_runtime import (
    DEFAULT_AWS_PROFILE,
    DEFAULT_AWS_REGION,
    DEFAULT_TAPDB_DATABASE_NAME,
    TapDBRuntimeError,
    export_database_url_for_target,
)
from app.settings import settings

server_app = typer.Typer(help="Development server management commands")
console = Console()

# Get project root
PROJECT_ROOT = Path(__file__).parent.parent.parent

# PID and log file locations — resolved via XDG (§6.4).
# Lazy helpers so paths resolve after RuntimeContext is initialized.


def _state_dir() -> Path:
    """Return the XDG state directory for Atlas, falling back gracefully."""
    try:
        from cli_core_yo.runtime import get_context

        return get_context().xdg_paths.state
    except Exception:
        return Path.home() / ".config" / "lsmc-atlas"


CONFIG_DIR = Path.home() / ".config" / "lsmc-atlas"  # static fallback for module-level refs
LOG_DIR = CONFIG_DIR / "logs"
PID_FILE = CONFIG_DIR / "server.pid"
WORKER_PID_FILE = CONFIG_DIR / "worker.pid"

# Certificate locations
CERTS_DIR = PROJECT_ROOT / "certs"
CERT_FILE = CERTS_DIR / "cert.pem"
KEY_FILE = CERTS_DIR / "key.pem"
_LOCAL_COGNITO_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0"}


def _server_url(*, host: str, port: int, ssl_enabled: bool = True) -> str:
    protocol = "https" if ssl_enabled else "http"
    display_host = "localhost" if host == "0.0.0.0" else host
    return f"{protocol}://{display_host}:{port}"


def _healthcheck_url_candidates(*, host: str, port: int) -> list[str]:
    display_host = "localhost" if host == "0.0.0.0" else host
    return [
        f"https://{display_host}:{port}/healthz",
        f"http://{display_host}:{port}/healthz",
    ]


def _probe_server_health(*, host: str, port: int, timeout: float = 1.5) -> tuple[bool, str | None]:
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    for url in _healthcheck_url_candidates(host=host, port=port):
        request = Request(url, method="GET")
        try:
            with urlopen(request, timeout=timeout, context=context) as response:
                status_code = getattr(response, "status", 0) or response.getcode()
                if 200 <= int(status_code) < 500:
                    return True, url
        except HTTPError as exc:
            if 200 <= exc.code < 500:
                return True, url
        except (TimeoutError, URLError, OSError):
            continue
    return False, None


def _ensure_dir():
    """Ensure .lsmc-atlas directories exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)


def _get_log_file(prefix: str = "server") -> Path:
    """Get timestamped log file path."""
    ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    return LOG_DIR / f"{prefix}_{ts}.log"


def _get_latest_log(prefix: str = "server") -> Path | None:
    """Get the most recent log file."""
    logs = sorted(LOG_DIR.glob(f"{prefix}_*.log"), reverse=True)
    return logs[0] if logs else None


def _get_pid(pid_file: Path) -> int | None:
    """Get the running server PID if exists."""
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)
            return pid
        except (ValueError, ProcessLookupError, PermissionError):
            pid_file.unlink(missing_ok=True)
    return None


def _source_env_file() -> bool:
    """Source .env file if it exists."""
    env_file = PROJECT_ROOT / ".env"
    if env_file.exists():
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    value = value.strip().strip('"').strip("'")
                    os.environ[key.strip()] = value
        return True
    return False


def _prepare_database_url_for_server() -> None:
    """Resolve DATABASE_URL from TapDB config for normal Atlas runtime."""
    backend = (os.environ.get("DATABASE_BACKEND") or settings.database_backend).strip().lower()
    if backend != "tapdb":
        return

    target = (
        os.environ.get("DATABASE_TARGET") or settings.database_target
    ).strip().lower() or "local"
    profile = os.environ.get("AWS_PROFILE") or settings.aws_profile or DEFAULT_AWS_PROFILE
    region = os.environ.get("AWS_REGION") or settings.aws_region or DEFAULT_AWS_REGION
    namespace = (
        os.environ.get("TAPDB_DATABASE_NAME")
        or settings.database_namespace
        or DEFAULT_TAPDB_DATABASE_NAME
    )
    db_url = export_database_url_for_target(
        target=target,
        profile=profile,
        region=region,
        namespace=namespace,
    )
    console.print(f"[dim]DATABASE_URL resolved via TapDB ({target}): {db_url}[/dim]")


def _validate_cognito_uris_for_server_port(port: int) -> None:
    """Fail fast when Cognito localhost callback/logout ports drift from the server port."""
    if (os.environ.get("AUTH_MODE") or settings.auth_mode).strip().lower() != "cognito":
        return

    pool_id = (settings.cognito_user_pool_id or "").strip()
    client_id = (settings.cognito_app_client_id or "").strip()
    region = (settings.cognito_region or settings.aws_region or "").strip()
    profile = (
        settings.cognito_aws_profile or settings.aws_profile or os.environ.get("AWS_PROFILE") or ""
    ).strip()

    if not pool_id or not client_id or not region:
        console.print(
            "[yellow]⚠[/yellow] Skipping Cognito URI validation: missing pool ID, client ID, or region."
        )
        return

    missing_fields: list[str] = []
    if not (settings.cognito_redirect_uri or "").strip():
        missing_fields.append("settings.cognito_redirect_uri")
    if not (settings.cognito_logout_url or "").strip():
        missing_fields.append("settings.cognito_logout_url")
    if not (settings.cognito_domain or "").strip():
        missing_fields.append("settings.cognito_domain")
    if not (settings.cognito_app_client_id or "").strip():
        missing_fields.append("settings.cognito_app_client_id")

    if missing_fields:
        console.print(
            "[red]✗[/red] Cognito startup validation failed: missing required settings values."
        )
        for field in missing_fields:
            console.print(f"   [red]-[/red] {field}")
        console.print(f"   Run: [cyan]atlas cognito status --port {port}[/cyan]")
        raise typer.Exit(1)

    result = validate_cognito_uri_ports(
        expected_port=port,
        pool_id=pool_id,
        app_client_id=client_id,
        region=region,
        profile=profile or None,
        settings_redirect_uri=settings.cognito_redirect_uri,
        settings_logout_uri=settings.cognito_logout_url,
        include_aws=True,
    )
    app_name_result = validate_cognito_app_client_name(
        expected_client_name=ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME,
        pool_id=pool_id,
        app_client_id=client_id,
        region=region,
        profile=profile or None,
        settings_client_name=settings.cognito_client_name,
        include_aws=True,
    )
    authorize_url_issues = _validate_generated_login_authorize_url(port)

    for warning in result.warnings:
        console.print(f"[yellow]⚠[/yellow] {warning}")
    for warning in app_name_result.warnings:
        console.print(f"[yellow]⚠[/yellow] {warning}")

    if result.ok and app_name_result.ok and not authorize_url_issues:
        console.print(
            f"[green]✓[/green] Cognito callback/logout URI validation passed for port {port}"
        )
        console.print(
            "[green]✓[/green] Cognito app client name validation passed "
            f"(expected '{ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME}')"
        )
        console.print("[green]✓[/green] Cognito authorize URL includes redirect_uri")
        return

    if not result.ok:
        console.print(
            f"[red]✗[/red] Cognito URI validation failed for Atlas port {port}. "
            "Fix callback/logout URIs before starting the server."
        )
        for issue in result.issues:
            console.print(f"   [red]-[/red] {issue.source}: {issue.message}")
            console.print(f"      [dim]{issue.uri}[/dim]")

    if not app_name_result.ok:
        console.print(
            "[red]✗[/red] Cognito app client name validation failed. "
            f"Atlas requires app client name '{ATLAS_REQUIRED_COGNITO_APP_CLIENT_NAME}'."
        )
        for issue in app_name_result.issues:
            shown = issue.client_name if issue.client_name else "(missing)"
            console.print(f"   [red]-[/red] {issue.source}: {issue.message}")
            console.print(f"      [dim]{shown}[/dim]")
    if authorize_url_issues:
        console.print(
            "[red]✗[/red] Cognito authorize URL validation failed. "
            "Atlas could not build a valid /oauth2/authorize URL."
        )
        for issue in authorize_url_issues:
            console.print(f"   [red]-[/red] {issue}")
    console.print(f"   Run: [cyan]atlas cognito status --port {port}[/cyan]")
    raise typer.Exit(1)


def _validate_generated_login_authorize_url(port: int) -> list[str]:
    """Validate generated Cognito authorize URL shape before server startup."""
    from app.auth.cognito import build_login_url

    issues: list[str] = []
    try:
        login_url = build_login_url(state="atlas-startup-check")
    except Exception as exc:  # pragma: no cover - defensive runtime guard
        return [f"Unable to build login URL: {exc}"]

    parsed = urlparse(login_url)
    if parsed.scheme not in {"http", "https"}:
        issues.append(f"Generated login URL must use http/https, got: {parsed.scheme!r}")

    query = parse_qs(parsed.query, keep_blank_values=True)

    client_id = (query.get("client_id", [""])[0] or "").strip()
    if not client_id:
        issues.append("Generated login URL is missing non-empty client_id query parameter.")

    redirect_uri = (query.get("redirect_uri", [""])[0] or "").strip()
    if not redirect_uri:
        issues.append("Generated login URL is missing non-empty redirect_uri query parameter.")
        return issues

    redirect_parsed = urlparse(redirect_uri)
    if redirect_parsed.scheme not in {"http", "https"} or not redirect_parsed.hostname:
        issues.append(f"Generated redirect_uri is invalid: {redirect_uri!r}")
        return issues

    hostname = redirect_parsed.hostname.lower()
    resolved_port = redirect_parsed.port or (443 if redirect_parsed.scheme == "https" else 80)
    if hostname in _LOCAL_COGNITO_HOSTS and resolved_port != port:
        issues.append(
            "Generated redirect_uri local port "
            f"{resolved_port} does not match Atlas server port {port} ({redirect_uri})"
        )

    return issues


@server_app.command("start")
def start(
    port: int = typer.Option(8915, "--port", "-p", help="Port to run the server on"),
    host: str = typer.Option("0.0.0.0", "--host", "-h", help="Host to bind to"),
    reload: bool = typer.Option(False, "--reload/--no-reload", "-r", help="Enable auto-reload"),
    background: bool = typer.Option(
        True, "--background/--foreground", "-b/-f", help="Run in background (default)"
    ),
    ssl: bool = typer.Option(True, "--ssl/--no-ssl", "-s", help="Enable HTTPS with local certs"),
    check_cognito_uris: bool = typer.Option(
        True,
        "--check-cognito-uris/--no-check-cognito-uris",
        help="Validate Cognito callback/logout URI ports before startup",
    ),
):
    """Start the LSMC Atlas development server."""
    _ensure_dir()

    if background and reload:
        console.print(
            "[red]✗[/red] Atlas detached mode does not support auto-reload. "
            "Use [cyan]atlas server start --foreground --reload[/cyan] for live reload, "
            "or omit [cyan]--reload[/cyan] in background mode."
        )
        raise typer.Exit(1)

    # Source .env file
    if _source_env_file():
        console.print("[dim]Loaded .env file[/dim]")

    try:
        _prepare_database_url_for_server()
    except TapDBRuntimeError as exc:
        console.print(f"[red]✗[/red] {exc}")
        raise typer.Exit(1) from exc

    # Check SSL certificates if requested
    if ssl:
        if not CERT_FILE.exists() or not KEY_FILE.exists():
            console.print("[red]✗[/red]  SSL certificates not found")
            console.print("   Run: [cyan]atlas certs install && atlas certs create[/cyan]")
            raise typer.Exit(1)

    # Check if already running
    pid = _get_pid(PID_FILE)
    if pid:
        protocol = "https" if ssl else "http"
        display_h = "localhost" if host == "0.0.0.0" else host
        console.print(f"[yellow]⚠[/yellow]  Server already running (PID {pid})")
        console.print(f"   URL: [cyan]{protocol}://{display_h}:{port}[/cyan]")
        return

    if check_cognito_uris:
        _validate_cognito_uris_for_server_port(port)

    server_url = _server_url(host=host, port=port, ssl_enabled=ssl)

    if background:
        # Background mode: spawn subprocess.
        # Use PATH-resolved python instead of sys.executable which can
        # resolve to the base conda interpreter on macOS.
        python = shutil.which("python") or sys.executable
        cmd = [python, "-m", "uvicorn", "app.main:app", "--host", host, "--port", str(port)]
        if reload:
            cmd.append("--reload")
        if ssl:
            cmd.extend(["--ssl-certfile", str(CERT_FILE)])
            cmd.extend(["--ssl-keyfile", str(KEY_FILE)])

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"

        log_file = _get_log_file()
        with open(log_file, "w", buffering=1) as log_f:
            proc = subprocess.Popen(
                cmd,
                stdout=log_f,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                cwd=PROJECT_ROOT,
                env=env,
            )

            time.sleep(2)
            if proc.poll() is not None:
                console.print("[red]✗[/red]  Server failed to start. Check logs:")
                console.print(f"   [dim]{log_file}[/dim]")
                raise typer.Exit(1)

            PID_FILE.write_text(str(proc.pid))
            console.print(f"[green]✓[/green]  Server started (PID {proc.pid})")
            console.print(f"   URL: [cyan]{server_url}[/cyan]")
            console.print(f"   Logs: [dim]{log_file}[/dim]")
    else:
        # Foreground mode: call uvicorn.run() directly in-process.
        # This avoids subprocess Python-resolution issues entirely.
        import uvicorn

        console.print(
            f"[green]✓[/green]  Starting server on [cyan]{server_url}[/cyan]"
        )
        console.print("   Press Ctrl+C to stop\n")

        kwargs: dict = {
            "app": "app.main:app",
            "host": host,
            "port": port,
            "reload": reload,
        }
        if ssl:
            kwargs["ssl_certfile"] = str(CERT_FILE)
            kwargs["ssl_keyfile"] = str(KEY_FILE)

        try:
            uvicorn.run(**kwargs)
        except KeyboardInterrupt:
            console.print("\n[yellow]⚠[/yellow]  Server stopped")


@server_app.command("stop")
def stop():
    """Stop the LSMC Atlas development server."""
    pid = _get_pid(PID_FILE)
    if not pid:
        console.print("[yellow]⚠[/yellow]  No server running")
        return

    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(10):
            time.sleep(0.5)
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
        else:
            os.kill(pid, signal.SIGKILL)

        PID_FILE.unlink(missing_ok=True)
        console.print(f"[green]✓[/green]  Server stopped (was PID {pid})")
    except ProcessLookupError:
        PID_FILE.unlink(missing_ok=True)
        console.print("[yellow]⚠[/yellow]  Server was not running")
    except PermissionError:
        console.print(f"[red]✗[/red]  Permission denied stopping PID {pid}")
        raise typer.Exit(1)


@server_app.command("status")
def status():
    """Check the status of the development server."""
    pid = _get_pid(PID_FILE)
    if pid:
        port = int(os.environ.get("ATLAS_RUNTIME__PORT", os.environ.get("ATLAS_PORT", "8915")))
        host = os.environ.get("ATLAS_RUNTIME__HOST", os.environ.get("ATLAS_HOST", "0.0.0.0"))
        log_file = _get_latest_log()
        healthy, resolved_url = _probe_server_health(host=host, port=port)
        if healthy:
            console.print(f"[green]●[/green]  Server is [green]healthy[/green] (PID {pid})")
            console.print(f"   URL: [cyan]{resolved_url or _server_url(host=host, port=port)}[/cyan]")
        else:
            console.print(f"[yellow]●[/yellow]  Server process exists but is [yellow]unhealthy[/yellow] (PID {pid})")
            console.print(
                f"   Expected URL: [cyan]{_server_url(host=host, port=port)}[/cyan]"
            )
            console.print("   Health probe: [red]failed[/red]")
        if log_file:
            console.print(f"   Logs: [dim]{log_file}[/dim]")
    else:
        console.print("[dim]○[/dim]  Server is [dim]not running[/dim]")


@server_app.command("logs")
def logs(
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
    all_logs: bool = typer.Option(False, "--all", "-a", help="List all log files"),
):
    """View and follow server logs (Ctrl+C to stop)."""
    _ensure_dir()

    if all_logs:
        log_files = sorted(LOG_DIR.glob("server_*.log"), reverse=True)
        if not log_files:
            console.print("[yellow]⚠[/yellow]  No log files found.")
            return
        console.print(f"[bold]Server log files ({len(log_files)}):[/bold]")
        for lf in log_files[:20]:
            size = lf.stat().st_size
            console.print(f"  {lf.name}  [dim]({size:,} bytes)[/dim]")
        return

    log_file = _get_latest_log()
    if not log_file:
        console.print("[yellow]⚠[/yellow]  No log file found. Start the server first.")
        return

    console.print(f"[dim]Following {log_file.name} (Ctrl+C to stop)[/dim]\n")
    try:
        subprocess.run(["tail", "-f", "-n", str(lines), str(log_file)])
    except KeyboardInterrupt:
        console.print("\n")


@server_app.command("restart")
def restart(
    port: int = typer.Option(8915, "--port", "-p", help="Port to run the server on"),
    host: str = typer.Option("0.0.0.0", "--host", "-h", help="Host to bind to"),
):
    """Restart the development server."""
    stop()
    time.sleep(1)
    start(port=port, host=host, reload=False, background=True)


@server_app.command("worker")
def worker():
    """Start the background job worker."""
    console.print("[green]Starting background job worker...[/green]")
    try:
        python = shutil.which("python") or sys.executable
        subprocess.run([python, "-m", "app.worker"], cwd=PROJECT_ROOT)
    except KeyboardInterrupt:
        console.print("\n[yellow]⚠[/yellow]  Worker stopped")


# ── Plugin registration ──────────────────────────────────────────────────────


def register(registry: CommandRegistry, spec: CliSpec) -> None:
    """cli-core-yo plugin: register the server command group."""
    registry.add_typer_app(None, server_app, "server", "Development server management")
