"""LSMC Hub - Flash Message Utilities.

Provides Flask-like flash message functionality for FastAPI using session storage.
"""

from fastapi import Request


def flash(request: Request, message: str, category: str = "info") -> None:
    """Add a flash message to the session.

    Args:
        request: The FastAPI request with session
        message: The message text to display
        category: Message category (info, success, warning, error)
    """
    if "_flash_messages" not in request.session:
        request.session["_flash_messages"] = []

    request.session["_flash_messages"].append({"category": category, "message": message})


def get_flashed_messages(request: Request, with_categories: bool = False) -> list:
    """Retrieve and clear flash messages from the session.

    Args:
        request: The FastAPI request with session
        with_categories: If True, return list of (category, message) tuples

    Returns:
        List of messages or list of (category, message) tuples
    """
    messages = request.session.pop("_flash_messages", [])

    if with_categories:
        return [(msg["category"], msg["message"]) for msg in messages]
    else:
        return [msg["message"] for msg in messages]
