"""Family management web routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette import status

from app.auth.dependencies import CurrentUser, get_current_user_web, require_read_write_web
from app.auth.middleware import csrf_protect
from app.auth.rbac import Permission, has_permission
from app.db.engine import get_db
from app.domain.services.families import FamilyCreate, FamilyService
from app.domain.services.patient_relationships import PatientRelationshipService
from app.domain.services.people import PatientService
from app.domain.services.site_scope import list_tenant_site_options
from app.util.security import safe_redirect_url, sanitize_path_segment
from app.web.flash import flash
from app.web.routes.pages import get_template_context
from app.web.templates import templates

router = APIRouter(tags=["families"])


@router.get("/families", response_class=HTMLResponse)
async def families_list(
    request: Request,
    current_user: CurrentUser = Depends(get_current_user_web),
    db: Session = Depends(get_db),
    search: str | None = Query(None),
):
    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "manage"

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    family_svc = FamilyService(db, current_user.tenant_id, current_user.sub_uuid)

    # Simple name filter client-side for now (TapDB repo list is in-memory anyway).
    rows = family_svc.list_families(limit=500, offset=0, cross_tenant=cross_tenant)
    families = []
    for fam, rev in rows:
        if search and search.strip().lower() not in (rev.name or "").lower():
            continue
        families.append(
            {
                "id": fam.euid,
                "name": rev.name,
                "notes": rev.notes,
                "created_at": fam.created_at.strftime("%Y-%m-%d %H:%M") if fam.created_at else None,
            }
        )

    ctx["families"] = families
    ctx["search"] = search or ""
    return templates.TemplateResponse(request, "families/index.html", context=ctx)


@router.get("/families/new", response_class=HTMLResponse)
async def families_new_form(
    request: Request,
    current_user: CurrentUser = Depends(require_read_write_web),
    db: Session = Depends(get_db),
):
    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "manage"
    site_options = list_tenant_site_options(db, current_user.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_site_id"] = site_options[0].id if len(site_options) == 1 else None
    return templates.TemplateResponse(request, "families/new.html", context=ctx)


@router.post("/families/new", dependencies=[Depends(csrf_protect)])
async def families_new_submit(
    request: Request,
    current_user: CurrentUser = Depends(require_read_write_web),
    db: Session = Depends(get_db),
    name: str = Form(...),
    notes: str | None = Form(None),
    site_id: str | None = Form(None),
):
    family_svc = FamilyService(db, current_user.tenant_id, current_user.sub_uuid)
    try:
        family, _rev = family_svc.create(
            FamilyCreate(
                name=name,
                notes=notes if (notes or "").strip() else None,
                site_id=(site_id or "").strip() or None,
            ),
            created_by=current_user.sub_uuid,
        )
        flash(request, f"Family '{name}' created", "success")
        return RedirectResponse(
            url=safe_redirect_url(f"/families/{sanitize_path_segment(family.euid)}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except Exception:
        db.rollback()
        flash(request, "An error occurred while creating family. Please try again.", "error")
        return RedirectResponse(url="/families/new", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/families/{family_id}", response_class=HTMLResponse)
async def families_detail(
    request: Request,
    family_id: str,
    current_user: CurrentUser = Depends(get_current_user_web),
    db: Session = Depends(get_db),
):
    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "manage"

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    family_svc = FamilyService(db, current_user.tenant_id, current_user.sub_uuid)
    rel_svc = PatientRelationshipService(db, current_user.tenant_id)
    patient_svc = PatientService(db, current_user.tenant_id, current_user.sub_uuid)

    result = family_svc.get_by_id(family_id, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=404, detail="Family not found")
    family, revision = result

    member_euids = rel_svc.list_family_member_euids(family.euid)
    members = []
    for peuid in member_euids:
        pres = patient_svc.get_by_id(peuid, cross_tenant=cross_tenant)
        if not pres:
            continue
        _p, prev = pres
        members.append(
            {
                "id": peuid,
                "name": f"{prev.first_name} {prev.last_name}",
                "mrn": prev.mrn,
                "dob": prev.date_of_birth.isoformat() if prev.date_of_birth else None,
            }
        )

    ctx["family"] = {"id": family.euid, "name": revision.name, "notes": revision.notes}
    ctx["members"] = members
    return templates.TemplateResponse(request, "families/detail.html", context=ctx)


@router.post("/families/{family_id}/members/add", dependencies=[Depends(csrf_protect)])
async def families_add_member(
    request: Request,
    family_id: str,
    current_user: CurrentUser = Depends(require_read_write_web),
    db: Session = Depends(get_db),
    patient_id: str = Form(...),
):
    family_svc = FamilyService(db, current_user.tenant_id, current_user.sub_uuid)
    result = family_svc.get_by_id(family_id)
    if not result:
        raise HTTPException(status_code=404, detail="Family not found")
    family, _rev = result
    safe_family_id = str(family.euid)

    rel_svc = PatientRelationshipService(db, current_user.tenant_id)
    try:
        rel_svc.add_patient_to_family(patient_euid=patient_id, family_euid=family_id)
        db.commit()
        flash(request, "Patient added to family", "success")
    except Exception:
        db.rollback()
        flash(request, "An error occurred while adding patient to family.", "error")
    return RedirectResponse(
        url=f"/families/{safe_family_id}", status_code=status.HTTP_303_SEE_OTHER
    )


@router.post("/families/{family_id}/relationships/set-parent", dependencies=[Depends(csrf_protect)])
async def families_set_parent(
    request: Request,
    family_id: str,
    current_user: CurrentUser = Depends(require_read_write_web),
    db: Session = Depends(get_db),
    child_patient_id: str = Form(...),
    parent_patient_id: str = Form(...),
    parent_type: str = Form(...),  # father|mother
):
    family_svc = FamilyService(db, current_user.tenant_id, current_user.sub_uuid)
    result = family_svc.get_by_id(family_id)
    if not result:
        raise HTTPException(status_code=404, detail="Family not found")
    family, _rev = result
    safe_family_id = str(family.euid)

    rel_svc = PatientRelationshipService(db, current_user.tenant_id)
    try:
        # Edit-family UX: any patient IDs used for relationship edits should
        # be linked as family members automatically if not already linked.
        rel_svc.add_patient_to_family(patient_euid=child_patient_id, family_euid=family_id)
        rel_svc.add_patient_to_family(patient_euid=parent_patient_id, family_euid=family_id)
        if parent_type == "father":
            rel_svc.set_father(
                child_patient_euid=child_patient_id, father_patient_euid=parent_patient_id
            )
        elif parent_type == "mother":
            rel_svc.set_mother(
                child_patient_euid=child_patient_id, mother_patient_euid=parent_patient_id
            )
        else:
            raise ValueError("Invalid parent_type")
        db.commit()
        flash(request, "Parent relationship updated", "success")
    except Exception:
        db.rollback()
        flash(request, "An error occurred while setting parent relationship.", "error")
    return RedirectResponse(
        url=f"/families/{safe_family_id}", status_code=status.HTTP_303_SEE_OTHER
    )


@router.post(
    "/families/{family_id}/relationships/add-sibling", dependencies=[Depends(csrf_protect)]
)
async def families_add_sibling(
    request: Request,
    family_id: str,
    current_user: CurrentUser = Depends(require_read_write_web),
    db: Session = Depends(get_db),
    patient_id_a: str = Form(...),
    patient_id_b: str = Form(...),
):
    family_svc = FamilyService(db, current_user.tenant_id, current_user.sub_uuid)
    result = family_svc.get_by_id(family_id)
    if not result:
        raise HTTPException(status_code=404, detail="Family not found")
    family, _rev = result
    safe_family_id = str(family.euid)

    rel_svc = PatientRelationshipService(db, current_user.tenant_id)
    try:
        # Edit-family UX: auto-link sibling patients into the family if missing.
        rel_svc.add_patient_to_family(patient_euid=patient_id_a, family_euid=family_id)
        rel_svc.add_patient_to_family(patient_euid=patient_id_b, family_euid=family_id)
        rel_svc.add_sibling_pair(
            patient_euid_a=patient_id_a,
            patient_euid_b=patient_id_b,
        )
        db.commit()
        flash(request, "Sibling relationship created", "success")
    except Exception:
        db.rollback()
        flash(request, "An error occurred while linking siblings.", "error")
    return RedirectResponse(
        url=f"/families/{safe_family_id}", status_code=status.HTTP_303_SEE_OTHER
    )
