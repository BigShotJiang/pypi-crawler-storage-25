"""Admin anomaly views for Atlas."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, require_internal
from app.db.engine import get_db
from app.observability.anomalies import TapdbAnomalyRepository
from app.web.routes.pages import get_template_context
from app.web.templates import templates

router = APIRouter(tags=["anomalies-web"])


@router.get("/admin/anomalies", response_class=HTMLResponse)
async def anomaly_dashboard(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "admin"
    ctx["anomaly"] = None
    ctx["anomalies"] = [record.__dict__ for record in TapdbAnomalyRepository(db).list()]
    return templates.TemplateResponse(request, "admin/anomalies.html", context=ctx)


@router.get("/admin/anomalies/{anomaly_id}", response_class=HTMLResponse)
async def anomaly_detail(
    anomaly_id: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "admin"
    repository = TapdbAnomalyRepository(db)
    anomaly = repository.get(anomaly_id)
    if anomaly is None:
        raise HTTPException(status_code=404, detail="Anomaly not found")
    ctx["anomaly"] = anomaly
    ctx["anomalies"] = [record.__dict__ for record in repository.list(limit=25)]
    return templates.TemplateResponse(request, "admin/anomalies.html", context=ctx)
