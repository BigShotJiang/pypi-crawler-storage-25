"""Internal/operator observability views for Atlas."""

from __future__ import annotations

from time import monotonic
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, require_internal
from app.db.engine import get_db
from app.observability.anomalies import TapdbAnomalyRepository
from app.observability.contracts import (
    build_api_health_payload,
    build_auth_health_payload,
    build_db_health_payload,
    build_endpoint_health_payload,
    build_health_payload,
    build_obs_services_payload,
)
from app.web.routes.pages import get_template_context
from app.web.templates import templates

router = APIRouter(tags=["observability-web"])


def _probe_database(db: Session) -> dict[str, object]:
    started = monotonic()
    try:
        db.execute(text("SELECT 1"))
        return {
            "status": "ok",
            "latency_ms": round((monotonic() - started) * 1000, 3),
            "detail": "ok",
        }
    except Exception as exc:
        return {
            "status": "error",
            "latency_ms": round((monotonic() - started) * 1000, 3),
            "detail": str(exc),
        }


@router.get("/admin/observability", response_class=HTMLResponse)
async def observability_dashboard(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    probe = _probe_database(db)
    request.app.state.observability.record_db_probe(
        status=str(probe["status"]),
        latency_ms=float(probe["latency_ms"]),
        detail=str(probe["detail"]),
    )
    if probe["status"] != "ok":
        TapdbAnomalyRepository(db).record_db_probe_failure(
            detail=str(probe["detail"]),
            latency_ms=float(probe["latency_ms"]),
        )

    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "admin"

    obs_projection, obs_snapshot = request.app.state.observability.obs_services_snapshot()
    api_projection, api_families = request.app.state.observability.api_health()
    endpoint_projection, endpoint_page = request.app.state.observability.endpoint_health(
        offset=0,
        limit=25,
    )
    db_projection, db_payload = request.app.state.observability.db_health()
    auth_projection, auth_payload = request.app.state.observability.auth_health()
    health_projection = request.app.state.observability.projection(
        observed_at=request.app.state.observability.latest_db_probe().get("observed_at")
        if request.app.state.observability.latest_db_probe()
        else None
    )

    ctx["health_payload"] = build_health_payload(
        request,
        projection=health_projection,
        health_snapshot=request.app.state.observability.health_snapshot(),
    )
    ctx["obs_services_payload"] = build_obs_services_payload(
        request,
        projection=obs_projection,
        snapshot=obs_snapshot,
    )
    ctx["api_health_payload"] = build_api_health_payload(
        request,
        projection=api_projection,
        families=api_families,
    )
    ctx["endpoint_health_payload"] = build_endpoint_health_payload(
        request,
        projection=endpoint_projection,
        total=int(endpoint_page["total"]),
        offset=int(endpoint_page["offset"]),
        limit=int(endpoint_page["limit"]),
        items=list(endpoint_page["items"]),
    )
    ctx["db_health_payload"] = build_db_health_payload(
        request,
        projection=db_projection,
        db_health=db_payload,
    )
    ctx["auth_health_payload"] = build_auth_health_payload(
        request,
        projection=auth_projection,
        auth_rollup=auth_payload,
    )
    return templates.TemplateResponse(request, "admin/observability.html", context=ctx)
