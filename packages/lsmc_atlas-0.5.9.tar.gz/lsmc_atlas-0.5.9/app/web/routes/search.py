"""Unified search web route."""

from __future__ import annotations

import json
import logging
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse
from pydantic import ValidationError
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user_web
from app.auth.rbac import Permission, has_permission
from app.db.engine import get_db
from app.search.contracts import (
    SEARCH_SCOPES,
    SEARCH_SORT_DIRS,
    SEARCH_SORT_FIELDS,
    SearchQueryRequest,
)
from app.search.service import UnifiedSearchService
from app.web.flash import flash
from app.web.routes.pages import get_template_context
from app.web.templates import templates

logger = logging.getLogger(__name__)

router = APIRouter(tags=["search"])


def _build_page_url(
    *,
    q: str | None,
    scopes: list[str],
    page: int,
    page_size: int,
    sort_field: str,
    sort_dir: str,
    include_deleted: bool,
) -> str:
    params: list[tuple[str, str]] = [("page", str(page)), ("page_size", str(page_size))]
    params.extend([("scope", scope) for scope in scopes])
    params.append(("sort_field", sort_field))
    params.append(("sort_dir", sort_dir))
    if q:
        params.append(("q", q))
    if include_deleted:
        params.append(("include_deleted", "true"))
    return f"/search?{urlencode(params, doseq=True)}"


@router.get("/search", response_class=HTMLResponse)
async def search_page(
    request: Request,
    current_user: CurrentUser = Depends(get_current_user_web),
    db: Session = Depends(get_db),
    q: str | None = Query(None, max_length=256),
    scope: list[str] | None = Query(None),
    page: int = Query(1, ge=1, le=200),
    page_size: int = Query(25, ge=1, le=100),
    sort_field: str = Query("created_at"),
    sort_dir: str = Query("desc"),
    include_deleted: bool = Query(False),
):
    """Render the unified search page."""
    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "search"

    selected_scopes = scope or list(SEARCH_SCOPES)
    query_text = (q or "").strip() or None
    should_query = bool(request.query_params)

    if sort_field not in SEARCH_SORT_FIELDS:
        sort_field = "created_at"
    if sort_dir not in SEARCH_SORT_DIRS:
        sort_dir = "desc"

    try:
        query_payload = SearchQueryRequest(
            q=query_text,
            scopes=selected_scopes,
            page=page,
            page_size=page_size,
            sort_field=sort_field,
            sort_dir=sort_dir,
            include_deleted=include_deleted,
            property_filters=[],
        )
    except ValidationError as exc:
        logger.warning("Unified search query validation failed during parse: %s", exc)
        flash(request, "Invalid search query parameters.", "error")
        query_payload = SearchQueryRequest(
            q=None,
            scopes=list(SEARCH_SCOPES),
            page=1,
            page_size=25,
            sort_field="created_at",
            sort_dir="desc",
            include_deleted=False,
            property_filters=[],
        )
        should_query = False

    response = None
    if should_query:
        try:
            cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
            response = UnifiedSearchService(
                db,
                current_user.tenant_id,
                cross_tenant=cross_tenant,
            ).query(query_payload)
        except Exception as exc:  # pragma: no cover - safety guard for web UX.
            logger.error("Unified search failed: %s", exc, exc_info=True)
            flash(request, "Search is temporarily unavailable.", "error")

    facets = {"instance": 0, "template": 0, "lineage": 0, "audit": 0}
    items = []
    total = 0
    pages = 0
    has_more = False
    timing_ms = 0
    prev_url = None
    next_url = None

    if response is not None:
        facets = response.facets.model_dump()
        items = response.items
        total = response.total
        has_more = response.has_more
        timing_ms = response.timing_ms
        pages = (total + response.page_size - 1) // response.page_size if total else 0
        if response.page > 1:
            prev_url = _build_page_url(
                q=query_payload.q,
                scopes=query_payload.scopes,
                page=response.page - 1,
                page_size=query_payload.page_size,
                sort_field=query_payload.sort_field,
                sort_dir=query_payload.sort_dir,
                include_deleted=query_payload.include_deleted,
            )
        if response.has_more:
            next_url = _build_page_url(
                q=query_payload.q,
                scopes=query_payload.scopes,
                page=response.page + 1,
                page_size=query_payload.page_size,
                sort_field=query_payload.sort_field,
                sort_dir=query_payload.sort_dir,
                include_deleted=query_payload.include_deleted,
            )

    export_payload = {
        "q": query_payload.q,
        "scopes": query_payload.scopes,
        "page": 1,
        "page_size": query_payload.page_size,
        "sort_field": query_payload.sort_field,
        "sort_dir": query_payload.sort_dir,
        "include_deleted": query_payload.include_deleted,
        "property_filters": [],
        "max_rows": 1000,
    }

    ctx.update(
        {
            "query_text": query_payload.q or "",
            "selected_scopes": query_payload.scopes,
            "all_scopes": list(SEARCH_SCOPES),
            "sort_field": query_payload.sort_field,
            "sort_dir": query_payload.sort_dir,
            "page_size": query_payload.page_size,
            "include_deleted": query_payload.include_deleted,
            "results": items,
            "facets": facets,
            "total": total,
            "page": query_payload.page,
            "pages": pages,
            "has_more": has_more,
            "timing_ms": timing_ms,
            "should_query": should_query,
            "prev_url": prev_url,
            "next_url": next_url,
            "export_payload_json": json.dumps(export_payload),
        }
    )
    return templates.TemplateResponse(request, "search/index.html", context=ctx)
