"""LSMC Hub - Web UI module."""
