(() => {
  function parseSortValue(raw) {
    const text = String(raw ?? "").trim();
    if (!text) {
      return { type: "empty", value: "" };
    }

    if (/^-?\d+(\.\d+)?$/.test(text)) {
      return { type: "number", value: Number(text) };
    }

    const timestamp = Date.parse(text);
    if (!Number.isNaN(timestamp) && /[-/:T]/.test(text)) {
      return { type: "date", value: timestamp };
    }

    return { type: "text", value: text.toLowerCase() };
  }

  function getCellSortValue(cell) {
    if (!cell) {
      return "";
    }
    return cell.dataset.sortValue ?? cell.textContent ?? "";
  }

  function compareValues(left, right) {
    if (left.type === "empty" && right.type === "empty") {
      return 0;
    }
    if (left.type === "empty") {
      return 1;
    }
    if (right.type === "empty") {
      return -1;
    }
    if (left.type === right.type) {
      if (left.value < right.value) {
        return -1;
      }
      if (left.value > right.value) {
        return 1;
      }
      return 0;
    }
    return String(left.value).localeCompare(String(right.value), undefined, {
      numeric: true,
      sensitivity: "base",
    });
  }

  function markHeaders(headers, activeIndex, direction) {
    headers.forEach((header, index) => {
      if (header.dataset.sortableEnabled !== "true") {
        return;
      }
      const state = index === activeIndex ? (direction === "asc" ? "ascending" : "descending") : "none";
      header.setAttribute("aria-sort", state);
      header.dataset.sortDirection = index === activeIndex ? direction : "";
    });
  }

  function enableSortableTable(table) {
    const headRow = table.tHead?.rows?.[0];
    const body = table.tBodies?.[0];
    if (!headRow || !body) {
      return;
    }

    const headers = Array.from(headRow.cells);
    headers.forEach((header, index) => {
      const label = String(header.textContent ?? "").trim();
      const sortable = header.dataset.sortable !== "false" && label.length > 0;
      if (!sortable) {
        header.setAttribute("aria-sort", "none");
        return;
      }
      header.dataset.sortableEnabled = "true";
      header.classList.add("table-sortable-header");
      header.tabIndex = 0;
      header.setAttribute("role", "button");
      header.setAttribute("aria-sort", "none");

      const sortHandler = () => {
        const rows = Array.from(body.rows);
        const currentDirection =
          table.dataset.sortColumn === String(index) && table.dataset.sortDirection === "asc"
            ? "asc"
            : "desc";
        const nextDirection = currentDirection === "asc" ? "desc" : "asc";

        rows.sort((leftRow, rightRow) => {
          const left = parseSortValue(getCellSortValue(leftRow.cells[index]));
          const right = parseSortValue(getCellSortValue(rightRow.cells[index]));
          const result = compareValues(left, right);
          return nextDirection === "asc" ? result : -result;
        });

        rows.forEach((row) => body.appendChild(row));
        table.dataset.sortColumn = String(index);
        table.dataset.sortDirection = nextDirection;
        markHeaders(headers, index, nextDirection);
      };

      header.addEventListener("click", sortHandler);
      header.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") {
          return;
        }
        event.preventDefault();
        sortHandler();
      });
    });
  }

  function init() {
    const tables = document.querySelectorAll(
      'table[data-sortable-table="true"], table.table, table.data-table'
    );
    tables.forEach((table) => enableSortableTable(table));
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
