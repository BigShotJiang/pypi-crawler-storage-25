/* Atlas graph viewer (read-only) */

(() => {
    const config = window.AtlasGraphConfig || {};

    const graphPath = config.graphPath || "/api/graph/data";
    const graphPagePath = config.graphPagePath || "/graph";
    const objectPathTemplate = config.objectPathTemplate || "/api/graph/object/{euid}";
    const externalGraphPath = config.externalGraphPath || "/api/graph/external";
    const externalObjectPath = config.externalObjectPath || "/api/graph/external/object";
    const canCrossTenant = !!config.canCrossTenant;
    let pendingAutoMergeRef =
        Number.isInteger(config.defaultMergeRef) ? config.defaultMergeRef : null;

    const TAP_WINDOW_MS = 700;
    const WAVE_STEP_MS = 260;
    const WAVE_GLOW_MS = 520;

    let cy = null;
    const tapTracker = new Map();

    function byId(id) {
        return document.getElementById(id);
    }

    function setStatus(message, level) {
        const el = byId("graph-status");
        if (!el) {
            return;
        }
        el.textContent = message;
        el.className = "graph-status";
        if (level) {
            el.classList.add(level);
        }
    }

    function escapeHtml(value) {
        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#39;");
    }

    function prettyJson(value) {
        const safeValue = value === undefined ? {} : value;
        return JSON.stringify(safeValue === null ? {} : safeValue, null, 2);
    }

    function currentTenant() {
        if (!canCrossTenant) {
            return "";
        }
        const input = byId("graph-tenant-id");
        return input ? (input.value || "").trim() : "";
    }

    function currentDepth() {
        const input = byId("graph-depth");
        const value = Number.parseInt(input ? input.value : "", 10);
        return Number.isFinite(value) ? value : (config.defaultDepth || 4);
    }

    function currentStartEuid() {
        const input = byId("graph-start-euid");
        return input ? (input.value || "").trim() : "";
    }

    function currentProjection() {
        const input = byId("graph-projection");
        const value = input ? (input.value || "").trim().toLowerCase() : "";
        return value || (config.defaultProjection || "story");
    }

    function buildGraphRequestUrl() {
        const depth = currentDepth();
        const startEuid = currentStartEuid();

        const params = new URLSearchParams();
        params.set("depth", String(depth));
        if (startEuid) {
            params.set("start_euid", startEuid);
        }
        if (canCrossTenant) {
            const tenantId = currentTenant();
            if (tenantId) {
                params.set("tenant_id", tenantId);
            }
        }
        params.set("projection", currentProjection());

        return `${graphPath}?${params.toString()}`;
    }

    function buildObjectDetailUrl(euid) {
        const encoded = encodeURIComponent(euid);
        const base = objectPathTemplate.replace("{euid}", encoded);
        if (!canCrossTenant) {
            return base;
        }

        const tenantId = currentTenant();
        if (!tenantId) {
            return base;
        }
        return `${base}?tenant_id=${encodeURIComponent(tenantId)}`;
    }

    function buildExternalGraphUrl(sourceEuid, refIndex) {
        const params = new URLSearchParams({
            source_euid: sourceEuid,
            ref_index: String(refIndex),
            depth: String(currentDepth()),
        });
        if (canCrossTenant) {
            const tenantId = currentTenant();
            if (tenantId) {
                params.set("tenant_id", tenantId);
            }
        }
        return `${externalGraphPath}?${params.toString()}`;
    }

    function buildExternalObjectDetailUrl(sourceEuid, refIndex, euid) {
        const params = new URLSearchParams({
            source_euid: sourceEuid,
            ref_index: String(refIndex),
            euid,
        });
        if (canCrossTenant) {
            const tenantId = currentTenant();
            if (tenantId) {
                params.set("tenant_id", tenantId);
            }
        }
        return `${externalObjectPath}?${params.toString()}`;
    }

    function updateHistoryState() {
        const params = new URLSearchParams();
        const depth = currentDepth();
        const startEuid = currentStartEuid();

        params.set("depth", String(depth));
        if (startEuid) {
            params.set("start_euid", startEuid);
        }
        if (canCrossTenant) {
            const tenantId = currentTenant();
            if (tenantId) {
                params.set("tenant_id", tenantId);
            }
        }
        params.set("projection", currentProjection());
        window.history.replaceState({}, "", `${graphPagePath}?${params.toString()}`);
    }

    function updateLegend(nodes) {
        const legend = byId("graph-legend");
        if (!legend) {
            return;
        }

        const staticItems = [
            '<span class="legend-item"><span class="legend-swatch" style="background:#6f7a92"></span>Local</span>',
            '<span class="legend-item"><span class="legend-swatch" style="background:#c1a967"></span>External</span>',
            '<span class="legend-item"><span class="legend-swatch" style="background:#f7c948"></span>Bridge</span>',
        ];

        const map = new Map();
        (nodes || []).forEach((node) => {
            const data = node.data || {};
            if (!data.category || !data.color || map.has(data.category)) {
                return;
            }
            map.set(data.category, data.color);
        });

        if (map.size === 0) {
            legend.innerHTML = staticItems.join("");
            return;
        }

        const items = Array.from(map.entries())
            .sort((left, right) => left[0].localeCompare(right[0]))
            .map(
                ([category, color]) =>
                    `<span class=\"legend-item\"><span class=\"legend-swatch\" ` +
                    `style=\"background:${escapeHtml(color)}\"></span>${escapeHtml(category)}</span>`
            )
            .join("");

        legend.innerHTML = staticItems.join("") + items;
    }

    function topLevelValue(key, value) {
        if (value === null || value === undefined || value === "") {
            return '<span class="text-muted">-</span>';
        }
        if (key === "json_addl") {
            return '<span class="text-muted">Rendered below</span>';
        }
        if (typeof value === "object") {
            return `<code>${escapeHtml(JSON.stringify(value))}</code>`;
        }
        return escapeHtml(String(value));
    }

    function renderExternalRefs(refs, sourceEuid, allowMerge) {
        if (!Array.isArray(refs) || refs.length === 0) {
            return "";
        }

        return (
            `<div class="details-section-title">External References</div>` +
            refs
                .map((ref) => {
                    const openRemote = ref.href
                        ? `<a href="${escapeHtml(ref.href)}" class="btn btn-secondary" target="_blank" rel="noreferrer">Open Remote</a>`
                        : "";
                    const mergeButton = allowMerge
                        ? `<button type="button" class="btn btn-secondary" onclick="window.mergeExternalRef('${escapeHtml(sourceEuid)}', ${Number(ref.ref_index || 0)})"${ref.graph_expandable ? "" : " disabled"}>Merge External Graph</button>`
                        : "";
                    const reason = !ref.graph_expandable && ref.reason
                        ? `<div class="text-muted" style="margin-top:0.35rem;">${escapeHtml(ref.reason)}</div>`
                        : "";
                    const localExternalObject = ref.external_object_id
                        ? `<div class="text-muted" style="margin:0.15rem 0;">local external object :: ${escapeHtml(ref.external_object_id)}</div>`
                        : "";
                    return (
                        `<div style="border:1px solid var(--border-muted); border-radius:8px; padding:0.75rem; margin-top:0.6rem;">` +
                        `<div style="font-weight:700;">${escapeHtml(ref.label || ref.root_euid || "External reference")}</div>` +
                        `${localExternalObject}` +
                        `<div class="text-muted" style="margin:0.25rem 0 0.5rem 0;">${escapeHtml(ref.system || "external")} :: ${escapeHtml(ref.root_euid || "-")}${ref.tenant_id ? ` :: ${escapeHtml(ref.tenant_id)}` : ""}</div>` +
                        `<div style="display:flex; gap:0.5rem; flex-wrap:wrap;">${openRemote}${mergeButton}</div>` +
                        `${reason}` +
                        `</div>`
                    );
                })
                .join("")
        );
    }

    function renderDetailPanel(objectData, graphData) {
        const detail = byId("graph-detail-content");
        if (!detail) {
            return;
        }

        const merged = { ...(objectData || {}) };
        if (!Object.prototype.hasOwnProperty.call(merged, "euid") && graphData && graphData.id) {
            merged.euid = graphData.id;
        }

        const preferredKeys = [
            "record_type",
            "uuid",
            "euid",
            "name",
            "category",
            "type",
            "subtype",
            "version",
            "bstatus",
            "source",
            "target",
            "relationship_type",
            "created_dt",
            "modified_dt",
        ];

        const orderedKeys = preferredKeys.filter((key) => Object.hasOwn(merged, key));
        Object.keys(merged)
            .filter((key) => !orderedKeys.includes(key) && key !== "json_addl")
            .sort()
            .forEach((key) => orderedKeys.push(key));

        const rows = orderedKeys
            .map(
                (key) =>
                    `<div class=\"detail-key\">${escapeHtml(key)}</div>` +
                    `<div class=\"detail-value\">${topLevelValue(key, merged[key])}</div>`
            )
            .join("");

        const jsonAddl = Object.hasOwn(merged, "json_addl") ? merged.json_addl : {};
        const externalRefs = Array.isArray(merged.external_refs) ? merged.external_refs : [];
        const sourceEuid =
            graphData && graphData.external_source_euid ? graphData.external_source_euid : merged.euid;
        const externalRefSection = renderExternalRefs(
            externalRefs,
            sourceEuid,
            !graphData || !graphData.is_external
        );
        const graphNodeId = graphData && graphData.id ? graphData.id : merged.euid;
        const canCenterNode = !graphData || (!Object.hasOwn(graphData, "source") && !Object.hasOwn(graphData, "target"));

        detail.innerHTML =
            `<div style="display:flex; gap:0.5rem; flex-wrap:wrap; margin-bottom:0.75rem;">` +
            `${canCenterNode && graphData && graphData.id ? `<button type="button" class="btn btn-secondary" onclick="window.centerGraphNode('${escapeHtml(graphNodeId)}')">Center</button>` : ""}` +
            `</div>` +
            `<div class=\"detail-grid\">${rows || '<span class="text-muted">No details.</span>'}</div>` +
            `<div class=\"detail-key\">json_addl</div>` +
            `<pre class=\"json-block\">${escapeHtml(prettyJson(jsonAddl))}</pre>` +
            `${externalRefSection}`;
    }

    async function fetchObjectDetail(euid) {
        const response = await fetch(buildObjectDetailUrl(euid), {
            headers: { Accept: "application/json" },
        });

        if (!response.ok) {
            let payload = {};
            try {
                payload = await response.json();
            } catch (_error) {
                payload = {};
            }
            throw new Error(payload.detail || `Failed to load details (${response.status})`);
        }

        return response.json();
    }

    async function fetchExternalObjectDetail(sourceEuid, refIndex, euid) {
        const response = await fetch(buildExternalObjectDetailUrl(sourceEuid, refIndex, euid), {
            headers: { Accept: "application/json" },
            credentials: "same-origin",
        });

        if (!response.ok) {
            let payload = {};
            try {
                payload = await response.json();
            } catch (_error) {
                payload = {};
            }
            throw new Error(payload.detail || `Failed to load external details (${response.status})`);
        }

        return response.json();
    }

    async function showElementDetail(graphData) {
        const detail = byId("graph-detail-content");
        if (detail) {
            detail.innerHTML = "<span class=\"text-muted\">Loading details...</span>";
        }

        try {
            const objectData =
                graphData.is_external || graphData.is_external_bridge
                    ? await fetchExternalObjectDetail(
                          graphData.external_source_euid,
                          graphData.source_ref_index,
                          graphData.remote_euid || graphData.id
                      )
                    : await fetchObjectDetail(graphData.id);
            renderDetailPanel(objectData, graphData);
        } catch (error) {
            renderDetailPanel(graphData, graphData);
            setStatus(`Detail lookup failed: ${error.message}`, "warn");
        }
    }

    function registerTapSequence(nodeId, button) {
        const key = `${nodeId}|${button}`;
        const now = Date.now();
        const previous = tapTracker.get(key);

        let count = 1;
        if (previous && now - previous.lastTs <= TAP_WINDOW_MS) {
            count = previous.count + 1;
        }

        tapTracker.set(key, { count, lastTs: now });
        if (count >= 3) {
            tapTracker.set(key, { count: 0, lastTs: now });
            return true;
        }
        return false;
    }

    function collectWaveLevels(startNode, direction) {
        const levels = [];
        const seen = new Set([startNode.id()]);
        let frontier = cy.collection(startNode);

        while (frontier.length > 0) {
            let next = cy.collection();
            frontier.forEach((node) => {
                const neighbors =
                    direction === "children"
                        ? node.incomers("edge").sources()
                        : node.outgoers("edge").targets();

                neighbors.forEach((neighbor) => {
                    const nid = neighbor.id();
                    if (seen.has(nid)) {
                        return;
                    }
                    seen.add(nid);
                    next = next.add(neighbor);
                });
            });

            if (next.length === 0) {
                break;
            }

            levels.push(next);
            frontier = next;
        }

        return levels;
    }

    function runWave(startNode, direction) {
        if (!cy || !startNode) {
            return;
        }

        const levels = collectWaveLevels(startNode, direction);
        if (levels.length === 0) {
            setStatus(`No ${direction} found for ${startNode.id()}.`, "warn");
            return;
        }

        const className = direction === "children" ? "wave-child" : "wave-parent";
        setStatus(`Running ${direction} wave from ${startNode.id()}...`, "ok");

        levels.forEach((group, index) => {
            window.setTimeout(() => {
                group.addClass(className);
                window.setTimeout(() => group.removeClass(className), WAVE_GLOW_MS);
            }, index * WAVE_STEP_MS);
        });
    }

    function styleConfig() {
        return [
            {
                selector: "node",
                style: {
                    "background-color": "data(color)",
                    label: "data(id)",
                    color: "#f9fbff",
                    "font-size": "10px",
                    "font-weight": "700",
                    "text-wrap": "wrap",
                    "text-max-width": "120px",
                    "text-valign": "bottom",
                    "text-margin-y": "5px",
                    width: "38px",
                    height: "38px",
                    "border-width": "2px",
                    "border-color": "#20242f",
                    "text-outline-color": "#05070c",
                    "text-outline-width": "2px",
                    "shadow-color": "#000",
                    "shadow-opacity": 0.22,
                    "shadow-blur": 5,
                },
            },
            {
                selector: "node:selected",
                style: {
                    "border-width": "4px",
                    "border-color": "#ffffff",
                    "background-color": "#e64a6f",
                },
            },
            {
                selector: "node.wave-child",
                style: {
                    "background-color": "#ff62b2",
                    "border-color": "#ffd8eb",
                    "border-width": "5px",
                    "shadow-color": "#ff62b2",
                    "shadow-opacity": 0.9,
                    "shadow-blur": 26,
                },
            },
            {
                selector: "node.wave-parent",
                style: {
                    "background-color": "#2edbff",
                    "border-color": "#d1f7ff",
                    "border-width": "5px",
                    "shadow-color": "#2edbff",
                    "shadow-opacity": 0.9,
                    "shadow-blur": 26,
                },
            },
            {
                selector: "node[is_external]",
                style: {
                    "border-style": "dashed",
                    "border-color": "#f0d79d",
                    "background-opacity": 0.78,
                },
            },
            {
                selector: "edge",
                style: {
                    width: 2,
                    "line-color": "#6f7a92",
                    "curve-style": "bezier",
                    "target-arrow-shape": "triangle",
                    "target-arrow-color": "#6f7a92",
                    "target-arrow-fill": "filled",
                    "arrow-scale": 1.4,
                    "target-distance-from-node": 6,
                },
            },
            {
                selector: "edge[is_external]",
                style: {
                    "line-style": "dashed",
                    "line-color": "#c1a967",
                    "target-arrow-color": "#c1a967",
                },
            },
            {
                selector: "edge[is_external_bridge]",
                style: {
                    width: 3,
                    "line-style": "dotted",
                    "line-color": "#f7c948",
                    "target-arrow-color": "#f7c948",
                },
            },
            {
                selector: 'edge[relationship_type = "content_parent_of"]',
                style: {
                    width: 3,
                    "line-style": "dashed",
                    "line-color": "#34d399",
                    "target-arrow-color": "#34d399",
                },
            },
            {
                selector: 'edge[relationship_type = "container_parent_of"]',
                style: {
                    width: 3,
                    "line-style": "dotted",
                    "line-color": "#60a5fa",
                    "target-arrow-color": "#60a5fa",
                },
            },
            {
                selector: "edge:selected",
                style: {
                    width: 3,
                    "line-color": "#ffc46f",
                    "target-arrow-color": "#ffc46f",
                },
            },
        ];
    }

    function selectedLayoutName() {
        const select = byId("graph-layout");
        return select ? select.value : "dagre";
    }

    function applyLayout() {
        if (!cy) {
            return;
        }

        const name = selectedLayoutName();
        const options = {
            dagre: { name: "dagre", rankDir: "BT", nodeSep: 45, rankSep: 80 },
            cose: { name: "cose", animate: true, animationDuration: 500 },
            breadthfirst: { name: "breadthfirst", directed: true, spacingFactor: 1.5 },
            circle: { name: "circle" },
            grid: { name: "grid" },
        };

        cy.layout(options[name] || { name }).run();
    }

    function renderNoData(message) {
        const container = byId("graph-canvas");
        if (!container) {
            return;
        }

        container.innerHTML = `<div class=\"graph-loading\">${escapeHtml(message)}</div>`;
        updateLegend([]);
    }

    function centerGraphNode(nodeId) {
        if (!cy) {
            return;
        }
        const node = cy.getElementById(nodeId);
        if (!node || node.length === 0) {
            return;
        }
        cy.animate({ center: { eles: node }, zoom: Math.max(cy.zoom(), 1.45) }, { duration: 300 });
        node.select();
    }

    async function mergeExternalRef(sourceEuid, refIndex) {
        if (!cy) {
            setStatus("Load a graph before merging an external reference.", "warn");
            return;
        }

        try {
            const response = await fetch(buildExternalGraphUrl(sourceEuid, refIndex), {
                headers: { Accept: "application/json" },
                credentials: "same-origin",
            });
            const payload = await response.json();
            if (!response.ok) {
                throw new Error(payload.detail || `Failed to merge external graph (${response.status})`);
            }

            const elements = payload.elements || {};
            const nodes = Array.isArray(elements.nodes) ? elements.nodes : [];
            const edges = Array.isArray(elements.edges) ? elements.edges : [];
            const existingIds = new Set(cy.elements().map((ele) => ele.id()));
            const additions = [];

            [...nodes, ...edges].forEach((element) => {
                const id = element && element.data ? element.data.id : null;
                if (!id || existingIds.has(id)) {
                    return;
                }
                additions.push(element);
                existingIds.add(id);
            });

            if (additions.length === 0) {
                setStatus("External graph already merged.", "warn");
                return;
            }

            cy.add(additions);
            applyLayout();
            updateLegend(cy.nodes().map((node) => ({ data: node.data() })));
            setStatus(`Merged external graph for ${sourceEuid}.`, "ok");
        } catch (error) {
            setStatus(`External merge failed: ${error.message}`, "error");
        }
    }

    function initGraph(elements) {
        const container = byId("graph-canvas");
        if (!container) {
            return;
        }

        container.innerHTML = "";
        if (cy) {
            cy.destroy();
            cy = null;
        }

        cy = window.cytoscape({
            container,
            elements,
            style: styleConfig(),
            layout: { name: "dagre", rankDir: "BT", nodeSep: 45, rankSep: 80 },
            minZoom: 0.1,
            maxZoom: 3,
            wheelSensitivity: 0.28,
        });

        cy.on("tap", "node", async (event) => {
            const node = event.target;
            await showElementDetail(node.data());
            if (node.data("is_external")) {
                return;
            }
            if (registerTapSequence(node.id(), "left")) {
                runWave(node, "children");
            }
        });

        cy.on("cxttap", "node", async (event) => {
            const node = event.target;
            await showElementDetail(node.data());
            if (registerTapSequence(node.id(), "right")) {
                runWave(node, "parents");
            }
        });

        cy.on("tap", "edge", async (event) => {
            await showElementDetail(event.target.data());
        });

        cy.on("cxttap", "edge", async (event) => {
            await showElementDetail(event.target.data());
        });

        applyLayout();
    }

    async function loadGraph() {
        renderNoData("Loading graph data...");

        try {
            const response = await fetch(buildGraphRequestUrl(), {
                headers: { Accept: "application/json" },
                credentials: "same-origin",
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.detail || `Failed to load graph data (${response.status})`);
            }

            const elements = data.elements || { nodes: [], edges: [] };
            const nodes = Array.isArray(elements.nodes) ? elements.nodes : [];
            const edges = Array.isArray(elements.edges) ? elements.edges : [];

            if (nodes.length === 0) {
                renderNoData("No visible graph data for this scope.");
                setStatus("No graph data found.", "warn");
                updateHistoryState();
                return;
            }

            initGraph({ nodes, edges });
            updateLegend(nodes);
            updateHistoryState();
            if (pendingAutoMergeRef !== null && currentStartEuid()) {
                const mergeRef = pendingAutoMergeRef;
                pendingAutoMergeRef = null;
                await mergeExternalRef(currentStartEuid(), mergeRef);
            }

            const meta = data.meta || {};
            if (meta.truncated) {
                setStatus(
                    `Loaded ${meta.node_count || nodes.length} nodes and ` +
                        `${meta.edge_count || edges.length} edges (truncated).`,
                    "warn"
                );
            } else {
                setStatus(
                    `Loaded ${meta.node_count || nodes.length} nodes and ` +
                        `${meta.edge_count || edges.length} edges.`,
                    "ok"
                );
            }
        } catch (error) {
            renderNoData(`Error: ${error.message}`);
            setStatus(`Load failed: ${error.message}`, "error");
        }
    }

    function fitView() {
        if (!cy) {
            return;
        }
        cy.fit(undefined, 40);
        setStatus("Fit view applied.", "ok");
    }

    function installHandlers() {
        const loadBtn = byId("graph-load");
        const fitBtn = byId("graph-fit");
        const layout = byId("graph-layout");
        const projection = byId("graph-projection");
        const startInput = byId("graph-start-euid");
        const depthInput = byId("graph-depth");
        const tenantInput = byId("graph-tenant-id");

        if (loadBtn) {
            loadBtn.addEventListener("click", () => {
                void loadGraph();
            });
        }
        if (fitBtn) {
            fitBtn.addEventListener("click", fitView);
        }
        if (layout) {
            layout.addEventListener("change", applyLayout);
        }
        if (projection) {
            projection.addEventListener("change", () => {
                void loadGraph();
            });
        }

        [startInput, depthInput, tenantInput].forEach((input) => {
            if (!input) {
                return;
            }
            input.addEventListener("keydown", (event) => {
                if (event.key !== "Enter") {
                    return;
                }
                event.preventDefault();
                void loadGraph();
            });
        });
    }

    function bootstrapDefaults() {
        const startInput = byId("graph-start-euid");
        const depthInput = byId("graph-depth");
        const tenantInput = byId("graph-tenant-id");
        const projection = byId("graph-projection");

        if (startInput && config.defaultStartEuid && !startInput.value) {
            startInput.value = config.defaultStartEuid;
        }
        if (depthInput && config.defaultDepth && !depthInput.value) {
            depthInput.value = String(config.defaultDepth);
        }
        if (tenantInput && config.defaultTenantId && !tenantInput.value) {
            tenantInput.value = config.defaultTenantId;
        }
        if (projection && config.defaultProjection && !projection.value) {
            projection.value = config.defaultProjection;
        }
    }

    document.addEventListener("DOMContentLoaded", () => {
        if (!window.cytoscape) {
            setStatus("Cytoscape failed to load.", "error");
            return;
        }

        if (window.cytoscapeDagre && typeof window.cytoscape.use === "function") {
            window.cytoscape.use(window.cytoscapeDagre);
        }

        bootstrapDefaults();
        installHandlers();
        window.mergeExternalRef = mergeExternalRef;
        window.centerGraphNode = centerGraphNode;
        void loadGraph();
    });
})();
