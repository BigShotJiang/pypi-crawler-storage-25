# LSMC logo web resources

Extracted from the provided brand study images as raster PNG assets.

## Included files

### Transparent
- `assets/lsmc-logo-black-transparent.png`
- `assets/lsmc-logo-white-transparent.png`

### Example backgrounds
- `assets/lsmc-logo-black-on-white.png`
- `assets/lsmc-logo-white-on-black.png`
- `assets/lsmc-logo-almond-on-black.png`
- `assets/lsmc-logo-gold-on-black.png`
- `assets/lsmc-logo-silver-on-black.png`

## Notes
- All exported assets are 512×512 PNG.
- Transparent exports are raster, not vector.
- If you want SVG, the cleanest path is the original vector source, not traced PNGs.

## Suggested usage

```html
<img src="assets/lsmc-logo-black-transparent.png" alt="LSMC logo" width="128" height="128">
```

```css
.logo {
  width: 128px;
  height: 128px;
  object-fit: contain;
}
```
