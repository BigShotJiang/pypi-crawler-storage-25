"""LSMC Atlas - Jinja2 Templates Configuration.

Centralized templates object for all web routes.
Includes custom Jinja2 filters for formatting.
"""

from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo

try:
    from daylily_tapdb.timezone_utils import (
        DEFAULT_DISPLAY_TIMEZONE,
        normalize_display_timezone,
    )
except Exception:
    DEFAULT_DISPLAY_TIMEZONE = "UTC"

    def normalize_display_timezone(value: str | None, default: str = "UTC") -> str:
        candidate = str(value or "").strip()
        if not candidate:
            return default
        if candidate.upper() in {"UTC", "GMT", "GMT+00:00", "Z"}:
            return "UTC"
        try:
            return ZoneInfo(candidate).key
        except Exception:
            return default


from fastapi.templating import Jinja2Templates

templates = Jinja2Templates(directory="app/web/templates")


def format_datetime(
    dt: datetime | None,
    format_type: str = "standard",
    display_timezone: str = DEFAULT_DISPLAY_TIMEZONE,
) -> str:
    """Format datetime based on user preference.

    Args:
        dt: Datetime to format
        format_type: "standard" (no microseconds) or "precise" (with microseconds)

    Returns:
        Formatted datetime string, or empty string if dt is None
    """
    if dt is None:
        return ""

    dt = dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)

    normalized_display_timezone = normalize_display_timezone(
        display_timezone,
        default=DEFAULT_DISPLAY_TIMEZONE,
    )
    try:
        dt = dt.astimezone(ZoneInfo(normalized_display_timezone))
    except Exception:
        dt = dt.astimezone(UTC)

    # Get timezone abbreviation
    tz_abbr = ""
    if dt.tzinfo:
        try:
            tz_abbr = dt.strftime(" %Z").strip()
            # If strftime returns offset instead of name, use the offset
            if not tz_abbr or tz_abbr.startswith(("+", "-")):
                tz_abbr = dt.strftime(" %z")  # e.g., "-0800"
        except Exception:
            tz_abbr = ""

    if format_type == "precise":
        # YYYY-MM-DD HH:MM:SS.ffffff TZ
        return dt.strftime("%Y-%m-%d %H:%M:%S.%f") + tz_abbr
    else:
        # YYYY-MM-DD HH:MM:SS TZ (standard - default)
        return dt.strftime("%Y-%m-%d %H:%M:%S") + tz_abbr


def datetime_filter(dt: Any, user_prefs: dict | None = None) -> str:
    """Jinja2 filter for formatting datetimes based on user preferences.

    Usage in templates:
        {{ created_at | format_dt(user_preferences) }}

    Args:
        dt: Datetime value to format
        user_prefs: User preferences dict (may contain 'datetime_format')

    Returns:
        Formatted datetime string
    """
    if dt is None:
        return ""

    # Handle string datetimes (parse them first)
    if isinstance(dt, str):
        try:
            from dateutil import parser

            dt = parser.parse(dt)
        except Exception:
            return dt  # Return as-is if can't parse

    if not isinstance(dt, datetime):
        return str(dt)

    format_type = "standard"
    display_timezone = DEFAULT_DISPLAY_TIMEZONE
    if user_prefs and isinstance(user_prefs, dict):
        format_type = user_prefs.get("datetime_format", "standard")
        display_timezone = user_prefs.get("display_timezone", DEFAULT_DISPLAY_TIMEZONE)

    return format_datetime(dt, format_type, display_timezone)


# Register custom filters
templates.env.filters["format_dt"] = datetime_filter
