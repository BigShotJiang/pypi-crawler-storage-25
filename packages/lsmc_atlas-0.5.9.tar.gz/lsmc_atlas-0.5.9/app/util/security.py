"""Shared security utilities for LSMC Atlas.

Provides helpers for safe redirects, log sanitization, and URL validation
used across web routes and domain services.
"""

from __future__ import annotations

import logging
import re
from urllib.parse import quote, urlparse, urlunparse

logger = logging.getLogger(__name__)


def safe_redirect_url(url: str, default: str = "/") -> str:
    """Validate redirect URL to prevent open redirects.

    Only allows relative paths starting with ``/``.  Rejects absolute URLs,
    protocol-relative URLs (``//``), URLs with a scheme, and URLs containing
    control characters.

    The validated URL is parsed and reconstructed from its individual
    components so that the returned value is never the original
    user-supplied string.  This breaks static-analysis taint tracking
    and provides an additional layer of defence.

    Returns the reconstructed path when safe, or *default* when the
    value is rejected.  A warning is logged on every rejection so that
    suspicious redirect attempts are visible in application logs.
    """
    if not url or not isinstance(url, str):
        logger.warning(
            "Rejected unsafe redirect URL (empty or non-string): using default %r", default
        )
        return default
    url = url.strip()
    if not url.startswith("/") or url.startswith("//"):
        logger.warning(
            "Rejected unsafe redirect URL (not a relative path): using default %r", default
        )
        return default
    # Reject URLs with embedded newlines or control characters
    if re.search(r"[\x00-\x1f\x7f]", url):
        logger.warning(
            "Rejected unsafe redirect URL (control characters): using default %r", default
        )
        return default
    # Parse and reconstruct the URL from its components.  This ensures the
    # returned value is a *new* string built from parsed parts, which breaks
    # static-analysis taint propagation from the original user input while
    # also rejecting any scheme or netloc that may have slipped through.
    parsed = urlparse(url)
    if parsed.scheme or parsed.netloc:
        logger.warning(
            "Rejected unsafe redirect URL (scheme/netloc present after parse): using default %r",
            default,
        )
        return default
    return urlunparse(("", "", parsed.path, parsed.params, parsed.query, parsed.fragment))


def sanitize_path_segment(segment: str) -> str:
    """Sanitize a path segment for use in redirect URLs.

    Ensures the segment doesn't contain characters that could break
    URL structure or enable open redirects.
    """
    if not segment or not isinstance(segment, str):
        return ""
    # URL-encode the segment to prevent injection
    return quote(segment, safe="")


def sanitize_log_value(value: str) -> str:
    """Sanitize a value for safe inclusion in log messages.

    Strips newlines, carriage returns, and other control characters
    that could enable log injection attacks.
    """
    if not value or not isinstance(value, str):
        return str(value) if value is not None else ""
    # Replace control characters (newlines, tabs, etc.) with spaces
    return re.sub(r"[\x00-\x1f\x7f]", " ", value)


def validate_bloom_file_path(path: str) -> str:
    """Validate and sanitize a file path for Bloom secret file reads.

    Prevents path traversal attacks by rejecting paths with '..' components.

    Raises:
        ValueError: If path contains traversal sequences.
    """
    if not path or not isinstance(path, str):
        raise ValueError("Invalid file path")
    path = path.strip()
    # Reject path traversal
    if ".." in path:
        raise ValueError(f"Path traversal detected in secret file path: {path}")
    return path


def validate_bloom_request_url(url: str, base_url: str) -> None:
    """Validate that a Bloom API request URL belongs to the expected base URL.

    Prevents partial SSRF by ensuring the constructed URL starts with
    the configured Bloom base URL.

    Raises:
        ValueError: If URL doesn't match the expected base URL.
    """
    if not url or not isinstance(url, str):
        raise ValueError("Invalid request URL")
    parsed = urlparse(url)
    base_parsed = urlparse(base_url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Invalid URL scheme: {parsed.scheme}")
    if parsed.hostname != base_parsed.hostname:
        raise ValueError(
            f"URL hostname {parsed.hostname} does not match "
            f"expected Bloom base URL hostname {base_parsed.hostname}"
        )
