"""TapDB-backed repository adapter for Atlas audit events."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

AUDIT_TEMPLATE_CODE = "atlas/events/audit-event/1.0/"
AUDIT_PREFIX = "ADT"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbAuditEventRecord:
    euid: str
    tenant_id: uuid.UUID | None
    user_id: uuid.UUID | None
    action: str
    entity_type: str | None
    entity_id: str | None
    details: dict | None
    ip_address: str | None
    user_agent: str | None
    created_at: datetime | None


class TapdbAuditRepository:
    """Audit event persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_event(
        self,
        tenant_id: uuid.UUID | None,
        user_id: uuid.UUID | None,
        action: str,
        entity_type: str | None,
        entity_id: str | None,
        details: dict | None,
        ip_address: str | None,
        user_agent: str | None,
    ) -> TapdbAuditEventRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        properties = {
            "tenant_id": str(tenant_id) if tenant_id else None,
            "user_id": str(user_id) if user_id else None,
            "action": action,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "details": details,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "created_at": now.isoformat(),
        }

        instance = self.factory.create_instance(
            session=self.db,
            template_code=AUDIT_TEMPLATE_CODE,
            name=action,
            properties=properties,
        )
        self.db.commit()
        return self._to_record(instance)

    def list_events(
        self,
        tenant_id: uuid.UUID | None,
        action: str | None = None,
        entity_type: str | None = None,
        entity_id: str | None = None,
        user_id: uuid.UUID | None = None,
        date_from: datetime | None = None,
        date_to: datetime | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> list[TapdbAuditEventRecord]:
        tenant_key = str(tenant_id) if tenant_id else None
        entity_key = entity_id
        user_key = str(user_id) if user_id else None

        rows: list[TapdbAuditEventRecord] = []
        for instance in self._instances_for_template(AUDIT_TEMPLATE_CODE):
            record = self._to_record(instance)
            if tenant_key and str(record.tenant_id) != tenant_key:
                continue
            if action and record.action != action:
                continue
            if entity_type and record.entity_type != entity_type:
                continue
            if entity_key and record.entity_id != entity_key:
                continue
            if user_key and str(record.user_id) != user_key:
                continue
            if date_from and record.created_at and record.created_at < date_from:
                continue
            if date_to and record.created_at and record.created_at > date_to:
                continue
            rows.append(record)

        rows.sort(key=lambda r: r.created_at or datetime.min.replace(tzinfo=UTC), reverse=True)
        return rows[skip : skip + limit]

    def count_events(
        self,
        tenant_id: uuid.UUID | None,
        action: str | None = None,
        entity_type: str | None = None,
        entity_id: str | None = None,
        user_id: uuid.UUID | None = None,
        date_from: datetime | None = None,
        date_to: datetime | None = None,
    ) -> int:
        return len(
            self.list_events(
                tenant_id=tenant_id,
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                user_id=user_id,
                date_from=date_from,
                date_to=date_to,
                skip=0,
                limit=1_000_000,
            )
        )

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            AUDIT_TEMPLATE_CODE,
            AUDIT_PREFIX,
            "Atlas Audit Event",
            {"managed_by": "lsmc-atlas", "domain": "audit"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        del name, json_addl
        from daylily_tapdb import require_seeded_template

        require_seeded_template(
            self.db,
            template_code,
            expected_prefix=instance_prefix,
            app_name="Atlas",
        )

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _to_record(self, instance: generic_instance) -> TapdbAuditEventRecord:
        props = self._instance_properties(instance)
        return TapdbAuditEventRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")),
            user_id=_parse_uuid(props.get("user_id")),
            action=str(props.get("action") or ""),
            entity_type=props.get("entity_type"),
            entity_id=props.get("entity_id"),
            details=props.get("details"),
            ip_address=props.get("ip_address"),
            user_agent=props.get("user_agent"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
        )
