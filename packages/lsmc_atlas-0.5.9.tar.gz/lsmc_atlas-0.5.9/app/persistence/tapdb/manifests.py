"""TapDB-backed repository adapter for Atlas manifest metadata."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

MANIFEST_TEMPLATE_CODE = "atlas/logistics/manifest/1.0/"
MANIFEST_REV_TEMPLATE_CODE = "atlas/logistics/manifest-revision/1.0/"

MANIFEST_PREFIX = "MAN"
MANIFEST_REV_PREFIX = "MAR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbManifestRecord:
    euid: str
    tenant_id: uuid.UUID
    manifest_number: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbManifestRevisionRecord:
    euid: str
    manifest_id: str
    revision_no: int
    items: list[dict] | None
    shipment_id: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


class TapdbManifestRepository:
    """Manifest persistence backed by TapDB templates and instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def generate_next_manifest_number(self) -> str:
        max_num = 0
        for instance in self._instances_for_template(MANIFEST_TEMPLATE_CODE):
            manifest = self._to_manifest(instance)
            match = re.fullmatch(r"MAN-(\d+)", manifest.manifest_number)
            if not match:
                continue
            max_num = max(max_num, int(match.group(1)))
        return f"MAN-{max_num + 1}"

    def create_manifest(
        self,
        tenant_id: uuid.UUID,
        manifest_number: str,
        items: list[dict],
        shipment_id: str | None,
        created_by: uuid.UUID | None,
        note: str | None,
    ) -> tuple[TapdbManifestRecord, TapdbManifestRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)

        manifest_instance = self.factory.create_instance(
            session=self.db,
            template_code=MANIFEST_TEMPLATE_CODE,
            name=manifest_number,
            properties={
                "tenant_id": str(tenant_id),
                "manifest_number": manifest_number,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=MANIFEST_REV_TEMPLATE_CODE,
            name=f"{manifest_number}-rev-1",
            properties={
                "manifest_id": manifest_instance.euid,
                "revision_no": 1,
                "items": items,
                "shipment_id": shipment_id if shipment_id else None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )

        self.factory.link_instances(
            session=self.db,
            parent=manifest_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()

        return self._to_manifest(manifest_instance), self._to_manifest_revision(revision_instance)

    def get_manifest_with_revision(
        self,
        manifest_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbManifestRecord, TapdbManifestRevisionRecord] | None:
        manifest = self._get_manifest_by_id(manifest_id, tenant_id)
        if manifest is None:
            return None
        revision = self.get_latest_manifest_revision(manifest_id)
        if revision is None:
            return None
        return manifest, revision

    def get_manifest_by_number(
        self,
        manifest_number: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbManifestRecord, TapdbManifestRevisionRecord] | None:
        tenant_key = str(tenant_id) if tenant_id else None
        for instance in self._instances_for_template(MANIFEST_TEMPLATE_CODE):
            manifest = self._to_manifest(instance)
            if tenant_key and str(manifest.tenant_id) != tenant_key:
                continue
            if manifest.manifest_number != manifest_number:
                continue
            revision = self.get_latest_manifest_revision(manifest.euid)
            if revision is None:
                return None
            return manifest, revision
        return None

    def list_manifests(
        self,
        tenant_id: uuid.UUID | None,
        skip: int = 0,
        limit: int = 50,
    ) -> list[tuple[TapdbManifestRecord, TapdbManifestRevisionRecord]]:
        tenant_key = str(tenant_id) if tenant_id else None
        rows: list[tuple[TapdbManifestRecord, TapdbManifestRevisionRecord]] = []

        for instance in self._instances_for_template(MANIFEST_TEMPLATE_CODE):
            manifest = self._to_manifest(instance)
            if tenant_key and str(manifest.tenant_id) != tenant_key:
                continue
            revision = self.get_latest_manifest_revision(manifest.euid)
            if revision is None:
                continue
            rows.append((manifest, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def get_latest_manifest_revision(
        self,
        manifest_id: str,
    ) -> TapdbManifestRevisionRecord | None:
        manifest_instance = self._resolve_manifest_instance(manifest_id)
        if manifest_instance is None:
            return None
        children = get_child_instances(self.db, manifest_instance, MANIFEST_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_manifest_revision(child) for child in children]
        revisions.sort(key=lambda revision: revision.revision_no, reverse=True)
        return revisions[0]

    def _get_manifest_by_id(
        self,
        manifest_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbManifestRecord | None:
        instance = self._resolve_manifest_instance(manifest_id)
        if instance is None or instance.is_deleted:
            return None
        if not self._matches_template(instance, MANIFEST_TEMPLATE_CODE):
            return None
        manifest = self._to_manifest(instance)
        if tenant_id and str(manifest.tenant_id) != str(tenant_id):
            return None
        return manifest

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            MANIFEST_TEMPLATE_CODE,
            MANIFEST_PREFIX,
            "Atlas Manifest",
            {"managed_by": "lsmc-atlas", "domain": "manifests"},
        )
        self._ensure_template(
            MANIFEST_REV_TEMPLATE_CODE,
            MANIFEST_REV_PREFIX,
            "Atlas Manifest Revision",
            {"managed_by": "lsmc-atlas", "domain": "manifests"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        del name, json_addl
        from daylily_tapdb import require_seeded_template

        require_seeded_template(
            self.db,
            template_code,
            expected_prefix=instance_prefix,
            app_name="Atlas",
        )

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    @staticmethod
    def _instance_properties(instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    @staticmethod
    def _matches_template(instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_manifest(self, instance: generic_instance) -> TapdbManifestRecord:
        props = self._instance_properties(instance)
        return TapdbManifestRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            manifest_number=str(props.get("manifest_number") or instance.name),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_manifest_revision(self, instance: generic_instance) -> TapdbManifestRevisionRecord:
        props = self._instance_properties(instance)
        items = props.get("items")
        return TapdbManifestRevisionRecord(
            euid=instance.euid,
            manifest_id=str(props.get("manifest_id") or ""),
            revision_no=int(props.get("revision_no") or 1),
            items=items if isinstance(items, list) else None,
            shipment_id=props.get("shipment_id"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _resolve_manifest_instance(self, manifest_id: str | uuid.UUID) -> generic_instance | None:
        return get_instance_by_euid(self.db, MANIFEST_TEMPLATE_CODE, str(manifest_id))
