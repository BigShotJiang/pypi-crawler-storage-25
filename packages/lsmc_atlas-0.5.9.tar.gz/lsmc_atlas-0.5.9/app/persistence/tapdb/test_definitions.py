"""TapDB-backed repository adapter for Atlas assay catalog."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.persistence.tapdb.euid_helpers import get_instance_by_euid

TEST_DEFINITION_TEMPLATE_CODE = "atlas/ordering/test-definition/1.0/"
ASSAY_INSTANCE_PREFIX = "ASY"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


@dataclass(frozen=True)
class TapdbTestDefinitionRecord:
    """Contract-compatible assay ref object."""

    euid: str
    code: str
    name: str
    description: str | None
    category: str | None
    technology: str | None
    specimen_types: list[str] | None
    is_active: bool
    created_at: datetime | None


class TapdbTestDefinitionRepository:
    """Assay catalog persistence using TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._template_ready = False

    def create(self, data: Any) -> TapdbTestDefinitionRecord:
        self._ensure_template()
        props = {
            "code": data.code,
            "name": data.name,
            "description": data.description,
            "category": data.category,
            "technology": data.technology,
            "specimen_types": data.specimen_types,
            "is_active": True,
        }
        instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_DEFINITION_TEMPLATE_CODE,
            name=data.code,
            properties=props,
        )
        self.db.commit()
        return self._to_record(instance)

    def get_by_euid(self, assay_euid: str) -> TapdbTestDefinitionRecord | None:
        instance = get_instance_by_euid(self.db, TEST_DEFINITION_TEMPLATE_CODE, assay_euid)
        if instance is None or instance.is_deleted:
            return None
        return self._to_record(instance)

    def get_by_code(self, code: str) -> TapdbTestDefinitionRecord | None:
        normalized = code.strip().upper()
        for instance in self._list_instances():
            props = self._properties(instance)
            if str(props.get("code", "")).strip().upper() == normalized:
                return self._to_record(instance)
        return None

    def list_all(
        self,
        active_only: bool = True,
        category: str | None = None,
        technology: str | None = None,
    ) -> list[TapdbTestDefinitionRecord]:
        records: list[TapdbTestDefinitionRecord] = []
        for instance in self._list_instances():
            record = self._to_record(instance)
            if active_only and not record.is_active:
                continue
            if category and record.category != category:
                continue
            if technology and record.technology != technology:
                continue
            records.append(record)

        records.sort(key=lambda item: item.code)
        return records

    def update(self, assay_euid: str, data: Any) -> TapdbTestDefinitionRecord | None:
        instance = get_instance_by_euid(self.db, TEST_DEFINITION_TEMPLATE_CODE, assay_euid)
        if instance is None or instance.is_deleted:
            return None

        props = self._properties(instance)
        if data.name is not None:
            props["name"] = data.name
        if data.description is not None:
            props["description"] = data.description
        if data.category is not None:
            props["category"] = data.category
        if data.technology is not None:
            props["technology"] = data.technology
        if data.specimen_types is not None:
            props["specimen_types"] = data.specimen_types
        if data.is_active is not None:
            props["is_active"] = bool(data.is_active)

        self._write_properties(instance, props)
        self.db.commit()
        return self._to_record(instance)

    def deactivate(self, assay_euid: str) -> TapdbTestDefinitionRecord | None:
        class _Deactivate:
            name = None
            description = None
            category = None
            technology = None
            specimen_types = None
            is_active = False

        return self.update(assay_euid, _Deactivate())

    def get_categories(self) -> list[str]:
        return sorted(
            {
                record.category
                for record in self.list_all(active_only=False)
                if record.category and record.category.strip()
            }
        )

    def get_technologies(self) -> list[str]:
        return sorted(
            {
                record.technology
                for record in self.list_all(active_only=False)
                if record.technology and record.technology.strip()
            }
        )

    def _ensure_template(self) -> None:
        if self._template_ready:
            return
        from daylily_tapdb import require_seeded_template

        require_seeded_template(
            self.db,
            TEST_DEFINITION_TEMPLATE_CODE,
            expected_prefix=ASSAY_INSTANCE_PREFIX,
            app_name="Atlas",
        )
        self._template_ready = True

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _properties(self, instance: generic_instance) -> dict[str, Any]:
        json_addl = instance.json_addl or {}
        props = json_addl.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _write_properties(self, instance: generic_instance, props: dict[str, Any]) -> None:
        json_addl = dict(instance.json_addl or {})
        json_addl["properties"] = props
        instance.json_addl = json_addl
        flag_modified(instance, "json_addl")

    def _list_instances(self) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(TEST_DEFINITION_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _to_record(self, instance: generic_instance) -> TapdbTestDefinitionRecord:
        props = self._properties(instance)
        return TapdbTestDefinitionRecord(
            euid=instance.euid,
            code=str(props.get("code") or instance.name),
            name=str(props.get("name") or instance.name),
            description=props.get("description"),
            category=props.get("category"),
            technology=props.get("technology"),
            specimen_types=props.get("specimen_types"),
            is_active=bool(props.get("is_active", True)),
            created_at=instance.created_dt or datetime.min.replace(tzinfo=UTC),
        )
