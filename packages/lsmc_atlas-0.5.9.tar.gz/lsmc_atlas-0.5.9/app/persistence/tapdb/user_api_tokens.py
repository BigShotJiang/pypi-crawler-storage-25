"""TapDB-backed repository adapter for Atlas user API tokens."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

TOKEN_TEMPLATE_CODE = "atlas/auth/user-api-token/1.0/"
TOKEN_REV_TEMPLATE_CODE = "atlas/auth/user-api-token-revision/1.0/"
TOKEN_USAGE_TEMPLATE_CODE = "atlas/auth/user-api-token-usage/1.0/"

TOKEN_PREFIX = "TKN"
TOKEN_REV_PREFIX = "TKR"
TOKEN_USAGE_PREFIX = "TKG"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbUserAPITokenRecord:
    euid: str
    tenant_id: uuid.UUID
    user_id: str
    token_name: str
    token_prefix: str
    scope: str
    created_at: datetime | None


@dataclass
class TapdbUserAPITokenRevisionRecord:
    token_id: str
    revision_id: str
    revision_no: int
    token_hash: str
    status: str
    expires_at: datetime
    last_used_at: datetime | None
    revoked_at: datetime | None
    revoked_by: str | None
    revocation_reason: str | None
    note: str | None
    created_at: datetime | None
    created_by: str | None


@dataclass
class TapdbUserAPITokenUsageLogRecord:
    euid: str
    tenant_id: uuid.UUID
    token_id: str
    endpoint: str
    http_method: str
    response_status: int
    ip_address: str | None
    user_agent: str | None
    request_timestamp: datetime | None
    request_metadata: dict | None


class TapdbUserAPITokenRepository:
    """User API token persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_token(
        self,
        tenant_id: uuid.UUID,
        user_id: str,
        token_name: str,
        token_prefix: str,
        scope: str,
        token_hash: str,
        expires_at: datetime,
        created_by: str | None,
        note: str | None = None,
    ) -> tuple[TapdbUserAPITokenRecord, TapdbUserAPITokenRevisionRecord]:
        self._ensure_templates()
        token_props = {
            "tenant_id": str(tenant_id),
            "user_id": user_id,
            "token_name": token_name,
            "token_prefix": token_prefix,
            "scope": scope,
        }
        token_instance = self.factory.create_instance(
            session=self.db,
            template_code=TOKEN_TEMPLATE_CODE,
            name=token_name,
            properties=token_props,
        )
        token_euid = token_instance.euid
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TOKEN_REV_TEMPLATE_CODE,
            name=f"{token_name}-rev-1",
            properties={
                "token_id": token_euid,
                "revision_no": 1,
                "token_hash": token_hash,
                "status": "ACTIVE",
                "expires_at": expires_at.isoformat(),
                "last_used_at": None,
                "revoked_at": None,
                "revoked_by": None,
                "revocation_reason": None,
                "note": note,
                "created_by": created_by,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=token_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_token(token_instance), self._to_revision(revision_instance)

    def get_token(
        self, token_id: str, tenant_id: uuid.UUID | None = None
    ) -> tuple[TapdbUserAPITokenRecord, TapdbUserAPITokenRevisionRecord] | None:
        token_instance = get_instance_by_euid(self.db, TOKEN_TEMPLATE_CODE, token_id)
        if token_instance is None or token_instance.is_deleted:
            return None
        if not self._matches_template(token_instance, TOKEN_TEMPLATE_CODE):
            return None
        token = self._to_token(token_instance)
        if tenant_id is not None and str(token.tenant_id) != str(tenant_id):
            return None
        revision = self.get_latest_revision(token.euid)
        if revision is None:
            return None
        return token, revision

    def list_tokens(
        self,
        tenant_id: uuid.UUID | None,
        user_id: str | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> list[TapdbUserAPITokenRecord]:
        tenant_key = str(tenant_id) if tenant_id else None
        user_key = user_id
        records: list[TapdbUserAPITokenRecord] = []
        for instance in self._instances_for_template(TOKEN_TEMPLATE_CODE):
            token = self._to_token(instance)
            if tenant_key and str(token.tenant_id) != tenant_key:
                continue
            if user_key and token.user_id != user_key:
                continue
            records.append(token)
        records.sort(
            key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return records[skip : skip + limit]

    def get_latest_revision(self, token_id: str) -> TapdbUserAPITokenRevisionRecord | None:
        token_instance = get_instance_by_euid(self.db, TOKEN_TEMPLATE_CODE, token_id)
        if token_instance is None:
            return None
        children = get_child_instances(self.db, token_instance, TOKEN_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_revision(c) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    def create_revision(
        self,
        token_id: str,
        revision_no: int,
        token_hash: str,
        status: str,
        expires_at: datetime,
        last_used_at: datetime | None,
        revoked_at: datetime | None,
        revoked_by: str | None,
        revocation_reason: str | None,
        created_by: str | None,
        note: str | None,
    ) -> TapdbUserAPITokenRevisionRecord:
        self._ensure_templates()
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TOKEN_REV_TEMPLATE_CODE,
            name=f"token-{token_id}-rev-{revision_no}",
            properties={
                "token_id": token_id,
                "revision_no": revision_no,
                "token_hash": token_hash,
                "status": status,
                "expires_at": expires_at.isoformat(),
                "last_used_at": last_used_at.isoformat() if last_used_at else None,
                "revoked_at": revoked_at.isoformat() if revoked_at else None,
                "revoked_by": revoked_by,
                "revocation_reason": revocation_reason,
                "note": note,
                "created_by": created_by,
            },
        )
        token_instance = get_instance_by_euid(self.db, TOKEN_TEMPLATE_CODE, token_id)
        if token_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=token_instance,
                child=revision_instance,
                relationship_type="revision",
            )
        self.db.commit()
        return self._to_revision(revision_instance)

    def find_latest_revision_by_hash(
        self, token_hash: str
    ) -> TapdbUserAPITokenRevisionRecord | None:
        matches = [
            rev
            for rev in (
                self._to_revision(instance)
                for instance in self._instances_for_template(TOKEN_REV_TEMPLATE_CODE)
            )
            if rev.token_hash == token_hash
        ]
        if not matches:
            return None
        matches.sort(key=lambda rev: rev.revision_no, reverse=True)
        return matches[0]

    def log_usage(
        self,
        tenant_id: uuid.UUID,
        token_id: str,
        endpoint: str,
        http_method: str,
        response_status: int,
        ip_address: str | None = None,
        user_agent: str | None = None,
        request_metadata: dict | None = None,
    ) -> None:
        self._ensure_templates()
        usage_props = {
            "tenant_id": str(tenant_id),
            "token_id": token_id,
            "endpoint": endpoint,
            "http_method": http_method,
            "response_status": response_status,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "request_timestamp": datetime.now(UTC).isoformat(),
            "request_metadata": request_metadata,
        }
        usage_instance = self.factory.create_instance(
            session=self.db,
            template_code=TOKEN_USAGE_TEMPLATE_CODE,
            name=f"{http_method.upper()} {endpoint}",
            properties=usage_props,
        )
        token_instance = get_instance_by_euid(self.db, TOKEN_TEMPLATE_CODE, token_id)
        if token_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=token_instance,
                child=usage_instance,
                relationship_type="usage",
            )
        self.db.commit()

    def get_usage_logs(
        self, token_id: str, limit: int = 100
    ) -> list[TapdbUserAPITokenUsageLogRecord]:
        logs = [
            log
            for log in (
                self._to_usage_log(instance)
                for instance in self._instances_for_template(TOKEN_USAGE_TEMPLATE_CODE)
            )
            if log.token_id == token_id
        ]
        logs.sort(
            key=lambda row: row.request_timestamp or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return logs[:limit]

    def count_usage(self, token_id: str) -> int:
        return sum(
            1
            for instance in self._instances_for_template(TOKEN_USAGE_TEMPLATE_CODE)
            if self._to_usage_log(instance).token_id == token_id
        )

    def get_usage_stats(self, token_id: str) -> dict[str, Any]:
        logs = self.get_usage_logs(token_id, limit=100000)
        endpoints: dict[str, int] = {}
        statuses: dict[int, int] = {}
        for log in logs:
            endpoints[log.endpoint] = endpoints.get(log.endpoint, 0) + 1
            statuses[log.response_status] = statuses.get(log.response_status, 0) + 1
        return {
            "total_requests": len(logs),
            "endpoints": dict(sorted(endpoints.items(), key=lambda i: i[1], reverse=True)[:10]),
            "status_codes": statuses,
            "last_request_at": logs[0].request_timestamp if logs else None,
        }

    def count_tokens(self, tenant_id: uuid.UUID | None, user_id: str | None = None) -> int:
        return len(self.list_tokens(tenant_id=tenant_id, user_id=user_id, skip=0, limit=1000000))

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            TOKEN_TEMPLATE_CODE,
            TOKEN_PREFIX,
            "Atlas User API Token",
            {"managed_by": "lsmc-atlas", "domain": "user_api_tokens"},
        )
        self._ensure_template(
            TOKEN_REV_TEMPLATE_CODE,
            TOKEN_REV_PREFIX,
            "Atlas User API Token Revision",
            {"managed_by": "lsmc-atlas", "domain": "user_api_tokens"},
        )
        self._ensure_template(
            TOKEN_USAGE_TEMPLATE_CODE,
            TOKEN_USAGE_PREFIX,
            "Atlas User API Token Usage",
            {"managed_by": "lsmc-atlas", "domain": "user_api_tokens"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        del name, json_addl
        from daylily_tapdb import require_seeded_template

        require_seeded_template(
            self.db,
            template_code,
            expected_prefix=instance_prefix,
            app_name="Atlas",
        )

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_token(self, instance: generic_instance) -> TapdbUserAPITokenRecord:
        props = self._instance_properties(instance)
        return TapdbUserAPITokenRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            user_id=str(props.get("user_id") or ""),
            token_name=str(props.get("token_name") or instance.name),
            token_prefix=str(props.get("token_prefix") or ""),
            scope=str(props.get("scope") or "ext_org"),
            created_at=instance.created_dt,
        )

    def _to_revision(self, instance: generic_instance) -> TapdbUserAPITokenRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbUserAPITokenRevisionRecord(
            token_id=str(props.get("token_id") or ""),
            revision_id=instance.euid,
            revision_no=int(props.get("revision_no") or 1),
            token_hash=str(props.get("token_hash") or ""),
            status=str(props.get("status") or "ACTIVE"),
            expires_at=_to_dt(props.get("expires_at")) or datetime.now(UTC),
            last_used_at=_to_dt(props.get("last_used_at")),
            revoked_at=_to_dt(props.get("revoked_at")),
            revoked_by=props.get("revoked_by"),
            revocation_reason=props.get("revocation_reason"),
            note=props.get("note"),
            created_at=instance.created_dt,
            created_by=props.get("created_by"),
        )

    def _to_usage_log(self, instance: generic_instance) -> TapdbUserAPITokenUsageLogRecord:
        props = self._instance_properties(instance)
        return TapdbUserAPITokenUsageLogRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            token_id=str(props.get("token_id") or ""),
            endpoint=str(props.get("endpoint") or ""),
            http_method=str(props.get("http_method") or ""),
            response_status=int(props.get("response_status") or 0),
            ip_address=props.get("ip_address"),
            user_agent=props.get("user_agent"),
            request_timestamp=_to_dt(props.get("request_timestamp")) or instance.created_dt,
            request_metadata=props.get("request_metadata"),
        )
