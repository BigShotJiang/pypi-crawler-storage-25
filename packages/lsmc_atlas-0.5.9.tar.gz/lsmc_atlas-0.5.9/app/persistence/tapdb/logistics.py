"""TapDB-backed repository adapter for Atlas logistics domain."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.documents import DOCUMENT_TEMPLATE_CODE
from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid
from app.persistence.tapdb.external_objects import EXTERNAL_OBJECT_TEMPLATE_CODE
from app.persistence.tapdb.trfs import TEST_TEMPLATE_CODE, TRF_TEMPLATE_CODE

SHIPMENT_TEMPLATE_CODE = "atlas/logistics/shipment/1.0/"
SHIPMENT_REV_TEMPLATE_CODE = "atlas/logistics/shipment-revision/1.0/"
TEST_KIT_TEMPLATE_CODE = "atlas/logistics/test-kit/1.0/"
TEST_KIT_REV_TEMPLATE_CODE = "atlas/logistics/test-kit-revision/1.0/"

SHIPMENT_PREFIX = "SHP"
SHIPMENT_REV_PREFIX = "SHR"
TEST_KIT_PREFIX = "TKT"
TEST_KIT_REV_PREFIX = "TKR"

# Shipment/TestKit physical containment is represented as TapDB lineage edges:
# child=<contained item> -> parent=<container>, relationship_type="contained_in".
CONTAINMENT_RELATIONSHIP_TYPE = "contained_in"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbShipmentRecord:
    euid: str
    tenant_id: uuid.UUID
    shipment_number: str
    created_at: datetime | None
    created_by: uuid.UUID | None
    uid: int | None = None
    euid_seq: int | None = None


@dataclass
class TapdbShipmentRevisionRecord:
    euid: str
    shipment_id: str
    revision_no: int
    status: str
    carrier: str | None
    tracking_number: str | None
    origin_site_id: str | None
    origin_address: dict | None
    destination_address: dict | None
    shipped_at: datetime | None
    delivered_at: datetime | None
    received_at: datetime | None
    received_by: str | None
    package_condition: str | None
    temperature_requirement: str | None
    special_instructions: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


@dataclass
class TapdbTestKitRecord:
    euid: str
    tenant_id: uuid.UUID
    kit_barcode: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    uid: int | None = None
    euid_seq: int | None = None

    @property
    def display_label(self) -> str:
        return str(self.kit_barcode or self.euid)


@dataclass
class TapdbTestKitRevisionRecord:
    euid: str
    test_kit_id: str
    revision_no: int
    kit_type: str | None
    status: str
    origin_site_id: str | None
    expiration_date: datetime | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


class TapdbLogisticsRepository:
    """Shipment/TestKit persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def generate_next_shipment_number(self) -> str:
        max_num = 0
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            match = re.fullmatch(r"SHP-(\d+)", shipment.shipment_number or "")
            if not match:
                continue
            max_num = max(max_num, int(match.group(1)))
        return f"SHP-{max_num + 1}"

    def create_shipment(
        self,
        *,
        tenant_id: uuid.UUID,
        shipment_number: str,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)

        shipment_instance = self.factory.create_instance(
            session=self.db,
            template_code=SHIPMENT_TEMPLATE_CODE,
            name=shipment_number,
            properties={
                "tenant_id": str(tenant_id),
                "shipment_number": shipment_number,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        shipment_euid = shipment_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=SHIPMENT_REV_TEMPLATE_CODE,
            name=f"{shipment_number}-rev-1",
            properties={
                "shipment_id": shipment_euid,
                "revision_no": 1,
                "status": "DRAFT",
                "carrier": getattr(data, "carrier", None),
                "tracking_number": getattr(data, "tracking_number", None),
                "origin_site_id": getattr(data, "origin_site_id", None),
                "origin_address": getattr(data, "origin_address", None),
                "destination_address": getattr(data, "destination_address", None),
                "shipped_at": None,
                "delivered_at": None,
                "received_at": None,
                "received_by": None,
                "package_condition": None,
                "temperature_requirement": getattr(data, "temperature_requirement", None),
                "special_instructions": getattr(data, "special_instructions", None),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=shipment_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_shipment(shipment_instance), self._to_shipment_revision(revision_instance)

    def create_shipment_revision(
        self,
        *,
        shipment_id: str,
        status: str,
        carrier: str | None,
        tracking_number: str | None,
        origin_site_id: str | None,
        origin_address: dict | None,
        destination_address: dict | None,
        shipped_at: datetime | None,
        delivered_at: datetime | None,
        received_at: datetime | None,
        received_by: str | None,
        package_condition: str | None,
        temperature_requirement: str | None,
        special_instructions: str | None,
        note: str | None,
        created_by: uuid.UUID | None,
    ) -> TapdbShipmentRevisionRecord | None:
        shipment = self.get_shipment_by_id(shipment_id=shipment_id, tenant_id=None)
        if shipment is None:
            return None
        latest = self.get_latest_shipment_revision(shipment_id)
        if latest is None:
            return None
        shipment_instance = self._resolve_shipment_instance(shipment_id)
        if shipment_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=SHIPMENT_REV_TEMPLATE_CODE,
            name=f"{shipment.shipment_number}-rev-{latest.revision_no + 1}",
            properties={
                "shipment_id": shipment_id,
                "revision_no": latest.revision_no + 1,
                "status": status,
                "carrier": carrier,
                "tracking_number": tracking_number,
                "origin_site_id": origin_site_id,
                "origin_address": origin_address,
                "destination_address": destination_address,
                "shipped_at": shipped_at.isoformat() if shipped_at else None,
                "delivered_at": delivered_at.isoformat() if delivered_at else None,
                "received_at": received_at.isoformat() if received_at else None,
                "received_by": received_by,
                "package_condition": package_condition,
                "temperature_requirement": temperature_requirement,
                "special_instructions": special_instructions,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=shipment_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_shipment_revision(revision_instance)

    def get_shipment_by_id(
        self,
        *,
        shipment_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbShipmentRecord | None:
        instance = self._resolve_shipment_instance(shipment_id)
        if instance is None or instance.is_deleted:
            return None
        shipment = self._to_shipment(instance)
        if tenant_id is not None and shipment.tenant_id != tenant_id:
            return None
        return shipment

    def get_shipment_by_number(
        self,
        *,
        shipment_number: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord] | None:
        normalized = (shipment_number or "").strip()
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            if shipment.shipment_number != normalized:
                continue
            if tenant_id is not None and shipment.tenant_id != tenant_id:
                continue
            revision = self.get_latest_shipment_revision(shipment.euid)
            if revision is None:
                return None
            return shipment, revision
        return None

    def get_shipment_by_tracking_number(
        self,
        *,
        tracking_number: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbShipmentRecord | None:
        normalized = (tracking_number or "").strip()
        if not normalized:
            return None
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            if tenant_id is not None and shipment.tenant_id != tenant_id:
                continue
            revision = self.get_latest_shipment_revision(shipment.euid)
            if revision is None:
                continue
            if (revision.tracking_number or "") == normalized:
                return shipment
        return None

    def list_shipments(
        self,
        *,
        tenant_id: uuid.UUID | None,
        skip: int,
        limit: int,
    ) -> list[tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord | None]]:
        rows: list[tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord | None]] = []
        for instance in self._instances_for_template(SHIPMENT_TEMPLATE_CODE):
            shipment = self._to_shipment(instance)
            if tenant_id is not None and shipment.tenant_id != tenant_id:
                continue
            rows.append((shipment, self.get_latest_shipment_revision(shipment.euid)))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def get_latest_shipment_revision(
        self,
        shipment_id: str,
    ) -> TapdbShipmentRevisionRecord | None:
        shipment_instance = self._resolve_shipment_instance(shipment_id)
        if shipment_instance is None:
            return None
        children = get_child_instances(self.db, shipment_instance, SHIPMENT_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_shipment_revision(c) for c in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    def create_test_kit(
        self,
        *,
        tenant_id: uuid.UUID,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> TapdbTestKitRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        kit_barcode = str(getattr(data, "kit_barcode", "") or "").strip() or None

        test_kit_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_KIT_TEMPLATE_CODE,
            name=kit_barcode or "test-kit",
            properties={
                "tenant_id": str(tenant_id),
                "kit_barcode": kit_barcode,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        test_kit_euid = test_kit_instance.euid
        test_kit_instance.name = kit_barcode or test_kit_euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_KIT_REV_TEMPLATE_CODE,
            name=f"{test_kit_instance.name}-rev-1",
            properties={
                "test_kit_id": test_kit_euid,
                "revision_no": 1,
                "kit_type": getattr(data, "kit_type", None),
                "status": "CREATED",
                "origin_site_id": getattr(data, "origin_site_id", None),
                "expiration_date": (
                    data.expiration_date.isoformat()
                    if getattr(data, "expiration_date", None)
                    else None
                ),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_kit_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_test_kit(test_kit_instance)

    def create_test_kit_revision(
        self,
        *,
        test_kit_id: str,
        kit_type: str | None,
        status: str,
        origin_site_id: str | None,
        expiration_date: datetime | None,
        note: str | None,
        created_by: uuid.UUID | None,
    ) -> TapdbTestKitRevisionRecord | None:
        test_kit = self.get_test_kit_by_id(test_kit_id=test_kit_id, tenant_id=None)
        if test_kit is None:
            return None
        latest = self.get_latest_test_kit_revision(test_kit_id)
        if latest is None:
            return None
        test_kit_instance = self._resolve_test_kit_instance(test_kit_id)
        if test_kit_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=TEST_KIT_REV_TEMPLATE_CODE,
            name=f"{test_kit.display_label}-rev-{latest.revision_no + 1}",
            properties={
                "test_kit_id": test_kit_id,
                "revision_no": latest.revision_no + 1,
                "kit_type": kit_type,
                "status": status,
                "origin_site_id": origin_site_id,
                "expiration_date": expiration_date.isoformat() if expiration_date else None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_kit_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_test_kit_revision(revision_instance)

    def get_test_kit_by_id(
        self,
        *,
        test_kit_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbTestKitRecord | None:
        instance = self._resolve_test_kit_instance(test_kit_id)
        if instance is None or instance.is_deleted:
            return None
        test_kit = self._to_test_kit(instance)
        if tenant_id is not None and test_kit.tenant_id != tenant_id:
            return None
        return test_kit

    def get_test_kit_by_barcode(
        self,
        *,
        barcode: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbTestKitRecord | None:
        normalized = (barcode or "").strip()
        if not normalized:
            return None
        for instance in self._instances_for_template(TEST_KIT_TEMPLATE_CODE):
            test_kit = self._to_test_kit(instance)
            if test_kit.kit_barcode != normalized:
                continue
            if tenant_id is not None and test_kit.tenant_id != tenant_id:
                continue
            return test_kit
        return None

    def list_test_kits(
        self,
        *,
        tenant_id: uuid.UUID | None,
        skip: int,
        limit: int,
    ) -> list[TapdbTestKitRecord]:
        rows: list[TapdbTestKitRecord] = []
        for instance in self._instances_for_template(TEST_KIT_TEMPLATE_CODE):
            test_kit = self._to_test_kit(instance)
            if tenant_id is not None and test_kit.tenant_id != tenant_id:
                continue
            rows.append(test_kit)
        rows.sort(
            key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def get_latest_test_kit_revision(
        self,
        test_kit_id: str,
    ) -> TapdbTestKitRevisionRecord | None:
        test_kit_instance = self._resolve_test_kit_instance(test_kit_id)
        if test_kit_instance is None:
            return None
        children = get_child_instances(self.db, test_kit_instance, TEST_KIT_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_test_kit_revision(c) for c in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    # ---------------------------------------------------------------------
    # Containment (TapDB lineage)
    # ---------------------------------------------------------------------

    def add_item_to_shipment(
        self,
        *,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None,
        created_by: uuid.UUID | None,
    ) -> bool:
        """Add an item to a shipment via TapDB lineage (idempotent).

        Returns True if a new relationship was created or re-activated.
        """
        return self.add_item_to_container(
            container_type="Shipment",
            container_id=shipment_id,
            item_type=item_type,
            item_id=item_id,
            reason=reason,
            created_by=created_by,
        )

    def remove_item_from_shipment(
        self,
        *,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None,
        created_by: uuid.UUID | None,
    ) -> bool:
        """Remove an item from a shipment via TapDB lineage (idempotent).

        Returns True if an existing relationship was marked deleted.
        """
        return self.remove_item_from_container(
            container_type="Shipment",
            container_id=shipment_id,
            item_type=item_type,
            item_id=item_id,
            reason=reason,
            created_by=created_by,
        )

    def list_shipment_contents(self, shipment_id: str) -> list[dict[str, Any]]:
        """Return the current contents of a shipment (TapDB lineage)."""
        return self.list_container_contents(container_type="Shipment", container_id=shipment_id)

    def get_shipment_containment_tree(self, shipment_id: str) -> dict[str, Any]:
        """Return shipment -> test kit tree used by the shipment detail page."""
        tree = self.get_container_tree(container_type="Shipment", container_id=shipment_id)
        top_level_kits: list[dict[str, Any]] = []
        direct_specimens: list[dict[str, Any]] = []
        for child in tree.get("children", []):
            if child.get("type") == "TestKit":
                top_level_kits.append(self._legacy_testkit_node(child))
            elif child.get("type") == "ExternalObject":
                direct_specimens.append(child)
        return {"test_kits": top_level_kits, "direct_specimens": direct_specimens, "tree": tree}

    def list_test_kit_contents(self, test_kit_id: str) -> list[dict[str, Any]]:
        """Return the current contents of a test kit (children via TapDB lineage)."""
        return self.list_container_contents(container_type="TestKit", container_id=test_kit_id)

    def add_item_to_container(
        self,
        *,
        container_type: str,
        container_id: str,
        item_type: str,
        item_id: str,
        reason: str | None,
        created_by: uuid.UUID | None,
    ) -> bool:
        """Add an item to a Shipment or TestKit via TapDB lineage."""
        parent_instance = self._resolve_container_instance(container_type, container_id)
        if parent_instance is None:
            raise ValueError(f"{container_type} not found: {container_id}")
        child_instance = self._resolve_supported_item_instance(item_type, item_id)
        if child_instance is None:
            raise ValueError(f"{item_type} not found: {item_id}")

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == parent_instance.uid,
                generic_instance_lineage.child_instance_uid == child_instance.uid,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is not None and not existing.is_deleted:
            return False

        props: dict[str, Any] = {}
        if reason:
            props["reason"] = reason
        if created_by:
            props["created_by"] = str(created_by)

        if existing is not None:
            existing.is_deleted = False
            existing.json_addl = {"properties": props} if props else (existing.json_addl or None)
            self.db.flush()
            return True

        lineage = self.factory.link_instances(
            session=self.db,
            parent=parent_instance,
            child=child_instance,
            relationship_type=CONTAINMENT_RELATIONSHIP_TYPE,
        )
        if props:
            lineage.json_addl = {"properties": props}
        self.db.flush()
        return True

    def remove_item_from_container(
        self,
        *,
        container_type: str,
        container_id: str,
        item_type: str,
        item_id: str,
        reason: str | None,
        created_by: uuid.UUID | None,
    ) -> bool:
        """Remove an item from a Shipment or TestKit via TapDB lineage."""
        parent_instance = self._resolve_container_instance(container_type, container_id)
        if parent_instance is None:
            raise ValueError(f"{container_type} not found: {container_id}")
        child_instance = self._resolve_supported_item_instance(item_type, item_id)
        if child_instance is None:
            raise ValueError(f"{item_type} not found: {item_id}")

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == parent_instance.uid,
                generic_instance_lineage.child_instance_uid == child_instance.uid,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            return False

        props: dict[str, Any] = {}
        if reason:
            props["reason"] = reason
        if created_by:
            props["created_by"] = str(created_by)
        existing.is_deleted = True
        if props:
            existing.json_addl = {"properties": props}
        self.db.flush()
        return True

    def list_container_contents(
        self, *, container_type: str, container_id: str
    ) -> list[dict[str, Any]]:
        """Return current containment children for a Shipment or TestKit."""
        parent_instance = self._resolve_container_instance(container_type, container_id)
        if parent_instance is None:
            return []

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == parent_instance.uid,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt)
        )
        edges = list(self.db.execute(stmt).scalars().all())
        if not edges:
            return []

        child_uids = [edge.child_instance_uid for edge in edges]
        inst_stmt = select(generic_instance).where(generic_instance.uid.in_(child_uids))
        instances = list(self.db.execute(inst_stmt).scalars().all())
        instance_by_uid = {row.uid: row for row in instances}

        rows: list[dict[str, Any]] = []
        for edge in edges:
            inst = instance_by_uid.get(edge.child_instance_uid)
            if inst is None or inst.is_deleted:
                continue
            rows.append(
                {
                    "type": self._instance_type(inst),
                    "id": inst.euid,
                    "label": self._instance_label(inst),
                    "added_at": edge.created_dt.isoformat() if edge.created_dt else None,
                }
            )
        return rows

    def get_container_tree(self, *, container_type: str, container_id: str) -> dict[str, Any]:
        """Return a recursive containment tree for a Shipment or TestKit."""
        parent_instance = self._resolve_container_instance(container_type, container_id)
        if parent_instance is None:
            return {}
        return self._build_container_tree(parent_instance, seen={parent_instance.euid})

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(SHIPMENT_TEMPLATE_CODE, "Atlas Shipment", SHIPMENT_PREFIX)
        self._ensure_template(
            SHIPMENT_REV_TEMPLATE_CODE,
            "Atlas Shipment Revision",
            SHIPMENT_REV_PREFIX,
        )
        self._ensure_template(TEST_KIT_TEMPLATE_CODE, "Atlas Test Kit", TEST_KIT_PREFIX)
        self._ensure_template(
            TEST_KIT_REV_TEMPLATE_CODE,
            "Atlas Test Kit Revision",
            TEST_KIT_REV_PREFIX,
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(self, template_code: str, name: str, instance_prefix: str) -> None:
        del name
        from daylily_tapdb import require_seeded_template

        require_seeded_template(
            self.db,
            template_code,
            expected_prefix=instance_prefix,
            app_name="Atlas",
        )

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _to_shipment(self, instance: generic_instance) -> TapdbShipmentRecord:
        props = self._instance_properties(instance)
        return TapdbShipmentRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            shipment_number=str(props.get("shipment_number") or instance.name or ""),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            uid=int(instance.uid) if instance.uid is not None else None,
            euid_seq=int(instance.euid_seq) if instance.euid_seq is not None else None,
        )

    def _to_shipment_revision(self, instance: generic_instance) -> TapdbShipmentRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbShipmentRevisionRecord(
            euid=instance.euid,
            shipment_id=str(props.get("shipment_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            status=str(props.get("status") or "DRAFT"),
            carrier=props.get("carrier"),
            tracking_number=props.get("tracking_number"),
            origin_site_id=props.get("origin_site_id"),
            origin_address=props.get("origin_address")
            if isinstance(props.get("origin_address"), dict)
            else None,
            destination_address=props.get("destination_address")
            if isinstance(props.get("destination_address"), dict)
            else None,
            shipped_at=_to_dt(props.get("shipped_at")),
            delivered_at=_to_dt(props.get("delivered_at")),
            received_at=_to_dt(props.get("received_at")),
            received_by=props.get("received_by"),
            package_condition=props.get("package_condition"),
            temperature_requirement=props.get("temperature_requirement"),
            special_instructions=props.get("special_instructions"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_test_kit(self, instance: generic_instance) -> TapdbTestKitRecord:
        props = self._instance_properties(instance)
        kit_barcode = (
            str(props.get("kit_barcode")).strip() if props.get("kit_barcode") is not None else ""
        )
        return TapdbTestKitRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            kit_barcode=kit_barcode or None,
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            uid=int(instance.uid) if instance.uid is not None else None,
            euid_seq=int(instance.euid_seq) if instance.euid_seq is not None else None,
        )

    def _to_test_kit_revision(self, instance: generic_instance) -> TapdbTestKitRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbTestKitRevisionRecord(
            euid=instance.euid,
            test_kit_id=str(props.get("test_kit_id", "")),
            revision_no=int(props.get("revision_no") or 1),
            kit_type=props.get("kit_type"),
            status=str(props.get("status") or "CREATED"),
            origin_site_id=props.get("origin_site_id"),
            expiration_date=_to_dt(props.get("expiration_date")),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    # ------------------------------------------------------------------
    # EUID-first resolvers
    # ------------------------------------------------------------------

    def _resolve_shipment_instance(
        self,
        shipment_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve a shipment instance by EUID."""
        euid = str(shipment_id)
        return get_instance_by_euid(self.db, SHIPMENT_TEMPLATE_CODE, euid)

    def _resolve_test_kit_instance(
        self,
        test_kit_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve a test kit instance by EUID."""
        euid = str(test_kit_id)
        return get_instance_by_euid(self.db, TEST_KIT_TEMPLATE_CODE, euid)

    def _resolve_container_instance(
        self,
        container_type: str,
        container_id: str,
    ) -> generic_instance | None:
        if container_type == "Shipment":
            return self._resolve_shipment_instance(container_id)
        if container_type == "TestKit":
            return self._resolve_test_kit_instance(container_id)
        if container_type == "TRF":
            return get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, str(container_id))
        raise ValueError(f"Unsupported container_type: {container_type}")

    def _resolve_supported_item_instance(
        self,
        item_type: str,
        item_id: str,
    ) -> generic_instance | None:
        if item_type == "Shipment":
            return self._resolve_shipment_instance(item_id)
        if item_type == "TestKit":
            return self._resolve_test_kit_instance(item_id)
        if item_type == "Document":
            return get_instance_by_euid(self.db, DOCUMENT_TEMPLATE_CODE, str(item_id))
        if item_type == "ExternalObject":
            return get_instance_by_euid(self.db, EXTERNAL_OBJECT_TEMPLATE_CODE, str(item_id))
        if item_type == "TRF":
            return get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, str(item_id))
        if item_type == "Test":
            return get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, str(item_id))
        raise ValueError(f"Unsupported item_type: {item_type}")

    @staticmethod
    def _instance_type(instance: generic_instance) -> str:
        template_code = (
            f"{instance.category}/{instance.type}/{instance.subtype}/{instance.version}/"
        )
        if template_code == SHIPMENT_TEMPLATE_CODE:
            return "Shipment"
        if template_code == TEST_KIT_TEMPLATE_CODE:
            return "TestKit"
        if template_code == DOCUMENT_TEMPLATE_CODE:
            return "Document"
        if template_code == EXTERNAL_OBJECT_TEMPLATE_CODE:
            return "ExternalObject"
        if template_code == TRF_TEMPLATE_CODE:
            return "TRF"
        if template_code == TEST_TEMPLATE_CODE:
            return "Test"
        return "Unknown"

    def _instance_label(self, instance: generic_instance) -> str:
        instance_type = self._instance_type(instance)
        if instance_type == "Shipment":
            shipment = self._to_shipment(instance)
            return shipment.shipment_number
        if instance_type == "TestKit":
            test_kit = self._to_test_kit(instance)
            return test_kit.display_label
        if instance_type == "TRF":
            props = self._instance_properties(instance)
            return str(props.get("order_number") or instance.euid)
        if instance_type == "Test":
            from app.persistence.tapdb.trfs import TapdbTrfRepository

            revision = TapdbTrfRepository(self.db).get_latest_test_revision(instance.euid)
            return revision.product_code if revision and revision.product_code else instance.euid
        props = self._instance_properties(instance)
        return str(props.get("filename") or props.get("external_euid") or instance.euid)

    def _build_container_tree(
        self,
        instance: generic_instance,
        *,
        seen: set[str],
    ) -> dict[str, Any]:
        node = {
            "type": self._instance_type(instance),
            "id": instance.euid,
            "label": self._instance_label(instance),
            "children": [],
        }
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.relationship_type == CONTAINMENT_RELATIONSHIP_TYPE,
                generic_instance_lineage.parent_instance_uid == instance.uid,
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt.asc())
        )
        edges = list(self.db.execute(stmt).scalars().all())
        if not edges:
            return node
        child_uids = [edge.child_instance_uid for edge in edges]
        inst_stmt = select(generic_instance).where(generic_instance.uid.in_(child_uids))
        instance_by_uid = {row.uid: row for row in self.db.execute(inst_stmt).scalars().all()}
        for edge in edges:
            child = instance_by_uid.get(edge.child_instance_uid)
            if child is None or child.is_deleted or child.euid in seen:
                continue
            child_seen = set(seen)
            child_seen.add(child.euid)
            child_node = self._build_container_tree(child, seen=child_seen)
            child_node["added_at"] = edge.created_dt.isoformat() if edge.created_dt else None
            node["children"].append(child_node)
        return node

    def _legacy_testkit_node(self, node: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": node.get("id"),
            "barcode": node.get("label"),
            "type": None,
            "specimens": [
                child for child in node.get("children", []) if child.get("type") == "ExternalObject"
            ],
            "children": node.get("children", []),
        }
