"""TapDB client bundle construction for Atlas repositories."""

from __future__ import annotations

from dataclasses import dataclass

from app.integrations.tapdb_runtime import (
    DEFAULT_AWS_PROFILE,
    DEFAULT_AWS_REGION,
    DEFAULT_TAPDB_DATABASE_NAME,
    export_database_url_for_target,
)
from app.settings import settings


@dataclass(frozen=True)
class TapdbClientBundle:
    """Typed bundle of TapDB clients used by repository adapters."""

    connection: object
    templates: object
    factory: object
    dispatcher: object
    database_url: str


def build_tapdb_client_bundle() -> TapdbClientBundle:
    """Create a lazily-imported TapDB client bundle.

    This intentionally avoids importing TapDB modules at module import time,
    so non-TapDB workflows can still import Atlas modules safely.
    """
    from daylily_tapdb import ActionDispatcher, InstanceFactory, TAPDBConnection, TemplateManager
    from daylily_tapdb.cli.db_config import get_db_config_for_env

    target = settings.database_target
    profile = settings.aws_profile or DEFAULT_AWS_PROFILE
    region = settings.aws_region or DEFAULT_AWS_REGION
    namespace = settings.database_namespace or DEFAULT_TAPDB_DATABASE_NAME

    database_url = export_database_url_for_target(
        target=target,
        profile=profile,
        region=region,
        namespace=namespace,
    )

    tapdb_env = "dev" if target == "local" else "prod"
    cfg = get_db_config_for_env(tapdb_env)

    connection = TAPDBConnection(
        db_hostname=f"{cfg['host']}:{cfg['port']}",
        db_user=cfg["user"],
        db_pass=cfg.get("password", ""),
        db_name=cfg["database"],
    )
    templates = TemplateManager()
    factory = InstanceFactory(templates)
    dispatcher = ActionDispatcher()

    return TapdbClientBundle(
        connection=connection,
        templates=templates,
        factory=factory,
        dispatcher=dispatcher,
        database_url=database_url,
    )
