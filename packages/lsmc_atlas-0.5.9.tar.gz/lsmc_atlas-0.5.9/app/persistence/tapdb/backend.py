"""Backend selection helpers for staged TapDB cutover."""

from __future__ import annotations

import os

from app.settings import settings


def get_backend_mode() -> str:
    """Return active backend mode for persistence migration."""
    backend = (
        (
            os.environ.get("ATLAS_DB_BACKEND")
            or os.environ.get("DATABASE_BACKEND")
            or settings.database_backend
            or "tapdb"
        )
        .strip()
        .lower()
    )
    if backend != "tapdb":
        return "tapdb"
    return backend


def is_tapdb_backend_enabled() -> bool:
    """Feature flag for enabling TapDB-backed repositories."""
    return get_backend_mode() == "tapdb"
