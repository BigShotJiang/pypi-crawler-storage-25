"""TapDB-backed repository for external object mappings and Bloom integration config."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_instance_by_euid

EXTERNAL_OBJECT_TEMPLATE_CODE = "atlas/integration/external-object/1.0/"
EXTERNAL_OBJECT_RELATION_TEMPLATE_CODE = "atlas/integration/external-object-relation/1.0/"
ORG_BLOOM_CONFIG_TEMPLATE_CODE = "atlas/integration/bloom-org-config/1.0/"
SITE_BLOOM_CONFIG_TEMPLATE_CODE = "atlas/integration/bloom-site-config/1.0/"
WEBHOOK_RECEIPT_TEMPLATE_CODE = "atlas/integration/webhook-receipt/1.0/"

# TapDB instance prefixes must avoid ambiguous letters (I/L/O/U). See daylily_tapdb.sequences.
EXTERNAL_OBJECT_PREFIX = "EXB"
EXTERNAL_OBJECT_RELATION_PREFIX = "EXR"
ORG_BLOOM_CONFIG_PREFIX = "EXC"
SITE_BLOOM_CONFIG_PREFIX = "EXS"
WEBHOOK_RECEIPT_PREFIX = "EWR"
RELATIONSHIP_PREFIX = "external_relation:"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbExternalObjectRecord:
    euid: str
    tenant_id: uuid.UUID
    provider: str
    object_type: str
    external_euid: str
    status: str
    is_deleted: bool
    metadata: dict[str, Any] | None
    version: int
    created_at: datetime | None
    created_by: uuid.UUID | None
    modified_at: datetime | None
    modified_by: uuid.UUID | None
    uid: int | None = None
    euid_seq: int | None = None


@dataclass
class TapdbExternalObjectRelationRecord:
    euid: str
    tenant_id: uuid.UUID
    external_object_id: str
    relation_type: str
    local_entity_type: str
    local_entity_id: str
    metadata: dict[str, Any] | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbOrgBloomConfigRecord:
    euid: str
    organization_id: uuid.UUID
    enabled: bool
    bloom_base_url: str
    bloom_api_key_secret_ref: str
    bloom_webhook_secret_ref: str | None
    bloom_service_user: str | None
    last_verified_at: datetime | None
    metadata: dict[str, Any] | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    modified_at: datetime | None
    modified_by: uuid.UUID | None


@dataclass
class TapdbSiteBloomConfigRecord:
    euid: str
    site_id: str
    organization_id: uuid.UUID
    enabled: bool
    bloom_base_url: str
    bloom_api_key_secret_ref: str
    bloom_webhook_secret_ref: str | None
    bloom_service_user: str | None
    last_verified_at: datetime | None
    metadata: dict[str, Any] | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    modified_at: datetime | None
    modified_by: uuid.UUID | None


@dataclass
class TapdbWebhookReceiptRecord:
    euid: str
    provider: str
    tenant_id: uuid.UUID
    event_id: str
    received_at: datetime
    created_at: datetime | None


class TapdbExternalObjectRepository:
    """External object + relation + Bloom integration config persistence."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_or_update_external_object(
        self,
        *,
        tenant_id: uuid.UUID,
        provider: str,
        object_type: str,
        external_euid: str,
        status: str = "active",
        is_deleted: bool = False,
        metadata: dict[str, Any] | None = None,
        version: int = 1,
        actor_id: uuid.UUID | None = None,
    ) -> TapdbExternalObjectRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        existing_instance = self._find_external_object_instance(
            tenant_id=tenant_id,
            provider=provider,
            object_type=object_type,
            external_euid=external_euid,
        )
        if existing_instance is None:
            props = {
                "tenant_id": str(tenant_id),
                "provider": provider,
                "object_type": object_type,
                "external_euid": external_euid,
                "status": status,
                "is_deleted": is_deleted,
                "metadata": metadata or {},
                "version": version,
                "created_by": str(actor_id) if actor_id else None,
                "created_at": now.isoformat(),
                "modified_by": str(actor_id) if actor_id else None,
                "modified_at": now.isoformat(),
            }
            instance = self.factory.create_instance(
                session=self.db,
                template_code=EXTERNAL_OBJECT_TEMPLATE_CODE,
                name=external_euid,
                properties=props,
            )
            self.db.commit()
            return self._to_external_object(instance)

        props = self._instance_properties(existing_instance)
        props.pop("external_uuid", None)
        props["status"] = status
        props["is_deleted"] = bool(is_deleted)
        props["metadata"] = metadata or {}
        props["version"] = int(version)
        props["modified_by"] = str(actor_id) if actor_id else None
        props["modified_at"] = now.isoformat()
        self._write_instance_properties(existing_instance, props)
        self.db.commit()
        self.db.refresh(existing_instance)
        return self._to_external_object(existing_instance)

    def get_external_object_by_euid(
        self,
        *,
        tenant_id: uuid.UUID,
        provider: str,
        object_type: str,
        external_euid: str,
    ) -> TapdbExternalObjectRecord | None:
        instance = self._find_external_object_instance(
            tenant_id=tenant_id,
            provider=provider,
            object_type=object_type,
            external_euid=external_euid,
        )
        if instance is None:
            return None
        return self._to_external_object(instance)

    def get_external_object_by_id(
        self, external_object_id: str
    ) -> TapdbExternalObjectRecord | None:
        instance = get_instance_by_euid(self.db, EXTERNAL_OBJECT_TEMPLATE_CODE, external_object_id)
        if instance is None or instance.is_deleted:
            return None
        return self._to_external_object(instance)

    def list_external_objects(
        self,
        *,
        tenant_id: uuid.UUID | None = None,
        provider: str | None = None,
        object_type: str | None = None,
        include_deleted: bool = False,
    ) -> list[TapdbExternalObjectRecord]:
        stmt = self._query_instances_for_template(
            EXTERNAL_OBJECT_TEMPLATE_CODE,
            property_filters={
                "tenant_id": str(tenant_id) if tenant_id else None,
                "provider": provider,
                "object_type": object_type,
            },
        )
        rows: list[TapdbExternalObjectRecord] = []
        for instance in self.db.execute(stmt).scalars().all():
            record = self._to_external_object(instance)
            if not include_deleted and record.is_deleted:
                continue
            rows.append(record)
        rows.sort(
            key=lambda item: (
                item.modified_at or item.created_at or datetime.min.replace(tzinfo=UTC)
            ),
            reverse=True,
        )
        return rows

    def create_relation(
        self,
        *,
        tenant_id: uuid.UUID,
        external_object_id: str,
        relation_type: str,
        local_entity_type: str,
        local_entity_id: str,
        metadata: dict[str, Any] | None = None,
        actor_id: uuid.UUID | None = None,
    ) -> TapdbExternalObjectRelationRecord:
        external_instance = get_instance_by_euid(
            self.db, EXTERNAL_OBJECT_TEMPLATE_CODE, external_object_id
        )
        if external_instance is None or external_instance.is_deleted:
            raise ValueError(f"External object not found: {external_object_id}")
        local_instance = self._find_any_instance(local_entity_id)
        if local_instance is None or local_instance.is_deleted:
            raise ValueError(f"Local entity not found: {local_entity_id}")

        existing = self._find_relation_lineage(
            external_object_id=external_object_id,
            relation_type=relation_type,
            local_entity_id=local_entity_id,
        )
        now = datetime.now(UTC)
        props = {
            "tenant_id": str(tenant_id),
            "relation_type": relation_type,
            "local_entity_type": local_entity_type,
            "metadata": metadata or {},
            "created_by": str(actor_id) if actor_id else None,
            "created_at": now.isoformat(),
        }
        if existing is not None:
            merged = dict(self._lineage_properties(existing).get("metadata") or {})
            merged.update(metadata or {})
            props["metadata"] = merged
            existing.json_addl = {"properties": props}
            self.db.commit()
            self.db.refresh(existing)
            return self._relation_record_from_lineage(existing)

        lineage = self.factory.link_instances(
            session=self.db,
            parent=external_instance,
            child=local_instance,
            relationship_type=self._relation_edge_type(relation_type),
        )
        lineage.json_addl = {"properties": props}
        self.db.commit()
        return self._relation_record_from_lineage(lineage)

    def delete_relation(
        self,
        *,
        tenant_id: uuid.UUID,
        external_object_id: str,
        relation_type: str,
        local_entity_id: str,
    ) -> bool:
        lineage = self._find_relation_lineage(
            external_object_id=external_object_id,
            relation_type=relation_type,
            local_entity_id=local_entity_id,
        )
        if lineage is None:
            return False
        props = self._lineage_properties(lineage)
        if str(props.get("tenant_id")) != str(tenant_id):
            return False
        lineage.is_deleted = True
        self.db.commit()
        return True

    def list_relations_for_external_object(
        self, external_object_id: str
    ) -> list[TapdbExternalObjectRelationRecord]:
        external_instance = get_instance_by_euid(
            self.db, EXTERNAL_OBJECT_TEMPLATE_CODE, external_object_id
        )
        if external_instance is None or external_instance.is_deleted:
            return []
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == external_instance.uid,
                generic_instance_lineage.relationship_type.like(f"{RELATIONSHIP_PREFIX}%"),
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt.asc())
        )
        return [
            self._relation_record_from_lineage(lineage)
            for lineage in self.db.execute(stmt).scalars().all()
        ]

    def list_relations_for_local_entity(
        self,
        *,
        tenant_id: uuid.UUID,
        local_entity_type: str,
        local_entity_id: str,
    ) -> list[TapdbExternalObjectRelationRecord]:
        local_instance = self._find_any_instance(local_entity_id)
        if local_instance is None or local_instance.is_deleted:
            return []
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.child_instance_uid == local_instance.uid,
                generic_instance_lineage.relationship_type.like(f"{RELATIONSHIP_PREFIX}%"),
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt.asc())
        )
        rows = [
            self._relation_record_from_lineage(lineage)
            for lineage in self.db.execute(stmt).scalars().all()
        ]
        return [
            row
            for row in rows
            if row.tenant_id == tenant_id and row.local_entity_type == local_entity_type
        ]

    def set_single_relation_for_local_entity(
        self,
        *,
        tenant_id: uuid.UUID,
        relation_type: str,
        local_entity_type: str,
        local_entity_id: str,
        external_object_id: str | None,
        metadata: dict[str, Any] | None = None,
        actor_id: uuid.UUID | None = None,
    ) -> TapdbExternalObjectRelationRecord | None:
        """Ensure at most one active relation exists for (tenant, relation_type, local_entity).

        If external_object_id is None, deletes any existing relations and returns None.
        Otherwise, deletes existing relations that point elsewhere, then upserts the requested relation.
        """
        self._ensure_templates()

        normalized_relation_type = (relation_type or "").strip()
        normalized_local_entity_type = (local_entity_type or "").strip()
        if not normalized_relation_type:
            raise ValueError("relation_type is required")
        if not normalized_local_entity_type:
            raise ValueError("local_entity_type is required")

        desired_external_id = external_object_id
        changed = False
        local_instance = self._find_any_instance(local_entity_id)
        if local_instance is not None:
            stmt = select(generic_instance_lineage).where(
                generic_instance_lineage.child_instance_uid == local_instance.uid,
                generic_instance_lineage.relationship_type
                == self._relation_edge_type(normalized_relation_type),
                generic_instance_lineage.is_deleted.is_(False),
            )
            for lineage in self.db.execute(stmt).scalars().all():
                props = self._lineage_properties(lineage)
                if str(props.get("tenant_id")) != str(tenant_id):
                    continue
                if str(props.get("local_entity_type")) != normalized_local_entity_type:
                    continue
                parent = self._find_instance_by_uid(lineage.parent_instance_uid)
                if parent is None:
                    continue
                if desired_external_id is None or parent.euid != desired_external_id:
                    lineage.is_deleted = True
                    changed = True

        if desired_external_id is None:
            if changed:
                self.db.commit()
            return None

        relation = self.create_relation(
            tenant_id=tenant_id,
            external_object_id=external_object_id,
            relation_type=normalized_relation_type,
            local_entity_type=normalized_local_entity_type,
            local_entity_id=local_entity_id,
            metadata=metadata,
            actor_id=actor_id,
        )

        if changed:
            # create_relation commits; if we also deleted relations, ensure those deletes are persisted.
            self.db.commit()
        return relation

    def upsert_org_bloom_config(
        self,
        *,
        organization_id: uuid.UUID,
        enabled: bool,
        bloom_base_url: str,
        bloom_api_key_secret_ref: str,
        bloom_webhook_secret_ref: str | None = None,
        bloom_service_user: str | None = None,
        last_verified_at: datetime | None = None,
        metadata: dict[str, Any] | None = None,
        actor_id: uuid.UUID | None = None,
    ) -> TapdbOrgBloomConfigRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        existing = self._find_org_bloom_config_instance(organization_id)
        if existing is None:
            props = {
                "organization_id": str(organization_id),
                "enabled": bool(enabled),
                "bloom_base_url": bloom_base_url,
                "bloom_api_key_secret_ref": bloom_api_key_secret_ref,
                "bloom_webhook_secret_ref": bloom_webhook_secret_ref,
                "bloom_service_user": bloom_service_user,
                "last_verified_at": last_verified_at.isoformat() if last_verified_at else None,
                "metadata": metadata or {},
                "created_by": str(actor_id) if actor_id else None,
                "created_at": now.isoformat(),
                "modified_by": str(actor_id) if actor_id else None,
                "modified_at": now.isoformat(),
            }
            instance = self.factory.create_instance(
                session=self.db,
                template_code=ORG_BLOOM_CONFIG_TEMPLATE_CODE,
                name=f"org-{organization_id}",
                properties=props,
            )
            self.db.commit()
            return self._to_org_bloom_config(instance)

        props = self._instance_properties(existing)
        props["enabled"] = bool(enabled)
        props["bloom_base_url"] = bloom_base_url
        props["bloom_api_key_secret_ref"] = bloom_api_key_secret_ref
        props["bloom_webhook_secret_ref"] = bloom_webhook_secret_ref
        props["bloom_service_user"] = bloom_service_user
        props["last_verified_at"] = last_verified_at.isoformat() if last_verified_at else None
        props["metadata"] = metadata or {}
        props["modified_by"] = str(actor_id) if actor_id else None
        props["modified_at"] = now.isoformat()
        self._write_instance_properties(existing, props)
        self.db.commit()
        self.db.refresh(existing)
        return self._to_org_bloom_config(existing)

    def get_org_bloom_config(self, organization_id: uuid.UUID) -> TapdbOrgBloomConfigRecord | None:
        instance = self._find_org_bloom_config_instance(organization_id)
        if instance is None:
            return None
        return self._to_org_bloom_config(instance)

    def list_enabled_bloom_configs(self) -> list[TapdbOrgBloomConfigRecord]:
        stmt = self._query_instances_for_template(
            ORG_BLOOM_CONFIG_TEMPLATE_CODE,
            property_filters={"enabled": "true"},
        )
        return [
            self._to_org_bloom_config(instance)
            for instance in self.db.execute(stmt).scalars().all()
        ]

    def upsert_site_bloom_config(
        self,
        *,
        site_id: str,
        organization_id: uuid.UUID,
        enabled: bool,
        bloom_base_url: str,
        bloom_api_key_secret_ref: str,
        bloom_webhook_secret_ref: str | None = None,
        bloom_service_user: str | None = None,
        last_verified_at: datetime | None = None,
        metadata: dict[str, Any] | None = None,
        actor_id: uuid.UUID | None = None,
    ) -> TapdbSiteBloomConfigRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        existing = self._find_site_bloom_config_instance(site_id)
        if existing is None:
            props = {
                "site_id": str(site_id),
                "organization_id": str(organization_id),
                "enabled": bool(enabled),
                "bloom_base_url": bloom_base_url,
                "bloom_api_key_secret_ref": bloom_api_key_secret_ref,
                "bloom_webhook_secret_ref": bloom_webhook_secret_ref,
                "bloom_service_user": bloom_service_user,
                "last_verified_at": last_verified_at.isoformat() if last_verified_at else None,
                "metadata": metadata or {},
                "created_by": str(actor_id) if actor_id else None,
                "created_at": now.isoformat(),
                "modified_by": str(actor_id) if actor_id else None,
                "modified_at": now.isoformat(),
            }
            instance = self.factory.create_instance(
                session=self.db,
                template_code=SITE_BLOOM_CONFIG_TEMPLATE_CODE,
                name=f"site-{site_id}",
                properties=props,
            )
            self.db.commit()
            return self._to_site_bloom_config(instance)

        props = self._instance_properties(existing)
        props["site_id"] = str(site_id)
        props["organization_id"] = str(organization_id)
        props["enabled"] = bool(enabled)
        props["bloom_base_url"] = bloom_base_url
        props["bloom_api_key_secret_ref"] = bloom_api_key_secret_ref
        props["bloom_webhook_secret_ref"] = bloom_webhook_secret_ref
        props["bloom_service_user"] = bloom_service_user
        props["last_verified_at"] = last_verified_at.isoformat() if last_verified_at else None
        props["metadata"] = metadata or {}
        props["modified_by"] = str(actor_id) if actor_id else None
        props["modified_at"] = now.isoformat()
        self._write_instance_properties(existing, props)
        self.db.commit()
        self.db.refresh(existing)
        return self._to_site_bloom_config(existing)

    def get_site_bloom_config(self, site_id: str) -> TapdbSiteBloomConfigRecord | None:
        instance = self._find_site_bloom_config_instance(site_id)
        if instance is None:
            return None
        return self._to_site_bloom_config(instance)

    def list_enabled_site_bloom_configs(
        self,
        *,
        organization_id: uuid.UUID | None = None,
    ) -> list[TapdbSiteBloomConfigRecord]:
        stmt = self._query_instances_for_template(
            SITE_BLOOM_CONFIG_TEMPLATE_CODE,
            property_filters={
                "enabled": "true",
                "organization_id": str(organization_id) if organization_id else None,
            },
        )
        return [
            self._to_site_bloom_config(instance)
            for instance in self.db.execute(stmt).scalars().all()
        ]

    def mark_webhook_event_received(
        self,
        *,
        provider: str,
        tenant_id: uuid.UUID,
        event_id: str,
    ) -> bool:
        """Record webhook receipt and return True when new, False when duplicate."""
        self._ensure_templates()
        event_id = (event_id or "").strip()
        if not event_id:
            raise ValueError("event_id is required")

        existing = self._find_webhook_receipt_instance(
            provider=provider,
            tenant_id=tenant_id,
            event_id=event_id,
        )
        if existing is not None:
            return False

        now = datetime.now(UTC)
        props = {
            "provider": provider,
            "tenant_id": str(tenant_id),
            "event_id": event_id,
            "received_at": now.isoformat(),
        }
        self.factory.create_instance(
            session=self.db,
            template_code=WEBHOOK_RECEIPT_TEMPLATE_CODE,
            name=f"{provider}:{event_id}",
            properties=props,
        )
        self.db.commit()
        return True

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            EXTERNAL_OBJECT_TEMPLATE_CODE,
            EXTERNAL_OBJECT_PREFIX,
            "Atlas External Object",
            {"managed_by": "lsmc-atlas", "domain": "external_objects"},
        )
        self._ensure_template(
            EXTERNAL_OBJECT_RELATION_TEMPLATE_CODE,
            EXTERNAL_OBJECT_RELATION_PREFIX,
            "Atlas External Object Relation",
            {"managed_by": "lsmc-atlas", "domain": "external_objects"},
        )
        self._ensure_template(
            ORG_BLOOM_CONFIG_TEMPLATE_CODE,
            ORG_BLOOM_CONFIG_PREFIX,
            "Atlas Bloom Organization Config",
            {"managed_by": "lsmc-atlas", "domain": "external_objects"},
        )
        self._ensure_template(
            SITE_BLOOM_CONFIG_TEMPLATE_CODE,
            SITE_BLOOM_CONFIG_PREFIX,
            "Atlas Bloom Site Config",
            {"managed_by": "lsmc-atlas", "domain": "external_objects"},
        )
        self._ensure_template(
            WEBHOOK_RECEIPT_TEMPLATE_CODE,
            WEBHOOK_RECEIPT_PREFIX,
            "Atlas Webhook Receipt",
            {"managed_by": "lsmc-atlas", "domain": "external_objects"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        del name, json_addl
        from daylily_tapdb import require_seeded_template

        require_seeded_template(
            self.db,
            template_code,
            expected_prefix=instance_prefix,
            app_name="Atlas",
        )

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        stmt = self._query_instances_for_template(template_code)
        return list(self.db.execute(stmt).scalars().all())

    def _query_instances_for_template(
        self,
        template_code: str,
        *,
        property_filters: dict[str, str | None] | None = None,
    ):
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        for key, value in (property_filters or {}).items():
            if value is None:
                continue
            stmt = stmt.where(
                func.jsonb_extract_path_text(
                    generic_instance.json_addl["properties"],
                    key,
                )
                == str(value)
            )
        return stmt

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _write_instance_properties(self, instance: generic_instance, props: dict[str, Any]) -> None:
        raw = dict(instance.json_addl or {})
        raw["properties"] = props
        instance.json_addl = raw

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _find_external_object_instance(
        self,
        *,
        tenant_id: uuid.UUID,
        provider: str,
        object_type: str,
        external_euid: str,
    ) -> generic_instance | None:
        stmt = self._query_instances_for_template(
            EXTERNAL_OBJECT_TEMPLATE_CODE,
            property_filters={
                "tenant_id": str(tenant_id),
                "provider": provider,
                "object_type": object_type,
                "external_euid": external_euid,
            },
        ).limit(1)
        return self.db.execute(stmt).scalar_one_or_none()

    def _find_any_instance(self, euid: str) -> generic_instance | None:
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.euid == str(euid),
                generic_instance.is_deleted.is_(False),
            )
            .limit(1)
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def _find_instance_by_uid(self, uid: int) -> generic_instance | None:
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.uid == uid,
                generic_instance.is_deleted.is_(False),
            )
            .limit(1)
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def _relation_edge_type(self, relation_type: str) -> str:
        return f"{RELATIONSHIP_PREFIX}{str(relation_type).strip()}"

    def _lineage_properties(self, lineage: generic_instance_lineage) -> dict[str, Any]:
        raw = lineage.json_addl or {}
        props = raw.get("properties") if isinstance(raw, dict) else None
        return dict(props) if isinstance(props, dict) else {}

    def _find_relation_lineage(
        self,
        *,
        external_object_id: str,
        relation_type: str,
        local_entity_id: str,
    ) -> generic_instance_lineage | None:
        external_instance = get_instance_by_euid(
            self.db, EXTERNAL_OBJECT_TEMPLATE_CODE, external_object_id
        )
        local_instance = self._find_any_instance(local_entity_id)
        if external_instance is None or local_instance is None:
            return None
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == external_instance.uid,
                generic_instance_lineage.child_instance_uid == local_instance.uid,
                generic_instance_lineage.relationship_type
                == self._relation_edge_type(relation_type),
                generic_instance_lineage.is_deleted.is_(False),
            )
            .limit(1)
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def _find_relation_instance(
        self,
        *,
        tenant_id: uuid.UUID,
        external_object_id: str,
        relation_type: str,
        local_entity_type: str,
        local_entity_id: str,
    ) -> generic_instance | None:
        stmt = self._query_instances_for_template(
            EXTERNAL_OBJECT_RELATION_TEMPLATE_CODE,
            property_filters={
                "tenant_id": str(tenant_id),
                "external_object_id": external_object_id,
                "relation_type": relation_type,
                "local_entity_type": local_entity_type,
                "local_entity_id": local_entity_id,
            },
        ).limit(1)
        return self.db.execute(stmt).scalar_one_or_none()

    def _find_org_bloom_config_instance(
        self, organization_id: uuid.UUID
    ) -> generic_instance | None:
        stmt = self._query_instances_for_template(
            ORG_BLOOM_CONFIG_TEMPLATE_CODE,
            property_filters={"organization_id": str(organization_id)},
        ).limit(1)
        return self.db.execute(stmt).scalar_one_or_none()

    def _find_site_bloom_config_instance(self, site_id: str) -> generic_instance | None:
        stmt = self._query_instances_for_template(
            SITE_BLOOM_CONFIG_TEMPLATE_CODE,
            property_filters={"site_id": str(site_id)},
        ).limit(1)
        return self.db.execute(stmt).scalar_one_or_none()

    def _find_webhook_receipt_instance(
        self,
        *,
        provider: str,
        tenant_id: uuid.UUID,
        event_id: str,
    ) -> generic_instance | None:
        stmt = self._query_instances_for_template(
            WEBHOOK_RECEIPT_TEMPLATE_CODE,
            property_filters={
                "provider": provider,
                "tenant_id": str(tenant_id),
                "event_id": event_id,
            },
        ).limit(1)
        return self.db.execute(stmt).scalar_one_or_none()

    def _to_external_object(self, instance: generic_instance) -> TapdbExternalObjectRecord:
        props = self._instance_properties(instance)
        return TapdbExternalObjectRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            provider=str(props.get("provider") or ""),
            object_type=str(props.get("object_type") or ""),
            external_euid=str(props.get("external_euid") or instance.name),
            status=str(props.get("status") or "active"),
            is_deleted=bool(props.get("is_deleted", False)),
            metadata=props.get("metadata") if isinstance(props.get("metadata"), dict) else {},
            version=int(props.get("version") or 1),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            modified_at=_to_dt(props.get("modified_at"))
            or instance.modified_dt
            or instance.created_dt,
            modified_by=_parse_uuid(props.get("modified_by")),
            uid=int(instance.uid) if instance.uid is not None else None,
            euid_seq=int(instance.euid_seq) if instance.euid_seq is not None else None,
        )

    def _relation_record_from_lineage(
        self, lineage: generic_instance_lineage
    ) -> TapdbExternalObjectRelationRecord:
        props = self._lineage_properties(lineage)
        parent = self._find_instance_by_uid(lineage.parent_instance_uid)
        child = self._find_instance_by_uid(lineage.child_instance_uid)
        relation_type = str(props.get("relation_type") or "")
        if not relation_type and lineage.relationship_type.startswith(RELATIONSHIP_PREFIX):
            relation_type = lineage.relationship_type[len(RELATIONSHIP_PREFIX) :]
        return TapdbExternalObjectRelationRecord(
            euid=lineage.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            external_object_id=parent.euid if parent is not None else "",
            relation_type=relation_type,
            local_entity_type=str(props.get("local_entity_type") or ""),
            local_entity_id=child.euid if child is not None else "",
            metadata=props.get("metadata") if isinstance(props.get("metadata"), dict) else {},
            created_at=_to_dt(props.get("created_at")) or lineage.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_relation(self, instance: generic_instance) -> TapdbExternalObjectRelationRecord:
        props = self._instance_properties(instance)
        return TapdbExternalObjectRelationRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            external_object_id=str(props.get("external_object_id") or ""),
            relation_type=str(props.get("relation_type") or ""),
            local_entity_type=str(props.get("local_entity_type") or ""),
            local_entity_id=str(props.get("local_entity_id") or ""),
            metadata=props.get("metadata") if isinstance(props.get("metadata"), dict) else {},
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_org_bloom_config(self, instance: generic_instance) -> TapdbOrgBloomConfigRecord:
        props = self._instance_properties(instance)
        return TapdbOrgBloomConfigRecord(
            euid=instance.euid,
            organization_id=_parse_uuid(props.get("organization_id")) or uuid.UUID(int=0),
            enabled=bool(props.get("enabled", False)),
            bloom_base_url=str(props.get("bloom_base_url") or ""),
            bloom_api_key_secret_ref=str(props.get("bloom_api_key_secret_ref") or ""),
            bloom_webhook_secret_ref=(
                str(props.get("bloom_webhook_secret_ref"))
                if props.get("bloom_webhook_secret_ref")
                else None
            ),
            bloom_service_user=(
                str(props.get("bloom_service_user")) if props.get("bloom_service_user") else None
            ),
            last_verified_at=_to_dt(props.get("last_verified_at")),
            metadata=props.get("metadata") if isinstance(props.get("metadata"), dict) else {},
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            modified_at=_to_dt(props.get("modified_at"))
            or instance.modified_dt
            or instance.created_dt,
            modified_by=_parse_uuid(props.get("modified_by")),
        )

    def _to_site_bloom_config(self, instance: generic_instance) -> TapdbSiteBloomConfigRecord:
        props = self._instance_properties(instance)
        return TapdbSiteBloomConfigRecord(
            euid=instance.euid,
            site_id=str(props.get("site_id") or ""),
            organization_id=_parse_uuid(props.get("organization_id")) or uuid.UUID(int=0),
            enabled=bool(props.get("enabled", False)),
            bloom_base_url=str(props.get("bloom_base_url") or ""),
            bloom_api_key_secret_ref=str(props.get("bloom_api_key_secret_ref") or ""),
            bloom_webhook_secret_ref=(
                str(props.get("bloom_webhook_secret_ref"))
                if props.get("bloom_webhook_secret_ref")
                else None
            ),
            bloom_service_user=(
                str(props.get("bloom_service_user")) if props.get("bloom_service_user") else None
            ),
            last_verified_at=_to_dt(props.get("last_verified_at")),
            metadata=props.get("metadata") if isinstance(props.get("metadata"), dict) else {},
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            modified_at=_to_dt(props.get("modified_at"))
            or instance.modified_dt
            or instance.created_dt,
            modified_by=_parse_uuid(props.get("modified_by")),
        )

    def _to_webhook_receipt(self, instance: generic_instance) -> TapdbWebhookReceiptRecord:
        props = self._instance_properties(instance)
        return TapdbWebhookReceiptRecord(
            euid=instance.euid,
            provider=str(props.get("provider") or ""),
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            event_id=str(props.get("event_id") or ""),
            received_at=_to_dt(props.get("received_at")) or datetime.now(UTC),
            created_at=instance.created_dt,
        )
