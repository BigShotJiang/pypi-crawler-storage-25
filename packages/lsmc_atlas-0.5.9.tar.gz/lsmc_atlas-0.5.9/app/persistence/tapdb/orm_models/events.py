"""LSMC Hub - Event Models (StatusEvent, LinkEvent, ContainmentEvent, AuditEvent)."""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, String, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.persistence.tapdb.orm_models.base import Base


class LinkAction(StrEnum):
    """Link event actions."""

    LINK = "LINK"
    UNLINK = "UNLINK"


class ContainmentAction(StrEnum):
    """Containment event actions."""

    ADD = "ADD"
    REMOVE = "REMOVE"


class AuditAction(StrEnum):
    """Audit event action types."""

    VIEW = "VIEW"
    DOWNLOAD = "DOWNLOAD"
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    STATUS_CHANGE = "STATUS_CHANGE"
    LINK = "LINK"
    UNLINK = "UNLINK"
    PERMISSION_CHANGE = "PERMISSION_CHANGE"
    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"
    INVITE_USER = "INVITE_USER"
    DOCS_ACCESS = "DOCS_ACCESS"


class StatusEvent(Base):
    """
    Status event table (append-only).

    Records status changes for any entity.
    """

    __tablename__ = "status_event"

    event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Entity reference
    entity_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    entity_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)

    # Status change
    previous_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    new_status: Mapped[str] = mapped_column(String(50), nullable=False)

    # Reason/notes
    reason: Mapped[str | None] = mapped_column(nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )


class LinkEvent(Base):
    """
    Link event table (append-only).

    Records linking/unlinking of entities.
    """

    __tablename__ = "link_event"

    event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Action
    action: Mapped[str] = mapped_column(String(20), nullable=False)  # LINK or UNLINK

    # Source entity
    source_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    source_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)

    # Target entity
    target_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    target_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)

    # Reason/notes
    reason: Mapped[str | None] = mapped_column(nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )


class ContainmentEvent(Base):
    """
    Containment event table (append-only).

    Records physical containment relationships (e.g., Container in TestKit in Shipment).
    """

    __tablename__ = "containment_event"

    event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Action
    action: Mapped[str] = mapped_column(String(20), nullable=False)  # ADD or REMOVE

    # Container entity
    container_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    container_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)

    # Contained entity
    contained_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    contained_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)

    # Reason/notes
    reason: Mapped[str | None] = mapped_column(nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )


class AuditEvent(Base):
    """
    Audit event table (append-only).

    Records all PHI-sensitive actions for compliance.
    """

    __tablename__ = "audit_event"

    event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=True,  # Can be null for system-level events
        index=True,
    )

    # Actor
    user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    user_email: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Action
    action: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    # Target entity (optional)
    entity_type: Mapped[str | None] = mapped_column(String(50), nullable=True, index=True)
    entity_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), nullable=True, index=True
    )

    # Request context
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)

    # Additional details (no PHI!)
    details: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        index=True,
    )


class ExternalIdentifier(Base):
    """
    External identifier table.

    Maps external IDs (MRN, accession numbers, etc.) to Hub entities.
    """

    __tablename__ = "external_identifier"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Identifier info
    identifier_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    identifier_value: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    identifier_system: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Entity reference
    entity_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    entity_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)

    # Status
    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )
