"""LSMC Hub - Support Ticket Models.

Support ticket system for customer service and issue tracking.
Uses identity + revision pattern for append-only design.
"""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, Integer, String, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.persistence.tapdb.orm_models.base import Base


class TicketType(StrEnum):
    """Support ticket types."""

    TECHNICAL = "TECHNICAL"  # Technical issues
    BILLING = "BILLING"  # Billing questions
    ORDER_ISSUE = "ORDER_ISSUE"  # Order-related problems
    SPECIMEN_ISSUE = "SPECIMEN_ISSUE"  # Specimen handling issues
    RESULT_INQUIRY = "RESULT_INQUIRY"  # Questions about results
    ACCESS_REQUEST = "ACCESS_REQUEST"  # Access/permission requests
    FEATURE_REQUEST = "FEATURE_REQUEST"  # Feature requests
    OTHER = "OTHER"  # Other inquiries


class TicketPriority(StrEnum):
    """Support ticket priority levels."""

    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"
    URGENT = "URGENT"


class TicketStatus(StrEnum):
    """Support ticket status."""

    OPEN = "OPEN"  # Newly created
    ASSIGNED = "ASSIGNED"  # Assigned to staff
    IN_PROGRESS = "IN_PROGRESS"  # Being worked on
    WAITING_CUSTOMER = "WAITING_CUSTOMER"  # Waiting for customer response
    WAITING_INTERNAL = "WAITING_INTERNAL"  # Waiting for internal response
    RESOLVED = "RESOLVED"  # Resolved
    CLOSED = "CLOSED"  # Closed


class SupportTicket(Base):
    """
    Support ticket identity table.

    Immutable after creation. All updates go to SupportTicketRevision.
    """

    __tablename__ = "support_ticket"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    # Tenant scoping
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Ticket number (human-readable, e.g., "TKT-2024-00001")
    ticket_number: Mapped[str] = mapped_column(String(50), nullable=False, unique=True, index=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)


class SupportTicketRevision(Base):
    """
    Support ticket revision table (append-only).

    Each update creates a new revision row.
    """

    __tablename__ = "support_ticket_revision"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    ticket_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("support_ticket.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    # Ticket details
    subject: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str] = mapped_column(nullable=False)
    ticket_type: Mapped[str] = mapped_column(String(50), nullable=False)
    priority: Mapped[str] = mapped_column(String(20), nullable=False)
    status: Mapped[str] = mapped_column(String(50), nullable=False)

    # Assignment
    assigned_to: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Related entities (optional)
    related_order_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    related_shipment_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Resolution
    resolution_notes: Mapped[str | None] = mapped_column(nullable=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    resolved_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
