"""LSMC Hub - Logistics Models (Shipment, TestKit, Manifest, Document)."""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, String, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class ShipmentStatus(StrEnum):
    """Shipment status values."""

    DRAFT = "DRAFT"
    READY_TO_SHIP = "READY_TO_SHIP"
    IN_TRANSIT = "IN_TRANSIT"
    DELIVERED = "DELIVERED"
    RECEIVED = "RECEIVED"
    CANCELED = "CANCELED"


class TestKitStatus(StrEnum):
    """TestKit status values (Step 6.5)."""

    CREATED = "CREATED"
    RECEIVED = "RECEIVED"


class Shipment(Base):
    """
    Shipment identity table.

    Shipments are physical packages. They can contain:
    - TestKits
    - Bloom-linked containers/specimens (external)
    - Documents
    - Nested Shipments
    Containment is tracked via ContainmentEvent.
    """

    __tablename__ = "shipment"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Human-readable shipment number
    shipment_number: Mapped[str] = mapped_column(
        String(50), nullable=False, unique=True, index=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["ShipmentRevision"]] = relationship(
        back_populates="shipment",
        order_by="ShipmentRevision.revision_no",
    )


class ShipmentRevision(Base):
    """Shipment revision table (append-only snapshots)."""

    __tablename__ = "shipment_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    shipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("shipment.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Status
    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=ShipmentStatus.DRAFT.value
    )

    # Carrier info
    carrier: Mapped[str | None] = mapped_column(String(100), nullable=True)
    tracking_number: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)

    # Origin/destination addresses
    origin_address: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    destination_address: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Dates
    shipped_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Special handling
    temperature_requirement: Mapped[str | None] = mapped_column(String(50), nullable=True)
    special_instructions: Mapped[str | None] = mapped_column(nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    shipment: Mapped["Shipment"] = relationship(back_populates="revisions")


class TestKit(Base):
    """
    TestKit identity table.

    TestKits are pre-assembled collection kits sent to clinics.
    They can contain Bloom-linked containers/specimens and Documents.
    """

    __tablename__ = "test_kit"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # Kit barcode/identifier
    kit_barcode: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        unique=True,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["TestKitRevision"]] = relationship(
        back_populates="test_kit",
        order_by="TestKitRevision.revision_no",
    )


class TestKitRevision(Base):
    """TestKit revision table."""

    __tablename__ = "test_kit_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    test_kit_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("test_kit.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Kit type/product
    kit_type: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Status
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="CREATED")

    # Expiration
    expiration_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    test_kit: Mapped["TestKit"] = relationship(back_populates="revisions")


class Manifest(Base):
    """
    Manifest identity table.

    Manifests document the contents of a shipment.
    """

    __tablename__ = "manifest"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    manifest_number: Mapped[str] = mapped_column(
        String(50), nullable=False, unique=True, index=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["ManifestRevision"]] = relationship(
        back_populates="manifest",
        order_by="ManifestRevision.revision_no",
    )


class ManifestRevision(Base):
    """Manifest revision table."""

    __tablename__ = "manifest_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    manifest_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("manifest.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Content summary (JSON list of items)
    items: Mapped[list[dict] | None] = mapped_column(JSONB, nullable=True)

    # Associated shipment
    shipment_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("shipment.id"),
        nullable=True,
    )

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    manifest: Mapped["Manifest"] = relationship(back_populates="revisions")


class Document(Base):
    """
    Document identity table.

    Documents are files attached to orders, shipments, etc.
    Actual file storage is in S3; this tracks metadata.
    """

    __tablename__ = "document"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    restricted_to_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        index=True,
    )

    # Relationships
    revisions: Mapped[list["DocumentRevision"]] = relationship(
        back_populates="document",
        order_by="DocumentRevision.revision_no",
    )


class DocumentRevision(Base):
    """Document revision table."""

    __tablename__ = "document_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    document_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("document.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Document metadata
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    content_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    size_bytes: Mapped[int | None] = mapped_column(nullable=True)

    # S3 location
    s3_bucket: Mapped[str | None] = mapped_column(String(255), nullable=True)
    s3_key: Mapped[str | None] = mapped_column(String(1024), nullable=True)

    # Document type (e.g., "requisition", "consent", "report")
    document_type: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    document: Mapped["Document"] = relationship(back_populates="revisions")


# =============================================================================
# Shipment Tracking (FedEx integration)
# =============================================================================


class ShipmentTrackingSnapshot(Base):
    """
    Append-only snapshots of FedEx tracking data for shipments.

    Each time we poll FedEx for tracking updates, we store a new snapshot
    containing the full tracking state at that point in time.
    """

    __tablename__ = "shipment_tracking_snapshot"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    shipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("shipment.id"),
        nullable=False,
        index=True,
    )

    tracking_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)

    # Tracking status
    delivery_status: Mapped[str] = mapped_column(String(50), nullable=False)

    # Origin location
    origin_city: Mapped[str | None] = mapped_column(String(100), nullable=True)
    origin_state: Mapped[str | None] = mapped_column(String(10), nullable=True)
    origin_country: Mapped[str | None] = mapped_column(String(10), nullable=True)

    # Destination location
    destination_city: Mapped[str | None] = mapped_column(String(100), nullable=True)
    destination_state: Mapped[str | None] = mapped_column(String(10), nullable=True)
    destination_country: Mapped[str | None] = mapped_column(String(10), nullable=True)

    # Key timestamps
    ship_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    pickup_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    delivery_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Transit time in seconds
    transit_time_seconds: Mapped[int | None] = mapped_column(nullable=True)

    # Service type
    service_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    service_description: Mapped[str | None] = mapped_column(String(200), nullable=True)

    # Store all tracking events as JSON for complete history
    tracking_events: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Raw FedEx API response (for debugging/audit)
    raw_response: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Error message if tracking failed
    error_message: Mapped[str | None] = mapped_column(nullable=True)

    # When this snapshot was captured
    captured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )


class ShipmentTrackingEvent(Base):
    """
    Individual tracking events from FedEx.

    Stored in append-only fashion - each event is recorded once
    and never modified or deleted.
    """

    __tablename__ = "shipment_tracking_event"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    shipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("shipment.id"),
        nullable=False,
        index=True,
    )

    tracking_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)

    # Event details
    event_timestamp: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    event_type: Mapped[str] = mapped_column(String(50), nullable=False)
    event_description: Mapped[str] = mapped_column(String(500), nullable=False)

    # Event location
    city: Mapped[str | None] = mapped_column(String(100), nullable=True)
    state: Mapped[str | None] = mapped_column(String(10), nullable=True)
    country_code: Mapped[str | None] = mapped_column(String(10), nullable=True)

    # Exception info (for delivery issues)
    exception_code: Mapped[str | None] = mapped_column(String(20), nullable=True)
    exception_description: Mapped[str | None] = mapped_column(String(500), nullable=True)

    # When we captured this event
    captured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    # Unique constraint to prevent duplicate events
    # (same shipment + event type + timestamp)
    __table_args__ = (
        # Index for efficient lookups
        # Note: We don't add a unique constraint because FedEx
        # might return slightly different data for same event
    )
