"""LSMC Hub - Assay Workflow Models (FulfillmentRun, FulfillmentRunRevision, FulfillmentOutput, ResultsSet)."""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class FulfillmentRunState(StrEnum):
    """Canonical assay lifecycle states (10 states, no skipping)."""

    DRAFT = "DRAFT"
    ORDERED = "ORDERED"
    RECEIVED = "RECEIVED"
    ACCESSIONED = "ACCESSIONED"
    IN_PROGRESS = "IN_PROGRESS"
    QC_HOLD = "QC_HOLD"
    FAILED = "FAILED"
    RESULTED = "RESULTED"
    AMENDED = "AMENDED"
    CANCELLED = "CANCELLED"


class FulfillmentRun(Base):
    """
    FulfillmentRun identity table.

    Represents a single assay execution instance within a TestOrder.
    One TestOrder may have multiple AssayRuns (one per fulfillment_route_code in fulfillment_route_codes).
    """

    __tablename__ = "assay_run"
    __table_args__ = (
        UniqueConstraint(
            "test_order_id", "fulfillment_route_code", name="uq_assay_run_test_order_assay_code"
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    order_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("order.id"),
        nullable=False,
        index=True,
    )

    test_order_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("test_order.id"),
        nullable=False,
        index=True,
    )

    # The specific assay code being run (from TestOrderRevision.fulfillment_route_codes)
    fulfillment_route_code: Mapped[str] = mapped_column(String(100), nullable=False, index=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    revisions: Mapped[list["FulfillmentRunRevision"]] = relationship(
        back_populates="assay_run",
        order_by="FulfillmentRunRevision.revision_no",
    )
    results: Mapped[list["FulfillmentOutput"]] = relationship(
        back_populates="assay_run",
        foreign_keys="FulfillmentOutput.fulfillment_run_id",
    )


class FulfillmentRunRevision(Base):
    """
    FulfillmentRunRevision table (append-only snapshots).

    Contains assay run state that changes over the lifecycle.
    """

    __tablename__ = "assay_run_revision"
    __table_args__ = (
        UniqueConstraint("fulfillment_run_id", "revision_no", name="uq_assay_run_revision_no"),
    )

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    fulfillment_run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("assay_run.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    # Canonical state (one of FulfillmentRunState values)
    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=FulfillmentRunState.DRAFT.value
    )

    # Set when entering ACCESSIONED state
    accession_id: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # QC Hold tracking
    qc_hold_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    # True only when transitioning from QC_HOLD → RESULTED with explicit override
    qc_override: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # General notes
    note: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Reference to the result (set when entering RESULTED or AMENDED)
    result_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("fulfillment_output.id"),
        nullable=True,
    )

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    assay_run: Mapped["FulfillmentRun"] = relationship(back_populates="revisions")


class FulfillmentOutput(Base):
    """
    FulfillmentOutput table (immutable).

    Stores structured results for an assay run. Once created, never updated.
    Amendments create new FulfillmentOutput records referencing the original.
    """

    __tablename__ = "fulfillment_output"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    fulfillment_run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("assay_run.id"),
        nullable=False,
        index=True,
    )

    # Version number (1, 2, 3...) for this assay run's results
    version_no: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    # Structured results payload (JSONB for flexibility)
    result_payload: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # References to artifacts (array of UUIDs; existence enforced in service layer)
    artifact_ids: Mapped[list[uuid.UUID] | None] = mapped_column(
        ARRAY(UUID(as_uuid=True)), nullable=True
    )

    # Amendment tracking
    amends_result_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("fulfillment_output.id"),
        nullable=True,
    )
    amend_reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    assay_run: Mapped["FulfillmentRun"] = relationship(
        back_populates="results",
        foreign_keys=[fulfillment_run_id],
    )
    amended_from: Mapped["FulfillmentOutput | None"] = relationship(
        "FulfillmentOutput",
        remote_side=[id],
        foreign_keys=[amends_result_id],
    )


class ResultsSet(Base):
    """
    ResultsSet table.

    Groups assay results for an order. Created when first assay enters RESULTED.
    External users can only view results sets that have been published.
    """

    __tablename__ = "results_set"
    __table_args__ = (
        UniqueConstraint("tenant_id", "order_id", name="uq_results_set_tenant_order"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    order_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("order.id"),
        nullable=False,
        index=True,
    )

    # Publication tracking
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    published_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Notes
    note: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    assays: Mapped[list["ResultsSetAssay"]] = relationship(
        back_populates="results_set",
    )


class ResultsSetAssay(Base):
    """
    ResultsSetAssay join table.

    Links ResultsSet to FulfillmentRun (many-to-many).
    """

    __tablename__ = "results_set_assay"
    __table_args__ = (
        UniqueConstraint("results_set_id", "fulfillment_run_id", name="uq_results_set_assay"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    results_set_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("results_set.id"),
        nullable=False,
        index=True,
    )

    fulfillment_run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("assay_run.id"),
        nullable=False,
        index=True,
    )

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    # Relationships
    results_set: Mapped["ResultsSet"] = relationship(back_populates="fulfillment_routes")
    assay_run: Mapped["FulfillmentRun"] = relationship()
