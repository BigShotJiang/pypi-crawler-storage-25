"""LSMC Hub - Theme/Skin Configuration Models.

Provides configurable UI theming per tenant:
- SkinConfiguration: Theme identity
- SkinConfigurationRevision: Theme settings revisions
"""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class BaseTheme(StrEnum):
    """Pre-built base theme variants."""

    DEFAULT = "default"  # LSMC dark industrial
    LSMC = "lsmc"  # Brand palette
    BOLD = "bold"  # High-contrast, vibrant
    PROFESSIONAL = "professional"  # Clean, corporate
    MINIMAL = "minimal"  # Light, simple


class SkinConfiguration(Base):
    """Skin Configuration identity table.

    Stores theme configurations per tenant.
    tenant_id=NULL indicates the system default theme.
    """

    __tablename__ = "skin_configuration"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=True,  # NULL = default system theme
        index=True,
    )

    skin_code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Relationships
    revisions: Mapped[list["SkinConfigurationRevision"]] = relationship(
        back_populates="skin",
        order_by="SkinConfigurationRevision.revision_no",
    )


class SkinConfigurationRevision(Base):
    """Skin Configuration revision table (append-only).

    Contains theme customization data including:
    - CSS variable overrides
    - Custom CSS (validated)
    - Font configuration
    - Component-specific styles
    """

    __tablename__ = "skin_configuration_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    skin_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("skin_configuration.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Base theme to extend
    base_theme: Mapped[str] = mapped_column(
        String(50), nullable=False, default=BaseTheme.DEFAULT.value
    )

    # CSS variable overrides (e.g., {"--bg-primary": "#1a1a2e", "--accent-blue": "#0ff"})
    css_variables: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Additional validated custom CSS
    custom_css: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Font configuration (e.g., {"family": "Inter", "heading_weight": 700})
    font_config: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Component-specific styling overrides
    component_styles: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Relationships
    skin: Mapped["SkinConfiguration"] = relationship(back_populates="revisions")
