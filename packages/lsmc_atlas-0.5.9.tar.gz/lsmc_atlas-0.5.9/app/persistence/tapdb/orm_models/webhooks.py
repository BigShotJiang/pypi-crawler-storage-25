"""LSMC Hub - Webhook Models.

Webhook subscription and delivery tracking for external integrations.
"""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.persistence.tapdb.orm_models.base import Base


class WebhookEventType(StrEnum):
    """Webhook event types."""

    ORDER_STATUS_CHANGED = "order.status.changed"
    ORDER_CREATED = "order.created"
    ARTIFACT_AVAILABLE = "artifact.available"
    RELEASE_PACKAGE_CREATED = "release.package.created"
    RELEASE_PACKAGE_RELEASED = "release.package.released"
    EXCEPTION_CREATED = "exception.created"
    EXCEPTION_RESOLVED = "exception.resolved"
    EXTERNAL_OBJECT_STATUS_CHANGED = "external_object.status.changed"
    EXTERNAL_OBJECT_DELETED = "external_object.deleted"
    ASSAY_RUN_STATUS_CHANGED = "fulfillment_run.status.changed"
    RESULTS_SET_PUBLISHED = "results_set.published"


class WebhookSubscription(Base):
    """
    Webhook subscription table (identity).

    Represents a webhook endpoint that should receive events.
    """

    __tablename__ = "webhook_subscription"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    subscription_name: Mapped[str] = mapped_column(String(100), nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    __table_args__ = (Index("ix_webhook_subscription_tenant", "tenant_id"),)


class WebhookSubscriptionRevision(Base):
    """
    Webhook subscription revision table (append-only).

    Tracks changes to webhook subscriptions.
    """

    __tablename__ = "webhook_subscription_revision"

    subscription_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("webhook_subscription.id"),
        primary_key=True,
    )

    revision_no: Mapped[int] = mapped_column(primary_key=True)

    url: Mapped[str] = mapped_column(String(500), nullable=False)

    secret: Mapped[str] = mapped_column(String(100), nullable=False)  # For HMAC signature

    event_types: Mapped[list[str]] = mapped_column(
        JSONB, nullable=False
    )  # List of event types to subscribe to

    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    headers: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Custom headers to send

    timeout_seconds: Mapped[int] = mapped_column(nullable=False, default=30)

    max_retries: Mapped[int] = mapped_column(nullable=False, default=3)

    note: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    __table_args__ = (
        Index("ix_webhook_subscription_revision_subscription", "subscription_id"),
        Index("ix_webhook_subscription_revision_active", "is_active"),
    )


class WebhookDeliveryLog(Base):
    """
    Webhook delivery log table (append-only).

    Tracks all webhook delivery attempts for audit and debugging.
    """

    __tablename__ = "webhook_delivery_log"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    subscription_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("webhook_subscription.id"),
        nullable=False,
        index=True,
    )

    event_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True)

    event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False
    )  # ID of the triggering event

    payload: Mapped[dict] = mapped_column(JSONB, nullable=False)

    url: Mapped[str] = mapped_column(String(500), nullable=False)

    attempt_number: Mapped[int] = mapped_column(nullable=False, default=1)

    http_status: Mapped[int | None] = mapped_column(nullable=True)

    response_body: Mapped[str | None] = mapped_column(Text, nullable=True)

    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    delivered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )

    __table_args__ = (
        Index("ix_webhook_delivery_log_tenant", "tenant_id"),
        Index("ix_webhook_delivery_log_subscription", "subscription_id"),
        Index("ix_webhook_delivery_log_event_type", "event_type"),
        Index("ix_webhook_delivery_log_delivered_at", "delivered_at"),
    )
