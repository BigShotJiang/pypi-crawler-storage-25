"""LSMC Hub - Core Identity Models (Organization, Site, UserProfile)."""

import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, ForeignKey, String, text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base

if TYPE_CHECKING:
    pass


class Organization(Base):
    """
    Organization identity table.

    Organizations are the tenant boundary - all data is scoped to an organization.
    This table is immutable after creation.
    """

    __tablename__ = "organization"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    sites: Mapped[list["Site"]] = relationship(back_populates="organization")
    revisions: Mapped[list["OrganizationRevision"]] = relationship(
        back_populates="organization",
        order_by="OrganizationRevision.revision_no",
    )


class OrganizationRevision(Base):
    """
    Organization revision table (append-only snapshots).

    Contains the actual organization data that can change over time.
    """

    __tablename__ = "organization_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    organization_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Organization data
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    org_type: Mapped[str] = mapped_column(
        String(50), nullable=False, default="clinic"
    )  # clinic, lab, research, etc.

    # Contact info
    contact_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    contact_phone: Mapped[str | None] = mapped_column(String(50), nullable=True)

    # Address (stored as JSON for flexibility)
    address: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Status
    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    organization: Mapped["Organization"] = relationship(back_populates="revisions")


class Site(Base):
    """
    Site identity table.

    Sites are physical locations within an organization (e.g., clinic branches).
    """

    __tablename__ = "site"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    organization_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
    )

    # Relationships
    organization: Mapped["Organization"] = relationship(back_populates="sites")
    revisions: Mapped[list["SiteRevision"]] = relationship(
        back_populates="site",
        order_by="SiteRevision.revision_no",
    )


class SiteRevision(Base):
    """Site revision table (append-only snapshots)."""

    __tablename__ = "site_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    site_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("site.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(nullable=False, default=1)

    # Site data
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    site_code: Mapped[str | None] = mapped_column(String(50), nullable=True)
    address: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    contact_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    contact_phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(nullable=True)

    # Relationships
    site: Mapped["Site"] = relationship(back_populates="revisions")


class UserProfile(Base):
    """
    User profile table.

    Maps Cognito subject IDs to tenant and roles within LSMC Hub.
    """

    __tablename__ = "user_profile"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    # Cognito mapping
    cognito_sub: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)

    # Tenant assignment
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=False,
        index=True,
    )

    # User info (may be synced from Cognito)
    email: Mapped[str] = mapped_column(String(255), nullable=False)
    name: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Roles: EXTERNAL_USER, INTERNAL_USER, ADMIN
    roles: Mapped[list[str]] = mapped_column(ARRAY(String), nullable=False, default=list)

    # Status
    is_active: Mapped[bool] = mapped_column(nullable=False, default=True)

    # User preferences (JSONB for flexibility)
    # Stores: datetime_format ("standard" | "precise"), etc.
    preferences: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Audit
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
