"""LSMC Hub - User Group Models.

Provides group-based access management:
- UserGroup: Group identity (CUSTOMER, LSMC_STAFF, ADMIN)
- UserGroupRevision: Group metadata revisions
- UserGroupMembership: Many-to-many user-to-group assignment
"""

import uuid
from datetime import datetime
from enum import StrEnum

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.persistence.tapdb.orm_models.base import Base


class AccessScope(StrEnum):
    """Access scope for user groups."""

    TENANT = "TENANT"  # Access limited to own tenant/organization
    CROSS_TENANT = "CROSS_TENANT"  # Can access multiple tenants (LSMC staff)
    SYSTEM = "SYSTEM"  # Full system access (admins)


class SystemGroup(StrEnum):
    """Pre-defined system group codes."""

    CUSTOMER = "CUSTOMER"
    LSMC_STAFF = "LSMC_STAFF"
    ADMIN = "ADMIN"
    API_ACCESS = "API_ACCESS"  # Users who can create personal API tokens


class UserGroup(Base):
    """User Group identity table.

    Groups determine system access scope:
    - CUSTOMER: Access limited to own tenant/organization records only
    - LSMC_STAFF: Cross-tenant access for intake operations
    - ADMIN: Full system access including admin tools
    """

    __tablename__ = "user_group"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    tenant_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization.id"),
        nullable=True,  # NULL = system-wide group
        index=True,
    )

    group_code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Relationships
    revisions: Mapped[list["UserGroupRevision"]] = relationship(
        back_populates="group",
        order_by="UserGroupRevision.revision_no",
    )
    memberships: Mapped[list["UserGroupMembership"]] = relationship(
        back_populates="group",
    )


class UserGroupRevision(Base):
    """User Group revision table (append-only)."""

    __tablename__ = "user_group_revision"

    revision_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    group_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("user_group.id"),
        nullable=False,
        index=True,
    )

    revision_no: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    access_scope: Mapped[str] = mapped_column(
        String(50), nullable=False, default=AccessScope.TENANT.value
    )

    # Default roles assigned to group members
    default_roles: Mapped[list[str] | None] = mapped_column(JSONB, nullable=True)

    is_system_group: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Relationships
    group: Mapped["UserGroup"] = relationship(back_populates="revisions")


class UserGroupMembership(Base):
    """User Group Membership - many-to-many between users and groups.

    Note: Uses append-only pattern. To remove a user from a group,
    set is_active=False and record deactivated_at/deactivated_by.
    """

    __tablename__ = "user_group_membership"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False, index=True
    )  # Cognito sub

    group_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("user_group.id"),
        nullable=False,
        index=True,
    )

    joined_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    added_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    deactivated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    deactivated_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    # Relationships
    group: Mapped["UserGroup"] = relationship(back_populates="memberships")
