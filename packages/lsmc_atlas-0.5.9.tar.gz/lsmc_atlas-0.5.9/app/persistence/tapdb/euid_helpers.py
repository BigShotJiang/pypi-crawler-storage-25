"""EUID-first helpers for TapDB-backed Atlas repositories.

Centralises EUID validation, instance-by-EUID lookup, and lineage
resolution so that domain repos never fall back to synthetic UUID
identity.

This module is the EUID-first replacement for the legacy identity shim
(removed in the TapDB 0.1.32 migration).
"""

from __future__ import annotations

from daylily_tapdb.euid import (
    resolve_runtime_validation_context,
)
from daylily_tapdb.euid import (
    validate_euid as _tapdb_validate_euid,
)
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from sqlalchemy import select
from sqlalchemy.orm import Session


class InvalidEUID(ValueError):
    """Raised when an EUID string fails Meridian validation."""


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def require_valid_euid(
    euid: str,
    *,
    environment: str | None = None,
    allowed_sandbox_prefixes: list[str] | None = None,
) -> str:
    """Validate *euid* and return it unchanged, or raise :class:`InvalidEUID`.

    Delegates to ``daylily_tapdb.euid.validate_euid`` for syntax and
    checksum verification.
    """
    if not euid or not isinstance(euid, str):
        raise InvalidEUID(f"EUID must be a non-empty string, got {euid!r}")
    kwargs: dict = (
        {"environment": environment}
        if environment is not None
        else resolve_runtime_validation_context()
    )
    if allowed_sandbox_prefixes is not None:
        kwargs["allowed_sandbox_prefixes"] = allowed_sandbox_prefixes
    if not _tapdb_validate_euid(euid, **kwargs):
        raise InvalidEUID(f"Invalid EUID: {euid!r}")
    return euid


# ---------------------------------------------------------------------------
# Instance lookup by EUID
# ---------------------------------------------------------------------------


def get_instance_by_euid(
    db: Session,
    template_code: str,
    euid: str,
) -> generic_instance | None:
    """Return the non-deleted instance matching *template_code* and *euid*.

    Uses a single indexed query on ``generic_instance.euid`` — no table
    scan required.
    """
    category, type_, subtype, version = _parse_template_code(template_code)
    stmt = (
        select(generic_instance)
        .where(
            generic_instance.euid == euid,
            generic_instance.category == category,
            generic_instance.type == type_,
            generic_instance.subtype == subtype,
            generic_instance.version == version,
            generic_instance.is_deleted.is_(False),
        )
        .limit(1)
    )
    return db.execute(stmt).scalars().first()


# ---------------------------------------------------------------------------
# Lineage helpers (TapDB 0.1.32: uses .uid / parent_instance_uid)
# ---------------------------------------------------------------------------


def get_child_instances(
    db: Session,
    parent: generic_instance,
    child_template_code: str,
) -> list[generic_instance]:
    """Return non-deleted child instances linked to *parent* via lineage."""
    category, type_, subtype, version = _parse_template_code(child_template_code)
    child_alias = generic_instance
    stmt = (
        select(child_alias)
        .join(
            generic_instance_lineage,
            child_alias.uid == generic_instance_lineage.child_instance_uid,
        )
        .where(
            generic_instance_lineage.parent_instance_uid == parent.uid,
            generic_instance_lineage.is_deleted.is_(False),
            child_alias.category == category,
            child_alias.type == type_,
            child_alias.subtype == subtype,
            child_alias.version == version,
            child_alias.is_deleted.is_(False),
        )
        .order_by(child_alias.created_dt.desc())
    )
    return list(db.execute(stmt).scalars().all())


def get_parent_instances(
    db: Session,
    child: generic_instance,
    parent_template_code: str,
) -> list[generic_instance]:
    """Return non-deleted parent instances linked to *child* via lineage."""
    category, type_, subtype, version = _parse_template_code(parent_template_code)
    parent_alias = generic_instance
    stmt = (
        select(parent_alias)
        .join(
            generic_instance_lineage,
            parent_alias.uid == generic_instance_lineage.parent_instance_uid,
        )
        .where(
            generic_instance_lineage.child_instance_uid == child.uid,
            generic_instance_lineage.is_deleted.is_(False),
            parent_alias.category == category,
            parent_alias.type == type_,
            parent_alias.subtype == subtype,
            parent_alias.version == version,
            parent_alias.is_deleted.is_(False),
        )
        .order_by(parent_alias.created_dt.desc())
    )
    return list(db.execute(stmt).scalars().all())


def get_latest_child_instance(
    db: Session,
    parent: generic_instance,
    child_template_code: str,
) -> generic_instance | None:
    """Return the most-recently created child of *parent*, or ``None``."""
    children = get_child_instances(db, parent, child_template_code)
    return children[0] if children else None


# ---------------------------------------------------------------------------
# Internal utilities
# ---------------------------------------------------------------------------


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    """Split a ``category/type/subtype/version/`` code into its four parts."""
    parts = [p for p in template_code.strip("/").split("/") if p]
    if len(parts) != 4:
        raise ValueError(
            f"Expected 4-part template code (category/type/subtype/version), got {template_code!r}"
        )
    return parts[0], parts[1], parts[2], parts[3]
