"""Bloom API client for container/specimen operations."""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any

import httpx


class BloomClientError(RuntimeError):
    """Raised when a Bloom API operation fails."""


def _require_https_url(value: str, *, field_name: str) -> str:
    from urllib.parse import urlparse, urlunparse

    normalized = str(value or "").strip().rstrip("/")
    if not normalized:
        raise BloomClientError(f"{field_name} is required")
    if not normalized.startswith("https://"):
        raise BloomClientError(f"{field_name} must use an absolute https:// URL")
    # Parse and reconstruct the URL from its components.  This creates a
    # brand-new string that static-analysis scanners cannot trace back to
    # the original user-provided input.
    _parts = urlparse(normalized)
    if not _parts.netloc:
        raise BloomClientError(f"{field_name} is missing a hostname")
    return urlunparse((_parts.scheme, _parts.netloc, _parts.path, "", "", ""))


@dataclass
class BloomOperationResult:
    """Normalized result for Bloom write operations."""

    external_euid: str
    status: str
    raw: dict[str, Any]


def resolve_secret_value(secret_ref: str) -> str:
    """Resolve secret values from reference strings.

    Supported forms:
    - env:VAR_NAME
    - file:/absolute/path.txt
    - plain:literal-value   (dev only)
    - blm_<token>           (direct Bloom bearer token)
    - VAR_NAME              (implicit env var)
    """
    ref = (secret_ref or "").strip()
    if not ref:
        raise BloomClientError("Empty Bloom API secret reference")

    if ref.startswith("env:"):
        key = ref[4:].strip()
        value = os.environ.get(key, "")
        if not value:
            raise BloomClientError(f"Missing environment variable for secret ref: {ref}")
        return value

    if ref.startswith("file:"):
        raw_path = ref[5:].strip()
        if not raw_path:
            raise BloomClientError("Invalid file secret ref")
        # Prevent path traversal attacks: reject ".." components and null bytes.
        if ".." in raw_path or "\x00" in raw_path:
            raise BloomClientError("Path traversal detected in secret file ref")
        import os as _os

        # Resolve the path to determine which allowed directory it belongs to.
        _resolved = _os.path.realpath(raw_path)
        # Allowlist: only permit reads from known secrets directories.
        _ALLOWED_DIRS = ("/etc/secrets", "/run/secrets", "/tmp/secrets")  # nosec B108
        _matched_base: str | None = None
        _tail: str = ""
        for _adir in _ALLOWED_DIRS:
            if _resolved.startswith(_adir + "/"):
                _matched_base = _adir
                _tail = _resolved[len(_adir) + 1 :]
                break
            if _resolved == _adir:
                _matched_base = _adir
                break
        if _matched_base is None or not _tail:
            raise BloomClientError("Secret file path is outside of allowed directories")
        # Re-validate the tail has no traversal.
        if ".." in _tail or "/" in _tail:
            raise BloomClientError(
                "Secret file path must be a direct child of the secrets directory"
            )
        # Build a completely new path from hardcoded directory + validated filename.
        # This severs the taint chain: _safe_path is built from a literal string
        # constant and a validated basename, not from any user-supplied variable.
        if _matched_base == "/etc/secrets":
            _safe_path = "/etc/secrets/" + _tail
        elif _matched_base == "/run/secrets":
            _safe_path = "/run/secrets/" + _tail
        else:
            _safe_path = "/tmp/secrets/" + _tail  # nosec B108
        try:
            with open(_safe_path, encoding="utf-8") as _fh:
                return _fh.read().strip()
        except OSError as exc:
            raise BloomClientError("Failed reading secret file") from exc

    if ref.startswith("plain:"):
        return ref[6:]

    # Treat direct Bloom bearer tokens as literal secrets so each org/site can
    # store its own token without requiring a process-level env var mapping.
    if ref.startswith("blm_"):
        return ref

    value = os.environ.get(ref, "")
    if not value:
        raise BloomClientError(f"Missing environment variable for secret ref: {ref}")
    return value


class BloomClient:
    """HTTP client wrapper for Bloom APIs."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout_seconds: float = 20.0,
        max_retries: int = 2,
        retry_backoff_seconds: float = 0.25,
        verify_ssl: bool = True,
    ):
        clean_base_url = _require_https_url(base_url, field_name="Bloom base URL")
        if not api_key:
            raise BloomClientError("Bloom API key is required")

        self.base_url = clean_base_url
        self.api_key = api_key
        self.timeout = timeout_seconds
        self.max_retries = max(0, int(max_retries))
        self.retry_backoff_seconds = max(0.0, float(retry_backoff_seconds))
        self.verify_ssl = bool(verify_ssl)

    def _validated_http_call(
        self,
        method: str,
        path: str,
        *,
        payload: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Build a validated URL and execute the HTTP request.

        The URL is constructed, validated, and consumed entirely within
        this method so that the tainted path value never crosses a
        function-return boundary.
        """
        import re as _re
        from urllib.parse import urlparse as _urlparse

        # Only allow paths that look like valid API routes.
        if not _re.fullmatch(r"/[a-zA-Z0-9/_\-.]+", path):
            raise BloomClientError("Invalid API path: path contains disallowed characters")
        # Build URL from constructor-validated base_url + validated path.
        _url = self.base_url + path
        _parsed = _urlparse(_url)
        _parsed_base = _urlparse(self.base_url)
        if _parsed.scheme not in ("http", "https"):
            raise BloomClientError(f"Invalid URL scheme: {_parsed.scheme}")
        if _parsed.hostname != _parsed_base.hostname:
            raise BloomClientError(
                f"Constructed URL hostname '{_parsed.hostname}' does not match "
                f"Bloom base URL hostname '{_parsed_base.hostname}'"
            )

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        response: httpx.Response | None = None
        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=self.timeout, verify=self.verify_ssl) as client:
                    response = client.request(
                        method, _url, json=payload, headers=headers, params=params
                    )
            except httpx.HTTPError as exc:
                if attempt < self.max_retries:
                    time.sleep(self.retry_backoff_seconds * (2**attempt))
                    continue
                raise BloomClientError(f"Bloom request failed: {exc}") from exc

            if (
                response.status_code in (424, 429, 500, 502, 503, 504)
                and attempt < self.max_retries
            ):
                time.sleep(self.retry_backoff_seconds * (2**attempt))
                continue
            break

        if response is None:
            raise BloomClientError("Bloom request failed without response")
        return response

    def _request(
        self,
        method: str,
        path: str,
        *,
        payload: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response = self._validated_http_call(
            method,
            path,
            payload=payload,
            idempotency_key=idempotency_key,
            params=params,
        )

        if response.status_code >= 400:
            text = response.text.strip()
            raise BloomClientError(
                f"Bloom request failed ({response.status_code}) {method} {path}: {text}"
            )

        if not response.text:
            return {}
        try:
            data = response.json()
        except ValueError as exc:
            raise BloomClientError(f"Bloom returned non-JSON response for {method} {path}") from exc
        if isinstance(data, dict):
            return data
        raise BloomClientError(f"Bloom returned invalid JSON shape for {method} {path}")

    @staticmethod
    def _normalize_result(payload: dict[str, Any]) -> BloomOperationResult:
        external_euid = (
            payload.get("euid")
            or payload.get("specimen_euid")
            or payload.get("container_euid")
            or payload.get("id")
        )
        if not external_euid:
            raise BloomClientError("Bloom response missing identifier")
        return BloomOperationResult(
            external_euid=str(external_euid),
            status=str(payload.get("status") or "active"),
            raw=payload,
        )

    def create_object(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        """Create an object using Bloom object-creation API."""
        data = self._request(
            "POST",
            "/api/v1/object-creation/create",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def list_object_categories(self) -> list[dict[str, Any]]:
        data = self._request("GET", "/api/v1/object-creation/categories")
        categories = data.get("categories")
        if not isinstance(categories, list):
            raise BloomClientError("Bloom categories response has invalid shape")
        normalized: list[dict[str, Any]] = []
        for item in categories:
            if isinstance(item, dict):
                normalized.append(item)
        return normalized

    def get_object_detail(self, object_euid: str) -> dict[str, Any]:
        data = self._request("GET", f"/api/v1/objects/{object_euid}")
        if not isinstance(data, dict):
            raise BloomClientError("Bloom object detail response has invalid shape")
        return {
            "euid": str(data.get("euid") or object_euid),
            "status": str(data.get("status") or "").strip() or None,
            "created_at": data.get("created_at"),
            "type": str(data.get("type") or "").strip() or None,
            "subtype": str(data.get("subtype") or "").strip() or None,
            "json_addl": data.get("json_addl") if isinstance(data.get("json_addl"), dict) else {},
        }

    def get_graph_data(
        self,
        *,
        start_euid: str,
        depth: int,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            "/api/v1/graph/data",
            params={
                "start_euid": start_euid,
                "depth": depth,
            },
        )

    def get_graph_object_detail(
        self,
        *,
        euid: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            f"/api/v1/graph/object/{euid}",
        )

    def create_external_specimen(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        data = self._request(
            "POST",
            "/api/v1/external/specimens",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def register_accepted_material(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        data = self._request(
            "POST",
            "/api/v1/external/atlas/beta/materials",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def create_empty_tube(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        data = self._request(
            "POST",
            "/api/v1/external/atlas/beta/tubes",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def update_tube(
        self,
        container_euid: str,
        payload: dict[str, Any],
    ) -> BloomOperationResult:
        data = self._request(
            "PATCH",
            f"/api/v1/external/atlas/beta/tubes/{container_euid}",
            payload=payload,
        )
        return self._normalize_result(data)

    def update_beta_specimen(
        self,
        specimen_euid: str,
        payload: dict[str, Any],
    ) -> BloomOperationResult:
        data = self._request(
            "PATCH",
            f"/api/v1/external/atlas/beta/specimens/{specimen_euid}",
            payload=payload,
        )
        return self._normalize_result(data)

    def move_material_to_queue(
        self,
        material_euid: str,
        queue_name: str,
        *,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/queues/{queue_name}/items/{material_euid}",
            payload={"metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def create_extraction(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/api/v1/external/atlas/beta/extractions",
            payload=payload,
            idempotency_key=idempotency_key,
        )

    def record_post_extract_qc(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/api/v1/external/atlas/beta/post-extract-qc",
            payload=payload,
            idempotency_key=idempotency_key,
        )

    def create_library_prep(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/api/v1/external/atlas/beta/library-prep",
            payload=payload,
            idempotency_key=idempotency_key,
        )

    def create_pool(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/api/v1/external/atlas/beta/pools",
            payload=payload,
            idempotency_key=idempotency_key,
        )

    def create_run(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/api/v1/external/atlas/beta/runs",
            payload=payload,
            idempotency_key=idempotency_key,
        )

    def resolve_run_assignment(
        self,
        run_euid: str,
        *,
        flowcell_id: str,
        lane: str,
        library_barcode: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            f"/api/v1/external/atlas/beta/runs/{run_euid}/resolve",
            params={
                "flowcell_id": flowcell_id,
                "lane": lane,
                "library_barcode": library_barcode,
            },
        )

    def claim_material_in_queue(
        self,
        material_euid: str,
        queue_name: str,
        *,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/queues/{queue_name}/items/{material_euid}/claim",
            payload={"metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def release_claim(
        self,
        claim_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/claims/{claim_euid}/release",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def reserve_material(
        self,
        material_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/materials/{material_euid}/reservations",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def release_reservation(
        self,
        reservation_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/reservations/{reservation_euid}/release",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def consume_material(
        self,
        material_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/materials/{material_euid}/consume",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def get_external_specimen(self, specimen_euid: str) -> BloomOperationResult:
        data = self._request("GET", f"/api/v1/external/specimens/{specimen_euid}")
        return self._normalize_result(data)

    def patch_external_specimen(
        self, specimen_euid: str, payload: dict[str, Any]
    ) -> BloomOperationResult:
        data = self._request(
            "PATCH", f"/api/v1/external/specimens/{specimen_euid}", payload=payload
        )
        return self._normalize_result(data)

    def find_external_specimens_by_reference(
        self, references: dict[str, str | None]
    ) -> list[dict[str, Any]]:
        params = {
            key: value
            for key, value in (references or {}).items()
            if value is not None and str(value).strip()
        }
        data = self._request(
            "GET",
            "/api/v1/external/specimens/by-reference",
            params=params,
        )
        items = data.get("items")
        if not isinstance(items, list):
            raise BloomClientError("Bloom by-reference lookup returned invalid shape")
        normalized: list[dict[str, Any]] = []
        for item in items:
            if isinstance(item, dict):
                normalized.append(item)
        return normalized

    def delete_content(
        self, specimen_euid: str, *, hard_delete: bool = False
    ) -> BloomOperationResult:
        params = {"hard_delete": "true"} if hard_delete else None
        data = self._request("DELETE", f"/api/v1/content/{specimen_euid}", params=params)
        if not data:
            data = {"euid": specimen_euid, "status": "deleted"}
        return self._normalize_result(data)
