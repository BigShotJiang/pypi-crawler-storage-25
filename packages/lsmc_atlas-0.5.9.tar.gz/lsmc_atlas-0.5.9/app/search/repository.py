"""TapDB-backed unified search repository for Atlas."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Any

from daylily_tapdb.models.audit import audit_log
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from sqlalchemy import String, and_, asc, cast, desc, or_, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, aliased

from app.search.contracts import SearchPropertyFilter, SearchQueryRequest, SearchResultItem

logger = logging.getLogger(__name__)

_MISSING = object()


def _normalize_uuid_str(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return str(value)
    try:
        return str(uuid.UUID(str(value)))
    except (TypeError, ValueError):
        return None


def _to_iso(value: Any) -> str | None:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, str):
        candidate = value.strip()
        return candidate or None
    return None


def _dict_value(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _instance_properties(instance: generic_instance) -> dict[str, Any]:
    json_addl = _dict_value(instance.json_addl)
    props = json_addl.get("properties")
    if isinstance(props, dict):
        return dict(props)
    return {}


def _path_get(data: dict[str, Any], path: str) -> Any:
    current: Any = data
    for segment in path.split("."):
        if isinstance(current, dict) and segment in current:
            current = current[segment]
            continue
        return _MISSING
    return current


def _parse_datetime_candidate(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if not isinstance(value, str):
        return None
    raw = value.strip()
    if not raw:
        return None
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(raw)
    except ValueError:
        return None


def _as_comparable(value: Any) -> Any:
    if isinstance(value, (int, float)):
        return value
    dt_value = _parse_datetime_candidate(value)
    if dt_value is not None:
        return dt_value
    if isinstance(value, str):
        stripped = value.strip()
        if stripped:
            try:
                return float(stripped)
            except ValueError:
                return stripped.lower()
    return value


def _match_filter(value: Any, rule: SearchPropertyFilter) -> bool:
    if rule.op == "exists":
        should_exist = bool(rule.value) if rule.value is not None else True
        return (value is not _MISSING) if should_exist else (value is _MISSING)

    if value is _MISSING:
        return False

    expected = rule.value
    if rule.op == "eq":
        return value == expected
    if rule.op == "neq":
        return value != expected
    if rule.op == "contains":
        if isinstance(value, str):
            return str(expected or "").lower() in value.lower()
        if isinstance(value, (list, tuple, set)):
            return expected in value
        return False
    if rule.op == "in":
        if not isinstance(expected, (list, tuple, set)):
            return False
        return value in expected

    left = _as_comparable(value)
    right = _as_comparable(expected)
    try:
        if rule.op == "gte":
            return left >= right
        if rule.op == "lte":
            return left <= right
    except TypeError:
        return False
    return False


def _matches_property_filters(
    metadata: dict[str, Any], property_filters: list[SearchPropertyFilter]
) -> bool:
    for rule in property_filters:
        current = _path_get(metadata, rule.path)
        if not _match_filter(current, rule):
            return False
    return True


def _deep_tenant_id(value: Any) -> str | None:
    if isinstance(value, dict):
        direct = _normalize_uuid_str(value.get("tenant_id"))
        if direct:
            return direct
        props = value.get("properties")
        if isinstance(props, dict):
            nested = _normalize_uuid_str(props.get("tenant_id"))
            if nested:
                return nested
        for nested_value in value.values():
            tenant_id = _deep_tenant_id(nested_value)
            if tenant_id:
                return tenant_id
        return None
    if isinstance(value, list):
        for item in value:
            tenant_id = _deep_tenant_id(item)
            if tenant_id:
                return tenant_id
    return None


def _order_clause(column: Any, direction: str):
    return asc(column) if direction == "asc" else desc(column)


class UnifiedSearchRepository:
    """Repository that queries TapDB generic tables for unified search."""

    def __init__(self, db: Session):
        self.db = db

    def search_instances(
        self,
        request: SearchQueryRequest,
        *,
        tenant_id: uuid.UUID,
        cross_tenant: bool,
        fetch_limit: int,
    ) -> list[SearchResultItem]:
        try:
            stmt = select(generic_instance)
            if not request.include_deleted:
                stmt = stmt.where(generic_instance.is_deleted.is_(False))

            if request.q:
                pattern = f"%{request.q}%"
                stmt = stmt.where(
                    or_(
                        generic_instance.name.ilike(pattern),
                        generic_instance.euid.ilike(pattern),
                        cast(generic_instance.json_addl, String).ilike(pattern),
                    )
                )

            order_column = {
                "created_at": generic_instance.created_dt,
                "modified_at": generic_instance.modified_dt,
                "name": generic_instance.name,
                "euid": generic_instance.euid,
            }[request.sort_field]
            stmt = stmt.order_by(
                _order_clause(order_column, request.sort_dir),
                desc(generic_instance.created_dt),
                desc(generic_instance.uid),
            ).limit(fetch_limit)

            items: list[SearchResultItem] = []
            tenant_scope = str(tenant_id)
            for instance in self.db.execute(stmt).scalars().all():
                properties = _instance_properties(instance)
                instance_tenant = _normalize_uuid_str(properties.get("tenant_id"))
                if not cross_tenant and instance_tenant != tenant_scope:
                    continue

                metadata = {
                    "template_code": (
                        f"{instance.category}/{instance.type}/{instance.subtype}/{instance.version}/"
                    ),
                    "tenant_id": instance_tenant,
                    "properties": properties,
                }
                if not _matches_property_filters(metadata, request.property_filters):
                    continue

                items.append(
                    SearchResultItem(
                        record_type="instance",
                        source_kind="tapdb.generic_instance",
                        uid=instance.uid,
                        euid=instance.euid,
                        name=instance.name or instance.euid or str(instance.uid),
                        created_at=_to_iso(instance.created_dt),
                        modified_at=_to_iso(instance.modified_dt),
                        category=instance.category or "",
                        type=instance.type or "",
                        subtype=instance.subtype or "",
                        version=instance.version or "",
                        is_deleted=bool(instance.is_deleted),
                        metadata=metadata,
                    )
                )
            return items
        except SQLAlchemyError as exc:
            logger.warning("Unified search scope=instance unavailable: %s", exc)
            return []

    def search_templates(
        self,
        request: SearchQueryRequest,
        *,
        fetch_limit: int,
    ) -> list[SearchResultItem]:
        try:
            stmt = select(generic_template)
            if not request.include_deleted:
                stmt = stmt.where(generic_template.is_deleted.is_(False))

            if request.q:
                pattern = f"%{request.q}%"
                stmt = stmt.where(
                    or_(
                        generic_template.name.ilike(pattern),
                        generic_template.euid.ilike(pattern),
                        cast(generic_template.json_addl, String).ilike(pattern),
                    )
                )

            order_column = {
                "created_at": generic_template.created_dt,
                "modified_at": generic_template.modified_dt,
                "name": generic_template.name,
                "euid": generic_template.euid,
            }[request.sort_field]
            stmt = stmt.order_by(
                _order_clause(order_column, request.sort_dir),
                desc(generic_template.created_dt),
                desc(generic_template.uid),
            ).limit(fetch_limit)

            items: list[SearchResultItem] = []
            for template in self.db.execute(stmt).scalars().all():
                metadata = {
                    "instance_prefix": template.instance_prefix,
                    "json_addl": _dict_value(template.json_addl),
                }
                if not _matches_property_filters(metadata, request.property_filters):
                    continue

                items.append(
                    SearchResultItem(
                        record_type="template",
                        source_kind="tapdb.generic_template",
                        uid=template.uid,
                        euid=template.euid,
                        name=template.name or template.euid or str(template.uid),
                        created_at=_to_iso(template.created_dt),
                        modified_at=_to_iso(template.modified_dt),
                        category=template.category or "",
                        type=template.type or "",
                        subtype=template.subtype or "",
                        version=template.version or "",
                        is_deleted=bool(template.is_deleted),
                        metadata=metadata,
                    )
                )
            return items
        except SQLAlchemyError as exc:
            logger.warning("Unified search scope=template unavailable: %s", exc)
            return []

    def search_lineage(
        self,
        request: SearchQueryRequest,
        *,
        tenant_id: uuid.UUID,
        cross_tenant: bool,
        fetch_limit: int,
    ) -> list[SearchResultItem]:
        parent_instance = aliased(generic_instance)
        child_instance = aliased(generic_instance)
        try:
            stmt = (
                select(generic_instance_lineage, parent_instance, child_instance)
                .join(
                    parent_instance,
                    parent_instance.uid == generic_instance_lineage.parent_instance_uid,
                )
                .join(
                    child_instance,
                    child_instance.uid == generic_instance_lineage.child_instance_uid,
                )
            )
            if not request.include_deleted:
                stmt = stmt.where(
                    and_(
                        generic_instance_lineage.is_deleted.is_(False),
                        parent_instance.is_deleted.is_(False),
                        child_instance.is_deleted.is_(False),
                    )
                )

            if request.q:
                pattern = f"%{request.q}%"
                stmt = stmt.where(
                    or_(
                        generic_instance_lineage.name.ilike(pattern),
                        generic_instance_lineage.euid.ilike(pattern),
                        parent_instance.euid.ilike(pattern),
                        child_instance.euid.ilike(pattern),
                        cast(generic_instance_lineage.json_addl, String).ilike(pattern),
                    )
                )

            order_column = {
                "created_at": generic_instance_lineage.created_dt,
                "modified_at": generic_instance_lineage.modified_dt,
                "name": generic_instance_lineage.name,
                "euid": generic_instance_lineage.euid,
            }[request.sort_field]
            stmt = stmt.order_by(
                _order_clause(order_column, request.sort_dir),
                desc(generic_instance_lineage.created_dt),
                desc(generic_instance_lineage.uid),
            ).limit(fetch_limit)

            items: list[SearchResultItem] = []
            tenant_scope = str(tenant_id)
            for lineage, parent, child in self.db.execute(stmt).all():
                parent_props = _instance_properties(parent)
                child_props = _instance_properties(child)
                lineage_json = _dict_value(lineage.json_addl)
                lineage_tenant = _deep_tenant_id(lineage_json)
                parent_tenant = _normalize_uuid_str(parent_props.get("tenant_id"))
                child_tenant = _normalize_uuid_str(child_props.get("tenant_id"))
                if not cross_tenant and tenant_scope not in {
                    lineage_tenant,
                    parent_tenant,
                    child_tenant,
                }:
                    continue

                metadata = {
                    "relationship_type": lineage.relationship_type,
                    "parent_instance_uid": lineage.parent_instance_uid,
                    "child_instance_uid": lineage.child_instance_uid,
                    "parent_euid": parent.euid,
                    "child_euid": child.euid,
                    "tenant_id": lineage_tenant or parent_tenant or child_tenant,
                    "parent_properties": parent_props,
                    "child_properties": child_props,
                    "json_addl": lineage_json,
                }
                if not _matches_property_filters(metadata, request.property_filters):
                    continue

                items.append(
                    SearchResultItem(
                        record_type="lineage",
                        source_kind="tapdb.generic_instance_lineage",
                        uid=lineage.uid,
                        euid=lineage.euid,
                        name=(
                            lineage.name
                            or lineage.relationship_type
                            or lineage.euid
                            or str(lineage.uid)
                        ),
                        created_at=_to_iso(lineage.created_dt),
                        modified_at=_to_iso(lineage.modified_dt),
                        category=lineage.category or "",
                        type=lineage.type or "",
                        subtype=lineage.subtype or "",
                        version=lineage.version or "",
                        is_deleted=bool(lineage.is_deleted),
                        metadata=metadata,
                    )
                )
            return items
        except SQLAlchemyError as exc:
            logger.warning("Unified search scope=lineage unavailable: %s", exc)
            return []

    def search_audit(
        self,
        request: SearchQueryRequest,
        *,
        tenant_id: uuid.UUID,
        cross_tenant: bool,
        fetch_limit: int,
    ) -> list[SearchResultItem]:
        try:
            stmt = select(audit_log)
            if not request.include_deleted:
                stmt = stmt.where(audit_log.is_deleted.is_(False))

            if request.q:
                pattern = f"%{request.q}%"
                stmt = stmt.where(
                    or_(
                        audit_log.euid.ilike(pattern),
                        audit_log.rel_table_name.ilike(pattern),
                        audit_log.column_name.ilike(pattern),
                        audit_log.old_value.ilike(pattern),
                        audit_log.new_value.ilike(pattern),
                        cast(audit_log.json_addl, String).ilike(pattern),
                    )
                )

            order_column = {
                "created_at": audit_log.changed_at,
                "modified_at": audit_log.changed_at,
                "name": audit_log.rel_table_name,
                "euid": audit_log.euid,
            }[request.sort_field]
            stmt = stmt.order_by(
                _order_clause(order_column, request.sort_dir),
                desc(audit_log.changed_at),
                desc(audit_log.uid),
            ).limit(fetch_limit)

            items: list[SearchResultItem] = []
            tenant_scope = str(tenant_id)
            for row in self.db.execute(stmt).scalars().all():
                json_addl = _dict_value(row.json_addl)
                deleted_record = _dict_value(row.deleted_record_json)
                tenant_value = _deep_tenant_id(json_addl) or _deep_tenant_id(deleted_record)
                if not cross_tenant and tenant_value != tenant_scope:
                    continue

                changed_at = _to_iso(row.changed_at)
                metadata = {
                    "operation_type": row.operation_type,
                    "changed_by": row.changed_by,
                    "changed_at": changed_at,
                    "rel_table_name": row.rel_table_name,
                    "column_name": row.column_name,
                    "old_value": row.old_value,
                    "new_value": row.new_value,
                    "rel_table_uid_fk": (
                        row.rel_table_uid_fk if row.rel_table_uid_fk is not None else None
                    ),
                    "rel_table_euid_fk": row.rel_table_euid_fk,
                    "tenant_id": tenant_value,
                    "json_addl": json_addl,
                    "deleted_record_json": deleted_record,
                }
                if not _matches_property_filters(metadata, request.property_filters):
                    continue

                items.append(
                    SearchResultItem(
                        record_type="audit",
                        source_kind="tapdb.audit_log",
                        uid=row.uid,
                        euid=row.euid,
                        name=(f"{row.operation_type or 'AUDIT'}:{row.rel_table_name or 'unknown'}"),
                        created_at=changed_at,
                        modified_at=changed_at,
                        category=row.category or "",
                        type=row.rel_table_name or "",
                        subtype=row.column_name or "",
                        version="",
                        is_deleted=bool(row.is_deleted),
                        metadata=metadata,
                    )
                )
            return items
        except SQLAlchemyError as exc:
            logger.warning("Unified search scope=audit unavailable: %s", exc)
            return []
