"""Unified Atlas search contracts shared by API and web routes."""

from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

SEARCH_SCOPES: tuple[str, ...] = ("instance", "template", "lineage", "audit")
SEARCH_SORT_FIELDS: tuple[str, ...] = ("created_at", "modified_at", "name", "euid")
SEARCH_SORT_DIRS: tuple[str, ...] = ("asc", "desc")
SEARCH_FILTER_OPS: tuple[str, ...] = ("eq", "neq", "contains", "in", "exists", "gte", "lte")

_PATH_SEGMENT_RE = re.compile(r"^[A-Za-z0-9_]+$")


class SearchPropertyFilter(BaseModel):
    """Structured filter applied against result metadata properties."""

    path: str = Field(..., min_length=1, max_length=255)
    op: Literal["eq", "neq", "contains", "in", "exists", "gte", "lte"]
    value: Any | None = None

    @field_validator("path")
    @classmethod
    def validate_path(cls, value: str) -> str:
        parts = value.split(".")
        if len(parts) > 5:
            raise ValueError("path depth cannot exceed 5 segments")
        if any(not _PATH_SEGMENT_RE.fullmatch(part or "") for part in parts):
            raise ValueError("path must use dot notation with [A-Za-z0-9_] segments")
        return value

    @model_validator(mode="after")
    def validate_value_for_operator(self) -> SearchPropertyFilter:
        if self.op != "exists" and self.value is None:
            raise ValueError("value is required for this operator")
        if self.op == "in" and not isinstance(self.value, (list, tuple, set)):
            raise ValueError("value must be a list for 'in' operator")
        return self


class SearchQueryRequest(BaseModel):
    """Canonical search v2 request payload."""

    q: str | None = Field(default=None, max_length=256)
    scopes: list[Literal["instance", "template", "lineage", "audit"]] = Field(
        default_factory=lambda: list(SEARCH_SCOPES)
    )
    page: int = Field(default=1, ge=1, le=200)
    page_size: int = Field(default=25, ge=1, le=100)
    sort_field: Literal["created_at", "modified_at", "name", "euid"] = "created_at"
    sort_dir: Literal["asc", "desc"] = "desc"
    include_deleted: bool = False
    property_filters: list[SearchPropertyFilter] = Field(default_factory=list)

    @field_validator("q")
    @classmethod
    def normalize_query(cls, value: str | None) -> str | None:
        if value is None:
            return None
        stripped = value.strip()
        return stripped or None

    @field_validator("scopes")
    @classmethod
    def normalize_scopes(
        cls, value: list[Literal["instance", "template", "lineage", "audit"]]
    ) -> list[str]:
        if not value:
            return list(SEARCH_SCOPES)
        deduped: list[str] = []
        for scope in value:
            if scope not in deduped:
                deduped.append(scope)
        return deduped


class SearchExportRequest(SearchQueryRequest):
    """Export request for search v2."""

    format: Literal["json", "tsv"] = "json"
    max_rows: int = Field(default=1000, ge=1, le=10000)


class SearchFacets(BaseModel):
    """Facet totals for each record type."""

    instance: int = 0
    template: int = 0
    lineage: int = 0
    audit: int = 0


class SearchResultItem(BaseModel):
    """Normalized mixed-type search result item."""

    record_type: Literal["instance", "template", "lineage", "audit"]
    source_kind: str
    uid: int
    euid: str | None = None
    name: str
    created_at: str | None = None
    modified_at: str | None = None
    category: str
    type: str
    subtype: str
    version: str
    is_deleted: bool
    metadata: dict[str, Any] = Field(default_factory=dict)


class SearchQueryResponse(BaseModel):
    """Canonical search v2 response."""

    items: list[SearchResultItem]
    facets: SearchFacets
    total: int
    page: int
    page_size: int
    has_more: bool
    timing_ms: int


class SearchExportResponse(BaseModel):
    """JSON export response payload."""

    items: list[SearchResultItem]
    row_count: int
    timing_ms: int
    truncated: bool
