"""Unified search service orchestration for Atlas."""

from __future__ import annotations

import logging
import time
import uuid
from datetime import datetime
from typing import Any

from app.search.contracts import (
    SEARCH_SCOPES,
    SearchExportRequest,
    SearchFacets,
    SearchQueryRequest,
    SearchQueryResponse,
    SearchResultItem,
)
from app.search.repository import UnifiedSearchRepository

logger = logging.getLogger(__name__)


def _parse_iso(value: str | None) -> datetime:
    if not value:
        return datetime.min
    candidate = value
    if candidate.endswith("Z"):
        candidate = candidate[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(candidate)
    except ValueError:
        return datetime.min


class UnifiedSearchService:
    """Service layer that merges scope queries into a unified response."""

    def __init__(
        self,
        db: Any,
        tenant_id: uuid.UUID,
        *,
        cross_tenant: bool,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.cross_tenant = cross_tenant
        self._repo: UnifiedSearchRepository | None = None

    def _repository(self) -> UnifiedSearchRepository:
        if self._repo is None:
            self._repo = UnifiedSearchRepository(self.db)
        return self._repo

    def _sort_items(
        self,
        items: list[SearchResultItem],
        *,
        sort_field: str,
        sort_dir: str,
    ) -> list[SearchResultItem]:
        by_uid = sorted(items, key=lambda item: item.uid or 0, reverse=True)
        by_created = sorted(by_uid, key=lambda item: _parse_iso(item.created_at), reverse=True)

        def primary_key(item: SearchResultItem) -> Any:
            if sort_field == "created_at":
                return _parse_iso(item.created_at)
            if sort_field == "modified_at":
                return _parse_iso(item.modified_at)
            if sort_field == "name":
                return (item.name or "").lower()
            return (item.euid or "").lower()

        return sorted(by_created, key=primary_key, reverse=(sort_dir == "desc"))

    def query(self, request: SearchQueryRequest) -> SearchQueryResponse:
        started = time.perf_counter()
        fetch_limit = max(request.page * request.page_size, request.page_size)
        fetch_limit = min(fetch_limit, 20_000)

        repo = self._repository()
        selected_scopes = request.scopes or list(SEARCH_SCOPES)
        per_scope: dict[str, list[SearchResultItem]] = {scope: [] for scope in SEARCH_SCOPES}

        if "instance" in selected_scopes:
            per_scope["instance"] = repo.search_instances(
                request,
                tenant_id=self.tenant_id,
                cross_tenant=self.cross_tenant,
                fetch_limit=fetch_limit,
            )
        if "template" in selected_scopes:
            per_scope["template"] = repo.search_templates(request, fetch_limit=fetch_limit)
        if "lineage" in selected_scopes:
            per_scope["lineage"] = repo.search_lineage(
                request,
                tenant_id=self.tenant_id,
                cross_tenant=self.cross_tenant,
                fetch_limit=fetch_limit,
            )
        if "audit" in selected_scopes:
            per_scope["audit"] = repo.search_audit(
                request,
                tenant_id=self.tenant_id,
                cross_tenant=self.cross_tenant,
                fetch_limit=fetch_limit,
            )

        facets = SearchFacets(
            instance=len(per_scope["instance"]),
            template=len(per_scope["template"]),
            lineage=len(per_scope["lineage"]),
            audit=len(per_scope["audit"]),
        )

        merged: list[SearchResultItem] = []
        for scope in SEARCH_SCOPES:
            merged.extend(per_scope[scope])

        sorted_items = self._sort_items(
            merged,
            sort_field=request.sort_field,
            sort_dir=request.sort_dir,
        )

        total = len(sorted_items)
        start = (request.page - 1) * request.page_size
        end = start + request.page_size
        paged_items = sorted_items[start:end]

        response = SearchQueryResponse(
            items=paged_items,
            facets=facets,
            total=total,
            page=request.page,
            page_size=request.page_size,
            has_more=end < total,
            timing_ms=int((time.perf_counter() - started) * 1000),
        )
        # Sanitize scope names for log safety (strip control chars)
        _safe_scopes = ",".join(s.replace("\n", "").replace("\r", "") for s in selected_scopes)
        logger.debug(
            "Unified search query scopes=%s total=%s page=%s page_size=%s timing_ms=%s",
            _safe_scopes,
            response.total,
            response.page,
            response.page_size,
            response.timing_ms,
        )
        return response

    def collect_export_rows(
        self,
        request: SearchExportRequest,
    ) -> tuple[list[SearchResultItem], int, bool]:
        started = time.perf_counter()
        base_payload = request.model_dump(exclude={"format", "max_rows", "page", "page_size"})
        remaining = request.max_rows
        page = 1
        rows: list[SearchResultItem] = []
        has_more = False

        while remaining > 0:
            page_size = min(100, remaining)
            query_request = SearchQueryRequest(
                **base_payload,
                page=page,
                page_size=page_size,
            )
            response = self.query(query_request)
            rows.extend(response.items)
            remaining = request.max_rows - len(rows)
            has_more = response.has_more
            if not response.items or not response.has_more:
                break
            page += 1

        truncated = has_more and len(rows) >= request.max_rows
        timing_ms = int((time.perf_counter() - started) * 1000)
        logger.debug(
            "Unified search export rows=%s max_rows=%s truncated=%s timing_ms=%s",
            len(rows),
            int(request.max_rows),
            truncated,
            timing_ms,
        )
        return rows[: request.max_rows], timing_ms, truncated
