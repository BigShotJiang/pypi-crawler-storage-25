# LSMC Atlas — Agent Rules

## Entry Point — ALWAYS DO THIS FIRST
```
source atlas_activate
```
This activates the `LSMC_ATLAS` conda env AND exposes the `atlas` CLI. **The activate script IS the entry point. The CLI IS the interface. Nothing else.**

## Setup
- Activate: `source atlas_activate` (or `conda activate LSMC_ATLAS`)
- Conda env: `LSMC_ATLAS`
- CLI: `atlas` (check `pyproject.toml` `[project.scripts]` for entry point)
- DB port: 5445 (local Postgres via conda, NOT Docker)

## Database Operations
- Initial setup: `source ./install_pg.sh skipenv` (use `skipenv` if conda env already active)
- Database name: `lsmc_atlas`
- Migrations: Alembic (`alembic upgrade head`)

## Architecture
- FastAPI + Jinja2 + HTMX
- Append-only data model
- Multi-tenant (tenant isolation is critical)
- Auth: AWS Cognito (OIDC) — dev mode available for local development

## Testing
```
source atlas_activate
pytest tests/ -v     # Full suite
```

## Key Constraints
- Atlas is the PHI authority (patient data lives here)
- Kits and shipping packages are Atlas-owned
- BioSpecimen ownership is migrating to Bloom — Atlas will hold only reference EUIDs
- All new AWS resources in us-east-1

