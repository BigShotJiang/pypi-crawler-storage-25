---
type: agent_requested
description: "UI look/feel inspired by lsmc.com: monochrome industrial, high-contrast, minimal."
---

# UI Style (LSMC-inspired)

- Dark background, light text, restrained borders and status pills.
- Large headings, generous spacing, minimal ornamentation.
- Tables are dense but readable; avoid bright colors.
- Use CSS variables for theme tokens and consistent spacing scale.
- Keep navigation simple: Dashboard, Orders, Shipments, Results, Support, Admin.
