---
type: "always_apply"
---

# LSMC Atlas — Project Context

LSMC Atlas is a CLIA/CAP/NYS-facing client + internal web portal for clinical sequencing logistics.

Primary capabilities:
- External users (clinics/collaborators) create digital Orders (digital TRF equivalent), add clinical context, and prepare Shipments/Manifests.
- Internal users (LSMC intake) receive packages and scan/match BioSpecimens to existing Orders/TestOrders; mismatches go to an exception queue.
- Clients retrieve results via “Release Packages” (one artifact may be re-released multiple times unchanged).

Authoritativeness:
- Atlas IS authoritative for: OrderID, ShipmentID, TestKitID, BioSpecimenID (for now), ManifestID, ReleasePackageID, DocumentID, internal Audit IDs.
- Atlas IS NOT authoritative for report/data UIDs produced by LIMS/downstream systems. Atlas stores these as Artifacts with source_system + source_uid + checksum.

Non‑negotiables:
- Append-only. No DELETE for business entities. Prefer no UPDATE; use revisions and events.
- Corrections are reversal events (UNLINK, REMOVE), never destructive edits.
- Multi-tenant with strong tenant isolation.
- Full audit trail for all PHI-affecting actions and downloads.

Naming and core IDs (use these exact names):
- BioSpecimenID (not “Specimen”)
- TestKitID (not “Kit ID”)
- PatientID (support family relationships)
- OrderID
- ManifestID

Physical containment is flexible and may have gaps:
- Shipment may contain 0..* (TestKits, BioSpecimens, Documents, nested Shipments)
- TestKit may contain 0..* (BioSpecimens, Documents)
- Any container may include materials across multiple patients/orders.

Goal: make it easy to work back from any received physical item to Patient / Clinician / Organization / Order context.

Products:
LSMC will offer an informatics only analysis product, a managed data product, and 3 sequencing products (short read, long read and hybrid long short) - with all three having a 'STAT' option for an additional cost.
- The informatics product will involve users sending fastqs to us, we run our analysis pipelines (as wrapped in the daylily-ephemeral-cluster workset API/UI), and the charge will be per-job, or prob per GB of fastq. The output data from this product is eligible to move into our managed data prodct. input 'samples' here are the fastqfiles the customer registers with metadata sufficent to run the pipeline. They effectively self-accession and self serve monitor and fetch data. We just manage the infra. Will be HIPAA.
- The 3 sequencing products are conceptually all the same. The customer places an order for one or several assays to run from a biospecimen to be sent after collection from a patient. The biospecimen arrives at our lab, we accessionin it (match to the placed order), run the specimen through sequencing via one of the 3 technologies + fast track if STAT, produce fastq and then the fastq move into our analysis product that ultimately emits data to be delivered back to the ordering entity.  These products are charged by sample run, with a surcharge for STAT. This is high touch, as we have a very physical and highly regulated process.  Will be CLIA/CAP/NYCLEP
- The managed data product is, at first, simply offering people to manage storing and making accessible the data we produce for them. This would be significantly cheaper than standard S3 aws, and would be a recurring monthly charge. Will be HIPAA
