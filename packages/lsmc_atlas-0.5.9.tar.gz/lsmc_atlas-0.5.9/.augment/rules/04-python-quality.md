---
type: always_apply
---

# Python Quality Rules

- Python 3.11+
- Use ruff for linting and formatting.
- Use mypy where practical.
- Use pytest for tests.
- Use pydantic models for request/response schemas.
- Use SQLAlchemy 2.x + Alembic for migrations.
- Prefer small, testable domain services; keep FastAPI endpoints thin.
