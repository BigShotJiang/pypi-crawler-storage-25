---
type: always_apply
---

# Domain Naming + Status Rules

Entity names must match:
- BioSpecimen (BioSpecimenID)
- TestKit (TestKitID)
- Shipment (ShipmentID)
- Manifest (ManifestID)
- ReleasePackage (ReleasePackageID)
- Artifact (non-authoritative; stores LIMS source_uid)

Order structure:
- Order.product_orders = 1..* TestOrder
- TestOrder.assays = 1..* AssayRef
- BioSpecimen may link to 0..* TestOrders (many-to-many via link events).

Required statuses:
- OrderStatus includes: DRAFT, SUBMITTED, ABANDONED, RECEIVING_IN_PROGRESS, ON_HOLD, ACTIVE,
  COMPLETED_REPORT_READY, RELEASED, AMENDED, CANCELED, REJECTED
- BioSpecimenStatus includes: EXPECTED, RECEIVED, MATCHED, ACTIVE, MIA, ON_HOLD, REJECTED

Order status is a rollup derived deterministically from underlying TestOrders/BioSpecimens and release state.
