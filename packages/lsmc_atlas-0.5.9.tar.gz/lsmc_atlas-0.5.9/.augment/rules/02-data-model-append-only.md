---
type: always_apply
---

# Append-only Data Modeling

For core entities use:
- Identity table: created once, immutable (e.g., Order, Patient, Shipment).
- Revision table: append-only snapshots (OrderRevision, PatientRevision, ...).
- Event tables: append-only state changes and links (StatusEvent, LinkEvent, ContainmentEvent, AuditEvent).

Rules:
- Never DELETE rows in identity/revision/event tables.
- Avoid UPDATE on revision/event tables. “Edits” create a new revision row.
- “Remove/unlink” must be an appended event with action=REMOVE/UNLINK (reversal events).
- Provide Postgres views for current snapshots:
  - order_current_v, patient_current_v, clinician_current_v, shipment_current_v, biospecimen_current_v, testkit_current_v, manifest_current_v.
- Add DB triggers to reject DELETE statements on business tables.

Performance:
- It is acceptable to maintain derived “current” tables/caches only if they are rebuildable from revisions/events.
