"""Sogen Python bindings"""

import enum
import pathlib
from typing import Optional


class Backend(enum.Enum):
    unicorn = 0

    icicle = 1

    whp = 2

unicorn: Backend = Backend.unicorn

icicle: Backend = Backend.icicle

whp: Backend = Backend.whp

class MemoryPermission(enum.Enum):
    none = 0

    read = 1

    write = 2

    exec = 4

    read_write = 3

    all = 7

none: MemoryPermission = MemoryPermission.none

read: MemoryPermission = MemoryPermission.read

write: MemoryPermission = MemoryPermission.write

exec: MemoryPermission = MemoryPermission.exec

read_write: MemoryPermission = MemoryPermission.read_write

all: MemoryPermission = MemoryPermission.all

class MemoryRegionKind(enum.Enum):
    free = 0

    private_allocation = 1

    file_section_view = 2

    pagefile_section_view = 3

    section_image = 4

    mmio = 5

free: MemoryRegionKind = MemoryRegionKind.free

private_allocation: MemoryRegionKind = MemoryRegionKind.private_allocation

file_section_view: MemoryRegionKind = MemoryRegionKind.file_section_view

pagefile_section_view: MemoryRegionKind = MemoryRegionKind.pagefile_section_view

section_image: MemoryRegionKind = MemoryRegionKind.section_image

mmio: MemoryRegionKind = MemoryRegionKind.mmio

class MemoryViolationType(enum.Enum):
    unmapped = 0

    protection = 1

unmapped: MemoryViolationType = MemoryViolationType.unmapped

protection: MemoryViolationType = MemoryViolationType.protection

class Register(enum.Enum):
    invalid = 0

    rax = 35

    rbx = 37

    rcx = 38

    rdx = 40

    rsi = 43

    rdi = 39

    rbp = 36

    rsp = 44

    rip = 41

    r8 = 106

    r9 = 107

    r10 = 108

    r11 = 109

    r12 = 110

    r13 = 111

    r14 = 112

    r15 = 113

    eax = 19

    ebx = 21

    ecx = 22

    edx = 24

    esi = 29

    edi = 23

    ebp = 20

    esp = 30

    eip = 26

    eflags = 25

    rflags = 253

    cs = 11

    ss = 49

    ds = 17

    es = 28

    fs = 32

    gs = 33

    xmm0 = 122

    xmm1 = 123

    xmm2 = 124

    xmm3 = 125

    xmm4 = 126

    xmm5 = 127

    xmm6 = 128

    xmm7 = 129

    xmm8 = 130

    xmm9 = 131

    xmm10 = 132

    xmm11 = 133

    xmm12 = 134

    xmm13 = 135

    xmm14 = 136

    xmm15 = 137

invalid: Instruction = Instruction.invalid

rax: Register = Register.rax

rbx: Register = Register.rbx

rcx: Register = Register.rcx

rdx: Register = Register.rdx

rsi: Register = Register.rsi

rdi: Register = Register.rdi

rbp: Register = Register.rbp

rsp: Register = Register.rsp

rip: Register = Register.rip

r8: Register = Register.r8

r9: Register = Register.r9

r10: Register = Register.r10

r11: Register = Register.r11

r12: Register = Register.r12

r13: Register = Register.r13

r14: Register = Register.r14

r15: Register = Register.r15

eax: Register = Register.eax

ebx: Register = Register.ebx

ecx: Register = Register.ecx

edx: Register = Register.edx

esi: Register = Register.esi

edi: Register = Register.edi

ebp: Register = Register.ebp

esp: Register = Register.esp

eip: Register = Register.eip

eflags: Register = Register.eflags

rflags: Register = Register.rflags

cs: Register = Register.cs

ss: Register = Register.ss

ds: Register = Register.ds

es: Register = Register.es

fs: Register = Register.fs

gs: Register = Register.gs

xmm0: Register = Register.xmm0

xmm1: Register = Register.xmm1

xmm2: Register = Register.xmm2

xmm3: Register = Register.xmm3

xmm4: Register = Register.xmm4

xmm5: Register = Register.xmm5

xmm6: Register = Register.xmm6

xmm7: Register = Register.xmm7

xmm8: Register = Register.xmm8

xmm9: Register = Register.xmm9

xmm10: Register = Register.xmm10

xmm11: Register = Register.xmm11

xmm12: Register = Register.xmm12

xmm13: Register = Register.xmm13

xmm14: Register = Register.xmm14

xmm15: Register = Register.xmm15

class MemoryStats:
    @property
    def reserved_memory(self) -> int: ...

    @property
    def committed_memory(self) -> int: ...

class Handle:
    def __init__(self) -> None: ...

    @property
    def bits(self) -> int: ...

    @bits.setter
    def bits(self, arg: int, /) -> None: ...

    @property
    def id(self) -> int: ...

    @property
    def type(self) -> int: ...

    @property
    def is_system(self) -> bool: ...

    @property
    def is_pseudo(self) -> bool: ...

    @property
    def high_bits(self) -> int: ...

class MemoryRegionInfo:
    @property
    def start(self) -> int: ...

    @property
    def length(self) -> int: ...

    @property
    def permissions(self) -> "nt_memory_permission": ...

    @property
    def allocation_base(self) -> int: ...

    @property
    def allocation_length(self) -> int: ...

    @property
    def is_reserved(self) -> bool: ...

    @property
    def is_committed(self) -> bool: ...

    @property
    def initial_permissions(self) -> "nt_memory_permission": ...

    @property
    def kind(self) -> MemoryRegionKind: ...

class HookContinuation(enum.Enum):
    run = 0

    skip = 1

run: HookContinuation = HookContinuation.run

skip: HookContinuation = HookContinuation.skip

class MemoryViolationContinuation(enum.Enum):
    stop = 0

    resume = 1

    restart = 2

stop: MemoryViolationContinuation = MemoryViolationContinuation.stop

resume: MemoryViolationContinuation = MemoryViolationContinuation.resume

restart: MemoryViolationContinuation = MemoryViolationContinuation.restart

class Instruction(enum.Enum):
    invalid = 0

    syscall = 1

    cpuid = 2

    rdtsc = 3

    rdtscp = 4

syscall: CallingConvention = CallingConvention.syscall

cpuid: Instruction = Instruction.cpuid

rdtsc: Instruction = Instruction.rdtsc

rdtscp: Instruction = Instruction.rdtscp

class CallingConvention(enum.Enum):
    cdecl = 0

    stdcall = 1

    fastcall = 2

    syscall = 3

cdecl: CallingConvention = CallingConvention.cdecl

stdcall: CallingConvention = CallingConvention.stdcall

fastcall: CallingConvention = CallingConvention.fastcall

class ApiContinuation(enum.Enum):
    run_original = 0

    intercept = 1

    skip = 1

run_original: ApiContinuation = ApiContinuation.run_original

intercept: ApiContinuation = ApiContinuation.intercept

class ApiCall:
    @property
    def module(self) -> str: ...

    @property
    def name(self) -> str: ...

    @property
    def address(self) -> int: ...

    @property
    def return_address(self) -> int: ...

    @property
    def return_value(self) -> int: ...

    @return_value.setter
    def return_value(self, arg: int, /) -> None: ...

class BasicBlock:
    @property
    def address(self) -> int: ...

    @property
    def instruction_count(self) -> int: ...

    @property
    def size(self) -> int: ...

class ExportedSymbol:
    @property
    def name(self) -> str: ...

    @property
    def ordinal(self) -> int: ...

    @property
    def rva(self) -> int: ...

    @property
    def address(self) -> int: ...

class MappedModule:
    @property
    def name(self) -> str: ...

    @property
    def path(self) -> pathlib.Path: ...

    @property
    def module_path(self) -> str: ...

    @property
    def image_base(self) -> int: ...

    @property
    def image_base_file(self) -> int: ...

    @property
    def size_of_image(self) -> int: ...

    @property
    def entry_point(self) -> int: ...

    @property
    def exports(self) -> list[ExportedSymbol]: ...

    @property
    def is_static(self) -> bool: ...

def api_call(cc: CallingConvention, params: Optional[object] = None, restype: Optional[object] = None) -> object: ...

class Hook:
    def remove(self) -> None: ...

    @property
    def active(self) -> bool: ...

class ApiHooks:
    def __setitem__(self, arg0: str, arg1: object, /) -> None: ...

    def __delitem__(self, arg: str, /) -> None: ...

    def clear(self) -> None: ...

class Hooks:
    def memory_execution(self, arg: object, /) -> Hook: ...

    def memory_execution_at(self, arg0: int, arg1: object, /) -> Hook: ...

    def memory_read(self, arg0: int, arg1: int, arg2: object, /) -> Hook: ...

    def memory_write(self, arg0: int, arg1: int, arg2: object, /) -> Hook: ...

    def instruction(self, arg0: int, arg1: object, /) -> Hook: ...

    def interrupt(self, arg: object, /) -> Hook: ...

    def memory_violation(self, arg: object, /) -> Hook: ...

    def basic_block(self, arg: object, /) -> Hook: ...

    @property
    def apis(self) -> ApiHooks: ...

class MemoryManager:
    def read_memory(self, arg0: int, arg1: int, /) -> bytes: ...

    def write_memory(self, arg0: int, arg1: bytes, /) -> None: ...

    def allocate_memory(self, size: int, permissions: MemoryPermission, reserve_only: bool = False, start: int = 0, kind: MemoryRegionKind = MemoryRegionKind.private_allocation) -> int: ...

    def protect_memory(self, arg0: int, arg1: int, arg2: MemoryPermission, /) -> bool: ...

    def commit_memory(self, arg0: int, arg1: int, arg2: MemoryPermission, /) -> bool: ...

    def decommit_memory(self, arg0: int, arg1: int, /) -> bool: ...

    def release_memory(self, arg0: int, arg1: int, /) -> bool: ...

    def find_free_allocation_base(self, arg0: int, arg1: int, /) -> int: ...

    def get_region_info(self, arg: int, /) -> MemoryRegionInfo: ...

    def compute_memory_stats(self) -> MemoryStats: ...

    @property
    def default_allocation_address(self) -> int: ...

    @default_allocation_address.setter
    def default_allocation_address(self, arg: int, /) -> None: ...

class Thread:
    @property
    def id(self) -> int: ...

    @property
    def name(self) -> str: ...

    @property
    def start_address(self) -> int: ...

    @property
    def argument(self) -> int: ...

    @property
    def executed_instructions(self) -> int: ...

    @property
    def current_ip(self) -> int: ...

    @property
    def previous_ip(self) -> int: ...

    @property
    def setup_done(self) -> bool: ...

    @property
    def exit_status(self) -> object: ...

class Callbacks:
    @property
    def on_module_load(self) -> object: ...

    @on_module_load.setter
    def on_module_load(self, callback: Optional[object]) -> None: ...

    @property
    def on_module_unload(self) -> object: ...

    @on_module_unload.setter
    def on_module_unload(self, callback: Optional[object]) -> None: ...

    @property
    def on_stdout(self) -> object: ...

    @on_stdout.setter
    def on_stdout(self, callback: Optional[object]) -> None: ...

    @property
    def on_syscall(self) -> object: ...

    @on_syscall.setter
    def on_syscall(self, callback: Optional[object]) -> None: ...

    @property
    def on_generic_access(self) -> object: ...

    @on_generic_access.setter
    def on_generic_access(self, callback: Optional[object]) -> None: ...

    @property
    def on_generic_activity(self) -> object: ...

    @on_generic_activity.setter
    def on_generic_activity(self, callback: Optional[object]) -> None: ...

    @property
    def on_suspicious_activity(self) -> object: ...

    @on_suspicious_activity.setter
    def on_suspicious_activity(self, callback: Optional[object]) -> None: ...

    @property
    def on_exception(self) -> object: ...

    @on_exception.setter
    def on_exception(self, callback: Optional[object]) -> None: ...

    @property
    def on_instruction(self) -> object: ...

    @on_instruction.setter
    def on_instruction(self, callback: Optional[object]) -> None: ...

    @property
    def on_memory_protect(self) -> object: ...

    @on_memory_protect.setter
    def on_memory_protect(self, callback: Optional[object]) -> None: ...

    @property
    def on_memory_allocate(self) -> object: ...

    @on_memory_allocate.setter
    def on_memory_allocate(self, callback: Optional[object]) -> None: ...

    @property
    def on_memory_violate(self) -> object: ...

    @on_memory_violate.setter
    def on_memory_violate(self, callback: Optional[object]) -> None: ...

    @property
    def on_rdtsc(self) -> object: ...

    @on_rdtsc.setter
    def on_rdtsc(self, callback: Optional[object]) -> None: ...

    @property
    def on_rdtscp(self) -> object: ...

    @on_rdtscp.setter
    def on_rdtscp(self, callback: Optional[object]) -> None: ...

    @property
    def on_ioctrl(self) -> object: ...

    @on_ioctrl.setter
    def on_ioctrl(self, callback: Optional[object]) -> None: ...

    @property
    def on_debug_string(self) -> object: ...

    @on_debug_string.setter
    def on_debug_string(self, callback: Optional[object]) -> None: ...

    @property
    def on_thread_create(self) -> object: ...

    @on_thread_create.setter
    def on_thread_create(self, callback: Optional[object]) -> None: ...

    @property
    def on_thread_terminated(self) -> object: ...

    @on_thread_terminated.setter
    def on_thread_terminated(self, callback: Optional[object]) -> None: ...

    @property
    def on_thread_set_name(self) -> object: ...

    @on_thread_set_name.setter
    def on_thread_set_name(self, callback: Optional[object]) -> None: ...

    @property
    def on_thread_switch(self) -> object: ...

    @on_thread_switch.setter
    def on_thread_switch(self, callback: Optional[object]) -> None: ...

class ProcessContext:
    @property
    def is_wow64_process(self) -> bool: ...

    @property
    def exit_status(self) -> object: ...

    @property
    def live_thread_count(self) -> int: ...

    @property
    def spawned_thread_count(self) -> int: ...

    @property
    def active_thread(self) -> Thread: ...

    @property
    def callbacks(self) -> Callbacks: ...

class WindowsEmulator:
    def start(self, count: int = 0) -> None: ...

    def stop(self) -> None: ...

    def save_snapshot(self) -> None: ...

    def restore_snapshot(self) -> None: ...

    def serialize_state(self) -> bytes: ...

    def deserialize_state(self, arg: bytes, /) -> None: ...

    def setup_process_if_necessary(self) -> None: ...

    def yield_thread(self, alertable: bool = False) -> None: ...

    def perform_thread_switch(self) -> bool: ...

    def activate_thread(self, arg: int, /) -> bool: ...

    @property
    def executed_instructions(self) -> int: ...

    @property
    def last_stop_reason(self) -> str: ...

    @property
    def last_stop_reason_code(self) -> int: ...

    @property
    def last_stop_detail(self) -> str: ...

    @property
    def backend_name(self) -> str: ...

    @property
    def emulation_root(self) -> pathlib.Path: ...

    @property
    def process(self) -> ProcessContext: ...

    @property
    def memory(self) -> MemoryManager: ...

    @property
    def current_thread(self) -> Thread: ...

    @property
    def current_thread_id(self) -> object: ...

    @property
    def callbacks(self) -> Callbacks: ...

    @property
    def hooks(self) -> Hooks: ...

    def read_memory(self, arg0: int, arg1: int, /) -> bytes: ...

    def write_memory(self, arg0: int, arg1: bytes, /) -> None: ...

    def read_register(self, arg: Register, /) -> int: ...

    def write_register(self, arg0: Register, arg1: int, /) -> None: ...

    def get_host_port(self, arg: int, /) -> int: ...

    def get_emulator_port(self, arg: int, /) -> int: ...

    def map_port(self, arg0: int, arg1: int, /) -> None: ...

def create_empty(**kwargs) -> WindowsEmulator: ...

def create_application(*args, **kwargs) -> WindowsEmulator: ...
