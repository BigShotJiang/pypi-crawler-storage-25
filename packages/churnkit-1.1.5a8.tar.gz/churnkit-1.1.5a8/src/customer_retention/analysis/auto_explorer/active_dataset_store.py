from __future__ import annotations

import gc
import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, List, Optional

from customer_retention.analysis.auto_explorer.run_namespace import RunNamespace
from customer_retention.core.compat import (
    _is_native_spark_df,
    as_spark_df,
    native_pd,
    normalize_timestamps,
    release_stage_memory,
    sanitize_spark_timestamps,
)
from customer_retention.core.compat import to_pandas as _compat_to_pandas
from customer_retention.core.config.column_config import DatasetGranularity
from customer_retention.integrations.adapters.factory import get_delta

if TYPE_CHECKING:
    from customer_retention.analysis.auto_explorer.project_context import ProjectContext

logger = logging.getLogger(__name__)


def _local_delta() -> Any:
    return get_delta(force_local=True)


def optimize_delta(path: str, z_order_columns: Optional[List[str]] = None) -> None:
    get_delta().optimize(path, z_order_columns or None)


def delta_write_summary(path: str) -> dict:
    """Query Delta table metadata for user-facing write summary.

    Returns dict with keys: cores, files, optimize_verified, z_order_verified.
    """
    from customer_retention.core.compat.detection import get_default_parallelism, get_spark_session
    result: dict = {}
    cores = get_default_parallelism()
    if cores:
        result["cores"] = cores
    spark = get_spark_session()
    if spark:
        try:
            files = spark.read.format("delta").load(path).inputFiles()
            if isinstance(files, (list, tuple)):
                result["files"] = len(files)
        except Exception:
            pass
        try:
            from delta.tables import DeltaTable
            dt = DeltaTable.forPath(spark, path)
            hist = dt.history(5).select("operation", "operationParameters").collect()
            for row in hist:
                if row.operation == "OPTIMIZE":
                    result["optimize_verified"] = True
                    params = row.operationParameters or {}
                    z_val = params.get("zOrderBy", "")
                    result["z_order_verified"] = bool(z_val and z_val != "[]")
                    break
        except Exception:
            pass
    if "files" not in result:
        try:
            import deltalake
            result["files"] = len(deltalake.DeltaTable(path).file_uris())
        except Exception:
            pass
    if "optimize_verified" not in result:
        try:
            import deltalake
            for entry in deltalake.DeltaTable(path).history(5):
                if entry.get("operation") == "OPTIMIZE":
                    result["optimize_verified"] = True
                    params = entry.get("operationParameters", {})
                    z_val = params.get("zOrderBy", "")
                    result["z_order_verified"] = bool(z_val and z_val != "[]")
                    break
        except Exception:
            pass
    return result


def print_write_report(
    title: str,
    path: str,
    rows: int,
    columns: int,
    z_order_columns: Optional[List[str]] = None,
) -> None:
    """Print standardized Delta write diagnostics via console.

    Replaces per-notebook diagnostic blocks with a single call.
    """
    from customer_retention.analysis.visualization import console

    ws = delta_write_summary(path)

    files = ws.get("files", "?")
    if ws.get("optimize_verified"):
        files = f"{files} (optimized)"

    cores = ws.get("cores", "unavailable")

    z_label = ", ".join(z_order_columns) if z_order_columns else "none"
    if z_order_columns and ws.get("z_order_verified"):
        z_label += " (verified)"
    elif z_order_columns and not ws.get("optimize_verified"):
        z_label += " (unverified)"

    console.start_section()
    console.header(title)
    console.metric("Rows", f"{rows:,}")
    console.metric("Columns", columns)
    console.metric("Delta files", files)
    console.metric("Spark cores", cores)
    console.metric("Z-order keys", z_label)
    console.metric("Path", path)
    console.end_section()


def _write_delta(
    df: Any,
    path: str,
    z_order_columns: Optional[List[str]] = None,
    target_partitions: Optional[int] = None,
) -> None:
    if _is_native_spark_df(df) or hasattr(df, "to_spark"):
        spark_df = sanitize_spark_timestamps(as_spark_df(df))
        get_delta().write(
            spark_df, path, mode="overwrite",
            z_order_columns=z_order_columns,
            target_partitions=target_partitions,
        )
        return
    _local_delta().write(
        normalize_timestamps(_compat_to_pandas(df)), path, mode="overwrite",
        z_order_columns=z_order_columns,
    )


def _read_delta(path: str) -> Any:
    df = get_delta().read(path)
    if isinstance(df, native_pd.DataFrame):
        df.attrs.clear()
        return normalize_timestamps(df)
    return df


def save_active_dataset(
    namespace: RunNamespace,
    dataset_name: str,
    df: Any,
    z_order_columns: Optional[List[str]] = None,
    target_partitions: Optional[int] = None,
) -> Path:
    dlt_path = namespace.landing_table_dir(dataset_name)
    _write_delta(
        df, str(dlt_path),
        z_order_columns=z_order_columns,
        target_partitions=target_partitions,
    )
    return dlt_path


def assert_landing_schema_matches_registry(
    namespace: RunNamespace,
    dataset_name: str,
    expected_columns: List[str],
) -> None:
    """Raise if the landing Delta's columns differ from ``expected_columns``.

    Catches the bouncing failure mode where NB00 patches the in-memory
    registry but the landing Delta on disk is stale (or vice versa). The
    helper is schema-only — it reads ``columns`` from the persisted Delta
    plan, never iterates rows — so it stays distributed-safe even on
    multi-million-row datasets.
    """
    landing_path = namespace.landing_table_dir(dataset_name)
    if not landing_path.is_dir():
        raise FileNotFoundError(
            f"Landing Delta missing for dataset {dataset_name!r}: {landing_path}",
        )
    actual = {str(c).lower() for c in get_delta().read(str(landing_path)).columns}
    expected = {str(c).lower() for c in expected_columns}
    if actual == expected:
        return
    only_actual = sorted(actual - expected)
    only_expected = sorted(expected - actual)
    raise ValueError(
        f"Schema drift for dataset {dataset_name!r}: landing Delta has "
        f"columns not in registry={only_actual}, registry has columns not "
        f"in landing Delta={only_expected}",
    )


def load_active_dataset(namespace: RunNamespace, dataset_name: str) -> Any:
    dlt_path = namespace.landing_table_dir(dataset_name)
    if not dlt_path.is_dir():
        raise FileNotFoundError(f"Active dataset not found: {dlt_path}")
    return _read_delta(str(dlt_path))


def save_aggregated_dataset(
    namespace: RunNamespace,
    dataset_name: str,
    df: Any,
    z_order_columns: Optional[List[str]] = None,
) -> Path:
    dlt_path = namespace.bronze_table_dir(dataset_name)
    _write_delta(df, str(dlt_path), z_order_columns=z_order_columns)
    return dlt_path


def load_merge_dataset(
    namespace: RunNamespace,
    dataset_name: str,
    granularity: DatasetGranularity,
) -> Any:
    if granularity == DatasetGranularity.EVENT_LEVEL:
        dlt_path = namespace.bronze_table_dir(dataset_name)
        if dlt_path.is_dir():
            return _read_delta(str(dlt_path))
    return load_active_dataset(namespace, dataset_name)


def load_merge_dataset_distributed(
    namespace: RunNamespace,
    dataset_name: str,
    granularity: DatasetGranularity,
) -> Any:
    delta = get_delta()
    if granularity == DatasetGranularity.EVENT_LEVEL:
        dlt_path = namespace.bronze_table_dir(dataset_name)
        if dlt_path.is_dir():
            return delta.read(str(dlt_path))
    dlt_path = namespace.landing_table_dir(dataset_name)
    if not dlt_path.is_dir():
        raise FileNotFoundError(f"Dataset not found: {dlt_path}")
    return delta.read(str(dlt_path))


def require_silver_merged(namespace: RunNamespace) -> Any:
    silver = namespace.silver_merged_path
    if not silver.is_dir():
        raise FileNotFoundError(
            f"Silver merged dataset not found: {silver}. Run notebook 03 (dataset_merge) first."
        )
    return _read_delta(str(silver))


def require_silver_merged_distributed(namespace: RunNamespace) -> Any:
    silver = namespace.silver_merged_path
    if not silver.is_dir():
        raise FileNotFoundError(
            f"Silver merged dataset not found: {silver}. Run notebook 03 (dataset_merge) first."
        )
    return get_delta().read(str(silver))


def load_silver_merged(
    namespace: RunNamespace,
    dataset_name: str,
    granularity: DatasetGranularity,
) -> Any:
    silver = namespace.silver_merged_path
    if silver.is_dir():
        return _read_delta(str(silver))
    return load_merge_dataset(namespace, dataset_name, granularity)


def save_gold_features(namespace: RunNamespace, composite_name: str, df: Any) -> Path:
    dlt_path = namespace.gold_table_dir(composite_name)
    z_cols = [c for c in ("entity_id", "as_of_date") if c in df.columns]
    _write_delta(df, str(dlt_path), z_order_columns=z_cols or None)
    return dlt_path


def load_gold_features(namespace: RunNamespace, composite_name: str) -> Any:
    dlt_path = namespace.gold_table_dir(composite_name)
    if not dlt_path.is_dir():
        raise FileNotFoundError(f"Gold features not found: {dlt_path}")
    return _read_delta(str(dlt_path))


def load_active_dataset_distributed(namespace: RunNamespace, dataset_name: str) -> Any:
    dlt_path = namespace.landing_table_dir(dataset_name)
    if not dlt_path.is_dir():
        raise FileNotFoundError(f"Active dataset not found: {dlt_path}")
    return get_delta().read(str(dlt_path))


def load_bridge_distributed(
    namespace: RunNamespace,
    dataset_name: str,
    project_ctx: "Optional[ProjectContext]" = None,
) -> Any:
    dlt_path = namespace.landing_table_dir(dataset_name)
    if dlt_path.is_dir():
        return get_delta().read(str(dlt_path))
    if project_ctx is None or dataset_name not in project_ctx.datasets:
        raise FileNotFoundError(
            f"Bridge dataset '{dataset_name}' not found in landing ({dlt_path}) "
            f"and no raw source available. Ensure the bridge dataset's NB01 "
            f"completes before datasets that depend on it for key resolution."
        )
    entry = project_ctx.datasets[dataset_name]
    logger.info(
        "Bridge '%s' not in landing yet — loading from raw source: %s",
        dataset_name, entry.path,
    )
    return _load_raw_source(entry.path, entry.storage_format)


def _load_raw_source(path: str, storage_format: str) -> Any:
    from customer_retention.analysis.auto_explorer.dataset_fingerprinter import is_table_name
    from customer_retention.core.compat import as_pandas_api, load_spark_table, native_pd
    from customer_retention.core.compat.detection import get_spark_session

    if is_table_name(path):
        return as_pandas_api(load_spark_table(path))
    spark = get_spark_session()
    fmt = storage_format or "csv"
    if spark:
        if fmt == "parquet":
            return as_pandas_api(spark.read.parquet(path))
        if fmt == "delta":
            return as_pandas_api(spark.read.format("delta").load(path))
        return as_pandas_api(
            spark.read.option("header", "true").option("inferSchema", "true").csv(path),
        )
    if fmt == "parquet":
        return native_pd.read_parquet(path)
    return native_pd.read_csv(path)


def load_silver_merged_distributed(
    namespace: RunNamespace,
    dataset_name: str,
    granularity: DatasetGranularity,
) -> Any:
    silver = namespace.silver_merged_path
    if silver.is_dir():
        return get_delta().read(str(silver))
    return load_merge_dataset_distributed(namespace, dataset_name, granularity)


def load_gold_features_distributed(namespace: RunNamespace, composite_name: str) -> Any:
    dlt_path = namespace.gold_table_dir(composite_name)
    if not dlt_path.is_dir():
        raise FileNotFoundError(f"Gold features not found: {dlt_path}")
    return get_delta().read(str(dlt_path))


def merge_datasets_incremental(
    namespace: RunNamespace,
    spine_sdf: Any,
    datasets: "list[Any]",
    merger: Any,
) -> Any:
    """Incrementally merge datasets via Delta checkpointing.

    Instead of accumulating a wide Spark plan and relying on
    ``localCheckpoint``, this function writes the intermediate result to
    Delta after every dataset join, reads it back (breaking lineage
    completely), and releases all Spark resources before the next step.

    Parameters
    ----------
    namespace:
        Active ``RunNamespace`` — used to locate ``silver_merged_path``.
    spine_sdf:
        Native Spark DataFrame with the temporal spine.
    datasets:
        ``DatasetMergeInput`` objects to merge.
    merger:
        ``SparkTemporalMerger`` instance.

    Returns
    -------
    ``MergeReport`` with merge statistics.
    """
    from customer_retention.core.compat.detection import get_spark_session
    from customer_retention.stages.temporal.temporal_merger import MergeReport

    delta = get_delta()
    output_path = str(namespace.silver_merged_path)
    entity_key = merger.config.entity_key
    as_of_column = merger.config.as_of_column

    report = MergeReport(
        spine_rows=spine_sdf.count(),
        spine_entities=spine_sdf.select(entity_key).distinct().count(),
        spine_dates=spine_sdf.select(as_of_column).distinct().count(),
    )

    # Step 1: write spine to Delta
    delta.write(spine_sdf, output_path, mode="overwrite")
    del spine_sdf
    gc.collect()
    logger.info("Spine written to Delta (%d rows)", report.spine_rows)

    # Step 2: merge each dataset incrementally
    for i, ds in enumerate(datasets):
        t0 = time.monotonic()

        spark = get_spark_session()
        current_sdf = spark.read.format("delta").load(output_path)

        merged_sdf, new_cols = merger.merge_one(current_sdf, ds)

        delta.write(merged_sdf, output_path, mode="overwrite")

        # Release all Spark resources
        del current_sdf, merged_sdf
        release_stage_memory()

        report.datasets_merged.append(ds.name)
        report.columns_per_dataset[ds.name] = len(new_cols)

        logger.info(
            "Incremental merge %d/%d '%s': +%d cols (%.1fs)",
            i + 1, len(datasets), ds.name, len(new_cols),
            time.monotonic() - t0,
        )

    # Step 3: compact + Z-ORDER by entity/temporal columns
    z_cols = [c for c in [entity_key, as_of_column] if c]
    delta.optimize(output_path, z_cols or None)
    logger.info("OPTIMIZE complete (Z-ORDER: %s)", z_cols or "compaction-only")

    # Step 4: read final schema for report
    spark = get_spark_session()
    final_sdf = spark.read.format("delta").load(output_path)
    report.total_columns = len(final_sdf.columns)
    report.renamed_columns = {
        col: col
        for col in final_sdf.columns
        if merger.config.conflict_separator in col
    }
    del final_sdf
    gc.collect()

    return report
