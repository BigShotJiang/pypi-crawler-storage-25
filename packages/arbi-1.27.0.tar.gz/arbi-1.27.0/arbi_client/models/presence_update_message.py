from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.presence_update_message_status import PresenceUpdateMessageStatus
from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="PresenceUpdateMessage")



@_attrs_define
class PresenceUpdateMessage:
    """ Sent when a contact's online status changes or is no longer tracked.

        Attributes:
            user_id (str):
            status (PresenceUpdateMessageStatus):
            timestamp (str):
            type_ (Literal['presence_update'] | Unset):  Default: 'presence_update'.
     """

    user_id: str
    status: PresenceUpdateMessageStatus
    timestamp: str
    type_: Literal['presence_update'] | Unset = 'presence_update'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        status = self.status.value

        timestamp = self.timestamp

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "user_id": user_id,
            "status": status,
            "timestamp": timestamp,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("user_id")

        status = PresenceUpdateMessageStatus(d.pop("status"))




        timestamp = d.pop("timestamp")

        type_ = cast(Literal['presence_update'] | Unset , d.pop("type", UNSET))
        if type_ != 'presence_update'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'presence_update', got '{type_}'")

        presence_update_message = cls(
            user_id=user_id,
            status=status,
            timestamp=timestamp,
            type_=type_,
        )


        presence_update_message.additional_properties = d
        return presence_update_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
