from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.model_citation_tool_tool_responses import ModelCitationToolToolResponses





T = TypeVar("T", bound="ModelCitationTool")



@_attrs_define
class ModelCitationTool:
    """ 
        Attributes:
            name (Literal['model_citation'] | Unset):  Default: 'model_citation'.
            description (str | Unset):  Default: 'model citation'.
            tool_responses (ModelCitationToolToolResponses | Unset):
     """

    name: Literal['model_citation'] | Unset = 'model_citation'
    description: str | Unset = 'model citation'
    tool_responses: ModelCitationToolToolResponses | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.model_citation_tool_tool_responses import ModelCitationToolToolResponses
        name = self.name

        description = self.description

        tool_responses: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tool_responses, Unset):
            tool_responses = self.tool_responses.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if tool_responses is not UNSET:
            field_dict["tool_responses"] = tool_responses

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.model_citation_tool_tool_responses import ModelCitationToolToolResponses
        d = dict(src_dict)
        name = cast(Literal['model_citation'] | Unset , d.pop("name", UNSET))
        if name != 'model_citation'and not isinstance(name, Unset):
            raise ValueError(f"name must match const 'model_citation', got '{name}'")

        description = d.pop("description", UNSET)

        _tool_responses = d.pop("tool_responses", UNSET)
        tool_responses: ModelCitationToolToolResponses | Unset
        if isinstance(_tool_responses,  Unset):
            tool_responses = UNSET
        else:
            tool_responses = ModelCitationToolToolResponses.from_dict(_tool_responses)




        model_citation_tool = cls(
            name=name,
            description=description,
            tool_responses=tool_responses,
        )


        model_citation_tool.additional_properties = d
        return model_citation_tool

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
