from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.declared_upload_file import DeclaredUploadFile





T = TypeVar("T", bound="UploadInitRequest")



@_attrs_define
class UploadInitRequest:
    """ Request body for ``POST /v1/document/upload-init``.

        Attributes:
            files (list[DeclaredUploadFile]):
            shared (bool | Unset):  Default: True.
            config_ext_id (None | str | Unset):
            parent_ext_id (None | str | Unset):
            wp_type (None | str | Unset):
            tag_ext_id (None | str | Unset):
            folder (None | str | Unset):
            presign_expires_in (int | Unset):  Default: 3600.
     """

    files: list[DeclaredUploadFile]
    shared: bool | Unset = True
    config_ext_id: None | str | Unset = UNSET
    parent_ext_id: None | str | Unset = UNSET
    wp_type: None | str | Unset = UNSET
    tag_ext_id: None | str | Unset = UNSET
    folder: None | str | Unset = UNSET
    presign_expires_in: int | Unset = 3600





    def to_dict(self) -> dict[str, Any]:
        from ..models.declared_upload_file import DeclaredUploadFile
        files = []
        for files_item_data in self.files:
            files_item = files_item_data.to_dict()
            files.append(files_item)



        shared = self.shared

        config_ext_id: None | str | Unset
        if isinstance(self.config_ext_id, Unset):
            config_ext_id = UNSET
        else:
            config_ext_id = self.config_ext_id

        parent_ext_id: None | str | Unset
        if isinstance(self.parent_ext_id, Unset):
            parent_ext_id = UNSET
        else:
            parent_ext_id = self.parent_ext_id

        wp_type: None | str | Unset
        if isinstance(self.wp_type, Unset):
            wp_type = UNSET
        else:
            wp_type = self.wp_type

        tag_ext_id: None | str | Unset
        if isinstance(self.tag_ext_id, Unset):
            tag_ext_id = UNSET
        else:
            tag_ext_id = self.tag_ext_id

        folder: None | str | Unset
        if isinstance(self.folder, Unset):
            folder = UNSET
        else:
            folder = self.folder

        presign_expires_in = self.presign_expires_in


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "files": files,
        })
        if shared is not UNSET:
            field_dict["shared"] = shared
        if config_ext_id is not UNSET:
            field_dict["config_ext_id"] = config_ext_id
        if parent_ext_id is not UNSET:
            field_dict["parent_ext_id"] = parent_ext_id
        if wp_type is not UNSET:
            field_dict["wp_type"] = wp_type
        if tag_ext_id is not UNSET:
            field_dict["tag_ext_id"] = tag_ext_id
        if folder is not UNSET:
            field_dict["folder"] = folder
        if presign_expires_in is not UNSET:
            field_dict["presign_expires_in"] = presign_expires_in

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.declared_upload_file import DeclaredUploadFile
        d = dict(src_dict)
        files = []
        _files = d.pop("files")
        for files_item_data in (_files):
            files_item = DeclaredUploadFile.from_dict(files_item_data)



            files.append(files_item)


        shared = d.pop("shared", UNSET)

        def _parse_config_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_ext_id = _parse_config_ext_id(d.pop("config_ext_id", UNSET))


        def _parse_parent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_ext_id = _parse_parent_ext_id(d.pop("parent_ext_id", UNSET))


        def _parse_wp_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        wp_type = _parse_wp_type(d.pop("wp_type", UNSET))


        def _parse_tag_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tag_ext_id = _parse_tag_ext_id(d.pop("tag_ext_id", UNSET))


        def _parse_folder(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        folder = _parse_folder(d.pop("folder", UNSET))


        presign_expires_in = d.pop("presign_expires_in", UNSET)

        upload_init_request = cls(
            files=files,
            shared=shared,
            config_ext_id=config_ext_id,
            parent_ext_id=parent_ext_id,
            wp_type=wp_type,
            tag_ext_id=tag_ext_id,
            folder=folder,
            presign_expires_in=presign_expires_in,
        )

        return upload_init_request

