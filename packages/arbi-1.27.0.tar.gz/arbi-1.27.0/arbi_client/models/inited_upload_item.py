from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.inited_upload_item_status import InitedUploadItemStatus
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="InitedUploadItem")



@_attrs_define
class InitedUploadItem:
    """ One file slot returned by ``POST /v1/document/upload-init``.

    When ``status == "uploading"`` the client should PUT the SecretBox-encrypted
    bytes (``nonce(24) ‖ ciphertext+tag``) to ``upload_url`` using a plain HTTPS
    PUT, then call ``/v1/document/upload-commit`` with the ``doc_ext_id``.
    Any other status means the server rejected this file and no PUT/commit
    should be attempted for it — the client should surface the reason to the
    user and move on.

        Attributes:
            file_name (str):
            doc_ext_id (None | str | Unset):
            storage_uri (None | str | Unset):
            upload_url (None | str | Unset):
            expires_in (int | None | Unset):
            status (InitedUploadItemStatus | Unset):  Default: InitedUploadItemStatus.UPLOADING.
            reason (None | str | Unset):
     """

    file_name: str
    doc_ext_id: None | str | Unset = UNSET
    storage_uri: None | str | Unset = UNSET
    upload_url: None | str | Unset = UNSET
    expires_in: int | None | Unset = UNSET
    status: InitedUploadItemStatus | Unset = InitedUploadItemStatus.UPLOADING
    reason: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        file_name = self.file_name

        doc_ext_id: None | str | Unset
        if isinstance(self.doc_ext_id, Unset):
            doc_ext_id = UNSET
        else:
            doc_ext_id = self.doc_ext_id

        storage_uri: None | str | Unset
        if isinstance(self.storage_uri, Unset):
            storage_uri = UNSET
        else:
            storage_uri = self.storage_uri

        upload_url: None | str | Unset
        if isinstance(self.upload_url, Unset):
            upload_url = UNSET
        else:
            upload_url = self.upload_url

        expires_in: int | None | Unset
        if isinstance(self.expires_in, Unset):
            expires_in = UNSET
        else:
            expires_in = self.expires_in

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "file_name": file_name,
        })
        if doc_ext_id is not UNSET:
            field_dict["doc_ext_id"] = doc_ext_id
        if storage_uri is not UNSET:
            field_dict["storage_uri"] = storage_uri
        if upload_url is not UNSET:
            field_dict["upload_url"] = upload_url
        if expires_in is not UNSET:
            field_dict["expires_in"] = expires_in
        if status is not UNSET:
            field_dict["status"] = status
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        file_name = d.pop("file_name")

        def _parse_doc_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        doc_ext_id = _parse_doc_ext_id(d.pop("doc_ext_id", UNSET))


        def _parse_storage_uri(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        storage_uri = _parse_storage_uri(d.pop("storage_uri", UNSET))


        def _parse_upload_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        upload_url = _parse_upload_url(d.pop("upload_url", UNSET))


        def _parse_expires_in(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        expires_in = _parse_expires_in(d.pop("expires_in", UNSET))


        _status = d.pop("status", UNSET)
        status: InitedUploadItemStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = InitedUploadItemStatus(_status)




        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))


        inited_upload_item = cls(
            file_name=file_name,
            doc_ext_id=doc_ext_id,
            storage_uri=storage_uri,
            upload_url=upload_url,
            expires_in=expires_in,
            status=status,
            reason=reason,
        )


        inited_upload_item.additional_properties = d
        return inited_upload_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
