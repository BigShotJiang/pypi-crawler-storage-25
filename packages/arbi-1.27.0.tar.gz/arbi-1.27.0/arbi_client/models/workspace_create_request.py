from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="WorkspaceCreateRequest")



@_attrs_define
class WorkspaceCreateRequest:
    """ 
        Attributes:
            name (str):
            workspace_key (str):
            project_ext_id (str):
            description (None | str | Unset):
            is_public (bool | Unset):  Default: False.
     """

    name: str
    workspace_key: str
    project_ext_id: str
    description: None | str | Unset = UNSET
    is_public: bool | Unset = False





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        workspace_key = self.workspace_key

        project_ext_id = self.project_ext_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        is_public = self.is_public


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "name": name,
            "workspace_key": workspace_key,
            "project_ext_id": project_ext_id,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if is_public is not UNSET:
            field_dict["is_public"] = is_public

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        workspace_key = d.pop("workspace_key")

        project_ext_id = d.pop("project_ext_id")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        is_public = d.pop("is_public", UNSET)

        workspace_create_request = cls(
            name=name,
            workspace_key=workspace_key,
            project_ext_id=project_ext_id,
            description=description,
            is_public=is_public,
        )

        return workspace_create_request

