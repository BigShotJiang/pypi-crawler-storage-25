from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="DeclaredUploadFile")



@_attrs_define
class DeclaredUploadFile:
    """ One file declared by the client for the direct-to-MinIO upload flow.

    The client hashes the RAW (pre-encryption) bytes with HMAC-SHA256 keyed by
    the workspace key and truncates to 16 hex chars — same formula the server
    uses today in ``create_content_hash``. ``file_size`` is the RAW byte count
    (not ciphertext); quota accounting and UI display stay in raw units so the
    ciphertext size (raw + 40 for SecretBox nonce + tag) is an implementation
    detail of what goes over the wire.

        Attributes:
            file_name (str):
            file_size (int): Raw byte count (pre-encryption)
            encrypted_file_size (int): Ciphertext byte count the client will PUT to MinIO (raw + SecretBox envelope: 24-byte
                nonce + 16-byte MAC = 40 bytes).
            content_hash (str):
            content_type (None | str | Unset):
     """

    file_name: str
    file_size: int
    encrypted_file_size: int
    content_hash: str
    content_type: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        file_name = self.file_name

        file_size = self.file_size

        encrypted_file_size = self.encrypted_file_size

        content_hash = self.content_hash

        content_type: None | str | Unset
        if isinstance(self.content_type, Unset):
            content_type = UNSET
        else:
            content_type = self.content_type


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "file_name": file_name,
            "file_size": file_size,
            "encrypted_file_size": encrypted_file_size,
            "content_hash": content_hash,
        })
        if content_type is not UNSET:
            field_dict["content_type"] = content_type

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        file_name = d.pop("file_name")

        file_size = d.pop("file_size")

        encrypted_file_size = d.pop("encrypted_file_size")

        content_hash = d.pop("content_hash")

        def _parse_content_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content_type = _parse_content_type(d.pop("content_type", UNSET))


        declared_upload_file = cls(
            file_name=file_name,
            file_size=file_size,
            encrypted_file_size=encrypted_file_size,
            content_hash=content_hash,
            content_type=content_type,
        )


        declared_upload_file.additional_properties = d
        return declared_upload_file

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
