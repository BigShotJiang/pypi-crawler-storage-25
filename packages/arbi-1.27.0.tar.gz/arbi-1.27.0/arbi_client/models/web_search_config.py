from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="WebSearchConfig")



@_attrs_define
class WebSearchConfig:
    """ Configuration for web search tools.

        Attributes:
            enabled (bool | Unset): Enable web_search and read_url tools. Default: False.
            save_sources (bool | Unset): Save fetched webpages as workspace documents for citations. Default: True.
     """

    enabled: bool | Unset = False
    save_sources: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        enabled = self.enabled

        save_sources = self.save_sources


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if enabled is not UNSET:
            field_dict["ENABLED"] = enabled
        if save_sources is not UNSET:
            field_dict["SAVE_SOURCES"] = save_sources

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        enabled = d.pop("ENABLED", UNSET)

        save_sources = d.pop("SAVE_SOURCES", UNSET)

        web_search_config = cls(
            enabled=enabled,
            save_sources=save_sources,
        )


        web_search_config.additional_properties = d
        return web_search_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
