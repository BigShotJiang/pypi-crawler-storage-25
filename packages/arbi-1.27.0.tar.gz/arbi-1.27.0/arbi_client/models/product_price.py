from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.price_tier import PriceTier





T = TypeVar("T", bound="ProductPrice")



@_attrs_define
class ProductPrice:
    """ Stripe product price information.

        Attributes:
            price_id (str):
            currency (str):
            interval (str):
            interval_count (int):
            default_price (bool):
            amount (int | None | Unset):
            billing_scheme (str | Unset):  Default: 'per_unit'.
            tiers (list[PriceTier] | None | Unset):
     """

    price_id: str
    currency: str
    interval: str
    interval_count: int
    default_price: bool
    amount: int | None | Unset = UNSET
    billing_scheme: str | Unset = 'per_unit'
    tiers: list[PriceTier] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.price_tier import PriceTier
        price_id = self.price_id

        currency = self.currency

        interval = self.interval

        interval_count = self.interval_count

        default_price = self.default_price

        amount: int | None | Unset
        if isinstance(self.amount, Unset):
            amount = UNSET
        else:
            amount = self.amount

        billing_scheme = self.billing_scheme

        tiers: list[dict[str, Any]] | None | Unset
        if isinstance(self.tiers, Unset):
            tiers = UNSET
        elif isinstance(self.tiers, list):
            tiers = []
            for tiers_type_0_item_data in self.tiers:
                tiers_type_0_item = tiers_type_0_item_data.to_dict()
                tiers.append(tiers_type_0_item)


        else:
            tiers = self.tiers


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "price_id": price_id,
            "currency": currency,
            "interval": interval,
            "interval_count": interval_count,
            "default_price": default_price,
        })
        if amount is not UNSET:
            field_dict["amount"] = amount
        if billing_scheme is not UNSET:
            field_dict["billing_scheme"] = billing_scheme
        if tiers is not UNSET:
            field_dict["tiers"] = tiers

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.price_tier import PriceTier
        d = dict(src_dict)
        price_id = d.pop("price_id")

        currency = d.pop("currency")

        interval = d.pop("interval")

        interval_count = d.pop("interval_count")

        default_price = d.pop("default_price")

        def _parse_amount(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        amount = _parse_amount(d.pop("amount", UNSET))


        billing_scheme = d.pop("billing_scheme", UNSET)

        def _parse_tiers(data: object) -> list[PriceTier] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tiers_type_0 = []
                _tiers_type_0 = data
                for tiers_type_0_item_data in (_tiers_type_0):
                    tiers_type_0_item = PriceTier.from_dict(tiers_type_0_item_data)



                    tiers_type_0.append(tiers_type_0_item)

                return tiers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[PriceTier] | None | Unset, data)

        tiers = _parse_tiers(d.pop("tiers", UNSET))


        product_price = cls(
            price_id=price_id,
            currency=currency,
            interval=interval,
            interval_count=interval_count,
            default_price=default_price,
            amount=amount,
            billing_scheme=billing_scheme,
            tiers=tiers,
        )


        product_price.additional_properties = d
        return product_price

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
