from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="TagBreakdown")



@_attrs_define
class TagBreakdown:
    """ Spend/token breakdown keyed by tag value (e.g. wrk-xxx, usr-xxx).

        Attributes:
            spend (float | Unset):  Default: 0.0.
            total_tokens (int | Unset):  Default: 0.
            requests (int | Unset):  Default: 0.
     """

    spend: float | Unset = 0.0
    total_tokens: int | Unset = 0
    requests: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        spend = self.spend

        total_tokens = self.total_tokens

        requests = self.requests


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if spend is not UNSET:
            field_dict["spend"] = spend
        if total_tokens is not UNSET:
            field_dict["total_tokens"] = total_tokens
        if requests is not UNSET:
            field_dict["requests"] = requests

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        spend = d.pop("spend", UNSET)

        total_tokens = d.pop("total_tokens", UNSET)

        requests = d.pop("requests", UNSET)

        tag_breakdown = cls(
            spend=spend,
            total_tokens=total_tokens,
            requests=requests,
        )


        tag_breakdown.additional_properties = d
        return tag_breakdown

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
