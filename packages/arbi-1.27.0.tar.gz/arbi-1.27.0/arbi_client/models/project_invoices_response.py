from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.project_invoice import ProjectInvoice





T = TypeVar("T", bound="ProjectInvoicesResponse")



@_attrs_define
class ProjectInvoicesResponse:
    """ Invoices for a project subscription.

        Attributes:
            project_ext_id (str):
            invoices (list[ProjectInvoice] | Unset):
     """

    project_ext_id: str
    invoices: list[ProjectInvoice] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.project_invoice import ProjectInvoice
        project_ext_id = self.project_ext_id

        invoices: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.invoices, Unset):
            invoices = []
            for invoices_item_data in self.invoices:
                invoices_item = invoices_item_data.to_dict()
                invoices.append(invoices_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "project_ext_id": project_ext_id,
        })
        if invoices is not UNSET:
            field_dict["invoices"] = invoices

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.project_invoice import ProjectInvoice
        d = dict(src_dict)
        project_ext_id = d.pop("project_ext_id")

        _invoices = d.pop("invoices", UNSET)
        invoices: list[ProjectInvoice] | Unset = UNSET
        if _invoices is not UNSET:
            invoices = []
            for invoices_item_data in _invoices:
                invoices_item = ProjectInvoice.from_dict(invoices_item_data)



                invoices.append(invoices_item)


        project_invoices_response = cls(
            project_ext_id=project_ext_id,
            invoices=invoices,
        )


        project_invoices_response.additional_properties = d
        return project_invoices_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
