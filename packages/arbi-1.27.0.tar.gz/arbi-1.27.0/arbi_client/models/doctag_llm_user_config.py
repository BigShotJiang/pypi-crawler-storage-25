from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tag_template import TagTemplate





T = TypeVar("T", bound="DoctagLLMUserConfig")



@_attrs_define
class DoctagLLMUserConfig:
    r""" 
        Attributes:
            auto_rename (bool | Unset): Generate a descriptive document title via LLM instead of using the filename. The
                generated title replaces the filename-derived title in doc_metadata. Default: False.
            auto_rename_instruction (str | Unset): Instruction for generating document titles when AUTO_RENAME is enabled.
                Default: 'Create a short substantive title for the document of no more than 10 words. E.g. \\"Email from X to Y
                re ABC\\", \\"Service Agreement between A and B\\".'.
            default_metadata_tags (list[TagTemplate] | Unset): Metadata templates used for automatic document metadata
                extraction during indexing. Built-in tags cannot be removed; additional tags may be appended.
     """

    auto_rename: bool | Unset = False
    auto_rename_instruction: str | Unset = 'Create a short substantive title for the document of no more than 10 words. E.g. \\"Email from X to Y re ABC\\", \\"Service Agreement between A and B\\".'
    default_metadata_tags: list[TagTemplate] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.tag_template import TagTemplate
        auto_rename = self.auto_rename

        auto_rename_instruction = self.auto_rename_instruction

        default_metadata_tags: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.default_metadata_tags, Unset):
            default_metadata_tags = []
            for default_metadata_tags_item_data in self.default_metadata_tags:
                default_metadata_tags_item = default_metadata_tags_item_data.to_dict()
                default_metadata_tags.append(default_metadata_tags_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if auto_rename is not UNSET:
            field_dict["AUTO_RENAME"] = auto_rename
        if auto_rename_instruction is not UNSET:
            field_dict["AUTO_RENAME_INSTRUCTION"] = auto_rename_instruction
        if default_metadata_tags is not UNSET:
            field_dict["DEFAULT_METADATA_TAGS"] = default_metadata_tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tag_template import TagTemplate
        d = dict(src_dict)
        auto_rename = d.pop("AUTO_RENAME", UNSET)

        auto_rename_instruction = d.pop("AUTO_RENAME_INSTRUCTION", UNSET)

        _default_metadata_tags = d.pop("DEFAULT_METADATA_TAGS", UNSET)
        default_metadata_tags: list[TagTemplate] | Unset = UNSET
        if _default_metadata_tags is not UNSET:
            default_metadata_tags = []
            for default_metadata_tags_item_data in _default_metadata_tags:
                default_metadata_tags_item = TagTemplate.from_dict(default_metadata_tags_item_data)



                default_metadata_tags.append(default_metadata_tags_item)


        doctag_llm_user_config = cls(
            auto_rename=auto_rename,
            auto_rename_instruction=auto_rename_instruction,
            default_metadata_tags=default_metadata_tags,
        )


        doctag_llm_user_config.additional_properties = d
        return doctag_llm_user_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
