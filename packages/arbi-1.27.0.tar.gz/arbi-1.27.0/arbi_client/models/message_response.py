from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.message_response_role import MessageResponseRole
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.message_response_tools import MessageResponseTools





T = TypeVar("T", bound="MessageResponse")



@_attrs_define
class MessageResponse:
    """ DTO for API responses to frontend - all fields guaranteed to be present

        Attributes:
            role (MessageResponseRole):
            content (str):
            external_id (str):
            created_at (datetime.datetime):
            created_by_ext_id (str):
            conversation_ext_id (str):
            tools (MessageResponseTools | Unset):
            config_ext_id (None | str | Unset):
            shared (bool | Unset):  Default: False.
            tokens (int | Unset):  Default: 0.
            status (str | Unset):  Default: 'completed'.
            parent_message_ext_id (None | str | Unset):
     """

    role: MessageResponseRole
    content: str
    external_id: str
    created_at: datetime.datetime
    created_by_ext_id: str
    conversation_ext_id: str
    tools: MessageResponseTools | Unset = UNSET
    config_ext_id: None | str | Unset = UNSET
    shared: bool | Unset = False
    tokens: int | Unset = 0
    status: str | Unset = 'completed'
    parent_message_ext_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.message_response_tools import MessageResponseTools
        role = self.role.value

        content = self.content

        external_id = self.external_id

        created_at = self.created_at.isoformat()

        created_by_ext_id = self.created_by_ext_id

        conversation_ext_id = self.conversation_ext_id

        tools: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tools, Unset):
            tools = self.tools.to_dict()

        config_ext_id: None | str | Unset
        if isinstance(self.config_ext_id, Unset):
            config_ext_id = UNSET
        else:
            config_ext_id = self.config_ext_id

        shared = self.shared

        tokens = self.tokens

        status = self.status

        parent_message_ext_id: None | str | Unset
        if isinstance(self.parent_message_ext_id, Unset):
            parent_message_ext_id = UNSET
        else:
            parent_message_ext_id = self.parent_message_ext_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "role": role,
            "content": content,
            "external_id": external_id,
            "created_at": created_at,
            "created_by_ext_id": created_by_ext_id,
            "conversation_ext_id": conversation_ext_id,
        })
        if tools is not UNSET:
            field_dict["tools"] = tools
        if config_ext_id is not UNSET:
            field_dict["config_ext_id"] = config_ext_id
        if shared is not UNSET:
            field_dict["shared"] = shared
        if tokens is not UNSET:
            field_dict["tokens"] = tokens
        if status is not UNSET:
            field_dict["status"] = status
        if parent_message_ext_id is not UNSET:
            field_dict["parent_message_ext_id"] = parent_message_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_response_tools import MessageResponseTools
        d = dict(src_dict)
        role = MessageResponseRole(d.pop("role"))




        content = d.pop("content")

        external_id = d.pop("external_id")

        created_at = isoparse(d.pop("created_at"))




        created_by_ext_id = d.pop("created_by_ext_id")

        conversation_ext_id = d.pop("conversation_ext_id")

        _tools = d.pop("tools", UNSET)
        tools: MessageResponseTools | Unset
        if isinstance(_tools,  Unset):
            tools = UNSET
        else:
            tools = MessageResponseTools.from_dict(_tools)




        def _parse_config_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_ext_id = _parse_config_ext_id(d.pop("config_ext_id", UNSET))


        shared = d.pop("shared", UNSET)

        tokens = d.pop("tokens", UNSET)

        status = d.pop("status", UNSET)

        def _parse_parent_message_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_message_ext_id = _parse_parent_message_ext_id(d.pop("parent_message_ext_id", UNSET))


        message_response = cls(
            role=role,
            content=content,
            external_id=external_id,
            created_at=created_at,
            created_by_ext_id=created_by_ext_id,
            conversation_ext_id=conversation_ext_id,
            tools=tools,
            config_ext_id=config_ext_id,
            shared=shared,
            tokens=tokens,
            status=status,
            parent_message_ext_id=parent_message_ext_id,
        )


        message_response.additional_properties = d
        return message_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
