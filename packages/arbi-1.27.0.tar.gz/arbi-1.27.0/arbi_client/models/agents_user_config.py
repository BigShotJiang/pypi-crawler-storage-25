from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="AgentsUserConfig")



@_attrs_define
class AgentsUserConfig:
    """ 
        Attributes:
            enabled (bool | Unset): Whether to use agents mode for queries. Default: True.
            memory_enabled (bool | Unset): Run memory synthesis (skills, memories) after agent queries. Default: False.
            persona (str | Unset): Agent persona prepended to the system prompt. Customise to change the agent's identity
                and tone. Default: 'You are ARBI, an AI assistant created by ARBI CITY. Be proactive, helpful and
                professional.'.
            agent_model_name (str | Unset): The name of the model to be used for the agent decision-making. Default: 'auto'.
     """

    enabled: bool | Unset = True
    memory_enabled: bool | Unset = False
    persona: str | Unset = 'You are ARBI, an AI assistant created by ARBI CITY. Be proactive, helpful and professional.'
    agent_model_name: str | Unset = 'auto'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        enabled = self.enabled

        memory_enabled = self.memory_enabled

        persona = self.persona

        agent_model_name = self.agent_model_name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if enabled is not UNSET:
            field_dict["ENABLED"] = enabled
        if memory_enabled is not UNSET:
            field_dict["MEMORY_ENABLED"] = memory_enabled
        if persona is not UNSET:
            field_dict["PERSONA"] = persona
        if agent_model_name is not UNSET:
            field_dict["AGENT_MODEL_NAME"] = agent_model_name

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        enabled = d.pop("ENABLED", UNSET)

        memory_enabled = d.pop("MEMORY_ENABLED", UNSET)

        persona = d.pop("PERSONA", UNSET)

        agent_model_name = d.pop("AGENT_MODEL_NAME", UNSET)

        agents_user_config = cls(
            enabled=enabled,
            memory_enabled=memory_enabled,
            persona=persona,
            agent_model_name=agent_model_name,
        )


        agents_user_config.additional_properties = d
        return agents_user_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
