from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.daily_usage_model_groups import DailyUsageModelGroups





T = TypeVar("T", bound="DailyUsage")



@_attrs_define
class DailyUsage:
    """ Usage for a single day.

        Attributes:
            date (str):
            spend (float | Unset):  Default: 0.0.
            total_tokens (int | Unset):  Default: 0.
            api_requests (int | Unset):  Default: 0.
            model_groups (DailyUsageModelGroups | Unset):
     """

    date: str
    spend: float | Unset = 0.0
    total_tokens: int | Unset = 0
    api_requests: int | Unset = 0
    model_groups: DailyUsageModelGroups | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.daily_usage_model_groups import DailyUsageModelGroups
        date = self.date

        spend = self.spend

        total_tokens = self.total_tokens

        api_requests = self.api_requests

        model_groups: dict[str, Any] | Unset = UNSET
        if not isinstance(self.model_groups, Unset):
            model_groups = self.model_groups.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "date": date,
        })
        if spend is not UNSET:
            field_dict["spend"] = spend
        if total_tokens is not UNSET:
            field_dict["total_tokens"] = total_tokens
        if api_requests is not UNSET:
            field_dict["api_requests"] = api_requests
        if model_groups is not UNSET:
            field_dict["model_groups"] = model_groups

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.daily_usage_model_groups import DailyUsageModelGroups
        d = dict(src_dict)
        date = d.pop("date")

        spend = d.pop("spend", UNSET)

        total_tokens = d.pop("total_tokens", UNSET)

        api_requests = d.pop("api_requests", UNSET)

        _model_groups = d.pop("model_groups", UNSET)
        model_groups: DailyUsageModelGroups | Unset
        if isinstance(_model_groups,  Unset):
            model_groups = UNSET
        else:
            model_groups = DailyUsageModelGroups.from_dict(_model_groups)




        daily_usage = cls(
            date=date,
            spend=spend,
            total_tokens=total_tokens,
            api_requests=api_requests,
            model_groups=model_groups,
        )


        daily_usage.additional_properties = d
        return daily_usage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
