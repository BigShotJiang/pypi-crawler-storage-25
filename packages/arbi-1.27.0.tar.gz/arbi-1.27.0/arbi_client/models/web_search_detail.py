from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="WebSearchDetail")



@_attrs_define
class WebSearchDetail:
    """ Detail for a web_search tool call.

        Attributes:
            query (str): Search query (truncated to 80 chars)
            tool (Literal['web_search'] | Unset):  Default: 'web_search'.
     """

    query: str
    tool: Literal['web_search'] | Unset = 'web_search'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        query = self.query

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "query": query,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        query = d.pop("query")

        tool = cast(Literal['web_search'] | Unset , d.pop("tool", UNSET))
        if tool != 'web_search'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'web_search', got '{tool}'")

        web_search_detail = cls(
            query=query,
            tool=tool,
        )


        web_search_detail.additional_properties = d
        return web_search_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
