from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.thread import Thread





T = TypeVar("T", bound="ThreadsResponse")



@_attrs_define
class ThreadsResponse:
    """ 
        Attributes:
            conversation_ext_id (str):
            threads (list[Thread]):
     """

    conversation_ext_id: str
    threads: list[Thread]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.thread import Thread
        conversation_ext_id = self.conversation_ext_id

        threads = []
        for threads_item_data in self.threads:
            threads_item = threads_item_data.to_dict()
            threads.append(threads_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "conversation_ext_id": conversation_ext_id,
            "threads": threads,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.thread import Thread
        d = dict(src_dict)
        conversation_ext_id = d.pop("conversation_ext_id")

        threads = []
        _threads = d.pop("threads")
        for threads_item_data in (_threads):
            threads_item = Thread.from_dict(threads_item_data)



            threads.append(threads_item)


        threads_response = cls(
            conversation_ext_id=conversation_ext_id,
            threads=threads,
        )


        threads_response.additional_properties = d
        return threads_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
