from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.quota_usage import QuotaUsage





T = TypeVar("T", bound="ProjectQuotas")



@_attrs_define
class ProjectQuotas:
    """ All quota metrics for a project, derived from packs.

        Attributes:
            storage_gb (QuotaUsage): Single quota metric: current usage vs limit.
            ai_credits (QuotaUsage): Single quota metric: current usage vs limit.
            collaborators (QuotaUsage): Single quota metric: current usage vs limit.
            budget_reset_at (int | None | Unset):
     """

    storage_gb: QuotaUsage
    ai_credits: QuotaUsage
    collaborators: QuotaUsage
    budget_reset_at: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.quota_usage import QuotaUsage
        storage_gb = self.storage_gb.to_dict()

        ai_credits = self.ai_credits.to_dict()

        collaborators = self.collaborators.to_dict()

        budget_reset_at: int | None | Unset
        if isinstance(self.budget_reset_at, Unset):
            budget_reset_at = UNSET
        else:
            budget_reset_at = self.budget_reset_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "storage_gb": storage_gb,
            "ai_credits": ai_credits,
            "collaborators": collaborators,
        })
        if budget_reset_at is not UNSET:
            field_dict["budget_reset_at"] = budget_reset_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.quota_usage import QuotaUsage
        d = dict(src_dict)
        storage_gb = QuotaUsage.from_dict(d.pop("storage_gb"))




        ai_credits = QuotaUsage.from_dict(d.pop("ai_credits"))




        collaborators = QuotaUsage.from_dict(d.pop("collaborators"))




        def _parse_budget_reset_at(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        budget_reset_at = _parse_budget_reset_at(d.pop("budget_reset_at", UNSET))


        project_quotas = cls(
            storage_gb=storage_gb,
            ai_credits=ai_credits,
            collaborators=collaborators,
            budget_reset_at=budget_reset_at,
        )


        project_quotas.additional_properties = d
        return project_quotas

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
