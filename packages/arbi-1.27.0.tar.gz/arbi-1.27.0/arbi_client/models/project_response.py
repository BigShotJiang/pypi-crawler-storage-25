from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.project_quotas import ProjectQuotas





T = TypeVar("T", bound="ProjectResponse")



@_attrs_define
class ProjectResponse:
    """ Project summary returned in list and detail views.

        Attributes:
            external_id (str):
            name (str):
            packs (int):
            subscription (str):
            created_at (datetime.datetime):
            quotas (ProjectQuotas): All quota metrics for a project, derived from packs.
            price_id (None | str | Unset):
            plan (None | str | Unset):
            amount (int | None | Unset):
            currency (None | str | Unset):
            current_period_end (int | None | Unset):
            cancel_at_period_end (bool | None | Unset):
            portal_url (None | str | Unset):
     """

    external_id: str
    name: str
    packs: int
    subscription: str
    created_at: datetime.datetime
    quotas: ProjectQuotas
    price_id: None | str | Unset = UNSET
    plan: None | str | Unset = UNSET
    amount: int | None | Unset = UNSET
    currency: None | str | Unset = UNSET
    current_period_end: int | None | Unset = UNSET
    cancel_at_period_end: bool | None | Unset = UNSET
    portal_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.project_quotas import ProjectQuotas
        external_id = self.external_id

        name = self.name

        packs = self.packs

        subscription = self.subscription

        created_at = self.created_at.isoformat()

        quotas = self.quotas.to_dict()

        price_id: None | str | Unset
        if isinstance(self.price_id, Unset):
            price_id = UNSET
        else:
            price_id = self.price_id

        plan: None | str | Unset
        if isinstance(self.plan, Unset):
            plan = UNSET
        else:
            plan = self.plan

        amount: int | None | Unset
        if isinstance(self.amount, Unset):
            amount = UNSET
        else:
            amount = self.amount

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        current_period_end: int | None | Unset
        if isinstance(self.current_period_end, Unset):
            current_period_end = UNSET
        else:
            current_period_end = self.current_period_end

        cancel_at_period_end: bool | None | Unset
        if isinstance(self.cancel_at_period_end, Unset):
            cancel_at_period_end = UNSET
        else:
            cancel_at_period_end = self.cancel_at_period_end

        portal_url: None | str | Unset
        if isinstance(self.portal_url, Unset):
            portal_url = UNSET
        else:
            portal_url = self.portal_url


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "external_id": external_id,
            "name": name,
            "packs": packs,
            "subscription": subscription,
            "created_at": created_at,
            "quotas": quotas,
        })
        if price_id is not UNSET:
            field_dict["price_id"] = price_id
        if plan is not UNSET:
            field_dict["plan"] = plan
        if amount is not UNSET:
            field_dict["amount"] = amount
        if currency is not UNSET:
            field_dict["currency"] = currency
        if current_period_end is not UNSET:
            field_dict["current_period_end"] = current_period_end
        if cancel_at_period_end is not UNSET:
            field_dict["cancel_at_period_end"] = cancel_at_period_end
        if portal_url is not UNSET:
            field_dict["portal_url"] = portal_url

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.project_quotas import ProjectQuotas
        d = dict(src_dict)
        external_id = d.pop("external_id")

        name = d.pop("name")

        packs = d.pop("packs")

        subscription = d.pop("subscription")

        created_at = isoparse(d.pop("created_at"))




        quotas = ProjectQuotas.from_dict(d.pop("quotas"))




        def _parse_price_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        price_id = _parse_price_id(d.pop("price_id", UNSET))


        def _parse_plan(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        plan = _parse_plan(d.pop("plan", UNSET))


        def _parse_amount(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        amount = _parse_amount(d.pop("amount", UNSET))


        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))


        def _parse_current_period_end(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        current_period_end = _parse_current_period_end(d.pop("current_period_end", UNSET))


        def _parse_cancel_at_period_end(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        cancel_at_period_end = _parse_cancel_at_period_end(d.pop("cancel_at_period_end", UNSET))


        def _parse_portal_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        portal_url = _parse_portal_url(d.pop("portal_url", UNSET))


        project_response = cls(
            external_id=external_id,
            name=name,
            packs=packs,
            subscription=subscription,
            created_at=created_at,
            quotas=quotas,
            price_id=price_id,
            plan=plan,
            amount=amount,
            currency=currency,
            current_period_end=current_period_end,
            cancel_at_period_end=cancel_at_period_end,
            portal_url=portal_url,
        )


        project_response.additional_properties = d
        return project_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
