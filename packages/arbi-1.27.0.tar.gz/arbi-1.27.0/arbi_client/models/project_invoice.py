from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ProjectInvoice")



@_attrs_define
class ProjectInvoice:
    """ Single Stripe invoice/receipt for a project.

        Attributes:
            date (str):
            amount (int):
            currency (str):
            status (str):
            url (None | str | Unset):
            pdf_url (None | str | Unset):
     """

    date: str
    amount: int
    currency: str
    status: str
    url: None | str | Unset = UNSET
    pdf_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        date = self.date

        amount = self.amount

        currency = self.currency

        status = self.status

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        pdf_url: None | str | Unset
        if isinstance(self.pdf_url, Unset):
            pdf_url = UNSET
        else:
            pdf_url = self.pdf_url


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "date": date,
            "amount": amount,
            "currency": currency,
            "status": status,
        })
        if url is not UNSET:
            field_dict["url"] = url
        if pdf_url is not UNSET:
            field_dict["pdf_url"] = pdf_url

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = d.pop("date")

        amount = d.pop("amount")

        currency = d.pop("currency")

        status = d.pop("status")

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))


        def _parse_pdf_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        pdf_url = _parse_pdf_url(d.pop("pdf_url", UNSET))


        project_invoice = cls(
            date=date,
            amount=amount,
            currency=currency,
            status=status,
            url=url,
            pdf_url=pdf_url,
        )


        project_invoice.additional_properties = d
        return project_invoice

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
