from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.skipped_file import SkippedFile





T = TypeVar("T", bound="UploadDocumentsResponse")



@_attrs_define
class UploadDocumentsResponse:
    """ Response for document upload operations.

    Returns array of document IDs for successfully uploaded files.
    Files that fail validation are skipped and listed with reasons.

        Attributes:
            doc_ext_ids (list[str] | Unset):
            batch_id (None | str | Unset): Batch ID for tracking completion via WebSocket batch_complete events
            skipped (list[SkippedFile] | Unset): Files that were skipped during upload with reasons
     """

    doc_ext_ids: list[str] | Unset = UNSET
    batch_id: None | str | Unset = UNSET
    skipped: list[SkippedFile] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.skipped_file import SkippedFile
        doc_ext_ids: list[str] | Unset = UNSET
        if not isinstance(self.doc_ext_ids, Unset):
            doc_ext_ids = self.doc_ext_ids



        batch_id: None | str | Unset
        if isinstance(self.batch_id, Unset):
            batch_id = UNSET
        else:
            batch_id = self.batch_id

        skipped: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.skipped, Unset):
            skipped = []
            for skipped_item_data in self.skipped:
                skipped_item = skipped_item_data.to_dict()
                skipped.append(skipped_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if doc_ext_ids is not UNSET:
            field_dict["doc_ext_ids"] = doc_ext_ids
        if batch_id is not UNSET:
            field_dict["batch_id"] = batch_id
        if skipped is not UNSET:
            field_dict["skipped"] = skipped

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.skipped_file import SkippedFile
        d = dict(src_dict)
        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids", UNSET))


        def _parse_batch_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        batch_id = _parse_batch_id(d.pop("batch_id", UNSET))


        _skipped = d.pop("skipped", UNSET)
        skipped: list[SkippedFile] | Unset = UNSET
        if _skipped is not UNSET:
            skipped = []
            for skipped_item_data in _skipped:
                skipped_item = SkippedFile.from_dict(skipped_item_data)



                skipped.append(skipped_item)


        upload_documents_response = cls(
            doc_ext_ids=doc_ext_ids,
            batch_id=batch_id,
            skipped=skipped,
        )


        upload_documents_response.additional_properties = d
        return upload_documents_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
