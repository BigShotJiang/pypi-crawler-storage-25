from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ProjectCheckoutRequest")



@_attrs_define
class ProjectCheckoutRequest:
    """ Create a Stripe checkout session for this project.

        Attributes:
            price_id (str):
            quantity (int | Unset): Number of Pro Packs Default: 1.
            promo_code (None | str | Unset): Promo code to auto-apply
     """

    price_id: str
    quantity: int | Unset = 1
    promo_code: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        price_id = self.price_id

        quantity = self.quantity

        promo_code: None | str | Unset
        if isinstance(self.promo_code, Unset):
            promo_code = UNSET
        else:
            promo_code = self.promo_code


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "price_id": price_id,
        })
        if quantity is not UNSET:
            field_dict["quantity"] = quantity
        if promo_code is not UNSET:
            field_dict["promo_code"] = promo_code

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        price_id = d.pop("price_id")

        quantity = d.pop("quantity", UNSET)

        def _parse_promo_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        promo_code = _parse_promo_code(d.pop("promo_code", UNSET))


        project_checkout_request = cls(
            price_id=price_id,
            quantity=quantity,
            promo_code=promo_code,
        )

        return project_checkout_request

