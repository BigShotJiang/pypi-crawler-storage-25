from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.stream_events_tool_events_item import StreamEventsToolEventsItem





T = TypeVar("T", bound="StreamEventsTool")



@_attrs_define
class StreamEventsTool:
    """ 
        Attributes:
            name (Literal['stream_events'] | Unset):  Default: 'stream_events'.
            events (list[StreamEventsToolEventsItem] | Unset):
     """

    name: Literal['stream_events'] | Unset = 'stream_events'
    events: list[StreamEventsToolEventsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.stream_events_tool_events_item import StreamEventsToolEventsItem
        name = self.name

        events: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.events, Unset):
            events = []
            for events_item_data in self.events:
                events_item = events_item_data.to_dict()
                events.append(events_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if events is not UNSET:
            field_dict["events"] = events

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.stream_events_tool_events_item import StreamEventsToolEventsItem
        d = dict(src_dict)
        name = cast(Literal['stream_events'] | Unset , d.pop("name", UNSET))
        if name != 'stream_events'and not isinstance(name, Unset):
            raise ValueError(f"name must match const 'stream_events', got '{name}'")

        _events = d.pop("events", UNSET)
        events: list[StreamEventsToolEventsItem] | Unset = UNSET
        if _events is not UNSET:
            events = []
            for events_item_data in _events:
                events_item = StreamEventsToolEventsItem.from_dict(events_item_data)



                events.append(events_item)


        stream_events_tool = cls(
            name=name,
            events=events,
        )


        stream_events_tool.additional_properties = d
        return stream_events_tool

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
