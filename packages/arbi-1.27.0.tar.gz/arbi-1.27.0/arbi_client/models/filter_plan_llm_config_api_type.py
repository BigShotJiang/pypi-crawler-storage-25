from enum import Enum

class FilterPlanLLMConfigApiType(str, Enum):
    LOCAL = "local"
    REMOTE = "remote"

    def __str__(self) -> str:
        return str(self.value)
