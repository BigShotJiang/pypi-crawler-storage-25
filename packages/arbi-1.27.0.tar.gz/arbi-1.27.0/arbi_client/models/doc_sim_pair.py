from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.doc_response import DocResponse





T = TypeVar("T", bound="DocSimPair")



@_attrs_define
class DocSimPair:
    """ A pair of documents identified as near-duplicates by centroid similarity.

        Attributes:
            doc_a (DocResponse):
            doc_b (DocResponse):
            similarity (float):
     """

    doc_a: DocResponse
    doc_b: DocResponse
    similarity: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.doc_response import DocResponse
        doc_a = self.doc_a.to_dict()

        doc_b = self.doc_b.to_dict()

        similarity = self.similarity


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_a": doc_a,
            "doc_b": doc_b,
            "similarity": similarity,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.doc_response import DocResponse
        d = dict(src_dict)
        doc_a = DocResponse.from_dict(d.pop("doc_a"))




        doc_b = DocResponse.from_dict(d.pop("doc_b"))




        similarity = d.pop("similarity")

        doc_sim_pair = cls(
            doc_a=doc_a,
            doc_b=doc_b,
            similarity=similarity,
        )


        doc_sim_pair.additional_properties = d
        return doc_sim_pair

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
