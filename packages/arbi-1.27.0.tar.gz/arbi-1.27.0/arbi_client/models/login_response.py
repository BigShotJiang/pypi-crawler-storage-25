from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.login_response_workspaces_item import LoginResponseWorkspacesItem
  from ..models.user_response import UserResponse





T = TypeVar("T", bound="LoginResponse")



@_attrs_define
class LoginResponse:
    """ Login response with access token, session key, user info, and workspaces.

    Used by: /user/login, /user/token (claim agent session)

        Attributes:
            access_token (str):
            session_key (str):
            user (UserResponse): Standard user representation used across all endpoints.

                Used for: login response, workspace users, contacts (when registered).
                Agents have agt- prefix and may have nullable name/email fields.
            workspaces (list[LoginResponseWorkspacesItem] | Unset):
     """

    access_token: str
    session_key: str
    user: UserResponse
    workspaces: list[LoginResponseWorkspacesItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.login_response_workspaces_item import LoginResponseWorkspacesItem
        from ..models.user_response import UserResponse
        access_token = self.access_token

        session_key = self.session_key

        user = self.user.to_dict()

        workspaces: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.workspaces, Unset):
            workspaces = []
            for workspaces_item_data in self.workspaces:
                workspaces_item = workspaces_item_data.to_dict()
                workspaces.append(workspaces_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "access_token": access_token,
            "session_key": session_key,
            "user": user,
        })
        if workspaces is not UNSET:
            field_dict["workspaces"] = workspaces

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.login_response_workspaces_item import LoginResponseWorkspacesItem
        from ..models.user_response import UserResponse
        d = dict(src_dict)
        access_token = d.pop("access_token")

        session_key = d.pop("session_key")

        user = UserResponse.from_dict(d.pop("user"))




        _workspaces = d.pop("workspaces", UNSET)
        workspaces: list[LoginResponseWorkspacesItem] | Unset = UNSET
        if _workspaces is not UNSET:
            workspaces = []
            for workspaces_item_data in _workspaces:
                workspaces_item = LoginResponseWorkspacesItem.from_dict(workspaces_item_data)



                workspaces.append(workspaces_item)


        login_response = cls(
            access_token=access_token,
            session_key=session_key,
            user=user,
            workspaces=workspaces,
        )


        login_response.additional_properties = d
        return login_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
