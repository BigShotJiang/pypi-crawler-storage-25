from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="SessionInfoResponse")



@_attrs_define
class SessionInfoResponse:
    """ Active session info returned by GET /user/sessions.

        Attributes:
            session_id (str):
            ttl (int):
            external_id (None | str | Unset):
            name (None | str | Unset):
            ip_address (None | str | Unset):
            active_workspace (None | str | Unset):
            workspaces (list[str] | Unset):
            status (str | Unset):  Default: 'user'.
     """

    session_id: str
    ttl: int
    external_id: None | str | Unset = UNSET
    name: None | str | Unset = UNSET
    ip_address: None | str | Unset = UNSET
    active_workspace: None | str | Unset = UNSET
    workspaces: list[str] | Unset = UNSET
    status: str | Unset = 'user'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        session_id = self.session_id

        ttl = self.ttl

        external_id: None | str | Unset
        if isinstance(self.external_id, Unset):
            external_id = UNSET
        else:
            external_id = self.external_id

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        ip_address: None | str | Unset
        if isinstance(self.ip_address, Unset):
            ip_address = UNSET
        else:
            ip_address = self.ip_address

        active_workspace: None | str | Unset
        if isinstance(self.active_workspace, Unset):
            active_workspace = UNSET
        else:
            active_workspace = self.active_workspace

        workspaces: list[str] | Unset = UNSET
        if not isinstance(self.workspaces, Unset):
            workspaces = self.workspaces



        status = self.status


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "session_id": session_id,
            "ttl": ttl,
        })
        if external_id is not UNSET:
            field_dict["external_id"] = external_id
        if name is not UNSET:
            field_dict["name"] = name
        if ip_address is not UNSET:
            field_dict["ip_address"] = ip_address
        if active_workspace is not UNSET:
            field_dict["active_workspace"] = active_workspace
        if workspaces is not UNSET:
            field_dict["workspaces"] = workspaces
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        session_id = d.pop("session_id")

        ttl = d.pop("ttl")

        def _parse_external_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        external_id = _parse_external_id(d.pop("external_id", UNSET))


        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_ip_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ip_address = _parse_ip_address(d.pop("ip_address", UNSET))


        def _parse_active_workspace(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        active_workspace = _parse_active_workspace(d.pop("active_workspace", UNSET))


        workspaces = cast(list[str], d.pop("workspaces", UNSET))


        status = d.pop("status", UNSET)

        session_info_response = cls(
            session_id=session_id,
            ttl=ttl,
            external_id=external_id,
            name=name,
            ip_address=ip_address,
            active_workspace=active_workspace,
            workspaces=workspaces,
            status=status,
        )


        session_info_response.additional_properties = d
        return session_info_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
