from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.personal_agent_tool_args import PersonalAgentToolArgs
  from ..models.personal_agent_tool_tool_responses import PersonalAgentToolToolResponses





T = TypeVar("T", bound="PersonalAgentTool")



@_attrs_define
class PersonalAgentTool:
    """ 
        Attributes:
            tool_args (PersonalAgentToolArgs): Typed arguments for personal agent tool.
            name (Literal['personal_agent'] | Unset):  Default: 'personal_agent'.
            description (str | Unset):  Default: 'personal agent'.
            tool_responses (PersonalAgentToolToolResponses | Unset):
     """

    tool_args: PersonalAgentToolArgs
    name: Literal['personal_agent'] | Unset = 'personal_agent'
    description: str | Unset = 'personal agent'
    tool_responses: PersonalAgentToolToolResponses | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.personal_agent_tool_tool_responses import PersonalAgentToolToolResponses
        from ..models.personal_agent_tool_args import PersonalAgentToolArgs
        tool_args = self.tool_args.to_dict()

        name = self.name

        description = self.description

        tool_responses: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tool_responses, Unset):
            tool_responses = self.tool_responses.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "tool_args": tool_args,
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if tool_responses is not UNSET:
            field_dict["tool_responses"] = tool_responses

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.personal_agent_tool_args import PersonalAgentToolArgs
        from ..models.personal_agent_tool_tool_responses import PersonalAgentToolToolResponses
        d = dict(src_dict)
        tool_args = PersonalAgentToolArgs.from_dict(d.pop("tool_args"))




        name = cast(Literal['personal_agent'] | Unset , d.pop("name", UNSET))
        if name != 'personal_agent'and not isinstance(name, Unset):
            raise ValueError(f"name must match const 'personal_agent', got '{name}'")

        description = d.pop("description", UNSET)

        _tool_responses = d.pop("tool_responses", UNSET)
        tool_responses: PersonalAgentToolToolResponses | Unset
        if isinstance(_tool_responses,  Unset):
            tool_responses = UNSET
        else:
            tool_responses = PersonalAgentToolToolResponses.from_dict(_tool_responses)




        personal_agent_tool = cls(
            tool_args=tool_args,
            name=name,
            description=description,
            tool_responses=tool_responses,
        )


        personal_agent_tool.additional_properties = d
        return personal_agent_tool

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
