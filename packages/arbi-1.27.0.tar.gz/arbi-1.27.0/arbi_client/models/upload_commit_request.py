from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="UploadCommitRequest")



@_attrs_define
class UploadCommitRequest:
    """ Request body for ``POST /v1/document/upload-commit``.

    ``doc_ext_ids`` should be the subset of init items the client actually
    uploaded successfully. Any IDs not listed here are left in ``uploading``
    state on the server and eventually garbage-collected.

        Attributes:
            doc_ext_ids (list[str]):
            tag_ext_id (None | str | Unset):
     """

    doc_ext_ids: list[str]
    tag_ext_id: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        doc_ext_ids = self.doc_ext_ids



        tag_ext_id: None | str | Unset
        if isinstance(self.tag_ext_id, Unset):
            tag_ext_id = UNSET
        else:
            tag_ext_id = self.tag_ext_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "doc_ext_ids": doc_ext_ids,
        })
        if tag_ext_id is not UNSET:
            field_dict["tag_ext_id"] = tag_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_ids = cast(list[str], d.pop("doc_ext_ids"))


        def _parse_tag_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tag_ext_id = _parse_tag_ext_id(d.pop("tag_ext_id", UNSET))


        upload_commit_request = cls(
            doc_ext_ids=doc_ext_ids,
            tag_ext_id=tag_ext_id,
        )

        return upload_commit_request

