from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.filter_plan_llm_config_api_type import FilterPlanLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="FilterPlanLLMConfig")



@_attrs_define
class FilterPlanLLMConfig:
    r""" Configuration for FilterPlanLLM — pre-agentic context selector.

    Runs before the agent loop to select relevant history messages and documents,
    plus produce a concise goal statement that primes the agent.
    Always uses the fast model (LLM_MODEL_NAME). In auto mode, also recommends
    a model tier (fast/wise/premium) for the agent loop.

        Attributes:
            api_type (FilterPlanLLMConfigApiType | Unset): The inference type (local or remote). Default:
                FilterPlanLLMConfigApiType.REMOTE.
            enable_thinking (bool | Unset): Enable reasoning/thinking mode. Default: False.
            model_name (str | Unset): The name of the non-reasoning model to be used. Default: 'dummy'.
            system_instruction (str | Unset): System prompt for the filter/plan LLM. Default: 'You are a context selector.
                Given a user\'s query, conversation history, and a table of available documents, determine the user\'s goal and
                select relevant context.\n\n## Instructions\n\n1. **goal**: 1-2 concise sentences describing the user\'s intent
                AND your filtering rationale. Explain what documents are needed and why. Examples:\n   - \\"The user is greeting
                the assistant. No documents are needed.\\"\n   - \\"The user wants to find force majeure clauses. Only the three
                contracts are relevant, so I will keep only those.\\"\n   - \\"The user wants a full timeline of the case. Most
                documents are relevant, so I will drop only the unrelated procedural orders.\\"\n\n2. **doc_filter_mode** and
                **doc_ids**: Select which documents the agent needs.\n   - `\\"keep\\"` mode: `doc_ids` lists the ONLY docs to
                keep. Everything else is dropped.\n   - `\\"drop\\"` mode: `doc_ids` lists the ONLY docs to drop. Everything
                else is kept.\n   - Pick whichever mode produces the **shorter `doc_ids` list**.\n   - Doc IDs are in the **Id**
                column of the Available Documents table (e.g. `\\"doc-abc12345\\"`). Copy them **exactly** from the table — do
                not invent, guess, or modify IDs.\n\n   | Scenario | doc_filter_mode | doc_ids |\n
                |----------|----------------|---------|\n   | Need ALL docs | `\\"drop\\"` | `[]` |\n   | Need NO docs |
                `\\"keep\\"` | `[]` |\n   | Need 3 of 100 docs | `\\"keep\\"` | `[\\"id1\\",\\"id2\\",\\"id3\\"]` |\n   | Drop 3
                of 100 docs | `\\"drop\\"` | `[\\"id1\\",\\"id2\\",\\"id3\\"]` |\n\n3. **chat_range_start** and
                **chat_range_end**: 0-based inclusive range of earlier history messages that provide relevant context. The last
                3 messages are always included automatically. Set both to -1 if no earlier history is needed.\n\n## Rules\n\n-
                **Never repeat a doc ID.** Each ID must appear at most once.\n- Before writing `doc_ids`, count how many you
                would keep vs drop, then pick the shorter list.\n- Greetings or meta-questions about the assistant (e.g.
                \\"hello\\", \\"who are you?\\", \\"what can you do?\\"): the agent does NOT need any documents → `\\"keep\\"`
                with `[]`.\n- Ambiguous references like \\"the document\\" or \\"this contract\\" without specifying which: keep
                all → `\\"drop\\"` with `[]`.\n- For follow-up questions, include history messages that establish the topic.\n-
                Always return valid JSON matching the schema.'.
            temperature (float | Unset):  Default: 0.0.
            max_tokens (int | Unset):  Default: 3000.
     """

    api_type: FilterPlanLLMConfigApiType | Unset = FilterPlanLLMConfigApiType.REMOTE
    enable_thinking: bool | Unset = False
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = 'You are a context selector. Given a user\'s query, conversation history, and a table of available documents, determine the user\'s goal and select relevant context.\n\n## Instructions\n\n1. **goal**: 1-2 concise sentences describing the user\'s intent AND your filtering rationale. Explain what documents are needed and why. Examples:\n   - \\"The user is greeting the assistant. No documents are needed.\\"\n   - \\"The user wants to find force majeure clauses. Only the three contracts are relevant, so I will keep only those.\\"\n   - \\"The user wants a full timeline of the case. Most documents are relevant, so I will drop only the unrelated procedural orders.\\"\n\n2. **doc_filter_mode** and **doc_ids**: Select which documents the agent needs.\n   - `\\"keep\\"` mode: `doc_ids` lists the ONLY docs to keep. Everything else is dropped.\n   - `\\"drop\\"` mode: `doc_ids` lists the ONLY docs to drop. Everything else is kept.\n   - Pick whichever mode produces the **shorter `doc_ids` list**.\n   - Doc IDs are in the **Id** column of the Available Documents table (e.g. `\\"doc-abc12345\\"`). Copy them **exactly** from the table — do not invent, guess, or modify IDs.\n\n   | Scenario | doc_filter_mode | doc_ids |\n   |----------|----------------|---------|\n   | Need ALL docs | `\\"drop\\"` | `[]` |\n   | Need NO docs | `\\"keep\\"` | `[]` |\n   | Need 3 of 100 docs | `\\"keep\\"` | `[\\"id1\\",\\"id2\\",\\"id3\\"]` |\n   | Drop 3 of 100 docs | `\\"drop\\"` | `[\\"id1\\",\\"id2\\",\\"id3\\"]` |\n\n3. **chat_range_start** and **chat_range_end**: 0-based inclusive range of earlier history messages that provide relevant context. The last 3 messages are always included automatically. Set both to -1 if no earlier history is needed.\n\n## Rules\n\n- **Never repeat a doc ID.** Each ID must appear at most once.\n- Before writing `doc_ids`, count how many you would keep vs drop, then pick the shorter list.\n- Greetings or meta-questions about the assistant (e.g. \\"hello\\", \\"who are you?\\", \\"what can you do?\\"): the agent does NOT need any documents → `\\"keep\\"` with `[]`.\n- Ambiguous references like \\"the document\\" or \\"this contract\\" without specifying which: keep all → `\\"drop\\"` with `[]`.\n- For follow-up questions, include history messages that establish the topic.\n- Always return valid JSON matching the schema.'
    temperature: float | Unset = 0.0
    max_tokens: int | Unset = 3000
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        enable_thinking = self.enable_thinking

        model_name = self.model_name

        system_instruction = self.system_instruction

        temperature = self.temperature

        max_tokens = self.max_tokens


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if enable_thinking is not UNSET:
            field_dict["ENABLE_THINKING"] = enable_thinking
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: FilterPlanLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = FilterPlanLLMConfigApiType(_api_type)




        enable_thinking = d.pop("ENABLE_THINKING", UNSET)

        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        filter_plan_llm_config = cls(
            api_type=api_type,
            enable_thinking=enable_thinking,
            model_name=model_name,
            system_instruction=system_instruction,
            temperature=temperature,
            max_tokens=max_tokens,
        )


        filter_plan_llm_config.additional_properties = d
        return filter_plan_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
