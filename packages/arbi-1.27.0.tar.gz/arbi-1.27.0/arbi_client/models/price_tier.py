from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PriceTier")



@_attrs_define
class PriceTier:
    """ Stripe volume pricing tier.

        Attributes:
            unit_amount (int):
            up_to (int | None | Unset):
     """

    unit_amount: int
    up_to: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        unit_amount = self.unit_amount

        up_to: int | None | Unset
        if isinstance(self.up_to, Unset):
            up_to = UNSET
        else:
            up_to = self.up_to


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "unit_amount": unit_amount,
        })
        if up_to is not UNSET:
            field_dict["up_to"] = up_to

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        unit_amount = d.pop("unit_amount")

        def _parse_up_to(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        up_to = _parse_up_to(d.pop("up_to", UNSET))


        price_tier = cls(
            unit_amount=unit_amount,
            up_to=up_to,
        )


        price_tier.additional_properties = d
        return price_tier

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
