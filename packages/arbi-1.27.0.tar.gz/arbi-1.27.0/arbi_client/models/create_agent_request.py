from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateAgentRequest")



@_attrs_define
class CreateAgentRequest:
    """ Create a persistent agent owned by the current user.

    Used by: POST /user/agent (authenticated, non-agent)

    Frontend generates an Ed25519 keypair from a random seed (the agent's "password").
    Only the public key is sent here; the seed is given to the agent CLI.
    The agent's synthetic email is ``agentname.usr-XXXXXXXX@deploymentdomain``.
    The agent logs in via POST /user/login using this email + Ed25519 signature.

    Agent name must be composed of letters, digits, hyphens, and underscores only
    (must start with a letter or digit) so it is valid as an email local-part.

        Attributes:
            name (str):
            signing_key (str):
            recovery_key (None | str | Unset):
     """

    name: str
    signing_key: str
    recovery_key: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        signing_key = self.signing_key

        recovery_key: None | str | Unset
        if isinstance(self.recovery_key, Unset):
            recovery_key = UNSET
        else:
            recovery_key = self.recovery_key


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "name": name,
            "signing_key": signing_key,
        })
        if recovery_key is not UNSET:
            field_dict["recovery_key"] = recovery_key

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        signing_key = d.pop("signing_key")

        def _parse_recovery_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        recovery_key = _parse_recovery_key(d.pop("recovery_key", UNSET))


        create_agent_request = cls(
            name=name,
            signing_key=signing_key,
            recovery_key=recovery_key,
        )

        return create_agent_request

