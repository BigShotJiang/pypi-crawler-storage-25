from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="WorkspaceOpenRequest")



@_attrs_define
class WorkspaceOpenRequest:
    """ Request to open a workspace — stores encrypted key in session and sets active.

    workspace_key is required for users (SealedBox-encrypted with session public key).
    Agents omit it — their workspace keys are pre-populated via /agent-session.

        Attributes:
            workspace_key (None | str | Unset):
     """

    workspace_key: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        workspace_key: None | str | Unset
        if isinstance(self.workspace_key, Unset):
            workspace_key = UNSET
        else:
            workspace_key = self.workspace_key


        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if workspace_key is not UNSET:
            field_dict["workspace_key"] = workspace_key

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_workspace_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        workspace_key = _parse_workspace_key(d.pop("workspace_key", UNSET))


        workspace_open_request = cls(
            workspace_key=workspace_key,
        )

        return workspace_open_request

