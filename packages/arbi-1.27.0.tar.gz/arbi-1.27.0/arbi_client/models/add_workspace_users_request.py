from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.workspace_role import WorkspaceRole
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="AddWorkspaceUsersRequest")



@_attrs_define
class AddWorkspaceUsersRequest:
    """ Request to add users to a workspace (POST /workspace/users).

    All invited users receive the same role.

    workspace_key + workspace_ext_id (optional): If provided, the caller supplies the
    SealedBox-encrypted workspace key directly (encrypted with their session public key)
    and the target workspace external ID. This allows sharing any workspace the caller
    holds a key for without needing to open/activate it first. If omitted, the server
    falls back to the current session's active workspace.

    session_pubkey_b64 (optional): If set, the grant is temporary and scoped to the
    recipient's current session (identified by this X25519 public key). The workspace
    key is stored in that session's Redis entry and the workspaceusers row expires when
    the session expires. Omit for a permanent grant (default behaviour).

        Attributes:
            emails (list[str]):
            role (WorkspaceRole | Unset): Role of a user within a workspace.
            workspace_key (None | str | Unset):
            workspace_ext_id (None | str | Unset):
            session_pubkey_b64 (None | str | Unset):
     """

    emails: list[str]
    role: WorkspaceRole | Unset = UNSET
    workspace_key: None | str | Unset = UNSET
    workspace_ext_id: None | str | Unset = UNSET
    session_pubkey_b64: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        emails = self.emails



        role: str | Unset = UNSET
        if not isinstance(self.role, Unset):
            role = self.role.value


        workspace_key: None | str | Unset
        if isinstance(self.workspace_key, Unset):
            workspace_key = UNSET
        else:
            workspace_key = self.workspace_key

        workspace_ext_id: None | str | Unset
        if isinstance(self.workspace_ext_id, Unset):
            workspace_ext_id = UNSET
        else:
            workspace_ext_id = self.workspace_ext_id

        session_pubkey_b64: None | str | Unset
        if isinstance(self.session_pubkey_b64, Unset):
            session_pubkey_b64 = UNSET
        else:
            session_pubkey_b64 = self.session_pubkey_b64


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "emails": emails,
        })
        if role is not UNSET:
            field_dict["role"] = role
        if workspace_key is not UNSET:
            field_dict["workspace_key"] = workspace_key
        if workspace_ext_id is not UNSET:
            field_dict["workspace_ext_id"] = workspace_ext_id
        if session_pubkey_b64 is not UNSET:
            field_dict["session_pubkey_b64"] = session_pubkey_b64

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        emails = cast(list[str], d.pop("emails"))


        _role = d.pop("role", UNSET)
        role: WorkspaceRole | Unset
        if isinstance(_role,  Unset):
            role = UNSET
        else:
            role = WorkspaceRole(_role)




        def _parse_workspace_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        workspace_key = _parse_workspace_key(d.pop("workspace_key", UNSET))


        def _parse_workspace_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        workspace_ext_id = _parse_workspace_ext_id(d.pop("workspace_ext_id", UNSET))


        def _parse_session_pubkey_b64(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        session_pubkey_b64 = _parse_session_pubkey_b64(d.pop("session_pubkey_b64", UNSET))


        add_workspace_users_request = cls(
            emails=emails,
            role=role,
            workspace_key=workspace_key,
            workspace_ext_id=workspace_ext_id,
            session_pubkey_b64=session_pubkey_b64,
        )

        return add_workspace_users_request

