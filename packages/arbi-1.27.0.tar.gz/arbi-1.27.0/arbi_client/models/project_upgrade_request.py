from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="ProjectUpgradeRequest")



@_attrs_define
class ProjectUpgradeRequest:
    """ Change pack quantity on an existing project.

        Attributes:
            price_id (str):
            quantity (int):
            proration_behavior (str | Unset):  Default: 'create_prorations'.
     """

    price_id: str
    quantity: int
    proration_behavior: str | Unset = 'create_prorations'





    def to_dict(self) -> dict[str, Any]:
        price_id = self.price_id

        quantity = self.quantity

        proration_behavior = self.proration_behavior


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "price_id": price_id,
            "quantity": quantity,
        })
        if proration_behavior is not UNSET:
            field_dict["proration_behavior"] = proration_behavior

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        price_id = d.pop("price_id")

        quantity = d.pop("quantity")

        proration_behavior = d.pop("proration_behavior", UNSET)

        project_upgrade_request = cls(
            price_id=price_id,
            quantity=quantity,
            proration_behavior=proration_behavior,
        )

        return project_upgrade_request

