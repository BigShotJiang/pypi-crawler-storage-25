from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="WorkspaceUpdateRequest")



@_attrs_define
class WorkspaceUpdateRequest:
    """ 
        Attributes:
            name (None | str | Unset):
            description (None | str | Unset):
            is_public (bool | None | Unset):
            project_ext_id (None | str | Unset):
     """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    is_public: bool | None | Unset = UNSET
    project_ext_id: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        is_public: bool | None | Unset
        if isinstance(self.is_public, Unset):
            is_public = UNSET
        else:
            is_public = self.is_public

        project_ext_id: None | str | Unset
        if isinstance(self.project_ext_id, Unset):
            project_ext_id = UNSET
        else:
            project_ext_id = self.project_ext_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if is_public is not UNSET:
            field_dict["is_public"] = is_public
        if project_ext_id is not UNSET:
            field_dict["project_ext_id"] = project_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_is_public(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_public = _parse_is_public(d.pop("is_public", UNSET))


        def _parse_project_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        project_ext_id = _parse_project_ext_id(d.pop("project_ext_id", UNSET))


        workspace_update_request = cls(
            name=name,
            description=description,
            is_public=is_public,
            project_ext_id=project_ext_id,
        )

        return workspace_update_request

