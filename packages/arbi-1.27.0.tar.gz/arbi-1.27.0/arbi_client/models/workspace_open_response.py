from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.conversation_response import ConversationResponse
  from ..models.workspace_response import WorkspaceResponse





T = TypeVar("T", bound="WorkspaceOpenResponse")



@_attrs_define
class WorkspaceOpenResponse:
    """ Response from opening a workspace — workspace data (no new JWT).

        Attributes:
            workspace (WorkspaceResponse):
            conversations (list[ConversationResponse] | None | Unset):
            documents (list[Any] | None | Unset):
            tags (list[Any] | None | Unset):
     """

    workspace: WorkspaceResponse
    conversations: list[ConversationResponse] | None | Unset = UNSET
    documents: list[Any] | None | Unset = UNSET
    tags: list[Any] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.workspace_response import WorkspaceResponse
        from ..models.conversation_response import ConversationResponse
        workspace = self.workspace.to_dict()

        conversations: list[dict[str, Any]] | None | Unset
        if isinstance(self.conversations, Unset):
            conversations = UNSET
        elif isinstance(self.conversations, list):
            conversations = []
            for conversations_type_0_item_data in self.conversations:
                conversations_type_0_item = conversations_type_0_item_data.to_dict()
                conversations.append(conversations_type_0_item)


        else:
            conversations = self.conversations

        documents: list[Any] | None | Unset
        if isinstance(self.documents, Unset):
            documents = UNSET
        elif isinstance(self.documents, list):
            documents = self.documents


        else:
            documents = self.documents

        tags: list[Any] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags


        else:
            tags = self.tags


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "workspace": workspace,
        })
        if conversations is not UNSET:
            field_dict["conversations"] = conversations
        if documents is not UNSET:
            field_dict["documents"] = documents
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.conversation_response import ConversationResponse
        from ..models.workspace_response import WorkspaceResponse
        d = dict(src_dict)
        workspace = WorkspaceResponse.from_dict(d.pop("workspace"))




        def _parse_conversations(data: object) -> list[ConversationResponse] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                conversations_type_0 = []
                _conversations_type_0 = data
                for conversations_type_0_item_data in (_conversations_type_0):
                    conversations_type_0_item = ConversationResponse.from_dict(conversations_type_0_item_data)



                    conversations_type_0.append(conversations_type_0_item)

                return conversations_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ConversationResponse] | None | Unset, data)

        conversations = _parse_conversations(d.pop("conversations", UNSET))


        def _parse_documents(data: object) -> list[Any] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                documents_type_0 = cast(list[Any], data)

                return documents_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Any] | None | Unset, data)

        documents = _parse_documents(d.pop("documents", UNSET))


        def _parse_tags(data: object) -> list[Any] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[Any], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Any] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))


        workspace_open_response = cls(
            workspace=workspace,
            conversations=conversations,
            documents=documents,
            tags=tags,
        )


        workspace_open_response.additional_properties = d
        return workspace_open_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
