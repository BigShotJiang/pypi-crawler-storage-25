from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.reranker_config_api_type import RerankerConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="RerankerConfig")



@_attrs_define
class RerankerConfig:
    """ 
        Attributes:
            min_score (float | Unset): Minimum reranker score for a chunk to be kept. With the Qwen3 strict fact-matching
                instruction, relevant chunks score 0.1+ and noise is typically < 0.005. Default: 0.01.
            max_numb_of_chunks (int | Unset): Maximum number of chunks to return after reranking. Default: 30.
            max_concurrent_requests (int | Unset): Deployment-wide in-flight reranker requests — sized for ~5 replicas * ~50
                concurrent each. Default: 256.
            model_name (str | Unset): Name of the reranking model to use. Default: 'Qwen/Qwen3-Reranker-0.6B'.
            api_type (RerankerConfigApiType | Unset): The inference type (local or remote). Default:
                RerankerConfigApiType.LOCAL.
            retrieval_instruction (str | Unset): Instruction for the <Instruct> tag when reranking retrieval results against
                a user query. Default: 'Judge whether the passage contains the specific facts, figures, names, or references
                mentioned in the query. Only answer yes if the passage directly contains these details'.
     """

    min_score: float | Unset = 0.01
    max_numb_of_chunks: int | Unset = 30
    max_concurrent_requests: int | Unset = 256
    model_name: str | Unset = 'Qwen/Qwen3-Reranker-0.6B'
    api_type: RerankerConfigApiType | Unset = RerankerConfigApiType.LOCAL
    retrieval_instruction: str | Unset = 'Judge whether the passage contains the specific facts, figures, names, or references mentioned in the query. Only answer yes if the passage directly contains these details'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        min_score = self.min_score

        max_numb_of_chunks = self.max_numb_of_chunks

        max_concurrent_requests = self.max_concurrent_requests

        model_name = self.model_name

        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        retrieval_instruction = self.retrieval_instruction


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if min_score is not UNSET:
            field_dict["MIN_SCORE"] = min_score
        if max_numb_of_chunks is not UNSET:
            field_dict["MAX_NUMB_OF_CHUNKS"] = max_numb_of_chunks
        if max_concurrent_requests is not UNSET:
            field_dict["MAX_CONCURRENT_REQUESTS"] = max_concurrent_requests
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if retrieval_instruction is not UNSET:
            field_dict["RETRIEVAL_INSTRUCTION"] = retrieval_instruction

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        min_score = d.pop("MIN_SCORE", UNSET)

        max_numb_of_chunks = d.pop("MAX_NUMB_OF_CHUNKS", UNSET)

        max_concurrent_requests = d.pop("MAX_CONCURRENT_REQUESTS", UNSET)

        model_name = d.pop("MODEL_NAME", UNSET)

        _api_type = d.pop("API_TYPE", UNSET)
        api_type: RerankerConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = RerankerConfigApiType(_api_type)




        retrieval_instruction = d.pop("RETRIEVAL_INSTRUCTION", UNSET)

        reranker_config = cls(
            min_score=min_score,
            max_numb_of_chunks=max_numb_of_chunks,
            max_concurrent_requests=max_concurrent_requests,
            model_name=model_name,
            api_type=api_type,
            retrieval_instruction=retrieval_instruction,
        )


        reranker_config.additional_properties = d
        return reranker_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
