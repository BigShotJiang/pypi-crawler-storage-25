from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.model_group_usage_models import ModelGroupUsageModels





T = TypeVar("T", bound="ModelGroupUsage")



@_attrs_define
class ModelGroupUsage:
    """ Usage metrics for a model group (e.g. Fast, Wise, Premium) with per-model detail.

        Attributes:
            spend (float | Unset):  Default: 0.0.
            prompt_tokens (int | Unset):  Default: 0.
            completion_tokens (int | Unset):  Default: 0.
            total_tokens (int | Unset):  Default: 0.
            successful_requests (int | Unset):  Default: 0.
            failed_requests (int | Unset):  Default: 0.
            models (ModelGroupUsageModels | Unset):
     """

    spend: float | Unset = 0.0
    prompt_tokens: int | Unset = 0
    completion_tokens: int | Unset = 0
    total_tokens: int | Unset = 0
    successful_requests: int | Unset = 0
    failed_requests: int | Unset = 0
    models: ModelGroupUsageModels | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.model_group_usage_models import ModelGroupUsageModels
        spend = self.spend

        prompt_tokens = self.prompt_tokens

        completion_tokens = self.completion_tokens

        total_tokens = self.total_tokens

        successful_requests = self.successful_requests

        failed_requests = self.failed_requests

        models: dict[str, Any] | Unset = UNSET
        if not isinstance(self.models, Unset):
            models = self.models.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if spend is not UNSET:
            field_dict["spend"] = spend
        if prompt_tokens is not UNSET:
            field_dict["prompt_tokens"] = prompt_tokens
        if completion_tokens is not UNSET:
            field_dict["completion_tokens"] = completion_tokens
        if total_tokens is not UNSET:
            field_dict["total_tokens"] = total_tokens
        if successful_requests is not UNSET:
            field_dict["successful_requests"] = successful_requests
        if failed_requests is not UNSET:
            field_dict["failed_requests"] = failed_requests
        if models is not UNSET:
            field_dict["models"] = models

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.model_group_usage_models import ModelGroupUsageModels
        d = dict(src_dict)
        spend = d.pop("spend", UNSET)

        prompt_tokens = d.pop("prompt_tokens", UNSET)

        completion_tokens = d.pop("completion_tokens", UNSET)

        total_tokens = d.pop("total_tokens", UNSET)

        successful_requests = d.pop("successful_requests", UNSET)

        failed_requests = d.pop("failed_requests", UNSET)

        _models = d.pop("models", UNSET)
        models: ModelGroupUsageModels | Unset
        if isinstance(_models,  Unset):
            models = UNSET
        else:
            models = ModelGroupUsageModels.from_dict(_models)




        model_group_usage = cls(
            spend=spend,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            successful_requests=successful_requests,
            failed_requests=failed_requests,
            models=models,
        )


        model_group_usage.additional_properties = d
        return model_group_usage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
