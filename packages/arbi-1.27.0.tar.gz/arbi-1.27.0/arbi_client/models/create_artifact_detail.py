from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="CreateArtifactDetail")



@_attrs_define
class CreateArtifactDetail:
    """ Detail for a create_artifact tool call.

        Attributes:
            title (str): Artifact title (truncated to 80 chars)
            tool (Literal['create_artifact'] | Unset):  Default: 'create_artifact'.
            mode (str | Unset): Rendering mode: markdown, html, text Default: 'markdown'.
     """

    title: str
    tool: Literal['create_artifact'] | Unset = 'create_artifact'
    mode: str | Unset = 'markdown'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        title = self.title

        tool = self.tool

        mode = self.mode


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "title": title,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool
        if mode is not UNSET:
            field_dict["mode"] = mode

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        title = d.pop("title")

        tool = cast(Literal['create_artifact'] | Unset , d.pop("tool", UNSET))
        if tool != 'create_artifact'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'create_artifact', got '{tool}'")

        mode = d.pop("mode", UNSET)

        create_artifact_detail = cls(
            title=title,
            tool=tool,
            mode=mode,
        )


        create_artifact_detail.additional_properties = d
        return create_artifact_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
