from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.copy_document_result import CopyDocumentResult





T = TypeVar("T", bound="CopyResponse")



@_attrs_define
class CopyResponse:
    """ 
        Attributes:
            detail (str):
            documents_copied (int | Unset):  Default: 0.
            results (list[CopyDocumentResult] | Unset):
     """

    detail: str
    documents_copied: int | Unset = 0
    results: list[CopyDocumentResult] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.copy_document_result import CopyDocumentResult
        detail = self.detail

        documents_copied = self.documents_copied

        results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.results, Unset):
            results = []
            for results_item_data in self.results:
                results_item = results_item_data.to_dict()
                results.append(results_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "detail": detail,
        })
        if documents_copied is not UNSET:
            field_dict["documents_copied"] = documents_copied
        if results is not UNSET:
            field_dict["results"] = results

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.copy_document_result import CopyDocumentResult
        d = dict(src_dict)
        detail = d.pop("detail")

        documents_copied = d.pop("documents_copied", UNSET)

        _results = d.pop("results", UNSET)
        results: list[CopyDocumentResult] | Unset = UNSET
        if _results is not UNSET:
            results = []
            for results_item_data in _results:
                results_item = CopyDocumentResult.from_dict(results_item_data)



                results.append(results_item)


        copy_response = cls(
            detail=detail,
            documents_copied=documents_copied,
            results=results,
        )


        copy_response.additional_properties = d
        return copy_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
