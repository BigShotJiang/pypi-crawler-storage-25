from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.doc_sim_pair import DocSimPair





T = TypeVar("T", bound="DocSimResponse")



@_attrs_define
class DocSimResponse:
    """ Response for the near-duplicates endpoint.

        Attributes:
            workspace_ext_id (str):
            pairs (list[DocSimPair]):
     """

    workspace_ext_id: str
    pairs: list[DocSimPair]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.doc_sim_pair import DocSimPair
        workspace_ext_id = self.workspace_ext_id

        pairs = []
        for pairs_item_data in self.pairs:
            pairs_item = pairs_item_data.to_dict()
            pairs.append(pairs_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "workspace_ext_id": workspace_ext_id,
            "pairs": pairs,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.doc_sim_pair import DocSimPair
        d = dict(src_dict)
        workspace_ext_id = d.pop("workspace_ext_id")

        pairs = []
        _pairs = d.pop("pairs")
        for pairs_item_data in (_pairs):
            pairs_item = DocSimPair.from_dict(pairs_item_data)



            pairs.append(pairs_item)


        doc_sim_response = cls(
            workspace_ext_id=workspace_ext_id,
            pairs=pairs,
        )


        doc_sim_response.additional_properties = d
        return doc_sim_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
