from enum import Enum

class InitedUploadItemStatus(str, Enum):
    DUPLICATE = "duplicate"
    EMPTY = "empty"
    QUOTA_EXCEEDED = "quota_exceeded"
    UNSUPPORTED = "unsupported"
    UPLOADING = "uploading"

    def __str__(self) -> str:
        return str(self.value)
