"""Document helper functions for the ARBI SDK.

Handles file uploads (with WebSocket-based wait), listing, and deletion.
All functions accept the low-level building blocks (client, workspace ID, key header)
so that ``ArbiSession`` can delegate to them without coupling.
"""

from __future__ import annotations

import asyncio
import mimetypes
from collections.abc import Callable
from io import BytesIO
from pathlib import Path
from typing import Any

import httpx

from arbi_client.api.document import delete_documents as delete_documents_api
from arbi_client.api.document import upload_commit as upload_commit_api
from arbi_client.api.document import upload_documents as upload_documents_api
from arbi_client.api.document import upload_init as upload_init_api
from arbi_client.client import AuthenticatedClient
from arbi_client.models.declared_upload_file import DeclaredUploadFile
from arbi_client.models.delete_documents_request import DeleteDocumentsRequest
from arbi_client.models.inited_upload_item_status import InitedUploadItemStatus
from arbi_client.models.task_update_message import TaskUpdateMessage
from arbi_client.models.upload_commit_request import UploadCommitRequest
from arbi_client.models.upload_documents_body import UploadDocumentsBody
from arbi_client.models.upload_init_request import UploadInitRequest
from arbi_client.sdk.crypto import create_content_hash, encrypt_file
from arbi_client.sdk.websocket import ArbiWebSocket
from arbi_client.types import File


def _path_to_file(path: str | Path) -> File:
    """Read a file from disk into an :class:`File` suitable for upload."""
    p = Path(path)
    mime, _ = mimetypes.guess_type(p.name)
    if mime is None:
        mime = "application/octet-stream"
    return File(payload=BytesIO(p.read_bytes()), file_name=p.name, mime_type=mime)


def upload_documents(
    client: AuthenticatedClient,
    base_url: str,
    access_token: str,
    file_paths: list[str | Path],
    *,
    wait: bool = True,
    timeout: int = 300,
    shared: bool = True,
    config_ext_id: str | None = None,
    tag_ext_id: str | None = None,
    on_status: Callable[[TaskUpdateMessage], Any] | None = None,
) -> list[str]:
    """Upload files and optionally wait for processing via WebSocket.

    Args:
        client: Authenticated API client.
        base_url: API base URL (needed for WebSocket connection).
        access_token: JWT bearer token (workspace-scoped JWT).
        file_paths: Local file paths to upload.
        wait: If ``True`` (default), block until all documents reach a
            terminal status (``completed``, ``failed``, or ``skipped``)
            using a WebSocket connection.
        timeout: Maximum seconds to wait when *wait* is ``True``.
        shared: Whether documents are shared with workspace members.
        config_ext_id: Optional processing config.
        tag_ext_id: Optional tag to link documents to.
        on_status: Optional callback receiving a :class:`TaskUpdateMessage`
            for every status update via WebSocket while waiting.
            Only used when *wait* is ``True``.

    Returns:
        List of document external IDs in upload order.

    Raises:
        RuntimeError: If the upload API returns an error.
        TimeoutError: If *wait* is ``True`` and documents don't finish in time.
    """
    files = [_path_to_file(p) for p in file_paths]

    kwargs: dict[str, Any] = {
        "client": client,
        "body": UploadDocumentsBody(files=files),
        "shared": shared,
    }
    if config_ext_id is not None:
        kwargs["config_ext_id"] = config_ext_id
    if tag_ext_id is not None:
        kwargs["tag_ext_id"] = tag_ext_id

    # Use sync_detailed to get the full response (status code, headers) for debugging
    response = upload_documents_api.sync_detailed(**kwargs)
    result = response.parsed
    if result is None or not hasattr(result, "doc_ext_ids"):
        raise RuntimeError(
            f"Upload failed: status={response.status_code}, "
            f"body={response.content[:500] if response.content else None}, "
            f"parsed={result}"
        )

    doc_ext_ids: list[str] = result.doc_ext_ids

    if wait and doc_ext_ids:
        _wait_for_docs_sync(base_url, access_token, doc_ext_ids, timeout, on_status)

    return doc_ext_ids


def upload_documents_direct(
    client: AuthenticatedClient,
    base_url: str,
    access_token: str,
    file_paths: list[str | Path],
    workspace_key: bytes,
    *,
    wait: bool = True,
    timeout: int = 300,
    shared: bool = True,
    config_ext_id: str | None = None,
    parent_ext_id: str | None = None,
    wp_type: str | None = None,
    tag_ext_id: str | None = None,
    folder: str | None = None,
    on_status: Callable[[TaskUpdateMessage], Any] | None = None,
    verify_tls: bool = True,
) -> list[str]:
    """Upload files via the direct-to-MinIO flow (no bytes through arbi-app).

    Three HTTP phases:

    1. ``POST /v1/document/upload-init`` — declare files, get presigned PUT
       URLs for every ``uploading`` slot.
    2. ``PUT {upload_url}`` — SecretBox-encrypt each file with *workspace_key*
       and send the ciphertext straight to MinIO over the public
       ``/arbi-files/`` route. arbi-app is not in the byte path.
    3. ``POST /v1/document/upload-commit`` — HEAD-verify objects landed and
       flip the rows to ``queued``; the normal parse pipeline runs from
       there.

    Args:
        client: Authenticated API client (workspace-scoped JWT).
        base_url: API base URL (needed for the optional WS wait).
        access_token: JWT bearer token for the WS wait.
        file_paths: Local file paths to upload.
        workspace_key: Raw 32-byte workspace key — used both for the
            HMAC content hash (dedup) and the SecretBox file encryption.
            Caller is responsible for obtaining this (e.g. via
            ``ArbiSession._raw_workspace_key()``).
        wait: Block until all docs reach a terminal status via WebSocket.
        timeout: Max seconds to wait when *wait* is ``True``.
        shared: Share with workspace members.
        config_ext_id / parent_ext_id / wp_type / tag_ext_id / folder:
            Optional metadata forwarded to ``upload-init``.
        on_status: WS progress callback (same contract as ``upload_documents``).
        verify_tls: Set to ``False`` for local dev deployments with self-signed
            certs — the presigned PUT still carries its own SigV4 auth.

    Returns:
        List of document external IDs that reached the queued state (files
        rejected at init — unsupported/empty/quota — are dropped).
    """
    paths = [Path(p) for p in file_paths]
    raws = [p.read_bytes() for p in paths]
    # SecretBox envelope: 24-byte nonce prefix + 16-byte Poly1305 tag = 40 bytes.
    # Server validates this exact relationship at init and pins the actual
    # ciphertext size to it via a HEAD check at commit.
    SECRETBOX_ENVELOPE_OVERHEAD = 40
    declared = [
        DeclaredUploadFile(
            file_name=p.name,
            file_size=len(raw),
            encrypted_file_size=len(raw) + SECRETBOX_ENVELOPE_OVERHEAD,
            content_hash=create_content_hash(raw, workspace_key),
            content_type=mimetypes.guess_type(p.name)[0] or "application/octet-stream",
        )
        for p, raw in zip(paths, raws, strict=True)
    ]

    init_kwargs: dict[str, Any] = {"files": declared, "shared": shared}
    if config_ext_id is not None:
        init_kwargs["config_ext_id"] = config_ext_id
    if parent_ext_id is not None:
        init_kwargs["parent_ext_id"] = parent_ext_id
    if wp_type is not None:
        init_kwargs["wp_type"] = wp_type
    if tag_ext_id is not None:
        init_kwargs["tag_ext_id"] = tag_ext_id
    if folder is not None:
        init_kwargs["folder"] = folder

    init_resp = upload_init_api.sync(client=client, body=UploadInitRequest(**init_kwargs))
    if init_resp is None:
        raise RuntimeError("upload-init returned no response")

    # Match init items back to their raws by file_name. Duplicate file names
    # within a single batch are allowed by the server but ambiguous here —
    # resolve in declaration order by popping from a per-name queue.
    raws_by_name: dict[str, list[bytes]] = {}
    for p, raw in zip(paths, raws, strict=True):
        raws_by_name.setdefault(p.name, []).append(raw)

    to_put: list[tuple[str, str, bytes]] = []  # (doc_ext_id, upload_url, ciphertext)
    accepted_ids: list[str] = []
    for item in init_resp.items:
        if item.status != InitedUploadItemStatus.UPLOADING:
            continue  # duplicate/unsupported/empty/quota_exceeded — server rejected it cleanly
        raw = raws_by_name[item.file_name].pop(0)
        to_put.append((item.doc_ext_id, item.upload_url, encrypt_file(raw, workspace_key)))
        accepted_ids.append(item.doc_ext_id)

    # Sequential PUTs are fine at this scale; we're not chasing throughput.
    with httpx.Client(timeout=httpx.Timeout(300.0, connect=10.0), verify=verify_tls) as http:
        for doc_ext_id, url, ciphertext in to_put:
            resp = http.put(url, content=ciphertext)
            if resp.status_code not in (200, 204):
                raise RuntimeError(
                    f"Presigned PUT for {doc_ext_id} failed: "
                    f"{resp.status_code} {resp.text[:200]}"
                )

    if not accepted_ids:
        return []

    commit_kwargs: dict[str, Any] = {"doc_ext_ids": accepted_ids}
    if tag_ext_id is not None:
        commit_kwargs["tag_ext_id"] = tag_ext_id
    commit_resp = upload_commit_api.sync(
        client=client, body=UploadCommitRequest(**commit_kwargs)
    )
    if commit_resp is None:
        raise RuntimeError("upload-commit returned no response")

    committed_ids: list[str] = list(commit_resp.doc_ext_ids)

    if wait and committed_ids:
        final = _wait_for_docs_sync(base_url, access_token, committed_ids, timeout, on_status)
        failed = [doc_id for doc_id, status in final.items() if status == "failed"]
        if failed:
            raise RuntimeError(
                f"Direct upload: {len(failed)} of {len(committed_ids)} documents "
                f"failed during processing: {failed}"
            )

    return committed_ids


def _wait_for_docs_sync(
    base_url: str,
    access_token: str,
    doc_ext_ids: list[str],
    timeout: int,
    on_status: Callable[[TaskUpdateMessage], Any] | None = None,
) -> dict[str, str]:
    """Block until documents reach terminal status using WebSocket."""

    async def _inner() -> dict[str, str]:
        async with ArbiWebSocket(base_url=base_url, access_token=access_token) as ws:
            return await ws.wait_for_docs(doc_ext_ids, timeout=timeout, on_status=on_status)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None and loop.is_running():
        # Already inside an event loop — run in a new thread
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, _inner()).result(timeout=timeout + 5)
    else:
        return asyncio.run(_inner())


def list_documents(
    client: AuthenticatedClient,
) -> list:
    """List all documents in the active workspace.

    Returns the list of document objects from the API.
    The workspace is identified by the workspace-scoped JWT in the client's auth header.
    """
    from arbi_client.api.document import list_documents as list_documents_api

    result = list_documents_api.sync(client=client)
    if result is None:
        return []
    if isinstance(result, list):
        return result
    raise RuntimeError(f"List documents failed: {result}")


def delete_documents(
    client: AuthenticatedClient,
    doc_ext_ids: list[str],
) -> Any:
    """Delete documents by their external IDs.

    Returns the API response.
    """
    return delete_documents_api.sync(
        client=client,
        body=DeleteDocumentsRequest(external_ids=doc_ext_ids),
    )
