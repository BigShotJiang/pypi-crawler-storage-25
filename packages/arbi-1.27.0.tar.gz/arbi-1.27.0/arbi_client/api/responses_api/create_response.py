from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.message_input import MessageInput
from ...models.responses_api_response import ResponsesAPIResponse
from typing import cast



def _get_kwargs(
    *,
    body: MessageInput,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/responses",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | HTTPValidationError | ResponsesAPIResponse | None:
    if response.status_code == 200:
        response_200 = cast(Any, None)
        return response_200

    if response.status_code == 202:
        response_202 = ResponsesAPIResponse.from_dict(response.json())



        return response_202

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | HTTPValidationError | ResponsesAPIResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MessageInput,

) -> Response[Any | HTTPValidationError | ResponsesAPIResponse]:
    """ Create Response

     Create a model response (OpenAI Responses API).

    Supports all combinations of ``stream`` and ``background``:
    - ``stream=false, background=false``: blocks, returns completed JSON
    - ``stream=true,  background=false``: SSE stream (resilient to disconnect)
    - ``background=true``: 202 immediately, task runs to completion

    Args:
        body (MessageInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | ResponsesAPIResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: MessageInput,

) -> Any | HTTPValidationError | ResponsesAPIResponse | None:
    """ Create Response

     Create a model response (OpenAI Responses API).

    Supports all combinations of ``stream`` and ``background``:
    - ``stream=false, background=false``: blocks, returns completed JSON
    - ``stream=true,  background=false``: SSE stream (resilient to disconnect)
    - ``background=true``: 202 immediately, task runs to completion

    Args:
        body (MessageInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | ResponsesAPIResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MessageInput,

) -> Response[Any | HTTPValidationError | ResponsesAPIResponse]:
    """ Create Response

     Create a model response (OpenAI Responses API).

    Supports all combinations of ``stream`` and ``background``:
    - ``stream=false, background=false``: blocks, returns completed JSON
    - ``stream=true,  background=false``: SSE stream (resilient to disconnect)
    - ``background=true``: 202 immediately, task runs to completion

    Args:
        body (MessageInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | ResponsesAPIResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: MessageInput,

) -> Any | HTTPValidationError | ResponsesAPIResponse | None:
    """ Create Response

     Create a model response (OpenAI Responses API).

    Supports all combinations of ``stream`` and ``background``:
    - ``stream=false, background=false``: blocks, returns completed JSON
    - ``stream=true,  background=false``: SSE stream (resilient to disconnect)
    - ``background=true``: 202 immediately, task runs to completion

    Args:
        body (MessageInput):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | ResponsesAPIResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
