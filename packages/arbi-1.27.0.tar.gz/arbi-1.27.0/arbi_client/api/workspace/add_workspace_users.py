from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.add_workspace_users_request import AddWorkspaceUsersRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.workspace_user_response import WorkspaceUserResponse
from typing import cast



def _get_kwargs(
    *,
    body: AddWorkspaceUsersRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/workspace/users",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | list[WorkspaceUserResponse] | None:
    if response.status_code == 201:
        response_201 = []
        _response_201 = response.json()
        for response_201_item_data in (_response_201):
            response_201_item = WorkspaceUserResponse.from_dict(response_201_item_data)



            response_201.append(response_201_item)

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | list[WorkspaceUserResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AddWorkspaceUsersRequest,

) -> Response[HTTPValidationError | list[WorkspaceUserResponse]]:
    """ Add Workspace Users

     Add users to a workspace (bulk operation). Only workspace owners can add users.

    Two modes:
    1. Body supplies ``workspace_key`` + ``workspace_ext_id``: caller provides the
       SealedBox-encrypted workspace key (encrypted with their session public key).
       The workspace need not be open/active on the session. This allows sharing any
       workspace for which the caller holds a key (e.g. from their login response).
    2. No body key: server falls back to the session's current active workspace.

    Wraps the workspace key with each recipient's X25519 public key (permanent grant)
    or deposits it into their Redis session (temporary grant when session_pubkey_b64 is set).
    Returns the full WorkspaceUserResponse for each successfully added user.

    Args:
        body (AddWorkspaceUsersRequest): Request to add users to a workspace (POST
            /workspace/users).

            All invited users receive the same role.

            workspace_key + workspace_ext_id (optional): If provided, the caller supplies the
            SealedBox-encrypted workspace key directly (encrypted with their session public key)
            and the target workspace external ID. This allows sharing any workspace the caller
            holds a key for without needing to open/activate it first. If omitted, the server
            falls back to the current session's active workspace.

            session_pubkey_b64 (optional): If set, the grant is temporary and scoped to the
            recipient's current session (identified by this X25519 public key). The workspace
            key is stored in that session's Redis entry and the workspaceusers row expires when
            the session expires. Omit for a permanent grant (default behaviour).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkspaceUserResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AddWorkspaceUsersRequest,

) -> HTTPValidationError | list[WorkspaceUserResponse] | None:
    """ Add Workspace Users

     Add users to a workspace (bulk operation). Only workspace owners can add users.

    Two modes:
    1. Body supplies ``workspace_key`` + ``workspace_ext_id``: caller provides the
       SealedBox-encrypted workspace key (encrypted with their session public key).
       The workspace need not be open/active on the session. This allows sharing any
       workspace for which the caller holds a key (e.g. from their login response).
    2. No body key: server falls back to the session's current active workspace.

    Wraps the workspace key with each recipient's X25519 public key (permanent grant)
    or deposits it into their Redis session (temporary grant when session_pubkey_b64 is set).
    Returns the full WorkspaceUserResponse for each successfully added user.

    Args:
        body (AddWorkspaceUsersRequest): Request to add users to a workspace (POST
            /workspace/users).

            All invited users receive the same role.

            workspace_key + workspace_ext_id (optional): If provided, the caller supplies the
            SealedBox-encrypted workspace key directly (encrypted with their session public key)
            and the target workspace external ID. This allows sharing any workspace the caller
            holds a key for without needing to open/activate it first. If omitted, the server
            falls back to the current session's active workspace.

            session_pubkey_b64 (optional): If set, the grant is temporary and scoped to the
            recipient's current session (identified by this X25519 public key). The workspace
            key is stored in that session's Redis entry and the workspaceusers row expires when
            the session expires. Omit for a permanent grant (default behaviour).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkspaceUserResponse]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AddWorkspaceUsersRequest,

) -> Response[HTTPValidationError | list[WorkspaceUserResponse]]:
    """ Add Workspace Users

     Add users to a workspace (bulk operation). Only workspace owners can add users.

    Two modes:
    1. Body supplies ``workspace_key`` + ``workspace_ext_id``: caller provides the
       SealedBox-encrypted workspace key (encrypted with their session public key).
       The workspace need not be open/active on the session. This allows sharing any
       workspace for which the caller holds a key (e.g. from their login response).
    2. No body key: server falls back to the session's current active workspace.

    Wraps the workspace key with each recipient's X25519 public key (permanent grant)
    or deposits it into their Redis session (temporary grant when session_pubkey_b64 is set).
    Returns the full WorkspaceUserResponse for each successfully added user.

    Args:
        body (AddWorkspaceUsersRequest): Request to add users to a workspace (POST
            /workspace/users).

            All invited users receive the same role.

            workspace_key + workspace_ext_id (optional): If provided, the caller supplies the
            SealedBox-encrypted workspace key directly (encrypted with their session public key)
            and the target workspace external ID. This allows sharing any workspace the caller
            holds a key for without needing to open/activate it first. If omitted, the server
            falls back to the current session's active workspace.

            session_pubkey_b64 (optional): If set, the grant is temporary and scoped to the
            recipient's current session (identified by this X25519 public key). The workspace
            key is stored in that session's Redis entry and the workspaceusers row expires when
            the session expires. Omit for a permanent grant (default behaviour).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkspaceUserResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AddWorkspaceUsersRequest,

) -> HTTPValidationError | list[WorkspaceUserResponse] | None:
    """ Add Workspace Users

     Add users to a workspace (bulk operation). Only workspace owners can add users.

    Two modes:
    1. Body supplies ``workspace_key`` + ``workspace_ext_id``: caller provides the
       SealedBox-encrypted workspace key (encrypted with their session public key).
       The workspace need not be open/active on the session. This allows sharing any
       workspace for which the caller holds a key (e.g. from their login response).
    2. No body key: server falls back to the session's current active workspace.

    Wraps the workspace key with each recipient's X25519 public key (permanent grant)
    or deposits it into their Redis session (temporary grant when session_pubkey_b64 is set).
    Returns the full WorkspaceUserResponse for each successfully added user.

    Args:
        body (AddWorkspaceUsersRequest): Request to add users to a workspace (POST
            /workspace/users).

            All invited users receive the same role.

            workspace_key + workspace_ext_id (optional): If provided, the caller supplies the
            SealedBox-encrypted workspace key directly (encrypted with their session public key)
            and the target workspace external ID. This allows sharing any workspace the caller
            holds a key for without needing to open/activate it first. If omitted, the server
            falls back to the current session's active workspace.

            session_pubkey_b64 (optional): If set, the grant is temporary and scoped to the
            recipient's current session (identified by this X25519 public key). The workspace
            key is stored in that session's Redis entry and the workspaceusers row expires when
            the session expires. Omit for a permanent grant (default behaviour).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkspaceUserResponse]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
