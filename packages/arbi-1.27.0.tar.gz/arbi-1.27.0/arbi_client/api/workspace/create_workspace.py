from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.workspace_create_request import WorkspaceCreateRequest
from ...models.workspace_response import WorkspaceResponse
from typing import cast



def _get_kwargs(
    *,
    body: WorkspaceCreateRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/workspace/create_protected",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | WorkspaceResponse | None:
    if response.status_code == 200:
        response_200 = WorkspaceResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | WorkspaceResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceCreateRequest,

) -> Response[HTTPValidationError | WorkspaceResponse]:
    """ Create Protected Workspace

     Create a new workspace with encryption and access controls.
    Sets up vector storage and associates the creator as the initial workspace user.

    Client generates the workspace symmetric key and sends it encrypted with the
    session key (SecretBox). Server decrypts and wraps it with the user's
    public key for storage. The wrapped key is returned in the response.

    Public workspaces are visible to all users and grant non-members limited access:
    - Non-members can view shared documents and tags
    - Non-members can create conversations and send messages
    - Only members can upload documents
    - Only members can see the member list

    Only users with developer flag can create public workspaces.

    Args:
        body (WorkspaceCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceCreateRequest,

) -> HTTPValidationError | WorkspaceResponse | None:
    """ Create Protected Workspace

     Create a new workspace with encryption and access controls.
    Sets up vector storage and associates the creator as the initial workspace user.

    Client generates the workspace symmetric key and sends it encrypted with the
    session key (SecretBox). Server decrypts and wraps it with the user's
    public key for storage. The wrapped key is returned in the response.

    Public workspaces are visible to all users and grant non-members limited access:
    - Non-members can view shared documents and tags
    - Non-members can create conversations and send messages
    - Only members can upload documents
    - Only members can see the member list

    Only users with developer flag can create public workspaces.

    Args:
        body (WorkspaceCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceCreateRequest,

) -> Response[HTTPValidationError | WorkspaceResponse]:
    """ Create Protected Workspace

     Create a new workspace with encryption and access controls.
    Sets up vector storage and associates the creator as the initial workspace user.

    Client generates the workspace symmetric key and sends it encrypted with the
    session key (SecretBox). Server decrypts and wraps it with the user's
    public key for storage. The wrapped key is returned in the response.

    Public workspaces are visible to all users and grant non-members limited access:
    - Non-members can view shared documents and tags
    - Non-members can create conversations and send messages
    - Only members can upload documents
    - Only members can see the member list

    Only users with developer flag can create public workspaces.

    Args:
        body (WorkspaceCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: WorkspaceCreateRequest,

) -> HTTPValidationError | WorkspaceResponse | None:
    """ Create Protected Workspace

     Create a new workspace with encryption and access controls.
    Sets up vector storage and associates the creator as the initial workspace user.

    Client generates the workspace symmetric key and sends it encrypted with the
    session key (SecretBox). Server decrypts and wraps it with the user's
    public key for storage. The wrapped key is returned in the response.

    Public workspaces are visible to all users and grant non-members limited access:
    - Non-members can view shared documents and tags
    - Non-members can create conversations and send messages
    - Only members can upload documents
    - Only members can see the member list

    Only users with developer flag can create public workspaces.

    Args:
        body (WorkspaceCreateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
