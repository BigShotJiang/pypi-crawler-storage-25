from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.conversation_title_update_request import ConversationTitleUpdateRequest
from ...models.conversation_title_update_response import ConversationTitleUpdateResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    conversation_ext_id: str,
    *,
    body: ConversationTitleUpdateRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/conversation/{conversation_ext_id}/title".format(conversation_ext_id=quote(str(conversation_ext_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ConversationTitleUpdateResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ConversationTitleUpdateResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ConversationTitleUpdateResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConversationTitleUpdateRequest,

) -> Response[ConversationTitleUpdateResponse | HTTPValidationError]:
    """ Update Conversation Title

     Update a conversation title.
    RLS ensures the user can only update conversations they have access to.

    Args:
        conversation_ext_id (str):
        body (ConversationTitleUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationTitleUpdateResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        conversation_ext_id=conversation_ext_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConversationTitleUpdateRequest,

) -> ConversationTitleUpdateResponse | HTTPValidationError | None:
    """ Update Conversation Title

     Update a conversation title.
    RLS ensures the user can only update conversations they have access to.

    Args:
        conversation_ext_id (str):
        body (ConversationTitleUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationTitleUpdateResponse | HTTPValidationError
     """


    return sync_detailed(
        conversation_ext_id=conversation_ext_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConversationTitleUpdateRequest,

) -> Response[ConversationTitleUpdateResponse | HTTPValidationError]:
    """ Update Conversation Title

     Update a conversation title.
    RLS ensures the user can only update conversations they have access to.

    Args:
        conversation_ext_id (str):
        body (ConversationTitleUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationTitleUpdateResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        conversation_ext_id=conversation_ext_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    conversation_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ConversationTitleUpdateRequest,

) -> ConversationTitleUpdateResponse | HTTPValidationError | None:
    """ Update Conversation Title

     Update a conversation title.
    RLS ensures the user can only update conversations they have access to.

    Args:
        conversation_ext_id (str):
        body (ConversationTitleUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationTitleUpdateResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        conversation_ext_id=conversation_ext_id,
client=client,
body=body,

    )).parsed
