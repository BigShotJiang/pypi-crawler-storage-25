from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.notification_response import NotificationResponse
from ...models.send_message_request import SendMessageRequest
from typing import cast



def _get_kwargs(
    *,
    body: SendMessageRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/notifications/",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | list[NotificationResponse] | None:
    if response.status_code == 201:
        response_201 = []
        _response_201 = response.json()
        for response_201_item_data in (_response_201):
            response_201_item = NotificationResponse.from_dict(response_201_item_data)



            response_201.append(response_201_item)

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | list[NotificationResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,

) -> Response[HTTPValidationError | list[NotificationResponse]]:
    """ Send Messages

     Send E2E encrypted messages to one or more users.

    Each message is encrypted with the recipient's individual shared key.
    Creates bilateral notifications visible to both sender and recipient.
    If recipient is online via WebSocket, delivers in real-time.

    Returns the created notifications.

    Args:
        body (SendMessageRequest): Send E2E encrypted messages to one or more users.

            Each recipient gets the same logical message, encrypted with their
            individual shared key (derived from X25519 DH).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[NotificationResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,

) -> HTTPValidationError | list[NotificationResponse] | None:
    """ Send Messages

     Send E2E encrypted messages to one or more users.

    Each message is encrypted with the recipient's individual shared key.
    Creates bilateral notifications visible to both sender and recipient.
    If recipient is online via WebSocket, delivers in real-time.

    Returns the created notifications.

    Args:
        body (SendMessageRequest): Send E2E encrypted messages to one or more users.

            Each recipient gets the same logical message, encrypted with their
            individual shared key (derived from X25519 DH).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[NotificationResponse]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,

) -> Response[HTTPValidationError | list[NotificationResponse]]:
    """ Send Messages

     Send E2E encrypted messages to one or more users.

    Each message is encrypted with the recipient's individual shared key.
    Creates bilateral notifications visible to both sender and recipient.
    If recipient is online via WebSocket, delivers in real-time.

    Returns the created notifications.

    Args:
        body (SendMessageRequest): Send E2E encrypted messages to one or more users.

            Each recipient gets the same logical message, encrypted with their
            individual shared key (derived from X25519 DH).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[NotificationResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,

) -> HTTPValidationError | list[NotificationResponse] | None:
    """ Send Messages

     Send E2E encrypted messages to one or more users.

    Each message is encrypted with the recipient's individual shared key.
    Creates bilateral notifications visible to both sender and recipient.
    If recipient is online via WebSocket, delivers in real-time.

    Returns the created notifications.

    Args:
        body (SendMessageRequest): Send E2E encrypted messages to one or more users.

            Each recipient gets the same logical message, encrypted with their
            individual shared key (derived from X25519 DH).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[NotificationResponse]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
