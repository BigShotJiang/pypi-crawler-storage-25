from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.notification_response import NotificationResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    limit: int | Unset = 100,
    offset: int | Unset = 0,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/notifications/",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | list[NotificationResponse] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in (_response_200):
            response_200_item = NotificationResponse.from_dict(response_200_item_data)



            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | list[NotificationResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,

) -> Response[HTTPValidationError | list[NotificationResponse]]:
    """ Get Notifications

     Retrieve notifications for the current user, newest first.

    Bilateral model: user sees notifications they sent OR received. Capped at
    ``limit`` (default 100) so the response stays small for chatty users.
    Use POST /notifications/read to mark specific notifications as read.

    Args:
        limit (int | Unset): Maximum number of notifications to return, newest first. Defaults to
            100 — almost everyone only cares about the latest. Increase or page via offset to walk
            further back in history. Default: 100.
        offset (int | Unset): Number of notifications to skip from the newest, for paging.
            Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[NotificationResponse]]
     """


    kwargs = _get_kwargs(
        limit=limit,
offset=offset,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,

) -> HTTPValidationError | list[NotificationResponse] | None:
    """ Get Notifications

     Retrieve notifications for the current user, newest first.

    Bilateral model: user sees notifications they sent OR received. Capped at
    ``limit`` (default 100) so the response stays small for chatty users.
    Use POST /notifications/read to mark specific notifications as read.

    Args:
        limit (int | Unset): Maximum number of notifications to return, newest first. Defaults to
            100 — almost everyone only cares about the latest. Increase or page via offset to walk
            further back in history. Default: 100.
        offset (int | Unset): Number of notifications to skip from the newest, for paging.
            Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[NotificationResponse]
     """


    return sync_detailed(
        client=client,
limit=limit,
offset=offset,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,

) -> Response[HTTPValidationError | list[NotificationResponse]]:
    """ Get Notifications

     Retrieve notifications for the current user, newest first.

    Bilateral model: user sees notifications they sent OR received. Capped at
    ``limit`` (default 100) so the response stays small for chatty users.
    Use POST /notifications/read to mark specific notifications as read.

    Args:
        limit (int | Unset): Maximum number of notifications to return, newest first. Defaults to
            100 — almost everyone only cares about the latest. Increase or page via offset to walk
            further back in history. Default: 100.
        offset (int | Unset): Number of notifications to skip from the newest, for paging.
            Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[NotificationResponse]]
     """


    kwargs = _get_kwargs(
        limit=limit,
offset=offset,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,

) -> HTTPValidationError | list[NotificationResponse] | None:
    """ Get Notifications

     Retrieve notifications for the current user, newest first.

    Bilateral model: user sees notifications they sent OR received. Capped at
    ``limit`` (default 100) so the response stays small for chatty users.
    Use POST /notifications/read to mark specific notifications as read.

    Args:
        limit (int | Unset): Maximum number of notifications to return, newest first. Defaults to
            100 — almost everyone only cares about the latest. Increase or page via offset to walk
            further back in history. Default: 100.
        offset (int | Unset): Number of notifications to skip from the newest, for paging.
            Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[NotificationResponse]
     """


    return (await asyncio_detailed(
        client=client,
limit=limit,
offset=offset,

    )).parsed
