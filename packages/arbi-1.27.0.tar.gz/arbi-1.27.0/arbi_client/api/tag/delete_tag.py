from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.delete_tag_response import DeleteTagResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    tag_ext_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/tag/{tag_ext_id}".format(tag_ext_id=quote(str(tag_ext_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteTagResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DeleteTagResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DeleteTagResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tag_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteTagResponse | HTTPValidationError]:
    """ Delete Tag

     Delete a tag by its external ID.

    Args:
        tag_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteTagResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        tag_ext_id=tag_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    tag_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteTagResponse | HTTPValidationError | None:
    """ Delete Tag

     Delete a tag by its external ID.

    Args:
        tag_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteTagResponse | HTTPValidationError
     """


    return sync_detailed(
        tag_ext_id=tag_ext_id,
client=client,

    ).parsed

async def asyncio_detailed(
    tag_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[DeleteTagResponse | HTTPValidationError]:
    """ Delete Tag

     Delete a tag by its external ID.

    Args:
        tag_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteTagResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        tag_ext_id=tag_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    tag_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> DeleteTagResponse | HTTPValidationError | None:
    """ Delete Tag

     Delete a tag by its external ID.

    Args:
        tag_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteTagResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        tag_ext_id=tag_ext_id,
client=client,

    )).parsed
