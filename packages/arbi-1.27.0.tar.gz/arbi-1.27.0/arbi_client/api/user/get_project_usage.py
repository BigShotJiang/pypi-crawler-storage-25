from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.project_usage_response import ProjectUsageResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    project_ext_id: str,
    *,
    months_back: int | Unset = 0,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["months_back"] = months_back


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/user/projects/{project_ext_id}/usage".format(project_ext_id=quote(str(project_ext_id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | ProjectUsageResponse | None:
    if response.status_code == 200:
        response_200 = ProjectUsageResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | ProjectUsageResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    months_back: int | Unset = 0,

) -> Response[HTTPValidationError | ProjectUsageResponse]:
    """ Get Project Usage Endpoint

     Get AI usage breakdown for a project's billing period.

    Args:
        project_ext_id (str):
        months_back (int | Unset): 0 = current billing period, 1 = previous month, etc. Default:
            0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectUsageResponse]
     """


    kwargs = _get_kwargs(
        project_ext_id=project_ext_id,
months_back=months_back,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    months_back: int | Unset = 0,

) -> HTTPValidationError | ProjectUsageResponse | None:
    """ Get Project Usage Endpoint

     Get AI usage breakdown for a project's billing period.

    Args:
        project_ext_id (str):
        months_back (int | Unset): 0 = current billing period, 1 = previous month, etc. Default:
            0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectUsageResponse
     """


    return sync_detailed(
        project_ext_id=project_ext_id,
client=client,
months_back=months_back,

    ).parsed

async def asyncio_detailed(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    months_back: int | Unset = 0,

) -> Response[HTTPValidationError | ProjectUsageResponse]:
    """ Get Project Usage Endpoint

     Get AI usage breakdown for a project's billing period.

    Args:
        project_ext_id (str):
        months_back (int | Unset): 0 = current billing period, 1 = previous month, etc. Default:
            0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectUsageResponse]
     """


    kwargs = _get_kwargs(
        project_ext_id=project_ext_id,
months_back=months_back,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    months_back: int | Unset = 0,

) -> HTTPValidationError | ProjectUsageResponse | None:
    """ Get Project Usage Endpoint

     Get AI usage breakdown for a project's billing period.

    Args:
        project_ext_id (str):
        months_back (int | Unset): 0 = current billing period, 1 = previous month, etc. Default:
            0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectUsageResponse
     """


    return (await asyncio_detailed(
        project_ext_id=project_ext_id,
client=client,
months_back=months_back,

    )).parsed
