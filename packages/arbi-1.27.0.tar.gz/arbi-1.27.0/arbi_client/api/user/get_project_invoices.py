from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.project_invoices_response import ProjectInvoicesResponse
from typing import cast



def _get_kwargs(
    project_ext_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/user/projects/{project_ext_id}/invoices".format(project_ext_id=quote(str(project_ext_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | ProjectInvoicesResponse | None:
    if response.status_code == 200:
        response_200 = ProjectInvoicesResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | ProjectInvoicesResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | ProjectInvoicesResponse]:
    """ Get Project Invoices

     List Stripe invoices for a project's subscription.

    Args:
        project_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectInvoicesResponse]
     """


    kwargs = _get_kwargs(
        project_ext_id=project_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | ProjectInvoicesResponse | None:
    """ Get Project Invoices

     List Stripe invoices for a project's subscription.

    Args:
        project_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectInvoicesResponse
     """


    return sync_detailed(
        project_ext_id=project_ext_id,
client=client,

    ).parsed

async def asyncio_detailed(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | ProjectInvoicesResponse]:
    """ Get Project Invoices

     List Stripe invoices for a project's subscription.

    Args:
        project_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectInvoicesResponse]
     """


    kwargs = _get_kwargs(
        project_ext_id=project_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | ProjectInvoicesResponse | None:
    """ Get Project Invoices

     List Stripe invoices for a project's subscription.

    Args:
        project_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectInvoicesResponse
     """


    return (await asyncio_detailed(
        project_ext_id=project_ext_id,
client=client,

    )).parsed
