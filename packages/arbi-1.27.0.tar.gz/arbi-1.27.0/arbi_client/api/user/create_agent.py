from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_agent_request import CreateAgentRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.user_response import UserResponse
from typing import cast



def _get_kwargs(
    *,
    body: CreateAgentRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/agent",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | UserResponse | None:
    if response.status_code == 201:
        response_201 = UserResponse.from_dict(response.json())



        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | UserResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateAgentRequest,

) -> Response[HTTPValidationError | UserResponse]:
    """ Create Agent

     Create a persistent agent owned by the current user.

    The frontend generates an Ed25519 keypair from a random seed (the agent's password).
    Only the public key is sent here.  The agent logs in via POST /user/login using its
    synthetic email (``agentname.usr-XXXXXXXX@deploymentdomain``) and a signature derived
    from the seed.

    Workspace access is granted separately via POST /workspace/{id}/users.

    Args:
        body (CreateAgentRequest): Create a persistent agent owned by the current user.

            Used by: POST /user/agent (authenticated, non-agent)

            Frontend generates an Ed25519 keypair from a random seed (the agent's "password").
            Only the public key is sent here; the seed is given to the agent CLI.
            The agent's synthetic email is ``agentname.usr-XXXXXXXX@deploymentdomain``.
            The agent logs in via POST /user/login using this email + Ed25519 signature.

            Agent name must be composed of letters, digits, hyphens, and underscores only
            (must start with a letter or digit) so it is valid as an email local-part.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateAgentRequest,

) -> HTTPValidationError | UserResponse | None:
    """ Create Agent

     Create a persistent agent owned by the current user.

    The frontend generates an Ed25519 keypair from a random seed (the agent's password).
    Only the public key is sent here.  The agent logs in via POST /user/login using its
    synthetic email (``agentname.usr-XXXXXXXX@deploymentdomain``) and a signature derived
    from the seed.

    Workspace access is granted separately via POST /workspace/{id}/users.

    Args:
        body (CreateAgentRequest): Create a persistent agent owned by the current user.

            Used by: POST /user/agent (authenticated, non-agent)

            Frontend generates an Ed25519 keypair from a random seed (the agent's "password").
            Only the public key is sent here; the seed is given to the agent CLI.
            The agent's synthetic email is ``agentname.usr-XXXXXXXX@deploymentdomain``.
            The agent logs in via POST /user/login using this email + Ed25519 signature.

            Agent name must be composed of letters, digits, hyphens, and underscores only
            (must start with a letter or digit) so it is valid as an email local-part.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateAgentRequest,

) -> Response[HTTPValidationError | UserResponse]:
    """ Create Agent

     Create a persistent agent owned by the current user.

    The frontend generates an Ed25519 keypair from a random seed (the agent's password).
    Only the public key is sent here.  The agent logs in via POST /user/login using its
    synthetic email (``agentname.usr-XXXXXXXX@deploymentdomain``) and a signature derived
    from the seed.

    Workspace access is granted separately via POST /workspace/{id}/users.

    Args:
        body (CreateAgentRequest): Create a persistent agent owned by the current user.

            Used by: POST /user/agent (authenticated, non-agent)

            Frontend generates an Ed25519 keypair from a random seed (the agent's "password").
            Only the public key is sent here; the seed is given to the agent CLI.
            The agent's synthetic email is ``agentname.usr-XXXXXXXX@deploymentdomain``.
            The agent logs in via POST /user/login using this email + Ed25519 signature.

            Agent name must be composed of letters, digits, hyphens, and underscores only
            (must start with a letter or digit) so it is valid as an email local-part.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateAgentRequest,

) -> HTTPValidationError | UserResponse | None:
    """ Create Agent

     Create a persistent agent owned by the current user.

    The frontend generates an Ed25519 keypair from a random seed (the agent's password).
    Only the public key is sent here.  The agent logs in via POST /user/login using its
    synthetic email (``agentname.usr-XXXXXXXX@deploymentdomain``) and a signature derived
    from the seed.

    Workspace access is granted separately via POST /workspace/{id}/users.

    Args:
        body (CreateAgentRequest): Create a persistent agent owned by the current user.

            Used by: POST /user/agent (authenticated, non-agent)

            Frontend generates an Ed25519 keypair from a random seed (the agent's "password").
            Only the public key is sent here; the seed is given to the agent CLI.
            The agent's synthetic email is ``agentname.usr-XXXXXXXX@deploymentdomain``.
            The agent logs in via POST /user/login using this email + Ed25519 signature.

            Agent name must be composed of letters, digits, hyphens, and underscores only
            (must start with a letter or digit) so it is valid as an email local-part.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
