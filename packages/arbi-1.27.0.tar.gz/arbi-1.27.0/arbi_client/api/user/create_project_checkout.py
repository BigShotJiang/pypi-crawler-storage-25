from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.project_checkout_request import ProjectCheckoutRequest
from ...models.project_checkout_response import ProjectCheckoutResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    project_ext_id: str,
    *,
    body: ProjectCheckoutRequest,
    origin: str | Unset = UNSET,
    referer: str | Unset = UNSET,
    x_frontend_origin: str | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(origin, Unset):
        headers["origin"] = origin

    if not isinstance(referer, Unset):
        headers["referer"] = referer

    if not isinstance(x_frontend_origin, Unset):
        headers["x-frontend-origin"] = x_frontend_origin



    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/projects/{project_ext_id}/checkout".format(project_ext_id=quote(str(project_ext_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | ProjectCheckoutResponse | None:
    if response.status_code == 200:
        response_200 = ProjectCheckoutResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | ProjectCheckoutResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ProjectCheckoutRequest,
    origin: str | Unset = UNSET,
    referer: str | Unset = UNSET,
    x_frontend_origin: str | Unset = UNSET,

) -> Response[HTTPValidationError | ProjectCheckoutResponse]:
    """ Create Project Checkout

     Create a Stripe checkout session for this project.

    Args:
        project_ext_id (str):
        origin (str | Unset):
        referer (str | Unset):
        x_frontend_origin (str | Unset):
        body (ProjectCheckoutRequest): Create a Stripe checkout session for this project.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectCheckoutResponse]
     """


    kwargs = _get_kwargs(
        project_ext_id=project_ext_id,
body=body,
origin=origin,
referer=referer,
x_frontend_origin=x_frontend_origin,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ProjectCheckoutRequest,
    origin: str | Unset = UNSET,
    referer: str | Unset = UNSET,
    x_frontend_origin: str | Unset = UNSET,

) -> HTTPValidationError | ProjectCheckoutResponse | None:
    """ Create Project Checkout

     Create a Stripe checkout session for this project.

    Args:
        project_ext_id (str):
        origin (str | Unset):
        referer (str | Unset):
        x_frontend_origin (str | Unset):
        body (ProjectCheckoutRequest): Create a Stripe checkout session for this project.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectCheckoutResponse
     """


    return sync_detailed(
        project_ext_id=project_ext_id,
client=client,
body=body,
origin=origin,
referer=referer,
x_frontend_origin=x_frontend_origin,

    ).parsed

async def asyncio_detailed(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ProjectCheckoutRequest,
    origin: str | Unset = UNSET,
    referer: str | Unset = UNSET,
    x_frontend_origin: str | Unset = UNSET,

) -> Response[HTTPValidationError | ProjectCheckoutResponse]:
    """ Create Project Checkout

     Create a Stripe checkout session for this project.

    Args:
        project_ext_id (str):
        origin (str | Unset):
        referer (str | Unset):
        x_frontend_origin (str | Unset):
        body (ProjectCheckoutRequest): Create a Stripe checkout session for this project.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectCheckoutResponse]
     """


    kwargs = _get_kwargs(
        project_ext_id=project_ext_id,
body=body,
origin=origin,
referer=referer,
x_frontend_origin=x_frontend_origin,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    project_ext_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ProjectCheckoutRequest,
    origin: str | Unset = UNSET,
    referer: str | Unset = UNSET,
    x_frontend_origin: str | Unset = UNSET,

) -> HTTPValidationError | ProjectCheckoutResponse | None:
    """ Create Project Checkout

     Create a Stripe checkout session for this project.

    Args:
        project_ext_id (str):
        origin (str | Unset):
        referer (str | Unset):
        x_frontend_origin (str | Unset):
        body (ProjectCheckoutRequest): Create a Stripe checkout session for this project.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectCheckoutResponse
     """


    return (await asyncio_detailed(
        project_ext_id=project_ext_id,
client=client,
body=body,
origin=origin,
referer=referer,
x_frontend_origin=x_frontend_origin,

    )).parsed
