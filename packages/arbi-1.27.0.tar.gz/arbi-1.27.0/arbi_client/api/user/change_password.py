from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.change_password_request import ChangePasswordRequest
from ...models.change_password_response import ChangePasswordResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    *,
    body: ChangePasswordRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/change_password",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ChangePasswordResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ChangePasswordResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ChangePasswordResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ChangePasswordRequest,

) -> Response[ChangePasswordResponse | HTTPValidationError]:
    r""" Change Password

     Change user's master password by re-keying all workspace keys.

    Self re-key (agent_ext_id omitted):
    1. Sign \"email|timestamp\" with current Ed25519 key (proves current password)
    2. Provide new Ed25519 signing key (derived from new password)
    3. Re-wrap all workspace keys with new X25519 public key

    Agent re-key (agent_ext_id provided):
    1. Parent signs \"agent_ext_id|timestamp\" with their own Ed25519 key (proves authority)
    2. Provide new Ed25519 signing key for the agent
    3. Re-wrap the agent's workspace keys with the agent's new X25519 public key

    Args:
        body (ChangePasswordRequest): Password change request with signature-based auth.

            Self re-key (agent_ext_id omitted):
              Client proves knowledge of current password by signing "email|timestamp"
              with their own Ed25519 key.

            Agent re-key (agent_ext_id provided):
              Parent re-keys an agent's signing/encryption keys.  Parent proves authority
              by signing "agent_ext_id|timestamp" with their own Ed25519 key.
              rewrapped_workspace_keys must contain entries for the agent's workspaces,
              each wrapped with the agent's new X25519 public key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChangePasswordResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ChangePasswordRequest,

) -> ChangePasswordResponse | HTTPValidationError | None:
    r""" Change Password

     Change user's master password by re-keying all workspace keys.

    Self re-key (agent_ext_id omitted):
    1. Sign \"email|timestamp\" with current Ed25519 key (proves current password)
    2. Provide new Ed25519 signing key (derived from new password)
    3. Re-wrap all workspace keys with new X25519 public key

    Agent re-key (agent_ext_id provided):
    1. Parent signs \"agent_ext_id|timestamp\" with their own Ed25519 key (proves authority)
    2. Provide new Ed25519 signing key for the agent
    3. Re-wrap the agent's workspace keys with the agent's new X25519 public key

    Args:
        body (ChangePasswordRequest): Password change request with signature-based auth.

            Self re-key (agent_ext_id omitted):
              Client proves knowledge of current password by signing "email|timestamp"
              with their own Ed25519 key.

            Agent re-key (agent_ext_id provided):
              Parent re-keys an agent's signing/encryption keys.  Parent proves authority
              by signing "agent_ext_id|timestamp" with their own Ed25519 key.
              rewrapped_workspace_keys must contain entries for the agent's workspaces,
              each wrapped with the agent's new X25519 public key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChangePasswordResponse | HTTPValidationError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ChangePasswordRequest,

) -> Response[ChangePasswordResponse | HTTPValidationError]:
    r""" Change Password

     Change user's master password by re-keying all workspace keys.

    Self re-key (agent_ext_id omitted):
    1. Sign \"email|timestamp\" with current Ed25519 key (proves current password)
    2. Provide new Ed25519 signing key (derived from new password)
    3. Re-wrap all workspace keys with new X25519 public key

    Agent re-key (agent_ext_id provided):
    1. Parent signs \"agent_ext_id|timestamp\" with their own Ed25519 key (proves authority)
    2. Provide new Ed25519 signing key for the agent
    3. Re-wrap the agent's workspace keys with the agent's new X25519 public key

    Args:
        body (ChangePasswordRequest): Password change request with signature-based auth.

            Self re-key (agent_ext_id omitted):
              Client proves knowledge of current password by signing "email|timestamp"
              with their own Ed25519 key.

            Agent re-key (agent_ext_id provided):
              Parent re-keys an agent's signing/encryption keys.  Parent proves authority
              by signing "agent_ext_id|timestamp" with their own Ed25519 key.
              rewrapped_workspace_keys must contain entries for the agent's workspaces,
              each wrapped with the agent's new X25519 public key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChangePasswordResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ChangePasswordRequest,

) -> ChangePasswordResponse | HTTPValidationError | None:
    r""" Change Password

     Change user's master password by re-keying all workspace keys.

    Self re-key (agent_ext_id omitted):
    1. Sign \"email|timestamp\" with current Ed25519 key (proves current password)
    2. Provide new Ed25519 signing key (derived from new password)
    3. Re-wrap all workspace keys with new X25519 public key

    Agent re-key (agent_ext_id provided):
    1. Parent signs \"agent_ext_id|timestamp\" with their own Ed25519 key (proves authority)
    2. Provide new Ed25519 signing key for the agent
    3. Re-wrap the agent's workspace keys with the agent's new X25519 public key

    Args:
        body (ChangePasswordRequest): Password change request with signature-based auth.

            Self re-key (agent_ext_id omitted):
              Client proves knowledge of current password by signing "email|timestamp"
              with their own Ed25519 key.

            Agent re-key (agent_ext_id provided):
              Parent re-keys an agent's signing/encryption keys.  Parent proves authority
              by signing "agent_ext_id|timestamp" with their own Ed25519 key.
              rewrapped_workspace_keys must contain entries for the agent's workspaces,
              each wrapped with the agent's new X25519 public key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChangePasswordResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
