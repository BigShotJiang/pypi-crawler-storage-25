from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.sso_status_request import SSOStatusRequest
from ...models.sso_status_response import SSOStatusResponse
from typing import cast



def _get_kwargs(
    *,
    body: SSOStatusRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/sso-status",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | SSOStatusResponse | None:
    if response.status_code == 200:
        response_200 = SSOStatusResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | SSOStatusResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: SSOStatusRequest,

) -> Response[HTTPValidationError | SSOStatusResponse]:
    r""" Sso Status

     Check SSO user registration state.

    Returns one of three states:
    1. new_user: No user exists with this email
    2. local_exists: User exists but registered locally (can link to SSO)
    3. sso_exists: User exists and already linked to SSO

    Frontend uses this to show appropriate UI:
    - new_user -> \"Set Master Password\"
    - local_exists -> \"Link SSO? Enter current master password\"
    - sso_exists -> \"Enter Master Password\"

    Args:
        body (SSOStatusRequest): SSO status request - checks user registration state and syncs
            profile.

            Profile fields (given_name, family_name, picture) are optional.
            If user exists, these fields will be updated (profile sync on every login).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SSOStatusResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: SSOStatusRequest,

) -> HTTPValidationError | SSOStatusResponse | None:
    r""" Sso Status

     Check SSO user registration state.

    Returns one of three states:
    1. new_user: No user exists with this email
    2. local_exists: User exists but registered locally (can link to SSO)
    3. sso_exists: User exists and already linked to SSO

    Frontend uses this to show appropriate UI:
    - new_user -> \"Set Master Password\"
    - local_exists -> \"Link SSO? Enter current master password\"
    - sso_exists -> \"Enter Master Password\"

    Args:
        body (SSOStatusRequest): SSO status request - checks user registration state and syncs
            profile.

            Profile fields (given_name, family_name, picture) are optional.
            If user exists, these fields will be updated (profile sync on every login).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SSOStatusResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: SSOStatusRequest,

) -> Response[HTTPValidationError | SSOStatusResponse]:
    r""" Sso Status

     Check SSO user registration state.

    Returns one of three states:
    1. new_user: No user exists with this email
    2. local_exists: User exists but registered locally (can link to SSO)
    3. sso_exists: User exists and already linked to SSO

    Frontend uses this to show appropriate UI:
    - new_user -> \"Set Master Password\"
    - local_exists -> \"Link SSO? Enter current master password\"
    - sso_exists -> \"Enter Master Password\"

    Args:
        body (SSOStatusRequest): SSO status request - checks user registration state and syncs
            profile.

            Profile fields (given_name, family_name, picture) are optional.
            If user exists, these fields will be updated (profile sync on every login).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SSOStatusResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: SSOStatusRequest,

) -> HTTPValidationError | SSOStatusResponse | None:
    r""" Sso Status

     Check SSO user registration state.

    Returns one of three states:
    1. new_user: No user exists with this email
    2. local_exists: User exists but registered locally (can link to SSO)
    3. sso_exists: User exists and already linked to SSO

    Frontend uses this to show appropriate UI:
    - new_user -> \"Set Master Password\"
    - local_exists -> \"Link SSO? Enter current master password\"
    - sso_exists -> \"Enter Master Password\"

    Args:
        body (SSOStatusRequest): SSO status request - checks user registration state and syncs
            profile.

            Profile fields (given_name, family_name, picture) are optional.
            If user exists, these fields will be updated (profile sync on every login).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SSOStatusResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
