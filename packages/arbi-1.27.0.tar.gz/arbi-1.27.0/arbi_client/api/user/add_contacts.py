from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.add_contacts_request import AddContactsRequest
from ...models.contact_response import ContactResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    *,
    body: AddContactsRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/user/contacts",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | list[ContactResponse] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in (_response_200):
            response_200_item = ContactResponse.from_dict(response_200_item_data)



            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | list[ContactResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AddContactsRequest,

) -> Response[HTTPValidationError | list[ContactResponse]]:
    r""" Add Contacts

     Add multiple contacts by email addresses.

    For each email:
    - If user already exists: Adds them to contacts with status=\"registered\"
    - If user doesn't exist: Sends invitation email and creates contact with status=\"invited\"

    Protected endpoint - requires authentication.
    Returns list of created contact records.

    Args:
        body (AddContactsRequest): Request model for adding contacts by email.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[ContactResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AddContactsRequest,

) -> HTTPValidationError | list[ContactResponse] | None:
    r""" Add Contacts

     Add multiple contacts by email addresses.

    For each email:
    - If user already exists: Adds them to contacts with status=\"registered\"
    - If user doesn't exist: Sends invitation email and creates contact with status=\"invited\"

    Protected endpoint - requires authentication.
    Returns list of created contact records.

    Args:
        body (AddContactsRequest): Request model for adding contacts by email.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[ContactResponse]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AddContactsRequest,

) -> Response[HTTPValidationError | list[ContactResponse]]:
    r""" Add Contacts

     Add multiple contacts by email addresses.

    For each email:
    - If user already exists: Adds them to contacts with status=\"registered\"
    - If user doesn't exist: Sends invitation email and creates contact with status=\"invited\"

    Protected endpoint - requires authentication.
    Returns list of created contact records.

    Args:
        body (AddContactsRequest): Request model for adding contacts by email.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[ContactResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AddContactsRequest,

) -> HTTPValidationError | list[ContactResponse] | None:
    r""" Add Contacts

     Add multiple contacts by email addresses.

    For each email:
    - If user already exists: Adds them to contacts with status=\"registered\"
    - If user doesn't exist: Sends invitation email and creates contact with status=\"invited\"

    Protected endpoint - requires authentication.
    Returns list of created contact records.

    Args:
        body (AddContactsRequest): Request model for adding contacts by email.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[ContactResponse]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
