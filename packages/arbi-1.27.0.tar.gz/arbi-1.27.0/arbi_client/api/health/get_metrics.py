from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_metrics_response_get_metrics import GetMetricsResponseGetMetrics
from typing import cast



def _get_kwargs(
    
) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/health/metrics",
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetMetricsResponseGetMetrics | None:
    if response.status_code == 200:
        response_200 = GetMetricsResponseGetMetrics.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetMetricsResponseGetMetrics]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetMetricsResponseGetMetrics]:
    """ Get Metrics

     Live operational metrics for this instance (developer-only).

    Returns a structured snapshot of DB pool utilisation, in-process
    semaphores (embedder, reranker, indexing, qdrant, doctag_llm, etc.),
    Redis queue backpressure for this deployment, and the current
    asyncio task count. Same data the periodic concurrency_monitor
    logger emits, but as JSON for dashboards / probes / tests.

    Gated to developer accounts because the payload exposes internal
    pool sizes and saturation — useful for recon if leaked to end users.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMetricsResponseGetMetrics]
     """


    kwargs = _get_kwargs(
        
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,

) -> GetMetricsResponseGetMetrics | None:
    """ Get Metrics

     Live operational metrics for this instance (developer-only).

    Returns a structured snapshot of DB pool utilisation, in-process
    semaphores (embedder, reranker, indexing, qdrant, doctag_llm, etc.),
    Redis queue backpressure for this deployment, and the current
    asyncio task count. Same data the periodic concurrency_monitor
    logger emits, but as JSON for dashboards / probes / tests.

    Gated to developer accounts because the payload exposes internal
    pool sizes and saturation — useful for recon if leaked to end users.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMetricsResponseGetMetrics
     """


    return sync_detailed(
        client=client,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,

) -> Response[GetMetricsResponseGetMetrics]:
    """ Get Metrics

     Live operational metrics for this instance (developer-only).

    Returns a structured snapshot of DB pool utilisation, in-process
    semaphores (embedder, reranker, indexing, qdrant, doctag_llm, etc.),
    Redis queue backpressure for this deployment, and the current
    asyncio task count. Same data the periodic concurrency_monitor
    logger emits, but as JSON for dashboards / probes / tests.

    Gated to developer accounts because the payload exposes internal
    pool sizes and saturation — useful for recon if leaked to end users.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMetricsResponseGetMetrics]
     """


    kwargs = _get_kwargs(
        
    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,

) -> GetMetricsResponseGetMetrics | None:
    """ Get Metrics

     Live operational metrics for this instance (developer-only).

    Returns a structured snapshot of DB pool utilisation, in-process
    semaphores (embedder, reranker, indexing, qdrant, doctag_llm, etc.),
    Redis queue backpressure for this deployment, and the current
    asyncio task count. Same data the periodic concurrency_monitor
    logger emits, but as JSON for dashboards / probes / tests.

    Gated to developer accounts because the payload exposes internal
    pool sizes and saturation — useful for recon if leaked to end users.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMetricsResponseGetMetrics
     """


    return (await asyncio_detailed(
        client=client,

    )).parsed
