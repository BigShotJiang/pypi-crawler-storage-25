from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.upload_init_request import UploadInitRequest
from ...models.upload_init_response import UploadInitResponse
from typing import cast



def _get_kwargs(
    *,
    body: UploadInitRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/document/upload-init",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | UploadInitResponse | None:
    if response.status_code == 200:
        response_200 = UploadInitResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | UploadInitResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadInitRequest,

) -> Response[HTTPValidationError | UploadInitResponse]:
    """ Upload Init

     Phase 1 of the direct-to-MinIO upload flow.

    The client declares each file it intends to upload (name, raw size,
    workspace-scoped HMAC content hash). For every file that passes
    validation + quota + dedup, the server reserves a ``Docs`` row in
    ``uploading`` state and returns a short-lived presigned PUT URL pointing
    at the public ``/arbi-files/`` nginx route. The client then encrypts
    the bytes locally with SecretBox(workspace_key) and PUTs the ciphertext
    straight to MinIO — arbi-app never sees the raw or encrypted payload.

    Call ``POST /v1/document/upload-commit`` once the PUTs succeed to flip
    the rows to ``queued`` and enqueue the parser pipeline.

    See ``init_direct_uploads`` for the full side-effect ordering.

    Requires active subscription if Stripe is configured.

    Args:
        body (UploadInitRequest): Request body for ``POST /v1/document/upload-init``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadInitResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UploadInitRequest,

) -> HTTPValidationError | UploadInitResponse | None:
    """ Upload Init

     Phase 1 of the direct-to-MinIO upload flow.

    The client declares each file it intends to upload (name, raw size,
    workspace-scoped HMAC content hash). For every file that passes
    validation + quota + dedup, the server reserves a ``Docs`` row in
    ``uploading`` state and returns a short-lived presigned PUT URL pointing
    at the public ``/arbi-files/`` nginx route. The client then encrypts
    the bytes locally with SecretBox(workspace_key) and PUTs the ciphertext
    straight to MinIO — arbi-app never sees the raw or encrypted payload.

    Call ``POST /v1/document/upload-commit`` once the PUTs succeed to flip
    the rows to ``queued`` and enqueue the parser pipeline.

    See ``init_direct_uploads`` for the full side-effect ordering.

    Requires active subscription if Stripe is configured.

    Args:
        body (UploadInitRequest): Request body for ``POST /v1/document/upload-init``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadInitResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadInitRequest,

) -> Response[HTTPValidationError | UploadInitResponse]:
    """ Upload Init

     Phase 1 of the direct-to-MinIO upload flow.

    The client declares each file it intends to upload (name, raw size,
    workspace-scoped HMAC content hash). For every file that passes
    validation + quota + dedup, the server reserves a ``Docs`` row in
    ``uploading`` state and returns a short-lived presigned PUT URL pointing
    at the public ``/arbi-files/`` nginx route. The client then encrypts
    the bytes locally with SecretBox(workspace_key) and PUTs the ciphertext
    straight to MinIO — arbi-app never sees the raw or encrypted payload.

    Call ``POST /v1/document/upload-commit`` once the PUTs succeed to flip
    the rows to ``queued`` and enqueue the parser pipeline.

    See ``init_direct_uploads`` for the full side-effect ordering.

    Requires active subscription if Stripe is configured.

    Args:
        body (UploadInitRequest): Request body for ``POST /v1/document/upload-init``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadInitResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UploadInitRequest,

) -> HTTPValidationError | UploadInitResponse | None:
    """ Upload Init

     Phase 1 of the direct-to-MinIO upload flow.

    The client declares each file it intends to upload (name, raw size,
    workspace-scoped HMAC content hash). For every file that passes
    validation + quota + dedup, the server reserves a ``Docs`` row in
    ``uploading`` state and returns a short-lived presigned PUT URL pointing
    at the public ``/arbi-files/`` nginx route. The client then encrypts
    the bytes locally with SecretBox(workspace_key) and PUTs the ciphertext
    straight to MinIO — arbi-app never sees the raw or encrypted payload.

    Call ``POST /v1/document/upload-commit`` once the PUTs succeed to flip
    the rows to ``queued`` and enqueue the parser pipeline.

    See ``init_direct_uploads`` for the full side-effect ordering.

    Requires active subscription if Stripe is configured.

    Args:
        body (UploadInitRequest): Request body for ``POST /v1/document/upload-init``.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadInitResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
