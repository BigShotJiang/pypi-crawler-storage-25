from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.doc_sim_response import DocSimResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    threshold: float | Unset = 0.92,
    doc_ext_id: None | str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["threshold"] = threshold

    json_doc_ext_id: None | str | Unset
    if isinstance(doc_ext_id, Unset):
        json_doc_ext_id = UNSET
    else:
        json_doc_ext_id = doc_ext_id
    params["doc_ext_id"] = json_doc_ext_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/document/similar",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DocSimResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DocSimResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DocSimResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    threshold: float | Unset = 0.92,
    doc_ext_id: None | str | Unset = UNSET,

) -> Response[DocSimResponse | HTTPValidationError]:
    """ Get Similar Documents

     Return document similarity pairs from the doc_similarities table.

    Pairs are stored at upload time for documents with similarity >= NEAR_DUPLICATE_STORE_THRESHOLD.
    Use the threshold param to filter (e.g. 0.92 for near-duplicates, 0.75 for similar docs).
    Use doc_ext_id to find all documents similar to a specific document.

    Args:
        threshold: Minimum cosine similarity score (0.0–1.0). Default 0.0 returns all stored pairs.
        doc_ext_id: Optional document ID to filter pairs involving that specific document.

    Returns:
        List of document similarity pairs with scores.

    Args:
        threshold (float | Unset): Minimum similarity score (default 0.92 for near-duplicates)
            Default: 0.92.
        doc_ext_id (None | str | Unset): Filter pairs involving a specific document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocSimResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        threshold=threshold,
doc_ext_id=doc_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    threshold: float | Unset = 0.92,
    doc_ext_id: None | str | Unset = UNSET,

) -> DocSimResponse | HTTPValidationError | None:
    """ Get Similar Documents

     Return document similarity pairs from the doc_similarities table.

    Pairs are stored at upload time for documents with similarity >= NEAR_DUPLICATE_STORE_THRESHOLD.
    Use the threshold param to filter (e.g. 0.92 for near-duplicates, 0.75 for similar docs).
    Use doc_ext_id to find all documents similar to a specific document.

    Args:
        threshold: Minimum cosine similarity score (0.0–1.0). Default 0.0 returns all stored pairs.
        doc_ext_id: Optional document ID to filter pairs involving that specific document.

    Returns:
        List of document similarity pairs with scores.

    Args:
        threshold (float | Unset): Minimum similarity score (default 0.92 for near-duplicates)
            Default: 0.92.
        doc_ext_id (None | str | Unset): Filter pairs involving a specific document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocSimResponse | HTTPValidationError
     """


    return sync_detailed(
        client=client,
threshold=threshold,
doc_ext_id=doc_ext_id,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    threshold: float | Unset = 0.92,
    doc_ext_id: None | str | Unset = UNSET,

) -> Response[DocSimResponse | HTTPValidationError]:
    """ Get Similar Documents

     Return document similarity pairs from the doc_similarities table.

    Pairs are stored at upload time for documents with similarity >= NEAR_DUPLICATE_STORE_THRESHOLD.
    Use the threshold param to filter (e.g. 0.92 for near-duplicates, 0.75 for similar docs).
    Use doc_ext_id to find all documents similar to a specific document.

    Args:
        threshold: Minimum cosine similarity score (0.0–1.0). Default 0.0 returns all stored pairs.
        doc_ext_id: Optional document ID to filter pairs involving that specific document.

    Returns:
        List of document similarity pairs with scores.

    Args:
        threshold (float | Unset): Minimum similarity score (default 0.92 for near-duplicates)
            Default: 0.92.
        doc_ext_id (None | str | Unset): Filter pairs involving a specific document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocSimResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        threshold=threshold,
doc_ext_id=doc_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    threshold: float | Unset = 0.92,
    doc_ext_id: None | str | Unset = UNSET,

) -> DocSimResponse | HTTPValidationError | None:
    """ Get Similar Documents

     Return document similarity pairs from the doc_similarities table.

    Pairs are stored at upload time for documents with similarity >= NEAR_DUPLICATE_STORE_THRESHOLD.
    Use the threshold param to filter (e.g. 0.92 for near-duplicates, 0.75 for similar docs).
    Use doc_ext_id to find all documents similar to a specific document.

    Args:
        threshold: Minimum cosine similarity score (0.0–1.0). Default 0.0 returns all stored pairs.
        doc_ext_id: Optional document ID to filter pairs involving that specific document.

    Returns:
        List of document similarity pairs with scores.

    Args:
        threshold (float | Unset): Minimum similarity score (default 0.92 for near-duplicates)
            Default: 0.92.
        doc_ext_id (None | str | Unset): Filter pairs involving a specific document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocSimResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        client=client,
threshold=threshold,
doc_ext_id=doc_ext_id,

    )).parsed
