from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.upload_commit_request import UploadCommitRequest
from ...models.upload_documents_response import UploadDocumentsResponse
from typing import cast



def _get_kwargs(
    *,
    body: UploadCommitRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/document/upload-commit",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | UploadDocumentsResponse | None:
    if response.status_code == 200:
        response_200 = UploadDocumentsResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadCommitRequest,

) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    """ Upload Commit

     Phase 3 of the direct-to-MinIO upload flow.

    The client calls this after it has PUT encrypted bytes for each
    ``doc_ext_id`` handed out by ``/upload-init``. The server HEADs each
    object in MinIO, flips the row from ``uploading`` → ``queued``, and
    runs the usual parser-enqueue pipeline (or the media / text
    fast-path for those file types). Any ``doc_ext_id`` whose object is
    missing is dropped and reported in the response's ``skipped`` list —
    the row is deleted rather than left half-committed.

    The response shape matches ``POST /v1/document/upload`` so the
    frontend's existing post-upload UI (batch completion tracking etc.)
    can consume it unchanged.

    Args:
        body (UploadCommitRequest): Request body for ``POST /v1/document/upload-commit``.

            ``doc_ext_ids`` should be the subset of init items the client actually
            uploaded successfully. Any IDs not listed here are left in ``uploading``
            state on the server and eventually garbage-collected.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadDocumentsResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UploadCommitRequest,

) -> HTTPValidationError | UploadDocumentsResponse | None:
    """ Upload Commit

     Phase 3 of the direct-to-MinIO upload flow.

    The client calls this after it has PUT encrypted bytes for each
    ``doc_ext_id`` handed out by ``/upload-init``. The server HEADs each
    object in MinIO, flips the row from ``uploading`` → ``queued``, and
    runs the usual parser-enqueue pipeline (or the media / text
    fast-path for those file types). Any ``doc_ext_id`` whose object is
    missing is dropped and reported in the response's ``skipped`` list —
    the row is deleted rather than left half-committed.

    The response shape matches ``POST /v1/document/upload`` so the
    frontend's existing post-upload UI (batch completion tracking etc.)
    can consume it unchanged.

    Args:
        body (UploadCommitRequest): Request body for ``POST /v1/document/upload-commit``.

            ``doc_ext_ids`` should be the subset of init items the client actually
            uploaded successfully. Any IDs not listed here are left in ``uploading``
            state on the server and eventually garbage-collected.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadDocumentsResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadCommitRequest,

) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    """ Upload Commit

     Phase 3 of the direct-to-MinIO upload flow.

    The client calls this after it has PUT encrypted bytes for each
    ``doc_ext_id`` handed out by ``/upload-init``. The server HEADs each
    object in MinIO, flips the row from ``uploading`` → ``queued``, and
    runs the usual parser-enqueue pipeline (or the media / text
    fast-path for those file types). Any ``doc_ext_id`` whose object is
    missing is dropped and reported in the response's ``skipped`` list —
    the row is deleted rather than left half-committed.

    The response shape matches ``POST /v1/document/upload`` so the
    frontend's existing post-upload UI (batch completion tracking etc.)
    can consume it unchanged.

    Args:
        body (UploadCommitRequest): Request body for ``POST /v1/document/upload-commit``.

            ``doc_ext_ids`` should be the subset of init items the client actually
            uploaded successfully. Any IDs not listed here are left in ``uploading``
            state on the server and eventually garbage-collected.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadDocumentsResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UploadCommitRequest,

) -> HTTPValidationError | UploadDocumentsResponse | None:
    """ Upload Commit

     Phase 3 of the direct-to-MinIO upload flow.

    The client calls this after it has PUT encrypted bytes for each
    ``doc_ext_id`` handed out by ``/upload-init``. The server HEADs each
    object in MinIO, flips the row from ``uploading`` → ``queued``, and
    runs the usual parser-enqueue pipeline (or the media / text
    fast-path for those file types). Any ``doc_ext_id`` whose object is
    missing is dropped and reported in the response's ``skipped`` list —
    the row is deleted rather than left half-committed.

    The response shape matches ``POST /v1/document/upload`` so the
    frontend's existing post-upload UI (batch completion tracking etc.)
    can consume it unchanged.

    Args:
        body (UploadCommitRequest): Request body for ``POST /v1/document/upload-commit``.

            ``doc_ext_ids`` should be the subset of init items the client actually
            uploaded successfully. Any IDs not listed here are left in ``uploading``
            state on the server and eventually garbage-collected.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadDocumentsResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
