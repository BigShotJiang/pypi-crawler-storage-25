from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.doc_response import DocResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_offset: int | None | Unset
    if isinstance(offset, Unset):
        json_offset = UNSET
    else:
        json_offset = offset
    params["offset"] = json_offset


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/document/list",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | list[DocResponse] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in (_response_200):
            response_200_item = DocResponse.from_dict(response_200_item_data)



            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | list[DocResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,

) -> Response[HTTPValidationError | list[DocResponse]]:
    """ List Documents

     List documents in the current workspace.

    By default returns all documents (no pagination) since the frontend needs
    the full set for client-side sort/search/filter. Pass ``limit``/``offset``
    to opt into pagination — useful for the CLI when streaming a workspace.

    Args:
        limit (int | None | Unset): Optional page size. Omit to return every document in the
            workspace (the default — the web UI's sort/search/filter is client-side and needs the full
            list). Set when paging through huge workspaces from a CLI.
        offset (int | None | Unset): Optional offset for pagination. Requires a stable id-ordered
            scan.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[DocResponse]]
     """


    kwargs = _get_kwargs(
        limit=limit,
offset=offset,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,

) -> HTTPValidationError | list[DocResponse] | None:
    """ List Documents

     List documents in the current workspace.

    By default returns all documents (no pagination) since the frontend needs
    the full set for client-side sort/search/filter. Pass ``limit``/``offset``
    to opt into pagination — useful for the CLI when streaming a workspace.

    Args:
        limit (int | None | Unset): Optional page size. Omit to return every document in the
            workspace (the default — the web UI's sort/search/filter is client-side and needs the full
            list). Set when paging through huge workspaces from a CLI.
        offset (int | None | Unset): Optional offset for pagination. Requires a stable id-ordered
            scan.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[DocResponse]
     """


    return sync_detailed(
        client=client,
limit=limit,
offset=offset,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,

) -> Response[HTTPValidationError | list[DocResponse]]:
    """ List Documents

     List documents in the current workspace.

    By default returns all documents (no pagination) since the frontend needs
    the full set for client-side sort/search/filter. Pass ``limit``/``offset``
    to opt into pagination — useful for the CLI when streaming a workspace.

    Args:
        limit (int | None | Unset): Optional page size. Omit to return every document in the
            workspace (the default — the web UI's sort/search/filter is client-side and needs the full
            list). Set when paging through huge workspaces from a CLI.
        offset (int | None | Unset): Optional offset for pagination. Requires a stable id-ordered
            scan.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[DocResponse]]
     """


    kwargs = _get_kwargs(
        limit=limit,
offset=offset,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,

) -> HTTPValidationError | list[DocResponse] | None:
    """ List Documents

     List documents in the current workspace.

    By default returns all documents (no pagination) since the frontend needs
    the full set for client-side sort/search/filter. Pass ``limit``/``offset``
    to opt into pagination — useful for the CLI when streaming a workspace.

    Args:
        limit (int | None | Unset): Optional page size. Omit to return every document in the
            workspace (the default — the web UI's sort/search/filter is client-side and needs the full
            list). Set when paging through huge workspaces from a CLI.
        offset (int | None | Unset): Optional offset for pagination. Requires a stable id-ordered
            scan.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[DocResponse]
     """


    return (await asyncio_detailed(
        client=client,
limit=limit,
offset=offset,

    )).parsed
