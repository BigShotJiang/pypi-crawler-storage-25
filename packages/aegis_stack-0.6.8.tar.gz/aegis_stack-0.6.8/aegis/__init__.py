"""
Aegis Stack CLI - Component generation and project management tools.
"""

__version__ = "0.6.8"
