#from PyQt5.QtWidgets import QMainWindow, QMessageBox

import threading

class MainData():
    _lock = threading.Lock()
    isTerminatedTMMProcess              :bool = False
    isRunningTPMProgram                 :bool = False
    isPausedTPMProgram                  :bool = False


    

    
    