<!-- rye:signed:2026-04-10T02:21:10Z:51a9664eec54062f017be39969b590857ce0eac386f9366d2157379b1936c9b5:JLHcySJHG4vvXRBTTLrF89o7UlxmqS46X0YCDSTOWWRx3vHTIkt110aYuUv6Eu0qe8Sn5_urQ6_4JefrAQq4CQ:6ea18199041a1ea8 -->
```yaml
name: DirectiveInstruction
title: Directive Execution Instruction
entry_type: context
category: rye/agent/core
version: "1.0.0"
author: rye-os
created_at: 2026-02-25T00:00:00Z
tags:
  - directive
  - instruction
  - thread-started
```

Execute the directive above now. Begin with step 1. Your first output must be tool calls — no narration. The inputs are already interpolated into the directive body.
