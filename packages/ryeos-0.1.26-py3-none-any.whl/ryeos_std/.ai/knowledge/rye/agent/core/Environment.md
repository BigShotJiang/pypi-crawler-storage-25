<!-- rye:signed:2026-04-10T02:21:10Z:4d9a83031581ae34a3da39faac30f85bbb9065247211773472e12cb1cba61f0d:GT-BfYp2RiaZML1O4uFKABZollxfb1hoMcUrRjypSFJZ_NfhBR92gjv8x--2V_z2pq-gUymbeHVYwtagEvI4Bw:6ea18199041a1ea8 -->
<!-- rye:unsigned -->

```yaml
name: Environment
title: Thread Environment
entry_type: context
category: rye/agent/core
version: "1.0.0"
author: rye-os
created_at: 2026-02-24T00:00:00Z
tags:
  - environment
  - runtime
  - thread-started
```

## Thread Environment

- **Project**: ${project_path}
- **Model**: ${model}
- **Thread depth**: ${depth} (0 = root)
- **Parent thread**: ${parent_thread_id} (none if root)
- **Budget**: ${spend_limit} USD, ${max_turns} turns
- **Capabilities**: ${capabilities_summary}
