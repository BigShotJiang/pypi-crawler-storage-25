# jjdiff
[![PyPI](https://img.shields.io/pypi/v/jjdiff)](https://pypi.org/project/jjdiff/)

A TUI that can be used as a diff editor in the jujutsu vcs.

jjdiff will show all changes and allow you to navigate through them and
(partially) select them to be included.

jjdiff makes it easy to navigate the diff by having a 2 dimensional cursor that
can 'grow' and 'shrink'.

This cursor can operate on 3 levels:
- Change: select an entire change
- Hunk: select a group of edited lines in a file
- Line: select a single edited line in a file

## Keybindings
| Command | Key | Description |
| --- | --- | --- |
| `exit` | `escape`, `ctrl+c` or `ctrl+d` | Exit the diff editor with status code 1, causing the diff to not be applied. |
| `next_cursor` | `j`, `down` or `tab` | Select the next entry. |
| `prev_cursor` | `k`, `up` or `shift+tab` | Select the previous entry. |
| `first_cursor` | `g` or `home` | Select the first entry. |
| `last_cursor` | `G` or `end` | Select the last entry. |
| `shrink_cursor` | `l` or `right` | Shrink the cursor. So go from change to hunk and from hunk to line. If the cursor is on an unopened change it will open it first. |
| `grow_cursor` | `h` or `left` | Grow the cursor. So go from line to hunk and from hunk to change. If the cursor is on an opened change it will close it. |
| `select_cursor` | `space` | Mark everything selected by the cursor to be included. If everything is already marked it will exclude it instead. This will also select the next entry. |
| `select_all` | `a` or `ctrl+a` | Mark everything in the diff to be included. If everything is already marked it will exclude it instead. |
| `confirm` | `enter` | Confirm the selected changes. | 
| `undo` | `u` | Undo the last command. Commands that only affect the UI state like changing the cursor and opening/closing changes are not included in this. |
| `redo` | `U` | Redo the last undone command. Commands that only affect the UI state like changing the cursor and opening/closing changes are not included in this. |
| `open_all` | `o` | Open all changes. |
| `close_all` | `O` | Close all changes. |

## Usage
jjdiff is available on pypi. You can use any way you are comfortable installing
python applications.

You can then use it by adding the following settings to `~/.config/jj/config.toml`:
```toml
[ui]
diff-editor = "jjdiff"
diff-instructions = false  # not required but recommended
diff-formatter = ["jjdiff", "--print", "$left", "$right"]  # to also format diffs using jjdiff
```

## Configuration
jjdiff can be configured in `~/.config/jjdiff/config.toml` or at
`$XDG_CONFIG_HOME/jjdiff/config.toml` if set. The following configuration
options are supported:

### diff.deprioritize
This contains a list of gitignore style globs that can be used to deprioritize
certain files in diffs. Deprioritizing has the following effects:
- Deprioritized files are always at the end of the diff.
- In `jjdiff --print` the changes in deprioritized files are not shown.

### editor.default_open
Controls if changes are by default open or closed. Deprioritized files will
remain closed by default even if this setting is set to true. Default is false.

### editor.auto_open
When navigating away from an opened change, automatically closes it and opens
the next one. Default is false.

### format.tab_width
Controls as how many spaces a tab is formatted in the diff. Default is 4.

### keybindings
A dictionary mapping command names to lists of keys that should trigger the
command. The default value for each command matches the keybindings table shown
earlier in this document.
