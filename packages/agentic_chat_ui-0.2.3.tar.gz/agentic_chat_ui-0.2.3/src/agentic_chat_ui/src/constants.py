from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from agentic_chat_ui.src.settings import (
        AgentClientSettings,
        ChainlitCallBackRegistrarSettings,
        ControllerSettings,
        FromConfigMixinSettings,
        ViewRunnerSettings,
        ViewSettings,
    )


CONFIG_PATH = "/config/config.yaml"
TCAgentClient = TypeVar("TCAgentClient", bound="AgentClientSettings")
TCController = TypeVar("TCController", bound="ControllerSettings")
TCView = TypeVar("TCView", bound="ViewSettings")
TCViewRunner = TypeVar("TCViewRunner", bound="ViewRunnerSettings")
TCRunner = TypeVar("TCRunner", bound="ViewRunnerSettings")
TCChainlitCallBackRegistrar = TypeVar(
    "TCChainlitCallBackRegistrar", bound="ChainlitCallBackRegistrarSettings"
)
TCFromConfigMixin = TypeVar("TCFromConfigMixin", bound="FromConfigMixinSettings")
