import pytest
from datetime import datetime
from devlog.models import LogEntry
from devlog import storage


# This runs before every single test — gives each test a clean slate
@pytest.fixture(autouse=True)
def clean_log_file(tmp_path, monkeypatch):
    """
    Redirect storage to a temporary directory for tests.
    We never want tests touching the real ~/.devlog/logs.json
    """
    monkeypatch.setattr(storage, "DATA_DIR", tmp_path)
    monkeypatch.setattr(storage, "LOG_FILE", tmp_path / "logs.json")


# ── LogEntry model tests ──────────────────────────────────────────


def test_log_entry_creation():
    """A LogEntry should store message and auto-generate a timestamp."""
    entry = LogEntry(message="wrote tests")
    assert entry.message == "wrote tests"
    assert isinstance(entry.timestamp, datetime)


def test_log_entry_to_dict():
    """to_dict should return a dict with message and timestamp keys."""
    entry = LogEntry(message="wrote tests")
    d = entry.to_dict()
    assert d["message"] == "wrote tests"
    assert "timestamp" in d


def test_log_entry_from_dict():
    """from_dict should reconstruct a LogEntry correctly."""
    original = LogEntry(message="wrote tests")
    reconstructed = LogEntry.from_dict(original.to_dict())
    assert reconstructed.message == original.message
    assert reconstructed.timestamp == original.timestamp


# ── Storage tests ─────────────────────────────────────────────────


def test_load_entries_empty():
    """load_entries should return empty list when no log file exists."""
    entries = storage.load_entries()
    assert entries == []


def test_save_and_load_entry():
    """An entry saved to disk should be retrievable."""
    entry = LogEntry(message="fixed a bug")
    storage.save_entry(entry)

    loaded = storage.load_entries()
    assert len(loaded) == 1
    assert loaded[0].message == "fixed a bug"


def test_save_multiple_entries():
    """Saving multiple entries should append, not overwrite."""
    storage.save_entry(LogEntry(message="first"))
    storage.save_entry(LogEntry(message="second"))
    storage.save_entry(LogEntry(message="third"))

    loaded = storage.load_entries()
    assert len(loaded) == 3


def test_get_entries_for_date_today():
    """get_entries_for_date should return only today's entries."""
    storage.save_entry(LogEntry(message="today's work"))
    entries = storage.get_entries_for_date(datetime.now())
    assert len(entries) == 1
    assert entries[0].message == "today's work"


def test_get_entries_for_date_filters_correctly():
    """get_entries_for_date should not return entries from other dates."""
    # Manually create an entry with a past timestamp
    old_entry = LogEntry(
        message="old work",
        timestamp=datetime(2024, 1, 1, 9, 0, 0)
    )
    storage.save_entry(old_entry)
    storage.save_entry(LogEntry(message="today's work"))

    todays_entries = storage.get_entries_for_date(datetime.now())
    assert len(todays_entries) == 1
    assert todays_entries[0].message == "today's work"