import click
from datetime import datetime
from devlog.models import LogEntry
from devlog import storage


@click.group()
def main():
    """devlog — log your work from the terminal."""
    pass


@main.command()
@click.argument("message")
def add(message: str):
    """Add a new log entry."""
    if not message.strip():
        click.echo("❌ Message cannot be empty.")
        return

    entry = LogEntry(message=message.strip())
    storage.save_entry(entry)
    click.echo(f"✅ Logged: {entry.message}")


@main.command()
def today():
    """Show all entries logged today."""
    entries = storage.get_entries_for_date(datetime.now())

    if not entries:
        click.echo("No entries yet today. Run `devlog add` to log something.")
        return

    click.echo(f"\n📅 Today — {datetime.now().strftime('%B %d, %Y')}\n")
    for entry in entries:
        time = entry.timestamp.strftime("%H:%M")
        click.echo(f"  {time}  {entry.message}")
    click.echo()


@main.command()
def export():
    """Export today's logs as markdown."""
    entries = storage.get_entries_for_date(datetime.now())

    if not entries:
        click.echo("No entries to export for today.")
        return

    date_str = datetime.now().strftime("%Y-%m-%d")
    filename = f"devlog-{date_str}.md"

    with open(filename, "w") as f:
        f.write(f"# Devlog — {date_str}\n\n")
        for entry in entries:
            time = entry.timestamp.strftime("%H:%M")
            f.write(f"- **{time}** {entry.message}\n")

    click.echo(f"📝 Exported to {filename}")