import json
from pathlib import Path
from datetime import datetime
from devlog.models import LogEntry


DATA_DIR = Path.home() / ".devlog"
LOG_FILE = DATA_DIR / "logs.json"


def _ensure_data_dir() -> None:
    """Create the data directory if it doesn't exist."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_entries() -> list[LogEntry]:
    """Load all log entries from disk."""
    _ensure_data_dir()
    if not LOG_FILE.exists():
        return []
    with open(LOG_FILE, "r") as f:
        data = json.load(f)
    return [LogEntry.from_dict(entry) for entry in data]


def save_entry(entry: LogEntry) -> None:
    """Append a new log entry to disk."""
    entries = load_entries()
    entries.append(entry)
    with open(LOG_FILE, "w") as f:
        json.dump([e.to_dict() for e in entries], f, indent=2)


def get_entries_for_date(date: datetime) -> list[LogEntry]:
    """Return all entries for a given date."""
    entries = load_entries()
    return [
        e for e in entries
        if e.timestamp.date() == date.date()
    ]