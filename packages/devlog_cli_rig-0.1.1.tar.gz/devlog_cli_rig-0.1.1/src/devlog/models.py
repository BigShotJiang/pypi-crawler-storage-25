from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class LogEntry:
    message: str
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "message": self.message,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "LogEntry":
        return cls(
            message=data["message"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )