# devlog 📝

[![CI](https://github.com/YOUR_USERNAME/devlog/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_USERNAME/devlog/actions)
[![PyPI version](https://badge.fury.io/py/devlog-cli-rig.svg)](https://badge.fury.io/py/devlog-cli-rig)
[![Python](https://img.shields.io/pypi/pyversions/devlog-cli-rig)](https://pypi.org/project/devlog-cli-rig/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> Log your daily work from the terminal. Stay in your flow.

Developers are terrible at tracking what they worked on. End of sprint,
performance review, standup — you're always trying to remember.

`devlog` lives in your terminal, where you already are. No browser.
No login. No context switching.

---

## Demo

```bash
$ devlog add "Fixed the race condition in auth service"
✅ Logged: Fixed the race condition in auth service

$ devlog add "Reviewed PR for payment module"
✅ Logged: Reviewed PR for payment module

$ devlog today
📅 Today — May 20, 2026

  09:32  Fixed the race condition in auth service
  14:15  Reviewed PR for payment module

$ devlog export
📝 Exported to devlog-2026-05-20.md
```

---

## Installation

```bash
pip install devlog-cli-rig
```

Requires Python 3.10+

---

## Commands

| Command | Description |
|---|---|
| `devlog add "message"` | Add a new log entry |
| `devlog today` | View all entries logged today |
| `devlog export` | Export today's logs as a markdown file |

---

## Where is my data stored?

All entries are stored locally at `~/.devlog/logs.json`.
Nothing leaves your machine.

---

## Contributing

Contributions are welcome. Please read
[CONTRIBUTING.md](CONTRIBUTING.md) before opening a PR.

---

## License

MIT © Rigved