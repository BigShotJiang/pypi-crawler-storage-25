"""Programmatic read/write access to the DB tables.

Exposed as ``gtm.db`` on a ``GTMAdmin`` instance so that workflow and node
functions can query and mutate table rows without going through the HTTP API.

Each table is identified by its **name** (the ``name`` column of the
``data_tables`` registry). Rows are plain ``dict`` objects that always
contain an ``"id"`` key (integer) alongside any column values.

Example::

    @gtm.workflow
    async def sync_customers(inputs: dict):
        rows = await gtm.db.rows("Customers")
        for row in rows:
            if not row.get("col-6"):   # active == False
                await gtm.db.update_row("Customers", row["id"], {"col-6": True})
        new = await gtm.db.add_row("Customers", {"col-2": "Dana Lee", "col-6": True})
        return {"processed": len(rows), "new_id": new["id"]}
"""
from __future__ import annotations

from decimal import Decimal
from datetime import date, datetime
from typing import Any

from sqlalchemy import text


def _qi(s: str) -> str:
    """Double-quote a PostgreSQL identifier to handle hyphens and special chars."""
    return '"' + s.replace('"', '""') + '"'


def _pg_table(table_id: int) -> str:
    return f"data_table_{table_id}"


_PG_TYPE_MAP: dict[str, str] = {
    "text": "TEXT",
    "number": "NUMERIC",
    "boolean": "BOOLEAN",
    "date": "DATE",
    "select": "TEXT",
    "json": "JSONB",
}

_UDT_TO_FRONTEND_TYPE: dict[str, str] = {
    "text": "text",
    "varchar": "text",
    "bpchar": "text",
    "numeric": "number",
    "int2": "number",
    "int4": "number",
    "int8": "number",
    "float4": "number",
    "float8": "number",
    "bool": "boolean",
    "date": "date",
    "jsonb": "json",
    "json": "json",
}


def _normalize_row(mapping: Any) -> dict:
    result: dict[str, Any] = {}
    for k, v in mapping.items():
        if isinstance(v, Decimal):
            result[k] = float(v)
        elif isinstance(v, datetime):
            result[k] = v.isoformat()
        elif isinstance(v, date):
            result[k] = v.isoformat()
        else:
            result[k] = v
    return result


async def _get_column_names(session: Any, tbl: str) -> list[str]:
    result = await session.execute(
        text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' AND column_name != 'id' "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    return [row[0] for row in result]


async def _read_columns(session: Any, table_id: int) -> list[dict[str, Any]]:
    tbl = _pg_table(table_id)
    col_result = await session.execute(
        text(
            "SELECT column_name, udt_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' AND column_name != 'id' "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    pg_cols = col_result.fetchall()
    meta_result = await session.execute(
        text("SELECT column_name, select_options FROM data_table_column_meta WHERE table_id = :tid"),
        {"tid": table_id},
    )
    select_opts_map: dict[str, list[str]] = {row[0]: row[1] for row in meta_result if row[1] is not None}
    cols: list[dict[str, Any]] = []
    for col in pg_cols:
        col_name, udt = col[0], col[1]
        opts = select_opts_map.get(col_name)
        col_type = "select" if opts is not None else _UDT_TO_FRONTEND_TYPE.get(udt, "text")
        entry: dict[str, Any] = {"id": col_name, "name": col_name, "type": col_type}
        if opts is not None:
            entry["selectOptions"] = opts
        cols.append(entry)
    return cols


async def _upsert_row(session: Any, tbl_name: str, row: dict, col_ids: list[str]) -> None:
    """INSERT ... ON CONFLICT (id) DO UPDATE for a single row."""
    known = set(col_ids)
    data = {k: v for k, v in row.items() if k != "id" and k in known}
    params: dict[str, Any] = {"row_id": int(row["id"])}
    col_q, val_ph, update_parts = [], [], []
    for i, (k, v) in enumerate(data.items()):
        qk = _qi(k)
        col_q.append(qk)
        val_ph.append(f":v{i}")
        update_parts.append(f"{qk} = EXCLUDED.{qk}")
        params[f"v{i}"] = v
    if col_q:
        sql = (
            f"INSERT INTO {tbl_name} (id, {', '.join(col_q)}) "
            f"VALUES (:row_id, {', '.join(val_ph)}) "
            f"ON CONFLICT (id) DO UPDATE SET {', '.join(update_parts)}"
        )
    else:
        sql = f"INSERT INTO {tbl_name} (id) VALUES (:row_id) ON CONFLICT (id) DO NOTHING"
    await session.execute(text(sql), params)


class DbStore:
    """Thin async wrapper around real PostgreSQL data tables.

    Attached to ``GTMAdmin`` as ``gtm.db``.
    """

    @staticmethod
    async def _fetch_registry(session: Any, table_name: str) -> Any:
        from sqlmodel import select

        from .models import DataTable

        result = await session.exec(select(DataTable).where(DataTable.name == table_name))
        table = result.first()
        if table is None:
            raise KeyError(f"Table {table_name!r} not found.")
        return table

    async def rows(self, table_name: str) -> list[dict]:
        """Return all rows from the named table as a list of plain ``dict``\\s."""
        from .database import _SessionLocal

        if _SessionLocal is None:
            return []
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            result = await session.execute(text(f"SELECT * FROM {_pg_table(t.id)} ORDER BY id"))
            return [_normalize_row(r._mapping) for r in result]

    async def get_row(self, table_name: str, row_id: int) -> dict | None:
        """Return a single row by its ``id``, or ``None`` if not found."""
        from .database import _SessionLocal

        if _SessionLocal is None:
            return None
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            result = await session.execute(
                text(f"SELECT * FROM {_pg_table(t.id)} WHERE id = :row_id"),
                {"row_id": row_id},
            )
            row = result.first()
            return _normalize_row(row._mapping) if row else None

    async def add_row(self, table_name: str, data: dict[str, Any]) -> dict:
        """Append a new row to the named table.

        A unique integer ``id`` is assigned automatically. Returns the stored row dict.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError("Database not initialised. GTMAdmin must be instantiated first.")
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            tbl = _pg_table(t.id)
            col_names = await _get_column_names(session, tbl)
            max_id: int = (await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))) or 0
            new_id = max_id + 1
            row = {"id": new_id, **{k: v for k, v in data.items() if k != "id"}}
            await _upsert_row(session, tbl, row, col_names)
            result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :row_id"), {"row_id": new_id}
            )
            stored = result.first()
            await session.commit()
            return _normalize_row(stored._mapping) if stored else row

    async def update_row(self, table_name: str, row_id: int, data: dict[str, Any]) -> dict:
        """Merge *data* into an existing row and return the updated dict.

        Raises :class:`KeyError` if *row_id* is not found.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError("Database not initialised. GTMAdmin must be instantiated first.")
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            tbl = _pg_table(t.id)
            known_col_ids = set(await _get_column_names(session, tbl))
            update_data = {k: v for k, v in data.items() if k in known_col_ids}
            if not update_data:
                result = await session.execute(
                    text(f"SELECT * FROM {tbl} WHERE id = :row_id"), {"row_id": row_id}
                )
                row = result.first()
                if row is None:
                    raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
                return _normalize_row(row._mapping)
            params: dict[str, Any] = {"row_id": row_id}
            set_clauses = []
            for i, (k, v) in enumerate(update_data.items()):
                set_clauses.append(f"{_qi(k)} = :v{i}")
                params[f"v{i}"] = v
            result = await session.execute(
                text(f"UPDATE {tbl} SET {', '.join(set_clauses)} WHERE id = :row_id RETURNING *"),
                params,
            )
            updated = result.first()
            if updated is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            await session.commit()
            return _normalize_row(updated._mapping)

    async def delete_row(self, table_name: str, row_id: int) -> None:
        """Remove a row by its ``id``.  Raises :class:`KeyError` if not found."""
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError("Database not initialised. GTMAdmin must be instantiated first.")
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            tbl = _pg_table(t.id)
            result = await session.execute(
                text(f"DELETE FROM {tbl} WHERE id = :row_id RETURNING id"),
                {"row_id": row_id},
            )
            deleted = result.first()
            if deleted is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            await session.commit()
