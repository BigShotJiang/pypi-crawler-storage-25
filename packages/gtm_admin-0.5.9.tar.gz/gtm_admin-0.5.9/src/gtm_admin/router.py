from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Response, WebSocket, WebSocketDisconnect, status
from fastapi.security import OAuth2PasswordRequestForm
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import Text, and_, cast, func, literal_column, or_, text
from sqlalchemy.exc import IntegrityError
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from .auth import create_access_token, create_api_token, decode_token, generate_webhook_token, hash_password, verify_password
from .broadcast import manager
from .database import get_session
from .decorator import _run_detail, _run_summary, _running_tasks
from .deps import get_current_user
from .models import ApiToken, ConfigRecord, DataTable, TriggerType, User, UserRole, WebhookToken, Workflow, WorkflowConfig, WorkflowRun, WorkflowStatus
from .db_store import _get_column_names, _normalize_row, _pg_table, _PG_TYPE_MAP, _qi, _read_columns, _upsert_row
from .trigger_context import TriggerContext


def _to_camel(s: str) -> str:
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


_VALID_COL_NAME = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]{0,62}$')
_RESERVED_COL_NAMES = frozenset({'id'})


def _validate_column_id(col_id: str) -> None:
    """Raise 422 if col_id is empty, reserved, or not a valid PostgreSQL identifier."""
    if not col_id or not col_id.strip():
        raise HTTPException(status_code=422, detail="Column name cannot be empty.")
    if col_id in _RESERVED_COL_NAMES:
        raise HTTPException(status_code=422, detail=f"Column name '{col_id}' is reserved.")
    if not _VALID_COL_NAME.match(col_id):
        raise HTTPException(
            status_code=422,
            detail=(
                f"Column name '{col_id}' is invalid. Use only letters, digits, and underscores, "
                "starting with a letter or underscore (max 63 characters)."
            ),
        )


class CamelModel(BaseModel):
    model_config = ConfigDict(alias_generator=_to_camel, populate_by_name=True)


class LogEntry(CamelModel):
    timestamp: str
    body: str
    type: str = "info"
    is_json: bool = Field(default=False, alias="json")


class NodeType(str, Enum):
    node = "node"
    workflow = "workflow"


class WorkflowNodeRead(CamelModel):
    id: int
    name: str
    type: NodeType = NodeType.node
    status: str
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    duration_ms: int = 0
    logs: list[LogEntry] | None = None
    child_run_id: int | None = None


class WorkflowRunSummary(CamelModel):
    id: int
    name: str
    status: str
    triggered_by: str
    trigger_context: dict[str, Any] = {}
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    logs: list[dict[str, Any]] = []
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    parent_id: int | None = None
    children: list[WorkflowRunSummary] = []


WorkflowRunSummary.model_rebuild()


class SetupRequest(BaseModel):
    username: str
    email: str | None = None
    password: str


class WorkflowRunRead(CamelModel):
    id: int
    name: str
    status: str
    triggered_by: str
    trigger_context: dict[str, Any] = {}
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    logs: list[dict[str, Any]] = []
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    parent_id: int | None = None
    nodes: list[WorkflowNodeRead] = []
    children: list[WorkflowRunRead] = []


WorkflowRunRead.model_rebuild()


class WorkflowStats(CamelModel):
    counts: dict[str, int]
    active: list[WorkflowRunSummary]
    recent: list[WorkflowRunSummary]


class ConfigRead(CamelModel):
    id: int
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None
    created_at: datetime
    updated_at: datetime


class ConfigCreate(CamelModel):
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


class ConfigUpdate(CamelModel):
    key: str | None = None
    value: str | None = None
    type: str | None = None
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


class DbTableRead(CamelModel):
    id: int
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []
    created_at: datetime
    updated_at: datetime


class DbTableCreate(CamelModel):
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []


class DbTableUpdate(CamelModel):
    name: str | None = None
    description: str | None = None
    columns: list[dict[str, Any]] | None = None
    rows: list[dict[str, Any]] | None = None


class UserRead(CamelModel):
    username: str
    created_at: datetime


class UserCreate(CamelModel):
    username: str
    password: str


class UserPasswordUpdate(CamelModel):
    password: str


class ApiTokenRead(CamelModel):
    id: int
    name: str
    username: str
    created_at: datetime
    expires_at: datetime | None


class ApiTokenCreate(CamelModel):
    name: str
    expires_days: int | None = None


class ApiTokenCreated(CamelModel):
    id: int
    name: str
    username: str
    created_at: datetime
    expires_at: datetime | None
    token: str


class WebhookTokenRead(CamelModel):
    token: str
    created_at: datetime


class InputFieldDef(CamelModel):
    key: str
    type: str  # "string" | "number" | "boolean" | "select" | "text" | "json"
    label: str | None = None
    description: str | None = None
    required: bool = False
    default: Any = None
    options: list[str] | None = None  # for "select" type


class WorkflowDefinitionRead(CamelModel):
    name: str
    trigger_type: str
    cron: str | None
    interval: int | None
    is_webhook: bool
    webhook_path: str | None
    enabled: bool
    cron_override: str | None
    interval_override: int | None
    timeout_seconds: int | None
    max_concurrent_runs: int | None
    recent_nodes: list[str]
    last_run_at: datetime | None
    last_run_status: str | None
    total_runs: int
    failure_rate: float
    input_schema: list[InputFieldDef] = []
    instructions: str | None = None


class WorkflowConfigUpdate(CamelModel):
    enabled: bool | None = None
    cron_override: str | None = None
    interval_override: int | None = None
    timeout_seconds: int | None = None
    max_concurrent_runs: int | None = None


class WorkflowTriggerRequest(CamelModel):
    inputs: dict[str, Any] = {}


def _to_summary(run: WorkflowRun, cm: dict[int, list[WorkflowRun]], wf_names: dict[int, str]) -> WorkflowRunSummary:
    d = run.data or {}
    return WorkflowRunSummary(
        id=run.id, name=wf_names.get(run.workflow_id, ""),
        status=run.status.value,
        triggered_by=run.triggered_by.value if hasattr(run.triggered_by, "value") else run.triggered_by,
        trigger_context=d.get("trigger_context", {}),
        inputs=d.get("inputs", {}),
        outputs=d.get("outputs", {}),
        logs=d.get("logs", []),
        started_at=run.started_at, finished_at=run.finished_at, created_at=run.created_at,
        parent_id=run.parent_id,
        children=[_to_summary(c, cm, wf_names) for c in cm.get(run.id, [])],
    )


def _build_summary_tree(runs: list[WorkflowRun], wf_names: dict[int, str]) -> list[WorkflowRunSummary]:
    cm: dict[int, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            cm[r.parent_id].append(r)
        else:
            roots.append(r)
    return [_to_summary(r, cm, wf_names) for r in roots]


def _run_to_read(run: WorkflowRun, cm: dict[int, list[WorkflowRun]], wf_names: dict[int, str]) -> WorkflowRunRead:
    d = run.data or {}
    return WorkflowRunRead(
        id=run.id, name=wf_names.get(run.workflow_id, ""),
        status=run.status.value,
        triggered_by=run.triggered_by.value if hasattr(run.triggered_by, "value") else run.triggered_by,
        trigger_context=d.get("trigger_context", {}),
        inputs=d.get("inputs", {}),
        outputs=d.get("outputs", {}),
        logs=d.get("logs", []),
        started_at=run.started_at, finished_at=run.finished_at, created_at=run.created_at,
        parent_id=run.parent_id,
        nodes=[WorkflowNodeRead(**n) for n in d.get("nodes", [])],
        children=[_run_to_read(c, cm, wf_names) for c in cm.get(run.id, [])],
    )


def _build_tree(runs: list[WorkflowRun], wf_names: dict[int, str]) -> list[WorkflowRunRead]:
    cm: dict[int, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            cm[r.parent_id].append(r)
        else:
            roots.append(r)

    def to_read(run: WorkflowRun) -> WorkflowRunRead:
            d = run.data or {}
            return WorkflowRunRead(
                id=run.id, name=wf_names.get(run.workflow_id, ""),
                status=run.status.value,
                triggered_by=run.triggered_by.value if hasattr(run.triggered_by, "value") else run.triggered_by,
                trigger_context=d.get("trigger_context", {}),
                inputs=d.get("inputs", {}),
                outputs=d.get("outputs", {}),
                logs=d.get("logs", []),
                started_at=run.started_at, finished_at=run.finished_at, created_at=run.created_at,
                parent_id=run.parent_id,
                nodes=[WorkflowNodeRead(**n) for n in d.get("nodes", [])],
                children=[to_read(c) for c in cm.get(run.id, [])],
            )

    return [to_read(r) for r in roots]


def create_router(secret: str, workflows: dict, workflow_meta: dict, invoke, wrappers: dict | None = None) -> APIRouter:
    router = APIRouter()

    @router.post("/auth/token", tags=["auth"])
    async def login(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
    ):
        user = await session.get(User, form.username)
        if not user or not verify_password(form.password, user.hashed_password):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        return {"access_token": create_access_token(user.username), "token_type": "bearer"}

    @router.post("/auth/register", status_code=status.HTTP_201_CREATED, tags=["auth"])
    async def register(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        if await session.get(User, form.username):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")
        session.add(User(username=form.username, hashed_password=hash_password(form.password)))
        await session.commit()
        return {"username": form.username}

    @router.get("/auth/setup-status", tags=["auth"])
    async def setup_status(session: AsyncSession = Depends(get_session)):
        count = (await session.execute(select(func.count(User.username)))).scalar_one()
        return {"setupRequired": count == 0}

    @router.post("/auth/setup", status_code=status.HTTP_201_CREATED, tags=["auth"])
    async def setup(
        body: SetupRequest,
        session: AsyncSession = Depends(get_session),
    ):
        count = (await session.execute(select(func.count(User.username)))).scalar_one()
        if count > 0:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Setup already completed")
        session.add(User(
            username=body.username,
            email=body.email,
            hashed_password=hash_password(body.password),
            role=UserRole.admin,
        ))
        await session.commit()
        return {"username": body.username}

    @router.get("/health", tags=["system"])
    async def health():
        return {"status": "ok"}

    @router.get("/workflow-runs/stats", response_model=WorkflowStats, response_model_by_alias=True, tags=["workflow-runs"])
    async def get_workflow_stats(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        raw = await session.execute(
            select(WorkflowRun.status, func.count(WorkflowRun.id)).group_by(WorkflowRun.status)
        )
        counts: dict[str, int] = {
            (s.value if hasattr(s, "value") else str(s)): c for s, c in raw.all()
        }
        for s in ("pending", "running", "success", "failed"):
            counts.setdefault(s, 0)

        active = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.status == WorkflowStatus.running)
        )).all())

        recent = list((await session.exec(
            select(WorkflowRun)
            .where(WorkflowRun.status != WorkflowStatus.running)
            .order_by(WorkflowRun.created_at.desc())
            .limit(5)
        )).all())

        wf_ids = {r.workflow_id for r in active + recent}
        wf_entries = (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all() if wf_ids else []
        wf_names = {w.id: w.name for w in wf_entries}

        def _s(r: WorkflowRun) -> WorkflowRunSummary:
            d = r.data or {}
            return WorkflowRunSummary(
                id=r.id, name=wf_names.get(r.workflow_id, ""),
                status=r.status.value,
                triggered_by=r.triggered_by.value if hasattr(r.triggered_by, "value") else r.triggered_by,
                trigger_context=d.get("trigger_context", {}),
                inputs=d.get("inputs", {}),
                outputs=d.get("outputs", {}),
                logs=d.get("logs", []),
                started_at=r.started_at,
                finished_at=r.finished_at, created_at=r.created_at,
            )

        return WorkflowStats(counts=counts, active=[_s(r) for r in active], recent=[_s(r) for r in recent])

    @router.get("/workflow-runs", response_model=list[WorkflowRunSummary], response_model_by_alias=True, tags=["workflow-runs"])
    async def list_workflow_runs(
        fastapi_response: Response,
        offset: int = 0,
        limit: int = 50,
        search: str = "",
        status: list[str] = Query(default=[]),
        workflow_name: list[str] = Query(default=[]),
        date_from: datetime | None = None,
        date_to: datetime | None = None,
        triggered_by: list[str] = Query(default=[]),
        original_run_id: str | None = None,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        conds = [WorkflowRun.parent_id == None]  # noqa: E711
        if search:
            conds.append(or_(
                WorkflowRun.workflow_id.in_(select(Workflow.id).where(Workflow.name.ilike(f"%{search}%"))),
                cast(WorkflowRun.id, Text).ilike(f"%{search}%"),
                literal_column("workflow_runs.data::text").ilike(f"%{search}%"),
            ))
        if status:
            conds.append(WorkflowRun.status.in_(status))  # type: ignore[arg-type]
        if workflow_name:
            conds.append(WorkflowRun.workflow_id.in_(
                select(Workflow.id).where(Workflow.name.in_(workflow_name))
            ))
        if date_from:
            conds.append(WorkflowRun.created_at >= date_from)
        if date_to:
            conds.append(WorkflowRun.created_at <= date_to)
        if triggered_by:
            conds.append(WorkflowRun.triggered_by.in_(triggered_by))
        if original_run_id:
            # Handle both camelCase (current) and snake_case (legacy) key names
            conds.append(or_(
                func.json_extract_path_text(WorkflowRun.data, "trigger_context", "originalRunId") == original_run_id,
                func.json_extract_path_text(WorkflowRun.data, "trigger_context", "original_run_id") == original_run_id,
            ))
        where = and_(*conds)

        total = (await session.execute(select(func.count(WorkflowRun.id)).where(where))).scalar_one()
        fastapi_response.headers["X-Total-Count"] = str(total)

        roots = list((await session.exec(
            select(WorkflowRun).where(where)
            .order_by(WorkflowRun.created_at.desc(), WorkflowRun.id.desc())
            .offset(offset).limit(limit)
        )).all())

        if not roots:
            return []

        root_ids = [r.id for r in roots]
        children = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.parent_id.in_(root_ids))
        )).all())

        grandchildren: list[WorkflowRun] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = list((await session.exec(
                select(WorkflowRun).where(WorkflowRun.parent_id.in_(child_ids))
            )).all())

        all_runs = roots + children + grandchildren
        wf_ids = {r.workflow_id for r in all_runs}
        wf_entries = (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all()
        wf_names = {w.id: w.name for w in wf_entries}

        return _build_summary_tree(all_runs, wf_names)

    @router.get("/workflow-runs/{id}", response_model=WorkflowRunRead, response_model_by_alias=True, tags=["workflow-runs"])
    async def get_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")

        children = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.parent_id == id)
        )).all())
        grandchildren: list[WorkflowRun] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = list((await session.exec(
                select(WorkflowRun).where(WorkflowRun.parent_id.in_(child_ids))
            )).all())

        cm: dict[int, list[WorkflowRun]] = defaultdict(list)
        for r in children + grandchildren:
            cm[r.parent_id].append(r)

        wf_ids = {run.workflow_id} | {r.workflow_id for r in children + grandchildren}
        wf_entries = (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all()
        wf_names = {w.id: w.name for w in wf_entries}

        return _run_to_read(run, cm, wf_names)

    @router.post("/workflow-runs/{id}/rerun", status_code=202, tags=["workflow-runs"])
    async def rerun_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")

        stored = (run.data or {}).get("trigger_context") or {}
        if not stored:
            stored = {"type": run.triggered_by.value if hasattr(run.triggered_by, "value") else run.triggered_by, "inputs": {}}
        original_ctx = TriggerContext.from_db(stored)
        rerun_ctx = TriggerContext(
            type="rerun",
            inputs=original_ctx.inputs,
            metadata={**original_ctx.metadata, "originalType": original_ctx.type, "originalRunId": str(id)},
        )

        wf = await session.get(Workflow, run.workflow_id)
        workflow_name = wf.name if wf else ""
        try:
            await invoke(workflow_name, rerun_ctx)
        except KeyError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow '{workflow_name}' is not registered in this process",
            )

        return {"status": "accepted"}

    @router.post("/workflow-runs/{id}/cancel", status_code=200, tags=["workflow-runs"])
    async def cancel_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")
        if run.status not in (WorkflowStatus.pending, WorkflowStatus.running):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Run is already in a terminal state")

        wf = await session.get(Workflow, run.workflow_id)
        workflow_name = wf.name if wf else ""

        run.status = WorkflowStatus.cancelled
        run.finished_at = datetime.now(timezone.utc)
        session.add(run)
        await session.commit()

        await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run, workflow_name)})
        await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run, workflow_name)})

        live_task = _running_tasks.get(id)
        if live_task is not None and not live_task.done():
            live_task.cancel()

        return {"status": "cancelled"}

    @router.post("/workflow-runs/cancel-pending", status_code=200, tags=["workflow-runs"])
    async def cancel_pending_runs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        pending = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.status == WorkflowStatus.pending)
        )).all())

        if not pending:
            return {"cancelled": 0}

        wf_ids = {r.workflow_id for r in pending}
        wf_entries = (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all()
        wf_names = {w.id: w.name for w in wf_entries}

        now = datetime.now(timezone.utc)
        for run in pending:
            run.status = WorkflowStatus.cancelled
            run.finished_at = now
            session.add(run)

        await session.commit()

        for run in pending:
            name = wf_names.get(run.workflow_id, "")
            await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run, name)})
            await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run, name)})

        return {"cancelled": len(pending)}

    @router.post("/workflow-runs/cancel-all", status_code=200, tags=["workflow-runs"])
    async def cancel_all_runs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Cancel all pending and running (root-level) workflow runs."""
        runs = list((await session.exec(
            select(WorkflowRun).where(
                WorkflowRun.status.in_([WorkflowStatus.pending, WorkflowStatus.running]),
                WorkflowRun.parent_id == None,  # noqa: E711
            )
        )).all())

        if not runs:
            return {"cancelled": 0}

        wf_ids = {r.workflow_id for r in runs}
        wf_entries = (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all()
        wf_names = {w.id: w.name for w in wf_entries}

        now = datetime.now(timezone.utc)
        for run in runs:
            run.status = WorkflowStatus.cancelled
            run.finished_at = now
            session.add(run)

        await session.commit()

        for run in runs:
            name = wf_names.get(run.workflow_id, "")
            await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run, name)})
            await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run, name)})

        return {"cancelled": len(runs)}

    @router.get("/execution-buckets", response_model=list[dict], tags=["execution-buckets"])
    async def get_execution_buckets(
        from_ms: int = Query(..., alias="from"),
        to_ms: int = Query(..., alias="to"),
        step_ms: int = Query(..., alias="step"),
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        dt_from = datetime.fromtimestamp(from_ms / 1000, tz=timezone.utc)
        dt_to = datetime.fromtimestamp(to_ms / 1000, tz=timezone.utc)

        runs = (await session.exec(
            select(WorkflowRun).where(
                WorkflowRun.started_at >= dt_from,
                WorkflowRun.started_at <= dt_to,
            )
        )).all()

        buckets: dict[int, dict] = {}
        for run in runs:
            if run.started_at is None:
                continue
            slot = (int(run.started_at.timestamp() * 1000) // step_ms) * step_ms
            if slot not in buckets:
                buckets[slot] = {"x": slot, "y": 0, "hasFailed": False}
            buckets[slot]["y"] += 1
            if run.status == WorkflowStatus.failed:
                buckets[slot]["hasFailed"] = True

        output = []
        slot = (from_ms // step_ms) * step_ms
        last = (to_ms // step_ms) * step_ms
        while slot <= last:
            output.append(buckets.get(slot, {"x": slot, "y": 0, "hasFailed": False}))
            slot += step_ms
        return output

    def _cfg_read(r: ConfigRecord) -> ConfigRead:
        return ConfigRead(
            id=r.id, key=r.key, value=r.value, type=r.type,
            select_options=r.select_options, description=r.description,
            folder=r.folder, created_at=r.created_at, updated_at=r.updated_at,
        )

    @router.get("/configs", response_model=list[ConfigRead], response_model_by_alias=True, tags=["configs"])
    async def list_configs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        return [_cfg_read(r) for r in (await session.exec(select(ConfigRecord))).all()]

    @router.post("/configs", response_model=ConfigRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["configs"])
    async def create_config(
        body: ConfigCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = ConfigRecord(**body.model_dump(by_alias=False))
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return _cfg_read(record)

    @router.patch("/configs/{id}", response_model=ConfigRead, response_model_by_alias=True, tags=["configs"])
    async def update_config(
        id: int,
        body: ConfigUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = await session.get(ConfigRecord, id)
        if not record:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
        for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
            setattr(record, field, value)
        record.updated_at = datetime.now(timezone.utc)
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return _cfg_read(record)

    @router.delete("/configs/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["configs"])
    async def delete_config(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = await session.get(ConfigRecord, id)
        if not record:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
        await session.delete(record)
        await session.commit()

    async def _tbl_read(t: DataTable, session: AsyncSession) -> DbTableRead:
        result = await session.execute(text(f"SELECT * FROM {_pg_table(t.id)} ORDER BY id"))
        rows = [_normalize_row(r._mapping) for r in result]
        columns = await _read_columns(session, t.id)
        return DbTableRead(
            id=t.id, name=t.name, description=t.description,
            columns=columns, rows=rows,
            created_at=t.created_at, updated_at=t.updated_at,
        )

    @router.get("/db-tables", response_model=list[DbTableRead], response_model_by_alias=True, tags=["db-tables"])
    async def list_db_tables(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        tables = (await session.exec(select(DataTable))).all()
        return [await _tbl_read(t, session) for t in tables]

    @router.post("/db-tables", response_model=DbTableRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["db-tables"])
    async def create_db_table(
        body: DbTableCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        # Validate column names before touching the database.
        seen_ids: set[str] = set()
        for col in (body.columns or []):
            col_id = col.get("id", "")
            _validate_column_id(col_id)
            if col_id in seen_ids:
                raise HTTPException(status_code=422, detail=f"Duplicate column name '{col_id}'.")
            seen_ids.add(col_id)

        # Check for duplicate table name before inserting.
        existing_name = (await session.exec(select(DataTable).where(DataTable.name == body.name))).first()
        if existing_name:
            raise HTTPException(status_code=409, detail=f"A table named '{body.name}' already exists.")

        t = DataTable(name=body.name, description=body.description)
        session.add(t)
        await session.flush()
        tbl = _pg_table(t.id)
        col_defs = ["id INTEGER NOT NULL"] + [
            f"{_qi(col['id'])} {_PG_TYPE_MAP.get(col.get('type', 'text'), 'TEXT')}"
            for col in (body.columns or [])
        ]
        await session.execute(text(f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))"))
        for col in (body.columns or []):
            if col.get("type") == "select" and col.get("selectOptions"):
                await session.execute(
                    text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                        "VALUES (:tid, :cn, CAST(:opts AS json))"
                    ),
                    {"tid": t.id, "cn": col["id"], "opts": json.dumps(col["selectOptions"])},
                )
        col_ids = [c["id"] for c in (body.columns or [])]
        max_id = 0
        for row in (body.rows or []):
            row_id = row.get("id")
            if not isinstance(row_id, int) or row_id <= 0:
                max_id += 1
                row = {**{k: v for k, v in row.items() if k != "id"}, "id": max_id}
            else:
                max_id = max(max_id, row_id)
            await _upsert_row(session, tbl, row, col_ids)
        await session.commit()
        await session.refresh(t)
        return await _tbl_read(t, session)

    @router.patch("/db-tables/{id}", response_model=DbTableRead, response_model_by_alias=True, tags=["db-tables"])
    async def update_db_table(
        id: int,
        body: DbTableUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Table not found")
        tbl = _pg_table(id)
        patch = body.model_dump(exclude_unset=True, by_alias=False)
        if "name" in patch and patch["name"] != t.name:
            clash = (await session.exec(select(DataTable).where(DataTable.name == patch["name"]))).first()
            if clash:
                raise HTTPException(status_code=409, detail=f"A table named '{patch['name']}' already exists.")
            t.name = patch["name"]
        if "description" in patch:
            t.description = patch["description"]
        if "columns" in patch:
            new_columns: list[dict] = patch["columns"] or []
            # Validate all incoming column names before any DDL.
            seen_ids: set[str] = set()
            for col in new_columns:
                col_id = col.get("id", "")
                _validate_column_id(col_id)
                if col_id in seen_ids:
                    raise HTTPException(status_code=422, detail=f"Duplicate column name '{col_id}'.")
                seen_ids.add(col_id)
            old_cols = await _read_columns(session, id)
            old_col_map = {c["id"]: c for c in old_cols}
            new_col_map = {c["id"]: c for c in new_columns}
            for col_id in set(new_col_map) - set(old_col_map):
                pg_type = _PG_TYPE_MAP.get(new_col_map[col_id].get("type", "text"), "TEXT")
                try:
                    await session.execute(text(f"ALTER TABLE {tbl} ADD COLUMN {_qi(col_id)} {pg_type}"))
                except Exception as exc:
                    err_str = str(exc).lower()
                    if "already exists" in err_str:
                        await session.rollback()
                        raise HTTPException(status_code=409, detail=f"Column '{col_id}' already exists.")
                    raise
            for col_id in set(old_col_map) - set(new_col_map):
                await session.execute(text(f"ALTER TABLE {tbl} DROP COLUMN {_qi(col_id)}"))
                await session.execute(
                    text("DELETE FROM data_table_column_meta WHERE table_id = :tid AND column_name = :cn"),
                    {"tid": id, "cn": col_id},
                )
            for col_id in set(old_col_map) & set(new_col_map):
                old_pg = _PG_TYPE_MAP.get(old_col_map[col_id].get("type", "text"), "TEXT")
                new_pg = _PG_TYPE_MAP.get(new_col_map[col_id].get("type", "text"), "TEXT")
                if old_pg != new_pg:
                    await session.execute(text(
                        f"ALTER TABLE {tbl} ALTER COLUMN {_qi(col_id)} TYPE {new_pg} "
                        f"USING CAST({_qi(col_id)} AS {new_pg})"
                    ))
            for col_id, col in new_col_map.items():
                if col.get("type") == "select" and col.get("selectOptions"):
                    await session.execute(
                        text(
                            "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                            "VALUES (:tid, :cn, CAST(:opts AS json)) "
                            "ON CONFLICT (table_id, column_name) DO UPDATE SET select_options = EXCLUDED.select_options"
                        ),
                        {"tid": id, "cn": col_id, "opts": json.dumps(col["selectOptions"])},
                    )
                else:
                    await session.execute(
                        text("DELETE FROM data_table_column_meta WHERE table_id = :tid AND column_name = :cn"),
                        {"tid": id, "cn": col_id},
                    )
        if "rows" in patch:
            col_ids = await _get_column_names(session, tbl)
            max_id: int = (await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))) or 0
            normalized: list[dict] = []
            for row in (patch["rows"] or []):
                row_id = row.get("id")
                if not isinstance(row_id, int) or row_id <= 0:
                    max_id += 1
                    normalized.append({**{k: v for k, v in row.items() if k != "id"}, "id": max_id})
                else:
                    max_id = max(max_id, row_id)
                    normalized.append(row)
            new_ids = [r["id"] for r in normalized]
            if new_ids:
                id_list = ", ".join(str(i) for i in new_ids)
                await session.execute(text(f"DELETE FROM {tbl} WHERE id NOT IN ({id_list})"))
            else:
                await session.execute(text(f"DELETE FROM {tbl}"))
            for row in normalized:
                await _upsert_row(session, tbl, row, col_ids)
        t.updated_at = datetime.now(timezone.utc)
        session.add(t)
        await session.commit()
        await session.refresh(t)
        return await _tbl_read(t, session)

    @router.delete("/db-tables/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["db-tables"])
    async def delete_db_table(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Table not found")
        await session.execute(text(f"DROP TABLE IF EXISTS {_pg_table(id)}"))
        await session.delete(t)
        await session.commit()

    async def _build_workflow_definition(
        name: str,
        meta: dict,
        cfg: Workflow | None,
        session: AsyncSession,
    ) -> WorkflowDefinitionRead:
        wf = (await session.exec(select(Workflow).where(Workflow.name == name))).first()
        wf_id = wf.id if wf else None

        if wf_id is not None:
            total: int = (await session.execute(
                select(func.count(WorkflowRun.id)).where(WorkflowRun.workflow_id == wf_id, WorkflowRun.parent_id == None)  # noqa: E711
            )).scalar_one()

            failed: int = (await session.execute(
                select(func.count(WorkflowRun.id)).where(
                    WorkflowRun.workflow_id == wf_id,
                    WorkflowRun.parent_id == None,  # noqa: E711
                    WorkflowRun.status == WorkflowStatus.failed,
                )
            )).scalar_one()

            last_run = (await session.exec(
                select(WorkflowRun)
                .where(WorkflowRun.workflow_id == wf_id, WorkflowRun.parent_id == None)  # noqa: E711
                .order_by(WorkflowRun.created_at.desc())
                .limit(1)
            )).first()
        else:
            total = 0
            failed = 0
            last_run = None

        recent_nodes: list[str] = []
        if last_run and last_run.data:
            recent_nodes = [n["name"] for n in last_run.data.get("nodes", []) if n.get("status") != "pending"]

        return WorkflowDefinitionRead(
            name=name,
            trigger_type=meta["trigger_type"],
            cron=meta["cron"],
            interval=meta["interval"],
            is_webhook=meta["is_webhook"],
            webhook_path=meta["webhook_path"],
            enabled=cfg.enabled if cfg else True,
            cron_override=cfg.cron_override if cfg else None,
            interval_override=cfg.interval_override if cfg else None,
            timeout_seconds=cfg.timeout_seconds if cfg else None,
            max_concurrent_runs=cfg.max_concurrent_runs if cfg else None,
            recent_nodes=recent_nodes,
            last_run_at=last_run.started_at if last_run else None,
            last_run_status=last_run.status.value if last_run else None,
            total_runs=total,
            failure_rate=round(failed / total, 4) if total > 0 else 0.0,
            input_schema=[InputFieldDef(**f) for f in meta.get("input_schema", [])],
            instructions=meta.get("instructions"),
        )

    @router.get("/workflows", response_model=list[WorkflowDefinitionRead], response_model_by_alias=True, tags=["workflows"])
    async def list_workflow_definitions(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        cfgs: dict[str, Workflow] = {
            r.name: r for r in (await session.exec(select(Workflow))).all()
        }
        return [
            await _build_workflow_definition(name, meta, cfgs.get(name), session)
            for name, meta in workflow_meta.items()
        ]

    @router.get("/workflows/{name}", response_model=WorkflowDefinitionRead, response_model_by_alias=True, tags=["workflows"])
    async def get_workflow_definition(
        name: str,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if name not in workflow_meta:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
        cfg = (await session.exec(select(Workflow).where(Workflow.name == name))).first()
        return await _build_workflow_definition(name, workflow_meta[name], cfg, session)

    @router.patch("/workflows/{name}", response_model=WorkflowDefinitionRead, response_model_by_alias=True, tags=["workflows"])
    async def update_workflow_config(
        name: str,
        body: WorkflowConfigUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if name not in workflow_meta:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
        cfg = (await session.exec(select(Workflow).where(Workflow.name == name))).first()
        if cfg is None:
            cfg = Workflow(name=name)
            session.add(cfg)
        for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
            setattr(cfg, field, value)
        cfg.updated_at = datetime.now(timezone.utc)
        session.add(cfg)
        await session.commit()
        await session.refresh(cfg)

        # If max_concurrent_runs changed, wake the drain loop so pending runs
        # that are now below the new limit start executing immediately.
        if "max_concurrent_runs" in body.model_dump(exclude_unset=True, by_alias=False):
            from .decorator import _ensure_drain_task, _notify_drain
            if name in wrappers:
                raw_fn = getattr(wrappers[name], "_gtm_fn", wrappers[name])
                _ensure_drain_task(name, raw_fn)
                _notify_drain(name)

        return await _build_workflow_definition(name, workflow_meta[name], cfg, session)

    @router.post("/workflows/{name}/trigger", status_code=202, tags=["workflows"])
    async def trigger_workflow(
        name: str,
        body: WorkflowTriggerRequest,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if name not in workflow_meta:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
        cfg = (await session.exec(select(Workflow).where(Workflow.name == name))).first()
        if cfg is not None and not cfg.enabled:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Workflow is disabled")
        ctx = TriggerContext("manual", body.inputs)
        await invoke(name, ctx)
        return {"status": "accepted"}

    @router.get("/users", response_model=list[UserRead], response_model_by_alias=True, tags=["users"])
    async def list_users(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        users = (await session.exec(select(User))).all()
        return [UserRead(username=u.username, created_at=u.created_at) for u in users]

    @router.post("/users", response_model=UserRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["users"])
    async def create_user(
        body: UserCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if await session.get(User, body.username):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")
        user = User(username=body.username, hashed_password=hash_password(body.password))
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return UserRead(username=user.username, created_at=user.created_at)

    @router.delete("/users/{username}", status_code=status.HTTP_204_NO_CONTENT, tags=["users"])
    async def delete_user(
        username: str,
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        if username == current_user.username:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot delete your own account")
        user = await session.get(User, username)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        tokens = (await session.exec(select(ApiToken).where(ApiToken.username == username))).all()
        for t in tokens:
            await session.delete(t)
        await session.delete(user)
        await session.commit()

    @router.patch("/users/{username}/password", status_code=status.HTTP_204_NO_CONTENT, tags=["users"])
    async def update_user_password(
        username: str,
        body: UserPasswordUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        user = await session.get(User, username)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        user.hashed_password = hash_password(body.password)
        session.add(user)
        await session.commit()

    @router.get("/tokens", response_model=list[ApiTokenRead], response_model_by_alias=True, tags=["tokens"])
    async def list_tokens(
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        tokens = (await session.exec(select(ApiToken).where(ApiToken.username == current_user.username))).all()
        return [
            ApiTokenRead(id=t.id, name=t.name, username=t.username, created_at=t.created_at, expires_at=t.expires_at)
            for t in tokens
        ]

    @router.post("/tokens", response_model=ApiTokenCreated, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["tokens"])
    async def create_token(
        body: ApiTokenCreate,
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        expires_at = datetime.now(timezone.utc) + timedelta(days=body.expires_days) if body.expires_days else None
        record = ApiToken(name=body.name, username=current_user.username, expires_at=expires_at)
        session.add(record)
        await session.commit()
        await session.refresh(record)
        token_str = create_api_token(current_user.username, str(record.id), body.expires_days)
        return ApiTokenCreated(
            id=record.id, name=record.name, username=record.username,
            created_at=record.created_at, expires_at=record.expires_at, token=token_str,
        )

    @router.delete("/tokens/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["tokens"])
    async def revoke_token(
        id: int,
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        token = await session.get(ApiToken, id)
        if not token or token.username != current_user.username:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Token not found")
        await session.delete(token)
        await session.commit()

    @router.get("/webhook-token", response_model=WebhookTokenRead, response_model_by_alias=True, tags=["webhook-token"])
    async def get_webhook_token(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        wt = await session.get(WebhookToken, "default")
        if not wt:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook token not initialized")
        return WebhookTokenRead(token=wt.token, created_at=wt.created_at)

    @router.post("/webhook-token/rotate", response_model=WebhookTokenRead, response_model_by_alias=True, tags=["webhook-token"])
    async def rotate_webhook_token(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        wt = await session.get(WebhookToken, "default")
        if wt is None:
            wt = WebhookToken(token=generate_webhook_token())
            session.add(wt)
        else:
            wt.token = generate_webhook_token()
            wt.created_at = datetime.now(timezone.utc)
            session.add(wt)
        await session.commit()
        await session.refresh(wt)
        return WebhookTokenRead(token=wt.token, created_at=wt.created_at)


    @router.websocket("/ws")
    async def ws_endpoint(ws: WebSocket, token: str = ""):
        """Real-time event stream.

        Connect with ?token=<jwt>.  Then send a subscription message:

            {"type": "subscribe", "channel": "workflow_list"}
            {"type": "subscribe", "channel": "workflow_detail", "id": "<run-id>"}

        The server will reply with {"type": "subscribed", "channel": "..."} and
        then push events as they happen:

            workflow_list  → {"type": "run_created"|"run_updated", "data": <WorkflowRunSummary>}
            workflow_detail → {"type": "run_updated", "data": <WorkflowRun>}
        """
        if not decode_token(token):
            await ws.close(code=4001)
            return
        await ws.accept()
        try:
            while True:
                data = await ws.receive_json()
                msg_type = data.get("type")
                if msg_type == "subscribe":
                    channel = data.get("channel", "")
                    if channel == "workflow_detail":
                        run_id = data.get("id", "")
                        channel = f"workflow_detail:{run_id}"
                    if channel:
                        manager.subscribe(ws, channel)
                        await ws.send_json({"type": "subscribed", "channel": channel})
                elif msg_type == "ping":
                    await ws.send_json({"type": "pong"})
        except WebSocketDisconnect:
            manager.disconnect(ws)
        except Exception:
            manager.disconnect(ws)

    return router

