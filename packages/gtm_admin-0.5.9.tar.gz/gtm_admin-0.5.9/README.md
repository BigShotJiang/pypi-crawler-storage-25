# gtm-admin

Workflow monitoring and management for FastAPI apps.

`gtm-admin` adds a self-hosted dashboard and run-tracking API to **any FastAPI application** with zero infrastructure setup. Decorate Python workflow functions with `@gtm.workflow` and choose how they are triggered: manually, on a cron schedule, or via a webhook.

## Install

```bash
pip install gtm-admin

# Required for cron-scheduled workflows:
pip install apscheduler
```

## Usage

````python
import os
from fastapi import FastAPI
from gtm_admin import GTMAdmin

app = FastAPI()

gtm = GTMAdmin(
    app,
    db_url=os.environ["GTM_DB_URL"],
    secret=os.environ["GTM_SECRET"],
)

# ── Manual workflow (called from your own code) ──────────────────────────────
@gtm.workflow
async def enrich_leads(inputs: dict):
    results = call_some_api(inputs["leads"])
    return {"enriched": results}

# ── Cron workflow (runs on a schedule automatically) ──────────────────────────
@gtm.workflow(cron="0 9 * * 1-5")   # every weekday at 09:00
async def daily_sync(inputs: dict):
    return {"synced": sync_database()}

# ── Webhook workflow (triggered by an external HTTP POST) ─────────────────────
@gtm.workflow(webhook=True)
# → auto-mounts POST /api/webhooks/process_event
async def process_event(inputs: dict):
    return handle(inputs)

# ── Node-based workflow (nodes are tracked as individual steps) ───────────────
@gtm.node
async def fetch_contacts(inputs: dict) -> dict:
    contacts = call_crm_api(inputs["limit"])
    return {"contacts": contacts}

@gtm.node
async def enrich_contacts(inputs: dict) -> dict:
    enriched = call_enrichment_api(inputs["contacts"])
    return {"enriched_count": len(enriched), "results": enriched}

@gtm.workflow
async def enrich_leads(inputs: dict):
    fetched = await fetch_contacts({"limit": inputs.get("limit", 10)})
    return await enrich_contacts(fetched)```

## Workflow Decorator Options

| Parameter            | Type                      | Default | Description                                                         |
| -------------------- | ------------------------- | ------- | ------------------------------------------------------------------- |
| `cron`               | `str`                     | `None`  | 5-field cron expression. Requires `apscheduler`.                    |
| `interval`           | `int`                     | `None`  | Run every N seconds. Requires `apscheduler`.                        |
| `webhook`            | `bool`                    | `False` | Auto-mount `POST /api/webhooks/{name}`. Body is passed as `inputs`. |
| `background`         | `bool \| dict \| Response` | `False` | Webhook background mode — see below.                                |
| `max_concurrent_runs`| `int \| None`             | `300`   | Maximum number of runs that may execute simultaneously. Excess triggers are queued as `pending` runs and executed in order as slots free up. Set to `None` for no limit. |
| `input_schema`       | `list[dict]`              | `[]`    | Field definitions for the dashboard run panel. Each dict has `key`, `type` (`"string"`, `"number"`, `"boolean"`, `"select"`, `"text"`, `"json"`), and optionally `label`, `description`, `required`, `default`, `options` (for `"select"`). When provided, the dashboard renders a structured form instead of a raw JSON editor. |
| `instructions`       | `str`                     | `None`  | Free-text guidance shown as an info banner in the dashboard run panel. Useful for documenting expected inputs or side-effects. |

When used without arguments (`@gtm.workflow`) the workflow is **manual** — called directly from your code or via the dashboard re-run button.

### Cron syntax

````

┌───── minute (0-59)
│ ┌───── hour (0-23)
│ │ ┌───── day of month (1-31)
│ │ │ ┌───── month (1-12)
│ │ │ │ ┌───── day of week (0-6 or 1-5 for Mon–Fri)

---

````

```python
@gtm.workflow(cron="0 9 * * 1-5")   # every weekday at 09:00
async def daily_sync(inputs: dict): ...

@gtm.workflow(interval=10)           # every 10 seconds
async def frequent_job(inputs: dict): ...
````

### Webhook usage

```bash
curl -X POST https://your-app.com/api/webhooks/process_event \
  -H "Content-Type: application/json" \
  -d '{"key": "value"}'
```

The JSON body is passed as `inputs` to your workflow function. Every invocation is tracked as a `WorkflowRun` with `trigger_type = "webhook"`.

### Webhook response modes

Webhooks support two response modes, controlled independently.

#### Sync mode (default)

The HTTP connection stays open until the workflow finishes. The function's return value drives the response:

| Return value       | HTTP response                                                       |
| ------------------ | ------------------------------------------------------------------- |
| `None` / no return | `200 {"status": "success"}`                                         |
| `dict`             | `200` with that dict as the JSON body                               |
| `Response`         | passed through as-is (full control over status code, headers, body) |

```python
from fastapi.responses import JSONResponse

@gtm.workflow(webhook=True)
async def validate_contact(inputs: dict):
    if not inputs.get("email"):
        return JSONResponse({"error": "email required"}, status_code=400)
    result = run_validation(inputs["email"])
    return {"valid": result}   # → 200 {"valid": true}
```

#### Background mode

Use `background` to respond immediately while the workflow runs asynchronously as an `asyncio` task. Ideal for long-running jobs (enrichment, reports, etc.) where the caller should not block.

The function's return value is silently ignored — the response is already sent.

| `background=` value | Immediate response           |
| ------------------- | ---------------------------- |
| `True`              | `202 {"status": "accepted"}` |
| `dict`              | `202` with that dict as body |
| `Response`          | exactly that response        |

```python
from fastapi.responses import JSONResponse

# Simplest — 202 {"status": "accepted"}
@gtm.workflow(webhook=True, background=True)
async def enrich_contact(inputs: dict):
    ...

# Custom body (still 202)
@gtm.workflow(webhook=True, background={"queued": True})
async def enrich_contact(inputs: dict):
    ...

# Full control
@gtm.workflow(webhook=True, background=JSONResponse({"accepted": True}, status_code=200))
async def enrich_contact(inputs: dict):
    ...
```

## Node Decorator

Use `@gtm.node` to break a workflow into individually-tracked steps. Each node records its own inputs, outputs, timing, and logs in the dashboard.

```python
@gtm.node
async def fetch_contacts(inputs: dict) -> dict:
    contacts = call_crm_api(inputs["limit"])
    return {"contacts": contacts}

@gtm.node
async def enrich_contacts(inputs: dict) -> dict:
    enriched = call_enrichment_api(inputs["contacts"])
    return {"enriched_count": len(enriched), "results": enriched}

@gtm.workflow
async def enrich_leads(inputs: dict):
    fetched = await fetch_contacts({"limit": inputs.get("limit", 10)})
    return await enrich_contacts(fetched)
```

Nodes are reusable — the same `@gtm.node` function can be called from multiple workflows. If a node is called **outside** a workflow (e.g. from a plain route), it runs transparently with no tracking overhead.

| Workflows that do **not** call any `@gtm.node` functions continue to work unchanged — a single implicit node is recorded for the whole run. |

### Logging inside nodes

Call `gtm.log(message)` from inside a `@gtm.node` function to append a line to that node's log buffer. Logs appear in the dashboard alongside the node's inputs/outputs.

```python
@gtm.node
async def fetch_contacts(inputs: dict) -> dict:
    gtm.log("Fetching contacts from CRM")
    contacts = call_crm_api(inputs["limit"])
    gtm.log(f"  Got {len(contacts)} contacts")
    return {"contacts": contacts}
```

When a node raises an exception, the traceback is automatically appended to the logs after any lines written by `gtm.log()`.

Calling `gtm.log()` outside a node (or outside a workflow) is a no-op.

### Declaring a node execution plan

Call `gtm.plan(*node_names)` at the top of a `@gtm.workflow` function to declare the full ordered list of nodes the workflow intends to run. Any node names in the plan that have not completed when the workflow finishes — because an earlier node raised — will be recorded with `status = "pending"` in the dashboard.

```python
@gtm.workflow(webhook=True)
async def process_event(inputs: dict):
    gtm.plan("validate_input", "call_external_api", "store_result")
    step1 = await validate_input(inputs)
    step2 = await call_external_api(step1)  # if this raises, store_result → pending
    return await store_result(step2)
```

The plan is optional. Workflows without a plan simply show the nodes that ran.
| ------------------------------------------------------------------------------------------------------------------------------------------- | ------- | --- | ------- | ------------------------------------------------------------- |
| `app` | FastAPI | ✓ | — | Your FastAPI application instance |
| `db_url` | str | ✓ | — | PostgreSQL connection string (`postgresql+asyncpg://...`) |
| `secret` | str | ✓ | — | Secret key for signing JWT tokens |
| `dev` | bool | | `False` | Proxy `/admin/*` to Vite HMR server instead of serving static |
| `auto_seed` | bool | | `False` | Seed the database with demo data on startup |

## API Routes

All routes are mounted under `/api` on your FastAPI app.

| Method    | Path                                | Auth | Description                                |
| --------- | ----------------------------------- | ---- | ------------------------------------------ |
| POST      | `/api/auth/token`                   | —    | Log in; returns a JWT access token         |
| POST      | `/api/auth/register`                | —    | Register a new user account                |
| GET       | `/api/health`                       | —    | Health check                               |
| POST      | `/api/webhooks/{name}`              | —    | Invoke a webhook-enabled workflow          |
| GET       | `/api/workflow-runs`                | ✓    | Paginated list of runs (filterable)        |
| GET       | `/api/workflow-runs/stats`          | ✓    | Status counts + active/recent run lists    |
| GET       | `/api/workflow-runs/{id}`           | ✓    | Full run detail with nodes                 |
| POST      | `/api/workflow-runs/{id}/rerun`     | ✓    | Re-execute a workflow with the same inputs |
| POST      | `/api/workflow-runs/{id}/cancel`    | ✓    | Cancel a specific pending or running run   |
| POST      | `/api/workflow-runs/cancel-pending` | ✓    | Cancel all pending (queued) runs           |
| POST      | `/api/workflow-runs/cancel-all`     | ✓    | Cancel all pending and running runs        |
| GET       | `/api/config`                       | ✓    | List all config records                    |
| POST      | `/api/config`                       | ✓    | Create a config record                     |
| PATCH     | `/api/config/{id}`                  | ✓    | Update a config record                     |
| DELETE    | `/api/config/{id}`                  | ✓    | Delete a config record                     |
| GET       | `/api/db-tables`                    | ✓    | List all database tables                   |
| POST      | `/api/db-tables`                    | ✓    | Create a table                             |
| PATCH     | `/api/db-tables/{id}`               | ✓    | Update a table's schema or rows            |
| DELETE    | `/api/db-tables/{id}`               | ✓    | Delete a table                             |
| WebSocket | `/api/ws?token=<jwt>`               | ✓    | Real-time event stream (see below)         |
| GET       | `/admin/`                           | —    | Dashboard SPA                              |

## Real-time WebSocket events

The dashboard receives live updates through a single WebSocket endpoint at `GET /api/ws?token=<jwt>`.
There is no polling — every event is deterministically triggered by the decorator when a workflow run is created or finishes.

### Subscribing

After connecting, send a JSON subscription message to tell the server which view you are on:

```json
{ "type": "subscribe", "channel": "workflow_list" }
{ "type": "subscribe", "channel": "workflow_detail", "id": "<run-id>" }
```

You can switch channels at any time by sending a new subscription message.  
The server replies with `{"type": "subscribed", "channel": "..."}`.

### Channels

| Channel                | Triggered when                                                                | Payload shape                                                 |
| ---------------------- | ----------------------------------------------------------------------------- | ------------------------------------------------------------- |
| `workflow_list`        | A run is **created** (status `running` or `pending` if queued)                | `run_created` event with `WorkflowRunSummary`                 |
| `workflow_list`        | A run **transitions** (pending→running, or finishes success/failed/cancelled) | `run_updated` event with `WorkflowRunSummary`                 |
| `workflow_detail:{id}` | That specific run **transitions or finishes**                                 | `run_updated` event with full `WorkflowRun` (including nodes) |

### Event shape

```json
{ "type": "run_created", "data": { "id": "...", "name": "...", "status": "running", ... } }
{ "type": "run_updated", "data": { "id": "...", "name": "...", "status": "success", "nodes": [...], ... } }
```

### Frontend integration

Two React hooks wrap the WebSocket logic (`frontend/src/hooks/`):

| Hook                                                    | Subscribes to          | Used in                                                  |
| ------------------------------------------------------- | ---------------------- | -------------------------------------------------------- |
| `useWorkflowListSocket({ onRunCreated, onRunUpdated })` | `workflow_list`        | `WorkflowListPage`                                       |
| `useWorkflowDetailSocket(id, onUpdate)`                 | `workflow_detail:{id}` | `WorkflowListPage` (inline panel) + `WorkflowDetailPage` |

Each hook opens its own WebSocket connection and closes it when the component unmounts.
Callbacks are held in a `useRef` so the socket never needs to reconnect when component state changes.

## Dashboard Features

| Page            | Route            | Description                                         |
| --------------- | ---------------- | --------------------------------------------------- |
| Overview        | `/`              | Status count cards, active runs, and recent runs    |
| Workflows       | `/workflows`     | Searchable/filterable table; click a row for detail |
| Workflow Detail | `/workflows/:id` | Node-level I/O, timing, logs; re-run button         |
| Config          | `/config`        | Key/value configuration store with typed fields     |
| Database        | `/database`      | Lightweight table viewer and editor                 |

## Deployment

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install gtm-admin
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8080
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8080"]
```

Set the following environment variables in your hosting console:

| Variable     | Description                                          |
| ------------ | ---------------------------------------------------- |
| `GTM_DB_URL` | PostgreSQL connection string (Supabase, Neon, …)     |
| `GTM_SECRET` | Random secret — generate with `openssl rand -hex 32` |

## Development mode

In dev mode, `/admin/*` is proxied to a Vite HMR server instead of serving static files. Use this when developing the dashboard locally:

```python
gtm = GTMAdmin(app, db_url=..., secret=..., dev=os.getenv("GTM_DEV") == "true")
```

## Package Structure

```
api/
├── src/gtm_admin/          # The published library
│   ├── __init__.py         # Exports GTMAdmin
│   ├── core.py             # GTMAdmin class — mounts router + dashboard
│   ├── auth.py             # JWT creation/verification + bcrypt helpers
│   ├── database.py         # Async SQLAlchemy engine + session factory + migrations
│   ├── decorator.py        # @gtm.workflow — wraps functions with run capture logic
│   ├── deps.py             # get_current_user FastAPI dependency
│   ├── models.py           # WorkflowRun, User, ConfigRecord, DbTable SQLModel models
│   ├── router.py           # All API route handlers + Pydantic response schemas
│   ├── seed.py             # Demo data seeder (used by auto_seed=True)
│   └── static/             # Built React SPA (populated by `pnpm run build`)
├── app/                    # Standalone FastAPI app for local development
│   ├── main.py             # App entry point — includes all routers + Vite proxy
│   ├── auth.py             # Auth helpers (mirrors the library)
│   ├── config.py           # pydantic-settings config (DATABASE_URL, SECRET_KEY)
│   ├── database.py         # Engine + session setup for the standalone app
│   ├── deps.py             # FastAPI dependencies
│   ├── models/             # SQLModel models (WorkflowRun, User, ConfigRecord, DbTable)
│   └── routers/            # auth, workflow_runs, configs, db_tables, execution_buckets
├── alembic/                # Database migrations for the standalone dev app
├── seed.py                 # Seed script (run directly: uv run python seed.py)
├── hatch_build.py          # Build hook — runs `pnpm run build` before packaging
└── pyproject.toml          # Package metadata + hatchling build config
```

## Local development setup

```bash
cd api
cp .env.example .env        # Set DATABASE_URL and SECRET_KEY
uv sync                      # Creates .venv and installs all dependencies
uv run alembic upgrade head  # Apply migrations
uv run python seed.py        # (Optional) seed demo data
```

Run the standalone dev server (from the monorepo root):

```bash
make dev-api                 # FastAPI on :8080 with GTM_DEV=true
make dev-frontend            # Vite on :5173 (run concurrently for HMR)
make dev                     # Both at once
```

## Requirements

- Python 3.11+
- PostgreSQL database (Supabase, Neon, or self-hosted)
- FastAPI app

## License

MIT
