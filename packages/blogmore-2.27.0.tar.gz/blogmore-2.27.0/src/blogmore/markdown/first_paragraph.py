"""First-paragraph extraction from Markdown content.

Converts Markdown to HTML using all BlogMore extensions and then locates
the first top-level paragraph that contains real text, returning it as
plain text.  Block-level containers (admonitions, blockquotes, tables,
lists, etc.) are skipped, as are paragraphs that consist entirely of
images.
"""

import re
from html.parser import HTMLParser

__all__ = ["extract_first_paragraph_from_html"]


class _FirstParagraphExtractor(HTMLParser):
    """HTML parser that extracts plain text from the first non-image-only paragraph.

    Only top-level `<p>` elements are considered; paragraphs nested inside
    block-level containers such as admonition `<div>` elements, blockquotes,
    or list items are skipped.  A paragraph that consists entirely of images
    (no text data) is also skipped so that posts that open with a banner image
    return the following descriptive paragraph instead.
    """

    _BLOCK_TAGS: frozenset[str] = frozenset(
        {
            "div",
            "blockquote",
            "ul",
            "ol",
            "table",
            "thead",
            "tbody",
            "tr",
            "td",
            "th",
            "pre",
            "figure",
            "section",
            "article",
            "aside",
            "nav",
            "header",
            "footer",
            "main",
        }
    )

    def __init__(self) -> None:
        """Initialise the extractor.

        Sets up all tracking state used during parsing:

        * `_block_depth` — current nesting level inside block-level container
          elements (`<div>`, `<blockquote>`, `<ul>`, etc.).  Any `<p>`
          encountered while this is non-zero is nested and therefore skipped.
        * `_in_paragraph` — whether the parser is currently inside a
          candidate top-level `<p>` element.
        * `_chunks` — raw character-data fragments collected from the current
          paragraph, joined and normalised when the paragraph ends.
        * `_has_text` — set to `True` as soon as non-whitespace data is
          seen inside the current paragraph; keeps image-only paragraphs from
          being returned.
        * `_result` — the accepted plain-text paragraph (empty until found).
        * `_done` — short-circuit flag; once `True` all further events are
          ignored.
        """
        super().__init__(convert_charrefs=True)
        self._block_depth: int = 0
        self._in_paragraph: bool = False
        self._chunks: list[str] = []
        self._has_text: bool = False
        self._result: str = ""
        self._done: bool = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        """Process an opening HTML tag.

        Args:
            tag: The lowercase tag name.
            attrs: List of (`attribute-name`, value) pairs for the tag.
        """
        if self._done:
            return
        if tag in self._BLOCK_TAGS:
            self._block_depth += 1
        elif tag == "p" and self._block_depth == 0 and not self._in_paragraph:
            self._in_paragraph = True
            self._chunks = []
            self._has_text = False

    def handle_endtag(self, tag: str) -> None:
        """Process a closing HTML tag.

        Args:
            tag: The lowercase tag name.
        """
        if self._done:
            return
        if tag in self._BLOCK_TAGS:
            if self._block_depth > 0:
                self._block_depth -= 1
        elif tag == "p" and self._in_paragraph:
            self._in_paragraph = False
            text = re.sub(r"\s+", " ", "".join(self._chunks)).strip()
            if self._has_text and text:
                self._result = text
                self._done = True

    def handle_data(self, data: str) -> None:
        """Process character data between tags.

        Args:
            data: The text content between tags.
        """
        if self._done or not self._in_paragraph:
            return
        self._chunks.append(data)
        if data.strip():
            self._has_text = True

    @property
    def result(self) -> str:
        """Get the extracted paragraph text.

        Returns:
            The extracted first paragraph text, or an empty string if none was
            found.
        """
        return self._result


def extract_first_paragraph_from_html(html_content: str) -> str:
    """Extract the first paragraph from HTML content as plain text.

    Args:
        html_content: The HTML content to extract from.

    Returns:
        The first paragraph as plain text, or an empty string if none is found.
    """
    if not html_content.strip():
        return ""
    extractor = _FirstParagraphExtractor()
    extractor.feed(html_content)
    return extractor.result
