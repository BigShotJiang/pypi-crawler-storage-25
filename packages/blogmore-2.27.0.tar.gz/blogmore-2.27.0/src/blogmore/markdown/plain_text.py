"""Markdown to plain text conversion utility.

Provides `blogmore.markdown.plain_text.markdown_to_plain_text` — the canonical way to convert a
Markdown string to clean, whitespace-collapsed plain text within BlogMore.
It runs the input through the Python-Markdown library so that all block
structures (fenced code, blockquotes, tables, admonitions, etc.) are handled
correctly before HTML tags are stripped.
"""

##############################################################################
# Python imports.
import re
import threading
from html.parser import HTMLParser
from typing import cast

import markdown

##############################################################################
# Local imports.
from blogmore.markdown import create_custom_extensions

# Thread-local storage for Markdown instances to ensure thread-safety while
# allowing for instance reuse via .reset().
_thread_local = threading.local()


def get_plain_text_markdown_instance() -> markdown.Markdown:
    """Get a thread-local Markdown instance suitable for plain-text extraction.

    Includes all BlogMore custom extensions and the standard extensions
    needed to correctly parse all block structures.  Intentionally omits
    presentation-only extensions (`codehilite`, `toc`) that are not
    required for text extraction.

    The instance is cached in thread-local storage; the caller should call
    `.reset()` on it before each use if it has been used previously.

    Returns:
        A configured `markdown.Markdown` instance.
    """
    if not hasattr(_thread_local, "plain_text_markdown"):
        _thread_local.plain_text_markdown = markdown.Markdown(
            extensions=[
                "fenced_code",
                "md_in_html",
                "tables",
                "footnotes",
                *create_custom_extensions(with_optimised_images=False),
            ],
        )
    return cast(markdown.Markdown, _thread_local.plain_text_markdown)


class TextExtractor(HTMLParser):
    """HTML parser that accumulates all visible text nodes.

    Unlike the first-paragraph extractor, this parser simply collects every
    character-data node encountered in the HTML, producing a plain-text
    representation of the entire document.
    """

    def __init__(self) -> None:
        """Initialise the extractor."""
        super().__init__(convert_charrefs=True)
        self._chunks: list[str] = []

    def handle_data(self, data: str) -> None:
        """Accumulate a character-data node.

        Args:
            data: Text content from the current HTML node.
        """
        self._chunks.append(data)

    @property
    def text(self) -> str:
        """Return all accumulated text with whitespace collapsed.

        Returns:
            Plain-text content with all whitespace runs normalised to a
            single space and leading/trailing whitespace removed.
        """
        return re.sub(r"\s+", " ", "".join(self._chunks)).strip()


class TextSansCodeExtractor(TextExtractor):
    """HTML parser that accumulates text nodes, skipping fenced code blocks.

    Fenced code blocks render as `<pre><code>…</code></pre>` in HTML. This
    extractor suppresses all text inside any `<pre>` element so that code
    block content is not included in the output. Inline code (`<code>`
    elements *not* wrapped in `<pre>`) is still captured because inline code
    snippets are readable words.
    """

    def __init__(self) -> None:
        """Initialise the extractor."""
        super().__init__()
        self._pre_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        """Track entry into `<pre>` elements.

        Args:
            tag: The HTML tag name (lower-cased).
            attrs: List of ``(name, value)`` attribute pairs for the tag.
        """
        if tag == "pre":
            self._pre_depth += 1

    def handle_endtag(self, tag: str) -> None:
        """Track exit from `<pre>` elements.

        Args:
            tag: The HTML tag name (lower-cased).
        """
        if tag == "pre" and self._pre_depth > 0:
            self._pre_depth -= 1

    def handle_data(self, data: str) -> None:
        """Accumulate a character-data node when not inside a ``<pre>`` element.

        Args:
            data: Text content from the current HTML node.
        """
        if self._pre_depth == 0:
            super().handle_data(data)


def html_to_plain_text(html: str, *, exclude_code_blocks: bool = False) -> str:
    """Convert an HTML string to clean plain text.

    Strips all HTML tags and collapses whitespace. This is the counterpart
    to `markdown_to_plain_text` for cases where the HTML is already available,
    avoiding a redundant Markdown parse.

    Args:
        html: HTML text to convert.
        exclude_code_blocks: When `True`, the content of fenced code blocks
            (rendered as ``<pre><code>…</code></pre>``) is omitted from the
            output.  Inline code snippets (``<code>`` not wrapped in
            ``<pre>``) are still included.  Defaults to `False`.

    Returns:
        Plain-text representation with whitespace collapsed to single spaces,
        or an empty string if *html* is blank.
    """
    if not html.strip():
        return ""
    extractor = TextSansCodeExtractor() if exclude_code_blocks else TextExtractor()
    extractor.feed(html)
    return extractor.text


def markdown_to_plain_text(text: str, *, exclude_code_blocks: bool = False) -> str:
    """Convert a Markdown string to clean plain text.

    Runs the input through Python-Markdown (with all BlogMore extensions and
    common block-level extensions such as `fenced_code`, `tables`, and
    `footnotes`) to produce HTML, then strips all HTML tags and collapses
    whitespace.  This correctly handles all Markdown block structures
    including fenced code blocks, blockquotes, admonitions, and tables —
    none of these leave raw Markdown syntax characters in the result.

    Args:
        text: Raw Markdown text to convert.
        exclude_code_blocks: When `True`, the content of fenced code blocks
            (rendered as ``<pre><code>…</code></pre>``) is omitted from the
            output.  Inline code snippets (``<code>`` not wrapped in
            ``<pre>``) are still included.  Defaults to `False`.

    Returns:
        Plain-text representation with whitespace collapsed to single spaces,
        or an empty string if *text* is blank.
    """
    if not text.strip():
        return ""
    md = get_plain_text_markdown_instance()
    md.reset()
    html = md.convert(text)
    return html_to_plain_text(html, exclude_code_blocks=exclude_code_blocks)


### plain_text.py ends here
