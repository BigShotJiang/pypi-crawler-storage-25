"""Command-line interface for blogmore."""

import argparse
import shutil
import sys
from pathlib import Path
from typing import Any

from blogmore.cli import create_parser
from blogmore.config import (
    DEFAULT_CONFIG_FILES,
    get_sidebar_config,
    load_config,
    merge_config_with_args,
    normalize_site_keywords,
    parse_site_config_from_dict,
)
from blogmore.generator import SiteGenerator
from blogmore.linter import lint_site
from blogmore.publisher import PublishError, publish_site
from blogmore.server import serve_site
from blogmore.site_config import SiteConfig, site_config_defaults
from blogmore.utils import get_user_cache_dir


def main() -> int:
    """Main entry point for the blogmore CLI."""
    parser = create_parser()
    args = parser.parse_args()

    # Expand user home directory in path arguments from CLI
    if hasattr(args, "content_dir") and args.content_dir is not None:
        args.content_dir = args.content_dir.expanduser()
    if hasattr(args, "templates") and args.templates is not None:
        args.templates = args.templates.expanduser()
    if hasattr(args, "output") and args.output is not None:
        args.output = args.output.expanduser()
    if hasattr(args, "config") and args.config is not None:
        args.config = args.config.expanduser()

    # Handle cache command
    if args.command == "cache":
        cache_dir = get_user_cache_dir()
        if args.cache_command == "location":
            print(cache_dir)
            return 0
        if args.cache_command == "clear":
            if cache_dir.exists():
                try:
                    shutil.rmtree(cache_dir)
                    print(f"Cache cleared: {cache_dir}")
                except Exception as e:
                    print(f"Error clearing cache: {e}", file=sys.stderr)
                    return 1
            else:
                print(f"Cache directory does not exist: {cache_dir}")
            return 0

    # Store the original CLI argument values before merging with config
    # This will be used to determine which CLI args should override config on reload
    cli_overrides = _extract_cli_overrides(args)

    # Load configuration file if specified or search for default
    config_path = None
    try:
        config_path = _determine_config_path(args)
        config = load_config(config_path)
        merge_config_with_args(config, args)
        sidebar_config = get_sidebar_config(config)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"Error: Invalid configuration file: {e}", file=sys.stderr)
        return 1

    # Normalize site_keywords: CLI provides a string, config provides a list or string
    site_keywords = normalize_site_keywords(getattr(args, "site_keywords", None))

    # Parse all config-file-controlled SiteConfig fields from the loaded config
    # dictionary. The call produces validated, normalised field values ready for
    # SiteConfig. Fields that are also available as CLI args are filtered out
    # below since merge_config_with_args already merged those into args with the
    # correct CLI-wins precedence.
    config_kwargs, config_errors = parse_site_config_from_dict(config, args.output)
    for error in config_errors:
        print(f"Error: {error}", file=sys.stderr)
    if config_errors:
        return 1
    # Exclude any field that is also accessible via args (handled above by
    # merge_config_with_args and args.*) so that CLI args always take precedence.
    config_only_kwargs = {
        k: v for k, v in config_kwargs.items() if not hasattr(args, k)
    }

    # Build the shared site configuration object
    site_config = SiteConfig(
        content_dir=args.content_dir,
        output_dir=args.output,
        templates_dir=args.templates,
        site_title=args.site_title,
        site_subtitle=args.site_subtitle,
        site_description=args.site_description,
        site_keywords=site_keywords,
        site_url=args.site_url,
        posts_per_feed=args.posts_per_feed,
        extra_stylesheets=args.extra_stylesheets,
        default_author=args.default_author,
        sidebar_config=sidebar_config,
        clean_first=args.clean_first,
        icon_source=args.icon_source,
        with_search=args.with_search,
        with_sitemap=args.with_sitemap,
        with_stats=args.with_stats,
        with_calendar=args.with_calendar,
        with_graph=args.with_graph,
        minify_css=args.minify_css,
        minify_js=args.minify_js,
        minify_html=args.minify_html,
        with_read_time=args.with_read_time,
        include_drafts=args.include_drafts,
        socials_title=args.socials_title,
        links_title=args.links_title,
        **config_only_kwargs,
    )

    # Handle serve command
    if args.command in ("serve", "test"):
        return serve_site(
            site_config=site_config,
            port=args.port,
            watch=not args.no_watch,
            config_path=config_path,
            cli_overrides=cli_overrides,
        )

    # Handle build command (and its aliases: generate, gen)
    if args.command in ("build", "generate", "gen"):
        # Validate that content_dir is provided
        if args.content_dir is None:
            print(
                "Error: content_dir is required. Specify it on the command line or in the config file.",
                file=sys.stderr,
            )
            return 1

        # Validate inputs
        if not args.content_dir.exists():
            print(
                f"Error: Content directory not found: {args.content_dir}",
                file=sys.stderr,
            )
            return 1

        # Validate templates directory if provided
        if args.templates is not None and not args.templates.exists():
            print(
                f"Error: Templates directory not found: {args.templates}",
                file=sys.stderr,
            )
            return 1

        # Generate the site
        try:
            generator = SiteGenerator(site_config=site_config)
            generator.generate()
            return 0
        except Exception as e:
            print(f"Error generating site: {e}", file=sys.stderr)
            return 1

    # Handle publish command
    if args.command == "publish":
        # Validate that content_dir is provided
        if args.content_dir is None:
            print(
                "Error: content_dir is required. Specify it on the command line or in the config file.",
                file=sys.stderr,
            )
            return 1

        # Validate inputs
        if not args.content_dir.exists():
            print(
                f"Error: Content directory not found: {args.content_dir}",
                file=sys.stderr,
            )
            return 1

        # Validate templates directory if provided
        if args.templates is not None and not args.templates.exists():
            print(
                f"Error: Templates directory not found: {args.templates}",
                file=sys.stderr,
            )
            return 1

        # Generate the site first
        try:
            print("Building site before publishing...")
            generator = SiteGenerator(site_config=site_config)
            generator.generate()
            print("Site built successfully")
        except Exception as e:
            print(f"Error generating site: {e}", file=sys.stderr)
            return 1

        # Publish the site
        try:
            publish_site(
                output_dir=args.output,
                branch=args.branch,
                remote=args.remote,
            )
            return 0
        except PublishError as e:
            print(f"Error publishing site: {e}", file=sys.stderr)
            return 1

    # Handle lint command
    if args.command in ("lint", "check"):
        # Validate that content_dir is provided
        if args.content_dir is None:
            print(
                "Error: content_dir is required. Specify it on the command line or in the config file.",
                file=sys.stderr,
            )
            return 1

        # Validate inputs
        if not args.content_dir.exists():
            print(
                f"Error: Content directory not found: {args.content_dir}",
                file=sys.stderr,
            )
            return 1

        # Run the linter
        try:
            return lint_site(site_config=site_config)
        except Exception as e:
            print(f"Error linting site: {e}", file=sys.stderr)
            return 1

    return 0


def _determine_config_path(args: argparse.Namespace) -> Path | None:
    """Determine which config file is being used.

    Args:
        args: Parsed command-line arguments

    Returns:
        Path to the config file being used, or None if no config file
    """
    # If a specific config file is provided, use it
    if hasattr(args, "config") and args.config is not None:
        return Path(args.config)

    # Otherwise, search for default config files
    for config_file in DEFAULT_CONFIG_FILES:
        config_file_path = Path(config_file)
        if config_file_path.exists():
            return config_file_path

    return None


def _extract_cli_overrides(args: argparse.Namespace) -> dict[str, Any]:
    """Extract CLI arguments that were explicitly set (not defaults).

    Args:
        args: Parsed command-line arguments

    Returns:
        Dictionary of argument names to values that were explicitly set
    """
    # Use SiteConfig as the single source of truth for site-config field defaults.
    defaults: dict[str, Any] = site_config_defaults()
    # SiteConfig uses templates_dir but the CLI arg is named templates.
    defaults["templates"] = defaults.pop("templates_dir")
    # SiteConfig.output_dir is a required field with no default; the CLI arg
    # output defaults to Path("output").
    defaults["output"] = Path("output")
    # CLI-only defaults that have no SiteConfig equivalent.
    defaults.update(
        {
            "port": 8000,
            "no_watch": False,
            "branch": "gh-pages",
            "remote": "origin",
        }
    )

    overrides: dict[str, Any] = {}

    # Check each argument to see if it differs from the default
    for arg_name, default_value in defaults.items():
        if not hasattr(args, arg_name):
            continue

        arg_value = getattr(args, arg_name)

        # If the value differs from default, it was explicitly set
        if arg_value != default_value:
            overrides[arg_name] = arg_value

    return overrides


if __name__ == "__main__":
    sys.exit(main())
