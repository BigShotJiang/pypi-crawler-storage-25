from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient

from bonsai_server.router import create_router


class _FakeStore:
    def list_memory_events(self, event_types=None, limit=200):
        events = [
            {
                "id": "evt-1",
                "type": "memory.auto_update_applied",
                "timestamp": "2026-01-01T00:00:00+00:00",
                "payload": {"new_memory_id": "mem-2"},
            },
            {
                "id": "evt-2",
                "type": "memory.conflict_created",
                "timestamp": "2026-01-01T00:01:00+00:00",
                "payload": {"conflict_id": "conf-1"},
            },
        ]
        selected = set(event_types or [])
        if selected:
            events = [e for e in events if e["type"] in selected]
        return events[:limit]


def test_memory_events_endpoint_filters_by_type():
    app = FastAPI()
    app.include_router(create_router(memory_store=_FakeStore()))
    client = TestClient(app)

    res = client.get("/bonsai/memory-events", params=[("event_type", "memory.conflict_created"), ("limit", "10")])
    assert res.status_code == 200
    body = res.json()
    assert "events" in body
    assert len(body["events"]) == 1
    assert body["events"][0]["type"] == "memory.conflict_created"
