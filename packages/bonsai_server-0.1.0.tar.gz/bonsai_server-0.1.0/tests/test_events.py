"""Tests for bonsai_server SSE EventBus.

All tests are pure-logic and require no external services.
"""

import asyncio
import time

import pytest

from bonsai_server.events import EventBus, MemoryEvent


class TestMemoryEvent:
    """Tests for the MemoryEvent Pydantic model."""

    def test_creation_with_all_fields(self):
        """MemoryEvent can be created with all fields specified."""
        now = time.time()
        event = MemoryEvent(
            type="memory.added",
            memory_id="mem-001",
            data={"text": "Hello world"},
            timestamp=now,
        )
        assert event.type == "memory.added"
        assert event.memory_id == "mem-001"
        assert event.data == {"text": "Hello world"}
        assert event.timestamp == now

    def test_event_types_accepted(self):
        """Standard event type strings are accepted without error."""
        now = time.time()
        for event_type in ("memory.added", "memory.updated", "memory.deleted"):
            event = MemoryEvent(
                type=event_type,
                memory_id="mem-002",
                timestamp=now,
            )
            assert event.type == event_type
            assert event.data is None

    def test_serialization_roundtrip(self):
        """MemoryEvent serializes to dict and deserializes back without data loss."""
        now = time.time()
        event = MemoryEvent(
            type="memory.updated",
            memory_id="mem-003",
            data={"importance": 0.9},
            timestamp=now,
        )
        d = event.model_dump()
        restored = MemoryEvent.model_validate(d)
        assert restored.type == event.type
        assert restored.memory_id == event.memory_id
        assert restored.data == event.data
        assert restored.timestamp == event.timestamp


class TestEventBus:
    """Tests for the EventBus pub/sub system."""

    def test_subscribe_returns_queue_and_tracks_it(self):
        """subscribe() returns an asyncio.Queue and adds it to _subscribers."""
        bus = EventBus()
        assert len(bus._subscribers) == 0

        queue = bus.subscribe()
        assert isinstance(queue, asyncio.Queue)
        assert len(bus._subscribers) == 1
        assert bus._subscribers[0] is queue

    def test_unsubscribe_removes_queue_and_double_unsubscribe_is_safe(self):
        """unsubscribe() removes the queue; calling it twice does not raise."""
        bus = EventBus()
        queue = bus.subscribe()
        assert len(bus._subscribers) == 1

        bus.unsubscribe(queue)
        assert len(bus._subscribers) == 0

        # Double unsubscribe should not crash.
        bus.unsubscribe(queue)
        assert len(bus._subscribers) == 0

    def test_publish_delivers_event_to_subscriber(self):
        """publish() places an event into the subscriber queue."""

        async def _test():
            bus = EventBus()
            queue = bus.subscribe()
            event = MemoryEvent(
                type="memory.added",
                memory_id="abc",
                timestamp=time.time(),
            )
            await bus.publish(event)

            received = queue.get_nowait()
            assert received.memory_id == "abc"
            assert received.type == "memory.added"

        asyncio.run(_test())

    def test_publish_delivers_to_multiple_subscribers(self):
        """publish() delivers the same event to all active subscribers."""

        async def _test():
            bus = EventBus()
            q1 = bus.subscribe()
            q2 = bus.subscribe()
            q3 = bus.subscribe()

            event = MemoryEvent(
                type="memory.deleted",
                memory_id="xyz",
                timestamp=time.time(),
            )
            await bus.publish(event)

            for q in (q1, q2, q3):
                received = q.get_nowait()
                assert received.memory_id == "xyz"
                assert received.type == "memory.deleted"

        asyncio.run(_test())

    def test_publish_drops_silently_when_queue_full(self):
        """publish() silently drops events for subscribers whose queue is full."""

        async def _test():
            bus = EventBus()
            # Create a queue with maxsize=1 and manually register it.
            small_queue: asyncio.Queue[MemoryEvent] = asyncio.Queue(maxsize=1)
            bus._subscribers.append(small_queue)

            event1 = MemoryEvent(
                type="memory.added",
                memory_id="first",
                timestamp=time.time(),
            )
            event2 = MemoryEvent(
                type="memory.added",
                memory_id="second",
                timestamp=time.time(),
            )

            # First publish fills the queue.
            await bus.publish(event1)
            assert small_queue.qsize() == 1

            # Second publish should be silently dropped (no exception).
            await bus.publish(event2)
            assert small_queue.qsize() == 1

            # The queued event should be the first one.
            received = small_queue.get_nowait()
            assert received.memory_id == "first"

        asyncio.run(_test())
