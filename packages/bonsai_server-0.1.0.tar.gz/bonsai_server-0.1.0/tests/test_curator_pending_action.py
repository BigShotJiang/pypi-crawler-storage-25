"""Tests for the Curator Agent HITL (human-in-the-loop) approval flow.

Uses pydantic-ai's native DeferredToolRequests / DeferredToolResults
mechanism — no regex hacks.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic_ai.messages import ToolCallPart
from pydantic_ai.tools import DeferredToolRequests

from bonsai_server.router import create_router


# ── Fakes ────────────────────────────────────────────────────────────────


class _FakeAgentResult:
    """Minimal stand-in for pydantic-ai AgentRunResult."""

    def __init__(self, output: Any, messages: list | None = None):
        self.output = output
        self._messages = messages or []

    def all_messages(self) -> list:
        return self._messages


@dataclass
class _FakeStore:
    deleted: list[tuple[str, dict]] = field(default_factory=list)
    added: list[tuple[str, str, dict | None, dict]] = field(default_factory=list)

    def delete(self, memory_id: str, **kwargs: Any) -> dict:
        self.deleted.append((memory_id, kwargs))
        return {"id": memory_id, "deleted": True}

    def add(
        self, content: str, user_id: str = "default", metadata: Any = None, **kwargs: Any
    ) -> dict:
        self.added.append((content, user_id, metadata, kwargs))
        return {"id": "merged-id"}


# ── Tests ────────────────────────────────────────────────────────────────


def test_deferred_tool_returns_pending_approval(monkeypatch):
    """When the agent returns DeferredToolRequests, the API returns pending_approvals."""
    monkeypatch.setenv("BONSAI_CURATOR_API_KEY", "test-key")

    deferred = DeferredToolRequests(
        approvals=[
            ToolCallPart(
                tool_name="merge_memories",
                args={"memory_ids": ["m-1", "m-2"], "merged_text": "merged"},
                tool_call_id="tc-1",
            ),
        ],
    )

    class _DeferredAgent:
        async def run(self, user_prompt, deps=None, message_history=None, **kwargs):
            return _FakeAgentResult(deferred)

    import bonsai_core.agent as agent_module
    monkeypatch.setattr(agent_module, "create_curator_agent", lambda *a, **kw: _DeferredAgent())

    app = FastAPI()
    app.include_router(create_router(memory_store=_FakeStore()))
    client = TestClient(app)

    resp = client.post(
        "/bonsai/curator/message",
        json={"message": "merge these", "user_id": "alice"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "pending_approval"
    assert len(body["pending_approvals"]) == 1
    assert body["pending_approvals"][0]["tool_call_id"] == "tc-1"
    assert body["pending_approvals"][0]["tool_name"] == "merge_memories"
    assert body["pending_approvals"][0]["args"]["memory_ids"] == ["m-1", "m-2"]


def test_approval_resumes_agent_and_executes_tool(monkeypatch):
    """POST /curator/approve resumes the agent run with DeferredToolResults."""
    monkeypatch.setenv("BONSAI_CURATOR_API_KEY", "test-key")

    deferred = DeferredToolRequests(
        approvals=[
            ToolCallPart(
                tool_name="merge_memories",
                args={"memory_ids": ["m-1", "m-2"], "merged_text": "merged"},
                tool_call_id="tc-1",
            ),
        ],
    )

    call_log: list[dict] = []

    class _DeferredThenResumeAgent:
        async def run(self, user_prompt, deps=None, message_history=None, deferred_tool_results=None, **kwargs):
            call_log.append({
                "user_prompt": user_prompt,
                "has_history": message_history is not None,
                "has_deferred": deferred_tool_results is not None,
            })
            if deferred_tool_results is not None:
                # Simulate: tool executed, agent responds
                return _FakeAgentResult("Merged 2 memories into new memory merged-id.")
            return _FakeAgentResult(deferred, messages=["fake-msg"])

    import bonsai_core.agent as agent_module
    monkeypatch.setattr(
        agent_module, "create_curator_agent",
        lambda *a, **kw: _DeferredThenResumeAgent(),
    )

    app = FastAPI()
    store = _FakeStore()
    app.include_router(create_router(memory_store=store))
    client = TestClient(app)

    # Step 1: Agent proposes merge → returns DeferredToolRequests
    first = client.post(
        "/bonsai/curator/message",
        json={"message": "merge m-1 and m-2", "user_id": "alice"},
    )
    assert first.status_code == 200
    session_id = first.json()["session_id"]
    assert first.json()["status"] == "pending_approval"

    # Step 2: User approves → agent resumes
    approval = client.post(
        "/bonsai/curator/approve",
        json={
            "session_id": session_id,
            "tool_call_id": "tc-1",
            "approved": True,
        },
    )
    assert approval.status_code == 200
    assert "Merged 2 memories" in approval.json()["response"]

    # Verify the agent was called twice: once for the initial message, once for approval resume
    assert len(call_log) == 2
    assert call_log[0]["has_deferred"] is False
    assert call_log[1]["has_deferred"] is True
    assert call_log[1]["has_history"] is True


def test_denial_resumes_agent_with_tool_denied(monkeypatch):
    """POST /curator/approve with approved=false sends ToolDenied to the agent."""
    monkeypatch.setenv("BONSAI_CURATOR_API_KEY", "test-key")

    deferred = DeferredToolRequests(
        approvals=[
            ToolCallPart(
                tool_name="delete_memories",
                args={"memory_ids": ["m-1"], "reason": "stale"},
                tool_call_id="tc-del",
            ),
        ],
    )

    captured_deferred_results: list[Any] = []

    class _DeferredAgent:
        async def run(self, user_prompt, deps=None, message_history=None, deferred_tool_results=None, **kwargs):
            if deferred_tool_results is not None:
                captured_deferred_results.append(deferred_tool_results)
                return _FakeAgentResult("Okay, I won't delete those memories.")
            return _FakeAgentResult(deferred, messages=["fake-msg"])

    import bonsai_core.agent as agent_module
    monkeypatch.setattr(agent_module, "create_curator_agent", lambda *a, **kw: _DeferredAgent())

    app = FastAPI()
    app.include_router(create_router(memory_store=_FakeStore()))
    client = TestClient(app)

    first = client.post(
        "/bonsai/curator/message",
        json={"message": "delete stale memories", "user_id": "alice"},
    )
    session_id = first.json()["session_id"]

    denial = client.post(
        "/bonsai/curator/approve",
        json={
            "session_id": session_id,
            "tool_call_id": "tc-del",
            "approved": False,
            "denial_reason": "I want to keep them",
        },
    )
    assert denial.status_code == 200
    assert "won't delete" in denial.json()["response"]

    # Verify ToolDenied was sent
    assert len(captured_deferred_results) == 1
    from pydantic_ai.tools import ToolDenied
    dr = captured_deferred_results[0]
    assert "tc-del" in dr.approvals
    result = dr.approvals["tc-del"]
    assert isinstance(result, ToolDenied)
    assert "keep them" in result.message


def test_multi_turn_conversation_preserves_context(monkeypatch):
    """The agent receives message_history on subsequent turns."""
    monkeypatch.setenv("BONSAI_CURATOR_API_KEY", "test-key")

    call_log: list[dict] = []

    class _ContextTrackingAgent:
        async def run(self, user_prompt, deps=None, message_history=None, **kwargs):
            call_log.append({
                "user_prompt": user_prompt,
                "history_len": len(message_history) if message_history else 0,
            })
            return _FakeAgentResult(
                f"Response to: {user_prompt}",
                messages=["msg-1", "msg-2"],  # simulate growing history
            )

    import bonsai_core.agent as agent_module
    monkeypatch.setattr(
        agent_module, "create_curator_agent",
        lambda *a, **kw: _ContextTrackingAgent(),
    )

    app = FastAPI()
    app.include_router(create_router(memory_store=_FakeStore()))
    client = TestClient(app)

    first = client.post(
        "/bonsai/curator/message",
        json={"message": "show me Jon Smith memories", "user_id": "alice"},
    )
    session_id = first.json()["session_id"]

    second = client.post(
        "/bonsai/curator/message",
        json={"message": "which can I merge?", "user_id": "alice", "session_id": session_id},
    )
    assert second.status_code == 200

    # First call: no history. Second call: has history from first result.
    assert call_log[0]["history_len"] == 0
    assert call_log[1]["history_len"] == 2  # from the first result's all_messages()


def test_approve_without_pending_returns_400(monkeypatch):
    """Approving a non-existent session or tool_call_id returns 400."""
    monkeypatch.setenv("BONSAI_CURATOR_API_KEY", "test-key")

    class _TextAgent:
        async def run(self, user_prompt, deps=None, message_history=None, **kwargs):
            return _FakeAgentResult("Just a text reply.", messages=["msg"])

    import bonsai_core.agent as agent_module
    monkeypatch.setattr(agent_module, "create_curator_agent", lambda *a, **kw: _TextAgent())

    app = FastAPI()
    app.include_router(create_router(memory_store=_FakeStore()))
    client = TestClient(app)

    # Create a session with no pending approvals
    first = client.post(
        "/bonsai/curator/message",
        json={"message": "hello", "user_id": "alice"},
    )
    session_id = first.json()["session_id"]

    resp = client.post(
        "/bonsai/curator/approve",
        json={"session_id": session_id, "tool_call_id": "nonexistent", "approved": True},
    )
    assert resp.status_code == 400
