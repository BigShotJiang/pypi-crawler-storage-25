import { resolve } from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@bonsai/react': resolve(__dirname, '../../bonsai-react/src'),
    },
  },
  build: {
    // Output goes to ../src/bonsai_server/static/ via --outDir flag in package.json
    sourcemap: false,
  },
});
