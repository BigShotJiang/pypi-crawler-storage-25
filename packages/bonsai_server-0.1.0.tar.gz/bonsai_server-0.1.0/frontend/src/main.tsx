import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BonsAIView } from '@bonsai/react';
import '@bonsai/react/styles.css';
import './styles.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <div style={{ width: '100vw', height: '100vh' }}>
      <BonsAIView apiEndpoint="/bonsai" userId="default" />
    </div>
  </StrictMode>,
);
