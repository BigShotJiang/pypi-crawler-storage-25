"""BonsAI CLI.

Usage::

    bonsai serve              # Start the server with UI
    bonsai serve --port 9000  # Custom port
    bonsai inspect "Google"   # Search memories from the terminal
    bonsai stats              # Show memory store statistics
"""

from __future__ import annotations

from pathlib import Path

import typer

app = typer.Typer(
    name="bonsai",
    help="BonsAI — memory oversight system for AI agents.",
    no_args_is_help=True,
)


@app.command()
def serve(
    port: int = typer.Option(8000, help="Port to listen on."),
    host: str = typer.Option("127.0.0.1", help="Host to bind to."),
    reload: bool = typer.Option(False, help="Enable auto-reload for development."),
) -> None:
    """Start the BonsAI server with the visualization UI."""
    import uvicorn

    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        typer.echo(f"Starting BonsAI on http://{host}:{port}")
    else:
        typer.echo(f"Starting BonsAI API on http://{host}:{port} (no bundled UI)")
        typer.echo("  Tip: build the frontend first with `pnpm --filter bonsai-server-frontend build`")

    uvicorn.run(
        "bonsai_server.app:create_app",
        factory=True,
        host=host,
        port=port,
        reload=reload,
    )


@app.command()
def inspect(
    query: str = typer.Argument(help="Search query for memories."),
    user_id: str = typer.Option("default", help="User ID to search within."),
    limit: int = typer.Option(10, help="Maximum number of results."),
) -> None:
    """Search memories from the command line."""
    from bonsai_core.memory import MemoryStore

    store = MemoryStore()
    results = store.search(query, user_id=user_id, limit=limit)

    if not results:
        typer.echo("No memories matched your query.")
        raise typer.Exit()

    typer.echo(f"Found {len(results)} memories:\n")
    for i, mem in enumerate(results, 1):
        text = mem.get("text") or mem.get("memory") or ""
        importance = (mem.get("metadata") or {}).get("importance", "?")
        tags = (mem.get("metadata") or {}).get("tags", [])
        tag_str = f"  tags: {', '.join(tags)}" if tags else ""
        typer.echo(f"  {i}. [{mem.get('id', '?')[:8]}...] (importance: {importance})")
        typer.echo(f"     {text}")
        if tag_str:
            typer.echo(f"    {tag_str}")
        typer.echo()


@app.command()
def stats(
    user_id: str = typer.Option("default", help="User ID to inspect."),
) -> None:
    """Show memory store statistics."""
    from collections import Counter

    from bonsai_core.memory import MemoryStore

    store = MemoryStore()
    memories = store.get_all(user_id=user_id)

    if not memories:
        typer.echo(f"No memories found for user '{user_id}'.")
        raise typer.Exit()

    importances = []
    tag_counts: Counter[str] = Counter()
    sources: Counter[str] = Counter()

    for m in memories:
        meta = m.get("metadata") or {}
        imp = meta.get("importance")
        if isinstance(imp, (int, float)):
            importances.append(float(imp))
        for t in meta.get("tags") or []:
            if t:
                tag_counts[t] += 1
        src = meta.get("source")
        if src:
            sources[src] += 1

    typer.echo(f"Memories: {len(memories)}")
    if importances:
        typer.echo(f"Importance: avg {sum(importances)/len(importances):.2f}, "
                    f"min {min(importances):.2f}, max {max(importances):.2f}")
    if tag_counts:
        top = ", ".join(f"{t} ({c})" for t, c in tag_counts.most_common(5))
        typer.echo(f"Top tags: {top}")
    if sources:
        top = ", ".join(f"{s} ({c})" for s, c in sources.most_common(5))
        typer.echo(f"Sources: {top}")
