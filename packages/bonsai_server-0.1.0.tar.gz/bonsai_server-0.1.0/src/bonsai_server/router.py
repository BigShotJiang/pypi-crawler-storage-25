"""FastAPI router factory for BonsAI.

Usage::

    from bonsai_server import create_router

    app = FastAPI()
    app.include_router(create_router())          # defaults
    app.include_router(create_router(store))      # bring your own store
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from typing import Any

import numpy as np
from fastapi import APIRouter, HTTPException, Query, Request
from sse_starlette.sse import EventSourceResponse

from bonsai_core.clustering import Clusterer
from bonsai_core.memory import MemoryStore
from bonsai_core.projection import Projector

from bonsai_server.events import EventBus
from bonsai_server.schemas import (
    BulkDeleteRequest,
    BulkDeleteResponse,
    Visualization3DByIdsRequest,
    ConflictListResponse,
    ConflictResolveRequest,
    CuratorApprovalRequest,
    CuratorApprovalResponse,
    CuratorMessageRequest,
    CuratorResponse,
    MemoryCreate,
    MemoryEventListResponse,
    MemoryUpdate,
    NLQueryRequest,
    NLQueryResponse,
    SearchQuery,
    SuggestMergeResponse,
    Visualization3DData,
    VisualizationData,
)

logger = logging.getLogger("bonsai_server")

# Minimum number of samples UMAP needs to produce a meaningful projection.
_MIN_SAMPLES_FOR_UMAP = 5


def _load_env_file() -> None:
    """Best-effort dotenv loading for direct router usage."""
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv(override=False)



def _normalize_memory(raw: dict[str, Any]) -> dict[str, Any]:
    """Map a Mem0 or ChromaDB memory dict to the frontend Memory shape.

    Frontend expects::

        { id, text, metadata: { created_at, updated_at, source, tags,
                                 importance, is_deleted, deleted_at } }

    Mem0 returns::

        { id, memory, hash, metadata, created_at, updated_at, user_id }

    ChromaDB (via get_all_with_embeddings) returns::

        { id, text, metadata: { data, hash, created_at, updated_at, user_id } }
    """
    raw_meta = raw.get("metadata") or {}

    # Text: try 'text', then 'memory' (Mem0), then metadata.data (ChromaDB)
    text = (
        raw.get("text")
        or raw.get("memory")
        or (raw_meta.get("data") if isinstance(raw_meta, dict) else "")
        or ""
    )

    # Timestamps: try top-level first (Mem0), then nested (ChromaDB)
    created_at = raw.get("created_at") or raw_meta.get("created_at", "")
    updated_at = raw.get("updated_at") or raw_meta.get("updated_at", "")

    return {
        "id": raw.get("id", ""),
        "text": text,
        "metadata": {
            "created_at": created_at,
            "updated_at": updated_at,
            "source": raw_meta.get("source") if isinstance(raw_meta, dict) else None,
            "tags": raw_meta.get("tags", []) if isinstance(raw_meta, dict) else [],
            "importance": raw_meta.get("importance", 0.5) if isinstance(raw_meta, dict) else 0.5,
            "is_deleted": raw_meta.get("is_deleted", False) if isinstance(raw_meta, dict) else False,
            "deleted_at": raw_meta.get("deleted_at") if isinstance(raw_meta, dict) else None,
            "source_episode_id": raw_meta.get("source_episode_id", "") if isinstance(raw_meta, dict) else "",
            "source_text": raw_meta.get("source_text", "") if isinstance(raw_meta, dict) else "",
            "source_context": raw_meta.get("source_context", "") if isinstance(raw_meta, dict) else "",
            "source_char_start": raw_meta.get("source_char_start", 0) if isinstance(raw_meta, dict) else 0,
            "source_char_end": raw_meta.get("source_char_end", 0) if isinstance(raw_meta, dict) else 0,
            "valid_from": raw_meta.get("valid_from") if isinstance(raw_meta, dict) else None,
            "valid_until": raw_meta.get("valid_until") if isinstance(raw_meta, dict) else None,
            "user_id": raw_meta.get("user_id", "default") if isinstance(raw_meta, dict) else "default",
            "version": raw_meta.get("version", 1) if isinstance(raw_meta, dict) else 1,
            "supersedes_id": raw_meta.get("supersedes_id") if isinstance(raw_meta, dict) else None,
            "triggered_by_id": raw_meta.get("triggered_by_id") if isinstance(raw_meta, dict) else None,
            "triggered_update_of_ids": raw_meta.get("triggered_update_of_ids", []) if isinstance(raw_meta, dict) else [],
        },
    }


def create_router(
    memory_store: MemoryStore | None = None,
    prefix: str = "/bonsai",
    tags: list[str] | None = None,
) -> APIRouter:
    """Create and return a fully-wired BonsAI :class:`APIRouter`.

    All endpoint handlers close over the *store*, *projector*, *clusterer*,
    *event_bus*, *query_engine*, and *curator_agent* instances so the caller
    never needs to manage them.

    Parameters
    ----------
    memory_store:
        A pre-configured :class:`MemoryStore`.  If ``None`` a default
        in-process store is created automatically.
    prefix:
        URL prefix for every route (default ``"/bonsai"``).
    tags:
        OpenAPI tags applied to all routes.
    """
    _load_env_file()

    router = APIRouter(prefix=prefix, tags=tags or ["BonsAI"])
    store: MemoryStore = memory_store or MemoryStore()
    projector = Projector()
    clusterer = Clusterer()
    event_bus = EventBus()
    # Cache for cluster labels and results between requests
    _cached_clusters: list[dict] | None = None

    # ── Cluster labeling ─────────────────────────────────────────────────
    _label_fn = None
    if os.environ.get("OPENAI_API_KEY"):
        try:
            from bonsai_core.labeling import generate_cluster_label

            _label_fn = generate_cluster_label
            logger.info("Cluster labeling enabled (OpenAI)")
        except Exception:
            logger.exception("Failed to import cluster labeling")

    if _label_fn is None:
        try:
            from bonsai_core.labeling import fallback_cluster_label

            _label_fn = fallback_cluster_label
            logger.info("Cluster labeling enabled (fallback keyword extraction)")
        except Exception:
            logger.exception("Failed to import fallback cluster labeling")

    # ── NL Query Engine (fully local, no API key needed) ────────────
    query_engine = None
    try:
        from bonsai_core.query import QueryEngine

        query_engine = QueryEngine(store)
        logger.info("NL Query Engine initialised (cross-encoder re-ranking)")
    except Exception:
        logger.exception("Failed to initialise NL Query Engine")

    # ── Optional: Curator Agent (env-configurable provider/model) ──────
    curator_agent = None
    curator_api_key = (
        os.environ.get("BONSAI_CURATOR_API_KEY")
        or os.environ.get("OPENROUTER_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
    )
    curator_base_url = os.environ.get("BONSAI_CURATOR_BASE_URL")
    curator_model = os.environ.get("BONSAI_CURATOR_MODEL")

    if curator_api_key:
        try:
            from bonsai_core.agent import (
                DEFAULT_CURATOR_MODEL,
                DEFAULT_OPENROUTER_BASE_URL,
                create_curator_agent,
            )

            if not curator_base_url and os.environ.get("OPENROUTER_API_KEY"):
                curator_base_url = DEFAULT_OPENROUTER_BASE_URL
            if curator_model is None:
                curator_model = (
                    "openai/gpt-4o-mini"
                    if os.environ.get("OPENROUTER_API_KEY")
                    else DEFAULT_CURATOR_MODEL
                )

            curator_agent = create_curator_agent(
                model=curator_model,
                base_url=curator_base_url,
                api_key=curator_api_key,
            )
            provider_name = (
                "OpenRouter" if curator_base_url == DEFAULT_OPENROUTER_BASE_URL else "OpenAI-compatible"
            )
            logger.info(
                "Curator Agent initialised (provider: %s, model: %s)",
                provider_name,
                curator_model,
            )
        except Exception:
            logger.exception("Failed to initialise Curator Agent")

    # In-memory curator session storage (session_id -> session state)
    curator_sessions: dict[str, dict[str, Any]] = {}

    # ── CRUD ──────────────────────────────────────────────────────────────

    @router.get("/memories")
    async def list_memories(user_id: str = Query("default")) -> list[dict]:
        """Return every memory for *user_id*."""
        return [_normalize_memory(m) for m in store.get_all(user_id=user_id)]

    @router.get("/memories/{memory_id}")
    async def get_memory(memory_id: str) -> dict:
        """Return a single memory by its ID."""
        try:
            return _normalize_memory(store.get(memory_id))
        except Exception as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @router.post("/memories", status_code=201)
    async def create_memory(body: MemoryCreate) -> dict:
        """Add a new memory using fact extraction + conflict checks."""
        result = store.add(
            content=body.content,
            user_id=body.user_id,
            metadata=body.metadata,
        )
        # Emit SSE event
        if isinstance(result, dict):
            added = result.get("added", [])
            for m in added:
                memory_id = m.get("id", "")
                if memory_id:
                    event_bus.emit("memory.added", memory_id, {"content": m.get("text", "")})
            pending = result.get("pending_conflicts", [])
            for conflict in pending:
                event_bus.emit("conflict.created", conflict.get("id", ""), conflict)
        return result

    @router.put("/memories/{memory_id}")
    async def update_memory(memory_id: str, body: MemoryUpdate) -> dict:
        """Update the text content of an existing memory."""
        try:
            old = store.get(memory_id)
            old_text = old.get("text", "")
            result = store.update(memory_id, body.content)
            version = (result.get("metadata") or {}).get("version", 1)
            event_bus.emit("memory.updated", memory_id, {
                "content": body.content,
                "before_text": old_text,
                "version": version,
            })
            return result
        except Exception as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @router.delete("/memories/{memory_id}")
    async def delete_memory(memory_id: str) -> dict:
        """Soft-delete a single memory."""
        try:
            result = store.delete(memory_id)
            event_bus.emit("memory.deleted", memory_id)
            return result
        except Exception as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    # ── Search ────────────────────────────────────────────────────────────

    @router.post("/memories/search")
    async def search_memories(body: SearchQuery) -> list[dict]:
        """Semantic similarity search over memories."""
        results = store.search(
            query=body.query,
            user_id=body.user_id,
            limit=body.limit,
        )
        return [_normalize_memory(m) for m in results]

    # ── Bulk operations ───────────────────────────────────────────────────

    @router.post("/memories/bulk-delete")
    async def bulk_delete(body: BulkDeleteRequest) -> BulkDeleteResponse:
        """Delete multiple memories in one request."""
        deleted: list[str] = []
        errors: list[dict[str, Any]] = []

        for mid in body.memory_ids:
            try:
                store.delete(mid)
                deleted.append(mid)
                event_bus.emit("memory.deleted", mid)
            except Exception as exc:
                errors.append({"memory_id": mid, "error": str(exc)})

        return BulkDeleteResponse(deleted=deleted, errors=errors)

    # ── Conflict HITL workflow ─────────────────────────────────────────────

    @router.get("/conflicts")
    async def list_conflicts(status: str = Query("pending")) -> ConflictListResponse:
        """List pending/resolved conflicts and severity map for visualization."""
        conflicts = store.list_pending_conflicts(status=status)
        return ConflictListResponse(
            conflicts=conflicts,
            severity_by_memory_id=store.get_conflict_severity_by_memory_id(),
        )

    @router.post("/conflicts/{conflict_id}/resolve")
    async def resolve_conflict(conflict_id: str, body: ConflictResolveRequest) -> dict:
        """Resolve a pending conflict with a human decision."""
        try:
            resolved = store.resolve_conflict(
                conflict_id=conflict_id,
                resolution=body.resolution,
                merged_text=body.merged_text,
            )
            event_bus.emit("conflict.resolved", conflict_id, resolved)
            return resolved
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @router.post("/conflicts/{conflict_id}/suggest-merge")
    async def suggest_merge(conflict_id: str) -> SuggestMergeResponse:
        """Generate an LLM-suggested merge for a pending conflict."""
        try:
            suggested = store.suggest_merge_text(conflict_id)
            return SuggestMergeResponse(suggested_text=suggested)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception("Suggest merge failed for conflict %s", conflict_id)
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @router.get("/memory-events")
    async def memory_events(
        event_type: list[str] = Query(default=[]),
        limit: int = Query(default=200, ge=1, le=1000),
    ) -> MemoryEventListResponse:
        """List memory/conflict decision events for timeline inspection."""
        return MemoryEventListResponse(
            events=store.list_memory_events(event_types=event_type or None, limit=limit),
        )

    @router.get("/memories/{memory_id}/history")
    async def memory_history(memory_id: str) -> dict:
        """Return all events for a memory, including its lineage predecessors."""
        events = store.list_memory_events(memory_id=memory_id)
        return {"memory_id": memory_id, "events": events}

    @router.post("/memories/{memory_id}/revert")
    async def revert_memory(memory_id: str, body: dict) -> dict:
        """Revert a memory to a previous version."""
        target_version = body.get("target_version")
        if target_version is None:
            raise HTTPException(status_code=400, detail="target_version is required")
        try:
            result = store.revert_memory(memory_id, int(target_version))
            event_bus.emit("memory.reverted", memory_id, {
                "target_version": target_version,
            })
            return result
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # ── Visualization ─────────────────────────────────────────────────────

    @router.get("/visualization/data")
    async def visualization_data() -> VisualizationData:
        """Compute and return 2-D projection + cluster data.

        Steps
        -----
        1. Fetch all memories with their raw embedding vectors.
        2. If enough data is available, run UMAP to produce 2-D coordinates.
        3. Run HDBSCAN on the 2-D coordinates to assign cluster labels.
        4. Collect per-cluster metadata via ``Clusterer.get_cluster_info``.

        Edge cases handled:
        * Empty store  -> returns empty lists.
        * Fewer than ``_MIN_SAMPLES_FOR_UMAP`` memories -> 2-D coords are set
          to ``[[0.0, 0.0], ...]`` (all at origin) and no clusters.
        """

        memories, embeddings = store.get_all_with_embeddings()

        normalized = [_normalize_memory(m) for m in memories]

        # Edge case: nothing stored yet.
        if len(memories) == 0:
            return VisualizationData(
                memories=[],
                coords_2d=[],
                clusters=[],
            )

        # Edge case: too few samples for a meaningful UMAP projection.
        if embeddings.shape[0] < _MIN_SAMPLES_FOR_UMAP:
            coords_2d_list = [[0.0, 0.0]] * len(memories)
            return VisualizationData(
                memories=normalized,
                coords_2d=coords_2d_list,
                clusters=[],
            )

        nonlocal _cached_clusters

        # Happy path: project -> cluster -> return.
        total_count = embeddings.shape[0]
        current_ids = [m.get("id", "") for m in memories]
        need_full_fit = projector.needs_refit_2d(total_count)

        # Fast path: nothing changed — return fully cached result
        if (
            not need_full_fit
            and projector.cached_ids_2d == current_ids
            and projector.cached_coords_2d is not None
            and _cached_clusters is not None
        ):
            coords_2d_list = projector.cached_coords_2d.tolist()
            return VisualizationData(
                memories=normalized,
                coords_2d=coords_2d_list,
                clusters=_cached_clusters,
            )

        try:
            if need_full_fit:
                # Full fit: run UMAP on all embeddings
                coords_2d = projector.fit_2d(embeddings)
                projector.cached_ids_2d = current_ids
            elif projector.cached_ids_2d is not None and set(current_ids) != set(projector.cached_ids_2d):
                # Memory set changed (removals and/or additions) — sync without refit
                synced = projector.sync_2d(current_ids, embeddings)
                if synced is not None:
                    coords_2d = synced
                else:
                    coords_2d = projector.fit_2d(embeddings)
                    projector.cached_ids_2d = current_ids
                    need_full_fit = True
            elif projector.cached_coords_2d is not None:
                # Incremental: transform only new points (append-only growth)
                fitted_n = len(projector.cached_ids_2d or [])
                new_embeddings = embeddings[fitted_n:]
                new_coords = projector.transform_2d(new_embeddings)
                coords_2d = np.vstack([projector.cached_coords_2d, new_coords])
                # Check trustworthiness — if degraded, do full refit
                if not projector.check_trustworthiness_2d(embeddings, coords_2d):
                    coords_2d = projector.fit_2d(embeddings)
                    projector.cached_ids_2d = current_ids
                    need_full_fit = True
                else:
                    projector.cached_coords_2d = coords_2d
                    projector.cached_ids_2d = current_ids
            else:
                # No cached coords (shouldn't happen, but safety fallback)
                coords_2d = projector.fit_2d(embeddings)
                projector.cached_ids_2d = current_ids
                need_full_fit = True
        except Exception:
            logger.exception("UMAP projection failed; falling back to zeros")
            coords_2d_list = [[0.0, 0.0]] * len(memories)
            return VisualizationData(
                memories=normalized,
                coords_2d=coords_2d_list,
                clusters=[],
            )

        try:
            if need_full_fit:
                labels = clusterer.auto_tune(coords_2d)
            elif clusterer.labels_ is not None and len(clusterer.labels_) < total_count:
                # Assign new points to nearest existing clusters
                existing_labels = clusterer.labels_
                new_labels = clusterer.assign_to_nearest_cluster(
                    coords_2d[len(existing_labels):],
                    coords_2d[:len(existing_labels)],
                    existing_labels,
                )
                labels = np.concatenate([existing_labels, new_labels])
                clusterer.labels_ = labels
            else:
                labels = clusterer.auto_tune(coords_2d)
                need_full_fit = True  # Trigger label generation
            cluster_infos = clusterer.get_cluster_info(coords_2d, labels)
            clusters = [ci.model_dump() for ci in cluster_infos]
        except Exception:
            logger.exception("Clustering failed; returning coords without clusters")
            clusters = []

        # Generate cluster labels — always when clusters lack labels
        has_labels = all(c.get("label") for c in clusters) if clusters else True
        if _label_fn and clusters and (need_full_fit or not has_labels):
            for cluster_dict in clusters:
                try:
                    indices = cluster_dict.get("member_indices", [])
                    member_embeddings = embeddings[indices] if len(indices) > 0 else None
                    texts = [
                        normalized[i]["text"]
                        for i in indices
                        if i < len(normalized)
                    ]
                    if texts:
                        import inspect
                        if "embeddings" in inspect.signature(_label_fn).parameters:
                            cluster_dict["label"] = _label_fn(
                                texts, embeddings=member_embeddings
                            )
                        else:
                            cluster_dict["label"] = _label_fn(texts)
                except Exception:
                    logger.debug("Cluster label generation failed", exc_info=True)

        # Cache the full cluster result for next request
        _cached_clusters = clusters

        coords_2d_list = coords_2d.tolist()

        return VisualizationData(
            memories=normalized,
            coords_2d=coords_2d_list,
            clusters=clusters,
        )

    # ── 3D Detail View ────────────────────────────────────────────────

    @router.get("/visualization/3d")
    async def visualization_3d_all() -> Visualization3DData:
        """Compute and return 3-D projection for all memories."""
        memories, embeddings = store.get_all_with_embeddings()

        if len(memories) == 0:
            return Visualization3DData(memories=[], coords_3d=[])

        normalized = [_normalize_memory(m) for m in memories]

        if embeddings.shape[0] < 4:
            raise HTTPException(
                status_code=422,
                detail="At least 4 memories are required for 3D projection",
            )

        try:
            coords_3d = projector.fit_3d(embeddings)
        except Exception:
            logger.exception("UMAP 3-D projection failed for all memories; falling back to random")
            rng = np.random.default_rng(42)
            coords_3d = rng.standard_normal((len(memories), 3)).astype(np.float32)

        return Visualization3DData(
            memories=normalized,
            coords_3d=coords_3d.tolist(),
        )

    @router.get("/visualization/3d/{cluster_id}")
    async def visualization_3d(cluster_id: int) -> Visualization3DData:
        """Compute and return 3-D projection for a single cluster.

        Steps
        -----
        1. Recompute the 2-D visualization (memories, embeddings, clusters).
        2. Locate the cluster matching *cluster_id*.
        3. Extract the member embeddings and run 3-D UMAP projection.
        4. Return the subset of memories with their 3-D coordinates.

        Raises
        ------
        HTTPException 404
            If the cluster with *cluster_id* is not found.
        """

        # ── Step 1: get all memories + embeddings ──────────────────────
        memories, embeddings = store.get_all_with_embeddings()

        if len(memories) == 0:
            raise HTTPException(
                status_code=404,
                detail=f"Cluster {cluster_id} not found (store is empty)",
            )

        # ── Step 2: use cached clusters from the 2-D view ─────────────
        # The 2-D endpoint uses auto_tune() which may pick different
        # HDBSCAN params than fit().  Re-running clustering here would
        # produce different cluster IDs, causing a mismatch with what
        # the frontend received.  Use the cached result instead.
        target_cluster = None

        if _cached_clusters:
            from bonsai_core.models import ClusterInfo as _CI
            for cd in _cached_clusters:
                ci = _CI(**cd) if isinstance(cd, dict) else cd
                if ci.id == cluster_id:
                    target_cluster = ci
                    break

        # Fallback: if no cache, recompute (same as before)
        if target_cluster is None and not _cached_clusters:
            if embeddings.shape[0] < _MIN_SAMPLES_FOR_UMAP:
                raise HTTPException(
                    status_code=404,
                    detail=f"Cluster {cluster_id} not found (too few memories for clustering)",
                )
            try:
                coords_2d = projector.fit_2d(embeddings)
            except Exception:
                logger.exception("UMAP 2-D projection failed during 3-D request")
                raise HTTPException(
                    status_code=500,
                    detail="Failed to compute 2-D projection",
                )
            try:
                labels = clusterer.auto_tune(coords_2d)
                cluster_infos = clusterer.get_cluster_info(coords_2d, labels)
            except Exception:
                logger.exception("Clustering failed during 3-D request")
                raise HTTPException(
                    status_code=500,
                    detail="Failed to compute clusters",
                )
            for ci in cluster_infos:
                if ci.id == cluster_id:
                    target_cluster = ci
                    break

        if target_cluster is None:
            raise HTTPException(
                status_code=404,
                detail=f"Cluster {cluster_id} not found",
            )

        member_indices = target_cluster.member_indices

        # ── Step 4: extract subset and compute 3-D projection ─────────
        subset_embeddings = embeddings[member_indices]
        subset_memories = [_normalize_memory(memories[i]) for i in member_indices]

        try:
            coords_3d = projector.fit_3d(subset_embeddings)
        except Exception:
            logger.exception("UMAP 3-D projection failed; falling back to random positions")
            rng = np.random.default_rng(42)
            n = len(member_indices)
            coords_3d = rng.standard_normal((n, 3)).astype(np.float32)

        coords_3d_list = coords_3d.tolist()

        return Visualization3DData(
            memories=subset_memories,
            coords_3d=coords_3d_list,
        )

    # ── 3D by IDs (custom selection) ─────────────────────────────────

    @router.post("/visualization/3d")
    async def visualization_3d_by_ids(body: Visualization3DByIdsRequest) -> Visualization3DData:
        """Compute and return 3-D projection for an arbitrary set of memory IDs.

        Accepts a list of memory IDs (e.g. from lasso selection) and returns
        their 3-D UMAP coordinates, following the same pattern as the
        cluster-based ``GET /visualization/3d/{cluster_id}`` endpoint.

        Raises
        ------
        HTTPException 422
            If fewer than 4 IDs are provided (UMAP minimum).
        HTTPException 404
            If none of the requested IDs are found in the store.
        """
        if len(body.memory_ids) < 4:
            raise HTTPException(
                status_code=422,
                detail="At least 4 memory IDs are required for 3D projection",
            )

        # Fetch all memories with embeddings
        all_memories, all_embeddings = store.get_all_with_embeddings()

        if len(all_memories) == 0:
            raise HTTPException(status_code=404, detail="No memories in store")

        # Build a lookup from memory id -> index
        id_to_index: dict[str, int] = {}
        for i, m in enumerate(all_memories):
            mid = m.get("id", "")
            if mid:
                id_to_index[mid] = i

        # Resolve requested IDs to indices
        indices = [id_to_index[mid] for mid in body.memory_ids if mid in id_to_index]

        if len(indices) < 4:
            raise HTTPException(
                status_code=422,
                detail=f"Only {len(indices)} of the requested IDs were found; need at least 4",
            )

        # Extract subset
        subset_indices = np.array(indices)
        subset_embeddings = all_embeddings[subset_indices]
        subset_memories = [_normalize_memory(all_memories[i]) for i in indices]

        try:
            coords_3d = projector.fit_3d(subset_embeddings)
        except Exception:
            logger.exception("UMAP 3-D projection failed for custom selection; falling back to random")
            rng = np.random.default_rng(42)
            coords_3d = rng.standard_normal((len(indices), 3)).astype(np.float32)

        return Visualization3DData(
            memories=subset_memories,
            coords_3d=coords_3d.tolist(),
        )

    # ── NL Query ──────────────────────────────────────────────────────

    @router.post("/query")
    async def nl_query(body: NLQueryRequest) -> NLQueryResponse:
        """Parse a natural-language query and return matching memories.

        Uses the NL Query Engine to parse the query into structured filters,
        execute the search, and return matching memory IDs for visualization
        highlighting.
        """
        if query_engine is None:
            raise HTTPException(
                status_code=503,
                detail="NL Query Engine unavailable (failed to initialise)",
            )

        try:
            parsed = query_engine._extract_filters(body.query)
            results = query_engine.search(body.query, user_id=body.user_id)
            normalized = [_normalize_memory(m) for m in results]
            matching_ids = [m["id"] for m in normalized if m["id"]]

            return NLQueryResponse(
                parsed=parsed.model_dump(),
                matching_ids=matching_ids,
                memories=normalized,
            )
        except Exception as exc:
            logger.exception("NL query failed")
            raise HTTPException(
                status_code=500,
                detail="Natural language query failed. Check server logs for details.",
            ) from exc

    @router.post("/query/parse")
    async def nl_query_parse(body: NLQueryRequest) -> NLQueryResponse:
        """Backward-compatible alias for the NL query endpoint.

        Matches the original implementation spec path while delegating to the
        canonical ``POST /query`` handler.
        """
        return await nl_query(body)

    # ── Curator Agent ─────────────────────────────────────────────────

    @router.post("/curator/message")
    async def curator_message(body: CuratorMessageRequest) -> CuratorResponse:
        """Send a message to the Curator Agent.

        If the agent invokes a destructive tool, the response will contain
        ``pending_approvals`` and ``status="pending_approval"`` so the
        frontend can render approval cards.
        """
        if curator_agent is None:
            raise HTTPException(
                status_code=503,
                detail="Curator Agent unavailable (no curator API key configured)",
            )

        session_id = body.session_id or str(uuid.uuid4())

        # Retrieve or create session state
        session = curator_sessions.setdefault(session_id, {
            "model_messages": None,  # pydantic-ai ModelMessage list for multi-turn
        })
        session["user_id"] = body.user_id

        try:
            from bonsai_core.agent import CuratorDeps
            from pydantic_ai.tools import DeferredToolRequests

            deps = CuratorDeps(store=store, user_id=body.user_id, event_bus=event_bus)
            model_messages = session.get("model_messages")

            result = await curator_agent.run(
                body.message,
                deps=deps,
                message_history=model_messages,
            )

            # Persist the full conversation so the agent remembers prior turns
            session["model_messages"] = result.all_messages()

            # Agent called an approval-required tool → pause for human review
            if isinstance(result.output, DeferredToolRequests):
                pending_approvals = []
                pending_ids = []
                for tool_call in result.output.approvals:
                    pending_approvals.append({
                        "tool_call_id": tool_call.tool_call_id,
                        "tool_name": tool_call.tool_name,
                        "args": tool_call.args_as_dict(),
                    })
                    pending_ids.append(tool_call.tool_call_id)
                session["pending_tool_call_ids"] = pending_ids

                return CuratorResponse(
                    response="The following actions require your approval:",
                    status="pending_approval",
                    pending_approvals=pending_approvals,
                    session_id=session_id,
                )

            # Normal text response
            return CuratorResponse(
                response=str(result.output),
                status="complete",
                session_id=session_id,
            )
        except Exception as exc:
            logger.exception("Curator agent failed")
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @router.post("/curator/run")
    async def curator_run(body: CuratorMessageRequest) -> CuratorResponse:
        """Backward-compatible alias for curator execution.

        Matches the original implementation spec path while delegating to the
        canonical ``POST /curator/message`` handler.
        """
        return await curator_message(body)

    @router.post("/curator/approve")
    async def curator_approve(body: CuratorApprovalRequest) -> CuratorApprovalResponse:
        """Approve or deny a pending destructive tool call from the Curator Agent.

        Resumes the pydantic-ai agent run with ``DeferredToolResults`` so the
        approved tool actually executes and the agent can respond naturally.
        """
        if curator_agent is None:
            raise HTTPException(
                status_code=503,
                detail="Curator Agent unavailable (no curator API key configured)",
            )

        session = curator_sessions.get(body.session_id)
        if session is None:
            raise HTTPException(
                status_code=404,
                detail=f"Session {body.session_id} not found",
            )

        model_messages = session.get("model_messages")
        pending_ids: list[str] = session.get("pending_tool_call_ids", [])
        if not model_messages or not pending_ids:
            raise HTTPException(
                status_code=400,
                detail="No pending approval for this session",
            )

        try:
            from bonsai_core.agent import CuratorDeps
            from pydantic_ai.tools import DeferredToolRequests, DeferredToolResults, ToolDenied

            deps = CuratorDeps(
                store=store,
                user_id=str(session.get("user_id", "default")),
                event_bus=event_bus,
            )

            # Build approval map: approve the requested tool, deny the rest
            approvals: dict[str, bool | ToolDenied] = {}
            for tc_id in pending_ids:
                if tc_id == body.tool_call_id:
                    if body.approved:
                        approvals[tc_id] = True
                    else:
                        approvals[tc_id] = ToolDenied(
                            message=body.denial_reason or "User denied the operation",
                        )
                else:
                    approvals[tc_id] = ToolDenied(message="Not yet reviewed")

            # Resume the agent — pydantic-ai executes the approved tool(s)
            result = await curator_agent.run(
                user_prompt=None,
                deps=deps,
                message_history=model_messages,
                deferred_tool_results=DeferredToolResults(approvals=approvals),
            )

            # Persist conversation for future turns
            session["model_messages"] = result.all_messages()
            session.pop("pending_tool_call_ids", None)

            if isinstance(result.output, DeferredToolRequests):
                response_text = "Additional approvals needed."
            else:
                response_text = str(result.output)

            return CuratorApprovalResponse(
                response=response_text,
                status="complete",
            )
        except Exception as exc:
            logger.exception("Curator approval failed")
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    # ── SSE Events ────────────────────────────────────────────────────

    @router.get("/events")
    async def sse_events(request: Request) -> EventSourceResponse:
        """Server-Sent Events stream for real-time memory updates.

        Clients connect via ``EventSource`` and receive events whenever
        memories are created, updated, or deleted.
        """
        queue = event_bus.subscribe()

        async def event_generator():
            try:
                while True:
                    # Check if client disconnected
                    if await request.is_disconnected():
                        break

                    try:
                        event = await asyncio.wait_for(queue.get(), timeout=30.0)
                        yield {
                            "event": event.type,
                            "data": json.dumps({
                                "memory_id": event.memory_id,
                                "data": event.data,
                                "timestamp": event.timestamp,
                            }),
                        }
                    except asyncio.TimeoutError:
                        # Send keepalive comment
                        yield {"comment": "keepalive"}
            finally:
                event_bus.unsubscribe(queue)

        return EventSourceResponse(event_generator())

    return router


# ── Helper for executing approved Curator tools ──────────────────────────


