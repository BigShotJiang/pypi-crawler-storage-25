"""Request and response schemas for the BonsAI Server API.

These Pydantic models define the HTTP contract between the React frontend
and the FastAPI backend. They are intentionally separate from the core
domain models in bonsai-core to allow the API surface to evolve
independently.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


# ── Request Models ────────────────────────────────────────────────────────────


class MemoryCreate(BaseModel):
    """Body for POST /memories."""

    content: str
    user_id: str = "default"
    metadata: dict | None = None


class MemoryUpdate(BaseModel):
    """Body for PUT /memories/{id}."""

    content: str


class SearchQuery(BaseModel):
    """Body for POST /memories/search."""

    query: str
    user_id: str = "default"
    limit: int = Field(default=10, ge=1, le=100)


class BulkDeleteRequest(BaseModel):
    """Body for POST /memories/bulk-delete."""

    memory_ids: list[str]


class Visualization3DByIdsRequest(BaseModel):
    """Body for POST /visualization/3d."""

    memory_ids: list[str]


class ConflictResolveRequest(BaseModel):
    """Body for POST /conflicts/{id}/resolve."""

    resolution: str  # keep_new | keep_existing | keep_both | merge
    merged_text: str | None = None


# ── Response Models ───────────────────────────────────────────────────────────


class VisualizationData(BaseModel):
    """Response for GET /visualization/data.

    Contains the full set of memories together with their projected 2-D
    coordinates and cluster assignments, ready for the frontend atlas view.
    """

    memories: list[dict]
    coords_2d: list[list[float]]
    clusters: list[dict]


class Visualization3DData(BaseModel):
    """Response for GET /visualization/3d/{cluster_id}.

    Contains the subset of memories belonging to a single cluster
    together with their 3-D UMAP coordinates for the R3F detail view.
    """

    memories: list[dict]
    coords_3d: list[list[float]]


class BulkDeleteResponse(BaseModel):
    """Response for POST /memories/bulk-delete."""

    deleted: list[str]
    errors: list[dict] = Field(default_factory=list)


class ErrorResponse(BaseModel):
    """Standard error envelope."""

    detail: str


class ConflictListResponse(BaseModel):
    """Response for GET /conflicts."""

    conflicts: list[dict]
    severity_by_memory_id: dict[str, float]


class MemoryEventListResponse(BaseModel):
    """Response for GET /memory-events."""

    events: list[dict]


# ── NL Query Models ──────────────────────────────────────────────────────────


class NLQueryRequest(BaseModel):
    """Body for POST /query."""

    query: str
    user_id: str = "default"


class NLQueryResponse(BaseModel):
    """Response for POST /query."""

    parsed: dict
    matching_ids: list[str]
    memories: list[dict]


# ── Curator Agent Models ─────────────────────────────────────────────────────


class CuratorMessageRequest(BaseModel):
    """Body for POST /curator/message."""

    message: str
    user_id: str = "default"
    session_id: str | None = None


class CuratorResponse(BaseModel):
    """Response for POST /curator/message."""

    response: str
    status: str = "complete"
    pending_approvals: list[dict] = Field(default_factory=list)
    session_id: str


class CuratorApprovalRequest(BaseModel):
    """Body for POST /curator/approve."""

    session_id: str
    tool_call_id: str
    approved: bool
    denial_reason: str | None = None


class CuratorApprovalResponse(BaseModel):
    """Response for POST /curator/approve."""

    response: str
    status: str = "complete"


class SuggestMergeResponse(BaseModel):
    """Response for POST /conflicts/{id}/suggest-merge."""

    suggested_text: str
