"""Convenience FastAPI application factory.

For quick prototyping or standalone deployment::

    uvicorn bonsai_server.app:create_app --factory --reload

Or import and customise in your own code::

    from bonsai_server import create_app
    app = create_app(memory_store=my_store)
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from bonsai_core.memory import MemoryStore

from bonsai_server.router import create_router


def _load_env_file() -> None:
    """Best-effort dotenv loading for direct bonsai-server usage.

    This keeps behaviour consistent across startup paths:
    - `demo.main` already loads dotenv explicitly
    - direct `bonsai_server.app:create_app` now also loads dotenv if available
    """
    try:
        from dotenv import load_dotenv
    except Exception:
        # python-dotenv is optional for library consumers.
        return

    load_dotenv(override=False)


def create_app(
    memory_store: MemoryStore | None = None,
    cors_origins: list[str] | None = None,
) -> FastAPI:
    """Build a ready-to-run :class:`FastAPI` application.

    Parameters
    ----------
    memory_store:
        Shared :class:`MemoryStore` instance. A default in-process store
        is created when ``None``.
    cors_origins:
        Allowed CORS origins. Defaults to ``["*"]`` for local
        development; tighten for production.
    """
    _load_env_file()

    app = FastAPI(
        title="BonsAI",
        description="Memory oversight system for AI agents",
        version="0.1.0",
    )

    # CORS — permissive by default so the React dev server can talk to us.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins or ["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Wire up all BonsAI API routes.
    app.include_router(create_router(memory_store))

    # Serve the bundled React build if it has been copied into the package.
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/", StaticFiles(directory=static_dir, html=True))

    return app
