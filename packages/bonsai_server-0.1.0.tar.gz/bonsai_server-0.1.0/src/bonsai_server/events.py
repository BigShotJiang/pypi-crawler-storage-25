"""SSE EventBus for BonsAI real-time updates.

Provides a lightweight pub/sub system so that endpoints can publish
memory-change events and the SSE endpoint can stream them to clients.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from pydantic import BaseModel


class MemoryEvent(BaseModel):
    """A single memory-change event delivered over SSE.

    Attributes:
        type: The kind of change — one of
              ``"memory.added"``, ``"memory.updated"``, or ``"memory.deleted"``.
        memory_id: The ID of the affected memory.
        data: Optional payload with extra details (e.g. the updated fields).
        timestamp: Unix epoch seconds when the event was created.
    """

    type: str
    memory_id: str
    data: dict[str, Any] | None = None
    timestamp: float


class EventBus:
    """Simple in-process pub/sub bus for :class:`MemoryEvent` instances.

    Subscribers receive an :class:`asyncio.Queue` and read events from it.
    Publishers push events into every active subscriber queue.  If a
    subscriber's queue is full the event is silently dropped for that
    subscriber so that a slow consumer never blocks the publisher.
    """

    def __init__(self) -> None:
        self._subscribers: list[asyncio.Queue[MemoryEvent]] = []

    def subscribe(self) -> asyncio.Queue[MemoryEvent]:
        """Create and return a new subscriber queue.

        The caller should read from this queue in an async loop and call
        :meth:`unsubscribe` when done.
        """
        queue: asyncio.Queue[MemoryEvent] = asyncio.Queue()
        self._subscribers.append(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue[MemoryEvent]) -> None:
        """Remove a subscriber queue so it no longer receives events."""
        try:
            self._subscribers.remove(queue)
        except ValueError:
            pass

    async def publish(self, event: MemoryEvent) -> None:
        """Put *event* into every subscriber queue (non-blocking).

        Uses :meth:`asyncio.Queue.put_nowait` so a full queue causes the
        event to be dropped for that subscriber rather than blocking the
        publisher.
        """
        for queue in self._subscribers:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                pass

    def publish_sync(self, event: MemoryEvent) -> None:
        """Schedule :meth:`publish` on the running event loop from sync code.

        If no event loop is running the call is silently ignored.
        """
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.publish(event))
        except RuntimeError:
            # No running event loop — nothing to do.
            pass

    def emit(
        self,
        event_type: str,
        memory_id: str,
        data: dict[str, Any] | None = None,
    ) -> None:
        """Convenience helper: build a :class:`MemoryEvent` and publish it.

        Creates the event with the current wall-clock time and delegates
        to :meth:`publish_sync`.

        Args:
            event_type: e.g. ``"memory.added"``, ``"memory.updated"``,
                        ``"memory.deleted"``.
            memory_id: The ID of the affected memory.
            data: Optional extra payload.
        """
        event = MemoryEvent(
            type=event_type,
            memory_id=memory_id,
            data=data,
            timestamp=time.time(),
        )
        self.publish_sync(event)
