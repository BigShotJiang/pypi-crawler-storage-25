# Yeloori
An advanced, production-capable, Sanskrit-inspired programming language.
