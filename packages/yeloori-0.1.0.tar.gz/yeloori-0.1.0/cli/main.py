import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from yeloori.core.engine import Lexer, Parser, Interpreter, LooriError

def run():
    if len(sys.argv) < 2:
        print("Yeloori Programming Language CLI v0.1.0")
        print("Usage: yeloori <filename.loori>")
        sys.exit(1)
        
    filename = sys.argv[1]
    if not os.path.exists(filename):
        print(f"Error: File '{filename}' not found.")
        sys.exit(1)
        
    with open(filename, 'r', encoding='utf-8') as f:
        source_code = f.read()
        
    try:
        lexer = Lexer(source_code, filename=filename)
        parser = Parser(lexer.tokenize(), filename=filename)
        interpreter = Interpreter()
        interpreter.execute(parser.parse())
    except LooriError as e:
        print(e)
    except Exception as e:
        print(f"Critical System Error: {e}")

if __name__ == '__main__':
    run()
