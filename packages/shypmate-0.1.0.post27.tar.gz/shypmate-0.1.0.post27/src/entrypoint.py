"""
Container entrypoint — the full lifecycle of one dev agent run.

This script runs INSIDE the agent Docker container. It:
1. Reads configuration from environment variables
2. Clones the repo
3. Creates or checks out the agent branch
4. Builds project context
5. Runs the dev agent (think → tool → repeat loop)
6. (Agent handles: edit code, validate, commit, push, create/update PR)
7. Exits
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from git import Repo
from git.exc import GitCommandError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("shypmate.entrypoint")


def main() -> int:
    # --- Read env vars ---
    github_token = os.environ.get("GITHUB_TOKEN")
    task_description = os.environ.get("AGENT_TASK", "")
    branch_name = os.environ.get("AGENT_BRANCH", "")
    agent_id = os.environ.get("AGENT_ID", "unknown")
    is_rebase = os.environ.get("AGENT_REBASE", "false").lower() == "true"
    repo_name = os.environ.get("GITHUB_REPO", "")
    base_branch = os.environ.get("BASE_BRANCH", "main")
    workspace = os.environ.get("WORKSPACE", "/workspace")
    task_id = os.environ.get("AGENT_TASK_ID", "")

    if not github_token:
        logger.error("GITHUB_TOKEN is required")
        return 1
    if not repo_name:
        logger.error("GITHUB_REPO is required")
        return 1
    if not task_description:
        logger.error("AGENT_TASK is required")
        return 1
    if not branch_name:
        logger.error("AGENT_BRANCH is required")
        return 1
    # Check for LLM API key — the key var name is passed by the host
    llm_provider = os.environ.get("LLM_PROVIDER", "anthropic")
    if llm_provider == "anthropic" and not os.environ.get("ANTHROPIC_API_KEY"):
        logger.error("ANTHROPIC_API_KEY is required for Anthropic provider")
        return 1

    logger.info("=" * 60)
    logger.info("SHYPMATE AGENT STARTUP")
    logger.info("=" * 60)
    logger.info(f"  Agent ID:    {agent_id}")
    logger.info(f"  Task:        {task_description}")
    logger.info(f"  Branch:      {branch_name}")
    logger.info(f"  Base branch: {base_branch}")
    logger.info(f"  Repo:        {repo_name}")
    logger.info(f"  Rebase:      {is_rebase}")
    logger.info(f"  LLM:         {llm_provider} / {os.environ.get('LLM_MODEL', '?')}")
    logger.info(f"  Install cmd: {os.environ.get('INSTALL_COMMAND', '(none)')}")
    logger.info(f"  Task ID:     {task_id or '(none)'}")
    logger.info(f"  Brief:       {'available' if Path('/brief/project_brief.json').exists() else 'not found (standalone mode)'}")
    logger.info("=" * 60)

    # --- Clone repo ---
    clone_url = f"https://x-access-token:{github_token}@github.com/{repo_name}.git"
    logger.info(f"Cloning {repo_name} into {workspace}...")

    try:
        repo = Repo.clone_from(clone_url, workspace)
    except GitCommandError as e:
        # If workspace already has the repo (e.g., rebase re-run), fetch instead
        if Path(workspace).joinpath(".git").exists():
            logger.info("Workspace already has repo, fetching...")
            repo = Repo(workspace)
            repo.git.fetch("--all")
        else:
            logger.error(f"Clone failed: {e}")
            return 1

    # Configure git identity — uses the developer's name with an agent suffix
    repo.config_writer().set_value("user", "name", f"shypmate-{agent_id}").release()
    repo.config_writer().set_value("user", "email", f"shypmate-{agent_id}@noreply.github.com").release()

    # --- Create or checkout branch ---
    try:
        if is_rebase:
            # For rebase: checkout existing branch
            logger.info(f"Checking out existing branch: {branch_name}")
            repo.git.checkout(branch_name)
        else:
            # For new work: create branch from base
            logger.info(f"Creating branch: {branch_name} from {base_branch}")
            repo.git.checkout(base_branch)
            repo.git.checkout("-b", branch_name)
    except GitCommandError:
        # Branch might exist remotely but not locally
        try:
            repo.git.checkout("-b", branch_name, f"origin/{branch_name}")
        except GitCommandError as e:
            logger.error(f"Branch setup failed: {e}")
            return 1

    # --- Install project dependencies ---
    # In dev mode (/opt/shypmate is mounted from host), skip install commands
    # that would override the mounted framework code (e.g. 'pip install -e .')
    install_command = os.environ.get("INSTALL_COMMAND", "")
    is_dev_mount = Path("/opt/shypmate/.dev_mounted").exists() or os.environ.get("SHYPMATE_DEV_MODE") == "1"
    if install_command and is_dev_mount and "pip install" in install_command:
        logger.info(f"Dev mode: skipping '{install_command}' to preserve mounted framework code")
    elif install_command:
        import subprocess
        logger.info(f"Installing dependencies: {install_command}")
        subprocess.run(
            install_command,
            shell=True,
            cwd=workspace,
            capture_output=True,
        )

    # --- Install test dependencies ---
    # Merges from two sources:
    #   1. shypmate.yml test_dependencies (passed via TEST_DEPENDENCIES env var)
    #   2. .shypmate/manager.yml test_dependencies (learned from retrospectives)
    # ruff is baked into the image; everything else is project-specific.
    test_deps_env = os.environ.get("TEST_DEPENDENCIES", "")
    deps_set: set[str] = set()
    if test_deps_env:
        deps_set.update(d.strip() for d in test_deps_env.split(",") if d.strip())

    # Load manager-learned dependencies (mounted at /dot-shypmate from host)
    manager_yml_standalone = Path("/dot-shypmate") / "manager.yml"
    if manager_yml_standalone.exists():
        try:
            import yaml as _yaml
            mgr_config = _yaml.safe_load(manager_yml_standalone.read_text(encoding="utf-8")) or {}
            for dep in mgr_config.get("test_dependencies", []):
                pkg = dep["package"] if isinstance(dep, dict) else dep
                deps_set.add(pkg)
        except Exception:
            pass

    if deps_set:
        import subprocess
        deps_list = sorted(deps_set)
        logger.info(f"Installing test dependencies: {', '.join(deps_list)}")
        subprocess.run(
            ["pip", "install", "--quiet"] + deps_list,
            cwd=workspace,
            capture_output=True,
        )

    # --- Build project context ---
    # Add workspace to Python path so shypmate imports work
    sys.path.insert(0, workspace)

    # Check for pre-built brief from manager (shared volume at /brief)
    brief_dir = Path("/brief")
    project_context = None

    if brief_dir.exists() and (brief_dir / "project_brief.json").exists():
        logger.info("Found project brief from manager — skipping discovery")
        try:
            from shypmate.manager.project_brief import load_brief, load_task_plan

            brief = load_brief(brief_dir)
            if brief:
                # Build CONDENSED context from the pre-digested brief.
                # Do NOT include raw_context — the whole point is the manager
                # already distilled it into what agents need.
                parts = []
                if brief.understanding:
                    parts.append(f"## Project Understanding\n{brief.understanding}")
                if brief.architecture:
                    parts.append(f"## Architecture\n{brief.architecture}")
                if brief.conventions:
                    parts.append(f"## Coding Conventions (MUST follow)\n{brief.conventions}")
                if brief.file_map:
                    file_map_str = "\n".join(f"  {k}: {v}" for k, v in brief.file_map.items())
                    parts.append(f"## Key Files and Directories\n{file_map_str}")

                # Add task-specific plan if available
                if task_id:
                    plan = load_task_plan(task_id, brief_dir)
                    if plan:
                        plan_parts = [f"## Task Plan"]
                        if plan.approach:
                            plan_parts.append(f"Approach: {plan.approach}")
                        if plan.relevant_files:
                            plan_parts.append(f"Start with these files: {', '.join(plan.relevant_files)}")
                        if plan.patterns_to_follow:
                            plan_parts.append(f"Follow these patterns: {plan.patterns_to_follow}")
                        parts.append("\n".join(plan_parts))
                        logger.info(f"  Task plan loaded: {len(plan.relevant_files)} relevant files")

                project_context = "\n\n".join(parts)
                logger.info(f"  Condensed context from brief: {len(project_context)} chars "
                            f"(raw was {len(brief.raw_context)} chars — "
                            f"{100 - len(project_context) * 100 // max(len(brief.raw_context), 1)}% reduction)")
        except Exception as e:
            logger.warning(f"Could not load brief: {e}")

    # Fall back to standalone discovery if no brief
    if project_context is None:
        logger.info("Building project context (standalone mode)...")
        from shypmate.context.project_context import build_project_context, build_rebase_context

        if is_rebase:
            project_context = build_rebase_context(
                workspace, task_description
            )
        else:
            project_context = build_project_context(workspace)

    # Log context summary so we can see what the agent is working with
    logger.info("=" * 60)
    logger.info("PROJECT CONTEXT SUMMARY")
    logger.info("=" * 60)
    logger.info(f"  Context length: {len(project_context)} chars")
    # Show section headers from the context
    for line in project_context.split("\n"):
        line = line.strip()
        if line.startswith("##") or line.startswith("# "):
            logger.info(f"  Section: {line}")
    # Show first 500 chars as a preview
    logger.info(f"  Preview: {project_context[:500]}")
    logger.info("=" * 60)

    # --- Determine execution mode ---
    pipeline_hats = os.environ.get("PIPELINE_HATS", "")
    sdlc_prompt = os.environ.get("SDLC_PROMPT", "")

    if pipeline_hats:
        # Pipeline mode — run multiple hats in sequence within this container
        return _run_pipeline(
            hat_names=pipeline_hats.split(","),
            task_description=task_description,
            branch_name=branch_name,
            project_context=project_context,
            sdlc_prompt=sdlc_prompt,
        )
    else:
        # Single agent mode (backward compatible)
        logger.info("Starting dev agent...")
        from shypmate.crews.dev_crew import run_dev_crew

        try:
            result = run_dev_crew(
                task_description=task_description,
                branch_name=branch_name,
                project_context=project_context,
                is_rebase=is_rebase,
            )
            logger.info(f"Crew finished. Result:\n{result}")
        except Exception as e:
            logger.error(f"Crew execution failed: {e}", exc_info=True)
            _comment_failure(branch_name, agent_id, str(e))
            return 1

        logger.info("Agent run complete.")
        return 0


def _run_pipeline(
    hat_names: list[str],
    task_description: str,
    branch_name: str,
    project_context: str,
    sdlc_prompt: str = "",
) -> int:
    """Run multiple hats in sequence within a single container."""
    import json as _json

    from shypmate.config.project import PROJECT
    from shypmate.hats.hat import get_default_hats, DEFAULT_SDLC
    from shypmate.hats.coordinator import load_hats_from_config, parse_hat_outcome, parse_developer_output
    from shypmate.hats.pipeline import get_hat_task_prompt
    from shypmate.hats.context import format_context_for_hat, save_stage_context, init_context
    from shypmate.engine.agent_loop import run_agent, AgentQuota
    from shypmate.engine.providers import create_provider
    from shypmate.engine.tool_registry import ToolRegistry

    agent_id = os.environ.get("AGENT_ID", "unknown")
    shypmate_dir = Path("/dot-shypmate")  # mounted from host's <project_root>/.shypmate/
    comms_dir = shypmate_dir / "comms"
    workspace = os.environ.get("WORKSPACE", "/workspace")
    manager_yml = shypmate_dir / "manager.yml"
    sdlc = sdlc_prompt or DEFAULT_SDLC
    max_retries = 2

    # Load hat configs
    all_hats = load_hats_from_config()

    # Initialize pipeline context
    init_context(comms_dir, agent_id, task_description, branch_name)

    logger.info("=" * 60)
    logger.info("PIPELINE MODE")
    logger.info(f"  Hats: {' → '.join(hat_names)}")
    logger.info(f"  SDLC: {sdlc[:200]}")
    logger.info("=" * 60)

    # Create LLM provider once — reused across hats and for retrospective
    provider_name = os.environ.get("LLM_PROVIDER", "anthropic")
    model = os.environ.get("LLM_MODEL", "claude-sonnet-4-6")
    max_tokens = int(os.environ.get("LLM_MAX_TOKENS", "8192"))
    base_url = os.environ.get("LLM_BASE_URL", "")
    api_key_var = os.environ.get("LLM_API_KEY_VAR", "ANTHROPIC_API_KEY")
    api_key = os.environ.get(api_key_var, "") if api_key_var else None

    premium_provider = create_provider(
        provider=provider_name,
        model=model,
        max_tokens=max_tokens,
        base_url=base_url or None,
        api_key=api_key or None,
    )

    # Wrap in TierRouter if economy tier is configured
    economy_provider_name = os.environ.get("ECONOMY_PROVIDER", "")
    tier_routing = os.environ.get("TIER_ROUTING", "false").lower() in ("true", "1", "yes")

    if tier_routing and economy_provider_name:
        from shypmate.engine.tier_router import TierRouter
        from shypmate.config.project import get_user_hook, LLM_PROVIDER_PRESETS

        economy_model = os.environ.get("ECONOMY_MODEL", "")
        economy_max_tokens = int(os.environ.get("ECONOMY_MAX_TOKENS", "4096"))
        economy_base_url = os.environ.get("ECONOMY_BASE_URL",
            LLM_PROVIDER_PRESETS.get(economy_provider_name, {}).get("base_url", ""))
        economy_api_key_var = os.environ.get("ECONOMY_API_KEY_VAR",
            LLM_PROVIDER_PRESETS.get(economy_provider_name, {}).get("api_key_var", ""))
        economy_api_key = os.environ.get(economy_api_key_var, "") if economy_api_key_var else None

        econ_provider = create_provider(
            provider=economy_provider_name,
            model=economy_model,
            max_tokens=economy_max_tokens,
            base_url=economy_base_url or None,
            api_key=economy_api_key or None,
        )
        provider = TierRouter(
            premium=premium_provider,
            economy=econ_provider,
            classify_hook=get_user_hook("classify_tier"),
        )
        logger.info(f"Tier routing enabled: premium={model}, economy={economy_model}")
    else:
        provider = premium_provider

    previous_feedback = ""
    retry_count = 0
    hat_index = 0

    while hat_index < len(hat_names):
        hat_name = hat_names[hat_index].strip()
        hat = all_hats.get(hat_name)

        if not hat:
            logger.warning(f"Unknown hat: {hat_name}, skipping")
            hat_index += 1
            continue

        if not hat.enabled:
            logger.info(f"[{hat_name}] Disabled, skipping")
            hat_index += 1
            continue

        # ── Hat switch ──
        logger.info("")
        logger.info("=" * 60)
        logger.info(f"HAT: {hat_name.upper()}")
        logger.info("=" * 60)
        logger.info(f"  Role: {hat.prompt[:100]}...")
        logger.info(f"  Tools: {hat.tools or '(all)'}")
        if hat.max_cost:
            logger.info(f"  Quota: max_cost=${hat.max_cost} max_iterations={hat.max_iterations}")
        logger.info("=" * 60)

        # Build filtered context from previous hats
        pipeline_context = format_context_for_hat(comms_dir, agent_id, hat_name)

        # Build the hat-specific task prompt
        hat_task = get_hat_task_prompt(
            hat, task_description, branch_name,
            previous_feedback, pipeline_context, sdlc,
        )

        # Build system prompt with project context + manager-learned additions + developer preferences
        # All external content goes through the prompt guard
        manager_additions = ""
        if manager_yml.exists():
            try:
                import yaml as _yaml
                mgr_config = _yaml.safe_load(manager_yml.read_text(encoding="utf-8")) or {}
                additions = mgr_config.get("prompt_additions", [])
                rules = mgr_config.get("learned_rules", [])
                parts = []
                for a in additions:
                    parts.append(a["text"] if isinstance(a, dict) else a)
                for r in rules:
                    parts.append(r["rule"] if isinstance(r, dict) else r)
                if parts:
                    manager_additions = "MANAGER-LEARNED GUIDANCE (from retrospectives):\n" + "\n".join(
                        f"- {p}" for p in parts
                    )
            except Exception:
                pass

        # Load developer preferences
        try:
            from shypmate.manager.preferences import format_for_prompt
            dev_prefs = format_for_prompt(str(shypmate_dir), hat_name=hat_name)
            if dev_prefs:
                manager_additions = (manager_additions + "\n\n" + dev_prefs) if manager_additions else dev_prefs
        except Exception:
            pass

        from shypmate.engine.prompt_guard import build_guarded_system_prompt

        system_prompt = build_guarded_system_prompt(
            core_prompt=hat.prompt,
            project_context=project_context,
            manager_additions=manager_additions,
            sdlc_prompt=sdlc,
            custom_hat_prompt=hat.prompt if hat.name not in ("developer", "qa", "product_owner") else "",
        )

        # Build tool registry — filter to hat's allowed tools
        from shypmate.agents.dev_agent import create_tool_registry
        full_registry = create_tool_registry()

        if hat.tools:
            # Filtered registry — only the tools this hat is allowed to use
            registry = ToolRegistry()
            for tool_name in hat.tools:
                func = full_registry._tools.get(tool_name)
                if func:
                    registry.register(func)
        else:
            registry = full_registry

        # Build quota: project config as base, hat-specific values override if set
        quota = AgentQuota(
            soft_max_tokens=PROJECT.soft_max_tokens,
            soft_max_cost=PROJECT.soft_max_cost,
            soft_max_seconds=PROJECT.soft_max_seconds,
            soft_max_iterations=PROJECT.soft_max_iterations,
            hard_max_tokens=PROJECT.hard_max_tokens,
            hard_max_cost=hat.max_cost if hat.max_cost else PROJECT.hard_max_cost,
            hard_max_iterations=hat.max_iterations if hat.max_iterations else PROJECT.hard_max_iterations,
            hard_max_seconds=hat.max_seconds if hat.max_seconds else PROJECT.hard_max_seconds,
        )

        # Run the agent for this hat
        try:
            from shypmate.engine.agent_loop import AgentResult
            agent_result = run_agent(
                provider=provider,
                system_prompt=system_prompt,
                task_prompt=hat_task,
                registry=registry,
                max_iterations=hat.max_iterations or 50,
                quota=quota,
                hat_name=hat_name,
            )
            result_text = agent_result.output if isinstance(agent_result, AgentResult) else str(agent_result)
        except Exception as e:
            logger.error(f"[{hat_name}] Agent failed: {e}", exc_info=True)
            result_text = f"FAIL: {e}"
            agent_result = None

        # Parse outcome
        status, feedback = parse_hat_outcome(hat_name, result_text)

        # Save context for next hat — includes structured activity steps
        stage_data = {
            "result": status,
            "summary": result_text[:500] if result_text else "",
            "feedback": feedback[:500] if feedback else "",
        }
        if hat_name == "developer":
            parsed = parse_developer_output(result_text or "")
            stage_data.update(parsed)

        # Add structured activity steps from the agent run
        if agent_result and isinstance(agent_result, AgentResult):
            from dataclasses import asdict
            stage_data["activity"] = [asdict(step) for step in agent_result.steps]
            stage_data["metrics"] = {
                "iterations": agent_result.iterations,
                "input_tokens": agent_result.total_input_tokens,
                "output_tokens": agent_result.total_output_tokens,
                "cost": round(agent_result.cost, 4),
                "elapsed_seconds": round(agent_result.elapsed_seconds, 1),
                "status": agent_result.status,
            }
            if agent_result.stop_reason:
                stage_data["metrics"]["stop_reason"] = agent_result.stop_reason
            if agent_result.tier_stats:
                stage_data["metrics"]["tier_stats"] = agent_result.tier_stats

        save_stage_context(comms_dir, agent_id, hat_name, stage_data)

        # Log outcome
        if status == "passed":
            logger.info(f"[{hat_name}] ✓ PASSED")
            previous_feedback = ""
            hat_index += 1
        else:
            logger.warning(f"[{hat_name}] ✗ FAILED")
            if feedback:
                for line in feedback[:300].splitlines():
                    logger.warning(f"  {line}")

            # Hard quota stop = out of budget — don't retry, stop immediately
            if result_text and result_text.startswith("AGENT STOPPED:"):
                logger.error(f"Pipeline STOPPED — {hat_name} hit hard quota. No retry.")
                _run_container_retrospective(provider, comms_dir, agent_id, task_description, hat_names)
                return 1

            # Retry: loop back to developer
            if hat_name != "developer" and retry_count < max_retries:
                retry_count += 1
                logger.info(f"Looping back to developer (retry {retry_count}/{max_retries})")
                previous_feedback = feedback
                hat_index = 0  # restart from developer
                continue
            else:
                logger.error(f"Pipeline FAILED after {retry_count + 1} attempts")
                _run_container_retrospective(provider, comms_dir, agent_id, task_description, hat_names)
                return 1

    # All hats passed — open PR
    logger.info("")
    logger.info("=" * 60)
    logger.info("ALL HATS PASSED — opening PR")
    logger.info("=" * 60)

    try:
        from shypmate.tools.github_tools import create_pull_request
        from shypmate.tools.git_tools import git_push

        # Push the branch
        push_result = git_push(branch_name)
        logger.info(f"Push: {push_result}")

        # Create PR
        pr_result = create_pull_request(
            title=f"[AI] {task_description[:60]}",
            body=f"## Task\n{task_description}\n\n## Pipeline\nHats: {' → '.join(hat_names)}\nAll stages passed.",
            branch_name=branch_name,
            base_branch=os.environ.get("BASE_BRANCH", "main"),
        )
        logger.info(f"PR: {pr_result}")
    except Exception as e:
        logger.error(f"Failed to create PR: {e}")
        return 1

    logger.info("Pipeline complete.")

    # Run retrospective inside the container — results written to pipeline context
    _run_container_retrospective(provider, comms_dir, agent_id, task_description, hat_names)

    return 0


def _run_container_retrospective(
    provider,
    comms_dir: Path,
    agent_id: str,
    task_description: str,
    hat_names: list[str],
) -> None:
    """Run retrospective inside the container and write results to pipeline context.

    The LLM call happens here (container has the SDK and API key).
    Results are written to:
      1. Pipeline context JSON — the manager reads this to compile observations
      2. Progress file — the --follow CLI sees it in real time

    The container does NOT write to manager_state.json — that's the manager's job.
    """
    import json as _json
    from shypmate.hats.context import load_context, _context_path
    from shypmate.engine.agent_loop import _write_progress

    try:
        logger.info("")
        logger.info("=" * 60)
        logger.info("RETROSPECTIVE")
        logger.info("=" * 60)

        # Load the pipeline context to see what happened across all hats
        ctx = load_context(comms_dir, agent_id)
        stages_summary = []
        discovery_steps = []  # track iterations spent discovering things
        for stage in ctx.get("stages", []):
            hat = stage.get("hat", "?")
            result = stage.get("result", "?")
            metrics = stage.get("metrics", {})
            iters = metrics.get("iterations", "?")
            cost = metrics.get("cost", "?")
            status = metrics.get("status", "?")
            stop = metrics.get("stop_reason", "")
            stages_summary.append(
                f"  {hat}: {result} ({iters} iterations, ${cost}, {status}"
                + (f", stopped: {stop}" if stop else "") + ")"
            )

            for step in stage.get("activity", []):
                for tc in step.get("tool_calls", []):
                    result_s = tc.get("result_summary", "")
                    # Track denied commands
                    if "DENIED" in result_s:
                        stages_summary.append(f"    DENIED: {tc['name']}({tc.get('input_summary', '')[:60]})")
                    # Track discovery/exploration steps
                    name = tc.get("name", "")
                    if name in ("search_files", "read_file", "list_directory"):
                        reasoning = step.get("reasoning", "").lower()
                        if any(w in reasoning for w in ("understand", "explore", "find", "look for", "check if", "figure out", "determine")):
                            discovery_steps.append(f"    [{hat} iter {step.get('iteration')}] {tc.get('input_summary', '')[:80]}")

        stages_text = "\n".join(stages_summary) if stages_summary else "No stage data available."
        discovery_text = "\n".join(discovery_steps[:10]) if discovery_steps else "None detected."

        # Check what config is currently set vs missing
        test_cmd = os.environ.get("SHYPMATE_TEST_COMMAND", "")
        test_fw = os.environ.get("SHYPMATE_TEST_FRAMEWORK", "")
        test_dir = os.environ.get("SHYPMATE_TEST_DIR", "")
        lint_cmd = os.environ.get("SHYPMATE_LINT_COMMAND", "")

        config_status = []
        if test_cmd:
            config_status.append(f"  test.command: {test_cmd}")
        else:
            config_status.append("  test.command: NOT SET — agent had to discover how to run tests")
        if test_fw:
            config_status.append(f"  test.framework: {test_fw}")
        else:
            config_status.append("  test.framework: NOT SET — agent had to discover test framework")
        if test_dir:
            config_status.append(f"  test.dir: {test_dir}")
        else:
            config_status.append("  test.dir: NOT SET — agent had to discover test directory")
        if lint_cmd:
            config_status.append(f"  lint.command: {lint_cmd}")
        else:
            config_status.append("  lint.command: NOT SET")
        config_text = "\n".join(config_status)

        # Tier routing info
        tier_routing_enabled = os.environ.get("TIER_ROUTING", "false").lower() in ("true", "1", "yes")
        tier_text = ""
        if tier_routing_enabled:
            tier_text = f"  Tier routing: ENABLED (premium={os.environ.get('LLM_MODEL', '?')}, economy={os.environ.get('ECONOMY_MODEL', '?')})"
            # Include tier stats from provider if available
            if hasattr(provider, 'tier_cost_breakdown'):
                tier_lines = provider.tier_cost_breakdown()
                if tier_lines:
                    tier_text += "\n" + "\n".join(tier_lines)
        else:
            tier_text = "  Tier routing: DISABLED — all iterations use the same model"

        prompt = f"""Review this pipeline execution and provide a structured retrospective.

Task: {task_description}
Hats: {' -> '.join(hat_names)}

Pipeline stages:
{stages_text}

Discovery/exploration steps (iterations spent figuring things out):
{discovery_text}

Current project config:
{config_text}

Tier routing:
{tier_text}

IMPORTANT: Focus on what could be PRE-CONFIGURED to eliminate discovery waste.
If agents spent iterations figuring out the test framework, test command, test directory,
or lint tool, those should be config suggestions.
If tier routing is disabled and many iterations were discovery-only, suggest enabling it.
If tier routing is enabled, assess whether the routing made good decisions — were there
iterations routed to economy that needed premium reasoning, or premium iterations wasted
on simple reads?

Respond in this exact JSON format (no markdown, just raw JSON):
{{
  "outcome": "PASS or FAIL",
  "outcome_reason": "brief reason",
  "total_cost": 0.00,
  "wasted_iterations": ["description of each wasted iteration and how many iterations it cost"],
  "observations": [
    {{
      "type": "repeated_install|prompt_improvement|missing_tool|quota_hit|shell_denied|wasted_read|discovery_waste|general",
      "pattern": "short pattern key",
      "detail": "what happened and what would fix it"
    }}
  ],
  "config_suggestions": [
    {{
      "key": "test.command|test.framework|test.dir|lint.command|test_dependencies|shell.allowed_prefixes|llm.tier_routing",
      "value": "the suggested value based on what the agent discovered",
      "reason": "why this would save iterations or cost"
    }}
  ],
  "tier_routing_assessment": {{
    "should_enable": true,
    "reason": "why tier routing should be enabled/disabled",
    "misrouted_iterations": ["iterations that were routed to the wrong tier and why"]
  }},
  "memory_suggestions": [
    "facts the agent should have remembered for future runs"
  ]
}}

Observation types:
- discovery_waste: agent spent iterations discovering something that could be configured
- repeated_install: agent installed packages that should be in test_dependencies
- shell_denied: agent tried a command not in the allowlist
- quota_hit: agent ran out of budget
- prompt_improvement: guidance that would prevent mistakes
- general: anything else"""

        response = provider.create_message(
            system="You are reviewing AI agent pipeline execution for process improvements. Respond with valid JSON only.",
            messages=[{"role": "user", "content": prompt}],
            tools=[],
        )

        retro_text = response.text or ""

        if not retro_text.strip():
            logger.info("  Nothing notable.")
            return

        # Strip markdown code fences if the LLM wrapped the JSON
        clean = retro_text.strip()
        if clean.startswith("```"):
            # Remove ```json or ``` prefix and trailing ```
            lines = clean.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            clean = "\n".join(lines)

        retro_data = _json.loads(clean)

        # Log findings
        outcome = retro_data.get("outcome", "?")
        reason = retro_data.get("outcome_reason", "")
        logger.info(f"  Outcome: {outcome} — {reason}")

        for w in retro_data.get("wasted_iterations", []):
            logger.info(f"  Wasted: {w}")

        for obs in retro_data.get("observations", []):
            logger.info(f"  Observation [{obs.get('type')}] {obs.get('pattern')}: {obs.get('detail', '')[:80]}")

        config_suggestions = retro_data.get("config_suggestions", [])
        for cs in config_suggestions:
            logger.info(f"  Config suggestion: {cs.get('key')} = {cs.get('value')} ({cs.get('reason', '')})")

        memory_suggestions = retro_data.get("memory_suggestions", [])
        for ms in memory_suggestions:
            logger.info(f"  Memory suggestion: {ms}")

        tier_assessment = retro_data.get("tier_routing_assessment", {})
        if tier_assessment:
            should = "enable" if tier_assessment.get("should_enable") else "disable"
            logger.info(f"  Tier routing: suggest {should} — {tier_assessment.get('reason', '')}")
            for mis in tier_assessment.get("misrouted_iterations", []):
                logger.info(f"    Misrouted: {mis}")

        logger.info("=" * 60)

        # Write retrospective to pipeline context JSON
        ctx["retrospective"] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "outcome": outcome,
            "outcome_reason": reason,
            "wasted_iterations": retro_data.get("wasted_iterations", []),
            "observations": retro_data.get("observations", []),
            "config_suggestions": config_suggestions,
            "memory_suggestions": memory_suggestions,
            "tier_routing_assessment": tier_assessment,
            "total_cost": retro_data.get("total_cost", 0),
        }

        path = _context_path(comms_dir, agent_id)
        path.write_text(_json.dumps(ctx, indent=2), encoding="utf-8")
        logger.info("Retrospective saved to pipeline context.")

        # Write to progress file so --follow CLI sees it
        _write_progress({
            "type": "retrospective",
            "outcome": outcome,
            "outcome_reason": reason,
            "wasted_iterations": retro_data.get("wasted_iterations", []),
            "observations": [
                {"type": o.get("type"), "pattern": o.get("pattern"), "detail": o.get("detail", "")[:100]}
                for o in retro_data.get("observations", [])
            ],
            "config_suggestions": config_suggestions,
            "memory_suggestions": memory_suggestions,
            "tier_routing_assessment": tier_assessment,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    except _json.JSONDecodeError:
        logger.warning("  Retrospective returned non-JSON, skipping.")
    except Exception as e:
        logger.warning(f"  Retrospective failed: {e}")


def _comment_failure(branch_name: str, agent_id: str, error: str) -> None:
    """Best-effort: comment on the PR that the agent failed."""
    try:
        from github import Github

        token = os.environ.get("GITHUB_TOKEN", "")
        repo_name = os.environ.get("GITHUB_REPO", "")
        gh = Github(token)
        repo = gh.get_repo(repo_name)

        for pr in repo.get_pulls(state="open"):
            if pr.head.ref == branch_name:
                pr.create_issue_comment(
                    f"**AI Agent `{agent_id}` failed.**\n\n"
                    f"```\n{error[:2000]}\n```\n\n"
                    "This PR may need manual attention."
                )
                break
    except Exception:
        pass  # Best effort


if __name__ == "__main__":
    sys.exit(main())
