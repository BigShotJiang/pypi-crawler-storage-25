"""
Developer preferences — behavioral guidance for agent prompts.

Three sources, merged in order:
  1. shypmate.yml / shypmate.py — project-level preferences (checked into repo)
  2. .shypmate/preferences.yml — CLI-added preferences (local, gitignored)

Preferences can be global or hat-specific:
  preferences:
    global:
      - "be literal — implement exactly what I ask"
    developer:
      - "always use type hints"
    qa:
      - "focus only on test results"
"""

import logging
import os
from datetime import datetime, timezone
from pathlib import Path

import yaml

logger = logging.getLogger("shypmate.manager.preferences")

PREFERENCES_FILE = "preferences.yml"


def _preferences_path(project_root: str | Path) -> Path:
    root = Path(project_root)
    if root.name in (".shypmate", "dot-shypmate"):
        return root / PREFERENCES_FILE
    return root / ".shypmate" / PREFERENCES_FILE


def _load_cli_preferences(project_root: str | Path) -> dict:
    """Load CLI-added preferences from .shypmate/preferences.yml."""
    path = _preferences_path(project_root)
    if not path.exists():
        return {}
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as e:
        logger.warning(f"Could not load CLI preferences: {e}")
        return {}


def _load_config_preferences() -> dict:
    """Load preferences from shypmate.yml / shypmate.py via the config system."""
    try:
        from shypmate.config.project import PROJECT, _load_yaml_config, _load_py_config, _find_project_root, _deep_merge

        root = _find_project_root()
        py_config, _ = _load_py_config(root)
        yml = _load_yaml_config(root)
        merged = _deep_merge(py_config, yml)
        return merged.get("preferences", {})
    except Exception:
        return {}


def load_all_preferences(project_root: str | Path) -> dict:
    """Load and merge preferences from all sources.

    Returns dict with 'global' and hat-specific keys, each containing a list of strings.
    """
    # Config preferences (shypmate.yml / shypmate.py)
    config_prefs = _load_config_preferences()

    # CLI preferences (.shypmate/preferences.yml)
    cli_data = _load_cli_preferences(project_root)
    cli_prefs = cli_data.get("preferences", {})

    # Normalize: if config_prefs is a list, treat as global
    if isinstance(config_prefs, list):
        config_prefs = {"global": config_prefs}
    if isinstance(cli_prefs, list):
        cli_prefs = {"global": [p.get("text", p) if isinstance(p, dict) else p for p in cli_prefs]}

    # Merge — CLI preferences are additive to config preferences
    merged: dict[str, list[str]] = {}
    for source in (config_prefs, cli_prefs):
        for key, items in source.items():
            if not isinstance(items, list):
                continue
            texts = merged.setdefault(key, [])
            for item in items:
                text = item.get("text", item) if isinstance(item, dict) else str(item)
                if text and text not in texts:
                    texts.append(text)

    return merged


def save_cli_preferences(project_root: str | Path, prefs_data: dict) -> None:
    """Save CLI-added preferences to .shypmate/preferences.yml."""
    path = _preferences_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.dump(prefs_data, default_flow_style=False, sort_keys=False), encoding="utf-8")


def add_preference(project_root: str | Path, text: str, hat: str = "global") -> None:
    """Add a preference via CLI. Stored in .shypmate/preferences.yml."""
    cli_data = _load_cli_preferences(project_root)
    prefs = cli_data.setdefault("preferences", {})

    if isinstance(prefs, list):
        # Migrate old flat list format to new dict format
        prefs = {"global": [{"text": p.get("text", p) if isinstance(p, dict) else p,
                              "added": p.get("added", "")} for p in prefs]}
        cli_data["preferences"] = prefs

    hat_prefs = prefs.setdefault(hat, [])

    # Don't duplicate
    existing = {p.get("text", p) if isinstance(p, dict) else p for p in hat_prefs}
    if text in existing:
        return

    hat_prefs.append({
        "text": text,
        "added": datetime.now(timezone.utc).isoformat(),
    })
    save_cli_preferences(project_root, cli_data)


def remove_preference(project_root: str | Path, index: int, hat: str = "global") -> str | None:
    """Remove a CLI preference by index (1-based). Returns removed text or None."""
    cli_data = _load_cli_preferences(project_root)
    prefs = cli_data.get("preferences", {})

    if isinstance(prefs, list):
        prefs = {"global": prefs}
        cli_data["preferences"] = prefs

    hat_prefs = prefs.get(hat, [])
    if index < 1 or index > len(hat_prefs):
        return None

    removed = hat_prefs.pop(index - 1)
    save_cli_preferences(project_root, cli_data)
    return removed.get("text", removed) if isinstance(removed, dict) else str(removed)


def format_for_prompt(project_root: str | Path, hat_name: str = "") -> str:
    """Format preferences for injection into an agent's system prompt.

    Merges global preferences with hat-specific ones.
    """
    all_prefs = load_all_preferences(project_root)
    if not all_prefs:
        return ""

    lines = []

    # Global preferences
    global_prefs = all_prefs.get("global", [])
    if global_prefs:
        lines.append("DEVELOPER PREFERENCES (from the human you're working for):")
        for p in global_prefs:
            lines.append(f"- {p}")

    # Hat-specific preferences
    if hat_name and hat_name in all_prefs:
        hat_prefs = all_prefs[hat_name]
        if hat_prefs:
            lines.append(f"\nPREFERENCES FOR {hat_name.upper()}:")
            for p in hat_prefs:
                lines.append(f"- {p}")

    return "\n".join(lines) if lines else ""
