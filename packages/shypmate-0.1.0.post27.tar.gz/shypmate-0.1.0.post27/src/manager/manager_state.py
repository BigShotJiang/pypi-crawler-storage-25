"""
Manager observation state — .shypmate/manager_state.json

The manager's private working memory. Tracks patterns observed across
retrospectives, accumulates evidence, and decides when to propose
improvements to the human.

IMPORTANT: Only the manager reads/writes this file. Agents must NEVER
access or influence it. This is enforced by:
  1. File lives under .shypmate/ which is not in the workspace sandbox
  2. No agent tool exposes this file
  3. The file is not passed as context to agents

The human can read this file at any time to understand what the manager
is thinking and why.

Lifecycle of an observation:
  accumulating → proposed → approved/dismissed
                         ↘ expired (if no new evidence for N days)
"""

import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger("shypmate.manager.state")

STATE_FILE = "manager_state.json"


def _state_path(project_root: str | Path) -> Path:
    """Resolve the state file path.

    Accepts either:
      - A project root (appends .shypmate/manager_state.json)
      - A .shypmate/ directory directly (appends manager_state.json)
    """
    root = Path(project_root)
    if root.name == ".shypmate" or root.name == "dot-shypmate":
        return root / STATE_FILE
    return root / ".shypmate" / STATE_FILE


def load_state(project_root: str | Path) -> dict:
    """Load the manager's observation state."""
    path = _state_path(project_root)
    if not path.exists():
        return {"observations": [], "decisions": []}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning(f"Could not load manager state: {e}")
        return {"observations": [], "decisions": []}


def save_state(project_root: str | Path, state: dict) -> None:
    """Save the manager's observation state."""
    path = _state_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2), encoding="utf-8")


# ── Observation Types ──

# Each type has a default threshold — how many occurrences before proposing
OBSERVATION_THRESHOLDS = {
    "repeated_install": 2,       # agent installed a package at runtime
    "discovery_waste": 2,        # agent spent iterations discovering config-able info
    "wasted_read": 3,            # agent read entire large files unnecessarily
    "missing_tool": 2,           # agent needed a tool it didn't have
    "prompt_improvement": 2,     # agent made a mistake a prompt could prevent
    "shell_denied": 2,           # agent tried a command not in allowlist
    "quota_hit": 2,              # agent hit quota before finishing
    "general": 3,                # catch-all
}


def _find_observation(state: dict, obs_type: str, pattern: str) -> dict | None:
    """Find an existing observation by type and pattern."""
    for obs in state.get("observations", []):
        if obs["type"] == obs_type and obs["pattern"] == pattern and obs["status"] == "accumulating":
            return obs
    return None


def record_observation(
    project_root: str | Path,
    obs_type: str,
    pattern: str,
    detail: str,
    container_name: str = "",
    agent_id: str = "",
) -> dict:
    """Record a new observation or add evidence to an existing one.

    Returns the observation dict (which may now be ready to propose).
    """
    state = load_state(project_root)
    now = datetime.now(timezone.utc).isoformat()

    evidence_entry = {
        "container": container_name,
        "agent_id": agent_id,
        "date": now,
        "detail": detail,
    }

    obs = _find_observation(state, obs_type, pattern)

    if obs:
        # Add evidence to existing observation
        obs["occurrences"] += 1
        obs["last_seen"] = now
        obs["evidence"].append(evidence_entry)
    else:
        # Create new observation
        obs = {
            "id": f"obs-{uuid.uuid4().hex[:8]}",
            "type": obs_type,
            "pattern": pattern,
            "occurrences": 1,
            "threshold": OBSERVATION_THRESHOLDS.get(obs_type, 3),
            "first_seen": now,
            "last_seen": now,
            "evidence": [evidence_entry],
            "status": "accumulating",
        }
        state.setdefault("observations", []).append(obs)

    save_state(project_root, state)
    return obs


def get_ready_observations(project_root: str | Path) -> list[dict]:
    """Get observations that have reached their threshold and are ready to propose."""
    state = load_state(project_root)
    ready = []
    for obs in state.get("observations", []):
        if obs["status"] == "accumulating" and obs["occurrences"] >= obs["threshold"]:
            ready.append(obs)
    return ready


def mark_proposed(project_root: str | Path, observation_id: str) -> None:
    """Mark an observation as proposed to the human."""
    state = load_state(project_root)
    for obs in state.get("observations", []):
        if obs["id"] == observation_id:
            obs["status"] = "proposed"
            obs["proposed_at"] = datetime.now(timezone.utc).isoformat()
            break
    save_state(project_root, state)


def mark_resolved(
    project_root: str | Path,
    observation_id: str,
    response: str,
    action_taken: str = "",
) -> None:
    """Mark an observation as resolved (approved or dismissed)."""
    state = load_state(project_root)
    now = datetime.now(timezone.utc).isoformat()

    for obs in state.get("observations", []):
        if obs["id"] == observation_id:
            obs["status"] = "approved" if response in ("yes", "y", "approve") else "dismissed"
            obs["resolved_at"] = now
            break

    # Record the decision
    state.setdefault("decisions", []).append({
        "observation_id": observation_id,
        "response": response,
        "action_taken": action_taken,
        "decided_at": now,
    })

    save_state(project_root, state)


def record_manager_thought(project_root: str | Path, thought: str) -> None:
    """Record a free-form manager thought/reasoning for debugging.

    These are timestamped entries that help the human understand
    the manager's decision-making process.
    """
    state = load_state(project_root)
    state.setdefault("thoughts", []).append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "thought": thought,
    })

    # Keep only the last 50 thoughts to avoid unbounded growth
    if len(state["thoughts"]) > 50:
        state["thoughts"] = state["thoughts"][-50:]

    save_state(project_root, state)


def get_summary(project_root: str | Path) -> str:
    """Get a human-readable summary of the manager's current state."""
    state = load_state(project_root)
    lines = ["Manager State Summary", "=" * 40]

    # Active observations
    accumulating = [o for o in state.get("observations", []) if o["status"] == "accumulating"]
    proposed = [o for o in state.get("observations", []) if o["status"] == "proposed"]

    if accumulating:
        lines.append(f"\nAccumulating ({len(accumulating)}):")
        for obs in accumulating:
            lines.append(
                f"  [{obs['type']}] {obs['pattern']} "
                f"— {obs['occurrences']}/{obs['threshold']} occurrences"
            )
    if proposed:
        lines.append(f"\nAwaiting human response ({len(proposed)}):")
        for obs in proposed:
            lines.append(f"  [{obs['type']}] {obs['pattern']}")

    # Recent thoughts
    thoughts = state.get("thoughts", [])
    if thoughts:
        lines.append(f"\nRecent thoughts ({len(thoughts)}):")
        for t in thoughts[-5:]:
            lines.append(f"  [{t['timestamp'][:19]}] {t['thought']}")

    # Recent decisions
    decisions = state.get("decisions", [])
    if decisions:
        lines.append(f"\nRecent decisions ({len(decisions)}):")
        for d in decisions[-5:]:
            lines.append(f"  [{d['decided_at'][:19]}] {d['observation_id']}: {d['response']}")

    return "\n".join(lines)
