"""
Manager-managed config layer — .shypmate/manager.yml

This is an additive overlay on top of shypmate.yml/shypmate.py.
The manager proposes improvements based on retrospectives, the human
approves them, and they're stored here for future agent runs.

The manager NEVER modifies shypmate.yml or shypmate.py. This file
is the manager's own config space.

Fields:
  - test_dependencies: packages to pre-install before agent loop
  - prompt_additions: extra guidance injected into agent system prompts
  - learned_rules: patterns discovered from retrospectives
  - pre_install_commands: shell commands to run before agent loop

Each entry tracks its source and approval status.
"""

import logging
from datetime import datetime, timezone
from pathlib import Path

import yaml

logger = logging.getLogger("shypmate.manager.config")

# Default location for manager config (relative to project root)
MANAGER_CONFIG_DIR = ".shypmate"
MANAGER_CONFIG_FILE = "manager.yml"


def _manager_config_path(project_root: str | Path) -> Path:
    """Get the path to the manager config file.

    Accepts either:
      - A project root (appends .shypmate/manager.yml)
      - A .shypmate/ directory directly (appends manager.yml)
    """
    root = Path(project_root)
    if root.name == ".shypmate" or root.name == "dot-shypmate":
        return root / MANAGER_CONFIG_FILE
    return root / MANAGER_CONFIG_DIR / MANAGER_CONFIG_FILE


def load_manager_config(project_root: str | Path) -> dict:
    """Load the manager config overlay. Returns empty dict if not found."""
    path = _manager_config_path(project_root)
    if not path.exists():
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        logger.warning(f"Could not load manager config: {e}")
        return {}


def save_manager_config(project_root: str | Path, config: dict) -> None:
    """Save the manager config overlay."""
    path = _manager_config_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    logger.info(f"Updated manager config: {path}")


def add_test_dependency(
    project_root: str | Path,
    package: str,
    source: str = "",
) -> None:
    """Add a test dependency (approved by human)."""
    config = load_manager_config(project_root)
    deps = config.setdefault("test_dependencies", [])

    # Don't duplicate
    existing_names = {d["package"] if isinstance(d, dict) else d for d in deps}
    if package in existing_names:
        return

    deps.append({
        "package": package,
        "source": source,
        "approved": datetime.now(timezone.utc).isoformat(),
    })
    save_manager_config(project_root, config)


def add_prompt_addition(
    project_root: str | Path,
    prompt: str,
    source: str = "",
) -> None:
    """Add a prompt addition (approved by human)."""
    config = load_manager_config(project_root)
    additions = config.setdefault("prompt_additions", [])

    # Don't duplicate (check by text)
    if any((a["text"] if isinstance(a, dict) else a) == prompt for a in additions):
        return

    additions.append({
        "text": prompt,
        "source": source,
        "approved": datetime.now(timezone.utc).isoformat(),
    })
    save_manager_config(project_root, config)


def add_learned_rule(
    project_root: str | Path,
    rule: str,
    source: str = "",
) -> None:
    """Add a learned rule (approved by human)."""
    config = load_manager_config(project_root)
    rules = config.setdefault("learned_rules", [])

    if any((r["rule"] if isinstance(r, dict) else r) == rule for r in rules):
        return

    rules.append({
        "rule": rule,
        "source": source,
        "approved": datetime.now(timezone.utc).isoformat(),
    })
    save_manager_config(project_root, config)


def get_test_dependencies(project_root: str | Path) -> list[str]:
    """Get the merged list of test dependency package names."""
    config = load_manager_config(project_root)
    deps = config.get("test_dependencies", [])
    return [d["package"] if isinstance(d, dict) else d for d in deps]


def get_prompt_additions(project_root: str | Path) -> list[str]:
    """Get all prompt addition texts."""
    config = load_manager_config(project_root)
    additions = config.get("prompt_additions", [])
    return [a["text"] if isinstance(a, dict) else a for a in additions]


def get_learned_rules(project_root: str | Path) -> list[str]:
    """Get all learned rule texts."""
    config = load_manager_config(project_root)
    rules = config.get("learned_rules", [])
    return [r["rule"] if isinstance(r, dict) else r for r in rules]
