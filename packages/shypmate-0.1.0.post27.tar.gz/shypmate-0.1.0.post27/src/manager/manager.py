"""
Manager — persistent container that orchestrates wave-based task execution.

Runs via 'shypmate start', stops via 'shypmate stop'.

Responsibilities:
1. Clone repo and generate project brief (ONE LLM call, shared with all workers)
2. Analyze all pending tasks and produce a wave plan (ONE LLM call)
3. Launch agents wave-by-wave: parallel within a wave, sequential across waves
4. Detect new tasks added mid-run and slot them into the plan
5. Re-analyze after each wave completes (repo has changed)
6. Monitor PRs for merges, clean up containers
7. Regenerate brief when the base branch advances
"""

import json
import logging
import os
import re
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger("shypmate.manager")

BRIEF_DIR = Path("/brief")
DATA_DIR = Path("/shypmate-data")
TASKS_FILE = Path(os.environ.get("TASKS_FILE", "/tasks/ai_tasks.yml"))


class Manager:
    def __init__(self):
        self.github_token = os.environ.get("GITHUB_TOKEN", "")
        self.repo_name = os.environ.get("GITHUB_REPO", "")
        self.base_branch = os.environ.get("BASE_BRANCH", "main")
        self.poll_interval = int(os.environ.get("POLL_INTERVAL", "60"))
        self.llm_provider_name = os.environ.get("LLM_PROVIDER", "anthropic")
        self.llm_model = os.environ.get("LLM_MODEL", "claude-sonnet-4-6")
        self.llm_max_tokens = int(os.environ.get("LLM_MAX_TOKENS", "8192"))
        self.llm_base_url = os.environ.get("LLM_BASE_URL", "")
        self.workspace = os.environ.get("WORKSPACE", "/workspace")
        self.execution_mode = os.environ.get("TASK_EXECUTION", "auto")
        self.branch_prefix = os.environ.get("BRANCH_PREFIX", "shypmate/dev")
        self.install_command = os.environ.get("INSTALL_COMMAND", "")
        self.agent_image = os.environ.get("AGENT_IMAGE", "shypmate-agent:latest")
        self.docker_network = os.environ.get("DOCKER_NETWORK", "bridge")
        self.comms_dir = os.environ.get("COMMS_DIR", "")  # host path (for child container mounts)
        # Container-internal paths (mounted from host's .shypmate/)
        self._shypmate_dir = Path("/dot-shypmate")
        self._comms_dir_internal = self._shypmate_dir / "comms"
        self.brief_volume = os.environ.get("BRIEF_VOLUME", "shypmate-brief")
        self.memory_max_entries = os.environ.get("SHYPMATE_MEMORY_MAX_ENTRIES", "50")
        self.memory_max_size = os.environ.get("SHYPMATE_MEMORY_MAX_SIZE", "8192")
        self.sdlc_prompt = os.environ.get("SDLC_PROMPT", "")

        # LLM pool for agent assignment (JSON-serialized list of pool entries)
        self.llm_pool_json = os.environ.get("LLM_POOL_JSON", "")

        self._provider = None
        self._gh_repo = None
        self._current_sha = None

        # Wave state
        self._wave_state = None
        self._known_task_ids: set[str] = set()
        self._agent_counter = 0

    # ── Provider / GitHub ──

    def _get_provider(self):
        """Lazy-init LLM provider."""
        if self._provider is None:
            from shypmate.engine.providers import create_provider

            api_key_var = os.environ.get("LLM_API_KEY_VAR", "")
            api_key = os.environ.get(api_key_var, "") if api_key_var else None

            self._provider = create_provider(
                provider=self.llm_provider_name,
                model=self.llm_model,
                max_tokens=self.llm_max_tokens,
                base_url=self.llm_base_url or None,
                api_key=api_key,
            )
        return self._provider

    def _get_gh_repo(self):
        """Lazy-init GitHub repo."""
        if self._gh_repo is None:
            try:
                from github import Github
                self._gh_repo = Github(self.github_token).get_repo(self.repo_name)
            except Exception as e:
                logger.error(f"GitHub connection failed: {e}")
        return self._gh_repo

    # ── Repo Operations ──

    def _clone_or_fetch(self):
        """Clone the repo or fetch if already cloned."""
        from git import Repo
        from git.exc import GitCommandError

        clone_url = f"https://x-access-token:{self.github_token}@github.com/{self.repo_name}.git"
        ws = Path(self.workspace)

        if ws.joinpath(".git").exists():
            logger.info("Fetching latest...")
            repo = Repo(self.workspace)
            repo.git.fetch("--all")
        else:
            logger.info(f"Cloning {self.repo_name}...")
            try:
                repo = Repo.clone_from(clone_url, self.workspace)
            except GitCommandError as e:
                logger.error(f"Clone failed: {e}")
                return None

        try:
            repo.git.checkout(self.base_branch)
            repo.git.pull("origin", self.base_branch)
            self._current_sha = repo.head.commit.hexsha
            logger.info(f"Base branch {self.base_branch} at {self._current_sha[:8]}")
        except Exception as e:
            logger.error(f"Could not update base branch: {e}")
            self._current_sha = repo.head.commit.hexsha

        return repo

    # ── Brief ──

    def ensure_brief(self) -> bool:
        """Generate or refresh the project brief. Returns True if brief is ready."""
        from shypmate.manager.project_brief import (
            load_brief, save_brief, generate_brief, is_brief_current,
        )

        existing = load_brief(BRIEF_DIR)
        if existing and self._current_sha and is_brief_current(existing, self._current_sha):
            logger.info("Brief is current, no regeneration needed")
            return True

        repo = self._clone_or_fetch()
        if not repo:
            return existing is not None

        logger.info("Building project context...")
        sys.path.insert(0, self.workspace)
        from shypmate.context.project_context import build_project_context
        raw_context = build_project_context(self.workspace)

        logger.info("Generating project brief (1 LLM call)...")
        provider = self._get_provider()
        brief = generate_brief(
            repo_root=Path(self.workspace),
            raw_context=raw_context,
            base_branch_sha=self._current_sha or "",
            provider=provider,
        )

        save_brief(brief, BRIEF_DIR)
        logger.info("Project brief generated and saved")
        return True

    # ── Task Loading ──

    def _load_pending_tasks(self) -> list[dict]:
        """Load pending tasks from the mounted task file."""
        try:
            from shypmate.task_manager import list_tasks
            return list_tasks(project_root=str(TASKS_FILE.parent), status="pending")
        except Exception as e:
            logger.debug(f"Could not load tasks: {e}")
            return []

    def _load_all_tasks(self) -> list[dict]:
        """Load all tasks from the mounted task file."""
        try:
            from shypmate.task_manager import list_tasks
            return list_tasks(project_root=str(TASKS_FILE.parent))
        except Exception as e:
            logger.debug(f"Could not load tasks: {e}")
            return []

    def _detect_new_tasks(self, pending_tasks: list[dict]) -> list[dict]:
        """Detect newly added tasks since last check."""
        current_ids = {t["id"] for t in pending_tasks}
        new_ids = current_ids - self._known_task_ids
        self._known_task_ids = current_ids | self._known_task_ids
        return [t for t in pending_tasks if t["id"] in new_ids]

    # ── Wave Orchestration ──

    def _plan_waves(self, pending_tasks: list[dict]) -> None:
        """Analyze pending tasks and create a wave plan."""
        from shypmate.manager.wave_planner import (
            plan_waves, WaveState, save_wave_state,
        )
        from shypmate.manager.project_brief import load_brief

        brief = load_brief(BRIEF_DIR)
        provider = self._get_provider()

        logger.info(f"Planning waves for {len(pending_tasks)} tasks (mode: {self.execution_mode})...")
        plan = plan_waves(pending_tasks, brief, provider, self.execution_mode)

        self._wave_state = WaveState(plan=plan)
        # Track all known task IDs
        self._known_task_ids.update(t["id"] for t in pending_tasks)

        # Log the plan
        for i, wave in enumerate(plan.waves):
            task_descs = []
            for tid in wave:
                t = next((t for t in pending_tasks if t["id"] == tid), None)
                desc = t["description"][:50] if t else tid
                task_descs.append(desc)
            logger.info(f"  Wave {i + 1}: {' | '.join(task_descs)}")

        save_wave_state(self._wave_state, DATA_DIR)

    def _launch_wave(self, wave_task_ids: list[str]) -> None:
        """Launch agent containers for all tasks in the current wave."""
        all_tasks = self._load_all_tasks()
        task_map = {t["id"]: t for t in all_tasks}

        pool = self._get_llm_pool()

        for task_id in wave_task_ids:
            task = task_map.get(task_id)
            if not task:
                logger.warning(f"Task {task_id} not found, skipping")
                continue

            if task.get("status") != "pending":
                logger.info(f"Task {task_id} is {task.get('status')}, skipping")
                continue

            agent_id = f"dev-{uuid.uuid4().hex[:6]}"
            slug = re.sub(r"[^a-z0-9]+", "-", task["description"].lower()).strip("-")[:40]
            ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            branch = f"{self.branch_prefix}/{agent_id}-{slug}-{ts}"

            # Round-robin LLM pool assignment
            llm_entry = pool[self._agent_counter % len(pool)] if pool else None
            self._agent_counter += 1

            container_name = self._launch_container(
                task=task["description"],
                agent_id=agent_id,
                branch=branch,
                task_id=task_id,
                llm_entry=llm_entry,
            )

            if container_name:
                # Mark task as running
                try:
                    from shypmate.task_manager import mark_running
                    mark_running(task_id, agent_id, branch, project_root=str(TASKS_FILE.parent))
                except Exception as e:
                    logger.error(f"Failed to mark task running: {e}")

                # Track in wave state
                self._wave_state.running_agents[task_id] = container_name
                self._wave_state.agent_branches[task_id] = branch
                self._wave_state.agent_ids[task_id] = agent_id

                logger.info(f"Launched {container_name} for task {task_id}")
            else:
                logger.error(f"Failed to launch agent for task {task_id}")
                self._wave_state.failed_tasks.append(task_id)

        from shypmate.manager.wave_planner import save_wave_state
        save_wave_state(self._wave_state, DATA_DIR)

    def _launch_container(
        self,
        task: str,
        agent_id: str,
        branch: str,
        task_id: str = "",
        llm_entry=None,
        rebase: bool = False,
    ) -> str | None:
        """Launch an agent container from inside the manager. Returns container name or None."""
        try:
            import docker
            client = docker.from_env()
        except Exception as e:
            logger.error(f"Docker client error: {e}")
            return None

        container_name = f"shypmate-{agent_id}"

        # Build environment
        env = {
            "GITHUB_TOKEN": self.github_token,
            "GITHUB_REPO": self.repo_name,
            "AGENT_TASK": task,
            "AGENT_BRANCH": branch,
            "AGENT_ID": agent_id,
            "AGENT_REBASE": str(rebase).lower(),
            "BASE_BRANCH": self.base_branch,
            "INSTALL_COMMAND": self.install_command,
            "TEST_DEPENDENCIES": os.environ.get("TEST_DEPENDENCIES", ""),
            "SHYPMATE_MEMORY_MAX_ENTRIES": self.memory_max_entries,
            "SHYPMATE_MEMORY_MAX_SIZE": self.memory_max_size,
        }

        if task_id:
            env["AGENT_TASK_ID"] = task_id

        if self.sdlc_prompt:
            env["SDLC_PROMPT"] = self.sdlc_prompt

        # LLM config from pool entry or manager defaults
        if llm_entry:
            env["LLM_PROVIDER"] = llm_entry.get("provider", self.llm_provider_name)
            env["LLM_MODEL"] = llm_entry.get("model", self.llm_model)
            env["LLM_MAX_TOKENS"] = str(llm_entry.get("max_tokens", self.llm_max_tokens))
            api_key_var = llm_entry.get("api_key_var", "")
            if api_key_var:
                env["LLM_API_KEY_VAR"] = api_key_var
                env[api_key_var] = os.environ.get(api_key_var, "")
            base_url = llm_entry.get("base_url", "")
            if base_url:
                env["LLM_BASE_URL"] = base_url
        else:
            env["LLM_PROVIDER"] = self.llm_provider_name
            env["LLM_MODEL"] = self.llm_model
            env["LLM_MAX_TOKENS"] = str(self.llm_max_tokens)
            api_key_var = os.environ.get("LLM_API_KEY_VAR", "")
            if api_key_var:
                env["LLM_API_KEY_VAR"] = api_key_var
                env[api_key_var] = os.environ.get(api_key_var, "")

        # Volumes
        volumes = {
            self.brief_volume: {"bind": "/brief", "mode": "ro"},
        }
        if self.comms_dir:
            # Mount the .shypmate/ dir (parent of comms/) so agents get
            # access to comms/, manager_state.json, and manager.yml
            shypmate_dir = str(Path(self.comms_dir).parent)
            volumes[shypmate_dir] = {"bind": "/dot-shypmate", "mode": "rw"}

        # Remove old container with same name
        try:
            old = client.containers.get(container_name)
            old.remove(force=True)
        except docker.errors.NotFound:
            pass

        try:
            container = client.containers.run(
                image=self.agent_image,
                name=container_name,
                environment=env,
                network=self.docker_network,
                volumes=volumes or None,
                detach=True,
            )
            return container_name
        except Exception as e:
            logger.error(f"Container launch failed for {agent_id}: {e}")
            return None

    def _get_llm_pool(self) -> list[dict]:
        """Parse the LLM pool from the JSON env var."""
        if not self.llm_pool_json:
            return []
        try:
            return json.loads(self.llm_pool_json)
        except Exception:
            return []

    def _check_wave_completion(self) -> bool:
        """Check if all agents in the current wave have finished. Returns True if wave is done."""
        if not self._wave_state or not self._wave_state.current_wave:
            return True

        try:
            import docker
            client = docker.from_env()
        except Exception as e:
            logger.error(f"Docker client error: {e}")
            return False

        all_done = True
        for task_id, container_name in list(self._wave_state.running_agents.items()):
            # Only check tasks in the current wave
            if task_id not in self._wave_state.current_wave:
                continue

            try:
                container = client.containers.get(container_name)
                status = container.status

                if status == "running":
                    all_done = False
                elif status == "exited":
                    exit_code = container.attrs.get("State", {}).get("ExitCode", -1)
                    if exit_code == 0:
                        logger.info(f"Agent {container_name} completed successfully")
                        self._mark_task_done(task_id)
                    else:
                        logger.warning(f"Agent {container_name} failed (exit code {exit_code})")
                        self._mark_task_failed(task_id)
                        self._wave_state.failed_tasks.append(task_id)
                    # Remove from running
                    del self._wave_state.running_agents[task_id]
                else:
                    all_done = False

            except docker.errors.NotFound:
                # Container gone — treat as failed
                logger.warning(f"Container {container_name} not found, marking task failed")
                self._mark_task_failed(task_id)
                self._wave_state.failed_tasks.append(task_id)
                del self._wave_state.running_agents[task_id]

        return all_done

    def _mark_task_done(self, task_id: str):
        """Mark a task as done in the task file."""
        try:
            from shypmate.task_manager import mark_done
            # Try to find PR URL from the branch
            branch = self._wave_state.agent_branches.get(task_id, "")
            pr_url = self._find_pr_url(branch) if branch else ""
            mark_done(task_id, pr_url=pr_url, project_root=str(TASKS_FILE.parent))
        except Exception as e:
            logger.error(f"Failed to mark task {task_id} done: {e}")

    def _mark_task_failed(self, task_id: str):
        """Mark a task as failed in the task file."""
        try:
            from shypmate.task_manager import mark_failed
            mark_failed(task_id, project_root=str(TASKS_FILE.parent))
        except Exception as e:
            logger.error(f"Failed to mark task {task_id} failed: {e}")

    def _find_pr_url(self, branch: str) -> str:
        """Find the PR URL for a branch."""
        gh_repo = self._get_gh_repo()
        if not gh_repo:
            return ""
        try:
            owner = gh_repo.owner.login
            for pr in gh_repo.get_pulls(state="open", head=f"{owner}:{branch}"):
                return pr.html_url
        except Exception:
            pass
        return ""

    def _check_prs_merged(self) -> bool:
        """Check if all PRs from the current wave are merged. Returns True if all merged."""
        if not self._wave_state or not self._wave_state.current_wave:
            return True

        gh_repo = self._get_gh_repo()
        if not gh_repo:
            logger.warning("Cannot check PRs — GitHub connection unavailable")
            return False

        unmerged = []
        for task_id in self._wave_state.current_wave:
            if task_id in self._wave_state.failed_tasks:
                continue  # Skip failed tasks

            branch = self._wave_state.agent_branches.get(task_id, "")
            if not branch:
                continue

            try:
                owner = gh_repo.owner.login
                merged = False
                for pr in gh_repo.get_pulls(state="all", head=f"{owner}:{branch}"):
                    if pr.merged:
                        merged = True
                        break
                if not merged:
                    unmerged.append(task_id)
            except Exception as e:
                logger.debug(f"PR check error for {task_id}: {e}")
                unmerged.append(task_id)

        if unmerged:
            logger.info(f"Waiting for PR merges: {unmerged}")
            return False

        return True

    def _advance_wave(self) -> None:
        """Mark current wave as complete and prepare for the next one."""
        from shypmate.manager.wave_planner import save_wave_state

        wave_idx = self._wave_state.current_wave_index
        self._wave_state.completed_waves.append(wave_idx)
        self._wave_state.current_wave_index = wave_idx + 1

        logger.info(f"Wave {wave_idx + 1} complete. Advancing to wave {wave_idx + 2}.")

        save_wave_state(self._wave_state, DATA_DIR)

    def _handle_new_tasks(self, new_tasks: list[dict]) -> None:
        """Slot new tasks into the wave plan or launch immediately if critical."""
        from shypmate.manager.wave_planner import slot_new_task, save_wave_state
        from shypmate.manager.project_brief import load_brief

        if not self._wave_state or not self._wave_state.plan:
            return

        brief = load_brief(BRIEF_DIR)
        provider = self._get_provider()

        for task in new_tasks:
            if task.get("priority") == "critical":
                # Launch immediately, bypass wave ordering
                logger.info(f"Critical task {task['id']} — launching immediately")
                self._launch_wave([task["id"]])
                continue

            # Slot into the plan
            updated_plan, target_wave = slot_new_task(
                self._wave_state.plan,
                task,
                self._wave_state.current_wave_index,
                brief,
                provider,
            )
            self._wave_state.plan = updated_plan

            if target_wave == self._wave_state.current_wave_index:
                # Can run with current wave — launch now
                logger.info(f"New task {task['id']} slotted into current wave — launching")
                self._launch_wave([task["id"]])
            else:
                logger.info(f"New task {task['id']} slotted into wave {target_wave + 1}")

        save_wave_state(self._wave_state, DATA_DIR)

    # ── Task Planning (per-task, for individual plans) ──

    def _plan_individual_tasks(self, tasks: list[dict]) -> None:
        """Generate per-task plans for tasks that don't have one yet."""
        from shypmate.manager.project_brief import (
            load_brief, load_task_plan, generate_task_plan, save_task_plan,
        )

        brief = load_brief(BRIEF_DIR)
        if not brief:
            return

        provider = self._get_provider()
        for task in tasks:
            existing = load_task_plan(task["id"], BRIEF_DIR)
            if existing:
                continue
            logger.info(f"Planning task {task['id']}: {task['description'][:60]}...")
            plan = generate_task_plan(task["id"], task["description"], brief, provider)
            save_task_plan(plan, BRIEF_DIR)

    # ── Retrospective & Observation System ──

    def _retrospective(self, container) -> None:
        """Review container logs and accumulate observations.

        Flow:
        1. Feed agent logs to LLM for structured analysis
        2. Record each finding as an observation in manager_state.json
        3. Log the manager's reasoning (thoughts)
        4. Do NOT propose to human yet — that happens in _evaluate_observations()
           when enough evidence accumulates across multiple retrospectives
        """
        from shypmate.manager.manager_state import record_observation, record_manager_thought

        try:
            task_desc = ""
            agent_id = ""
            for env_str in container.attrs.get("Config", {}).get("Env", []):
                if env_str.startswith("AGENT_TASK="):
                    task_desc = env_str.split("=", 1)[1]
                elif env_str.startswith("AGENT_ID="):
                    agent_id = env_str.split("=", 1)[1]

            logs = container.logs(tail=200).decode("utf-8", errors="replace")
            if not logs.strip():
                return

            provider = self._get_provider()

            prompt = f"""Review these agent container logs and provide a structured retrospective.
The agent was working on: {task_desc}

LOGS:
{logs}

Respond in this exact JSON format (no markdown, just raw JSON):
{{
  "outcome": "PASS or FAIL",
  "outcome_reason": "brief reason",
  "wasted_iterations": ["description of each wasted iteration"],
  "observations": [
    {{
      "type": "repeated_install",
      "pattern": "package-name",
      "detail": "what happened and why it was wasteful"
    }},
    {{
      "type": "prompt_improvement",
      "pattern": "short pattern key",
      "detail": "what guidance would have prevented the mistake"
    }},
    {{
      "type": "missing_tool",
      "pattern": "tool or capability name",
      "detail": "what the agent needed but didn't have"
    }},
    {{
      "type": "quota_hit",
      "pattern": "which limit was hit",
      "detail": "why the agent ran out of iterations/cost"
    }},
    {{
      "type": "shell_denied",
      "pattern": "the command prefix",
      "detail": "what the agent tried to run"
    }}
  ]
}}

Observation types:
- repeated_install: agent installed a package at runtime (wasting iterations)
- prompt_improvement: agent made a mistake a prompt addition could prevent
- missing_tool: agent needed a capability it didn't have
- quota_hit: agent ran out of iterations/cost before finishing
- shell_denied: agent tried a command not in the allowlist
- wasted_read: agent read entire large files unnecessarily
- general: anything else notable

Only include observations that would save time/money on FUTURE runs.
If nothing notable, return empty observations array."""

            response = provider.chat(
                system_prompt="You are reviewing AI agent execution logs for process improvements. Respond with valid JSON only.",
                messages=[{"role": "user", "content": prompt}],
            )

            retro_text = ""
            for block in response.content:
                if hasattr(block, "text"):
                    retro_text = block.text
                    break

            if not retro_text.strip():
                return

            retro_data = json.loads(retro_text)
            # Write state to mounted .shypmate/ dir (persisted to host)
            project_root = str(self._shypmate_dir)

            outcome = retro_data.get("outcome", "?")
            reason = retro_data.get("outcome_reason", "")
            logger.info(f"Retrospective for {container.name}: {outcome} — {reason}")

            # Record manager's thinking
            wasted = retro_data.get("wasted_iterations", [])
            if wasted:
                thought = (
                    f"Reviewed {container.name} (task: {task_desc[:60]}). "
                    f"Outcome: {outcome}. Wasted iterations: {', '.join(wasted)}"
                )
            else:
                thought = (
                    f"Reviewed {container.name} (task: {task_desc[:60]}). "
                    f"Outcome: {outcome}. {reason}. No significant waste detected."
                )
            record_manager_thought(project_root, thought)

            # Record each observation — accumulates evidence across runs
            observations = retro_data.get("observations", [])
            for obs in observations:
                obs_type = obs.get("type", "general")
                pattern = obs.get("pattern", "unknown")
                detail = obs.get("detail", "")

                recorded = record_observation(
                    project_root,
                    obs_type=obs_type,
                    pattern=pattern,
                    detail=detail,
                    container_name=container.name,
                    agent_id=agent_id,
                )

                logger.info(
                    f"  Observation [{obs_type}] '{pattern}': "
                    f"{recorded['occurrences']}/{recorded['threshold']} "
                    f"({'READY to propose' if recorded['occurrences'] >= recorded['threshold'] else 'accumulating'})"
                )

                if recorded["occurrences"] >= recorded["threshold"]:
                    record_manager_thought(
                        project_root,
                        f"Pattern '{pattern}' ({obs_type}) reached threshold "
                        f"({recorded['occurrences']}/{recorded['threshold']}). "
                        f"Will propose to human."
                    )

            # Save raw retrospective for audit trail
            retro_dir = DATA_DIR / "retrospectives"
            retro_dir.mkdir(parents=True, exist_ok=True)
            retro_file = retro_dir / f"{agent_id or container.name}.json"
            retro_data["task"] = task_desc
            retro_data["container"] = container.name
            retro_data["date"] = datetime.now(timezone.utc).isoformat()
            retro_file.write_text(json.dumps(retro_data, indent=2), encoding="utf-8")

        except json.JSONDecodeError:
            logger.warning(f"Retrospective for {container.name}: non-JSON response")
            record_manager_thought(
                str(self._shypmate_dir),
                f"Retrospective for {container.name} returned non-JSON. Skipped observation recording."
            )
        except Exception as e:
            logger.warning(f"Retrospective failed for {container.name}: {e}")

    def _evaluate_observations(self) -> None:
        """Check if any observations have crossed their threshold and propose to human.

        This is called each poll cycle. It:
        1. Finds observations that are ready (occurrences >= threshold)
        2. Converts them into proposals
        3. Sends to the human via request_human_input
        4. Marks observations as 'proposed'
        """
        from shypmate.manager.manager_state import (
            get_ready_observations,
            mark_proposed,
            record_manager_thought,
        )

        project_root = str(self._shypmate_dir)
        ready = get_ready_observations(project_root)
        if not ready:
            return

        # Map observation types to proposal types for manager.yml
        type_map = {
            "repeated_install": "test_dependency",
            "prompt_improvement": "prompt_addition",
            "missing_tool": "prompt_addition",  # until we have dynamic tool loading
            "wasted_read": "prompt_addition",
            "shell_denied": "prompt_addition",
            "quota_hit": "learned_rule",
            "general": "learned_rule",
        }

        proposals = []
        observation_ids = []
        for obs in ready:
            obs_type = obs["type"]
            proposal_type = type_map.get(obs_type, "learned_rule")
            evidence_summary = "; ".join(e["detail"] for e in obs["evidence"][-3:])

            if proposal_type == "test_dependency":
                value = obs["pattern"]
            else:
                # For prompt/rule proposals, summarize the evidence
                value = f"{obs['pattern']}: {evidence_summary}"

            proposals.append({
                "type": proposal_type,
                "value": value,
                "reason": f"Seen {obs['occurrences']} times across agent runs",
                "observation_id": obs["id"],
            })
            observation_ids.append(obs["id"])

        if not proposals:
            return

        record_manager_thought(
            project_root,
            f"Proposing {len(proposals)} improvement(s) to human: "
            + ", ".join(p["value"][:40] for p in proposals)
        )

        # Build human-readable question
        lines = [
            "The manager has accumulated enough evidence to propose improvements:\n"
        ]
        for i, p in enumerate(proposals, 1):
            ptype = p["type"]
            value = p["value"]
            reason = p["reason"]
            lines.append(f"  {i}. [{ptype}] {value}")
            lines.append(f"     Evidence: {reason}")

        lines.append(
            "\nThese will be saved to .shypmate/manager.yml for future agent runs."
        )
        lines.append(
            "Reply 'yes' to approve all, 'no' to skip, "
            "or list numbers to approve selectively (e.g. '1,3')."
        )

        question = "\n".join(lines)

        # Write proposal request
        comms_dir = self._comms_dir_internal if self._shypmate_dir.exists() else None
        if not comms_dir:
            logger.info(f"No comms dir — logging proposals only:\n{question}")
            return

        request_id = f"retro-batch-{uuid.uuid4().hex[:8]}"
        request_file = comms_dir / f"{request_id}.request.json"

        request_data = {
            "agent_id": "manager",
            "question": question,
            "context": "Manager batch proposal from accumulated observations",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "proposals": proposals,
        }

        request_file.write_text(json.dumps(request_data, indent=2), encoding="utf-8")
        logger.info(f"Proposed {len(proposals)} improvement(s) — waiting for human approval")

        # Mark observations as proposed so they're not re-proposed
        for obs_id in observation_ids:
            mark_proposed(project_root, obs_id)

    def _check_pending_proposals(self) -> None:
        """Check for human responses to retrospective proposals."""
        from shypmate.manager.manager_config import (
            add_test_dependency,
            add_prompt_addition,
            add_learned_rule,
        )
        from shypmate.manager.manager_state import mark_resolved, record_manager_thought

        comms_dir = self._comms_dir_internal if self._shypmate_dir.exists() else None
        if not comms_dir or not comms_dir.exists():
            return

        for response_file in comms_dir.glob("retro-*.response.json"):
            try:
                response_data = json.loads(response_file.read_text(encoding="utf-8"))
                answer = response_data.get("response", "").strip().lower()

                request_id = response_file.stem.replace(".response", "")
                request_file = comms_dir / f"{request_id}.request.json"
                if not request_file.exists():
                    response_file.unlink()
                    continue

                request_data = json.loads(request_file.read_text(encoding="utf-8"))
                proposals = request_data.get("proposals", [])

                if not proposals:
                    request_file.unlink()
                    response_file.unlink()
                    continue

                # Determine which proposals are approved
                if answer in ("yes", "y", "approve", "all"):
                    approved_indices = list(range(len(proposals)))
                elif answer in ("no", "n", "skip", "none"):
                    approved_indices = []
                else:
                    try:
                        approved_indices = [int(x.strip()) - 1 for x in answer.split(",")]
                    except ValueError:
                        approved_indices = []

                project_root = str(self._shypmate_dir)

                for idx, p in enumerate(proposals):
                    obs_id = p.get("observation_id", "")
                    approved = idx in approved_indices
                    ptype = p.get("type", "")
                    value = p.get("value", "")
                    source = request_data.get("context", "")

                    if approved:
                        if ptype == "test_dependency":
                            add_test_dependency(project_root, value, source)
                            logger.info(f"Approved: test dependency '{value}'")
                        elif ptype == "prompt_addition":
                            add_prompt_addition(project_root, value, source)
                            logger.info(f"Approved: prompt addition '{value[:60]}...'")
                        elif ptype == "learned_rule":
                            add_learned_rule(project_root, value, source)
                            logger.info(f"Approved: learned rule '{value[:60]}...'")

                    if obs_id:
                        mark_resolved(
                            project_root, obs_id,
                            response="yes" if approved else "no",
                            action_taken=f"{'added' if approved else 'skipped'} {ptype}: {value[:40]}",
                        )

                record_manager_thought(
                    project_root,
                    f"Human responded to batch proposal: '{answer}'. "
                    f"Approved {len(approved_indices)}/{len(proposals)}."
                )

                request_file.unlink()
                response_file.unlink()

            except Exception as e:
                logger.warning(f"Error processing proposal response {response_file}: {e}")

    # ── Cleanup ──

    def cleanup_merged(self):
        """Remove containers for merged/closed PRs. Runs retrospective before deletion."""
        try:
            import docker
            client = docker.from_env()
            gh_repo = self._get_gh_repo()
            if not gh_repo:
                return

            containers = client.containers.list(
                all=True, filters={"name": "shypmate-", "status": "exited"}
            )

            for c in containers:
                if c.name in ("shypmate-manager", "shypmate-verify"):
                    continue

                branch = ""
                try:
                    for env in c.attrs.get("Config", {}).get("Env", []):
                        if env.startswith("AGENT_BRANCH="):
                            branch = env.split("=", 1)[1]
                            break
                except Exception:
                    pass

                if not branch:
                    continue

                try:
                    owner = gh_repo.owner.login
                    for pr in gh_repo.get_pulls(state="all", head=f"{owner}:{branch}"):
                        if pr.merged or pr.state == "closed":
                            # Run retrospective before removing
                            self._retrospective(c)
                            logger.info(f"Cleaning up {c.name} (PR {pr.state})")
                            c.remove()
                            break
                except Exception:
                    pass

        except Exception as e:
            logger.error(f"Cleanup error: {e}")

    # ── Main Poll Loop ──

    def poll(self):
        """One poll cycle: manage waves, monitor agents, handle new tasks."""
        from shypmate.manager.wave_planner import save_wave_state, load_wave_state

        # 1. Ensure brief is ready
        try:
            self.ensure_brief()
        except Exception as e:
            logger.error(f"Brief generation error: {e}")

        # 2. Load current pending tasks
        pending = self._load_pending_tasks()

        # 3. Detect new tasks
        new_tasks = self._detect_new_tasks(pending)
        if new_tasks:
            logger.info(f"Detected {len(new_tasks)} new task(s)")

        # 4. If no wave state and there are pending tasks → create initial wave plan
        if not self._wave_state and pending:
            self._plan_waves(pending)
            # Generate per-task plans
            self._plan_individual_tasks(pending)
            # Launch wave 1
            if self._wave_state and self._wave_state.current_wave:
                logger.info(f"Launching Wave 1: {self._wave_state.current_wave}")
                self._launch_wave(self._wave_state.current_wave)

        # 5. If wave is running, check for completion
        elif self._wave_state and not self._wave_state.is_complete:
            wave_done = self._check_wave_completion()

            if wave_done:
                # Check if PRs are merged before advancing
                prs_merged = self._check_prs_merged()

                if prs_merged:
                    self._advance_wave()

                    # Re-fetch repo to get merged changes
                    self._clone_or_fetch()

                    # If there are more waves, re-analyze and launch next
                    if not self._wave_state.is_complete:
                        remaining_pending = self._load_pending_tasks()
                        if remaining_pending:
                            # Re-analyze remaining tasks against updated repo
                            logger.info("Re-analyzing remaining tasks after merge...")
                            self._plan_waves(remaining_pending)
                            self._plan_individual_tasks(remaining_pending)
                            if self._wave_state.current_wave:
                                logger.info(f"Launching next wave: {self._wave_state.current_wave}")
                                self._launch_wave(self._wave_state.current_wave)
                        else:
                            logger.info("All tasks complete!")
                            self._wave_state = None
                    else:
                        logger.info("All waves complete!")
                        self._wave_state = None

            # Handle new tasks mid-wave
            if new_tasks and self._wave_state:
                # Plan individual tasks first
                self._plan_individual_tasks(new_tasks)
                self._handle_new_tasks(new_tasks)

        # 6. No active wave state but new tasks arrived → fresh plan
        elif self._wave_state is None and new_tasks:
            all_pending = self._load_pending_tasks()
            if all_pending:
                self._plan_waves(all_pending)
                self._plan_individual_tasks(all_pending)
                if self._wave_state and self._wave_state.current_wave:
                    logger.info(f"Launching Wave 1: {self._wave_state.current_wave}")
                    self._launch_wave(self._wave_state.current_wave)

        # 7. Save state
        if self._wave_state:
            save_wave_state(self._wave_state, DATA_DIR)

        # 8. Check for human responses to retrospective proposals
        try:
            self._check_pending_proposals()
        except Exception as e:
            logger.warning(f"Proposal check error: {e}")

        # 9. Evaluate accumulated observations — propose to human if threshold reached
        try:
            self._evaluate_observations()
        except Exception as e:
            logger.warning(f"Observation evaluation error: {e}")

        # 10. Cleanup merged containers (runs retrospective before deletion)
        try:
            self.cleanup_merged()
        except Exception as e:
            logger.error(f"Cleanup error: {e}")

    def run(self):
        """Main loop — poll on interval."""
        from shypmate.manager.wave_planner import load_wave_state

        logger.info("=" * 60)
        logger.info("Shypmate Manager started")
        logger.info(f"  Repo: {self.repo_name}")
        logger.info(f"  Base branch: {self.base_branch}")
        logger.info(f"  LLM: {self.llm_provider_name} / {self.llm_model}")
        logger.info(f"  Execution mode: {self.execution_mode}")
        logger.info(f"  Poll interval: {self.poll_interval}s")
        logger.info(f"  Agent image: {self.agent_image}")
        logger.info("=" * 60)

        # Try to resume from saved state
        saved = load_wave_state(DATA_DIR)
        if saved and saved.plan and not saved.is_complete:
            logger.info(f"Resuming from wave {saved.current_wave_index + 1}")
            self._wave_state = saved
            # Rebuild known task IDs from the plan
            self._known_task_ids = saved.plan.all_task_ids()

        # Initial poll immediately
        self.poll()

        while True:
            try:
                time.sleep(self.poll_interval)
                self.poll()
            except KeyboardInterrupt:
                logger.info("Manager stopped")
                break
            except Exception as e:
                logger.error(f"Poll error: {e}", exc_info=True)
                time.sleep(self.poll_interval)


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    manager = Manager()
    return manager.run()


if __name__ == "__main__":
    sys.exit(main() or 0)
