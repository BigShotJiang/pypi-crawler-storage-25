"""
Pipeline coordinator — runs hats in sequence for a task.

Launches each hat as a container, monitors results, handles retries,
and opens the PR when the pipeline completes successfully.
"""

import logging
import os
from datetime import datetime, timezone
from pathlib import Path

from shypmate.hats.hat import Hat, get_default_hats
from shypmate.hats.pipeline import (
    Pipeline,
    PipelineStage,
    build_pipeline,
    get_hat_task_prompt,
    load_pipeline,
    save_pipeline,
)

logger = logging.getLogger(__name__)


def load_hats_from_config() -> dict[str, Hat]:
    """Load hat configurations from project config (yml + py).

    Merges built-in hats with user-defined hats from shypmate.yml or shypmate.py.
    """
    hats = get_default_hats()

    try:
        from shypmate.config.project import PROJECT, _load_yaml_config, _load_py_config, _find_project_root

        root = _find_project_root()
        py_config, _ = _load_py_config(root)
        yml = _load_yaml_config(root)

        # Merge: yml > py > defaults
        hat_config = py_config.get("hats", {})
        hat_config.update(yml.get("hats", {}))

        for name, config in hat_config.items():
            if isinstance(config, dict):
                if name in hats:
                    # Override existing hat
                    hat = hats[name]
                    if "enabled" in config:
                        hat.enabled = config["enabled"]
                    if "prompt" in config:
                        hat.prompt = config["prompt"]
                    if "tools" in config:
                        hat.tools = config["tools"]
                    if "max_cost" in config:
                        hat.max_cost = config["max_cost"]
                    if "max_iterations" in config:
                        hat.max_iterations = config["max_iterations"]
                    if "max_seconds" in config:
                        hat.max_seconds = config["max_seconds"]
                    if "validation_commands" in config:
                        hat.validation_commands = config["validation_commands"]
                else:
                    # New custom hat
                    hats[name] = Hat(
                        name=name,
                        prompt=config.get("prompt", f"You are a {name} specialist."),
                        tools=config.get("tools", []),
                        enabled=config.get("enabled", True),
                        max_cost=config.get("max_cost", 0.0),
                        max_iterations=config.get("max_iterations", 0),
                        max_seconds=config.get("max_seconds", 0),
                        validation_commands=config.get("validation_commands", []),
                    )
    except Exception as e:
        logger.debug(f"Could not load hat config: {e}")

    return hats


def parse_hat_outcome(hat_name: str, output: str) -> tuple[str, str]:
    """Parse the hat's output to determine pass/fail.

    Returns (status, feedback) where status is 'passed' or 'failed'.
    """
    if not output:
        return "failed", "No output from agent."

    # Hard quota stop is always a failure — the agent didn't finish its work
    if output.startswith("AGENT STOPPED:"):
        return "failed", output

    # Strip markdown formatting (**, *, `) from the first word
    first_word = output.strip().split()[0].strip("*`_#").upper() if output.strip() else ""

    if hat_name == "qa":
        # Check first word (the intended format)
        if first_word == "QA_PASS":
            return "passed", ""
        elif first_word == "QA_FAIL":
            return "failed", output

        # Agent may have said QA_PASS/QA_FAIL mid-output (not as the final message).
        # Scan the full output for the verdict keyword.
        import re
        # Match QA_PASS or **QA_PASS** anywhere in the output
        if re.search(r'\bQA_PASS\b', output):
            return "passed", ""
        if re.search(r'\bQA_FAIL\b', output):
            return "failed", output

        # No verdict found — treat as failure (QA must be explicit)
        return "failed", f"QA did not provide a verdict (QA_PASS or QA_FAIL). Output: {output[:200]}"

    elif hat_name == "product_owner":
        if first_word == "PO_APPROVE":
            return "passed", ""
        elif first_word == "PO_REJECT":
            return "failed", output

        import re
        if re.search(r'\bPO_APPROVE\b', output):
            return "passed", ""
        if re.search(r'\bPO_REJECT\b', output):
            return "failed", output

        return "failed", f"PO did not provide a verdict (PO_APPROVE or PO_REJECT). Output: {output[:200]}"

    elif hat_name == "developer":
        # Developer always "passes" — QA determines if the code is good
        return "passed", ""

    else:
        # Custom hat — look for generic pass/fail signals
        first_word_lower = first_word.lower()
        if first_word_lower in ("pass", "passed", "approve", "approved", "lgtm"):
            return "passed", ""
        elif first_word_lower in ("fail", "failed", "reject", "rejected"):
            return "failed", output
        return "passed", ""  # default to pass for custom hats


def parse_developer_output(output: str) -> dict:
    """Parse the developer's structured output into context fields.

    Looks for FILES_CHANGED:, COMMITS:, TEST_INSTRUCTIONS:, SUMMARY: markers.
    """
    result = {
        "files_changed": [],
        "commits": [],
        "test_instructions": "",
        "summary": "",
    }

    current_field = None
    current_lines = []

    for line in output.splitlines():
        stripped = line.strip()
        upper = stripped.upper()

        if upper.startswith("FILES_CHANGED:"):
            if current_field:
                _save_parsed(result, current_field, current_lines)
            current_field = "files_changed"
            current_lines = [stripped.split(":", 1)[1].strip()]
        elif upper.startswith("COMMITS:"):
            if current_field:
                _save_parsed(result, current_field, current_lines)
            current_field = "commits"
            current_lines = [stripped.split(":", 1)[1].strip()]
        elif upper.startswith("TEST_INSTRUCTIONS:"):
            if current_field:
                _save_parsed(result, current_field, current_lines)
            current_field = "test_instructions"
            current_lines = [stripped.split(":", 1)[1].strip()]
        elif upper.startswith("SUMMARY:"):
            if current_field:
                _save_parsed(result, current_field, current_lines)
            current_field = "summary"
            current_lines = [stripped.split(":", 1)[1].strip()]
        elif current_field:
            current_lines.append(stripped)

    if current_field:
        _save_parsed(result, current_field, current_lines)

    return result


def _save_parsed(result: dict, field: str, lines: list[str]) -> None:
    """Save parsed lines into the appropriate result field."""
    text = "\n".join(l for l in lines if l).strip()
    if field in ("files_changed", "commits"):
        # Parse comma-separated or line-by-line lists
        items = []
        for line in lines:
            for item in line.replace(",", "\n").splitlines():
                item = item.strip().lstrip("- ")
                if item:
                    items.append(item)
        result[field] = items
    else:
        result[field] = text


def get_comms_dir() -> Path:
    """Get the comms directory path."""
    try:
        from shypmate.config.project import PROJECT
        comms = Path(PROJECT.project_root) / ".shypmate" / "comms"
    except Exception:
        comms = Path(".shypmate") / "comms"
    comms.mkdir(parents=True, exist_ok=True)
    return comms
