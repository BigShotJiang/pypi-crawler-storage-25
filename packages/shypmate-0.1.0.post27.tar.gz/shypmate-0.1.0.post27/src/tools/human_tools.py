"""
Human interaction tools — allows agents to request input from a human.

The agent calls request_human_input(question) when it's stuck or needs a decision.
The request is written to the pipeline context JSON and the agent polls for a response
in the same file. One file, one source of truth.

Communication happens via the mounted .shypmate/ volume at /dot-shypmate.
"""

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

# Pipeline context location (mounted from host's .shypmate/)
PIPELINE_CTX_DIR = Path("/dot-shypmate/comms/pipeline_context")


def _get_ctx_path() -> Path:
    """Get the pipeline context file path for this agent."""
    agent_id = os.environ.get("AGENT_ID", "unknown")
    return PIPELINE_CTX_DIR / f"{agent_id}.json"


def _load_ctx() -> dict:
    """Load the pipeline context JSON."""
    path = _get_ctx_path()
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"pipeline_id": os.environ.get("AGENT_ID", "unknown"), "stages": []}


def _save_ctx(ctx: dict) -> None:
    """Save the pipeline context JSON."""
    path = _get_ctx_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(ctx, indent=2), encoding="utf-8")


def request_human_input(question: str, context: str = "") -> str:
    """Ask a human for help when you are stuck or need a decision.

    Use this when:
    - You encounter an ambiguous requirement and need clarification
    - You're unsure which approach to take and want guidance
    - You hit an error you can't resolve on your own
    - The task description is unclear

    Args:
        question: The specific question you need answered. Be clear and concise.
        context: Optional context about what you've tried or what you're seeing.

    Returns:
        The human's response.
    """
    agent_id = os.environ.get("AGENT_ID", "unknown")
    request_id = f"{agent_id}-{int(time.time())}"

    request_data = {
        "id": request_id,
        "agent_id": agent_id,
        "question": question,
        "context": context,
        "task": os.environ.get("AGENT_TASK", ""),
        "requested_at": datetime.now(timezone.utc).isoformat(),
        "response": None,
    }

    # Write to pipeline context JSON
    ctx = _load_ctx()
    ctx["pending_input"] = request_data
    _save_ctx(ctx)

    logger.warning(f"AGENT NEEDS HUMAN INPUT")
    logger.warning(f"  Agent:    {agent_id}")
    logger.warning(f"  Question: {question}")
    if context:
        logger.warning(f"  Context:  {context}")
    logger.warning(f"  Request:  {request_id}")
    logger.warning(f"Waiting for response...")

    # Poll the same file for a response
    poll_interval = 5  # seconds
    while True:
        try:
            ctx = _load_ctx()
            pending = ctx.get("pending_input")
            if pending and pending.get("id") == request_id and pending.get("response") is not None:
                answer = pending["response"]
                logger.info(f"Human responded: {answer[:200]}")
                # Clear pending_input
                ctx.pop("pending_input", None)
                _save_ctx(ctx)
                return answer
        except Exception as e:
            logger.warning(f"Error checking for response: {e}")

        time.sleep(poll_interval)
