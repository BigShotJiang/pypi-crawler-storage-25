"""
Shell tools for the dev agent.

Provides constrained shell access — only pre-approved commands can run.
The agent cannot execute arbitrary shell commands.
"""

import logging
import os
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

WORKSPACE = "/workspace"

# Built-in allowed command prefixes — always available
_BUILTIN_ALLOWED_PREFIXES = (
    "ruff ",
    "pytest ",
    "pip install",
    "pip list",
    "pip show",
    "cat ",
    "head ",
    "tail ",
    "wc ",
    "diff ",
    "find ",
    "ls ",
    "grep ",
    "git ",
)

# Built-in blocked patterns — always blocked
_BUILTIN_BLOCKED_PATTERNS = (
    "rm -rf",
    "rm -r /",
    "DROP ",
    "DELETE FROM",
    "TRUNCATE",
    "FLUSHALL",
    "FLUSHDB",
)


def _get_allowed_prefixes() -> tuple[str, ...]:
    """Merge built-in allowlist with project-specific additions from shypmate.yml."""
    try:
        from shypmate.config.project import PROJECT
        return _BUILTIN_ALLOWED_PREFIXES + PROJECT.allowed_shell_prefixes
    except Exception:
        return _BUILTIN_ALLOWED_PREFIXES


def _get_blocked_patterns() -> tuple[str, ...]:
    """Merge built-in blocklist with project-specific additions from shypmate.yml."""
    try:
        from shypmate.config.project import PROJECT
        return _BUILTIN_BLOCKED_PATTERNS + PROJECT.blocked_shell_patterns
    except Exception:
        return _BUILTIN_BLOCKED_PATTERNS


def _normalize_command(command: str) -> str:
    """Strip harmless prefixes that agents commonly add before the real command.

    Handles patterns like:
      cd /workspace && pytest ...  →  pytest ...
      cd /workspace; pytest ...    →  pytest ...
    """
    import re
    cmd = command.strip()
    # Strip "cd <path> &&" or "cd <path>;" prefix
    cmd = re.sub(r'^cd\s+\S+\s*&&\s*', '', cmd)
    cmd = re.sub(r'^cd\s+\S+\s*;\s*', '', cmd)
    return cmd.strip()


def _is_allowed(command: str) -> tuple[bool, str]:
    """Check if a command is in the allowlist and not blocked."""
    cmd = command.strip()
    blocked_patterns = _get_blocked_patterns()
    allowed_prefixes = _get_allowed_prefixes()

    for blocked in blocked_patterns:
        if blocked.lower() in cmd.lower():
            return False, f"Blocked: command contains '{blocked}'"

    # Check the raw command and the normalized version (with cd prefix stripped)
    normalized = _normalize_command(cmd)
    # Also resolve absolute paths (e.g., /usr/local/bin/pytest → pytest)
    basename = normalized.split()[0].rsplit("/", 1)[-1] + " " if normalized else ""
    for prefix in allowed_prefixes:
        if cmd.startswith(prefix) or normalized.startswith(prefix) or basename.startswith(prefix):
            return True, ""

    return False, (
        f"Command not in allowlist. Allowed prefixes: {', '.join(allowed_prefixes)}"
    )



def run_shell_command(command: str, working_dir: str = "") -> str:
    """Run a constrained shell command in the workspace.

    Only pre-approved commands are allowed. The agent cannot run arbitrary commands.

    Args:
        command: The shell command to run.
        working_dir: Working directory relative to workspace (default: workspace root).
    """
    return _run_command(command, working_dir)


def _run_command(command: str, working_dir: str = "") -> str:
    """Internal helper to run a validated shell command."""
    allowed, reason = _is_allowed(command)
    if not allowed:
        return f"DENIED: {reason}"

    cwd = WORKSPACE
    if working_dir:
        cwd = str(Path(WORKSPACE) / working_dir)

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=cwd,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += "\nSTDERR:\n" + result.stderr
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "Command timed out after 120 seconds"
    except Exception as e:
        return f"Error running command: {e}"



def _get_new_files() -> list[str]:
    """Get list of NEW (untracked) Python files — files the agent created."""
    try:
        result = subprocess.run(
            "git ls-files --others --exclude-standard",
            shell=True, capture_output=True, text=True, cwd=WORKSPACE,
        )
        files = [f.strip() for f in result.stdout.strip().splitlines() if f.strip()]
        return [f for f in files if f.endswith(".py")]
    except Exception:
        return []


def _get_modified_files() -> list[str]:
    """Get list of MODIFIED (tracked, changed) Python files."""
    try:
        result = subprocess.run(
            "git diff --name-only HEAD 2>/dev/null",
            shell=True, capture_output=True, text=True, cwd=WORKSPACE,
        )
        files = [f.strip() for f in result.stdout.strip().splitlines() if f.strip()]
        return [f for f in files if f.endswith(".py")]
    except Exception:
        return []


def run_ruff_check(path: str = "", fix: bool = False, all_files: bool = False) -> str:
    """Run ruff linter. By default only checks NEW files you created.

    Reports issues without auto-fixing to prevent changes to existing code.

    Args:
        path: Specific path to check. Leave empty to auto-detect new files.
        fix: Whether to auto-fix issues (default False — report only).
        all_files: Set to True to check all files (e.g. for a cleanup task).
    """
    if path:
        target = path
    elif all_files:
        target = "."
    else:
        # Only check NEW files by default. Checking modified files
        # with --fix would auto-correct pre-existing issues and pollute the diff.
        new_files = _get_new_files()
        if not new_files:
            return "No new Python files to check."
        target = " ".join(new_files)

    cmd = f"ruff check {'--fix ' if fix else ''}{target}"
    return _run_command(cmd)


def run_ruff_format(path: str = "", all_files: bool = False, check_only: bool = False) -> str:
    """Run ruff formatter. By default only formats NEW files you created — never reformats existing files.

    This prevents formatting-only changes from polluting your diff.

    Args:
        path: Specific path to format. Leave empty to auto-detect new files only.
        all_files: Set to True to format all files (e.g. for a cleanup task).
        check_only: If True, only check formatting without modifying files.
    """
    if path:
        target = path
    elif all_files:
        target = "."
    else:
        # ONLY format NEW files, not modified existing files.
        # Formatting modified files rewrites the whole file and pollutes the diff.
        new_files = _get_new_files()
        if not new_files:
            return "No new Python files to format. (Modified files are not reformatted to keep diffs clean.)"
        target = " ".join(new_files)

    check_flag = "--check " if check_only else ""
    cmd = f"ruff format {check_flag}{target}"
    return _run_command(cmd)
