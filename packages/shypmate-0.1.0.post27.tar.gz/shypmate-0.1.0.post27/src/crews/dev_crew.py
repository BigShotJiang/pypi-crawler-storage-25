"""
Dev crew — assembles and runs a single dev agent for one task.
"""

import logging
import os

from shypmate.agents.dev_agent import build_system_prompt, create_tool_registry
from shypmate.config.project import PROJECT
from shypmate.engine.agent_loop import run_agent, AgentQuota
from shypmate.engine.providers import create_provider
from shypmate.tasks.dev_task import build_task_prompt

logger = logging.getLogger(__name__)


def run_dev_crew(
    task_description: str,
    branch_name: str,
    project_context: str = "",
    is_rebase: bool = False,
) -> str:
    """
    Build and run a dev agent for a single task.

    Returns the agent's final output as a string.
    """
    # Resolve the API key from the configured env var name
    api_key = os.environ.get(PROJECT.llm_api_key_var, "") if PROJECT.llm_api_key_var else None

    premium_provider = create_provider(
        provider=PROJECT.llm_provider,
        model=PROJECT.llm_model,
        max_tokens=PROJECT.llm_max_tokens,
        base_url=PROJECT.llm_base_url or None,
        api_key=api_key or None,
    )

    # Build the effective provider — wrap in TierRouter if economy tier is configured
    if PROJECT.tier_routing and PROJECT.economy_provider:
        from shypmate.engine.tier_router import TierRouter
        from shypmate.config.project import get_user_hook

        economy_api_key = os.environ.get(PROJECT.economy_api_key_var, "") if PROJECT.economy_api_key_var else None
        economy_provider = create_provider(
            provider=PROJECT.economy_provider,
            model=PROJECT.economy_model,
            max_tokens=PROJECT.economy_max_tokens,
            base_url=PROJECT.economy_base_url or None,
            api_key=economy_api_key or None,
        )
        provider = TierRouter(
            premium=premium_provider,
            economy=economy_provider,
            classify_hook=get_user_hook("classify_tier"),
        )
        logger.info(f"Tier routing enabled: premium={PROJECT.llm_model}, economy={PROJECT.economy_model}")
    else:
        provider = premium_provider

    # Collect manager-learned guidance if available
    from pathlib import Path
    manager_additions = ""
    manager_yml = Path("/dot-shypmate") / "manager.yml"
    if manager_yml.exists():
        try:
            import yaml
            mgr = yaml.safe_load(manager_yml.read_text(encoding="utf-8")) or {}
            parts = []
            for a in mgr.get("prompt_additions", []):
                parts.append(a["text"] if isinstance(a, dict) else a)
            for r in mgr.get("learned_rules", []):
                parts.append(r["rule"] if isinstance(r, dict) else r)
            if parts:
                manager_additions = "MANAGER-LEARNED GUIDANCE (from retrospectives):\n" + "\n".join(
                    f"- {p}" for p in parts
                )
        except Exception:
            pass

    # Load developer preferences
    try:
        from shypmate.manager.preferences import format_for_prompt
        dev_prefs = format_for_prompt("/dot-shypmate")
        if dev_prefs:
            manager_additions = (manager_additions + "\n\n" + dev_prefs) if manager_additions else dev_prefs
    except Exception:
        pass

    # Build guarded system prompt — core rules protected from overrides
    from shypmate.agents.dev_agent import _build_core_prompt
    from shypmate.engine.prompt_guard import build_guarded_system_prompt

    system_prompt = build_guarded_system_prompt(
        core_prompt=_build_core_prompt(),
        project_context=project_context,
        manager_additions=manager_additions,
    )

    task_prompt = build_task_prompt(
        task_description=task_description,
        branch_name=branch_name,
        is_rebase=is_rebase,
    )
    registry = create_tool_registry()

    logger.info(f"Running agent with {len(registry.tool_names)} tools: {registry.tool_names}")

    # Build quota from project config
    quota = AgentQuota(
        soft_max_tokens=PROJECT.soft_max_tokens,
        soft_max_cost=PROJECT.soft_max_cost,
        soft_max_seconds=PROJECT.soft_max_seconds,
        soft_max_iterations=PROJECT.soft_max_iterations,
        hard_max_tokens=PROJECT.hard_max_tokens,
        hard_max_cost=PROJECT.hard_max_cost,
        hard_max_seconds=PROJECT.hard_max_seconds,
        hard_max_iterations=PROJECT.hard_max_iterations,
    )

    return run_agent(
        provider=provider,
        system_prompt=system_prompt,
        task_prompt=task_prompt,
        registry=registry,
        max_iterations=50,
        quota=quota,
    )
