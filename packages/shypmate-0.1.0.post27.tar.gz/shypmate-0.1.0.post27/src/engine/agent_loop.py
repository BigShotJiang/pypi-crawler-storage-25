"""
Agent loop — the think → tool → repeat cycle.

Drives a single agent to completion by calling the LLM, dispatching tool calls,
and feeding results back until the task is done or the iteration limit is reached.
"""

import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from shypmate.engine.providers import AnthropicProvider, OpenAIProvider
from shypmate.engine.tier_router import TierRouter
from shypmate.engine.tool_registry import ToolRegistry

# Minimum seconds between LLM calls to avoid rate limiting.
# At Tier 1 (50 req/min), 1.5s keeps us well under the limit.
_MIN_CALL_INTERVAL = float(os.environ.get("SHYPMATE_CALL_INTERVAL", "1.5"))


@dataclass
class ActivityStep:
    """A single step in the agent's execution — one iteration of think → tool → result."""
    iteration: int
    reasoning: str = ""             # agent's text output (thinking/explanation)
    tool_calls: list[dict] = field(default_factory=list)  # [{name, input_summary, result_summary}]
    timestamp: str = ""


@dataclass
class AgentResult:
    """Structured result from an agent run. Works as a string (via __str__) for backward compat."""
    output: str = ""                # final text output from the agent
    status: str = "completed"       # completed, stopped, failed
    steps: list[ActivityStep] = field(default_factory=list)
    iterations: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    cost: float = 0.0
    elapsed_seconds: float = 0.0
    stop_reason: str = ""           # why the agent stopped (if not completed)
    tier_stats: dict = field(default_factory=dict)  # per-tier breakdown {tier: {model, calls, in, out, cost}}

    def __str__(self) -> str:
        return self.output

    def startswith(self, prefix: str) -> bool:
        return self.output.startswith(prefix)

logger = logging.getLogger(__name__)


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate text for logging, showing the length if truncated."""
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"... ({len(text)} chars total)"


def _summarize_input(input_dict: dict, max_val: int = 100) -> str:
    """Create a short summary of tool input for logging."""
    parts = []
    for k, v in input_dict.items():
        val_str = str(v)
        if len(val_str) > max_val:
            val_str = val_str[:max_val] + "..."
        parts.append(f"{k}={val_str}")
    return ", ".join(parts)


def _log_context_summary(system_prompt: str, task_prompt: str, tool_schemas: list) -> None:
    """Log the full context being sent to the LLM on the first call. No truncation."""
    logger.info("=" * 60)
    logger.info("SYSTEM PROMPT (sent to LLM)")
    logger.info(f"  Length: {len(system_prompt)} chars")
    logger.info("=" * 60)
    for line in system_prompt.split("\n"):
        logger.info(f"  {line}")
    logger.info("=" * 60)

    logger.info("TASK PROMPT (sent to LLM)")
    logger.info("=" * 60)
    for line in task_prompt.split("\n"):
        logger.info(f"  {line}")
    logger.info("=" * 60)

    logger.info(f"TOOLS ({len(tool_schemas)}):")
    for t in tool_schemas:
        desc = t.get("description", "")
        params = list(t.get("input_schema", {}).get("properties", {}).keys())
        logger.info(f"  {t['name']}({', '.join(params)}) — {desc}")
    logger.info("=" * 60)


@dataclass
class AgentQuota:
    """Quota limits for an agent run. Two tiers: soft (ask human) and hard (stop immediately)."""
    # Soft quotas — pause and ask human to continue
    soft_max_tokens: int = 0       # total tokens (in + out). 0 = no limit
    soft_max_cost: float = 0.0     # estimated cost in USD. 0 = no limit
    soft_max_seconds: int = 0      # wall clock seconds. 0 = no limit
    soft_max_iterations: int = 0   # number of LLM calls. 0 = no limit

    # Hard quotas — stop immediately, no questions
    hard_max_tokens: int = 0
    hard_max_cost: float = 0.0
    hard_max_seconds: int = 0
    hard_max_iterations: int = 0

    # Track if soft quota was already triggered (so we only ask once)
    _soft_triggered: bool = False


def _estimate_cost(input_tokens: int, output_tokens: int) -> float:
    """Rough cost estimate using Sonnet pricing: $3/M input, $15/M output."""
    return input_tokens * 3.0 / 1_000_000 + output_tokens * 15.0 / 1_000_000


def _check_hard_quota(
    quota: AgentQuota,
    total_input: int,
    total_output: int,
    elapsed_seconds: float,
    iteration: int,
) -> str | None:
    """Check hard quotas. Returns a reason string if exceeded, None if OK."""
    total_tokens = total_input + total_output
    cost = _estimate_cost(total_input, total_output)

    if quota.hard_max_tokens and total_tokens >= quota.hard_max_tokens:
        return f"HARD QUOTA: token limit ({total_tokens:,} >= {quota.hard_max_tokens:,})"
    if quota.hard_max_cost and cost >= quota.hard_max_cost:
        return f"HARD QUOTA: cost limit (${cost:.4f} >= ${quota.hard_max_cost:.4f})"
    if quota.hard_max_seconds and elapsed_seconds >= quota.hard_max_seconds:
        return f"HARD QUOTA: time limit ({elapsed_seconds:.0f}s >= {quota.hard_max_seconds}s)"
    if quota.hard_max_iterations and iteration >= quota.hard_max_iterations:
        return f"HARD QUOTA: iteration limit ({iteration} >= {quota.hard_max_iterations})"
    return None


def _check_soft_quota(
    quota: AgentQuota,
    total_input: int,
    total_output: int,
    elapsed_seconds: float,
    iteration: int,
) -> str | None:
    """Check soft quotas. Returns a reason string if exceeded, None if OK."""
    if quota._soft_triggered:
        return None  # already asked, don't ask again

    total_tokens = total_input + total_output
    cost = _estimate_cost(total_input, total_output)

    if quota.soft_max_tokens and total_tokens >= quota.soft_max_tokens:
        return f"token usage ({total_tokens:,} >= {quota.soft_max_tokens:,})"
    if quota.soft_max_cost and cost >= quota.soft_max_cost:
        return f"cost (${cost:.4f} >= ${quota.soft_max_cost:.4f})"
    if quota.soft_max_seconds and elapsed_seconds >= quota.soft_max_seconds:
        return f"time ({elapsed_seconds:.0f}s >= {quota.soft_max_seconds}s)"
    if quota.soft_max_iterations and iteration >= quota.soft_max_iterations:
        return f"iterations ({iteration} >= {quota.soft_max_iterations})"
    return None



def _write_progress_end(hat_name: str, status: str, reason: str, cost: float) -> None:
    """Write a hat-end progress event to the pipeline context."""
    _write_progress({
        "type": "hat_end",
        "hat": hat_name,
        "status": status,
        "reason": reason,
        "cost": round(cost, 4),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })


def _write_progress(event: dict) -> None:
    """Append a live progress event to the pipeline context JSON.

    All progress lives in the same file as the pipeline context:
      /dot-shypmate/comms/pipeline_context/<agent_id>.json

    Events are appended to the 'live_progress' array. The host CLI
    polls this array for real-time updates.
    """
    import json as _json
    ctx_dir = Path("/dot-shypmate/comms/pipeline_context")
    if not ctx_dir.parent.parent.exists():
        return  # no mounted volume
    ctx_dir.mkdir(parents=True, exist_ok=True)
    agent_id = os.environ.get("AGENT_ID", "unknown")
    ctx_file = ctx_dir / f"{agent_id}.json"
    try:
        # Read existing context
        if ctx_file.exists():
            ctx = _json.loads(ctx_file.read_text(encoding="utf-8"))
        else:
            ctx = {"pipeline_id": agent_id, "stages": [], "live_progress": []}

        ctx.setdefault("live_progress", []).append(event)
        ctx_file.write_text(_json.dumps(ctx, indent=2), encoding="utf-8")
    except Exception:
        pass  # non-critical


def run_agent(
    provider: AnthropicProvider | OpenAIProvider | TierRouter,
    system_prompt: str,
    task_prompt: str,
    registry: ToolRegistry,
    max_iterations: int = 50,
    quota: AgentQuota | None = None,
    hat_name: str = "",
) -> AgentResult:
    """
    Run an agent loop to completion.

    Args:
        provider: LLM provider instance.
        system_prompt: System/backstory prompt for the agent.
        task_prompt: The user-facing task description.
        registry: Tool registry with all available tools.
        max_iterations: Maximum number of LLM calls before stopping.
        quota: Optional quota limits (soft + hard) for tokens, cost, time, iterations.

    Returns:
        AgentResult with output, status, and structured activity steps.
        Works as a string via __str__ for backward compatibility.
    """
    if quota is None:
        quota = AgentQuota()

    messages: list[dict[str, Any]] = [
        {"role": "user", "content": task_prompt},
    ]
    tool_schemas = registry.schemas
    total_input_tokens = 0
    total_output_tokens = 0
    last_call_time = 0.0
    start_time = time.time()
    activity_steps: list[ActivityStep] = []

    # Log the full context summary before the first LLM call
    _log_context_summary(system_prompt, task_prompt, tool_schemas)

    # Log the provider details
    hat_prefix = f"[{hat_name}] " if hat_name else ""
    model = getattr(provider, "model", "unknown")
    provider_type = type(provider).__name__
    is_tiered = isinstance(provider, TierRouter)
    if hat_name:
        logger.info(f"Hat: {hat_name.upper()}")
    if is_tiered:
        logger.info(f"Provider: TierRouter — premium={model}, economy={provider.economy_model}")
    else:
        logger.info(f"Provider: {provider_type} / {model}")
    logger.info(f"Max iterations: {max_iterations}")
    logger.info(f"Call interval: {_MIN_CALL_INTERVAL}s")

    # Log quota settings
    if quota.soft_max_tokens or quota.soft_max_cost or quota.soft_max_seconds or quota.soft_max_iterations:
        logger.info(f"Soft quota: tokens={quota.soft_max_tokens or 'none'} cost=${quota.soft_max_cost or 'none'} "
                     f"time={quota.soft_max_seconds or 'none'}s iterations={quota.soft_max_iterations or 'none'}")
    if quota.hard_max_tokens or quota.hard_max_cost or quota.hard_max_seconds or quota.hard_max_iterations:
        logger.info(f"Hard quota: tokens={quota.hard_max_tokens or 'none'} cost=${quota.hard_max_cost or 'none'} "
                     f"time={quota.hard_max_seconds or 'none'}s iterations={quota.hard_max_iterations or 'none'}")
    def _tier_info() -> str:
        return provider.tier_summary() if is_tiered else ""

    def _tier_breakdown() -> list[str] | None:
        return provider.tier_cost_breakdown() if is_tiered else None

    def _tier_stats_dict() -> dict:
        if not is_tiered:
            return {}
        stats = {}
        for s in (provider.premium_stats, provider.economy_stats):
            if s.calls > 0:
                stats[s.tier] = {
                    "model": s.model,
                    "provider": s.provider,
                    "calls": s.calls,
                    "input_tokens": s.input_tokens,
                    "output_tokens": s.output_tokens,
                    "cost": round(s.cost, 4),
                }
        return stats

    logger.info("")

    # Write hat start to progress
    _write_progress({
        "type": "hat_start",
        "hat": hat_name,
        "model": model,
        "max_iterations": max_iterations,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })

    prev_msg_count = 0  # track how many messages were logged last iteration

    for iteration in range(1, max_iterations + 1):
        logger.info(f"--- {hat_prefix}Iteration {iteration}/{max_iterations} ---")

        msg_count = len(messages)
        msg_size = sum(len(str(m)) for m in messages)
        logger.info(f"  Sending: {msg_count} messages, ~{msg_size} chars")

        # Only log NEW messages since last iteration (avoid repeating the full history)
        new_messages = messages[prev_msg_count:]
        if prev_msg_count > 0 and new_messages:
            logger.info(f"  New since last iteration:")
        for msg in new_messages:
            i = messages.index(msg)
            role = msg.get("role", "?")
            content = msg.get("content", "")

            if isinstance(content, str):
                for line in content.split("\n"):
                    logger.info(f"    [{i}] {role}: {line}")
            elif isinstance(content, list):
                for j, block in enumerate(content):
                    if isinstance(block, dict):
                        btype = block.get("type", "?")
                        if btype == "text":
                            for line in block.get("text", "").split("\n"):
                                logger.info(f"    [{i}.{j}] {role}/text: {line}")
                        elif btype == "tool_use":
                            logger.info(f"    [{i}.{j}] {role}/tool_use: {block.get('name', '?')}({_summarize_input(block.get('input', {}), max_val=500)})")
                        elif btype == "tool_result":
                            result_text = block.get("content", "")
                            for line in result_text.split("\n"):
                                logger.info(f"    [{i}.{j}] {role}/tool_result: {line}")
            else:
                logger.info(f"    [{i}] {role}: {str(content)}")

        prev_msg_count = msg_count

        # Throttle to avoid rate limiting
        elapsed = time.time() - last_call_time
        if elapsed < _MIN_CALL_INTERVAL and last_call_time > 0:
            wait = _MIN_CALL_INTERVAL - elapsed
            logger.debug(f"  Throttling: waiting {wait:.1f}s")
            time.sleep(wait)
        last_call_time = time.time()

        response = provider.create_message(
            system=system_prompt,
            messages=messages,
            tools=tool_schemas,
        )

        input_tokens = response.usage.get("input_tokens", 0)
        output_tokens = response.usage.get("output_tokens", 0)
        cache_read = response.usage.get("cache_read_tokens", 0)
        cache_create = response.usage.get("cache_creation_tokens", 0)
        total_input_tokens += input_tokens
        total_output_tokens += output_tokens

        cache_info = ""
        if cache_read:
            cache_info = f" cache_read={cache_read}"
        elif cache_create:
            cache_info = f" cache_create={cache_create}"

        elapsed_total = time.time() - start_time

        logger.info(f"  Response: {input_tokens} in / {output_tokens} out tokens "
                     f"(total: {total_input_tokens} in / {total_output_tokens} out) "
                     f"stop={response.stop_reason}{cache_info} "
                     f"elapsed={elapsed_total:.0f}s cost=${_estimate_cost(total_input_tokens, total_output_tokens):.4f}")

        # ── Check hard quota — stop immediately ──
        hard_reason = _check_hard_quota(quota, total_input_tokens, total_output_tokens, elapsed_total, iteration)
        if hard_reason:
            logger.error(f"  {hard_reason}")
            _log_summary(iteration, total_input_tokens, total_output_tokens, quota_reason=hard_reason, tier_summary=_tier_info(), tier_breakdown=_tier_breakdown())
            output = f"AGENT STOPPED: {hard_reason}. Progress at time of stop: {response.text or '(no output)'}"
            cost = _estimate_cost(total_input_tokens, total_output_tokens)
            _write_progress_end(hat_name, "stopped", hard_reason, cost)
            return AgentResult(
                output=output, status="stopped", steps=activity_steps,
                iterations=iteration, total_input_tokens=total_input_tokens,
                total_output_tokens=total_output_tokens,
                cost=cost, elapsed_seconds=elapsed_total, stop_reason=hard_reason,
                tier_stats=_tier_stats_dict(),
            )

        # ── Check soft quota — ask human whether to continue ──
        soft_reason = _check_soft_quota(quota, total_input_tokens, total_output_tokens, elapsed_total, iteration)
        if soft_reason:
            quota._soft_triggered = True
            logger.warning(f"  SOFT QUOTA reached: {soft_reason}")
            # Use request_human_input if available in the registry
            try:
                from shypmate.tools.human_tools import request_human_input
                human_response = request_human_input(
                    question=(
                        f"I've reached a resource quota: {soft_reason}. "
                        f"So far I've used {total_input_tokens + total_output_tokens:,} tokens "
                        f"(${_estimate_cost(total_input_tokens, total_output_tokens):.4f}) "
                        f"in {iteration} iterations over {elapsed_total:.0f}s. "
                        f"Should I continue working, or stop here? "
                        f"Reply 'continue' to keep going or 'stop' to end."
                    ),
                    context=f"Current progress: {response.text or '(working on task)'}",
                )
                if "stop" in human_response.lower():
                    _log_summary(iteration, total_input_tokens, total_output_tokens, quota_reason=f"Soft quota: {soft_reason} — human chose to stop", tier_summary=_tier_info(), tier_breakdown=_tier_breakdown())
                    output = f"Agent stopped by human at soft quota ({soft_reason}). Progress: {response.text or '(no output)'}"
                    return AgentResult(
                        output=output, status="stopped", steps=activity_steps,
                        iterations=iteration, total_input_tokens=total_input_tokens,
                        total_output_tokens=total_output_tokens,
                        cost=_estimate_cost(total_input_tokens, total_output_tokens),
                        elapsed_seconds=elapsed_total, stop_reason=f"human stop at {soft_reason}",
                        tier_stats=_tier_stats_dict(),
                    )
                logger.info(f"  Human approved continuing past soft quota")
            except Exception as e:
                logger.warning(f"  Could not reach human for soft quota decision: {e}. Continuing.")

        if response.text:
            for line in response.text.split("\n"):
                logger.info(f"  Agent says: {line}")

        # No tool calls — agent is done
        if not response.tool_calls:
            # Record final step (reasoning only, no tools)
            if response.text:
                activity_steps.append(ActivityStep(
                    iteration=iteration,
                    reasoning=response.text[:500],
                    timestamp=datetime.now(timezone.utc).isoformat(),
                ))
            elapsed_total = time.time() - start_time
            cost = _estimate_cost(total_input_tokens, total_output_tokens)
            _log_summary(iteration, total_input_tokens, total_output_tokens, tier_summary=_tier_info(), tier_breakdown=_tier_breakdown())
            _write_progress_end(hat_name, "completed", "", cost)
            return AgentResult(
                output=response.text or "", status="completed", steps=activity_steps,
                iterations=iteration, total_input_tokens=total_input_tokens,
                total_output_tokens=total_output_tokens,
                cost=cost,
                elapsed_seconds=elapsed_total,
                tier_stats=_tier_stats_dict(),
            )

        # Log tool calls with full input
        for tc in response.tool_calls:
            logger.info(f"  Tool call: {tc.name}({_summarize_input(tc.input, max_val=500)})")

        # Build the assistant message content (text + tool_use blocks)
        assistant_content: list[dict[str, Any]] = []
        if response.text:
            assistant_content.append({"type": "text", "text": response.text})
        for tc in response.tool_calls:
            assistant_content.append({
                "type": "tool_use",
                "id": tc.id,
                "name": tc.name,
                "input": tc.input,
            })

        messages.append({"role": "assistant", "content": assistant_content})

        # Dispatch each tool call and collect results
        tool_results: list[dict[str, Any]] = []
        step_tool_calls: list[dict] = []
        for tc in response.tool_calls:
            result = registry.dispatch(tc.name, tc.input)
            logger.info(f"  Tool result [{tc.name}]:")
            for line in result.split("\n"):
                logger.info(f"    {line}")
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tc.id,
                "content": result,
            })
            step_tool_calls.append({
                "name": tc.name,
                "input_summary": _summarize_input(tc.input, max_val=150),
                "result_summary": _truncate(result, 200),
            })

        # Record this iteration as an activity step
        step = ActivityStep(
            iteration=iteration,
            reasoning=(response.text or "")[:500],
            tool_calls=step_tool_calls,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        activity_steps.append(step)

        # Write live progress for the host CLI
        tier = getattr(provider, 'last_tier', None)
        _write_progress({
            "type": "step",
            "hat": hat_name,
            "iteration": iteration,
            "max_iterations": max_iterations,
            "tier": tier,
            "reasoning": (response.text or "")[:300],
            "tools": [{"name": tc["name"], "input": tc["input_summary"], "result": tc["result_summary"][:150]} for tc in step_tool_calls],
            "cost": round(_estimate_cost(total_input_tokens, total_output_tokens), 4),
            "timestamp": step.timestamp,
        })

        messages.append({"role": "user", "content": tool_results})

    logger.warning(f"Agent hit iteration limit ({max_iterations})")
    _log_summary(max_iterations, total_input_tokens, total_output_tokens, tier_summary=_tier_info(), tier_breakdown=_tier_breakdown())
    elapsed_total = time.time() - start_time
    cost = _estimate_cost(total_input_tokens, total_output_tokens)
    _write_progress_end(hat_name, "stopped", f"iteration limit ({max_iterations})", cost)
    return AgentResult(
        output=f"Agent stopped after {max_iterations} iterations without completing the task.",
        status="stopped", steps=activity_steps,
        iterations=max_iterations, total_input_tokens=total_input_tokens,
        total_output_tokens=total_output_tokens,
        cost=cost, elapsed_seconds=elapsed_total,
        stop_reason=f"iteration limit ({max_iterations})",
        tier_stats=_tier_stats_dict(),
    )


def _log_summary(
    iterations: int,
    input_tokens: int,
    output_tokens: int,
    quota_reason: str = "",
    tier_summary: str = "",
    tier_breakdown: list[str] | None = None,
) -> None:
    """Log a final summary of the agent run."""
    total_tokens = input_tokens + output_tokens
    cost = _estimate_cost(input_tokens, output_tokens)

    logger.info("=" * 60)
    logger.info("AGENT RUN SUMMARY")
    logger.info("=" * 60)
    if quota_reason:
        logger.info(f"  Status:        STOPPED — {quota_reason}")
    else:
        logger.info(f"  Status:        COMPLETED")
    logger.info(f"  Iterations:    {iterations}")
    logger.info(f"  API requests:  {iterations}")
    logger.info(f"  Input tokens:  {input_tokens:,}")
    logger.info(f"  Output tokens: {output_tokens:,}")
    logger.info(f"  Total tokens:  {total_tokens:,}")
    logger.info(f"  Est. cost:     ${cost:.4f}")
    if tier_summary:
        logger.info(f"  Tier routing:  {tier_summary}")
    if tier_breakdown:
        logger.info("")
        logger.info("  COST BREAKDOWN BY TIER")
        logger.info("  " + "-" * 56)
        for line in tier_breakdown:
            logger.info(line)
        logger.info("  " + "-" * 56)
    logger.info("=" * 60)
