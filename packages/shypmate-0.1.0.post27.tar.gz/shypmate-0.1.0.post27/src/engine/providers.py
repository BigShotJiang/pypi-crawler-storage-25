"""
LLM provider abstraction — wraps Anthropic (and future providers) behind a
common interface for the agent loop.
"""

import logging
import time
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

# Retry config for rate-limited requests
_MAX_RETRIES = 5
_INITIAL_BACKOFF = 2  # seconds
_MAX_BACKOFF = 60  # seconds


def _retry_on_rate_limit(func):
    """Decorator that retries API calls on rate limit (429) with exponential backoff."""
    def wrapper(*args, **kwargs):
        backoff = _INITIAL_BACKOFF
        for attempt in range(_MAX_RETRIES + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                error_str = str(e).lower()
                status = getattr(getattr(e, "response", None), "status_code", None) or \
                         getattr(e, "status_code", None)

                is_rate_limit = status == 429 or "429" in error_str or "rate" in error_str

                if is_rate_limit and attempt < _MAX_RETRIES:
                    logger.warning(f"Rate limited (attempt {attempt + 1}/{_MAX_RETRIES + 1}). "
                                   f"Retrying in {backoff}s...")
                    time.sleep(backoff)
                    backoff = min(backoff * 2, _MAX_BACKOFF)
                    continue
                raise
    return wrapper


@dataclass
class ToolCall:
    """A single tool call extracted from an LLM response."""
    id: str
    name: str
    input: dict


@dataclass
class LLMResponse:
    """Normalized response from any LLM provider."""
    text: str
    tool_calls: list[ToolCall]
    stop_reason: str
    usage: dict[str, int]


def _get_session_metadata() -> dict[str, str]:
    """Build session metadata from environment variables.

    Returns metadata dict with agent_id, task, hat, etc. for tracing
    API calls back to specific agent runs in the provider's console.
    """
    import os
    meta = {}
    agent_id = os.environ.get("AGENT_ID", "")
    if agent_id:
        meta["agent_id"] = agent_id
    task = os.environ.get("AGENT_TASK", "")
    if task:
        meta["task"] = task[:100]
    branch = os.environ.get("AGENT_BRANCH", "")
    if branch:
        meta["branch"] = branch
    return meta


def _is_local_url(url: str | None) -> bool:
    """Check if a URL points to a local or Docker-network service (no API key needed)."""
    if not url:
        return True
    url_lower = url.lower()
    local_patterns = ("localhost", "127.0.0.1", "0.0.0.0", "host.docker.internal",
                      "ollama", "lmstudio", "vllm", "localai")
    return any(p in url_lower for p in local_patterns)


class AnthropicProvider:
    """Anthropic Claude provider using the messages API with prompt caching."""

    def __init__(self, model: str, max_tokens: int):
        import anthropic
        self.client = anthropic.Anthropic()
        self.model = model
        self.max_tokens = max_tokens
        self._session_meta = _get_session_metadata()

    @_retry_on_rate_limit
    def create_message(
        self,
        system: str,
        messages: list[dict],
        tools: list[dict],
    ) -> LLMResponse:
        # Use prompt caching: mark the system prompt and tools as cacheable.
        # Anthropic caches these across calls so repeated iterations don't
        # re-process the same system prompt and tool definitions.
        system_with_cache = [
            {
                "type": "text",
                "text": system,
                "cache_control": {"type": "ephemeral"},
            }
        ]

        # Mark the last tool as cacheable (Anthropic caches everything up to
        # and including the block with cache_control)
        cached_tools = list(tools)
        if cached_tools:
            cached_tools[-1] = {
                **cached_tools[-1],
                "cache_control": {"type": "ephemeral"},
            }

        # Build metadata for tracing in the Anthropic console
        # user_id appears in usage dashboards; extra_headers for custom tracing
        api_kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "system": system_with_cache,
            "messages": messages,
            "tools": cached_tools,
        }

        agent_id = self._session_meta.get("agent_id", "")
        if agent_id:
            api_kwargs["metadata"] = {"user_id": f"shypmate-{agent_id}"}

        # Custom headers for tracing (visible in Anthropic dashboard logs)
        extra_headers = {}
        if agent_id:
            extra_headers["x-shypmate-agent-id"] = agent_id
        if self._session_meta.get("branch"):
            extra_headers["x-shypmate-branch"] = self._session_meta["branch"]
        if extra_headers:
            api_kwargs["extra_headers"] = extra_headers

        response = self.client.messages.create(**api_kwargs)

        text_parts = []
        tool_calls = []

        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(ToolCall(
                    id=block.id,
                    name=block.name,
                    input=block.input,
                ))

        # Extract cache metrics if available
        usage = {
            "input_tokens": response.usage.input_tokens,
            "output_tokens": response.usage.output_tokens,
        }
        cache_creation = getattr(response.usage, "cache_creation_input_tokens", 0)
        cache_read = getattr(response.usage, "cache_read_input_tokens", 0)
        if cache_creation:
            usage["cache_creation_tokens"] = cache_creation
        if cache_read:
            usage["cache_read_tokens"] = cache_read

        return LLMResponse(
            text="\n".join(text_parts),
            tool_calls=tool_calls,
            stop_reason=response.stop_reason,
            usage=usage,
        )


class OpenAIProvider:
    """OpenAI-compatible provider (OpenAI, Azure, local)."""

    def __init__(self, model: str, max_tokens: int, base_url: str | None = None, api_key: str | None = None):
        import openai
        kwargs: dict[str, Any] = {}
        if base_url:
            kwargs["base_url"] = base_url
        if api_key:
            kwargs["api_key"] = api_key
        elif not base_url or _is_local_url(base_url):
            # Local providers (Ollama, LM Studio, Docker services) don't need a real key
            kwargs.setdefault("api_key", "not-needed")
        self.client = openai.OpenAI(**kwargs)
        self.model = model
        self.max_tokens = max_tokens
        self._session_meta = _get_session_metadata()

    def _convert_tools(self, tools: list[dict]) -> list[dict]:
        """Convert Anthropic tool format to OpenAI function-calling format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t["input_schema"],
                },
            }
            for t in tools
        ]

    def _convert_messages(self, system: str, messages: list[dict]) -> list[dict]:
        """Convert Anthropic message format to OpenAI format."""
        converted = [{"role": "system", "content": system}]

        for msg in messages:
            if msg["role"] == "assistant":
                # Handle assistant messages that may contain tool calls
                if isinstance(msg["content"], list):
                    text_parts = []
                    tool_calls = []
                    for block in msg["content"]:
                        if isinstance(block, dict):
                            if block.get("type") == "text":
                                text_parts.append(block["text"])
                            elif block.get("type") == "tool_use":
                                import json
                                tool_calls.append({
                                    "id": block["id"],
                                    "type": "function",
                                    "function": {
                                        "name": block["name"],
                                        "arguments": json.dumps(block["input"]),
                                    },
                                })
                    oai_msg: dict[str, Any] = {"role": "assistant"}
                    if text_parts:
                        oai_msg["content"] = "\n".join(text_parts)
                    if tool_calls:
                        oai_msg["tool_calls"] = tool_calls
                    converted.append(oai_msg)
                else:
                    converted.append(msg)
            elif msg["role"] == "user":
                # Handle tool results
                if isinstance(msg["content"], list):
                    for block in msg["content"]:
                        if isinstance(block, dict) and block.get("type") == "tool_result":
                            converted.append({
                                "role": "tool",
                                "tool_call_id": block["tool_use_id"],
                                "content": block["content"],
                            })
                else:
                    converted.append(msg)

        return converted

    @_retry_on_rate_limit
    def create_message(
        self,
        system: str,
        messages: list[dict],
        tools: list[dict],
    ) -> LLMResponse:
        import json

        oai_messages = self._convert_messages(system, messages)
        oai_tools = self._convert_tools(tools)

        api_kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "messages": oai_messages,
        }
        if oai_tools:
            api_kwargs["tools"] = oai_tools

        # Pass agent_id as user for tracing in the OpenAI dashboard
        agent_id = self._session_meta.get("agent_id", "")
        if agent_id:
            api_kwargs["user"] = f"shypmate-{agent_id}"

        response = self.client.chat.completions.create(**api_kwargs)

        choice = response.choices[0]
        text = choice.message.content or ""
        tool_calls = []

        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                tool_calls.append(ToolCall(
                    id=tc.id,
                    name=tc.function.name,
                    input=json.loads(tc.function.arguments),
                ))

        stop_reason = "end_turn" if choice.finish_reason == "stop" else choice.finish_reason

        return LLMResponse(
            text=text,
            tool_calls=tool_calls,
            stop_reason=stop_reason,
            usage={
                "input_tokens": response.usage.prompt_tokens if response.usage else 0,
                "output_tokens": response.usage.completion_tokens if response.usage else 0,
            },
        )


def create_provider(
    provider: str,
    model: str,
    max_tokens: int,
    base_url: str | None = None,
    api_key: str | None = None,
) -> AnthropicProvider | OpenAIProvider:
    """Factory to create an LLM provider by name.

    Anthropic uses its native SDK. All other providers use the OpenAI-compatible
    interface (OpenAI, Gemini, Azure, Mistral, Groq, DeepSeek, Together, Ollama,
    LM Studio, or any custom endpoint).
    """
    if provider == "anthropic":
        return AnthropicProvider(model=model, max_tokens=max_tokens)
    else:
        # Everything else goes through OpenAI-compatible API
        return OpenAIProvider(model=model, max_tokens=max_tokens, base_url=base_url, api_key=api_key)
