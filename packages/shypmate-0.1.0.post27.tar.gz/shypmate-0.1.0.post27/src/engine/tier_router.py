"""
Tier router — intra-task model switching between premium and economy LLM tiers.

Routes each agent loop iteration to either a premium (e.g. Claude Sonnet) or
economy (e.g. Ollama, Groq) provider based on what the agent is doing:

  - Discovery phase (reading files, listing dirs, searching) → economy tier
  - Planning, coding, error handling, git operations → premium tier

The router implements the same create_message interface as providers, so the
agent loop doesn't need to know about tiers.

Developer control:
  - shypmate.yml: llm.tier_routing + llm.economy section
  - shypmate.py: classify_tier(iteration, last_tool_names, last_had_errors) hook
"""

import logging
from dataclasses import dataclass, field
from typing import Any

from shypmate.engine.providers import LLMResponse

logger = logging.getLogger(__name__)

# Tools that are read-only discovery — safe for economy tier
_DISCOVERY_TOOLS = frozenset({
    "read_file",
    "list_directory",
    "search_files",
})

# Tools that require premium reasoning
_PREMIUM_TOOLS = frozenset({
    "write_file",
    "patch_file",
    "run_command",
    "ruff_check",
    "ruff_format",
    "git_commit",
    "git_push",
    "git_rebase",
    "git_merge",
    "git_cherry_pick",
    "create_pull_request",
    "update_pull_request",
    "request_human_input",
})


def classify_tier(
    iteration: int,
    messages: list[dict],
    classify_hook: Any = None,
) -> str:
    """Classify whether the next LLM call should use economy or premium tier.

    Args:
        iteration: Current iteration number (1-based).
        messages: Full message history being sent to the LLM.
        classify_hook: Optional user-defined hook from shypmate.py.

    Returns:
        "economy" or "premium"
    """
    # Extract info about the last iteration for classification
    last_tool_names = _extract_last_tool_names(messages)
    last_had_errors = _check_last_results_for_errors(messages)

    # Let the developer override classification if they defined a hook
    if classify_hook is not None:
        try:
            result = classify_hook(iteration, last_tool_names, last_had_errors)
            if result in ("economy", "premium"):
                return result
        except Exception:
            pass  # fall through to built-in logic

    # ── Built-in classification rules ──

    # First iteration — agent needs to understand the task and plan → premium
    if iteration == 1:
        return "premium"

    # No previous tool calls (text-only response, or first real iteration) → premium
    if not last_tool_names:
        return "premium"

    # If last results had errors → premium (needs reasoning to recover)
    if last_had_errors:
        return "premium"

    # If ALL last tools were discovery-only → economy
    if all(t in _DISCOVERY_TOOLS for t in last_tool_names):
        return "economy"

    # If any tool requires premium reasoning → premium
    if any(t in _PREMIUM_TOOLS for t in last_tool_names):
        return "premium"

    # Unknown tools — default to premium (safe)
    return "premium"


def _extract_last_tool_names(messages: list[dict]) -> list[str]:
    """Extract tool names from the last assistant message."""
    for msg in reversed(messages):
        if msg.get("role") == "assistant":
            content = msg.get("content", [])
            if isinstance(content, list):
                return [
                    block["name"]
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "tool_use"
                ]
            break
    return []


def _check_last_results_for_errors(messages: list[dict]) -> bool:
    """Check if the last tool results contained error indicators."""
    if not messages or messages[-1].get("role") != "user":
        return False

    content = messages[-1].get("content", [])
    if not isinstance(content, list):
        return False

    error_signals = ("error", "traceback", "exception", "not found", "permission denied", "failed", "denied")
    for block in content:
        if isinstance(block, dict) and block.get("type") == "tool_result":
            result_text = (block.get("content") or "").lower()
            if any(signal in result_text for signal in error_signals):
                return True
    return False


# ── Per-model pricing (USD per 1M tokens) ──
# Used for cost estimation. Models not listed fall back to a default.
_MODEL_PRICING: dict[str, tuple[float, float]] = {
    # (input $/M, output $/M)
    # Anthropic
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-sonnet-4-5-20250514": (3.0, 15.0),
    "claude-haiku-4-5-20251001": (0.80, 4.0),
    "claude-opus-4-6": (15.0, 75.0),
    # OpenAI
    "gpt-4o": (2.50, 10.0),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4.1": (2.0, 8.0),
    "gpt-4.1-mini": (0.40, 1.60),
    "gpt-4.1-nano": (0.10, 0.40),
    # Google
    "gemini-2.5-pro": (1.25, 10.0),
    "gemini-2.5-flash": (0.15, 0.60),
    # Groq (hosted models — free tier or very cheap)
    "llama-3.3-70b-versatile": (0.59, 0.79),
    # DeepSeek
    "deepseek-chat": (0.14, 0.28),
    # Local (Ollama, LM Studio) — zero cost
    "llama3.1": (0.0, 0.0),
    "llama3.2": (0.0, 0.0),
    "mistral": (0.0, 0.0),
    "codellama": (0.0, 0.0),
    "qwen2.5-coder": (0.0, 0.0),
}

# Fallback for unknown models
_DEFAULT_PRICING = (3.0, 15.0)


def estimate_model_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate cost for a specific model using known pricing."""
    pricing = _MODEL_PRICING.get(model, _DEFAULT_PRICING)
    return input_tokens * pricing[0] / 1_000_000 + output_tokens * pricing[1] / 1_000_000


@dataclass
class TierStats:
    """Token and cost tracking for a single tier."""
    tier: str
    model: str
    provider: str
    calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    @property
    def cost(self) -> float:
        return estimate_model_cost(self.model, self.input_tokens, self.output_tokens)


class TierRouter:
    """Routes LLM calls to premium or economy providers based on iteration context.

    Implements the same create_message interface as AnthropicProvider/OpenAIProvider,
    so the agent loop can use it as a drop-in replacement.

    Tracks per-tier token usage and costs for detailed summaries.
    """

    def __init__(
        self,
        premium,
        economy,
        classify_hook=None,
    ):
        """
        Args:
            premium: The primary/premium LLM provider (e.g. AnthropicProvider).
            economy: The economy/local LLM provider (e.g. OpenAIProvider with Ollama).
            classify_hook: Optional callable(iteration, last_tool_names, last_had_errors) -> str.
        """
        self.premium = premium
        self.economy = economy
        self.classify_hook = classify_hook

        # For backward compatibility — agent_loop reads provider.model
        self.model = premium.model
        self.economy_model = economy.model

        # Per-tier tracking
        self.premium_stats = TierStats(
            tier="premium",
            model=premium.model,
            provider=type(premium).__name__,
        )
        self.economy_stats = TierStats(
            tier="economy",
            model=economy.model,
            provider=type(economy).__name__,
        )

        self.last_tier: str = "premium"
        self._iteration: int = 0

    @property
    def economy_calls(self) -> int:
        return self.economy_stats.calls

    @property
    def premium_calls(self) -> int:
        return self.premium_stats.calls

    def create_message(
        self,
        system: str,
        messages: list[dict],
        tools: list[dict],
    ) -> LLMResponse:
        """Route the LLM call to the appropriate tier and return the response."""
        self._iteration += 1
        tier = classify_tier(self._iteration, messages, self.classify_hook)
        self.last_tier = tier

        if tier == "economy":
            stats = self.economy_stats
            provider = self.economy
            logger.info(f"  Tier: ECONOMY ({self.economy_model})")
        else:
            stats = self.premium_stats
            provider = self.premium
            logger.info(f"  Tier: PREMIUM ({self.model})")

        response = provider.create_message(system=system, messages=messages, tools=tools)

        # Track per-tier usage
        stats.calls += 1
        stats.input_tokens += response.usage.get("input_tokens", 0)
        stats.output_tokens += response.usage.get("output_tokens", 0)

        return response

    def tier_summary(self) -> str:
        """Return a one-line summary of tier usage for the run summary header."""
        total = self.economy_stats.calls + self.premium_stats.calls
        if total == 0:
            return "No calls made"
        econ_pct = self.economy_stats.calls * 100 // total
        return (
            f"premium={self.premium_stats.calls} economy={self.economy_stats.calls} "
            f"({econ_pct}% economy)"
        )

    def tier_cost_breakdown(self) -> list[str]:
        """Return detailed per-tier cost breakdown lines for logging."""
        lines = []
        total_cost = 0.0

        for stats in (self.premium_stats, self.economy_stats):
            if stats.calls == 0:
                continue
            cost = stats.cost
            total_cost += cost
            lines.append(
                f"  {stats.tier.upper():>10}  "
                f"{stats.model:<30}  "
                f"{stats.calls:>3} calls  "
                f"{stats.input_tokens:>8,} in  "
                f"{stats.output_tokens:>8,} out  "
                f"${cost:.4f}"
            )

        if len(lines) > 1:
            # Both tiers used — show savings estimate
            premium_only_cost = estimate_model_cost(
                self.premium_stats.model,
                self.premium_stats.input_tokens + self.economy_stats.input_tokens,
                self.premium_stats.output_tokens + self.economy_stats.output_tokens,
            )
            saved = premium_only_cost - total_cost
            if saved > 0:
                lines.append(
                    f"  {'SAVED':>10}  "
                    f"{'(vs all-premium)':30}  "
                    f"{'':>3}       "
                    f"{'':>8}     "
                    f"{'':>8}      "
                    f"${saved:.4f}"
                )

        return lines
