"""Claude Code hook handlers.

Entry point: python3 -m staso.claude_code

Reads a JSON event from stdin, dispatches to the right handler.
Each hook invocation is a separate process; state is persisted to disk.

Trace model: one trace per conversation turn. All turns share session_id.
  Turn span (root, kind=agent)
    |- LLM span 1 (kind=llm)   <- extracted from transcript in Stop
    |- Tool span   (kind=tool)  <- timed via PreToolUse/PostToolUse pair
    +- LLM span 2 (kind=llm)
"""
from __future__ import annotations

import json
import logging
import os
import sys
import time
from typing import Any

from staso._common.helpers import generate_agent_id, new_id, now_iso, parse_iso_to_epoch, ts_to_iso, turn_span_name
from staso._common.repair import auto_sync_enabled, repair_hooks
from staso._common.sender import SpanSender, sender_from_env
from staso._common.span import base_span
from .state import HookState, acquire_lock, delete_state, load_state, release_lock, save_state
from .transcript import AssistantMessage, count_lines, parse_assistant_messages

logger = logging.getLogger("staso.claude_code")

_SOURCE = "claude-code"
_AGENT_NAME = os.environ.get("STASO_AGENT_NAME", "") or "claude-code"
_AGENT_ID = generate_agent_id(_AGENT_NAME)


# -- helpers -------------------------------------------------------------------


def _load_active_state(session_id: str) -> HookState | None:
    """Load state only when there is an active turn. Returns None otherwise."""
    state = load_state(session_id)
    if state is None or state.current_trace_id is None or state.current_turn_span_id is None:
        return None
    return state


def _aggregate_llm_messages(
    messages: list[AssistantMessage],
) -> tuple[int, int, str]:
    """Return (total_input_tokens, total_output_tokens, last_model)."""
    total_in = sum(m.input_tokens for m in messages)
    total_out = sum(m.output_tokens for m in messages)
    last_model = messages[-1].model if messages else ""
    return total_in, total_out, last_model


# -- handlers ------------------------------------------------------------------


def handle_session_start(payload: dict[str, Any], _sender: SpanSender) -> None:
    session_id = payload["session_id"]
    cwd = payload.get("cwd", "")

    if auto_sync_enabled():
        try:
            repair_hooks("claude-code", cwd)
        except Exception:
            logger.debug("staso: auto-repair failed", exc_info=True)

    if not acquire_lock(session_id):
        return
    try:
        state = HookState(
            session_id=session_id,
            cwd=cwd,
        )
        save_state(state)
    finally:
        release_lock(session_id)


def handle_user_prompt_submit(payload: dict[str, Any], _sender: SpanSender) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        state = load_state(session_id) or HookState(
            session_id=session_id,
            cwd=payload.get("cwd", ""),
        )
        state.turn_count += 1
        state.current_trace_id = new_id()
        state.current_turn_span_id = new_id()
        state.current_turn_start = time.time()
        state.current_turn_prompt = payload.get("prompt", "")
        state.last_transcript_line = count_lines(payload.get("transcript_path", ""))
        save_state(state)
    finally:
        release_lock(session_id)


def handle_pre_tool_use(payload: dict[str, Any], _sender: SpanSender) -> dict[str, Any] | None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return None
    try:
        state = _load_active_state(session_id)
        if state is None:
            return None
        tool_use_id = payload.get("tool_use_id", "")
        if tool_use_id:
            state.pending_tool_starts[tool_use_id] = time.time()
            save_state(state)

        # Guard evaluation
        guard_enabled = os.environ.get("STASO_GUARD_ENABLED", "true").lower() != "false"
        if guard_enabled:
            try:
                from staso.guard import guard

                tool_name = payload.get("tool_name", "unknown")
                tool_input = payload.get("tool_input") or {}
                guard_timeout = float(os.environ.get("STASO_GUARD_TIMEOUT", "10"))

                result = guard(
                    tool_name=tool_name,
                    tool_input=tool_input,
                    context={
                        "agent_id": _AGENT_ID,
                        "agent_name": _AGENT_NAME,
                        "trace_id": state.current_trace_id or "",
                        "session_id": state.session_id,
                    },
                    timeout=guard_timeout,
                )

                if result.action == "block":
                    # Record a span for the blocked tool call so it appears in traces
                    sender = _sender or sender_from_env()
                    if sender is not None:
                        blocked_span = base_span(
                            trace_id=state.current_trace_id or new_id(),
                            span_id=new_id(),
                            parent_span_id=state.current_turn_span_id,
                            name=f"guard:blocked:{tool_name}",
                            kind="tool",
                            timestamp=now_iso(),
                            duration_ms=result.latency_ms,
                            session_id=state.session_id,
                            agent_name=_AGENT_NAME,
                            agent_id=_AGENT_ID,
                            status="error",
                            input_data={"tool_name": tool_name, "tool_input": tool_input},
                            output_data={"action": "block", "reason": result.reason, "rules_triggered": result.rules_triggered},
                            metadata={"guard_action": "block", "guard_reason": result.reason, "source": _SOURCE},
                            error_message=f"Guard blocked: {result.reason}",
                        )
                        sender.send([blocked_span])
                    return {
                        "decision": "block",
                        "reason": result.reason or "Blocked by guard",
                    }
                elif result.action == "modify" and result.modified_input is not None:
                    # Record a span for the modified tool call so it appears in traces
                    sender = _sender or sender_from_env()
                    if sender is not None:
                        modified_span = base_span(
                            trace_id=state.current_trace_id or new_id(),
                            span_id=new_id(),
                            parent_span_id=state.current_turn_span_id,
                            name=f"guard:modified:{tool_name}",
                            kind="tool",
                            timestamp=now_iso(),
                            duration_ms=result.latency_ms,
                            session_id=state.session_id,
                            agent_name=_AGENT_NAME,
                            agent_id=_AGENT_ID,
                            status="ok",
                            input_data={"tool_name": tool_name, "tool_input": tool_input},
                            output_data={"action": "modify", "modified_input": result.modified_input, "modifications": result.modifications},
                            metadata={"guard_action": "modify", "guard_reason": result.reason, "source": _SOURCE},
                        )
                        sender.send([modified_span])
                    return {
                        "decision": "modify",
                        "tool_input": result.modified_input,
                    }

                # "allow" — check if any audit-mode rules fired (would have blocked)
                if result.results:
                    audit_rules = [r for r in result.results if not r.passed]
                    if audit_rules:
                        sender = _sender or sender_from_env()
                        if sender is not None:
                            audit_span = base_span(
                                trace_id=state.current_trace_id or new_id(),
                                span_id=new_id(),
                                parent_span_id=state.current_turn_span_id,
                                name=f"guard:would-block:{tool_name}",
                                kind="tool",
                                timestamp=now_iso(),
                                duration_ms=result.latency_ms,
                                session_id=state.session_id,
                                agent_name=_AGENT_NAME,
                                agent_id=_AGENT_ID,
                                status="ok",
                                input_data={"tool_name": tool_name, "tool_input": tool_input},
                                output_data={
                                    "action": "would_block",
                                    "reason": "; ".join(r.reason for r in audit_rules if r.reason),
                                    "rules_triggered": [
                                        {"rule_name": r.rule_name, "action": r.action, "reason": r.reason, "severity": getattr(r, "severity", "medium")}
                                        for r in audit_rules
                                    ],
                                },
                                metadata={"guard_action": "would_block", "guard_mode": "audit", "source": _SOURCE},
                            )
                            sender.send([audit_span])
            except Exception:
                # Fail-open: on any error, allow the tool call
                logger.warning("staso: guard evaluation failed, defaulting to allow", exc_info=True)

        return None
    finally:
        release_lock(session_id)


def handle_post_tool_use(payload: dict[str, Any], sender: SpanSender) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        state = _load_active_state(session_id)
        if state is None:
            return

        now = time.time()
        tool_use_id = payload.get("tool_use_id", "")
        start_time = state.pending_tool_starts.pop(tool_use_id, None)
        duration_ms = (now - start_time) * 1000 if start_time else 0.0

        tool_name = payload.get("tool_name", "unknown")
        tool_input = payload.get("tool_input") or {}
        tool_response = payload.get("tool_response") or {}
        cwd = state.cwd or payload.get("cwd", "")

        span = base_span(
            trace_id=state.current_trace_id,
            span_id=new_id(),
            parent_span_id=state.current_turn_span_id,
            name=f"tool:{tool_name}",
            kind="tool",
            timestamp=ts_to_iso(start_time) if start_time else now_iso(),
            duration_ms=duration_ms,
            session_id=session_id,
            agent_name=_AGENT_NAME,
            agent_id=_AGENT_ID,
            input_data={"tool_input": tool_input},
            output_data={"tool_response": tool_response},
            metadata={"tool_name": tool_name, "source": _SOURCE, "cwd": cwd},
        )
        sender.send([span])
        save_state(state)
    finally:
        release_lock(session_id)


def handle_post_tool_use_failure(payload: dict[str, Any], sender: SpanSender) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        state = _load_active_state(session_id)
        if state is None:
            return

        now = time.time()
        tool_use_id = payload.get("tool_use_id", "")
        start_time = state.pending_tool_starts.pop(tool_use_id, None)
        duration_ms = (now - start_time) * 1000 if start_time else 0.0

        tool_name = payload.get("tool_name", "unknown")
        error = payload.get("error", "")

        span = base_span(
            trace_id=state.current_trace_id,
            span_id=new_id(),
            parent_span_id=state.current_turn_span_id,
            name=f"tool:{tool_name}",
            kind="tool",
            timestamp=ts_to_iso(start_time) if start_time else now_iso(),
            duration_ms=duration_ms,
            session_id=session_id,
            agent_name=_AGENT_NAME,
            agent_id=_AGENT_ID,
            status="error",
            input_data={"tool_input": payload.get("tool_input") or {}},
            metadata={"tool_name": tool_name, "source": _SOURCE},
            error_message=error,
        )
        sender.send([span])
        save_state(state)
    finally:
        release_lock(session_id)


def handle_stop(payload: dict[str, Any], sender: SpanSender | None) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        state = load_state(session_id)
        if state is None or state.current_trace_id is None or state.current_turn_span_id is None:
            return

        transcript_path = payload.get("transcript_path", "")
        llm_messages, new_line = parse_assistant_messages(
            transcript_path, state.last_transcript_line
        )

        if sender is not None:
            spans: list[dict[str, Any]] = []
            project_name = os.path.basename(state.cwd) if state.cwd else _SOURCE
            turn_end = time.time()
            turn_start = state.current_turn_start or turn_end
            turn_duration_ms = (turn_end - turn_start) * 1000

            for i, msg in enumerate(llm_messages):
                ts = msg.timestamp if msg.timestamp else ts_to_iso(turn_start)
                ts_epoch = parse_iso_to_epoch(ts)
                if i + 1 < len(llm_messages):
                    next_ts = llm_messages[i + 1].timestamp
                    next_epoch = parse_iso_to_epoch(next_ts)
                    if ts_epoch and next_epoch:
                        llm_duration_ms = max((next_epoch - ts_epoch) * 1000, 0.0)
                    else:
                        llm_duration_ms = 0.0
                else:
                    llm_duration_ms = (
                        max((turn_end - ts_epoch) * 1000, 0.0) if ts_epoch else 0.0
                    )

                is_synthetic = msg.model.startswith("<")
                if is_synthetic:
                    content_text = " ".join(
                        b.get("text", "") for b in msg.content if b.get("type") == "text"
                    ).strip()
                    llm_span = base_span(
                        trace_id=state.current_trace_id,
                        span_id=new_id(),
                        parent_span_id=state.current_turn_span_id,
                        name="internal",
                        kind="custom",
                        timestamp=ts,
                        duration_ms=llm_duration_ms,
                        session_id=session_id,
                        agent_name=_AGENT_NAME,
                        agent_id=_AGENT_ID,
                        output_data={"content": msg.content} if msg.content else None,
                        metadata={
                            "source": _SOURCE,
                            "synthetic": True,
                            "synthetic_content": content_text,
                        },
                    )
                else:
                    llm_span = base_span(
                        trace_id=state.current_trace_id,
                        span_id=new_id(),
                        parent_span_id=state.current_turn_span_id,
                        name=f"llm:{msg.model}" if msg.model else "llm:claude",
                        kind="llm",
                        timestamp=ts,
                        duration_ms=llm_duration_ms,
                        session_id=session_id,
                        agent_name=_AGENT_NAME,
                        agent_id=_AGENT_ID,
                        model=msg.model,
                        input_tokens=msg.input_tokens,
                        output_tokens=msg.output_tokens,
                        total_tokens=msg.total_tokens,
                        output_data={"content": msg.content} if msg.content else None,
                        metadata={
                            "source": _SOURCE,
                            "response_id": msg.message_id,
                            "cache_read_input_tokens": msg.cache_read_tokens,
                            "cache_creation_input_tokens": msg.cache_creation_tokens,
                        },
                    )
                spans.append(llm_span)

            total_in, total_out, last_model = _aggregate_llm_messages(llm_messages)

            turn_span = base_span(
                trace_id=state.current_trace_id,
                span_id=state.current_turn_span_id,
                parent_span_id=None,
                name=turn_span_name(state.current_turn_prompt, state.turn_count),
                kind="agent",
                timestamp=ts_to_iso(turn_start),
                duration_ms=turn_duration_ms,
                session_id=session_id,
                agent_name=_AGENT_NAME,
                agent_id=_AGENT_ID,
                model=last_model,
                input_tokens=total_in,
                output_tokens=total_out,
                total_tokens=total_in + total_out,
                input_data=(
                    {"prompt": state.current_turn_prompt} if state.current_turn_prompt else None
                ),
                output_data=(
                    {"response": payload.get("last_assistant_message", "")}
                    if payload.get("last_assistant_message")
                    else None
                ),
                metadata={
                    "source": _SOURCE,
                    "project": project_name,
                    "cwd": state.cwd,
                    "turn_number": state.turn_count,
                },
            )
            spans.append(turn_span)

            sender.send(spans)

        # Always reset turn state, even if sender is unavailable
        state.current_trace_id = None
        state.current_turn_span_id = None
        state.current_turn_start = None
        state.current_turn_prompt = ""
        state.last_transcript_line = new_line
        state.pending_tool_starts.clear()
        state.pending_subagent_starts.clear()
        save_state(state)
    finally:
        release_lock(session_id)


def handle_stop_failure(payload: dict[str, Any], sender: SpanSender | None) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        state = load_state(session_id)
        if state is None or state.current_trace_id is None or state.current_turn_span_id is None:
            return

        if sender is not None:
            turn_end = time.time()
            turn_start = state.current_turn_start or turn_end
            turn_duration_ms = (turn_end - turn_start) * 1000
            project_name = os.path.basename(state.cwd) if state.cwd else _SOURCE
            error_type = payload.get("error", "unknown")
            error_details = payload.get("error_details", "")

            turn_span = base_span(
                trace_id=state.current_trace_id,
                span_id=state.current_turn_span_id,
                parent_span_id=None,
                name=turn_span_name(state.current_turn_prompt, state.turn_count),
                kind="agent",
                timestamp=ts_to_iso(turn_start),
                duration_ms=turn_duration_ms,
                session_id=session_id,
                agent_name=_AGENT_NAME,
                agent_id=_AGENT_ID,
                status="error",
                input_data=(
                    {"prompt": state.current_turn_prompt} if state.current_turn_prompt else None
                ),
                metadata={
                    "source": _SOURCE,
                    "project": project_name,
                    "cwd": state.cwd,
                    "turn_number": state.turn_count,
                    "error_type": error_type,
                },
                error_message=f"{error_type}: {error_details}" if error_details else error_type,
            )
            sender.send([turn_span])

        state.current_trace_id = None
        state.current_turn_span_id = None
        state.current_turn_start = None
        state.current_turn_prompt = ""
        state.pending_tool_starts.clear()
        state.pending_subagent_starts.clear()
        save_state(state)
    finally:
        release_lock(session_id)


def handle_subagent_start(payload: dict[str, Any], _sender: SpanSender) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        state = _load_active_state(session_id)
        if state is None:
            return
        agent_id = payload.get("agent_id", "")
        if agent_id:
            state.pending_subagent_starts[agent_id] = time.time()
            save_state(state)
    finally:
        release_lock(session_id)


def handle_subagent_stop(payload: dict[str, Any], sender: SpanSender) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        state = _load_active_state(session_id)
        if state is None:
            return

        now = time.time()
        agent_id = payload.get("agent_id", "")
        start_time = state.pending_subagent_starts.pop(agent_id, None)
        duration_ms = (now - start_time) * 1000 if start_time else 0.0

        transcript_path = payload.get("agent_transcript_path") or payload.get(
            "transcript_path", ""
        )
        llm_messages, _ = parse_assistant_messages(transcript_path, 0)

        total_in, total_out, last_model = _aggregate_llm_messages(llm_messages)

        agent_type = payload.get("agent_type", "")

        span = base_span(
            trace_id=state.current_trace_id,
            span_id=new_id(),
            parent_span_id=state.current_turn_span_id,
            name=f"subagent:{agent_type}" if agent_type else "subagent",
            kind="agent",
            timestamp=ts_to_iso(start_time) if start_time else now_iso(),
            duration_ms=duration_ms,
            session_id=session_id,
            agent_name=_AGENT_NAME,
            agent_id=_AGENT_ID,
            model=last_model,
            input_tokens=total_in,
            output_tokens=total_out,
            total_tokens=total_in + total_out,
            metadata={
                "source": _SOURCE,
                "subagent": True,
                "agent_id": agent_id,
                "agent_type": agent_type,
            },
        )
        sender.send([span])
        save_state(state)
    finally:
        release_lock(session_id)


def handle_session_end(payload: dict[str, Any], _sender: SpanSender) -> None:
    session_id = payload["session_id"]
    if not acquire_lock(session_id):
        return
    try:
        delete_state(session_id)
    finally:
        release_lock(session_id)


# -- dispatcher ----------------------------------------------------------------

_HANDLERS = {
    "SessionStart": handle_session_start,
    "UserPromptSubmit": handle_user_prompt_submit,
    "PreToolUse": handle_pre_tool_use,
    "PostToolUse": handle_post_tool_use,
    "PostToolUseFailure": handle_post_tool_use_failure,
    "Stop": handle_stop,
    "StopFailure": handle_stop_failure,
    "SubagentStart": handle_subagent_start,
    "SubagentStop": handle_subagent_stop,
    "SessionEnd": handle_session_end,
}

# Events that can proceed without a sender (state-only or guard-only operations)
_SENDERLESS_EVENTS = frozenset(
    ("SessionStart", "UserPromptSubmit", "PreToolUse", "Stop", "StopFailure", "SessionEnd")
)


def run(payload: dict[str, Any]) -> None:
    """Dispatch a hook payload to the appropriate handler."""
    event = payload.get("hook_event_name", "")
    handler = _HANDLERS.get(event)
    if handler is None:
        return

    sender = sender_from_env()
    if sender is None and event not in _SENDERLESS_EVENTS:
        return

    try:
        result = handler(payload, sender)  # type: ignore[arg-type]
        # PreToolUse can return a decision dict to output to stdout
        if result is not None and isinstance(result, dict):
            sys.stdout.write(json.dumps(result))
            sys.stdout.flush()
    except Exception:
        logger.warning("staso: %s handler error", event, exc_info=True)


def main() -> None:
    """Entry point: read JSON from stdin, run the hook."""
    debug = os.environ.get("STASO_DEBUG", "").lower() in ("1", "true")
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.WARNING,
        format="%(levelname)s staso: %(message)s",
    )
    try:
        payload = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("staso: failed to read hook payload: %s", exc)
        sys.exit(0)

    run(payload)
