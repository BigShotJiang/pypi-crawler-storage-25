"""Types for the guard API."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class GuardRuleResult:
    """Result of a single guard rule check."""
    rule_id: str = ""
    rule_name: str = ""
    passed: bool = True
    score: float | None = None
    action: str = "audit"
    reason: str = ""
    latency_ms: float = 0.0
    violations: list[dict[str, Any]] = field(default_factory=list)


@dataclass(frozen=True)
class GuardResult:
    """Result of a guard check."""
    action: str  # "allow" | "block" | "modify" | "escalate"
    reason: str = ""
    rule_name: str | None = None
    severity: str = "low"
    results: list[GuardRuleResult] = field(default_factory=list)
    modified_input: dict[str, Any] | None = None
    modifications: list[dict[str, Any]] = field(default_factory=list)
    escalation_id: str | None = None
    latency_ms: float = 0.0
    rules_triggered: list[str] = field(default_factory=list)
