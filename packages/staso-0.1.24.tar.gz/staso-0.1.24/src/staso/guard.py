"""Guard API — check agent actions before they execute."""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from staso.client import get_client
from staso.guard_types import GuardResult, GuardRuleResult

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 10.0  # seconds


def _get_version() -> str:
    try:
        from staso._version import __version__
        return __version__
    except Exception:
        return "unknown"
_DEFAULT_ESCALATION_POLL_INTERVAL = 3.0  # seconds
_DEFAULT_ESCALATION_TIMEOUT = 300.0  # seconds


def guard(
    tool_name: str,
    tool_input: dict[str, Any],
    *,
    context: dict[str, Any] | None = None,
    wait_for_escalation: bool = False,
    escalation_poll_interval: float = _DEFAULT_ESCALATION_POLL_INTERVAL,
    escalation_timeout: float = _DEFAULT_ESCALATION_TIMEOUT,
    timeout: float = _DEFAULT_TIMEOUT,
) -> GuardResult:
    """Check an agent action before executing it.

    Call this before executing a tool. Returns a GuardResult with the decision.

    If action == "modify": use result.modified_input instead of original.
    If action == "escalate" and wait_for_escalation=True:
        Polls until a human resolves the escalation.
        Returns final action (allow/block) after resolution.
    If action == "escalate" and wait_for_escalation=False:
        Returns immediately. Treat as block.

    Args:
        tool_name: Name of the tool being called
        tool_input: The tool's input parameters
        context: Optional context (session_id, agent_name, trace_id, environment, workspace_id)
        wait_for_escalation: If True, poll until escalation is resolved
        escalation_poll_interval: Seconds between polls (default 3)
        escalation_timeout: Max seconds to wait for escalation (default 300)
        timeout: HTTP request timeout in seconds

    Returns:
        GuardResult with the decision
    """
    client = get_client()

    # Resolve config from client or fall back to env vars (for hook subprocesses)
    if client is not None and client.config.enabled:
        config = client.config
        api_key = config.api_key
        base_url = config.base_url.rstrip("/")
        default_context = {
            "agent_id": config.agent_id,
            "agent_name": config.agent_name,
            "environment": config.environment,
            "workspace_id": config.workspace_slug,
        }
    else:
        api_key = os.environ.get("STASO_API_KEY", "")
        if not api_key:
            return GuardResult(action="allow", reason="Guard not initialized")
        base_url = os.environ.get("STASO_BASE_URL", "https://api.staso.ai").rstrip("/")
        default_context = {
            "agent_id": "",
            "agent_name": os.environ.get("STASO_AGENT_NAME", ""),
            "environment": os.environ.get("STASO_ENVIRONMENT", "default"),
            "workspace_id": os.environ.get("STASO_WORKSPACE_SLUG", "default"),
        }

    # Build request payload
    payload = {
        "tool_name": tool_name,
        "tool_input": tool_input,
        "context": {
            **default_context,
            **(context or {}),
        },
    }

    start = time.monotonic()

    try:
        response = _post(
            url=f"{base_url}/v1/guard/evaluate",
            api_key=api_key,
            payload=payload,
            timeout=timeout,
        )
    except Exception as e:
        logger.warning("Guard check failed: %s", e)
        return GuardResult(action="allow", reason=f"Guard check failed: {e}")

    latency_ms = (time.monotonic() - start) * 1000

    # Parse response
    result = _parse_response(response, latency_ms)

    # Handle escalation polling
    if result.action == "escalate" and wait_for_escalation and result.escalation_id:
        result = _poll_escalation(
            base_url=base_url,
            api_key=config.api_key,
            escalation_id=result.escalation_id,
            poll_interval=escalation_poll_interval,
            timeout=escalation_timeout,
            original_result=result,
        )

    return result


def _post(url: str, api_key: str, payload: dict, timeout: float) -> dict:
    """Make a POST request to the guard API."""
    data = json.dumps(payload, default=str).encode("utf-8")
    req = Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "X-API-Key": api_key,
            "User-Agent": f"staso-python/{_get_version()}",
        },
        method="POST",
    )

    with urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _get(url: str, api_key: str, timeout: float) -> dict:
    """Make a GET request."""
    req = Request(
        url,
        headers={
            "X-API-Key": api_key,
            "User-Agent": f"staso-python/{_get_version()}",
        },
        method="GET",
    )
    with urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _parse_response(data: dict, latency_ms: float) -> GuardResult:
    """Parse API response into GuardResult."""
    results = []
    for r in data.get("results", []):
        rule_action = r.get("action", "allow")
        results.append(GuardRuleResult(
            rule_id=r.get("rule_id", ""),
            rule_name=r.get("rule_name", ""),
            passed=rule_action == "allow",
            score=r.get("score"),
            action=rule_action,
            reason=r.get("reason", ""),
            latency_ms=r.get("latency_ms", 0.0),
            violations=r.get("violations", []),
        ))

    # Derive rules_triggered from individual results (backend doesn't send this separately)
    triggered = data.get("rules_triggered", [])
    if not triggered:
        triggered = [r.rule_name for r in results if not r.passed]

    return GuardResult(
        action=data.get("action", "allow"),
        reason=data.get("reason", ""),
        rule_name=triggered[0] if triggered else None,
        severity=data.get("severity", "low"),
        results=results,
        modified_input=data.get("modified_input"),
        modifications=data.get("modifications", []),
        escalation_id=data.get("escalation_id"),
        latency_ms=latency_ms,
        rules_triggered=triggered,
    )


def _poll_escalation(
    base_url: str,
    api_key: str,
    escalation_id: str,
    poll_interval: float,
    timeout: float,
    original_result: GuardResult,
) -> GuardResult:
    """Poll escalation status until resolved or timeout."""
    import time as _time

    start = _time.monotonic()
    url = f"{base_url}/v1/guard/escalations/{escalation_id}/status"

    while (_time.monotonic() - start) < timeout:
        try:
            status_data = _get(url, api_key, timeout=10.0)
            status = status_data.get("status", "pending")

            if status == "approved":
                return GuardResult(
                    action="allow",
                    reason="Escalation approved",
                    escalation_id=escalation_id,
                    latency_ms=(time.monotonic() - start) * 1000,
                    rules_triggered=original_result.rules_triggered,
                    severity=original_result.severity,
                )
            elif status in ("denied", "timeout"):
                return GuardResult(
                    action="block",
                    reason=f"Escalation {status}",
                    escalation_id=escalation_id,
                    latency_ms=(time.monotonic() - start) * 1000,
                    rules_triggered=original_result.rules_triggered,
                    severity=original_result.severity,
                )

            # Still pending, wait
            _time.sleep(poll_interval)

        except Exception as e:
            logger.warning("Escalation poll failed: %s", e)
            _time.sleep(poll_interval)

    # Timeout waiting for escalation
    return GuardResult(
        action="block",
        reason="Escalation poll timeout",
        escalation_id=escalation_id,
        latency_ms=(time.monotonic() - start) * 1000,
        rules_triggered=original_result.rules_triggered,
        severity=original_result.severity,
    )
