"""CLI runner for persona-based integration tests.

Usage (from repo root):
    uv run python tests/integration-tests/personas/common/run_persona_test.py \
        --persona customer-support --scenario billing_inquiry --provider openai --env staging

Usage (from tests/integration-tests/):
    uv run python personas/common/run_persona_test.py \
        --persona finance-ops --scenario cumulative_evasion --provider anthropic --env staging

To run via pytest instead (recommended):
    # From repo root:
    uv run pytest tests/integration-tests/ -m integration -k test_billing_inquiry -v
    # From tests/integration-tests/:
    uv run pytest -m integration -k test_billing_inquiry -v

Scenario names are defined in integration-tests/personas/INDEX.md.

The runner:
1. Initialises the Staso SDK with the given environment.
2. Imports the persona's harness module.
3. Calls run_scenario(scenario, provider, env).
4. Calls st.shutdown() to flush all pending spans.
5. Prints a summary of the result.

Environment variables required:
    STASO_API_KEY      -- Staso API key
    STASO_BASE_URL     -- Staso backend URL (default: https://api.staso.ai)
    OPENAI_API_KEY     -- Required when --provider openai
    ANTHROPIC_API_KEY  -- Required when --provider anthropic
"""
from __future__ import annotations

import argparse
import importlib
import importlib.util
import json
import os
import sys
import time

from pydantic_settings import BaseSettings, SettingsConfigDict


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

class RunnerSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    staso_api_key: str
    staso_base_url: str = "https://api.staso.ai"
    openai_api_key: str = ""
    anthropic_api_key: str = ""


# ---------------------------------------------------------------------------
# Supported personas
# ---------------------------------------------------------------------------

PERSONAS = {"customer-support", "finance-ops", "code-agent", "research-agent", "orchestrator"}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a persona-based e2e integration test against Staso.",
    )
    parser.add_argument(
        "--persona",
        required=True,
        choices=sorted(PERSONAS),
        help="Agent persona to test (customer-support, finance-ops, code-agent, research-agent, orchestrator).",
    )
    parser.add_argument(
        "--scenario",
        required=True,
        help="Scenario name to run, e.g. billing_inquiry, amnesia. See INDEX.md for all names.",
    )
    parser.add_argument(
        "--provider",
        default="openai",
        choices=["openai", "anthropic"],
        help="LLM provider (default: openai).",
    )
    parser.add_argument(
        "--env",
        default="staging",
        help="Staso environment tag (default: staging). Traces land in the staging workspace.",
    )
    args = parser.parse_args()

    settings = RunnerSettings()

    # Validate provider key is present
    if args.provider == "openai" and not settings.openai_api_key:
        sys.exit("Error: OPENAI_API_KEY is required when --provider openai")
    if args.provider == "anthropic" and not settings.anthropic_api_key:
        sys.exit("Error: ANTHROPIC_API_KEY is required when --provider anthropic")

    # Propagate provider keys into the environment so provider.py can pick them up
    if settings.openai_api_key:
        os.environ["OPENAI_API_KEY"] = settings.openai_api_key
    if settings.anthropic_api_key:
        os.environ["ANTHROPIC_API_KEY"] = settings.anthropic_api_key

    # Initialise Staso SDK
    import staso as st
    st.init(
        api_key=settings.staso_api_key,
        agent_name=f"{args.persona}-e2e-agent",
        base_url=settings.staso_base_url,
        environment=args.env,
        debug=True,
    )

    # Import the persona's scenarios module dynamically
    # Assumes run_persona_test.py is executed from the personas/ directory or that
    # personas/ is on sys.path. Adjust sys.path if needed.
    personas_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if personas_dir not in sys.path:
        sys.path.insert(0, personas_dir)

    # CLI uses hyphens (e.g. "customer-support") but directory names use underscores.
    # Convert hyphens to underscores for filesystem lookup.
    persona_slug = args.persona.replace("-", "_")
    persona_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), persona_slug)
    harness_path = os.path.join(persona_dir, "harness.py")
    if not os.path.exists(harness_path):
        st.shutdown()
        sys.exit(f"Error: harness.py not found for persona '{args.persona}' at {harness_path}")

    spec = importlib.util.spec_from_file_location("harness", harness_path)
    harness_module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(harness_module)
    except Exception as exc:
        st.shutdown()
        sys.exit(f"Error: could not import {harness_path}: {exc}")

    if not hasattr(harness_module, "run_scenario"):
        st.shutdown()
        sys.exit(f"Error: {harness_path} does not expose a run_scenario() function.")

    # Run the scenario
    print("-" * 60)
    print(f"Persona  : {args.persona}")
    print(f"Scenario : {args.scenario}")
    print(f"Provider : {args.provider}")
    print(f"Env      : {args.env}")
    print("-" * 60)

    start = time.monotonic()
    try:
        result = harness_module.run_scenario(
            scenario=args.scenario,
            provider=args.provider,
            env=args.env,
        )
    except Exception as exc:
        st.shutdown()
        sys.exit(f"Scenario raised an unhandled exception: {exc}")
    elapsed = time.monotonic() - start

    # Flush all pending spans
    st.shutdown()

    # Print result
    print("\nResult:")
    if isinstance(result, dict):
        print(json.dumps(result, indent=2, default=str))
    else:
        print(result)

    print(f"\nCompleted in {elapsed:.1f}s")


if __name__ == "__main__":
    main()
