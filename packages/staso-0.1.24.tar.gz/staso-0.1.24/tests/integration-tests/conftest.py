"""pytest configuration for integration tests.

Adds integration-tests/ to sys.path so all persona modules are importable
as `personas.*` without per-file path hacks.

Marks:
    integration  -- requires live LLM API keys and a running Staso backend
    atomic       -- single-capability, fast (<10s), no persona setup needed
    slow         -- multi-turn or multi-pipeline scenarios (>30s expected)

Run subsets:
    pytest -m atomic                          # atomic layer only
    pytest -m "integration and not slow"      # atomic + persona happy paths
    pytest -m integration                     # everything
"""
from __future__ import annotations

import json
import os
import sys

import pytest

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# Load .env from integration-tests/ if present (no python-dotenv dependency needed)
_ENV_FILE = os.path.join(_ROOT, ".env")
if os.path.exists(_ENV_FILE):
    with open(_ENV_FILE) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip())


_ALL_PROVIDERS = ["openai", "anthropic"]


def pytest_addoption(parser):
    parser.addoption(
        "--persona",
        default=None,
        help="Run tests for a specific persona: customer_support | finance_ops | code_agent | orchestrator | research_agent",
    )
    parser.addoption(
        "--providers",
        default=None,
        help="Comma-separated providers to test: openai,anthropic (default: whatever each test specifies)",
    )


def pytest_configure(config):
    config.addinivalue_line("markers", "integration: requires live LLM + Staso backend")
    config.addinivalue_line("markers", "atomic: single-capability, fast, no persona setup")
    config.addinivalue_line("markers", "slow: multi-turn or multi-pipeline, expect >30s")


def pytest_generate_tests(metafunc):
    """Centralized provider parametrization for all integration tests.

    All tests that accept a 'provider' argument are parametrized here.
    No test file should use @pytest.mark.parametrize("provider", ...) directly.

    --providers openai,anthropic   -> run both providers for all tests
    --providers openai             -> run only openai
    (no flag)                      -> openai only (default)
    """
    if "provider" not in metafunc.fixturenames:
        return

    providers_opt = metafunc.config.getoption("--providers")
    if providers_opt:
        providers = [p.strip() for p in providers_opt.split(",")]
    else:
        providers = ["openai"]

    metafunc.parametrize("provider", providers)


def pytest_collection_modifyitems(config, items):
    persona = config.getoption("--persona")
    if not persona:
        return
    skip = pytest.mark.skip(reason=f"--persona={persona} filter")
    for item in items:
        if f"test_{persona}" not in item.fspath.basename:
            item.add_marker(skip)


_RESULTS_DIR = os.path.join(_ROOT, "results")


@pytest.fixture
def save_result():
    """Return a callable that saves a scenario result dict to results/<scenario>_<provider>.json."""
    def _save(result: dict, provider: str) -> None:
        os.makedirs(_RESULTS_DIR, exist_ok=True)
        scenario = result.get("scenario", "unknown")
        path = os.path.join(_RESULTS_DIR, f"{scenario}_{provider}.json")
        with open(path, "w") as f:
            json.dump(result, f, indent=2)
    return _save


@pytest.fixture(scope="session")
def staso_env() -> str:
    return os.environ.get("STASO_ENVIRONMENT", os.environ.get("STASO_ENV", "staging"))


@pytest.fixture(scope="session", autouse=True)
def staso_session(staso_env):
    """Initialise the Staso SDK once per test session and shut down after."""
    api_key = os.environ.get("STASO_API_KEY", "")
    if not api_key:
        pytest.skip("STASO_API_KEY not set -- skipping all integration tests")

    import staso as st
    st.init(
        api_key=api_key,
        agent_name="integration-test-session",
        base_url=os.environ.get("STASO_BASE_URL", "https://api.staso.ai"),
        environment=staso_env,
        debug=False,
    )
    yield
    st.shutdown()
