"""Shared fixtures for Staso SDK tests."""
from __future__ import annotations

import pytest

import staso as st
from staso.client import Client, _set_client
from staso.config import Config
from staso.context import session_id_var, user_id_var
from staso.provider import TracerProvider
from staso.annotation import shutdown_annotation_client


@pytest.fixture(autouse=True)
def _clean_global_state():
    """Reset global SDK state between tests."""
    yield
    client = st.get_client()
    if client and client._transport:
        try:
            client._transport.shutdown()
        except Exception:
            pass
    _set_client(None)  # type: ignore[arg-type]
    session_id_var.set("")
    user_id_var.set("")
    shutdown_annotation_client()


@pytest.fixture
def capturing(mocker):
    """Set up a mock transport that captures enqueued span dicts."""
    captured: list[dict] = []
    transport = mocker.MagicMock()
    transport.enqueue.side_effect = lambda d: captured.append(d)

    cfg = Config(api_key="test-key", agent_name="test-agent", enabled=False)
    client = Client.__new__(Client)
    client._config = cfg
    client._transport = transport
    client._provider = TracerProvider(
        transport=transport, agent_name="test-agent", enabled=True
    )
    _set_client(client)
    return captured
