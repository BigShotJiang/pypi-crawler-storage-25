import logging
from enum import Enum, EnumType

logger = logging.getLogger(__name__)


class IlluminationMethod(Enum):
    BGR = 'bgr'  # Fastest, no conversion (ITU-R BT.601)
    GRAY = 'gray'  # Moderate speed, grayscale conversion
    LAB = 'lab'  # Slowest, most accurate (CIELAB L channel)


class IlluminationCurveType(Enum):
    LINEAR = 'linear'           # Linear interpolation (predictable)
    EXPONENTIAL = 'exponential' # Aggressive for low light (night driving)
    LOGARITHMIC = 'logarithmic' # Gentle for low light (variable lighting)
    GAUSSIAN = 'gaussian'


class LightingCondition(Enum):
    NIGHT = 'night'             # 0.0-0.2 (very dark)
    DUSK = 'dusk'               # 0.2-0.4 (dawn/dusk)
    CLOUDY = 'cloudy'           # 0.4-0.6 (overcast)
    SUNNY = 'sunny'             # 0.6-0.9 (bright daylight)
    OVEREXPOSED = 'overexposed' # 0.9-1.0 (glare/overexposure)