"""
model: Type-safe spatial primitives for YOLO detection pipelines.

Provides validated geometric containers (Point, Box, Polygon, Obb, YOLOInstance)
with normalized coordinate support and immutable transformations.
"""

from acmenra_cv.model.point import Point
from acmenra_cv.model.box import Box
from acmenra_cv.model.obb import Obb
from acmenra_cv.model.polygon import Polygon
from acmenra_cv.model.instance import Instance

__all__ = [
    'Point',
    'Box',
    'Polygon',
    'Obb',
    'Instance',
]

__version__ = "0.1.5.5"