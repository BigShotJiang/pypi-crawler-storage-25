import logging
from enum import Enum


logger = logging.getLogger(__name__)


class TaskType(Enum):
    DETECT = 'detect'           # Object detection (bounding boxes)
    SEGMENT = 'segment'         # Instance segmentation (masks + boxes)
    CLASSIFY = 'classify'       # Image classification
    POSE = 'pose'               # Pose estimation (keypoints)
    OBB = 'obb'                 # Oriented bounding boxes (rotated)
    TRACK = 'track'             # Multi-object tracking
    DETECT_TRACK = 'detect_track'  # Detection + tracking combined
    WORLD = 'world'             # YOLO-World (open-vocabulary detection)
    E = 'e'                     # YOLOE (enhanced version)
    RTDETR = 'rtdetr'           # RT-DETR (real-time detection transformer)


class DeviceType(Enum):
    AUTO = 'auto'
    MPS = 'mps'
    CPU = 'cpu'
    GPU = 'gpu'
    NPU = 'npu'
    NPU_RK3588 = 'npu:rk3588'
    NPU_INTEL = 'npu:intel'
    NPU_HAILO = 'npu:hailo'
    TPU = 'tpu'
    TPU_CORAL = 'tpu:coral'
    CUDA = 'cuda'
    CUDA_0 = 'cuda:0'
    CUDA_1 = 'cuda:1'
    CUDA_2 = 'cuda:2'
    CUDA_3 = 'cuda:3'
    TENSORRT = 'tensorrt'








