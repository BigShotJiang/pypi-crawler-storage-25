"""ImageProvider adapter for the existing Gemini image generation service."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from datetime import datetime, timezone
from pathlib import Path

from stable_delusion.providers.image_provider import ImageProvider, ImageResult
from stable_delusion.providers.types import Cost, ImageGenParams, Capabilities
from stable_delusion.models.requests import GenerateImageRequest


class GeminiProvider(ImageProvider):
    """Adapter that wraps GeminiImageGenerationService as an ImageProvider."""

    _COST_PER_IMAGE_USD = 0.04

    def __init__(
        self,
        project_id: str | None = None,
        location: str | None = None,
        output_dir: Path | None = None,
    ) -> None:
        from stable_delusion import builders  # pylint: disable=cyclic-import

        self._service = builders.create_image_generation_service(
            project_id=project_id,
            location=location,
            output_dir=output_dir,
            model="gemini",
        )

    @property
    def name(self) -> str:
        return "gemini"

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities(
            text_to_media=True,
            media_to_media=True,
            supported_resolutions=("1K", "2K"),
            supported_ratios=("1:1", "16:9", "9:16", "4:3", "3:4"),
        )

    def generate(
        self, prompt: str, source_images: list[Path], params: ImageGenParams
    ) -> ImageResult:
        request = GenerateImageRequest(
            prompt=prompt,
            images=source_images,
            scale=None,
            model="gemini",
        )
        response = self._service.generate_image(request)

        cost = Cost(
            amount=self._COST_PER_IMAGE_USD,
            currency="USD",
            input_tokens=0,
            output_tokens=0,
            model="gemini",
            timestamp=datetime.now(timezone.utc),
        )

        image_path = response.generated_file if response.generated_file else Path("unknown")
        return ImageResult(image_paths=[image_path], cost=cost)

    def estimate_cost(self, params: ImageGenParams) -> Cost:
        return Cost(
            amount=self._COST_PER_IMAGE_USD,
            currency="USD",
            input_tokens=0,
            output_tokens=0,
            model="gemini",
            timestamp=datetime.now(timezone.utc),
        )
