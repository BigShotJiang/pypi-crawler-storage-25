"""Shared data types for the provider plugin architecture."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class TaskState(Enum):
    """Possible states for an async video generation task."""

    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class Cost:
    """Cost of a single API call."""

    amount: float
    currency: str
    input_tokens: int
    output_tokens: int
    model: str
    timestamp: datetime


@dataclass(frozen=True)
class ImageGenParams:
    """Parameters for image generation."""

    image_size: str = "2K"
    seed: int | None = None
    aspect_ratio: str | None = None


@dataclass(frozen=True)
class VideoGenParams:
    """Parameters for video generation."""

    resolution: str = "720p"
    ratio: str = "16:9"
    duration: int = 8
    generate_audio: bool = False
    return_last_frame: bool = True
    model: str = "seedance-1-5-pro-251215"


@dataclass(frozen=True)
class TaskHandle:
    """Handle returned when submitting an async video generation task."""

    task_id: str
    provider: str
    submitted_at: datetime
    prompt: str
    params: VideoGenParams


@dataclass(frozen=True)
class TaskStatus:
    """Status of an async video generation task."""

    state: TaskState
    video_url: str | None = None
    last_frame_url: str | None = None
    cost: Cost | None = None
    error: str | None = None
    progress: float | None = None
    eta_seconds: int | None = None


@dataclass(frozen=True)
class Capabilities:
    """What a provider can do."""

    text_to_media: bool
    media_to_media: bool
    max_duration: int | None = None
    supported_resolutions: tuple[str, ...] = ()
    supported_ratios: tuple[str, ...] = ()
    supports_audio: bool = False
    supports_callback: bool = False
