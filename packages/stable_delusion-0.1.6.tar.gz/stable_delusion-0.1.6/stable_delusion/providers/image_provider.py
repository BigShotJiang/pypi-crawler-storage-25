"""Abstract base class for image generation providers."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path

from stable_delusion.providers.types import Cost, ImageGenParams, Capabilities


@dataclass(frozen=True)
class ImageResult:
    """Result of an image generation call."""

    image_paths: list[Path]
    cost: Cost


class ImageProvider(ABC):
    """Abstract base class for synchronous image generation providers."""

    @abstractmethod
    def generate(
        self, prompt: str, source_images: list[Path], params: ImageGenParams
    ) -> ImageResult:
        pass

    @abstractmethod
    def estimate_cost(self, params: ImageGenParams) -> Cost:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def capabilities(self) -> Capabilities:
        pass
