"""Provider plugin architecture for stable-delusion."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from stable_delusion.providers.gemini_provider import GeminiProvider
from stable_delusion.providers.image_provider import ImageProvider, ImageResult
from stable_delusion.providers.seedance_provider import SeedanceProvider
from stable_delusion.providers.seedream_provider import SeedreamProvider
from stable_delusion.providers.registry import ProviderRegistry
from stable_delusion.providers.video_provider import VideoProvider
from stable_delusion.providers.types import (
    Capabilities,
    Cost,
    ImageGenParams,
    TaskHandle,
    TaskState,
    TaskStatus,
    VideoGenParams,
)

__all__ = [
    "Capabilities",
    "Cost",
    "GeminiProvider",
    "ImageGenParams",
    "ImageProvider",
    "ImageResult",
    "ProviderRegistry",
    "SeedanceProvider",
    "SeedreamProvider",
    "TaskHandle",
    "TaskState",
    "TaskStatus",
    "VideoGenParams",
    "VideoProvider",
]
