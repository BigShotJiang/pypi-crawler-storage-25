"""Registry for image and video generation providers."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from typing import Callable

from stable_delusion.exceptions import ProviderError
from stable_delusion.providers.image_provider import ImageProvider
from stable_delusion.providers.video_provider import VideoProvider


class ProviderRegistry:
    """Registry that maps provider names to provider factories."""

    def __init__(self) -> None:
        self._image_providers: dict[str, Callable[[], ImageProvider]] = {}
        self._video_providers: dict[str, Callable[[], VideoProvider]] = {}

    def register_image_provider(self, name: str, factory: Callable[[], ImageProvider]) -> None:
        """Register an image provider factory under the given name."""
        self._image_providers[name] = factory

    def register_video_provider(self, name: str, factory: Callable[[], VideoProvider]) -> None:
        """Register a video provider factory under the given name."""
        self._video_providers[name] = factory

    def get_image_provider(self, name: str) -> ImageProvider:
        """Return a new instance of the named image provider."""
        if name not in self._image_providers:
            available = ", ".join(sorted(self._image_providers.keys()))
            raise ProviderError(
                f"Unknown image provider: '{name}'. Available: {available}",
                provider_name=name,
            )
        return self._image_providers[name]()

    def get_video_provider(self, name: str) -> VideoProvider:
        """Return a new instance of the named video provider."""
        if name not in self._video_providers:
            available = ", ".join(sorted(self._video_providers.keys()))
            raise ProviderError(
                f"Unknown video provider: '{name}'. Available: {available}",
                provider_name=name,
            )
        return self._video_providers[name]()

    def list_image_providers(self) -> list[str]:
        """Return sorted list of registered image provider names."""
        return sorted(self._image_providers.keys())

    def list_video_providers(self) -> list[str]:
        """Return sorted list of registered video provider names."""
        return sorted(self._video_providers.keys())
