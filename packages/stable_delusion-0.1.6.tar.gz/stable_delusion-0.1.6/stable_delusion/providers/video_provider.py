"""Abstract base class for video generation providers."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from abc import ABC, abstractmethod
from pathlib import Path

from stable_delusion.providers.types import (
    Cost,
    TaskHandle,
    TaskStatus,
    VideoGenParams,
    Capabilities,
)


class VideoProvider(ABC):
    """Abstract base class for asynchronous video generation providers."""

    @abstractmethod
    def submit(self, prompt: str, keyframes: list[Path], params: VideoGenParams) -> TaskHandle:
        pass

    @abstractmethod
    def poll(self, handle: TaskHandle) -> TaskStatus:
        pass

    @abstractmethod
    def estimate_cost(self, params: VideoGenParams) -> Cost:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def capabilities(self) -> Capabilities:
        pass
