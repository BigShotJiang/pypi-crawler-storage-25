"""ImageProvider adapter for the existing Seedream image generation service."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from datetime import datetime, timezone
from pathlib import Path

from stable_delusion.providers.image_provider import ImageProvider, ImageResult
from stable_delusion.providers.types import Cost, ImageGenParams, Capabilities
from stable_delusion.models.requests import GenerateImageRequest


class SeedreamProvider(ImageProvider):
    """Adapter that wraps SeedreamImageGenerationService as an ImageProvider."""

    _COST_PER_IMAGE_USD = 0.06

    def __init__(self, output_dir: Path | None = None) -> None:
        from stable_delusion import builders  # pylint: disable=cyclic-import

        self._service = builders.create_image_generation_service(
            output_dir=output_dir,
            model="seedream",
        )

    @property
    def name(self) -> str:
        return "seedream"

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities(
            text_to_media=True,
            media_to_media=True,
            supported_resolutions=("1K", "2K", "4K"),
        )

    def generate(
        self, prompt: str, source_images: list[Path], params: ImageGenParams
    ) -> ImageResult:
        request = GenerateImageRequest(
            prompt=prompt,
            images=source_images,
            image_size=params.image_size,
            model="seedream",
        )
        response = self._service.generate_image(request)

        cost = Cost(
            amount=self._COST_PER_IMAGE_USD,
            currency="USD",
            input_tokens=0,
            output_tokens=0,
            model="seedream",
            timestamp=datetime.now(timezone.utc),
        )

        image_path = response.generated_file if response.generated_file else Path("unknown")
        return ImageResult(image_paths=[image_path], cost=cost)

    def estimate_cost(self, params: ImageGenParams) -> Cost:
        return Cost(
            amount=self._COST_PER_IMAGE_USD,
            currency="USD",
            input_tokens=0,
            output_tokens=0,
            model="seedream",
            timestamp=datetime.now(timezone.utc),
        )
