"""Project-not-found exception class."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from pathlib import Path

from stable_delusion.exceptions.project_error import ProjectError


class ProjectNotFoundError(ProjectError):
    """Exception raised when a project cannot be found."""

    def __init__(self, project_name: str, projects_dir: Path | None = None) -> None:
        self.projects_dir = projects_dir
        details = f"searched in {projects_dir}" if projects_dir else ""
        super().__init__(f"Project not found: '{project_name}'", project_name, details)
