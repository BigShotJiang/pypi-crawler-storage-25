"""Project management exception class."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from stable_delusion.exceptions.nano_api_error import NanoAPIError


class ProjectError(NanoAPIError):
    """Exception raised for project management errors."""

    def __init__(self, message: str, project_name: str = "", details: str = "") -> None:
        self.project_name = project_name
        super().__init__(message, details)
