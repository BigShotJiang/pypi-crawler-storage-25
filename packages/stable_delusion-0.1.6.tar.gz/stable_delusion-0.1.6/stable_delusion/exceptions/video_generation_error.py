"""Video generation error."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from stable_delusion.exceptions.nano_api_error import NanoAPIError


class VideoGenerationError(NanoAPIError):
    """Raised when video generation fails."""

    def __init__(self, message: str, task_id: str = "", api_response: str = "") -> None:
        self.task_id = task_id
        self.api_response = api_response
        super().__init__(message)
