"""Provider-related error."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from stable_delusion.exceptions.nano_api_error import NanoAPIError


class ProviderError(NanoAPIError):
    """Raised when a provider operation fails (e.g., unknown provider name)."""

    def __init__(self, message: str, provider_name: str = "") -> None:
        self.provider_name = provider_name
        super().__init__(message)
