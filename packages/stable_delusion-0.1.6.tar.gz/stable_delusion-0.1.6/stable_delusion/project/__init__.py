"""Project and scene management for stable-delusion."""

__author__ = "Lene Preuss <lene.preuss@gmail.com>"

from stable_delusion.project.active_project import (
    clear_active_project,
    get_active_project,
    set_active_project,
)
from stable_delusion.project.aspect_ratio import parse_aspect_ratio, validate_image_aspect_ratio
from stable_delusion.project.models import (
    GroupCost,
    KeyframeGroupMetadata,
    KeyframeSidecar,
    ProjectCost,
    ProjectMetadata,
    ProviderDefaults,
    SceneCost,
    SceneMetadata,
    ScenePrompts,
)
from stable_delusion.project.context import ProjectContext, resolve_context
from stable_delusion.project.keyframe_group_repository import KeyframeGroupRepository
from stable_delusion.project.keyframe_sidecar_repository import KeyframeSidecarRepository
from stable_delusion.project.project_repository import ProjectRepository
from stable_delusion.project.scene_repository import SceneRepository
from stable_delusion.project.xdg_paths import resolve_projects_dir
