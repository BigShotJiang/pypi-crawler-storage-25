"""Image-related client functionality."""

from typing import Any, overload

from ... import fragments
from ...fragments import fragment_store
from ...types import (
    BulkImageUpdateInput,
    FindImagesResultType,
    Image,
    ImageDestroyInput,
    ImagesDestroyInput,
    ImageUpdateInput,
)
from ..protocols import StashClientProtocol


class ImageClientMixin(StashClientProtocol):
    """Mixin for image-related client methods."""

    async def find_image(self, id: str) -> Image | None:
        """Find an image by its ID.

        Args:
            id: The ID of the image to find

        Returns:
            Image object if found, None otherwise
        """
        try:
            result = await self.execute(
                fragment_store.FIND_IMAGE_QUERY,
                {"id": id},
            )
            if result and result.get("findImage"):
                return self._decode_result(Image, result["findImage"])
            return None
        except Exception as e:
            self.log.exception(f"Failed to find image {id}: {e}")
            return None

    async def find_images(
        self,
        filter_: dict[str, Any] | None = None,
        image_filter: dict[str, Any] | None = None,
        q: str | None = None,
    ) -> FindImagesResultType:
        """Find images matching the given filters.

        Args:
            filter_: Optional general filter parameters:
                - q: str (search query)
                - direction: SortDirectionEnum (ASC/DESC)
                - page: int
                - per_page: int
                - sort: str (field to sort by)
            image_filter: Optional image-specific filter
            q: Optional search query (alternative to filter_["q"])

        Returns:
            FindImagesResultType.
        """
        if filter_ is None:
            filter_ = {"per_page": -1}
        # Add q to filter if provided
        if q is not None:
            filter_ = dict(filter_ or {})
            filter_["q"] = q
        filter_ = self._normalize_sort_direction(filter_)

        try:
            result = await self.execute(
                fragment_store.FIND_IMAGES_QUERY,
                {"filter": filter_, "image_filter": image_filter},
            )
            return self._decode_result(FindImagesResultType, result["findImages"])
        except Exception as e:
            self.log.exception(f"Failed to find images: {e}")
            return FindImagesResultType(
                count=0, images=[], megapixels=0.0, filesize=0.0
            )

    async def create_image(self, image: Image) -> Image:
        """Create a new image in Stash.

        Args:
            image: Image object with the data to create. Required fields:
                - title: Image title

        Returns:
            Created Image object with ID and any server-generated fields

        Raises:
            ValueError: If the image data is invalid
            gql.TransportError: If the request fails
        """
        try:
            input_data = await image.to_input()
            result = await self.execute(
                fragment_store.CREATE_IMAGE_MUTATION,
                {"input": input_data},
            )
            return self._decode_result(Image, result["imageCreate"])
        except Exception as e:
            self.log.error(f"Failed to create image: {e}")
            raise

    async def update_image(self, image: Image) -> Image:
        """Update an existing image in Stash.

        Args:
            image: Image object with updated data. Required fields:
                - id: Image ID to update
                Any other fields that are set will be updated.
                Fields that are None will be ignored.

        Returns:
            Updated Image object with any server-generated fields

        Raises:
            ValueError: If the image data is invalid
            gql.TransportError: If the request fails
        """
        try:
            input_data = await image.to_input()
            result = await self.execute(
                fragment_store.UPDATE_IMAGE_MUTATION,
                {"input": input_data},
            )
            return self._decode_result(Image, result["imageUpdate"])
        except Exception as e:
            self.log.error(f"Failed to update image: {e}")
            raise

    async def image_destroy(
        self,
        input_data: ImageDestroyInput | dict[str, Any],
    ) -> bool:
        """Delete an image.

        Args:
            input_data: ImageDestroyInput object or dictionary.

        Returns:
            True if the image was successfully deleted

        Raises:
            ValueError: If the image ID is invalid
            gql.TransportError: If the request fails
        """
        try:
            if isinstance(input_data, ImageDestroyInput):
                input_dict = input_data.to_graphql()
            else:
                # Validate dict structure through Pydantic
                if not isinstance(input_data, dict):
                    raise TypeError(
                        f"input_data must be ImageDestroyInput or dict, "
                        f"got {type(input_data).__name__}"
                    )
                validated = ImageDestroyInput(**input_data)
                input_dict = validated.to_graphql()

            result = await self.execute(
                fragments.IMAGE_DESTROY_MUTATION,
                {"input": input_dict},
            )

            return result.get("imageDestroy") is True
        except Exception as e:
            self.log.error(f"Failed to delete image: {e}")
            raise

    async def images_destroy(
        self,
        input_data: ImagesDestroyInput | dict[str, Any],
    ) -> bool:
        """Delete multiple images.

        Args:
            input_data: ImagesDestroyInput object or dictionary.

        Returns:
            True if the images were successfully deleted

        Raises:
            ValueError: If any image ID is invalid
            gql.TransportError: If the request fails
        """
        try:
            if isinstance(input_data, ImagesDestroyInput):
                input_dict = input_data.to_graphql()
            else:
                # Validate dict structure through Pydantic
                if not isinstance(input_data, dict):
                    raise TypeError(
                        f"input_data must be ImagesDestroyInput or dict, "
                        f"got {type(input_data).__name__}"
                    )
                validated = ImagesDestroyInput(**input_data)
                input_dict = validated.to_graphql()

            result = await self.execute(
                fragments.IMAGES_DESTROY_MUTATION,
                {"input": input_dict},
            )

            return result.get("imagesDestroy") is True
        except Exception as e:
            self.log.error(f"Failed to delete images: {e}")
            raise

    @overload
    async def bulk_image_update(
        self,
        input_data: BulkImageUpdateInput | dict[str, Any],
    ) -> list[Image]: ...

    @overload
    async def bulk_image_update(
        self,
        input_data: BulkImageUpdateInput | dict[str, Any],
        *,
        return_fields: str,
    ) -> list[dict[str, Any]]: ...

    async def bulk_image_update(
        self,
        input_data: BulkImageUpdateInput | dict[str, Any],
        *,
        return_fields: str | None = None,
    ) -> list[Image] | list[dict[str, Any]]:
        """Bulk update images.

        Args:
            input_data: BulkImageUpdateInput object or dictionary with fields to update.
            return_fields: If provided, use a minimal inline mutation requesting
                only these fields (e.g. ``"id"``).  Avoids the full fragment
                response, which is significantly faster for fire-and-forget
                bulk updates.  When set, returns a list of raw dicts instead
                of Image objects.

        Returns:
            List of updated Image objects (default), or list of dicts when
            ``return_fields`` is provided.
        """
        try:
            # Convert BulkImageUpdateInput to dict if needed
            if isinstance(input_data, BulkImageUpdateInput):
                input_dict = input_data.to_graphql()
            else:
                # Validate dict structure through Pydantic
                if not isinstance(input_data, dict):
                    raise TypeError(
                        f"input_data must be BulkImageUpdateInput or dict, "
                        f"got {type(input_data).__name__}"
                    )
                validated = BulkImageUpdateInput(**input_data)
                input_dict = validated.to_graphql()

            if return_fields is not None:
                mutation = f"""mutation BulkImageUpdate($input: BulkImageUpdateInput!) {{
                    bulkImageUpdate(input: $input) {{ {return_fields} }}
                }}"""
                result = await self.execute(mutation, {"input": input_dict})
                return result.get("bulkImageUpdate") or []

            result = await self.execute(
                fragment_store.BULK_IMAGE_UPDATE_MUTATION,
                {"input": input_dict},
            )

            images_data = result.get("bulkImageUpdate") or []
            return [self._decode_result(Image, img) for img in images_data]
        except Exception as e:
            self.log.error(f"Failed to bulk update images: {e}")
            raise

    async def images_update(
        self,
        updates: list[ImageUpdateInput] | list[dict[str, Any]],
    ) -> list[Image]:
        """Update multiple images with individual update data.

        This is different from bulk_image_update which applies the same updates to all images.
        This method allows updating each image with different values.

        Args:
            updates: List of ImageUpdateInput objects or dictionaries, each containing:
                - id: Image ID to update (required)
                - Any other fields to update for that specific image

        Returns:
            List of updated Image objects (may contain None for failed updates)

        Examples:
            Update multiple images with different values:
            ```python
            from stash_graphql_client.types import ImageUpdateInput

            updates = [
                ImageUpdateInput(id="1", title="First Image", organized=True),
                ImageUpdateInput(id="2", title="Second Image", rating100=90),
            ]
            images = await client.images_update(updates)
            ```

            Using dictionaries:
            ```python
            updates = [
                {"id": "1", "organized": True},
                {"id": "2", "rating100": 75},
            ]
            images = await client.images_update(updates)
            ```
        """
        try:
            # Convert ImageUpdateInput objects to dicts if needed
            input_list = []
            for update in updates:
                if isinstance(update, ImageUpdateInput):
                    input_list.append(update.to_graphql())
                else:
                    input_list.append(update)

            result = await self.execute(
                fragment_store.IMAGES_UPDATE_MUTATION,
                {"input": input_list},
            )

            images_data = result.get("imagesUpdate") or []
            return [
                img_obj
                for img in images_data
                if (img_obj := self._decode_result(Image, img)) is not None
            ]
        except Exception as e:
            self.log.error(f"Failed to update images: {e}")
            raise

    # Image O-Count Operations

    async def image_increment_o(self, id: str) -> int:
        """Increment the O-counter for an image.

        Args:
            id: Image ID

        Returns:
            New O-count value after incrementing

        Example:
            ```python
            new_count = await client.image_increment_o("123")
            print(f"New O-count: {new_count}")
            ```
        """
        try:
            result = await self.execute(
                fragments.IMAGE_INCREMENT_O_MUTATION,
                {"id": id},
            )
            return int(result["imageIncrementO"])
        except Exception as e:
            self.log.error(f"Failed to increment O-count for image {id}: {e}")
            raise

    async def image_decrement_o(self, id: str) -> int:
        """Decrement the O-counter for an image.

        Args:
            id: Image ID

        Returns:
            New O-count value after decrementing

        Example:
            ```python
            new_count = await client.image_decrement_o("123")
            print(f"New O-count: {new_count}")
            ```
        """
        try:
            result = await self.execute(
                fragments.IMAGE_DECREMENT_O_MUTATION,
                {"id": id},
            )
            return int(result["imageDecrementO"])
        except Exception as e:
            self.log.error(f"Failed to decrement O-count for image {id}: {e}")
            raise

    async def image_reset_o(self, id: str) -> int:
        """Reset the O-counter for an image to 0.

        Args:
            id: Image ID

        Returns:
            New O-count value (0)

        Example:
            ```python
            count = await client.image_reset_o("123")
            print(f"O-count reset to: {count}")
            ```
        """
        try:
            result = await self.execute(
                fragments.IMAGE_RESET_O_MUTATION,
                {"id": id},
            )
            return int(result["imageResetO"])
        except Exception as e:
            self.log.error(f"Failed to reset O-count for image {id}: {e}")
            raise
