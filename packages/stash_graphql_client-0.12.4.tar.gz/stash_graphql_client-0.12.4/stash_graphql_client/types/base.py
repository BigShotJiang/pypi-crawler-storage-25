"""Base types for Stash models.

Note: While this is not a schema interface, it represents a common pattern
in the schema where many types have an id field. This includes core types
like Scene, Gallery, Performer, etc., and file types like VideoFile,
ImageFile, etc.

We use this interface to provide common functionality for these types, even
though the schema doesn't explicitly define an interface for them.

Note: created_at and updated_at are handled by Stash internally and not
included in this interface.

Three-Level Field System:
-------------------------
This module implements a three-level field system using the UNSET sentinel:

1. Set to a value: field = "example"
2. Set to null: field = None
3. Unset/untouched: field = UNSET (default)

This enables partial updates where only modified fields are included in
GraphQL mutations, avoiding the need to send all fields on every update.

UUID4 for New Objects:
---------------------
New objects automatically receive a UUID4 identifier when created without an ID.
This temporary ID is replaced with the server-assigned ID after save operations.

Example:
    >>> scene = Scene(title="Example")  # Auto-generates UUID4 for scene.id
    >>> scene.is_new()  # True
    >>> await scene.save(client)  # Server assigns real ID
    >>> scene.is_new()  # False
"""

from __future__ import annotations

import inspect
import re
import types
import uuid
import warnings
from typing import TYPE_CHECKING, Any, ClassVar, Self, TypeVar, get_args, get_origin

from pydantic import (
    BaseModel,
    ConfigDict,
    ModelWrapValidatorHandler,
    PrivateAttr,
    ValidationInfo,
    field_validator,
    model_validator,
)
from pydantic._internal._model_construction import ModelMetaclass

from stash_graphql_client import fragments
from stash_graphql_client.errors import (
    StashCapabilityError,
    StashIntegrationError,
    StashUnmappedFieldWarning,
)
from stash_graphql_client.fragments import fragment_store
from stash_graphql_client.logging import client_logger as log
from stash_graphql_client.types.scalars import Time
from stash_graphql_client.types.unset import UNSET, UnsetType, is_set


if TYPE_CHECKING:
    from collections.abc import Callable

    from stash_graphql_client.client import StashClient
    from stash_graphql_client.store import StashEntityStore
    from stash_graphql_client.types.enums import BulkUpdateIdMode

T = TypeVar("T", bound="StashObject")


# =============================================================================
# Relationship Metadata
# =============================================================================


class RelationshipMetadata:
    """Metadata describing a bidirectional relationship between Stash entity types.

    All relationships in Stash auto-sync bidirectionally via backend referential
    integrity. This metadata documents how to read/write each relationship and
    provides information for convenience helpers.

    Attributes:
        target_field: Field name in *UpdateInput/*CreateInput (e.g., 'gallery_ids')
        is_list: True for many-to-many, False for many-to-one
        transform: Optional transform function for complex types (e.g., StashID → StashIDInput)
        query_field: Field name when reading (e.g., 'galleries'). Defaults to relationship name.
        inverse_type: Type of the related entity (e.g., 'Gallery' as string to avoid circular imports)
        inverse_query_field: Field name on inverse type (e.g., 'scenes' on Gallery)
        query_strategy: How to query the inverse relationship
        filter_query_hint: For filter_query strategy, example filter usage
        auto_sync: Backend maintains referential integrity (always True for Stash)
        notes: Additional implementation notes or caveats

    Query Strategies:
        - 'direct_field': Use nested field (e.g., gallery.scenes)
        - 'filter_query': Use find* with filter (e.g., findScenes(scene_filter))
        - 'complex_object': Nested object with metadata (e.g., group.sub_groups[].group)

    Example:
        >>> from stash_graphql_client.types import RelationshipMetadata
        >>>
        >>> # Simple many-to-many with direct field
        >>> galleries_rel = RelationshipMetadata(
        ...     target_field="gallery_ids",
        ...     is_list=True,
        ...     query_field="galleries",
        ...     inverse_type="Gallery",
        ...     inverse_query_field="scenes",
        ...     query_strategy="direct_field",
        ... )
        >>>
        >>> # Many-to-one with filter query
        >>> studio_rel = RelationshipMetadata(
        ...     target_field="studio_id",
        ...     is_list=False,
        ...     query_field="studio",
        ...     inverse_type="Studio",
        ...     query_strategy="filter_query",
        ...     filter_query_hint='findScenes(scene_filter={studios: {value: [studio_id]}})',
        ... )
    """

    def __init__(
        self,
        target_field: str,
        is_list: bool,
        transform: Callable[[Any], Any] | None = None,
        *,
        query_field: str | None = None,
        inverse_type: str | type | None = None,
        inverse_query_field: str | None = None,
        query_strategy: str = "direct_field",
        filter_query_hint: str | None = None,
        auto_sync: bool = True,
        notes: str = "",
    ):
        """Initialize relationship metadata.

        Args:
            target_field: Field name in *UpdateInput/*CreateInput
            is_list: True for many-to-many, False for many-to-one
            transform: Optional transform function for complex types
            query_field: Field name when reading. Defaults to smart conversion of target_field.
            inverse_type: Type of the related entity (string or type)
            inverse_query_field: Field name on inverse type
            query_strategy: How to query inverse ('direct_field', 'filter_query', 'complex_object')
            filter_query_hint: Example filter usage for filter_query strategy
            auto_sync: Backend maintains referential integrity (always True)
            notes: Additional implementation notes
        """
        self.target_field = target_field
        self.is_list = is_list
        self.transform = transform

        # Auto-derive query_field if not provided
        if query_field is None:
            # Convert studio_id → studio, gallery_ids → galleries, etc.
            if target_field.endswith("_ids"):
                query_field = target_field[:-4] + "s"  # gallery_ids → galleries
            elif target_field.endswith("_id"):
                query_field = target_field[:-3]  # studio_id → studio
            else:
                query_field = target_field  # Already correct (e.g., stash_ids)

        self.query_field = query_field
        self.inverse_type = inverse_type
        self.inverse_query_field = inverse_query_field
        self.query_strategy = query_strategy
        self.filter_query_hint = filter_query_hint
        self.auto_sync = auto_sync
        self.notes = notes

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"RelationshipMetadata("
            f"target_field={self.target_field!r}, "
            f"query_field={self.query_field!r}, "
            f"strategy={self.query_strategy!r})"
        )


# ─── Sentinel for deferred field resolution ─────────────────────────
_DEFERRED = object()

# ─── Singularization for target_field derivation ────────────────────
_IRREGULAR_PLURALS = {"children": "child", "galleries": "gallery"}


def _singularize(plural: str) -> str:
    """Convert a plural field name to singular (e.g., galleries → gallery)."""
    if plural in _IRREGULAR_PLURALS:
        return _IRREGULAR_PLURALS[plural]
    if plural.endswith("ies"):
        return plural[:-3] + "y"  # galleries → gallery (fallback)
    if plural.endswith("s") and not plural.endswith("ss"):
        return plural[:-1]  # tags → tag, scenes → scene
    return plural


def _pluralize(singular: str) -> str:
    """Convert a singular type name to plural for GraphQL operations."""
    if singular.endswith("y") and not singular.endswith("ey"):
        return singular[:-1] + "ies"  # Gallery → Galleries
    return singular + "s"  # Scene → Scenes, Tag → Tags


def _to_snake_case(name: str) -> str:
    """Convert PascalCase/camelCase to snake_case (e.g., SceneMarker → scene_marker)."""
    return re.sub(r"(?<=[a-z0-9])([A-Z])", r"_\1", name).lower()


def _build_filter_query_hint(
    inverse_type: str, owner_type: str, query_field: str
) -> str:
    """Auto-generate filter_query_hint from relationship metadata.

    Examples:
        Tag + "Scene" + "scenes" → findScenes(scene_filter={tags: {value: [tag_id]}})
        Scene + "Studio" + "studio" → findScenes(scene_filter={studios: {value: [studio_id]}})
        Tag + "SceneMarker" + "scene_markers" → findSceneMarkers(scene_marker_filter={tags: ...})
    """
    inverse_plural = _pluralize(inverse_type)  # SceneMarker → SceneMarkers
    inverse_snake = _to_snake_case(inverse_type)  # SceneMarker → scene_marker
    owner_snake = _to_snake_case(owner_type)  # Tag → tag
    owner_plural_snake = _pluralize(owner_snake)  # tag → tags
    return (
        f"find{inverse_plural}("
        f"{inverse_snake}_filter={{{owner_plural_snake}: "
        f"{{value: [{owner_snake}_id]}}}})"
    )


# ─── ActiveRecord-style relationship helpers ────────────────────────


def belongs_to(
    inverse_type: str,
    *,
    target_field: str | None = None,
    inverse_query_field: str | None = None,
    transform: Callable[[Any], Any] | None = None,
    notes: str = "",
) -> RelationshipMetadata:
    """FK side of a many-to-one. Owns the write (studio_id, scene_id, etc.).

    Auto-derives (via __init_subclass__):
        - query_field: from dict key
        - target_field: key + "_id" (studio → studio_id)
        - filter_query_hint: when inverse_query_field is set

    Examples:
        "studio": belongs_to("Studio", inverse_query_field="scenes")
        "parent_studio": belongs_to("Studio", inverse_query_field="child_studios")
        "scene": belongs_to("Scene", inverse_query_field="scene_markers")
    """
    return RelationshipMetadata(
        target_field=target_field or _DEFERRED,  # type: ignore[arg-type]
        is_list=False,
        transform=transform,
        query_field=_DEFERRED,  # type: ignore[arg-type]
        inverse_type=inverse_type,
        inverse_query_field=inverse_query_field,
        query_strategy="direct_field",
        notes=notes,
    )


def habtm(
    inverse_type: str,
    *,
    target_field: str | None = None,
    inverse_query_field: str | None = None,
    transform: Callable[[Any], Any] | None = None,
    notes: str = "",
) -> RelationshipMetadata:
    """Many-to-many join. Owns the write (tag_ids, performer_ids, etc.).

    Auto-derives (via __init_subclass__):
        - query_field: from dict key
        - target_field: singularize(key) + "_ids" (galleries → gallery_ids)

    Examples:
        "tags": habtm("Tag", inverse_query_field="scenes")
        "performers": habtm("Performer", inverse_query_field="scenes")
        "parents": habtm("Tag", inverse_query_field="children")
        "stash_ids": habtm("StashID", transform=lambda s: StashIDInput(...))
    """
    return RelationshipMetadata(
        target_field=target_field or _DEFERRED,  # type: ignore[arg-type]
        is_list=True,
        transform=transform,
        query_field=_DEFERRED,  # type: ignore[arg-type]
        inverse_type=inverse_type,
        inverse_query_field=inverse_query_field,
        query_strategy="direct_field",
        notes=notes,
    )


def has_many(
    inverse_type: str,
    *,
    inverse_query_field: str | None = None,
    notes: str = "",
) -> RelationshipMetadata:
    """Inverse/read-only side. No mutation input — populated via inverse sync or filter_query.

    Auto-derives (via __init_subclass__):
        - query_field: from dict key
        - target_field: "" (read-only)
        - query_strategy: "filter_query"
        - filter_query_hint: from inverse_type + owner type

    Examples:
        "scenes": has_many("Scene", inverse_query_field="tags")
        "child_studios": has_many("Studio", inverse_query_field="parent_studio")
    """
    return RelationshipMetadata(
        target_field="",  # Read-only — no mutation input
        is_list=True,
        query_field=_DEFERRED,  # type: ignore[arg-type]
        inverse_type=inverse_type,
        inverse_query_field=inverse_query_field,
        query_strategy="filter_query",
        filter_query_hint=_DEFERRED,  # type: ignore[arg-type]
        notes=notes,
    )


def has_many_through(
    inverse_type: str,
    *,
    transform: Callable[[Any], Any],
    target_field: str | None = None,
    inverse_query_field: str | None = None,
    notes: str = "",
) -> RelationshipMetadata:
    """Ordered/metadata relationship via wrapper type (e.g., SceneGroup, GroupDescription).

    Auto-derives (via __init_subclass__):
        - query_field: from dict key
        - target_field: key as-is (groups → groups)

    Examples:
        "groups": has_many_through("Group", transform=lambda g: SceneGroupInput(...),
                                    inverse_query_field="scenes")
    """
    return RelationshipMetadata(
        target_field=target_field or _DEFERRED,  # type: ignore[arg-type]
        is_list=True,
        transform=transform,
        query_field=_DEFERRED,  # type: ignore[arg-type]
        inverse_type=inverse_type,
        inverse_query_field=inverse_query_field,
        query_strategy="complex_object",
        notes=notes,
    )


class FromGraphQLMixin:
    """Mixin for types that can be returned directly from GraphQL queries.

    This includes:
    - Result types (FindScenesResultType, etc.)
    - Entity types returned by find{Type}(id) queries (Scene, Performer, etc.)
    - System types (StashConfig, SystemStatus, etc.)
    """

    @classmethod
    def from_graphql(cls: type[T], data: dict[str, Any]) -> T:  # type: ignore[misc]
        """Deserialize from GraphQL response data.

        This method provides symmetric deserialization to complement
        StashInput.to_graphql(). It's functionally equivalent to
        model_validate() but provides clearer intent.

        Recursively processes nested StashObject dicts to ensure they
        also have _received_fields tracking.

        Args:
            data: Dictionary from GraphQL response

        Returns:
            Instance of the type with data validated

        Raises:
            ValueError: If __typename doesn't match the class name
        """
        # Validate __typename matches class name (if present in data)
        # This ensures type safety when explicitly deserializing to a specific type
        # For polymorphic types (interfaces/unions), allow concrete implementations
        if isinstance(data, dict) and "__typename" in data:
            expected = cls.__name__
            actual = data["__typename"]
            # Check if this might be polymorphic (interface/union with subclasses)
            # If the class has subclasses, allow different __typename (field validators will handle it)
            if actual != expected and not cls.__subclasses__():
                raise ValueError(
                    f"Type mismatch: Attempting to deserialize {actual} as {expected}"
                )

        # Recursively process nested StashObject dicts
        processed_data = cls._process_nested_graphql(data)

        # Mark this data as coming from GraphQL for _received_fields tracking
        return cls.model_validate(processed_data, context={"from_graphql": True})  # type: ignore[attr-defined]

    @classmethod
    def _process_nested_graphql(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Recursively process nested dicts that should be StashObjects.

        Args:
            data: Dictionary potentially containing nested StashObject dicts

        Returns:
            Dictionary with nested dicts preprocessed via from_graphql
        """
        processed: dict[str, Any] = {}

        for field_name, value in data.items():
            if value is None:
                processed[field_name] = value
                continue

            # Check if this field should be a StashObject type
            if field_name in cls.model_fields:  # type: ignore[attr-defined]
                field_info = cls.model_fields[field_name]  # type: ignore[attr-defined]
                annotation = field_info.annotation

                # Handle Optional[Type], Type | None, and List[Type]
                origin = get_origin(annotation)
                args = get_args(annotation)

                # For Union types (created with | syntax in modern Python)
                if origin is types.UnionType:
                    # Filter out None and UnsetType to get the actual type
                    non_none_args = [
                        arg
                        for arg in args
                        if arg is not type(None) and arg is not UnsetType
                    ]
                    if len(non_none_args) == 1:
                        annotation = non_none_args[0]
                        # Re-check origin and args for the unwrapped annotation
                        origin = get_origin(annotation)
                        args = get_args(annotation) if origin else ()

                # For List[Type]
                if origin is list and args and isinstance(value, list):
                    item_type = args[0]

                    # Union-typed list (e.g. list[VideoFile | ImageFile]):
                    # dispatch by __typename to the correct StashObject subclass
                    if isinstance(item_type, types.UnionType):
                        union_types = {
                            t.__name__: t
                            for t in get_args(item_type)
                            if isinstance(t, type) and issubclass(t, StashObject)
                        }
                        if union_types:
                            processed[field_name] = [
                                union_types[item["__typename"]].from_graphql(item)
                                if isinstance(item, dict)
                                and item.get("__typename") in union_types
                                else item
                                for item in value
                            ]
                            continue

                    if isinstance(item_type, type) and issubclass(
                        item_type, StashObject
                    ):
                        # Process list items through from_graphql
                        processed[field_name] = [
                            item_type.from_graphql(item)
                            if isinstance(item, dict)
                            else item
                            for item in value
                        ]
                        continue

                # Single StashObject field
                if (
                    isinstance(annotation, type)
                    and issubclass(annotation, StashObject)
                    and isinstance(value, dict)
                ):
                    processed[field_name] = annotation.from_graphql(value)
                    continue

            processed[field_name] = value

        return processed

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:  # type: ignore[misc]
        """Alias for from_graphql() for backwards compatibility.

        Args:
            data: Dictionary from GraphQL response

        Returns:
            Instance of the type with data validated
        """
        return cls.from_graphql(data)  # type: ignore[arg-type,misc]


class StashInput(BaseModel):
    """Base class for all Stash GraphQL input types.

    Configures Pydantic to accept both Python snake_case field names
    and GraphQL aliases during construction, while serializing
    to GraphQL field names using Field aliases and by_alias=True.

    This allows tests and Python code to use Pythonic naming conventions
    while ensuring GraphQL compatibility.

    Capability Gating (``__safe_to_eat__``):
        Subclasses may declare a ``__safe_to_eat__`` class variable containing
        GraphQL field names (as they appear in the schema) that are known to be
        absent on older server versions.
        When ``to_graphql()`` detects that the server schema lacks one of these
        fields, it silently strips it (with a warning) instead of raising.
        Unsupported fields **not** in ``__safe_to_eat__`` raise ``ValueError``.

    Example:
        ```python
        class MyInput(StashInput):
            my_field: str = Field(alias="myField")

        # Both work during construction:
        MyInput(my_field="value")    # Python style
        MyInput(myField="value")     # GraphQL style

        # Serialization always uses GraphQL style:
        obj.to_graphql()  # {"myField": "value"}
        ```
    """

    # GraphQL field names safe to silently strip when the server doesn't support them.
    __safe_to_eat__: ClassVar[frozenset[str]] = frozenset()

    model_config = ConfigDict(
        populate_by_name=True,
        # Custom serializer to skip UNSET values during JSON serialization
        ser_json_inf_nan="constants",  # Not related, but good practice
        extra="allow",  # Allow extra fields but warn about them (see validator below)
    )

    @model_validator(mode="before")
    @classmethod
    def _warn_extra_fields(cls, data: Any) -> Any:
        """Emit deprecation warning for unknown fields.

        In v0.11.0, we emit warnings for unknown fields to help users identify typos.
        In v0.13.0+, unknown fields will be rejected with ValidationError (extra="forbid").

        This gives users at least one full release cycle to fix field name typos
        before they become hard errors.
        """
        if not isinstance(data, dict):
            return data

        # Get known field names (both Python snake_case and GraphQL camelCase aliases)
        known_fields = set()
        for field_name, field_info in cls.model_fields.items():
            known_fields.add(field_name)  # Python name (e.g., "tag_ids")
            if field_info.alias:
                known_fields.add(field_info.alias)  # GraphQL alias (e.g., "tagIds")

        # Find extra fields that aren't recognized, excluding internal fields
        # (e.g., __typename from GraphQL introspection) — mirrors sanitize_model_data()
        extra_fields = {
            k for k in set(data.keys()) - known_fields if not k.startswith("_")
        }

        if extra_fields:
            warnings.warn(
                f"{cls.__name__}: Unknown fields will be rejected in v0.13.0: "
                f"{', '.join(sorted(extra_fields))}. "
                f"Please check for typos or outdated field names. "
                f"Common mistakes: 'tag_id' should be 'tag_ids' (plural), "
                f"'performer_id' should be 'performer_ids' (plural).",
                DeprecationWarning,
                stacklevel=4,  # Points to user's code, not this validator
            )

        return data

    def to_graphql(self) -> dict[str, Any]:
        """Convert to GraphQL-compatible dictionary.

        Excludes UNSET sentinel values but keeps None (null) values.
        This allows:
        - UNSET fields to be omitted from the request (not sent to GraphQL)
        - None fields to explicitly clear/null values in GraphQL
        - Regular values to be sent normally

        After building the dict, applies capability gating: if the
        ``fragment_store`` has detected server capabilities, every key
        is checked against the server schema.  Fields listed in
        ``__safe_to_eat__`` are silently stripped (with a warning) when
        the server doesn't support them; other unsupported fields raise
        ``ValueError``.

        Returns:
            Dictionary ready to send to GraphQL API with GraphQL field names

        Example:
            ```python
            from .unset import UNSET

            input_obj = SceneUpdateInput(
                title="New Title",  # Send this value
                rating=None,         # Send null (clear rating)
                url=UNSET            # Don't send at all
            )
            result = input_obj.to_graphql()
            # {'title': 'New Title', 'rating': None}  # url excluded
            ```
        """
        # Build exclude set using Python field names (not aliases)
        # Pydantic's exclude parameter works with field names, not aliases
        exclude_fields = {
            field_name
            for field_name in self.__class__.model_fields
            if isinstance(getattr(self, field_name, None), UnsetType)
        }

        # Dump with JSON serialization, excluding UNSET fields
        # Pydantic will handle the alias conversion and exclude the right fields
        result = self.model_dump(by_alias=True, mode="json", exclude=exclude_fields)

        # Apply capability gating if server capabilities are available
        caps = fragment_store._capabilities
        if caps is not None:
            self._apply_capability_gating(result, caps)

        return result

    def _apply_capability_gating(self, result: dict[str, Any], caps: Any) -> None:
        """Check all fields against server schema and gate unsupported ones.

        Fields in ``__safe_to_eat__`` are silently stripped (with warning).
        Other unsupported fields raise ``ValueError``.
        If the type itself is not in the schema, gating is skipped entirely.
        """
        type_name = type(self).__name__
        if not caps.has_type(type_name):
            return  # Type not in schema — skip gating

        for key in list(result.keys()):
            if not caps.input_has_field(type_name, key):
                if key in self.__safe_to_eat__:
                    msg = f"Server lacks '{key}' on {type_name}; stripping from request"
                    log.warning(msg)
                    warnings.warn(msg, stacklevel=3)
                    del result[key]
                else:
                    raise ValueError(f"Server does not support '{key}' on {type_name}")


class BulkUpdateStrings(StashInput):
    """Input for bulk string updates."""

    values: list[str] | UnsetType = UNSET  # [String!]!
    mode: BulkUpdateIdMode | UnsetType = UNSET  # BulkUpdateIdMode!


class BulkUpdateIds(StashInput):
    """Input for bulk ID updates."""

    ids: list[str] | UnsetType = UNSET  # [ID!]!
    mode: BulkUpdateIdMode | UnsetType = UNSET  # BulkUpdateIdMode!


class StashResult(FromGraphQLMixin, BaseModel):
    """Base class for all Stash GraphQL result/output types.

    Result types wrap collections of entities returned from list queries
    like findScenes, findPerformers, etc.

    Example result types:
    - FindScenesResultType
    - FindPerformersResultType
    - StatsResultType
    """

    model_config = ConfigDict(populate_by_name=True)


class _StashObjectMeta(ModelMetaclass):
    """Metaclass that intercepts direct ``Foo(...)`` construction for the
    identity-map cache.

    Why a metaclass: Pydantic v2's ``mode='wrap'`` model validator can return
    a cached instance for the ``model_validate`` / ``from_dict`` paths, but
    when invoked via ``__init__`` (e.g. ``Performer(id='1')``) Pydantic
    discards the validator's returned instance — Python's ``__init__`` has
    no return value, so the cached object is silently thrown away **and**
    Pydantic emits a "validator returning value other than ``self``"
    UserWarning every time.

    The metaclass's ``__call__`` runs BEFORE ``__new__`` / ``__init__``, so
    cache-hit paths can be diverted around ``__init__`` entirely:

    * **Id-only stub** (``Foo(id='X')``) on cache hit → return the cached
      entity directly. No validation needed.
    * **Multi-field** (``Foo(id='X', name='Y')``) on cache hit → route
      through ``self.model_validate(kwargs)`` instead of ``super().__call__()``.
      The wrap validator's existing merge logic runs, returns the cached
      entity with merged values, and ``model_validate`` honors the return
      (unlike ``__init__``, which would discard it and emit the warning).

    Both paths preserve same-id-yields-same-object identity. Cache misses
    fall through to ``super().__call__()`` as before.
    """

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        # In a metaclass ``__call__``, ``self`` is the class being
        # instantiated (e.g. ``Performer``). Named ``self`` to satisfy N805 —
        # the body still uses it as the class object below.
        store = getattr(self, "_store", None)
        type_name = getattr(self, "__type_name__", None)

        # Conditions for cache-hit redirection:
        #   1. A store is registered on the class
        #   2. No positional args (model_validate accepts only the kwargs dict)
        #   3. Caller passed an id kwarg
        #   4. The id is in the cache and not expired
        if store is None or not type_name or args or "id" not in kwargs:
            return super().__call__(*args, **kwargs)

        cache_key = (type_name, kwargs["id"])
        entry = store._cache.get(cache_key)
        if entry is None or entry.is_expired():
            return super().__call__(*args, **kwargs)

        # Id-only fast path: cached entity already has the id; return it.
        if set(kwargs) == {"id"}:
            return entry.entity

        # Multi-field cache hit: route through model_validate so the wrap
        # validator's merge path runs without ``__init__`` discarding its
        # return (the cause of the UserWarning). At runtime ``self`` is
        # the class being constructed (a BaseModel subclass), but mypy
        # sees the metaclass type and can't resolve the inherited
        # classmethod — same pattern as the ``_store._cache`` ignore above.
        return self.model_validate(kwargs)  # type: ignore[attr-defined]


class StashObject(FromGraphQLMixin, BaseModel, metaclass=_StashObjectMeta):
    """Base interface for our Stash model implementations.

    While this is not a schema interface, it represents a common pattern in the
    schema where many types have id, created_at, and updated_at fields. We use
    this interface to provide common functionality for these types.

    Common fields (matching schema pattern):
    - id: Unique identifier (ID!)
    Note: created_at and updated_at are handled by Stash internally

    Common functionality provided:
    - find_by_id: Find object by ID
    - save: Save object to Stash
    - to_input: Convert to GraphQL input type
    - is_dirty: Check if object has unsaved changes
    - mark_clean: Mark object as having no unsaved changes
    - mark_dirty: Mark object as having unsaved changes

    Identity Map Integration:
    - Direct ``Foo(id=...)`` stub construction is intercepted at the metaclass
      level (``_StashObjectMeta.__call__``) for cache lookup, restoring the
      same-id-yields-same-object guarantee for ``__init__`` callers and
      eliminating Pydantic's "validator returning non-self" warning.
    - For multi-field construction or new server data, ``from_dict`` /
      ``from_graphql`` use ``model_validate`` and run the wrap validator's
      full merge logic.
    """

    # Class-level store reference (set by StashContext during initialization)
    # This enables identity map pattern without context propagation issues
    _store: ClassVar[StashEntityStore | None] = None
    _handler_nondict_calls: ClassVar[
        dict[str, int]
    ] = {}  # Profiling: handler(non-dict) calls

    # GraphQL type name (e.g., "Scene", "Performer")
    __type_name__: ClassVar[str]

    # Input type for updates (e.g., SceneUpdateInput, PerformerUpdateInput)
    __update_input_type__: ClassVar[type[BaseModel]]

    # Input type for creation (e.g., SceneCreateInput, PerformerCreateInput)
    # Optional - if not set, the type doesn't support creation
    __create_input_type__: ClassVar[type[BaseModel] | None] = None

    # Input type for deletion (e.g., SceneDestroyInput, TagDestroyInput)
    # Optional - if not set, delete() is not supported for this type
    __destroy_input_type__: ClassVar[type[BaseModel] | None] = None

    # Input type for bulk deletion (e.g., ScenesDestroyInput, ImagesDestroyInput)
    # Optional - if not set, bulk_destroy() falls back to bare ids mutation
    __bulk_destroy_input_type__: ClassVar[type[BaseModel] | None] = None

    # Input type for merging (e.g., SceneMergeInput, PerformerMergeInput)
    # Optional - if not set, merge() is not supported for this type
    __merge_input_type__: ClassVar[type[BaseModel] | None] = None

    # Fields to include in queries
    __field_names__: ClassVar[set[str]]

    # Fields to track for changes
    __tracked_fields__: ClassVar[set[str]] = set()

    # Side mutations: fields that are dirty-tracked but persisted via separate
    # GraphQL mutations instead of the main create/update input.
    # Maps field name → async callable(client, obj) that fires the side mutation.
    # Handlers are called AFTER the main save mutation (so new objects have real IDs).
    # When the field value is None (reset), the handler is still called — it is the
    # handler's responsibility to distinguish set vs. reset semantics.
    __side_mutations__: ClassVar[
        dict[str, Callable[[StashClient, StashObject], Any]]
    ] = {}

    # Relationship mappings for converting to input types
    __relationships__: ClassVar[dict[str, RelationshipMetadata]] = {}

    # Field conversion functions
    __field_conversions__: ClassVar[dict[str, Callable[[Any], Any]]] = {}

    # Fields to try for compact repr (first set+non-None field wins)
    __short_repr_fields__: ClassVar[tuple[str, ...]] = ()

    # Max items to show in list-of-StashObject repr before truncating
    _SHORT_REPR_LIST_LIMIT: ClassVar[int] = 2

    # ─── Resolve deferred relationship metadata ────────────────────
    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Resolve deferred fields in __relationships__ from dict keys.

        When ActiveRecord-style helpers (belongs_to, habtm, has_many, etc.)
        are used, they set query_field and target_field to _DEFERRED.
        This hook resolves them from the dict key after class creation.
        """
        super().__init_subclass__(**kwargs)

        relationships = cls.__dict__.get("__relationships__")
        if not relationships:
            return

        owner_type = getattr(cls, "__type_name__", cls.__name__)

        for key, meta in relationships.items():
            if not isinstance(meta, RelationshipMetadata):
                continue

            # Resolve deferred query_field
            if meta.query_field is _DEFERRED:
                meta.query_field = key

            # Resolve deferred target_field
            if meta.target_field is _DEFERRED:
                if not meta.is_list:
                    # belongs_to: studio → studio_id, parent_studio → parent_id
                    if key.startswith("parent_"):
                        meta.target_field = "parent_id"
                    else:
                        meta.target_field = f"{key}_id"
                elif meta.query_strategy == "complex_object":
                    # has_many_through: groups → groups (key as-is)
                    meta.target_field = key
                # habtm: galleries → gallery_ids, tags → tag_ids
                # But stash_ids → stash_ids (already has _ids suffix)
                elif key.endswith("_ids"):
                    meta.target_field = key
                else:
                    singular = _singularize(key)
                    meta.target_field = f"{singular}_ids"

            # Resolve deferred filter_query_hint
            if (
                meta.filter_query_hint is _DEFERRED
                and meta.query_strategy == "filter_query"
                and meta.inverse_type
            ):
                meta.filter_query_hint = _build_filter_query_hint(
                    inverse_type=meta.inverse_type
                    if isinstance(meta.inverse_type, str)
                    else meta.inverse_type.__name__,
                    owner_type=owner_type,
                    query_field=meta.query_field,
                )
            elif meta.filter_query_hint is _DEFERRED:
                meta.filter_query_hint = None

    # Pydantic configuration
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        extra="allow",  # Allow extra fields for flexibility
        validate_assignment=True,  # Validate on attribute assignment
        populate_by_name=True,  # Accept both snake_case and camelCase
    )

    # Private attributes (stored in __pydantic_private__, survives validate_assignment)
    _snapshot: dict = PrivateAttr(default_factory=dict)
    _is_new: bool = PrivateAttr(default=False)
    _received_fields: set = PrivateAttr(default_factory=set)
    _pending_side_ops: list = PrivateAttr(default_factory=list)

    id: str = ""  # Auto-generates UUID4 if empty/None in __init__
    created_at: Time | UnsetType = UNSET  # Time! - Stash internal
    updated_at: Time | UnsetType = UNSET  # Time! - Stash internal

    @field_validator("id")
    @classmethod
    def _validate_id(cls, value: str) -> str:
        """Validate that id is either a numeric string or a valid UUID4.

        Stash server assigns integer IDs (transmitted as strings), while
        new unsaved objects receive a UUID4 hex identifier from _inject_uuid().
        Any other format indicates corrupted or unexpected data.

        Args:
            value: The id string to validate.

        Returns:
            The validated id string, unchanged.

        Raises:
            ValueError: If the id is not a numeric string or valid UUID4.
        """
        if not value:
            return value

        # Accept numeric strings (Stash server-assigned IDs)
        if value.isdigit():
            return value

        # Accept UUID4 (both hex and dashed formats)
        try:
            parsed = uuid.UUID(value, version=4)
            # Verify it round-trips (catches malformed strings that UUID() coerces)
            if parsed.hex == value.replace("-", ""):
                return value
        except (ValueError, AttributeError):
            pass

        raise ValueError(
            f"Invalid StashObject id {value!r}: must be a numeric string or UUID4"
        )

    def __setattr__(self, name: str, value: Any) -> None:
        """Override setattr to automatically sync inverse relationships.

        When a relationship field is set, this automatically updates the inverse
        side on related objects if they're in the same identity map.
        """
        # Use Pydantic's normal setattr for the assignment
        super().__setattr__(name, value)

        # Sync inverse relationships if this is a relationship field
        if name in self.__relationships__:
            self._sync_inverse_relationship(name, value)

    def _sync_inverse_relationship(self, field_name: str, new_value: Any) -> None:
        """Sync the inverse side of a relationship when it's set.

        Args:
            field_name: The relationship field name that was set
            new_value: The new value (object, list of objects, or None)
        """
        # Skip if value is UNSET or if no relationship metadata
        if isinstance(new_value, UnsetType) or field_name not in self.__relationships__:
            return

        # Get relationship metadata
        mapping = self.__relationships__[field_name]

        # Only sync for RelationshipMetadata with inverse info
        if not isinstance(mapping, RelationshipMetadata):
            return
        if not mapping.inverse_query_field or not mapping.inverse_type:
            return

        # Handle list relationships
        if mapping.is_list and isinstance(new_value, list):
            for related_obj in new_value:
                if not isinstance(related_obj, StashObject):
                    continue
                self._add_to_inverse(related_obj, mapping.inverse_query_field)

        # Handle single object relationships
        elif new_value is not None and isinstance(new_value, StashObject):
            self._add_to_inverse(new_value, mapping.inverse_query_field)

    def _add_to_inverse(self, related_obj: StashObject, inverse_field: str) -> None:
        """Add this object to the inverse relationship field on related object.

        Args:
            related_obj: The related object to update
            inverse_field: The field name on the related object to update
        """
        # Get current inverse value
        current_inverse = getattr(related_obj, inverse_field, UNSET)

        # If UNSET and it's a list relationship, initialize to [] so the
        # inverse sync can populate it. This enables bidirectional sync
        # for filter_query relationships (e.g., Tag.scenes) during preload
        # when entities are loaded in any order.
        if isinstance(current_inverse, UnsetType):
            inverse_meta = related_obj.__relationships__.get(inverse_field)
            if isinstance(inverse_meta, RelationshipMetadata) and inverse_meta.is_list:
                current_inverse = []
                related_obj.__dict__[inverse_field] = current_inverse
                # Add to _received_fields so populate() knows it's loaded
                received: set[str] = getattr(related_obj, "_received_fields", set())
                related_obj._received_fields = received | {inverse_field}
            else:
                return

        # Handle list inverse fields
        if isinstance(current_inverse, list):
            if self not in current_inverse:
                current_inverse.append(self)
                # Snapshot the list so inverse-sync additions aren't considered
                # dirty (this is server-derived data, not user intent)
                related_obj._update_snapshot_for_fields({inverse_field})
        # Handle single object inverse fields
        else:
            # Use object.__setattr__ to avoid triggering another sync
            object.__setattr__(related_obj, inverse_field, self)

    # =========================================================================
    # Generic Relationship Management Helpers
    # =========================================================================

    async def _add_to_relationship(
        self, field_name: str, related_obj: StashObject
    ) -> None:
        """Add an object to a relationship field (generic helper).

        This method leverages RelationshipMetadata to:
        1. Fetch the field from store if UNSET
        2. Fetch the inverse field from store if UNSET (for bidirectional sync)
        3. Initialize to [] if None (for list relationships)
        4. Add object if not already present
        5. Sync inverse relationship automatically

        Args:
            field_name: Name of the relationship field (e.g., "parents", "galleries")
            related_obj: The object to add to the relationship

        Raises:
            ValueError: If field_name is not in __relationships__
            StashIntegrationError: If store is not available when needed

        Example:
            >>> tag = await client.find_tag("child_id")
            >>> parent = await client.find_tag("parent_id")
            >>> await tag._add_to_relationship("parents", parent)
            >>> await store.save(tag)
        """

        # 1. Validate field has metadata
        if field_name not in self.__relationships__:
            raise ValueError(
                f"No relationship metadata for field '{field_name}' on {self.__type_name__}"
            )

        metadata = self.__relationships__[field_name]
        if not isinstance(metadata, RelationshipMetadata):
            raise ValueError(
                f"Field '{field_name}' uses old tuple syntax, not RelationshipMetadata"
            )

        # 2. Get current value of the field
        current_value = getattr(self, field_name)

        # 3. If UNSET, fetch from store
        if isinstance(current_value, UnsetType):
            if self._store is None:
                if metadata.query_strategy == "filter_query":
                    raise StashIntegrationError(
                        f"Cannot add to '{field_name}' on {self.__type_name__}: "
                        f"this relationship uses filter_query strategy and requires "
                        f"a store connection to populate. Either initialize the field "
                        f"manually (e.g., obj.{field_name} = []) or assign the "
                        f"relationship from the other side."
                    )
                raise StashIntegrationError(
                    f"Cannot add to '{field_name}': store not available. "
                    f"Ensure the {self.__type_name__} was loaded through a StashEntityStore."
                )
            await self._store.populate(self, fields=[field_name])
            current_value = getattr(self, field_name)

            # populate() may not resolve filter_query fields
            if isinstance(current_value, UnsetType):
                if metadata.query_strategy == "filter_query":
                    raise StashIntegrationError(
                        f"Cannot add to '{field_name}' on {self.__type_name__}: "
                        f"field uses filter_query strategy and could not be populated "
                        f"from the store. Initialize the field manually "
                        f"(e.g., obj.{field_name} = []) or assign the relationship "
                        f"from the other side."
                    )
                raise StashIntegrationError(
                    f"Cannot add to '{field_name}' on {self.__type_name__}: "
                    f"field is still UNSET after populate."
                )

        # 4. Initialize to [] if None (for list relationships)
        if current_value is None and metadata.is_list:
            current_value = []
            setattr(self, field_name, current_value)

        # 5. Fetch inverse field if UNSET (for bidirectional sync)
        if metadata.inverse_query_field:
            inverse_field = metadata.inverse_query_field
            inverse_value = getattr(related_obj, inverse_field, UNSET)

            if isinstance(inverse_value, UnsetType):
                if related_obj._store is None:
                    inverse_meta = related_obj.__relationships__.get(inverse_field)
                    strategy = (
                        inverse_meta.query_strategy
                        if isinstance(inverse_meta, RelationshipMetadata)
                        else "unknown"
                    )
                    if strategy == "filter_query":
                        raise StashIntegrationError(
                            f"Cannot sync inverse '{inverse_field}' on "
                            f"{type(related_obj).__name__}: this relationship uses "
                            f"filter_query strategy and requires a store connection. "
                            f"Either initialize the field manually "
                            f"(e.g., obj.{inverse_field} = []) or assign the "
                            f"relationship from the other side."
                        )
                    raise StashIntegrationError(
                        f"Cannot sync inverse '{inverse_field}': store not available. "
                        f"Ensure the {metadata.inverse_type} was loaded through "
                        f"a StashEntityStore."
                    )
                await related_obj._store.populate(related_obj, fields=[inverse_field])
                # If still UNSET after populate, skip inverse sync gracefully
                # — the field simply isn't available in the store's fragment
                inverse_value = getattr(related_obj, inverse_field, UNSET)
                if isinstance(inverse_value, UnsetType):
                    inverse_value = None  # skip inverse init below

            # Initialize inverse to [] if None
            inverse_value = getattr(related_obj, inverse_field)
            if inverse_value is None:
                # Check if inverse is a list relationship
                inverse_meta = related_obj.__relationships__.get(inverse_field)
                if (
                    isinstance(inverse_meta, RelationshipMetadata)
                    and inverse_meta.is_list
                ):
                    setattr(related_obj, inverse_field, [])

        # 6. Add to list or set single value
        if metadata.is_list:
            current_value = getattr(self, field_name)
            if current_value is not None and related_obj not in current_value:
                current_value.append(related_obj)
                # Manually sync inverse since append() doesn't trigger __setattr__
                self._sync_inverse_relationship(field_name, current_value)
        else:
            # Setting triggers __setattr__ -> _sync_inverse_relationship()
            setattr(self, field_name, related_obj)

    async def _remove_from_relationship(
        self, field_name: str, related_obj: StashObject
    ) -> None:
        """Remove an object from a relationship field (generic helper).

        This method leverages RelationshipMetadata to:
        1. Skip if field is UNSET (nothing to remove)
        2. Skip if field is None (nothing to remove)
        3. Remove object if present
        4. Sync inverse relationship automatically

        Args:
            field_name: Name of the relationship field (e.g., "parents", "galleries")
            related_obj: The object to remove from the relationship

        Raises:
            ValueError: If field_name is not in __relationships__

        Example:
            >>> tag = await client.find_tag("child_id")
            >>> parent = await client.find_tag("parent_id")
            >>> await tag._remove_from_relationship("parents", parent)
            >>> await store.save(tag)
        """
        # 1. Validate field has metadata
        if field_name not in self.__relationships__:
            raise ValueError(
                f"No relationship metadata for field '{field_name}' on {self.__type_name__}"
            )

        metadata = self.__relationships__[field_name]
        if not isinstance(metadata, RelationshipMetadata):
            raise ValueError(
                f"Field '{field_name}' uses old tuple syntax, not RelationshipMetadata"
            )

        # 2. Get current value
        current_value = getattr(self, field_name)

        # 3. Skip if UNSET or None (nothing to remove)
        if isinstance(current_value, UnsetType) or current_value is None:
            return

        # 4. Remove from list or clear single value
        if metadata.is_list:
            if isinstance(current_value, list) and related_obj in current_value:
                current_value.remove(related_obj)
                # Sync inverse (removing this object from related_obj's inverse field)
                if metadata.inverse_query_field:
                    inverse_field = metadata.inverse_query_field
                    inverse_value = getattr(related_obj, inverse_field, UNSET)
                    if (
                        not isinstance(inverse_value, UnsetType)
                        and inverse_value is not None
                    ):
                        if isinstance(inverse_value, list) and self in inverse_value:
                            inverse_value.remove(self)
                        elif inverse_value is self:
                            # Single object inverse - set to None
                            setattr(related_obj, inverse_field, None)
        # Single object - set to None if it matches
        elif current_value is related_obj:
            setattr(self, field_name, None)

    @model_validator(mode="before")
    @classmethod
    def _inject_uuid(cls, data: Any) -> Any:
        """Auto-generate UUID4 for new objects without an ID.

        If no 'id' is provided (or it is None/empty), generates a UUID4 hex
        string (32 chars) before Pydantic validates fields. This temporary ID
        is replaced with the server-assigned ID after save operations.
        """
        if not isinstance(data, dict):
            return data
        if not data.get("id"):
            new_id = uuid.uuid4().hex
            data = {**data, "id": new_id}
            log.debug(f"Auto-generated UUID4 for new {cls.__name__}: {new_id}")
        return data

    @model_validator(mode="after")
    def _set_is_new(self) -> Self:
        """Set _is_new flag: True when the id looks like an auto-generated UUID4.

        A 32-char non-digit hex string is either a UUID4 we injected above or a
        UUID4 passed in explicitly by the caller — both mean the object hasn't
        been saved to the server yet.

        Guards against non-string id values (e.g., UNSET) that can arrive when
        a model_construct()-built instance is later re-validated as a field value.
        """
        obj_id = getattr(self, "id", None)
        if isinstance(obj_id, str):
            self._is_new = len(obj_id) == 32 and not obj_id.isdigit()
        return self

    @classmethod
    def new(cls: type[T], **data: Any) -> T:
        """Create a new object that hasn't been saved to the server yet.

        This is a convenience method that creates a new instance without providing
        an 'id', which triggers UUID4 auto-generation and sets _is_new=True.

        This is equivalent to calling the constructor without an 'id' field, but
        makes the intent more explicit in the code.

        Args:
            **data: Field values for the new object (excluding 'id')

        Returns:
            New instance with auto-generated UUID4 and _is_new=True

        Example:
            >>> tag = Tag.new(name="New Tag", description="A new tag")
            >>> tag.is_new()  # True
            >>> tag.id  # '3fa85f6457174562b3fc2c963f66afa6' (UUID4 hex)
        """
        # Create instance without id to trigger UUID generation
        return cls(**data)

    def is_new(self) -> bool:
        """Check if this is a new object not yet saved to the server.

        Uses the _is_new flag which is set during initialization for new objects
        or when explicitly creating new objects with UUID4 identifiers.

        Returns:
            True if this object has not been saved to the server
        """
        return self._is_new

    def update_id(self, server_id: str) -> None:
        """Update the temporary UUID with the server-assigned ID.

        This should be called after a successful create operation to replace
        the auto-generated UUID with the permanent ID from the server. Also
        marks the object as no longer new.

        Args:
            server_id: The permanent ID assigned by the Stash server

        Example:
            >>> scene = Scene(title="Example")  # Auto-generates UUID
            >>> scene.id  # "a1b2c3d4e5f6..."
            >>> scene._is_new  # True
            >>> await scene.save(client)  # Server assigns ID "123"
            >>> scene.id  # "123"
            >>> scene._is_new  # False
        """
        old_id = self.id
        self.id = server_id
        # Mark as no longer new
        self._is_new = False
        log.debug(f"Updated {self.__class__.__name__} ID: {old_id} -> {server_id}")

    @model_validator(mode="before")
    @classmethod
    def _warn_extra_fields(cls, data: Any) -> Any:
        """Emit warning for unmapped fields in GraphQL response data.

        Unlike StashInput._warn_extra_fields (which uses DeprecationWarning for
        user typos heading toward extra="forbid"), this uses StashUnmappedFieldWarning
        because the extra fields come from the Stash server — not user error.
        The server may be newer (fields not yet mapped), older (deprecated fields
        no longer declared), or a schema rename occurred between versions.

        Internal fields (_-prefixed like __typename) are silently ignored.
        """
        if not isinstance(data, dict):
            return data

        # Get known field names (both Python snake_case and GraphQL camelCase aliases)
        known_fields = set()
        for field_name, field_info in cls.model_fields.items():
            known_fields.add(field_name)  # Python name
            if field_info.alias:
                known_fields.add(field_info.alias)  # GraphQL alias

        # Find extra fields, excluding _-prefixed internal fields
        extra_fields = {
            k for k in set(data.keys()) - known_fields if not k.startswith("_")
        }

        if extra_fields:
            warnings.warn(
                f"{cls.__name__}: Unmapped fields from server: "
                f"{', '.join(sorted(extra_fields))}. "
                f"The Stash server may be newer (fields not yet mapped) "
                f"or older (deprecated fields no longer supported).",
                StashUnmappedFieldWarning,
                stacklevel=4,
            )

        return data

    @model_validator(mode="wrap")
    @classmethod
    def _identity_map_validator(
        cls, data: Any, handler: ModelWrapValidatorHandler[Self], info: ValidationInfo
    ) -> Self:
        """Identity map validator with nested object support.

        This validator implements the identity map pattern:
        1. Validate __typename matches expected type (if present)
        2. If data has an ID, check if entity is already cached
        3. If cached, return the cached instance (skip construction)
        4. Process nested StashObject dicts to replace with cached instances
        5. Call handler() for normal Pydantic construction with processed data
        6. Cache the newly constructed instance

        This ensures same ID = same object reference for both top-level
        and nested objects.

        Args:
            data: Raw data (dict, model instance, or other)
            handler: Pydantic's validation handler

        Returns:
            Entity instance (either from cache or newly constructed)

        Raises:
            ValueError: If __typename doesn't match expected type
        """
        # Skip identity map if no store or not a dict
        if not cls._store or not isinstance(data, dict):
            _key = f"{cls.__name__}:{type(data).__name__}"
            StashObject._handler_nondict_calls[_key] = (
                StashObject._handler_nondict_calls.get(_key, 0) + 1
            )
            return handler(data)

        # Check cache for current object if it has an ID
        if "id" in data:
            cache_key = (cls.__type_name__, data["id"])

            # Return cached instance if it exists and hasn't expired
            if cache_key in cls._store._cache:
                cached_entry = cls._store._cache[cache_key]
                if not cached_entry.is_expired():
                    cached_obj = cached_entry.entity

                    # Stub-data fast path: when the input only carries id /
                    # __typename, there is nothing to merge — the cached
                    # entity already has both. Skip the handler+merge cycle
                    # so we don't pay the per-item Pydantic-init tax
                    # (signature_no_eval over PrivateAttr default_factories)
                    # for relationship-populate queries that fetch only IDs.
                    if set(data.keys()) <= {"id", "__typename"}:
                        if info.context and info.context.get("from_graphql"):
                            cached_obj._received_fields |= {"id"}
                        return cached_obj

                    log.debug(
                        f"Identity map: returning cached {cls.__type_name__} {data['id']}"
                    )
                    # Merge strategy: call handler() to get a properly
                    # validated fresh instance (field validators run, union
                    # types discriminated), then merge validated values into
                    # cached_obj and RETURN cached_obj (preserves identity).
                    #
                    # To prevent pydantic-core's post-validator pipeline from
                    # overwriting __dict__ with raw input data (Pydantic v2
                    # regression on union-typed list fields), we mutate the
                    # input `data` dict in-place with validated values before
                    # returning.  pydantic-core holds a reference to (not a
                    # copy of) the Python dict, so the overwrite becomes
                    # harmless — it writes back already-validated values.
                    old_received: set[str] = cached_obj._received_fields
                    new_fields = set(data.keys())

                    # Process nested lookups, then let handler fully validate
                    processed_data = cls._process_nested_cache_lookups(data)
                    fresh = handler(
                        processed_data,
                        info.context if info.context else None,
                    )

                    # Merge validated values from fresh into cached via
                    # direct __dict__ writes (bypasses validate_assignment
                    # to avoid the ~42M duplicate-copy memory leak).
                    merged_fields: set[str] = set()
                    cached_dict = cached_obj.__dict__
                    fresh_dict = fresh.__dict__
                    for field_name in new_fields:
                        if field_name not in cached_dict:
                            continue
                        fresh_val = fresh_dict.get(field_name)
                        current = cached_dict[field_name]
                        if current is fresh_val or current == fresh_val:
                            continue
                        cached_dict[field_name] = fresh_val
                        merged_fields.add(field_name)
                        # Sync inverse relationships (bypassed by __dict__ write)
                        if field_name in cached_obj.__relationships__:
                            cached_obj._sync_inverse_relationship(field_name, fresh_val)

                    # Inoculate the input dict: replace raw values with
                    # validated ones so pydantic-core's post-validator
                    # pipeline writes back correct types (not raw dicts)
                    # when it touches union-typed list fields.
                    for k in data:
                        if k in fresh_dict:
                            data[k] = fresh_dict[k]

                    # Merge received fields
                    merged_received = old_received | new_fields
                    cached_obj._received_fields = merged_received

                    # Selectively update snapshot for merged fields only.
                    # Fields the user modified locally that weren't in this merge
                    # remain dirty and will still be saved.
                    if merged_fields:
                        cached_obj._update_snapshot_for_fields(merged_fields)

                    log.debug(
                        f"Identity map: merged {len(new_fields)} new fields into cached "
                        f"{cls.__type_name__} {data['id']}"
                    )
                    return cached_obj
                # Expired - remove from cache
                del cls._store._cache[cache_key]
                log.debug(
                    f"Identity map: evicted expired {cls.__type_name__} {data['id']}"
                )

        # Process nested StashObjects to use cached instances
        # This happens BEFORE handler is called, so Pydantic will use the cached objects
        processed_data = cls._process_nested_cache_lookups(data)

        # Normal construction path with processed data
        # Pass context to nested objects so they also track _received_fields
        instance = handler(processed_data, info.context if info.context else None)

        # Track which fields were received from GraphQL
        # Only set _received_fields for data that came through from_graphql()
        # Factory-built and directly constructed objects keep empty _received_fields
        if isinstance(data, dict) and info.context and info.context.get("from_graphql"):
            received_fields = set(data.keys())
            instance._received_fields = received_fields
            log.debug(
                f"Identity map: tracked {len(received_fields)} received fields for {cls.__type_name__}"
            )

        # Cache the new instance
        cls._store._cache_entity(instance)
        log.debug(f"Identity map: cached new {cls.__type_name__} {instance.id}")

        return instance

    @classmethod
    def _process_nested_cache_lookups(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Process nested dicts to replace with cached StashObject instances.

        Args:
            data: Dictionary potentially containing nested StashObject dicts

        Returns:
            Dictionary with nested dicts replaced by cached instances where available
        """
        if not cls._store:
            return data

        # Get field info from Pydantic model
        processed = data.copy()

        for field_name, field_info in cls.model_fields.items():
            if field_name not in data:
                continue

            value = data[field_name]
            if value is None:
                continue

            # Get the field's annotation to check if it's a StashObject type
            annotation = field_info.annotation

            # Handle Union types created with | syntax (types.UnionType)
            # Must check this BEFORE get_origin() since get_origin() may not handle it
            if isinstance(annotation, types.UnionType):
                args = get_args(annotation)
                # Filter out None and UnsetType
                non_none_args = [
                    arg
                    for arg in args
                    if arg is not type(None) and arg is not UnsetType
                ]
                if len(non_none_args) == 1:
                    annotation = non_none_args[0]

            # Get origin and args for the (potentially unwrapped) annotation
            origin = get_origin(annotation)
            args = get_args(annotation)

            # For List[Type]
            if origin is list:
                if args and isinstance(value, list):
                    # Process list of potential StashObjects
                    item_type = args[0]

                    # Build a __typename → StashObject subclass map for
                    # union-typed list items (e.g. list[VideoFile | ImageFile])
                    typename_map: dict[str, type[StashObject]] | None = None
                    if isinstance(item_type, types.UnionType):
                        union_members = [
                            t
                            for t in get_args(item_type)
                            if isinstance(t, type) and issubclass(t, StashObject)
                        ]
                        if union_members:
                            typename_map = {t.__type_name__: t for t in union_members}

                    if (
                        isinstance(item_type, type)
                        and issubclass(item_type, StashObject)
                    ) or typename_map:
                        processed_list = []
                        for item in value:
                            if isinstance(item, dict) and "id" in item:
                                # Resolve the concrete type for cache lookup
                                if typename_map:
                                    tn = item.get("__typename", "")
                                    concrete = typename_map.get(tn)
                                else:
                                    concrete = item_type  # type: ignore[assignment]
                                if concrete is not None:
                                    cache_key = (
                                        concrete.__type_name__,
                                        item["id"],
                                    )
                                    if cache_key in cls._store._cache:
                                        cached_entry = cls._store._cache[cache_key]
                                        if not cached_entry.is_expired():
                                            log.debug(
                                                f"Identity map: using cached {concrete.__type_name__} {item['id']} for nested list"
                                            )
                                            processed_list.append(cached_entry.entity)
                                            continue
                            processed_list.append(item)
                        processed[field_name] = processed_list
                continue

            # Check if this field is a StashObject type (single object, not list)
            if (
                isinstance(annotation, type)
                and issubclass(annotation, StashObject)
                and isinstance(value, dict)
                and "id" in value
            ):
                # Check cache for nested object
                cache_key = (annotation.__type_name__, value["id"])
                if cache_key in cls._store._cache:
                    cached_entry = cls._store._cache[cache_key]
                    if not cached_entry.is_expired():
                        log.debug(
                            f"Identity map: using cached {annotation.__type_name__} {value['id']} for nested field"
                        )
                        processed[field_name] = cached_entry.entity

        return processed

    @staticmethod
    def _snapshot_value(value: Any) -> Any:
        """Create a snapshot copy of a field value for dirty tracking.

        Mutable collections (lists, dicts) are shallow copied to detect in-place
        modifications. Immutables, StashObjects, and special values (None, UNSET)
        are stored by reference.

        Args:
            value: Field value to snapshot

        Returns:
            Copy of value if mutable collection, otherwise the value itself
        """
        # Lists need shallow copy to detect append/extend/remove operations
        if isinstance(value, list):
            return value.copy()
        # Dicts need shallow copy too (e.g. custom_fields Map fields) so
        # in-place mutation (`obj.custom_fields["k"] = v`) is detectable.
        if isinstance(value, dict):
            return value.copy()
        # Primitives, StashObjects, None, UNSET can be stored by reference
        return value

    def model_post_init(self, _context: Any) -> None:
        """Initialize object and store snapshot after Pydantic init.

        This is called by Pydantic after all fields are initialized, so it's
        the right place to capture the initial state for dirty tracking.

        Args:
            _context: Pydantic context (unused but required by signature)
        """
        # Store snapshot of initial state by capturing field values directly
        # This avoids circular reference errors when model_dump() would recurse
        # into bidirectional relationships (e.g., Scene.performers ↔ Performer.scenes)
        # Use _snapshot_value to copy mutable collections (lists)
        self._snapshot = {
            field: self._snapshot_value(getattr(self, field, UNSET))
            for field in self.__tracked_fields__
        }

    def is_dirty(self) -> bool:
        """Check if tracked fields have unsaved changes.

        Compares current field values with snapshot using object identity for
        StashObjects to avoid circular reference errors during comparison.

        Returns:
            True if any tracked field has changed since last snapshot
        """
        for field in self.__tracked_fields__:
            current_value = getattr(self, field, UNSET)
            snapshot_value = self._snapshot.get(field, UNSET)

            # Direct comparison - uses __eq__ which compares by ID for StashObjects
            if current_value != snapshot_value:
                return True

        return False

    def get_changed_fields(self) -> dict[str, Any]:
        """Get fields that have changed since last snapshot.

        Returns:
            Dictionary of field names to current values for changed fields
        """
        changed = {}

        for field in self.__tracked_fields__:
            current_value = getattr(self, field, UNSET)
            snapshot_value = self._snapshot.get(field, UNSET)

            # Field value changed (uses __eq__ which compares by ID for StashObjects)
            if current_value != snapshot_value:
                changed[field] = current_value

        return changed

    def mark_clean(self) -> None:
        """Mark object as having no unsaved changes.

        Updates the snapshot to match the current state and clears
        any pending queued side operations.
        """
        # Capture current field values directly to avoid circular reference errors
        # Use _snapshot_value to copy mutable collections (lists)
        self._snapshot = {
            field: self._snapshot_value(getattr(self, field, UNSET))
            for field in self.__tracked_fields__
        }
        self._pending_side_ops.clear()

    def _update_snapshot_for_fields(
        self, field_names: set[str] | frozenset[str]
    ) -> None:
        """Update snapshot for specific fields only.

        Used after identity map merge or populate() to mark server-provided
        fields as clean without disturbing dirty state on locally-modified fields.

        Args:
            field_names: Field names to update in the snapshot. Only fields
                         that are in __tracked_fields__ will be updated.
        """
        for field in field_names & self.__tracked_fields__:
            self._snapshot[field] = self._snapshot_value(getattr(self, field, UNSET))

    def mark_dirty(self) -> None:
        """Mark object as having unsaved changes.

        Clears the snapshot to force all tracked fields to be considered dirty.
        """
        self._snapshot = {}

    def _queue_side_op(self, op: Callable[[StashClient, StashObject], Any]) -> None:
        """Queue an async operation to fire during save().

        Queued operations fire AFTER the main create/update mutation and AFTER
        field-based side mutations, so the object has its real server ID.

        Args:
            op: Async callable ``(client, obj) -> Any``. Use closures to
                capture arguments::

                    def increment_o(self):
                        async def _op(client, obj):
                            result = await client.execute(MUTATION, {"id": obj.id})
                            obj.o_counter = result["imageIncrementO"]
                        self._queue_side_op(_op)
        """
        self._pending_side_ops.append(op)

    # Default batch size for bulk update side mutations.
    # SQLite's SQLITE_MAX_VARIABLE_NUMBER defaults to 999, so keep batches
    # well under that to avoid query failures on large relationship sets.
    _BULK_BATCH_SIZE: ClassVar[int] = 500

    @staticmethod
    def _make_bulk_relationship_handler(
        field_name: str,
        bulk_method_name: str,
        id_field: str,
        *,
        use_bulk_ids: bool = True,
        batch_size: int = 500,
    ) -> Callable[[StashClient, StashObject], Any]:
        """Factory for bulk-update side mutation handlers.

        Creates a handler that computes the diff between the current and
        snapshot values of ``field_name``, then fires the client's bulk update
        method to add/remove items.  Large diffs are automatically split into
        batches to stay within SQLite's parameter limits.

        Args:
            field_name: Field name on the entity to diff (e.g., ``"scenes"``).
            bulk_method_name: Name of the client method (e.g.,
                ``"bulk_scene_update"``).
            id_field: Field name in the bulk update input (e.g.,
                ``"performer_ids"``, ``"studio_id"``).
            use_bulk_ids: If ``True`` (default), uses ``BulkUpdateIds`` with
                ``mode: ADD/REMOVE``.  If ``False``, uses a scalar value
                (``entity.id`` for adds, ``None`` for removes).
            batch_size: Maximum number of IDs per bulk update call.  Defaults
                to 500 to stay within SQLite's parameter limits.

        Returns:
            Async callable ``(client, entity) -> None`` suitable for
            ``__side_mutations__``.
        """

        async def handler(client: StashClient, entity: StashObject) -> None:
            current = getattr(entity, field_name)
            current = current if is_set(current) else []
            snapshot = entity._snapshot.get(field_name, [])

            current_ids = {obj.id for obj in current} if current else set()
            snapshot_ids = {obj.id for obj in snapshot} if snapshot else set()

            added = list(current_ids - snapshot_ids)
            removed = list(snapshot_ids - current_ids)

            bulk_method = getattr(client, bulk_method_name)

            # Process in batches to stay within SQLite parameter limits.
            # Use return_fields="id" to avoid the server resolving the full
            # entity fragment for every item in the batch (massive perf win
            # for large batches — avoids N*M relationship SELECTs).
            for i in range(0, max(len(added), 1), batch_size):
                batch = added[i : i + batch_size]
                if not batch:
                    break
                if use_bulk_ids:
                    await bulk_method(
                        {"ids": batch, id_field: {"ids": [entity.id], "mode": "ADD"}},
                        return_fields="id __typename",
                    )
                else:
                    await bulk_method(
                        {"ids": batch, id_field: entity.id},
                        return_fields="id __typename",
                    )

            for i in range(0, max(len(removed), 1), batch_size):
                batch = removed[i : i + batch_size]
                if not batch:
                    break
                if use_bulk_ids:
                    await bulk_method(
                        {
                            "ids": batch,
                            id_field: {"ids": [entity.id], "mode": "REMOVE"},
                        },
                        return_fields="id __typename",
                    )
                else:
                    await bulk_method(
                        {"ids": batch, id_field: None},
                        return_fields="id __typename",
                    )

        return handler

    @staticmethod
    def _diff_custom_fields(entity: StashObject) -> Any:
        """Compute the CustomFieldsInput payload for a dirty ``custom_fields`` field.

        Compares the current value against the snapshot and produces a
        ``CustomFieldsInput`` with ``partial`` (added / changed keys) and
        ``remove`` (deleted keys). Returns ``None`` when there is nothing to send.

        Snapshot semantics:
        - snapshot is UNSET / None (field was never read): emit ``partial`` only.
          We can't know which keys to remove because we don't have ground truth.
        - snapshot is dict: emit ``partial`` for added/changed keys plus
          ``remove`` for keys present in snapshot but absent in current.

        Server upsert semantics (``partial`` mode) only touch the keys we send,
        leaving untouched keys alone — safe even when snapshot is incomplete.

        Args:
            entity: A StashObject instance with a dirty ``custom_fields`` field.

        Returns:
            ``CustomFieldsInput`` instance describing the diff, or ``None`` if
            no payload is needed.
        """
        # Local import avoids a circular dependency: metadata imports from base.
        from .metadata import CustomFieldsInput  # noqa: PLC0415, I001  # circular: metadata imports from base

        current = getattr(entity, "custom_fields", UNSET)
        if not is_set(current) or current is None:
            return None
        if not isinstance(current, dict):
            return None

        snapshot = entity._snapshot.get("custom_fields", UNSET)

        if not is_set(snapshot) or snapshot is None:
            # Field was never read; can't compute removes safely.
            if not current:
                return None
            return CustomFieldsInput(partial=dict(current))

        if not isinstance(snapshot, dict):
            # Defensive: unexpected snapshot type — fall back to partial-only.
            if not current:
                return None
            return CustomFieldsInput(partial=dict(current))

        if snapshot == current:
            return None

        partial: dict[str, Any] = {
            k: v for k, v in current.items() if k not in snapshot or snapshot[k] != v
        }
        remove: list[str] = sorted(set(snapshot.keys()) - set(current.keys()))

        if not partial and not remove:  # pragma: no cover
            # Defensive: logically unreachable. snapshot != current (line above
            # returned early on equality) implies dict diff is non-empty under
            # standard dict.__eq__ semantics, but a pathological dict subclass
            # with broken __eq__ could land here. Avoid emitting an empty
            # CustomFieldsInput in that case.
            return None

        kwargs: dict[str, Any] = {}
        if partial:
            kwargs["partial"] = partial
        if remove:
            kwargs["remove"] = remove
        return CustomFieldsInput(**kwargs)

    @staticmethod
    def _make_custom_fields_handler(
        *,
        capability_attr: str | None,
        update_method_name: str,
    ) -> Callable[[StashClient, StashObject], Any]:
        """Factory for the ``custom_fields`` side-mutation handler.

        Each entity that supports custom_fields registers
        ``"custom_fields": StashObject._make_custom_fields_handler(...)``
        in its ``__side_mutations__`` dict. The handler:

        1. (Optionally) checks that the connected server supports custom_fields
           for this entity (via ``client.capabilities.<capability_attr>``).
        2. Computes the partial+remove diff between snapshot and current.
        3. Fires the entity's ``<entity>Update`` mutation with just
           ``{id, custom_fields: <CustomFieldsInput>}``.

        Args:
            capability_attr: Name of the property on ``client.capabilities``
                that gates this entity's custom_fields support — e.g.,
                ``"has_scene_custom_fields"``. Pass ``None`` for entities
                whose custom_fields predate the appSchema floor (Performer,
                where the ``performer_custom_fields`` table was added in
                migration 71, below the appSchema 75 floor).
            update_method_name: Unused (reserved for future use). The handler
                builds and executes the update mutation directly to bypass
                ``to_input()``'s side-mutation field stripping.

        Returns:
            Async handler ``(client, entity) -> None`` suitable for
            ``__side_mutations__``.

        Raises:
            StashCapabilityError: When ``capability_attr`` is non-None and
                ``capabilities.<capability_attr>`` is falsy at handler-fire time.
        """
        # update_method_name is currently unused but kept in the signature so
        # callers self-document which client method is the conceptual target;
        # this also reserves it for a future optimization that batches
        # custom_fields with other tracked-field changes.
        del update_method_name

        async def handler(client: StashClient, entity: StashObject) -> None:
            if capability_attr is not None:
                caps = getattr(client, "capabilities", None)
                if caps is None or not getattr(caps, capability_attr, False):
                    raise StashCapabilityError(
                        f"{type(entity).__name__}.custom_fields requires "
                        f"capabilities.{capability_attr} (server appSchema too old)"
                    )

            cfi = StashObject._diff_custom_fields(entity)
            if cfi is None:
                return

            type_name = entity.__type_name__
            operation_key = f"{type_name[0].lower()}{type_name[1:]}Update"
            mutation = f"""
                mutation Update{type_name}CustomFields($input: {type_name}UpdateInput!) {{
                    {operation_key}(input: $input) {{
                        id
                    }}
                }}
            """

            # Serialize via to_graphql() — strips UNSET, applies aliases, and
            # produces the wire-shape dict the server expects.
            cfi_payload = (
                cfi.to_graphql()
                if hasattr(cfi, "to_graphql")
                else cfi.model_dump(
                    by_alias=True, exclude_unset=True, exclude_defaults=True
                )
            )
            input_dict = {"id": entity.id, "custom_fields": cfi_payload}
            await client.execute(mutation, {"input": input_dict})

        return handler

    @classmethod
    def _get_field_names(cls) -> set[str]:
        """Get field names from Pydantic model definition.

        Returns:
            Set of field names to include in queries
        """
        if not hasattr(cls, "__field_names__"):
            # Try to get all fields from Pydantic model
            try:
                # Get field names from Pydantic's model_fields
                field_names = set(cls.model_fields.keys())

                # Defensive fallback if no fields were successfully extracted
                if not field_names:
                    cls.__field_names__ = {"id"}
                else:
                    cls.__field_names__ = field_names
            except (AttributeError, TypeError):
                # Fallback if model fields is not available
                cls.__field_names__ = {"id"}  # At minimum, include id field
        return cls.__field_names__

    @classmethod
    async def find_by_id(
        cls: type[T],
        client: StashClient,
        id: str,
    ) -> T | None:
        """Find object by ID.

        Args:
            client: StashClient instance
            id: Object ID

        Returns:
            Object instance if found, None otherwise
        """
        # Map type names to their corresponding find queries
        query_map = {
            "Scene": fragment_store.FIND_SCENE_QUERY,
            "Performer": fragment_store.FIND_PERFORMER_QUERY,
            "Studio": fragment_store.FIND_STUDIO_QUERY,
            "Tag": fragment_store.FIND_TAG_QUERY,
            "Gallery": fragment_store.FIND_GALLERY_QUERY,
            "Image": fragment_store.FIND_IMAGE_QUERY,
            "SceneMarker": fragments.FIND_MARKER_QUERY,
        }

        # Get the appropriate query for this type
        query = query_map.get(cls.__type_name__)
        if not query:
            # Fallback to manual query building for types not in fragments
            fields = " ".join(cls._get_field_names())
            query = f"""
                query Find{cls.__type_name__}($id: ID!) {{
                    find{cls.__type_name__}(id: $id) {{
                        {fields}
                    }}
                }}
            """

        try:
            result = await client.execute(query, {"id": id})
            data = result[f"find{cls.__type_name__}"]
            return cls.from_graphql(data) if data else None
        except Exception:
            return None

    async def save(self, client: StashClient) -> None:
        """Save object to Stash.

        For new objects (created without a server ID), this performs a create
        operation and updates the temporary UUID with the server-assigned ID.

        For existing objects, this performs an update operation, but only if
        there are dirty (changed) fields.

        Side mutations (__side_mutations__) are fired AFTER the main mutation
        so that new objects already have their server-assigned ID. Side-mutation
        fields are excluded from the main create/update input. When multiple
        fields map to the same handler (e.g., resume_time and play_duration
        both map to _save_activity), the handler is deduplicated and fires once.

        Queued operations (_pending_side_ops) fire after field-based side
        mutations. These are closures queued by entity methods like
        ``increment_o()`` or ``reset_play_count()``.

        Args:
            client: StashClient instance

        Raises:
            ValueError: If save fails
        """
        # Skip save if object is not dirty, not new, and has no queued ops
        if not self.is_dirty() and not self.is_new() and not self._pending_side_ops:
            return

        # Identify dirty side-mutation fields before building input
        dirty_fields = set(self.get_changed_fields().keys())
        dirty_side_fields = dirty_fields & set(self.__side_mutations__.keys())

        try:
            # --- Main mutation ---
            input_data = await self.to_input()
            if not isinstance(input_data, dict):
                raise ValueError(
                    f"to_input() must return a dict, got {type(input_data)}"
                )

            # Determine if there are real (non-side) changes for the main mutation
            has_main_changes = self.is_new() or set(input_data.keys()) > {"id"}

            if has_main_changes:
                is_update = not self.is_new()
                operation = "Update" if is_update else "Create"
                type_name = self.__type_name__

                operation_key = f"{type_name[0].lower()}{type_name[1:]}{operation}"
                mutation = f"""
                    mutation {operation}{type_name}($input: {type_name}{operation}Input!) {{
                        {operation_key}(input: $input) {{
                            id
                        }}
                    }}
                """

                result = await client.execute(mutation, {"input": input_data})

                if operation_key not in result:
                    raise ValueError(f"Missing '{operation_key}' in response: {result}")

                operation_result = result[operation_key]
                if operation_result is None:
                    raise ValueError(f"{operation} operation returned None")

                # Update ID for new objects using the dedicated method
                if not is_update:
                    self.update_id(operation_result["id"])

            # --- Field-based side mutations (fire AFTER main mutation so ID is real) ---
            # Deduplicate handlers: multiple fields may map to the same handler
            # (e.g., resume_time and play_duration both → _save_activity)
            seen_handlers: set[int] = set()
            for field_name in dirty_side_fields:
                handler = self.__side_mutations__[field_name]
                handler_id = id(handler)
                if handler_id not in seen_handlers:
                    seen_handlers.add(handler_id)
                    await handler(client, self)

            # --- Queued side operations ---
            for op in self._pending_side_ops:
                await op(client, self)

            # Mark object as clean after all mutations succeed
            self.mark_clean()

        except Exception as e:
            raise ValueError(f"Failed to save {self.__type_name__}: {e}") from e

    async def delete(self, client: StashClient, **kwargs: Any) -> bool:
        """Delete this object from Stash and invalidate from cache.

        Builds a destroy input from ``__destroy_input_type__`` and executes
        the corresponding GraphQL destroy mutation. Extra keyword arguments
        are merged into the destroy input (e.g., ``delete_file=True``).

        Args:
            client: StashClient instance
            **kwargs: Additional destroy input fields (e.g., delete_file, delete_generated)

        Returns:
            True if the object was successfully deleted

        Raises:
            NotImplementedError: If the type has no __destroy_input_type__
            ValueError: If the object has no server ID or delete fails

        Examples:
            >>> await scene.delete(client)
            >>> await scene.delete(client, delete_file=True)
        """
        if not self.__destroy_input_type__:
            raise NotImplementedError(
                f"{self.__type_name__} does not support delete "
                f"(no __destroy_input_type__ defined)"
            )

        if self.is_new():
            raise ValueError(
                f"Cannot delete unsaved {self.__type_name__} (no server ID)"
            )

        type_name = self.__type_name__
        operation_key = f"{type_name[0].lower()}{type_name[1:]}Destroy"

        # Build the destroy input using the declared type.
        # Most types use `id`, but some (Gallery) use `ids` (list).
        destroy_fields = self.__destroy_input_type__.model_fields
        if "ids" in destroy_fields:
            destroy_input = self.__destroy_input_type__(ids=[self.id], **kwargs)
        else:
            destroy_input = self.__destroy_input_type__(id=self.id, **kwargs)
        input_data = destroy_input.to_graphql()  # type: ignore[attr-defined]

        mutation = f"""
            mutation Destroy{type_name}($input: {type_name}DestroyInput!) {{
                {operation_key}(input: $input)
            }}
        """

        result = await client.execute(mutation, {"input": input_data})

        success = result.get(operation_key, False)
        if not success:
            raise ValueError(f"Failed to delete {type_name} {self.id}: {result}")

        # Invalidate from cache
        if self._store is not None:
            self._store.invalidate(self)

        return True

    @classmethod
    async def bulk_destroy(
        cls, client: StashClient, ids: list[str], **kwargs: Any
    ) -> bool:
        """Delete multiple objects of this type from Stash.

        Uses the bulk destroy mutation (e.g., ``scenesDestroy``, ``tagsDestroy``).
        Types with ``__bulk_destroy_input_type__`` use an input object; others
        use the bare ``ids`` parameter pattern.

        Args:
            client: StashClient instance
            ids: List of entity IDs to delete
            **kwargs: Additional destroy input fields (e.g., delete_file)

        Returns:
            True if successfully deleted

        Raises:
            ValueError: If delete fails

        Examples:
            >>> await Scene.bulk_destroy(client, ["1", "2", "3"])
            >>> await Scene.bulk_destroy(client, ["1", "2"], delete_file=True)
        """
        type_name = cls.__type_name__
        # Plural operation key: scenesDestroy, tagsDestroy, etc.
        operation_key = f"{type_name[0].lower()}{type_name[1:]}sDestroy"

        if cls.__bulk_destroy_input_type__ is not None:
            # Types with a dedicated input type (Scene, Image)
            destroy_input = cls.__bulk_destroy_input_type__(ids=ids, **kwargs)
            input_data = destroy_input.to_graphql()  # type: ignore[attr-defined]
            input_type_name = cls.__bulk_destroy_input_type__.__name__

            mutation = f"""
                mutation Destroy{type_name}s($input: {input_type_name}!) {{
                    {operation_key}(input: $input)
                }}
            """
            result = await client.execute(mutation, {"input": input_data})
        else:
            # Types with bare ids param (Tag, Performer, Studio, Group)
            mutation = f"""
                mutation Destroy{type_name}s($ids: [ID!]!) {{
                    {operation_key}(ids: $ids)
                }}
            """
            result = await client.execute(mutation, {"ids": ids})

        success = result.get(operation_key, False)
        if not success:
            raise ValueError(f"Failed to bulk delete {type_name}s {ids}: {result}")

        # Invalidate all from cache
        if cls._store is not None:
            for eid in ids:
                cls._store.invalidate(cls, eid)

        return True

    @classmethod
    async def merge(
        cls,
        client: StashClient,
        source_ids: list[str],
        destination_id: str,
        **kwargs: Any,
    ) -> Self | None:
        """Merge source entities into a destination entity.

        Combines multiple entities of this type into one, transferring
        relationships and optionally overriding field values.

        Args:
            client: StashClient instance
            source_ids: IDs of entities to merge from (these will be deleted)
            destination_id: ID of the entity to merge into (this will be kept)
            **kwargs: Additional merge input fields (e.g., values, play_history)

        Returns:
            The merged destination entity, or None

        Raises:
            NotImplementedError: If the type doesn't support merge
            ValueError: If merge fails

        Examples:
            >>> merged = await Tag.merge(client, ["1", "2"], "3")
            >>> merged = await Scene.merge(client, ["1"], "2", play_history=True)
        """
        if not cls.__merge_input_type__:
            raise NotImplementedError(
                f"{cls.__type_name__} does not support merge "
                f"(no __merge_input_type__ defined)"
            )

        type_name = cls.__type_name__
        merge_input = cls.__merge_input_type__(
            source=source_ids, destination=destination_id, **kwargs
        )
        input_data = merge_input.to_graphql()  # type: ignore[attr-defined]
        input_type_name = cls.__merge_input_type__.__name__

        # Schema uses tagsMerge (plural) vs sceneMerge/performerMerge (singular)
        operation_key = f"{type_name[0].lower()}{type_name[1:]}Merge"
        if type_name == "Tag":
            operation_key = "tagsMerge"

        # Merge returns the merged entity with its fields
        fields = " ".join(cls._get_field_names())
        mutation = f"""
            mutation Merge{type_name}($input: {input_type_name}!) {{
                {operation_key}(input: $input) {{
                    {fields}
                }}
            }}
        """

        result = await client.execute(mutation, {"input": input_data})
        entity_data = result.get(operation_key)

        # Invalidate source entities from cache
        if cls._store is not None:
            for sid in source_ids:
                cls._store.invalidate(cls, sid)

        if entity_data is None:
            return None

        return cls.from_dict(entity_data)

    @staticmethod
    async def _get_id(obj: Any) -> str | None:
        """Get ID from object or dict.

        Args:
            obj: Object to get ID from

        Returns:
            ID if found, None otherwise
        """
        if isinstance(obj, dict):
            return obj.get("id")
        if hasattr(obj, "awaitable_attrs"):
            await obj.awaitable_attrs.id
        return getattr(obj, "id", None)

    async def _process_single_relationship(
        self, value: Any, transform: Callable[[Any], Any] | None
    ) -> str | None:
        """Process a single relationship.

        Args:
            value: Value to transform
            transform: Transform function to apply

        Returns:
            Transformed value if successful, None otherwise
        """
        if not value:
            return None
        if transform is not None:
            # Check if transform is async or sync
            if inspect.iscoroutinefunction(transform):
                result = await transform(value)
            else:
                result = transform(value)
            # Ensure we return str | None as declared
            return str(result) if result is not None else None
        return None

    async def _process_list_relationship(
        self, value: list[Any], transform: Callable[[Any], Any] | None
    ) -> list[str | dict[str, Any]]:
        """Process a list relationship.

        Args:
            value: List of values to transform
            transform: Transform function to apply

        Returns:
            List of transformed values — strings for simple ID transforms,
            dicts for BaseModel transforms (e.g., nested input shapes).
        """
        if not value:
            return []

        items: list[str | dict[str, Any]] = []
        for item in value:
            if transform is not None:
                # Check if transform is async or sync
                if inspect.iscoroutinefunction(transform):
                    transformed = await transform(item)
                else:
                    transformed = transform(item)
                if transformed:
                    # For BaseModel results (complex objects), convert to dict;
                    # for simple results (IDs), convert to string.
                    if isinstance(transformed, BaseModel):
                        items.append(
                            transformed.model_dump(exclude_unset=True, by_alias=True)
                        )
                    else:
                        items.append(str(transformed))
        return items

    async def _process_relationships(
        self, fields_to_process: set[str]
    ) -> dict[str, Any]:
        """Process relationships according to their mappings.

        Relationships with value UNSET are excluded. Relationships with value None
        are included to allow clearing server-side relationships.

        Args:
            fields_to_process: Set of field names to process

        Returns:
            Dictionary of processed relationships (UNSET relationships excluded)
        """
        data: dict[str, Any] = {}

        for rel_field in fields_to_process:
            # Skip if field is not a relationship or doesn't exist
            if rel_field not in self.__relationships__ or not hasattr(self, rel_field):
                continue

            # Get value and skip if UNSET
            value = getattr(self, rel_field)
            if isinstance(value, UnsetType):
                continue

            # Get relationship mapping (supports both RelationshipMetadata and legacy tuple)
            mapping = self.__relationships__[rel_field]

            # Handle both new RelationshipMetadata and legacy tuple format
            if isinstance(mapping, RelationshipMetadata):
                # New format: use RelationshipMetadata attributes
                target_field = mapping.target_field
                is_list = mapping.is_list
                transform = (
                    mapping.transform if mapping.transform is not None else self._get_id
                )
            else:
                # Legacy format: tuple (target_field, is_list, transform)
                target_field, is_list = mapping[:2]
                transform = (
                    mapping[2]
                    if len(mapping) >= 3 and mapping[2] is not None
                    else self._get_id
                )

            # Process value (including None to clear relationships)
            if value is None:
                data[target_field] = None
            elif is_list:
                items = await self._process_list_relationship(value, transform)
                if items:
                    data[target_field] = items
            else:
                transformed = await self._process_single_relationship(value, transform)
                if transformed:
                    data[target_field] = transformed

        return data

    async def _process_fields(self, fields_to_process: set[str]) -> dict[str, Any]:
        """Process fields according to their converters.

        Fields with value UNSET are excluded. Fields with value None are included
        to allow clearing server-side values.

        Args:
            fields_to_process: Set of field names to process

        Returns:
            Dictionary of processed fields (UNSET fields excluded)
        """
        data: dict[str, Any] = {}
        for field in fields_to_process:
            if field not in self.__field_conversions__:
                continue

            if hasattr(self, field):
                value = getattr(self, field)

                # Skip UNSET fields entirely
                if isinstance(value, UnsetType):
                    continue

                # Include None values (to clear server values)
                if value is None:
                    data[field] = None
                else:
                    try:
                        converter = self.__field_conversions__[field]
                        if converter is not None and callable(converter):
                            converted = converter(value)
                            if converted is not None:
                                data[field] = converted
                    except (ValueError, TypeError, ArithmeticError):
                        pass

        return data

    async def to_input(self) -> dict[str, Any]:
        """Convert to GraphQL input type.

        For new objects (with temporary UUID), includes all fields.
        For existing objects, includes only dirty (changed) fields plus ID.

        Fields with value UNSET are excluded from the input to avoid
        overwriting server values that were never touched locally.

        Returns:
            Dictionary of input fields. For new objects, all non-UNSET fields
            are included. For existing objects, only changed fields plus ID.
        """
        # For new objects, include all fields
        input_obj = (
            await self._to_input_all()
            if self.is_new()
            else await self._to_input_dirty()
        )

        # Serialize to dict - exclude UNSET fields, keep None (to clear values)
        # StashInput.to_graphql() builds an explicit exclude set for UNSET fields.
        # model_dump(exclude_none=True) would only exclude None, leaving UNSET
        # objects in the dict that cannot be JSON-serialized by the gql transport.
        result_dict: dict[str, Any] = input_obj.to_graphql()  # type: ignore[attr-defined]
        log.debug(f"Converted {self.__type_name__} to input: {result_dict}")
        return result_dict

    async def _to_input_all(self) -> BaseModel:
        """Convert all fields to input type.

        For new objects, uses CreateInput type. For existing objects (rare case),
        uses UpdateInput type.

        Fields with value UNSET are excluded from the resulting input.

        Returns:
            Validated Pydantic input object (CreateInput or UpdateInput)

        Raises:
            ValueError: If creation is not supported and object is new
        """
        # Process all fields (excluding side-mutation fields)
        side_keys = set(self.__side_mutations__.keys())
        data = await self._process_fields(
            set(self.__field_conversions__.keys()) - side_keys
        )

        # Process all relationships (excluding side-mutation fields)
        rel_data = await self._process_relationships(
            set(self.__relationships__.keys()) - side_keys
        )
        data.update(rel_data)

        # Determine if this is a create or update operation
        object_is_new = self.is_new()

        # If this is a create operation but creation isn't supported, raise an error
        if object_is_new and not self.__create_input_type__:
            raise ValueError(
                f"{self.__type_name__} objects cannot be created, only updated"
            )

        # Use the appropriate input type
        input_type = (
            self.__create_input_type__ if object_is_new else self.__update_input_type__
        )
        if input_type is None:
            # Note: object_is_new case already handled by check at line 1028
            raise NotImplementedError("__update_input_type__ cannot be None")

        # Return validated Pydantic object
        return input_type(**data)

    async def _to_input_dirty(self) -> BaseModel:
        """Convert only dirty fields to input type.

        Uses snapshot-based change detection to identify modified fields.

        Returns:
            Validated Pydantic UpdateInput object with dirty fields plus ID
        """
        if (
            not hasattr(self, "__update_input_type__")
            or self.__update_input_type__ is None
        ):
            raise NotImplementedError("Subclass must define __update_input_type__")

        # Start with ID which is always required for updates
        data = {"id": self.id}

        # Get dirty fields using snapshot comparison
        # This leverages Pydantic's model_dump() for accurate change detection
        dirty_fields = set(self.get_changed_fields().keys())

        # Exclude side-mutation fields — they are persisted by separate handlers
        dirty_fields -= set(self.__side_mutations__.keys())

        # Process dirty regular fields
        field_data = await self._process_fields(dirty_fields)
        data.update(field_data)

        # Process dirty relationships
        rel_data = await self._process_relationships(dirty_fields)
        data.update(rel_data)

        # Convert to update input type
        update_input_type = self.__update_input_type__
        if update_input_type is None:
            raise NotImplementedError("__update_input_type__ cannot be None")

        # Return validated Pydantic object
        return update_input_type(**data)

    def __hash__(self) -> int:
        """Make object hashable based on type and ID.

        Returns:
            Hash of (type_name, id)
        """
        return hash((self.__type_name__, self.id))

    def __eq__(self, other: object) -> bool:
        """Compare objects based on type and ID.

        Args:
            other: Object to compare with

        Returns:
            True if objects are equal
        """
        if not isinstance(other, StashObject):
            return NotImplemented
        return (self.__type_name__, self.id) == (other.__type_name__, other.id)

    def _short_repr(self) -> str:
        """Compact repr for nested display inside another object's repr."""
        parts: list[str] = []
        for field in self.__short_repr_fields__:
            val = getattr(self, field, UNSET)
            if is_set(val) and val is not None:
                parts.append(f"{field}={val!r}")
        if not parts:
            return f"{self.__type_name__}(id={self.id!r})"
        return f"{self.__type_name__}({', '.join(parts)})"

    def __repr__(self) -> str:
        """Shallow repr that avoids recursive expansion of relationship fields."""
        parts: list[str] = [f"id={self.id!r}"]

        for field_name in sorted(self.__class__.model_fields):
            if field_name == "id":
                continue
            val = getattr(self, field_name, UNSET)
            if not is_set(val):
                continue

            if isinstance(val, StashObject):
                parts.append(f"{field_name}={val._short_repr()}")
            elif isinstance(val, list) and val and isinstance(val[0], StashObject):
                limit = self._SHORT_REPR_LIST_LIMIT
                items = [item._short_repr() for item in val[:limit]]
                suffix = f", ..{len(val) - limit} more" if len(val) > limit else ""
                parts.append(f"{field_name}=[{', '.join(items)}{suffix}]")
            else:
                r = repr(val)
                if len(r) > 200:
                    r = r[:197] + "..."
                parts.append(f"{field_name}={r}")

        return f"{self.__type_name__}({', '.join(parts)})"
