#pragma once

#include "aut_preprocessors/no_preprocessing.hh"
#include "aut_preprocessors/standard.hh"
#include "aut_preprocessors/surely_losing.hh"
#include "configuration.hh"
