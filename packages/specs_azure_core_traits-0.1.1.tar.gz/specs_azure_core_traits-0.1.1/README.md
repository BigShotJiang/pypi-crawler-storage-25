# specs-azure-core-traits

anupamas0x1
