## 17.26.4 (2026-04-16)

### Fix

- **io**: update Reader.read to respect Liskov Substitution Principle (#23)

## 17.26.0 (2026-01-20)

### Fix

- **util**: remove Stream class (#14)

## 17.25.0 (2025-12-16)

## 17.25.0b6 (2025-12-10)

## 17.25.0b5 (2025-12-08)

## 17.25.0b4 (2025-12-08)

## 17.25.0b3 (2025-12-08)

## 17.25.0b2 (2025-12-08)

## 17.25.0b1 (2025-12-05)

### Refactor

- **java**: set class attribute constants (#1)

## 17.25.0b0 (2025-12-05)
