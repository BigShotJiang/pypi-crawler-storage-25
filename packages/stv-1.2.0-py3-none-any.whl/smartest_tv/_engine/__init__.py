"""CI stub."""
