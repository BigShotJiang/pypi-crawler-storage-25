def welcome():
    print ("welcome to my world")