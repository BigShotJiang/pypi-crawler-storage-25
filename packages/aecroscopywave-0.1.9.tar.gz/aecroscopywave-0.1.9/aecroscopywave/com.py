"""Helpers for thread-local COM initialization."""

from __future__ import annotations

import importlib
import threading

_com_state = threading.local()


def ensure_com_initialized() -> None:
    """Initialize COM once per thread before using any COM object."""
    if getattr(_com_state, "initialized", False):
        return

    pythoncom = importlib.import_module("pythoncom")
    pythoncom.CoInitialize()
    _com_state.initialized = True
