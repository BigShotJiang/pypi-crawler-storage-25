# Init for wavecraft module
