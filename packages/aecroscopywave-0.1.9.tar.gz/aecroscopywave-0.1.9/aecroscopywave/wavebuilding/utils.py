import numpy as np
from typing import List, Tuple
from ..logger import log_function

@log_function
def timebase(duration: float = 1, # Duration in seconds
             io_rate: float = 4e6  # Sampling rate
             ) -> List[float]:
    """
    Create a uniformly spaced time vector for waveform generation.
    
    Generates a time array starting at 0 and ending at approximately the 
    specified duration, with sample spacing determined by the I/O rate.
    
    Args:
        duration: Total time duration in seconds (default: 1.0)
        io_rate: Sampling rate in samples per second (Hz) (default: 4e6)
        
    Returns:
        Time vector from 0 to approximately duration, with n samples where
        n = int(duration * io_rate). Actual final time is (n-1) / io_rate.
        
    Note:
        The number of samples is computed as int(duration * io_rate), which 
        truncates to the nearest integer. This means the actual duration may 
        be slightly less than requested:
        
        actual_duration = int(duration * io_rate) / io_rate
        
        The time spacing between samples is: dt = 1 / io_rate
        
    Example:
        >>> t = timebase(duration=1.0, io_rate=4e6)
        >>> len(t)
        4000000
        >>> t[0], t[-1]
        (0.0, 0.99999975)
    """
    n = int(duration * io_rate)
    time_vector = np.arange(n) / io_rate
    return time_vector.tolist()

@log_function
def compute_waveform_duration(waveform: List[float], io_rate: float) -> float:
    """
    Calculate the total time duration of a waveform given its sampling rate.
    
    This utility function converts the number of samples in a waveform to
    the equivalent time duration based on the I/O rate (sampling frequency).
    
    Parameters
    ----------
    waveform : List[float]
        The 1D waveform as a list of amplitude values.
    io_rate : float
        Sampling rate in samples per second (Hz).
        Must be positive.
    
    Returns
    -------
    float
        Total duration of the waveform in seconds.
        Calculated as: duration = len(waveform) / io_rate
    
    Raises
    ------
    ValueError
        If io_rate is zero or negative (would cause division by zero or negative duration).
    
    Notes
    -----
    The relationship between samples, duration, and sampling rate:
        n_samples = duration * io_rate
        duration = n_samples / io_rate
        io_rate = n_samples / duration
    
    Examples
    --------
    >>> import numpy as np
    >>> # 1 second waveform at 4 MHz sampling
    >>> wave = np.sin(np.linspace(0, 2*np.pi, 4000000)).tolist()
    >>> compute_waveform_duration(wave, 4e6)
    1.0
    
    >>> # 10 ms waveform at 1 MHz sampling
    >>> wave = [0.0] * 10000
    >>> compute_waveform_duration(wave, 1e6)
    0.01
    
    >>> # Verify relationship with time base
    >>> t = _timebase(duration=0.5, io_rate=4e6)
    >>> computed_duration = compute_waveform_duration(t, 4e6)
    >>> print(f"Expected: 0.5, Computed: {computed_duration:.10f}")
    Expected: 0.5, Computed: 0.4999997500
    
    >>> # Calculate duration for BE waveform
    >>> be_wave, _, _, _ = BE_wave(
    ...     BE_band_center=350e3,
    ...     BE_band_width=100e3,
    ...     BE_amplitude=2.0,
    ...     BE_repeats=4,
    ...     BE_pulse_duration_req=0.01
    ... )
    >>> actual_duration = compute_waveform_duration(be_wave, 4e6)
    >>> print(f"Requested: 0.01s, Actual: {actual_duration:.6f}s")
    
    >>> # Calculate timeout needed for measurement
    >>> # Rule of thumb: timeout = waveform_duration + 2 seconds
    >>> waveform_duration = compute_waveform_duration(be_wave, 4e6)
    >>> recommended_timeout = waveform_duration + 2.0
    >>> print(f"Recommended timeout: {recommended_timeout:.2f}s")
    
    See Also
    --------
    _timebase : Create time vector with specified duration and sampling rate
    point_be_spectroscopy : Uses waveform duration to set appropriate timeout
    """
    if io_rate <= 0:
        raise ValueError(f"io_rate must be positive, got {io_rate}")
    
    return len(waveform) / io_rate

@log_function
def embed_waveforms(waveform1: List[float], waveform2: List[float]) -> Tuple[List[float], List[float]]:
    """
    Combine two waveforms by repeating waveform1 at each step of waveform2.
    
    This function creates a combined waveform where waveform1 (typically a fast
    AC signal) is embedded at each voltage level of waveform2 (typically a slow
    DC bias). Each sample of waveform2 acts as a DC offset applied to an entire
    copy of waveform1. This is essential for BEPS and BEcKPFM measurements where
    AC excitation is combined with DC bias sequences.
    
    Parameters
    ----------
    waveform1 : List[float]
        Base waveform to be repeated (typically AC or band excitation signal).
        This is the "fast" component that repeats at each step.
    waveform2 : List[float]
        Modulating waveform providing offset values (typically DC bias sequence).
        This is the "slow" component that varies the DC level.
    
    Returns
    -------
    sample_index : List[float]
        Index list (0, 1, 2, ..., n-1) for the combined waveform,
        where n = len(waveform1) * len(waveform2).
    combined_waveform : List[float]
        Combined waveform of length len(waveform1) * len(waveform2).
        Structure: [wf1+wf2[0], wf1+wf2[1], ..., wf1+wf2[-1]]
        where each segment is the full waveform1 with a DC offset.
    
    Notes
    -----
    Mathematical operation:
        For each i in range(len(waveform2)):
            combined_waveform[i*n1:(i+1)*n1] = waveform1 + waveform2[i]
    
    where n1 = len(waveform1).
    
    The total length of the output waveform is:
        n_total = len(waveform1) * len(waveform2)
    
    This embedding technique is fundamental for:
    - BEPS: Combining BE waveform with DC switching pulses
    - BEcKPFM: Layering BE, write, and read waveforms
    - Any measurement requiring AC excitation at multiple DC bias levels
    
    Memory consideration: The output size grows as the product of input lengths.
    For large waveforms, this can consume significant memory.
    
    Examples
    --------
    >>> # Simple example: embed sine wave into DC steps
    >>> import numpy as np
    >>> ac_wave = np.sin(np.linspace(0, 2*np.pi, 100)).tolist()
    >>> dc_wave = [0, 1, 2, 3]  # 4 DC levels
    >>> idx, combined = embed_waveforms(ac_wave, dc_wave)
    >>> print(len(combined))  # 100 * 4 = 400
    400
    >>> print(np.mean(combined[0:100]))  # First segment, DC offset = 0
    0.0
    >>> print(np.mean(combined[100:200]))  # Second segment, DC offset = 1
    1.0
    
    >>> # BEPS-like example: BE waveform with bipolar DC
    >>> be_wave, _, _, _ = BE_wave(
    ...     BE_band_center=350e3,
    ...     BE_band_width=100e3,
    ...     BE_amplitude=1.0,
    ...     BE_repeats=4,
    ...     BE_pulse_duration_req=0.01
    ... )
    >>> dc_bias = [5.0, -5.0]  # Positive then negative bias
    >>> idx, beps_wave = embed_waveforms(be_wave, dc_bias)
    >>> print(len(beps_wave) / len(be_wave))  # Should be 2.0
    2.0
    
    >>> # Multi-level DC sweep
    >>> ac_signal = [1.0] * 1000  # Simple AC carrier
    >>> dc_sweep = list(np.linspace(-5, 5, 10))  # 10 DC levels
    >>> idx, combined = embed_waveforms(ac_signal, dc_sweep)
    >>> print(len(combined))  # 1000 * 10 = 10000
    10000
    
    >>> # Verify structure: first segment should have DC offset = -5
    >>> print(np.mean(combined[0:1000]))
    -4.0  # 1.0 (AC) + (-5.0) (DC offset)
    
    See Also
    --------
    upload_beps_wave : Uses this function to combine BE and DC waveforms
    upload_beckpfm_wave : Uses this function twice to layer BE, write, and read
    """
    waveform1 = np.asarray(waveform1)
    waveform2 = np.asarray(waveform2)

    n1 = len(waveform1)
    n2 = len(waveform2)

    # Repeat waveform1 for each value of waveform2
    combined_waveform = np.zeros(n1 * n2)
    for i, w2_val in enumerate(waveform2):
        start = i * n1
        end = start + n1
        combined_waveform[start:end] = waveform1 + w2_val

    # Create a simple sample index
    sample_index = np.arange(len(combined_waveform))
    return sample_index.tolist(), combined_waveform.tolist()

