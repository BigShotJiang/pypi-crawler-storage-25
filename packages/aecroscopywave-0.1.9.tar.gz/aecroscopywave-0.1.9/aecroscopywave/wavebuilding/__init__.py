# Init for wave_building module
