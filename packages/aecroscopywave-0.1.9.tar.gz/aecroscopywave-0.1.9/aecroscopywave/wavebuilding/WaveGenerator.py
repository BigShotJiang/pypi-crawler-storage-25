import numpy as np
from scipy.signal import sawtooth
from math import erf
from ..wavebuilding.utils import *
from typing import Tuple, List
from ..logger import log_function
# To Do
# Add forc function with adaptable on and off times, also add a function that only embed BE_wave in off 
# Add AC amplitude upward and downward sweep function

@log_function
def square_wave(frequency: float = 1, amplitude: float = 1, duty: float = 0.5,
                duration: float = 1, io_rate: float = 4e6) -> Tuple[List[float], list[float]]:
    """Generate a square wave signal.
    
    Creates a periodic square wave that alternates between positive and negative
    amplitude values based on the specified duty cycle. The waveform is ideal for
    generating digital-like signals, clock patterns, or pulse trains for AFM experiments.
    
    Args:
        frequency (float, optional): Frequency of the square wave in Hz. Default is 1.0 Hz.
            Must be positive. Higher frequencies require higher io_rate for proper sampling.
        amplitude (float, optional): Peak amplitude of the square wave. Default is 1.0.
            The wave alternates between +amplitude and -amplitude.
            Must be within DAQ output range (typically ±10V, ±2V, or ±0.2V).
        duty (float, optional): Duty cycle as a fraction of the period (0 to 1). Default is 0.5.
            Represents the fraction of each period where the signal is high (+amplitude).
            - 0.5: Symmetric square wave (50% high, 50% low)
            - <0.5: Shorter high pulses, longer low periods
            - >0.5: Longer high pulses, shorter low periods
            Valid range: (0, 1) exclusive of endpoints.
        duration (float, optional): Total signal duration in seconds. Default is 1.0 s.
            Must be positive. Longer durations create more periods of the waveform.
        io_rate (float, optional): Sampling rate in samples per second. Default is 4e6 (4 MHz).
            Higher rates provide better temporal resolution but larger waveforms.
            Should satisfy Nyquist criterion: io_rate ≥ 2 × frequency.
    
    Returns:
        tuple: A tuple containing:
            - **time_vector** (List[float]): Time values in seconds, evenly spaced.
                Length = int(duration × io_rate).
            - **waveform_vector** (List[float]): Square wave amplitude values corresponding 
                to each time point. Values alternate between +amplitude and -amplitude based 
                on duty cycle.
    
    Examples:
        Generate a symmetric 10 Hz square wave:
        >>> time, wave = square_wave(frequency=10, amplitude=2.0, duty=0.5, duration=0.1)
        >>> print(f"Generated {len(wave)} samples over {duration} seconds")
        Generated 400000 samples over 0.1 seconds
    """
    time_vector = np.asarray(timebase(duration, io_rate))
    phase_fraction = (time_vector * frequency) % 1.0
    waveform_vector = np.where(phase_fraction < duty, amplitude, -amplitude)
    return time_vector.tolist(), waveform_vector.tolist()

@log_function
def square_pulse (amplitude: float = 1, pulse_duration: Tuple[float, float, float] = (0.1, 0.5, 0.1), 
                  io_rate = 4e6, repeats: int = 1) -> Tuple[List[float], list[float]]:
    """Generate a rectangular pulse waveform with configurable timing.
    
    Creates a pulse that starts at zero, rises to the specified amplitude for a
    defined duration, then returns to zero. The pulse can be repeated multiple times
    with configurable pre/post delays, useful for voltage pulses, gating signals,
    and trigger patterns in AFM experiments.
    
    Args:
        amplitude (float, optional): Pulse amplitude (height). Default is 1.0.
            The signal is 0 during off periods and amplitude during on period.
            Must be within DAQ output range configuration.
        pulse_duration (Tuple[float, float, float], optional): Pulse timing components 
            in seconds as (t_off_start, t_on, t_off_end). Default is (0.1, 0.5, 0.1).
            - t_off_start: Duration of zero signal before pulse starts
            - t_on: Duration of high amplitude pulse
            - t_off_end: Duration of zero signal after pulse ends
            All values must be non-negative.
        io_rate (float, optional): Sampling rate in samples per second. Default is 4e6 (4 MHz).
            Higher rates provide better temporal resolution.
        repeats (int, optional): Number of times to repeat the pulse pattern. Default is 1.
            Each repeat includes the complete t_off_start-t_on-t_off_end sequence.
            Must be positive integer.
    
    Returns:
        tuple: A tuple containing:
            - **time_vector** (List[float]): Time values in seconds.
                Length = int((t_off_start + t_on + t_off_end) × repeats × io_rate).
            - **waveform_vector** (List[float]): Pulse waveform amplitude values.
                Values are either 0 (off) or amplitude (on).
    
    Examples:
        Single pulse: 0.1s low, 0.5s high, 0.1s low:
        >>> time, wave = square_pulse(amplitude=5.0, pulse_duration=(0.1, 0.5, 0.1))
        >>> print(f"Total duration: {time[-1]:.2f} s")
        Total duration: 0.70 s
        >>> print(f"Pulse amplitude: {max(wave)} V")
        Pulse amplitude: 5.0 V
    """
    t_off_start, t_on, t_off_end = pulse_duration
    single_pulse_duration = t_off_start + t_on + t_off_end
    time_vector = np.asarray(timebase(single_pulse_duration, io_rate))

    # single pulse waveform
    waveform_vector = np.zeros_like(time_vector)
    waveform_vector[np.asarray(timebase(t_off_start, io_rate)).shape[0] : np.asarray(timebase(t_off_start + t_on, io_rate)).shape[0]] = amplitude
    # repeat the pulse
    waveform_vector = np.tile(waveform_vector, repeats)
    time_vector = np.asarray(timebase(compute_waveform_duration(waveform_vector, io_rate), io_rate))

    return time_vector.tolist(), waveform_vector.tolist()

@log_function
def chirp_wave(frequency_start: float = 1, frequency_end: float = 10, duration: float = 1,
               amplitude: float = 1, io_rate: float = 4e6) -> Tuple[List[float], list[float]]:
    """Generate a linear frequency chirp (sweep) signal.
    
    Creates a sinusoidal signal whose instantaneous frequency increases (or decreases)
    linearly from a start frequency to an end frequency over the specified duration.
    Also known as a linear frequency modulated (LFM) signal or frequency sweep.
    Widely used in impedance spectroscopy, system identification, and broadband
    excitation in AFM band excitation techniques.
    
    Args:
        frequency_start (float, optional): Starting frequency in Hz. Default is 1.0 Hz.
            The instantaneous frequency at t=0.
            Can be greater than frequency_end for downward chirps.
        frequency_end (float, optional): Ending frequency in Hz. Default is 10.0 Hz.
            The instantaneous frequency at t=duration.
            Determines the frequency sweep range.
        duration (float, optional): Total sweep duration in seconds. Default is 1.0 s.
            Must be positive. Longer durations provide finer frequency resolution.
        amplitude (float, optional): Peak amplitude of the chirp signal. Default is 1.0.
            The amplitude remains constant throughout the sweep.
            Must be within DAQ output range.
        io_rate (float, optional): Sampling rate in samples per second. Default is 4e6 (4 MHz).
            Should satisfy Nyquist for highest frequency: io_rate ≥ 2 × max(f_start, f_end).
    
    Returns:
        tuple: A tuple containing:
            - **time_vector** (List[float]): Time values in seconds.
                Evenly spaced from 0 to duration.
            - **waveform_vector** (List[float]): Chirp waveform amplitude values.
                Sinusoidal signal with linearly varying instantaneous frequency.
    
    Examples:
        Audio frequency sweep from 20 Hz to 20 kHz: 
        >>> time, wave = chirp_wave(frequency_start=20, frequency_end=20000, duration=2.0)
        >>> print(f"Sweep rate: {(20000-20)/2:.0f} Hz/s")
        Sweep rate: 9990 Hz/s
    """
    time_vector = np.asarray(timebase(duration, io_rate))
    k = (frequency_end - frequency_start) / duration  # rate of frequency change (Hz/s)
    waveform_vector = amplitude * np.sin(2 * np.pi * (frequency_start * time_vector + 0.5 * k * time_vector**2))
    return time_vector.tolist(), waveform_vector.tolist()

@log_function
def composite_wave(components: List[Tuple[float, float]], duration: float = 1,
                   io_rate: float = 4e6) -> Tuple[List[float], list[float]]:
    """Generate a composite waveform by summing multiple sinusoidal components.
    
    Creates a multi-frequency signal by adding together sine waves with different
    frequencies and amplitudes. This superposition creates complex excitation patterns
    useful for testing multi-harmonic responses, intermodulation distortion, and
    simultaneous multi-frequency measurements in AFM experiments.
    
    Args:
        components (List[Tuple[float, float]]): List of (frequency, amplitude) tuples 
            defining each sinusoidal component.
            - frequency (float): Component frequency in Hz, must be positive
            - amplitude (float): Component amplitude, can be positive or negative
            Example: [(100, 1.0), (200, 0.5), (300, 0.25)]
            
            Each component contributes: amplitude × sin(2π × frequency × t)
            At least one component should be provided for meaningful output.
        duration (float, optional): Total signal duration in seconds. Default is 1.0 s.
            Must be positive. All components use the same duration.
        io_rate (float, optional): Sampling rate in samples per second. Default is 4e6 (4 MHz).
            Should satisfy Nyquist for highest frequency component.
    
    Returns:
        tuple: A tuple containing:
            - **time_vector** (List[float]): Time values in seconds.
                Evenly spaced from 0 to duration.
            - **waveform_vector** (List[float]): Composite waveform formed by summing 
                all components. Result of linear superposition of all sine waves.
    Examples:
        Two-tone signal for intermodulation testing:
        
        >>> components = [(1000, 1.0), (1100, 1.0)]
        >>> time, wave = composite_wave(components, duration=0.01)
        >>> print(f"Beat frequency: {abs(1100-1000)} Hz")
        Beat frequency: 100 Hz
        >>> # Observe 100 Hz amplitude modulation (beating)
    """
    time_vector = np.asarray(timebase(duration, io_rate))
    waveform_vector = np.zeros_like(time_vector)
    for freq, amp in components:
        waveform_vector += amp * np.sin(2 * np.pi * freq * time_vector)
    return time_vector.tolist(), waveform_vector.tolist()

@log_function
def triangular(cycle_amplitude: float = 1, cycle_phase_shift: float = 0, cycle_number: int = 1, 
               steps_per_cycle: int= 32, points_per_step: int = 1, cycle_fraction: float = 1) -> Tuple[List[float], list[float]]:
    """Generate a triangular waveform with discrete steps.
    
    Creates a triangle wave that linearly ramps up and down, with configurable
    discretization into steps. The waveform oscillates symmetrically between negative
    and positive amplitudes. Widely used for generating bias waveforms in switching
    spectroscopy, voltage cycling, and piezoresponse force microscopy (PFM) measurements.
    
    Args:
        cycle_amplitude (float, optional): Peak amplitude of the triangle wave. Default is 1.0.
            The waveform oscillates between -cycle_amplitude and +cycle_amplitude.
            Must be within DAQ output range configuration.
        cycle_phase_shift (float, optional): Phase shift in cycles (not radians). Default is 0.
            Applied as 2π × cycle_phase_shift × 2 in the calculation.
            - 0: Start near zero, rising
            - 0.25: Start at peak
            - 0.5: Start near zero, falling
            Range: typically [0, 1) for one full phase cycle.
        cycle_number (int, optional): Number of times to repeat the waveform pattern. Default is 1.
            Each repeat is an identical triangle cycle.
            Must be positive integer.
        steps_per_cycle (int, optional): Number of discrete voltage steps in one complete cycle. 
            Default is 32.
            Higher values create smoother triangles with finer voltage resolution.
            Typical range: 16-256 depending on measurement requirements.
        points_per_step (int, optional): Number of samples per discrete step. Default is 1.
            Determines how long each voltage level is held.
            Total samples per cycle = steps_per_cycle × points_per_step.
            Higher values → longer dwell time at each voltage.
        cycle_fraction (float, optional): Fraction of one cycle to use before repeating (0 to 1). 
            Default is 1.0.
            - 1.0: Complete triangle (up and down)
            - 0.5: Half cycle (e.g., rising edge only)
            - 0.25: Quarter cycle
            Useful for asymmetric or truncated waveforms.
    
    Returns:
        tuple: A tuple containing:
            - **step_vector** (List[float]): Sample indices (0, 1, 2, ..., N-1) for the waveform.
                Not time in seconds - use with io_rate to convert to time if needed.
            - **waveform_vector** (List[float]): Triangular waveform amplitude values.
                Discretized into steps_per_cycle voltage levels.
    
    Examples:
        Basic triangle wave (one cycle, 32 steps):
        
        >>> steps, wave = triangular(cycle_amplitude=5.0, steps_per_cycle=32)
        >>> print(f"Samples per cycle: {len(wave)}")
        >>> print(f"Amplitude range: [{min(wave):.1f}, {max(wave):.1f}]")
        Samples per cycle: 32
        Amplitude range: [-5.0, 5.0]
    """
    # build the per-step phase grid in [0,1) for one cycle
    step = np.linspace(0, 1, steps_per_cycle, endpoint=False)
    step = np.repeat(step, points_per_step)  # upsample steps to points

    # sawtooth(..., width=0.5) gives a triangle in [-1,1], starting at -1 at phase=0.
    # We rotate by π/2 so it starts near 0 and rises. The extra factor *2 on phase keeps
    # your original “cycle-based” phase semantics.
    tri_waveform = cycle_amplitude * sawtooth(
        2 * np.pi * step + np.pi / 2 + np.pi * cycle_phase_shift * 2,
        width=0.5
    )

    # keep only the first 'cycle_fraction' of this one-cycle buffer,
    # then tile it `cycle_number` times. (Exactly your original behavior.)
    keep = int(cycle_fraction * len(tri_waveform))
    tri_waveform = tri_waveform[:keep]
    waveform_vector = np.tile(tri_waveform, cycle_number)

    # simple sample index time-base. If you want seconds instead, divide by a sample rate.
    step_vector = np.arange(len(waveform_vector))
    return step_vector.tolist(), waveform_vector.tolist()

@log_function
def triangular_modulated_pulse(cycle_amplitude: float = 1, cycle_phase_shift: float = 0, cycle_number: int = 1,
                               steps_per_cycle: int = 32, points_per_step: int = 1, cycle_fraction: float = 1) -> Tuple[List[float], list[float]]:
    """Generate a pulse-modulated triangular waveform.
    
    Creates a triangle wave where each voltage step is modulated with a 50% duty cycle
    ON/OFF pattern. This produces a pulsed triangle useful for switching spectroscopy 
    where the measurement needs to be gated. The voltage is applied during ON periods 
    and set to zero during OFF periods, allowing synchronized AC measurements during 
    the OFF periods.
    
    Args:
        cycle_amplitude (float, optional): Peak amplitude of the triangle wave. Default is 1.0.
            The waveform oscillates between -cycle_amplitude (during ON) and 0 (during OFF).
            Must be within DAQ output range.
        cycle_phase_shift (float, optional): Phase shift in cycles (not radians). Default is 0.
            Controls starting point in the triangle cycle.
            Same behavior as triangular() function.
        cycle_number (int, optional): Number of times to repeat the waveform pattern. Default is 1.
            Each repeat is an identical pulsed triangle cycle.
        steps_per_cycle (int, optional): Number of discrete voltage steps in one complete cycle. 
            Default is 32.
            Higher values create smoother triangles.
        points_per_step (int, optional): Number of samples per discrete step **before** ON/OFF 
            modulation. Default is 1.
            Each step will have 2×points_per_step samples after modulation:
            - First points_per_step samples: ON (triangle amplitude)
            - Second points_per_step samples: OFF (zero)
        cycle_fraction (float, optional): Fraction of one cycle to use before repeating (0 to 1). 
            Default is 1.0.
            Applied to the complete cycle before tiling.
    
    Returns:
        tuple: A tuple containing:
            - **step_vector** (List[float]): Sample indices for the waveform.
                Simple enumeration (0, 1, 2, ..., N-1).
            - **waveform_vector** (List[float]): Pulse-modulated triangular waveform.
                Alternates between triangle values (ON) and zero (OFF).

    Examples:
        Pulsed triangle for switching spectroscopy:
        
        >>> steps, wave = triangular_modulated_pulse(
        ...     cycle_amplitude=10.0,
        ...     steps_per_cycle=32,
        ...     points_per_step=100
        ... )
        >>> # Each voltage step: 100 samples ON, 100 samples OFF
        >>> print(f"Total samples: {len(wave)}")
        >>> print(f"Samples per voltage step: {200}")
        Total samples: 6400
        Samples per voltage step: 200
    """
    # Time axis for one cycle
    step = np.linspace(0, 1, steps_per_cycle, endpoint=False)
    step = np.repeat(step, points_per_step*2)

    # Base triangle (see notes in `triangular`)
    tri_waveform = cycle_amplitude * sawtooth(
        2 * np.pi * step + np.pi / 2 + np.pi * cycle_phase_shift * 2,
        width=0.5
    )

    # (ON/OFF pattern):
    # - This creates a square gate inside each step with 50% duty (1's then 0's).
    # - Pattern is built for the full single cycle, then broadcast across it.
    pulse_pattern = np.repeat([1, 0], points_per_step)
    pulse_pattern = np.tile(pulse_pattern, steps_per_cycle)

    # elementwise gate -> ON segments preserved, OFF segments zeroed.
    pulse_triangular = tri_waveform * pulse_pattern

    # Truncate to the requested fraction of one cycle, then tile
    keep = int(cycle_fraction * len(pulse_triangular))
    pulse_triangular = pulse_triangular[:keep]
    waveform_vector = np.tile(pulse_triangular, cycle_number)

    step_vector= np.arange(len(waveform_vector))
    return step_vector.tolist(), waveform_vector.tolist()

@log_function
def forc(forc_segment_number: int = 3, forc_start_amplitude: float = 1, forc_end_amplitude: float = 5,
         cycle_phase_shift: float = 0, cycle_number: int = 1, steps_per_cycle: int = 32, 
         points_per_step: int = 1, cycle_fraction: float = 1) -> Tuple[List[float], list[float]]:
    """Generate a First-Order Reversal Curve (FORC) waveform.
    
    Creates a FORC waveform by concatenating triangular segments with linearly
    increasing amplitudes. FORC is a powerful technique used to characterize hysteresis,
    switching behavior, and interaction fields in ferroelectric and ferromagnetic materials.
    The method provides detailed information about switching distributions by applying
    a series of minor hysteresis loops with progressively larger reversal points.
    
    Args:
        forc_segment_number (int, optional): Number of amplitude segments in the FORC sequence. 
            Default is 3.
            Each segment is a complete triangle wave at a different amplitude.
            More segments → finer amplitude resolution but longer measurement time.
            Typical range: 5-50 depending on measurement requirements.
        forc_start_amplitude (float, optional): Amplitude of the first triangle segment. 
            Default is 1.0.
            Starting point of the amplitude ramp.
            Should be positive (negative would be symmetric).
        forc_end_amplitude (float, optional): Amplitude of the final triangle segment. 
            Default is 5.0.
            End point of the amplitude ramp.
            Typically larger than forc_start_amplitude for increasing amplitude sequence.
        cycle_phase_shift (float, optional): Phase shift applied to all triangular segments 
            (in cycles). Default is 0.
            Passed to triangular() for each segment.
            Affects starting point within each triangle cycle.
        cycle_number (int, optional): Number of triangle cycles per amplitude segment. 
            Default is 1.
            Each amplitude level can include multiple triangle cycles for averaging.
        steps_per_cycle (int, optional): Number of discrete steps in each triangle cycle. 
            Default is 32.
            Determines voltage resolution within each cycle.
        points_per_step (int, optional): Number of samples per discrete step. Default is 1.
            Controls dwell time at each voltage level.
        cycle_fraction (float, optional): Fraction of each triangle cycle to include (0 to 1). 
            Default is 1.0.
            Allows partial cycles (e.g., 0.5 for half-cycle reversals).
    
    Returns:
        tuple: A tuple containing:
            - **step_vector** (List[float]): Sample indices across the concatenated waveform.
                Simple enumeration (0, 1, 2, ..., N-1).
            - **waveform_vector** (List[float]): FORC waveform with linearly ramped amplitude 
                segments.
                Concatenation of forc_segment_number triangle waveforms.
    
    Examples:
        Basic FORC with 5 amplitude steps:
        
        >>> steps, wave = forc(
        ...     forc_segment_number=5,
        ...     forc_start_amplitude=1.0,
        ...     forc_end_amplitude=10.0,
        ...     steps_per_cycle=32
        ... )
        >>> print(f"Total samples: {len(wave)}")
        >>> print(f"Samples per segment: {len(wave) // 5}")
        Total samples: 160
        Samples per segment: 32
    """
    # amplitude changes per segment; each segment is a triangular() call with its own amplitude
    forc_amplitudes = np.linspace(forc_start_amplitude, forc_end_amplitude, forc_segment_number)
    forc_wv = []
    for fcn in range(forc_segment_number):
        # triangular() returns (time, wave); we only need the wave to concatenate
        _, wv = triangular(
            forc_amplitudes[fcn], cycle_phase_shift, cycle_number,
            steps_per_cycle, points_per_step, cycle_fraction
        )
        forc_wv.append(wv)

    waveform_vector = np.concatenate(forc_wv) if len(forc_wv) else np.array([], dtype=float)
    step_vector = np.arange(len(waveform_vector))
    return step_vector.tolist(), waveform_vector.tolist()

@log_function
def forc_modulated_pulse(forc_segment_number: int = 3, forc_start_amplitude: float = 1, forc_end_amplitude: float = 5,
                         cycle_phase_shift: float = 0, cycle_number: int = 1, steps_per_cycle: int = 32, 
                         points_per_step: int = 1, cycle_fraction: float = 1) -> Tuple[List[float], list[float]]:
    """Generate a pulse-modulated First-Order Reversal Curve (FORC) waveform.
    
    Creates a FORC waveform with 50% duty cycle ON/OFF pulse modulation applied to
    each voltage step. Combines the amplitude ramping of FORC with pulse gating for
    switching spectroscopy applications. This allows separation of DC bias application 
    (ON periods) from AC measurement (OFF periods), enabling high-resolution switching 
    spectroscopy with reduced capacitive artifacts.
    
    Args:
        forc_segment_number (int, optional): Number of amplitude segments in the FORC sequence. 
            Default is 3.
            Each segment is a pulsed triangle at progressively larger amplitude.
        forc_start_amplitude (float, optional): Amplitude of the first segment. Default is 1.0.
            Starting amplitude of the FORC sequence.
        forc_end_amplitude (float, optional): Amplitude of the final segment. Default is 5.0.
            Ending amplitude of the FORC sequence.
        cycle_phase_shift (float, optional): Phase shift applied to all segments (in cycles). 
            Default is 0.
            Passed to triangular() for phase control.
        cycle_number (int, optional): Number of triangle cycles per amplitude segment. 
            Default is 1.
            Multiple cycles allow averaging at each amplitude.
        steps_per_cycle (int, optional): Number of discrete steps in each triangle cycle. 
            Default is 32.
            Determines voltage resolution.
        points_per_step (int, optional): Number of samples per discrete step **before** modulation. 
            Default is 1.
            Each step will have 2×points_per_step samples after modulation:
            - First points_per_step: ON (bias applied)
            - Second points_per_step: OFF (zero for AC measurement)
        cycle_fraction (float, optional): Fraction of each triangle cycle to include (0 to 1). 
            Default is 1.0.
            Allows partial cycle measurements.
    
    Returns:
        tuple: A tuple containing:
            - **step_vector** (List[float]): Sample indices across the full waveform.
                Simple enumeration of concatenated segments.
            - **waveform_vector** (List[float]): Pulse-modulated FORC waveform.
                Concatenation of pulsed triangular segments with increasing amplitude.
    
    Examples:
        Pulsed FORC for switching spectroscopy:
        
        >>> steps, wave = forc_modulated_pulse(
        ...     forc_segment_number=10,
        ...     forc_start_amplitude=2.0,
        ...     forc_end_amplitude=10.0,
        ...     steps_per_cycle=32,
        ...     points_per_step=50
        ... )
        >>> print(f"Total samples: {len(wave)}")
        >>> print(f"Each voltage step: 50 ON + 50 OFF = 100 samples")
        Total samples: 32000
        Each voltage step: 50 ON + 50 OFF = 100 samples
    """
    # Amplitude levels across the sweep
    forc_amplitudes = np.linspace(forc_start_amplitude, forc_end_amplitude, forc_segment_number)
    forc_wv = []
    for fcn in range(forc_segment_number):
        _, wv = triangular(
            forc_amplitudes[fcn], cycle_phase_shift, cycle_number,
            steps_per_cycle, points_per_step*2, cycle_fraction
        )
        forc_wv.append(wv)
    forc_wv = np.concatenate(forc_wv) if len(forc_wv) else np.array([], dtype=float)

    # (gate for the full FORC signal):
    # - 50% duty per step (1's then 0's).
    pulse_pattern = np.repeat([1, 0], points_per_step)
    pulse_pattern = np.tile(pulse_pattern, steps_per_cycle * cycle_number * forc_segment_number)

    # pattern is built to match length based on ideal counts;
    # if lengths mismatch due to odd divisors or rounding, slice to the shorter one.
    L = min(len(forc_wv), len(pulse_pattern))
    waveform_vector = (forc_wv[:L]) * (pulse_pattern[:L])

    step_vector = np.arange(len(waveform_vector))
    return step_vector.tolist(), waveform_vector.tolist()
