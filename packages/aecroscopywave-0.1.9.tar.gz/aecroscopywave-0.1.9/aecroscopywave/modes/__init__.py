"""
Experiment modes for PyWave, connects PyWave with experiments
"""

