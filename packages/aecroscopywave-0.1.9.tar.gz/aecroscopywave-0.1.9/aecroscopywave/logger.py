"""
GLOBAL LOGGING SYSTEM - Works Across Multiple Files and Jupyter Notebooks
===========================================================================

This module provides a global logging system that:
1. Uses a default log filename
2. Works across multiple .py files
3. All functions log to the same file when used in Jupyter notebooks
4. Can be reconfigured at runtime
5. SUPPORTS SILENT MODE - log to file without printing to console

Usage:
------
In your .py files, just use @log_function decorator.
In Jupyter notebook, import and use - everything logs to one file!

NEW: Set console=False to log silently (file only, no console output)
"""

import functools
import sys
import inspect
import time
from datetime import datetime
from pathlib import Path
import os


class GlobalLogConfig:
    """Global logging configuration shared across all modules."""
    
    def __init__(self):
        self.log_file = 'experiment_log.txt'  # Default filename
        self.log_dir = 'logs'
        self.console = False  # Can be set to False for silent logging
        self.log_type = 'io'  # 'io', 'vars', or 'all'
        self.enabled = False
        self._file_initialized = False
        self._log_path = None
    
    def configure(self, log_file=None, log_dir=None, console=None, 
                  log_type=None, enabled=None):
        """
        Configure global logging settings.
        
        Parameters
        ----------
        log_file : str, optional
            Log filename. If None, keeps current.
        log_dir : str, optional
            Log directory. If None, keeps current.
        console : bool, optional
            Print to console. If None, keeps current.
            Set to False for silent mode (log to file only)
        log_type : str, optional
            Logging type: 'io', 'vars', or 'all'. If None, keeps current.
        enabled : bool, optional
            Enable/disable logging. If None, keeps current.
        
        Examples
        --------
        >>> from global_logger import configure_logging
        >>> 
        >>> # Set custom log filename
        >>> configure_logging(log_file='my_experiment_2024.log')
        >>> 
        >>> # Change to detailed logging
        >>> configure_logging(log_type='all')
        >>> 
        >>> # Disable console output (SILENT MODE - logs to file only)
        >>> configure_logging(console=False)
        >>> 
        >>> # Re-enable console output
        >>> configure_logging(console=True)
        """
        if log_file is not None:
            self.log_file = log_file
            self._file_initialized = False  # Reinitialize with new name
        
        if log_dir is not None:
            self.log_dir = log_dir
            self._file_initialized = False
        
        if console is not None:
            self.console = console
        
        if log_type is not None:
            if log_type not in ('io', 'vars', 'all'):
                raise ValueError("log_type must be 'io', 'vars', or 'all'")
            self.log_type = log_type
        
        if enabled is not None:
            self.enabled = enabled
        
        # Update log path
        self._log_path = f"{self.log_dir}/{self.log_file}"
    
    def get_log_path(self):
        """Get full path to log file."""
        if self._log_path is None:
            self._log_path = f"{self.log_dir}/{self.log_file}"
        return self._log_path
    
    def initialize_log_file(self):
        """Initialize log file with header."""
        if not self._file_initialized:
            Path(self.log_dir).mkdir(exist_ok=True)
            log_path = self.get_log_path()
            
            # Check if file exists and has content
            if not os.path.exists(log_path) or os.path.getsize(log_path) == 0:
                with open(log_path, 'w') as f:
                    f.write('='*70 + '\n')
                    f.write(f'GLOBAL EXPERIMENT LOG\n')
                    f.write(f'Log File: {self.log_file}\n')
                    f.write(f'Started: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
                    f.write('='*70 + '\n\n')
            
            self._file_initialized = True
    
    def reset_log_file(self):
        """Clear the log file and reinitialize."""
        self._file_initialized = False
        log_path = self.get_log_path()
        if os.path.exists(log_path):
            os.remove(log_path)
        self.initialize_log_file()
    
    def enable(self):
        """Enable logging."""
        self.enabled = True
    
    def disable(self):
        """Disable logging."""
        self.enabled = False


# Global instance
_global_config = GlobalLogConfig()








# HELPER FUNCTIONS FOR INDENTATION

def _get_call_stack_depth():
    """
    Calculate the depth of decorated function calls in the call stack.
    
    Returns
    -------
    int
        The depth of nested decorated function calls (0 for top-level)
    """
    frame = inspect.currentframe()
    depth = 0
    
    try:
        # Walk up the call stack
        current_frame = frame.f_back.f_back  # Skip current function and wrapper
        
        while current_frame is not None:
            # Check if this frame belongs to a decorated function
            # Look for the wrapper function pattern
            if (current_frame.f_code.co_name == 'wrapper' and 
                hasattr(current_frame, 'f_locals') and 
                'func' in current_frame.f_locals):
                depth += 1
            
            current_frame = current_frame.f_back
        
        return depth
    finally:
        del frame


def _get_indent(depth):
    """
    Get indentation string based on call depth.
    
    Parameters
    ----------
    depth : int
        The call stack depth
    
    Returns
    -------
    str
        Indentation string (2 spaces per level)
    """
    return "  " * depth


# GLOBAL CONFIGURATION

# Thread-local storage to track TeeToLog nesting depth
import threading
_tee_context = threading.local()

def _get_tee_depth():
    """Get the current TeeToLog nesting depth."""
    if not hasattr(_tee_context, 'depth'):
        _tee_context.depth = 0
    return _tee_context.depth

def _increment_tee_depth():
    """Increment the TeeToLog nesting depth."""
    if not hasattr(_tee_context, 'depth'):
        _tee_context.depth = 0
    _tee_context.depth += 1
    return _tee_context.depth

def _decrement_tee_depth():
    """Decrement the TeeToLog nesting depth."""
    if not hasattr(_tee_context, 'depth'):
        _tee_context.depth = 0
    if _tee_context.depth > 0:
        _tee_context.depth -= 1
    return _tee_context.depth



# PUBLIC CONFIGURATION FUNCTIONS

def configure_logging(**kwargs):
    """
    Configure global logging settings.
    
    Parameters
    ----------
    log_file : str, optional
        Log filename
    log_dir : str, optional
        Log directory
    console : bool, optional
        Print to console (True) or silent mode (False)
    log_type : str, optional
        Logging type: 'io', 'vars', or 'all'
    enabled : bool, optional
        Enable/disable logging
    
    Examples
    --------
    >>> configure_logging(log_file='my_experiment.log')
    >>> configure_logging(log_type='all', console=False)  # Silent mode
    >>> configure_logging(console=True)  # Re-enable console output
    """
    _global_config.configure(**kwargs)
    print(f"✓ Logging configured:")
    print(f"  File: {_global_config.log_dir}/{_global_config.log_file}")
    print(f"  Type: {_global_config.log_type}")
    print(f"  Console: {_global_config.console}")
    print(f"  Enabled: {_global_config.enabled}")


def reset_log():
    """Clear the current log file and start fresh."""
    _global_config.reset_log_file()
    print(f"✓ Log file reset: {_global_config.get_log_path()}")


def enable_logging():
    """Enable logging."""
    _global_config.enable()
    print("✓ Logging enabled")


def disable_logging():
    """Disable logging."""
    _global_config.disable()
    print("✓ Logging disabled")


def get_log_path():
    """Get the current log file path."""
    return _global_config.get_log_path()


# LOGGING DECORATORS

def log_function(func):
    """
    Decorator that logs function to the global log file.
    
    This is the main decorator to use in your .py files.
    It automatically uses the global configuration.
    
    Examples
    --------
    In your_module.py:
    >>> from global_logger import log_function
    >>> 
    >>> @log_function
    ... def process_data(data):
    ...     print("Processing...")
    ...     return sum(data)
    
    In Jupyter notebook:
    >>> from global_logger import configure_logging
    >>> from your_module import process_data
    >>> 
    >>> configure_logging(log_file='my_experiment.log')
    >>> result = process_data([1, 2, 3])  # Logs to my_experiment.log
    >>> 
    >>> # Silent mode - logs but doesn't print
    >>> configure_logging(console=False)
    >>> result = process_data([1, 2, 3])  # Logs to file, no console output
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Check if logging is enabled
        if not _global_config.enabled:
            return func(*args, **kwargs)
        
        # Initialize log file if needed
        _global_config.initialize_log_file()
        
        # Get log type
        log_type = _global_config.log_type
        
        # Execute appropriate logging
        if log_type == 'io':
            return _log_io_impl(func, args, kwargs)
        elif log_type == 'vars':
            return _log_vars_impl(func, args, kwargs)
        elif log_type == 'all':
            return _log_all_impl(func, args, kwargs)
        else:
            return func(*args, **kwargs)
    
    return wrapper



# INTERNAL LOGGING IMPLEMENTATIONS

def _log_io_impl(func, args, kwargs):
    """Internal implementation of I/O logging."""
    old_stdout = sys.stdout
    
    # Get the call stack depth for indentation
    depth = _get_call_stack_depth()
    indent = _get_indent(depth)
    
    # Track TeeToLog nesting to prevent duplicate file writes
    tee_depth = _increment_tee_depth()
    write_to_file = (tee_depth == 1)  # Only the outermost TeeToLog writes to file
    
    class TeeToLog:
        def __init__(self, indent_str, write_file):
            self.terminal = old_stdout
            self.indent_str = indent_str
            self.at_line_start = True
            self.write_file = write_file
        
        def write(self, message):
            # Apply indentation to each line
            indented_message = ""
            for char in message:
                if self.at_line_start and char not in ['\n', '\r']:
                    indented_message += self.indent_str
                    self.at_line_start = False
                indented_message += char
                if char == '\n':
                    self.at_line_start = True
            
            if _global_config.console:
                self.terminal.write(indented_message)
            if self.write_file:
                with open(_global_config.get_log_path(), 'a') as f:
                    f.write(indented_message)
        
        def flush(self):
            self.terminal.flush()
    
    sys.stdout = TeeToLog(indent, write_to_file)
    
    try:
        print('='*70)
        print(f'Function: {func.__name__}')
        print(f'Module: {func.__module__}')
        print(f'Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        print('='*70)
        
        print('\nINPUT ARGUMENTS:')
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()
        for param_name, param_value in bound_args.arguments.items():
            print(f'  {param_name} = {repr(param_value)}')
        
        print('\nEXECUTION OUTPUT:')
        
        start_time = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start_time
        
        print('\nRETURN VALUE:')
        print(f'  {repr(result)}')
        
        print(f'\nExecution time: {elapsed:.3f} seconds')
        print('='*70)
        print()
        
        return result
        
    finally:
        sys.stdout = old_stdout
        _decrement_tee_depth()


def _log_vars_impl(func, args, kwargs):
    """Internal implementation of variable logging."""
    old_stdout = sys.stdout
    
    # Get the call stack depth for indentation
    depth = _get_call_stack_depth()
    indent = _get_indent(depth)
    
    # Track TeeToLog nesting to prevent duplicate file writes
    tee_depth = _increment_tee_depth()
    write_to_file = (tee_depth == 1)  # Only the outermost TeeToLog writes to file
    
    class TeeToLog:
        def __init__(self, indent_str, write_file):
            self.terminal = old_stdout
            self.indent_str = indent_str
            self.at_line_start = True
            self.write_file = write_file
        
        def write(self, message):
            # Apply indentation to each line
            indented_message = ""
            for char in message:
                if self.at_line_start and char not in ['\n', '\r']:
                    indented_message += self.indent_str
                    self.at_line_start = False
                indented_message += char
                if char == '\n':
                    self.at_line_start = True
            
            if _global_config.console:
                self.terminal.write(indented_message)
            if self.write_file:
                with open(_global_config.get_log_path(), 'a') as f:
                    f.write(indented_message)
        
        def flush(self):
            self.terminal.flush()
    
    sys.stdout = TeeToLog(indent, write_to_file)
    
    var_history = []
    
    def trace_calls(frame, event, arg):
        if event == 'line' and frame.f_code.co_name == func.__name__:
            local_vars = frame.f_locals.copy()
            line_no = frame.f_lineno
            for var_name, var_value in local_vars.items():
                if not var_name.startswith('__'):
                    var_history.append((line_no, var_name, var_value))
        return trace_calls
    
    try:
        print('='*70)
        print(f'Function: {func.__name__}')
        print(f'Module: {func.__module__}')
        print(f'Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        print('='*70)
        print('\nVARIABLE ASSIGNMENTS:\n')
        
        sys.settrace(trace_calls)
        start_time = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start_time
        sys.settrace(None)
        
        seen_vars = {}
        for line_no, var_name, var_value in var_history:
            value_repr = repr(var_value)
            if seen_vars.get(var_name) != value_repr:
                print(f'[Line {line_no}] {var_name} = {value_repr}')
                seen_vars[var_name] = value_repr
        
        print('\nFINAL VARIABLE STATE:')
        for var_name, var_value in seen_vars.items():
            print(f'  {var_name} = {var_value}')
        
        print(f'\nExecution time: {elapsed:.3f} seconds')
        print('='*70)
        print()
        
        return result
        
    finally:
        sys.stdout = old_stdout
        _decrement_tee_depth()


def _log_all_impl(func, args, kwargs):
    """Internal implementation of complete logging."""
    old_stdout = sys.stdout
    
    # Get the call stack depth for indentation
    depth = _get_call_stack_depth()
    indent = _get_indent(depth)
    
    # Track TeeToLog nesting to prevent duplicate file writes
    tee_depth = _increment_tee_depth()
    write_to_file = (tee_depth == 1)  # Only the outermost TeeToLog writes to file
    
    class TeeToLog:
        def __init__(self, indent_str, write_file):
            self.terminal = old_stdout
            self.indent_str = indent_str
            self.at_line_start = True
            self.write_file = write_file
        
        def write(self, message):
            # Apply indentation to each line
            indented_message = ""
            for char in message:
                if self.at_line_start and char not in ['\n', '\r']:
                    indented_message += self.indent_str
                    self.at_line_start = False
                indented_message += char
                if char == '\n':
                    self.at_line_start = True
            
            if _global_config.console:
                self.terminal.write(indented_message)
            if self.write_file:
                with open(_global_config.get_log_path(), 'a') as f:
                    f.write(indented_message)
        
        def flush(self):
            self.terminal.flush()
    
    sys.stdout = TeeToLog(indent, write_to_file)
    
    var_history = []
    
    def trace_calls(frame, event, arg):
        if event == 'line' and frame.f_code.co_name == func.__name__:
            local_vars = frame.f_locals.copy()
            line_no = frame.f_lineno
            for var_name, var_value in local_vars.items():
                if not var_name.startswith('__'):
                    var_history.append((line_no, var_name, var_value))
        return trace_calls
    
    try:
        print('='*70)
        print(f'Function: {func.__name__}')
        print(f'Module: {func.__module__}')
        print(f'Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        print('='*70)
        
        print('\nINPUT ARGUMENTS:')
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()
        for param_name, param_value in bound_args.arguments.items():
            print(f'  {param_name} = {repr(param_value)}')
        
        print('\nEXECUTION OUTPUT:')
        
        sys.settrace(trace_calls)
        start_time = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start_time
        sys.settrace(None)
        
        print('\nVARIABLE TRACKING:')
        seen_vars = {}
        for line_no, var_name, var_value in var_history:
            value_repr = repr(var_value)
            if seen_vars.get(var_name) != value_repr:
                print(f'[Line {line_no}] {var_name} = {value_repr}')
                seen_vars[var_name] = value_repr
        
        print('\nFINAL VARIABLE STATE:')
        for var_name, var_value in seen_vars.items():
            print(f'  {var_name} = {var_value}')
        
        print('\nRETURN VALUE:')
        print(f'  {repr(result)}')
        
        print(f'\nExecution time: {elapsed:.3f} seconds')
        print('='*70)
        print()
        
        return result
        
    finally:
        sys.stdout = old_stdout
        _decrement_tee_depth()



# CONVENIENCE FUNCTION
def finalize_log():
    """Add a footer to the log file."""
    if _global_config._file_initialized:
        with open(_global_config.get_log_path(), 'a') as f:
            f.write('\n' + '='*70 + '\n')
            f.write(f'LOG FINALIZED: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            f.write('='*70 + '\n')
        print(f"✓ Log finalized: {_global_config.get_log_path()}")



# EXAMPLE USAGE
if __name__ == '__main__':
    print("="*70)
    print("GLOBAL LOGGING SYSTEM - DEMONSTRATION")
    print("="*70)
    print()
    
    # Configure logging
    configure_logging(log_file='demo_global_log.log', log_type='io')