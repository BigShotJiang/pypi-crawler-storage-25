"""Compatibility entrypoint for the WaveCraft MCP server."""

from __future__ import annotations

from importlib import import_module

from aecroscopywave.mcp.server import create_mcp_server

mcp = create_mcp_server()

_COMPAT_EXPORTS = {
    "set_afm_instances": "aecroscopywave.mcp.tools.core",
    "set_vi_instances": "aecroscopywave.mcp.tools.core",
    "ARExecuteControl": "aecroscopywave.mcp.tools.cypher",
    "Execute": "aecroscopywave.mcp.tools.cypher",
    "PV": "aecroscopywave.mcp.tools.cypher",
    "doIV": "aecroscopywave.mcp.tools.cypher",
    "engage": "aecroscopywave.mcp.tools.cypher",
    "get_MasterVariables": "aecroscopywave.mcp.tools.cypher",
    "initialize_move_tip": "aecroscopywave.mcp.tools.cypher",
    "is_scanning": "aecroscopywave.mcp.tools.cypher",
    "move_tip": "aecroscopywave.mcp.tools.cypher",
    "pixel_to_voltage": "aecroscopywave.mcp.tools.cypher",
    "pixel_to_xy": "aecroscopywave.mcp.tools.cypher",
    "set_CrosspointPanel": "aecroscopywave.mcp.tools.cypher",
    "set_Master_Panel": "aecroscopywave.mcp.tools.cypher",
    "withdraw": "aecroscopywave.mcp.tools.cypher",
    "xy_to_voltage": "aecroscopywave.mcp.tools.cypher",
    "clear_6124": "aecroscopywave.mcp.tools.wavevi",
    "get_AI_waveforms": "aecroscopywave.mcp.tools.wavevi",
    "get_AO_waveforms": "aecroscopywave.mcp.tools.wavevi",
    "get_AO_waveforms_duration": "aecroscopywave.mcp.tools.wavevi",
    "get_IO_parameters": "aecroscopywave.mcp.tools.wavevi",
    "get_IO_settings": "aecroscopywave.mcp.tools.wavevi",
    "run_6124_IO_10": "aecroscopywave.mcp.tools.wavevi",
    "set_AO_waveforms": "aecroscopywave.mcp.tools.wavevi",
    "set_IO_control": "aecroscopywave.mcp.tools.wavevi",
    "set_IO_settings": "aecroscopywave.mcp.tools.wavevi",
    "upload_to_6124": "aecroscopywave.mcp.tools.wavevi",
    "wait_for_vi_flag": "aecroscopywave.mcp.tools.wavevi",
    "square_wave": "aecroscopywave.wavebuilding.WaveGenerator",
    "square_pulse": "aecroscopywave.wavebuilding.WaveGenerator",
    "chirp_wave": "aecroscopywave.wavebuilding.WaveGenerator",
    "composite_wave": "aecroscopywave.wavebuilding.WaveGenerator",
    "triangular": "aecroscopywave.wavebuilding.WaveGenerator",
    "triangular_modulated_pulse": "aecroscopywave.wavebuilding.WaveGenerator",
    "forc": "aecroscopywave.wavebuilding.WaveGenerator",
    "forc_modulated_pulse": "aecroscopywave.wavebuilding.WaveGenerator",
    "timebase": "aecroscopywave.wavebuilding.utils",
    "compute_waveform_duration": "aecroscopywave.wavebuilding.utils",
    "embed_waveforms": "aecroscopywave.wavebuilding.utils",
}

__all__ = ["mcp", "main", *sorted(_COMPAT_EXPORTS)]


def __getattr__(name: str):
    module_name = _COMPAT_EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = import_module(module_name)
    return getattr(module, name)


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
