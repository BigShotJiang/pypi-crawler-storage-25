"""FastMCP server factory and registration helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from fastmcp import FastMCP

from .config import tools_enabled
from .tools import core, cypher, wavegen, wavevi


@dataclass(frozen=True)
class ToolRegistration:
    fn: Callable[..., Any]
    name: str
    group: str
    title: str
    tags: tuple[str, ...]
    legacy_aliases: tuple[str, ...] = ()
    description: str | None = None


def _description_for(tool: Callable[..., Any]) -> str | None:
    doc = (tool.__doc__ or "").strip()
    if not doc:
        return None
    first_line = doc.splitlines()[0].strip()
    return first_line or None


def _core_registrations() -> list[ToolRegistration]:
    return [
        ToolRegistration(
            fn=core.set_afm_instances,
            name="set_afm_instances",
            group="core",
            title="Initialize AFM Controller",
            tags=("core", "setup", "cypher"),
        ),
        ToolRegistration(
            fn=core.set_vi_instances,
            name="set_vi_instances",
            group="core",
            title="Initialize WaveVI Controller",
            tags=("core", "setup", "wavevi"),
        ),
    ]


def _wavevi_registrations() -> list[ToolRegistration]:
    return [
        ToolRegistration(wavevi.wait_for_vi_flag, "wavevi_wait_for_vi_flag", "wavevi", "Wait For VI Flag", ("wavevi", "daq", "sync"), ("wait_for_vi_flag",)),
        ToolRegistration(wavevi.get_IO_settings, "wavevi_get_io_settings", "wavevi", "Get IO Settings", ("wavevi", "daq", "read"), ("get_IO_settings",)),
        ToolRegistration(wavevi.get_IO_parameters, "wavevi_get_io_parameters", "wavevi", "Get IO Parameters", ("wavevi", "daq", "read"), ("get_IO_parameters",)),
        ToolRegistration(wavevi.set_IO_settings, "wavevi_set_io_settings", "wavevi", "Set IO Settings", ("wavevi", "daq", "write"), ("set_IO_settings",)),
        ToolRegistration(wavevi.set_AO_waveforms, "wavevi_set_ao_waveforms", "wavevi", "Set AO Waveforms", ("wavevi", "daq", "waveform"), ("set_AO_waveforms",)),
        ToolRegistration(wavevi.get_AO_waveforms, "wavevi_get_ao_waveforms", "wavevi", "Get AO Waveforms", ("wavevi", "daq", "waveform"), ("get_AO_waveforms",)),
        ToolRegistration(wavevi.get_AO_waveforms_duration, "wavevi_get_ao_waveforms_duration", "wavevi", "Get AO Waveform Duration", ("wavevi", "daq", "waveform"), ("get_AO_waveforms_duration",)),
        ToolRegistration(wavevi.get_AI_waveforms, "wavevi_get_ai_waveforms", "wavevi", "Get AI Waveforms", ("wavevi", "daq", "waveform"), ("get_AI_waveforms",)),
        ToolRegistration(wavevi.upload_to_6124, "wavevi_upload_to_6124", "wavevi", "Upload To 6124", ("wavevi", "daq", "upload"), ("upload_to_6124",)),
        ToolRegistration(wavevi.clear_6124, "wavevi_clear_6124", "wavevi", "Clear 6124", ("wavevi", "daq", "reset"), ("clear_6124",)),
        ToolRegistration(wavevi.run_6124_IO_10, "wavevi_run_6124_io_10", "wavevi", "Run 6124 IO", ("wavevi", "daq", "run"), ("run_6124_IO_10",)),
        ToolRegistration(wavevi.set_IO_control, "wavevi_set_io_control", "wavevi", "Run IO Control Sequence", ("wavevi", "daq", "workflow"), ("set_IO_control",)),
    ]


def _cypher_registrations() -> list[ToolRegistration]:
    return [
        ToolRegistration(cypher.Execute, "cypher_execute", "cypher", "Execute Igor Command", ("cypher", "afm", "low-level"), ("Execute",)),
        ToolRegistration(cypher.PV, "cypher_set_master_variables", "cypher", "Set Master Variables", ("cypher", "afm", "parameters"), ("PV",)),
        ToolRegistration(cypher.ARExecuteControl, "cypher_execute_control", "cypher", "Execute UI Control", ("cypher", "afm", "ui"), ("ARExecuteControl",)),
        ToolRegistration(cypher.set_Master_Panel, "cypher_set_master_panel", "cypher", "Set Master Panel", ("cypher", "afm", "scan"), ("set_Master_Panel",)),
        ToolRegistration(cypher.set_CrosspointPanel, "cypher_set_crosspoint_panel", "cypher", "Set Crosspoint Panel", ("cypher", "afm", "routing"), ("set_CrosspointPanel",)),
        ToolRegistration(cypher.doIV, "cypher_do_iv", "cypher", "Run IV Measurement", ("cypher", "afm", "measurement"), ("doIV",)),
        ToolRegistration(cypher.get_MasterVariables, "cypher_get_master_variables", "cypher", "Get Master Variables", ("cypher", "afm", "read"), ("get_MasterVariables",)),
        ToolRegistration(cypher.is_scanning, "cypher_is_scanning", "cypher", "Check Scanning State", ("cypher", "afm", "state"), ("is_scanning",)),
        ToolRegistration(cypher.engage, "cypher_engage", "cypher", "Engage Tip", ("cypher", "afm", "motion"), ("engage",)),
        ToolRegistration(cypher.withdraw, "cypher_withdraw", "cypher", "Withdraw Tip", ("cypher", "afm", "motion"), ("withdraw",)),
        ToolRegistration(cypher.pixel_to_xy, "cypher_pixel_to_xy", "cypher", "Convert Pixel To XY", ("cypher", "afm", "coordinates"), ("pixel_to_xy",)),
        ToolRegistration(cypher.xy_to_voltage, "cypher_xy_to_voltage", "cypher", "Convert XY To Voltage", ("cypher", "afm", "coordinates"), ("xy_to_voltage",)),
        ToolRegistration(cypher.pixel_to_voltage, "cypher_pixel_to_voltage", "cypher", "Convert Pixel To Voltage", ("cypher", "afm", "coordinates"), ("pixel_to_voltage",)),
        ToolRegistration(cypher.initialize_move_tip, "cypher_initialize_move_tip", "cypher", "Initialize Tip Move", ("cypher", "afm", "motion"), ("initialize_move_tip",)),
        ToolRegistration(cypher.move_tip, "cypher_move_tip", "cypher", "Move Tip", ("cypher", "afm", "motion"), ("move_tip",)),
    ]


def _wavegen_registrations() -> list[ToolRegistration]:
    square_wave, square_pulse, chirp_wave, composite_wave, triangular, triangular_modulated_pulse, forc, forc_modulated_pulse, timebase, compute_waveform_duration, embed_waveforms = wavegen.get_tools()
    return [
        ToolRegistration(square_wave, "wavegen_square_wave", "wavegen", "Generate Square Wave", ("wavegen", "waveform"), ("square_wave",)),
        ToolRegistration(square_pulse, "wavegen_square_pulse", "wavegen", "Generate Square Pulse", ("wavegen", "waveform"), ("square_pulse",)),
        ToolRegistration(chirp_wave, "wavegen_chirp_wave", "wavegen", "Generate Chirp Wave", ("wavegen", "waveform"), ("chirp_wave",)),
        ToolRegistration(composite_wave, "wavegen_composite_wave", "wavegen", "Generate Composite Wave", ("wavegen", "waveform"), ("composite_wave",)),
        ToolRegistration(triangular, "wavegen_triangular", "wavegen", "Generate Triangular Wave", ("wavegen", "waveform"), ("triangular",)),
        ToolRegistration(triangular_modulated_pulse, "wavegen_triangular_modulated_pulse", "wavegen", "Generate Triangular Modulated Pulse", ("wavegen", "waveform"), ("triangular_modulated_pulse",)),
        ToolRegistration(forc, "wavegen_forc", "wavegen", "Generate FORC Waveform", ("wavegen", "waveform"), ("forc",)),
        ToolRegistration(forc_modulated_pulse, "wavegen_forc_modulated_pulse", "wavegen", "Generate FORC Modulated Pulse", ("wavegen", "waveform"), ("forc_modulated_pulse",)),
        ToolRegistration(timebase, "wavegen_timebase", "wavegen", "Build Timebase", ("wavegen", "utility"), ("timebase",)),
        ToolRegistration(compute_waveform_duration, "wavegen_compute_waveform_duration", "wavegen", "Compute Waveform Duration", ("wavegen", "utility"), ("compute_waveform_duration",)),
        ToolRegistration(embed_waveforms, "wavegen_embed_waveforms", "wavegen", "Embed Waveforms", ("wavegen", "utility"), ("embed_waveforms",)),
    ]


def _build_capabilities_tool(registry: list[dict[str, Any]], enabled_groups: list[str]):
    def list_server_capabilities() -> dict[str, Any]:
        grouped: dict[str, list[dict[str, Any]]] = {}
        for item in registry:
            grouped.setdefault(item["group"], []).append(
                {
                    "name": item["name"],
                    "title": item["title"],
                    "legacy_aliases": item["legacy_aliases"],
                    "tags": item["tags"],
                }
            )
        return {
            "server": "afm_server",
            "enabled_groups": enabled_groups,
            "tool_count": len(registry),
            "groups": grouped,
        }

    list_server_capabilities.__name__ = "list_server_capabilities"
    list_server_capabilities.__doc__ = "List the MCP server tool groups and registered tool names."
    return list_server_capabilities


def _register_tool(mcp: FastMCP, spec: ToolRegistration, registry: list[dict[str, Any]]) -> None:
    description = spec.description or _description_for(spec.fn)
    mcp.tool(
        spec.fn,
        name=spec.name,
        title=spec.title,
        description=description,
        tags=set(spec.tags),
        meta={"tool_group": spec.group, "canonical": True},
    )
    registry.append(
        {
            "name": spec.name,
            "group": spec.group,
            "title": spec.title,
            "tags": list(spec.tags),
            "legacy_aliases": list(spec.legacy_aliases),
        }
    )

    for alias in spec.legacy_aliases:
        mcp.tool(
            spec.fn,
            name=alias,
            title=f"{spec.title} (Legacy Alias)",
            description=description,
            tags=set(spec.tags) | {"legacy"},
            meta={"tool_group": spec.group, "canonical": False, "alias_for": spec.name},
        )


def create_mcp_server() -> FastMCP:
    mcp = FastMCP("afm_server")
    registry: list[dict[str, Any]] = []
    enabled_groups: list[str] = ["core"]

    for spec in _core_registrations():
        _register_tool(mcp, spec, registry)

    if tools_enabled("WAVEVI"):
        enabled_groups.append("wavevi")
        for spec in _wavevi_registrations():
            _register_tool(mcp, spec, registry)

    if tools_enabled("CYPHER"):
        enabled_groups.append("cypher")
        for spec in _cypher_registrations():
            _register_tool(mcp, spec, registry)

    if tools_enabled("WAVEGENERATOR"):
        enabled_groups.append("wavegen")
        for spec in _wavegen_registrations():
            _register_tool(mcp, spec, registry)

    capabilities_tool = _build_capabilities_tool(registry, enabled_groups)
    mcp.tool(
        capabilities_tool,
        name="list_server_capabilities",
        title="List Server Capabilities",
        description="List enabled MCP tool groups and registered canonical tool names.",
        tags={"core", "introspection"},
        meta={"tool_group": "core", "canonical": True},
    )

    return mcp
