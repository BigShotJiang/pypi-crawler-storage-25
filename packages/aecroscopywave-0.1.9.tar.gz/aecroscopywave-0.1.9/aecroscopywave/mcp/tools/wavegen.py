"""Waveform generation MCP tools."""

from __future__ import annotations


def get_tools():
    from aecroscopywave.wavebuilding.WaveGenerator import (
        chirp_wave,
        composite_wave,
        forc,
        forc_modulated_pulse,
        square_pulse,
        square_wave,
        triangular,
        triangular_modulated_pulse,
    )
    from aecroscopywave.wavebuilding.utils import (
        compute_waveform_duration,
        embed_waveforms,
        timebase,
    )

    return (
        square_wave,
        square_pulse,
        chirp_wave,
        composite_wave,
        triangular,
        triangular_modulated_pulse,
        forc,
        forc_modulated_pulse,
        timebase,
        compute_waveform_duration,
        embed_waveforms,
    )
