"""WaveVI-backed MCP tools."""

from __future__ import annotations

from typing import List, Optional

from ..state import require_vi_instance


def wait_for_vi_flag(flag_name: str, poll_interval: float = 0.001, timeout: float = 10.0) -> str:
    return require_vi_instance().wait_for_vi_flag(flag_name, poll_interval, timeout)


def get_IO_settings() -> dict:
    return require_vi_instance().get_IO_settings()


def get_IO_parameters() -> dict:
    return require_vi_instance().get_IO_parameters()


def set_IO_settings(IO_setting_dict: Optional[dict] = None) -> str:
    return require_vi_instance().set_IO_settings(IO_setting_dict=IO_setting_dict)


def set_AO_waveforms(waveform: List[float], zero_tail: bool = False, timeout: float = 5.0) -> str:
    return require_vi_instance().set_AO_waveforms(waveform=waveform, zero_tail=zero_tail)


def get_AO_waveforms() -> List[float]:
    return require_vi_instance().get_AO_waveforms()


def get_AO_waveforms_duration() -> float:
    return require_vi_instance().get_AO_waveforms_duration()


def get_AI_waveforms() -> List[float]:
    return require_vi_instance().get_AI_waveforms()


def upload_to_6124(timeout: float = 10.0) -> str:
    return require_vi_instance().upload_to_6124()


def clear_6124(timeout: float = 10.0) -> str:
    return require_vi_instance().clear_6124(timeout=timeout)


def run_6124_IO_10(timeout: Optional[float] = None) -> str:
    return require_vi_instance().run_6124_IO_10(timeout=timeout)


def set_IO_control(
    clear: bool = True,
    upload: bool = True,
    do_IO: bool = True,
    fetch_result: bool = True,
    timeout: float = 10.0,
) -> List[float] | str:
    return require_vi_instance().set_IO_control(
        clear=clear,
        upload=upload,
        do_IO=do_IO,
        fetch_result=fetch_result,
        timeout=timeout,
    )


TOOLS = (
    wait_for_vi_flag,
    get_IO_settings,
    get_IO_parameters,
    set_IO_settings,
    set_AO_waveforms,
    get_AO_waveforms,
    get_AO_waveforms_duration,
    get_AI_waveforms,
    upload_to_6124,
    clear_6124,
    run_6124_IO_10,
    set_IO_control,
)
