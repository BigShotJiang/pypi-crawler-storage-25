"""Cypher-backed MCP tools."""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

from ..state import require_afm_instance


def Execute(command: str) -> str:
    return require_afm_instance().Execute(command=command)


def PV(parameters: Optional[Dict[str, Any]] = None) -> str:
    return require_afm_instance().PV(parameters=parameters)


def ARExecuteControl(
    control_name: str,
    graph_name: str,
    var_num: int | float = 0,
    var_str: str = "",
) -> str:
    return require_afm_instance().ARExecuteControl(
        control_name=control_name,
        graph_name=graph_name,
        var_num=var_num,
        var_str=var_str,
    )


def set_Master_Panel(
    imaging_mode: str = "PFM Mode",
    scan_mode: str = "One Frame Mode",
    parameters: Optional[Dict[str, float]] = None,
    do_scan: Optional[str] = None,
) -> str:
    return require_afm_instance().set_Master_Panel(
        imaging_mode=imaging_mode,
        scan_mode=scan_mode,
        parameters=parameters,
        do_scan=do_scan,
    )


def set_CrosspointPanel(channel_settings: Optional[Dict[str, str]] = None, lock: bool = True) -> str:
    return require_afm_instance().set_CrosspointPanel(
        channel_settings=channel_settings,
        lock=lock,
    )


def doIV() -> str:
    return require_afm_instance().doIV()


def get_MasterVariables() -> dict:
    return require_afm_instance().get_MasterVariables()


def is_scanning() -> bool:
    return require_afm_instance().is_scanning()


def engage() -> str:
    return require_afm_instance().engage()


def withdraw() -> str:
    return require_afm_instance().withdraw()


def pixel_to_xy(pixel_coordinates: Tuple[int, int]) -> Tuple[float, float]:
    return require_afm_instance().pixel_to_xy(pixel_coordinates=pixel_coordinates)


def xy_to_voltage(xy_coordinates: Tuple[float, float]) -> Tuple[float, float]:
    return require_afm_instance().xy_to_voltage(xy_coordinates=xy_coordinates)


def pixel_to_voltage(pixel_coordinates: Tuple[int, int]) -> Tuple[float, float]:
    return require_afm_instance().pixel_to_voltage(pixel_coordinates=pixel_coordinates)


def initialize_move_tip() -> str:
    return require_afm_instance().initialize_move_tip()


def move_tip(pixel_coordinates: Tuple[int, int], transit_time: float = 0.3) -> str:
    return require_afm_instance().move_tip(
        pixel_coordinates=pixel_coordinates,
        transit_time=transit_time,
    )


TOOLS = (
    Execute,
    PV,
    ARExecuteControl,
    set_Master_Panel,
    set_CrosspointPanel,
    doIV,
    get_MasterVariables,
    is_scanning,
    engage,
    withdraw,
    pixel_to_xy,
    xy_to_voltage,
    pixel_to_voltage,
    initialize_move_tip,
    move_tip,
)
