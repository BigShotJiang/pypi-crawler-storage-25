"""Tool groups used by the MCP server."""
