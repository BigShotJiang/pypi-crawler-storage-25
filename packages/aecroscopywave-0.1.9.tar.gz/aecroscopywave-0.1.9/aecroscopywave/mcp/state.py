"""Shared instrument configuration and per-thread COM-backed state."""

from __future__ import annotations

import threading
from typing import Optional

from ..com import ensure_com_initialized

DEFAULT_VI_PATH = (
    r"C:\Users\Asylum Research\Desktop\PyScanner_FPGA_6124_01"
    r"\PyScanner_FPGA_6124_01.exe"
)

DEFAULT_AFM_PATH = r"C:\AsylumResearch\v21\Igor Pro Folder\Igor.exe"

_instrument_state = threading.local()

_afm_path = DEFAULT_AFM_PATH
_vi_path = DEFAULT_VI_PATH


def _thread_afm_instance():
    return getattr(_instrument_state, "pycy", None)


def _thread_vi_instance():
    return getattr(_instrument_state, "pyvi", None)


def set_afm_instance(afm_path: Optional[str] = None):
    """Configure the AFM path and create a controller for the current thread."""
    global _afm_path
    from aecroscopywave.interfaces import Cypher

    if afm_path is not None:
        _afm_path = afm_path

    ensure_com_initialized()
    _instrument_state.pycy = Cypher.PyCypher(afm_path=_afm_path)
    return _instrument_state.pycy


def set_vi_instance(vi_path: Optional[str] = None):
    """Configure the VI path and create a controller for the current thread."""
    global _vi_path
    from aecroscopywave.interfaces import WaveVI

    if vi_path is not None:
        _vi_path = vi_path

    ensure_com_initialized()
    _instrument_state.pyvi = WaveVI.PyWaveVI(app_path=_vi_path)
    return _instrument_state.pyvi


def require_afm_instance():
    """Return a thread-local AFM controller, creating it if needed."""
    ensure_com_initialized()

    instance = _thread_afm_instance()
    if instance is None:
        instance = set_afm_instance()
    return instance


def require_vi_instance():
    """Return a thread-local VI controller, creating it if needed."""
    ensure_com_initialized()

    instance = _thread_vi_instance()
    if instance is None:
        instance = set_vi_instance()
    return instance
