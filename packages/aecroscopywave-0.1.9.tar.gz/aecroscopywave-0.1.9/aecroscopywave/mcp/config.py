"""Configuration helpers for MCP tool registration."""

from __future__ import annotations

import os


def _env_flag(name: str) -> bool:
    value = os.getenv(name)
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def tools_enabled(group: str) -> bool:
    """Return True when a tool group should be registered."""
    normalized = group.upper()
    return not (
        _env_flag(f"DISENABLE_{normalized}_TOOLS")
        or _env_flag(f"DISABLE_{normalized}_TOOLS")
    )
