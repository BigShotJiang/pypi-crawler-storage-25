### Utility function for interfaces

import os, re
import numpy as np
from ..logger import log_function
from ..interfaces.utils import *

@log_function
def windows2igor(file_loc_windows):
    """
    Convert a Windows file path to Igor Pro file path format.
    
    Igor Pro uses colons (:) as path separators instead of backslashes (\),
    and paths must end with a colon.
    
    Parameters
    ----------
    file_loc_windows : str
        A Windows file path using backslashes as separators.
        Example: 'C:\\Users\\Documents\\data.txt'
    
    Returns
    -------
    str
        The path in Igor Pro format with colons as separators.
        Example: 'C:Users:Documents:data.txt:'
    
    Examples
    --------
    >>> windows2igor('C:\\Users\\Documents\\experiment.txt')
    'C:Users:Documents:experiment.txt:'
    
    >>> windows2igor('D:\\Data\\')
    'D:Data:'
    """
    # Replace all backslashes with colons
    file_loc = file_loc_windows.replace('\\', ':')
    
    # Ensure the path ends with a colon
    if not file_loc.endswith(':'):
        file_loc += ':'
    
    return file_loc

@log_function
def igor2windows(file_loc_igor):
    """
    Convert an Igor Pro file path to Windows format.
    
    Igor Pro uses colons (:) as path separators, while Windows uses
    backslashes (\). This function performs the reverse conversion of
    windows2igor().
    
    Parameters
    ----------
    file_loc_igor : str
        An Igor Pro file path using colons as separators.
        Example: 'C:Users:Documents:data.txt:'
    
    Returns
    -------
    str
        The path in Windows format with backslashes as separators.
        Example: 'C:\\Users\\Documents\\data.txt'
    
    Examples
    --------
    >>> igor2windows('C:Users:Documents:experiment.txt:')
    'C:\\Users\\Documents\\experiment.txt'
    
    >>> igor2windows('D:Data:')
    'D:\\Data'
    """
    # Remove trailing colon if present
    file_loc_igor = file_loc_igor.rstrip(':')
    # Split at first colon to separate drive letter
    parts = file_loc_igor.split(':', 1)
    
    if len(parts) == 1:
        # No colon found, return as-is
        return file_loc_igor
    
    drive_letter = parts[0]
    remaining_path = parts[1]
    # Replace colons with backslashes in the remaining path
    remaining_path = remaining_path.replace(':', '\\')
    # Reconstruct Windows path
    windows_path = f'{drive_letter}:\\{remaining_path}'
    return windows_path

@log_function
def get_next_filename(base_name='Image', directory='.', filetype='.ibw'):
    """
    Generate the next available filename with a 4-digit zero-padded suffix.
    
    Scans the directory for all files starting with base_name followed by
    exactly 4 digits, finds the highest index, and returns the next filename
    with an incremented suffix.
    
    Parameters
    ----------
    base_name : str, optional
        The base filename without extension or number.
        Default is 'Image'.
    directory : str, optional
        The directory to search for existing files.
        Can be absolute or relative path. Default is current directory '.'.
    filetype : str, optional
        The file extension to use for the new filename.
        Should include the dot. Default is '.ibw'.
    
    Returns
    -------
    str
        The next available filename (not full path) with 4-digit zero-padded suffix.
        Example: 'Image0006.ibw'
    
    Examples
    --------
    >>> # Directory contains: Image0001.ibw, Image0002.ibw, Image0005.ibw
    >>> get_next_filename()
    'Image0006.ibw'
    >>> # Custom base name and file type
    >>> get_next_filename("Test", "C:\\Data", ".tif")
    'Test0006.tif'
    >>> # Directory is empty or no matching files
    >>> get_next_filename("Experiment")
    'Experiment0000.ibw'
    
    Notes
    -----
    - The suffix is always exactly 4 digits (0000-9999)
    - Searches across all file extensions to find the highest index
    - Returns only the filename, not the full path
    """
    # Validate inputs
    if not os.path.isdir(directory):
        raise FileNotFoundError(f"Directory not found: {directory}")
    if not filetype.startswith('.'):
        raise ValueError(f"File type must start with '.', got: {filetype}")
    
    # Pattern matches: base_name + exactly 4 digits + any extension
    pattern = re.compile(rf"^{re.escape(base_name)}(\d{{4}})\..+$")
    max_index = -1
    for filename in os.listdir(directory):
        match = pattern.match(filename)
        if match:
            index = int(match.group(1))
            max_index = max(max_index, index)

    # Next index (starts at 0000 if no files found)
    next_index = max_index + 1
    next_filename = f"{base_name}{next_index:04d}{filetype}"
    # Return only the filename (not full path)
    return next_filename

@log_function
def to_uint8_grayscale(img):
    """
    Convert image to 8-bit grayscale with contrast stretching.
    
    Converts color or grayscale images to uint8 format with automatic
    contrast adjustment using percentile-based normalization. This enhances
    contrast by stretching the 1st-99th percentile range to 0-255.
    
    Parameters
    ----------
    img : list or tuple
        Input image. 
    
    Returns
    -------
    list
        Grayscale image as uint8 (0-255 range), shape (height, width)
    
    Examples
    --------
    >>> gray = to_uint8_grayscale(color_img)
    >>> print(gray.dtype)
    uint8
    """
    arr = np.asarray(img) #Convert to numpy array 
    
    # Convert color to grayscale if needed (3D -> 2D)
    if arr.ndim == 3:
        arr = arr.mean(axis=-1)  
    # Calculate percentiles for contrast stretching
    p1, p99 = np.percentile(arr, [1, 99]) # Use 1st and 99th percentiles to ignore outliers
    
    if p99 <= p1: # Handle edge case: constant or near-constant image
        p1, p99 = float(arr.min()), float(arr.max()) # Fall back to actual min/max
    # Normalize to [0, 1] range with contrast stretching
    range_val = max(p99 - p1, 1e-6)  # Avoid division by zero
    normalized = (arr.astype(np.float32) - p1) / range_val
    # Clip to [0, 1] to handle values outside percentile range
    normalized = np.clip(normalized, 0, 1)
    
    # Scale to [0, 255] and convert to uint8. Add 0.5 for proper rounding (e.g., 127.6 -> 128)
    uint8_image = (normalized * 255.0 + 0.5).astype(np.uint8)
    
    return uint8_image

@log_function
def smooth_signal(signal, window_size=5):
    """
    Smooth signal using moving average.
    
    Parameters
    ----------
    signal : list
        Input signal as list
    window_size : int, optional
        Moving average window size. Default is 5.
    
    Returns
    -------
    list
        Smoothed signal (trimmed to remove edge effects). Output length is reduced by 2*window_size due to edge trimming
    
    Examples
    --------
    >>> # Smooth noisy data
    >>> noisy = [1.2, 2.5, 1.8, 3.1, 2.9, 4.2, 3.5]
    >>> smooth = smooth_signal(noisy, window_size=3)
    >>> print(smooth)
    [1.83, 2.47, 2.60, 3.40]
    """  
    # Convert input to numpy array for processing
    signal_array = np.array(signal)
    # Apply moving average
    smoothed = np.convolve(signal_array, np.ones(window_size) / window_size, mode='same')
    # Trim edges to remove boundary effects
    smoothed_trimmed = smoothed[window_size:-window_size]
    # Convert back to list
    return smoothed_trimmed.tolist()