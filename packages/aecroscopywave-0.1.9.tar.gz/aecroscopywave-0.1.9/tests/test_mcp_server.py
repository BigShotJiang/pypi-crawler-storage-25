from __future__ import annotations

from aecroscopywave.afm_mcp_server import square_wave
from aecroscopywave.mcp.server import create_mcp_server


def _tool_components():
    mcp = create_mcp_server()
    return getattr(mcp.local_provider, "_components", {})


def test_server_registers_canonical_and_legacy_tool_names():
    components = _tool_components()

    assert "tool:cypher_move_tip@" in components
    assert "tool:move_tip@" in components
    assert "tool:wavevi_set_io_settings@" in components
    assert "tool:set_IO_settings@" in components
    assert "tool:wavegen_square_wave@" in components
    assert "tool:square_wave@" in components


def test_server_registers_capabilities_tool_with_grouped_output():
    components = _tool_components()
    capabilities_tool = components["tool:list_server_capabilities@"]

    result = capabilities_tool.fn()

    assert result["server"] == "afm_server"
    assert set(result["enabled_groups"]) == {"core", "cypher", "wavegen", "wavevi"}
    assert result["tool_count"] == 40
    assert set(result["groups"]) == {"core", "cypher", "wavegen", "wavevi"}
    assert any(item["name"] == "cypher_move_tip" for item in result["groups"]["cypher"])
    assert any(
        item["legacy_aliases"] == ["square_wave"]
        for item in result["groups"]["wavegen"]
        if item["name"] == "wavegen_square_wave"
    )


def test_compatibility_module_exposes_lazy_exports():
    assert callable(square_wave)
