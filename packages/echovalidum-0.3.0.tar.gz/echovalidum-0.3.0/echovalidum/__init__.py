"""
Echovalidum — *the echo, validated.*

A Python library for lattice-based memory with kernel-checked
attestations for the Sabelfeld-Sands four-channel iteration-count
non-interference model.

This package is the clean Python-library facade for the underlying
``soilith_*`` modules. It does not change any behaviour — every
function and type re-exported here is the same object exposed
under the historical ``soilith_*`` module names. The package
exists so that downstream code can write::

    import echovalidum as ev

    cell  = ev.Cell(value=x, trust=0.95, phase=0.0)
    rep   = ev.iteration_count_ni_check(...)
    proof = ev.verify_loop_bound_ni(...)
    sig   = ev.sign_with_pqc(proof)

instead of pulling each loose module by its historical name.

Submodules
----------
* :mod:`echovalidum.memory`   — ``Cell``, ``Arena``, ``SparseScaleMemory``, ``Memory64``, ``Capability``.
* :mod:`echovalidum.phi`      — ``PHI`` dict of operators (φ_0..φ_60).
* :mod:`echovalidum.ifc`      — ``Label``, ``LabeledStore``, ``noninterference_check``, ``declassify``.
* :mod:`echovalidum.loops`    — Zone-154 loop-form NI: ``LoopForm``, ``SSChannel``, ``discharge_loop_form_ni``.
* :mod:`echovalidum.verify`   — Zone-151 Z3 + PQC pipeline: ``verify_cayley_disjoint``, ``verify_loop_bound_ni`` etc.
* :mod:`echovalidum.catalog`  — discovery catalog: ``scan_arena``, ``build_manifest``.

Top-level headline re-exports
-----------------------------
The most-used names are also bound at the top level for one-line use::

    ev.Cell, ev.TOP, ev.BOT
    ev.iteration_count_ni_check
    ev.discharge_loop_form_ni
    ev.verify_cayley_disjoint
    ev.verify_loop_bound_ni / verify_outer_schedule_ni /
       verify_touch_pattern_ni / verify_iteration_bound
    ev.sign_with_pqc
"""

from __future__ import annotations

import sys
from pathlib import Path

# Put the legacy module directory on the import path so the
# underscore-prefixed ``soilith_*`` modules are findable both when
# this package is installed editable (``pip install -e .``) and
# when it is imported directly from a checkout.
_LEGACY_ROOT = Path(__file__).resolve().parent.parent
if str(_LEGACY_ROOT) not in sys.path:
    sys.path.insert(0, str(_LEGACY_ROOT))

# Subsystem submodules (thin re-exports each).
from echovalidum import (  # noqa: E402,F401
    memory, phi, ifc, loops, verify, catalog,
)

# Headline re-exports at top level.
from echovalidum.memory import (  # noqa: E402,F401
    Cell, BOT, TOP, Arena,
    SparseScaleMemory, Memory64, Capability,
    TrustError, QuorumError,
)
from echovalidum.loops import (  # noqa: E402,F401
    LoopForm, IFCVerdict, SSChannel,
    LoopNIReport,
    classify_loop_form, channel_of,
    iteration_count_ni_check, discharge_loop_form_ni,
)
from echovalidum.verify import (  # noqa: E402,F401
    Z3VerifyResult,
    verify_cayley_disjoint, verify_frame_disjoint, verify_ai_sound,
    verify_loop_bound_ni, verify_outer_schedule_ni,
    verify_touch_pattern_ni, verify_iteration_bound,
    sign_with_pqc,
    SSChannelBundle, sign_ss_bundle,
)
from echovalidum.ifc import (  # noqa: E402,F401
    Label, LabeledStore,
    noninterference_check, declassify,
)
from soilith_qif import (  # noqa: E402,F401
    LeakageReport, QIFError, GainFunction,
    qif_from_traces, qif_for_loop_form, composition_bound,
    verify_qif_leak_bounded, verify_g_leak_bounded, certify_leak_bound,
    gain_identity, gain_prefix, gain_high_bits, gain_in_set,
)

__version__ = "0.3.0"

__all__ = [
    # Subsystem modules
    "memory", "phi", "ifc", "loops", "verify", "catalog",
    # Memory / core
    "Cell", "BOT", "TOP", "Arena",
    "SparseScaleMemory", "Memory64", "Capability",
    "TrustError", "QuorumError",
    # Loops / Zone 154
    "LoopForm", "IFCVerdict", "SSChannel", "LoopNIReport",
    "classify_loop_form", "channel_of",
    "iteration_count_ni_check", "discharge_loop_form_ni",
    # Verify / Zone 151
    "Z3VerifyResult",
    "verify_cayley_disjoint", "verify_frame_disjoint",
    "verify_ai_sound", "verify_loop_bound_ni",
    "verify_outer_schedule_ni", "verify_touch_pattern_ni",
    "verify_iteration_bound", "sign_with_pqc",
    "SSChannelBundle", "sign_ss_bundle",
    # IFC / Zone 138
    "Label", "LabeledStore",
    "noninterference_check", "declassify",
    # QIF / Department 11 quantitative extension
    "LeakageReport", "QIFError", "GainFunction",
    "qif_from_traces", "qif_for_loop_form", "composition_bound",
    "verify_qif_leak_bounded", "verify_g_leak_bounded",
    "certify_leak_bound",
    "gain_identity", "gain_prefix", "gain_high_bits", "gain_in_set",
]
