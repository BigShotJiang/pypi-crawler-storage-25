"""echovalidum.verify — Zone-151 Z3 + PQC verification pipeline.

Re-exports from ``soilith_z3verify``. Three classical judgments
(Cayley-disjoint borrows, frame-rule disjointness, AI soundness)
plus the four Sabelfeld-Sands iteration-count channels added in
Zone 154 × Zone 151. Every successful UNSAT can be wrapped by
``sign_with_pqc`` into an MVPS-compatible
``SignedCertificationResult`` attestation.
"""

from __future__ import annotations

from soilith_z3verify import (  # noqa: F401
    Z3VerifyResult, Z3VerifyError,
    verify_cayley_disjoint, verify_frame_disjoint, verify_ai_sound,
    verify_loop_bound_ni, verify_outer_schedule_ni,
    verify_touch_pattern_ni, verify_iteration_bound,
    sign_with_pqc, persist,
    SSChannelBundle, sign_ss_bundle,
)

__all__ = [
    "Z3VerifyResult", "Z3VerifyError",
    "verify_cayley_disjoint", "verify_frame_disjoint",
    "verify_ai_sound",
    "verify_loop_bound_ni", "verify_outer_schedule_ni",
    "verify_touch_pattern_ni", "verify_iteration_bound",
    "sign_with_pqc", "persist",
    "SSChannelBundle", "sign_ss_bundle",
]
