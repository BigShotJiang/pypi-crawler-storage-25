"""
soilith_qif.py — Quantitative Information Flow (Department 11 extension).

The existing IFC stack (Zone 138 + Zone 154 + the Sabelfeld–Sands four-
channel verifier in ``soilith_loop_ifc.py``) answers a *boolean*
question: does HIGH influence a LOW-observable channel? That is the
right gate for "ship / don't ship", but it loses information when the
influence is small. ``soilith_qif`` upgrades the gate to a *number*:

    "HIGH influences this channel by at most B bits per observation."

Empirical → symbolic → attested
-------------------------------
The module exposes three layers, following the same pattern used by
every other empirical analyser in the codebase:

  1. ``qif_from_traces`` / ``qif_for_loop_form`` — *empirical*
     estimators. Compute min-entropy and Shannon leakage from a
     finite sweep of secrets.

  2. ``verify_qif_leak_bounded`` — *symbolic*. Re-encodes the
     deterministic sample as an SMT-LIB ∃-query and asks Z3 to
     prove ``L_∞ ≤ B`` (equivalently, that no ``⌊2^B⌋ + 1`` distinct
     observations exist). Returns a ``Z3VerifyResult`` that the
     existing ``sign_with_pqc`` pipeline accepts directly.

  3. ``persist`` — *attested*. Both kinds of evidence land in the
     same ``qif/`` and ``z3verify/qif_leak_bounded/`` arena slots
     on the trust-coherence lattice.

Background
----------
We use the **min-entropy / Smith** formulation of QIF (Smith, 2009,
*On the Foundations of Quantitative Information Flow*). Given a finite
set of secrets ``S`` with prior ``π`` and an observation function
``obs : S → O`` (possibly noisy), define:

    Vulnerability     V(S)      = max_s π(s)
    Posterior vuln.   V(S | O)  = Σ_o P(o) · max_s P(s | o)
    Min-entropy       H_∞(S)    = -log₂ V(S)
    Cond. min-entropy H_∞(S|O)  = -log₂ V(S|O)
    ML-leakage        L_∞(S→O)  = H_∞(S) - H_∞(S|O)
                                = log₂( V(S|O) / V(S) )

For a uniform prior over ``n`` secrets and a *deterministic* ``obs``,

    L_∞ = log₂ |range(obs)|       ≤ log₂ n,

so the leakage in bits is exactly ``log₂(distinct observations)``.
That is the headline number this module reports.

We also report the **Shannon mutual information** ``I(S; O)``. For
deterministic obs and uniform secrets it equals ``H(O)``. We compute
both because they answer subtly different threats (one-shot guess vs
asymptotic decoding); a sound budget should bound the larger of the
two.

For ``K`` adaptive queries the standard composition bound is

    L_∞^K  ≤  K · L_∞^1

(no amplification beyond the linear rate); ``composition_bound``
exposes that in one line so callers can size a per-query budget for
a known query budget.

Outputs and persistence
-----------------------
``LeakageReport`` is a plain dataclass; ``persist`` writes a 6-float
payload ``[n_secrets, repeats, distinct_obs, min_entropy_leak_bits,
shannon_leak_bits, exceeded_budget]`` into the arena slot
``qif/<program_name>``. Trust grade is ``1.0`` if the report stays
within the supplied budget, ``0.0`` otherwise — same convention as
``soilith_loop_ifc.persist``.

CLI
---
    python soilith_qif.py --demo
    python soilith_qif.py --demo --budget 0.5
"""

from __future__ import annotations

import argparse
import math
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Hashable, Iterable, Sequence

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class QIFError(ValueError):
    """Raised when a QIF measurement is ill-formed (empty secret set,
    inconsistent repeats, etc.)."""


# ──────────────────────────────────────────────────────────────────────────
#  Report
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class LeakageReport:
    """A single quantitative leakage measurement.

    All entropies are in **bits** (log base 2)."""

    program_name: str
    n_secrets: int
    repeats: int
    distinct_observations: int

    min_entropy_prior: float           # H_∞(S)
    min_entropy_posterior: float       # H_∞(S | O)
    min_entropy_leak_bits: float       # L_∞ = prior - posterior

    shannon_entropy_obs: float         # H(O)
    shannon_cond_entropy: float        # H(O | S)
    shannon_leak_bits: float           # I(S; O) = H(O) - H(O | S)

    budget_bits: float | None = None
    deterministic: bool = True
    confusion: dict[tuple[Any, Any], int] = field(default_factory=dict)
    witness_pair: tuple[Any, Any] | None = None

    # ── Optional g-leakage (Alvim/Chatzikokolakis/Palamidessi/Smith) ──
    # Populated only when ``qif_from_traces`` is called with a gain
    # function. For 1-bounded ``g`` we have ``L_g ≤ L_∞``, so this is
    # a *tighter* bound for a more restricted attacker. Recovers
    # ``min_entropy_leak_bits`` exactly when ``gain == gain_identity()``.
    g_leak_bits: float | None = None
    g_v_prior: float | None = None
    g_v_posterior: float | None = None
    gain_function_name: str | None = None

    @property
    def headline_leak_bits(self) -> float:
        """The conservative leak: max of min-entropy, Shannon, and
        (if computed) g-leakage. For 1-bounded gains the g-leakage
        is always ≤ min-entropy, so the max is unchanged in that
        case; for unbounded gains the explicit max protects the
        budget gate."""
        out = max(self.min_entropy_leak_bits, self.shannon_leak_bits)
        if self.g_leak_bits is not None:
            out = max(out, self.g_leak_bits)
        return out

    @property
    def safe(self) -> bool:
        """Within budget? If no budget was set, ``safe`` requires
        zero leakage."""
        if self.budget_bits is None:
            return self.headline_leak_bits == 0.0
        return self.headline_leak_bits <= self.budget_bits + 1e-12

    def describe(self) -> str:
        ok = "✓" if self.safe else "✗"
        budget = (
            f"≤ {self.budget_bits:.3f}b"
            if self.budget_bits is not None else "no budget"
        )
        out = [
            f"LeakageReport {ok}  program={self.program_name}",
            f"  n_secrets       : {self.n_secrets}",
            f"  repeats         : {self.repeats}",
            f"  distinct obs    : {self.distinct_observations}",
            f"  H_∞(S)          : {self.min_entropy_prior:.4f}b",
            f"  H_∞(S|O)        : {self.min_entropy_posterior:.4f}b",
            f"  min-entropy leak: {self.min_entropy_leak_bits:.4f}b",
            f"  H(O)            : {self.shannon_entropy_obs:.4f}b",
            f"  I(S; O)         : {self.shannon_leak_bits:.4f}b",
        ]
        if self.g_leak_bits is not None:
            out.append(
                f"  L_g  ({self.gain_function_name or 'g'})"
                f"{' ' * max(0, 12 - len(self.gain_function_name or 'g'))}"
                f": {self.g_leak_bits:.4f}b  "
                f"V_prior={self.g_v_prior:.4f}  "
                f"V_post={self.g_v_posterior:.4f}"
            )
        out.append(
            f"  headline        : {self.headline_leak_bits:.4f}b "
            f"({budget})"
        )
        if self.witness_pair is not None:
            out.append(
                f"  witness pair    : {self.witness_pair[0]!r} → "
                f"distinct obs from {self.witness_pair[1]!r}"
            )
        return "\n".join(out)


# ──────────────────────────────────────────────────────────────────────────
#  Gain functions for g-leakage (Alvim/Chatzikokolakis/Palamidessi/Smith,
#  CSF 2012). Every gain function in this section is 1-bounded
#  (0 ≤ g ≤ 1) so the headline-leakage invariant ``L_g ≤ L_∞`` holds.
# ──────────────────────────────────────────────────────────────────────────
GainFunction = Callable[[Any, Any], float]


def gain_identity() -> GainFunction:
    """Smith's identity gain: 1 iff the guess equals the secret.

    Recovers min-entropy leakage exactly when ``guesses == secrets``.
    Use this as a sanity check / reduction to ``L_∞``."""
    def g(w: Any, s: Any) -> float:
        return 1.0 if w == s else 0.0
    return g


def gain_prefix(k_chars: int) -> GainFunction:
    """Reward guessing the first ``k_chars`` characters of
    ``str(secret)``. Models a partial-credit attacker who only
    needs the prefix (e.g. the first byte of a key)."""
    def g(w: Any, s: Any) -> float:
        return 1.0 if str(w)[:k_chars] == str(s)[:k_chars] else 0.0
    return g


def gain_high_bits(k_high: int, total_bits: int) -> GainFunction:
    """Reward guessing the top ``k_high`` of ``total_bits``-bit
    integer secrets. The guess ``w`` is the value of those top
    ``k_high`` bits directly — an integer in ``[0, 2^k_high)``.

    Use with ``guesses=list(range(2 ** k_high))``. Models an
    attacker who only cares about the high-order bits (common for
    cryptographic key-recovery threat models)."""
    shift = max(0, total_bits - k_high)

    def g(w: Any, s: Any) -> float:
        return 1.0 if int(w) == (int(s) >> shift) else 0.0
    return g


def gain_in_set(target_set: Iterable[Hashable]) -> GainFunction:
    """Binary distinguishing attack: guesses are booleans, the
    attacker wins iff the boolean correctly classifies whether
    the secret is in ``target_set``.

    Use this with ``guesses=[True, False]`` to measure exactly
    how much the channel reveals about *membership* in the set
    (vs. revealing the whole secret)."""
    target = frozenset(target_set)

    def g(w: Any, s: Any) -> float:
        return 1.0 if bool(w) == (s in target) else 0.0
    return g


def _compute_g_leakage(
    joint: dict[tuple[Hashable, Hashable], int],
    *,
    secrets_list: Sequence[Hashable],
    repeats: int,
    gain: GainFunction,
    guesses: Sequence[Hashable],
) -> tuple[float, float, float]:
    """Empirical g-leakage from the joint count table.

    Returns ``(V_g(π), V_g(π|O), L_g_bits)``. For deterministic
    obs ``joint[(s, o)] ∈ {0, repeats}`` and the result agrees with
    the closed form ``V_g(π|O) = (1/n) · Σ_o max_w Σ_{s∈S_o} g(w, s)``.
    """
    n = len(secrets_list)
    total = n * repeats
    if total == 0 or not guesses:
        return 0.0, 0.0, 0.0

    v_prior = max(
        sum(gain(w, s) for s in secrets_list) / n
        for w in guesses
    )

    obs_set: set[Hashable] = {o for (_s, o) in joint.keys()}
    v_post = 0.0
    for o in obs_set:
        v_post += max(
            sum(joint.get((s, o), 0) * gain(w, s)
                for s in secrets_list) / total
            for w in guesses
        )

    if v_prior <= 0.0:
        return v_prior, v_post, 0.0
    leak = max(0.0, math.log2(v_post / v_prior))
    return v_prior, v_post, leak


# ──────────────────────────────────────────────────────────────────────────
#  Empirical estimator
# ──────────────────────────────────────────────────────────────────────────
def qif_from_traces(
    secrets: Sequence[Hashable],
    observation_fn: Callable[[Hashable], Hashable],
    *,
    repeats: int = 1,
    name: str = "<gadget>",
    budget_bits: float | None = None,
    gain: GainFunction | None = None,
    guesses: Sequence[Hashable] | None = None,
    gain_name: str = "g",
) -> LeakageReport:
    """Estimate Smith min-entropy and Shannon leakage of
    ``observation_fn`` against the uniform prior on ``secrets``.

    For each candidate secret ``s`` we call ``observation_fn(s)``
    exactly ``repeats`` times. Observations must be hashable; for
    timing channels round to a fixed bucket size before passing them
    in (e.g. floor to nearest microsecond).

    Returns a :class:`LeakageReport`. Set ``budget_bits`` to make the
    report's ``safe`` flag enforce a numeric ceiling.

    Optional g-leakage (Alvim et al. CSF 2012)
    ------------------------------------------
    Pass a ``gain`` function ``g : W × S → [0, 1]`` and, optionally,
    a list of ``guesses`` (defaults to ``secrets``). The report
    additionally carries ``g_leak_bits``, ``g_v_prior``,
    ``g_v_posterior``. For ``gain == gain_identity()`` the result
    recovers ``min_entropy_leak_bits`` exactly; for restricted gains
    (e.g. ``gain_high_bits(2, 8)``) the value is the *tighter*
    leakage bound under that attacker's threat model.
    """
    if not secrets:
        raise QIFError("qif_from_traces requires at least one secret")
    if repeats < 1:
        raise QIFError("repeats must be >= 1")

    secrets_list = list(secrets)
    n = len(secrets_list)

    joint: dict[tuple[Hashable, Hashable], int] = defaultdict(int)
    obs_per_secret: dict[Hashable, set[Hashable]] = defaultdict(set)

    for s in secrets_list:
        for _ in range(repeats):
            o = observation_fn(s)
            joint[(s, o)] += 1
            obs_per_secret[s].add(o)

    total = n * repeats
    obs_total: dict[Hashable, int] = defaultdict(int)
    for (s, o), c in joint.items():
        obs_total[o] += c

    distinct = len(obs_total)
    deterministic = all(len(obs_per_secret[s]) <= 1 for s in secrets_list)

    h_min_prior = math.log2(n) if n > 1 else 0.0

    v_post = 0.0
    for o, ot in obs_total.items():
        candidates = [
            joint[(s, o)] / ot for s in secrets_list
            if joint.get((s, o), 0) > 0
        ]
        if candidates:
            v_post += (ot / total) * max(candidates)
    h_min_post = -math.log2(v_post) if v_post > 0 else float("inf")
    if math.isfinite(h_min_post):
        h_min_post = max(0.0, h_min_post)
    leak_min = max(0.0, h_min_prior - (
        h_min_post if math.isfinite(h_min_post) else h_min_prior
    ))

    h_o = 0.0
    for ot in obs_total.values():
        p = ot / total
        if p > 0:
            h_o -= p * math.log2(p)

    h_o_given_s = 0.0
    for s in secrets_list:
        h_o_s = 0.0
        for o in obs_per_secret[s]:
            p_o_given_s = joint[(s, o)] / repeats
            if p_o_given_s > 0:
                h_o_s -= p_o_given_s * math.log2(p_o_given_s)
        h_o_given_s += (1.0 / n) * h_o_s
    leak_shannon = max(0.0, h_o - h_o_given_s)

    witness: tuple[Any, Any] | None = None
    if deterministic and distinct >= 2:
        first_seen: dict[Hashable, Hashable] = {}
        for s in secrets_list:
            o = next(iter(obs_per_secret[s]))
            if o in first_seen:
                continue
            first_seen[o] = s
        if len(first_seen) >= 2:
            xs = list(first_seen.values())
            witness = (xs[0], xs[1])

    g_leak_bits: float | None = None
    g_v_prior: float | None = None
    g_v_post: float | None = None
    gain_name_out: str | None = None
    if gain is not None:
        guesses_list = (
            list(guesses) if guesses is not None else list(secrets_list)
        )
        g_v_prior, g_v_post, g_leak_bits = _compute_g_leakage(
            joint,
            secrets_list=secrets_list,
            repeats=repeats,
            gain=gain,
            guesses=guesses_list,
        )
        gain_name_out = gain_name

    return LeakageReport(
        program_name=name,
        n_secrets=n,
        repeats=repeats,
        distinct_observations=distinct,
        min_entropy_prior=h_min_prior,
        min_entropy_posterior=(
            h_min_post if math.isfinite(h_min_post) else h_min_prior
        ),
        min_entropy_leak_bits=leak_min,
        shannon_entropy_obs=h_o,
        shannon_cond_entropy=h_o_given_s,
        shannon_leak_bits=leak_shannon,
        budget_bits=budget_bits,
        deterministic=deterministic,
        confusion=dict(joint),
        witness_pair=witness,
        g_leak_bits=g_leak_bits,
        g_v_prior=g_v_prior,
        g_v_posterior=g_v_post,
        gain_function_name=gain_name_out,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Loop-form bridge — wires SS-channel observations into the analyser
# ──────────────────────────────────────────────────────────────────────────
def qif_for_loop_form(
    loop_factory: Callable[[dict[str, Any], dict[str, Any]], int],
    *,
    secrets: Sequence[dict[str, Any]],
    low_inputs: dict[str, Any],
    name: str = "<loop_qif>",
    repeats: int = 1,
    budget_bits: float | None = None,
) -> LeakageReport:
    """Quantify the iteration-count leakage of a loop factory.

    ``loop_factory`` follows the same contract as
    :func:`soilith_loop_ifc.iteration_count_ni_check` — given
    ``(high_dict, low_dict)`` it returns the iteration count it
    executed. We sweep ``secrets`` (each a candidate HIGH dict),
    observe the iteration count, and feed the resulting trace into
    :func:`qif_from_traces`.

    Use ``repeats > 1`` only when ``loop_factory`` is intentionally
    randomised (e.g. Form 6 / particle filter); for deterministic
    forms ``repeats=1`` already gives the exact distinct-count
    upper bound.
    """
    if not secrets:
        raise QIFError("qif_for_loop_form requires at least one secret variant")

    def _fresh_low() -> dict[str, Any]:
        out: dict[str, Any] = {}
        for k, v in low_inputs.items():
            if isinstance(v, Cell):
                out[k] = Cell(
                    value=np.asarray(v.value, dtype=float).copy(),
                    trust=v.trust, phase=v.phase,
                )
            elif isinstance(v, np.ndarray):
                out[k] = v.copy()
            else:
                out[k] = v
        return out

    def _obs(idx: int) -> int:
        high = dict(secrets[idx])
        return int(loop_factory(high, _fresh_low()))

    return qif_from_traces(
        secrets=range(len(secrets)),
        observation_fn=_obs,
        repeats=repeats,
        name=name,
        budget_bits=budget_bits,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Composition: K-query adaptive bound
# ──────────────────────────────────────────────────────────────────────────
def composition_bound(
    single_query: LeakageReport, *, n_queries: int,
) -> float:
    """Smith / Köpf–Basin linear composition bound: ``K`` adaptive
    queries leak at most ``K · L_∞`` bits of min-entropy.

    Returns the composed *headline* upper bound (max of min-entropy
    and Shannon). ``n_queries`` must be ≥ 1."""
    if n_queries < 1:
        raise QIFError("n_queries must be >= 1")
    return float(n_queries) * single_query.headline_leak_bits


# ──────────────────────────────────────────────────────────────────────────
#  Z3 escalation — machine-checked min-entropy leakage bound
# ──────────────────────────────────────────────────────────────────────────
def verify_qif_leak_bounded(
    secrets: Sequence[Hashable],
    observation_fn: Callable[[Hashable], Hashable],
    *,
    bound_bits: float,
    name: str = "qif_leak_bounded",
    samples_per_secret: int = 4,
) -> "Any":
    """Prove via Z3 that the Smith min-entropy leakage of
    ``observation_fn`` on the uniform prior over ``secrets`` is at
    most ``bound_bits``.

    For a deterministic observation and uniform prior,

        L_∞(S → O) = log₂ |range(obs)|       ⇒
        L_∞ ≤ B    iff    |range(obs)| ≤ ⌊2^B⌋.

    Encoding (Int sort, general Solver):
        * declare an uninterpreted function ``obs : Int → Int``;
        * fix ``obs(i) = observed_value_i`` for ``i ∈ [0, n)``;
        * assert the *negation* of the bound: there exist
          ``⌊2^B⌋ + 1`` distinct indices in ``[0, n)`` whose
          observations are pairwise ``distinct``.
        * UNSAT  ⇒ bound proven   (``verified=True``)
        * SAT    ⇒ concrete counterexample tuple of indices
                    (``verified=False``)

    Noise detection: each secret is probed
    ``samples_per_secret`` times. If any secret produces more than
    one distinct value across probes the channel is non-deterministic
    and the certificate is *not* valid; raise :class:`QIFError` and
    require the caller to use :func:`qif_from_traces` instead.

    Returns a :class:`soilith_z3verify.Z3VerifyResult` with
    ``judgment="qif_leak_bounded"``; the SMT-LIB body is portable —
    a downstream auditor can re-run the proof without trusting this
    process.

    Practical scale: enumerates secrets, so ``len(secrets) ≤ 2^14``
    and ``bound_bits ≤ 14`` is the supported sweet spot. Beyond that
    the pairwise-distinct constraint grows quadratically in
    ``⌊2^B⌋ + 1``.
    """
    from soilith_z3verify import Z3VerifyResult, Z3VerifyError
    import time

    if not secrets:
        raise QIFError("verify_qif_leak_bounded requires ≥ 1 secret")
    if samples_per_secret < 1:
        raise QIFError("samples_per_secret must be ≥ 1")
    if bound_bits < 0.0:
        raise QIFError("bound_bits must be ≥ 0")

    secrets_list = list(secrets)
    n = len(secrets_list)

    observed: list[int] = []
    for s in secrets_list:
        samples = {observation_fn(s) for _ in range(samples_per_secret)}
        if len(samples) > 1:
            raise QIFError(
                f"observation_fn is non-deterministic for secret "
                f"{s!r}: saw {len(samples)} distinct values. "
                "Use qif_from_traces for noisy channels — Z3 "
                "certification requires a deterministic obs."
            )
        observed.append(int(next(iter(samples))))

    distinct = len(set(observed))
    max_distinct = int(math.floor(2.0 ** bound_bits))
    need = max_distinct + 1
    rule_ok = f"QIF-LEAK-BOUND (Z3-Int, B={bound_bits:.3f})"
    rule_fail = f"QIF-LEAK-BOUND (Z3-Int, B={bound_bits:.3f}; witness)"

    if n < need:
        smtlib = (
            f"; trivial: only {n} secret(s), bound requires "
            f"≥ {need} distinct to violate — vacuously ≤ {bound_bits} bits\n"
        )
        return Z3VerifyResult(
            judgment="qif_leak_bounded",
            verified=True, n_clauses=0,
            time_ms=0.0, smtlib=smtlib,
            rule_name=rule_ok,
        )

    try:
        import z3
    except ImportError as exc:
        raise Z3VerifyError(
            "Z3 not available. Install with: pip install z3-solver."
        ) from exc

    solver = z3.Solver()
    obs_fun = z3.Function("obs", z3.IntSort(), z3.IntSort())

    for i, v in enumerate(observed):
        solver.add(obs_fun(i) == v)

    idx_vars = [z3.Int(f"i_{j}") for j in range(need)]
    for v in idx_vars:
        solver.add(v >= 0, v < n)
    solver.add(z3.Distinct(*[obs_fun(v) for v in idx_vars]))

    smtlib = solver.to_smt2()
    t0 = time.perf_counter()
    check = solver.check()
    dt = (time.perf_counter() - t0) * 1000.0

    n_clauses = n + need + 1  # obs eqs + range bounds + distinct
    if check == z3.unsat:
        return Z3VerifyResult(
            judgment="qif_leak_bounded",
            verified=True, n_clauses=n_clauses,
            time_ms=dt, smtlib=smtlib,
            rule_name=rule_ok,
        )
    if check == z3.sat:
        model = solver.model()
        idx_vals = [model.eval(v).as_long() for v in idx_vars]
        obs_vals = [int(observed[i]) for i in idx_vals]
        cex = {
            "indices": idx_vals,
            "observations": obs_vals,
            "secrets": [
                str(secrets_list[i]) for i in idx_vals
            ],
            "distinct_observations": distinct,
            "required_for_violation": need,
        }
        return Z3VerifyResult(
            judgment="qif_leak_bounded",
            verified=False, n_clauses=n_clauses,
            time_ms=dt, smtlib=smtlib,
            counterexample=cex,
            rule_name=rule_fail,
        )
    return Z3VerifyResult(
        judgment="qif_leak_bounded",
        verified=False, n_clauses=n_clauses,
        time_ms=dt, smtlib=smtlib,
        rule_name=f"QIF-LEAK-BOUND (UNKNOWN, B={bound_bits:.3f})",
    )


def verify_g_leak_bounded(
    secrets: Sequence[Hashable],
    observation_fn: Callable[[Hashable], Hashable],
    *,
    gain: GainFunction,
    guesses: Sequence[Hashable] | None = None,
    bound_bits: float,
    name: str = "g_leak_bounded",
    gain_name: str = "g",
    samples_per_secret: int = 4,
) -> "Any":
    """Prove via Z3 that the g-leakage of ``observation_fn`` on a
    uniform prior over ``secrets`` against an attacker with gain
    function ``gain`` is at most ``bound_bits``.

    For deterministic obs and uniform prior the bound

        L_g ≤ B    iff    V_g(π|O) ≤ 2^B · V_g(π)

    becomes a rational inequality. We pre-compute the per-observation
    max-attainable-gain values in Python (a finite max over
    ``guesses``), then ask Z3 to verify the resulting linear
    inequality over reals. The SMT-LIB body carries the precomputed
    gain values explicitly — an auditor can independently
    (1) re-run ``gain`` against ``secrets`` to confirm the
    per-observation maxes, and (2) re-run Z3 to confirm the
    inequality.

    Returns :class:`soilith_z3verify.Z3VerifyResult` with
    ``judgment="g_leak_bounded"``. The PQC pipeline accepts it
    directly via :func:`soilith_z3verify.sign_with_pqc`.

    Noise rejection: each secret is probed ``samples_per_secret``
    times; non-deterministic obs raises :class:`QIFError` (use
    :func:`qif_from_traces` with a ``gain`` argument for noisy
    channels).
    """
    from soilith_z3verify import Z3VerifyResult, Z3VerifyError
    import time

    if not secrets:
        raise QIFError("verify_g_leak_bounded requires ≥ 1 secret")
    if bound_bits < 0.0:
        raise QIFError("bound_bits must be ≥ 0")
    if samples_per_secret < 1:
        raise QIFError("samples_per_secret must be ≥ 1")

    secrets_list = list(secrets)
    n = len(secrets_list)
    guesses_list = (
        list(guesses) if guesses is not None else list(secrets_list)
    )
    if not guesses_list:
        raise QIFError("guesses must be non-empty")

    observed: list[Hashable] = []
    for s in secrets_list:
        samples = {observation_fn(s) for _ in range(samples_per_secret)}
        if len(samples) > 1:
            raise QIFError(
                f"observation_fn is non-deterministic for secret "
                f"{s!r}: saw {len(samples)} distinct values. "
                "Use qif_from_traces(..., gain=...) for noisy channels."
            )
        observed.append(next(iter(samples)))

    obs_class: dict[Hashable, list[int]] = defaultdict(list)
    for i, o in enumerate(observed):
        obs_class[o].append(i)

    per_obs: list[tuple[Hashable, float, Any]] = []
    for o, idxs in obs_class.items():
        best_val = -1.0
        best_w: Any = None
        for w in guesses_list:
            val = sum(float(gain(w, secrets_list[i])) for i in idxs)
            if val > best_val:
                best_val = val
                best_w = w
        per_obs.append((o, best_val / n, best_w))

    best_prior_val = -1.0
    best_prior_w: Any = None
    for w in guesses_list:
        val = sum(float(gain(w, s)) for s in secrets_list) / n
        if val > best_prior_val:
            best_prior_val = val
            best_prior_w = w

    threshold_mult = 2.0 ** float(bound_bits)
    total_post = sum(c for _, c, _ in per_obs)

    rule_ok = (
        f"G-LEAK-BOUND ({gain_name}, Z3-R, B={bound_bits:.3f})"
    )
    rule_fail = (
        f"G-LEAK-BOUND ({gain_name}, Z3-R, B={bound_bits:.3f}; witness)"
    )

    if best_prior_val <= 0.0:
        smtlib = (
            f"; trivial: V_g(prior) = 0 ⇒ V_g(post) = 0 vacuously\n"
        )
        return Z3VerifyResult(
            judgment="g_leak_bounded",
            verified=True, n_clauses=0,
            time_ms=0.0, smtlib=smtlib,
            rule_name=rule_ok,
        )

    try:
        import z3
    except ImportError as exc:
        raise Z3VerifyError(
            "Z3 not available. Install with: pip install z3-solver."
        ) from exc

    solver = z3.Solver()
    o_vars: list[Any] = []
    for i, (_o, c, _w) in enumerate(per_obs):
        v = z3.Real(f"c_o{i}")
        solver.add(v == c)
        o_vars.append(v)
    prior_var = z3.Real("c_prior")
    solver.add(prior_var == best_prior_val)
    total_var = z3.Real("total_post")
    if o_vars:
        solver.add(total_var == z3.Sum(*o_vars))
    else:
        solver.add(total_var == 0.0)
    threshold_var = z3.Real("two_pow_B")
    solver.add(threshold_var == threshold_mult)
    solver.add(total_var > threshold_var * prior_var)

    smtlib = solver.to_smt2()
    t0 = time.perf_counter()
    check = solver.check()
    dt = (time.perf_counter() - t0) * 1000.0

    n_clauses = len(per_obs) + 4
    if check == z3.unsat:
        return Z3VerifyResult(
            judgment="g_leak_bounded",
            verified=True, n_clauses=n_clauses,
            time_ms=dt, smtlib=smtlib,
            rule_name=rule_ok,
        )
    if check == z3.sat:
        cex = {
            "total_g_posterior": total_post,
            "g_v_prior": best_prior_val,
            "threshold_mult_2_pow_B": threshold_mult,
            "n_observations": len(per_obs),
            "best_prior_guess": str(best_prior_w),
            "best_guesses_per_obs": [
                {
                    "observation": str(o),
                    "max_g_in_class_per_n": float(c),
                    "best_guess": str(w),
                }
                for o, c, w in per_obs[:5]
            ],
        }
        return Z3VerifyResult(
            judgment="g_leak_bounded",
            verified=False, n_clauses=n_clauses,
            time_ms=dt, smtlib=smtlib,
            counterexample=cex,
            rule_name=rule_fail,
        )
    return Z3VerifyResult(
        judgment="g_leak_bounded",
        verified=False, n_clauses=n_clauses,
        time_ms=dt, smtlib=smtlib,
        rule_name=(
            f"G-LEAK-BOUND ({gain_name}, UNKNOWN, "
            f"B={bound_bits:.3f})"
        ),
    )


def certify_leak_bound(
    report: LeakageReport,
    secrets: Sequence[Hashable],
    observation_fn: Callable[[Hashable], Hashable],
    *,
    samples_per_secret: int = 4,
) -> "Any":
    """Take an empirical :class:`LeakageReport` and produce a Z3
    certificate that its budget is correct.

    Convenience wrapper: pulls ``budget_bits`` off the report,
    uses ``report.program_name`` for the certificate name, and
    forwards everything else to :func:`verify_qif_leak_bounded`.

    Raises :class:`QIFError` if the report has no ``budget_bits``.
    """
    if report.budget_bits is None:
        raise QIFError(
            "LeakageReport has no budget_bits set — cannot certify"
        )
    return verify_qif_leak_bounded(
        secrets=secrets,
        observation_fn=observation_fn,
        bound_bits=report.budget_bits,
        name=report.program_name,
        samples_per_secret=samples_per_secret,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def _safe(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name)[:60]


def persist(report: LeakageReport, arena_path: Path) -> None:
    """Write the report to the arena under ``qif/<program>``.

    Payload (6 floats):
        [n_secrets, repeats, distinct_obs,
         min_entropy_leak_bits, shannon_leak_bits,
         exceeded_budget]   # 1.0 if leak > budget, else 0.0

    Trust = 1.0 iff the report is ``safe`` (within budget); 0.0
    otherwise — matches the convention used by
    ``soilith_loop_ifc.persist``.
    """
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(report.n_secrets),
        float(report.repeats),
        float(report.distinct_observations),
        float(report.min_entropy_leak_bits),
        float(report.shannon_leak_bits),
        0.0 if report.safe else 1.0,
    ], dtype=float)
    trust = 1.0 if report.safe else 0.0
    arena[f"qif/{_safe(report.program_name)}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def _demo_secret_compare(secret_lengths: Iterable[int]) -> LeakageReport:
    """Iteration count of a naive memcmp leaks ``log₂(distinct lengths)``
    bits per call. With four candidates {8, 16, 24, 32} → 2 bits."""
    sl = list(secret_lengths)
    return qif_from_traces(
        secrets=sl,
        observation_fn=lambda s: int(s),
        name="naive_memcmp",
        budget_bits=0.0,
    )


def _demo_aes_round_keys() -> LeakageReport:
    """Iteration count of AES round-key expansion is fixed at 16 for
    AES-128 regardless of key. Leakage = 0 bits."""
    return qif_from_traces(
        secrets=[("k", i) for i in range(16)],
        observation_fn=lambda s: 16,
        name="aes_round_keys",
        budget_bits=0.0,
    )


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith QIF — quantitative information flow."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    p.add_argument("--demo", action="store_true",
                   help="run two synthetic gadgets against the analyser")
    p.add_argument("--budget", type=float, default=None,
                   help="reporting budget in bits (overrides per-demo)")
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    if not args.demo:
        p.error("nothing to do — pass --demo")

    print("# Σoilith QIF — quantitative leakage gadget")
    rep_aes = _demo_aes_round_keys()
    if args.budget is not None:
        rep_aes.budget_bits = args.budget
    print(rep_aes.describe())
    persist(rep_aes, args.arena)

    print()
    rep_cmp = _demo_secret_compare([8, 16, 24, 32])
    if args.budget is not None:
        rep_cmp.budget_bits = args.budget
    print(rep_cmp.describe())
    persist(rep_cmp, args.arena)

    print(f"\nComposition over 16 adaptive queries:")
    print(f"  aes_round_keys → ≤ "
          f"{composition_bound(rep_aes, n_queries=16):.3f}b total")
    print(f"  naive_memcmp   → ≤ "
          f"{composition_bound(rep_cmp, n_queries=16):.3f}b total")

    print(f"\nPersisted to {args.arena}")
    return 0 if (rep_aes.safe and rep_cmp.safe) else 1


if __name__ == "__main__":
    raise SystemExit(main())
