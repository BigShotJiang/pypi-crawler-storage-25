"""
ct_echo_ast — turn real Python source into ``ct_echo`` SS-channel
loop specs.

For every ``for`` loop in every top-level ``def`` of a Python source
file, this module derives the four Sabelfeld-Sands iteration-count
parameters by walking the AST and running a simple flow-insensitive
HIGH/LOW taint analysis on the enclosing function body. The output
is a list of dicts in the exact shape ``ct_echo.audit_loop`` already
consumes — no model in between, no hand-written manifest.

HIGH / LOW labelling
--------------------
Three sources are combined (later sources override earlier):

1. **Annotations.** ``def f(key: "HIGH", n: "LOW"): ...`` —
   strings, so the module being audited never has to import
   anything from ``echovalidum``. Anything other than
   ``"HIGH"`` / ``"LOW"`` is treated as ``"UNKNOWN"``.

2. **Docstring marker.** ``ct-echo: high(a, b) low(c, d)`` inside
   the function docstring (case-insensitive, anywhere on a line).

3. **CLI overrides.** ``override_high={"key"}``,
   ``override_low={"n"}`` — supplied by ``ct_echo --high a,b
   --low c,d``.

Taint lattice & propagation
---------------------------
Labels: ``{LOW, HIGH, UNKNOWN}`` with ``HIGH ⊔ UNKNOWN = HIGH`` (for
the purpose of channel classification, ``UNKNOWN`` propagates
through expressions but is treated as ``LOW`` at the channel-level
verdict — explicit unsafety must be witnessed by a HIGH name).

The body of each function is scanned in a single forward pass:

* ``x = expr``    →  ``taint[x] = join(taint[n] for n in names(expr))``
* ``x += expr``   →  ``taint[x] = taint[x] ⊔ join(...)``
* ``for x in iter: ...``  classifies the iteration:
    – iter is ``range(N)`` ⇒  classify ``N``
    – iter is any other expression ⇒  classify its ``names(...)``

A loop is **HIGH-driven on Ch1 (loop bound)** iff its bound
expression names any HIGH-tainted variable. Same idea for Ch3
(``high_drives_touch``) over the subscript expressions of
``Subscript`` nodes in the loop body, and for Ch2
(``high_drives_sched``) when any enclosing outer loop is HIGH-bound.

Where the AST cannot determine a concrete numeric bound (e.g.
``for x in arr:`` where ``arr`` is a function parameter), the
spec omits ``max_iter`` / ``low_n_writes`` so the auditor's
defaults apply. The classification is still sound: if any name in
the iterator is HIGH-tainted, ``high_drives_bound`` is set, which
is what Ch1 needs to refute.

What this **does not** do (yet)
-------------------------------
* No interprocedural analysis. Each function is audited in
  isolation; calls inside loops are not followed.
* No alias analysis. ``y = x; for i in range(y): ...`` is handled
  (assignment propagates taint) but ``y = box; box.n = secret;
  for i in range(box.n): ...`` is not.
* No while-loops yet (most cryptographic constant-time code uses
  bounded ``for`` loops; while-loops are flagged with a TODO
  hint).
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


# ──────────────────────────────────────────────────────────────────
# Taint analysis
# ──────────────────────────────────────────────────────────────────
HIGH = "HIGH"
LOW = "LOW"
UNKNOWN = "UNKNOWN"


def _join(a: str, b: str) -> str:
    if a == HIGH or b == HIGH:
        return HIGH
    if a == UNKNOWN or b == UNKNOWN:
        return UNKNOWN
    return LOW


def _names_in(node: ast.AST) -> set[str]:
    return {n.id for n in ast.walk(node) if isinstance(n, ast.Name)}


def _classify_expr(node: ast.AST, taint: dict[str, str]) -> str:
    """Resolve the taint label of an expression based on the
    HIGH/LOW labelling of every ``Name`` it references.

    Names that have never been bound — typically Python builtins
    (``len``, ``range``, ``int``) or imported helpers — default to
    ``LOW``: they are constant references that cannot carry runtime
    taint by themselves. Only explicitly-seeded UNKNOWN labels
    (unannotated function parameters) propagate UNKNOWN through
    the analysis.
    """
    names = _names_in(node)
    label = LOW
    for n in names:
        label = _join(label, taint.get(n, LOW))
    return label


_DOCSTRING_HIGH_RE = re.compile(
    r"ct-echo:\s*(?:.*?\bhigh\(([^)]*)\))?(?:.*?\blow\(([^)]*)\))?",
    re.IGNORECASE | re.DOTALL,
)


def _names_from_docstring_block(
    body: list[ast.stmt],
) -> tuple[set[str], set[str]]:
    """Return ``(high_names, low_names)`` declared via
    ``ct-echo: high(a, b) low(c, d)`` inside the function
    docstring."""
    if not body:
        return set(), set()
    first = body[0]
    if not isinstance(first, ast.Expr):
        return set(), set()
    if isinstance(first.value, ast.Constant) and isinstance(
        first.value.value, str
    ):
        doc = first.value.value
    else:
        return set(), set()
    high: set[str] = set()
    low: set[str] = set()
    for m in _DOCSTRING_HIGH_RE.finditer(doc):
        h_grp, l_grp = m.group(1), m.group(2)
        if h_grp:
            high |= {x.strip() for x in h_grp.split(",") if x.strip()}
        if l_grp:
            low |= {x.strip() for x in l_grp.split(",") if x.strip()}
    return high, low


def _initial_taint_for_function(
    fn: ast.FunctionDef,
    *,
    override_high: set[str],
    override_low: set[str],
) -> dict[str, str]:
    """Build the initial HIGH/LOW labelling for a function's
    parameters from string annotations, the docstring, and CLI
    overrides (later sources win)."""
    taint: dict[str, str] = {}
    args = list(fn.args.args)
    args.extend(getattr(fn.args, "posonlyargs", []) or [])
    args.extend(fn.args.kwonlyargs or [])
    for arg in args:
        ann = arg.annotation
        label = UNKNOWN
        if isinstance(ann, ast.Constant) and isinstance(ann.value, str):
            up = ann.value.strip().upper()
            if up in (HIGH, LOW):
                label = up
        elif isinstance(ann, ast.Name) and ann.id in (HIGH, LOW):
            label = ann.id
        taint[arg.arg] = label

    doc_high, doc_low = _names_from_docstring_block(fn.body)
    for n in doc_high:
        taint[n] = HIGH
    for n in doc_low:
        taint[n] = LOW

    for n in override_high:
        taint[n] = HIGH
    for n in override_low:
        taint[n] = LOW
    return taint


def _propagate_taint(
    body: list[ast.stmt], taint: dict[str, str],
) -> dict[str, str]:
    """Forward-walk the function body propagating HIGH/LOW taint
    through assignments. Flow-insensitive but iterates to a
    fixpoint, so simple back-edges (``x = f(x)``) settle."""
    changed = True
    safety = 0
    while changed and safety < 32:
        changed = False
        safety += 1
        for node in ast.walk(ast.Module(body=body, type_ignores=[])):
            if isinstance(node, ast.Assign):
                rhs = _classify_expr(node.value, taint)
                for tgt in node.targets:
                    for nm in _names_in(tgt):
                        new = _join(taint.get(nm, LOW), rhs)
                        if taint.get(nm) != new:
                            taint[nm] = new
                            changed = True
            elif isinstance(node, ast.AugAssign):
                rhs = _classify_expr(node.value, taint)
                for nm in _names_in(node.target):
                    new = _join(taint.get(nm, LOW), rhs)
                    if taint.get(nm) != new:
                        taint[nm] = new
                        changed = True
            elif isinstance(node, ast.AnnAssign) and node.value is not None:
                rhs = _classify_expr(node.value, taint)
                for nm in _names_in(node.target):
                    new = _join(taint.get(nm, LOW), rhs)
                    if taint.get(nm) != new:
                        taint[nm] = new
                        changed = True
    return taint


# ──────────────────────────────────────────────────────────────────
# Loop spec extraction
# ──────────────────────────────────────────────────────────────────
@dataclass
class ExtractedLoop:
    """A single ``for`` loop turned into a ``ct_echo`` manifest
    spec plus source provenance."""

    spec: dict[str, Any]
    source_path: str
    source_lineno: int
    source_snippet: str
    iter_label: str  # HIGH / LOW / UNKNOWN
    nesting_depth: int = 0  # 0 = outermost in the function
    enclosing_high: bool = False


def _iter_bound_literal(iter_node: ast.AST) -> int | None:
    """Best-effort numeric upper bound of an iterator expression.

    * ``range(K)``                 → K
    * ``range(A, B)``              → max(0, B - A)
    * ``range(A, B, S)``           → no symbolic guess; None
    * ``[lit1, lit2, ...]`` or
      ``(lit1, ...)``              → len(...)
    * ``b"..."``, ``"...."``       → len(...)
    * ``len(literal)``-style       → handled via Constant fallback
    """
    if isinstance(iter_node, ast.Call) and isinstance(iter_node.func, ast.Name) and iter_node.func.id == "range":
        args = iter_node.args
        try:
            if len(args) == 1 and isinstance(args[0], ast.Constant) and isinstance(args[0].value, int):
                return int(args[0].value)
            if (
                len(args) >= 2
                and isinstance(args[0], ast.Constant)
                and isinstance(args[1], ast.Constant)
                and isinstance(args[0].value, int)
                and isinstance(args[1].value, int)
                and len(args) == 2
            ):
                return max(0, int(args[1].value) - int(args[0].value))
        except (TypeError, ValueError):
            return None
    if isinstance(iter_node, (ast.List, ast.Tuple)):
        return len(iter_node.elts)
    if isinstance(iter_node, ast.Constant) and isinstance(
        iter_node.value, (bytes, str)
    ):
        return len(iter_node.value)
    return None


def _classify_bound(
    iter_node: ast.AST, taint: dict[str, str],
) -> str:
    """Return HIGH/LOW/UNKNOWN for the *bound* of a ``for`` loop's
    iterator.

    For ``range(N)``, classify ``N``. For any other expression, fall
    back to the union of ``Name`` taints anywhere in the expression
    — which is correctly conservative: ``for x in HIGH_arr`` and
    ``for x in range(HIGH_n)`` are both HIGH-bound.
    """
    if (
        isinstance(iter_node, ast.Call)
        and isinstance(iter_node.func, ast.Name)
        and iter_node.func.id == "range"
    ):
        label = LOW
        for arg in iter_node.args:
            label = _join(label, _classify_expr(arg, taint))
        return label
    return _classify_expr(iter_node, taint)


def _subscript_classification(
    body: list[ast.stmt], taint: dict[str, str],
) -> tuple[str, str | None]:
    """Walk the loop body for subscript expressions; return the
    union taint of every slice expression plus the source snippet
    of the first HIGH-driven subscript (for counterexample
    display)."""
    label = LOW
    witness: str | None = None
    for node in body:
        for sub in ast.walk(node):
            if isinstance(sub, ast.Subscript):
                sl = sub.slice
                if isinstance(sl, ast.Index):  # python <3.9 compat
                    sl = sl.value  # type: ignore[attr-defined]
                ll = _classify_expr(sl, taint)
                if ll == HIGH and witness is None:
                    try:
                        witness = ast.unparse(sub)
                    except Exception:  # noqa: BLE001
                        witness = None
                label = _join(label, ll)
    return label, witness


def _early_exit_classification(
    body: list[ast.stmt], taint: dict[str, str],
) -> tuple[str, str | None]:
    """Detect HIGH-dependent early-termination patterns in the
    loop body. Returns ``(label, witness_snippet)`` where ``label``
    is HIGH iff any ``If`` whose test references a HIGH variable
    contains a ``Return``, ``Break``, ``Continue`` or ``Raise`` in
    its body (or orelse). This is the early-exit-on-secret pattern
    behind the canonical naive-memcmp timing leak: the declared
    loop bound is LOW, but the *effective* iteration count is a
    function of HIGH, so SS Ch1 should refute.

    We treat early-exit-on-HIGH as ``high_drives_bound = True``
    because that is the channel the practical timing leak occupies
    (one HIGH bit per iteration whose execution is conditional on
    the secret, observed via wall-clock or instruction count).
    """
    label = LOW
    witness: str | None = None

    def _block_contains_early_exit(block: list[ast.stmt]) -> bool:
        for n in block:
            for sub in ast.walk(n):
                if isinstance(
                    sub,
                    (ast.Return, ast.Break, ast.Continue, ast.Raise),
                ):
                    return True
        return False

    def _scan(stmts: list[ast.stmt], inside_high_if: bool) -> None:
        nonlocal label, witness
        for node in stmts:
            if isinstance(node, ast.For):
                continue  # inner loops handled separately
            if isinstance(node, ast.If):
                test_label = _classify_expr(node.test, taint)
                if test_label == HIGH and (
                    _block_contains_early_exit(node.body)
                    or _block_contains_early_exit(node.orelse)
                ):
                    label = HIGH
                    if witness is None:
                        try:
                            witness = ast.unparse(node.test)
                        except Exception:  # noqa: BLE001
                            witness = "<unrenderable>"
                _scan(node.body, inside_high_if or test_label == HIGH)
                _scan(node.orelse, inside_high_if or test_label == HIGH)
            elif isinstance(node, (ast.Try, ast.With)):
                _scan(node.body, inside_high_if)
                if hasattr(node, "orelse"):
                    _scan(node.orelse, inside_high_if)
                if isinstance(node, ast.Try):
                    _scan(node.finalbody, inside_high_if)
                    for h in node.handlers:
                        _scan(h.body, inside_high_if)
            elif isinstance(node, ast.While):
                _scan(node.body, inside_high_if)
                _scan(node.orelse, inside_high_if)
            elif isinstance(
                node,
                (ast.Return, ast.Break, ast.Continue, ast.Raise),
            ):
                if inside_high_if:
                    label = HIGH
    _scan(body, False)
    return label, witness


def _extract_for_loops(
    fn: ast.FunctionDef,
    taint: dict[str, str],
    *,
    source_path: str,
    source_text: str,
    enclosing_high: bool = False,
    nesting_depth: int = 0,
) -> list[ExtractedLoop]:
    """Recursively collect every ``for`` loop inside ``fn`` (or a
    nested block of an outer ``for``)."""
    out: list[ExtractedLoop] = []
    src_lines = source_text.splitlines()

    def walk(body: list[ast.stmt], depth: int, encl_high: bool) -> None:
        for node in body:
            if isinstance(node, ast.For):
                declared_bound = _classify_bound(node.iter, taint)
                touch_label, _t_witness = _subscript_classification(
                    node.body, taint
                )
                early_label, _e_witness = _early_exit_classification(
                    node.body, taint
                )
                # The effective bound is HIGH when either the
                # declared range is HIGH or an early-exit conditional
                # on HIGH shortens the iteration count from within
                # the body. The latter is the canonical naive-memcmp
                # leak pattern.
                effective_bound = _join(declared_bound, early_label)
                bound_lit = _iter_bound_literal(node.iter)

                spec: dict[str, Any] = {
                    "name": f"{fn.name}.for@{node.lineno}",
                    "high_drives_bound": effective_bound == HIGH,
                    "high_drives_sched": encl_high,
                    "high_drives_touch": touch_label == HIGH,
                    "data_dependent_iter": effective_bound == HIGH,
                }
                if bound_lit is not None:
                    spec["low_n_writes"] = bound_lit
                    spec["max_iter"] = bound_lit
                if depth >= 1:
                    spec["iters_per_run"] = bound_lit or 1
                if early_label == HIGH and declared_bound != HIGH:
                    spec["leak_pattern"] = "high_dependent_early_exit"
                snippet = (
                    src_lines[node.lineno - 1].rstrip()
                    if 0 <= node.lineno - 1 < len(src_lines)
                    else "<source unavailable>"
                )
                out.append(ExtractedLoop(
                    spec=spec,
                    source_path=source_path,
                    source_lineno=node.lineno,
                    source_snippet=snippet,
                    iter_label=effective_bound,
                    nesting_depth=depth,
                    enclosing_high=encl_high,
                ))
                walk(
                    node.body,
                    depth + 1,
                    encl_high or effective_bound == HIGH,
                )
            elif isinstance(node, (ast.If, ast.While, ast.Try, ast.With)):
                walk(node.body, depth, encl_high)
                if hasattr(node, "orelse"):
                    walk(node.orelse, depth, encl_high)
                if isinstance(node, ast.Try):
                    walk(node.finalbody, depth, encl_high)
                    for h in node.handlers:
                        walk(h.body, depth, encl_high)

    walk(fn.body, nesting_depth, enclosing_high)
    return out


# ──────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────
@dataclass
class ExtractionResult:
    source_path: str
    loops: list[ExtractedLoop] = field(default_factory=list)
    per_function: dict[str, list[ExtractedLoop]] = field(default_factory=dict)

    @property
    def specs(self) -> list[dict[str, Any]]:
        """Manifest-shaped list of spec dicts, one per loop, ready
        to feed to ``ct_echo.audit_loop`` /
        ``ct_echo.audit_loop_with_qif``."""
        return [el.spec for el in self.loops]


def extract_loop_specs_from_source(
    source_path: str | Path,
    *,
    override_high: Iterable[str] = (),
    override_low: Iterable[str] = (),
    function_filter: Iterable[str] | None = None,
) -> ExtractionResult:
    """Parse ``source_path`` and extract one SS-channel loop spec
    per ``for`` loop in every top-level ``def``.

    Parameters
    ----------
    source_path
        Path to a Python source file. Read as UTF-8.
    override_high, override_low
        Names of variables to be force-labelled HIGH or LOW
        regardless of what the annotations / docstring say. CLI
        callers pass these from ``--high`` / ``--low``.
    function_filter
        If non-None, restrict extraction to function names in this
        iterable. Useful for ``--source-function aes_round`` style
        invocations.

    Returns
    -------
    :class:`ExtractionResult`. ``.specs`` is the list of manifest
    dicts to feed into ``ct_echo``; ``.loops`` carries source
    provenance so the receipt can pin each verdict to a file/line.
    """
    path = Path(source_path)
    source_text = path.read_text(encoding="utf-8")
    tree = ast.parse(source_text, filename=str(path))

    oh, ol = set(override_high), set(override_low)
    keep = set(function_filter) if function_filter is not None else None

    result = ExtractionResult(source_path=str(path))
    for node in tree.body:
        if not isinstance(node, ast.FunctionDef):
            continue
        if keep is not None and node.name not in keep:
            continue
        taint = _initial_taint_for_function(
            node, override_high=oh, override_low=ol,
        )
        taint = _propagate_taint(node.body, taint)
        fn_loops = _extract_for_loops(
            node, taint,
            source_path=str(path),
            source_text=source_text,
        )
        result.per_function[node.name] = fn_loops
        result.loops.extend(fn_loops)
    return result
