"""
ct_echo — the unified Z3 + PQC discharge of all four Sabelfeld–Sands
iteration-count covert channels.

For every loop in a manifest, ``ct_echo`` discharges all four
Sabelfeld-Sands (SS 2000) non-interference channels — loop bound,
outer schedule, touch pattern, iteration bound — through Z3, packs
the four Z3 verdicts into a single :class:`SSChannelBundle`, and
(with ``--sign``) emits one unified PQC attestation per loop whose
signature commits to all four SMT-LIB proofs as atomic bytes.

This is the headline claim packaged as a CLI you can run on real
Python: one tool, four channels, Z3-proved, PQC-attested, with a
parseable receipt. The receipt is the thing you pin under the post.

With ``--qif`` it additionally runs a Smith min-entropy / Shannon
leakage analysis (Department 11 quantitative extension) on every
loop, turning the boolean PASS/FAIL into a *bit* count: how many
bits of HIGH does the iteration count reveal per query?

Manifest schema (JSON)
----------------------
{
  "loops": [
    {
      "name":               "aes_round_keys",
      "high_drives_bound":  false,        // SS Ch1
      "low_n_writes":       16,
      "high_drives_sched":  false,        // SS Ch2
      "low_n_runs":         4,
      "iters_per_run":      10,
      "closure_sizes":      [3,3,3,3],    // SS Ch3
      "high_drives_touch":  false,
      "max_iter":           64,           // SS Ch4
      "qif": {                            // optional, for --qif
        "secret_space":     16,           // |S| for the synthetic sweep
        "budget_bits":      0.0           // per-loop ceiling
      }
    },
    ...
  ]
}

CLI
---
    python -m applications.ct_echo --demo                          # SS verdicts + headline block
    python -m applications.ct_echo --demo --sign                   # + unified PQC attestation per loop
    python -m applications.ct_echo --demo --sign --receipt out.json  # + machine-readable receipt
    python -m applications.ct_echo --demo --qif --budget 0.0
    python -m applications.ct_echo --demo --prove --budget 0.0 --queries 16
    python -m applications.ct_echo --manifest path/to/loops.json --sign --receipt receipt.json

Exit code 0 = every loop is iteration-count non-interfering on
            every Sabelfeld-Sands channel (and, with --qif, within
            its leakage budget).
Exit code 1 = at least one channel failed or one loop exceeded its
            quantitative budget; counterexamples printed.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path

import echovalidum as ev


# ──────────────────────────────────────────────────────────────────
# Verdict aggregation
# ──────────────────────────────────────────────────────────────────
@dataclass
class LoopAuditRow:
    name: str
    ch1: ev.Z3VerifyResult
    ch2: ev.Z3VerifyResult
    ch3: ev.Z3VerifyResult
    ch4: ev.Z3VerifyResult
    bundle: ev.SSChannelBundle | None = None
    attestation: dict | None = None
    qif: ev.LeakageReport | None = None
    qif_cert: ev.Z3VerifyResult | None = None
    source_path: str | None = None
    source_lineno: int | None = None
    source_snippet: str | None = None
    leak_pattern: str | None = None

    @property
    def all_pass(self) -> bool:
        ok = all(
            r.verified for r in (self.ch1, self.ch2, self.ch3, self.ch4)
        )
        if self.qif is not None:
            ok = ok and self.qif.safe
        if self.qif_cert is not None:
            ok = ok and self.qif_cert.verified
        return ok

    @property
    def total_ms(self) -> float:
        return sum(r.time_ms for r in (self.ch1, self.ch2, self.ch3, self.ch4))

    def build_bundle(self) -> ev.SSChannelBundle:
        """Pack the four Z3 verdicts into a single
        :class:`SSChannelBundle`. The bundle's transcript digest is
        the deterministic SHA-256 commitment to all four SMT-LIBs;
        signing it with :func:`ev.sign_ss_bundle` produces the
        unified PQC attestation that is the headline artefact of
        ``ct_echo``."""
        if self.bundle is None:
            self.bundle = ev.SSChannelBundle(
                loop_name=self.name,
                ch1=self.ch1, ch2=self.ch2,
                ch3=self.ch3, ch4=self.ch4,
            )
        return self.bundle


# ──────────────────────────────────────────────────────────────────
# Quantitative information flow — synthetic per-channel observation
# ──────────────────────────────────────────────────────────────────
def _synthetic_qif(
    spec: dict, *, budget_bits: float, default_secret_space: int = 16,
) -> ev.LeakageReport:
    """Build a per-channel observation function for a loop manifest
    entry and run it through ``ev.qif_from_traces``.

    The observation function follows the Sabelfeld–Sands semantics
    of the four channels. When the corresponding ``high_drives_*``
    flag is false the channel is constant-in-secret (0 bits leaked);
    when it is true the channel exposes a function of the secret
    whose range is bounded by the channel's natural cap
    (``low_n_writes``, ``low_n_runs * iters_per_run``,
    ``len(closure_sizes)``, or ``max_iter``).

    The synthetic mode quantifies the *worst-case* leakage of a
    declared channel under a uniform secret prior. Combine with
    ``--queries K`` to get a K-query adaptive bound.
    """
    qif_block = dict(spec.get("qif") or {})
    n_secrets = int(qif_block.get("secret_space", default_secret_space))
    budget = float(qif_block.get("budget_bits", budget_bits))
    secrets = list(range(n_secrets))

    high_bound = bool(spec.get("high_drives_bound", False))
    high_sched = bool(spec.get("high_drives_sched", False))
    high_touch = bool(spec.get("high_drives_touch", False))
    data_dep_iter = bool(spec.get("data_dependent_iter", False))
    low_n_writes = int(spec.get("low_n_writes", 16))
    low_n_runs = int(spec.get("low_n_runs", 1))
    iters_per_run = int(spec.get("iters_per_run", 1))
    closure_sizes = list(spec.get("closure_sizes", [3, 3, 3, 3]))
    max_iter = int(spec.get("max_iter", 64))
    low_node = int(spec.get("low_node", 0))

    def obs(s: int) -> int:
        ch1 = (s % max(1, low_n_writes)) if high_bound else low_n_writes
        ch2 = (
            (s % max(1, low_n_runs * iters_per_run))
            if high_sched else low_n_runs * iters_per_run
        )
        ch3 = (
            int(closure_sizes[s % max(1, len(closure_sizes))])
            if high_touch
            else int(closure_sizes[low_node % max(1, len(closure_sizes))])
        )
        ch4 = (s % max(1, max_iter + 1)) if data_dep_iter else 0
        return ch1 * 1_000_000 + ch2 * 10_000 + ch3 * 100 + ch4

    return ev.qif_from_traces(
        secrets=secrets,
        observation_fn=obs,
        repeats=1,
        name=str(spec.get("name", "<unnamed>")),
        budget_bits=budget,
    )


def audit_loop(spec: dict) -> LoopAuditRow:
    """Discharge SS Ch1-4 against a single loop spec."""
    ch1 = ev.verify_loop_bound_ni(
        high_drives_bound=bool(spec.get("high_drives_bound", False)),
        low_n_writes=int(spec.get("low_n_writes", 16)),
    )
    ch2 = ev.verify_outer_schedule_ni(
        high_drives_schedule=bool(spec.get("high_drives_sched", False)),
        low_n_runs=int(spec.get("low_n_runs", 4)),
        iters_per_run=int(spec.get("iters_per_run", 10)),
    )
    ch3 = ev.verify_touch_pattern_ni(
        closure_sizes=list(spec.get("closure_sizes", [3, 3, 3, 3])),
        high_drives_touch=bool(spec.get("high_drives_touch", False)),
        low_node=int(spec.get("low_node", 0)),
    )
    ch4 = ev.verify_iteration_bound(
        max_iter=int(spec.get("max_iter", 64)),
    )
    return LoopAuditRow(
        name=str(spec.get("name", "<unnamed>")),
        ch1=ch1, ch2=ch2, ch3=ch3, ch4=ch4,
        source_path=spec.get("source_path"),
        source_lineno=spec.get("source_lineno"),
        source_snippet=spec.get("source_snippet"),
        leak_pattern=spec.get("leak_pattern"),
    )


def _synthetic_obs(
    spec: dict, *, n_secrets: int,
) -> tuple[list[int], "callable"]:
    """Re-build the same synthetic obs function used by
    :func:`_synthetic_qif`, but returned as ``(secrets, obs)`` so it
    can be handed to :func:`ev.verify_qif_leak_bounded` for symbolic
    certification (not just empirical estimation)."""
    high_bound = bool(spec.get("high_drives_bound", False))
    high_sched = bool(spec.get("high_drives_sched", False))
    high_touch = bool(spec.get("high_drives_touch", False))
    data_dep_iter = bool(spec.get("data_dependent_iter", False))
    low_n_writes = int(spec.get("low_n_writes", 16))
    low_n_runs = int(spec.get("low_n_runs", 1))
    iters_per_run = int(spec.get("iters_per_run", 1))
    closure_sizes = list(spec.get("closure_sizes", [3, 3, 3, 3]))
    max_iter = int(spec.get("max_iter", 64))
    low_node = int(spec.get("low_node", 0))

    def obs(s: int) -> int:
        ch1 = (s % max(1, low_n_writes)) if high_bound else low_n_writes
        ch2 = (
            (s % max(1, low_n_runs * iters_per_run))
            if high_sched else low_n_runs * iters_per_run
        )
        ch3 = (
            int(closure_sizes[s % max(1, len(closure_sizes))])
            if high_touch
            else int(closure_sizes[low_node % max(1, len(closure_sizes))])
        )
        ch4 = (s % max(1, max_iter + 1)) if data_dep_iter else 0
        return ch1 * 1_000_000 + ch2 * 10_000 + ch3 * 100 + ch4

    return list(range(n_secrets)), obs


def audit_loop_with_qif(
    spec: dict, *, budget_bits: float, prove: bool = False,
) -> LoopAuditRow:
    """Boolean SS verdict + synthetic QIF in one row.

    When ``prove=True`` we also produce a Z3 certificate of the
    declared budget via ``ev.verify_qif_leak_bounded``. The
    certificate's SMT-LIB body is portable and the attached row
    fails its ``all_pass`` gate if Z3 returns SAT (concrete witness
    of bound violation).
    """
    row = audit_loop(spec)
    row.qif = _synthetic_qif(spec, budget_bits=budget_bits)
    if prove:
        qif_block = dict(spec.get("qif") or {})
        n_secrets = int(qif_block.get("secret_space", 16))
        budget = float(qif_block.get("budget_bits", budget_bits))
        secrets, obs = _synthetic_obs(spec, n_secrets=n_secrets)
        try:
            row.qif_cert = ev.verify_qif_leak_bounded(
                secrets=secrets,
                observation_fn=obs,
                bound_bits=budget,
                name=str(spec.get("name", "<unnamed>")),
            )
        except Exception as exc:  # noqa: BLE001 — surface in table
            print(
                f"    ! QIF cert for "
                f"{spec.get('name', '<unnamed>')!r} failed to build: "
                f"{exc!r}"
            )
            row.qif_cert = None
    return row


# ──────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────
def _print_table(
    rows: list[LoopAuditRow], *, sign: bool, n_queries: int = 1,
) -> None:
    has_qif = any(r.qif is not None for r in rows)
    has_cert = any(r.qif_cert is not None for r in rows)
    if has_qif and has_cert:
        header = (
            f"{'loop':<28s}  {'Ch1':<5}  {'Ch2':<5}  {'Ch3':<5}  "
            f"{'Ch4':<5}  {'bits':>6}  {'xK':>7}  {'cert':<5}  "
            f"{'ms':>7}  verdict"
        )
    elif has_qif:
        header = (
            f"{'loop':<28s}  {'Ch1':<5}  {'Ch2':<5}  {'Ch3':<5}  "
            f"{'Ch4':<5}  {'bits':>6}  {'xK':>7}  {'ms':>7}  verdict"
        )
    else:
        header = (
            f"{'loop':<28s}  {'Ch1':<5}  {'Ch2':<5}  {'Ch3':<5}  "
            f"{'Ch4':<5}  {'ms':>7}  verdict"
        )
    print(header)
    print("─" * len(header))
    for r in rows:
        ok = lambda b: "PASS" if b else "FAIL"  # noqa: E731
        verdict = (
            "CONSTANT-TIME" if r.all_pass else "SIDE-CHANNEL"
        )
        if has_qif and r.qif is not None:
            bits = r.qif.headline_leak_bits
            composed = bits * n_queries
            qif_ok = "≤" if r.qif.safe else ">"
            cert_cell = ""
            if has_cert:
                if r.qif_cert is None:
                    cert_cell = "n/a "
                else:
                    cert_cell = (
                        "PROV " if r.qif_cert.verified else "REFU "
                    )
            print(
                f"{r.name:<28s}  "
                f"{ok(r.ch1.verified):<5}  "
                f"{ok(r.ch2.verified):<5}  "
                f"{ok(r.ch3.verified):<5}  "
                f"{ok(r.ch4.verified):<5}  "
                f"{bits:>5.2f}{qif_ok}  "
                f"{composed:>7.2f}  "
                + (f"{cert_cell:<5}  " if has_cert else "")
                + f"{r.total_ms:>7.3f}  {verdict}"
            )
        else:
            print(
                f"{r.name:<28s}  "
                f"{ok(r.ch1.verified):<5}  "
                f"{ok(r.ch2.verified):<5}  "
                f"{ok(r.ch3.verified):<5}  "
                f"{ok(r.ch4.verified):<5}  "
                f"{r.total_ms:>7.3f}  {verdict}"
            )
        if not r.all_pass:
            for ch_name, res in [("Ch1", r.ch1), ("Ch2", r.ch2),
                                 ("Ch3", r.ch3), ("Ch4", r.ch4)]:
                if not res.verified and res.counterexample is not None:
                    print(f"    ↳ {ch_name} counterexample: {res.counterexample}")
            if r.qif is not None and not r.qif.safe:
                budget = r.qif.budget_bits
                budget_s = (
                    f"{budget:.3f}" if budget is not None else "0"
                )
                print(
                    f"    ↳ QIF: leaked "
                    f"{r.qif.headline_leak_bits:.3f}b headline "
                    f"(budget {budget_s}b, "
                    f"distinct obs = {r.qif.distinct_observations})"
                )
                if r.qif.witness_pair is not None:
                    a, b = r.qif.witness_pair
                    print(
                        f"      witness: secret {a!r} and secret {b!r}"
                        f" produce distinguishable iteration counts"
                    )
            if (
                r.qif_cert is not None and not r.qif_cert.verified
                and r.qif_cert.counterexample is not None
            ):
                cx = r.qif_cert.counterexample
                print(
                    f"    ↳ QIF cert REFUTED: "
                    f"{cx.get('distinct_observations')} distinct obs "
                    f"≥ {cx.get('required_for_violation')} required "
                    f"to violate budget; Z3 witness = "
                    f"indices {cx.get('indices')}  "
                    f"observations {cx.get('observations')}"
                )
    if sign:
        print()
        print(
            "Unified PQC attestations — one signature per loop, "
            "committing to all four SS channel SMT-LIBs as a bundle:"
        )
        for r in rows:
            att = r.attestation
            if att is None:
                continue
            mark = "✓" if att["all_verified"] else "✗"
            print(
                f"  {mark} {r.name:<28s}"
                f"  digest={att['transcript_digest'][:16]}…"
                f"  sig={att['signature'][:16]}…"
                f"  type={att['attestation_type']}"
            )
            for c in att["channels"]:
                cmark = "P" if c["verified"] else "F"
                print(
                    f"      {cmark} {c['name']:<28s}"
                    f" clauses={c['n_clauses']:>3d}"
                    f"  time={c['time_ms']:>6.2f}ms"
                )


def _print_headline(
    rows: list[LoopAuditRow], *, signed: bool,
    sources: list[Path] | None = None,
) -> None:
    """Print the headline claim that ``ct_echo`` reifies.

    This is the block whose words match the launch sentence: every
    audited loop is shown together with the count of SS channels
    discharged, with the unified PQC attestation receipts when
    available. The output is intentionally repetitive — the sentence
    is the artefact.
    """
    n_loops = len(rows)
    n_pass = sum(1 for r in rows if all(
        x.verified for x in (r.ch1, r.ch2, r.ch3, r.ch4)
    ))
    n_channels_total = 4 * n_loops
    n_channels_pass = sum(
        int(x.verified)
        for r in rows
        for x in (r.ch1, r.ch2, r.ch3, r.ch4)
    )
    print()
    print("═" * 72)
    print("HEADLINE")
    print("═" * 72)
    src_clause = ""
    if sources:
        src_names = ", ".join(str(p) for p in sources)
        src_clause = (
            f"\n  Sources audited (real Python, AST-extracted): "
            f"{src_names}"
        )
    print(
        f"  Unified Z3 discharge of all four Sabelfeld-Sands "
        "(SS 2000) iteration-count\n"
        f"  covert channels for {n_loops} loop"
        f"{'s' if n_loops != 1 else ''}: "
        f"{n_channels_pass} / {n_channels_total} channel proofs UNSAT."
        + src_clause,
    )
    if signed:
        n_sig = sum(1 for r in rows if r.attestation is not None)
        att_types = sorted({
            r.attestation["attestation_type"]
            for r in rows if r.attestation is not None
        })
        print(
            f"  {n_sig} unified PQC attestation"
            f"{'s' if n_sig != 1 else ''} issued, one per loop, each "
            f"signature committing\n"
            f"  to all four SS channel SMT-LIBs as one bundle."
        )
        print(f"  attestation_type(s): {', '.join(att_types)}")
    print()
    print(
        f"  Verdict: {n_pass} / {n_loops} loops are iteration-count "
        "non-interfering on every"
    )
    print("           Sabelfeld-Sands channel (Ch1..Ch4 all PROV).")
    print("═" * 72)


def _build_receipt(
    rows: list[LoopAuditRow], *, signed: bool, n_queries: int,
) -> dict:
    """Build a machine-readable JSON receipt for the audit run.

    The receipt is the deliverable shape: an auditor reading
    ``receipt.json`` recovers every (channel, rule, verdict,
    SMT-LIB digest, signature, signer_id) tuple in fixed order
    and can independently re-run the four Z3 checks per loop,
    recompute each bundle's transcript digest, and verify each
    signature against that digest.
    """
    from datetime import datetime, timezone
    loops_out: list[dict] = []
    for r in rows:
        chans = []
        for tag, res in (
            ("ch1.loop_bound_ni", r.ch1),
            ("ch2.outer_schedule_ni", r.ch2),
            ("ch3.touch_pattern_ni", r.ch3),
            ("ch4.iteration_bound", r.ch4),
        ):
            chans.append({
                "channel": tag,
                "rule": res.rule_name,
                "verified": bool(res.verified),
                "n_clauses": int(res.n_clauses),
                "time_ms": float(res.time_ms),
                "smtlib_sha256": _sha256_hex(res.smtlib),
                "counterexample": res.counterexample,
            })
        item = {
            "loop_name": r.name,
            "channels": chans,
            "all_verified": all(
                x.verified for x in (r.ch1, r.ch2, r.ch3, r.ch4)
            ),
            "total_time_ms": float(r.total_ms),
            "source": (
                {
                    "path": r.source_path,
                    "lineno": r.source_lineno,
                    "snippet": r.source_snippet,
                    "leak_pattern": r.leak_pattern,
                }
                if r.source_path is not None else None
            ),
            "bundle": (
                {
                    "transcript_digest": (
                        r.bundle.transcript_digest()
                        if r.bundle is not None else None
                    ),
                }
                if r.bundle is not None else None
            ),
            "attestation": r.attestation,
        }
        if r.qif is not None:
            item["qif"] = {
                "headline_leak_bits": float(r.qif.headline_leak_bits),
                "min_entropy_leak_bits": float(r.qif.min_entropy_leak_bits),
                "shannon_leak_bits": float(r.qif.shannon_leak_bits),
                "distinct_observations": int(r.qif.distinct_observations),
                "budget_bits": (
                    float(r.qif.budget_bits)
                    if r.qif.budget_bits is not None else None
                ),
                "safe": bool(r.qif.safe),
            }
        if r.qif_cert is not None:
            item["qif_cert"] = {
                "rule": r.qif_cert.rule_name,
                "verified": bool(r.qif_cert.verified),
                "time_ms": float(r.qif_cert.time_ms),
                "smtlib_sha256": _sha256_hex(r.qif_cert.smtlib),
            }
        loops_out.append(item)
    n_total = 4 * len(rows)
    n_pass = sum(
        int(x.verified)
        for r in rows
        for x in (r.ch1, r.ch2, r.ch3, r.ch4)
    )
    return {
        "tool": "ct_echo",
        "claim": (
            "Unified Z3 + PQC discharge of all four Sabelfeld-Sands "
            "iteration-count covert channels"
        ),
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "echovalidum_version": getattr(ev, "__version__", "unknown"),
        "n_loops": len(rows),
        "n_channels_total": n_total,
        "n_channels_pass": n_pass,
        "all_loops_pass": n_pass == n_total,
        "signed": signed,
        "n_queries_composed": n_queries,
        "loops": loops_out,
    }


def _sha256_hex(s: str) -> str:
    import hashlib
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _demo_manifest() -> dict:
    """Five-loop example: four clean, one secret-dependent bound.

    The QIF blocks declare ``secret_space`` (size of the candidate
    HIGH set under uniform prior) and a per-loop ``budget_bits``.
    With ``--qif`` the auditor will exercise the synthetic channel
    obs and report bits leaked vs budget.
    """
    return {"loops": [
        {"name": "aes_round_keys",     "low_n_writes": 16,
         "qif": {"secret_space": 16, "budget_bits": 0.0}},
        {"name": "ec_scalar_mul",      "low_n_writes": 256,
         "qif": {"secret_space": 64, "budget_bits": 0.0}},
        {"name": "kyber_ntt",          "low_n_writes": 128,
         "qif": {"secret_space": 32, "budget_bits": 0.0}},
        {"name": "chacha20_block",     "low_n_writes": 20,
         "low_n_runs": 4, "iters_per_run": 20,
         "qif": {"secret_space": 32, "budget_bits": 0.0}},
        {"name": "BAD_secret_compare", "high_drives_bound": True,
         "low_n_writes": 8,
         "qif": {"secret_space": 16, "budget_bits": 0.0}},
    ]}


def main(argv: list[str] | None = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--manifest", type=Path, help="JSON loop manifest")
    g.add_argument("--demo", action="store_true", help="run built-in demo")
    g.add_argument(
        "--source", type=Path, nargs="+", metavar="PATH",
        help="audit every `for` loop in one or more Python source "
             "files; HIGH/LOW labels come from string annotations "
             "(arg: 'HIGH'/'LOW') and from `ct-echo: high(...) "
             "low(...)` markers inside the function docstring",
    )
    ap.add_argument(
        "--high", type=str, default="",
        help="comma-separated names to force-label HIGH "
             "(overrides annotations/docstring)",
    )
    ap.add_argument(
        "--low", type=str, default="",
        help="comma-separated names to force-label LOW "
             "(overrides annotations/docstring)",
    )
    ap.add_argument(
        "--source-function", type=str, default="",
        help="restrict --source audit to a comma-separated list of "
             "function names (default: every top-level def)",
    )
    ap.add_argument("--sign", action="store_true",
                    help="emit PQC attestation per loop")
    ap.add_argument("--qif", action="store_true",
                    help="add quantitative leakage analysis (bits per query)")
    ap.add_argument("--budget", type=float, default=0.0,
                    help="default per-loop QIF budget in bits "
                         "(spec qif.budget_bits overrides; default 0.0)")
    ap.add_argument("--queries", type=int, default=1,
                    help="adaptive query budget K — table shows K·bits "
                         "(linear composition; default 1)")
    ap.add_argument("--prove", action="store_true",
                    help="also build a Z3 certificate of each loop's "
                         "leak bound (implies --qif)")
    ap.add_argument("--receipt", type=Path, default=None,
                    help="write a machine-readable JSON receipt of the "
                         "run to PATH (suitable for pinning under a "
                         "launch post or feeding a downstream policy "
                         "gate)")
    args = ap.parse_args(argv)
    if args.prove and not args.qif:
        args.qif = True

    extracted_loops: list = []
    if args.demo:
        manifest = _demo_manifest()
    elif args.source is not None:
        from applications.ct_echo_ast import (
            extract_loop_specs_from_source,
        )
        oh = {x.strip() for x in args.high.split(",") if x.strip()}
        ol = {x.strip() for x in args.low.split(",") if x.strip()}
        fnames = {
            x.strip() for x in args.source_function.split(",")
            if x.strip()
        }
        all_specs: list[dict] = []
        for src_path in args.source:
            res = extract_loop_specs_from_source(
                src_path,
                override_high=oh,
                override_low=ol,
                function_filter=fnames if fnames else None,
            )
            extracted_loops.extend(res.loops)
            for el in res.loops:
                spec = dict(el.spec)
                spec["source_path"] = el.source_path
                spec["source_lineno"] = el.source_lineno
                spec["source_snippet"] = el.source_snippet
                all_specs.append(spec)
        manifest = {"loops": all_specs}
        print(
            f"Extracted {len(all_specs)} loop(s) from "
            f"{len(args.source)} source file(s):"
        )
        for el in extracted_loops:
            tag = "HIGH" if el.iter_label == "HIGH" else (
                "LOW " if el.iter_label == "LOW" else "?   "
            )
            print(
                f"  [{tag}]  {el.source_path}:{el.source_lineno}"
                f"  {el.source_snippet.strip()}"
            )
        print()
    else:
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))

    if args.qif:
        rows = [
            audit_loop_with_qif(
                spec, budget_bits=args.budget, prove=args.prove,
            )
            for spec in manifest.get("loops", [])
        ]
    else:
        rows = [audit_loop(spec) for spec in manifest.get("loops", [])]

    for r in rows:
        r.build_bundle()
        if args.sign:
            r.attestation = ev.sign_ss_bundle(r.bundle)

    _print_table(rows, sign=args.sign, n_queries=max(1, args.queries))

    failed = [r for r in rows if not r.all_pass]
    print()
    print(f"Audited {len(rows)} loop(s); {len(rows) - len(failed)} pass, "
          f"{len(failed)} fail.")
    if args.qif:
        leaky = [r for r in rows if r.qif is not None and not r.qif.safe]
        if leaky:
            total = sum(
                r.qif.headline_leak_bits for r in leaky if r.qif is not None
            )
            print(
                f"QIF: {len(leaky)} loop(s) over budget; "
                f"sum of headline leakage = {total:.3f} bits/query "
                f"(× {args.queries} queries = "
                f"{total * args.queries:.3f} bits total)."
            )
        else:
            print("QIF: every loop within its leakage budget.")

    _print_headline(
        rows, signed=args.sign,
        sources=args.source if hasattr(args, "source") else None,
    )

    if args.receipt is not None:
        receipt = _build_receipt(
            rows, signed=args.sign, n_queries=max(1, args.queries),
        )
        args.receipt.write_text(
            json.dumps(receipt, indent=2, default=str),
            encoding="utf-8",
        )
        print()
        print(f"Receipt written → {args.receipt}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
