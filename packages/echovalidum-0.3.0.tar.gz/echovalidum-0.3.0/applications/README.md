# Echovalidum — Applications

Five concrete tools built on the public `echovalidum` API. Each is a single
self-contained module (~100–250 lines), and each exists to convert one
Tier-S power of the library into something a non-specialist can install,
run, and ship.

| Tool             | One-liner                                                                | Module                          |
|------------------|--------------------------------------------------------------------------|---------------------------------|
| `ct-echo`        | Constant-time auditor — SS Ch1–4 verdicts per loop in microseconds.      | `applications/ct_echo.py`       |
| `borrowsmith`    | HTTP microservice that returns PQC-signed Cayley disjointness proofs.    | `applications/borrowsmith.py`   |
| `provenance`     | Decorator that turns any function into a signed, trust-propagating trace.| `applications/provenance.py`    |
| `particle-bound` | Particle filter with a Z3-proven, PQC-signed `max_iter` termination bound.| `applications/particle_bound.py`|
| `scale-heap`     | Topological heap profiler that detects anomalies via Euler characteristic.| `applications/scale_heap.py`    |

## Run each one

```powershell
python -m applications.ct_echo        --demo
python -m applications.borrowsmith    --self-test
python -m applications.provenance
python -m applications.particle_bound --max-iter 32 --n-particles 200
python -m applications.scale_heap     --k 8
```

All five depend only on what `pip install "echovalidum[verify]"` already gives
you (echovalidum, numpy, scipy, z3-solver). `borrowsmith` additionally uses
Python's stdlib `http.server`, so there is no extra dependency surface.

## What each tool replaces

- **`ct-echo`** replaces hand-audit of constant-time crypto code. The
  classical alternative is CT-Verif / ct-fuzz / FlowTracker — multi-second runs
  with hand-written annotations. `ct-echo` finishes a four-channel SS audit
  in single-digit milliseconds, end to end.

- **`borrowsmith`** replaces "review every PR for aliasing bugs". A static
  analyzer typically integrates at build time; `borrowsmith` is a 1-ms HTTP
  call you can put on a code-review hook or even on a hot-path runtime check.

- **`provenance`** replaces ad-hoc audit-log scaffolding around ML pipelines.
  Every wrapped call returns a cryptographically signed record of the inputs,
  the propagated trust, and the output cell. The signer ID, signature, and
  timestamp let a downstream consumer independently verify the trace.

- **`particle-bound`** replaces "we set `max_iter` to 64 because it works on
  our data". The library proves the bound holds before any work is done and
  ships the proof alongside the posterior.

- **`scale-heap`** replaces leak counters with topology. χ anomalies catch
  *shape* changes in heap regions — cyclic-leak patterns, fragmentation
  collapses — that byte-counting profilers cannot see.

## Provenance & licence

Same as the parent project — **source-available under PolyForm
Noncommercial 1.0.0**. Free for academic, hobby, and other noncommercial
use; commercial use requires a separate paid licence from the copyright
holder. See the top-level [`LICENSE`](../LICENSE) and [`NOTICE`](../NOTICE).

The names *Echovalidum*, *Σoilith*, *AegisOps*, and the individual tool
names (*ct-echo*, *borrowsmith*, *provenance*, *particle-bound*,
*scale-heap*) are trademarks of Brisen Koch and are not licensed for
derivative product naming. Inquiries: <hello@echovalidum.com>.
