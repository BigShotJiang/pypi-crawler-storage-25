"""applications.examples — real Python loop bodies for ``ct_echo``
to audit via ``--source``."""
