"""
ct_loops — real Python loop examples for ``ct_echo --source``.

The four functions below are written in *runnable Python*, not in
a JSON manifest. Each carries explicit HIGH/LOW string annotations
on its parameters so the AST extractor can taint-classify every
``for`` loop in the file against the four Sabelfeld-Sands
iteration-count covert channels (SS 2000):

  Ch1 — loop bound non-interference
  Ch2 — outer-schedule non-interference
  Ch3 — touch-pattern non-interference
  Ch4 — iteration-bound (a numeric ceiling exists)

Two of the four loops are written to be **iteration-count constant
time** under the declared threat model; the auditor should prove
all four channels for them. The other two are written to leak in
specific, well-understood ways; the auditor should refute the
relevant channel with a concrete Z3 counterexample.

This file imports nothing from ``echovalidum`` — the annotations
are deliberately string literals so the source survives unchanged
in any consumer environment.
"""

from __future__ import annotations


def aes_round_clean(state: "LOW", round_keys: "LOW") -> None:
    """ct-echo: low(state, round_keys)

    16-byte AES-style state XOR with a fixed round key. The loop
    bound (16) is a literal; no index depends on a secret; no
    nesting. Ch1..Ch4 should all PROV."""
    for i in range(16):
        state[i] = state[i] ^ round_keys[i]


def memcmp_naive_leaky(a: "LOW", b: "HIGH") -> bool:
    """ct-echo: high(b) low(a)

    Naïve byte-by-byte compare with an early ``return`` on
    mismatch. The number of iterations executed before the
    early-out depends on the HIGH operand ``b``; the auditor
    should classify this loop as **HIGH-drives-bound** and Ch1
    must REFUTE.

    This is the canonical timing-leak pattern used by every
    constant-time-compare cautionary tale; we keep it here so
    ``ct_echo`` has an actual Python function whose verdict is
    SIDE-CHANNEL, on bytes the user can read and reason about."""
    n = len(a)
    for i in range(n):
        if a[i] != b[i]:
            return False
    return True


def chacha20_nested_clean(state: "LOW") -> None:
    """ct-echo: low(state)

    A ChaCha20-style double round: 10 outer iterations × 4 inner
    quarter-rounds. Both bounds are literals, no array index
    depends on a secret, all touches are on the public state
    array. Ch1..Ch4 should all PROV; Ch2 in particular is the
    interesting one (nested loop, neither bound HIGH-driven)."""
    for _round in range(10):
        for q in range(4):
            state[q] = state[q] + state[(q + 4) % 16]


def square_and_multiply_high_leaky(base: "LOW", exp: "HIGH") -> int:
    """ct-echo: high(exp) low(base)

    Textbook square-and-multiply modular exponentiation: the loop
    bound is ``exp.bit_length()`` — a function of the HIGH secret
    exponent. This is the classical RSA-CRT-style timing leak that
    Kocher 1996 used to recover keys; the auditor should classify
    this as HIGH-drives-bound and Ch1 must REFUTE."""
    result = 1
    width = exp.bit_length()
    for i in range(width):
        result = result * result
        if (exp >> i) & 1:
            result = result * base
    return result
