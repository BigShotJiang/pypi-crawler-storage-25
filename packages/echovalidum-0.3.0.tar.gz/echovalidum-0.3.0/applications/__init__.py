"""Concrete applications built on top of the :mod:`echovalidum` library.

This subpackage ships the public headline tool only:

* :mod:`applications.ct_echo`     — *the* unified Z3 + PQC discharge of
  all four Sabelfeld-Sands (2000) iteration-count covert channels, as a
  CLI. After ``pip install echovalidum`` it is available as the
  ``ct-echo`` console script.
* :mod:`applications.ct_echo_ast` — flow-insensitive HIGH/LOW taint
  propagation over real Python source, used by
  ``ct-echo --source PATH`` to convert ordinary Python ``for`` loops
  into SS-channel specs.
* :mod:`applications.examples.ct_loops` — four real Python loops
  (clean AES round, naive memcmp, nested ChaCha20, square-and-multiply)
  exercised by the documented end-to-end demo in the README.

Other sibling auditors (borrowsmith, provenance, particle_bound,
scale_heap) exist in the development source tree but are NOT shipped
in the public wheel/sdist. They will join the public surface once they
reach the same level of attestation polish as ``ct_echo``.
"""
