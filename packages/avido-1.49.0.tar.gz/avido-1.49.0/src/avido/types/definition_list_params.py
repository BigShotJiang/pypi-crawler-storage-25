# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["DefinitionListParams"]


class DefinitionListParams(TypedDict, total=False):
    definition_status: Annotated[Literal["DRAFT", "ACTIVE"], PropertyInfo(alias="definitionStatus")]
    """Filter by eval definition status (DRAFT or ACTIVE).

    Defaults to ACTIVE when not provided.
    """

    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Field to order by in the result set."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    quickstart_id: Annotated[str, PropertyInfo(alias="quickstartId")]
    """Filter by quickstart ID (for quickstart-scoped evals)"""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    status: Literal["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED", "SKIPPED"]
    """Filter by evaluation status (e.g. COMPLETED)"""

    task_id: Annotated[str, PropertyInfo(alias="taskId")]
    """Filter by task ID"""

    trace_id: Annotated[str, PropertyInfo(alias="traceId")]
    """Filter by trace ID"""

    type: str
    """Filter by evaluation type (e.g. NATURALNESS)"""
