# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["TopicListParams"]


class TopicListParams(TypedDict, total=False):
    is_knowledge_base_verified: Annotated[str, PropertyInfo(alias="isKnowledgeBaseVerified")]
    """Filter topics by knowledge base verification status.

    When true, only returns topics where the knowledge base has been verified. When
    false, only returns unverified topics.
    """

    is_policies_verified: Annotated[str, PropertyInfo(alias="isPoliciesVerified")]
    """Filter topics by policies verification status.

    When true, only returns topics where the policies have been verified. When
    false, only returns unverified topics.
    """

    is_tasks_verified: Annotated[str, PropertyInfo(alias="isTasksVerified")]
    """Filter topics by task verification status.

    When true, only returns topics where all tasks are verified. When false, only
    returns unverified topics.
    """

    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[str, PropertyInfo(alias="orderBy")]
    """Field to order by in the result set."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    title: str
    """Filter by topic title (case-insensitive)"""
