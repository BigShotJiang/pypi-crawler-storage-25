# NMTC Application Builder

**The open-source intelligence platform for competitive CDFI Fund applications.**

[![PyPI version](https://img.shields.io/pypi/v/nmtc-application-builder.svg)](https://pypi.org/project/nmtc-application-builder/)
[![Python](https://img.shields.io/pypi/pyversions/nmtc-application-builder.svg)](https://pypi.org/project/nmtc-application-builder/)
[![Tests](https://img.shields.io/badge/tests-544%20passing-brightgreen.svg)](https://github.com/Jaypatel1511/nmtc-application-builder/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Documentation](https://img.shields.io/badge/docs-GitHub%20Pages-blue.svg)](https://jaypatel1511.github.io/nmtc-application-builder/)

**[Documentation](https://jaypatel1511.github.io/nmtc-application-builder/) · [Streamlit Demo](https://nmtc-application-builder.streamlit.app) · [Examples](examples/) · [PyPI](https://pypi.org/project/nmtc-application-builder/)**

---

CDEs spend months preparing NMTC allocation applications without knowing how their pipeline compares to historical winners. This library changes that — scoring your pipeline against five years of CDFI Fund award data in seconds, generating competition-ready document drafts automatically, and telling you exactly what to fix.

```python
app = Application(cde=CDEProfile.sample(), requested_allocation=65_000_000)
app.add_pipeline(Pipeline.from_csv("pipeline.csv"))
score = app.score_win_probability()
print(f"Alignment: {score.composite_score:.0f}/100 [{score.competitive_tier}]")
# → Alignment: 66/100 [competitive]
paths = app.generate("./drafts/")
# → Word, Excel, PDF, and Markdown application package ready in ./drafts/
```

---

## The Problem

CDE teams preparing NMTC allocation applications work blind. They spend weeks manually assembling pipeline data in Excel, draft narrative sections without knowing how their distress concentration or geographic diversity compares to past winners, and submit applications with no objective measure of competitiveness. The CDFI Fund receives 280–340 applications per round with a ~35% acceptance rate — yet most CDEs have no systematic way to benchmark their position before the deadline.

## The Solution

`nmtc-application-builder` gives CDEs a programmatic intelligence layer built on five years of CDFI Fund public award data. Load your pipeline from CSV, run `analyze()`, and immediately see where you stand on every dimension the CDFI Fund scores: distress concentration, geographic diversity, sector mix, impact intensity, and pipeline quality. Get specific, numbered recommendations. Optimize your project subset automatically. Generate the Word, Excel, PDF, and Markdown drafts that go directly into your application package.

---

## Quickstart

```bash
pip install nmtc-application-builder[output,viz]
```

```python
from nmtcapp import Application, CDEProfile, Pipeline
from nmtcapp.optimizer import OptimizationConstraints

# 1. Define your CDE
cde = CDEProfile.sample()                           # or CDEProfile.from_yaml("cde.yaml")

# 2. Load your pipeline
pipeline = Pipeline.from_csv("pipeline.csv")        # or Pipeline.sample(n=20) for demo

# 3. Analyze
app = Application(cde=cde, requested_allocation=65_000_000)
app.add_pipeline(pipeline)
analysis = app.analyze()
analysis.summary()

# 4. Score alignment with historical winners
score = app.score_win_probability()                 # alignment score, not win probability
print(f"{score.composite_score:.0f}/100 [{score.competitive_tier}]")

# 5. Get quantified recommendations
recs = app.recommendations()
print(recs.summary())

# 6. Optimize your pipeline subset
result = app.optimize_pipeline(
    constraints=OptimizationConstraints(max_total_qei=65_000_000, min_states=5)
)
print(f"Score: {result.alignment_score_before*100:.0f} → {result.alignment_score_after*100:.0f}")

# 7. Generate the full application package
paths = app.generate("./drafts/")
```

Or bootstrap a starter project in 60 seconds:

```bash
nmtcapp init my-application/
cd my-application/
jupyter notebook analysis.ipynb
```

---

## What It Does

- **Pipeline ingestion** — Load from CSV or build programmatically; validates all required fields
- **NMTC eligibility enrichment** — Census tract lookup, distress level classification (deep / severe / LIC), opportunity zone and native area flags
- **Distress concentration analysis** — Deep/severe QEI percentage vs. CDFI Fund competitive thresholds (target: ≥75%)
- **Geographic diversity scoring** — State count, HHI concentration index, urban/rural split
- **Sector mix analysis** — Shannon entropy, dominant sector, high-priority sector alignment
- **Impact projection** — Jobs per $MM QEI benchmarked against historical winner distributions
- **Win alignment scoring** — 5-dimensional score (0–100) against CY2020–2024 winner patterns
- **Quantified recommendations** — Specific, numbered improvement actions per dimension with estimated score impact
- **Pipeline optimizer** — Greedy + local-search selects the best project subset for your target budget
- **Output generation** — Word, Excel, PDF, and Markdown application drafts in one call
- **Geographic visualizations** — Publication-quality pipeline maps, radar charts, and benchmark plots at 300 DPI
- **CLI** — `nmtcapp init` / `nmtcapp analyze` for quick command-line workflows

> **Methodology note:** Alignment scores measure similarity to historical winner patterns — they are not win probabilities. The CDFI Fund does not publish rejected application data, so a true probability model cannot be built from public information alone.

---

## Sample Output Gallery

Generated outputs are in [`examples/sample_output/`](examples/sample_output/) — Word, Excel, PDF, and Markdown for a realistic sample CDE application.

The three example notebooks tell a complete story:

| Notebook | What it demonstrates |
|---|---|
| [01_quickstart.ipynb](examples/01_quickstart.ipynb) | End-to-end workflow in 10 minutes |
| [02_full_application_walkthrough.ipynb](examples/02_full_application_walkthrough.ipynb) | Complete document generation |
| [03_intelligence_and_optimization.ipynb](examples/03_intelligence_and_optimization.ipynb) | **5.5 → 65.9 → 79.1/100** — weak→competitive pipeline transformation |

---

## Architecture

```
nmtc-application-builder/
├── nmtcapp/
│   ├── core/               Application · CDEProfile · Pipeline
│   ├── intelligence/       PipelineAnalyzer · WinProbabilityModel · RecommendationEngine
│   ├── optimizer/          PipelineOptimizer · CandidatePool · Objectives
│   ├── validation/         EligibilityCheck · CompletenessCheck · ReadinessScore
│   ├── integrations/       nmtc-mapper · nmtc-calc · cdfidata · impact-ledger
│   ├── visualization/      pipeline maps · distress heatmap · radar · alignment charts
│   ├── renderers/          Word · Excel · PDF · Markdown builders
│   ├── data/               historical awards · benchmark thresholds · schema
│   └── cli.py              nmtcapp init / analyze / version
├── examples/               3 executed Jupyter notebooks + sample output
├── streamlit_app/          Interactive web demo (4 pages)
├── templates/              pipeline_template.csv · cde_profile_template.yaml
└── docs/                   MkDocs documentation site
```

### Built on the Open-Source CDFI Analytics Stack

This library integrates six companion libraries built for the CDFI space:

| Library | Role in this project |
|---|---|
| `nmtc-mapper` | Census tract geocoding and eligibility classification (deep / severe / LIC) |
| `nmtc-calc` | NMTC leveraged deal economics (QEI → NMTCs → investor equity) |
| `cdfidata` | CDFI Fund TLR/CLR/Awards ETL and dataset loader |
| `impact-ledger` | Portfolio-level impact tracking by sector |
| `hmda-analyzer` | HMDA CRA assessment data integration |
| `cra-scraper` | Community Reinvestment Act data extraction |

---

## Use Cases

**CDE application teams** — Run `analyze()` on your pipeline weekly during application season. Watch your readiness score improve as you add projects and address recommendations. Generate the first draft of every section automatically.

**CDFI consultants** — Drop a client's pipeline CSV in and produce a competitive benchmark report in minutes. Show exactly where they stand vs. historical winners before committing to a full engagement.

**Researchers and policy analysts** — Query the embedded CY2020–2024 CDFI Fund award statistics. Study what differentiates winning applications across distress concentration, geographic reach, and impact intensity.

**CDEs evaluating pipeline strategy** — Use the optimizer to understand what subset of your project pipeline maximizes competitive alignment given a target allocation amount and diversity constraints.

---

## Limitations & Honest Disclosures

- **Not a win probability model.** Alignment score ≠ probability of receiving an allocation. The CDFI Fund does not publish rejected application data, so a calibrated probability model cannot be built from public information alone.
- **Historical patterns, not current NOFA.** Benchmarks derive from CY2020–2024 award data. CDFI Fund priorities shift — always check the current NOFA for updated criteria.
- **Approximate geographic data.** Pipeline maps use state centroids, not actual project addresses. Eligibility enrichment uses `nmtc-mapper` and falls back to embedded sample data when offline.
- **Not a substitute for expert review.** Always have a qualified CDFI practitioner or attorney review application materials before submission.
- **No investor or underwriting analysis.** This library covers competitive positioning, not deal structuring, investor sourcing, or legal compliance.

---

## Documentation

Full documentation at **[jaypatel1511.github.io/nmtc-application-builder](https://jaypatel1511.github.io/nmtc-application-builder/)**

- [Installation guide](https://jaypatel1511.github.io/nmtc-application-builder/installation/)
- [60-second quickstart](https://jaypatel1511.github.io/nmtc-application-builder/quickstart/)
- [Pipeline analysis workflow](https://jaypatel1511.github.io/nmtc-application-builder/workflow/pipeline-analysis/)
- [Win alignment scoring & methodology](https://jaypatel1511.github.io/nmtc-application-builder/workflow/win-alignment/)
- [Full API reference](https://jaypatel1511.github.io/nmtc-application-builder/reference/api/)
- [Honest limitations](https://jaypatel1511.github.io/nmtc-application-builder/about/limitations/)

---

## Contributing

Contributions welcome — bug fixes, additional data sources, visualization improvements, and documentation all help.

```bash
git clone https://github.com/Jaypatel1511/nmtc-application-builder.git
cd nmtc-application-builder
pip install -e ".[dev]"
PYTHONPATH=. pytest tests/ -v          # 544 tests, should all pass
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on pull requests, code style, and issue reporting.

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

*Built by [Jay Patel](https://github.com/Jaypatel1511) as part of an open-source CDFI analytics portfolio. Not affiliated with the CDFI Fund or the US Treasury.*
