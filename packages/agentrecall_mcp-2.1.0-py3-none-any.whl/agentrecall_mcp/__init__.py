"""AgentRecall MCP Server — Persistent memory for AI agents via MCP."""

from .server import __version__

__all__ = ["__version__"]
