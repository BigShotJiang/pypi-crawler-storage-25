"""AgentRecall MCP Server.

Exposes AgentRecall's memory API as MCP tools for Claude Code, Hermes Agent,
OpenClaw, and any MCP-compatible client.

Each API key is bound to ONE agent — no agent resolution needed.

Usage:
    AGENTRECALL_API_KEY=ark_xxx agentrecall-mcp
"""

import asyncio
import json
import os
import sys
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

__version__ = "2.0.0"

# ── Configuration ──────────────────────────────────────────────────────────

API_KEY = os.environ.get("AGENTRECALL_API_KEY", "")
API_URL = os.environ.get("AGENTRECALL_API_URL", "https://api.agentrecall.cloud/v1")

# ── HTTP Client ────────────────────────────────────────────────────────────

_client: httpx.AsyncClient | None = None


def get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        headers = {}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"
        _client = httpx.AsyncClient(base_url=API_URL, headers=headers, timeout=30.0)
    return _client


async def api_get(path: str, params: dict | None = None) -> Any:
    r = await get_client().get(path, params=params)
    r.raise_for_status()
    return r.json()


async def api_post(path: str, data: dict | None = None) -> Any:
    r = await get_client().post(path, json=data)
    r.raise_for_status()
    return r.json()


async def api_put(path: str, data: dict | None = None) -> Any:
    r = await get_client().put(path, json=data)
    r.raise_for_status()
    return r.json()


async def api_delete(path: str) -> Any:
    r = await get_client().delete(path)
    r.raise_for_status()
    return r.json()


# ── MCP Server ─────────────────────────────────────────────────────────────

server = Server("agentrecall")

TOOLS: list[Tool] = [
    Tool(
        name="store_memory",
        description="Store a memory. Auto-classified by AI into categories (preference, correction, temporal, factual, general). Memories are enriched with entities and relationships.",
        inputSchema={
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The memory text to store"},
                "category": {"type": "string", "enum": ["preference", "correction", "temporal", "factual", "general"], "description": "Auto-classified if omitted"},
                "importance": {"type": "string", "enum": ["high", "medium", "low"], "default": "medium"},
                "metadata": {"type": "object", "description": "Custom key-value pairs"},
            },
            "required": ["content"],
        },
    ),
    Tool(
        name="search_memories",
        description="Semantic search across memories. Finds by meaning, not keywords. Returns results ranked by relevance, importance, and recency.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural language search query"},
                "category": {"type": "string", "enum": ["preference", "correction", "temporal", "factual", "general"]},
                "limit": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="get_memory",
        description="Get a single memory by ID.",
        inputSchema={"type": "object", "properties": {"memory_id": {"type": "integer"}}, "required": ["memory_id"]},
    ),
    Tool(
        name="update_memory",
        description="Update memory content.",
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {"type": "integer"},
                "content": {"type": "string", "description": "New content"},
            },
            "required": ["memory_id", "content"],
        },
    ),
    Tool(
        name="delete_memory",
        description="Permanently delete a memory.",
        inputSchema={"type": "object", "properties": {"memory_id": {"type": "integer"}}, "required": ["memory_id"]},
    ),
    Tool(
        name="list_memories",
        description="List memories for this agent.",
        inputSchema={
            "type": "object",
            "properties": {
                "category": {"type": "string", "enum": ["preference", "correction", "temporal", "factual", "general"]},
                "limit": {"type": "integer", "default": 20},
            },
        },
    ),
    Tool(
        name="count_memories",
        description="Count total memories for this agent.",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="traverse_graph",
        description="Traverse the knowledge graph. Follow entity relationships to find connections across memories.",
        inputSchema={
            "type": "object",
            "properties": {
                "entity": {"type": "string", "description": "Starting entity name"},
                "depth": {"type": "integer", "default": 2, "description": "Traversal depth 1-5"},
            },
            "required": ["entity"],
        },
    ),
    Tool(
        name="get_graph_stats",
        description="Graph statistics: entity counts, relationship counts, top entities.",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="find_graph_path",
        description="Find shortest path between two entities in the knowledge graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "from_entity": {"type": "string"},
                "to_entity": {"type": "string"},
                "max_depth": {"type": "integer", "default": 5},
            },
            "required": ["from_entity", "to_entity"],
        },
    ),
    Tool(
        name="get_graph_context",
        description="Get graph context for a natural language query: related entities, memories, and connections.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="list_agents",
        description="List agents accessible with this token (usually just one).",
        inputSchema={"type": "object", "properties": {}},
    ),
]


def _fmt_memory(m: dict) -> str:
    lines = [f"[{m.get('id')}] {m.get('content', '')[:200]}"]
    meta = []
    if m.get("category"):
        meta.append(f"cat={m['category']}")
    if m.get("importance"):
        meta.append(f"imp={m['importance']}")
    if m.get("score") is not None:
        meta.append(f"score={m['score']:.2f}")
    if meta:
        lines.append(f"  ({', '.join(meta)})")
    return "\n".join(lines)


async def handle_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle MCP tool calls.

    No agent_id resolution needed — the API key token is bound to one agent.
    The server infers agent_id from the token automatically.
    """
    try:
        if name == "store_memory":
            data = {"content": arguments["content"]}
            if arguments.get("category"):
                data["category"] = arguments["category"]
            if arguments.get("importance"):
                data["importance"] = arguments["importance"]
            if arguments.get("metadata"):
                data["metadata"] = arguments["metadata"]
            result = await api_post("/memories", data)
            return [TextContent(type="text", text=f"Memory stored: [{result['id']}] {result['content'][:150]}")]

        elif name == "search_memories":
            params = {"query": arguments["query"]}
            if arguments.get("category"):
                params["category"] = arguments["category"]
            if arguments.get("limit"):
                params["limit"] = arguments["limit"]
            results = await api_get("/memories/recall", params)
            if not results:
                return [TextContent(type="text", text="No memories found.")]
            lines = [f"Found {len(results)} memories:\n"]
            for r in results:
                lines.append(_fmt_memory(r))
                lines.append("")
            return [TextContent(type="text", text="\n".join(lines))]

        elif name == "get_memory":
            result = await api_get(f"/memories/{arguments['memory_id']}")
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "update_memory":
            await api_put(f"/memories/{arguments['memory_id']}", {"content": arguments["content"]})
            return [TextContent(type="text", text=f"Memory {arguments['memory_id']} updated.")]

        elif name == "delete_memory":
            await api_delete(f"/memories/{arguments['memory_id']}")
            return [TextContent(type="text", text=f"Memory {arguments['memory_id']} deleted.")]

        elif name == "list_memories":
            params = {}
            if arguments.get("category"):
                params["category"] = arguments["category"]
            if arguments.get("limit"):
                params["limit"] = arguments["limit"]
            results = await api_get("/memories", params)
            if not results:
                return [TextContent(type="text", text="No memories found.")]
            lines = [f"Found {len(results)} memories:\n"]
            for m in results:
                lines.append(_fmt_memory(m))
                lines.append("")
            return [TextContent(type="text", text="\n".join(lines))]

        elif name == "count_memories":
            result = await api_get("/agents")
            if result:
                agent = result[0]  # API key is bound to one agent
                return [TextContent(type="text", text=f"Agent '{agent['name']}' has {agent.get('memory_count', 0)} memories.")]
            return [TextContent(type="text", text="No agent found.")]

        elif name == "traverse_graph":
            result = await api_get(
                f"/graph/entities/{arguments['entity']}/neighbors",
                {"depth": arguments.get("depth", 2)},
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "get_graph_stats":
            result = await api_get("/graph/stats")
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "find_graph_path":
            result = await api_get(
                "/graph/paths",
                {"from": arguments["from_entity"], "to": arguments["to_entity"], "max_depth": arguments.get("max_depth", 5)},
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "get_graph_context":
            result = await api_get(
                "/graph/context",
                {"query": arguments["query"], "limit": arguments.get("limit", 10)},
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "list_agents":
            results = await api_get("/agents")
            if not results:
                return [TextContent(type="text", text="No agents found.")]
            lines = ["Agents:\n"]
            for a in results:
                lines.append(f"  {a['name']} — {a.get('memory_count', 0)} memories (id: {a['id']})")
            return [TextContent(type="text", text="\n".join(lines))]

        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"API error ({e.response.status_code}): {e.response.text[:500]}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


# ── Server Setup ───────────────────────────────────────────────────────────


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    return await handle_tool(name, arguments)


async def run():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main():
    if not API_KEY:
        print("Warning: AGENTRECALL_API_KEY not set.", file=sys.stderr)
    asyncio.run(run())


if __name__ == "__main__":
    main()
