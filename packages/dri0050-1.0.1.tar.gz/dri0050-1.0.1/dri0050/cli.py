"""Command-line interface for DRI0050 driver."""

import argparse
from dri0050.driver import DRI0050


def main_info():
    """CLI entry point: read and display device info."""
    parser = argparse.ArgumentParser(description="DRI0050 device info")
    parser.add_argument("port", help="Serial port (e.g. /dev/ttyUSB0, COM3)")
    parser.add_argument("--slave", type=int, default=0x32, help="MODBUS slave address (default: 0x32)")
    parser.add_argument("--baudrate", type=int, default=9600, help="Baud rate (default: 9600)")
    args = parser.parse_args()

    with DRI0050(port=args.port, slave=args.slave, baudrate=args.baudrate) as drv:
        info = drv.info()
        print("DRI0050 Device Information")
        print("-" * 30)
        print(f"  PID:     0x{info['pid']:04X}")
        print(f"  VID:     0x{info['vid']:04X}")
        print(f"  Address: 0x{info['addr']:02X}")
        print(f"  Version: 0x{info['version']:x}")
        print(f"  Freq:    {info['freq_hz']} Hz")
        print(f"  Duty:    {info['duty']:.2%} (raw={info['duty_raw']})")
        print(f"  Enable:  {info['enable']}")


def main_pwm():
    """CLI entry point: set PWM parameters."""
    parser = argparse.ArgumentParser(description="DRI0050 PWM control")
    parser.add_argument("port", help="Serial port (e.g. /dev/ttyUSB0, COM3)")
    parser.add_argument("--freq", type=int, help="PWM frequency in Hz (183-46875)")
    parser.add_argument("--duty", type=float, help="Duty cycle 0.0-1.0")
    parser.add_argument("--enable", type=int, choices=[0, 1], help="Enable output (0=off, 1=on)")
    parser.add_argument("--slave", type=int, default=0x32, help="MODBUS slave address (default: 0x32)")
    parser.add_argument("--baudrate", type=int, default=9600, help="Baud rate (default: 9600)")
    args = parser.parse_args()

    with DRI0050(port=args.port, slave=args.slave, baudrate=args.baudrate) as drv:
        if args.freq is not None:
            drv.set_freq(args.freq)
        if args.duty is not None:
            drv.set_duty(args.duty)
        if args.enable is not None:
            drv.set_enable(bool(args.enable))
        print(f"freq={drv.get_freq()}Hz  duty={drv.get_duty():.2f}  enable={drv.get_enable()}")
