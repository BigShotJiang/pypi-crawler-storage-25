"""DRI0050 PWM Driver - MODBUS RTU communication using modbus_tk.

This is the direct-control driver matching the official DFRobot example.
Uses modbus_tk (the library recommended in the DRI0050 wiki) instead of
minimalmodbus.

MODBUS Register Map (Holding Registers):
    Reg 0 (0x00): PID          (read-only)  - Product ID
    Reg 1 (0x01): VID          (read-only)  - Vendor ID
    Reg 2 (0x02): Address      (read-only)  - MODBUS slave address
    Reg 5 (0x05): Version      (read-only)  - Firmware version
    Reg 6 (0x06): Duty         (read/write) - PWM duty 0-255 (0%=0, 100%=255)
    Reg 7 (0x07): Frequency    (read/write) - Prescaler value, freq = 12MHz/256/(val+1)
    Reg 8 (0x08): Enable       (read/write) - Output enable (0=off, 1=on)

Default slave address: 0x32 (50)
Default baudrate: 9600
"""

import time
import serial
import modbus_tk.defines as cst
from modbus_tk import modbus_rtu

from dri0050.driver import (
    freq_to_prescaler,
    FREQ_MIN,
    FREQ_MAX,
    DUTY_MIN,
    DUTY_MAX,
    DEFAULT_SLAVE_ADDRESS,
    DEFAULT_BAUDRATE,
)

PID_REG = 0x00
VID_REG = 0x01
ADDR_REG = 0x02
VER_REG = 0x05
DUTY_REG = 0x06
FREQ_REG = 0x07
PWM_EN_REG = 0x08


class DRI0050ModbusTK:
    """Driver for DFRobot DRI0050 using modbus_tk (official DFRobot approach).

    Communicates via MODBUS RTU over a serial (USB/UART) connection.
    This driver matches the official DFRobot example code and uses
    the modbus_tk library recommended in the product wiki.

    Args:
        port: Serial port path, e.g. ``/dev/ttyUSB0`` (Linux/Mac)
              or ``COM3`` (Windows).
        slave: MODBUS slave address. Default 0x32 (50).
        baudrate: Serial baud rate. Default 9600.
        timeout: MODBUS response timeout in seconds. Default 5.0.

    Example::

        driver = DRI0050ModbusTK(port="/dev/ttyUSB0")
        driver.set_freq(1000)
        driver.set_duty(0.5)
        driver.set_enable(1)
    """

    def __init__(
        self,
        port: str,
        slave: int = DEFAULT_SLAVE_ADDRESS,
        baudrate: int = DEFAULT_BAUDRATE,
        timeout: float = 5.0,
    ):
        self._slave = slave
        self._ser = serial.Serial(
            port=port,
            baudrate=baudrate,
            bytesize=8,
            parity="N",
            stopbits=1,
        )
        self._master = modbus_rtu.RtuMaster(self._ser)
        self._master.set_timeout(timeout)
        time.sleep(0.5)

    # -- Read operations ---------------------------------------------------

    def get_pid(self) -> int:
        """Read Product ID (register 0x00)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, PID_REG, 1)
        time.sleep(0.03)
        return data[0]

    def get_vid(self) -> int:
        """Read Vendor ID (register 0x01)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, VID_REG, 1)
        time.sleep(0.03)
        return data[0]

    def get_addr(self) -> int:
        """Read MODBUS slave address (register 0x02)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, ADDR_REG, 1)
        time.sleep(0.03)
        return data[0]

    def get_version(self) -> int:
        """Read firmware version (register 0x05)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, VER_REG, 1)
        time.sleep(0.03)
        return data[0]

    def get_duty(self) -> float:
        """Read PWM duty cycle as a float 0.0-1.0 (register 0x06)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, DUTY_REG, 1)
        time.sleep(0.03)
        return data[0] / 255

    def get_duty_raw(self) -> int:
        """Read PWM duty cycle as raw register value 0-255 (register 0x06)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, DUTY_REG, 1)
        time.sleep(0.03)
        return data[0]

    def get_freq(self) -> int:
        """Read PWM frequency in Hz (register 0x07, converted from prescaler)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, FREQ_REG, 1)
        time.sleep(0.03)
        return int(12 * 1000 * 1000 / 256 / (data[0] + 1))

    def get_freq_raw(self) -> int:
        """Read raw frequency prescaler value (register 0x07)."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, FREQ_REG, 1)
        time.sleep(0.03)
        return data[0]

    def get_enable(self) -> int:
        """Read output enable state (register 0x08). Returns 0 or 1."""
        data = self._master.execute(self._slave, cst.READ_HOLDING_REGISTERS, PWM_EN_REG, 1)
        time.sleep(0.03)
        return data[0]

    # -- Write operations --------------------------------------------------

    def set_duty(self, duty: float) -> None:
        """Set PWM duty cycle.

        Args:
            duty: Duty cycle as float 0.0 (0%) to 1.0 (100%).
        """
        if not (DUTY_MIN <= duty <= DUTY_MAX):
            raise ValueError(f"Duty must be between {DUTY_MIN} and {DUTY_MAX}, got {duty}")
        self._master.execute(
            self._slave, cst.WRITE_SINGLE_REGISTER, DUTY_REG, output_value=int(duty * 255)
        )
        time.sleep(0.03)

    def set_duty_raw(self, raw: int) -> None:
        """Set PWM duty cycle as raw register value.

        Args:
            raw: Duty value 0-255.
        """
        if not (0 <= raw <= 255):
            raise ValueError(f"Raw duty must be between 0 and 255, got {raw}")
        self._master.execute(self._slave, cst.WRITE_SINGLE_REGISTER, DUTY_REG, output_value=raw)
        time.sleep(0.03)

    def set_freq(self, freq: int) -> None:
        """Set PWM frequency in Hz.

        Args:
            freq: Frequency in Hz (183 - 46875). For values above 2kHz
                  only discrete steps are possible — see HIGH_FREQ_TABLE.
        """
        if not (FREQ_MIN <= freq <= FREQ_MAX):
            raise ValueError(f"Frequency must be between {FREQ_MIN} and {FREQ_MAX} Hz, got {freq}")
        prescaler = freq_to_prescaler(freq)
        self._master.execute(
            self._slave, cst.WRITE_SINGLE_REGISTER, FREQ_REG, output_value=prescaler
        )
        time.sleep(0.03)

    def set_freq_raw(self, prescaler: int) -> None:
        """Set raw frequency prescaler register value."""
        self._master.execute(
            self._slave, cst.WRITE_SINGLE_REGISTER, FREQ_REG, output_value=prescaler
        )
        time.sleep(0.03)

    def set_enable(self, enable: int) -> None:
        """Enable or disable PWM output.

        Args:
            enable: 1 to enable, 0 to disable.
        """
        self._master.execute(
            self._slave, cst.WRITE_SINGLE_REGISTER, PWM_EN_REG, output_value=enable
        )
        time.sleep(0.03)

    # -- Convenience -------------------------------------------------------

    def pwm(self, freq: int, duty: float) -> None:
        """Set frequency and duty cycle atomically using WRITE_MULTIPLE_REGISTERS.

        Writes both duty and freq prescaler in a single MODBUS transaction.

        Args:
            freq: PWM frequency in Hz (183 - 46875).
            duty: Duty cycle as float 0.0-1.0.
        """
        v = [int(duty * 255), freq_to_prescaler(freq)]
        self._master.execute(
            self._slave, cst.WRITE_MULTIPLE_REGISTERS, DUTY_REG, output_value=v
        )
        time.sleep(0.03)

    def factory_reset(self) -> None:
        """Restore factory defaults: 366Hz, 50% duty, output disabled."""
        self.pwm(freq=366, duty=0.5)
        self.set_enable(0)

    def info(self) -> dict:
        """Read all device information as a dictionary."""
        return {
            "pid": self.get_pid(),
            "vid": self.get_vid(),
            "addr": self.get_addr(),
            "version": self.get_version(),
            "freq_hz": self.get_freq(),
            "duty": round(self.get_duty(), 4),
            "duty_raw": self.get_duty_raw(),
            "enable": self.get_enable(),
        }

    def close(self) -> None:
        """Close the serial connection."""
        self._ser.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def __repr__(self) -> str:
        return (
            f"DRI0050ModbusTK(port={self._ser.port!r}, "
            f"slave=0x{self._slave:02x}, "
            f"baudrate={self._ser.baudrate})"
        )
