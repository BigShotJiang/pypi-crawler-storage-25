"""DRI0050 PWM Driver - MODBUS RTU communication over serial.

This module provides a standalone Python driver for the DFRobot DRI0050
PWM Motor/LED controller using the MODBUS RTU protocol. No dependency on
the pinpong library is required.

MODBUS Register Map (Holding Registers):
    Reg 0: PID          (read-only)  - Product ID
    Reg 1: VID          (read-only)  - Vendor ID
    Reg 2: Address      (read-only)  - MODBUS slave address
    Reg 5: Version      (read-only)  - Firmware version
    Reg 6: Duty         (read/write) - PWM duty 0-255 (0%=0, 100%=255)
    Reg 7: Frequency    (read/write) - Prescaler value, freq = 12MHz/256/(val+1)
    Reg 8: Enable       (read/write) - Output enable (0=off, 1=on)

Default slave address: 0x32 (50)
Default baudrate: 9600
"""

import time
import minimalmodbus


# Valid PWM frequency values above 2kHz (discrete steps due to prescaler)
HIGH_FREQ_TABLE = [
    46875, 23437, 15625, 11718,
    9375, 7812, 6696, 5859, 5208, 4687, 4261,
    3906, 3605, 3348, 3125,
    2929, 2757, 2604, 2467, 2343, 2232, 2130, 2038,
]

FREQ_MIN = 183
FREQ_MAX = 46875
DUTY_MIN = 0.0
DUTY_MAX = 1.0

DEFAULT_SLAVE_ADDRESS = 0x32
DEFAULT_BAUDRATE = 9600

REG_PID = 0
REG_VID = 1
REG_ADDR = 2
REG_VERSION = 5
REG_DUTY = 6
REG_FREQ = 7
REG_ENABLE = 8


def freq_to_prescaler(freq: int) -> int:
    """Convert frequency in Hz to MODBUS prescaler register value.

    Formula: prescaler = (12_000_000 / 256 / freq) - 1
    """
    return int(12_000_000 / 256 / freq) - 1


def prescaler_to_freq(prescaler: int) -> int:
    """Convert MODBUS prescaler register value to frequency in Hz.

    Formula: freq = 12_000_000 / 256 / (prescaler + 1)
    """
    return int(12_000_000 / 256 / (prescaler + 1))


def nearest_valid_freq(freq: int) -> int:
    """Return the nearest valid frequency for the hardware prescaler.

    For frequencies <= 2kHz the prescaler provides fine granularity.
    For frequencies > 2kHz, only discrete values in HIGH_FREQ_TABLE
    are achievable.
    """
    if freq <= 2000:
        return freq
    best = min(HIGH_FREQ_TABLE, key=lambda f: abs(f - freq))
    return best


class DRI0050:
    """Driver for DFRobot DRI0050 PWM Motor/LED Controller.

    Communicates via MODBUS RTU over a serial (USB/UART) connection.

    Args:
        port: Serial port path, e.g. ``/dev/ttyUSB0`` (Linux/Mac)
              or ``COM3`` (Windows).
        slave: MODBUS slave address. Default 0x32 (50).
        baudrate: Serial baud rate. Default 9600.
        timeout: MODBUS response timeout in seconds. Default 1.0.

    Example::

        driver = DRI0050(port="/dev/ttyUSB0")
        driver.set_freq(1000)
        driver.set_duty(0.5)
        driver.set_enable(True)
    """

    def __init__(
        self,
        port: str,
        slave: int = DEFAULT_SLAVE_ADDRESS,
        baudrate: int = DEFAULT_BAUDRATE,
        timeout: float = 1.0,
    ):
        self._instrument = minimalmodbus.Instrument(
            port, slaveaddress=slave
        )
        self._instrument.serial.baudrate = baudrate
        self._instrument.serial.bytesize = 8
        self._instrument.serial.parity = minimalmodbus.serial.PARITY_NONE
        self._instrument.serial.stopbits = 1
        self._instrument.serial.timeout = timeout
        self._slave = slave

    # -- Read operations ---------------------------------------------------

    def get_pid(self) -> int:
        """Read Product ID (register 0)."""
        return self._instrument.read_register(REG_PID)

    def get_vid(self) -> int:
        """Read Vendor ID (register 1)."""
        return self._instrument.read_register(REG_VID)

    def get_addr(self) -> int:
        """Read MODBUS slave address (register 2)."""
        return self._instrument.read_register(REG_ADDR)

    def get_version(self) -> int:
        """Read firmware version (register 5)."""
        return self._instrument.read_register(REG_VERSION)

    def get_duty(self) -> float:
        """Read PWM duty cycle as a float 0.0-1.0 (register 6)."""
        raw = self._instrument.read_register(REG_DUTY)
        return raw / 255.0

    def get_duty_raw(self) -> int:
        """Read PWM duty cycle as raw register value 0-255 (register 6)."""
        return self._instrument.read_register(REG_DUTY)

    def get_freq(self) -> int:
        """Read PWM frequency in Hz (register 7, converted from prescaler)."""
        prescaler = self._instrument.read_register(REG_FREQ)
        return prescaler_to_freq(prescaler)

    def get_freq_raw(self) -> int:
        """Read raw frequency prescaler value (register 7)."""
        return self._instrument.read_register(REG_FREQ)

    def get_enable(self) -> bool:
        """Read output enable state (register 8). Returns True if enabled."""
        return bool(self._instrument.read_register(REG_ENABLE))

    # -- Write operations --------------------------------------------------

    def set_duty(self, duty: float) -> None:
        """Set PWM duty cycle.

        Args:
            duty: Duty cycle as float 0.0 (0%) to 1.0 (100%).
        """
        if not (DUTY_MIN <= duty <= DUTY_MAX):
            raise ValueError(f"Duty must be between {DUTY_MIN} and {DUTY_MAX}, got {duty}")
        raw = int(duty * 255)
        self._instrument.write_register(REG_DUTY, raw)
        time.sleep(0.03)

    def set_duty_raw(self, raw: int) -> None:
        """Set PWM duty cycle as raw register value.

        Args:
            raw: Duty value 0-255.
        """
        if not (0 <= raw <= 255):
            raise ValueError(f"Raw duty must be between 0 and 255, got {raw}")
        self._instrument.write_register(REG_DUTY, raw)
        time.sleep(0.03)

    def set_freq(self, freq: int) -> None:
        """Set PWM frequency in Hz.

        Args:
            freq: Frequency in Hz (183 - 46875). For values above 2kHz
                  only discrete steps are possible — see HIGH_FREQ_TABLE.
        """
        if not (FREQ_MIN <= freq <= FREQ_MAX):
            raise ValueError(f"Frequency must be between {FREQ_MIN} and {FREQ_MAX} Hz, got {freq}")
        prescaler = freq_to_prescaler(freq)
        self._instrument.write_register(REG_FREQ, prescaler)
        time.sleep(0.03)

    def set_freq_raw(self, prescaler: int) -> None:
        """Set raw frequency prescaler register value.

        Args:
            prescaler: Prescaler value. freq = 12MHz / 256 / (prescaler+1)
        """
        self._instrument.write_register(REG_FREQ, prescaler)
        time.sleep(0.03)

    def set_enable(self, enable: bool) -> None:
        """Enable or disable PWM output.

        Args:
            enable: True to enable, False to disable.
        """
        self._instrument.write_register(REG_ENABLE, 1 if enable else 0)
        time.sleep(0.03)

    # -- Convenience -------------------------------------------------------

    def pwm(self, freq: int, duty: float, enable: bool = True) -> None:
        """Set frequency, duty cycle, and optionally enable output.

        Convenience method that sets freq and duty, then enables output.

        Args:
            freq: PWM frequency in Hz (183 - 46875).
            duty: Duty cycle as float 0.0-1.0.
            enable: Also enable the output. Default True.
        """
        self.set_freq(freq)
        self.set_duty(duty)
        if enable:
            self.set_enable(True)

    def factory_reset(self) -> None:
        """Restore factory defaults: 366Hz, 50% duty, output disabled."""
        self.pwm(freq=366, duty=0.5, enable=False)
        self.set_enable(False)

    def info(self) -> dict:
        """Read all device information as a dictionary."""
        return {
            "pid": self.get_pid(),
            "vid": self.get_vid(),
            "addr": self.get_addr(),
            "version": self.get_version(),
            "freq_hz": self.get_freq(),
            "duty": round(self.get_duty(), 4),
            "duty_raw": self.get_duty_raw(),
            "enable": self.get_enable(),
        }

    def close(self) -> None:
        """Close the serial connection."""
        self._instrument.serial.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def __repr__(self) -> str:
        return (
            f"DRI0050(port={self._instrument.serial.port!r}, "
            f"slave=0x{self._slave:02x}, "
            f"baudrate={self._instrument.serial.baudrate})"
        )
