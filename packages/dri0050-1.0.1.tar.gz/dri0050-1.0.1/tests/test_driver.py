"""Unit tests for DRI0050 driver (no hardware required)."""

import pytest
import unittest.mock as mock
from dri0050.driver import (
    DRI0050,
    freq_to_prescaler,
    prescaler_to_freq,
    nearest_valid_freq,
    HIGH_FREQ_TABLE,
)
from dri0050.driver_modbus_tk import DRI0050ModbusTK


class TestPrescalerConversion:
    def test_freq_to_prescaler_366hz(self):
        assert freq_to_prescaler(366) == int(12_000_000 / 256 / 366) - 1

    def test_freq_to_prescaler_1khz(self):
        assert freq_to_prescaler(1000) == int(12_000_000 / 256 / 1000) - 1

    def test_freq_to_prescaler_max(self):
        assert freq_to_prescaler(46875) == int(12_000_000 / 256 / 46875) - 1

    def test_prescaler_roundtrip(self):
        # Prescaler is integer, so roundtrip has inherent quantization error.
        # Verify the roundtrip result is within one prescaler step of the target.
        for freq in [183, 366, 500, 860, 1000, 2000]:
            p = freq_to_prescaler(freq)
            f = prescaler_to_freq(p)
            assert abs(f - freq) <= max(20, freq * 0.03)

    def test_prescaler_to_freq_known(self):
        # 366Hz factory default
        p = freq_to_prescaler(366)
        f = prescaler_to_freq(p)
        assert f == int(12_000_000 / 256 / (p + 1))


class TestNearestValidFreq:
    def test_below_2khz_returns_same(self):
        assert nearest_valid_freq(500) == 500
        assert nearest_valid_freq(183) == 183
        assert nearest_valid_freq(2000) == 2000

    def test_above_2khz_snaps_to_table(self):
        result = nearest_valid_freq(5000)
        assert result in HIGH_FREQ_TABLE

    def test_exact_match(self):
        assert nearest_valid_freq(46875) == 46875
        assert nearest_valid_freq(9375) == 9375

    def test_closest_match(self):
        # 3000Hz → closest in table is 2929 (diff 71) vs 3125 (diff 125)
        result = nearest_valid_freq(3000)
        assert result in HIGH_FREQ_TABLE
        assert result == 2929


class TestDRI0050Init:
    def test_repr(self):
        # Just test that repr works without hardware
        # We can't fully init without a serial port, but we can test the class
        import unittest.mock as mock
        with mock.patch("dri0050.driver.minimalmodbus.Instrument") as MockInst:
            instance = MockInst.return_value
            instance.serial.port = "/dev/ttyUSB0"
            instance.serial.baudrate = 9600
            drv = DRI0050(port="/dev/ttyUSB0")
            r = repr(drv)
            assert "/dev/ttyUSB0" in r
            assert "0x32" in r

    def test_duty_validation(self):
        import unittest.mock as mock
        with mock.patch("dri0050.driver.minimalmodbus.Instrument"):
            drv = DRI0050(port="/dev/ttyUSB0")
            with pytest.raises(ValueError, match="Duty must be between"):
                drv.set_duty(1.5)
            with pytest.raises(ValueError, match="Duty must be between"):
                drv.set_duty(-0.1)

    def test_freq_validation(self):
        import unittest.mock as mock
        with mock.patch("dri0050.driver.minimalmodbus.Instrument"):
            drv = DRI0050(port="/dev/ttyUSB0")
            with pytest.raises(ValueError, match="Frequency must be between"):
                drv.set_freq(100)
            with pytest.raises(ValueError, match="Frequency must be between"):
                drv.set_freq(50000)

    def test_raw_duty_validation(self):
        import unittest.mock as mock
        with mock.patch("dri0050.driver.minimalmodbus.Instrument"):
            drv = DRI0050(port="/dev/ttyUSB0")
            with pytest.raises(ValueError, match="Raw duty must be between"):
                drv.set_duty_raw(300)
            with pytest.raises(ValueError, match="Raw duty must be between"):
                drv.set_duty_raw(-1)


class TestDRI0050ModbusTKInit:
    def _make_driver(self, port="/dev/ttyUSB0"):
        """Create a DRI0050ModbusTK with mocked serial/modbus."""
        with mock.patch("dri0050.driver_modbus_tk.serial.Serial") as MockSer, \
             mock.patch("dri0050.driver_modbus_tk.modbus_rtu.RtuMaster") as MockMaster:
            mock_ser = MockSer.return_value
            mock_ser.port = port
            mock_ser.baudrate = 9600
            drv = DRI0050ModbusTK(port=port)
            drv._master = MockMaster.return_value
            drv._ser = mock_ser
            return drv

    def test_repr(self):
        drv = self._make_driver()
        r = repr(drv)
        assert "/dev/ttyUSB0" in r
        assert "0x32" in r

    def test_duty_validation(self):
        drv = self._make_driver()
        with pytest.raises(ValueError, match="Duty must be between"):
            drv.set_duty(1.5)
        with pytest.raises(ValueError, match="Duty must be between"):
            drv.set_duty(-0.1)

    def test_freq_validation(self):
        drv = self._make_driver()
        with pytest.raises(ValueError, match="Frequency must be between"):
            drv.set_freq(100)
        with pytest.raises(ValueError, match="Frequency must be between"):
            drv.set_freq(50000)

    def test_raw_duty_validation(self):
        drv = self._make_driver()
        with pytest.raises(ValueError, match="Raw duty must be between"):
            drv.set_duty_raw(300)
        with pytest.raises(ValueError, match="Raw duty must be between"):
            drv.set_duty_raw(-1)

    def test_pwm_calls_write_multiple(self):
        drv = self._make_driver()
        drv.pwm(freq=860, duty=0.5)
        drv._master.execute.assert_called_once()
        call_args = drv._master.execute.call_args
        # Verify WRITE_MULTIPLE_REGISTERS function code is used
        import modbus_tk.defines as cst
        assert call_args[0][1] == cst.WRITE_MULTIPLE_REGISTERS
