"""Hardware tests for DRI0050 (requires connected device)."""

import pytest
from dri0050 import DRI0050, DRI0050ModbusTK

# Default USB port on Linux
HARDWARE_PORT = "/dev/ttyUSB0"


@pytest.mark.hardware
def test_dri0050_minimalmodbus_read_info():
    """Test DRI0050 (minimalmodbus) reads device info."""
    with DRI0050(port=HARDWARE_PORT) as drv:
        info = drv.info()
        print(f"\nDRI0050 info: {info}")
        assert info["pid"] > 0
        assert info["vid"] > 0
        assert info["addr"] == 0x32
        assert info["version"] > 0
        assert 183 <= info["freq_hz"] <= 46875
        assert 0.0 <= info["duty"] <= 1.0


@pytest.mark.hardware
def test_dri0050_modbus_tk_read_info():
    """Test DRI0050ModbusTK reads device info."""
    with DRI0050ModbusTK(port=HARDWARE_PORT) as drv:
        info = drv.info()
        print(f"\nDRI0050ModbusTK info: {info}")
        assert info["pid"] > 0
        assert info["vid"] > 0
        assert info["addr"] == 0x32
        assert info["version"] > 0
        assert 183 <= info["freq_hz"] <= 46875
        assert 0.0 <= info["duty"] <= 1.0


@pytest.mark.hardware
def test_dri0050_set_freq_duty():
    """Test DRI0050 sets frequency and duty cycle."""
    with DRI0050(port=HARDWARE_PORT) as drv:
        # Set to known values
        drv.set_freq(1000)
        drv.set_duty(0.5)
        drv.set_enable(True)

        # Read back
        freq = drv.get_freq()
        duty = drv.get_duty()
        enable = drv.get_enable()

        print(f"\nSet: freq=1000, duty=0.5, enable=True")
        print(f"Read: freq={freq}, duty={duty:.2f}, enable={enable}")

        # Allow some prescaler quantization error
        assert abs(freq - 1000) <= 20
        assert abs(duty - 0.5) < 0.01
        assert enable is True

        # Disable output
        drv.set_enable(False)


@pytest.mark.hardware
def test_dri0050_modbus_tk_set_freq_duty():
    """Test DRI0050ModbusTK sets frequency and duty cycle."""
    with DRI0050ModbusTK(port=HARDWARE_PORT) as drv:
        # Set to known values
        drv.set_freq(860)
        drv.set_duty(0.75)
        drv.set_enable(1)

        # Read back
        freq = drv.get_freq()
        duty = drv.get_duty()
        enable = drv.get_enable()

        print(f"\nSet: freq=860, duty=0.75, enable=1")
        print(f"Read: freq={freq}, duty={duty:.2f}, enable={enable}")

        # Allow some prescaler quantization error
        assert abs(freq - 860) <= 20
        assert abs(duty - 0.75) < 0.01
        assert enable == 1

        # Disable output
        drv.set_enable(0)


@pytest.mark.hardware
def test_dri0050_modbus_tk_pwm_atomic():
    """Test DRI0050ModbusTK pwm() uses WRITE_MULTIPLE_REGISTERS."""
    with DRI0050ModbusTK(port=HARDWARE_PORT) as drv:
        drv.pwm(freq=500, duty=0.25)
        drv.set_enable(1)

        freq = drv.get_freq()
        duty = drv.get_duty()
        print(f"\npwm(500, 0.25) -> freq={freq}, duty={duty:.2f}")

        assert abs(freq - 500) <= 20
        assert abs(duty - 0.25) < 0.01

        drv.set_enable(0)


if __name__ == "__main__":
    # Run hardware tests directly
    import sys

    print("=== Running hardware tests ===")
    print(f"Port: {HARDWARE_PORT}\n")

    test_dri0050_minimalmodbus_read_info()
    test_dri0050_modbus_tk_read_info()
    test_dri0050_set_freq_duty()
    test_dri0050_modbus_tk_set_freq_duty()
    test_dri0050_modbus_tk_pwm_atomic()

    print("\n=== All hardware tests passed! ===")
