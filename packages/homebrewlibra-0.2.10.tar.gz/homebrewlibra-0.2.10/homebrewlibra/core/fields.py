"""Field type coercion and name matching utilities."""
from typing import Dict, List, Union

import pandas as pd
from pandas import DataFrame


def check_fields(df: DataFrame, fields_match: Dict[str, str] = None) -> Dict[str, str]:
    """Auto-detect or validate DataFrame column names against a field dictionary.

    Returns a standardized name-to-column mapping.
    """
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    if fields_match is None:
        return {}

    sv = ""
    fields_matched = {}
    for k, v in fields_match.items():
        vs = str(v)
        ks = str(k)
        if ks.startswith("*"):
            if sv != "" and any(df[sv] == v):
                logger.debug(f" value '{v}' for key '{ks}' value found in '{sv}'")
                fields_matched[ks] = sv
            else:
                logger.warning(f" value '{v}' for key '{k}' does not exist in field '{sv}'")
                continue
        else:
            if ks in df.columns:
                logger.debug(f" The key '{ks}' already exist as field name ")
                fields_matched[ks] = ks
                sv = ks
            elif vs in df.columns:
                logger.debug(f" The value '{vs}' for key '{ks}' exist as field ")
                fields_matched[ks] = vs
                sv = vs
            else:
                logger.warning(f" The value '{vs}' for key '{ks}' does not exist as field ")
                continue
    return fields_matched


def numercal_col(df: DataFrame, col: Union[str, List[str]] = None, inplace: bool = True) -> DataFrame:
    """Convert specified DataFrame columns to numeric via pd.to_numeric."""
    newdf = df if inplace else df.copy(deep=True)
    if col is None:
        return newdf
    columns = []
    if isinstance(col, str):
        col = [col]
    for icol in col:
        if icol in df.columns:
            columns.append(icol)
    if len(columns) > 0:
        newdf[columns] = newdf[columns].apply(pd.to_numeric, errors="coerce")
    else:
        raise ValueError(f"passed 'col={col}', but should be either list of strings or string ")
    return newdf
