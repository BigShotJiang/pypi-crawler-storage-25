'''
Created on 23 Jan 2026

@author: alex
'''
import tkinter as tk
from tkinter import filedialog
# For file dialog (optional - falls back to command line if no GUI)
def select_file(**kwargs):
  """
  parameters:
    title           = "Open your project file",
    initialdir      = "/home/alex/projects",
    defaultextension = ".json",
    filetypes       = [("JSON config", "*.json"), ("All files", "*.*")],
    parent          = some_toplevel_window,   # if you have one
  """
  root = tk.Tk()
  root.withdraw()  # Hide the main window
  file_path = filedialog.askopenfilename(**kwargs)
  root.destroy()
  return file_path
