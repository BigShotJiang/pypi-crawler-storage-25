"""Step execution helper — idempotent data pipeline step.

Either loads existing feather data or runs a producer function and persists
the result. Supports forced regeneration and incremental updates.

Safety guarantee: the old cache file is never deleted before the new data is
successfully produced. If ``func_name`` raises, the original file remains
intact.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable

from pandas import DataFrame

from homebrewlibra.helper_feather.feather_io_helper import (
    load_feather_trades,
    save_feather_trades,
)

logger = logging.getLogger(__name__)

__all__ = ["step_execution"]


def step_execution(
    file_name: str | Path,
    func_name: Callable,
    *,
    force_update: bool = False,
    update: bool = False,
    **kwargs,
) -> DataFrame | None:
    """Load cached data or run ``func_name`` to produce it.

    Args:
        file_name: Path to the feather cache file.
        func_name: Callable that returns a DataFrame. When ``update=True`` and
            cache exists, the cached data is passed as ``ddf``.
        force_update: If ``True``, ignore the cache and regenerate. The old
            file is overwritten *only after* ``func_name`` succeeds.
        update: If ``True`` and cache exists, pass loaded data to
            ``func_name`` as ``ddf`` so it can append/extend.
        **kwargs: Passed through to ``func_name``.

    Returns:
        The resulting DataFrame, or ``None`` if the file is missing and
        ``func_name`` returned ``None``.

    Raises:
        Exception: Propagates any exception raised by ``func_name`` or I/O helpers.
    """
    path = Path(file_name)
    logger.info("--Process: %s", path)

    # Ensure parent directory exists before any I/O
    if not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        logger.info("Created parent directory: %s", path.parent)

    existing = None
    if path.exists():
        existing = load_feather_trades(path)
        logger.debug("Loaded existing data (%s rows)", len(existing))

    need_run = False
    if force_update:
        logger.warning("Force update applied — will regenerate and overwrite")
        need_run = True
    elif existing is None:
        logger.info("Cache missing — will generate fresh data")
        need_run = True
    elif update:
        logger.info("Data exists and update requested — will pass ddf to func_name")
        need_run = True
    else:
        # Cache hit — return loaded data directly without calling func_name
        logger.info("Returning cached data")
        return existing

    # Build kwargs copy so caller's dict is never mutated
    # Pass loaded data as ``ddf`` whenever it exists and the function accepts it.
    func_kwargs = dict(kwargs)
    if need_run and existing is not None:
        import inspect

        if "ddf" in inspect.signature(func_name).parameters:
            func_kwargs["ddf"] = existing

    df_out: DataFrame | None = func_name(**func_kwargs)

    if df_out is not None:
        # Overwrite only after successful production — old file stays safe
        # until this point
        save_feather_trades(df_out, path)
    else:
        logger.warning("func_name returned None — nothing saved, old cache preserved")

    return df_out
