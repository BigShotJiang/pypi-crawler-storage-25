"""HomeBrewLibra — modular market data utilities."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("homebrewlibra")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "unknown"
