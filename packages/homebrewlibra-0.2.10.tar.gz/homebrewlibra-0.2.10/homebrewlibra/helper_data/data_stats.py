'''
Created on 17 Mar 2026

@author: alex
'''
import pandas as pd
#import numpy as np
#import logging
#__logger = logging.getLogger(__name__)

def pareto_threshold(dt: pd.Series, target_pct: float = 0.95):
    """
    Calculate threshold value where sum of values above it covers target_pct% of total sum.

    For a numeric series, finds the minimum value such that the sum of all values
    greater than or equal to this threshold constitutes at least target_pct% of the total sum.

    Parameters:
    -----------
    dt : pd.Series
        Input numeric series
    target_pct : float, default=0.95
        Target coverage percentage (0 to 1)

    Returns:
    --------
    float
        Threshold value

    Example:
    --------
    >>> s = pd.Series([100, 50, 30, 20, 10])
    >>> pareto_threshold(s, 0.8)
    30  # Values >=30 sum to 180 (80% of total 210)
    """
    try:
        # Convert series to float, coercing errors to NaN and dropping them
        dt_float = pd.to_numeric(dt, errors='coerce').dropna()

        # Calculate target sum
        target_sum = dt_float.sum() * target_pct

        # Return threshold
        return dt_float.sort_values(ascending=False).loc[lambda x: x.cumsum() < target_sum].min()

    except Exception as e:
        e.add_note("Error in pareto_threshold calculation")
        raise e
