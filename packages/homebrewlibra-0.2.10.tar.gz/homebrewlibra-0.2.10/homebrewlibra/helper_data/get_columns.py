"""Column existence helper."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pandas import DataFrame

logger = logging.getLogger(__name__)


def get_columns(df: DataFrame, list_columns: list[str] | str) -> list[str]:
    """Return only columns from ``list_columns`` that actually exist in ``df``."""
    if isinstance(list_columns, str):
        list_columns = [list_columns]

    if isinstance(list_columns, list):
        feature_cols = [col for col in list_columns if col in df.columns]
        if feature_cols:
            logger.debug("feature_cols are %r", feature_cols)
            return feature_cols
        msg = "None of the requested columns exist in the DataFrame"
    else:
        msg = (
            f"type of list_columns expected to be list, "
            f"got {type(list_columns).__name__}"
        )

    raise ValueError(msg)
