"""Index reset helper."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pandas import DataFrame

logger = logging.getLogger(__name__)

_DEFAULT_INDEX = ("timestamp", "date")


def set_default_index(
    df: DataFrame,
    default_index: str | list[str] | None = None,
) -> DataFrame:
    """Reset index to the first available column from ``default_index``.

    If the requested column is already the index, returns ``df`` unchanged.
    """
    if default_index is None:
        default_index = list(_DEFAULT_INDEX)

    if not default_index:
        msg = "default_index is empty or None"
        logger.error(msg)
        raise ValueError(msg)

    if isinstance(default_index, str):
        default_index = [default_index]

    # Drop a RangeIndex (unnamed), keep named multi-indexes
    has_named_index = df.index.name is not None or len(df.index.names) > 1

    for idx in default_index:
        if idx in df.index.names:
            logger.debug("'%s' already in index — no action", idx)
            return df
        if idx in df.columns:
            if has_named_index:
                df = df.reset_index(drop=False)
            else:
                df = df.reset_index(drop=True)
            df = df.set_index(idx).sort_index()
            logger.info("Index set to '%s'", idx)
            return df

    msg = f"None of the provided columns {default_index} found in DataFrame"
    logger.warning(msg)
    raise ValueError(msg)
