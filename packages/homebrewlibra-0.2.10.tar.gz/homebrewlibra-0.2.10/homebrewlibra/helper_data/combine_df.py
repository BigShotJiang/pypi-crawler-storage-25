"""
DataFrame Combination Utilities

This module provides three distinct methods for combining DataFrames with identical columns:
1. unified_combine - Single set of columns with source tracking
2. merged_combine - Merge with indicator for overlapping records
3. side_by_side_combine - Both sets of columns for direct comparison

All functions include intelligent index handling and comprehensive validation.
"""

import pandas as pd
import warnings
from typing import Optional, Union, List, Dict, Any, Tuple
from enum import Enum


# ============================================================================
# Utility Functions (Shared across all methods)
# ============================================================================

class IndexType(Enum):
    """Classification of index types for intelligent handling"""
    RANGE = 'range'
    DATETIME = 'datetime'
    NAMED_UNIQUE = 'named_unique'
    MULTI = 'multi'
    OTHER_MEANINGFUL = 'other_meaningful'
    OTHER_ARBITRARY = 'other_arbitrary'


def analyze_index(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Analyze DataFrame index to determine if it's meaningful and how to handle it.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to analyze

    Returns
    -------
    Dict[str, Any]
        Analysis results including type, meaningfulness, uniqueness, and suggestions
    """
    index = df.index

    # RangeIndex detection
    if isinstance(index, pd.RangeIndex):
        return {
            'type': IndexType.RANGE,
            'meaningful': False,
            'unique': True,
            'name': index.name,
            'suggested_handling': 'ignore',
            'description': 'Default RangeIndex (no business meaning)'
        }

    # DatetimeIndex detection
    elif isinstance(index, pd.DatetimeIndex):
        return {
            'type': IndexType.DATETIME,
            'meaningful': True,
            'unique': index.is_unique,
            'name': index.name,
            'freq': index.freq,
            'suggested_handling': 'preserve_for_alignment',
            'description': 'Time series index - preserve for temporal alignment'
        }

    # MultiIndex detection
    elif isinstance(index, pd.MultiIndex):
        return {
            'type': IndexType.MULTI,
            'meaningful': True,
            'unique': index.is_unique,
            'names': index.names,
            'nlevels': index.nlevels,
            'suggested_handling': 'preserve_hierarchy',
            'description': 'Hierarchical index - preserve structure'
        }

    # Named unique index
    elif index.name and index.is_unique and not index.name is None:
        return {
            'type': IndexType.NAMED_UNIQUE,
            'meaningful': True,
            'unique': True,
            'name': index.name,
            'suggested_handling': 'preserve_as_key',
            'description': f'Named unique index "{index.name}" - preserve as potential key'
        }

    # Other indexes - check if they look meaningful
    else:
        # Heuristic: non-default, non-monotonic, or non-integer often meaningful
        is_monotonic = index.is_monotonic_increasing
        is_integer = pd.api.types.is_integer_dtype(index)
        has_name = bool(index.name)

        meaningful = (has_name)  or \
        (not is_monotonic and False                   ) or \
        (not is_integer   and len(index) > 0 and False)


        return {
            'type': IndexType.OTHER_MEANINGFUL if meaningful else IndexType.OTHER_ARBITRARY,
            'meaningful': meaningful,
            'unique': index.is_unique,
            'name': index.name,
            'suggested_handling': 'preserve' if meaningful else 'ask_user',
            'description': f'{"Potentially meaningful" if meaningful else "Arbitrary"} index'
        }


def validate_columns_compatible(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    method: str,
    key_columns: Optional[Union[str, List[str]]] = None,
    strict_columns: bool = False
) -> Tuple[List[str], List[str], List[str]]:
    """
    Validate column compatibility between two DataFrames.

    Parameters
    ----------
    df1, df2 : pd.DataFrame
        DataFrames to validate
    method : str
        Method name for context in error messages
    key_columns : str or List[str], optional
        Key columns that must exist
    strict_columns : bool
        If True, require exact column match

    Returns
    -------
    Tuple[List[str], List[str], List[str]]
        Common columns, columns only in df1, columns only in df2

    Raises
    ------
    ValueError
        If validation fails
    """
    cols1 = set(df1.columns)
    cols2 = set(df2.columns)

    # Check key columns exist
    if key_columns:
        if isinstance(key_columns, str):
            key_columns = [key_columns]

        missing_in_df1 = [k for k in key_columns if k not in cols1]
        missing_in_df2 = [k for k in key_columns if k not in cols2]

        if missing_in_df1 or missing_in_df2:
            raise ValueError(
                f"Key columns missing:\n"
                f"Missing in df1: {missing_in_df1}\n"
                f"Missing in df2: {missing_in_df2}"
            )

    # Strict validation
    if strict_columns and cols1 != cols2:
        raise ValueError(
            f"DataFrames must have identical columns for {method} method:\n"
            f"Only in df1: {sorted(cols1 - cols2)}\n"
            f"Only in df2: {sorted(cols2 - cols1)}"
        )

    # Return column analysis
    common = sorted(cols1 & cols2)
    only_df1 = sorted(cols1 - cols2)
    only_df2 = sorted(cols2 - cols1)

    # Warning for different columns
    if only_df1 or only_df2:
        warnings.warn(
            f"DataFrames have different columns:\n"
            f"Common: {common}\n"
            f"Only in df1: {only_df1}\n"
            f"Only in df2: {only_df2}\n"
            f"Missing values will be filled with NaN."
        )

    return common, only_df1, only_df2


def prepare_index(
    df: pd.DataFrame,
    handling: str = 'auto',
    source_name: Optional[str] = None
) -> pd.DataFrame:
    """
    Prepare DataFrame index according to specified handling.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to process
    handling : str
        Index handling strategy: 'auto', 'preserve', 'ignore', 'as_column'
    source_name : str, optional
        Source name for creating composite index

    Returns
    -------
    pd.DataFrame
        DataFrame with processed index
    """
#    df = df.copy()
    index_analysis = analyze_index(df)

    if handling == 'ignore':
      dropIdx = not index_analysis.get('meaningful',True)
      df.reset_index(drop=dropIdx, inplace=True)

    elif handling == 'as_column':
        if df.index.name:
            index_name = df.index.name
        else:
            index_name = 'index'
        df.reset_index(inplace=True)
        df.rename(columns={'index': index_name}, inplace=True)

    elif handling == 'preserve':
        # Keep as is, but ensure uniqueness if needed
        if not df.index.is_unique and source_name:
            # Create composite index with source
            df.index = [f"{source_name}_{idx}" for idx in df.index]
            warnings.warn(f"Index was not unique. Created composite with source: {source_name}")

    elif handling == 'auto':
        index_info = analyze_index(df)
        if not index_info['meaningful']:
            df.reset_index(drop=True, inplace=True)
        # else preserve

    return df


# ============================================================================
# Method 1: Unified Combine (Variant A)
# ============================================================================

def unified_combine(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    source_names: tuple = ('source1', 'source2'),
    index_handling: str = 'auto',
    strict_columns: bool = False
) -> pd.DataFrame:
    """
    Combine DataFrames with single set of columns and source tracking.

    Best for: Unified analysis, memory efficiency, distinct records.
    Result: All rows stacked, with '_source' column indicating origin.

    Parameters
    ----------
    df1, df2 : pd.DataFrame
        DataFrames to combine (can have different columns)
    source_names : tuple, default=('source1', 'source2')
        Names to identify sources in '_source' column
    index_handling : str, default='auto'
        How to handle indexes: 'auto', 'preserve', 'ignore', 'as_column'
    strict_columns : bool, default=False
        If True, require exact column match

    Returns
    -------
    pd.DataFrame
        Combined DataFrame with all rows and '_source' column

    Examples
    --------
    >>> df1 = pd.DataFrame({'id': [1, 2], 'value': [10, 20]})
    >>> df2 = pd.DataFrame({'id': [3, 4], 'value': [30, 40]})
    >>> unified_combine(df1, df2, source_names=('sales_2023', 'sales_2024'))
    """
    source1_name, source2_name = source_names

    # Validate columns (flexible by default)
    # common, only_df1, only_df2 =
    validate_columns_compatible(
        df1, df2, 'unified', strict_columns=strict_columns
    )
#    #rename hardcoded names
    # Prepare indexes
    df1_prepared = prepare_index(df1, index_handling, source1_name)
    df2_prepared = prepare_index(df2, index_handling, source2_name)

    # Add source tracking
#    df1_prepared = df1_prepared.copy()
#    df2_prepared = df2_prepared.copy()
    # apply only for new column
    if not '_source' in df1_prepared.columns:
      df1_prepared['_source'] = source1_name
    if not '_source' in df2_prepared.columns:
      df2_prepared['_source'] = source2_name



    # Combine
    result = pd.concat([df1_prepared, df2_prepared], ignore_index=False, sort=False)

    # Add metadata as attributes
    result.attrs['method'] = 'unified'
    result.attrs['source_names'] = source_names
    result.attrs['source_attrs'] ={
      source1_name : df1.attrs,
      source2_name : df2.attrs
      }
    result.attrs['row_counts'] = {
        source1_name: len(df1),
        source2_name: len(df2),
        'total': len(result)
    }

    return result


# ============================================================================
# Method 2: Merged Combine (with indicator)
# ============================================================================

def merged_combine(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    key_columns: Optional[Union[str, List[str]]] = None,
    how: str = 'outer',
    source_names: tuple = ('source1', 'source2'),
    index_handling: str = 'use_as_key',
    strict_columns: bool = False
) -> pd.DataFrame:
    """
    Merge DataFrames with indicator for overlap tracking.

    Best for: Overlapping records, data reconciliation, quality checks.
    Result: Merged DataFrame with '_merge' column showing record source/overlap.

    Parameters
    ----------
    df1, df2 : pd.DataFrame
        DataFrames to merge
    key_columns : str or List[str], optional
        Column(s) to merge on. If None, uses index
    how : str, default='outer'
        Merge type: 'inner', 'outer', 'left', 'right'
    source_names : tuple, default=('source1', 'source2')
        Names for column suffixes
    index_handling : str, default='use_as_key'
        How to handle indexes: 'use_as_key', 'ignore', 'as_column'
    strict_columns : bool, default=False
        If True, require exact column match (except key columns)

    Returns
    -------
    pd.DataFrame
        Merged DataFrame with '_merge' indicator column

    Examples
    --------
    >>> df1 = pd.DataFrame({'id': [1, 2, 3], 'value': [10, 20, 30]})
    >>> df2 = pd.DataFrame({'id': [3, 4, 5], 'value': [35, 40, 50]})
    >>> merged_combine(df1, df2, key_columns='id', source_names=('old', 'new'))
    """
    source1_name, source2_name = source_names

    # Prepare for merge
    df1_prepared = df1#.copy()
    df2_prepared = df2#.copy()

    # Handle index as key if specified
    use_index = False
    if key_columns is None:
        if index_handling == 'use_as_key':
            use_index = True
            # Ensure indexes have names for clarity
            if df1.index.name is None:
                df1_prepared.index.name = 'index'
            if df2.index.name is None:
                df2_prepared.index.name = 'index'
        else:
            raise ValueError(
                "key_columns must be provided when not using index as key"
            )

    # Validate columns
    if not use_index:
        validate_columns_compatible(
            df1, df2, 'merged',
            key_columns=key_columns,
            strict_columns=strict_columns
        )

    # Prepare indexes if not using as key
    if index_handling == 'ignore':
        df1_prepared = prepare_index(df1_prepared, 'ignore')
        df2_prepared = prepare_index(df2_prepared, 'ignore')
    elif index_handling == 'as_column' and not use_index:
        df1_prepared = prepare_index(df1_prepared, 'as_column')
        df2_prepared = prepare_index(df2_prepared, 'as_column')

    # Perform merge
    result = pd.merge(
        df1_prepared,
        df2_prepared,
        left_index=use_index,
        right_index=use_index,
        on=None if use_index else key_columns,
        how=how,
        suffixes=(f'_{source1_name}', f'_{source2_name}'),
        indicator=True
    )

    # Add metadata
    result.attrs['method'] = 'merged'
    result.attrs['source_names'] = source_names
    result.attrs['source_attrs'] ={
      source1_name : df1.attrs,
      source2_name : df2.attrs
      }
    result.attrs['merge_info'] = {
        'how': how,
        'key': 'index' if use_index else key_columns,
        'counts': result['_merge'].value_counts().to_dict()
    }

    return result


# ============================================================================
# Method 3: Side by Side Combine (Variant B)
# ============================================================================

def side_by_side_combine(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    alignment: str = 'index',
    key_columns: Optional[Union[str, List[str]]] = None,
    source_names: tuple = ('source1', 'source2'),
    index_handling: str = 'preserve',
    strict_columns: bool = True
) -> pd.DataFrame:
    """
    Combine DataFrames side by side with prefixed columns.

    Best for: Direct comparison, small aligned datasets, validation.
    Result: All columns from both sources with prefixes, aligned row-wise.

    Parameters
    ----------
    df1, df2 : pd.DataFrame
        DataFrames to combine side by side
    alignment : str, default='index'
        How to align rows: 'index', 'keys', 'sequential'
    key_columns : str or List[str], optional
        Columns to align on when alignment='keys'
    source_names : tuple, default=('source1', 'source2')
        Prefixes for columns from each source
    index_handling : str, default='preserve'
        How to handle indexes: 'preserve', 'ignore', 'as_column'
    strict_columns : bool, default=True
        If True, require exact column match

    Returns
    -------
    pd.DataFrame
        Side-by-side DataFrame with prefixed columns

    Examples
    --------
    >>> df1 = pd.DataFrame({'id': [1, 2], 'value': [10, 20]})
    >>> df2 = pd.DataFrame({'id': [1, 2], 'value': [11, 21]})
    >>> side_by_side_combine(df1, df2, alignment='keys', key_columns='id')
    """
    source1_name, source2_name = source_names

    # Validate columns (strict by default for this method)
    # common, only_df1, only_df2 =
    validate_columns_compatible(
        df1, df2, 'side_by_side',
        strict_columns=strict_columns
    )

    # Prepare DataFrames based on alignment strategy
    df1_prepared = df1#.copy()
    df2_prepared = df2#.copy()

    if alignment == 'index':
        # Align on index
        if not df1.index.equals(df2.index):
            warnings.warn(
                "Indexes don't match. Performing outer alignment.\n"
                "Rows unique to one source will have NaN in the other."
            )
            df1_prepared, df2_prepared = df1.align(df2, join='outer')

    elif alignment == 'keys':
        # Align on key columns
        if key_columns is None:
            raise ValueError("key_columns must be provided for alignment='keys'")

        df1_prepared = df1.set_index(key_columns)
        df2_prepared = df2.set_index(key_columns)

        if not df1_prepared.index.equals(df2_prepared.index):
            warnings.warn(
                f"Keys don't match. Performing outer alignment on {key_columns}.\n"
                f"Rows unique to one source will have NaN in the other."
            )
            df1_prepared, df2_prepared = df1_prepared.align(df2_prepared, join='outer')

    elif alignment == 'sequential':
        # Simple sequential alignment (assumes same order)
        if len(df1) != len(df2):
            raise ValueError(
                f"DataFrames must have same length for sequential alignment:\n"
                f"df1: {len(df1)} rows, df2: {len(df2)} rows"
            )
        # Reset indexes to ensure sequential alignment
        df1_prepared = df1_prepared.reset_index(drop=True)
        df2_prepared = df2_prepared.reset_index(drop=True)

    # Handle indexes according to specified strategy
    if index_handling != 'preserve' or alignment != 'index':
        df1_prepared = prepare_index(df1_prepared, index_handling, source1_name)
        df2_prepared = prepare_index(df2_prepared, index_handling, source2_name)

    # Add prefixes and combine
    df1_prefixed = df1_prepared.add_prefix(f'{source1_name}_')
    df2_prefixed = df2_prepared.add_prefix(f'{source2_name}_')

    result = pd.concat([df1_prefixed, df2_prefixed], axis=1)

    # Add metadata
    result.attrs['method'] = 'side_by_side'
    result.attrs['source_names'] = source_names
    result.attrs['source_attrs'] ={
      source1_name : df1.attrs,
      source2_name : df2.attrs
      }
    result.attrs['alignment'] = alignment
    result.attrs['shape'] = {
        'rows': len(result),
        'columns_from_source1': len(df1.columns),
        'columns_from_source2': len(df2.columns),
        'total_columns': len(result.columns)
    }

    return result


# ============================================================================
# Demonstration and Testing
# ============================================================================

if __name__ == "__main__":
    print("=" * 80)
    print("DATAFRAME COMBINATION UTILITIES - DEMONSTRATION")
    print("=" * 80)

    # ========================================================================
    # Test Data Preparation
    # ========================================================================

    print("\n1. CREATING TEST DATAFRAMES")
    print("-" * 40)

    # Simple DataFrames for basic testing
    df_basic1 = pd.DataFrame({
        'id': [1, 2, 3],
        'value': [10, 20, 30],
        'category': ['A', 'B', 'A']
    })

    df_basic2 = pd.DataFrame({
        'id': [3, 4, 5],
        'value': [35, 40, 50],
        'category': ['A', 'C', 'B']
    })

    print("df_basic1:")
    print(df_basic1)
    print("\ndf_basic2:")
    print(df_basic2)

    # DataFrames with meaningful indexes
    df_indexed1 = pd.DataFrame(
        {'sales': [100, 200, 150], 'region': ['North', 'South', 'East']},
        index=['P001', 'P002', 'P003']
    )
    df_indexed1.index.name = 'product_id'

    df_indexed2 = pd.DataFrame(
        {'sales': [180, 220, 130], 'region': ['North', 'West', 'East']},
        index=['P001', 'P004', 'P003']
    )
    df_indexed2.index.name = 'product_id'

    print("\n" + "=" * 80)
    print("df_indexed1 (with meaningful index):")
    print(df_indexed1)
    print("\ndf_indexed2 (with meaningful index):")
    print(df_indexed2)

    # Time series DataFrames
    dates1 = pd.date_range('2023-01-01', periods=3, freq='D')
    dates2 = pd.date_range('2023-01-02', periods=3, freq='D')

    df_timeseries1 = pd.DataFrame(
        {'temperature': [20, 22, 25], 'humidity': [60, 65, 70]},
        index=dates1
    )
    df_timeseries2 = pd.DataFrame(
        {'temperature': [21, 23, 26], 'humidity': [62, 67, 72]},
        index=dates2
    )

    print("\n" + "=" * 80)
    print("df_timeseries1 (with DatetimeIndex):")
    print(df_timeseries1)
    print("\ndf_timeseries2 (with DatetimeIndex):")
    print(df_timeseries2)

    # DataFrames with different columns
    df_diff_cols1 = pd.DataFrame({
        'id': [1, 2, 3],
        'value': [10, 20, 30],
        'extra1': ['X', 'Y', 'Z']
    })

    df_diff_cols2 = pd.DataFrame({
        'id': [3, 4, 5],
        'value': [35, 40, 50],
        'extra2': [True, False, True]
    })

    print("\n" + "=" * 80)
    print("df_diff_cols1 (with extra column 'extra1'):")
    print(df_diff_cols1)
    print("\ndf_diff_cols2 (with extra column 'extra2'):")
    print(df_diff_cols2)

    # ========================================================================
    # Method 1: Unified Combine Tests
    # ========================================================================

    print("\n" + "=" * 80)
    print("METHOD 1: UNIFIED COMBINE (Variant A)")
    print("=" * 80)

    print("\n--- Test 1.1: Basic unified combine ---")
    result1 = unified_combine(
        df_basic1, df_basic2,
        source_names=('sales_2023', 'sales_2024')
    )
    print(result1)
    print(f"\nMetadata: {result1.attrs}")

    print("\n--- Test 1.2: Unified combine with meaningful indexes ---")
    result1_indexed = unified_combine(
        df_indexed1, df_indexed2,
        source_names=('q1', 'q2'),
        index_handling='preserve'
    )
    print(result1_indexed)
    print(f"\nIndex type: {type(result1_indexed.index)}")
    print(f"Index values: {result1_indexed.index.tolist()}")

    print("\n--- Test 1.3: Unified combine with different columns (flexible) ---")
    result1_diff = unified_combine(
        df_diff_cols1, df_diff_cols2,
        source_names=('system_A', 'system_B'),
        strict_columns=False
    )
    print(result1_diff)
    print("\nNote: Missing values filled with NaN")

    # ========================================================================
    # Method 2: Merged Combine Tests
    # ========================================================================

    print("\n" + "=" * 80)
    print("METHOD 2: MERGED COMBINE (with indicator)")
    print("=" * 80)

    print("\n--- Test 2.1: Basic merge on 'id' ---")
    result2 = merged_combine(
        df_basic1, df_basic2,
        key_columns='id',
        source_names=('old', 'new')
    )
    print(result2)
    print(f"\nMerge statistics: {result2['_merge'].value_counts().to_dict()}")

    print("\n--- Test 2.2: Merge using index as key ---")
    result2_index = merged_combine(
        df_indexed1, df_indexed2,
        key_columns=None,  # Use index
        source_names=('q1', 'q2'),
        index_handling='use_as_key'
    )
    print(result2_index)
    print(f"\nMerge statistics: {result2_index['_merge'].value_counts().to_dict()}")

    print("\n--- Test 2.3: Inner merge (only matching records) ---")
    result2_inner = merged_combine(
        df_basic1, df_basic2,
        key_columns='id',
        how='inner',
        source_names=('old', 'new')
    )
    print(result2_inner)
    print(f"\nInner merge - only {len(result2_inner)} records with matches")

    # ========================================================================
    # Method 3: Side by Side Combine Tests
    # ========================================================================

    print("\n" + "=" * 80)
    print("METHOD 3: SIDE BY SIDE COMBINE (Variant B)")
    print("=" * 80)

    # Create aligned DataFrames for side_by_side
    df_aligned1 = pd.DataFrame({
        'id': [1, 2, 3],
        'value': [10, 20, 30]
    })
    df_aligned2 = pd.DataFrame({
        'id': [1, 2, 3],
        'value': [11, 21, 31]
    })

    print("\n--- Test 3.1: Basic side-by-side with index alignment ---")
    result3 = side_by_side_combine(
        df_aligned1, df_aligned2,
        alignment='sequential',
        source_names=('actual', 'forecast')
    )
    print(result3)

    print("\n--- Test 3.2: Side-by-side with key alignment ---")
    # Create DataFrames with different order
    df_messy1 = pd.DataFrame({
        'id': [1, 2, 3],
        'value': [10, 20, 30]
    })
    df_messy2 = pd.DataFrame({
        'id': [3, 1, 2],
        'value': [33, 11, 22]
    })

    result3_keys = side_by_side_combine(
        df_messy1, df_messy2,
        alignment='keys',
        key_columns='id',
        source_names=('system1', 'system2')
    )
    print("\nAligned on 'id' (corrects for different order):")
    print(result3_keys)

    print("\n--- Test 3.3: Side-by-side with time series alignment ---")
    result3_ts = side_by_side_combine(
        df_timeseries1, df_timeseries2,
        alignment='index',
        source_names=('day1', 'day2')
    )
    print(result3_ts)
    print("\nNote: Outer alignment on dates - shows both days with NaN where missing")

    # ========================================================================
    # Error Handling Demonstrations
    # ========================================================================

    print("\n" + "=" * 80)
    print("ERROR HANDLING DEMONSTRATION")
    print("=" * 80)

    print("\n--- Test 4.1: Attempting side_by_side with mismatched lengths ---")
    df_short = pd.DataFrame({'id': [1, 2], 'value': [10, 20]})
    df_long = pd.DataFrame({'id': [1, 2, 3], 'value': [11, 21, 31]})

    try:
        result_error = side_by_side_combine(
            df_short, df_long,
            alignment='sequential',
            source_names=('a', 'b')
        )
    except ValueError as e:
        print(f"Caught expected error: {e}")

    print("\n--- Test 4.2: Strict columns validation ---")
    try:
        result_strict = unified_combine(
            df_diff_cols1, df_diff_cols2,
            strict_columns=True
        )
    except ValueError as e:
        print(f"Caught expected error: {e}")

    # ========================================================================
    # Summary Statistics
    # ========================================================================

    print("\n" + "=" * 80)
    print("SUMMARY - When to Use Each Method")
    print("=" * 80)

    summary = pd.DataFrame({
        'Method': ['unified_combine', 'merged_combine', 'side_by_side_combine'],
        'Best For': [
            'Unified analysis, memory efficiency, distinct records',
            'Overlap detection, data reconciliation, quality checks',
            'Direct comparison, validation, small aligned datasets'
        ],
        'Output Shape': [
            'Rows: len(df1)+len(df2), Cols: union of columns + _source',
            'Rows: varies by overlap, Cols: merged with suffixes + _merge',
            'Rows: max(len(df1),len(df2)), Cols: 2*original columns'
        ],
        'Index Handling': [
            'Auto-detects meaningful indexes',
            'Can use index as join key',
            'Preserves index for alignment'
        ]
    })

    print(summary.to_string(index=False))

    print("\n" + "=" * 80)
    print("DEMONSTRATION COMPLETE")
    print("=" * 80)