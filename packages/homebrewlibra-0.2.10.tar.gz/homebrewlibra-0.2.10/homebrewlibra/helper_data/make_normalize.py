"""Column normalization and categorization helpers."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from homebrewlibra.helper_data.get_columns import get_columns

if TYPE_CHECKING:
    from pandas import DataFrame

logger = logging.getLogger(__name__)


def make_normalize(
    df: DataFrame,
    ratio_name: str = "weight",
    criteria_name: str = "peaks",
    modify_list: list[str] | None = None,
) -> DataFrame:
    """Normalize columns in ``modify_list`` by the last non-zero ``criteria_name`` ratio.

    For each row, computes ``df[col] / last_ratio`` where ``last_ratio`` is the
    most recent ``ratio_name`` value at a point where ``criteria_name != 0``.
    """
    if modify_list is None:
        modify_list = ["open", "close", "mean", "weight"]

    try:
        df["~~temp"] = (
            df[ratio_name].where(df[criteria_name] != 0).ffill()
        ).fillna(1)
        for col in modify_list:
            df[col] = (df[col] / df["~~temp"]).fillna(1)
        df.drop("~~temp", inplace=True, errors="ignore")
    except Exception as e:
        logger.fatal(e, exc_info=True)
        raise

    return df


def make_categorize(
    df: DataFrame,
    modify_list: list[str] | None = None,
) -> tuple[DataFrame, dict]:
    """Convert non-numeric columns to categorical integer codes.

    Returns the modified DataFrame plus a mapping dict of
    ``{column_name: {code: original_value}}``.
    """
    try:
        mappings: dict = {}
        if not modify_list:
            modify_list = list(df.columns)
        modify_list = get_columns(df, modify_list)
        for col in df[modify_list].select_dtypes(exclude="number").columns:
            df[col] = df[col].astype("category")
            mappings[col] = dict(enumerate(df[col].cat.categories))
            df[col] = df[col].cat.codes.astype("int32")
        return df, mappings
    except Exception as e:
        logger.fatal(e, exc_info=True)
        raise
