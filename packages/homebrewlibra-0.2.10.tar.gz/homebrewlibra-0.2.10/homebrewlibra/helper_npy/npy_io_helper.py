"""NPY I/O helpers for NumPy array persistence.

Provides :func:`load_npy` and :func:`save_npy` with directory creation,
path expansion, and logging — matching the API style of
:mod:`homebrewlibra.helper_feather.feather_io_helper`.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy import ndarray

logger = logging.getLogger(__name__)


def load_npy(
    path: str | Path,
    *,
    mmap_mode: str | None = None,
    allow_pickle: bool = False,
) -> ndarray:
    """Load a NumPy array from ``.npy`` or ``.npz``.

    Parameters
    ----------
    path
        File path (``~`` is expanded automatically).
    mmap_mode
        If given, memory-map the file instead of loading into RAM.
        Valid values: ``"r"``, ``"r+"``, ``"w+"``, ``"c"``.
    allow_pickle
        Allow pickled objects (default ``False`` for safety).

    Returns
    -------
    ndarray
    """
    resolved = Path(path).expanduser()
    data = np.load(resolved, mmap_mode=mmap_mode, allow_pickle=allow_pickle)
    logger.info("Loaded %s shape=%s dtype=%s from %s", resolved, data.shape, data.dtype, resolved.name)
    return data


def save_npy(
    data: ndarray | None,
    file_path: str | Path,
    *,
    allow_pickle: bool = False,
) -> str | None:
    """Save a NumPy array to ``.npy``, creating parent directories if needed.

    Parameters
    ----------
    data
        Array to save. If ``None``, nothing is written and ``None`` is
        returned.
    file_path
        Destination path (``~`` is expanded automatically).
    allow_pickle
        Allow pickled objects (default ``False``).

    Returns
    -------
    str | None
        The absolute file path on success, or ``None`` when *data* is ``None``.
    """
    if data is None:
        logger.info("Passed array is None — nothing saved")
        return None

    path = Path(file_path).expanduser()
    if not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        logger.info("Created parent directory: %s", path.parent)

    if path.suffix.lower() == ".npz":
        np.savez_compressed(path, data=data)
    else:
        np.save(path, data, allow_pickle=allow_pickle)

    logger.info("Saved %s shape=%s dtype=%s to %s", data.shape, data.dtype, path.name)
    return str(path)
