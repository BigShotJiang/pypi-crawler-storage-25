"""Feather I/O helpers for generic data loading."""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

from homebrewlibra.core.fields import numercal_col
from homebrewlibra.core.timestamp import parse_unix_ts

if TYPE_CHECKING:
    from pandas import DataFrame

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


def load_feather_trades(
    path: str | Path,
    *,
    convert_timestamp: str | None = "timestamp",
    index_col: str | None = None,
    convert_2_floats: list[str] | str | None = None,
) -> DataFrame:
    """Load trades from a feather file with optional type coercion."""
    import pandas as pd

    df = pd.read_feather(path)
    logger.info("loaded %s records from file %s", len(df), path)

    if isinstance(convert_timestamp, str) and convert_timestamp in df.columns:
        df[convert_timestamp] = parse_unix_ts(df[convert_timestamp])
        logger.info("Column '%s' converted to datetime", convert_timestamp)
        # Validate tz-awareness after conversion
        ts_col = df[convert_timestamp]
        if hasattr(ts_col, "dt") and ts_col.dt.tz is None:
            logger.error(
                "BUSINESS ERROR: loaded '%s' is naive datetime64 — "
                "timestamps will shift under .timestamp() on non-UTC hosts. "
                "Run check_continuity.py --repair to migrate to tz-aware UTC.",
                convert_timestamp,
            )

    numercal_col(df, col=convert_2_floats, inplace=True)

    if isinstance(index_col, str):
        if index_col in df.index.names:
            logger.info("Index '%s' already applied — no action", index_col)
        elif index_col in df.columns:
            df = df.set_index(index_col).sort_index()
            logger.info("Index '%s' applied", index_col)
        else:
            logger.warning("Field '%s' missing — no index applied", index_col)
    else:
        logger.info("No indexing required")

    return df


def save_feather_trades(
    df_data: DataFrame | None,
    file_path: str | Path,
    *,
    unique_col: str | None = None,
) -> str | None:
    """Save DataFrame to feather, creating parent directories if needed.

    Returns the file path on success, or ``None`` if ``df_data`` is ``None``.
    """
    import pandas as pd

    if df_data is None:
        logger.info("Passed DataFrame is None — nothing saved")
        return None

    path = Path(file_path)
    if not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        logger.info("Created parent directory: %s", path.parent)

    if os.path.exists(path):
        logger.warning("Overwriting file: %s", path)

    if isinstance(unique_col, str) and unique_col in df_data.columns:
        df_data = df_data.drop_duplicates(subset=[unique_col], keep="first")

    # Validate timestamp column before saving
    if "timestamp" in df_data.columns:
        ts_col = df_data["timestamp"]
        if hasattr(ts_col, "dt") and ts_col.dt.tz is None:
            logger.error(
                "BUSINESS ERROR: saving naive 'timestamp' column — "
                "data will be host-timezone dependent. "
                "Run check_continuity.py --repair to migrate.",
            )

    df_data.to_feather(path)
    logger.info("Saved %s records to %s", len(df_data), path)
    return str(path)
