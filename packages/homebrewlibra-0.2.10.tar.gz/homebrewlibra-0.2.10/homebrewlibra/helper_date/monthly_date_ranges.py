'''
Created on 28 Jan 2026

@author: alex
'''

from datetime import datetime, date
from dateutil.relativedelta import relativedelta
from typing import Tuple, List

import logging
__logger = logging.getLogger(__name__)

def get_monthly_date_ranges(start_date: date | datetime, end_date: date | datetime) -> Tuple[List[date], List[date]]:
  """
    Returns two lists: date_from and date_to covering complete months
    between start_date and end_date (inclusive).

    Example:
        Input:  2024-03-15, 2024-07-10
        Output:
            date_from = [2024-04-01, 2024-05-01, 2024-06-01, 2024-07-01]
            date_to   = [2024-04-30, 2024-05-31, 2024-06-30, 2024-07-31]
  """
    # Convert to date if datetime was passed
  if isinstance(start_date, datetime):
      start_date = start_date.date()
  if isinstance(end_date, datetime):
      end_date = end_date.date()

  # Move start to first day of next month if not already on 1st
  current = start_date
  if current.day != 1:
      current = current.replace(day=1) + relativedelta(months=1)

  date_from = []
  date_to = []

  while current <= end_date:
      # First day of current month
      month_start = current.replace(day=1)

      # Last day of current month
      month_end = (month_start + relativedelta(months=1) - relativedelta(days=1))

      # Only include if the full month is within the range
      if month_end <= end_date:
          date_from.append(month_start)
          date_to.append(month_end)
      else:
          # If partial last month — you can decide whether to include or not
          # Here: we skip partial months at the end
          break

      current += relativedelta(months=1)

  return date_from, date_to

def get_monthly_date_ranges_inclusive(start: date, end: date) -> Tuple[List[date], List[date]]:
    current = start.replace(day=1)
    date_from = []
    date_to = []

    while current <= end:
        month_start = current
        month_end = min(
            (current + relativedelta(months=1) - relativedelta(days=1)),
            end
        )
        date_from.append(month_start)
        date_to.append(month_end)
        current += relativedelta(months=1)

    return date_from, date_to
# ────────────────────────────────────────────────
# Examples / Test
# ────────────────────────────────────────────────

if __name__ == "__main__":
    from datetime import date

    # Test 1
    from1, to1 = get_monthly_date_ranges(date(2024, 3, 15), date(2024, 7, 10))
    print("Test 1:")
    print("From:", [d.isoformat() for d in from1])
    print("To:  ", [d.isoformat() for d in to1])
    # Expected:
    # From: ['2024-04-01', '2024-05-01', '2024-06-01', '2024-07-01']
    # To:   ['2024-04-30', '2024-05-31', '2024-06-30', '2024-07-31']

    # Test 2 - different year
    from2, to2 = get_monthly_date_ranges(date(2025, 11, 20), date(2026, 2, 5))
    print("\nTest 2:")
    print("From:", [d.isoformat() for d in from2])
    print("To:  ", [d.isoformat() for d in to2])
    # Expected: Dec 2025, Jan 2026