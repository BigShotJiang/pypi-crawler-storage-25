'''
Created on 23 Jan 2026

@author: alex
'''
import pandas as pd
from pandas.core.frame import DataFrame
import os
from pathlib import Path

import logging
__logger = logging.getLogger(__name__)

def load_csv(file_path:str|Path)->DataFrame :
    # Select file
    if not os.path.exists(file_path):
        msg=f"❌ Error: File '{file_path}' not found!"
        __logger.exception(msg)
        raise IOError(msg)


    __logger.info(f"📁 Loading: {file_path}")

    # Read CSV
    try:
        df = pd.read_csv(file_path)
        __logger.info(f"✅ Loaded {len(df)} rows, {len(df.columns)} columns")
        for col in ['date','timestamp','timestamp1']:
          if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')
    except Exception as e:
        msg=f"❌ Error reading CSV: {e}"
        raise IOError(msg)
    return df
