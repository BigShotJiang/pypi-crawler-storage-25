"""CSV I/O helpers for generic data loading."""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

from homebrewlibra.core.fields import numercal_col
from homebrewlibra.core.timestamp import parse_unix_ts

if TYPE_CHECKING:
    from pandas import DataFrame

logger = logging.getLogger(__name__)


def load_csv_trades(
    path: str | Path,
    *,
    convert_timestamp: str | None = "timestamp",
    index_col: str | None = None,
    convert_2_floats: list[str] | str | None = None,
) -> DataFrame:
    """Load trades from a CSV file with optional type coercion."""
    import pandas as pd

    df = pd.read_csv(path)

    if isinstance(convert_timestamp, str) and convert_timestamp in df.columns:
        df[convert_timestamp] = parse_unix_ts(df[convert_timestamp])
        logger.info("Column '%s' converted to datetime", convert_timestamp)

    numercal_col(df, col=convert_2_floats, inplace=True)

    if isinstance(index_col, str):
        if index_col in df.columns:
            df = df.set_index(index_col).sort_index()
            logger.info(
                "Loaded %s records from %s to %s",
                len(df),
                df.index.min(),
                df.index.max(),
            )
        else:
            logger.warning(
                "Field '%s' missing — no index applied (%s records)",
                index_col,
                len(df),
            )
    else:
        logger.info("Loaded %s records — no indexing", len(df))

    return df


def save_csv_trades(
    df_data: DataFrame,
    file_path: str | Path,
    *,
    unique_col: str | None = None,
) -> str:
    """Save DataFrame to CSV, creating parent directories if needed."""
    path = Path(file_path)
    if not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        logger.info("Created parent directory: %s", path.parent)

    if os.path.exists(path):
        logger.warning("Overwriting file: %s", path)

    if isinstance(unique_col, str) and unique_col in df_data.columns:
        df_data = df_data.drop_duplicates(subset=[unique_col], keep="first")

    df_data.to_csv(path, index=False)
    logger.info("Saved %s records to %s", len(df_data), path)
    return str(path)
