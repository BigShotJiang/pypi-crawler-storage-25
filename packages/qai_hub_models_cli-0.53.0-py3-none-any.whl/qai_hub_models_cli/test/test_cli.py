# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------
from importlib.metadata import PackageNotFoundError
from unittest.mock import patch

import pytest

from qai_hub_models_cli.cli import (
    _check_version_match,
    main,
)


def test_cli_import() -> None:
    """Verify the CLI entry point is importable."""
    assert callable(main)


def test_cli_no_qai_hub_models() -> None:
    """Verify the CLI runs without error when qai_hub_models is not installed."""

    def _version_without_models(pkg: str) -> str:
        if pkg == "qai_hub_models":
            raise PackageNotFoundError(pkg)
        return "1.0.0"

    with (
        patch("qai_hub_models_cli.cli.version", side_effect=_version_without_models),
        patch.dict("sys.modules", {"qai_hub_models": None, "qai_hub_models.cli": None}),
    ):
        main([])  # should not raise


def test_version_mismatch_exits() -> None:
    """Verify sys.exit(1) is called when package versions differ."""
    with (
        patch(
            "qai_hub_models_cli.cli.version",
            side_effect=lambda pkg: "1.0.0" if pkg == "qai_hub_models_cli" else "2.0.0",
        ),
        pytest.raises(SystemExit),
    ):
        _check_version_match()


def test_version_match_ok() -> None:
    """Verify no error when package versions match."""
    with patch(
        "qai_hub_models_cli.cli.version",
        return_value="1.0.0",
    ):
        _check_version_match()


def test_version_check_models_not_installed() -> None:
    """Verify no error when qai_hub_models is not installed."""

    def _version_without_models(pkg: str) -> str:
        if pkg == "qai_hub_models":
            raise PackageNotFoundError(pkg)
        return "1.0.0"

    with patch("qai_hub_models_cli.cli.version", side_effect=_version_without_models):
        _check_version_match()


# ── --version flag ──────────────────────────────────────────────────


def test_version_flag() -> None:
    with (
        patch("qai_hub_models_cli.cli._check_version_match"),
        pytest.raises(SystemExit) as exc_info,
    ):
        main(["--version"])
    assert exc_info.value.code == 0
