---
name: agent-guard project context
description: Core facts about the agent-guard repo — pre-alpha OSS library for LLM agent safety (budget caps, audit log, kill switch, HITL)
type: project
---

agent-guard is a pre-alpha Python library (v0.0.1) that provides runtime enforcement for LLM agents: hard USD budget caps, append-only hash-chained JSONL audit log, kill switch, and human-in-the-loop webhook. One import, one class: `from agent_guard import Firewall`.

**Why:** Targets the uncontested B2B layer — cost enforcement and compliance evidence — explicitly not competing with content-safety scanners (LlamaFirewall, Invariant, NeMo Guardrails).

**How to apply:** When suggesting implementations, enforce the core constraints: zero runtime deps for core (stdlib only), adapters ≤300 LOC each, async-first sync-compatible, JSONL audit format is a wire contract. The Firewall facade surface (3 properties, 3 methods, 1 constructor) is locked in API.md.

Current state as of 2026-05-16:
- firewall.py and types.py have ~229 LOC of real code; all other modules (budget, audit, kill, hitl, policy, adapters, cli) are 0-LOC stubs.
- 0 tests. No CI. No CVE scanner.
- 5 P0 tasks, 5 P1 tasks, 4 P2 tasks in Beads (prefix: dreamy-swirles-89f100).
- Next milestone: v0.1 — core firewall + Anthropic/OpenAI adapters + CLI (replay, verify).
