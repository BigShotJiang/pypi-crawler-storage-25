# Changelog

All notable changes are recorded here. Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning: [SemVer](https://semver.org/) — public top-level surface is stable from v1.0.

## [1.3.1] — 2026-05-16

### Added
- **Expanded Anthropic pricing coverage** in `PRICING_v_2026_05`. Real-world
  agent orchestrators (CrewAI, OpenRouter routing tables, OpenHands) pin
  model names from across the Claude family — not just the latest. Adds:
  `claude-opus-4-6`, `claude-opus-4-5`, `claude-sonnet-4-5`,
  `claude-sonnet-3-5`, `claude-haiku-3-5`.
- Patch-level only: zero behaviour changes outside the pricing table.

### Why
First field integration (Minctrl crypto-orchestrator) surfaced an
`UnknownModel` error on `claude-opus-4-6`. The table was 2026-05-future-leaning
and missed names still common in production today. v1.3.1 closes the gap.

## [1.3.0] — 2026-05-16

### Added
- **SOC 2 evidence pack generator** — `llm_leash.audit.soc2.generate_report(...)`
  turns any `audit.jsonl` into six artefacts an auditor can attach to
  their evidence binder directly:
  - `executive-summary.html` — single-page overview with integrity verdict
  - `cc6_access_control.csv` — per-session/tenant activity (CC6.1, CC6.6)
  - `cc7_monitoring.csv` — security events with reasons (CC7.1, CC7.3)
  - `cc7_integrity.json` — hash-chain verification (CC7.2)
  - `anomalies.csv` — outlier detection (kill spikes, p95 spend, tool spam)
  - `bom.json` — bill of materials with sha256 of source log and every artefact
- **CLI** — `llm-leash soc2 audit.jsonl --out DIR --period-start ISO --period-end ISO`.
  Exit code `2` when the source chain is broken.
- **`docs/SOC2.md`** — Trust Service Criteria mapping, anomaly heuristics,
  reproducibility notes.
- 314 tests, 96 % coverage.

## [1.2.0] — 2026-05-16

### Added
- **Durable HITL queue** — `HitlQueue` protocol with two backends:
  - `InMemoryHitlQueue` for tests and single-process apps
  - `SQLiteHitlQueue` for multi-process production; state survives restarts
- **`QueueBackedHitlGate`** — plugs a queue into the existing `HitlGate`
  surface so the firewall blocks (with timeout) until an operator
  approves/rejects via the queue.
- **`hitl.resume`** helpers — `pending()` / `approve()` / `reject()`
  convenience functions for operator UIs, Slack bots, CLI integrations.
- **`HTTPKillRegistry`** — kill-switch backed by a tiny HTTP service
  (GET/POST/DELETE \`/kill/{session_id}\`). Stdlib `urllib` only. Reads
  fail-open so a flaky control-plane never blocks traffic.
- **CLI `hitl` subcommand** — `llm-leash hitl list|approve|reject <queue.db>`
  for operator workflows.
- 302 tests, 96 % coverage.

## [1.1.0] — 2026-05-16

### Added
- **OpenHands adapter** — wraps `openhands.llm.LLM.completion()` (LiteLLM-shaped),
  routes `provider/model` prefixes (anthropic/openai).
- **Pydantic-AI adapter** — wraps `Model.request()` (async), handles both the
  new `input_tokens` / `output_tokens` Usage shape and the legacy
  `request_tokens` / `response_tokens` one.
- **LlamaFirewallRule** — converts a LlamaFirewall scanner's `ScanResult`
  into a `Decision` (BLOCK / HITL / ALLOW). Score-threshold gated.
- **PresidioRule** — blocks calls when Presidio detects PII entities above a
  configurable score; for redaction-instead-of-block, use `PiiRedactor`.
- Both external scanners are **duck-typed** — no `llama-firewall` or
  `presidio-analyzer` import at module level.
- 266 tests, 96 % coverage.

### Changed
- `Firewall.wrap()` dispatch order extended: Anthropic → OpenAI → LangChain →
  MCP → **OpenHands → Pydantic-AI** → CrewAI → pass-through.

## [1.0.0] — 2026-05-16

First stable release. Public surface is semver-locked.

### Added
- **Stability promise** documented in API.md. Top-level imports, audit JSONL
  schema, and CLI sub-commands (`verify`, `replay`, `export`) will not change
  without a major-version bump.
- **PyPI publication workflow** — tag `v*.*.*` to push a release.
- **Per-adapter examples** in README for Anthropic, OpenAI, LangGraph/LangChain,
  CrewAI, and MCP.

## [0.7.0] — 2026-05-16

### Added
- `audit.replay(path)` — iterator over events.
- `audit.export_csv(path, out)` / `audit.export_json(path, out)`.
- CLI `replay` and `export --format csv|json` sub-commands.
- `SQLiteBudgetStore` and `SQLiteKillRegistry` — persistent, multi-worker safe,
  stdlib `sqlite3` only.
- 229 tests, 96 % line coverage.

## [0.6.0] — 2026-05-16

### Added
- **LangChain / LangGraph adapter** — wraps `ChatAnthropic` / `ChatOpenAI`
  `.invoke()` / `.ainvoke()`.
- **CrewAI adapter** — wraps `crewai.LLM.call()` (LiteLLM-shaped responses,
  routes `anthropic/...` prefixes correctly).
- **MCP adapter** — wraps `ClientSession.call_tool()` with policy / HITL / audit.
  No token charge (tool calls are free).
- `ToolCallEvent` in the audit schema.
- `docs/TESTING.md` + `scripts/release_check.sh` — acceptance gate enforces
  ruff + mypy + pytest + coverage ≥ 85 % + smoke before tagging.
- Smoke test for the README five-line demo.

### Changed
- `Firewall.wrap()` dispatch order: Anthropic → OpenAI → LangChain → MCP → CrewAI → pass-through.

## [0.5.0] — 2026-05-16

### Added
- `HitlGate` protocol + `InMemoryHitlGate` (auto-approve/reject for tests).
- `WebhookHitlGate` — stdlib-only POST + polling, configurable timeout, zero deps.
- `HitlThreshold` rule — triggers HITL approval at a configurable % of budget cap.
- Firewall + every adapter wires `hitl_gate=`. Default-deny if no gate configured.

## [0.4.0] — 2026-05-16

### Added
- `RedisBudgetStore` and `RedisKillRegistry` — duck-typed Redis client support.
- Integration test wiring Firewall to Redis-backed stores via a fake Redis.

## [0.3.0] — 2026-05-16

### Added
- `BlockedSql` rule — keyword tokenizer with `read_only` / `no_ddl` modes.
- `BlockedShell` rule — 10-pattern shell-command blocklist.

## [0.2.0] — 2026-05-16

### Added
- `PolicyEngine` + `Rule` protocol — first non-`None` decision wins.
- `BlockedPatterns` and `BudgetThreshold` built-in rules.
- `PiiRedactor` — stdlib regex redactor for email, SSN, credit cards, phone.

## [0.1.0] — 2026-05-16

### Added
- `Firewall`, `BudgetTracker`, `AuditWriter` (hash-chained JSONL), kill switch.
- Anthropic adapter (`client.messages.create`).
- OpenAI adapter (`client.chat.completions.create`).
- `cost_for(provider, model, in_tokens, out_tokens)` with built-in pricing
  table `PRICING_v_2026_05`.
- CLI `verify` sub-command.
- 46 tests covering budget arithmetic, hash-chain integrity (property tests),
  adapter dispatch, kill-switch propagation.

[1.3.1]: https://github.com/avelikiy/llm-leash/releases/tag/v1.3.1
[1.3.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.3.0
[1.2.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.2.0
[1.1.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.1.0
[1.0.0]: https://github.com/avelikiy/llm-leash/releases/tag/v1.0.0
[0.7.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.7.0
[0.6.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.6.0
[0.5.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.5.0
[0.4.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.4.0
[0.3.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.3.0
[0.2.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.2.0
[0.1.0]: https://github.com/avelikiy/llm-leash/releases/tag/v0.1.0
