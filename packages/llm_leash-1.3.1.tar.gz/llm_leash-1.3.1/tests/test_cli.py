"""CLI tests for `llm-leash` verify / replay / export."""
from __future__ import annotations

import csv
import io
import json

import pytest

from llm_leash.cli import main


@pytest.fixture
def good_log(tmp_path):
    """Two valid chained model_call events."""
    from llm_leash.audit.schema import ModelCall
    from llm_leash.audit.writer import AuditWriter

    log = tmp_path / "audit.jsonl"
    w = AuditWriter(str(log), fsync=False)
    for _seq in range(2):
        w.write(ModelCall(
            ts="2026-05-16T00:00:00Z",
            session_id="s", tenant_id=None,
            seq=0, prev_hash="x",
            provider="openai", model="gpt-4o",
            input_tokens=10, output_tokens=5, cost_usd=0.001,
            request_hash="r", response_hash="s",
        ))
    w.close()
    return log


def test_cli_verify_good_log_returns_zero(good_log, capsys):
    rc = main(["verify", str(good_log)])
    assert rc == 0
    out = capsys.readouterr().out
    assert "2 events verified" in out


def test_cli_verify_missing_file_returns_one(tmp_path, capsys):
    rc = main(["verify", str(tmp_path / "no_such.jsonl")])
    # Non-existent file → verify_chain returns 0 (no exception) → exit 0.
    # FileNotFoundError path is for explicit broken-state files.
    assert rc == 0


def test_cli_verify_broken_chain_returns_two(tmp_path, capsys):
    log = tmp_path / "broken.jsonl"
    log.write_text(
        '{"kind":"kill","seq":1,"ts":"t","session_id":"s","tenant_id":null,'
        '"prev_hash":"WRONG","reason":"r","hash":"BAD"}\n'
    )
    rc = main(["verify", str(log)])
    assert rc == 2
    err = capsys.readouterr().err
    assert "BROKEN" in err


def test_cli_replay_outputs_jsonl(good_log, capsys):
    rc = main(["replay", str(good_log)])
    assert rc == 0
    out = capsys.readouterr().out.strip().splitlines()
    assert len(out) == 2
    for line in out:
        ev = json.loads(line)
        assert ev["kind"] == "model_call"


def test_cli_export_csv(good_log, capsys):
    rc = main(["export", str(good_log), "--format", "csv"])
    assert rc == 0
    out = capsys.readouterr().out
    rows = list(csv.DictReader(io.StringIO(out)))
    assert len(rows) == 2
    assert rows[0]["model"] == "gpt-4o"


def test_cli_export_json_default(good_log, capsys):
    rc = main(["export", str(good_log)])
    assert rc == 0
    out = capsys.readouterr().out
    arr = json.loads(out)
    assert len(arr) == 2
    assert arr[0]["provider"] == "openai"


@pytest.fixture
def hitl_db(tmp_path):
    """A populated SQLite HITL queue: one pending entry."""
    import asyncio

    from llm_leash.hitl.queue import SQLiteHitlQueue
    from llm_leash.types import Decision, ToolCall

    path = tmp_path / "hitl.db"
    q = SQLiteHitlQueue(str(path))
    rid = asyncio.run(q.enqueue(
        ToolCall(tool="t", args={"x": 1}, session_id="s", tenant_id=None),
        Decision(action="hitl", rule_id="r", reason="needs review"),
    ))
    q.close()
    return path, rid


def test_cli_hitl_list_shows_pending(hitl_db, capsys):
    path, rid = hitl_db
    rc = main(["hitl", "list", str(path)])
    assert rc == 0
    out = capsys.readouterr().out
    row = json.loads(out.strip().splitlines()[0])
    assert row["request_id"] == rid
    assert row["tool"] == "t"


def test_cli_hitl_approve(hitl_db, capsys):
    import asyncio

    from llm_leash.hitl.queue import SQLiteHitlQueue
    path, rid = hitl_db
    rc = main(["hitl", "approve", str(path), rid])
    assert rc == 0
    q = SQLiteHitlQueue(str(path))
    status, _ = asyncio.run(q.status(rid))
    q.close()
    assert status == "approved"


def test_cli_soc2_generates_evidence_pack(good_log, tmp_path, capsys):
    out = tmp_path / "evidence"
    rc = main([
        "soc2", str(good_log),
        "--out", str(out),
        "--period-start", "2026-01-01T00:00:00Z",
        "--period-end", "2026-12-31T23:59:59Z",
        "--org", "Test Co",
    ])
    assert rc == 0  # valid chain → exit 0
    assert (out / "executive-summary.html").exists()
    assert (out / "cc6_access_control.csv").exists()
    assert (out / "cc7_integrity.json").exists()
    assert (out / "bom.json").exists()
    err = capsys.readouterr().err
    assert "SOC 2 pack generated" in err
    assert "VERIFIED" in err


def test_cli_soc2_returns_two_on_broken_chain(tmp_path, capsys):
    log = tmp_path / "broken.jsonl"
    log.write_text(
        '{"kind":"kill","seq":1,"ts":"2026-06-01T00:00:00Z","session_id":"s",'
        '"tenant_id":null,"prev_hash":"WRONG","reason":"r","hash":"BAD"}\n'
    )
    out = tmp_path / "evidence"
    rc = main([
        "soc2", str(log),
        "--out", str(out),
        "--period-start", "2026-01-01T00:00:00Z",
        "--period-end", "2026-12-31T23:59:59Z",
    ])
    assert rc == 2


def test_cli_hitl_reject_records_reason(hitl_db, capsys):
    import asyncio

    from llm_leash.hitl.queue import SQLiteHitlQueue
    path, rid = hitl_db
    rc = main(["hitl", "reject", str(path), rid, "--reason", "not now"])
    assert rc == 0
    q = SQLiteHitlQueue(str(path))
    status, reason = asyncio.run(q.status(rid))
    q.close()
    assert status == "rejected"
    assert reason == "not now"
