"""Policy engine — evaluates a Rule chain and raises LeashBlocked on block."""
from __future__ import annotations

from ..types import Decision, LeashBlocked, PolicyContext, Rule, ToolCall

_DEFAULT = Decision(action="allow", rule_id="engine:default", reason="no rule matched")


class PolicyEngine:
    def __init__(self, rules: list[Rule]) -> None:
        self._rules = rules

    def evaluate(self, call: ToolCall, ctx: PolicyContext) -> Decision:
        for rule in self._rules:
            decision = rule.evaluate(call, ctx)
            if decision is None:
                continue
            if decision.action == "block":
                raise LeashBlocked(rule_id=decision.rule_id, reason=decision.reason)
            return decision
        return _DEFAULT


__all__ = ["PolicyEngine"]
