"""BudgetTracker — composes pricing + store, enforces caps."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, cast

from ..types import LeashKilled
from .pricing import PRICING_v_2026_05, cost_for
from .store import BudgetStore

BudgetDecision = Literal["under", "soft_exceeded", "hard_exceeded"]


@dataclass(frozen=True)
class BudgetState:
    cumulative_usd: float
    cap_usd: float | None
    decision: BudgetDecision


class BudgetTracker:
    """Per-session budget enforcement.

    `charge` records the actual cost of a completed call and returns the
    new state. If the hard cap is now exceeded, raises LeashKilled
    *after* recording (so the audit log reflects what happened).

    `estimate` is non-mutating — used for pre-call gating.
    """

    def __init__(
        self,
        *,
        session_id: str,
        hard_cap_usd: float | None,
        soft_cap_usd: float | None,
        store: BudgetStore,
        pricing: Mapping[str, Mapping[str, Mapping[str, float]]] | None = None,
    ) -> None:
        self._session_id = session_id
        self._hard = hard_cap_usd
        self._soft = soft_cap_usd
        self._store = store
        self._pricing = cast(Any, pricing) if pricing is not None else PRICING_v_2026_05

    async def cumulative_usd(self) -> float:
        return await self._store.get(self._session_id)

    async def estimate(self, *, provider: str, model: str, in_tokens: int) -> float:
        return cost_for(
            provider=provider, model=model,
            in_tokens=in_tokens, out_tokens=0,
            table=self._pricing,
        )

    async def charge(
        self,
        *,
        provider: str,
        model: str,
        in_tokens: int,
        out_tokens: int,
    ) -> BudgetState:
        delta = cost_for(
            provider=provider, model=model,
            in_tokens=in_tokens, out_tokens=out_tokens,
            table=self._pricing,
        )
        cumulative = await self._store.add(self._session_id, delta)

        decision: BudgetDecision = "under"
        if self._hard is not None and cumulative > self._hard:
            decision = "hard_exceeded"
        elif self._soft is not None and cumulative > self._soft:
            decision = "soft_exceeded"

        state = BudgetState(cumulative_usd=cumulative, cap_usd=self._hard, decision=decision)

        if decision == "hard_exceeded":
            raise LeashKilled(
                rule_id="budget:hard_cap",
                reason=f"budget: cumulative ${cumulative:.4f} exceeds hard cap ${self._hard:.4f}",
            )
        return state


__all__ = ["BudgetDecision", "BudgetState", "BudgetTracker"]
