"""llm-leash CLI.

Subcommands:
  verify <path>                        — verify the hash chain of an audit log
  replay <path>                        — pretty-print events as JSON lines
  export <path> --format csv|json      — export events to stdout (CSV or JSON)
  hitl list   <queue.db>               — list pending HITL requests
  hitl approve <queue.db> <request_id> — approve a pending request
  hitl reject  <queue.db> <request_id> --reason TEXT — reject a pending request
  soc2 <path> --out DIR --period-start ISO --period-end ISO
                                        — generate a SOC 2 evidence pack
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .audit.replay import export_csv, export_json, replay
from .audit.soc2 import generate_report
from .audit.verify import ChainBroken, verify_chain
from .hitl.queue import SQLiteHitlQueue


def _cmd_verify(args: argparse.Namespace) -> int:
    try:
        n = verify_chain(args.path)
    except ChainBroken as exc:
        print(f"BROKEN: {exc}", file=sys.stderr)
        return 2
    except FileNotFoundError:
        print(f"file not found: {args.path}", file=sys.stderr)
        return 1
    print(f"OK: {n} events verified")
    return 0


def _cmd_replay(args: argparse.Namespace) -> int:
    count = 0
    for ev in replay(args.path):
        sys.stdout.write(json.dumps(ev, ensure_ascii=False) + "\n")
        count += 1
    print(f"# replayed {count} events", file=sys.stderr)
    return 0


def _cmd_export(args: argparse.Namespace) -> int:
    if args.format == "csv":
        n = export_csv(args.path, sys.stdout)
    else:
        n = export_json(args.path, sys.stdout)
    print(f"# exported {n} events as {args.format}", file=sys.stderr)
    return 0


def _cmd_soc2(args: argparse.Namespace) -> int:
    report = generate_report(
        args.path, args.out,
        period_start=args.period_start,
        period_end=args.period_end,
        organization_name=args.org,
    )
    verdict = "VERIFIED" if report.integrity_ok else "BROKEN"
    print(
        f"SOC 2 pack generated → {report.output_dir}/  "
        f"({report.summary['total_events']} events; integrity: {verdict})",
        file=sys.stderr,
    )
    print(str(report.output_dir / "executive-summary.html"))
    return 0 if report.integrity_ok else 2


def _cmd_hitl(args: argparse.Namespace) -> int:
    queue = SQLiteHitlQueue(args.queue_path)
    try:
        if args.hitl_cmd == "list":
            items = asyncio.run(queue.list_pending())
            for req in items:
                row = {
                    "request_id": req.request_id,
                    "created_ts": req.created_ts,
                    "session_id": req.session_id,
                    "tenant_id": req.tenant_id,
                    "tool": req.tool,
                    "rule_id": req.rule_id,
                    "reason": req.reason,
                }
                sys.stdout.write(json.dumps(row, ensure_ascii=False) + "\n")
            print(f"# {len(items)} pending", file=sys.stderr)
            return 0
        if args.hitl_cmd == "approve":
            asyncio.run(queue.approve(args.request_id))
            print(f"approved {args.request_id}")
            return 0
        if args.hitl_cmd == "reject":
            asyncio.run(queue.reject(args.request_id, reason=args.reason))
            print(f"rejected {args.request_id}: {args.reason}")
            return 0
        return 1
    finally:
        queue.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="llm-leash")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_verify = sub.add_parser("verify", help="Verify the hash chain of an audit log.")
    p_verify.add_argument("path", help="Path to audit.jsonl")

    p_replay = sub.add_parser("replay", help="Print events from an audit log as JSON lines.")
    p_replay.add_argument("path", help="Path to audit.jsonl")

    p_export = sub.add_parser("export", help="Export an audit log as CSV or JSON.")
    p_export.add_argument("path", help="Path to audit.jsonl")
    p_export.add_argument(
        "--format", choices=["csv", "json"], default="json",
        help="Output format (default: json).",
    )

    p_soc2 = sub.add_parser("soc2", help="Generate a SOC 2 evidence pack from an audit log.")
    p_soc2.add_argument("path", help="Path to audit.jsonl")
    p_soc2.add_argument("--out", required=True, help="Output directory for the evidence pack.")
    p_soc2.add_argument(
        "--period-start", required=True,
        help="Report period start (ISO 8601, e.g. 2026-04-01T00:00:00Z).",
    )
    p_soc2.add_argument(
        "--period-end", required=True,
        help="Report period end (ISO 8601).",
    )
    p_soc2.add_argument(
        "--org", default=None,
        help="Organization name (printed in the executive summary).",
    )

    p_hitl = sub.add_parser("hitl", help="Operator commands for the HITL queue.")
    hitl_sub = p_hitl.add_subparsers(dest="hitl_cmd", required=True)
    p_hitl_list = hitl_sub.add_parser("list", help="List pending HITL requests.")
    p_hitl_list.add_argument("queue_path", help="Path to the SQLite HITL queue.")
    p_hitl_app = hitl_sub.add_parser("approve", help="Approve a pending request.")
    p_hitl_app.add_argument("queue_path")
    p_hitl_app.add_argument("request_id")
    p_hitl_rej = hitl_sub.add_parser("reject", help="Reject a pending request.")
    p_hitl_rej.add_argument("queue_path")
    p_hitl_rej.add_argument("request_id")
    p_hitl_rej.add_argument("--reason", required=True, help="Why the request was rejected.")

    args = parser.parse_args(argv)
    if args.cmd == "verify":
        return _cmd_verify(args)
    if args.cmd == "replay":
        return _cmd_replay(args)
    if args.cmd == "export":
        return _cmd_export(args)
    if args.cmd == "soc2":
        return _cmd_soc2(args)
    if args.cmd == "hitl":
        return _cmd_hitl(args)
    return 1


if __name__ == "__main__":
    sys.exit(main())
