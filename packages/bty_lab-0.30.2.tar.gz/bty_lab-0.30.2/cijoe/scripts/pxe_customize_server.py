"""
Stage the workspace for the PXE chain test
============================================

The server appliance ships with a known default credential
(``bty / bty``, baked at image-build time) so the test can boot the
production qcow2 unmodified and ``POST /ui/login`` directly. No
NoCloud overlay, no virt-customize, no DB seeding.

This step just lays out the test workspace under
``cijoe/_build/test-pxe/``:

- ``server.qcow2``       - working copy of the production qcow2
                          (rehydrated from .img.gz when only that's
                          present, the CI artifact shape).
- ``test-image.qcow2``   - 1 MiB dummy qcow2 the chain step uploads
                          to ``PUT /images/<name>``.
- ``boot/{vmlinuz,...}`` - copies of the live trio for the chain
                          step to upload to ``PUT /boot/<name>``.

Retargetable: False
"""

from __future__ import annotations

import errno
import logging as log
import shutil
from argparse import ArgumentParser
from pathlib import Path

# Artifact names carry the bty version (set at runtime from the
# repo's pyproject.toml so the chain test finds the freshly-built trio).
ARTIFACT_NAME_FMTS = (
    "bty-netboot-x86_64-v{version}.vmlinuz",
    "bty-netboot-x86_64-v{version}.initrd",
    "bty-netboot-x86_64-v{version}.squashfs",
)


def _read_bty_version() -> str:
    """Read bty-lab's version from the repo's top-level pyproject.toml.
    Mirrors :func:`usb_iso_build._read_bty_version`; kept inline to keep
    each cijoe script standalone."""
    pyproject = Path.cwd().parent / "pyproject.toml"
    for line in pyproject.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("version") and "=" in stripped:
            return stripped.split("=", 1)[1].strip().strip('"').strip("'")
    raise RuntimeError(f"could not find version line in {pyproject}")


def _artifact_names() -> tuple[str, ...]:
    version = _read_bty_version()
    return tuple(fmt.format(version=version) for fmt in ARTIFACT_NAME_FMTS)


def _server_gz_name() -> str:
    return f"bty-server-x86_64-v{_read_bty_version()}.img.gz"


def add_args(parser: ArgumentParser):
    del parser  # signature kept for cijoe consistency


def main(args, cijoe):
    del args
    cfg = cijoe.getconf("test.pxe", {})
    if not cfg:
        log.error("missing [test.pxe] section in cijoe config")
        return errno.EINVAL

    artifact_dir = Path(cfg["artifact_dir"])
    artifact_names = _artifact_names()
    server_qcow2_src = artifact_dir / "bty-server-x86_64.qcow2"
    server_gz = artifact_dir / _server_gz_name()

    # Reconstitute the qcow2 from .img.gz when only the .gz is
    # present (CI shape: release.yml uploads only the operator-
    # shippable .img.gz). Locally a fresh ``make build
    # VARIANT=server-x86`` leaves the qcow2 next to the .gz, so this
    # is a no-op.
    if not server_qcow2_src.is_file():
        if not server_gz.is_file():
            log.error(
                f"neither {server_qcow2_src.name} nor {server_gz.name} found in {artifact_dir}"
            )
            log.error("Run `make build VARIANT=server-x86` from the repo root first")
            return errno.ENOENT
        server_raw = artifact_dir / "bty-server-x86_64.img"
        log.info(f"Rehydrating {server_gz.name} -> {server_qcow2_src.name}")
        err, _ = cijoe.run_local(f"sh -c 'gunzip -d -c {server_gz} > {server_raw}'")
        if err:
            log.error("gunzip decompress failed")
            return err
        err, _ = cijoe.run_local(
            f"qemu-img convert -f raw -O qcow2 {server_raw} {server_qcow2_src}"
        )
        if err:
            log.error("qemu-img convert raw -> qcow2 failed")
            return err
        server_raw.unlink(missing_ok=True)

    for name in artifact_names:
        if not (artifact_dir / name).is_file():
            log.error(f"live artifact missing: {artifact_dir / name}")
            log.error("Run `make build VARIANT=netboot-x86` from the repo root first")
            return errno.ENOENT

    # Workspace: ``cijoe/_build/test-pxe/`` (gitignored alongside the
    # wheel-staging dir). Cleared at start so reruns don't accumulate
    # stale qcow2 copies / serial logs from a prior run.
    cijoe_dir = Path.cwd()
    workspace = cijoe_dir / "_build" / "test-pxe"
    if workspace.exists():
        shutil.rmtree(workspace)
    workspace.mkdir(parents=True)

    # Working copy of the server qcow2 - the chain step boots this
    # directly. No mutation: PAM auth uses the baked-in default
    # credential (bty/bty).
    server_dst = workspace / "server.qcow2"
    log.info(f"Copying {server_qcow2_src} -> {server_dst}")
    err, _ = cijoe.run_local(f"qemu-img convert -f qcow2 -O qcow2 {server_qcow2_src} {server_dst}")
    if err:
        log.error("qemu-img convert failed (server.qcow2 copy)")
        return err

    # 1 MiB dummy qcow2 the chain step PUTs to /images/<name>.
    dummy_image = workspace / "test-image.qcow2"
    err, _ = cijoe.run_local(f"qemu-img create -f qcow2 {dummy_image} 1M")
    if err:
        log.error("qemu-img create failed (dummy flash image)")
        return err

    # Stage the live trio so the chain step can PUT each via
    # ``PUT /boot/<name>``. The artifact dir itself is left
    # untouched.
    boot_stage = workspace / "boot"
    boot_stage.mkdir()
    for name in artifact_names:
        shutil.copy2(artifact_dir / name, boot_stage / name)

    log.info(f"Workspace ready at {workspace}")
    log.info(f"  server qcow2: {server_dst}")
    log.info(f"  dummy image:  {dummy_image}")
    log.info(f"  live trio:    {boot_stage}")
    return 0
