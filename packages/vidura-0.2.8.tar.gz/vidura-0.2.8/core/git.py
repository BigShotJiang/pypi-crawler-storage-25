"""Git analysis layer. Runs git commands to produce ChangedFile[]."""

from __future__ import annotations

import subprocess
from pathlib import Path

from core.extractor.types import ChangedFile
from core.logger import logger


def _run_git(cmd: str, cwd: str) -> str:
    """Run a git command and return stdout as a string."""
    result = subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if result.returncode != 0:
        raise RuntimeError(f"git command failed: {cmd}\n{result.stderr.strip()}")
    return result.stdout


class GitAnalyzer:
    def __init__(self, repo_path: str | None = None) -> None:
        self.repo_path = repo_path or str(Path.cwd())

    def get_current_branch(self) -> str:
        try:
            return _run_git("git rev-parse --abbrev-ref HEAD", self.repo_path).strip()
        except RuntimeError:
            raise RuntimeError("Failed to get current branch — is this a git repository?")

    def get_commit_metadata(self, base_branch: str) -> dict:
        """Return commit info for the PDF metadata block."""
        def _safe(cmd: str) -> str:
            try:
                return _run_git(cmd, self.repo_path).strip().strip('"')
            except RuntimeError:
                return ""

        diff_base = self._resolve_merge_base(base_branch)
        current = _safe("git rev-parse --short HEAD")
        previous = _safe(f"git rev-parse --short {diff_base}")
        author   = _safe('git log -1 --pretty=format:"%an"')
        message  = _safe('git log -1 --pretty=format:"%s"')
        ts       = _safe('git log -1 --pretty=format:"%ci"')
        tag      = _safe("git describe --tags --abbrev=0")

        return {
            "current_commit":  current,
            "previous_commit": previous,
            "authors":         author or "Engineering Team",
            "commit_message":  message,
            "commit_time":     ts,
            "version":         tag or f"v1.0-{current}",
            "repo_name":       Path(self.repo_path).name,
        }

    def get_changed_files(self, base_branch: str) -> list[ChangedFile]:
        """Returns files changed between the merge-base of baseBranch and HEAD."""
        diff_base = self._resolve_merge_base(base_branch)
        logger.debug(f"Diff base resolved to: {diff_base}")

        try:
            name_status = _run_git(f"git diff --name-status {diff_base}", self.repo_path)
        except RuntimeError as err:
            raise RuntimeError(f"git diff failed: {err}")

        changed_files: list[ChangedFile] = []
        for line in name_status.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split("\t")
            status_code = parts[0]
            file_path = parts[-1].replace("\\", "/")  # normalize Windows backslashes
            if not file_path:
                continue

            status = self._parse_status_code(status_code)
            changed_files.append(
                ChangedFile(
                    path=file_path,
                    status=status,
                    diff=self._get_file_diff(diff_base, file_path),
                    content=self._read_file_content(file_path) if status != "deleted" else None,
                )
            )

        logger.debug(f"Total changed files: {len(changed_files)}")
        return changed_files

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _resolve_merge_base(self, base_branch: str) -> str:
        # Try the configured base branch first
        try:
            current_branch = _run_git(
                "git rev-parse --abbrev-ref HEAD", self.repo_path
            ).strip()
            if current_branch == base_branch:
                logger.info(
                    f"[git] running on base branch '{base_branch}' — "
                    f"scanning full repository from initial commit"
                )
                return _run_git(
                    "git rev-list --max-parents=0 HEAD", self.repo_path
                ).strip()
        except RuntimeError:
            pass
        
        for candidate in self._branch_candidates(base_branch):
            try:
                result = _run_git(f"git merge-base {candidate} HEAD", self.repo_path).strip()
                if result:
                    if candidate != base_branch:
                        logger.info(f"Base branch '{base_branch}' not found — using '{candidate}'")
                    return result
            except RuntimeError:
                continue
        # Last resort: diff from the very first commit
        logger.warn(f"Could not resolve merge base for '{base_branch}' — diffing all commits")
        try:
            return _run_git("git rev-list --max-parents=0 HEAD", self.repo_path).strip()
        except RuntimeError:
            return base_branch

    def _branch_candidates(self, base_branch: str) -> list[str]:
        """Return branches to try in order when resolving merge base."""
        candidates = [base_branch]
        # Try remote tracking refs
        for remote in ("origin", "upstream"):
            candidates.append(f"{remote}/{base_branch}")
        # Auto-detect remote default branch via symbolic ref
        try:
            default = _run_git(
                "git symbolic-ref refs/remotes/origin/HEAD", self.repo_path
            ).strip().removeprefix("refs/remotes/origin/")
            if default and default not in candidates:
                candidates.append(default)
                candidates.append(f"origin/{default}")
        except RuntimeError:
            pass
        # Common fallbacks
        for fallback in ("master", "main", "develop", "trunk"):
            if fallback not in candidates:
                candidates.append(fallback)
        return candidates

    @staticmethod
    def _parse_status_code(code: str) -> str:
        if code.startswith("A"):
            return "added"
        if code.startswith("D"):
            return "deleted"
        return "modified"

    def _get_file_diff(self, diff_base: str, file_path: str) -> str:
        try:
            return _run_git(f'git diff {diff_base} -- "{file_path}"', self.repo_path)
        except RuntimeError:
            return ""

    def _read_file_content(self, file_path: str) -> str | None:
        try:
            abs_path = Path(self.repo_path) / file_path
            if abs_path.exists():
                return abs_path.read_text(encoding="utf-8")
        except Exception:
            pass
        return None

    def get_first_commit(self) -> str:
        try:
            return _run_git(
                "git hash-object -t tree /dev/null", # 4b825dc642cb6eb9a060e54bf8d69288fbee4904 - empty tree
                self.repo_path
            ).strip()
        except RuntimeError:
            # fallback for Windows where /dev/null may not exist
            return _run_git(
                "git rev-list --max-parents=0 HEAD",
                self.repo_path
            ).strip()
        
    def get_all_files(self) -> list[ChangedFile]:
        """Diff against empty tree — returns every file in the repo as 'added'."""
        empty_tree = self._get_empty_tree()
        logger.debug(f"Full scan from empty tree: {empty_tree}")

        try:
            name_status = _run_git(f"git diff --name-status {empty_tree}", self.repo_path)
        except RuntimeError as err:
            raise RuntimeError(f"git diff failed: {err}")

        changed_files: list[ChangedFile] = []
        for line in name_status.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split("\t")
            status_code = parts[0]
            file_path = parts[-1].replace("\\", "/")
            if not file_path:
                continue

            status = self._parse_status_code(status_code)
            changed_files.append(
                ChangedFile(
                    path=file_path,
                    status=status,
                    diff=self._get_file_diff(empty_tree, file_path),
                    content=self._read_file_content(file_path) if status != "deleted" else None,
                )
            )

        logger.debug(f"Total files (full scan): {len(changed_files)}")
        return changed_files

    def _get_empty_tree(self) -> str:
        try:
            return _run_git("git hash-object -t tree /dev/null", self.repo_path).strip()
        except RuntimeError:
            return _run_git("git rev-list --max-parents=0 HEAD", self.repo_path).strip()