# """Shared diff-processing utilities used by agent tool handlers."""

# from __future__ import annotations
# from pathlib import Path 
# from core.extractor.types import ChangedFile


# def build_diff_batches(
#     files: list[ChangedFile],
#     batch_size: int = 3,
#     per_file_cap: int = 7_000,
# ) -> list[tuple[list[ChangedFile], str]]:
#     """Group files into batches and build a diff context string per batch.

#     Each batch gets its own LLM call — prevents large commits from silently
#     dropping endpoints/findings due to a single-blob token cap.

#     Returns list of (files_in_batch, diff_context_string).
#     """
#     batches: list[tuple[list[ChangedFile], str]] = []
#     for i in range(0, len(files), batch_size):
#         group = files[i: i + batch_size]
#         parts: list[str] = []
#         for f in group:
#             header = f"=== {f.path} ({f.status}) ===\n"
#             body = (f.diff or "")[:per_file_cap]
#             if body.strip():
#                 parts.append(header + body)
#         if parts:
#             batches.append((group, "\n\n".join(parts)))
#     return batches
"""Shared diff-processing utilities used by agent tool handlers."""

from __future__ import annotations
from pathlib import Path
from core.extractor.types import ChangedFile

# These files define schemas that other files reference.
# They must be sent as FULL CONTENT, not just the diff.
#
# Critical case: serializers.py uses `fields = "__all__"` which means
# "every field from the model". The LLM cannot expand this unless it
# also sees the complete model class — so "model"/"models" is essential.
_FULL_CONTENT_HINTS = {
    "serializer", "serializers",
    "schema", "schemas",
    "model", "models",        # <- was missing — this is why schemas were empty
    "dto", "dtos",
    "form", "forms",
    "entity",
    "request", "response",
    "input", "payload",
}


def build_diff_batches(
    files: list[ChangedFile],
    batch_size: int = 5,
    per_file_cap: int = 80_000,
) -> list[tuple[list[ChangedFile], str]]:
    """Group files into batches and build a diff context string per batch.

    For model/serializer files: sends FULL FILE CONTENT so the LLM can
    resolve fields = "__all__" and other model references.

    For all other files: sends the git diff (+/- lines only).
    """
    batches: list[tuple[list[ChangedFile], str]] = []

    for i in range(0, len(files), batch_size):
        group = files[i: i + batch_size]
        parts: list[str] = []

        for f in group:
            header = f"=== {f.path} ({f.status}) ===\n"
            file_stem = Path(f.path).stem.lower()
            is_schema_or_model = any(h in file_stem for h in _FULL_CONTENT_HINTS)

            if is_schema_or_model and f.content:
                # Send full file — field definitions must never be truncated.
                # 2x cap because these are the source of truth for schemas.
                body = (
                    "# FULL FILE CONTENT (use this for schema/field extraction):\n"
                    + f.content[: per_file_cap * 2]
                )
            else:
                # For route/view/helper files the diff is enough.
                body = (f.diff or "")[: per_file_cap]

            if body.strip():
                parts.append(header + body)

        if parts:
            batches.append((group, "\n\n".join(parts)))

    return batches