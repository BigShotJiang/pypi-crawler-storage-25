"""Memory manager (L3). Single-tier: global store only.

All memory reads/writes go to the global store (HTTP in SaaS mode, Git in local mode).
No local filesystem memory — nothing written to the project repo.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from core.logger import logger
from core.storage.memory_store import MemoryStore

MAX_SKILL_CHARS = 8_000


@dataclass
class MemorySearchResult:
    source: str
    section: str
    score: float


class MemoryManager:
    """Single-tier memory backed by the global store.

    SaaS mode  → GitMemoryStore (Vidura's memory repo, short-lived GitHub App token)
    Local mode → GitMemoryStore (configured via VIDURA_GLOBAL_MEMORY_REPO)
    No store   → all operations are no-ops with a debug warning
    """

    def __init__(
        self,
        global_store: MemoryStore | None = None,
        *,
        global_files: dict[str, str] | None = None,
        global_initial_content: dict[str, str] | None = None,
        categories: dict[str, str] | None = None,
    ) -> None:
        self._global = global_store
        self._global_files = global_files or {}
        self._global_initial_content = global_initial_content or {}
        self._categories = categories or {}

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def initialize(self) -> None:
        if self._global and self._global_initial_content:
            logger.step("Initializing global memory store with default content")
            self._global.initialize(self._global_initial_content)
            logger.info(f"Global memory initialized: {list(self._global_initial_content.keys())}")
        elif self._global:
            logger.info("Global memory store connected (no initial content to seed)")
        else:
            logger.warn("No memory store configured — memory features disabled")

    # ── Read ──────────────────────────────────────────────────────────────────

    def read_skill(self, filename: str) -> str:
        if not self._global:
            logger.debug(f"[memory] read_skill({filename}) skipped — no store")
            return ""
        logger.step(f"Reading memory file: {filename}")
        content = self._global.read(filename)
        logger.info(f"Memory read: {filename} ({len(content)} chars)")
        return content

    # ── Search ────────────────────────────────────────────────────────────────

    def search_memory(self, query: str, max_results: int = 5) -> list[MemorySearchResult]:
        if not self._global:
            logger.debug("[memory] search_memory skipped — no store")
            return []

        terms = [t.lower() for t in re.split(r"\W+", query) if len(t) >= 2]
        if not terms:
            return []

        logger.step(f"Searching memory: '{query}' (terms: {terms})")
        filenames = self._global.list_files() or list(self._global_files.values())
        results = self._search_store(self._global, terms, filenames)
        results.sort(key=lambda r: r.score, reverse=True)
        top = results[:max_results]
        logger.info(f"Memory search returned {len(top)} result(s) for '{query}'")
        return top

    # ── Write ─────────────────────────────────────────────────────────────────

    def store_memory(
        self,
        category: str,
        title: str,
        content: str,
        mem_type: str = "episodic",
        tags: list | None = None,
        priority: str = "medium",
        patterns: list | None = None,
        examples: str = "",
        relates_to: list | None = None,
    ) -> None:
        if not self._global:
            logger.debug("[memory] No global store — skipping store_memory")
            return

        filename = self._categories.get(category) or next(iter(self._global_files.values()), None)
        if not filename:
            return

        from datetime import datetime, timezone
        import uuid
        now = datetime.now(timezone.utc).isoformat()
        _tags = tags or [category]
        _patterns = patterns or []
        _relates_to = relates_to or []

        pattern_lines = "\n".join(
            f"- when: {p.get('when', 'N/A')}\n- then: {p.get('then', 'N/A')}\n- confidence: {p.get('confidence', 0.5)}"
            for p in _patterns
        ) or "- when: N/A\n- then: N/A\n- confidence: 0.5"

        entry = (
            f"\n# {title}\n\n"
            f"## Metadata\n"
            f"- id: {uuid.uuid4()}\n"
            f"- type: {mem_type}\n"
            f"- created_at: {now}\n"
            f"- updated_at: {now}\n"
            f"- tags: [{', '.join(_tags)}]\n"
            f"- priority: {priority}\n\n"
            f"---\n\n"
            f"## Summary\n{content[:300]}\n\n"
            f"---\n\n"
            f"## Details\n{content}\n\n"
            f"---\n\n"
            f"## Patterns (IMPORTANT)\n{pattern_lines}\n\n"
            f"---\n\n"
            f"## Examples\n{examples or 'N/A'}\n\n"
            f"---\n\n"
            f"## Relations\n- relates_to: [{', '.join(_relates_to)}]\n- derived_from: []\n"
        )
        logger.step(f"Writing memory: [{category}] '{title}' → {filename}")
        self._global.append(filename, entry)
        self._prune_store(self._global, list(self._global_files.values()))
        logger.success(f"Memory stored: [{category}] {title} ({len(entry)} chars written to {filename})")

    def store_memory_batch(self, entries: list[dict]) -> None:
        """Write multiple memory entries in one operation via the store's write_batch().

        Builds filename→content map (appending to existing content) then delegates
        to write_batch() — git backend commits once, default backend falls back to
        individual writes. No private store internals accessed.
        """
        if not self._global or not entries:
            return

        from datetime import datetime, timezone
        import uuid

        logger.step(f"[memory] Batch writing {len(entries)} memory entries")

        # Read existing content for each target file once
        file_contents: dict[str, str] = {}
        written: list[str] = []

        for entry in entries:
            category = entry.get("category", "general")
            title = entry.get("title", "")
            content = entry.get("content", "")
            if not title or not content:
                continue

            filename = self._categories.get(category) or next(iter(self._global_files.values()), None)
            if not filename:
                continue

            if filename not in file_contents:
                file_contents[filename] = self._global.read(filename)

            now = datetime.now(timezone.utc).isoformat()
            _tags = entry.get("tags") or [category]
            _patterns = entry.get("patterns") or []
            _relates_to = entry.get("relates_to") or []

            pattern_lines = "\n".join(
                f"- when: {p.get('when', 'N/A')}\n- then: {p.get('then', 'N/A')}\n- confidence: {p.get('confidence', 0.5)}"
                for p in _patterns
            ) or "- when: N/A\n- then: N/A\n- confidence: 0.5"

            text = (
                f"\n# {title}\n\n"
                f"## Metadata\n"
                f"- id: {uuid.uuid4()}\n"
                f"- type: {entry.get('mem_type', 'episodic')}\n"
                f"- created_at: {now}\n"
                f"- updated_at: {now}\n"
                f"- tags: [{', '.join(_tags)}]\n"
                f"- priority: {entry.get('priority', 'medium')}\n\n"
                f"---\n\n"
                f"## Summary\n{content[:300]}\n\n"
                f"---\n\n"
                f"## Details\n{content}\n\n"
                f"---\n\n"
                f"## Patterns (IMPORTANT)\n{pattern_lines}\n\n"
                f"---\n\n"
                f"## Examples\n{entry.get('examples') or 'N/A'}\n\n"
                f"---\n\n"
                f"## Relations\n- relates_to: [{', '.join(_relates_to)}]\n- derived_from: []\n"
            )
            file_contents[filename] = file_contents[filename] + text + "\n"
            written.append(f"[{category}] {title}")
            logger.debug(f"[memory] queued: [{category}] {title} → {filename}")

        if not written:
            return

        # Prune oversized files before committing
        for filename in list(file_contents.keys()):
            content = file_contents[filename]
            if len(content) > MAX_SKILL_CHARS:
                lines = content.split("\n")
                header = "\n".join(lines[:8])
                keep_from = int(len(lines) * 0.4)
                file_contents[filename] = header + "\n...[older entries pruned]\n" + "\n".join(lines[keep_from:])
                logger.warn(f"[memory] {filename} pruned during batch write")

        # Single atomic write — git backend does one push
        self._global.write_batch(file_contents)
        logger.success(f"[memory] Batch committed: {written}")

    def record_feedback(self, feature: str, rating: str, note: str = "") -> None:
        if not self._global:
            return
        if rating not in ("good", "excellent"):
            logger.info(f"[memory] Skipping feedback write — rating '{rating}' does not meet threshold (good/excellent)")
            return

        from datetime import datetime, timezone
        import uuid
        now = datetime.now(timezone.utc).isoformat()
        date = now[:10]
        symbol = {"good": "+", "bad": "-", "improved": "^"}.get(rating, "·")
        entry = (
            f"\n# [{symbol}] {feature} — {rating.upper()}\n\n"
            f"## Metadata\n"
            f"- id: {uuid.uuid4()}\n"
            f"- type: episodic\n"
            f"- created_at: {now}\n"
            f"- updated_at: {now}\n"
            f"- tags: [feedback, {rating}]\n"
            f"- priority: {'high' if rating == 'bad' else 'medium'}\n\n"
            f"---\n\n"
            f"## Summary\nFeedback for feature '{feature}' on {date}: {rating.upper()}.\n\n"
            f"---\n\n"
            f"## Details\n{note or 'No additional notes.'}\n\n"
            f"---\n\n"
            f"## Patterns (IMPORTANT)\n"
            f"- when: similar feature encountered\n"
            f"- then: apply lesson from this feedback\n"
            f"- confidence: 0.8\n\n"
            f"---\n\n"
            f"## Examples\nFeature: {feature}\nRating: {rating}\n\n"
            f"---\n\n"
            f"## Relations\n- relates_to: []\n- derived_from: [agent-run]\n"
        )

        feedback_file = self._categories.get("feedback") or self._global_files.get("feedback")
        if feedback_file:
            logger.step(f"Recording run feedback: [{rating}] {feature} → {feedback_file}")
            self._global.append(feedback_file, entry)
            self._prune_store(self._global, list(self._global_files.values()))
            logger.success(f"Feedback stored: [{rating}] {feature}")

    # ── Agent-improvement patterns ────────────────────────────────────────────

    def write_agent_patterns(self, patterns: dict) -> None:
        """Append extracted patterns. Good runs only. Pure agent knowledge — no org data."""
        if not self._global:
            logger.debug("[memory] write_agent_patterns skipped — no store")
            return
        logger.step("Updating global agent patterns from good run")

        from datetime import datetime, timezone
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

        file_map = {
            "promptPatterns": "prompt-patterns.md",
            "stepSequence":   "step-sequences.md",
            "logicNotes":     "logic-notes.md",
            "authStrategies": "auth-strategies.md",
            "commonPatterns": "common-patterns.md",
        }

        wrote_any = False
        for key, filename in file_map.items():
            value = patterns.get(key)
            if not value:
                continue

            new_items: list[str] = value if isinstance(value, list) else [value]
            new_items = [p.strip() for p in new_items if p and p.strip()]
            if not new_items:
                continue

            # Read existing content and extract known patterns to deduplicate
            existing = self._global.read(filename)
            existing_lower = existing.lower()
            novel = [p for p in new_items if not self._pattern_already_known(p, existing_lower)]

            if not novel:
                logger.info(f"[memory] {filename}: all {len(new_items)} pattern(s) already known — skipping")
                continue

            logger.info(f"[memory] {filename}: {len(novel)} new pattern(s) of {len(new_items)} (skipped {len(new_items)-len(novel)} duplicates)")

            import uuid
            # Build a clean entry: only the novel pattern bullets, no timestamp header
            bullet_lines = "\n".join(f"- {p}" for p in novel)
            pattern_blocks = "\n".join(
                f"- when: pattern observed\n- then: {p[:200]}\n- confidence: 0.7"
                for p in novel[:3]
            )
            content = (
                f"\n# {key}\n\n"
                f"## Metadata\n"
                f"- id: {uuid.uuid4()}\n"
                f"- type: pattern\n"
                f"- tags: [{key}, agent-patterns]\n"
                f"- priority: high\n\n"
                f"---\n\n"
                f"## Details\n{bullet_lines}\n\n"
                f"---\n\n"
                f"## Patterns (IMPORTANT)\n{pattern_blocks}\n\n"
                f"---\n\n"
                f"## Relations\n- relates_to: []\n- derived_from: [agent-run]\n"
            )
            self._global.append(filename, content)
            wrote_any = True

        if wrote_any:
            logger.success("[memory] Global agent patterns updated — only novel patterns written")

    def get_global_patterns(self, max_chars: int = 4000) -> str:
        """Read pattern files for injection into system prompt."""
        if not self._global:
            return ""

        logger.step("Loading global memory patterns for system prompt injection")
        sections = []
        for filename, label in [
            ("prompt-patterns.md",  "Prompt Patterns"),
            ("step-sequences.md",   "Step Sequences"),
            ("logic-notes.md",      "Logic Notes"),
            ("auth-strategies.md",  "Auth Strategies"),
            ("common-patterns.md",  "Common Patterns"),
        ]:
            content = self._global.read(filename).strip()
            if not content or len(content) < 50:
                continue
            # Split on H1 entries (new memory format uses `# Title` as entry boundary)
            # Fall back to splitting on H2 for legacy files written before format change
            if re.search(r"^# ", content, re.MULTILINE):
                entries = re.split(r"(?=^# )", content, flags=re.MULTILINE)
            else:
                entries = re.split(r"(?=^## )", content, flags=re.MULTILINE)
            # Take the most recent entries (last 5) — recency already weighted in search
            recent_entries = [e.strip() for e in entries if e.strip()][-5:]
            recent = "\n\n".join(recent_entries)
            if recent:
                sections.append(f"### {label}\n{recent}")

        if not sections:
            logger.info("No global patterns found in memory store")
            return ""

        result = "## Agent Knowledge (from previous good runs)\n\n" + "\n\n".join(sections)
        logger.info(f"Loaded {len(sections)} global pattern section(s) ({len(result)} chars)")
        return result[:max_chars]

    # ── Auto-context ──────────────────────────────────────────────────────────

    def get_auto_context(self, branch: str, max_chars: int = 1500) -> str:
        """Search memory for branch-relevant context to inject at turn 1."""
        if not self._global:
            return ""
        logger.step(f"Auto-context search for branch '{branch}'")

        branch_parts = re.split(r"[/_\-]", branch)
        keywords = {
            w.lower() for w in branch_parts
            if len(w) >= 3 and w.lower() not in {"the", "and", "for", "api", "main", "feature", "feat"}
        }
        if not keywords:
            return ""

        query = " ".join(list(keywords)[:8])
        results = self.search_memory(query, max_results=3)
        if not results:
            return ""

        parts = ["## Memory Context"]
        total = len(parts[0])
        for r in results:
            entry = f"\n### {r.source}\n{r.section}"
            if total + len(entry) > max_chars:
                break
            parts.append(entry)
            total += len(entry)

        context = "\n".join(parts) if len(parts) > 1 else ""
        if context:
            logger.info(f"Auto-context: {len(parts)-1} section(s) injected from memory ({len(context)} chars)")
        else:
            logger.info(f"Auto-context: no relevant memory found for branch keywords {list(keywords)}")
        return context

    @property
    def has_global(self) -> bool:
        return self._global is not None

    # ── Private helpers ───────────────────────────────────────────────────────

    def _search_store(
        self,
        store: MemoryStore,
        terms: list[str],
        filenames: list[str],
    ) -> list[MemorySearchResult]:
        results = []
        for filename in filenames:
            content = store.read(filename)
            if not content:
                continue
            sections = re.split(r"(?=^# )", content, flags=re.MULTILINE)
            total_sections = max(len(sections), 1)
            for idx, section in enumerate(sections):
                section = section.strip()
                if not section:
                    continue
                lower = section.lower()
                term_score = sum(lower.count(t) for t in terms)
                if term_score == 0:
                    continue
                # Recency boost: sections later in file are more recent (append-only store)
                recency = (idx + 1) / total_sections  # 0..1, higher = more recent
                score = term_score * (0.7 + 0.3 * recency)
                results.append(MemorySearchResult(
                    source=filename,
                    section=section[:1000],
                    score=score,
                ))
        return results

    @staticmethod
    def _pattern_already_known(pattern: str, existing_lower: str) -> bool:
        """Return True if pattern is substantially similar to existing content."""
        if not existing_lower:
            return False
        p = pattern.lower().strip()
        # Exact substring match
        if p in existing_lower:
            return True
        # Token overlap — only apply when enough meaningful tokens exist.
        # Short patterns (< 5 meaningful tokens) are too ambiguous for overlap scoring
        # and would produce false duplicates.
        stopwords = {"the", "a", "an", "is", "are", "in", "of", "to", "and", "or", "for", "not", "use", "when", "that"}
        tokens = {t for t in re.split(r"\W+", p) if len(t) >= 4 and t not in stopwords}
        if len(tokens) < 5:
            return False  # too short to score reliably — let it through
        matched = sum(1 for t in tokens if t in existing_lower)
        return matched / len(tokens) >= 0.65

    def _prune_store(self, store: MemoryStore, filenames: list[str]) -> None:
        for filename in filenames:
            content = store.read(filename)
            if len(content) <= MAX_SKILL_CHARS:
                continue
            lines = content.split("\n")
            header = "\n".join(lines[:8])
            keep_from = int(len(lines) * 0.4)
            pruned = header + "\n...[older entries pruned]\n" + "\n".join(lines[keep_from:])
            store.write(filename, pruned)
            logger.warn(f"[memory] {filename} exceeded {MAX_SKILL_CHARS} chars — pruned to {len(pruned)} chars")
