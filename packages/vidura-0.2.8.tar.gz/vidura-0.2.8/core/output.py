"""Structured agent output — VCS-agnostic JSON that the SaaS platform translates to VCS API calls."""

from __future__ import annotations

import json
import sys
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class AgentOutput:
    """Standard output contract for all agents."""

    agent: str
    status: str       # completed, failed, no_change
    output_type: str  # file_commit, review, pull_request, report, …
    error_code: str = ""   # empty string = no error; see core/errors.py for codes
    metadata: dict[str, Any] = field(default_factory=dict)
    result: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


def create_output(
    agent: str,
    status: str,
    output_type: str,
    result: dict[str, Any],
    *,
    error_code: str = "",
    branch: str = "",
    base_branch: str = "",
    tokens_used: dict[str, int] | None = None,
    duration_ms: int = 0,
    ci_context: dict[str, Any] | None = None,
    commit_hash: str = "",
) -> AgentOutput:
    """Create an AgentOutput with populated metadata."""
    import os
    metadata: dict[str, Any] = {
        "run_id": os.environ.get("VIDURA_RUN_ID") or str(uuid.uuid4()),
        "branch": branch,
        "base_branch": base_branch,
        "commit_hash": commit_hash,
        "tokens_used": tokens_used or {"input": 0, "output": 0},
        "duration_ms": duration_ms,
    }

    if ci_context:
        metadata.update(ci_context)

    return AgentOutput(
        agent=agent,
        status=status,
        output_type=output_type,
        error_code=error_code,
        metadata=metadata,
        result=result,
    )


def write_output(output: AgentOutput, output_file: str | None = None) -> None:
    """Write AgentOutput as JSON to a file or stdout."""
    json_str = output.to_json()

    if output_file:
        Path(output_file).parent.mkdir(parents=True, exist_ok=True)
        Path(output_file).write_text(json_str, encoding="utf-8")
    else:
        sys.stdout.write(json_str + "\n")


async def post_callback(output: AgentOutput, callback_url: str, token: str) -> None:
    """POST the AgentOutput JSON to the SaaS callback URL."""
    import urllib.request

    data = output.to_json().encode("utf-8")
    req = urllib.request.Request(
        callback_url,
        data=data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except Exception as err:
        from core.logger import logger
        logger.warn(f"Callback POST failed: {err}")
        return None


async def upload_artifact(pdf_path: str, upload_url: str, token: str) -> str | None:
    """Upload a generated PDF to the SaaS platform artifact store.

    Returns the artifact ID from the platform response, or None on failure.
    Upload failures are non-fatal — they are logged as warnings.
    """
    import asyncio
    import urllib.request
    from core.logger import logger

    path = Path(pdf_path)
    if not path.exists():
        logger.warn(f"Artifact upload skipped — file not found: {pdf_path}")
        return None

    def _do_upload() -> str | None:
        with path.open("rb") as fh:
            data = fh.read()

        boundary = "ViduraUploadBoundary"
        filename = path.name
        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
            f"Content-Type: application/pdf\r\n\r\n"
        ).encode("utf-8") + data + f"\r\n--{boundary}--\r\n".encode("utf-8")

        req = urllib.request.Request(
            upload_url,
            data=body,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": f"multipart/form-data; boundary={boundary}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read())
                artifact_id = result.get("artifact_id") or result.get("id", "")
                logger.info(f"Artifact uploaded: {filename} → {artifact_id}")
                return artifact_id
        except Exception as err:
            logger.warn(f"Artifact upload failed: {err}")
            return None

    return await asyncio.get_event_loop().run_in_executor(None, _do_upload)


def write_run_log(output: AgentOutput, repo_path: str) -> str:
    """Write a structured JSON run log to .vidura/runs/<run_id>.json.

    Non-fatal — log failures are silently ignored.
    Returns the log file path, or empty string on failure.
    """
    try:
        run_id = output.metadata.get("run_id", "unknown")
        log_dir = Path(repo_path) / ".vidura" / "runs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"{run_id}.json"
        log_path.write_text(output.to_json(), encoding="utf-8")
        return str(log_path)
    except Exception:
        return ""
