"""Git repo-backed memory store for shared global memory across projects.

The admin creates a private Git repo and sets the URL as an env var.
The agent clones it locally, reads/writes skill files, and pushes changes.
The end user never sees the repo URL or knows it exists.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from core.logger import logger
from core.storage.memory_store import MemoryStore


class GitMemoryStore(MemoryStore):
    """Reads / writes skill files to a shared Git repository.

    On first use, clones the repo to ~/.agentic-docs/global-memory-repo/.
    On subsequent uses, pulls latest changes before reading.
    After writes, commits and pushes automatically.

    Files are stored under ``<local_dir>/<subdir>/`` when *subdir* is set,
    enabling per-agent isolation inside a single shared repo.
    """

    def __init__(
        self,
        repo_url: str,
        branch: str = "main",
        token: str | None = None,
        local_path: str | None = None,
        subdir: str = "",
    ) -> None:
        self.branch = branch
        self.subdir = subdir.strip("/") if subdir else ""

        if token and repo_url.startswith("https://"):
            parts = repo_url.split("://", 1)
            self.repo_url = f"{parts[0]}://x-access-token:{token}@{parts[1]}"
        else:
            self.repo_url = repo_url

        self.local_dir = Path(local_path) if local_path else Path.home() / ".agentic-docs" / "global-memory-repo"
        self._ensure_repo()

    def _file_path(self, filename: str) -> Path:
        """Resolve the full path to a memory file, honouring subdir."""
        if self.subdir:
            return self.local_dir / self.subdir / filename
        return self.local_dir / filename

    def _ensure_repo(self) -> None:
        """Clone or pull the repo, then create the agent subdir if needed."""
        try:
            if (self.local_dir / ".git").exists():
                # Refresh token in remote URL every time — tokens rotate
                self._git("remote", "set-url", "origin", self.repo_url)
                self._git("fetch", "origin", self.branch)
                self._git("reset", "--hard", f"origin/{self.branch}")
            else:
                self.local_dir.mkdir(parents=True, exist_ok=True)
                self._git_global(
                    "clone", "--branch", self.branch, "--single-branch",
                    "--depth", "1", self.repo_url, str(self.local_dir),
                    timeout=120,
                )
            if self.subdir:
                (self.local_dir / self.subdir).mkdir(parents=True, exist_ok=True)
            suffix = f"/{self.subdir}" if self.subdir else ""
            logger.debug(f"Global memory repo ready: {self.local_dir}{suffix}")
        except Exception as err:
            logger.warn(
                f"[memory] Global memory repo unavailable — memory reads/writes will be skipped. "
                f"Reason: {err}"
            )
            self._unavailable = True

    @property
    def _is_unavailable(self) -> bool:
        return getattr(self, "_unavailable", False)

    def _pull(self) -> None:
        try:
            self._git("pull", "--rebase", "origin", self.branch)
        except subprocess.TimeoutExpired:
            logger.warn("[memory] git pull timed out — proceeding with stale local state")
        except Exception as err:
            logger.warn(f"[memory] git pull failed: {err} — proceeding with stale local state")

    def _push(self, message: str, _retries: int = 3) -> None:
        """Commit and push with retry-on-conflict for concurrent run safety."""
        for attempt in range(1, _retries + 1):
            try:
                self._git("add", ".")
                status = subprocess.run(
                    ["git", "status", "--porcelain"],
                    cwd=str(self.local_dir),
                    capture_output=True, text=True,
                )
                if not status.stdout.strip():
                    return  # nothing to push

                self._git("commit", "-m", message)
                self._git("push", "origin", self.branch)
                logger.debug(f"Global memory pushed: {message}")
                return
            except subprocess.TimeoutExpired:
                logger.warn(f"[memory] git push timed out on attempt {attempt}/{_retries}")
                if attempt < _retries:
                    continue
                return
            except subprocess.CalledProcessError as err:
                stderr = (err.stderr or "").lower()
                push_rejected = "rejected" in stderr or "non-fast-forward" in stderr or "fetch first" in stderr
                if push_rejected and attempt < _retries:
                    logger.warn(
                        f"[memory] Push conflict on attempt {attempt}/{_retries} — "
                        f"pulling and retrying: {message}"
                    )
                    try:
                        # Reset staged changes, pull remote, re-apply our file writes, re-commit
                        self._git("reset", "--soft", "HEAD~1")  # undo commit, keep changes staged
                        self._git("stash")
                        self._git("pull", "--rebase", "origin", self.branch)
                        self._git("stash", "pop")
                    except Exception as pull_err:
                        logger.warn(f"[memory] Rebase failed: {pull_err} — memory write may be lost")
                        return
                else:
                    logger.warn(f"[memory] Push failed after {attempt} attempt(s): {err.stderr or err}")
                    return
            except Exception as err:
                logger.warn(f"[memory] Push failed: {err}")
                return

    def read(self, filename: str) -> str:
        if self._is_unavailable:
            return ""
        self._pull()
        path = self._file_path(filename)
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return ""
        except Exception as err:
            logger.warn(f"Git store read failed for {filename}: {err}")
            return ""

    def write(self, filename: str, content: str) -> None:
        if self._is_unavailable:
            logger.warn(f"[memory] Skipping write to {filename} — global store unavailable")
            return
        try:
            path = self._file_path(filename)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            self._push(f"update {self.subdir + '/' if self.subdir else ''}{filename}")
        except Exception as err:
            logger.warn(f"Git store write failed for {filename}: {err}")

    def append(self, filename: str, content: str) -> None:
        if self._is_unavailable:
            return
        self._pull()
        existing = self.read(filename)
        self.write(filename, existing + content + "\n")

    def exists(self, filename: str) -> bool:
        if self._is_unavailable:
            return False
        self._pull()
        return self._file_path(filename).exists()

    def list_files(self) -> list[str]:
        if self._is_unavailable:
            return []
        self._pull()
        base = self.local_dir / self.subdir if self.subdir else self.local_dir
        if not base.exists():
            return []
        return [f.name for f in base.iterdir() if f.is_file() and f.suffix == ".md"]

    def write_batch(self, entries: dict[str, str]) -> None:
        """Write multiple files in one pull → N writes → one push cycle."""
        if self._is_unavailable or not entries:
            return
        self._pull()
        for filename, content in entries.items():
            try:
                path = self._file_path(filename)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="utf-8")
                logger.debug(f"[memory] batch wrote: {filename}")
            except Exception as err:
                logger.warn(f"[memory] batch write failed for {filename}: {err}")
        filenames = ", ".join(entries.keys())
        self._push(f"store_memory batch: {filenames}")

    def initialize(self, initial_content: dict[str, str]) -> None:
        if self._is_unavailable:
            return
        self._pull()
        created = False
        for filename, content in initial_content.items():
            path = self._file_path(filename)
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_text(content, encoding="utf-8")
                created = True
                logger.debug(f"Initialized global skill: {filename}")
        if created:
            self._push("initialize global memory skill files")

    def _git(self, *args: str, timeout: int = 30) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            cwd=str(self.local_dir),
            capture_output=True,
            text=True,
            check=True,
            timeout=timeout,
        )

    def _git_global(self, *args: str, timeout: int = 60) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            check=True,
            timeout=timeout,
        )
