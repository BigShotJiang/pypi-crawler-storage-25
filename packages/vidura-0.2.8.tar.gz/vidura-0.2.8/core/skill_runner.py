"""Skill runner — generic executor for agent and single-shot skills."""

from __future__ import annotations

import json

from core.llm.base import LLMProvider
from core.logger import logger
from core.retry import retry_sync
from core.skill_loader import SkillDefinition


class SkillRunner:
    """Executes any skill by loading its definition and calling the LLM."""

    def __init__(self, provider: LLMProvider) -> None:
        self.provider = provider
        self.last_usage: TokenUsage | None = None  # populated after each run()

    def run(self, skill: SkillDefinition, context: dict) -> dict:
        """Run a single-shot skill. Returns parsed result dict.

        After returning, ``self.last_usage`` holds the token counts for this call.
        """
        from core.llm.base import TokenUsage as _TokenUsage
        self.last_usage = _TokenUsage()

        system_prompt = skill.body
        user_message = self._build_user_message(skill, context)

        try:
            response = retry_sync(
                lambda: self.provider.chat(
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_message}],
                    # Default raised from 2048 → 16000.
                    # 2048 caused scan batches to truncate mid-JSON for any file
                    # with more than ~3 findings, silently discarding all findings.
                    max_tokens=context.get("max_tokens", 406000),
                ),
                max_attempts=3,
                base_delay=2.0,
                label=skill.name,
            )
            self.last_usage = response.usage
            logger.debug(
                f"[skill:{skill.name}] tokens: {response.usage.input_tokens} in / {response.usage.output_tokens} out"
            )

            if skill.output_format == "json":
                return self._parse_json(response.content, skill.name)

            return {"content": response.content}

        except Exception as err:
            logger.warn(f"Skill '{skill.name}' failed after retries: {err}")
            return self._fallback(skill, str(err))

    def _build_user_message(self, skill: SkillDefinition, context: dict) -> str:
        """Build the user message from context.

        The skill body is the system prompt. The user message is built
        from the context dict — each key becomes a section.
        """
        parts: list[str] = []

        if "documentation" in context:
            parts.append(f"## Documentation Draft\n```markdown\n{context['documentation']}\n```")

        if "delta_summary" in context:
            parts.append(f"## API Delta (ground truth)\n```json\n{context['delta_summary']}\n```")

        if "existing_docs" in context:
            parts.append(f"## Existing Documentation (for style comparison)\n```markdown\n{context['existing_docs']}\n```")

        # Any extra context keys become sections
        skip = {"documentation", "delta_summary", "existing_docs", "max_tokens"}
        for key, value in context.items():
            if key not in skip and isinstance(value, str) and value.strip():
                parts.append(f"## {key.replace('_', ' ').title()}\n{value}")

        return "\n\n".join(parts) if parts else "Review the provided content."

    @staticmethod
    def _parse_json(content: str, skill_name: str) -> dict:
        """Parse JSON from LLM response, stripping markdown fences if present.

        On parse failure attempts partial recovery for truncated responses —
        common when the extractor hits its output token limit mid-array.
        """
        text = content.strip()

        # Strip markdown code fences
        if text.startswith("```"):
            lines = text.split("\n")
            lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines).strip()

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Attempt partial recovery for truncated JSON arrays
            recovered = SkillRunner._recover_truncated_json(text)
            if recovered is not None:
                logger.warn(
                    f"Skill '{skill_name}' response truncated — partially recovered "
                    f"({recovered.get('_recovered_endpoints', 0)} endpoint(s) salvaged)"
                )
                return recovered
            logger.warn(f"Skill '{skill_name}' returned non-JSON response")
            return {"error": f"Could not parse JSON from {skill_name}", "raw": content[:4000]}

    @staticmethod
    def _recover_truncated_json(text: str) -> dict | None:
        """Salvage endpoints from a JSON response truncated mid-stream.

        Strategy: walk backwards from the end of the text, stripping characters
        until the truncated portion can be closed into valid JSON. Handles the
        common case where the LLM hits its output token cap mid-object inside
        a 'new' / 'modified' / 'removed' array.
        """
        if not text.startswith("{"):
            return None

        # Step 1: find the last position of a complete JSON object boundary `}`
        # and truncate everything after it, then attempt to close the structure.
        pos = len(text)
        while pos > 0:
            pos = text.rfind("}", 0, pos)
            if pos == -1:
                break
            # Candidate: text up to and including this `}`
            fragment = text[: pos + 1]
            # Count unclosed brackets/braces to determine what closers to append
            opens_brace = fragment.count("{") - fragment.count("}")
            opens_bracket = fragment.count("[") - fragment.count("]")
            # Build closer string
            closer = ("]" * max(opens_bracket, 0)) + ("}" * max(opens_brace, 0))
            candidate = fragment + closer
            try:
                data = json.loads(candidate)
                if isinstance(data, dict):
                    total = (
                        len(data.get("new", []))
                        + len(data.get("modified", []))
                        + len(data.get("removed", []))
                    )
                    if total > 0:
                        data["_recovered"] = True
                        data["_recovered_endpoints"] = total
                        return data
            except (json.JSONDecodeError, ValueError):
                pass
            pos -= 1  # try next `}` to the left

        return None

    @staticmethod
    def _fallback(skill: SkillDefinition, error_msg: str) -> dict:
        """Return a sensible fallback based on the skill name."""
        summary = f"{skill.name} failed: {error_msg}"

        if skill.name == "critic":
            return {
                "scores": {
                    "completeness": 0, "clarity": 0, "accuracy": 0,
                    "structure": 0, "developerExperience": 0,
                },
                "overallScore": 0,
                "criticalIssues": [],
                "suggestions": [summary],
                "summary": summary,
            }
        elif skill.name == "evaluator":
            return {
                "qualityScore": 0,
                "dimensions": {
                    "targetAudienceFit": 0, "completeness": 0,
                    "codeExamples": 0, "consistency": 0,
                    "styleConsistency": None,
                },
                "integratorBlockers": [],
                "suggestions": [summary],
                "summary": summary,
            }

        return {"error": summary}