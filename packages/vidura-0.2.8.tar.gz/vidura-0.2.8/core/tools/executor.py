"""Generic stateful tool dispatcher — manifest-driven.

Handles core tools (file, search, plan, memory) directly.
Delegates agent-specific tools to dynamically-loaded handler from manifest.
"""

from __future__ import annotations

import fnmatch
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.agent_manifest import AgentManifest, load_agent_tool_handler
from core.config import AgentConfig
from core.git import GitAnalyzer
from core.llm.base import LLMProvider
from core.logger import logger
from core.memory import MemoryManager
from core.tools.core_tools import build_tool_set, get_core_tools_by_names

TerminalStatus = str  # "GENERATED", "NO_API_CHANGE", etc.

SEARCH_SKIP_DIRS = {".git", "node_modules", "__pycache__", "venv", ".venv", ".tox", "dist", "build"}
MAX_PLAN_REVISIONS = 3

# Legacy guard — blocks writes to removed system categories.
MEMORY_SYSTEM_CATEGORIES = {"api", "auth", "versioning", "general"}


@dataclass
class ToolResult:
    """Result of a tool execution."""

    content: str
    is_terminal: bool
    terminal_status: TerminalStatus | None = None
    output_path: str | None = None
    feature_name: str | None = None


@dataclass
class AgentPlan:
    """Agent's self-created plan."""

    goal: str
    steps: list[str]
    revision_count: int = 0


class ToolExecutor:
    """Manifest-driven tool dispatcher. Core tools are built-in;
    agent-specific tools are loaded from the manifest's tool modules."""

    def __init__(
        self,
        repo_path: str,
        config: AgentConfig,
        branch: str,
        memory: MemoryManager,
        manifest: AgentManifest,
        secondary_providers: dict[str, LLMProvider] | None = None,
        skills_dir: Path | None = None,
        usage: dict | None = None,       
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self.branch = branch
        self._memory = memory
        self._manifest = manifest
        self._secondary_providers = secondary_providers or {}
        self._skills_dir = skills_dir or Path(repo_path) / "skills"
        self._usage: dict = usage if usage is not None else {}  # ← add this

        self._git = GitAnalyzer(repo_path)
        self._plan: AgentPlan | None = None
        self._current_draft: str = ""
        self.token_budget_pct: float = 0.0  # updated each turn by workflow; tools use this to tighten responses
        self._run_quality: str = "unknown"  # set to "good"/"excellent" by agent handlers after successful write
        self._pending_memory: list[dict] = []  # store_memory calls queued until run quality confirmed

        # Terminal tools from manifest
        self._terminal_tools: set[str] = set(manifest.workflow.terminal_tools)

        # Load agent-specific tool handlers
        self._agent_handlers: list[Any] = []
        self._agent_tool_defs: list[dict] = []
        self._agent_tool_names: set[str] = set()

        for module_path in manifest.tools.agent_specific:
            try:
                module = load_agent_tool_handler(module_path)
                handler_cls = getattr(module, "ToolHandler", None)
                if handler_cls:
                    handler = handler_cls(
                        repo_path=repo_path,
                        config=config,
                        branch=branch,
                        memory=memory,
                        secondary_providers=secondary_providers or {},
                        skills_dir=self._skills_dir,
                        executor=self,
                    )
                    self._agent_handlers.append(handler)
                tool_defs = getattr(module, "TOOL_DEFINITIONS", [])
                self._agent_tool_defs.extend(tool_defs)
                for td in tool_defs:
                    self._agent_tool_names.add(td["name"])
            except (ImportError, AttributeError) as err:
                logger.warn(f"Failed to load agent tools from {module_path}: {err}")

        # Build core tool definitions from manifest's core tool list
        self._core_tool_defs = get_core_tools_by_names(manifest.tools.core)
        self._core_tool_names = {t["name"] for t in self._core_tool_defs}

        # Exploration-only tools (gated behind progressive state)
        self._exploration_only = set(manifest.tools.exploration_only)

    def is_terminal(self, tool_name: str) -> bool:
        return tool_name in self._terminal_tools

    def get_tool_definitions(self) -> list[dict]:
        """Return the current tool set based on progressive gating."""
        gate_field = self._manifest.workflow.progressive_gate_field
        gate_active = False
        if gate_field:
            gate_active = bool(getattr(self, gate_field, ""))

        if gate_active:
            # All tools available
            return build_tool_set(self._core_tool_defs, self._agent_tool_defs)
        else:
            # Exclude exploration-only tools
            return build_tool_set(
                self._core_tool_defs,
                self._agent_tool_defs,
                exclude=self._exploration_only,
            )

    async def execute(self, tool_name: str, tool_input: dict) -> ToolResult:
        logger.info(f"Tool call: {tool_name}")

        # Core tool handlers
        core_handlers = {
            "get_changed_files": lambda: self._get_changed_files(),
            "read_file": lambda: self._read_file(
                tool_input.get("path", ""),
                tool_input.get("offset", 0),
                tool_input.get("limit", 100),
            ),
            "search_codebase": lambda: self._search_codebase(
                tool_input.get("pattern", ""),
                tool_input.get("glob"),
                tool_input.get("maxResults", 20),
            ),
            "create_plan": lambda: self._create_plan(
                tool_input.get("goal", ""),
                tool_input.get("steps", []),
            ),
            "revise_plan": lambda: self._revise_plan(
                tool_input.get("reason", ""),
                tool_input.get("updatedSteps", []),
            ),
            "read_memory": lambda: self._read_memory(
                tool_input.get("skill", ""),
                tool_input.get("scope", "project"),
            ),
            "search_memory": lambda: self._search_memory(
                tool_input.get("query", ""),
                tool_input.get("maxResults", 5),
                tool_input.get("scope", "all"),
            ),
            "store_memory": lambda: self._store_memory(
                tool_input.get("category", "general"),
                tool_input.get("title", ""),
                tool_input.get("content", ""),
                tool_input.get("scope", "project"),
                mem_type=tool_input.get("mem_type", "episodic"),
                tags=tool_input.get("tags", []),
                priority=tool_input.get("priority", "medium"),
                patterns=tool_input.get("patterns", []),
                examples=tool_input.get("examples", ""),
                relates_to=tool_input.get("relates_to", []),
            ),
            "store_draft": lambda: self._store_draft(tool_input.get("documentation", "")),
            "signal_no_change": lambda: self._signal_no_change(tool_input.get("reason", "")),
        }

        handler = core_handlers.get(tool_name)
        if handler:
            return handler()

        # Delegate to agent-specific handlers
        for agent_handler in self._agent_handlers:
            if hasattr(agent_handler, "can_handle") and agent_handler.can_handle(tool_name):
                return await agent_handler.handle(tool_name, tool_input)

        return ToolResult(
            content=json.dumps({"error": f"Unknown tool: {tool_name}"}),
            is_terminal=False,
        )

    # ─── Core tool implementations ───────────────────────────────────────────

    def _get_changed_files(self) -> ToolResult:
        # all_changed = self._git.get_changed_files(self.config.base_branch)
        if self.config.is_first_run:
            logger.info("First run — scanning full repository from initial commit")
            first_commit = self._git.get_first_commit()
            # all_changed = self._git.get_changed_files(first_commit)
            all_changed = self._git.get_all_files()  # ← use new method directly

        else:
            logger.info("Incremental run — scanning git diff only")
            all_changed = self._git.get_changed_files(self.config.base_branch)

            logger.info(f"Changed files: {len(all_changed)} total")

        # preview = [
        #     {
        #         "path": f.path,
        #         "status": f.status,
        #     }
        #     for f in all_changed
        # ]
        
        # Only show API-relevant files in the preview to save tokens
        api_exts = {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".java", ".kt", ".rb", ".php"}
        skip_parts = {".git", "__pycache__", "node_modules", "dist", "build", "migrations"}

        preview = [
            {"path": f.path, "status": f.status}
            for f in all_changed
            if Path(f.path).suffix in api_exts
            and not (set(Path(f.path).parts) & skip_parts)
        ][:20]  # cap at 20 files shown to LLM

        # Store for agent handlers to use
        self._changed_files = all_changed

        return ToolResult(
            content=json.dumps({"total": len(all_changed), "files": preview}),
            is_terminal=False,
        )

    def _read_file(self, path: str, offset: int = 0, limit: int = 100) -> ToolResult:
        # Tighten the hard cap when budget is running low to avoid burning tokens on large file reads
        hard_cap = 300 if self.token_budget_pct < 0.70 else (150 if self.token_budget_pct < 0.85 else 60)
        limit = min(max(limit, 1), hard_cap)
        offset = max(offset, 0)

        repo_root = Path(self.repo_path).resolve()
        target = (repo_root / path).resolve()

        if not str(target).startswith(str(repo_root)):
            return ToolResult(
                content=json.dumps({"error": "Path traversal not allowed."}),
                is_terminal=False,
            )

        if not target.exists():
            return ToolResult(
                content=json.dumps({"error": f"File not found: {path}"}),
                is_terminal=False,
            )

        if not target.is_file():
            return ToolResult(
                content=json.dumps({"error": f"Not a file: {path}"}),
                is_terminal=False,
            )

        try:
            lines = target.read_text(encoding="utf-8", errors="replace").split("\n")
            total_lines = len(lines)
            selected = lines[offset : offset + limit]

            numbered = [f"{offset + i + 1}: {line}" for i, line in enumerate(selected)]

            return ToolResult(
                content=json.dumps({
                    "path": path,
                    "totalLines": total_lines,
                    "offset": offset,
                    "linesReturned": len(selected),
                    "content": "\n".join(numbered),
                }),
                is_terminal=False,
            )
        except Exception as err:
            return ToolResult(
                content=json.dumps({"error": f"Failed to read file: {err}"}),
                is_terminal=False,
            )

    def _search_codebase(self, pattern: str, glob_filter: str | None = None, max_results: int = 20) -> ToolResult:
        # Reduce result cap as budget tightens — each match line costs input tokens on the next turn
        result_cap = 50 if self.token_budget_pct < 0.70 else (20 if self.token_budget_pct < 0.85 else 10)
        max_results = min(max(max_results, 1), result_cap)

        try:
            compiled = re.compile(pattern, re.IGNORECASE)
        except re.error as err:
            return ToolResult(
                content=json.dumps({"error": f"Invalid regex: {err}"}),
                is_terminal=False,
            )

        repo_root = Path(self.repo_path)
        matches: list[dict] = []

        for file_path in repo_root.rglob("*"):
            if len(matches) >= max_results:
                break

            parts = file_path.relative_to(repo_root).parts
            if any(part in SEARCH_SKIP_DIRS for part in parts):
                continue

            if not file_path.is_file():
                continue

            rel_path = str(file_path.relative_to(repo_root)).replace("\\", "/")

            if glob_filter and not fnmatch.fnmatch(rel_path, glob_filter):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            for i, line in enumerate(content.split("\n"), start=1):
                if compiled.search(line):
                    matches.append({
                        "file": rel_path,
                        "line": i,
                        "content": line.strip()[:200],
                    })
                    if len(matches) >= max_results:
                        break

        return ToolResult(
            content=json.dumps({"pattern": pattern, "totalMatches": len(matches), "matches": matches}),
            is_terminal=False,
        )

    def _create_plan(self, goal: str, steps: list[str]) -> ToolResult:
        self._plan = AgentPlan(goal=goal, steps=steps)
        logger.info(f"Plan created: {goal} ({len(steps)} steps)")

        return ToolResult(
            content=json.dumps({
                "planCreated": True,
                "goal": goal,
                "steps": steps,
                "message": "Plan registered. Proceed with execution. Call revise_plan if you need to adjust.",
            }),
            is_terminal=False,
        )

    def _revise_plan(self, reason: str, updated_steps: list[str]) -> ToolResult:
        if not self._plan:
            return ToolResult(
                content=json.dumps({"error": "No plan exists. Call create_plan first."}),
                is_terminal=False,
            )

        if self._plan.revision_count >= MAX_PLAN_REVISIONS:
            return ToolResult(
                content=json.dumps({
                    "error": f"Plan revision limit reached ({MAX_PLAN_REVISIONS}). Stop revising and execute the current plan.",
                    "currentSteps": self._plan.steps,
                }),
                is_terminal=False,
            )

        self._plan.steps = updated_steps
        self._plan.revision_count += 1
        logger.info(f"Plan revised (#{self._plan.revision_count}): {reason}")

        return ToolResult(
            content=json.dumps({
                "planRevised": True,
                "reason": reason,
                "revisionNumber": self._plan.revision_count,
                "updatedSteps": updated_steps,
            }),
            is_terminal=False,
        )

    def _read_memory(self, skill: str, scope: str = "global") -> ToolResult:
        file_map = self._manifest.memory.global_files
        filename = file_map.get(skill)
        if not filename:
            valid = ", ".join(file_map.keys())
            return ToolResult(
                content=json.dumps({"error": f"Unknown skill: '{skill}'. Valid: {valid}"}),
                is_terminal=False,
            )

        raw = self._memory.read_skill(filename)
        content = raw[:3000] + "\n...[truncated]" if len(raw) > 3000 else raw
        return ToolResult(content=content, is_terminal=False)

    def _search_memory(self, query: str, max_results: int = 5, scope: str = "all") -> ToolResult:
        results = self._memory.search_memory(query, max_results=max_results)

        if not results:
            return ToolResult(
                content=json.dumps({"totalResults": 0, "results": [], "message": "No results found."}),
                is_terminal=False,
            )

        return ToolResult(
            content=json.dumps({
                "totalResults": len(results),
                "results": [{"source": r.source, "score": r.score, "section": r.section} for r in results],
            }),
            is_terminal=False,
        )

    def _store_memory(
        self,
        category: str,
        title: str,
        content: str,
        scope: str = "global",
        mem_type: str = "episodic",
        tags: list | None = None,
        priority: str = "medium",
        patterns: list | None = None,
        examples: str = "",
        relates_to: list | None = None,
    ) -> ToolResult:
        if not title or not content:
            return ToolResult(
                content=json.dumps({"error": "Both title and content are required."}),
                is_terminal=False,
            )

        valid_categories = list(self._manifest.memory.categories.keys())
        if category in MEMORY_SYSTEM_CATEGORIES or category not in valid_categories:
            return ToolResult(
                content=json.dumps({
                    "error": f"Invalid category '{category}'. Valid: {', '.join(valid_categories)}."
                }),
                is_terminal=False,
            )

        # Queue the write — flush only after run quality confirmed good/excellent.
        # Prevents bad runs from poisoning memory with wrong conventions.
        self._pending_memory.append({
            "category": category, "title": title, "content": content,
            "mem_type": mem_type, "tags": tags or [category],
            "priority": priority, "patterns": patterns or [],
            "examples": examples, "relates_to": relates_to or [],
        })
        logger.debug(f"[memory] store_memory queued: [{category}] {title} (pending quality confirmation)")

        return ToolResult(
            content=json.dumps({
                "stored": True,
                "queued": True,
                "category": category,
                "title": title,
                "message": "Queued — will be written to memory after run completes successfully.",
            }),
            is_terminal=False,
        )

    def flush_pending_memory(self) -> None:
        """Called by agent handlers after a confirmed good run. Writes all queued memory entries
        in a single git commit to avoid N sequential push operations."""
        if not self._pending_memory:
            return
        if self._run_quality not in ("good", "excellent"):
            logger.info(
                f"[memory] Discarding {len(self._pending_memory)} queued store_memory call(s) "
                f"— run quality '{self._run_quality}' does not meet threshold"
            )
            self._pending_memory.clear()
            return

        logger.step(f"[memory] Flushing {len(self._pending_memory)} queued store_memory call(s) (quality: {self._run_quality})")
        self._memory.store_memory_batch(self._pending_memory)
        self._pending_memory.clear()

    def _store_draft(self, documentation: str) -> ToolResult:
        if not documentation.strip():
            return ToolResult(
                content=json.dumps({"error": "Draft cannot be empty."}),
                is_terminal=False,
            )
        self._current_draft = documentation
        self._store_draft_calls = getattr(self, "_store_draft_calls", 0) + 1
        char_count = len(documentation)
        logger.info(f"Draft stored ({char_count} chars)")
        return ToolResult(
            content=json.dumps({
                "stored": True,
                "charCount": char_count,
                "message": "Draft stored. You can now call downstream tools.",
            }),
            is_terminal=False,
        )

    def _signal_no_change(self, reason: str) -> ToolResult:
        logger.success(f"NO_CHANGE: {reason}")
        # Discard any queued store_memory calls — no output means no quality confirmation
        if self._pending_memory:
            logger.info(
                f"[memory] Discarding {len(self._pending_memory)} queued store_memory call(s) "
                f"— signal_no_change: no output produced"
            )
            self._pending_memory.clear()
        return ToolResult(
            content=json.dumps({"noChange": True, "reason": reason}),
            is_terminal=True,
            terminal_status="NO_API_CHANGE",
        )
