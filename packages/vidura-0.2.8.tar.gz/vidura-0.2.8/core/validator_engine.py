"""Declarative validation engine — reads rules from validator.md skill file."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from core.extractor.types import ApiEndpoint, ExtractedApiDelta
from core.logger import logger
from core.skill_loader import SkillDefinition

VALID_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class ValidatorEngine:
    """Applies declarative validation rules from a skill definition."""

    def validate(self, documentation: str, delta: ExtractedApiDelta, skill: SkillDefinition) -> ValidationResult:
        """Run all rules from the skill definition against the documentation."""
        errors: list[str] = []
        warnings: list[str] = []

        for rule in skill.rules:
            rule_id = rule.get("id", "unknown")
            severity = rule.get("severity", "error")
            check = rule.get("check", "")
            message_template = rule.get("message", f"Rule '{rule_id}' failed")

            issues = self._run_check(check, rule, documentation, delta, message_template)

            if severity == "error":
                errors.extend(issues)
            else:
                warnings.extend(issues)

        logger.debug(f"Validation — errors: {len(errors)}, warnings: {len(warnings)}")
        return ValidationResult(valid=len(errors) == 0, errors=errors, warnings=warnings)

    def _run_check(
        self,
        check: str,
        rule: dict,
        doc: str,
        delta: ExtractedApiDelta,
        message_template: str,
    ) -> list[str]:
        handlers = {
            "contains": self._check_contains,
            "regex_absent": self._check_regex_absent,
            "http_methods": self._check_http_methods,
            "endpoints_in_delta": self._check_endpoints_in_delta,
            "delta_coverage": self._check_delta_coverage,
            "delta_coverage_new": self._check_delta_coverage_new,
            "delta_coverage_modified": self._check_delta_coverage_modified,
            "delta_coverage_removed": self._check_delta_coverage_removed,
            "endpoint_section_contains": self._check_endpoint_section_contains,
            "bearer_endpoints_have_status_code": self._check_bearer_endpoints_have_status_code,
            "status_code_table_sort_order": self._check_status_code_table_sort_order,
            "contains_when_new_or_modified_endpoints_present": self._check_contains_when_new_or_modified,
            "regex_absent_in_curl_blocks": self._check_regex_absent_in_curl_blocks,
            "no_3col_table": self._check_no_3col_request_table,
        }

        handler = handlers.get(check)
        if not handler:
            return []

        return handler(rule, doc, delta, message_template)

    @staticmethod
    def _check_contains(rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        import re as _re
        feature_name = _re.sub(r"^(feature|feat|fix|chore|hotfix|release)/", "", delta.feature)
        pattern = rule.get("pattern", "").replace("{feature}", feature_name)

        # Primary check: exact match with derived feature name
        if pattern in doc:
            return []

        # Fallback: accept any "# Feature: <non-empty-name>" if the branch name
        # itself is a protected branch (main/master/develop/dev) — the LLM may
        # derive a more meaningful name from the changed files.
        protected = {"main", "master", "develop", "dev", "trunk"}
        if feature_name in protected:
            if _re.search(r'^# Feature:\s+\S+', doc, _re.MULTILINE):
                return []

        return [message.replace("{feature}", feature_name)]

    @staticmethod
    def _check_regex_absent(rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        issues: list[str] = []
        for pattern_str in rule.get("patterns", []):
            compiled = re.compile(pattern_str, re.IGNORECASE)
            m = compiled.search(doc)
            if m:
                issues.append(message.replace("{match}", m.group(0)))
        return issues

    @staticmethod
    def _check_http_methods(rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        allowed = set(rule.get("allowed", VALID_METHODS))
        issues: list[str] = []
        for m in re.finditer(r"`([A-Z]+)\s+/[^\s`]*`", doc):
            if m.group(1) not in allowed:
                issues.append(f"Invalid HTTP method in documentation: {m.group(1)}")
        return issues

    def _check_endpoints_in_delta(self, rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        all_ground_truth = self._all_endpoints(delta)
        documented = self._extract_documented_endpoints(doc)

        issues: list[str] = []
        for d in documented:
            found = any(
                ep.method == d["method"] and self._paths_match(ep.path, d["path"])
                for ep in all_ground_truth
            )
            if not found:
                issues.append(f"Invented endpoint not in structured data: {d['method']} {d['path']}")
        return issues

    def _check_delta_coverage(self, rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        # Legacy — kept for backward compat with old validator.md files
        return self._check_delta_coverage_new(rule, doc, delta, message)

    def _check_delta_coverage_new(self, rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        documented = self._extract_documented_endpoints(doc)
        issues: list[str] = []
        for ep in delta.new:
            covered = any(
                d["method"] == ep.method and self._paths_match(d["path"], ep.path)
                for d in documented
            )
            if not covered:
                issues.append(f"New endpoint missing from documentation: {ep.method} {ep.path}")
        return issues

    def _check_delta_coverage_modified(self, rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        documented = self._extract_documented_endpoints(doc)
        issues: list[str] = []
        for m in delta.modified:
            ep = m.after
            covered = any(
                d["method"] == ep.method and self._paths_match(d["path"], ep.path)
                for d in documented
            )
            if not covered:
                issues.append(f"Modified endpoint missing from documentation: {ep.method} {ep.path}")
        return issues

    def _check_delta_coverage_removed(self, rule: dict, doc: str, delta: ExtractedApiDelta, message: str) -> list[str]:
        documented = self._extract_documented_endpoints(doc)
        issues: list[str] = []
        for ep in delta.removed:
            covered = any(
                d["method"] == ep.method and self._paths_match(d["path"], ep.path)
                for d in documented
            )
            if not covered:
                issues.append(f"Removed endpoint not mentioned in documentation: {ep.method} {ep.path}")
        return issues

    @staticmethod
    def _all_endpoints(delta: ExtractedApiDelta) -> list[ApiEndpoint]:
        return [
            *delta.new,
            *(m.after for m in delta.modified),
            *(m.before for m in delta.modified),
            *delta.removed,
        ]

    @staticmethod
    def _extract_documented_endpoints(doc: str) -> list[dict[str, str]]:
        results: list[dict[str, str]] = []
        seen: set[tuple[str, str]] = set()
        # Matches: ### GET /path | `GET /path` | **GET /path** | GET /path (bare)
        pattern = re.compile(
            r"(?:^#{1,4}\s+)?[`*]{0,2}(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(/[^\s`*\"'\n]+)[`*]{0,2}",
            re.MULTILINE,
        )
        for m in pattern.finditer(doc):
            method, path = m.group(1), m.group(2).rstrip(".,;:")
            key = (method, path)
            if key not in seen:
                seen.add(key)
                results.append({"method": method, "path": path})
        return results

    @staticmethod
    def _paths_match(a: str, b: str) -> bool:
        def norm(p: str) -> str:
            p = re.sub(r":[a-zA-Z_]\w*", "{p}", p)
            p = re.sub(r"\{[^}]+\}", "{p}", p)
            return p

        return norm(a) == norm(b) or a == b
    
    @staticmethod
    def _check_endpoint_section_contains(
        rule: dict, doc: str, delta: ExtractedApiDelta, message: str
    ) -> list[str]:
        """Check that each ### METHOD /path section contains at least one required pattern."""
        required_any = rule.get("required_any", [])
        if not required_any:
            return []

        issues: list[str] = []

        # Find all ### METHOD /path section headings
        section_pattern = re.compile(
            r'^(?:#{1,4}\s+)?(?:[`*]{0,2})(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(/[^\s`*"\']+)(?:[`*]{0,2})',
            re.MULTILINE,
        )
        matches = list(section_pattern.finditer(doc))

        for i, match in enumerate(matches):
            method = match.group(1)
            path = match.group(2).rstrip(".,;:")

            # Extract content from this heading to the next heading (or end of doc)
            start = match.start()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(doc)
            section_content = doc[start:end]

            # Check if any required pattern is present in this section
            found = any(pattern in section_content for pattern in required_any)
            if not found:
                issues.append(
                    message
                    .replace("{method}", method)
                    .replace("{path}", path)
                )

        return issues
    
    @staticmethod
    def _check_bearer_endpoints_have_status_code(
        rule: dict, doc: str, delta: ExtractedApiDelta, message: str
    ) -> list[str]:
        """Every bearer-auth endpoint section must contain a 401 row in its errors table."""
        required_code = str(rule.get("required_code", 401))
        issues: list[str] = []

        section_pattern = re.compile(
            r'^(?:#{1,4}\s+)?(?:[`*]{0,2})(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(/[^\s`*"\']+)(?:[`*]{0,2})',
            re.MULTILINE,
        )
        matches = list(section_pattern.finditer(doc))

        # Build a set of bearer endpoints from delta
        bearer_paths: set[tuple[str, str]] = set()
        for ep in [*delta.new, *(m.after for m in delta.modified)]:
            if ep.auth and ep.auth.type == "bearer":
                bearer_paths.add((ep.method, ep.path))

        for i, match in enumerate(matches):
            method = match.group(1)
            path = match.group(2).rstrip(".,;:")

            # Only check bearer endpoints
            is_bearer = any(
                method == bm and ValidatorEngine._paths_match_static(path, bp)
                for bm, bp in bearer_paths
            )
            if not is_bearer:
                continue

            start = match.start()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(doc)
            section_content = doc[start:end]

            if f"| {required_code}" not in section_content and f"|{required_code}" not in section_content:
                issues.append(
                    message
                    .replace("{method}", method)
                    .replace("{path}", path)
                )

        return issues

    @staticmethod
    def _check_status_code_table_sort_order(
        rule: dict, doc: str, delta: ExtractedApiDelta, message: str
    ) -> list[str]:
        """Warn if status codes in any errors table are not sorted ascending."""
        issues: list[str] = []

        section_pattern = re.compile(
            r'^(?:#{1,4}\s+)?(?:[`*]{0,2})(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(/[^\s`*"\']+)(?:[`*]{0,2})',
            re.MULTILINE,
        )
        code_row_pattern = re.compile(r'^\|\s*(\d{3})\s*\|', re.MULTILINE)
        matches = list(section_pattern.finditer(doc))

        for i, match in enumerate(matches):
            method = match.group(1)
            path = match.group(2).rstrip(".,;:")
            start = match.start()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(doc)
            section_content = doc[start:end]

            codes = [int(m.group(1)) for m in code_row_pattern.finditer(section_content)]
            if codes != sorted(codes):
                issues.append(
                    message
                    .replace("{method}", method)
                    .replace("{path}", path)
                )

        return issues

    @staticmethod
    def _check_contains_when_new_or_modified(
        rule: dict, doc: str, delta: ExtractedApiDelta, message: str
    ) -> list[str]:
        """Check that a pattern exists in doc, but only when new or modified endpoints are present."""
        if not delta.new and not delta.modified:
            return []
        pattern = rule.get("pattern", "")
        if pattern not in doc:
            return [message]
        return []

    @staticmethod
    def _check_regex_absent_in_curl_blocks(
        rule: dict, doc: str, delta: ExtractedApiDelta, message: str
    ) -> list[str]:
        """Check that certain patterns don't appear inside cURL blocks only."""
        issues: list[str] = []

        # Extract all curl blocks from the doc
        curl_block_pattern = re.compile(
            r'(curl\s+--location.*?)(?=\n\n|\n#{1,4}\s|\Z)',
            re.DOTALL | re.IGNORECASE,
        )
        curl_blocks = curl_block_pattern.findall(doc)
        curl_text = "\n".join(curl_blocks)

        for pattern_str in rule.get("patterns", []):
            compiled = re.compile(pattern_str, re.IGNORECASE)
            m = compiled.search(curl_text)
            if m:
                issues.append(message.replace("{match}", m.group(0)))

        return issues

    @staticmethod
    def _paths_match_static(a: str, b: str) -> bool:
        """Static version of _paths_match for use in static methods."""
        def norm(p: str) -> str:
            p = re.sub(r":[a-zA-Z_]\w*", "{p}", p)
            p = re.sub(r"\{[^}]+\}", "{p}", p)
            return p
        return norm(a) == norm(b) or a == b

    @staticmethod
    def _check_no_3col_request_table(
        rule: dict, doc: str, delta: ExtractedApiDelta, message: str
    ) -> list[str]:
        """Detect request body tables with exactly 3 columns (Field|Type|Required)
        but missing the 4th Accepted Values column."""
        # Match a header row that has EXACTLY these 3 columns and nothing after
        # the last pipe on that line (ignoring trailing whitespace).
        pattern = re.compile(
            r'^\|\s*Field\s*\|\s*Type\s*\|\s*Required\s*\|\s*$',
            re.MULTILINE | re.IGNORECASE,
        )
        if pattern.search(doc):
            return [message]
        return []