"""OpenAI-compatible provider implementation.

Works with OpenAI, DeepSeek, Groq, Mistral, Together, OpenRouter, Ollama,
and any other service that implements the OpenAI chat-completions API.
"""

from __future__ import annotations

import json
from typing import Any

from core.llm.base import LLMProvider, LLMResponse, TokenUsage, ToolCall, ToolCallResult


class OpenAIProvider(LLMProvider):
    """LLM provider backed by any OpenAI-compatible Chat Completions API."""

    def __init__(self, api_key: str, model: str, base_url: str | None = None) -> None:
        try:
            import openai
        except ImportError:
            raise ImportError(
                "openai package is required for OpenAI-compatible providers. "
                "Install with: pip install openai"
            )

        client_kwargs: dict[str, Any] = {"api_key": api_key}
        if base_url:
            client_kwargs["base_url"] = base_url

        self.client = openai.OpenAI(**client_kwargs)
        self.model = model

    def chat(
        self,
        system: str,
        messages: list,
        tools: list[dict] | None = None,
        max_tokens: int = 15000,
    ) -> LLMResponse:
        oai_messages: list[dict[str, Any]] = [{"role": "system", "content": system}]
        oai_messages.extend(messages)

        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": oai_messages,
        }
        if tools:
            kwargs["tools"] = tools

        response = self.client.chat.completions.create(**kwargs)
        choice = response.choices[0]
        message = choice.message

        stop_reason = "end_turn"
        if choice.finish_reason == "tool_calls":
            stop_reason = "tool_use"
        elif choice.finish_reason == "length":
            stop_reason = "max_tokens"

        # Some OpenAI-compatible providers (Groq, Ollama, etc.) return
        # finish_reason="stop" even when tool_calls are populated.
        # Normalise to tool_use so the workflow dispatches correctly.
        if stop_reason == "end_turn" and message.tool_calls:
            stop_reason = "tool_use"

        tool_calls: list[ToolCall] = []
        if message.tool_calls:
            for tc in message.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except (json.JSONDecodeError, TypeError):
                    args = {}
                tool_calls.append(
                    ToolCall(id=tc.id, name=tc.function.name, input=args)
                )

        usage = TokenUsage()
        if response.usage:
            usage = TokenUsage(
                input_tokens=response.usage.prompt_tokens,
                output_tokens=response.usage.completion_tokens,
            )

        return LLMResponse(
            content=message.content or "",
            stop_reason=stop_reason,
            tool_calls=tool_calls,
            usage=usage,
            _raw=message,
        )

    def build_assistant_message(self, response: LLMResponse) -> dict:
        msg: dict[str, Any] = {
            "role": "assistant",
            "content": response.content or None,
        }
        if response.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": json.dumps(tc.input),
                    },
                }
                for tc in response.tool_calls
            ]
        return msg

    def build_tool_result_messages(self, results: list[ToolCallResult]) -> list:
        return [
            {
                "role": "tool",
                "tool_call_id": r.tool_call_id,
                "content": r.content,
            }
            for r in results
        ]

    def get_tool_definitions(self, canonical_tools: list[dict]) -> list:
        """Convert canonical tool defs to OpenAI function-calling format."""
        oai_tools: list[dict] = []
        for tool in canonical_tools:
            oai_tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool.get("description", ""),
                        "parameters": tool.get(
                            "input_schema",
                            {"type": "object", "properties": {}},
                        ),
                    },
                }
            )
        return oai_tools
