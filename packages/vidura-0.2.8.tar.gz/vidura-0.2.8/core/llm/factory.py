"""Factory for creating LLM providers from configuration."""

from __future__ import annotations

import os

from core.llm.base import LLMProvider

KNOWN_PROVIDERS: dict[str, dict] = {
    "anthropic": {"base_url": None, "env_var": "ANTHROPIC_API_KEY"},
    "openai": {"base_url": None, "env_var": "OPENAI_API_KEY"},
    "deepseek": {"base_url": "https://api.deepseek.com/v1", "env_var": "DEEPSEEK_API_KEY"},
    "groq": {"base_url": "https://api.groq.com/openai/v1", "env_var": "GROQ_API_KEY"},
    "together": {"base_url": "https://api.together.xyz/v1", "env_var": "TOGETHER_API_KEY"},
    "mistral": {"base_url": "https://api.mistral.ai/v1", "env_var": "MISTRAL_API_KEY"},
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "env_var": "OPENROUTER_API_KEY"},
    "local": {"base_url": "http://localhost:11434/v1", "env_var": None},
}


def get_env_var_for_provider(provider: str) -> str | None:
    """Return the expected environment-variable name for a provider's API key.

    Returns None for providers that don't require an API key (e.g. local).
    """
    known = KNOWN_PROVIDERS.get(provider)
    if known:
        return known.get("env_var")
    return f"{provider.upper().replace('-', '_')}_API_KEY"


def get_base_url_for_provider(provider: str) -> str | None:
    """Return the default base_url for a known provider, or None."""
    known = KNOWN_PROVIDERS.get(provider)
    if known:
        return known.get("base_url")
    return None


def resolve_api_key(provider: str) -> str:
    """Resolve an API key from environment variables.

    In SaaS mode (--config-url + --token), the key is injected into the
    environment by load_config_from_url() before this is called — so it
    should always be present here. If it isn't, the platform failed to
    deliver credentials and load_config_from_url() should have raised already.

    In local mode, the key must be set manually as an environment variable.
    """
    env_var = get_env_var_for_provider(provider)
    if env_var is None:
        # Provider doesn't require an API key (e.g. local LLMs).
        return "not-needed"
    value = os.environ.get(env_var)
    if not value:
        saas_hint = (
            "\nIf you are running via a SaaS platform (--config-url / --token), "
            "this means the platform did not deliver credentials — check your "
            "install token and project configuration."
        )
        raise RuntimeError(
            f"No API key found for provider '{provider}'. "
            f"Expected environment variable: '{env_var}'.{saas_hint}"
        )
    return value


def resolve_api_base(provider: str) -> str | None:
    """Resolve custom API base URL.

    Resolution order:
      1. AGENTIC_DOCS_{PROVIDER}_API_BASE env var (e.g. AGENTIC_DOCS_DEEPSEEK_API_BASE)
      2. Known provider default (e.g. https://api.deepseek.com for deepseek)
      3. None (use SDK default)
    """
    env_var = f"AGENTIC_DOCS_{provider.upper().replace('-', '_')}_API_BASE"
    from_env = os.environ.get(env_var)
    if from_env:
        return from_env
    return get_base_url_for_provider(provider)


def create_provider(
    provider: str,
    model: str,
    api_key: str,
    base_url: str | None = None,
) -> LLMProvider:
    """Instantiate an LLM provider.

    Routes ``"anthropic"`` to the Anthropic SDK. All other providers
    (openai, deepseek, groq, together, mistral, openrouter, local, or any
    unknown provider with an OpenAI-compatible API) are routed through the
    OpenAI-compatible provider.
    """
    if provider == "anthropic":
        from core.llm.anthropic_provider import AnthropicProvider

        return AnthropicProvider(api_key=api_key, model=model)

    # Everything else goes through the OpenAI-compatible provider.
    from core.llm.openai_provider import OpenAIProvider

    return OpenAIProvider(api_key=api_key, model=model, base_url=base_url)
