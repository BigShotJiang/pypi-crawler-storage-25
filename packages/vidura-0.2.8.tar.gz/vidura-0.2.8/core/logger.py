"""Colored logging module matching the TypeScript logger."""

import sys
from typing import TextIO

from colorama import Fore
from colorama import init as colorama_init


def _configure_stream_encoding(stream: TextIO) -> None:
    """Prefer UTF-8 on Windows consoles when the stream supports it."""
    reconfigure = getattr(stream, "reconfigure", None)
    if callable(reconfigure):
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, OSError):
            pass


_configure_stream_encoding(sys.stdout)
_configure_stream_encoding(sys.stderr)
colorama_init(autoreset=True)

_silent = False
_verbose = False

# In CI environments disable ANSI colors — they appear as escape garbage in logs
import os as _os
_ci_mode = bool(
    _os.environ.get("CI")
    or _os.environ.get("GITHUB_ACTIONS")
    or _os.environ.get("GITLAB_CI")
    or _os.environ.get("CIRCLECI")
    or _os.environ.get("NO_COLOR")
)


def _safe_text(text: str, stream: TextIO) -> str:
    """Avoid UnicodeEncodeError when the console encoding is not UTF-8."""
    wrapped = getattr(stream, "wrapped", stream)
    encoding = getattr(wrapped, "encoding", None) or "utf-8"
    return text.encode(encoding, errors="replace").decode(encoding)


def _emit(stream: TextIO, prefix: str, msg: str, *args: object) -> None:
    if _ci_mode:
        # Strip color codes — use plain bracketed prefix extracted from the prefix string
        import re as _re
        plain_prefix = _re.sub(r"\x1b\[[0-9;]*m", "", prefix).strip()
        text = " ".join([f"{plain_prefix} {msg}", *(str(arg) for arg in args)])
    else:
        text = " ".join([f"{prefix}{msg}", *(str(arg) for arg in args)])
    print(_safe_text(text, stream), file=stream)


def set_silent(value: bool) -> None:
    global _silent
    _silent = value


def set_verbose(value: bool) -> None:
    global _verbose
    _verbose = value


class _Logger:
    def debug(self, msg: str, *args: object) -> None:
        if not _verbose or _silent:
            return
        _emit(sys.stdout, f"{Fore.LIGHTBLACK_EX}[DEBUG] ", msg, *args)

    def info(self, msg: str, *args: object) -> None:
        if _silent:
            return
        _emit(sys.stdout, f"{Fore.BLUE}[INFO]  ", msg, *args)

    def step(self, msg: str, *args: object) -> None:
        """Pipeline stage marker — always visible, distinct from info."""
        if _silent:
            return
        _emit(sys.stdout, f"{Fore.CYAN}[STEP]  ", msg, *args)

    def warn(self, msg: str, *args: object) -> None:
        if _silent:
            return
        _emit(sys.stderr, f"{Fore.YELLOW}[WARN]  ", msg, *args)

    def error(self, msg: str, *args: object) -> None:
        _emit(sys.stderr, f"{Fore.RED}[ERROR] ", msg, *args)

    def success(self, msg: str, *args: object) -> None:
        if _silent:
            return
        _emit(sys.stdout, f"{Fore.GREEN}[OK]    ", msg, *args)


logger = _Logger()
