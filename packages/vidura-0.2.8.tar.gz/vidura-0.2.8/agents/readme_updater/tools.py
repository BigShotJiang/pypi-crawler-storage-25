"""README updater agent tool handler."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core.logger import logger
from core.skill_loader import load_skill
from core.skill_runner import SkillRunner
from core.tools.executor import ToolResult

TOOL_DEFINITIONS: list[dict] = [
    {
        "name": "write_readme",
        "description": (
            "Write the stored draft as README.md in the repository root. "
            "This is a TERMINAL action — the agent loop exits after this call. "
            "Only call after store_draft has been called with the complete updated README."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
]

_HANDLED_TOOLS = {t["name"] for t in TOOL_DEFINITIONS}


class ToolHandler:
    def __init__(
        self,
        repo_path: str,
        config: Any,
        branch: str,
        memory: Any,
        secondary_providers: dict,
        skills_dir: Path,
        executor: Any,
    ) -> None:
        self.repo_path = repo_path
        self._memory = memory
        self._branch = branch
        self._executor = executor
        self._secondary_providers = secondary_providers
        self._skills_dir = skills_dir

    def can_handle(self, tool_name: str) -> bool:
        return tool_name in _HANDLED_TOOLS

    async def handle(self, tool_name: str, tool_input: dict[str, Any]) -> ToolResult:
        if tool_name == "write_readme":
            return self._write_readme()
        return ToolResult(
            content=json.dumps({"error": f"Unknown tool: {tool_name}"}),
            is_terminal=False,
        )

    def _write_readme(self) -> ToolResult:
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({"error": "No draft available. Call store_draft first."}),
                is_terminal=False,
            )

        readme_path = Path(self.repo_path) / "README.md"
        readme_path.write_text(draft, encoding="utf-8")
        logger.success(f"README written -> {readme_path}")

        # Record feedback only on good runs (first-attempt draft, no revisions needed)
        draft_attempts = getattr(self._executor, "_store_draft_calls", 1)
        rating = "good" if draft_attempts == 1 else "improved"
        self._executor._run_quality = rating
        self._executor.flush_pending_memory()
        self._memory.record_feedback(
            feature=self._branch,
            rating=rating,
            note=f"README updated. Draft attempts: {draft_attempts}.",
        )

        if rating == "good":
            self._extract_and_store_patterns()

        return ToolResult(
            content=json.dumps({"success": True, "path": str(readme_path)}),
            is_terminal=True,
            terminal_status="GENERATED",
            output_path=str(readme_path),
            feature_name="readme-update",
        )

    def _extract_and_store_patterns(self) -> None:
        import agents.readme_updater as _pkg
        bundled_path = Path(_pkg.__file__).parent / "skills" / "pattern-extractor.md"
        user_path = self._skills_dir / "pattern-extractor.md"
        skill_path = user_path if user_path.exists() else (bundled_path if bundled_path.exists() else None)
        if skill_path is None:
            logger.warn("[readme-patterns] pattern-extractor.md not found — skipping")
            return

        provider = (
            self._secondary_providers.get("critic")
            or next(iter(self._secondary_providers.values()), None)
        )
        if provider is None:
            # Only log once — repeated warnings on every good run become noise
            if not getattr(self.__class__, "_warned_no_provider", False):
                logger.info(
                    "[readme-patterns] Pattern extraction disabled — no secondary provider configured. "
                    "To enable: set VIDURA_README_CRITIC_PROVIDER + VIDURA_README_CRITIC_MODEL env vars."
                )
                self.__class__._warned_no_provider = True
            return

        existing_patterns = self._memory.get_global_patterns(max_chars=2000)
        run_context = (
            f"Branch: {self._branch}\n"
            f"Draft excerpt:\n{(self._executor._current_draft or '')[:800]}"
        )
        try:
            skill = load_skill(skill_path)
            runner = SkillRunner(provider=provider)
            patterns = runner.run(skill, {
                "run_context": run_context,
                "existing_patterns": existing_patterns or "None yet.",
                "max_tokens": 1024,
            })
            if isinstance(patterns, dict) and not patterns.get("error"):
                self._memory.write_agent_patterns(patterns)
        except Exception as err:
            logger.warn(f"[readme-patterns] Pattern extraction failed: {err}")
