---
name: validator
type: rules
description: Validates enterprise SAST & VAPT security report. Checks all six mandatory documents, all finding fields, compliance standards, and Checkmarx card format headings.
---

## Rules

# ── Required Header ───────────────────────────────────────────────────────────

- id: required_header
  severity: error
  check: contains
  pattern: "# Security Report"
  message: "Missing required header: # Security Report"

# ── Six Mandatory Documents (Enterprise SAST & VAPT Standards Section 9) ──────

- id: required_document_1
  severity: error
  check: contains
  pattern: "## Document 1: Security Standards Compliance Report"
  message: "Missing required section: ## Document 1: Security Standards Compliance Report"

- id: required_document_2
  severity: error
  check: contains
  pattern: "## Document 2: Illegal Parameters & Secret Exposure Report"
  message: "Missing required section: ## Document 2: Illegal Parameters & Secret Exposure Report"

- id: required_document_3
  severity: error
  check: contains
  pattern: "## Document 3: Executive Security Summary"
  message: "Missing required section: ## Document 3: Executive Security Summary"

- id: required_document_4
  severity: error
  check: contains
  pattern: "## Document 4: Top Vulnerable Files Report"
  message: "Missing required section: ## Document 4: Top Vulnerable Files Report"

- id: required_document_5
  severity: error
  check: contains
  pattern: "## Document 5: Immediate Remediation Plan"
  message: "Missing required section: ## Document 5: Immediate Remediation Plan"

- id: required_document_6
  severity: error
  check: contains
  pattern: "## Document 6: Compliance Mapping Report"
  message: "Missing required section: ## Document 6: Compliance Mapping Report"

# ── Required Sub-Sections ─────────────────────────────────────────────────────

- id: required_executive_summary
  severity: error
  check: contains
  pattern: "## Executive Summary"
  message: "Missing required section: ## Executive Summary (must appear as its own ## heading inside Document 3)"

- id: required_recommended_actions
  severity: error
  check: contains
  pattern: "## Recommended Actions"
  message: "Missing required section: ## Recommended Actions (required inside Document 5)"

- id: required_forbidden_files
  severity: error
  check: contains
  pattern: "### Forbidden Files Detected"
  message: "Missing required sub-section: ### Forbidden Files Detected (required in Document 2)"

- id: required_hardcoded_secrets
  severity: error
  check: contains
  pattern: "### Hardcoded Secrets Detected"
  message: "Missing required sub-section: ### Hardcoded Secrets Detected (required in Document 2)"

- id: required_illegal_configs
  severity: error
  check: contains
  pattern: "### Illegal Security Configurations Detected"
  message: "Missing required sub-section: ### Illegal Security Configurations Detected (required in Document 2)"

- id: required_sensitive_data
  severity: error
  check: contains
  pattern: "### Sensitive Data Exposure"
  message: "Missing required sub-section: ### Sensitive Data Exposure (required in Document 2)"

# ── Required Compliance Standards in Document 1 ───────────────────────────────

- id: required_owasp_top10
  severity: error
  check: contains
  pattern: "OWASP Top 10 2021"
  message: "Document 1 must include OWASP Top 10 2021 compliance status"

- id: required_owasp_api
  severity: error
  check: contains
  pattern: "OWASP API Security Top 10"
  message: "Document 1 must include OWASP API Security Top 10 compliance status"

- id: required_pci_dss
  severity: error
  check: contains
  pattern: "PCI DSS v4.0"
  message: "Document 1 must include PCI DSS v4.0 compliance status"

- id: required_nist
  severity: error
  check: contains
  pattern: "NIST SP 800-53"
  message: "Document 1 must include NIST SP 800-53 compliance status"

- id: required_cwe_top25
  severity: error
  check: contains
  pattern: "CWE Top 25"
  message: "Document 1 must include CWE Top 25 compliance status"

- id: required_sans_top25
  severity: error
  check: contains
  pattern: "SANS Top 25"
  message: "Document 1 must include SANS Top 25 compliance status"

# ── Required Finding Fields for Critical/High Findings ───────────────────────

- id: required_exploitation_scenario
  severity: error
  check: contains
  pattern: "Exploitation Scenario"
  message: "Critical/High findings must include an Exploitation Scenario"

- id: required_compliance_violation
  severity: error
  check: contains
  pattern: "Compliance Violation"
  message: "Critical/High findings must include a Compliance Violation field"

- id: required_secure_code_recommendation
  severity: error
  check: contains
  pattern: "Secure Code Recommendation"
  message: "Critical/High findings must include a Secure Code Recommendation"

# ── Document 6 Compliance Mapping Coverage ────────────────────────────────────

- id: required_compliance_mapping_cwe
  severity: error
  check: contains
  pattern: "CWE"
  message: "Document 6 Compliance Mapping Report must include CWE references"

- id: required_compliance_mapping_owasp
  severity: error
  check: contains
  pattern: "OWASP"
  message: "Document 6 Compliance Mapping Report must include OWASP references"

# ── Language Quality ──────────────────────────────────────────────────────────

- id: no_speculation
  severity: error
  check: regex_absent
  patterns:
    - "(?:may|might|could)\\s+(?:want to|consider|think about)"
    - "it\\s+is\\s+(?:recommended|suggested)\\s+that\\s+you"
    - "note:\\s+this\\s+is\\s+not\\s+yet\\s+implemented"
  message: "Speculative language detected: {match}"

- id: valid_http_methods
  severity: error
  check: http_methods
  allowed:
    - GET
    - POST
    - PUT
    - PATCH
    - DELETE
    - HEAD
    - OPTIONS
  message: "Invalid HTTP method in documentation"