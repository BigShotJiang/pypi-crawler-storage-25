"""
Enterprise SAST & VAPT Agent Tool Handler — Vulnerability Scanning and Security Report Generation.

Standards Compliance:
  - OWASP Top 10 2021              (https://owasp.org/www-project-top-ten/)
  - OWASP API Security Top 10      (https://owasp.org/www-project-api-security/)
  - OWASP ASVS                     (https://owasp.org/www-project-application-security-verification-standard/)
  - PCI DSS v4.0                   (https://www.pcisecuritystandards.org/)
  - NIST SP 800-53                 (https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final)
  - NIST SP 800-171
  - NIST SSDF
  - CWE Top 25                     (https://cwe.mitre.org/)
  - SANS Top 25                    (https://www.sans.org/top25-software-errors/)

Mandatory Analysis Categories (Section 4 of Enterprise SAST & VAPT Security Standards Framework):
  XSS, SQL Injection, SSRF, CSRF, IDOR, Path Traversal, JWT Vulnerabilities,
  Weak Cryptography, Broken Authentication, Broken Access Control,
  Parameter Tampering, Unsafe Object Binding, ReDoS, Insecure Dependencies,
  Logging Exposure, Security Misconfiguration, Hardcoded Credentials,
  API Vulnerabilities, PII Exposure, XXE, Deserialization, Race Conditions

Forbidden Files Detected (Section 5.1):
  .env, .env.production, credentials.json, secrets.yaml, *.pem, *.key,
  *.p12, *.jks, serviceAccountKey.json

Illegal Security Configurations Detected (Section 5.3):
  ssl.trustAllCerts=true, hostnameVerification=false, csrf.disable(),
  debug=true, allowOrigins("*"), management.endpoints.web.exposure.include=*,
  trustAllHosts=true

Sensitive Data Detection (Section 6):
  Aadhaar Numbers, PAN Numbers, Emails, Phone Numbers, JWT Tokens,
  Credit Card Data, API Keys, OAuth Tokens
"""

from __future__ import annotations

import json
import re
from datetime import datetime as _dt
from pathlib import Path
from typing import Any

from core.diff_utils import build_diff_batches
from core.logger import logger
from core.skill_loader import load_skill
from core.skill_runner import SkillRunner
from core.tools.executor import ToolResult
from core.memory import MemoryManager

from agents.sast.dependency_scanner import scan_dependencies_async, format_for_llm

import tempfile
_tmp = tempfile.gettempdir()

# ── Enterprise Standards: Forbidden File Patterns (Section 5.1) ───────────────
FORBIDDEN_FILE_NAMES = {
    ".env",
    ".env.production",
    "credentials.json",
    "secrets.yaml",
    "serviceAccountKey.json",
}

FORBIDDEN_FILE_SUFFIXES = {".pem", ".key", ".p12", ".jks"}

# ── Enterprise Standards: Hardcoded Secret Detection Regex (Section 5.2) ──────
SECRET_PATTERNS: list[re.Pattern] = [
    re.compile(r'password\s*=\s*["\'][^"\']+["\']', re.IGNORECASE),
    re.compile(r'secret\s*=\s*["\'][^"\']+["\']', re.IGNORECASE),
    re.compile(r'api[_-]?key\s*=\s*["\'][^"\']+["\']', re.IGNORECASE),
    re.compile(r'token\s*=\s*["\'][^"\']+["\']', re.IGNORECASE),
    re.compile(r'AKIA[0-9A-Z]{16}'),
    re.compile(r'-----BEGIN PRIVATE KEY-----'),
    re.compile(r'jdbc:.*password=', re.IGNORECASE),
    re.compile(r'Authorization:\s*Bearer\s+[A-Za-z0-9+/=]{20,}', re.IGNORECASE),
]

# ── Enterprise Standards: Illegal Security Configurations (Section 5.3) ───────
# Each tuple: (compiled regex, human-readable config name, risk description)
ILLEGAL_CONFIG_PATTERNS: list[tuple[re.Pattern, str, str]] = [
    (re.compile(r'ssl\.trustAllCerts\s*=\s*true', re.IGNORECASE),       "ssl.trustAllCerts=true",                           "TLS validation bypass"),
    (re.compile(r'hostnameVerification\s*=\s*false', re.IGNORECASE),    "hostnameVerification=false",                       "SSL hostname bypass"),
    (re.compile(r'csrf\.disable\(\)', re.IGNORECASE),                    "csrf.disable()",                                   "CSRF attack exposure"),
    (re.compile(r'debug\s*=\s*true', re.IGNORECASE),                    "debug=true",                                       "Sensitive data exposure via debug mode"),
    (re.compile(r'allowOrigins\(\s*["\']?\*["\']?\s*\)', re.IGNORECASE),'allowOrigins("*")',                                 "Unsafe CORS configuration"),
    (re.compile(r'management\.endpoints\.web\.exposure\.include\s*=\s*\*', re.IGNORECASE), "management.endpoints.web.exposure.include=*", "Full actuator endpoint exposure"),
    (re.compile(r'trustAllHosts\s*=\s*true', re.IGNORECASE),            "trustAllHosts=true",                               "SSRF & MITM risk"),
]

# ── Enterprise Standards: Sensitive Data Detection (Section 6) ────────────────
SENSITIVE_DATA_PATTERNS: list[tuple[re.Pattern, str, str]] = [
    (re.compile(r'\b[2-9]\d{11}\b'), "Aadhaar Number", "Identity theft"),
    (re.compile(r'\b[A-Z]{5}[0-9]{4}[A-Z]\b'), "PAN Number", "Financial fraud"),
    (re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'), "Email Address", "Privacy exposure"),
    (re.compile(r'\b(?:\+91|0)?[6-9]\d{9}\b'), "Phone Number", "PII leakage"),
    (re.compile(r'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'), "JWT Token", "Session compromise"),
    (re.compile(r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11})\b'), "Credit Card Number", "PCI DSS violation"),
]

TOOL_DEFINITIONS: list[dict] = [
    {
        "name": "validate_report",
        "description": (
            "Validate the stored enterprise security report draft — checks all six mandatory documents "
            "are present, all findings from scan_for_vulnerabilities are documented with required fields "
            "(exploitation_scenario, compliance_violation, secure_code_recommendation), and Document 2 "
            "covers forbidden files, illegal configs, and sensitive data. "
            "Returns valid (boolean), errors[], warnings[]. "
            "Fix all errors before calling write_report. Requires store_draft first."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "scan_for_vulnerabilities",
        "description": (
            "Enterprise SAST & VAPT scan of changed files for security vulnerabilities. "
            "Covers all 22 mandatory vulnerability categories per the Enterprise Security Standards Framework: "
            "XSS, SQL Injection, SSRF, CSRF, IDOR, Path Traversal, JWT Vulnerabilities, Weak Cryptography, "
            "Broken Authentication, Broken Access Control, Parameter Tampering, Unsafe Object Binding, "
            "ReDoS, Insecure Dependencies, Logging Exposure, Security Misconfiguration, Hardcoded Credentials, "
            "API Vulnerabilities, PII Exposure, XXE, Deserialization, Race Conditions. "
            "Also detects forbidden files (Section 5.1), hardcoded secrets (Section 5.2), "
            "illegal security configurations (Section 5.3), and sensitive data (Section 6). "
            "Language and framework agnostic — works for Python, Go, Java, TypeScript, Ruby, "
            "Spring Boot, Node.js, React, Angular, Terraform, Kubernetes YAML, and any other. "
            "Call once after get_changed_files. Returns structured findings with CWE, OWASP, "
            "PCI DSS, NIST SP 800-53, and SANS Top 25 compliance mappings."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "write_report",
        "description": (
            "Write the stored enterprise security report draft to disk as a PDF. "
            "Also writes a JSON output file for backend API ingestion. "
            "Report must contain all six mandatory documents: "
            "(1) Security Standards Compliance Report, "
            "(2) Illegal Parameters & Secret Exposure Report, "
            "(3) Executive Security Summary, "
            "(4) Top Vulnerable Files Report, "
            "(5) Immediate Remediation Plan, "
            "(6) Compliance Mapping Report. "
            "This is a TERMINAL action — the agent loop exits after this call. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
]

_HANDLED_TOOLS = {t["name"] for t in TOOL_DEFINITIONS}
SCAN_BATCH_SIZE = 2   # 2 files per batch — gives the LLM more context window per file
BATCH_SIZE = SCAN_BATCH_SIZE

# Severity ordering for report sorting
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


# ── Section 5.1: Forbidden file check ─────────────────────────────────────────
def _check_forbidden_files(file_path: str) -> str | None:
    name = Path(file_path).name
    suffix = Path(file_path).suffix.lower()
    if name in FORBIDDEN_FILE_NAMES:
        return f"Forbidden file detected: {name} — risk: secret/credential exposure"
    if suffix in FORBIDDEN_FILE_SUFFIXES:
        return f"Forbidden file detected: {file_path} ({suffix}) — risk: private key or certificate exposure"
    return None


# ── Section 5.2: Hardcoded secret detection ────────────────────────────────────
def _check_secret_patterns(content: str) -> list[str]:
    matches = []
    for line in content.splitlines():
        if not line.startswith("+"):
            continue
        stripped = line[1:]
        for pattern in SECRET_PATTERNS:
            if pattern.search(stripped):
                matches.append(f"Hardcoded secret pattern matched: {pattern.pattern[:60]}")
    return list(set(matches))


# ── Section 5.3: Illegal config detection ──────────────────────────────────────
def _check_illegal_configs(content: str) -> list[str]:
    matches = []
    for line in content.splitlines():
        if not line.startswith("+"):
            continue
        stripped = line[1:]
        for pattern, config_name, risk in ILLEGAL_CONFIG_PATTERNS:
            if pattern.search(stripped):
                matches.append(f"Illegal configuration: {config_name} — {risk}")
    return list(set(matches))


# ── Section 6: Sensitive data detection ───────────────────────────────────────
def _check_sensitive_data(content: str) -> list[str]:
    found = []
    for line in content.splitlines():
        if not line.startswith("+"):
            continue
        stripped = line[1:]
        for pattern, data_type, risk in SENSITIVE_DATA_PATTERNS:
            if pattern.search(stripped):
                found.append(f"Sensitive data exposed: {data_type} — {risk}")
    return list(set(found))


class ToolHandler:
    def __init__(
        self,
        repo_path: str,
        config: Any,
        branch: str,
        memory: Any,
        secondary_providers: dict,
        skills_dir: Path,
        executor: Any,
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self.branch = branch
        self._memory = memory
        self._secondary_providers = secondary_providers
        self._skills_dir = skills_dir
        self._executor = executor
        self._findings: list[dict] = []
        self._summary: dict = {}
        # Enterprise standard pre-scan results (Sections 5.1, 5.2, 5.3, 6)
        self._forbidden_files: list[str] = []
        self._secret_matches: list[str] = []
        self._illegal_configs: list[str] = []
        self._sensitive_data: list[str] = []
        # ── Token tracking across all phases ──────────────────────────────────
        # Tracks tokens consumed by: scanner batches, pattern extractor, agent LLM calls.
        # These are injected into the PDF report and JSON output for full auditability.
        self._token_usage: dict[str, int] = {
            "scanner_prompt_tokens":     0,   # tokens sent to the scan LLM
            "scanner_completion_tokens": 0,   # tokens returned by the scan LLM
            "agent_prompt_tokens":       0,   # primary agent input tokens
            "agent_completion_tokens":   0,   # primary agent output tokens
            "total_prompt_tokens":       0,   # sum of all prompt tokens
            "total_completion_tokens":   0,   # sum of all completion tokens
            "total_tokens":              0,   # grand total
        }

    def can_handle(self, tool_name: str) -> bool:
        return tool_name in _HANDLED_TOOLS

    async def handle(self, tool_name: str, tool_input: dict[str, Any]) -> ToolResult:
        if tool_name == "scan_for_vulnerabilities":
            return await self._scan_for_vulnerabilities()
        if tool_name == "validate_report":
            return self._validate_report()
        if tool_name == "write_report":
            return await self._write_report()
        return ToolResult(
            content=json.dumps({"error": f"Unknown tool: {tool_name}"}),
            is_terminal=False,
        )

    # ── Token accumulation helpers ────────────────────────────────────────────

    def _add_scan_tokens(self, in_tokens: int, out_tokens: int) -> None:
        """Record tokens consumed by the SAST scanner (secondary LLM)."""
        self._token_usage["scanner_prompt_tokens"]     += in_tokens
        self._token_usage["scanner_completion_tokens"] += out_tokens
        self._token_usage["total_prompt_tokens"]       += in_tokens
        self._token_usage["total_completion_tokens"]   += out_tokens
        self._token_usage["total_tokens"]              += in_tokens + out_tokens

    def _sync_agent_tokens(self) -> None:
        """
        Pull the primary agent's cumulative token usage from the executor.
        Tries multiple attribute names used by different executor implementations.
        """
        try:
            in_t, out_t = 0, 0
            # Try every known attribute name the executor might use
            for attr in ("_token_usage", "_tokens_used", "_usage", "token_usage",
                         "_cumulative_tokens", "_llm_tokens"):
                usage = getattr(self._executor, attr, None)
                if isinstance(usage, dict) and usage:
                    in_t  = usage.get("inputTokens",  0) or usage.get("input_tokens",  0) or 0
                    out_t = usage.get("outputTokens", 0) or usage.get("output_tokens", 0) or 0
                    if in_t or out_t:
                        break

            # Also check _secondary_tokens_used which we populate ourselves
            # Subtract scanner tokens already counted to avoid double-counting
            sec = getattr(self._executor, "_secondary_tokens_used", {}) or {}
            sec_in  = sec.get("inputTokens",  0)
            sec_out = sec.get("outputTokens", 0)
            # Agent tokens = total executor tokens minus secondary (scanner) tokens
            agent_in  = max(0, in_t  - sec_in)
            agent_out = max(0, out_t - sec_out)

            self._token_usage["agent_prompt_tokens"]     = agent_in
            self._token_usage["agent_completion_tokens"] = agent_out
            self._token_usage["total_prompt_tokens"] = (
                self._token_usage["scanner_prompt_tokens"] + agent_in
            )
            self._token_usage["total_completion_tokens"] = (
                self._token_usage["scanner_completion_tokens"] + agent_out
            )
            self._token_usage["total_tokens"] = (
                self._token_usage["total_prompt_tokens"]
                + self._token_usage["total_completion_tokens"]
            )
        except Exception:
            pass

    def _token_report_section(self) -> str:
        """
        Return a Markdown section that embeds token usage into the PDF report.
        Matches Checkmarx's 'Scan Details' metadata block style.
        """
        u = self._token_usage
        return (
            "\n\n## Scan Token Usage\n\n"
            "| Phase | Prompt Tokens | Completion Tokens | Total |\n"
            "|---|---|---|---|\n"
            f"| Scanner (file analysis) | {u['scanner_prompt_tokens']:,} | {u['scanner_completion_tokens']:,} | {u['scanner_prompt_tokens'] + u['scanner_completion_tokens']:,} |\n"
            f"| Agent (report generation) | {u['agent_prompt_tokens']:,} | {u['agent_completion_tokens']:,} | {u['agent_prompt_tokens'] + u['agent_completion_tokens']:,} |\n"
            f"| **Total** | **{u['total_prompt_tokens']:,}** | **{u['total_completion_tokens']:,}** | **{u['total_tokens']:,}** |\n"
        )

    # ── First-run detection ───────────────────────────────────────────────────

    def _is_first_run(self) -> bool:
        """Scan entire repo when on the base branch or when no prior reports exist."""
        try:
            from core.git import GitAnalyzer
            git = GitAnalyzer(self.repo_path)
            current_branch = git.get_current_branch()
            base_branch = getattr(self.config, "base_branch", "master")
            if current_branch == base_branch:
                logger.info(
                    f"[sast] running on base branch '{base_branch}' — full repository scan"
                )
                return True
        except Exception:
            pass
        output_dir = Path(self.repo_path) / self.config.output_dir
        if not output_dir.exists():
            return True
        return len(list(output_dir.glob("*security-report*.pdf"))) == 0

    # ── Scan ──────────────────────────────────────────────────────────────────

    async def _scan_for_vulnerabilities(self) -> ToolResult:
        """
        Always performs a full repository scan regardless of branch or prior reports.

        WHY: Diff-mode scanning (only looking at changed files between commits) is
        fundamentally inadequate for security analysis. A vulnerability in an unchanged
        file is still a vulnerability. The SAST agent must see the entire codebase on
        every run to catch:
          - Pre-existing vulnerabilities in files not touched by this commit
          - Secrets in config files that haven't changed recently
          - Illegal security configurations that were always present
          - Dependency issues across the full requirements/package files

        The only files excluded are binary assets, compiled output, and package lock
        files that contain no security-relevant source code.
        """
        logger.info("[sast] full repository scan — all source files included")
            # ── Directories that never contain security-relevant source code ────────
        SKIP_DIRS = {
            ".git", "node_modules", "__pycache__", "venv", ".venv",
            "dist", "build", ".agent", "skills", "migrations",
            ".idea", ".vscode",
        }

        # ── File types that contain no scannable source code ─────────────────
        # IMPORTANT: .yml, .yaml, .json, .env are NOT here — they contain
        # docker configs, CI/CD pipelines, app settings, and secrets that
        # must be scanned. Only binary assets and lock files are excluded.
        SKIP_SUFFIXES = {
            # Binary assets
            ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg",
            ".woff", ".woff2", ".ttf", ".eot", ".otf",
            ".pdf", ".docx", ".xlsx", ".pptx",
            ".mp4", ".mp3", ".wav", ".avi",
            ".zip", ".tar", ".gz", ".rar",
            # Compiled / generated output
            ".pyc", ".pyo", ".class", ".o", ".so", ".dll", ".exe",
            # Package lock files (no source code, just resolved dependency trees)
            ".lock", ".sum",
            # Pure documentation
            ".md", ".rst", ".txt",
            # Log files
            ".log",
        }

        repo_root = Path(self.repo_path)
        scan_files = []

        for file_path in repo_root.rglob("*"):
            if not file_path.is_file():
                continue

            # Skip excluded directories
            parts = set(file_path.relative_to(repo_root).parts[:-1])
            if parts & SKIP_DIRS:
                continue

            # Skip excluded file types
            if file_path.suffix.lower() in SKIP_SUFFIXES:
                continue

            rel = str(file_path.relative_to(repo_root)).replace("\\", "/")

            # Run forbidden-file check (Section 5.1) on every file in the repo
            forbidden_reason = _check_forbidden_files(rel)
            if forbidden_reason:
                self._forbidden_files.append(f"{rel}: {forbidden_reason}")

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            # Treat every line as "added" so the secret/config/PII detectors fire
            diff_content = "\n".join(f"+{line}" for line in content.splitlines())
            self._secret_matches.extend(_check_secret_patterns(diff_content))
            self._illegal_configs.extend(_check_illegal_configs(diff_content))
            self._sensitive_data.extend(_check_sensitive_data(diff_content))

            from core.extractor.types import ChangedFile as _CF
            scan_files.append(_CF(
                path=rel,
                status="added",
                diff=diff_content,
                content=content,
            ))

        logger.info(f"[sast] full scan: {len(scan_files)} files queued for LLM analysis")

        if not scan_files:
            return ToolResult(
                content=json.dumps({
                    "noIssues": True,
                    "findings": [],
                    "summary": {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0, "total": 0},
                    "forbidden_files_detected": list(set(self._forbidden_files)),
                    "illegal_configs_detected": list(set(self._illegal_configs)),
                    "sensitive_data_detected": list(set(self._sensitive_data)),
                    "message": "No scannable source files found in repository.",
                }),
                is_terminal=False,
            )

        # ── Load skill ────────────────────────────────────────────────────────
        import agents.sast as _pkg
        bundled_path = Path(_pkg.__file__).parent / "skills" / "sast-analyzer.md"
        user_path = self._skills_dir / "sast-analyzer.md"
        skill_path = user_path if user_path.exists() else (bundled_path if bundled_path.exists() else None)

        if skill_path is None:
            return ToolResult(
                content=json.dumps({"error": "sast-analyzer.md not found."}),
                is_terminal=False,
            )

        provider = (
            self._secondary_providers.get("scanner")
            or self._secondary_providers.get("extractor")
            or self._secondary_providers.get("critic")
        )
        if provider is None:
            return ToolResult(
                content=json.dumps({"error": "No LLM provider available for scanning."}),
                is_terminal=False,
            )

        skill = load_skill(skill_path)
        runner = SkillRunner(provider=provider)

        # ── Dependency audit ──────────────────────────────────────────────────
        dep_findings: list[dict] = []
        dep_context = ""
        try:
            dep_findings = await scan_dependencies_async(self.repo_path)
            dep_context = format_for_llm(dep_findings)
            if dep_context:
                logger.info(f"[sast-deps] {len(dep_findings)} dependency issue(s) found")
        except Exception as dep_err:
            logger.warn(f"[sast-deps] dependency audit failed (non-fatal): {dep_err}")

        # ── Batch scan ────────────────────────────────────────────────────────
        batches = build_diff_batches(
            scan_files,
            batch_size=SCAN_BATCH_SIZE,
            per_file_cap=90_000,
        )
        logger.info(f"[sast] {len(scan_files)} file(s) → {len(batches)} batch(es) of ≤{BATCH_SIZE}")

        all_findings: list[dict] = []
        seen_ids: set[str] = set()

        def _recover_json(result: dict) -> dict | None:
            """
            When SkillRunner fails to parse the LLM response as JSON, it returns:
              {"error": "Could not parse JSON from sast-analyzer", "raw": "```json\n{...}\n```"}

            The findings are sitting in the "raw" field wrapped in markdown fences.
            This function strips the fences and recovers the JSON rather than
            silently discarding a batch that may contain critical findings.
            """
            raw = result.get("raw", "")
            if not raw:
                return None
            import re as _re
            # Strip ```json ... ``` or ``` ... ``` fences
            cleaned = _re.sub(r'^```(?:json)?\s*', '', raw.strip(), flags=_re.IGNORECASE)
            cleaned = _re.sub(r'\s*```$', '', cleaned.strip()).strip()
            try:
                return json.loads(cleaned)
            except Exception:
                pass
            # Last resort: extract the outermost { ... } block
            m = _re.search(r'\{.*\}', cleaned, _re.DOTALL)
            if m:
                try:
                    return json.loads(m.group(0))
                except Exception:
                    pass
            logger.debug(f"[sast] _recover_json failed — raw length: {len(raw)}, last 100 chars: {raw[-100:]!r}")
            return None

        for batch_idx, (batch_files, diff_context) in enumerate(batches, 1):
            logger.step(f"[sast] batch {batch_idx}/{len(batches)}: {[f.path for f in batch_files]}")
            enriched = (dep_context + "\n\n" + diff_context) if batch_idx == 1 and dep_context else diff_context
            # max_tokens=16000 is passed explicitly.
            # skill_runner.py defaults to 2048 which truncates mid-JSON for any
            # batch with more than ~3 findings, silently losing all those findings.
            result = runner.run(skill, {"diff": enriched, "branch": self.branch, "max_tokens": 16384})

            if runner.last_usage:
                self._add_scan_tokens(
                    runner.last_usage.input_tokens,
                    runner.last_usage.output_tokens,
                )

            if not isinstance(result, dict):
                logger.warn(f"[sast] batch {batch_idx} returned non-dict — skipping")
                continue

            # ── Recover findings from fenced JSON before giving up ────────────
            # gpt-4o-mini frequently wraps its JSON response in ```json...```
            # markdown fences even when instructed not to. The SkillRunner
            # marks this as an error but preserves the raw text in result["raw"].
            # We extract and parse that instead of discarding the whole batch.
            if "error" in result:
                recovered = _recover_json(result)
                if recovered and isinstance(recovered, dict) and "error" not in recovered:
                    logger.info(
                        f"[sast] batch {batch_idx}: recovered findings from fenced JSON "
                        f"(original error: {result.get('error', '')[:60]})"
                    )
                    result = recovered
                else:
                    logger.warn(f"[sast] batch {batch_idx} failed and could not be recovered: {result.get('error', '')[:80]} — skipping")
                    continue

            if result.get("noIssues"):
                continue
            for finding in result.get("findings", []):
                if not isinstance(finding, dict):
                    continue
                fid = finding.get("id", "")
                if fid and fid in seen_ids:
                    continue
                if fid:
                    seen_ids.add(fid)
                all_findings.append(finding)

            for ff in result.get("forbidden_files_detected", []):
                if ff and ff not in self._forbidden_files:
                    self._forbidden_files.append(ff)
            for ic in result.get("illegal_configs_detected", []):
                if ic and ic not in self._illegal_configs:
                    self._illegal_configs.append(ic)
            for sd in result.get("sensitive_data_detected", []):
                if sd and sd not in self._sensitive_data:
                    self._sensitive_data.append(sd)

        # ── Update executor secondary token counters (for existing pipeline) ──
        self._executor._secondary_tokens_used = getattr(
            self._executor, "_secondary_tokens_used", {"inputTokens": 0, "outputTokens": 0}
        )
        self._executor._secondary_tokens_used["inputTokens"]  += self._token_usage["scanner_prompt_tokens"]
        self._executor._secondary_tokens_used["outputTokens"] += self._token_usage["scanner_completion_tokens"]

        logger.info(
            f"[sast] total findings: {len(all_findings)} across {len(batches)} batch(es) | "
            f"scan tokens: {self._token_usage['scanner_prompt_tokens']:,} in / "
            f"{self._token_usage['scanner_completion_tokens']:,} out"
        )

        # ── Merge dependency findings ──────────────────────────────────────────
        for dep_idx, dep in enumerate(dep_findings, start=len(all_findings) + 1):
            fid = f"DEP-{dep_idx:03d}"
            if fid in seen_ids:
                continue
            seen_ids.add(fid)
            vuln_desc = ""
            if dep.get("vulnerabilities"):
                cve_list = ", ".join(v["id"] for v in dep["vulnerabilities"][:3])
                vuln_desc = f" Known CVEs: {cve_list}."
            all_findings.append({
                "id": fid,
                "severity": dep["severity"],
                "category": "Dependency Issues",
                "title": f"{dep['package']} pinned to outdated version {dep['current_version']}",
                "file": (
                    "requirements.txt" if dep["ecosystem"] == "pypi"
                    else "package.json" if dep["ecosystem"] == "npm"
                    else "pom.xml" if dep["ecosystem"] == "maven"
                    else "go.mod"
                ),
                "line": 0,
                "reachability": "direct",
                "result_state": "To Verify",
                "code_snippet": f"{dep['package']}=={dep['current_version']}",
                "description": (
                    f"{dep['package']} is pinned to {dep['current_version']} "
                    f"but latest is {dep['latest_version']}.{vuln_desc}"
                ),
                "remediation": f"Upgrade to {dep['package']}>={dep['latest_version']}",
                "cwe": "CWE-1035",
                "owasp": "A06:2021 – Vulnerable and Outdated Components",
                "compliance_tags": ["OWASP Top 10 2021", "OWASP Top 10 2017", "NIST SP 800-53"],
            })

        if not all_findings:
            return ToolResult(
                content=json.dumps({
                    "noIssues": True,
                    "findings": [],
                    "summary": {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0, "total": 0},
                    "forbidden_files_detected": [],
                    "illegal_configs_detected": [],
                    "sensitive_data_detected": [],
                    "message": "No security issues found. Call signal_no_change.",
                }),
                is_terminal=False,
            )

        # ── Sort, normalise, summarise ─────────────────────────────────────────
        self._findings = sorted(
            all_findings,
            key=lambda f: SEVERITY_ORDER.get(f.get("severity", "info"), 4),
        )
        for f in self._findings:
            if "severity" in f and isinstance(f["severity"], str):
                f["severity"] = f["severity"].lower()

        self._summary = {
            sev: sum(1 for f in self._findings if f.get("severity") == sev)
            for sev in ("critical", "high", "medium", "low", "info")
        }
        self._summary["total"] = len(self._findings)

        min_sev = (getattr(self.config, "extra", {}) or {}).get("min_severity", "low")
        min_order = SEVERITY_ORDER.get(min_sev, 3)
        filtered = [f for f in self._findings if SEVERITY_ORDER.get(f.get("severity", "info"), 4) <= min_order]

        logger.info(
            f"[sast] found {self._summary.get('total', 0)} issues: "
            f"critical={self._summary.get('critical', 0)} "
            f"high={self._summary.get('high', 0)} "
            f"medium={self._summary.get('medium', 0)} "
            f"low={self._summary.get('low', 0)}"
        )

        return ToolResult(
            content=json.dumps({
                "findings": filtered,
                "summary": self._summary,
                "forbidden_files_detected": list(set(self._forbidden_files)),
                "secret_patterns_detected": list(set(self._secret_matches)),
                "illegal_configs_detected": list(set(self._illegal_configs)),
                "sensitive_data_detected": list(set(self._sensitive_data)),
                "_instruction": (
                    f"Document ALL {len(filtered)} findings. "
                    f"Forbidden files: {len(self._forbidden_files)}. "
                    f"Illegal configs: {len(self._illegal_configs)}. "
                    f"Sensitive data exposures: {len(self._sensitive_data)}. "
                    f"Critical/High require: Exploitation Scenario, Compliance Violation, "
                    f"Secure Code Recommendation. Medium/Low use table format."
                ),
            }),
            is_terminal=False,
        )

    # ── Validate report ───────────────────────────────────────────────────────

    def _validate_report(self) -> ToolResult:
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({"valid": False, "errors": ["No draft. Call store_draft first."], "warnings": []}),
                is_terminal=False,
            )

        errors: list[str] = []
        warnings: list[str] = []

        import re as _re

        def _normalize_id(fid: str) -> str:
            m = _re.match(r"([A-Za-z]+)-0*(\d+)", fid)
            return f"{m.group(1).upper()}-{m.group(2)}" if m else fid.upper()

        draft_upper = draft.upper()

        # ── Six mandatory documents ───────────────────────────────────────────
        required_documents = [
            "## Document 1: Security Standards Compliance Report",
            "## Document 2: Illegal Parameters & Secret Exposure Report",
            "## Document 3: Executive Security Summary",
            "## Document 4: Top Vulnerable Files Report",
            "## Document 5: Immediate Remediation Plan",
            "## Document 6: Compliance Mapping Report",
        ]
        for doc in required_documents:
            if doc not in draft:
                errors.append(
                    f"Missing mandatory document: {doc} — "
                    "add this exact heading and section content"
                )

        # ── Required sub-sections ─────────────────────────────────────────────
        required_sections = [
            "# Security Report",
            "## Executive Summary",
            "## Recommended Actions",
            "### Forbidden Files Detected",
            "### Hardcoded Secrets Detected",
            "### Illegal Security Configurations Detected",
            "### Sensitive Data Exposure",
        ]
        for section in required_sections:
            if section not in draft:
                errors.append(
                    f"Missing required section: {section} — "
                    "add this exact heading (character-for-character match required)"
                )

        # ── Required compliance standards in Document 1 ───────────────────────
        required_standards = [
            "OWASP Top 10 2021",
            "OWASP API Security Top 10",
            "PCI DSS v4.0",
            "NIST SP 800-53",
            "CWE Top 25",
            "SANS Top 25",
        ]
        for standard in required_standards:
            if standard not in draft:
                errors.append(f"Missing compliance standard in Document 1: {standard}")

        # ── Required finding fields for critical/high ─────────────────────────
        has_critical_or_high = any(
            f.get("severity") in ("critical", "high") for f in self._findings
        )
        if has_critical_or_high:
            for field in ("Exploitation Scenario", "Compliance Violation", "Secure Code Recommendation"):
                if field not in draft:
                    errors.append(
                        f"Critical/High findings require '{field}' field — "
                        "add this to every critical/high finding block"
                    )

        # ── Batch all missing findings into a single error ────────────────────
        missing_findings: list[str] = []
        for finding in self._findings:
            raw_id = finding.get("id", "")
            fid = _normalize_id(raw_id) if raw_id else ""
            severity = finding.get("severity", "")
            title = finding.get("title", "")
            id_present = fid and (fid in draft_upper or raw_id in draft)
            if raw_id and not id_present:
                missing_findings.append(f"{raw_id} ({severity}: {title})")
            elif severity in ("critical", "high"):
                file_ref = finding.get("file", "")
                if file_ref and file_ref not in draft:
                    warnings.append(f"Finding {raw_id}: file '{file_ref}' not mentioned in report")

        if missing_findings:
            errors.append(
                f"The following {len(missing_findings)} finding(s) are missing — "
                "add each as a ### card block (critical/high) or table row (medium/low/info): "
                + "; ".join(missing_findings)
            )

        valid = len(errors) == 0
        message = (
            "Report valid. Call write_report."
            if valid
            else f"Validation failed: {len(errors)} error(s). Fix before writing: {'; '.join(errors)}"
        )
        return ToolResult(
            content=json.dumps({"valid": valid, "errors": errors, "warnings": warnings, "message": message}),
            is_terminal=False,
        )

    # ── Checkmarx-style dashboard charts ─────────────────────────────────────

    def _generate_charts(self) -> str:
        """
        Generate Checkmarx-style dashboard charts and return an HTML block for
        embedding in the report Markdown.

        Three charts produced:
          - Result Summary          — severity breakdown pie
          - Most Vulnerable Files   — top-10 files by finding count pie
          - Top 5 Vulnerabilities   — most frequent vulnerability titles bar
        """
        if not self._findings:
            return ""

        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            from collections import Counter

            # Checkmarx severity palette
            SEVERITY_COLOURS = {
                "critical": "#D9534F",
                "high":     "#E8824A",
                "medium":   "#F0AD4E",
                "low":      "#5BC0DE",
                "info":     "#9B9B9B",
            }
            SEV_ORDER = ["critical", "high", "medium", "low", "info"]

            chart_paths: list[str] = []

            # ── 1. Result Summary — severity pie ──────────────────────────────
            sev_labels, sev_sizes, sev_colors = [], [], []
            for sev in SEV_ORDER:
                count = self._summary.get(sev, 0)
                if count > 0:
                    sev_labels.append(f"{sev.capitalize()} ({count})")
                    sev_sizes.append(count)
                    sev_colors.append(SEVERITY_COLOURS[sev])

            if sev_sizes:
                fig, ax = plt.subplots(figsize=(5, 4))
                wedges, texts, autotexts = ax.pie(
                    sev_sizes, labels=sev_labels, colors=sev_colors,
                    autopct="%1.0f%%", startangle=140,
                    textprops={"fontsize": 9},
                )
                for at in autotexts:
                    at.set_fontsize(8)
                ax.set_title("Result Summary", fontsize=11, fontweight="bold", pad=12)
                fig.tight_layout()
                path_sev = str(Path(_tmp) / "sast_severity_pie.png")
                fig.savefig(path_sev, dpi=120, bbox_inches="tight")
                plt.close(fig)
                chart_paths.append(path_sev)

            # ── 2. Most Vulnerable Files — top-10 pie ─────────────────────────
            file_counter: Counter = Counter(f.get("file", "unknown") for f in self._findings)
            top_files = file_counter.most_common(10)

            if top_files:
                f_labels = [str(Path(name).name) + f" ({cnt})" for name, cnt in top_files]
                f_sizes  = [cnt for _, cnt in top_files]
                palette  = [
                    "#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F",
                    "#EDC948", "#B07AA1", "#FF9DA7", "#9C755F", "#BAB0AC",
                ]
                f_colors = [palette[i % len(palette)] for i in range(len(top_files))]
                fig, ax = plt.subplots(figsize=(5, 4))
                ax.pie(f_sizes, labels=f_labels, colors=f_colors,
                       autopct="%1.0f%%", startangle=140,
                       textprops={"fontsize": 8})
                ax.set_title("Most Vulnerable Files", fontsize=11, fontweight="bold", pad=12)
                fig.tight_layout()
                path_files = str(Path(_tmp) / "sast_files_pie.png")
                fig.savefig(path_files, dpi=120, bbox_inches="tight")
                plt.close(fig)
                chart_paths.append(path_files)

            # ── 3. Top 5 Vulnerabilities — horizontal bar ─────────────────────
            title_counter: Counter = Counter(
                f.get("title", f.get("category", "Unknown")) for f in self._findings
            )
            top_vulns = title_counter.most_common(5)

            if top_vulns:
                v_labels = [t for t, _ in reversed(top_vulns)]
                v_counts = [c for _, c in reversed(top_vulns)]
                v_labels_short = [
                    lbl if len(lbl) <= 38 else lbl[:35] + "…" for lbl in v_labels
                ]
                bar_colors = [
                    SEVERITY_COLOURS.get(
                        next(
                            (f.get("severity", "info") for f in self._findings
                             if f.get("title", f.get("category", "")) == lbl),
                            "info",
                        ),
                        "#9B9B9B",
                    )
                    for lbl in v_labels
                ]
                fig, ax = plt.subplots(figsize=(6, max(2.5, len(top_vulns) * 0.7)))
                bars = ax.barh(v_labels_short, v_counts, color=bar_colors, edgecolor="white")
                ax.set_xlabel("Finding Count", fontsize=9)
                ax.set_title("Top 5 Vulnerabilities", fontsize=11, fontweight="bold")
                ax.tick_params(axis="y", labelsize=8)
                ax.tick_params(axis="x", labelsize=8)
                for bar, val in zip(bars, v_counts):
                    ax.text(
                        bar.get_width() + 0.05,
                        bar.get_y() + bar.get_height() / 2,
                        str(val), va="center", ha="left", fontsize=8,
                    )
                ax.set_xlim(0, max(v_counts) * 1.25)
                fig.tight_layout()
                path_bar = str(Path(_tmp) / "sast_vuln_bar.png")
                fig.savefig(path_bar, dpi=120, bbox_inches="tight")
                plt.close(fig)
                chart_paths.append(path_bar)

            if not chart_paths:
                return ""

            import base64

            def _png_to_data_uri(path: str) -> str:
                with open(path, "rb") as fh:
                    b64 = base64.b64encode(fh.read()).decode("ascii")
                return f"data:image/png;base64,{b64}"

            chart_cells = ""
            for cp in chart_paths:
                try:
                    uri = _png_to_data_uri(cp)
                    chart_cells += (
                        '<td style="padding:8px;text-align:center;vertical-align:top;">'
                        f'<img src="{uri}" style="max-width:300px;height:auto;" /></td>'
                    )
                except Exception as embed_err:
                    logger.warn(f"[sast] could not embed chart {cp}: {embed_err}")

            if not chart_cells:
                return ""

            return (
                "\n\n## Result Dashboard\n\n"
                '<table style="width:100%;border-collapse:collapse;">'
                f"<tr>{chart_cells}</tr>"
                "</table>\n\n"
            )

        except Exception as chart_err:
            logger.warn(f"[sast] chart generation failed (non-fatal): {chart_err}")
            return ""

    # ── JSON output file for backend API ─────────────────────────────────────

    def _write_sast_json(
        self,
        output_dir: str,
        feature_name: str,
        commit_id: str,
        repo_name: str,
        branch: str,
        generated_date: str,
    ) -> str | None:
        """
        Write a structured JSON file for backend API ingestion.

        File name format:  {YYYYMMDD}_{HHMMSS}_{commit_short}_{feature}_sast.json
        Location:          <output_dir>/

        The JSON shape matches the POST body expected by the admin panel API:
          {
            "run_id":          "<date>_<time>_<commit>",
            "generated_at":    "<ISO datetime>",
            "repo":            "<repo_name>",
            "branch":          "<branch>",
            "commit_id":       "<full commit hash>",
            "summary":         { critical, high, medium, low, info, total },
            "token_usage":     { scanner_prompt, scanner_completion, agent_prompt,
                                 agent_completion, total_prompt, total_completion, total },
            "scanned_files":   ["path/to/file.py", ...],
            "vulnerabilities": [
              {
                "id":          "SAST-001",          # matches report ID
                "severity":    "high",
                "category":    "injection",
                "title":       "SQL injection...",
                "file":        "api/users.py",
                "line":        42,
                "description": "...",
                "remediation": "...",
                "cwe":         "CWE-89",
                "owasp":       "A03:2021 – Injection"
              },
              ...
            ],
            "forbidden_files":  [...],
            "illegal_configs":  [...],
            "sensitive_data":   [...]
          }
        """
        try:
            now = _dt.utcnow()
            date_str   = now.strftime("%Y%m%d")
            time_str   = now.strftime("%H%M%S")
            commit_short = (commit_id or "unknown")[:8]

            run_id = f"{date_str}_{time_str}_{commit_short}"
            safe_feature = re.sub(r"[^a-zA-Z0-9-]", "-", feature_name)
            file_name = f"{run_id}_{safe_feature}_sast.json"
            json_path = str(Path(output_dir) / file_name)

            # Collect unique scanned file paths from findings
            scanned_files = sorted({
                f.get("file", "") for f in self._findings if f.get("file")
            })

            # Build vulnerability list — one entry per finding
            vulnerabilities = []
            for finding in self._findings:
                vulnerabilities.append({
                    "id":          finding.get("id", ""),
                    "severity":    finding.get("severity", ""),
                    "category":    finding.get("category", ""),
                    "title":       finding.get("title", ""),
                    "file":        finding.get("file", ""),
                    "line":        finding.get("line", 0),
                    "description": finding.get("description", ""),
                    "remediation": finding.get("remediation", ""),
                    "cwe":         finding.get("cwe", ""),
                    "owasp":       finding.get("owasp", ""),
                    "owasp_api":   finding.get("owasp_api", None),
                    "compliance_violation": finding.get("compliance_violation", ""),
                    "result_state": finding.get("result_state", "To Verify"),
                    "reachability": finding.get("reachability", ""),
                })

            payload = {
                "run_id":         run_id,
                "generated_at":   now.isoformat() + "Z",
                "repo":           repo_name,
                "branch":         branch,
                "commit_id":      commit_id or "",
                "summary":        self._summary,
                "token_usage": {
                    "scanner_prompt_tokens":     self._token_usage["scanner_prompt_tokens"],
                    "scanner_completion_tokens": self._token_usage["scanner_completion_tokens"],
                    "agent_prompt_tokens":       self._token_usage["agent_prompt_tokens"],
                    "agent_completion_tokens":   self._token_usage["agent_completion_tokens"],
                    "total_prompt_tokens":       self._token_usage["total_prompt_tokens"],
                    "total_completion_tokens":   self._token_usage["total_completion_tokens"],
                    "total_tokens":              self._token_usage["total_tokens"],
                },
                "scanned_files":  scanned_files,
                "vulnerabilities": vulnerabilities,
                "forbidden_files":  list(set(self._forbidden_files)),
                "illegal_configs":  list(set(self._illegal_configs)),
                "sensitive_data":   list(set(self._sensitive_data)),
            }

            Path(output_dir).mkdir(parents=True, exist_ok=True)
            with open(json_path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)

            logger.success(f"[sast] JSON output written → {json_path}")
            return json_path

        except Exception as json_err:
            logger.warn(f"[sast] JSON output failed (non-fatal): {json_err}")
            return None

    # ── Write report ──────────────────────────────────────────────────────────

    async def _write_report(self) -> ToolResult:
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({"error": "No draft. Call store_draft first."}),
                is_terminal=False,
            )

        # ── Pull final agent token counts before writing ───────────────────────
        self._sync_agent_tokens()

        # ── Inject token usage section into the draft ─────────────────────────
        token_section = self._token_report_section()
        # Append just before the last section or at end — after Recommended Actions
        recommended_marker = "## Recommended Actions"
        rec_pos = draft.rfind(recommended_marker)
        if rec_pos != -1:
            # Find the end of Recommended Actions section (next ## or end of string)
            next_section = draft.find("\n## ", rec_pos + len(recommended_marker))
            if next_section != -1:
                draft = draft[:next_section] + token_section + draft[next_section:]
            else:
                draft = draft + token_section
        else:
            draft = draft + token_section

        # ── Inject Checkmarx-style dashboard charts after Executive Summary ────
        charts_md = self._generate_charts()
        if charts_md:
            exec_marker = "## Executive Summary"
            exec_pos = draft.find(exec_marker)
            if exec_pos != -1:
                next_section_pos = draft.find("\n## ", exec_pos + len(exec_marker))
                if next_section_pos != -1:
                    draft = draft[:next_section_pos] + "\n" + charts_md + draft[next_section_pos:]
                else:
                    draft = draft + "\n" + charts_md
            else:
                draft = charts_md + draft

        from agents.doc_gen.document import DocumentGenerator, DocumentMetadata
        from core.git import GitAnalyzer
        from datetime import datetime as _dt

        git = GitAnalyzer(self.repo_path)
        git_meta = git.get_commit_metadata(self.config.base_branch)
        commit_id   = git_meta.get("current_commit", "")
        repo_name   = self.config.repo_name or git_meta.get("repo_name", "")
        generated_date = _dt.utcnow().strftime("%Y-%m-%d %H:%M UTC")

        metadata = DocumentMetadata(
            feature_name=f"Security Scan — {self.branch}",
            version=git_meta.get("version", ""),
            org_name=self.config.org_name or "",
            repo_name=repo_name,
            project_name=self.config.project_name or "",
            branch_name=self.branch,
            authors=git_meta.get("authors", "Security Team"),
            previous_commit=git_meta.get("previous_commit", ""),
            current_commit=commit_id,
            commit_message=git_meta.get("commit_message", ""),
            commit_time=git_meta.get("commit_time", ""),
            generated_date=generated_date,
            changed_files=[],
            # ── NEW ──────────────────────────────────────────────────────────────
            input_tokens=self._token_usage["total_prompt_tokens"],
            output_tokens=self._token_usage["total_completion_tokens"],
            model=getattr(self._executor, "_usage", {}).get("model", self.config.model),
        )

        output_dir   = str(Path(self.repo_path) / self.config.output_dir)
        feature_name = re.sub(r"[^a-zA-Z0-9-]", "-", self.branch.replace("/", "-"))

        gen    = DocumentGenerator()
        output = await gen.generate(
            draft,
            f"{feature_name}-security-report",
            output_dir,
            doc_title_template="{feature} — Enterprise Security Report",
            org_name=self.config.org_name,
            company_name=getattr(self.config, "company_name", None),
            logo_url=getattr(self.config, "logo_url", None),
            metadata=metadata,
        )

        # ── Write JSON output file for backend API ─────────────────────────────
        json_path = self._write_sast_json(
            output_dir=output_dir,
            feature_name=feature_name,
            commit_id=commit_id,
            repo_name=repo_name,
            branch=self.branch,
            generated_date=generated_date,
        )

        # ── Memory / feedback ──────────────────────────────────────────────────
        draft_attempts = getattr(self._executor, "_store_draft_calls", 1)
        rating = "good" if draft_attempts <= 2 else "improved"
        self._executor._run_quality = rating
        self._executor.flush_pending_memory()
        self._memory.record_feedback(
            feature=self.branch,
            rating=rating,
            note=(
                f"Enterprise SAST & VAPT scan: {self._summary.get('total', 0)} total findings — "
                f"critical={self._summary.get('critical', 0)}, "
                f"high={self._summary.get('high', 0)}, "
                f"medium={self._summary.get('medium', 0)}, "
                f"low={self._summary.get('low', 0)}. "
                f"Tokens: {self._token_usage['total_tokens']:,} total "
                f"({self._token_usage['total_prompt_tokens']:,} prompt / "
                f"{self._token_usage['total_completion_tokens']:,} completion). "
                f"Forbidden files: {len(self._forbidden_files)}. "
                f"Illegal configs: {len(self._illegal_configs)}. "
                f"Sensitive data: {len(self._sensitive_data)}."
            ),
        )

        if rating == "good":
            self._extract_and_store_patterns(feature_name)

        logger.success(f"Enterprise security report written → {output.pdf_path}")
        if json_path:
            logger.success(f"JSON output written → {json_path}")

        return ToolResult(
            content=json.dumps({
                "success":                   True,
                "pdfPath":                   output.pdf_path,
                "jsonPath":                  json_path,
                "summary":                   self._summary,
                "token_usage":               self._token_usage,
                "forbidden_files_detected":  len(self._forbidden_files),
                "illegal_configs_detected":  len(self._illegal_configs),
                "sensitive_data_detected":   len(self._sensitive_data),
            }),
            is_terminal=True,
            terminal_status="GENERATED",
            output_path=output.pdf_path,
            feature_name=feature_name,
        )

    # ── Pattern extractor ─────────────────────────────────────────────────────

    def _extract_and_store_patterns(self, feature_name: str) -> None:
        import agents.sast as _pkg
        bundled_path = Path(_pkg.__file__).parent / "skills" / "pattern-extractor.md"
        user_path = self._skills_dir / "pattern-extractor.md"
        skill_path = user_path if user_path.exists() else (bundled_path if bundled_path.exists() else None)
        if skill_path is None:
            logger.warn("[sast-patterns] pattern-extractor.md not found — skipping")
            return

        provider = (
            self._secondary_providers.get("scanner")
            or self._secondary_providers.get("extractor")
            or self._secondary_providers.get("critic")
        )
        if provider is None:
            return

        existing_patterns = self._memory.get_global_patterns(max_chars=2000)
        run_context = (
            f"Feature: {feature_name}\n"
            f"Findings: {self._summary}\n"
            f"Forbidden files: {self._forbidden_files}\n"
            f"Illegal configs: {self._illegal_configs}\n"
            f"Sensitive data: {self._sensitive_data}\n"
            f"Draft excerpt:\n{(self._executor._current_draft or '')[:800]}"
        )
        try:
            skill = load_skill(skill_path)
            runner = SkillRunner(provider=provider)
            patterns = runner.run(skill, {
                "run_context": run_context,
                "existing_patterns": existing_patterns or "None yet.",
                "max_tokens": 16384,
            })
            if runner.last_usage:
                self._add_scan_tokens(
                    runner.last_usage.input_tokens,
                    runner.last_usage.output_tokens,
                )
                logger.info(
                    f"[sast-patterns] tokens: {runner.last_usage.input_tokens:,} in / "
                    f"{runner.last_usage.output_tokens:,} out"
                )
            if isinstance(patterns, dict) and not patterns.get("error"):
                self._memory.write_agent_patterns(patterns)
        except Exception as err:
            logger.warn(f"[sast-patterns] Pattern extraction failed: {err}")