"""
Dependency Scanner
- Detects dependencies across Python, Node, Java, Go
- Checks outdated versions via PyPI/npm/Maven registries
- Checks known vulnerabilities via OSV.dev
"""

from __future__ import annotations

import json
import re
import asyncio
from pathlib import Path
from typing import Any

import httpx
from packaging.version import parse as py_parse

# OSV ecosystem name map — must match exactly what OSV expects
OSV_ECOSYSTEM = {
    "pypi": "PyPI",
    "npm": "npm",
    "maven": "Maven",
    "go": "Go",
}


def is_outdated(current: str, latest: str, ecosystem: str) -> bool:
    try:
        if ecosystem == "pypi":
            return py_parse(current) < py_parse(latest)
        # For others: simple string comparison — good enough for major version detection
        c_parts = [int(x) for x in current.split(".")[:3] if x.isdigit()]
        l_parts = [int(x) for x in latest.split(".")[:3] if x.isdigit()]
        return c_parts < l_parts
    except Exception:
        return current != latest


def _severity_from_gap(current: str, latest: str) -> str:
    """Derive severity from how far behind the pinned version is."""
    try:
        c = [int(x) for x in current.split(".")[:2] if x.isdigit()]
        l = [int(x) for x in latest.split(".")[:2] if x.isdigit()]
        if not c or not l:
            return "low"
        major_gap = l[0] - c[0]
        minor_gap = (l[1] - c[1]) if len(c) > 1 and len(l) > 1 and major_gap == 0 else 0
        if major_gap >= 2:
            return "critical"
        if major_gap == 1:
            return "high"
        if minor_gap >= 5:
            return "medium"
        return "low"
    except Exception:
        return "low"


async def get_latest_version_async(
    client: httpx.AsyncClient, package: str, ecosystem: str
) -> str | None:
    try:
        if ecosystem == "pypi":
            resp = await client.get(f"https://pypi.org/pypi/{package}/json", timeout=8)
            if resp.status_code == 200:
                return resp.json()["info"]["version"]

        elif ecosystem == "npm":
            resp = await client.get(
                f"https://registry.npmjs.org/{package}/latest", timeout=8
            )
            if resp.status_code == 200:
                return resp.json().get("version")

        elif ecosystem == "maven":
            resp = await client.get(
                f"https://search.maven.org/solrsearch/select?q=g:{package}&rows=1&wt=json",
                timeout=8,
            )
            if resp.status_code == 200:
                docs = resp.json().get("response", {}).get("docs", [])
                if docs:
                    return docs[0].get("latestVersion")

    except Exception:
        pass
    return None


async def check_osv_async(
    client: httpx.AsyncClient, package: str, version: str, ecosystem: str
) -> list[dict]:
    osv_eco = OSV_ECOSYSTEM.get(ecosystem, ecosystem)
    try:
        resp = await client.post(
            "https://api.osv.dev/v1/query",
            json={"package": {"name": package, "ecosystem": osv_eco}, "version": version},
            timeout=8,
        )
        vulns = resp.json().get("vulns", []) if resp.status_code == 200 else []
        return [
            {
                "id": v.get("id", ""),
                "summary": v.get("summary", ""),
                "severity": (v.get("severity") or [{}])[0].get("score", "unknown")
                if isinstance(v.get("severity"), list)
                else "unknown",
            }
            for v in vulns
        ]
    except Exception:
        return []


# ── Parsers ───────────────────────────────────────────────────────────────────

def parse_requirements(file: Path) -> list[tuple[str, str, str]]:
    deps = []
    for line in file.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z0-9_\-\.]+)==([^\s;#]+)", line)
        if m:
            deps.append((m.group(1), m.group(2), "pypi"))
    return deps


def parse_package_json(file: Path) -> list[tuple[str, str, str]]:
    try:
        data = json.loads(file.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return []
    deps = []
    for section in ("dependencies", "devDependencies"):
        for name, version in data.get(section, {}).items():
            clean = re.sub(r"^[\^~>=<v]", "", version).strip()
            if clean and clean[0].isdigit():
                deps.append((name, clean, "npm"))
    return deps


def parse_pom(file: Path) -> list[tuple[str, str, str]]:
    content = file.read_text(encoding="utf-8", errors="replace")
    deps = []
    matches = re.findall(
        r"<dependency>\s*<groupId>(.*?)</groupId>\s*<artifactId>(.*?)</artifactId>\s*<version>(.*?)</version>",
        content,
        re.DOTALL,
    )
    for g, a, v in matches:
        # Skip property placeholders like ${spring.version}
        if not v.strip().startswith("$"):
            deps.append((f"{g.strip()}:{a.strip()}", v.strip(), "maven"))
    return deps


def parse_go_mod(file: Path) -> list[tuple[str, str, str]]:
    deps = []
    in_require = False
    for line in file.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line.startswith("require ("):
            in_require = True
            continue
        if in_require and line == ")":
            in_require = False
            continue
        # Single-line require: require github.com/foo/bar v1.2.3
        if line.startswith("require ") and not line.endswith("("):
            line = line[len("require "):].strip()
        if in_require or line:
            m = re.match(r"^([\w\.\-/]+)\s+v([\d][^\s]*)", line)
            if m and "//" not in line.split()[0]:
                deps.append((m.group(1), m.group(2), "go"))
    return deps


# ── Main scanner ──────────────────────────────────────────────────────────────

async def scan_dependencies_async(repo_path: str) -> list[dict]:
    repo = Path(repo_path)
    all_deps: list[tuple[str, str, str]] = []

    for file in repo.rglob("*"):
        if file.name == "requirements.txt" or (
            file.name.startswith("requirements") and file.suffix == ".txt"
        ):
            all_deps += parse_requirements(file)
        elif file.name == "package.json" and "node_modules" not in file.parts:
            all_deps += parse_package_json(file)
        elif file.name == "pom.xml":
            all_deps += parse_pom(file)
        elif file.name == "go.mod":
            all_deps += parse_go_mod(file)

    if not all_deps:
        return []

    findings = []
    async with httpx.AsyncClient() as client:
        for name, version, ecosystem in all_deps:
            latest = await get_latest_version_async(client, name, ecosystem)
            outdated = bool(latest and is_outdated(version, latest, ecosystem))
            osv_vulns = await check_osv_async(client, name, version, ecosystem)

            if outdated or osv_vulns:
                severity = _severity_from_gap(version, latest) if outdated else "high"
                # CVEs always override the version-gap severity upward
                if osv_vulns:
                    severity = "high"

                findings.append({
                    "package": name,
                    "ecosystem": ecosystem,
                    "current_version": version,
                    "latest_version": latest or "unknown",
                    "outdated": outdated,
                    "severity": severity,
                    "vulnerabilities": osv_vulns,
                })

    return findings


def scan_dependencies(repo_path: str) -> list[dict]:
    """Sync wrapper — use in non-async contexts."""
    return asyncio.run(scan_dependencies_async(repo_path))


# ── Formatted output for LLM injection ───────────────────────────────────────

def format_for_llm(findings: list[dict]) -> str:
    """Format dependency findings as a structured string for injection into the scan context."""
    if not findings:
        return ""

    lines = ["=== DEPENDENCY AUDIT (live registry + OSV check) ==="]
    for f in findings:
        pkg = f["package"]
        cur = f["current_version"]
        lat = f["latest_version"]
        sev = f["severity"].upper()
        vulns = f.get("vulnerabilities", [])

        status = f"latest: {lat} — {sev}" if f["outdated"] else f"UP TO DATE (latest: {lat})"
        lines.append(f"{pkg}=={cur} → {status}")

        for v in vulns:
            lines.append(f"  CVE: {v['id']} — {v['summary'][:120]}")

    return "\n".join(lines)


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    repo_path = sys.argv[1] if len(sys.argv) > 1 else "."
    results = scan_dependencies(repo_path)
    print(json.dumps({"dependency_issues": results, "total": len(results)}, indent=2))