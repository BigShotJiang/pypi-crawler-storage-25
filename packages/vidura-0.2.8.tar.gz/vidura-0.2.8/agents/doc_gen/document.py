"""Document generation (L7). Writes PDF."""

from __future__ import annotations

import io
import json
import re
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from core.logger import logger

# Pricing per 1M tokens (USD) — update as needed
MODEL_PRICING_USD: dict[str, dict[str, float]] = {
    # Anthropic
    "claude-opus-4-20250514":      {"input": 15.00, "output": 75.00},
    "claude-sonnet-4-20250514":    {"input":  3.00, "output": 15.00},
    "claude-haiku-4-5-20251001":   {"input":  0.80, "output":  4.00},
    # OpenAI
    "gpt-4o":                      {"input":  2.50, "output": 10.00},
    "gpt-4o-mini":                 {"input":  0.15, "output":  0.60},
    "gpt-4-turbo":                 {"input": 10.00, "output": 30.00},
    # DeepSeek
    "deepseek-chat":               {"input":  0.27, "output":  1.10},
    # Groq (Llama 3.3)
    "llama-3.3-70b-versatile":     {"input":  0.59, "output":  0.79},
    # Fallback
    "_default":                    {"input":  1.00, "output":  3.00},
}

# Exchange rates (USD base — update periodically or wire to a live rate)
FX_RATES: dict[str, float] = {
    "USD": 1.0,
    "INR": 96.3,   # approx May 2026
    "EUR": 0.92,
}


def compute_token_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
) -> dict[str, dict[str, float]]:
    """
    Returns costs per currency: {"USD": {"input": x, "output": y, "total": z}, ...}
    """
    pricing = MODEL_PRICING_USD.get(model) or MODEL_PRICING_USD["_default"]
    usd_in  = (input_tokens  / 1_000_000) * pricing["input"]
    usd_out = (output_tokens / 1_000_000) * pricing["output"]
    usd_tot = usd_in + usd_out

    result: dict[str, dict[str, float]] = {}
    for currency, rate in FX_RATES.items():
        result[currency] = {
            "input":  round(usd_in  * rate, 4),
            "output": round(usd_out * rate, 4),
            "total":  round(usd_tot * rate, 4),
        }
    return result

@dataclass
class DocumentOutput:
    pdf_path: str


@dataclass
class DocumentMetadata:
    feature_name: str
    version: str
    org_name: str
    repo_name: str
    project_name: str
    branch_name: str
    authors: str
    previous_commit: str
    current_commit: str
    commit_message: str
    commit_time: str
    generated_date: str
    changed_files: list[str]
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""


@dataclass
class ParsedSection:
    type: str   # h1, h2, h3, code, bullet, text, table, hr
    content: str
    level: int = 0                          # bullet indent level
    rows: list[list[str]] = field(default_factory=list)  # for type=table


class DocumentGenerator:
    async def generate(
        self,
        markdown_content: str,
        feature_name: str,
        output_dir: str,
        doc_title_template: str = "{feature} - API Documentation",
        org_name: str | None = None,
        project_name: str | None = None,
        repo_name: str | None = None,
        company_name: str | None = None,
        logo_url: str | None = None,
        metadata: DocumentMetadata | None = None,
    ) -> DocumentOutput:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        file_name = re.sub(r"[^a-zA-Z0-9-]", "-", feature_name)
        timestamp = datetime.now().strftime("%Y%m%d-%H%M")
        pdf_path = str(output_path / f"{file_name}-api-docs-{timestamp}.pdf")

        doc_title = doc_title_template.format(
            org=org_name or "",
            project=project_name or "",
            repo=repo_name or "",
            feature=feature_name,
        ).strip(" -") or "API Documentation"

        logo_bytes = self._fetch_logo(logo_url) if logo_url else None

        self._generate_pdf(markdown_content, pdf_path, doc_title, company_name, logo_bytes, metadata)
        logger.debug(f"PDF written: {pdf_path}")

        return DocumentOutput(pdf_path=pdf_path)

    @staticmethod
    def _fetch_logo(url: str) -> bytes | None:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "vidura-agent/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.read()
        except Exception as err:
            logger.warn(f"Logo fetch failed ({url}): {err}")
            return None

    # ─── PDF generation ───────────────────────────────────────────────────────

    def _generate_pdf(
        self,
        markdown: str,
        output_path: str,
        title: str,
        company_name: str | None = None,
        logo_bytes: bytes | None = None,
        metadata: DocumentMetadata | None = None,
    ) -> None:
        from functools import partial

        from reportlab.lib import colors
        from reportlab.lib.enums import TA_LEFT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import mm
        from reportlab.platypus import (
            HRFlowable, Paragraph, Preformatted,
            SimpleDocTemplate, Spacer, Table, TableStyle,
        )

        PAGE_W, PAGE_H = A4
        MARGIN     = 22 * mm
        CONTENT_W  = PAGE_W - 2 * MARGIN

        # ── Palette ───────────────────────────────────────────────────────────
        C_BLUE_DARK  = colors.HexColor("#1a3a5c")
        C_BLUE_MID   = colors.HexColor("#2e6da4")
        C_BLUE_LIGHT = colors.HexColor("#4a6fa5")
        C_BLUE_TINT  = colors.HexColor("#e8f0f8")
        C_GRAY_BG    = colors.HexColor("#f4f4f4")
        C_GRAY_RULE  = colors.HexColor("#cccccc")
        C_GRAY_TEXT  = colors.HexColor("#555555")
        C_DARK       = colors.HexColor("#1a1a1a")
        C_ALT_ROW    = colors.HexColor("#f9f9f9")

        base = getSampleStyleSheet()

        def s(name, parent="Normal", **kw) -> ParagraphStyle:
            return ParagraphStyle(name, parent=base[parent], **kw)

        # Typography
        s_h1 = s("VH1", fontSize=20, leading=26, textColor=C_BLUE_DARK,
                  fontName="Helvetica-Bold", spaceBefore=20, spaceAfter=6,
                  alignment=TA_LEFT)
        s_h2 = s("VH2", fontSize=14, leading=20, textColor=C_BLUE_MID,
                  fontName="Helvetica-Bold", spaceBefore=16, spaceAfter=4)
        s_h3 = s("VH3", fontSize=11, leading=16, textColor=C_BLUE_LIGHT,
                  fontName="Helvetica-Bold", spaceBefore=10, spaceAfter=3)
        s_body = s("VBody", fontSize=10, leading=16, textColor=C_DARK,
                   spaceBefore=3, spaceAfter=3)
        s_bullet = s("VBullet", fontSize=10, leading=15, textColor=C_DARK,
                     spaceBefore=2, spaceAfter=2,
                     leftIndent=14, firstLineIndent=0)
        s_bullet2 = s("VBullet2", fontSize=9.5, leading=14, textColor=C_GRAY_TEXT,
                      spaceBefore=1, spaceAfter=1,
                      leftIndent=28, firstLineIndent=0)
        s_bullet3 = s("VBullet3", fontSize=9, leading=14, textColor=C_GRAY_TEXT,
                      spaceBefore=1, spaceAfter=1,
                      leftIndent=42, firstLineIndent=0)
        s_code = s("VCode", "Code", fontSize=8.5, leading=13,
                   fontName="Courier", textColor=C_DARK)
        s_meta_label = s("VMLabel", fontSize=8.5, leading=12,
                         textColor=C_GRAY_TEXT, fontName="Helvetica-Bold")
        s_meta_val   = s("VMVal",   fontSize=8.5, leading=12, textColor=C_DARK)
        s_th = s("VTH", fontSize=9, leading=13, fontName="Helvetica-Bold",
                 textColor=C_BLUE_DARK)
        s_td = s("VTD", fontSize=9, leading=13, textColor=C_DARK)

        # ── Helpers ───────────────────────────────────────────────────────────

        # Max lines per code block chunk — prevents "too large" PDF crash.
        # A4 page body ≈ 688pt; 13pt leading → ~52 lines max. Use 40 to be safe.
        MAX_CODE_LINES = 40

        def _make_code_table(chunk: str):
            pre = Preformatted(chunk, s_code)
            tbl = Table([[pre]], colWidths=[CONTENT_W])
            tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, -1), C_GRAY_BG),
                ("BOX",           (0, 0), (-1, -1), 0.5, C_GRAY_RULE),
                ("LEFTPADDING",   (0, 0), (-1, -1), 8),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 8),
                ("TOPPADDING",    (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]))
            return tbl

        MAX_CODE_LINE_CHARS = 95  # wrap long lines to prevent right-side clipping

        def _wrap_code_lines(text: str) -> str:
            """Wrap lines longer than MAX_CODE_LINE_CHARS with a continuation marker."""
            out = []
            for line in text.split("\n"):
                if len(line) <= MAX_CODE_LINE_CHARS:
                    out.append(line)
                else:
                    while len(line) > MAX_CODE_LINE_CHARS:
                        out.append(line[:MAX_CODE_LINE_CHARS] + " ↵")
                        line = "  " + line[MAX_CODE_LINE_CHARS:]
                    out.append(line)
            return "\n".join(out)

        def code_block(text: str) -> list:
            """Return list of flowables — wraps long lines and splits tall blocks."""
            text = _wrap_code_lines(text)
            lines = text.split("\n")
            if len(lines) <= MAX_CODE_LINES:
                return [_make_code_table(text)]
            chunks = []
            for i in range(0, len(lines), MAX_CODE_LINES):
                chunk_lines = lines[i:i + MAX_CODE_LINES]
                is_last = (i + MAX_CODE_LINES) >= len(lines)
                if not is_last:
                    chunk_lines.append("    ...")
                chunks.append(_make_code_table("\n".join(chunk_lines)))
            return chunks

        def _col_widths(n_cols: int) -> list[float]:
            """Proportional column widths tuned for API doc tables.

            Typical API table: Field | Type | Required
            Field names can be long (e.g. 'start_datetime', 'youtube_video_id').
            Type can contain enums (e.g. 'string (enum: INACTIVE|UPCOMING|LIVE|PAST)').
            Give first col 35%, type col 45%, required col 20%.
            """
            if n_cols <= 1:
                return [CONTENT_W]
            if n_cols == 2:
                return [CONTENT_W * 0.38, CONTENT_W * 0.62]
            if n_cols == 3:
                # Field | Type | Required
                # Field col needs 35% — long names like "notification_type",
                # "registration_id", "youtube_video_id" clip at 30%.
                return [CONTENT_W * 0.35, CONTENT_W * 0.45, CONTENT_W * 0.20]
            if n_cols == 4:
                # Name | Type | Required | Description
                return [CONTENT_W * 0.22, CONTENT_W * 0.22, CONTENT_W * 0.12, CONTENT_W * 0.44]
            # 5+ cols: equal split
            w = CONTENT_W / n_cols
            return [w] * n_cols

        # ── Checkmarx-style severity badge colours ────────────────────────────
        # Matches Checkmarx's result severity colour convention exactly.
        SAST_SEV_BG = {
            "critical": colors.HexColor("#D9534F"),
            "high":     colors.HexColor("#E8824A"),
            "medium":   colors.HexColor("#F0AD4E"),
            "low":      colors.HexColor("#5BC0DE"),
            "info":     colors.HexColor("#9B9B9B"),
        }
        SAST_SEV_FG = colors.white   # white text on all severity badge cells

        # Style for text inside a severity badge cell
        s_badge = s("VBadge", fontSize=9, leading=13,
                    fontName="Helvetica-Bold", textColor=colors.white,
                    alignment=1)   # centred

        def _severity_key(text: str) -> str | None:
            """Return the normalised severity key if the cell text is a severity label."""
            t = text.strip().lower()
            # Accept plain word or word in parentheses/brackets, e.g. "(High)" "HIGH"
            t = t.strip("()[]")
            return t if t in SAST_SEV_BG else None

        def _is_severity_column(header_cell: str) -> bool:
            """True if the column header looks like a severity column."""
            return header_cell.strip().lower() in ("severity", "sev", "risk", "level")

        def md_table(rows: list[list[str]]):
            if not rows:
                return Spacer(1, 2 * mm)
            header = rows[0]
            data_rows = rows[1:]
            n_cols = len(header)
            col_widths = _col_widths(n_cols)

            # Identify which columns are severity columns so we can badge them
            sev_col_indices = {
                idx for idx, h in enumerate(header) if _is_severity_column(h)
            }

            table_data = [[Paragraph(self._escape(c), s_th) for c in header]]
            # Track (row_idx, col_idx) pairs that need severity badge background
            badge_cells: list[tuple[int, int, str]] = []   # (row_1based, col, sev_key)

            for i, row in enumerate(data_rows):
                padded = row + [""] * (n_cols - len(row))
                row_cells = []
                for col_idx, cell_text in enumerate(padded):
                    sev_key = None
                    if col_idx in sev_col_indices:
                        sev_key = _severity_key(cell_text)
                    if sev_key:
                        # Use badge style (bold white centred) for severity cells
                        row_cells.append(Paragraph(
                            self._escape(cell_text.strip().capitalize()), s_badge
                        ))
                        badge_cells.append((i + 1, col_idx, sev_key))  # +1 for header row
                    else:
                        row_cells.append(Paragraph(self._escape(cell_text), s_td))
                table_data.append(row_cells)

            tbl = Table(table_data, colWidths=col_widths, repeatRows=1, hAlign="LEFT")
            ts = TableStyle([
                # Header row
                ("BACKGROUND",    (0, 0), (-1, 0),  C_BLUE_TINT),
                ("LINEBELOW",     (0, 0), (-1, 0),  1.0, C_BLUE_MID),
                # Grid
                ("GRID",          (0, 0), (-1, -1), 0.4, C_GRAY_RULE),
                ("BOX",           (0, 0), (-1, -1), 0.8, C_BLUE_MID),
                # Padding
                ("LEFTPADDING",   (0, 0), (-1, -1), 8),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 8),
                ("TOPPADDING",    (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
            ])

            # Alternate row shading (skipped for badge rows — badge bg takes priority)
            badge_rows = {r for r, _, _ in badge_cells}
            for i, _ in enumerate(data_rows):
                if i % 2 == 1 and (i + 1) not in badge_rows:
                    ts.add("BACKGROUND", (0, i + 1), (-1, i + 1), C_ALT_ROW)

            # Apply Checkmarx severity badge background to each severity cell
            for row_idx, col_idx, sev_key in badge_cells:
                bg = SAST_SEV_BG[sev_key]
                ts.add("BACKGROUND",  (col_idx, row_idx), (col_idx, row_idx), bg)
                ts.add("TEXTCOLOR",   (col_idx, row_idx), (col_idx, row_idx), SAST_SEV_FG)
                ts.add("FONTNAME",    (col_idx, row_idx), (col_idx, row_idx), "Helvetica-Bold")
                ts.add("ALIGN",       (col_idx, row_idx), (col_idx, row_idx), "CENTER")
                # Rounded-corner effect: slightly thicker border on the badge cell
                ts.add("BOX",         (col_idx, row_idx), (col_idx, row_idx), 1.2, bg)

            tbl.setStyle(ts)
            return tbl

        def token_cost_table(
            input_tokens: int,
            output_tokens: int,
            model: str,
        ) -> list:
            """Render a styled token-usage + multi-currency cost table."""
            from reportlab.platypus import KeepTogether

            costs = compute_token_cost(model, input_tokens, output_tokens)

            # ── Section heading ───────────────────────────────────────────────────
            heading = Paragraph("Token Usage &amp; Cost", s_h2)
            rule    = HRFlowable(width="100%", thickness=0.5, color=C_GRAY_RULE, spaceAfter=4)

            # ── Usage row ─────────────────────────────────────────────────────────
            usage_data = [
                [
                    Paragraph("Metric",        s_th),
                    Paragraph("Tokens",        s_th),
                ],
                [
                    Paragraph("Input tokens",  s_td),
                    Paragraph(f"{input_tokens:,}", s_td),
                ],
                [
                    Paragraph("Output tokens", s_td),
                    Paragraph(f"{output_tokens:,}", s_td),
                ],
                [
                    Paragraph("<b>Total tokens</b>", s_td),
                    Paragraph(f"<b>{input_tokens + output_tokens:,}</b>", s_td),
                ],
            ]
            usage_tbl = Table(usage_data, colWidths=[CONTENT_W * 0.5, CONTENT_W * 0.5])
            usage_tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, 0),  C_BLUE_TINT),
                ("LINEBELOW",     (0, 0), (-1, 0),  1.0, C_BLUE_MID),
                ("GRID",          (0, 0), (-1, -1), 0.4, C_GRAY_RULE),
                ("BOX",           (0, 0), (-1, -1), 0.8, C_BLUE_MID),
                ("LEFTPADDING",   (0, 0), (-1, -1), 8),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 8),
                ("TOPPADDING",    (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                ("BACKGROUND",    (0, 3), (-1, 3),  colors.HexColor("#eaf4ff")),  # total row
            ]))

            # ── Cost table ────────────────────────────────────────────────────────
            SYMBOLS = {"USD": "$", "INR": "Rs.", "EUR": "€"}
            cost_data = [
                [
                    Paragraph("Currency",       s_th),
                    Paragraph("Input cost",     s_th),
                    Paragraph("Output cost",    s_th),
                    Paragraph("Total cost",     s_th),
                ]
            ]
            for currency, vals in costs.items():
                sym = SYMBOLS.get(currency, currency)
                cost_data.append([
                    Paragraph(f"<b>{currency}</b>", s_td),
                    Paragraph(f"{sym} {vals['input']:.4f}",  s_td),
                    Paragraph(f"{sym} {vals['output']:.4f}", s_td),
                    Paragraph(f"<b>{sym} {vals['total']:.4f}</b>", s_td),
                ])

            cost_tbl = Table(
                cost_data,
                colWidths=[
                    CONTENT_W * 0.15,
                    CONTENT_W * 0.28,
                    CONTENT_W * 0.28,
                    CONTENT_W * 0.29,
                ],
                repeatRows=1,
            )
            cost_tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, 0),  C_BLUE_TINT),
                ("LINEBELOW",     (0, 0), (-1, 0),  1.0, C_BLUE_MID),
                ("GRID",          (0, 0), (-1, -1), 0.4, C_GRAY_RULE),
                ("BOX",           (0, 0), (-1, -1), 0.8, C_BLUE_MID),
                ("LEFTPADDING",   (0, 0), (-1, -1), 8),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 8),
                ("TOPPADDING",    (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                # Alternate row tint
                ("BACKGROUND",    (0, 2), (-1, 2),  C_ALT_ROW),
                # Highlight total column
                ("BACKGROUND",    (3, 1), (3, -1),  colors.HexColor("#eaf4ff")),
            ]))

            model_note = Paragraph(
                f"<i>Pricing based on model: <font name='Courier'>{model or 'unknown'}</font>. "
                "Exchange rates: 1 USD = Rs.96.3 / €0.92 (approximate, May 2026).</i>",
                s("VNote", fontSize=7.5, leading=11, textColor=C_GRAY_TEXT),
            )

            return [
                Spacer(1, 4 * mm),
                heading,
                rule,
                usage_tbl,
                Spacer(1, 3 * mm),
                cost_tbl,
                Spacer(1, 2 * mm),
                model_note,
                Spacer(1, 3 * mm),
            ]
        
        def meta_table(rows: list[tuple[str, str]]):
            data = [[Paragraph(label, s_meta_label), Paragraph(val, s_meta_val)]
                    for label, val in rows if val]
            if not data:
                return Spacer(1, 1 * mm)
            tbl = Table(data, colWidths=[40 * mm, CONTENT_W - 40 * mm])
            tbl.setStyle(TableStyle([
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING",   (0, 0), (-1, -1), 4),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
                ("TOPPADDING",    (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LINEBELOW",     (0, 0), (-1, -1), 0.3, C_GRAY_RULE),
            ]))
            return tbl

        # ── Parse + inject default heading if missing ─────────────────────────
        sections = self._parse_markdown(markdown)
        has_h1 = any(s.type == "h1" for s in sections)
        story: list = []

        if not has_h1:
            story.append(Paragraph(self._escape(title), s_h1))
            story.append(HRFlowable(width="100%", thickness=1.5,
                                    color=C_BLUE_DARK, spaceAfter=8))
            story.append(Spacer(1, 2 * mm))

        # ── Metadata table ────────────────────────────────────────────────────
        if metadata:
            meta_rows = [
                ("Feature",         metadata.feature_name),
                ("Version",         metadata.version),
                ("Model",           metadata.model),
                ("Organization",    metadata.org_name),
                ("Repository",      metadata.repo_name),
                ("Project",         metadata.project_name),
                ("Branch",          metadata.branch_name),
                ("Authors",         metadata.authors),
                ("Current Commit",  metadata.current_commit),
                ("Previous Commit", metadata.previous_commit),
                ("Commit Message",  metadata.commit_message),
                ("Commit Time",     metadata.commit_time),
                ("Generated",       metadata.generated_date),
            ]
            story.append(meta_table(meta_rows))
            if metadata.changed_files:
                files_str = ", ".join(metadata.changed_files[:10])
                if len(metadata.changed_files) > 10:
                    files_str += f" (+{len(metadata.changed_files) - 10} more)"
                story.append(meta_table([("Changed Files", files_str)]))
            story.append(Spacer(1, 3 * mm))
            story.append(HRFlowable(width="100%", thickness=1,
                                    color=C_BLUE_MID, spaceAfter=8))
        
        # ── SAST finding card styles ──────────────────────────────────────────
        # Matches the Checkmarx finding card layout from the reference screenshot:
        #   ┌─[SEVERITY BADGE]  Title                          Line N ─────┐
        #   │  [CWE-xxx]  [OWASP A0N:2021 - Category]                      │
        #   │  Issue:  <description>                                        │
        #   │  ┌─ Impact ──────────────────────────────────────────────────┐│
        #   │  │  <exploitation scenario>                                  ││
        #   │  └───────────────────────────────────────────────────────────┘│
        #   │  ┌── code viewer with line numbers, vuln line highlighted ───┐│
        #   │  │  6   # comment                                            ││
        #   │  │  7 ► app.secret_key = "..."   ← highlighted yellow        ││
        #   │  │  8                                                         ││
        #   │  └───────────────────────────────────────────────────────────┘│
        #   │  Fix:   <remediation>                                         │
        #   └───────────────────────────────────────────────────────────────┘

        import re as _re

        # Severity colours (same as badge palette)
        _SEV_LEFT_BAR = {
            "critical": colors.HexColor("#D9534F"),
            "high":     colors.HexColor("#E8824A"),
            "medium":   colors.HexColor("#F0AD4E"),
            "low":      colors.HexColor("#5BC0DE"),
            "info":     colors.HexColor("#9B9B9B"),
            "dep":      colors.HexColor("#7B68EE"),   # dependency findings
        }
        _SEV_BADGE_BG = _SEV_LEFT_BAR   # same palette

        # SAST finding heading pattern — matches all variants the agent might write:
        #   ### [CRITICAL] SAST-001 — title     (standard)
        #   ### [HIGH] DEP-001 — title           (dependency)
        #   ### CRITICAL SAST-001 — title        (without brackets)
        #   #### [HIGH] SAST-002 — title         (level 4, parsed as h3)
        # The h3_content received here is ALREADY stripped of the ### prefix by the parser.
        _FINDING_H3 = _re.compile(
            r"^\[?(?P<sev>CRITICAL|HIGH|MEDIUM|LOW|INFO)\]?\s+"
            r"(?P<id>(?:SAST|DEP|CONF)-\d+)\s+[—\-–]+\s*(?P<title>.+)$",
            _re.IGNORECASE,
        )

        

        def _parse_sev(text: str) -> str:
            """Extract severity from heading content like '[HIGH] SAST-001 — …'"""
            m = _re.match(r"\[?(\w+)\]?", text.strip())
            return m.group(1).lower() if m else "info"

        def _sast_finding_card(h3_content: str, body_secs: list) -> list:
            """
            Build a Checkmarx-style finding card as a list of ReportLab flowables.

            h3_content : the raw text after '### ' e.g. '[HIGH] SAST-001 — Hardcoded Secret'
            body_secs  : ParsedSection list that follows the h3 heading (bullets, code, text)
            """
            m = _FINDING_H3.match(h3_content.strip())
            if not m:
                return []   # not a SAST finding — caller will render normally

            sev       = m.group("sev").lower()
            find_id   = m.group("id")
            title     = m.group("title").strip()
            bar_color = _SEV_LEFT_BAR.get(sev, colors.HexColor("#9B9B9B"))
            badge_bg  = _SEV_BADGE_BG.get(sev, colors.HexColor("#9B9B9B"))

            # ── Parse bullet fields out of body_secs ──────────────────────────
            fields: dict[str, str] = {}   # lowercase key → value
            code_text  = ""
            code_lang  = ""
            file_ref   = ""
            line_num   = 0

            for bs in body_secs:
                if bs.type in ("bullet", "text"):
                    # Bullets are "**Key**: value" or "Key: value"
                    raw = bs.content
                    # Strip bold markers for key detection
                    clean = _re.sub(r"\*\*(.+?)\*\*", r"\1", raw)
                    kv_m  = _re.match(r"^([^:]+):\s*(.+)$", clean, _re.DOTALL)
                    if kv_m:
                        key = kv_m.group(1).strip().lower()
                        val = kv_m.group(2).strip()
                        fields[key] = val
                        # Extract file + line
                        if key in ("file & line", "file", "file:line"):
                            fl_m = _re.match(r"(.+?)(?::(\d+))?$", val)
                            if fl_m:
                                file_ref = fl_m.group(1).strip()
                                line_num = int(fl_m.group(2)) if fl_m.group(2) else 0
                elif bs.type == "code":
                    code_text = bs.content
                    code_lang = ""

            # Also check 'code' field captured in bullets (inline backtick snippets)
            if not code_text:
                for key in ("code", "code snippet", "snippet"):
                    if key in fields:
                        code_text = fields[key].strip("`")
                        break

            # ── Styles for card internals ─────────────────────────────────────
            s_card_title = ParagraphStyle(
                "VCardTitle", parent=base["Normal"],
                fontSize=11, leading=15, fontName="Helvetica-Bold",
                textColor=C_DARK,
            )
            s_badge_text = ParagraphStyle(
                "VBadgeTxt", parent=base["Normal"],
                fontSize=9, leading=12, fontName="Helvetica-Bold",
                textColor=colors.white, alignment=1,
            )
            s_tag = ParagraphStyle(
                "VTag", parent=base["Normal"],
                fontSize=8, leading=11, fontName="Helvetica",
                textColor=C_BLUE_MID,
                borderColor=C_BLUE_MID, borderWidth=0.5,
                borderPadding=(2, 4, 2, 4),
            )
            s_field_label = ParagraphStyle(
                "VFLabel", parent=base["Normal"],
                fontSize=9, leading=13, fontName="Helvetica-Bold",
                textColor=C_GRAY_TEXT,
            )
            s_field_val = ParagraphStyle(
                "VFVal", parent=base["Normal"],
                fontSize=9.5, leading=14, textColor=C_DARK,
            )
            s_impact_val = ParagraphStyle(
                "VFImpact", parent=base["Normal"],
                fontSize=9.5, leading=14, textColor=C_BLUE_MID,
                fontName="Helvetica-Oblique",
            )
            s_fix_val = ParagraphStyle(
                "VFFix", parent=base["Normal"],
                fontSize=9.5, leading=14, textColor=colors.HexColor("#2d6a2d"),
            )
            s_line_num = ParagraphStyle(
                "VLN", parent=base["Normal"],
                fontSize=8, leading=12, fontName="Courier",
                textColor=C_GRAY_TEXT, alignment=2,   # right-aligned
            )
            s_line_code = ParagraphStyle(
                "VLC", parent=base["Normal"],
                fontSize=8, leading=12, fontName="Courier",
                textColor=C_DARK,
            )
            s_line_code_hl = ParagraphStyle(
                "VLCHL", parent=base["Normal"],
                fontSize=8, leading=12, fontName="Courier-Bold",
                textColor=colors.HexColor("#7a4000"),
            )
            s_line_num_hl = ParagraphStyle(
                "VLNHL", parent=base["Normal"],
                fontSize=8, leading=12, fontName="Courier-Bold",
                textColor=colors.HexColor("#7a4000"), alignment=2,
            )

            # ── 1. Header row: badge + title + line ref ───────────────────────
            badge_cell  = Paragraph(sev.upper(), s_badge_text)
            id_title    = Paragraph(
                f"<b>{self._escape(find_id)}</b> &nbsp;—&nbsp; {self._escape(title)}",
                s_card_title,
            )
            line_ref_str = f"Line {line_num}" if line_num else (file_ref or "")
            line_ref    = Paragraph(
                self._escape(line_ref_str),
                ParagraphStyle("VLRef", parent=base["Normal"],
                               fontSize=9, textColor=C_GRAY_TEXT, alignment=2),
            )

            BADGE_W = 58
            header_tbl = Table(
                [[badge_cell, id_title, line_ref]],
                colWidths=[BADGE_W, CONTENT_W - BADGE_W - 55, 55],
            )
            header_tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (0, 0),  badge_bg),
                ("BACKGROUND",    (1, 0), (-1, 0), colors.HexColor("#f8f8f8")),
                ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING",   (0, 0), (-1, -1), 6),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
                ("TOPPADDING",    (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("BOX",           (0, 0), (-1, -1), 0.5, C_GRAY_RULE),
            ]))

            # ── 2. CWE / OWASP tag row ────────────────────────────────────────
            tag_parts = []
            for key in ("cwe", "references", "owasp", "owasp api"):
                if key in fields:
                    # Split "CWE-89 | OWASP A03:2021 | ..." into individual tags
                    for part in _re.split(r"[|,]", fields[key]):
                        part = part.strip()
                        if part:
                            tag_parts.append(part)

            tag_flowables = []
            for tp in tag_parts[:5]:   # cap at 5 tags
                tag_flowables.append(
                    Paragraph(f"[ {self._escape(tp)} ]", s_tag)
                )

            tag_row_content: list = tag_flowables if tag_flowables else [Spacer(1, 1)]
            tag_tbl = Table(
                [tag_row_content],
                colWidths=[CONTENT_W / max(len(tag_row_content), 1)] * len(tag_row_content)
                          if tag_flowables else [CONTENT_W],
            )
            tag_tbl.setStyle(TableStyle([
                ("BACKGROUND",   (0, 0), (-1, -1), colors.HexColor("#f0f4f8")),
                ("LEFTPADDING",  (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING",   (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING",(0, 0), (-1, -1), 4),
                ("VALIGN",       (0, 0), (-1, -1), "MIDDLE"),
            ]))

            # ── 3. Issue / Description field ──────────────────────────────────
            desc_text = (
                fields.get("description")
                or fields.get("issue")
                or fields.get("desc")
                or ""
            )
            desc_label = Paragraph("Issue:", s_field_label)
            desc_val   = Paragraph(self._escape(desc_text), s_field_val) if desc_text else Spacer(1, 1)
            desc_tbl   = Table(
                [[desc_label, desc_val]],
                colWidths=[38, CONTENT_W - 38],
            )
            desc_tbl.setStyle(TableStyle([
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING",   (0, 0), (-1, -1), 6),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
                ("TOPPADDING",    (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("BACKGROUND",    (0, 0), (-1, -1), colors.white),
                ("BOX",           (0, 0), (-1, -1), 0.3, C_GRAY_RULE),
            ]))

            # ── 4. Impact / Exploitation Scenario (blue accent panel) ─────────
            impact_text = (
                fields.get("exploitation scenario")
                or fields.get("impact")
                or fields.get("exploitation")
                or ""
            )
            impact_elements: list = []
            if impact_text:
                impact_label = Paragraph("Impact:", s_field_label)
                impact_val   = Paragraph(self._escape(impact_text), s_impact_val)
                impact_inner = Table(
                    [[impact_label, impact_val]],
                    colWidths=[38, CONTENT_W - 38 - 8],
                )
                impact_inner.setStyle(TableStyle([
                    ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING",   (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
                    ("TOPPADDING",    (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ("BACKGROUND",    (0, 0), (-1, -1), colors.HexColor("#eaf4ff")),
                    # Blue left accent bar via left border only
                    ("LINEBEFORE",    (0, 0), (0, -1), 3, colors.HexColor("#2e6da4")),
                ]))
                impact_elements = [impact_inner]

            # ── 5. Code viewer with line numbers ──────────────────────────────
            code_elements: list = []
            raw_code = code_text.strip()
            if raw_code:
                # Split into lines; detect which line number is the vuln line
                code_lines_raw = raw_code.splitlines()

                # If we have a line number, try to show 3 lines before + 3 after
                # centred on the vulnerable line.
                # code_text from the markdown usually IS just the snippet, so
                # we treat line_num as the first line of the snippet unless the
                # snippet has line-number prefixes ("7   app.secret_key = ...").
                first_display_line = max(1, line_num - 3) if line_num else 1
                vuln_line          = line_num  # 0 means unknown

                code_viewer_rows: list = []
                for i, cl in enumerate(code_lines_raw):
                    # Strip any existing line-number prefix from the snippet
                    cl_stripped = _re.sub(r"^\s*\d+\s*", "", cl) if _re.match(r"^\s*\d+\s+\S", cl) else cl
                    display_num = first_display_line + i
                    is_vuln     = (vuln_line > 0 and display_num == vuln_line)

                    ln_style   = s_line_num_hl  if is_vuln else s_line_num
                    code_style = s_line_code_hl if is_vuln else s_line_code
                    bg_color   = colors.HexColor("#fff9e6") if is_vuln else colors.white

                    # Wrap long code lines
                    if len(cl_stripped) > 90:
                        cl_stripped = cl_stripped[:87] + " ↵"

                    # Escape for ReportLab XML but preserve Courier font
                    safe_code = (
                        cl_stripped
                        .replace("&", "&amp;")
                        .replace("<", "&lt;")
                        .replace(">", "&gt;")
                    )

                    ln_cell   = Paragraph(str(display_num), ln_style)
                    code_cell = Paragraph(safe_code or "&nbsp;", code_style)
                    code_viewer_rows.append(([ln_cell, code_cell], bg_color, is_vuln))

                if code_viewer_rows:
                    tbl_data   = [[r[0][0], r[0][1]] for r in code_viewer_rows]
                    row_bgs    = [r[1] for r in code_viewer_rows]
                    vuln_rows  = [i for i, r in enumerate(code_viewer_rows) if r[2]]

                    cv_tbl = Table(
                        tbl_data,
                        colWidths=[22, CONTENT_W - 22],
                    )
                    cv_ts = TableStyle([
                        ("BACKGROUND",    (0, 0), (-1, -1), colors.white),
                        ("GRID",          (0, 0), (-1, -1), 0.3, colors.HexColor("#e0e0e0")),
                        ("BOX",           (0, 0), (-1, -1), 0.6, colors.HexColor("#cccccc")),
                        ("LEFTPADDING",   (0, 0), (-1, -1), 5),
                        ("RIGHTPADDING",  (0, 0), (-1, -1), 5),
                        ("TOPPADDING",    (0, 0), (-1, -1), 2),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
                        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
                        ("ALIGN",         (0, 0), (0, -1),  "RIGHT"),   # line nums right-aligned
                    ])
                    # Apply per-row background
                    for i, bg in enumerate(row_bgs):
                        cv_ts.add("BACKGROUND", (0, i), (-1, i), bg)
                    # Highlighted vuln rows: bolder left border
                    for vi in vuln_rows:
                        cv_ts.add("LINEBEFORE", (0, vi), (0, vi), 3, bar_color)

                    cv_tbl.setStyle(cv_ts)
                    code_elements = [Spacer(1, 2 * mm), cv_tbl, Spacer(1, 1 * mm)]

            # ── 6. Fix / Remediation field (green accent panel) ───────────────
            fix_text = (
                fields.get("remediation")
                or fields.get("fix")
                or fields.get("secure code recommendation")
                or ""
            )
            fix_elements: list = []
            if fix_text:
                fix_label = Paragraph("Fix:", s_field_label)
                fix_val   = Paragraph(self._escape(fix_text), s_fix_val)
                fix_inner = Table(
                    [[fix_label, fix_val]],
                    colWidths=[28, CONTENT_W - 28 - 8],
                )
                fix_inner.setStyle(TableStyle([
                    ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING",   (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
                    ("TOPPADDING",    (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ("BACKGROUND",    (0, 0), (-1, -1), colors.HexColor("#eafaef")),
                    ("LINEBEFORE",    (0, 0), (0, -1), 3, colors.HexColor("#2d8a2d")),
                ]))
                fix_elements = [fix_inner]

            # ── 7. Assemble the card outer border ─────────────────────────────
            # Everything sits in a single-cell outer table that provides the
            # left coloured bar + outer border — matching Checkmarx's card look.
            inner_story: list = [header_tbl]
            if tag_flowables:
                inner_story.append(tag_tbl)
            inner_story.append(Spacer(1, 2 * mm))
            inner_story.append(desc_tbl)
            inner_story.extend(impact_elements)
            inner_story.extend(code_elements)
            inner_story.extend(fix_elements)
            inner_story.append(Spacer(1, 1 * mm))

            from reportlab.platypus import KeepTogether
            try:
                # KeepTogether keeps the card on one page when it fits.
                # Must receive a flat list of Flowables — never a nested list.
                return [Spacer(1, 3 * mm), KeepTogether(inner_story), Spacer(1, 2 * mm)]
            except Exception:
                # KeepTogether failed — return flat list directly (always safe)
                return [Spacer(1, 3 * mm)] + inner_story + [Spacer(1, 2 * mm)]

        # ── Group sections into SAST finding cards where applicable ──────────
        # Walk the section list; when we hit an h3 that matches the SAST
        # finding pattern, collect the body sections that follow it (until
        # the next h3/h2/h1/hr) and emit a card instead of individual elements.

        def _render_section(sec, story: list) -> None:
            """Render a single non-finding section normally."""
            if sec.type == "h1":
                story.append(Spacer(1, 2 * mm))
                story.append(Paragraph(self._escape(sec.content), s_h1))
                story.append(HRFlowable(width="100%", thickness=1.5,
                                        color=C_BLUE_DARK, spaceAfter=6))
            elif sec.type == "h2":
                story.append(Spacer(1, 3 * mm))
                story.append(Paragraph(self._escape(sec.content), s_h2))
                story.append(HRFlowable(width="100%", thickness=0.5,
                                        color=C_GRAY_RULE, spaceAfter=4))
            elif sec.type == "h3":
                story.append(Spacer(1, 2 * mm))
                story.append(Paragraph(self._escape(sec.content), s_h3))
            elif sec.type == "code":
                story.append(Spacer(1, 2 * mm))
                story.extend(code_block(sec.content))
                story.append(Spacer(1, 2 * mm))
            elif sec.type == "table":
                story.append(Spacer(1, 2 * mm))
                story.append(md_table(sec.rows))
                story.append(Spacer(1, 3 * mm))
            elif sec.type == "bullet":
                if sec.level == 0:
                    st, prefix = s_bullet,  "• "
                elif sec.level == 1:
                    st, prefix = s_bullet2, "◦ "
                else:
                    st, prefix = s_bullet3, "▪ "
                story.append(Paragraph(prefix + self._escape(sec.content), st))
            elif sec.type == "hr":
                story.append(Spacer(1, 2 * mm))
                story.append(HRFlowable(width="100%", thickness=0.5,
                                        color=C_GRAY_RULE))
                story.append(Spacer(1, 2 * mm))
            elif sec.type == "html":
                import base64 as _base64
                from reportlab.platypus import Image as RLImage
                img_pattern = re.compile(
                    r'src="data:image/png;base64,([A-Za-z0-9+/=\s]+)"',
                    re.DOTALL,
                )
                matches = img_pattern.findall(sec.content)
                if matches:
                    story.append(Spacer(1, 3 * mm))
                    img_flowables = []
                    for b64_data in matches:
                        try:
                            img_bytes = _base64.b64decode(
                                b64_data.replace("\n", "").replace(" ", "")
                            )
                            col_w = CONTENT_W / len(matches)
                            img_obj = RLImage(
                                io.BytesIO(img_bytes),
                                width=col_w - 8,
                                height=col_w - 8,
                                kind="proportional",
                            )
                            img_flowables.append(img_obj)
                        except Exception as img_err:
                            logger.warn(f"[doc] chart embed failed: {img_err}")
                    if img_flowables:
                        col_w = CONTENT_W / len(img_flowables)
                        img_tbl = Table(
                            [img_flowables],
                            colWidths=[col_w] * len(img_flowables),
                        )
                        img_tbl.setStyle(TableStyle([
                            ("ALIGN",          (0, 0), (-1, -1), "CENTER"),
                            ("VALIGN",         (0, 0), (-1, -1), "MIDDLE"),
                            ("LEFTPADDING",    (0, 0), (-1, -1), 4),
                            ("RIGHTPADDING",   (0, 0), (-1, -1), 4),
                            ("TOPPADDING",     (0, 0), (-1, -1), 4),
                            ("BOTTOMPADDING",  (0, 0), (-1, -1), 4),
                        ]))
                        story.append(img_tbl)
                        story.append(Spacer(1, 3 * mm))
            elif sec.type == "text":
                story.append(Paragraph(self._escape(sec.content), s_body))

        # ── Main content ──────────────────────────────────────────────────────
        i = 0
        while i < len(sections):
            sec = sections[i]

            # A finding can appear as h3, h4 (parsed as h3), OR even as a text/bullet
            # line when the agent omits the ### prefix. Check all three.
            is_finding = (
                sec.type == "h3" and _FINDING_H3.match(sec.content.strip())
            ) or (
                sec.type in ("text", "bullet") and _FINDING_H3.match(sec.content.strip())
            )

            if is_finding:
                # Collect body sections until the next structural break or next finding
                body: list = []
                j = i + 1
                while j < len(sections):
                    ns = sections[j]
                    # Stop at any heading, hr, or another finding line
                    if ns.type in ("h1", "h2", "h3", "hr"):
                        break
                    if ns.type in ("text", "bullet") and _FINDING_H3.match(ns.content.strip()):
                        break
                    body.append(ns)
                    j += 1
                card_flowables = _sast_finding_card(sec.content, body)
                if card_flowables:
                    story.extend(card_flowables)
                    i = j
                    continue
                else:
                    _render_section(sec, story)
                    i += 1
                    continue
            else:
                _render_section(sec, story)
                i += 1

        # ── Token usage + cost table (always last section) ───────────────────
        if metadata and (metadata.input_tokens or metadata.output_tokens):
            story.extend(
                token_cost_table(
                    input_tokens=metadata.input_tokens,
                    output_tokens=metadata.output_tokens,
                    model=metadata.model,
                )
            )

        # Strip trailing spacers/rules to prevent blank last page
        while story and isinstance(story[-1], (Spacer, HRFlowable)):
            story.pop()

        # ── Build doc ─────────────────────────────────────────────────────────
        has_branding = bool(company_name or logo_bytes)
        top_margin = MARGIN + (14 * mm if has_branding else 0)

        doc = SimpleDocTemplate(
            output_path, pagesize=A4,
            leftMargin=MARGIN, rightMargin=MARGIN,
            topMargin=top_margin, bottomMargin=MARGIN + 6 * mm,
            title=title, author="vidura-agent",
        )

        page_fn = partial(
            self._draw_page_chrome,
            company_name=company_name or "",
            logo_bytes=logo_bytes,
            margin=MARGIN,
            has_branding=has_branding,
        )
        doc.build(story, onFirstPage=page_fn, onLaterPages=page_fn)

    # ─── Per-page chrome (header + footer) ───────────────────────────────────

    @staticmethod
    def _draw_page_chrome(
        canvas,
        doc,
        company_name: str = "",
        logo_bytes: bytes | None = None,
        margin: float = 0,
        has_branding: bool = False,
    ) -> None:
        from reportlab.lib import colors

        canvas.saveState()
        PAGE_W, PAGE_H = doc.pagesize

        # Header (only when branding present)
        if has_branding:
            LINE_Y = PAGE_H - margin - 10 * mm

            if logo_bytes:
                try:
                    from reportlab.lib.utils import ImageReader
                    img = ImageReader(io.BytesIO(logo_bytes))
                    logo_h = 9 * mm
                    iw, ih = img.getSize()
                    logo_w = logo_h * (iw / ih) if ih else logo_h
                    canvas.drawImage(
                        img, margin, LINE_Y + 1 * mm,
                        width=logo_w, height=logo_h,
                        preserveAspectRatio=True, mask="auto",
                    )
                except Exception as err:
                    logger.warn(f"Logo render failed: {err}")

            if company_name:
                canvas.setFont("Helvetica-BoldOblique", 8.5)
                canvas.setFillColor(colors.HexColor("#888888"))
                canvas.drawCentredString(PAGE_W / 2, LINE_Y + 2 * mm, company_name)

            canvas.setStrokeColor(colors.HexColor("#2e6da4"))
            canvas.setLineWidth(0.5)
            canvas.line(margin, LINE_Y, PAGE_W - margin, LINE_Y)

        # Footer — page number always shown
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#aaaaaa"))
        canvas.drawCentredString(
            PAGE_W / 2,
            margin / 2,
            f"Page {canvas.getPageNumber()}",
        )
        # Thin footer rule
        canvas.setStrokeColor(colors.HexColor("#dddddd"))
        canvas.setLineWidth(0.3)
        canvas.line(margin, margin * 0.75, PAGE_W - margin, margin * 0.75)

        canvas.restoreState()

    # ─── Markdown parser ──────────────────────────────────────────────────────

    @staticmethod
    def _escape(text: str) -> str:
        text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
        text = re.sub(r"\*(.+?)\*",     r"<i>\1</i>", text)
        text = re.sub(r"`([^`]+)`",     r"<font name='Courier'>\1</font>", text)
        return text

    @staticmethod
    def _parse_markdown(markdown: str) -> list[ParsedSection]:
        result: list[ParsedSection] = []
        in_code = False
        code_lines: list[str] = []
        table_rows: list[list[str]] = []

        def flush_table():
            if table_rows:
                result.append(ParsedSection(type="table", content="", rows=list(table_rows)))
                table_rows.clear()

        def parse_table_row(line: str) -> list[str]:
            protected = re.sub(r"`[^`]*`", lambda m: m.group(0).replace("|", "\x01"), line)
            protected = protected.replace("\\|", "\x02")
            cells = [c.strip() for c in protected.strip().strip("|").split("|")]
            return [c.replace("\x01", "|").replace("\x02", "|") for c in cells]

        # ── NEW: extract HTML blocks (chart tables) before line-by-line parsing ──
        # The SAST agent injects <table>...</table> blocks containing base64 chart
        # images. The line-by-line parser can't handle multi-line HTML, so we split
        # the markdown on these blocks first and replace them with placeholders.
        html_block_pattern = re.compile(
            r'(<table\b[^>]*>.*?</table>)',
            re.DOTALL | re.IGNORECASE,
        )
        html_blocks: dict[str, str] = {}
        segments = html_block_pattern.split(markdown)
        markdown_lines: list[str] = []
        for seg in segments:
            if html_block_pattern.fullmatch(seg):
                placeholder = f"__HTML_BLOCK_{len(html_blocks)}__"
                html_blocks[placeholder] = seg
                markdown_lines.append(placeholder)
            else:
                markdown_lines.extend(seg.split("\n"))
        # ── END NEW ───────────────────────────────────────────────────────────────

        for line in markdown_lines:
            # ── NEW: HTML block placeholder ───────────────────────────────────────
            if line in html_blocks:
                flush_table()
                result.append(ParsedSection(type="html", content=html_blocks[line]))
                continue
            # ── END NEW ───────────────────────────────────────────────────────────

            if line.lstrip().startswith("```"):
                flush_table()
                if in_code:
                    result.append(ParsedSection(type="code", content="\n".join(code_lines)))
                    code_lines.clear()
                    in_code = False
                else:
                    in_code = True
                continue

            if in_code:
                code_lines.append(line)
                continue

            stripped = line.strip()

            if stripped.startswith("|") and stripped.endswith("|"):
                if re.match(r"^\|[\s\-:|]+\|$", stripped):
                    continue
                table_rows.append(parse_table_row(line))
                continue
            else:
                flush_table()

            if re.match(r"^(-{3,}|_{3,}|\*{3,})$", stripped):
                result.append(ParsedSection(type="hr", content=""))
                continue

            if line.startswith("#### "):
                result.append(ParsedSection(type="h3", content=line[5:].strip()))
            elif line.startswith("### "):
                result.append(ParsedSection(type="h3", content=line[4:].strip()))
            elif line.startswith("## "):
                result.append(ParsedSection(type="h2", content=line[3:].strip()))
            elif line.startswith("# "):
                result.append(ParsedSection(type="h1", content=line[2:].strip()))
            elif re.match(r"^\s{0,2}[-*+]\s+", line):
                content = re.sub(r"^\s*[-*+]\s+", "", line).strip()
                result.append(ParsedSection(type="bullet", content=content, level=0))
            elif re.match(r"^\s{3,5}[-*+]\s+", line):
                content = re.sub(r"^\s*[-*+]\s+", "", line).strip()
                result.append(ParsedSection(type="bullet", content=content, level=1))
            elif re.match(r"^\s{6,}[-*+]\s+", line):
                content = re.sub(r"^\s*[-*+]\s+", "", line).strip()
                result.append(ParsedSection(type="bullet", content=content, level=2))
            elif stripped:
                result.append(ParsedSection(type="text", content=stripped))

        flush_table()
        if code_lines:
            result.append(ParsedSection(type="code", content="\n".join(code_lines)))

        return result