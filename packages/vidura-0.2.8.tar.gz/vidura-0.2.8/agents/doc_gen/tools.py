"""Doc-gen agent tool handler — API extraction, validation, writing, critique, evaluation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agents.doc_gen.document import DocumentGenerator, DocumentMetadata
from core.diff_utils import build_diff_batches
from core.validator_engine import ValidatorEngine
from core.config import AgentConfig
from core.extractor.types import ChangedFile, ExtractedApiDelta
from core.logger import logger
from core.memory import MemoryManager
from core.skill_loader import load_skill
from core.skill_runner import SkillRunner
from core.tools.executor import ToolResult

# ─── Tool definitions exposed to the LLM ─────────────────────────────────────

TOOL_DEFINITIONS: list[dict] = [
    {
        "name": "extract_api_changes",
        "description": (
            "Analyze the changed files and extract all HTTP API endpoint changes. "
            "Language and framework agnostic — works for Python, Go, Java, TypeScript, Ruby, or any language. "
            "Call this once after get_changed_files. Returns structured endpoint data."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "validate_documentation",
        "description": (
            "Validate the stored draft against the extracted API delta. "
            "Returns valid (boolean), errors[], and warnings[]. "
            "Fix all errors before calling write_documentation. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "write_documentation",
        "description": (
            "Write the stored draft to disk as a PDF file. "
            "This is a TERMINAL action — the agent loop exits after this call. "
            "Only call after validate_documentation returns valid=true with no errors. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "featureName": {
                    "type": "string",
                    "description": (
                        'The feature name used for the output filename (e.g. "user-auth", "payment-api")'
                    ),
                },
            },
            "required": ["featureName"],
        },
    },
]

_HANDLED_TOOLS = {t["name"] for t in TOOL_DEFINITIONS}
EXTRACT_BATCH_SIZE = 5
BATCH_SIZE = EXTRACT_BATCH_SIZE

# Files that contain HTTP route registrations (primary signals)
_PRIMARY_ROUTE_HINTS = (
    "api", "route", "router", "view", "views", "endpoint",
    "handler", "controller", "url", "urls",
)

# Files that contain business logic delegated from route files (service layer).
# Covers patterns across all languages/frameworks:
#   Python  — helpers.py, db_helpers.py, services.py, serializers.py, managers.py, repositories.py
#   Go      — service.go, repository.go, store.go, usecase.go, query.go, db.go
#   Java/Kt — *Service.java, *ServiceImpl.java, *Repository.java, *Dao.java, *Manager.java
#   JS/TS   — *.service.ts, *.repository.ts, services/*.js, helpers/*.js
#   Ruby    — app/services/*.rb, app/helpers/*.rb, lib/**/*.rb
#   PHP     — *Service.php, *Repository.php, *Manager.php, *Helper.php
#   C#      — *Service.cs, *Repository.cs, *Manager.cs, *Handler.cs (CQRS)
#   Rust    — services/*.rs, repositories/*.rs, db/*.rs
#   Elixir  — *_service.ex, *_helper.ex, lib/*_context.ex (Phoenix Contexts)
_SERVICE_LAYER_HINTS = (
    "service", "services",
    "helper", "helpers",
    "db_helper", "db_helpers",
    "util", "utils",
    "repository", "repo", "repos",
    "manager", "managers",
    "serializer", "serializers",
    "schema", "schemas",
    "model", "models",          
    "resource", "resources",
    "middleware", "middlewares",
    "query", "queries",
    "command", "commands",
    "usecase", "use_case",
    "store", "stores",
    "dao",
    "impl",
    "interactor",
    "gateway",
    "context", "contexts",
    "commandhandler", "queryhandler",
)


# ─── Tool handler ─────────────────────────────────────────────────────────────


class ToolHandler:
    """Handles doc-gen specific tools: extraction, validation, writing, critique, evaluation."""

    def __init__(
        self,
        repo_path: str,
        config: AgentConfig,
        branch: str,
        memory: MemoryManager,
        secondary_providers: dict[str, Any],
        skills_dir: Path,
        executor: Any,
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self.branch = branch
        self._memory = memory
        self._secondary_providers = secondary_providers
        self._skills_dir = skills_dir
        self._executor = executor

        self._merged_delta: ExtractedApiDelta | None = None
        self._doc_gen = DocumentGenerator()
        self._validator = ValidatorEngine()
        self._last_validation_passed: bool = False

    def can_handle(self, tool_name: str) -> bool:
        return tool_name in _HANDLED_TOOLS

    async def handle(self, tool_name: str, tool_input: dict[str, Any]) -> ToolResult:
        handlers = {
            "extract_api_changes": lambda: self._extract_api_changes(),
            "validate_documentation": lambda: self._validate_documentation(),
        }

        if tool_name == "write_documentation":
            return await self._write_documentation(tool_input.get("featureName", ""))

        handler = handlers.get(tool_name)
        if handler:
            return handler()

        return ToolResult(
            content=json.dumps({"error": f"Unknown doc-gen tool: {tool_name}"}),
            is_terminal=False,
        )

    # ─── Tool implementations ─────────────────────────────────────────────────

    def _extract_api_changes(self) -> ToolResult:
        import datetime

        changed_files = getattr(self._executor, "_changed_files", None)
        if changed_files is None:
            return ToolResult(
                content=json.dumps({"error": "No changed files available. Call get_changed_files first."}),
                is_terminal=False,
            )

        if not changed_files:
            return ToolResult(
                content=json.dumps({
                    "noChanges": True,
                    "new": [], "modified": [], "removed": [],
                    "message": "No files changed in this diff. Call signal_no_change.",
                }),
                is_terminal=False,
            )

        # Build combined diff — cap each file at 4000 chars to stay within token budget
        candidate_files = self._select_api_candidate_files(changed_files)
        if not candidate_files:
            return ToolResult(
                content=json.dumps({
                    "noChanges": True,
                    "new": [], "modified": [], "removed": [],
                    "message": "No likely API code files found in this diff. Call signal_no_change.",
                }),
                is_terminal=False,
            )

        # Load extractor skill and provider before batching
        import agents.doc_gen as _pkg
        bundled_path = Path(_pkg.__file__).parent / "skills" / "api-extractor.md"
        user_path = self._skills_dir / "api-extractor.md"
        extractor_path = user_path if user_path.exists() else (bundled_path if bundled_path.exists() else None)

        if extractor_path is None:
            return ToolResult(
                content=json.dumps({"error": "api-extractor.md not found. Run 'vidura init --agent doc-gen'."}),
                is_terminal=False,
            )

        provider = (
            self._secondary_providers.get("extractor")
            or self._secondary_providers.get("critic")
            or self._secondary_providers.get("evaluator")
        )
        if provider is None:
            return ToolResult(
                content=json.dumps({"error": "No LLM provider available for extraction."}),
                is_terminal=False,
            )

        skill = load_skill(extractor_path)
        runner = SkillRunner(provider=provider)

        # Detect if only service-layer files changed (no route files in diff).
        # If so, find related route/view files in the same dirs to provide HTTP context.
        has_route_file = any(
            any(h in Path(f.path.replace("\\", "/")).stem.lower() for h in _PRIMARY_ROUTE_HINTS)
            for f in candidate_files
        )
        route_context_files = self._find_route_context_files(candidate_files) if not has_route_file else []
        if route_context_files:
            logger.info(
                f"[extractor] no route files in diff — injecting {len(route_context_files)} "
                f"route context file(s): {[p for p, _ in route_context_files]}"
            )

        # Sort candidate files by directory so related files (views + serializers + helpers)
        # from the same module end up in the same batch — better cross-file schema resolution.
        # from collections import defaultdict
        # dir_groups: dict[str, list] = defaultdict(list)
        # for f in candidate_files:
        #     dir_groups[str(Path(f.path).parent)].append(f)
        # grouped_files = []
        # for parent_dir in sorted(dir_groups.keys()):
        #     grouped_files.extend(dir_groups[parent_dir])

        # # Batch files: groups of 3, max 12K chars per group.
        # # Each batch gets its own LLM call — results are merged.
        # # This prevents large commits from silently dropping endpoints due to single-blob truncation.
        # batches = build_diff_batches(
        #     grouped_files,
        #     batch_size=EXTRACT_BATCH_SIZE,
        #     per_file_cap=12_000,
        # )
        # logger.info(
        #     f"[extractor] {len(candidate_files)} candidate files → "
        #     f"{len(batches)} batch(es) of ≤{BATCH_SIZE} files"
        # )
        # Group files by directory — each Django app / module gets its own batch
        # This ensures views.py + serializers.py + helpers.py from same app
        # are always in the same LLM call for accurate schema cross-referencing
        from collections import defaultdict

        dir_groups: dict[str, list[ChangedFile]] = defaultdict(list)
        for f in candidate_files:
            dir_groups[str(Path(f.path).parent)].append(f)

        # One batch per directory — never mix files from different app directories.
        # build_diff_batches handles per-file content vs diff decision internally.
        batches: list[tuple[list[ChangedFile], str]] = []
        for parent_dir in sorted(dir_groups.keys()):
            group_files = dir_groups[parent_dir]
            dir_batches = build_diff_batches(
                group_files,
                batch_size=len(group_files),  # entire directory = one batch
                per_file_cap=90_000,
            )
            batches.extend(dir_batches)

        logger.info(
            f"[extractor] {len(candidate_files)} candidate files → "
            f"{len(batches)} batch(es) across {len(dir_groups)} directory group(s)"
        )

        merged: dict = {"new": [], "modified": [], "removed": []}
        extraction_tokens = {"in": 0, "out": 0}
        for batch_idx, (batch_files, diff_context) in enumerate(batches, 1):
            logger.step(f"[extractor] batch {batch_idx}/{len(batches)}: {[f.path for f in batch_files]}")
            batch_diff = diff_context
            if route_context_files:
                ctx_parts = "\n\n".join(
                    f"--- {p} (UNCHANGED — route context only, do NOT extract changes from this) ---\n{c}"
                    for p, c in route_context_files
                )
                batch_diff = (
                    "=== ROUTE CONTEXT FILES (unchanged — use ONLY to resolve HTTP method/path for the changed files below) ===\n"
                    + ctx_parts
                    + "\n\n=== CHANGED FILES (diff — extract API changes only from these) ===\n"
                    + diff_context
                )
            logger.debug(f"[extractor] batch {batch_idx} diff size: {len(batch_diff)} chars")

            schema_instruction = (
            "\n\n[EXTRACTION REQUIREMENT] "
            "You MUST extract every parameter and field visible in this batch. Specifically:\n"
            "1. PARAMETERS: Extract ALL request.data.get(...), request.query_params.get(...), "
            "request.GET.get(...), request.POST.get(...) calls as queryParams or requestSchema. "
            "Do NOT skip parameters that have no default value — if the code reads it, document it.\n"
            "2. SCHEMAS: If a serializer class is visible (e.g. EventSerializer), extract ALL its "
            "fields as requestSchema and responseSchema for the matching endpoint. "
            "For Django: fields = '__all__' means use ALL model fields from the matching model class "
            "visible in this batch — expand every field explicitly.\n"
            "3. NESTED RESPONSE: If the response returns a dict with nested serializer data "
            "(e.g. {'total': total, 'events': serializer.data}), document BOTH the wrapper fields "
            "(total, events) AND the fields inside the serializer as the shape of each array item.\n"
            "Returning empty or partial schemas when the code is visible in this batch is a hard error."
        )
            
            result = runner.run(skill, {"diff": batch_diff + schema_instruction, "branch": self.branch, "max_tokens": 15000})
            if runner.last_usage:
                extraction_tokens["in"] += runner.last_usage.input_tokens
                extraction_tokens["out"] += runner.last_usage.output_tokens

            if not isinstance(result, dict) or "error" in result:
                logger.warn(f"[extractor] batch {batch_idx} failed: {result} — skipping")
                continue

            if result.get("noChanges"):
                continue

            # DEBUG: show what schemas were extracted per endpoint
            for ep in result.get("new", []):
                req = ep.get("requestSchema", [])
                res = ep.get("responseSchema", [])
                logger.debug(
                    f"[extractor] batch {batch_idx} endpoint {ep.get('method')} {ep.get('path')} "
                    f"→ requestSchema={len(req)} fields, responseSchema={len(res)} fields"
                )
                if not req:
                    logger.debug(f"[extractor] MISSING requestSchema for {ep.get('method')} {ep.get('path')}")

            # Deduplicate by method+path before merging
            for key in ("new", "modified", "removed"):
                for item in result.get(key, []):
                    if not isinstance(item, dict):
                        continue
                    ep = item if key != "modified" else item.get("after", item)
                    sig = (ep.get("method", ""), ep.get("path", ""))
                    already = any(
                        (x if key != "modified" else x.get("after", x)).get("method") == sig[0]
                        and (x if key != "modified" else x.get("after", x)).get("path") == sig[1]
                        for x in merged[key]
                    )
                    if not already:
                        merged[key].append(item)

        result = merged
        if not result["new"] and not result["modified"] and not result["removed"]:
            return ToolResult(
                content=json.dumps({
                    "noChanges": True,
                    "new": [], "modified": [], "removed": [],
                    "message": "No API endpoint changes detected. Call signal_no_change.",
                }),
                is_terminal=False,
            )

        # Build _merged_delta from LLM result so the validator can cross-check the doc
        from core.extractor.types import (
            ApiEndpoint, AuthRequirement, ExtractedApiDelta,
            ModifiedEndpoint, SchemaField, PathParam, QueryParam,
        )

        def _parse_auth(d: dict) -> AuthRequirement | None:
            auth = d.get("auth", {})
            if not auth:
                return None
            return AuthRequirement(type=auth.get("type", "none"))

        def _parse_fields(items: list) -> list[SchemaField]:
            return [
                SchemaField(name=f["name"], type=f.get("type", "string"), required=bool(f.get("required", False)))
                for f in (items or [])
                if isinstance(f, dict) and f.get("name")
            ]

        def _parse_path_params(items: list) -> list[PathParam]:
            return [PathParam(name=p["name"], type=p.get("type", "string")) for p in (items or []) if isinstance(p, dict) and p.get("name")]

        def _parse_query_params(items: list) -> list[QueryParam]:
            return [QueryParam(name=q["name"], type=q.get("type", "string"), required=bool(q.get("required", False))) for q in (items or []) if isinstance(q, dict) and q.get("name")]

        def _parse_status_codes(items: list) -> list:
            from core.extractor.types import StatusCode
            return [
                StatusCode(code=int(s["code"]), description=s.get("description", ""))
                for s in (items or [])
                if isinstance(s, dict) and s.get("code")
            ]

        def _parse_ep(d: dict) -> ApiEndpoint:
            return ApiEndpoint(
                method=d.get("method", "GET"),
                path=d.get("path", "/unknown"),
                auth=_parse_auth(d),
                params=_parse_path_params(d.get("pathParams", [])),
                query=_parse_query_params(d.get("queryParams", [])),
                request_schema=_parse_fields(d.get("requestSchema", [])),
                response_schema=_parse_fields(d.get("responseSchema", [])),
                status_codes=_parse_status_codes(d.get("statusCodes", [])),
            )

        new_eps = [_parse_ep(e) for e in result.get("new", [])]
        modified_eps = [
            ModifiedEndpoint(
                before=_parse_ep(m.get("before", {})),
                after=_parse_ep(m.get("after", {})),
                change_type=m.get("changeType", "request-schema"),
            )
            for m in result.get("modified", [])
            if isinstance(m, dict)
        ]
        removed_eps = [_parse_ep(e) for e in result.get("removed", [])]

        self._merged_delta = ExtractedApiDelta(
            feature=self.branch,
            branch=self.branch,
            base_branch=self.config.base_branch,
            timestamp=datetime.datetime.utcnow().isoformat(),
            new=new_eps,
            modified=modified_eps,
            removed=removed_eps,
        )

        logger.info(
            f"[extractor] new={len(new_eps)} modified={len(modified_eps)} removed={len(removed_eps)} | "
            f"extraction tokens: {extraction_tokens['in']:,} in / {extraction_tokens['out']:,} out "
            f"({len(batches)} batch call(s))"
        )
        # Report secondary token usage to executor so workflow can account for it
        self._executor._secondary_tokens_used = getattr(self._executor, "_secondary_tokens_used", {"inputTokens": 0, "outputTokens": 0})
        self._executor._secondary_tokens_used["inputTokens"] += extraction_tokens["in"]
        self._executor._secondary_tokens_used["outputTokens"] += extraction_tokens["out"]

        # Count breaking changes for instruction
        breaking_count = sum(
            1 for m in result.get("modified", [])
            if isinstance(m, dict) and m.get("breaking")
        )
        result["_instruction"] = (
            f"Ground truth: document ONLY the {len(new_eps)} new, "
            f"{len(modified_eps)} modified ({breaking_count} breaking), "
            f"{len(removed_eps)} removed endpoints listed above. "
            "For modified endpoints: document ALL logicChanges entries — "
            "validation rules, error codes, rate limits, behavior changes."
        )
        return ToolResult(content=json.dumps(result), is_terminal=False)
    
    def _find_route_context_files(self, candidate_files: list[ChangedFile]) -> list[tuple[str, str]]:
        """When only service-layer files changed, find related route/view files in the
        same directories to provide HTTP method/path context to the extractor."""
        route_context: list[tuple[str, str]] = []
        checked_dirs: set[str] = set()

        for f in candidate_files:
            parent = str(Path(f.path).parent)
            if parent in checked_dirs:
                continue
            checked_dirs.add(parent)

            parent_path = Path(self.repo_path) / parent
            if not parent_path.exists():
                continue

            for candidate in parent_path.iterdir():
                if not candidate.is_file():
                    continue
                stem = candidate.stem.lower()
                if not any(h in stem for h in _PRIMARY_ROUTE_HINTS):
                    continue
                if candidate.suffix not in {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".java", ".kt", ".rb", ".php", ".cs"}:
                    continue
                rel = str(candidate.relative_to(self.repo_path)).replace("\\", "/")
                try:
                    content = candidate.read_text(encoding="utf-8", errors="replace")
                    route_context.append((rel, content[:8_000]))
                except Exception:
                    continue

        return route_context

    @staticmethod
    def _select_api_candidate_files(changed_files: list[ChangedFile]) -> list[ChangedFile]:
        allowed_exts = {
            ".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".java",
            ".kt", ".rb", ".php", ".cs", ".scala",
        }
        skip_parts = {
            ".git", ".agent", "docs", "skills", "templates", "__pycache__",
            "node_modules", "dist", "build", "migrations", "tests", "test",
            "frontend",
        }
        skip_suffixes = {
            ".md", ".rst", ".txt", ".json", ".yaml", ".yml", ".toml", ".ini",
        }
        route_hints = (
            "api", "route", "router", "view", "views", "endpoint",
            "handler", "controller","url", "urls","serializer", "serializers",
            "model", "models","helper", "helpers", "main", "app"
        )

        candidates: list[ChangedFile] = []
        fallback: list[ChangedFile] = []
        for changed in changed_files:
            path = (changed.path or "").replace("\\", "/")
            lower = path.lower()
            parts = set(lower.split("/"))
            suffix = Path(lower).suffix

            if parts & skip_parts:
                continue
            if suffix in skip_suffixes:
                continue
            if suffix and suffix not in allowed_exts:
                continue

            fallback.append(changed)
            if any(hint in lower for hint in route_hints):
                candidates.append(changed)

        return candidates or fallback[:15]

    def _validate_documentation(self) -> ToolResult:
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No draft available. Call store_draft first."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No API delta available. Call extract_api_changes first."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        # Load validator skill from skills dir
        validator_path = self._skills_dir / "validator.md"
        if not validator_path.exists():
            return ToolResult(
                content=json.dumps({
                    "valid": True,
                    "errors": [],
                    "warnings": ["No validator.md skill found — skipping validation."],
                }),
                is_terminal=False,
            )

        skill = load_skill(validator_path)
        result = self._validator.validate(draft, self._merged_delta, skill)

        # Track for rating — used by _store_run_summary after write
        self._last_validation_passed = result.valid

        message = (
            "Documentation is valid. You may now call write_documentation."
            if result.valid
            else f"Validation failed with {len(result.errors)} error(s). Fix before writing: {'; '.join(result.errors)}"
        )

        return ToolResult(
            content=json.dumps({
                "valid": result.valid,
                "errors": result.errors,
                "warnings": result.warnings,
                "message": message,
            }),
            is_terminal=False,
        )

    async def _write_documentation(self, feature_name: str) -> ToolResult:
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No draft available. Call store_draft before writing.",
                }),
                is_terminal=True,
                terminal_status="GENERATED",
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No API delta available. Call extract_api_changes before writing.",
                }),
                is_terminal=True,
                terminal_status="GENERATED",
            )

        output_dir = str(Path(self.repo_path) / self.config.output_dir)

        # Read doc-specific config from extra fields
        extra = getattr(self.config, "extra", {}) or {}
        # doc_title (explicit) takes precedence over template
        doc_title_override = extra.get("doc_title", "").strip()
        doc_title_template = (
            doc_title_override if doc_title_override
            else extra.get("doc_title_template", "{feature} - API Documentation")
        )

        from datetime import datetime as _dt
        from core.git import GitAnalyzer

        git = GitAnalyzer(self.repo_path)
        git_meta = git.get_commit_metadata(self.config.base_branch)
        changed_files = getattr(self._executor, "_changed_files", []) or []

        metadata = DocumentMetadata(
            feature_name=feature_name,
            version=git_meta.get("version", ""),
            org_name=self.config.org_name or "",
            repo_name=self.config.repo_name or git_meta.get("repo_name", ""),
            project_name=self.config.project_name or "",
            branch_name=self.branch,
            authors=git_meta.get("authors", "Engineering Team"),
            previous_commit=git_meta.get("previous_commit", ""),
            current_commit=git_meta.get("current_commit", ""),
            commit_message=git_meta.get("commit_message", ""),
            commit_time=git_meta.get("commit_time", ""),
            generated_date=_dt.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
            changed_files=[
                f"{f.path} ({f.status})" for f in changed_files
                if not f.path.startswith((".agent/", "docs/", "skills/"))
            ],

            # ── NEW ──────────────────────────────────────────────────────────
            input_tokens=getattr(self._executor, "_usage", {}).get("inputTokens", 0),
            output_tokens=getattr(self._executor, "_usage", {}).get("outputTokens", 0),
            model=getattr(self._executor, "_usage", {}).get("model", self.config.model),
        
        )

        output = await self._doc_gen.generate(
            draft,
            feature_name,
            output_dir,
            doc_title_template=doc_title_template,
            org_name=self.config.org_name,
            project_name=self.config.project_name,
            repo_name=self.config.repo_name,
            company_name=getattr(self.config, "company_name", None),
            logo_url=getattr(self.config, "logo_url", None),
            metadata=metadata,
        )

        # Store run summary + extract patterns to global memory on good runs
        self._store_run_summary(feature_name, extra)
        self._executor._run_quality = "good" if self._last_validation_passed and getattr(self._executor, "_store_draft_calls", 1) == 1 else "improved"
        self._executor.flush_pending_memory()

        logger.success(f"Documentation written -> {output.pdf_path}")

        return ToolResult(
            content=json.dumps({
                "success": True,
                "pdfPath": output.pdf_path,
            }),
            is_terminal=True,
            terminal_status="GENERATED",
            output_path=output.pdf_path,
            feature_name=feature_name,
        )

    def _store_run_summary(self, feature_name: str, extra: dict) -> None:
        if not self._merged_delta:
            return

        draft_attempts = getattr(self._executor, "_store_draft_calls", 1)
        n_new = len(self._merged_delta.new)
        n_mod = len(self._merged_delta.modified)
        n_rem = len(self._merged_delta.removed)

        # Good = validation passed on first draft attempt
        # Improved = validation passed but needed revision
        rating = "good" if (self._last_validation_passed and draft_attempts == 1) else "improved"

        step_seq = "get_changed_files → extract_api_changes → store_draft"
        if draft_attempts > 1:
            step_seq += f" → validate (failed) → store_draft ×{draft_attempts - 1}"
        step_seq += " → validate (passed) → write_documentation"

        note = (
            f"Endpoints: {n_new} new, {n_mod} modified, {n_rem} removed. "
            f"Draft attempts: {draft_attempts}. "
            f"Validation: {'passed' if self._last_validation_passed else 'failed'}. "
            f"Steps: {step_seq}."
        )

        self._memory.record_feedback(feature_name, rating, note)

        if rating == "good":
            self._extract_and_store_patterns(feature_name, step_seq, n_new, n_mod, n_rem)

    def _extract_and_store_patterns(
        self,
        feature_name: str,
        step_seq: str,
        n_new: int,
        n_mod: int,
        n_rem: int,
    ) -> None:
        """Fire-and-forget: extract reusable patterns from this good run and write to global memory."""
        import agents.doc_gen as _pkg

        bundled_path = Path(_pkg.__file__).parent / "skills" / "pattern-extractor.md"
        user_path = self._skills_dir / "pattern-extractor.md"
        skill_path = user_path if user_path.exists() else (bundled_path if bundled_path.exists() else None)

        if skill_path is None:
            logger.warn("[patterns] pattern-extractor.md not found — skipping global memory update")
            return

        provider = (
            self._secondary_providers.get("pattern-extractor")
            or self._secondary_providers.get("extractor")
            or self._secondary_providers.get("critic")
        )
        if provider is None:
            return

        # Read existing patterns so the extractor avoids proposing duplicates
        existing_patterns = self._memory.get_global_patterns(max_chars=2000)

        run_context = (
            f"Feature: {feature_name}\n"
            f"Endpoints: {n_new} new, {n_mod} modified, {n_rem} removed\n"
            f"Draft attempts: 1 (good run)\n"
            f"Step sequence: {step_seq}\n"
            f"Draft excerpt (first 800 chars):\n"
            f"{(self._executor._current_draft or '')[:800]}"
        )

        try:
            skill = load_skill(skill_path)
            runner = SkillRunner(provider=provider)
            patterns = runner.run(skill, {
                "run_context": run_context,
                "existing_patterns": existing_patterns or "None yet.",
                "max_tokens": 1024,
            })

            if runner.last_usage:
                self._executor._secondary_tokens_used = getattr(self._executor, "_secondary_tokens_used", {"inputTokens": 0, "outputTokens": 0})
                self._executor._secondary_tokens_used["inputTokens"] += runner.last_usage.input_tokens
                self._executor._secondary_tokens_used["outputTokens"] += runner.last_usage.output_tokens
                logger.info(f"[patterns] tokens: {runner.last_usage.input_tokens:,} in / {runner.last_usage.output_tokens:,} out")
            if isinstance(patterns, dict) and not patterns.get("error"):
                self._memory.write_agent_patterns(patterns)
        except Exception as err:
            logger.warn(f"[patterns] Pattern extraction failed: {err}")

    def get_merged_delta(self) -> ExtractedApiDelta | None:
        return self._merged_delta


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _delta_to_dict(delta: ExtractedApiDelta) -> dict:
    """Serialize an ExtractedApiDelta to a JSON-friendly dict."""

    def endpoint_dict(ep: Any) -> dict:
        d: dict[str, Any] = {"method": ep.method, "path": ep.path}
        if ep.handler:
            d["handler"] = ep.handler
        if ep.request_schema:
            d["requestSchema"] = [
                {"name": s.name, "type": s.type, "required": s.required}
                for s in ep.request_schema
            ]
        if ep.response_schema:
            d["responseSchema"] = [
                {"name": s.name, "type": s.type, "required": s.required}
                for s in ep.response_schema
            ]
        if getattr(ep, "status_codes", None):
            d["statusCodes"] = [
                {"code": s.code, "description": s.description}
                for s in ep.status_codes
            ]
        if ep.auth:
            d["auth"] = {"type": ep.auth.type}
            if ep.auth.scopes:
                d["auth"]["scopes"] = ep.auth.scopes
        if ep.tags:
            d["tags"] = ep.tags
        return d

    return {
        "feature": delta.feature,
        "branch": delta.branch,
        "baseBranch": delta.base_branch,
        "timestamp": delta.timestamp,
        "new": [endpoint_dict(e) for e in delta.new],
        "modified": [
            {
                "before": endpoint_dict(m.before),
                "after": endpoint_dict(m.after),
                "changeType": m.change_type,
            }
            for m in delta.modified
        ],
        "removed": [endpoint_dict(e) for e in delta.removed],
        "contractChanges": [
            {"endpoint": c.endpoint, "changeType": c.change_type, "description": c.description}
            for c in delta.contract_changes
        ],
        "authChanges": [
            {"file": a.file, "type": a.type, "description": a.description}
            for a in delta.auth_changes
        ],
        "versioningChanges": [
            {"type": v.type, "description": v.description}
            for v in delta.versioning_changes
        ],
    }


def _read_existing_docs(output_dir: Path) -> str:
    """Read existing markdown docs for style comparison."""
    if not output_dir.exists():
        return ""

    docs: list[str] = []
    for md_file in sorted(output_dir.glob("*-api-docs.md"))[:3]:
        try:
            content = md_file.read_text(encoding="utf-8", errors="replace")
            docs.append(f"### {md_file.name}\n{content[:2000]}")
        except Exception:
            continue

    return "\n\n".join(docs) if docs else ""
