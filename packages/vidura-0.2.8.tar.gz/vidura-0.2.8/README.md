# Vidura

Universal Agent Orchestrator — skill-driven AI agents for software development workflows.

Vidura runs any agent by swapping skill `.md` files and an `agent.yaml` manifest. One PyPI package, multiple agents. Each agent is defined by markdown skill files (behavior) and a YAML manifest (tools, memory, workflow config) — no Python changes needed to customize or add agents.

---

## How it works

```
CI trigger ──▶ vidura run --agent doc-gen --config-url $URL --token $TOKEN
                    │
                    ├── loads agent.yaml manifest
                    ├── reads global memory (patterns from previous good runs)
                    ├── loads skills/*.md (system prompt, analyzer, validator)
                    ├── runs multi-turn LLM agent loop with tool-use
                    │       └── logs every step: context build, memory read,
                    │           LLM call, tool execution, memory update
                    └── produces structured JSON output (AgentOutput)
                              │
                              ▼
                    SaaS platform translates to VCS API calls
                    (commits, PR comments, issues, check statuses)
```

Vidura is **VCS-agnostic** — it produces structured JSON output. A separate SaaS platform translates that output into GitHub/GitLab/Bitbucket/Azure DevOps API calls.

---

## Available Agents

| Agent | Output Type | Description |
|-------|-------------|-------------|
| `doc-gen` | `file_commit` | Detects API changes via git diff, generates Markdown + Word documentation |
| `readme-updater` | `file_commit` | Detects config/setup changes and updates README.md to stay in sync |
| `sast` | `report` | Scans code changes for security vulnerabilities, generates a security report |

More agents planned: `code-review`, `pr-description`, `changelog-gen`, `test-gen`.

---

## Installation

```bash
pip install vidura
```

Supports Anthropic (Claude), OpenAI, DeepSeek, Groq, Together, Mistral, OpenRouter, and local LLMs (Ollama, LM Studio, etc.). Verify:

```bash
vidura --version
vidura doctor   # check environment, connectivity, and memory store
```

---

## Quick Start

### SaaS mode (recommended for teams)

The platform admin configures everything. The developer sets **zero env vars** — just two CI secrets.

```bash
# 1. Store two secrets in your CI:
#    VIDURA_TOKEN       ← install token from platform admin
#    VIDURA_CONFIG_URL  ← platform config endpoint

# 2. Add to your CI workflow:
vidura sync --agent doc-gen --config-url $VIDURA_CONFIG_URL --token $VIDURA_TOKEN
vidura run  --agent doc-gen --config-url $VIDURA_CONFIG_URL --token $VIDURA_TOKEN
```

### Local mode

```bash
# 1. Install
pip install vidura

# 2. Set required env vars (doc-gen uses AGENTIC_DOCS_ prefix)
export AGENTIC_DOCS_PROVIDER=anthropic
export ANTHROPIC_API_KEY=sk-ant-...
export AGENTIC_DOCS_MODEL=claude-sonnet-4-6
export AGENTIC_DOCS_MAX_INPUT_TOKENS=100000
export AGENTIC_DOCS_MAX_OUTPUT_TOKENS=8192

# 3. Initialise in your repo
cd /path/to/your/repo
vidura init --agent doc-gen

# 4. Run
vidura run --agent doc-gen --verbose
```

#### Other providers

```bash
# OpenAI
export AGENTIC_DOCS_PROVIDER=openai
export OPENAI_API_KEY=sk-...
export AGENTIC_DOCS_MODEL=gpt-4o

# DeepSeek
export AGENTIC_DOCS_PROVIDER=deepseek
export DEEPSEEK_API_KEY=sk-...
export AGENTIC_DOCS_MODEL=deepseek-chat

# Local LLM (Ollama) — no API key needed
export AGENTIC_DOCS_PROVIDER=local
export AGENTIC_DOCS_MODEL=llama3
```

---

## Agents

### doc-gen

Analyzes git diffs and generates complete API documentation for changed endpoints.

**Supported frameworks (any language):**

| Language | Frameworks |
|---|---|
| Python | FastAPI, Django, Flask, Starlette, Tornado, aiohttp |
| JavaScript/TypeScript | Next.js App Router, Next.js Pages Router, Express, NestJS, Fastify, Hono, tRPC |
| Go | Gin, Echo, Chi, Fiber, Gorilla Mux, net/http |
| Java/Kotlin | Spring MVC, Spring WebFlux, JAX-RS, Micronaut, Ktor |
| Ruby | Rails routes.rb + controllers, Sinatra, Grape |
| PHP | Laravel, Symfony, Slim |
| C# | ASP.NET Core (attributes + Minimal API) |
| Rust | Actix, Axum, Rocket |
| Other | GraphQL (Query/Mutation), gRPC/protobuf, OpenAPI YAML, Elixir Phoenix, Scala Play, Swift Vapor |

**Extraction:** Files are processed in **batches of 3** — each batch gets its own LLM call and results are merged with deduplication. This ensures large commits with many route files don't silently drop endpoints due to a single-blob token cap.

The agent resolves full endpoint paths including all prefixes — router mounts, blueprint prefixes, controller annotations, group scopes. For example:
- NestJS `@Controller('users')` + `@Get(':id')` → `GET /users/:id`
- Next.js `app/api/orders/[id]/route.ts` + `export async function POST` → `POST /api/orders/[id]`
- Django `urlpatterns` prefix + `path('detail/', ...)` → full resolved path
- Spring `@RequestMapping('/api')` class + `@GetMapping('/users')` method → `GET /api/users`

**Validation:** All endpoints from `extract_api_changes` must appear in the draft. Missing any `new`, `modified`, or `removed` endpoint is a validation **error** (not a warning) — the agent is forced to fix before writing.

**Turn limit:** 10 turns (raised from 5 to handle large commits with multiple fix cycles).

### sast

Scans changed files for security vulnerabilities across any language. Generates a structured security report with severity-graded findings and actionable remediations.

**Detected vulnerability categories:** SQL/command/template injection, hardcoded secrets, broken auth, access control issues, weak cryptography, XSS, SSRF, path traversal, XXE, insecure deserialization, security misconfiguration, sensitive data exposure, race conditions.

**Validation:** All findings from `scan_for_vulnerabilities` must appear in the report. Missing any finding ID is a validation error.

**Turn limit:** 10 turns.

**Memory:** Accumulates false-positive signals and true-positive patterns from good runs (zero critical + zero high findings).

### readme-updater

Detects changes in config, dependency, and setup files and updates README.md to stay in sync.

**Trigger files:** `package.json`, `pyproject.toml`, `Cargo.toml`, `go.mod`, `Dockerfile`, `docker-compose*.yml`, `.env.example`, `.github/workflows/*.yml`, `Makefile`, setup scripts, and more.

**Turn limit:** 8 turns.

---

## Memory System

Vidura accumulates knowledge across runs in a global Git-backed memory store. Memory is **only updated when a run is rated good** — quality-gated writes prevent noise from failed or low-quality runs.

### Quality gate

| Rating | Condition | Memory written |
|---|---|---|
| `good` | doc-gen: validation passed on first draft attempt | Feedback + novel patterns |
| `good` | sast: zero critical AND zero high findings | Feedback + novel patterns |
| `good` | readme-updater: first draft attempt, no revisions | Feedback + novel patterns |
| `improved` | Any run that succeeded but needed revision | Nothing written |

### Pattern deduplication

When a good run completes, a pattern extractor LLM call identifies reusable knowledge from the run. Before writing, each candidate pattern is checked against existing memory using 70% token-overlap similarity — only genuinely novel patterns are appended. No timestamp-keyed entries — just clean pattern bullets.

### Memory file format

All memory files follow a structured template:

```markdown
# <TITLE>

## Metadata
- id: <uuid>
- type: <semantic | episodic | procedural | pattern>
- created_at: <ISO timestamp>
- updated_at: <ISO timestamp>
- tags: [tag1, tag2]
- priority: <low | medium | high>

---

## Summary
<2–5 line summary>

---

## Details
<main content>

---

## Patterns (IMPORTANT)
- when: <condition>
- then: <action>
- confidence: <0–1>

---

## Examples
<real examples>

---

## Relations
- relates_to: [file1, file2]
- derived_from: [source]
```

### Memory categories

| Category | Writable by | Contents |
|---|---|---|
| `style` | LLM (agent) | Writing/formatting preferences discovered during a run |
| `feedback` | Agent handler (post-write) | Run quality ratings, endpoint counts, step sequences |
| `conventions` | LLM (agent) | Cross-PR team conventions that can't be derived from code |
| `findings-patterns` | SAST agent | Recurring vulnerability patterns, false-positive signals |

**System categories** (`api`, `auth`, `versioning`, `general`) are **blocked from LLM writes** — only deterministic L2 extraction may write them.

### store_memory tool

The LLM can call `store_memory` with rich structured fields:

```json
{
  "category": "conventions",
  "title": "Rate limit documentation standard",
  "content": "Always document rate limits even when not visible in the diff.",
  "type": "procedural",
  "tags": ["rate-limiting", "conventions"],
  "priority": "high",
  "patterns": [
    { "when": "endpoint diff shows throttle/rate limit", "then": "document the limit values", "confidence": 0.9 }
  ],
  "examples": "GET /api/v1/users — 100 req/min per API key",
  "relates_to": ["conventions.md"]
}
```

### Memory search

Search uses term-frequency scoring with **recency weighting** — sections appearing later in append-only memory files score higher (30% recency boost), so recent patterns surface over old ones with more keyword matches.

### Global memory (pipeline)

When using `run-pipeline`, all agents in the pipeline share a single memory store instance — doc-gen findings are visible to sast in the same pipeline run.

---

## Logging

Every step is logged to stdout/stderr with distinct level markers:

```
[STEP]  Initializing memory
[INFO]  Global memory store connected
[STEP]  Loading global memory patterns for system prompt injection
[INFO]  Loaded 3 global pattern section(s) (1842 chars)
[STEP]  Building system prompt (primary skill + style + global memory patterns)
[STEP]  Reading memory context for branch 'feature/user-auth'
[STEP]  Auto-context search for branch 'feature/user-auth'
[INFO]  Memory context injected (834 chars)
[STEP]  Starting agent loop (max 10 turns | budget: 100,000 in / 8,192 out tokens)
[STEP]  ── Turn 1/10 ──────────────────────────
[STEP]  Calling LLM (anthropic/claude-sonnet-4-6) — 1 messages, ~1240 context chars, max_out=8192 tokens
[INFO]  LLM response — stop: tool_use | this turn: 1823 in / 47 out | cumulative: 1,823/100,000 in, 47/8,192 out (2% budget used)
[STEP]  LLM decided to call: get_changed_files, extract_api_changes
[STEP]  Executing tool: get_changed_files
[STEP]  Executing tool: extract_api_changes
[STEP]  Writing memory: [feedback] 'feature-auth' → feedback.md
[OK]    Memory stored: [feedback] feature-auth (1204 chars written to feedback.md)
[OK]    Global agent patterns updated — only novel patterns written
[OK]    Agent completed in 5 turn(s) | tokens: 18,432 in + 3,891 out | status: GENERATED
```

**CI environments** (`CI`, `GITHUB_ACTIONS`, `GITLAB_CI`, `CIRCLECI`, `NO_COLOR`) automatically disable ANSI color codes — plain text output for clean CI logs.

| Level | Color | When used |
|---|---|---|
| `[STEP]` | Cyan | Pipeline stage markers — context build, LLM call, tool execution, memory write |
| `[INFO]` | Blue | Counts, sizes, results |
| `[WARN]` | Yellow | Non-fatal issues — truncated diffs, pruned memory, skipped memory writes |
| `[OK]` | Green | Successful completions |
| `[ERROR]` | Red | Failures |
| `[DEBUG]` | Grey | Verbose mode only — system prompt size, tool result previews |

---

## Token Control

### Budget thresholds

| Threshold | What happens |
|-----------|--------------|
| **85%** | Agent instructed to fix only critical issues — skip style, skip suggestions |
| **95%** | All exploration locked. Must call terminal tool immediately |
| **100%** | Hard abort — `TOKEN_BUDGET_EXCEEDED` |

### Adaptive tool sizing

| Tool | Budget < 70% | Budget 70–85% | Budget > 85% |
|------|-------------|---------------|--------------|
| `read_file` max lines | 300 | 150 | 60 |
| `search_codebase` max results | 50 | 20 | 10 |

### Large commit handling

When a commit touches more files than the diff budget allows, excluded files are surfaced as a warning both in the log and injected into the extractor context:

```
[WARN]  3 file(s) excluded from diff (budget exhausted) — extraction may miss endpoints in: ['src/routes/admin.py', ...]
```

The extractor LLM is informed of the truncation so it can note incomplete coverage in its output rather than silently missing endpoints.

### Recommended token budgets

| Use case | `MAX_INPUT_TOKENS` | `MAX_OUTPUT_TOKENS` |
|----------|--------------------|---------------------|
| Small PR (< 5 files) | `40,000` | `4,000` |
| Medium PR (5–20 files) | `80,000` | `6,000` |
| Large PR (20+ files) | `150,000` | `8,192` |
| Maximum quality | `200,000` | `8,192` |

Use a cheaper model for secondary skills to save tokens:

```bash
AGENTIC_DOCS_MODEL=claude-opus-4-7          # main agent
AGENTIC_DOCS_CRITIC_MODEL=claude-haiku-4-5  # critic/evaluator — faster, cheaper
```

---

## Loop Control

### Turn limits by agent

| Agent | Max turns | Rationale |
|---|---|---|
| `doc-gen` | 10 | Large commits need fix cycles after validation errors |
| `sast` | 10 | Many findings require same fix-cycle headroom |
| `readme-updater` | 8 | Simpler linear flow — smaller buffer sufficient |

### Context compaction

Full message context is preserved for the last **6 turns** (raised from 3). Older turns are compacted — tool result content is summarized, large draft content is replaced with `[see store_draft]`. This prevents the context window from filling before the agent can finish on large runs.

### Loop prevention

| Mechanism | Limit | On trigger |
|-----------|-------|------------|
| Plan revisions | 3 | Tool returns error, agent must proceed |
| Repetitive identical calls | 3 consecutive | `[SYSTEM]` warning injected |
| Stall (no draft) | 2 turns | `[SYSTEM]` push to write injected |
| Critical budget | 95% | Locks all non-terminal tools |

---

## Validation

### doc-gen

All three endpoint lists are validated as **errors** (not warnings) — the run cannot write until all are covered:

| Rule | Severity | Check |
|---|---|---|
| `required_header` | error | Doc must start with `# Feature: <name>` |
| `no_speculation` | error | No hedging language ("may", "might consider", etc.) |
| `no_invented_endpoints` | error | No endpoints in doc that weren't in extraction output |
| `coverage_new` | **error** | Every new endpoint must appear in doc |
| `coverage_modified` | **error** | Every modified endpoint must appear in doc |
| `coverage_removed` | warning | Removed endpoints should be mentioned |
| `valid_http_methods` | error | Only valid HTTP verbs in doc |

Endpoint matching handles all doc formats: `### GET /path`, `` `GET /path` ``, `**GET /path**`, bare `GET /path`.

### sast

| Rule | Severity | Check |
|---|---|---|
| `required_header` | error | Report must start with `# Security Report` |
| `required_summary` | error | Must include `## Executive Summary` |
| `required_actions` | error | Must include `## Recommended Actions` |
| `no_speculation` | error | No hedging language |
| Finding coverage | error | Every finding ID from scan must appear in report |

---

## CI Integration

### GitHub Actions — doc-gen

```yaml
name: Vidura doc-gen

on:
  pull_request:
    branches: [main]

jobs:
  doc-gen:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Install Vidura
        run: pip install vidura

      - name: Sync skills
        run: vidura sync --agent doc-gen --config-url ${{ secrets.VIDURA_CONFIG_URL }} --token ${{ secrets.VIDURA_TOKEN }}

      - name: Run doc-gen
        run: vidura run --agent doc-gen --config-url ${{ secrets.VIDURA_CONFIG_URL }} --token ${{ secrets.VIDURA_TOKEN }}

      - name: Push updated docs
        run: git push origin HEAD
```

### GitHub Actions — pipeline (doc-gen + sast)

```yaml
- name: Run pipeline
  run: |
    vidura run-pipeline --agents doc-gen,sast \
      --config-url ${{ secrets.VIDURA_CONFIG_URL }} \
      --token ${{ secrets.VIDURA_TOKEN }}
```

Pipeline agents share a single global memory store — findings from doc-gen are visible to sast in the same run.

### Callbacks

`post_callback` fires on **all** run statuses (success, failure, no-change) — CI integrations receive a webhook signal regardless of outcome. For pipelines, an aggregated result is posted after all agents complete.

---

## CLI Reference

### `vidura run --agent <name>`

```bash
vidura run --agent doc-gen --verbose
vidura run --agent doc-gen --dry-run
vidura run --agent doc-gen --base-branch development --no-commit
vidura run --agent sast --config-url $URL --token $TOKEN
vidura run --agent readme-updater --output-file output.json
```

| Flag | Description |
|------|-------------|
| `--agent` | **Required.** Agent name |
| `--config-url` | SaaS platform config endpoint |
| `--token` | SaaS install token |
| `--base-branch` | Override base branch for diff |
| `--no-commit` | Skip auto-commit |
| `--dry-run` | Show changed files, no LLM calls |
| `--output-file` | Write `AgentOutput` JSON to path |
| `--callback-url` | POST result JSON to this URL (fires on success and failure) |
| `-v, --verbose` | Enable debug logging |

### `vidura run-pipeline --agents <list>`

```bash
vidura run-pipeline --agents doc-gen,sast,readme-updater \
  --config-url $URL --token $TOKEN

vidura run-pipeline --agents doc-gen,sast --continue-on-failure
```

Agents share global memory within the pipeline run. Aggregated result posted to callback URL on completion.

### `vidura doctor`

```bash
vidura doctor
vidura doctor --agent doc-gen
vidura doctor --config-url $URL --token $TOKEN
```

Checks:
- Python >= 3.10
- Required packages installed
- API key / install token set
- Agent manifest and skills found
- **Global memory store reachable** (live connectivity check via `VIDURA_GLOBAL_MEMORY_REPO`)
- SaaS platform reachable (if `--config-url` provided)

### `vidura init --agent <name>`

Creates `skills/` (editable skill copies), `.agent/skills/` (memory files), and output directory.

### `vidura sync --agent <name>`

Pulls latest skill files from platform. Locally-modified files are skipped with a warning — never overwritten.

### Exit codes

| Code | Meaning |
|------|---------|
| `0` | Success or no changes |
| `1` | Failure — validation error, budget exceeded, max turns exceeded, API error |

---

## Configuration

### doc-gen (prefix: `AGENTIC_DOCS`)

#### Required

| Variable | Description |
|----------|-------------|
| `AGENTIC_DOCS_PROVIDER` | LLM provider: `anthropic`, `openai`, `deepseek`, `groq`, `together`, `mistral`, `openrouter`, `local`, or any custom name |
| `{PROVIDER}_API_KEY` | API key for the chosen provider |
| `AGENTIC_DOCS_MODEL` | Model ID |
| `AGENTIC_DOCS_MAX_INPUT_TOKENS` | Input token budget |
| `AGENTIC_DOCS_MAX_OUTPUT_TOKENS` | Output token budget |

#### Optional

| Variable | Default | Description |
|----------|---------|-------------|
| `AGENTIC_DOCS_BASE_BRANCH` | `main` | Branch to diff against |
| `AGENTIC_DOCS_OUTPUT_DIR` | `docs` | Output directory |
| `AGENTIC_DOCS_MAX_TURNS` | `10` | Max agent loop turns |
| `AGENTIC_DOCS_DOC_STYLE` | `detailed` | `concise`, `detailed`, or `enterprise` |
| `AGENTIC_DOCS_NO_AUTO_COMMIT` | `false` | Skip auto-commit |
| `AGENTIC_DOCS_LANGUAGES` | (empty) | Comma-separated language hints |
| `AGENTIC_DOCS_CRITIC_PROVIDER` | (inherit) | Provider for critic pass |
| `AGENTIC_DOCS_CRITIC_MODEL` | (inherit) | Model for critic pass |

### sast (prefix: `VIDURA_SAST`)

Same structure. Additional:

| Variable | Default | Description |
|----------|---------|-------------|
| `VIDURA_SAST_MIN_SEVERITY` | `low` | Minimum severity to report: `critical`, `high`, `medium`, `low`, `info` |

### readme-updater (prefix: `VIDURA_README`)

Same structure as doc-gen. Replace `AGENTIC_DOCS_` with `VIDURA_README_`.

### Global memory

| Variable | Description |
|----------|-------------|
| `VIDURA_GLOBAL_MEMORY_REPO` | Git repo URL for shared cross-project memory |
| `VIDURA_GLOBAL_MEMORY_TOKEN` | Git access token (PAT or GitHub App token) |
| `VIDURA_GLOBAL_MEMORY_BRANCH` | Branch (default: `main`) |

### Supported providers

| Provider | Value | API key env var |
|----------|-------|-----------------|
| Anthropic | `anthropic` | `ANTHROPIC_API_KEY` |
| OpenAI | `openai` | `OPENAI_API_KEY` |
| DeepSeek | `deepseek` | `DEEPSEEK_API_KEY` |
| Groq | `groq` | `GROQ_API_KEY` |
| Together | `together` | `TOGETHER_API_KEY` |
| Mistral | `mistral` | `MISTRAL_API_KEY` |
| OpenRouter | `openrouter` | `OPENROUTER_API_KEY` |
| Local (Ollama) | `local` | None required |
| Custom | any name | `{NAME}_API_KEY` |

---

## Architecture

### Core runtime

| Module | Role |
|--------|------|
| `core/workflow.py` | Manifest-driven workflow engine — loads skills, builds context, runs agent loop, enforces token/loop limits |
| `core/tools/executor.py` | Stateful tool dispatcher — core tools + agent-specific handlers, token-aware sizing, quality tracking |
| `core/memory.py` | Global memory manager — quality-gated writes, pattern deduplication, recency-weighted search |
| `core/validator_engine.py` | Declarative rule engine — endpoint coverage checks, no LLM calls |
| `core/skill_loader.py` | Parses `.md` frontmatter into `SkillDefinition` |
| `core/skill_runner.py` | Single-shot LLM skill executor |
| `core/git.py` | Git diff analysis (`merge-base` + `diff --name-status`) |
| `core/logger.py` | Colored logging with CI plain-text mode, STEP/INFO/WARN/OK/ERROR/DEBUG levels |
| `core/llm/` | Provider abstraction: Anthropic + any OpenAI-compatible endpoint |
| `core/storage/` | Memory backends: filesystem + Git repo |

### Agent structure

```
agents/<name>/
├── agent.yaml              # Manifest: skills, tools, memory, workflow, config
├── tools.py                # Agent-specific tool handler (extraction, validation, writing)
└── skills/
    ├── primary-agent.md    # Main agent system prompt + turn-by-turn instructions
    ├── <analyzer>.md       # Single-shot analysis skill (LLM call, JSON output)
    ├── validator.md        # Declarative validation rules (no LLM)
    └── pattern-extractor.md  # Extracts reusable patterns from good runs
```

### Concurrent write safety

The git-backed memory store uses retry-on-conflict for push operations. On a rejected push (concurrent write from another CI run), it:
1. Resets the commit
2. Stashes local changes
3. Pulls + rebases from remote
4. Pops stash and retries

Up to 3 attempts before giving up with a warning. This handles parallel CI runs on busy repos.

### Pipeline memory namespacing

In `run-pipeline`, each agent uses its own subdir (`doc-gen/`, `sast/`, `readme-updater/`) within the shared memory repo. Agents don't stomp each other's memory files. The same git repo means cross-agent reads are possible via `read_memory`.

### Memory flow

```
Run starts
    │
    ├── get_global_patterns()  → injected into system prompt
    ├── get_auto_context()     → injected into initial user message
    │
Agent loop (turns 1–N)
    │
    ├── LLM calls store_memory → written immediately (quality gate in memory.py)
    │
Run ends (terminal tool called)
    │
    ├── rating computed (good / improved)
    ├── if good → record_feedback() written to global store
    └── if good → pattern-extractor LLM call
                      → existing patterns loaded (dedup context)
                      → novel patterns only → write_agent_patterns()
                          → 70% token overlap check
                          → only truly new patterns appended
```

### Layer dependency order

```
L2 (Diff + Extraction) → L1 (CLI) → L3 (Memory) → L4 (Token control)
  → L5 (Workflow + Skills) → L6 (Validation) → L7 (Document generation) → L8 (CI)
```

---

## Project Structure

```
vidura/
├── bin/
│   └── cli.py                           # CLI — run, init, sync, doctor, run-pipeline, feedback
├── core/
│   ├── workflow.py                      # Agent loop, token/loop controls, context compaction
│   ├── tools/
│   │   ├── executor.py                  # Tool dispatcher (quality tracking, token-aware sizing)
│   │   ├── core_tools.py               # Generic tool definitions (store_memory with rich schema)
│   │   └── handler.py                  # AgentToolHandler protocol
│   ├── config.py                        # Config from env or SaaS API
│   ├── memory.py                        # Quality-gated memory, deduplication, recency search
│   ├── validator_engine.py             # Declarative validation (coverage errors, regex checks)
│   ├── logger.py                        # Leveled logging, CI plain-text mode
│   ├── errors.py                        # Typed error codes
│   ├── retry.py                         # Exponential backoff
│   ├── progress.py                      # Progress reporting to platform
│   ├── git.py                           # Git diff analysis
│   ├── llm/
│   │   ├── base.py                      # LLMProvider ABC
│   │   ├── anthropic_provider.py        # Anthropic Claude
│   │   ├── openai_provider.py           # OpenAI-compatible (all other providers)
│   │   └── factory.py                   # Provider factory
│   ├── extractor/
│   │   ├── types.py                     # ExtractedApiDelta, ApiEndpoint, ChangedFile types
│   │   └── __init__.py
│   └── storage/
│       ├── memory_store.py              # MemoryStore ABC
│       ├── local_store.py               # Filesystem backend
│       └── git_store.py                # Git repo backend
├── agents/
│   ├── doc_gen/
│   │   ├── agent.yaml
│   │   ├── tools.py                     # extract_api_changes, validate_documentation, write_documentation
│   │   ├── document.py                  # Markdown + DOCX generation
│   │   └── skills/
│   │       ├── primary-agent.md         # Main agent — enumeration, 10-turn flow
│   │       ├── api-extractor.md         # Multi-language endpoint extraction (20+ frameworks)
│   │       ├── validator.md             # Coverage errors for new/modified/removed endpoints
│   │       ├── pattern-extractor.md     # Learns from good runs
│   │       └── style-{concise,detailed,enterprise}.md
│   ├── sast/
│   │   ├── agent.yaml
│   │   ├── tools.py                     # scan_for_vulnerabilities, validate_report, write_report
│   │   └── skills/
│   │       ├── primary-agent.md         # Security report agent — 10-turn flow
│   │       ├── sast-analyzer.md         # Vulnerability scanner (any language)
│   │       ├── validator.md             # Required sections + finding coverage
│   │       └── pattern-extractor.md     # Learns false-positive signals from good runs
│   └── readme_updater/
│       ├── agent.yaml
│       ├── tools.py                     # write_readme + pattern extraction
│       └── skills/
│           ├── primary-agent.md         # README update agent — 8-turn flow
│           └── pattern-extractor.md     # Learns project doc conventions
└── pyproject.toml
```

---

## Development

```bash
pip install -e "."

# Run in development
python -m bin.cli run --agent doc-gen --verbose
python -m bin.cli run --agent sast --verbose
python -m bin.cli run --agent doc-gen --dry-run

# Build distribution
pip install build && python -m build
```

---

## Requirements

- Python >= 3.10
- Git (must be run inside a git repository)
- An LLM API key for cloud providers, or a local LLM server for local mode. Alternatively, a Vidura install token + config URL for SaaS mode.

---

## License

MIT
