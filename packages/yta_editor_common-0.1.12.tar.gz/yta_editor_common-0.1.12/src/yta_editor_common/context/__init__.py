"""
The module to include classes related to the
rendering context.
"""
from yta_editor_common.context.gpu_resources import GPUResources
from yta_editor_common.context.cpu_resources import CPUResources
from yta_editor_common.context.config import RenderConfig
from yta_programming.decorators.requires_dependency import requires_dependency
from yta_validation.parameter import ParameterValidator
from typing import Union


class RenderContext:
    """
    A context that will be used along a rendering
    process, to be able to access to different
    resources, providers, etc.

    You have access to these diferent attributes:
    - `.config`: General configuration for the
    rendering process.
    - `.gpu`: Configuration for the GPU processing.
    - `.cpu`: Configuration for the CPU processing.
    """

    @property
    @requires_dependency('yta_editor_pools', 'yta_editor_common', 'yta_editor_pools')
    def gpu(
        self
    ) -> 'GPUResources':
        """
        The resources related to GPU.
        """
        if not hasattr(self, '_gpu'):
            self._gpu: GPUResources = GPUResources(self._opengl_context)

        return self._gpu
    
    @property
    def cpu(
        self
    ) -> 'CPUResources':
        """
        The resources related to CPU.
        """
        if not hasattr(self, '_cpu'):
            self._cpu: CPUResources = CPUResources()

        return self._cpu

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None],
        size: tuple[int, int],
        fps: float,
        audio_fps: int,
        do_use_gpu: bool
    ):
        ParameterValidator.validate_instance_of('opengl_context', opengl_context, 'Context')
        # TODO: Validate others

        self._opengl_context: 'moderngl.Context' = opengl_context
        """
        *For internal use only*
        
        The `moderngl.Context` instance.
        """
        self.config: 'RenderConfig' = RenderConfig(
            size = size,
            fps = fps,
            audio_fps = audio_fps,
            do_use_gpu = do_use_gpu
        )
        """
        The configuration of the rendering process.
        """

    def use_cpu(
        self
    ) -> 'RenderContext':
        """
        Activate the desire to use CPU (and not GPU) by
        setting the `do_use_gpu` parameter to `False`.
        """
        self.config.use_cpu()

        return self

    def use_gpu(
        self
    ) -> 'RenderContext':
        """
        Activate the desire to use GPU (and no CPU) by
        setting the `do_use_gpu` parameter to `True`.
        """
        self.config.use_gpu()

        return self