"""
I created this module just to have the CPU and GPU
module together with the same structure, to be able
to easily separate into those two context when
handling with the specific nodes.
"""


class CPUResources:
    """
    The resources of the context related to CPU.
    
    By now this module is empty.
    """

    def __init__(
        self
    ):
        pass