import sys
import time

ASCII_ART = r"""
  __  __       _     _ _         _             _                     _ _           
 |  \/  |     | |   (_) |       | |           | |                   | | |          
 | \  / | ___ | |__  _| |_      | | __ _ _ __ | |__   __ _ _ __   __| | |__  _   _ 
 | |\/| |/ _ \| '_ \| | __| _   | |/ _` | '_ \| '_ \ / _` | '_ \ / _` | '_ \| | | |
 | |  | | (_) | | | | | |_|  |__| | (_| | | | | |_) | (_| | | | | (_| | | | | |_| |
 |_|  |_|\___/|_| |_|_|\__| \____/ \__,_|_| |_|_.__/ \__,_|_| |_|\__,_|_| |_|\__,_|
"""

def animated_typing(text, delay=0.005, color_code="\033[94m"):
    """Prints text with an animated typing effect using sys.stdout and time."""
    sys.stdout.write(color_code)
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        if char.strip():
            time.sleep(delay)
    sys.stdout.write("\033[0m\n")

def print_banner():
    """Prints the animated ASCII banner."""
    animated_typing(ASCII_ART, delay=0.001)
