import os
import site
import sys


def get_scripts_path():
    return os.path.join(site.USER_BASE, "Scripts")


def is_path_set():
    scripts_path = get_scripts_path().lower()
    return scripts_path in os.environ.get("PATH", "").lower()


def show_warning():
    scripts_path = get_scripts_path()

    print("\n[WARNING] 'mohitjan' command is not available globally.\n")
    print("Add this path to your PATH:\n")
    print(scripts_path)
    print()


def add_to_path():
    scripts_path = get_scripts_path()

    print("\nAttempting to update PATH...\n")

    # safer version
    current_path = os.environ.get("PATH", "")
    new_path = f"{current_path};{scripts_path}"

    os.system(f'setx PATH "{new_path}"')

    print("\nPATH updated successfully.")
    print("Restart terminal and run: mohitjan\n")


def check_and_fix_path():
    if not is_path_set():
        show_warning()

        choice = input("Fix automatically? (y/n): ").strip().lower()

        if choice == "y":
            add_to_path()
        else:
            print("\nSkipped. You can fix it manually later.\n")