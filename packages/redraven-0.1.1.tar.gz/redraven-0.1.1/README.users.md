# redraven SDK — user guide

This guide is for **users of the Redraven platform** ([app.redraven.fireraven.ai](https://app.redraven.fireraven.ai)) who want to drive a test from their own Python code.

> The user-side LLM call always happens **in your process**. Your model API key is **never** sent to Redraven.

## 1. Install

```bash
uv add redraven
```

Or with pip:

```bash
pip install redraven
```

The SDK requires Python 3.10+ and pulls in `httpx`, `pydantic`, `anyio`.

## 2. Configure

The SDK never hardcodes a backend URL. Set both via env vars (recommended) or pass them explicitly to `Client(...)`:

```bash
export REDRAVEN_API_KEY="rr_..."
export REDRAVEN_BASE_URL="https://app.redraven.fireraven.ai"
```

Pass the **host only** — the SDK adds the `/api/v1` prefix automatically. (Pasting `…/api` or `…/api/v1` is also tolerated.) Get the API key from your Redraven organization settings.

## 3. Prepare a test

Create a test in the Redraven app or via the SDK's `client.generate_test(...)`. You'll need its `test_id` — a UUID string. The dataset is stored on Redraven as one JSON object per test case in your test bucket; the SDK pulls cases from there one by one.

## 4. Run the full flow

```python
import asyncio
import redraven

# Example: OpenAI-compatible client (sync — runs in a worker thread automatically)
from openai import OpenAI
oai = OpenAI()

def my_llm(prompt: str) -> str:
    resp = oai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
    )
    return resp.choices[0].message.content or ""

async def main():
    async with redraven.Client() as client:
        result = await client.run_test(
            test_id="00000000-0000-0000-0000-000000000000",
            llm=my_llm,
            concurrency=4,         # in-flight LLM calls
            retries=2,             # per-case
            allow_partial=True,    # set False to raise on any failed case
        )
        print(f"state={result.state} received={result.received} failed={result.failed}")
        print(f"failed cases: {result.failed_case_ids}")

asyncio.run(main())
```

`my_llm` can also be `async def`; it will be awaited directly. Sync callables are dispatched to a worker thread so blocking SDKs (e.g. `openai`) do not block the event loop.

## 5. Generate tests (with or without waiting)

```python
test_id = await client.generate_test(
    generate_kwargs={
        "project_id": "11111111-1111-1111-1111-111111111111",
        "test_name": "SDK generated test",
        "business_context": "Healthcare SaaS for clinicians.",
        "use_case": "Symptom triage assistant.",
        "certifications": ["HIPAA"],
        "max_policies": 5,
        "max_prompts_per_policy": 2,
    },
)
```

`generate_test(...)` triggers generation and returns quickly by default. If you want to block until dataset materialization is ready, set:

```python
test_id = await client.generate_test(
    generate_kwargs={...},
    wait_for_dataset=True,
)
```

You can also wait explicitly later:

```python
await client.wait_for_dataset_ready(test_id)
```

## 6. Generate + run + evaluate in a single call

For the simplest end-user flow, use one call:

```python
result = await client.generate_and_run_test(
    generate_kwargs={
        "project_id": "11111111-1111-1111-1111-111111111111",
        "test_name": "SDK generated test",
        "business_context": "Healthcare SaaS for clinicians.",
        "use_case": "Symptom triage assistant.",
        "certifications": ["HIPAA"],
        "max_policies": 5,
        "max_prompts_per_policy": 2,
    },
    llm=my_llm,
    concurrency=8,
)
```

If you prefer separate steps, run when ready:

```python
result = await client.run_test(test_id=test_id, llm=my_llm, concurrency=8)
```

## 7. Multi-org

Each `Client` instance is fully self-contained — no module-level globals. Drive multiple Redraven organizations from the same process by holding multiple clients:

```python
async with redraven.Client(api_key=org1_key, base_url=BASE) as c1, \
           redraven.Client(api_key=org2_key, base_url=BASE) as c2:
    r1 = await c1.run_test(test_id_1, my_llm)
    r2 = await c2.run_test(test_id_2, my_llm)
```

The env vars (`REDRAVEN_API_KEY`, `REDRAVEN_BASE_URL`) are only fallbacks for the single-org convenience case.

## 8. What the result contains

`run_test` returns an `EvalSummary`:

- `state` — terminal manifest state (`completed` / `failed`).
- `expected_cases`, `received`, `failed`, `failed_case_ids`.
- `summary` — the eval `summary.json` aggregated by Redraven (per-policy stats, etc.).
- `manifest` — the eval `manifest.json` for traceability.

## 9. Errors

- `RedravenConfigError` — missing API key or base URL.
- `RedravenHTTPError` — non-2xx from the backend; carries `status_code`, `url`, `body`.
- `RedravenTimeoutError` — eval did not reach a terminal state within `poll_timeout_s`.
- `RedravenPartialRunError` — only raised when `allow_partial=False` and at least one case failed.

All inherit from `RedravenError`.

## 10. Resumability

If `run_test` is interrupted, just call it again with the same `test_id`. The backend stores per-case responses idempotently under `client_llm_output/v1/tests/{test_id}/cases/{case_id}.json`, so previously-submitted cases are simply re-confirmed.
