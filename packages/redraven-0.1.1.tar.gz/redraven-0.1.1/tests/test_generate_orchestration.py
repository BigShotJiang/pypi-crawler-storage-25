from __future__ import annotations

import httpx
import pytest

from redraven.client import Client


@pytest.mark.asyncio
async def test_generate_test_non_blocking_default() -> None:
    seen: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(f"{request.method} {request.url.path}")
        if request.method == "POST" and request.url.path == "/api/v1/tests/":
            return httpx.Response(200, json={"id": "test-1"})
        if request.method == "POST" and request.url.path == "/api/v1/tests/test-1/generate":
            return httpx.Response(200, json={"ok": True})
        return httpx.Response(500, json={"detail": "unexpected request"})

    async with Client(
        api_key="rr_test",
        base_url="https://example.test",
        transport=httpx.MockTransport(handler),
    ) as client:
        test_id = await client.generate_test(
            generate_kwargs={
                "project_id": "proj-1",
                "test_name": "test",
                "business_context": "ctx",
                "use_case": "use-case",
            }
        )

    assert test_id == "test-1"
    assert seen == [
        "POST /api/v1/tests/",
        "POST /api/v1/tests/test-1/generate",
    ]


@pytest.mark.asyncio
async def test_generate_test_wait_for_dataset_true() -> None:
    dataset_polls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal dataset_polls
        if request.method == "POST" and request.url.path == "/api/v1/tests/":
            return httpx.Response(200, json={"id": "test-2"})
        if request.method == "POST" and request.url.path == "/api/v1/tests/test-2/generate":
            return httpx.Response(200, json={"ok": True})
        if request.method == "GET" and request.url.path == "/api/v1/tests/test-2/results/summary":
            if request.url.params.get("kind") == "dataset":
                dataset_polls += 1
                if dataset_polls == 1:
                    return httpx.Response(404, json={"detail": "not ready"})
                return httpx.Response(
                    200,
                    json={
                        "kind": "dataset",
                        "manifest": {"state": "completed", "case_ids": []},
                        "summary": None,
                    },
                )
        return httpx.Response(500, json={"detail": "unexpected request"})

    async with Client(
        api_key="rr_test",
        base_url="https://example.test",
        transport=httpx.MockTransport(handler),
    ) as client:
        test_id = await client.generate_test(
            generate_kwargs={
                "project_id": "proj-2",
                "test_name": "test",
                "business_context": "ctx",
                "use_case": "use-case",
            },
            wait_for_dataset=True,
            poll_interval_s=0.001,
            poll_timeout_s=1.0,
        )

    assert test_id == "test-2"
    assert dataset_polls >= 2


@pytest.mark.asyncio
async def test_generate_and_run_test_waits_then_runs() -> None:
    events: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        key = f"{request.method} {request.url.path}"
        events.append(key)

        if request.method == "POST" and request.url.path == "/api/v1/tests/":
            return httpx.Response(200, json={"id": "test-3"})
        if request.method == "POST" and request.url.path == "/api/v1/tests/test-3/generate":
            return httpx.Response(200, json={"ok": True})
        if request.method == "GET" and request.url.path == "/api/v1/tests/test-3/results/summary":
            kind = request.url.params.get("kind")
            if kind == "dataset":
                return httpx.Response(
                    200,
                    json={
                        "kind": "dataset",
                        "manifest": {"state": "completed", "case_ids": ["c1"]},
                        "summary": None,
                    },
                )
            if kind == "eval":
                return httpx.Response(
                    200,
                    json={
                        "kind": "eval",
                        "manifest": {"state": "completed"},
                        "summary": {"failed_case_ids": []},
                    },
                )
        if request.method == "POST" and request.url.path == "/api/v1/tests/test-3/run-against-client":
            return httpx.Response(
                200,
                json={
                    "job_id": "job-1",
                    "run_id": "run-1",
                    "test_id": "test-3",
                    "expected_cases": 1,
                    "case_ids": ["c1"],
                },
            )
        if request.method == "GET" and request.url.path == "/api/v1/tests/test-3/results/cases":
            return httpx.Response(
                200,
                json={
                    "kind": "dataset",
                    "offset": 0,
                    "limit": 200,
                    "total": 1,
                    "cases": [{"id": "c1", "request": "hello"}],
                },
            )
        if request.method == "POST" and request.url.path == "/api/v1/tests/test-3/cases/c1/client-response":
            return httpx.Response(
                200,
                json={
                    "test_id": "test-3",
                    "case_id": "c1",
                    "received": 1,
                    "failed": 0,
                    "expected_cases": 1,
                    "state": "ready_for_eval",
                    "auto_finalized": True,
                },
            )
        return httpx.Response(500, json={"detail": "unexpected request"})

    async with Client(
        api_key="rr_test",
        base_url="https://example.test",
        transport=httpx.MockTransport(handler),
    ) as client:
        result = await client.generate_and_run_test(
            generate_kwargs={
                "project_id": "proj-3",
                "test_name": "test",
                "business_context": "ctx",
                "use_case": "use-case",
            },
            llm=lambda _prompt: "ok",
            poll_interval_s=0.001,
            poll_timeout_s=1.0,
        )

    assert result.test_id == "test-3"
    assert result.state == "completed"

    idx_dataset = events.index("GET /api/v1/tests/test-3/results/summary")
    idx_run_against = events.index("POST /api/v1/tests/test-3/run-against-client")
    assert idx_dataset < idx_run_against
