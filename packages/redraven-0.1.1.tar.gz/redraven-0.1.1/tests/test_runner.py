"""End-to-end runner test using httpx.MockTransport.

Covers the happy path and the partial-failure path. We mock the backend
endpoints the SDK uses, drive `run_test` with a simple user-LLM
callable, and assert observable behavior."""
from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

import redraven

BASE = "https://test.example"
TEST_ID = "00000000-0000-0000-0000-000000000abc"
CASE_IDS = ["case-1", "case-2", "case-3"]


def _build_handler(
    state: dict[str, Any],
    *,
    inject_failed_ids: list[str] | None = None,
    summary_status_sequence: list[int] | None = None,
):
    inject_failed_ids = list(inject_failed_ids or [])
    summary_status_sequence = list(summary_status_sequence or [])

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        method = request.method

        if method == "POST" and path in {"/api/v1/tests", "/api/v1/tests/"}:
            payload = json.loads(request.content.decode("utf-8"))
            state["created_test_payload"] = payload
            return httpx.Response(
                201,
                json={
                    "id": TEST_ID,
                    "project_id": payload["project_id"],
                    "name": payload["name"],
                    "status": payload.get("status", "pending"),
                },
            )

        if method == "POST" and path == f"/api/v1/tests/{TEST_ID}/generate":
            payload = json.loads(request.content.decode("utf-8"))
            state["generate_payload"] = payload
            return httpx.Response(200, json={"status": "started", "file_id": "generated-x"})

        if method == "POST" and path == f"/api/v1/tests/{TEST_ID}/run-against-client":
            return httpx.Response(
                200,
                json={
                    "job_id": "11111111-1111-1111-1111-111111111111",
                    "run_id": "run-x",
                    "test_id": TEST_ID,
                    "expected_cases": len(CASE_IDS),
                    "case_ids": CASE_IDS,
                },
            )

        if method == "GET" and path == f"/api/v1/tests/{TEST_ID}/results/cases":
            offset = int(request.url.params.get("offset", "0"))
            limit = int(request.url.params.get("limit", "100"))
            cases = [
                {"id": cid, "request": f"prompt for {cid}", "policy": "P1"}
                for cid in CASE_IDS
            ][offset : offset + limit]
            return httpx.Response(
                200,
                json={
                    "kind": "dataset",
                    "offset": offset,
                    "limit": limit,
                    "total": len(CASE_IDS),
                    "cases": cases,
                },
            )

        if (
            method == "POST"
            and path.startswith(f"/api/v1/tests/{TEST_ID}/cases/")
            and path.endswith("/client-response")
        ):
            case_id = path.split("/cases/", 1)[1].split("/", 1)[0]
            payload = json.loads(request.content.decode("utf-8"))
            state.setdefault("posts", []).append({"case_id": case_id, "payload": payload})
            received = sum(1 for p in state["posts"] if p["payload"].get("status") == "ok")
            failed = sum(1 for p in state["posts"] if p["payload"].get("status") == "failed")
            auto_finalized = (received + failed) >= len(CASE_IDS)
            if auto_finalized:
                state["eval_ready"] = True
            return httpx.Response(
                200,
                json={
                    "test_id": TEST_ID,
                    "case_id": case_id,
                    "received": received,
                    "failed": failed,
                    "expected_cases": len(CASE_IDS),
                    "state": "ready_for_eval" if auto_finalized else "awaiting_responses",
                    "auto_finalized": auto_finalized,
                },
            )

        if method == "GET" and path == f"/api/v1/tests/{TEST_ID}/results/summary":
            kind = request.url.params.get("kind", "eval")
            poll_idx = state.get("summary_poll_idx", 0)
            state["summary_poll_idx"] = poll_idx + 1
            if poll_idx < len(summary_status_sequence):
                code = summary_status_sequence[poll_idx]
                if code == 404:
                    return httpx.Response(404, json={"detail": "not ready"})
                if code == 500:
                    return httpx.Response(500, json={"detail": "transient error"})
                return httpx.Response(code, json={"detail": "forced error"})
            if not state.get("eval_ready"):
                return httpx.Response(404, json={"detail": "not ready"})
            return httpx.Response(
                200,
                json={
                    "kind": kind,
                    "manifest": {"state": "completed", "case_count": len(CASE_IDS)},
                    "summary": {
                        "test_id": TEST_ID,
                        "aggregated_policies": [],
                        "failed_case_ids": list(inject_failed_ids),
                    },
                },
            )

        return httpx.Response(500, json={"detail": f"unmocked {method} {path}"})

    return handler


@pytest.mark.asyncio
async def test_run_test_happy_path():
    state: dict[str, Any] = {}
    transport = httpx.MockTransport(_build_handler(state))

    def my_llm(prompt: str) -> str:
        return f"answer: {prompt}"

    async with redraven.Client(
        api_key="rr_test",
        base_url=BASE,
        transport=transport,
    ) as client:
        result = await client.run_test(
            test_id=TEST_ID,
            llm=my_llm,
            concurrency=2,
            retries=0,
            poll_interval_s=0.01,
            poll_timeout_s=5.0,
        )

    posts = state["posts"]
    assert {p["case_id"] for p in posts} == set(CASE_IDS)
    assert all(p["payload"]["status"] == "ok" for p in posts)
    assert all(p["payload"]["response"].startswith("answer: ") for p in posts)
    assert result.expected_cases == len(CASE_IDS)
    assert result.failed == 0
    assert result.failed_case_ids == []
    assert result.state == "completed"


@pytest.mark.asyncio
async def test_run_test_partial_failure_raises_when_disallowed():
    state: dict[str, Any] = {}
    transport = httpx.MockTransport(
        _build_handler(state, inject_failed_ids=["case-3"])
    )

    def flaky_llm(prompt: str) -> str:
        if "case-3" in prompt:
            raise RuntimeError("boom")
        return "ok"

    async with redraven.Client(
        api_key="rr_test",
        base_url=BASE,
        transport=transport,
    ) as client:
        with pytest.raises(redraven.RedravenPartialRunError) as ei:
            await client.run_test(
                test_id=TEST_ID,
                llm=flaky_llm,
                concurrency=2,
                retries=0,
                allow_partial=False,
                poll_interval_s=0.01,
                poll_timeout_s=5.0,
            )
    assert "case-3" in ei.value.failed_case_ids
    posts = state["posts"]
    statuses = {p["case_id"]: p["payload"]["status"] for p in posts}
    assert statuses["case-3"] == "failed"
    assert statuses["case-1"] == "ok"


@pytest.mark.asyncio
async def test_run_test_poll_retries_transient_500():
    state: dict[str, Any] = {"eval_ready": True}
    transport = httpx.MockTransport(
        _build_handler(state, summary_status_sequence=[404, 500])
    )

    def my_llm(prompt: str) -> str:
        return f"answer: {prompt}"

    async with redraven.Client(
        api_key="rr_test",
        base_url=BASE,
        transport=transport,
    ) as client:
        result = await client.run_test(
            test_id=TEST_ID,
            llm=my_llm,
            concurrency=2,
            retries=0,
            poll_interval_s=0.01,
            poll_timeout_s=5.0,
        )

    assert result.state == "completed"
    assert result.failed == 0


@pytest.mark.asyncio
async def test_run_test_poll_raises_after_repeated_transient_500():
    state: dict[str, Any] = {"eval_ready": True}
    transport = httpx.MockTransport(
        _build_handler(state, summary_status_sequence=[500, 500, 500, 500])
    )

    def my_llm(prompt: str) -> str:
        return f"answer: {prompt}"

    async with redraven.Client(
        api_key="rr_test",
        base_url=BASE,
        transport=transport,
    ) as client:
        with pytest.raises(redraven.RedravenHTTPError):
            await client.run_test(
                test_id=TEST_ID,
                llm=my_llm,
                concurrency=2,
                retries=0,
                poll_interval_s=0.01,
                poll_timeout_s=5.0,
            )


@pytest.mark.asyncio
async def test_generate_test_creates_and_triggers_generation():
    state: dict[str, Any] = {}
    transport = httpx.MockTransport(_build_handler(state))

    async with redraven.Client(
        api_key="rr_test",
        base_url=BASE,
        transport=transport,
    ) as client:
        test_id = await client.generate_test(
            generate_kwargs={
                "project_id": "11111111-1111-1111-1111-111111111111",
                "test_name": "SDK Generated Test",
                "business_context": "Healthcare SaaS",
                "use_case": "Symptom triage assistant",
                "max_prompts_per_policy": 2,
            }
        )

    assert test_id == TEST_ID
    assert state["created_test_payload"]["project_id"] == "11111111-1111-1111-1111-111111111111"
    assert state["created_test_payload"]["name"] == "SDK Generated Test"
    assert "project_id" not in state["generate_payload"]
    assert "test_name" not in state["generate_payload"]
    assert state["generate_payload"]["business_context"] == "Healthcare SaaS"
    assert state["generate_payload"]["use_case"] == "Symptom triage assistant"
