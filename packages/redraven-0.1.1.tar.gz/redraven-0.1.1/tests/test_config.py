"""Config resolution from constructor args + env vars."""
from __future__ import annotations

import pytest

import redraven
from redraven.config import ENV_API_KEY, ENV_BASE_URL, Settings


def test_settings_from_constructor_args():
    s = Settings.resolve(api_key="rr_x", base_url="https://example.test/")
    assert s.api_key == "rr_x"
    assert s.base_url == "https://example.test"  # trailing slash stripped


def test_settings_strips_api_suffixes():
    assert Settings.resolve(api_key="x", base_url="https://h.test/api").base_url == "https://h.test"
    assert (
        Settings.resolve(api_key="x", base_url="https://h.test/api/v1").base_url
        == "https://h.test"
    )


def test_settings_from_env(monkeypatch):
    monkeypatch.setenv(ENV_API_KEY, "rr_env")
    monkeypatch.setenv(ENV_BASE_URL, "https://api.example.test")
    s = Settings.resolve(api_key=None, base_url=None)
    assert s.api_key == "rr_env"
    assert s.base_url == "https://api.example.test"


def test_settings_constructor_overrides_env(monkeypatch):
    monkeypatch.setenv(ENV_API_KEY, "rr_env")
    monkeypatch.setenv(ENV_BASE_URL, "https://api.example.test")
    s = Settings.resolve(api_key="rr_explicit", base_url="https://other.test")
    assert s.api_key == "rr_explicit"
    assert s.base_url == "https://other.test"


def test_missing_api_key_raises(monkeypatch):
    monkeypatch.delenv(ENV_API_KEY, raising=False)
    monkeypatch.setenv(ENV_BASE_URL, "https://x")
    with pytest.raises(redraven.RedravenConfigError):
        Settings.resolve(api_key=None, base_url=None)


def test_missing_base_url_raises(monkeypatch):
    monkeypatch.setenv(ENV_API_KEY, "rr_x")
    monkeypatch.delenv(ENV_BASE_URL, raising=False)
    with pytest.raises(redraven.RedravenConfigError):
        Settings.resolve(api_key=None, base_url=None)
