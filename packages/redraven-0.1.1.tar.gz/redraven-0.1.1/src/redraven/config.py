"""Resolve SDK configuration from constructor args or environment variables.

No URL is hardcoded anywhere. Either pass values to `Client(api_key=..., base_url=...)`
or set the `REDRAVEN_API_KEY` and `REDRAVEN_BASE_URL` environment variables.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

from redraven.exceptions import RedravenConfigError

ENV_API_KEY = "REDRAVEN_API_KEY"
ENV_BASE_URL = "REDRAVEN_BASE_URL"


@dataclass(frozen=True)
class Settings:
    api_key: str
    base_url: str

    @staticmethod
    def resolve(api_key: str | None, base_url: str | None) -> "Settings":
        api_key = (api_key or os.getenv(ENV_API_KEY) or "").strip()
        base_url = (base_url or os.getenv(ENV_BASE_URL) or "").strip()

        if not api_key:
            raise RedravenConfigError(
                f"Redraven API key is required. Pass api_key=... or set {ENV_API_KEY}."
            )
        if not base_url:
            raise RedravenConfigError(
                f"Redraven base URL is required. Pass base_url=... or set {ENV_BASE_URL}. "
                "Pass the host only (e.g. https://app.redraven.fireraven.ai); the SDK adds /api/v1."
            )

        base_url = base_url.rstrip("/")
        # Be forgiving if the user pasted a URL that already contains /api or /api/v1.
        for suffix in ("/api/v1", "/api"):
            if base_url.endswith(suffix):
                base_url = base_url[: -len(suffix)]
                break
        return Settings(api_key=api_key, base_url=base_url)
