"""Redraven SDK — Python client for the Redraven public API (fireraven.ai)."""
from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from redraven.client import Client
from redraven.exceptions import (
    RedravenConfigError,
    RedravenError,
    RedravenHTTPError,
    RedravenPartialRunError,
    RedravenTimeoutError,
)
from redraven.models import (
    CaseResponseAck,
    EvalSummary,
    PipelineCases,
    PipelineSummary,
    RunAgainstClient,
)

try:
    __version__ = version("redraven")
except PackageNotFoundError:
    __version__ = "0.dev0"

__all__ = [
    "__version__",
    "Client",
    "RedravenError",
    "RedravenConfigError",
    "RedravenHTTPError",
    "RedravenPartialRunError",
    "RedravenTimeoutError",
    "CaseResponseAck",
    "EvalSummary",
    "PipelineCases",
    "PipelineSummary",
    "RunAgainstClient",
]
