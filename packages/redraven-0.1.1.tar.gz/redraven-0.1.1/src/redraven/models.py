"""Pydantic response models mirroring the redraven-backend public schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class _Base(BaseModel):
    model_config = ConfigDict(extra="ignore", protected_namespaces=())


class RunAgainstClient(_Base):
    """Response from POST /tests/{id}/run-against-client."""

    job_id: str
    run_id: str
    test_id: str
    expected_cases: int
    case_ids: list[str]


class CaseResponseAck(_Base):
    """Response from POST /tests/{id}/cases/{case_id}/client-response."""

    test_id: str
    case_id: str
    received: int
    failed: int
    expected_cases: int
    state: str
    auto_finalized: bool = False


class PipelineSummary(_Base):
    """Response from GET /tests/{id}/results/summary?kind=eval|dataset."""

    kind: str
    manifest: dict[str, Any]
    summary: dict[str, Any] | None = None


class PipelineCases(_Base):
    """Response from GET /tests/{id}/results/cases?kind=...&offset=&limit=."""

    kind: str
    offset: int
    limit: int
    total: int
    cases: list[dict[str, Any]]


class EvalSummary(_Base):
    """Final result returned by run_test once eval is done."""

    test_id: str
    state: str
    received: int
    failed: int
    expected_cases: int
    failed_case_ids: list[str]
    summary: dict[str, Any] | None = None
    manifest: dict[str, Any] | None = None
