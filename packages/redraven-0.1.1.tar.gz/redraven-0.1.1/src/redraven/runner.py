"""Bounded-concurrency runner for the SDK ↔ user-LLM ↔ Redraven loop.

KISS:
  * one anyio.Semaphore caps in-flight calls to the user's LLM
  * each finished case is POSTed immediately
  * sync callables go through anyio.to_thread.run_sync so blocking SDKs are safe
  * per-case retry with exponential backoff
  * resumable: server-side per-case POST is idempotent, so re-running skips done cases
"""
from __future__ import annotations

import inspect
import time
from typing import TYPE_CHECKING, Any, Awaitable, Callable

import anyio

from redraven.exceptions import (
    RedravenHTTPError,
    RedravenPartialRunError,
    RedravenTimeoutError,
)
from redraven.models import EvalSummary

if TYPE_CHECKING:
    from redraven.client import Client


_TERMINAL_STATES = {"completed", "failed"}
_TRANSIENT_POLL_ERROR_CODES = {0, 500, 502, 503, 504}
_MAX_TRANSIENT_POLL_ERRORS = 3


async def _call_llm(llm: Callable[[str], Awaitable[str] | str], prompt: str) -> str:
    """Call the user's LLM. Async callables are awaited; sync ones run in a worker thread."""
    if inspect.iscoroutinefunction(llm):
        result = await llm(prompt)
    else:
        result = await anyio.to_thread.run_sync(llm, prompt)
    if not isinstance(result, str):
        raise TypeError(
            f"LLM callable must return str, got {type(result).__name__}"
        )
    return result


async def _process_case(
    client: "Client",
    *,
    test_id: str,
    case: dict[str, Any],
    llm: Callable[[str], Awaitable[str] | str],
    semaphore: anyio.Semaphore,
    retries: int,
    retry_backoff_s: float,
    prompt_field: str,
) -> None:
    case_id = str(case.get("id") or case.get("test_case_id") or "").strip()
    if not case_id:
        return
    prompt = case.get(prompt_field)
    if not isinstance(prompt, str) or not prompt.strip():
        await client.submit_case_response(
            test_id,
            case_id,
            status="failed",
            error=f"missing prompt in field '{prompt_field}'",
        )
        return

    async with semaphore:
        last_error: str | None = None
        started = time.monotonic()
        for attempt in range(retries + 1):
            try:
                response_text = await _call_llm(llm, prompt)
                latency_ms = int((time.monotonic() - started) * 1000)
                await client.submit_case_response(
                    test_id,
                    case_id,
                    status="ok",
                    response=response_text,
                    latency_ms=latency_ms,
                )
                return
            except Exception as e:
                last_error = f"{type(e).__name__}: {e}"
                if attempt < retries:
                    await anyio.sleep(retry_backoff_s * (2 ** attempt))
                    continue
                break

        try:
            await client.submit_case_response(
                test_id,
                case_id,
                status="failed",
                error=last_error or "unknown error",
            )
        except RedravenHTTPError:
            # If we cannot even register the failure, bubble up so caller sees it.
            raise


async def _poll_until_terminal(
    client: "Client",
    *,
    test_id: str,
    poll_interval_s: float,
    poll_timeout_s: float,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    deadline = time.monotonic() + poll_timeout_s
    transient_error_count = 0
    while time.monotonic() < deadline:
        try:
            summary = await client.get_results_summary(test_id, kind="eval")
            transient_error_count = 0
            manifest_state = (summary.manifest or {}).get("state")
            if manifest_state in _TERMINAL_STATES:
                return summary.manifest or {}, summary.summary
        except RedravenHTTPError as e:
            if e.status_code == 404:
                pass
            elif e.status_code in _TRANSIENT_POLL_ERROR_CODES:
                transient_error_count += 1
                if transient_error_count > _MAX_TRANSIENT_POLL_ERRORS:
                    raise
            else:
                raise
        await anyio.sleep(poll_interval_s)
    raise RedravenTimeoutError(
        f"Eval did not reach terminal state within {poll_timeout_s}s for test {test_id}"
    )


async def run_test(
    client: "Client",
    *,
    test_id: str,
    llm: Callable[[str], Awaitable[str] | str],
    concurrency: int,
    retries: int,
    retry_backoff_s: float,
    allow_partial: bool,
    poll_interval_s: float,
    poll_timeout_s: float,
    prompt_field: str,
) -> EvalSummary:
    handshake = await client.start_run_test(test_id)
    expected_cases = handshake.expected_cases

    cases: list[dict[str, Any]] = []
    async for case in client.iter_dataset_cases(test_id, page_size=200):
        cases.append(case)

    if len(cases) != expected_cases:
        # Backend says expected_cases is the source of truth; we still submit what we have.
        pass

    semaphore = anyio.Semaphore(max(concurrency, 1))

    last_ack = None
    async with anyio.create_task_group() as tg:
        async def _worker(c: dict[str, Any]) -> None:
            nonlocal last_ack
            await _process_case(
                client,
                test_id=test_id,
                case=c,
                llm=llm,
                semaphore=semaphore,
                retries=retries,
                retry_backoff_s=retry_backoff_s,
                prompt_field=prompt_field,
            )

        for c in cases:
            tg.start_soon(_worker, c)

    manifest, summary_payload = await _poll_until_terminal(
        client,
        test_id=test_id,
        poll_interval_s=poll_interval_s,
        poll_timeout_s=poll_timeout_s,
    )

    failed_case_ids = list((summary_payload or {}).get("failed_case_ids") or [])

    eval_summary = EvalSummary(
        test_id=test_id,
        state=str(manifest.get("state") or ""),
        received=expected_cases - len(failed_case_ids),
        failed=len(failed_case_ids),
        expected_cases=expected_cases,
        failed_case_ids=failed_case_ids,
        summary=summary_payload,
        manifest=manifest,
    )

    if not allow_partial and failed_case_ids:
        raise RedravenPartialRunError(
            f"{len(failed_case_ids)} case(s) failed and allow_partial=False",
            failed_case_ids=failed_case_ids,
        )

    return eval_summary


async def _wait_for_dataset_ready(
    client: "Client",
    *,
    test_id: str,
    poll_interval_s: float,
    poll_timeout_s: float,
) -> None:
    deadline = time.monotonic() + poll_timeout_s
    while time.monotonic() < deadline:
        try:
            summary = await client.get_results_summary(test_id, kind="dataset")
            state = (summary.manifest or {}).get("state")
            if state == "completed":
                return
        except RedravenHTTPError as e:
            if e.status_code != 404:
                raise
        await anyio.sleep(poll_interval_s)
    raise RedravenTimeoutError(
        f"Dataset did not reach 'completed' within {poll_timeout_s}s for test {test_id}"
    )


async def wait_for_dataset_ready(
    client: "Client",
    *,
    test_id: str,
    poll_interval_s: float,
    poll_timeout_s: float,
) -> None:
    await _wait_for_dataset_ready(
        client,
        test_id=test_id,
        poll_interval_s=poll_interval_s,
        poll_timeout_s=poll_timeout_s,
    )


async def generate_test(
    client: "Client",
    *,
    generate_kwargs: dict[str, Any],
    wait_for_dataset: bool,
    poll_interval_s: float,
    poll_timeout_s: float,
) -> str:
    project_id = str(generate_kwargs["project_id"])
    test_name = str(generate_kwargs["test_name"])

    test = await client.create_test(project_id=project_id, name=test_name)
    test_id = str(test["id"])

    generate_payload = dict(generate_kwargs)
    generate_payload.pop("project_id", None)
    generate_payload.pop("test_name", None)
    await client.generate(test_id, **generate_payload)
    if wait_for_dataset:
        await _wait_for_dataset_ready(
            client,
            test_id=test_id,
            poll_interval_s=poll_interval_s,
            poll_timeout_s=poll_timeout_s,
        )
    return test_id


async def generate_and_run_test(
    client: "Client",
    *,
    generate_kwargs: dict[str, Any],
    llm: Callable[[str], Awaitable[str] | str],
    concurrency: int,
    retries: int,
    retry_backoff_s: float,
    allow_partial: bool,
    poll_interval_s: float,
    poll_timeout_s: float,
    prompt_field: str,
) -> EvalSummary:
    test_id = await generate_test(
        client,
        generate_kwargs=generate_kwargs,
        wait_for_dataset=True,
        poll_interval_s=poll_interval_s,
        poll_timeout_s=poll_timeout_s,
    )
    return await run_test(
        client,
        test_id=test_id,
        llm=llm,
        concurrency=concurrency,
        retries=retries,
        retry_backoff_s=retry_backoff_s,
        allow_partial=allow_partial,
        poll_interval_s=poll_interval_s,
        poll_timeout_s=poll_timeout_s,
        prompt_field=prompt_field,
    )
