"""Async HTTP client for the Redraven public API.

Each `Client` instance is fully self-contained (no module-level globals), so
multi-org usage is just `Client(api_key=org1_key)` and `Client(api_key=org2_key)`
side by side.
"""
from __future__ import annotations

from types import TracebackType
from typing import Any, Awaitable, Callable, Type

import httpx

from redraven.config import Settings
from redraven.exceptions import RedravenHTTPError
from redraven.models import (
    CaseResponseAck,
    EvalSummary,
    PipelineCases,
    PipelineSummary,
    RunAgainstClient,
)

_API_PREFIX = "/api/v1"
_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


class Client:
    """Async client for the Redraven public API.

    Args:
        api_key: Organization-level Redraven API key. Falls back to env `REDRAVEN_API_KEY`.
        base_url: Backend host (e.g. `https://app.redraven.fireraven.ai`). The SDK adds the
            `/api/v1` prefix automatically. Falls back to env `REDRAVEN_BASE_URL`. Never hardcoded.
        timeout: Per-request httpx timeout. Defaults to 30s with 10s connect.
        transport: Optional httpx.AsyncBaseTransport (mainly for tests).
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: httpx.Timeout | float | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._settings = Settings.resolve(api_key, base_url)
        self._timeout = timeout if timeout is not None else _DEFAULT_TIMEOUT
        self._http = httpx.AsyncClient(
            base_url=self._settings.base_url,
            headers={
                "X-API-Key": self._settings.api_key,
                "User-Agent": "redraven-sdk-python/0.1",
            },
            timeout=self._timeout,
            transport=transport,
        )

    @property
    def base_url(self) -> str:
        return self._settings.base_url

    async def __aenter__(self) -> "Client":
        return self

    async def __aexit__(
        self,
        exc_type: Type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._http.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{_API_PREFIX}{path}"
        try:
            resp = await self._http.request(method, url, json=json, params=params)
        except httpx.HTTPError as e:
            raise RedravenHTTPError(
                f"HTTP transport error calling {method} {url}: {e}",
                status_code=0,
                url=str(self._http.base_url) + url,
            ) from e
        if resp.status_code >= 400:
            body: Any
            try:
                body = resp.json()
            except Exception:
                body = resp.text
            raise RedravenHTTPError(
                f"{method} {url} -> {resp.status_code}: {body}",
                status_code=resp.status_code,
                url=str(resp.request.url),
                body=body,
            )
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    async def create_test(
        self,
        *,
        project_id: str,
        name: str,
        status: str = "pending",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "project_id": project_id,
            "name": name,
            "status": status,
        }
        if metadata is not None:
            payload["metadata"] = metadata
        return await self._request("POST", "/tests/", json=payload)

    # ---- Generate -----------------------------------------------------------

    async def generate(
        self,
        test_id: str,
        *,
        business_context: str,
        use_case: str,
        certifications: list[str] | None = None,
        policies: list[dict[str, str]] | None = None,
        max_policies: int | None = None,
        max_prompts_per_policy: int = 1,
    ) -> dict[str, Any]:
        """Trigger dataset generation for a test (POST /tests/{id}/generate)."""
        payload: dict[str, Any] = {
            "business_context": business_context,
            "use_case": use_case,
            "max_prompts_per_policy": max_prompts_per_policy,
        }
        if certifications is not None:
            payload["certifications"] = certifications
        if policies is not None:
            payload["policies"] = policies
        if max_policies is not None:
            payload["max_policies"] = max_policies
        return await self._request("POST", f"/tests/{test_id}/generate", json=payload)

    async def get_generated_status(self, test_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/tests/{test_id}/generated/status")

    # ---- Pipeline reads -----------------------------------------------------

    async def get_results_summary(
        self,
        test_id: str,
        *,
        kind: str = "eval",
    ) -> PipelineSummary:
        data = await self._request(
            "GET",
            f"/tests/{test_id}/results/summary",
            params={"kind": kind},
        )
        return PipelineSummary.model_validate(data)

    async def get_results_cases(
        self,
        test_id: str,
        *,
        kind: str = "dataset",
        offset: int = 0,
        limit: int = 50,
    ) -> PipelineCases:
        data = await self._request(
            "GET",
            f"/tests/{test_id}/results/cases",
            params={"kind": kind, "offset": offset, "limit": limit},
        )
        return PipelineCases.model_validate(data)

    async def iter_dataset_cases(
        self,
        test_id: str,
        *,
        page_size: int = 100,
    ):
        """Async iterator over all dataset cases for a test."""
        offset = 0
        while True:
            page = await self.get_results_cases(
                test_id, kind="dataset", offset=offset, limit=page_size
            )
            for case in page.cases:
                yield case
            offset += len(page.cases)
            if not page.cases or offset >= page.total:
                return

    # ---- Run-against-client orchestration -----------------------------------

    async def start_run_test(self, test_id: str) -> RunAgainstClient:
        data = await self._request("POST", f"/tests/{test_id}/run-against-client")
        return RunAgainstClient.model_validate(data)

    async def submit_case_response(
        self,
        test_id: str,
        case_id: str,
        *,
        status: str,
        response: str | None = None,
        error: str | None = None,
        model_name: str | None = None,
        latency_ms: int | None = None,
    ) -> CaseResponseAck:
        payload: dict[str, Any] = {"status": status}
        if response is not None:
            payload["response"] = response
        if error is not None:
            payload["error"] = error
        if model_name is not None:
            payload["model_name"] = model_name
        if latency_ms is not None:
            payload["latency_ms"] = latency_ms
        data = await self._request(
            "POST",
            f"/tests/{test_id}/cases/{case_id}/client-response",
            json=payload,
        )
        return CaseResponseAck.model_validate(data)

    # ---- High-level orchestration -------------------------------------------

    async def run_test(
        self,
        test_id: str,
        llm: Callable[[str], Awaitable[str] | str],
        *,
        concurrency: int = 4,
        retries: int = 2,
        retry_backoff_s: float = 1.0,
        allow_partial: bool = True,
        poll_interval_s: float = 2.0,
        poll_timeout_s: float = 600.0,
        prompt_field: str = "request",
    ) -> EvalSummary:
        """Drive the full SDK loop and return the final eval summary."""
        from redraven.runner import run_test as _runner

        return await _runner(
            self,
            test_id=test_id,
            llm=llm,
            concurrency=concurrency,
            retries=retries,
            retry_backoff_s=retry_backoff_s,
            allow_partial=allow_partial,
            poll_interval_s=poll_interval_s,
            poll_timeout_s=poll_timeout_s,
            prompt_field=prompt_field,
        )

    async def generate_test(
        self,
        *,
        generate_kwargs: dict[str, Any],
        wait_for_dataset: bool = False,
        poll_interval_s: float = 2.0,
        poll_timeout_s: float = 600.0,
    ) -> str:
        """Create a test, trigger dataset generation, and return test_id.

        By default this is fire-and-forget for dataset materialization; set
        wait_for_dataset=True to block until dataset manifest reaches completed.
        """
        required_fields = ("project_id", "test_name", "business_context", "use_case")
        missing = [field for field in required_fields if not generate_kwargs.get(field)]
        if missing:
            missing_str = ", ".join(missing)
            raise ValueError(
                f"generate_kwargs missing required fields: {missing_str}"
            )

        from redraven.runner import generate_test as _generate_test

        return await _generate_test(
            self,
            generate_kwargs=generate_kwargs,
            wait_for_dataset=wait_for_dataset,
            poll_interval_s=poll_interval_s,
            poll_timeout_s=poll_timeout_s,
        )

    async def wait_for_dataset_ready(
        self,
        test_id: str,
        *,
        poll_interval_s: float = 2.0,
        poll_timeout_s: float = 600.0,
    ) -> None:
        """Block until dataset artifacts for test_id are materialized."""
        from redraven.runner import wait_for_dataset_ready as _wait_for_dataset_ready

        await _wait_for_dataset_ready(
            self,
            test_id=test_id,
            poll_interval_s=poll_interval_s,
            poll_timeout_s=poll_timeout_s,
        )

    async def generate_and_run_test(
        self,
        *,
        generate_kwargs: dict[str, Any],
        llm: Callable[[str], Awaitable[str] | str],
        concurrency: int = 4,
        retries: int = 2,
        retry_backoff_s: float = 1.0,
        allow_partial: bool = True,
        poll_interval_s: float = 2.0,
        poll_timeout_s: float = 600.0,
        prompt_field: str = "request",
    ) -> EvalSummary:
        """Create + generate + wait + run as one high-level call."""
        from redraven.runner import generate_and_run_test as _generate_and_run

        return await _generate_and_run(
            self,
            generate_kwargs=generate_kwargs,
            llm=llm,
            concurrency=concurrency,
            retries=retries,
            retry_backoff_s=retry_backoff_s,
            allow_partial=allow_partial,
            poll_interval_s=poll_interval_s,
            poll_timeout_s=poll_timeout_s,
            prompt_field=prompt_field,
        )
