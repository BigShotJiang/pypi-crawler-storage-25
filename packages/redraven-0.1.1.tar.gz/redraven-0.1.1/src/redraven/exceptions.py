"""Public exception hierarchy for the redraven SDK."""
from __future__ import annotations

from typing import Any


class RedravenError(Exception):
    """Base class for all redraven SDK errors."""


class RedravenConfigError(RedravenError):
    """Raised when required SDK configuration (API key, base URL) is missing."""


class RedravenHTTPError(RedravenError):
    """Raised when the Redraven backend returns a non-2xx response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        url: str,
        body: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.url = url
        self.body = body


class RedravenTimeoutError(RedravenError):
    """Raised when polling for a final state exceeds the configured timeout."""


class RedravenPartialRunError(RedravenError):
    """Raised when run_test cannot reach 100% successful responses and `allow_partial=False`."""

    def __init__(self, message: str, *, failed_case_ids: list[str]) -> None:
        super().__init__(message)
        self.failed_case_ids = failed_case_ids
