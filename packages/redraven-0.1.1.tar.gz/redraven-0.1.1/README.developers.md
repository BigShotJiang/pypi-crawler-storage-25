# redraven SDK — developer guide

This guide is for **contributors** to the redraven Python SDK.

## Repo layout

```
redraven-sdk/
  packages/
    python/
      pyproject.toml          # project metadata + deps; uv-first
      README.md               # overview + links
      README.users.md         # end-user guide
      README.developers.md    # this file
      src/redraven/
        __init__.py           # public re-exports
        client.py             # async httpx Client wrapping the public Redraven API
        config.py             # Settings (REDRAVEN_API_KEY, REDRAVEN_BASE_URL)
        models.py             # pydantic response models
        runner.py             # run_test / generate_test orchestration
        exceptions.py
      tests/                  # pytest + httpx MockTransport
```

## Environment

We use [`uv`](https://github.com/astral-sh/uv) for everything. Always prefer `uv` over plain `pip` / `python`.

```bash
cd packages/python
uv sync --extra dev
```

This creates `.venv/`, installs runtime + dev deps, and locks them.

## Running things

```bash
cd packages/python
uv run python -c "import redraven; print(redraven.__version__)"
uv run pytest -q
uv run ruff check .
```

## Architecture (1-pager)

The SDK is a thin async client around four public Redraven backend endpoints:

| HTTP                                                           | Purpose                                                           |
| -------------------------------------------------------------- | ----------------------------------------------------------------- |
| `POST /api/v1/tests`                                            | create a test                                                     |
| `POST /api/v1/tests/{id}/generate`                             | trigger dataset generation                                        |
| `GET  /api/v1/tests/{id}/results/cases?kind=dataset`           | iterate dataset cases (one JSON per test case)                    |
| `POST /api/v1/tests/{id}/run-against-client`                   | start the SDK loop; returns `expected_cases` + `case_ids`         |
| `POST /api/v1/tests/{id}/cases/{case_id}/client-response`      | submit per-case LLM response (idempotent)                         |
| `GET  /api/v1/tests/{id}/results/summary?kind=eval`            | poll eval lifecycle until terminal                                |

All endpoints authenticate with the org `X-API-Key` header. The SDK never talks to `redraven-api` (the internal compute service) directly.

The backend treats per-case JSON as the source of truth — the SDK writes one JSON per case to `client_llm_output/v1/tests/{test_id}/cases/{case_id}.json`, the backend manifest tracks `received`/`failed` counts, and auto-finalizes the eval when `received + failed == expected_cases`.

## Concurrency model

`runner.run_test` is the heart of the SDK:

- A single `anyio.Semaphore(concurrency)` caps in-flight calls to the user's LLM.
- `async def` callables are awaited directly; `def` callables go through `anyio.to_thread.run_sync` so blocking SDKs are safe.
- Per-case retries with exponential backoff (`retry_backoff_s * 2**attempt`).
- Each finished case is POSTed immediately — no batch boundary.
- Resumable: idempotent server-side per-case PUT-like upsert means re-runs skip done cases.

## Testing

- `pytest-asyncio` for async tests.
- `respx` (or `httpx.MockTransport`) for HTTP mocking — tests must not hit the network.
- Aim for tests that exercise: happy path, partial failure path, retry path, config error path.

Run:

```bash
cd packages/python
uv run pytest
```

## Style

- `ruff` enforces line length 100, target Python 3.10.
- Type hints everywhere on public APIs.
- Keep the public surface small; avoid leaking implementation details from `client.py` / `runner.py`.

## Releasing

1. Bump `version` in `pyproject.toml`.
2. Commit and push `main`.
3. Create and push a tag matching the version (`vX.Y.Z` for `X.Y.Z` in `pyproject.toml`).
4. The tag pipeline runs test/build/publish to PyPI via Trusted Publishing.

```bash
git push origin main
git tag vX.Y.Z
git push origin vX.Y.Z
```

## Filing issues

Issues and merge requests live in the GitLab project. Please include:

- redraven SDK version
- Python version
- a minimal reproducer
- whether the user LLM was sync or async
