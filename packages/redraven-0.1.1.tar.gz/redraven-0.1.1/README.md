# redraven (Python SDK)

The official Python SDK for **Redraven** — the LLM red-teaming and policy-evaluation platform from [fireraven.ai](https://fireraven.ai).

Redraven generates adversarial prompts, evaluates your LLM's responses against your safety policies and certifications, and surfaces failures so you can harden your AI products.

This SDK lets you drive the full Redraven flow from your own Python code:

1. Generate (or pick) a test dataset on Redraven.
2. Run each test case **locally** through your own LLM — your model API key never leaves your process.
3. Submit responses back to Redraven for scoring; receive a summary you can act on.

The SDK talks only to public endpoints on the Redraven backend, authenticated with your **organization API key** (issued from the Redraven app).

## Platforms

- Marketing site: [fireraven.ai](https://fireraven.ai)
- FireRaven app (production): [app.fireraven.ai](https://app.fireraven.ai)
- Redraven app (red-teaming console): [app.redraven.fireraven.ai](https://app.redraven.fireraven.ai)

## Installation

Install from PyPI:

```bash
uv add redraven
# or
pip install redraven
```

`uv` is preferred for reproducible installs.

## Quick start

```python
import asyncio
import redraven

async def my_llm(prompt: str) -> str:
    # Call your own LLM here. Your key stays in your process.
    return f"echo: {prompt}"

async def main():
    async with redraven.Client() as client:  # reads REDRAVEN_API_KEY + REDRAVEN_BASE_URL
        result = await client.run_test(
            test_id="<your-existing-test-id>",
            llm=my_llm,
            concurrency=4,
        )
        print(result.model_dump())

asyncio.run(main())
```

See [README.users.md](./README.users.md) for the full user guide.
The guide includes dataset-readiness semantics for `generate_test(...)` plus
the one-call `generate_and_run_test(...)` workflow.

## Documentation

- [User guide](./README.users.md)
- [Developer / contributor guide](./README.developers.md)

## License

Proprietary — © fireraven.ai. Contact us if you'd like to integrate Redraven into your product.
