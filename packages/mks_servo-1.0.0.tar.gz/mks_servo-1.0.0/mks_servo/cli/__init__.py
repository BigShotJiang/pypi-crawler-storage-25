"""CLI subpackage."""
