"""MAXIA Oracle SDK — synchronous HTTP client for the REST API.

Usage:

    from maxia_oracle import MaxiaOracleClient

    with MaxiaOracleClient(api_key="mxo_your_key") as client:
        btc = client.price("BTC")
        print(btc["price"])          # direct access, no ["data"] wrapper

If you do not yet have a key, call `register()` on a keyless client first:

    with MaxiaOracleClient() as client:
        registered = client.register()
        key = registered["api_key"]   # direct access, no ["data"] wrapper

Every successful response is the parsed JSON dict as returned by the
backend, including the mandatory `disclaimer` field. Errors are raised as
typed exceptions from `maxia_oracle.exceptions`.

Data feed only. Not investment advice. No custody. No KYC.
"""
from __future__ import annotations

import os
from types import TracebackType
from typing import Any, Final

import httpx

from .exceptions import (
    MaxiaOracleAuthError,
    MaxiaOraclePaymentRequiredError,
    MaxiaOracleRateLimitError,
    MaxiaOracleTransportError,
    MaxiaOracleUpstreamError,
    MaxiaOracleValidationError,
)

DEFAULT_BASE_URL: Final[str] = "https://oracle.maxiaworld.app"
DEFAULT_TIMEOUT_S: Final[float] = 15.0
USER_AGENT: Final[str] = "maxia-oracle-python/0.2.0"


class MaxiaOracleClient:
    """Synchronous client for the MAXIA Oracle REST API.

    Implements 9 methods aligned with the 8 MCP tools exposed by the
    MAXIA Oracle server (phase 5) plus `register()`:

        - `register()`              → POST /api/register
        - `health()`                → GET  /health
        - `price(symbol)`           → GET  /api/price/{symbol}
        - `prices_batch(symbols)`   → POST /api/prices/batch
        - `sources()`               → GET  /api/sources
        - `cache_stats()`           → GET  /api/cache/stats
        - `list_symbols()`          → GET  /api/symbols
        - `chainlink_onchain(sym)`  → GET  /api/chainlink/{symbol}
        - `confidence(symbol)`      → GET  /api/price/{symbol} (divergence extract)

    `register()` and `health()` are the only methods that work without a
    key — the rest require a `mxo_`-prefixed key supplied either at
    construction time, via the `MAXIA_ORACLE_API_KEY` environment
    variable, or loaded from a freshly registered session.

    Data feed only. Not investment advice. No custody. No KYC.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout_s: float = DEFAULT_TIMEOUT_S,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("MAXIA_ORACLE_API_KEY")
        self._base_url = (base_url or os.environ.get("MAXIA_ORACLE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout_s,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
            transport=transport,
        )

    # ── Context manager ─────────────────────────────────────────────────────

    def __enter__(self) -> "MaxiaOracleClient":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    # ── Public API ──────────────────────────────────────────────────────────

    def register(self) -> dict[str, Any]:
        """Register a fresh free-tier API key.

        Returns the parsed response dict. The raw key is in
        `response["data"]["api_key"]` — it is returned exactly once, store
        it immediately. The daily quota is in `response["data"]["daily_limit"]`.

        Note: this endpoint is IP-throttled to one registration per minute.
        """
        return self._request("POST", "/api/register", auth=False)

    def health(self) -> dict[str, Any]:
        """Lightweight liveness probe. No authentication required.

        Returns the parsed dict containing `data.status`, `data.env`,
        `data.uptime_s` and the disclaimer.
        """
        return self._request("GET", "/health", auth=False)

    def price(self, symbol: str) -> dict[str, Any]:
        """Return a cross-validated multi-source live price for one asset.

        The response shape mirrors the MCP `get_price` tool: a median price,
        the per-source breakdown, the source count, and the divergence in
        percent across sources.

        Raises:
            MaxiaOracleValidationError: symbol does not match the format.
            MaxiaOracleUpstreamError: every upstream source failed.
            MaxiaOracleAuthError: missing or invalid API key.
            MaxiaOracleRateLimitError: daily quota exhausted.
        """
        symbol = self._validate_symbol(symbol)
        return self._request("GET", f"/api/price/{symbol}")

    def prices_batch(self, symbols: list[str]) -> dict[str, Any]:
        """Return live prices for up to 50 symbols in a single upstream call.

        Uses the Pyth Hermes batch endpoint. Dramatically cheaper than
        N × `price()`. Maximum 50 symbols per call.

        Raises:
            MaxiaOracleValidationError: non-list, empty list, over 50, or
                any symbol fails the format check.
        """
        if not isinstance(symbols, list):
            raise MaxiaOracleValidationError("symbols must be a list of strings")
        if not symbols:
            raise MaxiaOracleValidationError("symbols must contain at least one entry")
        if len(symbols) > 50:
            raise MaxiaOracleValidationError(
                f"batch size exceeds 50 (got {len(symbols)})"
            )
        cleaned = [self._validate_symbol(s) for s in symbols]
        return self._request("POST", "/api/prices/batch", json={"symbols": cleaned})

    def sources(self) -> dict[str, Any]:
        """List every configured upstream oracle source and its current status.

        Returns the parsed dict containing `data.sources` — a list of
        named source objects with their liveness, last-good-read
        timestamp, and base URL.
        """
        return self._request("GET", "/api/sources")

    def cache_stats(self) -> dict[str, Any]:
        """Return the aggregator in-memory cache hit-rate and circuit-breaker state.

        Debug-oriented tool: lets an agent introspect its own latency
        amplification by checking how often reads hit the cache vs how
        often they punch through to the upstream sources.
        """
        return self._request("GET", "/api/cache/stats")

    def list_symbols(self) -> dict[str, Any]:
        """Return the union of supported asset symbols, grouped by upstream source.

        Response shape mirrors the MCP `list_supported_symbols` tool:
        `data.total_symbols`, `data.all_symbols` (flat sorted list), and
        `data.by_source` (pyth_crypto, pyth_equity, chainlink_base,
        price_oracle). No upstream calls — cheap metadata read.
        """
        return self._request("GET", "/api/symbols")

    def chainlink_onchain(self, symbol: str) -> dict[str, Any]:
        """Return a single-source price directly from the Chainlink feed on Base.

        Forces the on-chain single-source path (bypasses Pyth and the
        aggregator). Useful for audit or for cross-checking the median
        returned by `price()`. Supported symbols are in
        `list_symbols()["data"]["by_source"]["chainlink_base"]`.

        Raises:
            MaxiaOracleValidationError: symbol format or not supported on
                Chainlink Base.
        """
        symbol = self._validate_symbol(symbol)
        return self._request("GET", f"/api/chainlink/{symbol}")

    def confidence(self, symbol: str) -> dict[str, Any]:
        """Return the multi-source divergence for a symbol, compact.

        Helper built on top of `price()`. Returns the symbol, the source
        count and the divergence in percent — not the individual per-source
        quotes. Use this when all you need is "do the sources agree?",
        not the full price breakdown.
        """
        data = self.price(symbol)
        return {
            "symbol": data.get("symbol", symbol),
            "source_count": data.get("source_count"),
            "divergence_pct": data.get("divergence_pct"),
        }

    # ── Internals ───────────────────────────────────────────────────────────

    _SYMBOL_MAX_LEN = 10

    def _validate_symbol(self, symbol: str) -> str:
        if not isinstance(symbol, str):
            raise MaxiaOracleValidationError("symbol must be a string")
        cleaned = symbol.strip().upper()
        if not cleaned:
            raise MaxiaOracleValidationError("symbol must not be empty")
        if len(cleaned) > self._SYMBOL_MAX_LEN:
            raise MaxiaOracleValidationError(
                f"symbol must be at most {self._SYMBOL_MAX_LEN} characters"
            )
        if not cleaned.replace("_", "").isalnum():
            raise MaxiaOracleValidationError(
                "symbol must match ^[A-Z0-9]{1,10}$"
            )
        for char in cleaned:
            if not (char.isdigit() or ("A" <= char <= "Z")):
                raise MaxiaOracleValidationError(
                    "symbol must match ^[A-Z0-9]{1,10}$"
                )
        return cleaned

    def _build_headers(self, auth: bool) -> dict[str, str]:
        headers: dict[str, str] = {}
        if auth:
            if not self._api_key:
                raise MaxiaOracleAuthError(
                    "API key required — pass api_key= or set MAXIA_ORACLE_API_KEY"
                )
            headers["X-API-Key"] = self._api_key
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        auth: bool = True,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        try:
            response = self._client.request(
                method,
                path,
                headers=self._build_headers(auth),
                json=json,
            )
        except httpx.HTTPError as exc:
            raise MaxiaOracleTransportError(
                f"transport error on {method} {path}: {exc}"
            ) from exc

        return self._handle_response(response, method=method, path=path)

    def _handle_response(
        self,
        response: httpx.Response,
        *,
        method: str,
        path: str,
    ) -> dict[str, Any]:
        status = response.status_code

        try:
            body = response.json()
        except ValueError:
            raise MaxiaOracleTransportError(
                f"non-JSON response from {method} {path}: status={status}"
            )

        if status >= 200 and status < 300:
            return body.get("data", body) if isinstance(body, dict) else body

        # Error branches
        message = body.get("error") if isinstance(body, dict) else None
        message = message or f"HTTP {status}"

        if status == 401:
            raise MaxiaOracleAuthError(message)
        if status == 402:
            raise MaxiaOraclePaymentRequiredError(
                message,
                accepts=body.get("accepts") if isinstance(body, dict) else None,
            )
        if status == 404 and isinstance(body, dict) and body.get("error") == "no live price available":
            raise MaxiaOracleUpstreamError(message)
        if status == 400 or status == 422:
            raise MaxiaOracleValidationError(message)
        if status == 429:
            raise MaxiaOracleRateLimitError(
                message,
                retry_after_seconds=(
                    body.get("retry_after_seconds") if isinstance(body, dict) else None
                ),
                limit=body.get("limit") if isinstance(body, dict) else None,
            )
        raise MaxiaOracleTransportError(
            f"unexpected {status} on {method} {path}: {message}"
        )
