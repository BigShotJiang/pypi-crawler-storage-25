# PW Agent

CLI coding assistant powered by your Ollama GPUs via [PastaWater](https://pastawater.io).

## Install

```bash
pip install pw-agent
```

## Usage

```bash
pw-agent
```

First run guides you through setup — paste your API token, pick a GPU, start chatting.

## Features

- Interactive REPL with streaming responses
- Tab autocomplete for commands and file paths
- Session persistence (resume where you left off)
- `/add file.py` or `@file.py` — inject files into context
- `/models` — view your GPU fleet
- `/switch N` — hot-switch between GPUs
- `/commit` — AI-generated git commit messages
- `-y` flag for auto-approve mode
- `-p "prompt"` for one-shot non-interactive mode

## Connect

- **Cloud mode**: Use your PastaWater API token
- **Direct mode**: Point at a local Ollama instance (`--brain http://localhost:11434`)

Get your token at [pastawater.io/settings](https://pastawater.io/settings?tab=cli)
