"""Local tools that the agent can execute on the user's machine."""

import os
import glob as glob_mod
import subprocess
import re


TOOL_DEFINITIONS = [
    {
        "name": "read_file",
        "description": "Read the contents of a file. Use this to understand existing code before making changes.",
        "parameters": {
            "path": {"type": "string", "description": "File path (relative to working directory)"}
        },
        "required": ["path"]
    },
    {
        "name": "write_file",
        "description": "Create a new file or completely overwrite an existing file with new content.",
        "parameters": {
            "path": {"type": "string", "description": "File path (relative to working directory)"},
            "content": {"type": "string", "description": "The full file content to write"}
        },
        "required": ["path", "content"]
    },
    {
        "name": "edit_file",
        "description": "Replace a specific string in a file. The old_str must match exactly (including whitespace/indentation). Use this for targeted edits instead of rewriting whole files.",
        "parameters": {
            "path": {"type": "string", "description": "File path (relative to working directory)"},
            "old_str": {"type": "string", "description": "The exact string to find and replace"},
            "new_str": {"type": "string", "description": "The replacement string"}
        },
        "required": ["path", "old_str", "new_str"]
    },
    {
        "name": "bash",
        "description": "Run a shell command and return its output. Use for running tests, git commands, installing packages, etc.",
        "parameters": {
            "command": {"type": "string", "description": "The bash command to execute"}
        },
        "required": ["command"]
    },
    {
        "name": "list_files",
        "description": "List files matching a glob pattern. Use to explore project structure.",
        "parameters": {
            "pattern": {"type": "string", "description": "Glob pattern (e.g. '**/*.py', 'src/*.ts')"}
        },
        "required": ["pattern"]
    },
    {
        "name": "grep",
        "description": "Search for a regex pattern in files. Returns matching lines with file paths and line numbers.",
        "parameters": {
            "pattern": {"type": "string", "description": "Regex pattern to search for"},
            "path": {"type": "string", "description": "File or directory to search in (default: current directory)", "default": "."},
            "include": {"type": "string", "description": "File glob filter (e.g. '*.py')", "default": ""}
        },
        "required": ["pattern"]
    },
]

# Commands that are always blocked
BLOCKED_COMMANDS = [
    "rm -rf /", "rm -rf /*", "mkfs", "dd if=", ":(){", "fork bomb",
    "chmod -R 777 /", "shutdown", "reboot", "halt", "poweroff",
]

# Global auto-approve flag — set by --yes flag
AUTO_APPROVE = False


def _resolve_path(path: str) -> str:
    """Resolve a path relative to the working directory."""
    if os.path.isabs(path):
        return path
    return os.path.abspath(path)


def read_file(path: str) -> str:
    """Read a file and return its contents."""
    full_path = _resolve_path(path)
    if not os.path.exists(full_path):
        return f"Error: File not found: {path}"
    if os.path.isdir(full_path):
        return f"Error: {path} is a directory, not a file"
    try:
        with open(full_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        lines = content.split("\n")
        if len(lines) > 500:
            return f"[File has {len(lines)} lines, showing first 500]\n" + "\n".join(
                f"{i+1}: {line}" for i, line in enumerate(lines[:500])
            )
        return "\n".join(f"{i+1}: {line}" for i, line in enumerate(lines))
    except Exception as e:
        return f"Error reading {path}: {e}"


def write_file(path: str, content: str) -> str:
    """Write content to a file."""
    full_path = _resolve_path(path)
    try:
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
        lines = content.count("\n") + 1
        return f"Wrote {lines} lines to {path}"
    except Exception as e:
        return f"Error writing {path}: {e}"


def edit_file(path: str, old_str: str, new_str: str) -> str:
    """Find and replace a string in a file."""
    full_path = _resolve_path(path)
    if not os.path.exists(full_path):
        return f"Error: File not found: {path}"
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            content = f.read()

        count = content.count(old_str)
        if count == 0:
            return f"Error: old_str not found in {path}. Make sure it matches exactly (including whitespace)."
        if count > 1:
            return f"Error: old_str found {count} times in {path}. Make it more specific to match exactly once."

        new_content = content.replace(old_str, new_str, 1)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(new_content)
        return f"Edited {path}: replaced 1 occurrence"
    except Exception as e:
        return f"Error editing {path}: {e}"


def bash(command: str, auto_approve: bool = False) -> str:
    """Run a bash command with safety checks."""
    # Block dangerous commands
    cmd_lower = command.lower().strip()
    for blocked in BLOCKED_COMMANDS:
        if blocked in cmd_lower:
            return f"Error: Command blocked for safety: {command}"

    # Ask for confirmation unless auto-approved
    if not auto_approve and not AUTO_APPROVE:
        print(f"\n  \033[33m$ {command}\033[0m")
        try:
            confirm = input("  Run this command? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "Command cancelled by user."
        if confirm not in ("y", "yes"):
            return "Command cancelled by user."

    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=60, cwd=os.getcwd()
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += ("\n" if output else "") + result.stderr
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        # Truncate very long output
        if len(output) > 5000:
            output = output[:5000] + f"\n... [truncated, {len(output)} chars total]"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out after 60 seconds"
    except Exception as e:
        return f"Error running command: {e}"


def list_files(pattern: str) -> str:
    """List files matching a glob pattern."""
    try:
        matches = sorted(glob_mod.glob(pattern, recursive=True))
        if not matches:
            return f"No files found matching: {pattern}"
        if len(matches) > 100:
            return "\n".join(matches[:100]) + f"\n... and {len(matches) - 100} more"
        return "\n".join(matches)
    except Exception as e:
        return f"Error listing files: {e}"


def grep(pattern: str, path: str = ".", include: str = "") -> str:
    """Search for a pattern in files."""
    try:
        cmd = ["grep", "-rn", "--color=never", "-I"]
        if include:
            cmd.extend(["--include", include])
        cmd.extend([pattern, path])

        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=30, cwd=os.getcwd()
        )
        output = result.stdout.strip()
        if not output:
            return f"No matches found for: {pattern}"
        lines = output.split("\n")
        if len(lines) > 50:
            return "\n".join(lines[:50]) + f"\n... and {len(lines) - 50} more matches"
        return output
    except subprocess.TimeoutExpired:
        return "Error: grep timed out after 30 seconds"
    except Exception as e:
        return f"Error running grep: {e}"


# Map tool names to functions
TOOL_MAP = {
    "read_file": lambda args: read_file(args["path"]),
    "write_file": lambda args: write_file(args["path"], args["content"]),
    "edit_file": lambda args: edit_file(args["path"], args["old_str"], args["new_str"]),
    "bash": lambda args: bash(args["command"]),
    "list_files": lambda args: list_files(args["pattern"]),
    "grep": lambda args: grep(args["pattern"], args.get("path", "."), args.get("include", "")),
}


def execute_tool(name: str, args: dict) -> str:
    """Execute a tool by name with the given arguments."""
    if name not in TOOL_MAP:
        return f"Error: Unknown tool '{name}'. Available: {', '.join(TOOL_MAP.keys())}"
    try:
        return TOOL_MAP[name](args)
    except KeyError as e:
        return f"Error: Missing required argument {e} for tool '{name}'"
    except Exception as e:
        return f"Error executing {name}: {e}"
