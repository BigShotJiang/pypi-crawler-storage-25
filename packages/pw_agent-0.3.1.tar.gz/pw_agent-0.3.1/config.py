"""Config management — persists token, slot, model preferences."""

import json
import os

DEFAULT_CONFIG_DIR = os.path.expanduser("~/.config/pw-agent")
CONFIG_FILE = "config.json"


def _config_path(config_dir: str = "") -> str:
    d = config_dir or DEFAULT_CONFIG_DIR
    return os.path.join(d, CONFIG_FILE)


def load_config(config_dir: str = "") -> dict:
    """Load saved config, or return empty dict."""
    path = _config_path(config_dir)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(data: dict, config_dir: str = "") -> str:
    """Save config and return the file path."""
    d = config_dir or DEFAULT_CONFIG_DIR
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, CONFIG_FILE)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    return path


def has_config(config_dir: str = "") -> bool:
    """Check if a config file exists."""
    return os.path.exists(_config_path(config_dir))


# ─── Session persistence ─────────────────────────────────────────────────────

def _sessions_dir(config_dir: str = "") -> str:
    d = config_dir or DEFAULT_CONFIG_DIR
    return os.path.join(d, "sessions")


def save_session(conversation: list[dict], cwd: str, config_dir: str = "") -> str:
    """Save conversation to a session file. Returns the path."""
    d = _sessions_dir(config_dir)
    os.makedirs(d, exist_ok=True)
    # Use cwd hash as session key so each project has its own session
    import hashlib
    key = hashlib.md5(cwd.encode()).hexdigest()[:10]
    path = os.path.join(d, f"{key}.json")
    data = {"cwd": cwd, "conversation": conversation}
    with open(path, "w") as f:
        json.dump(data, f)
    return path


def load_session(cwd: str, config_dir: str = "") -> list[dict]:
    """Load the session for a given cwd, or return empty list."""
    d = _sessions_dir(config_dir)
    import hashlib
    key = hashlib.md5(cwd.encode()).hexdigest()[:10]
    path = os.path.join(d, f"{key}.json")
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r") as f:
            data = json.load(f)
        if data.get("cwd") == cwd:
            return data.get("conversation", [])
    except (json.JSONDecodeError, OSError):
        pass
    return []


def clear_session(cwd: str, config_dir: str = ""):
    """Delete the session for a given cwd."""
    d = _sessions_dir(config_dir)
    import hashlib
    key = hashlib.md5(cwd.encode()).hexdigest()[:10]
    path = os.path.join(d, f"{key}.json")
    if os.path.exists(path):
        os.remove(path)
