"""Sherpa IPTC category mapper"""

__version__ = "0.6.25"
