"""
scellrun CLI entrypoint.

Top-level command groups:
    scellrun scrna ...     single-cell RNA-seq commands
    scellrun profiles ...  list / inspect profiles
"""
from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from scellrun import __version__

app = typer.Typer(
    no_args_is_help=True,
    help="scellrun — opinionated, report-first single-cell + multi-omics CLI.",
    add_completion=False,
)
scrna_app = typer.Typer(no_args_is_help=True, help="Single-cell RNA-seq commands.")
profiles_app = typer.Typer(no_args_is_help=True, help="Inspect available profiles.")
app.add_typer(scrna_app, name="scrna")
app.add_typer(profiles_app, name="profiles")

console = Console()


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"scellrun {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool | None = typer.Option(
        None, "--version", "-V", help="Show version and exit.", callback=_version_callback, is_eager=True
    ),
) -> None:
    pass


@scrna_app.command("convert")
def scrna_convert(
    input_path: Path = typer.Argument(..., exists=True, readable=True, help="Input file or directory (10x mtx dir / .h5 / .loom / .csv / .tsv / .h5ad)."),
    output: Path = typer.Option(..., "--out", "-o", help="Output .h5ad path."),
    fmt: str = typer.Option("auto", "--format", "-f", help="Input format. 'auto' tries to detect from extension/contents."),
) -> None:
    """
    Convert raw single-cell input (10x mtx dir, cellranger .h5, loom, csv, tsv)
    into the .h5ad format that scellrun expects.

    Most users have cellranger output sitting on disk and don't want to write
    Python to load it. This command is the first mile.
    """
    from scellrun.scrna.convert import UnsupportedInputError, convert

    valid = {"auto", "10x_mtx", "10x_h5", "loom", "csv", "tsv", "h5ad"}
    if fmt not in valid:
        console.print(f"[red]error:[/red] --format must be one of {sorted(valid)}")
        raise typer.Exit(2) from None

    console.print(f"[bold]scellrun scrna convert[/bold]  •  format=[cyan]{fmt}[/cyan]")
    console.print(f"reading [dim]{input_path}[/dim]")
    try:
        adata = convert(input_path, output, fmt=fmt)  # type: ignore[arg-type]
    except UnsupportedInputError as e:
        console.print(f"[red]error:[/red] {e}")
        raise typer.Exit(1) from None
    console.print(f"loaded: {adata.n_obs:,} cells × {adata.n_vars:,} genes")
    console.print(f"wrote: {output}")


@scrna_app.command("qc")
def scrna_qc(
    h5ad: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="Input .h5ad file."),
    run_dir: Path | None = typer.Option(None, "--run-dir", help="Run root directory. Default: scellrun_out/run-YYYYMMDD-HHMMSS."),
    out: Path | None = typer.Option(None, "--out", "-o", help="Override output dir for this stage. By default, writes to <run-dir>/01_qc/."),
    assay: str = typer.Option("scrna", "--assay", help="Assay flavor: 'scrna' or 'snrna'.", show_default=True),
    species: str = typer.Option("human", "--species", help="'human' or 'mouse'. Currently informational; v0.2+ uses it for cell-cycle gene lists."),
    profile: str = typer.Option("default", "--profile", "-p", help="Profile name (see `scellrun profiles list`)."),
    max_genes: int | None = typer.Option(None, "--max-genes", help="Override profile max_genes upper cap."),
    flag_doublets: bool = typer.Option(True, "--flag-doublets/--no-flag-doublets", help="Run scrublet for doublet flagging."),
    write_h5ad: bool = typer.Option(True, "--write-h5ad/--no-write-h5ad", help="Also write annotated qc.h5ad (canonical handoff to v0.2 integrate)."),
    force: bool = typer.Option(False, "--force/--no-force", help="Overwrite existing artifacts in the stage dir. Default: error if 01_qc/ already has output."),
    lang: str = typer.Option("en", "--lang", help="Report language: 'en' or 'zh'."),
) -> None:
    """
    Compute single-cell QC metrics, FLAG (don't drop) outlier cells, and emit:
      - report.html
      - per_cell_metrics.csv
      - qc.h5ad  (annotated AnnData, canonical handoff for v0.2 integrate)

    Output goes to <run-dir>/01_qc/ so the v0.4+ pipeline can pick it up.
    """
    import dataclasses

    import anndata as ad

    from scellrun.profiles import load as load_profile
    from scellrun.runlayout import (
        StageOutputExists,
        default_run_dir,
        stage_dir,
        write_run_meta,
    )
    from scellrun.scrna.qc import InvalidInputError, run_qc, write_artifacts

    if assay not in ("scrna", "snrna"):
        console.print(f"[red]error:[/red] --assay must be 'scrna' or 'snrna', got {assay!r}")
        raise typer.Exit(2) from None
    if species not in ("human", "mouse"):
        console.print(f"[red]error:[/red] --species must be 'human' or 'mouse', got {species!r}")
        raise typer.Exit(2) from None
    if lang not in ("en", "zh"):
        console.print(f"[red]error:[/red] --lang must be 'en' or 'zh', got {lang!r}")
        raise typer.Exit(2) from None

    try:
        prof = load_profile(profile)
    except ModuleNotFoundError:
        console.print(f"[red]error:[/red] unknown profile {profile!r}. Try `scellrun profiles list`.")
        raise typer.Exit(2) from None

    base_thresholds = prof.snrna_qc if assay == "snrna" else prof.scrna_qc
    overrides: dict = {"species": species}
    if max_genes is not None:
        overrides["max_genes"] = max_genes
    thresholds = dataclasses.replace(base_thresholds, **overrides)

    if run_dir is None:
        run_dir = default_run_dir()
    if out is not None:
        out_dir = out
        out_dir.mkdir(parents=True, exist_ok=True)
    else:
        try:
            out_dir = stage_dir(run_dir, "qc", force=force)
        except StageOutputExists as e:
            console.print(f"[red]error:[/red] {e}")
            raise typer.Exit(2) from None

    console.print(
        f"[bold]scellrun scrna qc[/bold]  •  profile=[cyan]{profile}[/cyan]  "
        f"assay=[cyan]{assay}[/cyan]  species=[cyan]{species}[/cyan]"
    )
    console.print(f"run-dir: [dim]{run_dir}[/dim]")
    console.print(f"out-dir: [dim]{out_dir}[/dim]")
    console.print("[bold]effective thresholds:[/bold]")
    for k, v in dataclasses.asdict(thresholds).items():
        console.print(f"  {k:24s} {v}")
    console.print(f"reading [dim]{h5ad}[/dim]")

    adata = ad.read_h5ad(h5ad)
    console.print(f"loaded: {adata.n_obs:,} cells × {adata.n_vars:,} genes")

    try:
        result = run_qc(
            adata,
            assay=assay,
            flag_doublets=flag_doublets,
            thresholds=thresholds,
        )
    except InvalidInputError as e:
        console.print(f"[red]error:[/red] {e}")
        raise typer.Exit(1) from None

    if result.raw_counts_check == "looks_like_normalized":
        console.print(
            "[yellow]warning:[/yellow] X looks log-normalized, not raw counts. "
            "pct_counts_* metrics may be misleading; doublet flagging skipped."
        )
    elif result.raw_counts_check == "unknown":
        console.print(
            "[yellow]note:[/yellow] could not confirm whether X is raw counts; "
            "proceeding anyway."
        )

    pct = 100 * result.n_cells_pass / max(result.n_cells_in, 1)
    console.print(
        f"QC pass: [bold green]{result.n_cells_pass:,}[/bold green] / {result.n_cells_in:,} "
        f"({pct:.1f}%) — pct_mt median {result.pct_mt_median:.2f}%, p95 {result.pct_mt_p95:.2f}%"
    )
    if flag_doublets and result.raw_counts_check != "looks_like_normalized":
        console.print(f"doublets flagged: {result.n_doublets_flagged:,}")

    artifacts = write_artifacts(result, adata, out_dir, write_h5ad=write_h5ad, lang=lang)
    write_run_meta(
        run_dir,
        command="scrna qc",
        params={
            "h5ad": h5ad,
            "out_dir": out_dir,
            "assay": assay,
            "species": species,
            "profile": profile,
            "thresholds": thresholds,
            "flag_doublets": flag_doublets,
            "write_h5ad": write_h5ad,
            "force": force,
            "raw_counts_check": result.raw_counts_check,
            "lang": lang,
        },
    )
    console.print(f"[bold]report:[/bold] [link=file://{artifacts['report'].resolve()}]{artifacts['report']}[/link]")
    console.print(f"per-cell CSV: {artifacts['per_cell_metrics']}")
    if "qc_h5ad" in artifacts:
        console.print(f"annotated h5ad: {artifacts['qc_h5ad']}")


@scrna_app.command("integrate")
def scrna_integrate(
    h5ad: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="Input .h5ad (typically <run-dir>/01_qc/qc.h5ad)."),
    run_dir: Path | None = typer.Option(None, "--run-dir", help="Run root directory. Default: same as the qc.h5ad's parent run-dir."),
    out: Path | None = typer.Option(None, "--out", "-o", help="Override output dir for this stage. By default, writes to <run-dir>/02_integrate/."),
    method: str = typer.Option("harmony", "--method", help="Integration method: harmony / rpca / cca / none."),
    sample_key: str | None = typer.Option(None, "--sample-key", help="obs column naming the sample/batch (default: auto-detect orig.ident / sample / batch / donor)."),
    n_pcs: int = typer.Option(30, "--n-pcs", help="Number of PCA components."),
    resolutions: str = typer.Option(
        "0.1,0.3,0.5,0.8,1.0",
        "--resolutions",
        help="Comma-separated Leiden resolutions, or 'aio' for the AIO 13-step sweep.",
    ),
    regress_cell_cycle: bool = typer.Option(False, "--regress-cell-cycle/--no-regress-cell-cycle", help="Score and regress out S/G2M cell-cycle effect."),
    species: str = typer.Option("human", "--species", help="'human' or 'mouse' (drives cell-cycle gene-list selection)."),
    drop_qc_fail: bool = typer.Option(True, "--drop-qc-fail/--keep-qc-fail", help="Drop cells with scellrun_qc_pass=False before integration."),
    write_h5ad: bool = typer.Option(True, "--write-h5ad/--no-write-h5ad", help="Write integrated.h5ad with PCA/UMAP/clusters attached."),
    force: bool = typer.Option(False, "--force/--no-force", help="Overwrite existing 02_integrate/ artifacts."),
    lang: str = typer.Option("en", "--lang", help="Report language: 'en' or 'zh'."),
) -> None:
    """
    Cross-sample integration with multi-resolution Leiden clustering.

    Reads a QC'd h5ad, normalizes + scales, runs PCA, integrates (Harmony
    by default) if a sample key is detected, then sweeps clustering at
    several resolutions. Outputs integrated.h5ad + a UMAP grid + report.

    Maps to AIO stage 4 + Rmd § 6-8.
    """
    import anndata as ad

    from scellrun.runlayout import (
        StageOutputExists,
        default_run_dir,
        stage_dir,
        write_run_meta,
    )
    from scellrun.scrna.integrate import (
        AIO_FULL_RESOLUTIONS,
        DEFAULT_RESOLUTIONS,
        IntegrationError,
        run_integrate,
        write_artifacts,
    )

    if method not in ("harmony", "rpca", "cca", "none"):
        console.print(f"[red]error:[/red] --method must be one of harmony/rpca/cca/none, got {method!r}")
        raise typer.Exit(2) from None
    if species not in ("human", "mouse"):
        console.print(f"[red]error:[/red] --species must be 'human' or 'mouse', got {species!r}")
        raise typer.Exit(2) from None
    if lang not in ("en", "zh"):
        console.print(f"[red]error:[/red] --lang must be 'en' or 'zh', got {lang!r}")
        raise typer.Exit(2) from None

    if resolutions == "aio":
        res_tuple = AIO_FULL_RESOLUTIONS
    elif resolutions == "default":
        res_tuple = DEFAULT_RESOLUTIONS
    else:
        try:
            res_tuple = tuple(float(x) for x in resolutions.split(",") if x.strip())
        except ValueError:
            console.print(f"[red]error:[/red] could not parse --resolutions {resolutions!r}")
            raise typer.Exit(2) from None
    if not res_tuple:
        console.print("[red]error:[/red] --resolutions must list at least one value")
        raise typer.Exit(2) from None

    # Default run-dir: assume h5ad lives under <run-dir>/01_qc/, walk up two levels
    if run_dir is None:
        if h5ad.parent.name == "01_qc":
            run_dir = h5ad.parent.parent
        else:
            run_dir = default_run_dir()

    if out is not None:
        out_dir = out
        out_dir.mkdir(parents=True, exist_ok=True)
    else:
        try:
            out_dir = stage_dir(run_dir, "integrate", force=force)
        except StageOutputExists as e:
            console.print(f"[red]error:[/red] {e}")
            raise typer.Exit(2) from None

    console.print(
        f"[bold]scellrun scrna integrate[/bold]  •  method=[cyan]{method}[/cyan]  "
        f"species=[cyan]{species}[/cyan]"
    )
    console.print(f"run-dir: [dim]{run_dir}[/dim]")
    console.print(f"out-dir: [dim]{out_dir}[/dim]")
    console.print(f"reading [dim]{h5ad}[/dim]")

    adata = ad.read_h5ad(h5ad)
    console.print(f"loaded: {adata.n_obs:,} cells × {adata.n_vars:,} genes")

    try:
        result, integrated = run_integrate(
            adata,
            method=method,
            sample_key=sample_key,
            n_pcs=n_pcs,
            resolutions=res_tuple,
            regress_cell_cycle=regress_cell_cycle,
            species=species,
            drop_qc_fail=drop_qc_fail,
        )
    except (IntegrationError, NotImplementedError) as e:
        console.print(f"[red]error:[/red] {e}")
        raise typer.Exit(1) from None

    console.print(f"used [bold green]{result.n_cells_used:,}[/bold green] / {result.n_cells_in:,} cells")
    if result.sample_key:
        console.print(f"sample key: {result.sample_key} ({integrated.obs[result.sample_key].nunique()} levels)")
    else:
        console.print("sample key: [dim](none — single-batch run)[/dim]")
    console.print(f"clusters per resolution: {dict(result.cluster_counts)}")

    artifacts = write_artifacts(result, integrated, out_dir, write_h5ad=write_h5ad, lang=lang)
    write_run_meta(
        run_dir,
        command="scrna integrate",
        params={
            "h5ad": h5ad,
            "out_dir": out_dir,
            "method": method,
            "sample_key": result.sample_key,
            "n_pcs": n_pcs,
            "resolutions": list(res_tuple),
            "regress_cell_cycle": regress_cell_cycle,
            "species": species,
            "drop_qc_fail": drop_qc_fail,
            "force": force,
            "lang": lang,
        },
    )

    console.print(f"[bold]report:[/bold] [link=file://{artifacts['report'].resolve()}]{artifacts['report']}[/link]")
    console.print(f"UMAP grid: {artifacts['umap_grid']}")
    if "integrated_h5ad" in artifacts:
        console.print(f"integrated h5ad: {artifacts['integrated_h5ad']}")


@scrna_app.command("markers")
def scrna_markers(
    h5ad: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="Input integrated .h5ad (typically <run-dir>/02_integrate/integrated.h5ad)."),
    run_dir: Path | None = typer.Option(None, "--run-dir", help="Run root directory. Default: parent of <h5ad>'s 02_integrate/ dir, else fresh."),
    out: Path | None = typer.Option(None, "--out", "-o", help="Override output dir. By default writes to <run-dir>/03_markers/."),
    resolutions: str | None = typer.Option(None, "--resolutions", help="Comma-separated resolutions (e.g. '0.3,0.5'). Default: all leiden_res_* columns present in the h5ad."),
    logfc_threshold: float = typer.Option(1.0, "--logfc-threshold", help="Minimum |log2 fold-change| to keep a marker."),
    pct_min: float = typer.Option(0.25, "--pct-min", help="Minimum fraction of cells in a cluster expressing the gene."),
    only_positive: bool = typer.Option(True, "--only-positive/--all-direction", help="Keep only positive (cluster-up) markers."),
    top_n: int = typer.Option(10, "--top-n", help="How many top markers per cluster to show in the HTML report (CSV always full)."),
    force: bool = typer.Option(False, "--force/--no-force", help="Overwrite existing 03_markers/ artifacts."),
    lang: str = typer.Option("en", "--lang", help="Report language: 'en' or 'zh'."),
) -> None:
    """
    Per-cluster differential markers across all (or specified) clustering
    resolutions in an integrated h5ad. Wilcoxon rank-sum, logfc>=1, pct>=0.25,
    positive-only by default — same defaults the in-house pipeline uses.

    Maps to AIO stage 5 (FindAllMarkers) + Rmd § 10 first block.
    """
    import anndata as ad

    from scellrun.runlayout import (
        StageOutputExists,
        default_run_dir,
        stage_dir,
        write_run_meta,
    )
    from scellrun.scrna.markers import run_markers, write_artifacts

    if lang not in ("en", "zh"):
        console.print(f"[red]error:[/red] --lang must be 'en' or 'zh', got {lang!r}")
        raise typer.Exit(2) from None

    if resolutions is not None:
        try:
            res_tuple: tuple[float, ...] | None = tuple(
                float(x) for x in resolutions.split(",") if x.strip()
            )
        except ValueError:
            console.print(f"[red]error:[/red] could not parse --resolutions {resolutions!r}")
            raise typer.Exit(2) from None
        if not res_tuple:
            console.print("[red]error:[/red] --resolutions must list at least one value")
            raise typer.Exit(2) from None
    else:
        res_tuple = None

    if run_dir is None:
        if h5ad.parent.name == "02_integrate":
            run_dir = h5ad.parent.parent
        else:
            run_dir = default_run_dir()

    if out is not None:
        out_dir = out
        out_dir.mkdir(parents=True, exist_ok=True)
    else:
        try:
            out_dir = stage_dir(run_dir, "markers", force=force)
        except StageOutputExists as e:
            console.print(f"[red]error:[/red] {e}")
            raise typer.Exit(2) from None

    console.print(
        f"[bold]scellrun scrna markers[/bold]  •  "
        f"logfc≥{logfc_threshold}  pct≥{pct_min}  "
        f"only_positive={only_positive}"
    )
    console.print(f"run-dir: [dim]{run_dir}[/dim]")
    console.print(f"out-dir: [dim]{out_dir}[/dim]")
    console.print(f"reading [dim]{h5ad}[/dim]")

    adata = ad.read_h5ad(h5ad)
    console.print(f"loaded: {adata.n_obs:,} cells × {adata.n_vars:,} genes")

    try:
        result, per_res_df = run_markers(
            adata,
            resolutions=res_tuple,
            logfc_threshold=logfc_threshold,
            pct_min=pct_min,
            only_positive=only_positive,
            top_n_per_cluster=top_n,
        )
    except ValueError as e:
        console.print(f"[red]error:[/red] {e}")
        raise typer.Exit(1) from None

    for res, n in result.n_markers_per_resolution.items():
        console.print(f"  res={res:g}: {n:,} markers across {result.cluster_counts[res]} clusters")

    artifacts = write_artifacts(result, per_res_df, out_dir, lang=lang)
    write_run_meta(
        run_dir,
        command="scrna markers",
        params={
            "h5ad": h5ad,
            "out_dir": out_dir,
            "resolutions": list(result.resolutions),
            "logfc_threshold": logfc_threshold,
            "pct_min": pct_min,
            "only_positive": only_positive,
            "top_n": top_n,
            "force": force,
            "lang": lang,
        },
    )

    console.print(f"[bold]report:[/bold] [link=file://{artifacts['report'].resolve()}]{artifacts['report']}[/link]")
    for key, p in artifacts.items():
        if key.startswith("markers_res_"):
            console.print(f"  {p}")


@profiles_app.command("list")
def profiles_list() -> None:
    """List available profiles."""
    from scellrun.profiles import list_profiles

    for name in list_profiles():
        console.print(f"  • {name}")


@profiles_app.command("show")
def profiles_show(
    name: str = typer.Argument("default", help="Profile name."),
) -> None:
    """Show the thresholds and panels (if any) in a profile."""
    from scellrun.profiles import load as load_profile

    try:
        mod = load_profile(name)
    except ModuleNotFoundError:
        console.print(f"[red]error:[/red] unknown profile {name!r}.")
        raise typer.Exit(2) from None

    console.print(f"[bold]profile:[/bold] {name}")
    for attr in ("scrna_qc", "snrna_qc"):
        if hasattr(mod, attr):
            console.print(f"  [cyan]{attr}[/cyan]: {getattr(mod, attr)}")

    for panel_attr in ("chondrocyte_markers", "celltype_broad"):
        if hasattr(mod, panel_attr):
            panel = getattr(mod, panel_attr)
            console.print(f"\n  [cyan]{panel_attr}[/cyan] ({len(panel)} groups):")
            for label, genes in panel.items():
                console.print(f"    {label:10s} {', '.join(genes)}")


if __name__ == "__main__":
    app(prog_name="scellrun")
