"""Tests for ketacli/sdk/request/api/dashboard.yaml resource config.

Covers: path resolution (all 4 methods), template rendering,
fuzzy matching, default fields, create data structure.
"""

import json
import time
from pathlib import Path

import pytest
import yaml
from jinja2 import Environment, StrictUndefined
from jinja2.exceptions import UndefinedError

from ketacli.sdk.request.asset_map import get_request_path, get_resource


# =============================================================================
# TestDashboardPathResolution
# =============================================================================


class TestDashboardPathResolution:
    """Tests for get_request_path() with dashboard config."""

    def test_list_method(self, mocker):
        mock = {
            "dashboard": {
                "path": "dashboard",
                "methods": {
                    "list": {"path": "dashboard", "method": "get"},
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock,
        )
        path, method, data = get_request_path("dashboard", "list")
        assert path == "dashboard"
        assert method == "get"
        assert data == {}

    def test_get_method(self, mocker):
        mock = {
            "dashboard": {
                "path": "dashboard",
                "methods": {
                    "get": "dashboard",
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock,
        )
        path, method, data = get_request_path("dashboard", "get")
        assert path == "dashboard"
        assert method == "get"
        assert data == {}

    def test_create_method(self, mocker):
        mock = {
            "dashboard": {
                "path": "dashboard",
                "methods": {
                    "create": {
                        "path": "dashboard/{{ id }}",
                        "method": "put",
                        "data": {"id": "{{ id }}"},
                    },
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock,
        )
        path, method, data = get_request_path("dashboard", "create")
        assert path == "dashboard/{{ id }}"
        assert method == "put"
        assert data != {}

    def test_delete_method(self, mocker):
        mock = {
            "dashboard": {
                "path": "dashboard",
                "methods": {
                    "delete": {
                        "path": "dashboard:batchDelete",
                        "method": "post",
                        "data": {"names": ["{{ name }}"]},
                    },
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock,
        )
        path, method, data = get_request_path("dashboard", "delete")
        assert path == "dashboard:batchDelete"
        assert method == "post"


# =============================================================================
# TestDashboardTemplateRendering
# =============================================================================


class TestDashboardTemplateRendering:
    """Tests for Jinja2 template rendering of dashboard create data."""

    def _load_create_data(self):
        api_dir = (
            Path(__file__).parent.parent
            / "ketacli"
            / "sdk"
            / "request"
            / "api"
        )
        with open(api_dir / "dashboard.yaml") as f:
            config = yaml.safe_load(f)
        return config["dashboard"]["methods"]["create"]["data"]

    def test_template_render_success(self):
        data = self._load_create_data()
        template_str = json.dumps(data)
        env = Environment(undefined=StrictUndefined, autoescape=False)
        env.globals['int'] = int
        env.globals['time'] = time
        template = env.from_string(template_str)
        result = template.render(id="test-001", title="Test", app="search", xml_content="<v-root>test</v-root>")
        rendered = json.loads(result)

        assert rendered["dashboardType"] == "xml"
        assert isinstance(rendered["xml"], str) and len(rendered["xml"]) > 0
        assert "operationBarToken" in rendered["xmlVariables"]
        assert "interval" in rendered["xmlVariables"]

    def test_template_render_missing_id(self):
        data = self._load_create_data()
        template_str = json.dumps(data)
        env = Environment(undefined=StrictUndefined, autoescape=False)
        env.globals['int'] = int
        env.globals['time'] = time
        template = env.from_string(template_str)

        with pytest.raises(UndefinedError):
            template.render(xml_content="<v-root>test</v-root>")


# =============================================================================
# TestDashboardFuzzyMatching
# =============================================================================


class TestDashboardFuzzyMatching:
    """Tests for fuzzy key matching with dashboard resource."""

    def test_fuzzy_plural_match(self, mocker):
        mock = {
            "dashboard": {
                "path": "dashboard",
                "methods": {
                    "list": {"path": "dashboard", "method": "get"},
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock,
        )
        path, method, data = get_request_path("dashboards", "list")
        assert path == "dashboard"
        assert method == "get"


# =============================================================================
# TestDashboardDefaultFields
# =============================================================================


class TestDashboardDefaultFields:
    """Tests for default_fields in dashboard list config."""

    def test_default_fields_exist(self, mocker):
        mock = {
            "dashboard": {
                "path": "dashboard",
                "methods": {
                    "list": {
                        "path": "dashboard",
                        "method": "get",
                        "default_fields": [
                            {"name": "id"},
                            {"name": "name"},
                            {"name": "title"},
                            {"name": "app"},
                            {"name": "dashboardType"},
                            {"name": "updateTime"},
                        ],
                    },
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock,
        )
        resource = get_resource("dashboard")
        default_fields = resource["methods"]["list"]["default_fields"]
        field_names = [f["name"] for f in default_fields]
        for field in ["id", "name", "title", "app", "dashboardType", "updateTime"]:
            assert field in field_names


# =============================================================================
# TestDashboardCreateData
# =============================================================================


class TestDashboardCreateData:
    """Tests for the create method's data structure."""

    def test_create_data_structure(self, mocker):
        mock = {
            "dashboard": {
                "path": "dashboard",
                "methods": {
                    "create": {
                        "path": "dashboard/{{ id }}",
                        "method": "put",
                        "data": {
                            "preset": 2,
                            "scope": "app",
                            "dashboardType": "xml",
                            "operations": ["list", "edit"],
                            "appOperations": ["list", "create"],
                            "tag": False,
                            "fragment": True,
                            "groupResId": "{{ id }}",
                            "charts": [],
                            "variables": [],
                            "options": None,
                        },
                    },
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock,
        )
        _, _, data = get_request_path("dashboard", "create")
        for key in [
            "preset",
            "scope",
            "dashboardType",
            "operations",
            "appOperations",
            "tag",
            "fragment",
            "groupResId",
            "charts",
            "variables",
            "options",
        ]:
            assert key in data
