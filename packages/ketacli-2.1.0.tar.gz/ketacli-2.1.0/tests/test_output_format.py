"""Tests for ketacli.sdk.output.format — OutputTable, prettify_value, make_*, format_table."""

import json
import re

from rich.table import Table

from ketacli.sdk.output.format import (
    OutputTable,
    format_table,
    make_records_to_table,
    make_table,
    prettify_value,
)


# =========================================================================
# OutputTable — init
# =========================================================================


class TestOutputTableInit:
    def test_with_header_and_rows(self):
        table = OutputTable(["a", "b"], [[1, 2], [3, 4]])
        assert table.header == ["a", "b"]
        assert table.rows == [[1, 2], [3, 4]]

    def test_header_only_empty_rows_default(self):
        table = OutputTable(["x", "y", "z"])
        assert table.header == ["x", "y", "z"]
        assert table.rows == []

    def test_header_only_with_explicit_empty_rows(self):
        table = OutputTable(["x"], [])
        assert table.header == ["x"]
        assert table.rows == []


# =========================================================================
# OutputTable — add_row / add_rows
# =========================================================================


class TestOutputTableAddRow:
    def test_add_single_row(self):
        table = OutputTable(["a", "b"])
        table.add_row([10, 20])
        assert len(table.rows) == 1
        assert table.rows[0] == [10, 20]

    def test_add_multiple_rows_individually(self):
        table = OutputTable(["a"])
        table.add_row([1])
        table.add_row([2])
        table.add_row([3])
        assert len(table.rows) == 3


class TestOutputTableAddRows:
    def test_add_multiple_rows_at_once(self):
        table = OutputTable(["a", "b"])
        table.add_rows([[1, 2], [3, 4], [5, 6]])
        assert len(table.rows) == 3
        assert table.rows == [[1, 2], [3, 4], [5, 6]]

    def test_add_rows_empty_list(self):
        table = OutputTable(["a"], [[1]])
        table.add_rows([])
        assert len(table.rows) == 1


# =========================================================================
# prettify_value
# =========================================================================


class TestPrettifyValue:
    def test_none_returns_none(self):
        assert prettify_value("any_key", None) is None

    def test_key_ending_in_time_with_int_returns_datestamp(self):
        result = prettify_value("createTime", 1700000000000)
        assert isinstance(result, str)
        assert re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", result)

    def test_key_ending_in_time_lowercase_matches(self):
        result = prettify_value("updatetime", 1700000000000)
        assert isinstance(result, str)
        assert re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", result)

    def test_key_with_time_mixed_case_matches(self):
        result = prettify_value("Update_Time", 1700000000000)
        assert isinstance(result, str)
        assert re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", result)

    def test_string_unchanged(self):
        assert prettify_value("name", "hello") == "hello"

    def test_int_unchanged(self):
        assert prettify_value("count", 42) == 42

    def test_bool_unchanged(self):
        assert prettify_value("active", True) is True
        assert prettify_value("active", False) is False

    def test_float_unchanged(self):
        assert prettify_value("rate", 3.14) == 3.14

    def test_dict_converted_to_json(self):
        result = prettify_value("metadata", {"a": 1, "b": "two"})
        assert isinstance(result, str)
        assert json.loads(result) == {"a": 1, "b": "two"}

    def test_list_converted_to_json(self):
        result = prettify_value("tags", ["x", "y", "z"])
        assert isinstance(result, str)
        assert json.loads(result) == ["x", "y", "z"]

    def test_int_with_non_time_key_stays_int(self):
        assert prettify_value("count", 1700000000000) == 1700000000000


# =========================================================================
# make_records_to_table
# =========================================================================


class TestMakeRecordsToTable:
    def test_with_header_and_records(self):
        records = [{"name": "foo", "value": 1}, {"name": "bar", "value": 2}]
        table = make_records_to_table(["name", "value"], records)
        assert table is not None
        assert table.header == ["name", "value"]
        assert len(table.rows) == 2
        assert table.rows[0] == ["foo", 1]

    def test_auto_header_from_first_record(self):
        records = [{"name": "a", "val": 10}]
        table = make_records_to_table([], records)
        assert table is not None
        assert "name" in table.header
        assert "val" in table.header
        assert table.rows[0] == ["a", 10]

    def test_empty_records_empty_table(self):
        table = make_records_to_table(["h"], [])
        assert table is not None
        assert table.header == ["h"]
        assert table.rows == []

    def test_empty_header_and_empty_records_returns_none(self):
        result = make_records_to_table([], [])
        assert result is None

    def test_dict_header_with_aliases(self):
        header_config = [{"name": "real_name", "alias": "Display Name"}]
        records = [{"real_name": "hello"}]
        table = make_records_to_table(
            header_config, records, field_aliases={"real_name": "Display Name"}
        )
        assert table is not None
        assert table.header == ["Display Name"]
        assert table.rows[0] == ["hello"]

    def test_dict_header_with_field_aliases_arg(self):
        header = ["a"]
        records = [{"a": 1}]
        field_aliases = {"a": "AAA"}
        table = make_records_to_table(header, records, field_aliases=field_aliases)
        assert table is not None
        assert table.header == ["AAA"]
        assert table.rows[0] == [1]

    def test_mixed_dict_and_string_header(self):
        header_config = [{"name": "real_name", "alias": "Name"}, "extra"]
        records = [{"real_name": "hello", "extra": "world"}]
        table = make_records_to_table(
            header_config, records, field_aliases={"real_name": "Name"}
        )
        assert table is not None
        assert table.header == ["Name", "extra"]
        assert table.rows[0] == ["hello", "world"]

    def test_missing_field_in_record_is_none(self):
        records = [{"name": "x"}]
        table = make_records_to_table(["name", "extra"], records)
        assert table is not None
        assert table.rows[0] == ["x", None]

    def test_field_converters_applied(self):
        records = [{"name": "test", "value": 1234.5678}]
        field_converters = {
            "value": {"function": "format_number", "args": [{"precision": 0}]}
        }
        table = make_records_to_table(
            ["name", "value"], records, field_converters=field_converters
        )
        assert table is not None
        assert table.rows[0][1] == "1,234"

    def test_raw_output_skips_converters(self):
        records = [{"name": "test", "value": 1234.5678}]
        field_converters = {
            "value": {"function": "format_number", "args": [{"precision": 0}]}
        }
        table = make_records_to_table(
            ["name", "value"],
            records,
            field_converters=field_converters,
            raw_output=True,
        )
        assert table is not None
        assert table.rows[0][1] == 1234.5678

    def test_raw_output_skips_aliases(self):
        records = [{"a": 1}]
        field_aliases = {"a": "Aliased"}
        table = make_records_to_table(
            ["a"], records, field_aliases=field_aliases, raw_output=True
        )
        assert table is not None
        assert table.header == ["a"]


# =========================================================================
# make_table
# =========================================================================


class TestMakeTable:
    def test_normal_data(self):
        table = make_table(["x", "y"], [[1, 2], [3, 4]])
        assert table.header == ["x", "y"]
        assert table.rows == [[1, 2], [3, 4]]

    def test_transpose_true(self):
        table = make_table(["name", "value"], [["a", 1]], transpose=True)
        assert table.header == ["Field Name", "Values"]
        assert len(table.rows) == 2
        assert table.rows[0] == ["name", "a"]
        assert table.rows[1] == ["value", 1]

    def test_empty_header_and_rows(self):
        table = make_table([], [])
        assert table.header == []
        assert table.rows == []

    def test_default_none_args(self):
        table = make_table()
        assert table.header == []
        assert table.rows == []

    def test_default_rows_none(self):
        table = make_table(["a"])
        assert table.header == ["a"]
        assert table.rows == []


# =========================================================================
# format_table
# =========================================================================


class TestFormatTable:
    def test_default_format_is_table(self):
        t = OutputTable(["a", "b"], [[1, 2]])
        result = format_table(t)
        assert isinstance(result, Table)

    def test_format_table_returns_rich_table(self):
        t = OutputTable(["x"], [["hello"]])
        result = format_table(t, "table")
        assert isinstance(result, Table)

    def test_format_json_returns_json_string(self):
        t = OutputTable(["a", "b"], [[1, "two"], [3, "four"]])
        result = format_table(t, "json")
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert isinstance(parsed, list)
        assert len(parsed) == 2
        assert parsed[0] == {"a": 1, "b": "two"}

    def test_format_json_omits_none_values(self):
        t = OutputTable(["a", "b"], [[1, None]])
        result = format_table(t, "json")
        parsed = json.loads(result)
        assert len(parsed) == 1
        assert "b" not in parsed[0]
        assert parsed[0] == {"a": 1}

    def test_format_text_returns_string(self):
        t = OutputTable(["a"], [[1]])
        result = format_table(t, "text")
        assert isinstance(result, str)
        assert "a" in result
        assert "1" in result

    def test_prettify_converts_time_values(self):
        t = OutputTable(["createTime", "name"], [[1700000000000, "test"]])
        result = format_table(t, "json", prettify=True)
        parsed = json.loads(result)
        assert isinstance(parsed[0]["createTime"], str)
        assert re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", parsed[0]["createTime"])
        assert parsed[0]["name"] == "test"

    def test_raw_output_skips_prettify(self):
        t = OutputTable(["createTime"], [[1700000000000]])
        result = format_table(t, "json", prettify=True, raw_output=True)
        parsed = json.loads(result)
        assert parsed[0]["createTime"] == 1700000000000

    def test_prettify_false_skips_prettify(self):
        t = OutputTable(["createTime"], [[1700000000000]])
        result = format_table(t, "json", prettify=False)
        parsed = json.loads(result)
        assert parsed[0]["createTime"] == 1700000000000


# =========================================================================
# OutputTable — prettify method
# =========================================================================


class TestOutputTablePrettify:
    def test_prettify_returns_new_table_with_converted_values(self):
        t = OutputTable(["createTime", "label"], [[1700000000000, "hello"]])
        prettified = t.prettify()
        assert t.rows[0][0] == 1700000000000
        assert isinstance(prettified.rows[0][0], str)
        assert re.match(
            r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$", prettified.rows[0][0]
        )
        assert prettified.rows[0][1] == "hello"
        assert prettified.header == t.header

    def test_prettify_handles_rows_shorter_than_header(self):
        t = OutputTable(["a", "b", "c"], [[1, 2]])
        prettified = t.prettify()
        assert prettified.rows[0] == [1, 2]


# =========================================================================
# OutputTable — get_json_string
# =========================================================================


class TestOutputTableGetJsonString:
    def test_get_json_string_valid_json(self):
        t = OutputTable(["a", "b"], [[1, 2], [3, 4]])
        result = t.get_json_string()
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0] == {"a": 1, "b": 2}

    def test_get_json_string_sorts_keys(self):
        t = OutputTable(["z", "a"], [[1, 2]])
        result = t.get_json_string()
        parsed = json.loads(result)
        keys = list(parsed[0].keys())
        assert keys == ["a", "z"]


# =========================================================================
# OutputTable — get_formatted_string
# =========================================================================


class TestOutputTableGetFormattedString:
    def test_table_format_returns_rich_table(self):
        t = OutputTable(["x"], [["val"]])
        result = t.get_formatted_string("table")
        assert isinstance(result, Table)

    def test_text_format_returns_string(self):
        t = OutputTable(["x"], [["val"]])
        result = t.get_formatted_string("text")
        assert isinstance(result, str)
        assert "x" in result
        assert "val" in result

    def test_toon_format_returns_string(self):
        t = OutputTable(["a"], [[1]])
        result = t.get_formatted_string("toon")
        assert isinstance(result, str)


# =========================================================================
# OutputTable — get_pretty_table
# =========================================================================


class TestOutputTableGetPrettyTable:
    def test_returns_prettytable(self):
        from prettytable import PrettyTable

        t = OutputTable(["a"], [[1]])
        pt = t.get_pretty_table()
        assert isinstance(pt, PrettyTable)
