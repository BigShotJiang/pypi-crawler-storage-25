"""Tests for ketacli.sdk.util module.

Covers: is_key, is_fuzzy_key, parse_url_params, format_bytes (standalone),
Template.render, Template.batch_render, and template error handling.
"""

import pytest
from ketacli.sdk.util import (
    Template,
    format_bytes,
    is_fuzzy_key,
    is_key,
    parse_url_params,
)

# =============================================================================
# is_key
# =============================================================================


class TestIsKey:
    """Tests for is_key()."""

    def test_exact_match(self):
        """Exact key match returns the lowered key."""
        assert is_key("name", {"name": "test"}) == "name"

    def test_case_insensitive(self):
        """Case-insensitive match returns the lowered input key."""
        assert is_key("Name", {"name": "test"}) == "name"

    def test_missing_key(self):
        """Missing key returns None."""
        assert is_key("foo", {"name": "test"}) is None

    def test_empty_map(self):
        """Empty dict returns None."""
        assert is_key("name", {}) is None

    def test_none_map_defaults_to_empty(self):
        """Default value_map=None becomes {} so missing key returns None."""
        assert is_key("anything") is None


# =============================================================================
# is_fuzzy_key
# =============================================================================


class TestIsFuzzyKey:
    """Tests for is_fuzzy_key()."""

    def test_exact_match(self):
        """Exact match returns the lowered key."""
        assert is_fuzzy_key("name", {"name": "test"}) == "name"

    def test_plural_matching(self):
        """Singular input 'repo' should match plural map key 'repos'."""
        assert is_fuzzy_key("repo", {"repos": ["item1"]}) == "repos"

    def test_singular_matching(self):
        """Plural input 'repos' should match singular map key 'repo'."""
        assert is_fuzzy_key("repos", {"repo": ["item1"]}) == "repo"

    def test_exact_match_takes_precedence(self):
        """When both exact and fuzzy match exist, exact wins."""
        result = is_fuzzy_key("repos", {"repos": ["items"], "repo": ["item"]})
        assert result == "repos"

    def test_missing_key(self):
        """No match at all returns None."""
        assert is_fuzzy_key("foo", {"name": "test"}) is None

    def test_none_map_defaults_to_empty(self):
        """Default value_map=None becomes {} so returns None."""
        assert is_fuzzy_key("anything") is None

    def test_word_not_ending_in_s_becomes_plural(self):
        """A key not ending in 's' gets an 's' appended for fuzzy lookup."""
        assert is_fuzzy_key("friend", {"friends": ["a"]}) == "friends"

    def test_word_ending_in_s_gets_singularized(self):
        """A key ending in 's' has the 's' removed for fuzzy lookup."""
        assert is_fuzzy_key("cats", {"cat": ["a"]}) == "cat"


# =============================================================================
# parse_url_params
# =============================================================================


class TestParseUrlParams:
    """Tests for parse_url_params()."""

    def test_basic_key_value_pairs(self):
        """Comma-separated key=value pairs are parsed into a dict."""
        assert parse_url_params("k1=v1,k2=v2") == {"k1": "v1", "k2": "v2"}

    def test_leading_question_mark_is_stripped(self):
        """A leading '?' is automatically removed before parsing."""
        assert parse_url_params("?a=1,b=2") == {"a": 1, "b": 2}

    def test_numeric_auto_conversion_int(self):
        """Values that look like integers are converted to int."""
        result = parse_url_params("a=123")
        assert result == {"a": 123}
        assert isinstance(result["a"], int)

    def test_numeric_auto_conversion_float(self):
        """Values with a dot are converted to float."""
        result = parse_url_params("b=45.6")
        assert result == {"b": 45.6}
        assert isinstance(result["b"], float)

    def test_mixed_types(self):
        """String, int, and float values coexist in the result dict."""
        result = parse_url_params("a=hello,b=42,c=3.14")
        assert result == {"a": "hello", "b": 42, "c": 3.14}
        assert isinstance(result["b"], int)
        assert isinstance(result["c"], float)

    def test_single_pair(self):
        """A single key=value pair works correctly."""
        assert parse_url_params("name=test") == {"name": "test"}

    def test_empty_raises_valueerror(self):
        """Empty string raises ValueError (no pairs to split)."""
        with pytest.raises(ValueError):
            parse_url_params("")


# =============================================================================
# format_bytes (standalone function in util.py)
# =============================================================================


class TestFormatBytes:
    """Tests for format_bytes() — the standalone utility function."""

    def test_zero_bytes(self):
        assert format_bytes(0) == "0.00 B"

    def test_kilobytes(self):
        assert format_bytes(1024) == "1.00 KB"

    def test_megabytes(self):
        assert format_bytes(1048576) == "1.00 MB"

    def test_gigabytes(self):
        assert format_bytes(1073741824) == "1.00 GB"

    def test_terabytes(self):
        assert format_bytes(1099511627776) == "1.00 TB"

    def test_partial_kb(self):
        """Values under 1024 stay in bytes."""
        result = format_bytes(500)
        assert result == "500.00 B"

    def test_fractional_kb(self):
        """Values over 1024 show as fractional KB."""
        assert format_bytes(1536) == "1.50 KB"

    def test_almost_kb_stays_in_bytes(self):
        """1023 is still under 1024, so it stays in 'B'."""
        assert format_bytes(1023) == "1023.00 B"

    def test_large_value_trillions(self):
        """Very large numbers convert to TB."""
        assert format_bytes(2 * 1099511627776) == "2.00 TB"


# =============================================================================
# Template — render
# =============================================================================


class TestTemplateRender:
    """Tests for Template.render()."""

    @pytest.fixture(autouse=True)
    def _mock_faker(self, mocker):
        """Mock Faker to avoid slow Faker initialization in every test."""
        mocker.patch("ketacli.sdk.util.Faker")

    def test_simple_substitution(self):
        """Simple {{ variable }} is substituted correctly."""
        t = Template("Hello {{ name }}")
        assert t.render(name="World") == "Hello World"

    def test_multiple_variables(self):
        """Multiple variables in a template are all substituted."""
        t = Template("{{a}}|{{b}}|{{c}}")
        assert t.render(a="x", b="y", c="z") == "x|y|z"

    def test_no_variables(self):
        """Template with no variables renders verbatim."""
        t = Template("static text")
        assert t.render() == "static text"

    def test_template_cache_reuses_objects(self):
        """Same template string reuses cached env and temp objects."""
        t1 = Template("Cache me {{ name }}")
        t2 = Template("Cache me {{ name }}")
        assert t2.temp is t1.temp, "cached Template.temp should be identical"
        assert t2.env is t1.env, "cached Template.env should be identical"

    def test_different_templates_are_not_shared(self):
        """Different template strings get separate cache entries."""
        t1 = Template("Alpha {{ x }}")
        t2 = Template("Beta {{ x }}")
        assert t2.temp is not t1.temp

    def test_render_with_numeric_value(self):
        """Numeric values are converted to string by Jinja2."""
        t = Template("count={{ n }}")
        assert t.render(n=42) == "count=42"


class TestTemplateRenderWithVariables:
    """Tests for Template.render() with built-in variables
    (time, random, faker, faker_zh)."""

    @pytest.fixture(autouse=True)
    def _mock_faker(self, mocker):
        """Mock Faker to avoid slow Faker initialization in every test."""
        mocker.patch("ketacli.sdk.util.Faker")

    def test_time_variable(self, mocker):
        """The 'time' module is available inside templates."""
        mock_time = mocker.patch("ketacli.sdk.util.time")
        mock_time.time.return_value = 1609459200
        t = Template("{{ time.time() }}")
        assert t.render() == "1609459200"

    def test_random_variable(self, mocker):
        """The 'random' module is available inside templates."""
        mock_random = mocker.patch("ketacli.sdk.util.random")
        mock_random.randint.return_value = 42
        t = Template("{{ random.randint(1, 100) }}")
        assert t.render() == "42"

    def test_faker_variable(self, mocker):
        """The 'faker' (en_US) variable is mocked to return predictable values."""
        mock_instance = mocker.MagicMock()
        mock_instance.name.return_value = "John Doe"
        mocker.patch("ketacli.sdk.util.Faker", return_value=mock_instance)
        t = Template("{{ faker.name() }}")
        assert t.render() == "John Doe"

    def test_faker_zh_variable(self, mocker):
        """The 'faker_zh' (zh_CN) variable is mocked to return predictable values."""
        mock_instance = mocker.MagicMock()
        mock_instance.name.return_value = "张三"
        mocker.patch("ketacli.sdk.util.Faker", return_value=mock_instance)
        t = Template("{{ faker_zh.name() }}")
        assert t.render() == "张三"


class TestTemplateRenderError:
    """Tests for Template.render() error handling — missing variables."""

    @pytest.fixture(autouse=True)
    def _mock_faker(self, mocker):
        """Mock Faker to avoid slow Faker initialization in every test."""
        mocker.patch("ketacli.sdk.util.Faker")

    def test_missing_variable_raises_system_exit(self, mocker):
        """Missing variable triggers exit(1) -> SystemExit(1)."""
        mocker.patch("rich.console.Console.print")
        t = Template("Hello {{ name }}")
        with pytest.raises(SystemExit) as exc_info:
            t.render()
        assert exc_info.value.code == 1

    def test_error_message_is_printed_to_console(self, mocker):
        """Before exit, an error message is printed via Console.print()."""
        mock_print = mocker.patch("rich.console.Console.print")
        t = Template("Hello {{ name }}")
        with pytest.raises(SystemExit):
            t.render()
        mock_print.assert_called_once()
        args, _ = mock_print.call_args
        rendered = str(args[0])
        assert "Template rendering failed" in rendered
        assert "Hello {{ name }}" in rendered


class TestTemplateBatchRender:
    """Tests for Template.batch_render()."""

    @pytest.fixture(autouse=True)
    def _mock_faker(self, mocker):
        """Mock Faker to avoid slow Faker initialization in every test."""
        mocker.patch("ketacli.sdk.util.Faker")

    def test_batch_render_count(self):
        """batch_render returns the requested number of results."""
        t = Template("hello")
        results = t.batch_render(5)
        assert len(results) == 5

    def test_batch_render_all_identical(self):
        """All results from a static template are identical."""
        t = Template("hello")
        results = t.batch_render(3)
        assert all(r == "hello" for r in results)

    def test_batch_render_render_false(self):
        """With render=False, raw template strings are returned."""
        t = Template("hello {{ name }}")
        results = t.batch_render(3, render=False)
        assert len(results) == 3
        assert all(r == "hello {{ name }}" for r in results)

    def test_batch_render_zero_count(self):
        """batch_render(0) returns an empty list."""
        t = Template("hello")
        results = t.batch_render(0)
        assert results == []

    def test_batch_render_error_exits(self, mocker):
        """batch_render with undefined variables raises SystemExit."""
        mocker.patch("rich.console.Console.print")
        t = Template("Hello {{ name }}")
        with pytest.raises(SystemExit):
            t.batch_render(3)
