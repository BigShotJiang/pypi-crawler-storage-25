"""Unit tests for ketacli/sdk/output/output.py.

Tests all public functions: find_list_field, find_result_field, flatten_dict,
list_output, search_result_output, get_asset_output, describe_output,
rs_output_all, rs_output_one.

Mock strategy: mock make_table / make_records_to_table / prettify_value
from the output module's namespace to verify call arguments without
depending on format.py rendering logic.
"""

import pytest
from ketacli.sdk.output.output import (
    RESP_OUTPUT_KEY,
    describe_output,
    find_list_field,
    find_result_field,
    flatten_dict,
    get_asset_output,
    help_methods,
    list_output,
    rs_output_all,
    rs_output_one,
    rs_output_one_example,
    search_result_output,
)


# ── find_list_field ──────────────────────────────────────────────────────────


class TestFindListField:
    """find_list_field: find first list-valued key in a dict."""

    def test_dict_with_list_values(self):
        """Dict with list values returns the first list key."""
        resp = {"items": [1, 2, 3], "name": "test"}
        assert find_list_field(resp) == "items"

    def test_dict_with_multiple_list_values(self):
        """Dict with multiple list values returns the first one."""
        resp = {"a": [1], "b": [2]}
        assert find_list_field(resp) == "a"

    def test_no_list_field(self):
        """Dict without list values returns None."""
        resp = {"name": "test", "value": 123}
        assert find_list_field(resp) is None

    def test_none_input(self):
        """None input defaults to {} and returns None."""
        assert find_list_field(None) is None

    def test_non_dict_input(self):
        """Non-dict input (string, int, list) returns None."""
        assert find_list_field("string") is None
        assert find_list_field(123) is None
        assert find_list_field([1, 2, 3]) is None


# ── find_result_field ───────────────────────────────────────────────────────


class TestFindResultField:
    """find_result_field: resolve asset_type to a result field key."""

    def test_whitelist_bizsystems(self):
        """Whitelist entry 'bizsystems' maps to 'items'."""
        resp = {"items": [{"name": "a"}], "total": 1}
        assert find_result_field("bizsystems", resp) == "items"

    def test_whitelist_target(self):
        """Whitelist entry 'target' maps to 'items'."""
        resp = {"items": [{"name": "a"}], "total": 1}
        assert find_result_field("target", resp) == "items"

    def test_whitelist_targettype(self):
        """Whitelist entry 'targettype' maps to 'items'."""
        resp = {"items": [{"name": "a"}], "total": 1}
        assert find_result_field("targettype", resp) == "items"

    def test_exact_name_match(self):
        """Exact match of asset_type key in resp returns that key."""
        resp = {"repos": [{"name": "test-repo"}], "total": 1}
        assert find_result_field("repos", resp) == "repos"

    def test_fuzzy_plural_match(self):
        """Singular asset_type ('repo') matches plural key ('repos')."""
        resp = {"repos": [{"name": "test-repo"}], "total": 1}
        assert find_result_field("repo", resp) == "repos"

    def test_fuzzy_singular_match(self):
        """Plural asset_type ('repos') matches singular key ('repo')."""
        resp = {"repo": [{"name": "test-repo"}], "total": 1}
        assert find_result_field("repos", resp) == "repo"

    def test_fallback_to_list_field(self):
        """Fallback to find_list_field when no name or whitelist match."""
        resp = {"items": [{"id": 1}], "total": 1}
        assert find_result_field("unknown", resp) == "items"

    def test_list_resp_returns_none(self):
        """List response returns None immediately."""
        resp = [{"name": "a"}, {"name": "b"}]
        assert find_result_field("test", resp) is None

    def test_empty_list_field_returns_none(self):
        """List field with zero items returns None."""
        resp = {"total": 0, "items": []}
        assert find_result_field("repos", resp) is None

    def test_empty_resp_returns_none(self):
        """Empty dict response returns None."""
        assert find_result_field("test", {}) is None

    def test_none_resp_defaults_to_empty(self):
        """None response defaults to {} and returns None."""
        assert find_result_field("test", None) is None


# ── flatten_dict ─────────────────────────────────────────────────────────────


class TestFlattenDict:
    """flatten_dict: flatten nested dicts into dotted-key flat dicts."""

    def test_simple_dict(self):
        """Simple flat dict returns same keys."""
        assert flatten_dict({"a": 1, "b": "hello"}) == {"a": 1, "b": "hello"}

    def test_with_prefix(self):
        """Prefix is prepended to all top-level keys."""
        result = flatten_dict({"a": 1, "b": 2}, prefix="cfg.")
        assert result == {"cfg.a": 1, "cfg.b": 2}

    def test_nested_dict(self):
        """Nested dict creates dotted keys (parent.child)."""
        result = flatten_dict({"a": {"b": 1, "c": 2}})
        assert result == {"a.b": 1, "a.c": 2}

    def test_deeply_nested(self):
        """Deeply nested dict creates multi-level dotted keys."""
        result = flatten_dict({"a": {"b": {"c": 3}}})
        assert result == {"a.b.c": 3}

    def test_empty_dict(self):
        """Empty dict returns empty dict."""
        assert flatten_dict({}) == {}

    def test_none_value_not_flattened(self):
        """None value is kept unchanged (not treated as nested dict)."""
        result = flatten_dict({"a": None})
        assert result == {"a": None}

    def test_mixed_flat_and_nested(self):
        """Mixed flat keys and nested dicts produce correct dotted keys."""
        result = flatten_dict({"a": 1, "b": {"c": 2, "d": 3}, "e": 4})
        assert result == {"a": 1, "b.c": 2, "b.d": 3, "e": 4}

    def test_empty_nested_dict(self):
        """Empty nested dict is skipped (falsy check)."""
        result = flatten_dict({"a": {}, "b": 1})
        # {} is falsy, so it will be treated as a value rather than recursed into
        assert result == {"a": {}, "b": 1}


# ── list_output ──────────────────────────────────────────────────────────────


class TestListOutput:
    """list_output: build a table from a list-type API response."""

    def test_dict_with_total(self, mocker):
        """Dict with 'total' key processes items via find_result_field."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        resp = {"total": 2, "items": [{"name": "a"}, {"name": "b"}]}
        result = list_output("some_type", resp=resp)
        mock.assert_called_once_with([], resp["items"], {}, {}, False)
        assert result == "table_mock"

    def test_dict_without_total_flattens(self, mocker):
        """Dict without 'total' flattens and wraps in a list."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        resp = {"key": "value", "nested": {"inner": 1}}
        result = list_output("some_type", resp=resp)
        expected_records = [{"key": "value", "nested.inner": 1}]
        mock.assert_called_once_with([], expected_records, {}, {}, False)
        assert result == "table_mock"

    def test_list_input(self, mocker):
        """List input passes directly to make_records_to_table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        resp = [{"name": "a"}, {"name": "b"}]
        result = list_output("some_type", resp=resp)
        mock.assert_called_once_with([], resp, {}, {}, False)
        assert result == "table_mock"

    def test_empty_resp_returns_none(self, mocker):
        """Unmatched response with no list field returns None."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        resp = {"total": 0, "no_list": "value"}
        result = list_output("unknown", resp=resp)
        assert result is None
        mock.assert_not_called()

    def test_with_field_aliases(self, mocker):
        """field_aliases are forwarded to make_records_to_table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        resp = {"total": 1, "items": [{"name": "test"}]}
        aliases = {"name": "名称"}
        result = list_output("bizsystems", resp=resp, field_aliases=aliases)
        mock.assert_called_once_with([], resp["items"], aliases, {}, False)
        assert result == "table_mock"

    def test_with_field_converters(self, mocker):
        """field_converters are forwarded to make_records_to_table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        resp = {"total": 1, "items": [{"name": "test"}]}
        converters = {"name": {"converter": "format_boolean"}}
        result = list_output("bizsystems", resp=resp, field_converters=converters)
        mock.assert_called_once_with([], resp["items"], {}, converters, False)
        assert result == "table_mock"

    def test_with_output_fields(self, mocker):
        """output_fields are forwarded to make_records_to_table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        resp = {"total": 1, "items": [{"name": "test"}]}
        result = list_output("bizsystems", output_fields=["name"], resp=resp)
        mock.assert_called_once_with(["name"], resp["items"], {}, {}, False)
        assert result == "table_mock"

    def test_raw_output_flag(self, mocker):
        """raw_output flag is forwarded to make_records_to_table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        resp = {"total": 1, "items": [{"name": "test"}]}
        result = list_output("bizsystems", resp=resp, raw_output=True)
        mock.assert_called_once_with([], resp["items"], {}, {}, True)
        assert result == "table_mock"

    def test_none_resp_defaults_to_empty(self, mocker):
        """None response defaults to {}, flattens, and passes to make_records_to_table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_records_to_table")
        mock.return_value = "table_mock"
        result = list_output("unknown", resp=None)
        # resp becomes [{}] after flatten, find_result_field returns None,
        # but since resp is now a list it goes to make_records_to_table
        mock.assert_called_once_with([], [{}], {}, {}, False)
        assert result == "table_mock"


# ── search_result_output ─────────────────────────────────────────────────────


class TestSearchResultOutput:
    """search_result_output: build a table from search result."""

    def test_valid_result(self, mocker):
        """Valid result with fields and rows returns a table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"
        result = {
            "fields": [{"name": "col1"}, {"name": "col2"}],
            "rows": [["a", 1], ["b", 2]],
        }
        output = search_result_output(result)
        mock.assert_called_once_with(["col1", "col2"], [["a", 1], ["b", 2]], False)
        assert output == "table_mock"

    def test_transpose_flag(self, mocker):
        """Transpose flag is forwarded to make_table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"
        result = {
            "fields": [{"name": "col1"}],
            "rows": [["val1"]],
        }
        output = search_result_output(result, transpose=True)
        mock.assert_called_once_with(["col1"], [["val1"]], True)
        assert output == "table_mock"

    def test_failed_result(self):
        """Result with 'failed' truthy key returns None."""
        assert search_result_output({"failed": True}) is None
        assert search_result_output({"failed": "error"}) is None

    def test_string_result(self):
        """String result returns None."""
        assert search_result_output("error message") is None

    def test_none_result_raises_keyerror(self):
        """None defaults to {} — empty dict lacks 'fields' key → KeyError."""
        with pytest.raises(KeyError):
            search_result_output(None)


# ── get_asset_output ─────────────────────────────────────────────────────────


class TestGetAssetOutput:
    """get_asset_output: build a field/value table from a single resource."""

    def test_standard_resp(self, mocker):
        """Standard response produces field/value rows."""
        mock_table = mocker.patch("ketacli.sdk.output.output.make_table")
        mock_prettify = mocker.patch("ketacli.sdk.output.output.prettify_value")
        mock_prettify.side_effect = lambda k, v: v
        mock_table.return_value = "table_mock"

        resp = {"name": "test", "value": 123}
        result = get_asset_output(resp)

        mock_table.assert_called_once_with(
            ["field", "value"],
            [["name", "test"], ["value", 123]],
        )
        assert result == "table_mock"

    def test_with_output_fields_filter(self, mocker):
        """output_fields filter restricts which keys are included."""
        mock_table = mocker.patch("ketacli.sdk.output.output.make_table")
        mock_prettify = mocker.patch("ketacli.sdk.output.output.prettify_value")
        mock_prettify.side_effect = lambda k, v: v
        mock_table.return_value = "table_mock"

        resp = {"name": "test", "value": 123, "hidden": "secret"}
        result = get_asset_output(resp, output_fields=["name"])

        mock_table.assert_called_once_with(
            ["field", "value"],
            [["name", "test"]],
        )
        assert result == "table_mock"

    def test_multiple_output_fields(self, mocker):
        """Multiple output_fields filter correctly."""
        mock_table = mocker.patch("ketacli.sdk.output.output.make_table")
        mock_prettify = mocker.patch("ketacli.sdk.output.output.prettify_value")
        mock_prettify.side_effect = lambda k, v: v
        mock_table.return_value = "table_mock"

        resp = {"a": 1, "b": 2, "c": 3}
        result = get_asset_output(resp, output_fields=["a", "c"])

        mock_table.assert_called_once_with(
            ["field", "value"],
            [["a", 1], ["c", 3]],
        )
        assert result == "table_mock"

    def test_empty_resp(self, mocker):
        """Empty response returns empty table."""
        mock_table = mocker.patch("ketacli.sdk.output.output.make_table")
        mock_table.return_value = "table_mock"

        result = get_asset_output({})

        mock_table.assert_called_once_with(["field", "value"], [])
        assert result == "table_mock"

    def test_none_resp_defaults_to_empty(self, mocker):
        """None response defaults to {}."""
        mock_table = mocker.patch("ketacli.sdk.output.output.make_table")
        mock_table.return_value = "table_mock"

        result = get_asset_output(None)

        mock_table.assert_called_once_with(["field", "value"], [])
        assert result == "table_mock"


# ── describe_output ──────────────────────────────────────────────────────────


class TestDescribeOutput:
    """describe_output: build a field-name → type table from first record."""

    def test_valid_resp(self, mocker):
        """Valid response with records returns field type table."""
        mock_table = mocker.patch("ketacli.sdk.output.output.make_table")
        mock_table.return_value = "table_mock"

        resp = {"total": 1, "repos": [{"name": "test", "value": 123, "active": True}]}
        result = describe_output("repos", resp)

        mock_table.assert_called_once_with(
            ["fields", "type"],
            [
                ("name", "<class 'str'>"),
                ("value", "<class 'int'>"),
                ("active", "<class 'bool'>"),
            ],
        )
        assert result == "table_mock"

    def test_total_zero_returns_none(self):
        """total == 0 returns None (fails <= 0 check)."""
        resp = {"total": 0, "repos": [{"name": "test"}]}
        assert describe_output("repos", resp) is None

    def test_no_result_field(self):
        """No matching result field in resp returns None."""
        # Use a resp with no list fields at all to prevent find_list_field fallback
        resp = {"total": 1, "id": "abc", "name": "test"}
        assert describe_output("repos", resp) is None

    def test_dict_without_total_flattens_but_no_list(self, mocker):
        """Dict without 'total' flattens but may not find list field."""
        # After flattening, resp becomes a list, and find_result_field returns None
        assert describe_output("repos", {"nested": {"a": 1}}) is None

    def test_list_resp(self, mocker):
        """List response can be processed when a list field is found."""
        # When resp is a list, total = len(resp)
        # But find_result_field returns None for list input
        assert describe_output("repos", [{"name": "test"}]) is None

    def test_none_resp(self):
        """None response defaults to {} and returns None (no total key)."""
        assert describe_output("repos", None) is None


# ── rs_output_all ────────────────────────────────────────────────────────────


class TestRsOutputAll:
    """rs_output_all: build a resource-type listing table."""

    def test_multiple_resources(self, mocker):
        """Multiple resources create correct table rows."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        asset_types = {
            "repos": {
                "desc": "Repository",
                "path": "repos",
                "methods": {"list": {}, "create": {}},
            },
            "dashboards": {
                "desc": "Dashboard",
                "path": "dashboards",
                "methods": {"list": {}, "get": {}, "delete": {}},
            },
        }
        result = rs_output_all(asset_types)

        mock.assert_called_once_with(
            ["资源类型", "资源描述", "API路径", "支持方法"],
            [
                ["repos", "Repository", "repos", "list,create"],
                ["dashboards", "Dashboard", "dashboards", "list,get,delete"],
            ],
        )
        assert result == "table_mock"

    def test_admin_path_rewrites_list(self, mocker):
        """Admin path rewrites 'list' to 'admin' at front."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        asset_types = {
            "users": {
                "desc": "Users",
                "path": "admin/users",
                "methods": {"list": {}, "create": {}, "delete": {}},
            },
        }
        result = rs_output_all(asset_types)

        mock.assert_called_once_with(
            ["资源类型", "资源描述", "API路径", "支持方法"],
            [
                ["users", "Users", "admin/users", "admin,create,delete"],
            ],
        )
        assert result == "table_mock"

    def test_admin_path_no_list(self, mocker):
        """Admin path without 'list' method keeps original method keys."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        asset_types = {
            "settings": {
                "desc": "Settings",
                "path": "admin/settings",
                "methods": {"get": {}, "update": {}},
            },
        }
        result = rs_output_all(asset_types)

        mock.assert_called_once_with(
            ["资源类型", "资源描述", "API路径", "支持方法"],
            [
                ["settings", "Settings", "admin/settings", "get,update"],
            ],
        )
        assert result == "table_mock"

    def test_slash_in_name_replaced(self, mocker):
        """Asset type with '/' gets '/' replaced by '-'."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        asset_types = {
            "apps/market": {
                "desc": "App Market",
                "path": "apps/market",
                "methods": {"list": {}},
            },
        }
        result = rs_output_all(asset_types)

        mock.assert_called_once_with(
            ["资源类型", "资源描述", "API路径", "支持方法"],
            [
                ["apps-market", "App Market", "apps/market", "list"],
            ],
        )
        assert result == "table_mock"

    def test_empty_asset_types(self, mocker):
        """Empty asset_types dict returns empty table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        result = rs_output_all({})

        mock.assert_called_once_with(
            ["资源类型", "资源描述", "API路径", "支持方法"],
            [],
        )
        assert result == "table_mock"

    def test_none_asset_types(self, mocker):
        """None defaults to empty dict."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        result = rs_output_all(None)

        mock.assert_called_once_with(
            ["资源类型", "资源描述", "API路径", "支持方法"],
            [],
        )
        assert result == "table_mock"


# ── rs_output_one ────────────────────────────────────────────────────────────


class TestRsOutputOne:
    """rs_output_one: build a detail table for a single resource type."""

    def test_resource_with_methods(self, mocker):
        """Resource with dict methods shows help strings in 支持方法 row."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        conf = {
            "desc": "Repository",
            "path": "repos",
            "methods": {"list": {}, "create": {}},
        }
        result = rs_output_one("repos", conf)

        assert mock.called
        args, _ = mock.call_args
        header, rows = args
        assert header == ["字段", "值"]
        # Check fixed rows
        assert rows[0] == ["资源类型", "repos"]
        assert rows[1] == ["资源描述", "Repository"]
        assert rows[2] == ["API路径", "api/v1/repos"]
        # methods row should be present (list + create + describe)
        method_rows = [r for r in rows if r[0] == "支持方法"]
        assert len(method_rows) == 1
        methods_str = method_rows[0][1]
        assert "ketacli asset repos list" in methods_str
        assert "ketacli asset repos create" in methods_str
        assert "ketacli asset repos --help" in methods_str  # show_describe adds this
        # Remark row should be present
        remark_rows = [r for r in rows if r[0] == "备注"]
        assert len(remark_rows) == 1
        assert result == "table_mock"

    def test_resource_with_string_method_values(self, mocker):
        """Resource with string method values still works."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        conf = {
            "desc": "Custom",
            "path": "custom",
            "methods": {"action1": "some_description"},
        }
        result = rs_output_one("custom", conf)

        assert mock.called
        args, _ = mock.call_args
        rows = args[1]
        method_rows = [r for r in rows if r[0] == "支持方法"]
        assert len(method_rows) == 1
        # String value path - help_methods called without example/description
        assert "action1" in method_rows[0][1]
        assert result == "table_mock"

    def test_resource_with_method_data_example(self, mocker):
        """Resource method with data example passes json to help_methods."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        conf = {
            "desc": "Test",
            "path": "test",
            "methods": {
                "create": {
                    "data": {"name": "default"},
                    "description": "Create a test resource",
                }
            },
        }
        result = rs_output_one("test", conf)

        assert mock.called
        args, _ = mock.call_args
        rows = args[1]
        method_rows = [r for r in rows if r[0] == "支持方法"]
        assert len(method_rows) == 1
        methods_str = method_rows[0][1]
        # create no longer embeds the data example inline
        assert '{"name": "default"}' not in methods_str
        assert "ketacli asset test create" in methods_str
        assert result == "table_mock"

    def test_resource_without_methods(self, mocker):
        """Resource without methods key has no 支持方法 row."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        conf = {
            "desc": "Simple",
            "path": "simple",
        }
        result = rs_output_one("simple", conf)

        assert mock.called
        args, _ = mock.call_args
        rows = args[1]
        # Should have: 资源类型, 资源描述, API路径, 备注 = 4 rows
        assert len(rows) == 4
        method_rows = [r for r in rows if r[0] == "支持方法"]
        assert len(method_rows) == 0
        assert result == "table_mock"

    def test_show_describe_false(self, mocker):
        """show_describe=False prevents describe method from being added."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        conf = {
            "desc": "Repo",
            "path": "repos",
            "methods": {"list": {}},
            "show_describe": False,
        }
        result = rs_output_one("repos", conf)

        assert mock.called
        args, _ = mock.call_args
        rows = args[1]
        method_rows = [r for r in rows if r[0] == "支持方法"]
        assert len(method_rows) == 1
        assert "describe" not in method_rows[0][1]
        assert result == "table_mock"

    def test_empty_conf(self, mocker):
        """Empty conf returns empty table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        result = rs_output_one("test", {})

        mock.assert_called_once_with(["字段", "值"], [])
        assert result == "table_mock"

    def test_none_conf_defaults_to_empty(self, mocker):
        """None conf defaults to {} and returns empty table."""
        mock = mocker.patch("ketacli.sdk.output.output.make_table")
        mock.return_value = "table_mock"

        result = rs_output_one("test", None)

        mock.assert_called_once_with(["字段", "值"], [])
        assert result == "table_mock"


# ── rs_output_one_example ────────────────────────────────────────────────────


class TestRsOutputOneExample:
    """rs_output_one_example: build example data for a single resource type."""

    def test_with_example(self):
        """Resource with example data returns formatted JSON."""
        conf = {
            "example": {"name": "default", "value": 42},
        }
        result = rs_output_one_example("test", conf)
        assert '"name": "default"' in result
        assert '"value": 42' in result

    def test_without_example(self):
        """Resource without example returns no-example message."""
        conf = {"desc": "Test"}
        result = rs_output_one_example("test", conf)
        assert "there is no example" in result

    def test_empty_conf(self):
        """Empty conf returns no-example message."""
        result = rs_output_one_example("test", {})
        assert "there is no example" in result

    def test_none_conf(self):
        """None conf returns no-example message."""
        result = rs_output_one_example("test", None)
        assert "there is no example" in result


# ── help_methods ─────────────────────────────────────────────────────────────


class TestHelpMethods:
    """help_methods: generate help strings for resource operations."""

    def test_list(self):
        result = help_methods("repos", "list")
        assert "ketacli asset repos list" in result

    def test_get(self):
        result = help_methods("repos", "get")
        assert "ketacli asset repos get" in result

    def test_create(self):
        result = help_methods("repos", "create")
        assert "ketacli asset repos create" in result

    def test_describe(self):
        result = help_methods("repos", "describe")
        assert "ketacli asset repos --help" in result

    def test_update(self):
        result = help_methods("repos", "update")
        assert "ketacli asset repos update" in result

    def test_download(self):
        result = help_methods("repos", "download")
        assert "ketacli asset repos download" in result

    def test_unknown_method_with_desc(self):
        """Unknown method uses description and -o flag."""
        result = help_methods("apps", "install", description="安装应用")
        assert "安装应用" in result
        assert "ketacli asset apps install" in result

    def test_unknown_method_example(self):
        """Unknown method includes example data when provided."""
        result = help_methods("apps", "install", example='{"v": "1"}')
        assert "ketacli asset apps install" in result
