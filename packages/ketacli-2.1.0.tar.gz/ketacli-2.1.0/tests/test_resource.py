"""Tests for ketacli.plugins.resource module — dynamic CLI generation from YAML configs.

Covers: _build_resource_group, make_list_cmd, make_operation_cmd,
register_asset_commands, nested resource handling, large-scale resource
registration.
"""

import pytest
import click
from click.testing import CliRunner


# =============================================================================
# Mock resource configs
# =============================================================================

DC_TAG_CONFIG = {
    "path": "dc/tags",
    "desc": "KetaAgent \u6807\u7b7e",
    "methods": {
        "list": {"path": "dc/tags", "method": "get", "default_fields": ["id", "name"]},
        "get": {"path": "dc/tag/{{ asset_id }}", "method": "get"},
        "create": {
            "path": "dc/tag",
            "method": "post",
            "data": {
                "name": "{{ name }}",
                "key": "{{ key }}",
                "description": "{{ description | default('') }}",
            },
        },
        "update": {
            "path": "dc/tag/{{ asset_id }}",
            "method": "put",
            "data": {
                "name": "{{ name }}",
                "key": "{{ key }}",
                "description": "{{ description | default('') }}",
            },
        },
        "delete": {"path": "dc/tags/{{ asset_id }}", "method": "delete"},
    },
}

REPOS_CONFIG = {
    "path": "repos",
    "desc": "\u4ed3\u5e93",
    "methods": {
        "list": {"path": "repos", "method": "get"},
        "get": {"path": "repos/{{ asset_id }}", "method": "get"},
        "create": {"path": "repos", "method": "post"},
        "update": {"path": "repos/{{ asset_id }}", "method": "put"},
        "delete": {"path": "repos/{{ asset_id }}", "method": "delete"},
    },
}

APPS_CONFIG = {
    "path": "apps",
    "desc": "\u5e94\u7528",
    "methods": {
        "list": {"path": "apps", "method": "get"},
        "get": {"path": "apps/{{ asset_id }}", "method": "get"},
        "create": {"path": "apps", "method": "post"},
        "delete": {"path": "apps/{{ asset_id }}", "method": "delete"},
    },
}

APPS_MARKET_CONFIG = {
    "path": "apps/market",
    "desc": "\u5e94\u7528\u5e02\u573a",
    "methods": {
        "list": {"path": "apps/market", "method": "get"},
        "get": {"path": "apps/market/{{ asset_id }}", "method": "get"},
        "install": {
            "path": "apps/market/install",
            "method": "post",
            "data": {"app_name": "{{ name }}"},
        },
    },
}


# =============================================================================
# Shared fixture: mock get_resources with a representative set of resources
# =============================================================================

@pytest.fixture
def mock_resources(mocker):
    """Mock get_resources() so register_asset_commands uses controlled data.

    Covers typical top-level resources (dc-tag, repos) and nested
    resources (apps/market under apps).
    """
    resources = {
        "dc-tag": DC_TAG_CONFIG,
        "repos": REPOS_CONFIG,
        "apps": APPS_CONFIG,
        "apps/market": APPS_MARKET_CONFIG,
    }
    mocker.patch("ketacli.plugins.resource.get_resources", return_value=resources)
    return resources


@pytest.fixture
def root_cli():
    """Create a fresh root click.Group for each test."""
    return click.Group(name="cli", help="Test CLI")


# =============================================================================
# _build_resource_group
# =============================================================================


class TestBuildResourceGroup:
    """Tests for _build_resource_group()."""

    def test_creates_group_with_correct_name_and_help(self):
        """Group name matches last segment; group.help comes from config desc."""
        from ketacli.plugins.resource import _build_resource_group

        group = _build_resource_group("dc-tag", DC_TAG_CONFIG)

        assert isinstance(group, click.Group)
        assert group.name == "dc-tag"
        assert group.help == DC_TAG_CONFIG["desc"]

    def test_adds_list_command_when_list_method_present(self):
        """When methods contains 'list', a list subcommand is added."""
        from ketacli.plugins.resource import _build_resource_group

        group = _build_resource_group("repos", REPOS_CONFIG)
        list_cmd = group.commands.get("list")

        assert list_cmd is not None
        assert isinstance(list_cmd, click.Command)
        assert list_cmd.name == "list"

    def test_adds_all_non_list_operation_commands(self):
        """Every method key (except 'list') becomes a click.Command subcommand."""
        from ketacli.plugins.resource import _build_resource_group

        group = _build_resource_group("dc-tag", DC_TAG_CONFIG)

        # dc-tag has: list, get, create, update, delete → 5 total
        assert "list" in group.commands
        assert "get" in group.commands
        assert "create" in group.commands
        assert "update" in group.commands
        assert "delete" in group.commands
        assert len(group.commands) == 5

    def test_nested_resource_uses_last_segment_as_group_name(self):
        """'apps/market' → group name is 'apps-market', with '/' replaced by '-'."""
        from ketacli.plugins.resource import _build_resource_group

        group = _build_resource_group("apps/market", APPS_MARKET_CONFIG)

        assert group.name == "apps-market"
        assert group.help == APPS_MARKET_CONFIG["desc"]

    def test_config_without_methods_key_produces_empty_group(self):
        """When config has no 'methods' key, group has zero subcommands."""
        from ketacli.plugins.resource import _build_resource_group

        group = _build_resource_group("empty", {"path": "empty", "desc": "EMPTY"})

        assert isinstance(group, click.Group)
        assert len(group.commands) == 0

    def test_group_help_falls_back_to_resource_name(self):
        """When config has no 'desc' key, group.help is the full resource name."""
        from ketacli.plugins.resource import _build_resource_group

        group = _build_resource_group("no-desc", {"path": "no-desc"})

        assert group.help == "no-desc"

    def test_config_with_only_list_method(self):
        """When methods only contains 'list', only the list command is added."""
        from ketacli.plugins.resource import _build_resource_group

        config = {"path": "readonly", "methods": {"list": {"path": "readonly", "method": "get"}}}
        group = _build_resource_group("readonly", config)

        assert "list" in group.commands
        assert len(group.commands) == 1

    def test_config_with_only_operations_no_list(self):
        """When methods has operations but no 'list' key, list is not added."""
        from ketacli.plugins.resource import _build_resource_group

        config = {
            "path": "ops-only",
            "methods": {
                "get": {"path": "ops-only/{{ asset_id }}", "method": "get"},
                "delete": {"path": "ops-only/{{ asset_id }}", "method": "delete"},
            },
        }
        group = _build_resource_group("ops-only", config)

        assert "list" not in group.commands
        assert "get" in group.commands
        assert "delete" in group.commands
        assert len(group.commands) == 2

    def test_multi_level_nested_name_truncates_correctly(self):
        """'a/b/c' produces group name 'a-b-c' (flat, '/' → '-')."""
        from ketacli.plugins.resource import _build_resource_group

        config = {"path": "a/b/c", "methods": {"list": {"path": "a/b/c", "method": "get"}}}
        group = _build_resource_group("a/b/c", config)

        assert group.name == "a-b-c"


# =============================================================================
# make_list_cmd
# =============================================================================


class TestMakeListCmd:
    """Tests for make_list_cmd()."""

    def test_returns_click_command_named_list(self):
        """make_list_cmd returns a click.Command whose name is 'list'."""
        from ketacli.plugins.resource import make_list_cmd

        cmd = make_list_cmd("dc-tag", DC_TAG_CONFIG)

        assert isinstance(cmd, click.Command)
        assert cmd.name == "list"

    def test_has_all_required_parameters(self):
        """list command exposes --query, --sort, --order, -l, -f, -e."""
        from ketacli.plugins.resource import make_list_cmd

        cmd = make_list_cmd("dc-tag", DC_TAG_CONFIG)
        param_names = {p.name for p in cmd.params}

        assert "query" in param_names
        assert "sort" in param_names
        assert "order" in param_names
        assert "page_size" in param_names
        assert "format_" in param_names
        assert "extra" in param_names
        assert len(cmd.params) == 6

    def test_parameter_short_options_present(self):
        """-l, -f, -e short options are available on the list command."""
        from ketacli.plugins.resource import make_list_cmd

        cmd = make_list_cmd("dc-tag", DC_TAG_CONFIG)
        all_opts = [opt for p in cmd.params for opt in p.opts]

        assert "-l" in all_opts
        assert "-f" in all_opts
        assert "-e" in all_opts
        assert "--page-size" in all_opts
        assert "--format" in all_opts
        assert "--extra" in all_opts

    def test_help_text_includes_resource_name(self):
        """Command help string mentions the resource type."""
        from ketacli.plugins.resource import make_list_cmd

        cmd = make_list_cmd("repos", REPOS_CONFIG)

        assert "repos" in cmd.help

    def test_can_invoke_help_without_api_calls(self):
        """Invoking --help does not trigger the callback (safe without API mocks)."""
        from ketacli.plugins.resource import make_list_cmd

        runner = CliRunner()
        cmd = make_list_cmd("dc-tag", DC_TAG_CONFIG)
        result = runner.invoke(cmd, ["--help"])

        assert result.exit_code == 0
        assert "--query" in result.output
        assert "--sort" in result.output

    def test_works_with_nested_resource_names(self):
        """Nested resource names like 'apps/market' are passed through correctly."""
        from ketacli.plugins.resource import make_list_cmd

        cmd = make_list_cmd("apps/market", APPS_MARKET_CONFIG)

        assert cmd.name == "list"
        # Help text should reference the full resource name
        assert "apps/market" in cmd.help


# =============================================================================
# make_operation_cmd
# =============================================================================


class TestMakeOperationCmd:
    """Tests for make_operation_cmd()."""

    def test_command_name_matches_method_name(self):
        """make_operation_cmd('dc-tag', 'create', ...) → click.Command('create')."""
        from ketacli.plugins.resource import make_operation_cmd

        cmd = make_operation_cmd("dc-tag", "create", DC_TAG_CONFIG["methods"]["create"])

        assert isinstance(cmd, click.Command)
        assert cmd.name == "create"

    def test_has_name_and_extra_parameters(self):
        """Operation commands ONLY have -n/--name and -e/--extra parameters."""
        from ketacli.plugins.resource import make_operation_cmd

        cmd = make_operation_cmd("dc-tag", "get", DC_TAG_CONFIG["methods"]["get"])
        param_names = {p.name for p in cmd.params}

        assert param_names == {"name", "extra"}
        assert len(cmd.params) == 2

    def test_short_options_present(self):
        """-n maps to --name, -e maps to --extra."""
        from ketacli.plugins.resource import make_operation_cmd

        cmd = make_operation_cmd("dc-tag", "delete", DC_TAG_CONFIG["methods"]["delete"])
        all_opts = [opt for p in cmd.params for opt in p.opts]

        assert "-n" in all_opts
        assert "--name" in all_opts
        assert "-e" in all_opts
        assert "--extra" in all_opts

    def test_help_includes_method_and_resource(self):
        """Command help string mentions both operation and resource."""
        from ketacli.plugins.resource import make_operation_cmd

        cmd = make_operation_cmd("repos", "update", REPOS_CONFIG["methods"]["update"])

        assert "update" in cmd.help.lower()
        assert "repos" in cmd.help

    def test_can_invoke_help_without_api_calls(self):
        """--help is safe to invoke without any API mocks."""
        from ketacli.plugins.resource import make_operation_cmd

        runner = CliRunner()
        cmd = make_operation_cmd("dc-tag", "get", DC_TAG_CONFIG["methods"]["get"])
        result = runner.invoke(cmd, ["--help"])

        assert result.exit_code == 0
        assert "-n" in result.output
        assert "-e" in result.output

    def test_different_methods_produce_different_names(self):
        """Each method_name produces a distinct command name."""
        from ketacli.plugins.resource import make_operation_cmd

        get_cmd = make_operation_cmd("dc-tag", "get", DC_TAG_CONFIG["methods"]["get"])
        create_cmd = make_operation_cmd("dc-tag", "create", DC_TAG_CONFIG["methods"]["create"])
        delete_cmd = make_operation_cmd("dc-tag", "delete", DC_TAG_CONFIG["methods"]["delete"])

        assert get_cmd.name == "get"
        assert create_cmd.name == "create"
        assert delete_cmd.name == "delete"

    def test_works_with_nested_resource_names(self):
        """Nested name 'apps/market' is passed through for YAML lookups."""
        from ketacli.plugins.resource import make_operation_cmd

        cmd = make_operation_cmd(
            "apps/market", "install", APPS_MARKET_CONFIG["methods"]["install"]
        )

        assert cmd.name == "install"
        assert "apps/market" in cmd.help

    def test_string_method_config_accepted(self):
        """Method config can be a plain dict (handled upstream by get_request_path)."""
        from ketacli.plugins.resource import make_operation_cmd

        cmd = make_operation_cmd("test-res", "delete", {"path": "test", "method": "delete"})

        assert cmd.name == "delete"
        assert isinstance(cmd, click.Command)

    def test_multipart_operation_has_file_option(self):
        """Operations with body_type=multipart get an extra -f/--file parameter."""
        from ketacli.plugins.resource import make_operation_cmd

        multipart_config = {
            "path": "apps/import",
            "method": "post",
            "body_type": "multipart",
            "form_fields": [
                {"field": "resumableFilename"},
                {"field": "resumableTotalSize", "default": "1"},
            ],
        }
        cmd = make_operation_cmd("apps", "import", multipart_config)

        param_names = {p.name for p in cmd.params}
        assert "file" in param_names
        all_opts = [opt for p in cmd.params for opt in p.opts]
        assert "-f" in all_opts
        assert "--file" in all_opts

    def test_non_multipart_operation_has_no_file_option(self):
        """Regular operations (no body_type=multipart) do NOT get --file."""
        from ketacli.plugins.resource import make_operation_cmd

        cmd = make_operation_cmd("dc-tag", "get", DC_TAG_CONFIG["methods"]["get"])
        param_names = {p.name for p in cmd.params}

        assert "file" not in param_names


# =============================================================================
# register_asset_commands
# =============================================================================


class TestRegisterAssetCommands:
    """Integration-style tests for register_asset_commands()."""

    def test_adds_asset_group_to_cli(self, root_cli, mock_resources):
        """register_asset_commands(cli) adds an 'asset' click.Group to cli."""
        from ketacli.plugins.resource import register_asset_commands

        register_asset_commands(root_cli)

        assert "asset" in root_cli.commands
        asset_group = root_cli.commands["asset"]
        assert isinstance(asset_group, click.Group)

    def test_asset_group_contains_top_level_resource_groups(self, root_cli, mock_resources):
        """Top-level resources (dc-tag, repos, apps) appear directly under asset."""
        from ketacli.plugins.resource import register_asset_commands

        register_asset_commands(root_cli)
        asset_group = root_cli.commands["asset"]

        assert "dc-tag" in asset_group.commands
        assert "repos" in asset_group.commands
        assert "apps" in asset_group.commands
        # apps/market is nested under apps, NOT at top level
        assert "market" not in asset_group.commands

    def test_dc_tag_has_all_five_operations(self, root_cli, mock_resources):
        """dc-tag group contains list, get, create, update, delete subcommands."""
        from ketacli.plugins.resource import register_asset_commands

        register_asset_commands(root_cli)
        dc_tag_group = root_cli.commands["asset"].commands["dc-tag"]

        assert set(dc_tag_group.commands.keys()) == {"list", "get", "create", "update", "delete"}
        assert len(dc_tag_group.commands) == 5

    def test_apps_market_nested_under_apps(self, root_cli, mock_resources):
        """'apps/market' becomes 'apps-market' directly under asset (flat layout)."""
        from ketacli.plugins.resource import register_asset_commands

        register_asset_commands(root_cli)
        asset_group = root_cli.commands["asset"]

        assert "apps-market" in asset_group.commands
        market_group = asset_group.commands["apps-market"]
        assert isinstance(market_group, click.Group)
        # market group should have its own commands
        assert "list" in market_group.commands
        assert "get" in market_group.commands
        assert "install" in market_group.commands

    def test_cli_help_shows_asset_command(self, root_cli, mock_resources):
        """Root CLI --help lists 'asset' as a command."""
        from ketacli.plugins.resource import register_asset_commands

        register_asset_commands(root_cli)
        runner = CliRunner()
        result = runner.invoke(root_cli, ["--help"])

        assert result.exit_code == 0
        assert "asset" in result.output

    def test_asset_help_lists_resource_subgroups(self, root_cli, mock_resources):
        """'asset --help' shows dc-tag, repos, and apps as subcommands."""
        from ketacli.plugins.resource import register_asset_commands

        register_asset_commands(root_cli)
        runner = CliRunner()
        result = runner.invoke(root_cli, ["asset", "--help"])

        assert result.exit_code == 0
        assert "dc-tag" in result.output
        assert "repos" in result.output
        assert "apps" in result.output

    def test_oracle_apps_help_shows_market(self, root_cli, mock_resources):
        """'asset --help' shows apps-market as a direct subcommand (flat layout)."""
        from ketacli.plugins.resource import register_asset_commands

        register_asset_commands(root_cli)
        runner = CliRunner()
        result = runner.invoke(root_cli, ["asset", "--help"])

        assert result.exit_code == 0
        assert "apps-market" in result.output

    def test_nested_resource_without_parent_goes_to_asset(self, mocker, root_cli):
        """'foo/bar' becomes 'foo-bar' directly under asset (flat layout)."""
        from ketacli.plugins.resource import register_asset_commands

        resources = {
            "foo/bar": {
                "path": "foo/bar",
                "desc": "Orphan nested",
                "methods": {"list": {"path": "foo/bar", "method": "get"}},
            },
        }
        mocker.patch("ketacli.plugins.resource.get_resources", return_value=resources)

        register_asset_commands(root_cli)
        asset_group = root_cli.commands["asset"]

        assert "foo-bar" in asset_group.commands

    def test_empty_resources_does_not_crash(self, mocker, root_cli):
        """When get_resources returns {}, the asset group is still created (empty)."""
        from ketacli.plugins.resource import register_asset_commands

        mocker.patch("ketacli.plugins.resource.get_resources", return_value={})
        register_asset_commands(root_cli)

        assert "asset" in root_cli.commands
        assert len(root_cli.commands["asset"].commands) == 0

    def test_multi_level_nesting_adds_to_closest_parent(self, mocker, root_cli):
        """'a/b/c' becomes 'a-b-c' directly under asset (flat layout)."""
        from ketacli.plugins.resource import register_asset_commands

        resources = {
            "a": {
                "path": "a",
                "methods": {"list": {"path": "a", "method": "get"}},
            },
            "a/b/c": {
                "path": "a/b/c",
                "methods": {"list": {"path": "a/b/c", "method": "get"}},
            },
        }
        mocker.patch("ketacli.plugins.resource.get_resources", return_value=resources)

        register_asset_commands(root_cli)
        asset_group = root_cli.commands["asset"]

        assert "a" in asset_group.commands
        assert "a-b-c" in asset_group.commands


# =============================================================================
# Large-scale resource registration
# =============================================================================


class TestManyResources:
    """Tests for correct behavior with a large number of resources."""

    def test_all_56_resources_have_commands(self, mocker, root_cli):
        """When 56 resources are defined, every one gets a group with at least list."""
        from ketacli.plugins.resource import register_asset_commands

        TOTAL = 56
        resources = {}
        for i in range(TOTAL):
            name = f"res-{i:03d}"
            resources[name] = {
                "path": name,
                "desc": f"Resource {i}",
                "methods": {"list": {"path": name, "method": "get"}},
            }
        mocker.patch("ketacli.plugins.resource.get_resources", return_value=resources)

        register_asset_commands(root_cli)
        asset_group = root_cli.commands["asset"]

        assert len(asset_group.commands) == TOTAL
        for i in range(TOTAL):
            name = f"res-{i:03d}"
            assert name in asset_group.commands
            assert "list" in asset_group.commands[name].commands


# =============================================================================
# Edge cases — all '/' names must result in nested groups
# =============================================================================


class TestNestedSlashNames:
    """Any resource_name containing '/' must result in nested group structure."""

    def test_every_slash_resource_nested_or_orphaned(self, mocker, root_cli):
        """Every '/' resource gets flat name with '-' and lives directly under asset."""
        from ketacli.plugins.resource import register_asset_commands

        resources = {
            "parent": {
                "path": "parent",
                "methods": {"list": {"path": "parent", "method": "get"}},
            },
            "parent/child": {
                "path": "parent/child",
                "methods": {"list": {"path": "parent/child", "method": "get"}},
            },
            "orphan/alone": {
                "path": "orphan/alone",
                "methods": {"list": {"path": "orphan/alone", "method": "get"}},
            },
        }
        mocker.patch("ketacli.plugins.resource.get_resources", return_value=resources)

        register_asset_commands(root_cli)
        asset_group = root_cli.commands["asset"]

        # parent/child → 'parent-child' directly under asset
        assert "parent-child" in asset_group.commands
        # orphan/alone → 'orphan-alone' directly under asset
        assert "orphan-alone" in asset_group.commands

    def test_multiple_children_under_same_parent(self, mocker, root_cli):
        """Several 'parent/alpha', 'parent/beta' all live flat under asset."""
        from ketacli.plugins.resource import register_asset_commands

        resources = {
            "parent": {
                "path": "parent",
                "methods": {"list": {"path": "parent", "method": "get"}},
            },
            "parent/alpha": {
                "path": "parent/alpha",
                "methods": {"list": {"path": "parent/alpha", "method": "get"}},
            },
            "parent/beta": {
                "path": "parent/beta",
                "methods": {"list": {"path": "parent/beta", "method": "get"}},
            },
            "parent/gamma": {
                "path": "parent/gamma",
                "methods": {"list": {"path": "parent/gamma", "method": "get"}},
            },
        }
        mocker.patch("ketacli.plugins.resource.get_resources", return_value=resources)

        register_asset_commands(root_cli)
        asset_group = root_cli.commands["asset"]

        assert "parent" in asset_group.commands
        assert "parent-alpha" in asset_group.commands
        assert "parent-beta" in asset_group.commands
        assert "parent-gamma" in asset_group.commands
