"""Tests for ketacli.sdk.request.asset_map module.

Covers: get_request_path, load_yaml_config, get_resources, get_resource,
resolve_asset_id.
"""

import pytest
from unittest.mock import MagicMock

from ketacli.sdk.request.asset_map import (
    get_request_path,
    get_resource,
    get_resources,
    load_yaml_config,
    resolve_asset_id,
)


# =============================================================================
# get_request_path
# =============================================================================


class TestGetRequestPath:
    """Tests for get_request_path()."""

    def test_method_is_dict(self, mocker):
        """When method config is a dict, returns (path, method, data) from it."""
        mock_asset_map = {
            "repos": {
                "path": "repos",
                "methods": {
                    "list": {
                        "path": "repos/list",
                        "method": "get",
                        "data": {"fields": ["name"]},
                    },
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock_asset_map,
        )
        path, method, data = get_request_path("repos", "list")
        assert path == "repos/list"
        assert method == "get"
        assert data == {"fields": ["name"]}

    def test_method_is_string(self, mocker):
        """When method config is a plain string, path=str, req_method=original, data={}."""
        mock_asset_map = {
            "repos": {
                "path": "repos",
                "methods": {
                    "get": "repos/simple",
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock_asset_map,
        )
        path, method, data = get_request_path("repos", "get")
        assert path == "repos/simple"
        assert method == "get"
        assert data == {}

    def test_method_not_in_config(self, mocker):
        """When method absent from config, fallback to top-level path and 'put'."""
        mock_asset_map = {
            "repos": {
                "path": "repos/fallback",
                "methods": {
                    "list": {"path": "repos/list", "method": "get"},
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock_asset_map,
        )
        path, method, data = get_request_path("repos", "delete")
        assert path == "repos/fallback"
        assert method == "put"
        assert data == {}

    def test_asset_type_not_found(self, mocker):
        """Unknown asset_type returns (original_name, method, {})."""
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value={"other": {}},
        )
        path, method, data = get_request_path("nonexistent", "list")
        assert path == "nonexistent"
        assert method == "list"
        assert data == {}

    def test_fuzzy_match_singular_to_plural(self, mocker):
        """Singular input 'repo' matches plural key 'repos' in asset map."""
        mock_asset_map = {
            "repos": {
                "path": "repos",
                "methods": {
                    "list": {"path": "repos/list", "method": "get"},
                },
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock_asset_map,
        )
        path, method, data = get_request_path("repo", "list")
        assert path == "repos/list"
        assert method == "get"

    def test_method_not_in_config_no_methods_key(self, mocker):
        """When asset_map[key] has no 'methods' key at all, fallback to 'put'."""
        mock_asset_map = {
            "repos": {
                "path": "repos/fallback",
            }
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock_asset_map,
        )
        path, method, data = get_request_path("repos", "list")
        assert path == "repos/fallback"
        assert method == "put"
        assert data == {}


# =============================================================================
# load_yaml_config
# =============================================================================


class TestLoadYamlConfig:
    """Tests for load_yaml_config()."""

    def _make_mock_file(self, name):
        """Helper: create a MagicMock that looks like a Traversable YAML file."""
        m = MagicMock()
        m.name = name
        m.open.return_value.__enter__.return_value = MagicMock()
        return m

    def _make_mock_api_dir(self, files):
        """Helper: create a MagicMock for the api/ Traversable directory."""
        api_dir = MagicMock()
        api_dir.is_dir.return_value = True
        api_dir.iterdir.return_value = files
        return api_dir

    def test_valid_yaml_file(self, mocker):
        """A single YAML file is loaded and returned as a config dict."""
        mock_file = self._make_mock_file("test_asset.yaml")
        api_dir = self._make_mock_api_dir([mock_file])

        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        mocker.patch("importlib.resources.files", return_value=mock_files)
        mocker.patch(
            "ketacli.sdk.request.asset_map.yaml.safe_load",
            return_value={"repos": {"path": "repos", "desc": "仓库"}},
        )

        config = load_yaml_config()
        assert config == {"repos": {"path": "repos", "desc": "仓库"}}

    def test_multiple_yaml_files_merged(self, mocker):
        """Multiple YAML files are merged into one config dict."""
        mock_r = self._make_mock_file("repos.yaml")
        mock_a = self._make_mock_file("apps.yaml")
        api_dir = self._make_mock_api_dir([mock_r, mock_a])

        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        contents = {
            mock_r.open.return_value.__enter__.return_value: {"repos": {"path": "repos"}},
            mock_a.open.return_value.__enter__.return_value: {"apps": {"path": "apps"}},
        }

        mocker.patch("importlib.resources.files", return_value=mock_files)
        mocker.patch(
            "ketacli.sdk.request.asset_map.yaml.safe_load",
            side_effect=lambda stream: contents.get(stream, {}),
        )

        config = load_yaml_config()
        assert config == {"repos": {"path": "repos"}, "apps": {"path": "apps"}}

    def test_empty_directory(self, mocker):
        """Empty YAML directory returns empty dict."""
        api_dir = self._make_mock_api_dir([])
        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        mocker.patch("importlib.resources.files", return_value=mock_files)

        config = load_yaml_config()
        assert config == {}

    def test_directory_not_found(self, mocker):
        """When api/ directory does not exist, returns empty dict."""
        api_dir = MagicMock()
        api_dir.is_dir.return_value = False

        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        mocker.patch("importlib.resources.files", return_value=mock_files)

        config = load_yaml_config()
        assert config == {}

    def test_config_yaml_excluded(self, mocker):
        """A file named config.yaml is NOT loaded."""
        mock_config = self._make_mock_file("config.yaml")
        mock_repos = self._make_mock_file("repos.yaml")
        api_dir = self._make_mock_api_dir([mock_config, mock_repos])

        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        mock_safe_load = mocker.patch(
            "ketacli.sdk.request.asset_map.yaml.safe_load",
            return_value={"repos": {"path": "repos"}},
        )

        mocker.patch("importlib.resources.files", return_value=mock_files)

        config = load_yaml_config()
        assert config == {"repos": {"path": "repos"}}
        # yaml.safe_load should only be called once (repos.yaml, NOT config.yaml)
        assert mock_safe_load.call_count == 1

    def test_yaml_load_error_skipped(self, mocker):
        """A YAML file that raises during safe_load is skipped."""
        mock_bad = self._make_mock_file("bad.yaml")
        mock_good = self._make_mock_file("good.yaml")
        api_dir = self._make_mock_api_dir([mock_bad, mock_good])

        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        bad_handle = mock_bad.open.return_value.__enter__.return_value
        good_handle = mock_good.open.return_value.__enter__.return_value

        def yaml_side_effect(stream):
            if stream is bad_handle:
                raise ValueError("Bad YAML content")
            return {"good_type": {"path": "good"}}

        mocker.patch("importlib.resources.files", return_value=mock_files)
        mocker.patch(
            "ketacli.sdk.request.asset_map.yaml.safe_load",
            side_effect=yaml_side_effect,
        )
        mocker.patch("builtins.print")

        config = load_yaml_config()
        assert config == {"good_type": {"path": "good"}}

    def test_yaml_load_returns_none_skipped(self, mocker):
        """A YAML file that safe_loads to None is skipped."""
        mock_file = self._make_mock_file("empty.yaml")
        api_dir = self._make_mock_api_dir([mock_file])

        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        mocker.patch("importlib.resources.files", return_value=mock_files)
        mocker.patch(
            "ketacli.sdk.request.asset_map.yaml.safe_load",
            return_value=None,
        )

        config = load_yaml_config()
        assert config == {}

    def test_skip_non_yaml_files(self, mocker):
        """Files not ending in .yaml are skipped."""
        mock_txt = self._make_mock_file("notes.txt")
        mock_yml = self._make_mock_file("data.yml")  # .yml != .yaml
        api_dir = self._make_mock_api_dir([mock_txt, mock_yml])

        mock_files = MagicMock()
        mock_files.joinpath.return_value = api_dir

        mocker.patch("importlib.resources.files", return_value=mock_files)

        config = load_yaml_config()
        assert config == {}


# =============================================================================
# get_resources
# =============================================================================


class TestGetResources:
    """Tests for get_resources()."""

    def test_delegates_to_load_yaml_config(self, mocker):
        """get_resources returns whatever load_yaml_config returns."""
        expected = {"repos": {"path": "repos"}}
        mocker.patch(
            "ketacli.sdk.request.asset_map.load_yaml_config",
            return_value=expected,
        )
        assert get_resources() == expected


# =============================================================================
# get_resource
# =============================================================================


class TestGetResource:
    """Tests for get_resource()."""

    def test_asset_exists(self, mocker):
        """Existing asset type returns its config dict."""
        mock_config = {
            "repos": {"path": "repos", "desc": "仓库"},
            "apps": {"path": "apps"},
        }
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value=mock_config,
        )
        assert get_resource("repos") == {"path": "repos", "desc": "仓库"}

    def test_asset_not_found(self, mocker):
        """Missing asset type returns None."""
        mocker.patch(
            "ketacli.sdk.request.asset_map.get_resources",
            return_value={"other": {}},
        )
        assert get_resource("nonexistent") is None


# =============================================================================
# resolve_asset_id
# =============================================================================


class TestResolveAssetId:
    """Tests for resolve_asset_id()."""

    def test_asset_id_takes_priority(self):
        """kwargs['asset_id'] is used first, injects 'id' and 'name'."""
        kwargs = {"asset_id": "abc-123"}
        resolve_asset_id(kwargs, name="test-name")
        assert kwargs["asset_id"] == "abc-123"
        assert kwargs["id"] == "abc-123"
        assert kwargs["name"] == "test-name"

    def test_id_fallback(self):
        """kwargs['id'] is used when asset_id absent, injects 'asset_id'."""
        kwargs = {"id": "def-456"}
        resolve_asset_id(kwargs)
        assert kwargs["asset_id"] == "def-456"
        assert kwargs["id"] == "def-456"

    def test_name_last_resort(self):
        """name parameter is used when neither asset_id nor id present."""
        kwargs = {}
        resolve_asset_id(kwargs, name="fallback-name")
        assert kwargs["asset_id"] == "fallback-name"
        assert kwargs["id"] == "fallback-name"
        assert kwargs["name"] == "fallback-name"

    def test_all_none_no_modification(self):
        """When all sources are None/absent, kwargs unchanged."""
        kwargs = {}
        resolve_asset_id(kwargs)
        assert kwargs == {}

    def test_asset_id_overrides_id(self):
        """When both asset_id and id are present, asset_id wins."""
        kwargs = {"asset_id": "asset-1", "id": "id-1"}
        resolve_asset_id(kwargs)
        assert kwargs["asset_id"] == "asset-1"
        assert kwargs["id"] == "asset-1"

    def test_existing_name_not_overridden(self):
        """Name parameter does not overwrite an existing 'name' in kwargs."""
        kwargs = {"asset_id": "abc", "name": "existing"}
        resolve_asset_id(kwargs, name="new-name")
        assert kwargs["name"] == "existing"

    def test_empty_string_asset_id_falls_through(self):
        """Empty string asset_id is falsy, falls through to id then name."""
        kwargs = {"asset_id": ""}
        resolve_asset_id(kwargs, name="named")
        assert kwargs["asset_id"] == "named"
        assert kwargs["id"] == "named"
        assert kwargs["name"] == "named"
