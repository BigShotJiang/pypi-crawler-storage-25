"""Tests for ketacli.sdk.base.config — cluster config management.

NOTE: The functions in config.py construct the config path inline via
``os.path.expanduser('~/.keta')`` + ``config.yaml`` — they do NOT use the
module-level ``AUTH_FILE_PATH`` constant.  All tests therefore monkeypatch
``os.path.expanduser`` to point at a ``tmp_path`` so real ``~/.keta`` is
never touched.
"""

import os

import pytest
import yaml

from ketacli.sdk.base.config import (
    delete_cluster,
    get_current_cluster,
    list_clusters,
    set_default_cluster,
)

# =============================================================================
# Helpers & shared data
# =============================================================================

SAMPLE_CLUSTERS = [
    {"name": "dev", "endpoint": "http://dev:9000", "token": "tok1", "default": True},
    {"name": "prod", "endpoint": "http://prod:9000", "token": "tok2", "default": False},
]


def _write_config(tmp_path, clusters):
    """Write *clusters* (list of dict) to ``tmp_path / config.yaml``."""
    path = tmp_path / "config.yaml"
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(clusters, f, default_flow_style=False)
    return path


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def config_dir(tmp_path, monkeypatch):
    """Redirect ``os.path.expanduser`` to a temporary directory.

    Every function in ``config.py`` computes the config path with::

        config_dir = os.path.expanduser('~/.keta')
        config_path = os.path.join(config_dir, 'config.yaml')

    By replacing ``expanduser`` with a simple identity that returns our
    *tmp_path*, all file I/O stays inside the per-test temporary directory.
    """
    monkeypatch.setattr("os.path.expanduser", lambda _: str(tmp_path))
    return tmp_path


# =============================================================================
# list_clusters
# =============================================================================

class TestListClusters:
    """list_clusters() — read cluster list from config.yaml."""

    def test_valid_yaml(self, config_dir):
        """Happy path: parse a YAML list of cluster dicts."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        assert list_clusters() == SAMPLE_CLUSTERS

    def test_single_cluster(self, config_dir):
        """A config with exactly one cluster."""
        clusters = [{"name": "only", "endpoint": "http://localhost:9000"}]
        _write_config(config_dir, clusters)
        assert list_clusters() == clusters

    def test_empty_yaml_list(self, config_dir):
        """``[]`` in YAML → empty Python list."""
        _write_config(config_dir, [])
        assert list_clusters() == []

    def test_empty_file_returns_none(self, config_dir):
        """A zero-byte file causes ``yaml.load`` to return ``None``."""
        (config_dir / "config.yaml").write_text("")
        assert list_clusters() is None

    def test_missing_file_raises(self, config_dir):
        """When no config file exists, ``open()`` raises ``FileNotFoundError``."""
        with pytest.raises(FileNotFoundError):
            list_clusters()


# =============================================================================
# set_default_cluster
# =============================================================================

class TestSetDefaultCluster:
    """set_default_cluster(name) — mark one cluster as default."""

    def test_set_existing_cluster(self, config_dir):
        """Setting ``prod`` as default → its ``default`` is ``True``, ``dev`` becomes ``False``."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        result = set_default_cluster("prod")
        assert result[0]["default"] is False  # dev
        assert result[1]["default"] is True  # prod

        # Verify the file on disk was updated too
        with open(config_dir / "config.yaml") as f:
            saved = yaml.safe_load(f)
        assert saved[0]["default"] is False
        assert saved[1]["default"] is True

    def test_switch_default(self, config_dir):
        """Switching default between clusters multiple times works."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        set_default_cluster("prod")
        set_default_cluster("dev")
        result = set_default_cluster("prod")
        assert result[0]["default"] is False
        assert result[1]["default"] is True

    def test_non_existent_name(self, config_dir):
        """A name that doesn't match any cluster sets **all** to ``default=False``."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        result = set_default_cluster("nonexistent")
        assert result[0]["default"] is False
        assert result[1]["default"] is False

    def test_single_cluster(self, config_dir):
        """Setting default on the only cluster works."""
        clusters = [{"name": "only", "endpoint": "http://localhost:9000"}]
        _write_config(config_dir, clusters)
        result = set_default_cluster("only")
        assert result[0]["default"] is True

    def test_empty_config_raises_type_error(self, config_dir):
        """An empty file (``None`` conf) causes ``TypeError`` on iteration."""
        (config_dir / "config.yaml").write_text("")
        with pytest.raises(TypeError):
            set_default_cluster("dev")


# =============================================================================
# delete_cluster
# =============================================================================

class TestDeleteCluster:
    """delete_cluster(name) — remove a cluster from the config."""

    def test_delete_existing(self, config_dir):
        """Deleting ``dev`` removes it; only ``prod`` remains."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        result = delete_cluster("dev")
        assert len(result) == 1
        assert result[0]["name"] == "prod"

    def test_delete_non_existent(self, config_dir):
        """Deleting a name that doesn't exist leaves config unchanged."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        result = delete_cluster("nonexistent")
        assert len(result) == 2

    def test_delete_last_cluster(self, config_dir):
        """Removing the last cluster results in an empty list."""
        clusters = [{"name": "only", "endpoint": "http://localhost:9000"}]
        _write_config(config_dir, clusters)
        result = delete_cluster("only")
        assert result == []

    def test_delete_updates_file_on_disk(self, config_dir):
        """Verify the underlying YAML file is actually rewritten."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        delete_cluster("prod")
        with open(config_dir / "config.yaml") as f:
            saved = yaml.safe_load(f)
        assert len(saved) == 1
        assert saved[0]["name"] == "dev"

    def test_empty_config_raises_type_error(self, config_dir):
        """An empty file (``None`` conf) causes ``TypeError`` on iteration."""
        (config_dir / "config.yaml").write_text("")
        with pytest.raises(TypeError):
            delete_cluster("dev")


# =============================================================================
# get_current_cluster
# =============================================================================

class TestGetCurrentCluster:
    """get_current_cluster() — return the cluster with ``default: True``."""

    def test_has_default(self, config_dir):
        """When one cluster has ``default=True``, return it."""
        _write_config(config_dir, SAMPLE_CLUSTERS)
        result = get_current_cluster()
        assert result["name"] == "dev"
        assert result["default"] is True

    def test_no_default(self, config_dir):
        """No cluster has ``default=True`` → empty ``dict``."""
        clusters = [
            {"name": "dev", "endpoint": "http://dev:9000", "default": False},
            {"name": "prod", "endpoint": "http://prod:9000", "default": False},
        ]
        _write_config(config_dir, clusters)
        assert get_current_cluster() == {}

    def test_multiple_clusters_one_default(self, config_dir):
        """Only the cluster with ``default=True`` is returned."""
        clusters = [
            {"name": "dev", "endpoint": "http://dev:9000", "default": True},
            {"name": "prod", "endpoint": "http://prod:9000", "default": False},
            {"name": "staging", "endpoint": "http://staging:9000", "default": False},
        ]
        _write_config(config_dir, clusters)
        result = get_current_cluster()
        assert result["name"] == "dev"

    def test_empty_list_returns_empty_dict(self, config_dir):
        """An empty cluster list yields an empty dict (the loop never executes)."""
        _write_config(config_dir, [])
        assert get_current_cluster() == {}

    def test_empty_config_raises_type_error(self, config_dir):
        """An empty file (``None`` conf) causes ``TypeError`` on iteration."""
        (config_dir / "config.yaml").write_text("")
        with pytest.raises(TypeError):
            get_current_cluster()
