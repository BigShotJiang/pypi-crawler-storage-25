"""Tests for ketacli.plugins.docs — pure logic mapping (no Click command invocation).

Tests only the core doc name → filename mapping logic: normalization, alias
resolution, doc_map lookup, error handling, and file reading. Does NOT invoke
the ``@click.command()`` decorator or use ``CliRunner`` — calls
``docs.callback`` directly to exercise the raw function body.
"""

from unittest.mock import call, mock_open

import pytest

from ketacli.plugins.docs import docs

# =========================================================================
# Helper
# =========================================================================


def _path_matches(path, expected_suffix):
    """Check if a path-like argument ends with *expected_suffix* (OS-agnostic)."""
    return str(path).replace("\\", "/").endswith(expected_suffix)


def _setup_success_mocks(mocker, content="test doc content"):
    """Patch ``open`` and ``Path.exists`` so the doc function can succeed."""
    m_open = mock_open(read_data=content)
    mocker.patch("builtins.open", m_open)
    mocker.patch("pathlib.Path.exists", return_value=True)
    mocker.patch("ketacli.plugins.docs.console.print")
    return m_open


def _assert_error_printed(print_mock, expected_substring):
    """Assert that ``console.print`` was called with a red error message."""
    assert any(
        expected_substring in str(call_args)
        for call_args in print_mock.call_args_list
    ), f"Expected error containing {expected_substring!r} in {print_mock.call_args_list}"


# =========================================================================
# Known name → filename mapping
# =========================================================================


class TestKnownNameMapping:
    """Docs that exist in ``doc_map`` should resolve to the correct filename."""

    def test_log_search_syntax(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("log-search-syntax")
        assert _path_matches(m_open.call_args[0][0], "log_search_syntax.md")

    def test_metric_search_syntax(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("metric-search-syntax")
        assert _path_matches(m_open.call_args[0][0], "metric_search_syntax.md")

    def test_simple_search(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("simple-search")
        assert _path_matches(m_open.call_args[0][0], "simple_search.md")

    def test_simple_metric_search(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("simple-metric-search")
        assert _path_matches(m_open.call_args[0][0], "simple_metric_search.md")

    def test_system(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("system")
        assert _path_matches(m_open.call_args[0][0], "system.md")

    def test_transformer(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("transformer")
        assert _path_matches(m_open.call_args[0][0], "transformer.md")


# =========================================================================
# Alias resolution
# =========================================================================


class TestAliasResolution:
    """Aliases defined in the ``alias`` dict should resolve to canonical names."""

    def test_logs_alias(self, mocker):
        """'logs' is an alias for 'log-search-syntax' → 'log_search_syntax.md'."""
        m_open = _setup_success_mocks(mocker)
        docs.callback("logs")
        assert _path_matches(m_open.call_args[0][0], "log_search_syntax.md")

    def test_metrics_alias(self, mocker):
        """'metrics' is an alias for 'metric-search-syntax' → 'metric_search_syntax.md'."""
        m_open = _setup_success_mocks(mocker)
        docs.callback("metrics")
        assert _path_matches(m_open.call_args[0][0], "metric_search_syntax.md")

    def test_repos_alias(self, mocker):
        """'repos' is an alias for 'log-search-syntax' (same as 'logs')."""
        m_open = _setup_success_mocks(mocker)
        docs.callback("repos")
        assert _path_matches(m_open.call_args[0][0], "log_search_syntax.md")


# =========================================================================
# Direct .md filename passthrough
# =========================================================================


class TestDirectMdFilename:
    """Names ending with ``.md`` bypass both alias and doc_map lookups."""

    def test_direct_md_used_as_is(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("custom_doc.md")
        assert _path_matches(m_open.call_args[0][0], "custom_doc.md")

    def test_known_name_with_dot_md_passthrough(self, mocker):
        """Even a known name like 'log-search-syntax.md' is used directly."""
        m_open = _setup_success_mocks(mocker)
        docs.callback("log-search-syntax.md")
        assert _path_matches(m_open.call_args[0][0], "log-search-syntax.md")


# =========================================================================
# Name normalization
# =========================================================================


class TestNameNormalization:
    """Names are stripped, lowercased, and spaces replaced with dashes."""

    def test_uppercase_normalized(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("LOG-SEARCH-SYNTAX")
        assert _path_matches(m_open.call_args[0][0], "log_search_syntax.md")

    def test_mixed_case_normalized(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("Metric-Search-Syntax")
        assert _path_matches(m_open.call_args[0][0], "metric_search_syntax.md")

    def test_spaces_replaced_with_dashes(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("metric search syntax")
        assert _path_matches(m_open.call_args[0][0], "metric_search_syntax.md")

    def test_leading_trailing_whitespace_stripped(self, mocker):
        m_open = _setup_success_mocks(mocker)
        docs.callback("  log-search-syntax  ")
        assert _path_matches(m_open.call_args[0][0], "log_search_syntax.md")

    def test_multiple_spaces_become_multiple_dashes(self, mocker):
        """Multiple consecutive spaces become consecutive dashes (unknown → error)."""
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("log  search  syntax")
        _assert_error_printed(print_mock, "不支持的文档")


# =========================================================================
# Error handling — unsupported name
# =========================================================================


class TestUnsupportedName:
    """Names not in ``doc_map`` or ``alias`` produce an error message."""

    def test_unknown_name_prints_error(self, mocker):
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("unsupported-name")
        _assert_error_printed(print_mock, "不支持的文档")

    def test_empty_string_prints_error(self, mocker):
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("")
        _assert_error_printed(print_mock, "不支持的文档")

    def test_none_prints_error(self, mocker):
        """The function uses ``(name or "")`` to handle None gracefully."""
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback(None)
        _assert_error_printed(print_mock, "不支持的文档")


# =========================================================================
# Error handling — file not found
# =========================================================================


class TestFileNotFound:
    """A valid name whose file doesn't exist on disk prints a different error."""

    def test_known_name_file_missing(self, mocker):
        mocker.patch("pathlib.Path.exists", return_value=False)
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("log-search-syntax")
        _assert_error_printed(print_mock, "文档不存在")

    def test_direct_md_file_missing(self, mocker):
        mocker.patch("pathlib.Path.exists", return_value=False)
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("custom_doc.md")
        _assert_error_printed(print_mock, "文档不存在")


# =========================================================================
# Success path — file read and content printing
# =========================================================================


class TestSuccessPath:
    """Happy path: file exists → opened → content printed to console."""

    def test_console_print_receives_content(self, mocker):
        mocker.patch("builtins.open", mock_open(read_data="hello docs"))
        mocker.patch("pathlib.Path.exists", return_value=True)
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("log-search-syntax")
        print_mock.assert_called_once()
        args, _ = print_mock.call_args
        assert "hello docs" in str(args[0]), f"Expected content in {args}"

    def test_multiline_content_printed(self, mocker):
        content = "line1\nline2\nline3"
        mocker.patch("builtins.open", mock_open(read_data=content))
        mocker.patch("pathlib.Path.exists", return_value=True)
        print_mock = mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("system")
        args, _ = print_mock.call_args
        assert "line1\nline2\nline3" in str(args[0])

    def test_open_with_utf8_encoding(self, mocker):
        m_open = mock_open(read_data="content")
        mocker.patch("builtins.open", m_open)
        mocker.patch("pathlib.Path.exists", return_value=True)
        mocker.patch("ketacli.plugins.docs.console.print")
        docs.callback("transformer")
        # Verify open was called with encoding='utf-8'
        call_kwargs = m_open.call_args[1]
        assert call_kwargs.get("encoding") == "utf-8"
