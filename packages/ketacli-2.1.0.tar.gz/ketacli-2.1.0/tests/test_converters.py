"""Tests for ketacli.sdk.converters — all 8 converter functions + apply_field_converter."""

import json

import pytest

from ketacli.sdk.converters import (
    CONVERTER_REGISTRY,
    apply_field_converter,
    format_boolean,
    format_bytes,
    format_duration,
    format_enum,
    format_json,
    format_number,
    format_timestamp,
    format_truncate,
)


# =============================================================================
# format_timestamp
# =============================================================================

class TestFormatTimestamp:
    """format_timestamp(value, format='%Y-%m-%d %H:%M:%S', tz='UTC')"""

    @pytest.mark.parametrize(
        ("value", "fmt", "tz", "expected"),
        [
            # Happy path – seconds
            (1609459200, "%Y-%m-%d %H:%M:%S", "UTC", "2021-01-01 00:00:00"),
            # Happy path – milliseconds (> 1e10 triggers /1000)
            (1609459200000, "%Y-%m-%d %H:%M:%S", "UTC", "2021-01-01 00:00:00"),
            # Timezone offset +08:00
            (1609459200, "%Y-%m-%d %H:%M:%S", "+08:00", "2021-01-01 08:00:00"),
            # Short timezone +8
            (1609459200, "%Y-%m-%d %H:%M:%S", "+8", "2021-01-01 08:00:00"),
            # Negative timezone -05:00
            (1609459200, "%Y-%m-%d %H:%M:%S", "-05:00", "2020-12-31 19:00:00"),
            # Short negative timezone -5
            (1609459200, "%Y-%m-%d %H:%M:%S", "-5", "2020-12-31 19:00:00"),
            # String input
            ("1609459200", "%Y-%m-%d %H:%M:%S", "UTC", "2021-01-01 00:00:00"),
            # Custom format
            (1609459200, "%Y/%m/%d", "UTC", "2021/01/01"),
            # Custom format with time component
            (1609459200, "%Y-%m-%d %H:%M:%S", "UTC", "2021-01-01 00:00:00"),
        ],
    )
    def test_happy_path(self, value, fmt, tz, expected):
        assert format_timestamp(value, format=fmt, tz=tz) == expected

    def test_none_returns_empty_string(self):
        assert format_timestamp(None) == ""

    def test_unrecognized_type_returns_str(self):
        """Non-numeric, non-string types are converted via str()."""
        assert format_timestamp([1, 2, 3]) == "[1, 2, 3]"

    def test_unrecognized_tz_falls_back_to_utc(self):
        """If tz is not 'UTC' and doesn't start with +/- -> fallback to UTC."""
        result = format_timestamp(1609459200, tz="invalid")
        assert result == "2021-01-01 00:00:00"

    def test_invalid_timestamp_string_returns_str(self):
        """A string that can't be parsed as float returns the original string."""
        result = format_timestamp("not-a-timestamp")
        assert result == "not-a-timestamp"


# =============================================================================
# format_bytes
# =============================================================================

class TestFormatBytes:
    """format_bytes(value, unit='auto')"""

    @pytest.mark.parametrize(
        ("value", "unit", "expected"),
        [
            (0, "auto", "0.00 B"),
            (500, "auto", "500 B"),
            (1024, "auto", "1.00 KB"),
            (10240, "auto", "10.0 KB"),
            (102400, "auto", "100 KB"),
            (1048576, "auto", "1.00 MB"),
            (1073741824, "auto", "1.00 GB"),
            (1099511627776, "auto", "1.00 TB"),
            (1024, "B", "1024.00 B"),
            (1024, "KB", "1.00 KB"),
            (1048576, "MB", "1.00 MB"),
            (1073741824, "GB", "1.00 GB"),
            (1099511627776, "TB", "1.00 TB"),
            # Negative value stays in base unit (condition < 1024)
            (-1024, "auto", "-1024.00 B"),
        ],
    )
    def test_various(self, value, unit, expected):
        assert format_bytes(value, unit=unit) == expected

    def test_none_returns_empty_string(self):
        assert format_bytes(None) == ""

    def test_invalid_unit_returns_str(self):
        """When unit is not recognized, return str(value)."""
        assert format_bytes(1024, unit="INVALID") == "1024"

    def test_non_numeric_returns_str(self):
        assert format_bytes("abc") == "abc"

    def test_float_input(self):
        assert format_bytes(0.5, unit="auto") == "0.50 B"


# =============================================================================
# format_number
# =============================================================================

class TestFormatNumber:
    """format_number(value, precision=2, thousands_sep=',')"""

    @pytest.mark.parametrize(
        ("value", "precision", "sep", "expected"),
        [
            # Default precision=2 with thousands separator
            (1234.5678, 2, ",", "1,234.57"),
            # precision=0 truncates via int() (not round)
            (1234.5678, 0, ",", "1,234"),
            # Custom thousands separator replaces comma
            (1234.56, 2, ".", "1.234.56"),
            # Whitespace as separator
            (1234567, 2, " ", "1 234 567.00"),
            # Integer input
            (42, 2, ",", "42.00"),
            # Large number
            (9999999.99, 2, ",", "9,999,999.99"),
            # Rounding up
            (0.9999, 2, ",", "1.00"),
            # String numeric input
            ("1234.56", 2, ",", "1,234.56"),
        ],
    )
    def test_various(self, value, precision, sep, expected):
        assert format_number(value, precision=precision, thousands_sep=sep) == expected

    def test_none_returns_empty_string(self):
        assert format_number(None) == ""

    def test_non_numeric_returns_str(self):
        assert format_number("not-a-number") == "not-a-number"

    def test_negative_number(self):
        result = format_number(-1234.56, precision=2)
        assert result == "-1,234.56"


# =============================================================================
# format_boolean
# =============================================================================

class TestFormatBoolean:
    """format_boolean(value, true_text='是', false_text='否')"""

    @pytest.mark.parametrize(
        ("value", "true_text", "false_text", "expected"),
        [
            # bool True / False
            (True, "是", "否", "是"),
            (False, "是", "否", "否"),
            # String truthy values
            ("true", "是", "否", "是"),
            ("True", "是", "否", "是"),
            ("TRUE", "是", "否", "是"),
            ("1", "是", "否", "是"),
            ("yes", "是", "否", "是"),
            ("on", "是", "否", "是"),
            # String falsy values
            ("false", "是", "否", "否"),
            ("False", "是", "否", "否"),
            ("0", "是", "否", "否"),
            ("no", "是", "否", "否"),
            ("off", "是", "否", "否"),
            # Numeric truthy / falsy
            (1, "是", "否", "是"),
            (0, "是", "否", "否"),
            (0.0, "是", "否", "否"),
            (0.1, "是", "否", "是"),
            (-1, "是", "否", "是"),
            # Custom text
            (True, "YES", "NO", "YES"),
            (False, "YES", "NO", "NO"),
        ],
    )
    def test_various(self, value, true_text, false_text, expected):
        assert format_boolean(value, true_text=true_text, false_text=false_text) == expected

    def test_none_returns_empty_string(self):
        assert format_boolean(None) == ""

    def test_unrecognized_string_returns_original(self):
        """A string that isn't in truthy/falsy lists returns str(value)."""
        assert format_boolean("unknown") == "unknown"

    def test_other_type_returns_str(self):
        """Types that aren't bool/str/int/float return str(value)."""
        assert format_boolean([1, 2]) == "[1, 2]"

    def test_all_truthy_string_variants(self):
        """Verify that common truthy strings map to true_text."""
        for s in ("true", "True", "TRUE", "1", "yes", "YES", "on", "ON"):
            assert format_boolean(s) == "是"

    def test_all_falsy_string_variants(self):
        """Verify that common falsy strings map to false_text."""
        for s in ("false", "False", "FALSE", "0", "no", "NO", "off", "OFF"):
            assert format_boolean(s) == "否"


# =============================================================================
# format_json
# =============================================================================

class TestFormatJson:
    """format_json(value, indent=None)"""

    def test_dict_input(self):
        """A dict should be serialized to JSON."""
        result = format_json({"a": 1, "b": 2})
        assert json.loads(result) == {"a": 1, "b": 2}

    def test_dict_input_with_indent(self):
        """With indent=2, the output should have 2-space indentation."""
        result = format_json({"a": 1, "b": 2}, indent=2)
        assert result == '{\n  "a": 1,\n  "b": 2\n}'

    def test_json_string_input(self):
        """A valid JSON string should be parsed and re-serialized."""
        result = format_json('{"a": 1, "b": 2}')
        assert json.loads(result) == {"a": 1, "b": 2}

    def test_json_string_with_indent(self):
        result = format_json('{"a": 1, "b": 2}', indent=2)
        assert result == '{\n  "a": 1,\n  "b": 2\n}'

    def test_list_input(self):
        result = format_json([1, 2, 3])
        assert result == "[1, 2, 3]"

    def test_none_returns_empty_string(self):
        assert format_json(None) == ""

    def test_invalid_json_string_returns_original(self):
        """An invalid JSON string should be returned as-is (str)."""
        assert format_json("not-json") == "not-json"

    def test_non_serializable_returns_str(self):
        """A value that can't be serialized (e.g. a complex object) returns str(value)."""

        class Unserializable:
            pass

        result = format_json(Unserializable())
        assert isinstance(result, str)


# =============================================================================
# format_truncate
# =============================================================================

class TestFormatTruncate:
    """format_truncate(value, max_length=50, suffix='...')"""

    def test_short_text_unchanged(self):
        """Text shorter than max_length is returned as-is."""
        assert format_truncate("short") == "short"

    def test_exact_max_length(self):
        """Text exactly at max_length is returned unchanged."""
        text = "a" * 50
        assert format_truncate(text) == text

    def test_long_text_truncated(self):
        """Text exceeding max_length is truncated with suffix."""
        text = "a" * 100
        result = format_truncate(text, max_length=10)
        # max_length=10, suffix='...' (3 chars), so 7 chars + '...' = 10 chars
        assert result == "aaaaaaa..."
        assert len(result) == 10

    def test_custom_suffix(self):
        text = "a" * 100
        result = format_truncate(text, max_length=10, suffix=">>>")
        # 7 chars + '>>>' = 10 chars
        assert result == "aaaaaaa>>>"

    def test_none_returns_empty_string(self):
        assert format_truncate(None) == ""

    def test_non_string_converted(self):
        """Non-string values are converted via str() first."""
        assert format_truncate(12345, max_length=10) == "12345"

    def test_truncate_with_short_max_length(self):
        text = "hello world"
        result = format_truncate(text, max_length=2, suffix="...")
        assert result == "hello worl..."

    def test_max_length_zero(self):
        text = "hello"
        result = format_truncate(text, max_length=0, suffix="...")
        assert result == "he..."

    def test_integer_value(self):
        """Integer input should be str()-converted and truncated if needed."""
        result = format_truncate(1234567890, max_length=5, suffix="..")
        assert result == "123.."


# =============================================================================
# format_enum
# =============================================================================

class TestFormatEnum:
    """format_enum(value, enum_map)"""

    def test_mapped_value(self):
        assert format_enum("active", {"active": "活跃", "inactive": "未激活"}) == "活跃"

    def test_unmapped_value_returns_original(self):
        assert format_enum("unknown", {"active": "活跃"}) == "unknown"

    def test_none_returns_empty_string(self):
        assert format_enum(None, {"active": "活跃"}) == ""

    def test_int_value_mapped(self):
        """Integer values are str()-converted before lookup."""
        assert format_enum(1, {"1": "one", "2": "two"}) == "one"

    def test_int_value_unmapped(self):
        assert format_enum(3, {"1": "one", "2": "two"}) == "3"

    def test_empty_map(self):
        """With an empty map, any value returns its str()."""
        assert format_enum("anything", {}) == "anything"


# =============================================================================
# format_duration
# =============================================================================

class TestFormatDuration:
    """format_duration(value, src_unit='s', dst_unit='s')"""

    @pytest.mark.parametrize(
        ("value", "src_unit", "dst_unit", "expected"),
        [
            # s -> s
            (120, "s", "s", "120.00秒"),
            # s -> m
            (120, "s", "m", "2.00分"),
            # s -> h
            (3600, "s", "h", "1.00时"),
            # s -> d
            (86400, "s", "d", "1.00天"),
            # s -> ms
            (1, "s", "ms", "1000.00毫秒"),
            # ms -> s: not supported (ms is not a src_unit key), returns str
            (5000, "ms", "s", "5000"),
            # m -> s
            (2, "m", "s", "120.00秒"),
            # m -> h
            (120, "m", "h", "2.00时"),
            # h -> m
            (2, "h", "m", "120.00分"),
            # d -> h
            (1, "d", "h", "24.00时"),
        ],
    )
    def test_various(self, value, src_unit, dst_unit, expected):
        assert format_duration(value, src_unit=src_unit, dst_unit=dst_unit) == expected

    def test_none_returns_empty_string(self):
        assert format_duration(None) == ""

    def test_invalid_src_unit_returns_str(self):
        """Unrecognized src_unit returns str(value)."""
        assert format_duration(120, src_unit="invalid", dst_unit="s") == "120"

    def test_invalid_dst_unit_returns_str(self):
        """Unrecognized dst_unit returns str(value)."""
        assert format_duration(120, src_unit="s", dst_unit="invalid") == "120"

    def test_non_numeric_returns_str(self):
        assert format_duration("abc") == "abc"

    def test_negative_duration(self):
        result = format_duration(-120, src_unit="s", dst_unit="m")
        assert result == "-2.00分"

    def test_zero_duration(self):
        result = format_duration(0, src_unit="s", dst_unit="m")
        assert result == "0.00分"

    def test_fractional_result(self):
        """Fractional durations are formatted with 2 decimal places."""
        result = format_duration(1, src_unit="s", dst_unit="h")
        assert result == "0.00时"


# =============================================================================
# apply_field_converter
# =============================================================================

class TestApplyFieldConverter:
    """apply_field_converter(value, convert_config)"""

    def test_format_timestamp_dispatched(self):
        config = {"function": "format_timestamp", "args": [{"format": "%Y-%m-%d"}]}
        result = apply_field_converter(1609459200, config)
        assert result == "2021-01-01"

    def test_format_bytes_dispatched(self):
        config = {"function": "format_bytes", "args": [{"unit": "KB"}]}
        result = apply_field_converter(2048, config)
        assert result == "2.00 KB"

    def test_format_number_dispatched(self):
        config = {"function": "format_number", "args": [{"precision": 0}]}
        result = apply_field_converter(1234.56, config)
        assert result == "1,234"

    def test_format_boolean_dispatched(self):
        config = {"function": "format_boolean", "args": [{"true_text": "Y", "false_text": "N"}]}
        assert apply_field_converter(True, config) == "Y"
        assert apply_field_converter(False, config) == "N"

    def test_format_json_dispatched(self):
        config = {"function": "format_json", "args": [{"indent": 2}]}
        result = apply_field_converter({"a": 1}, config)
        assert result == '{\n  "a": 1\n}'

    def test_format_truncate_dispatched(self):
        config = {"function": "format_truncate", "args": [{"max_length": 5}]}
        result = apply_field_converter("hello world", config)
        assert result == "he..."

    def test_format_enum_dispatched(self):
        config = {"function": "format_enum", "args": [{"enum_map": {"active": "活跃"}}]}
        result = apply_field_converter("active", config)
        assert result == "活跃"

    def test_format_duration_dispatched(self):
        config = {"function": "format_duration", "args": [{"src_unit": "s", "dst_unit": "m"}]}
        result = apply_field_converter(120, config)
        assert result == "2.00分"

    def test_no_args(self):
        """Converter with no additional args should still work."""
        config = {"function": "format_truncate", "args": []}
        text = "a" * 100
        result = apply_field_converter(text, config)
        assert result == "a" * 47 + "..."

    def test_none_config_returns_str_value(self):
        assert apply_field_converter("hello", None) == "hello"

    def test_none_config_with_none_value_returns_empty(self):
        assert apply_field_converter(None, None) == ""

    def test_empty_config_returns_str_value(self):
        assert apply_field_converter("hello", {}) == "hello"

    def test_config_without_function_key_returns_str_value(self):
        assert apply_field_converter("hello", {"not_function": "x"}) == "hello"

    def test_invalid_function_name_returns_str_value(self):
        config = {"function": "does_not_exist"}
        assert apply_field_converter("hello", config) == "hello"

    def test_none_value_with_valid_config_returns_call_result(self):
        """None value with a config that handles None (returning "")."""
        config = {"function": "format_truncate", "args": []}
        assert apply_field_converter(None, config) == ""

    def test_args_with_field_key_is_skipped(self):
        """Args dicts containing 'field' key should skip that key."""
        config = {
            "function": "format_truncate",
            "args": [{"field": "name", "max_length": 5}],
        }
        result = apply_field_converter("hello world", config)
        assert result == "he..."

    def test_simple_string_arg_is_ignored(self):
        """Non-dict args should be ignored."""
        config = {
            "function": "format_truncate",
            "args": ["should_be_ignored", {"max_length": 5}],
        }
        result = apply_field_converter("hello world", config)
        assert result == "he..."

    def test_invalid_kwargs_triggers_exception_handler(self):
        """Passing unrecognized kwargs triggers the except Exception handler."""
        config = {
            "function": "format_truncate",
            "args": [{"nonexistent_param": "value"}],
        }
        result = apply_field_converter("hello", config)
        assert result == "hello"

    def test_exception_handler_with_none_value(self):
        """Exception handler returns '' when value is None."""
        config = {
            "function": "format_truncate",
            "args": [{"nonexistent_param": "value"}],
        }
        result = apply_field_converter(None, config)
        assert result == ""


# =============================================================================
# CONVERTER_REGISTRY completeness
# =============================================================================

class TestConverterRegistry:
    """Verify CONVERTER_REGISTRY contains all expected converters."""

    def test_registry_has_all_8_functions(self):
        expected = {
            "format_timestamp",
            "format_bytes",
            "format_number",
            "format_boolean",
            "format_json",
            "format_truncate",
            "format_enum",
            "format_duration",
        }
        assert set(CONVERTER_REGISTRY.keys()) == expected

    def test_registry_values_are_callable(self):
        for name, func in CONVERTER_REGISTRY.items():
            assert callable(func), f"{name} is not callable"
