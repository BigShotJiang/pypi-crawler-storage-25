"""Shared pytest fixtures for ketacli tests."""

import os
import tempfile

import pytest


def _clean_template_caches(template_cls):
    """Safely clear Template class-level caches by clearing any dict caches found."""
    for attr in ("_template_cache", "_faker_instances"):
        cache = getattr(template_cls, attr, None)
        if isinstance(cache, dict):
            cache.clear()


@pytest.fixture(scope="function")
def tmp_config_dir(monkeypatch):
    """Monkeypatch AUTH_FILE_PATH to a temp path to prevent real config reads."""
    with tempfile.NamedTemporaryFile(delete=False, suffix=".yaml") as f:
        tmp_path = f.name
    monkeypatch.setattr("ketacli.sdk.base.config.AUTH_FILE_PATH", tmp_path)
    yield tmp_path
    try:
        os.unlink(tmp_path)
    except OSError:
        pass


@pytest.fixture(scope="function")
def sample_records():
    """Return a standard list of dict records for testing."""
    return [
        {"name": "test1", "value": 1},
        {"name": "test2", "value": 2},
    ]


@pytest.fixture(scope="function")
def sample_resp_dict():
    """Return a standard API-style response dict for testing."""
    return {
        "total": 2,
        "items": [
            {"name": "a"},
            {"name": "b"},
        ],
    }


@pytest.fixture(scope="function", autouse=True)
def clean_template_cache():
    """Clean Template class-level caches before and after each test.

    Clears ``Template._template_cache`` and ``Template._faker_instances``
    dicts at the start and end of every test to prevent cross-test pollution.
    """
    from ketacli.sdk.util import Template

    _clean_template_caches(Template)

    yield

    _clean_template_caches(Template)
