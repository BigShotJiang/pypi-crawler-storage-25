from setuptools import setup, find_packages

setup(
    name='ketacli',
    version='2.1.0',
    packages=find_packages(),
    package_data={
        'ketacli': [
            'charts/*',
            'hosts/*',
        ],
        'ketacli.sdk.request': ['api/*'],
    },
    include_package_data=True,
    license='MIT',
    description='KetaDB Client',
    long_description=open('README.md', encoding='UTF-8').read(),
    long_description_content_type='text/markdown',
    author='lvheyang',
    author_email='cuiwenzheng@ymail.com',
    url='https://xishuhq.com',
    install_requires=[
        "requests~=2.31.0",
        "prettytable~=3.10.0",
        "pyyaml~=6.0.1",
        "click>=8.1.0",
        "argcomplete~=3.3.0",
        "faker~=24.11.0",
        "jinja2~=3.1.3",
        "rich>=13.7.1",
        "toon-py>=1.0.2",
    ],
    entry_points={
        'console_scripts': [
            'ketacli=ketacli.ketacli:start',
        ],
    },
)
