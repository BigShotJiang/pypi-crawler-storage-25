import json
import argcomplete
from ketacli.cli import cli, escape_rich, console

# Import all plugin modules to register their commands
from ketacli.plugins import search
from ketacli.plugins import data
from ketacli.plugins import config

# Add search commands
cli.add_command(search.search, 'search')
search.search.help = "Search logs and metrics using SPL syntax"
cli.add_command(search.benchmark, 'benchmark')
search.benchmark.help = "Benchmark SPL/PQL query performance"

# Add data commands
cli.add_command(data.insert, 'insert')
data.insert.help = "Upload JSON data to a repository"

# Add config commands (config is a group)
cli.add_command(config.config, 'config')
cli.add_command(config.version_cmd, 'version')

# Add dynamic asset commands (ketacli asset <resource> <operation>)
from ketacli.plugins.resource import register_asset_commands
register_asset_commands(cli)

# Import mock module
from ketacli.plugins.mock import mock
cli.add_command(mock, 'mock')
mock.help = "Generate and upload mock data (logs, metrics, or generic)"

# Import test module
from ketacli.sdk.test.cli import test_command


def start():
    try:
        cli(standalone_mode=False)
    except SystemExit:
        pass
    except Exception as e:
        error_msg = str(e)
        
        if error_msg.startswith("('Bad request'") or error_msg.startswith("('Server error'"):
            try:
                parts = eval(error_msg)
                if len(parts) >= 5:
                    status_code = parts[1]
                    url = parts[2]
                    method = parts[3].upper()
                    response_text = parts[4]
                    
                    try:
                        resp = json.loads(response_text)
                        code = resp.get("Code", "")
                        message = resp.get("Message", "")
                        console.print(f"[red]Error {escape_rich(status_code)}[/red]")
                        if code:
                            console.print(f"[red]{escape_rich(code)}[/red]: {escape_rich(message)}")
                        else:
                            console.print(f"[red]{escape_rich(message)}[/red]")
                        return
                    except:
                        pass
            except:
                pass
        
        if error_msg.startswith("Usage:"):
            console.print(f"[red]Error:[/red] {error_msg}")
        else:
            console.print(f"[red]Error:[/red] {escape_rich(error_msg)}")


if __name__ == "__main__":
    start()