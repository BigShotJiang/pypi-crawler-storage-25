import os
import click
import yaml
from rich.console import Console
from ketacli.sdk.chart.layout import LayoutChart
import importlib.resources as pkg_resources

console = Console()


def get_chart_names(prefix):
    charts_dir = pkg_resources.files('ketacli').joinpath('charts')
    return [
        x.replace('.yaml', '').replace('.yml', '')
        for x in os.listdir(str(charts_dir)) if x.startswith(prefix)
    ]


def get_theme_names(prefix):
    themes = ["default", "dark", "clear", "pro", "matrix", "windows",
              "retro", "elegant", "mature", "dreamland", "grandpa",
              "salad", "girly", "serious", "sahara", "scream"]
    return [x for x in themes if x.startswith(prefix)]


@click.command('dashboard')
@click.option("-c", "--chart", help="Built-in chart name (e.g., monitor, infra-host, k8s-monitor)")
@click.option("-f", "--file_path", "--file", "file_path", help="Path to YAML chart config file")
@click.option("--interval", default=30, help="Refresh interval in seconds")
@click.option("--theme", help="Chart theme (dark/light)")
@click.option("-d", "--disable_auto_refresh", is_flag=True, default=True, flag_value=False, help="Disable auto refresh")
def dashboard(chart, file_path, interval, theme, disable_auto_refresh):
    """Display live dashboard from built-in chart or YAML config"""
    if file_path is None and chart is None:
        console.print("Please specify file path with --file or --chart")
        return
    if chart is not None:
        file_path = str(pkg_resources.files('ketacli').joinpath('charts', f"{chart}.yaml"))
    config = yaml.safe_load(open(file_path, encoding="utf-8"))
    chart = LayoutChart(config)
    chart.live(interval=interval, theme=theme, disable_auto_refresh=disable_auto_refresh)