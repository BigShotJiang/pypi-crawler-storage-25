"""
数据操作相关命令模块
"""
import json
import click
from rich.console import Console
from ketacli.sdk.base.client import request_post

console = Console()


@click.command()
@click.option("--repo", default="default", help='Target repository name')
@click.option("--data", default=None, help='JSON data to insert (array format: [{"field":"value"}])')
@click.option("--file", default=None, help='Read JSON data from file')
def insert(repo, data, file):
    """Upload data to specified repo"""
    if repo is None:
        console.print(f"Please specify target repo with --repo")
        return
    if data is None and file is None:
        console.print(f"Please use --data or --file to specify data to upload")
        return

    if file is not None:
        f = open(file, encoding="utf-8")
        data = f.read()

    query_params = {
        "repo": repo,
    }
    resp = request_post("data", json.loads(data), query_params).json()
    console.print(resp, overflow="fold", markup=False)