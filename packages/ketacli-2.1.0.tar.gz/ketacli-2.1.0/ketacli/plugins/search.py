import sys
import time
from datetime import datetime
import click
from rich.console import Console
from rich.live import Live
from rich.progress import Progress
from concurrent.futures import ProcessPoolExecutor
from ketacli.sdk.base.search import search_spl, search_spl_meta, search_pql
from ketacli.sdk.output.output import search_result_output
from ketacli.sdk.output.format import format_table

console = Console()


def _get_format_completion(ctx, param, incomplete):
    formats = ["table", "text", "json", "csv", "html", "latex"]
    return [x for x in formats if x.startswith(incomplete)]


@click.command('search')
@click.argument('spl', type=str)
@click.option('--start', type=str, help='Start time. Format: "2024-01-02 10:10:10"')
@click.option('--end', type=str, help='End time. Format: "2024-01-02 10:10:10"')
@click.option('-l', '--limit', type=int, default=100, help='Limit the query result size')
@click.option('-f', '--format', 'format_', type=str, help='Output format', shell_complete=_get_format_completion)
@click.option('--raw', is_flag=True, help='Output raw timestamps')
@click.option('-w', '--watch', is_flag=True, help='Watch resource changes')
@click.option('--interval', type=float, default=3.0, help='Watch refresh interval')
@click.option('--debug', is_flag=True, help='Output debug info including server-side query duration')
def search(spl, start, end, limit, format_, raw, watch, interval, debug):
    if start is not None:
        start = datetime.strptime(start, '%Y-%m-%d %H:%M:%S')
    if end is not None:
        end = datetime.strptime(end, '%Y-%m-%d %H:%M:%S')

    def generate_table():
        resp = search_spl(spl=spl, start=start, end=end, limit=limit)
        if isinstance(resp, dict) and resp.get("failed"):
            console.print(f"[red]Error: {resp['failed']}[/red]")
            return None, True
        result = search_result_output(resp)
        return format_table(result, format_, not raw), False

    def generate_table_with_debug():
        import time as time_module
        start_ts = int(time_module.time()) - 3600
        end_ts = int(time_module.time())
        meta_resp = search_spl_meta(spl=spl, start=start_ts, end=end_ts, limit=limit)
        resp = search_spl(spl=spl, start=start, end=end, limit=limit)
        if isinstance(resp, dict) and resp.get("failed"):
            console.print(f"[red]Error: {resp['failed']}[/red]")
            return None, True
        result = search_result_output(resp)
        console.print(f"[dim][DEBUG] Server query duration: {meta_resp.get('duration', 0)}ms[/dim]")
        return format_table(result, format_, not raw), False

    if watch:
        table_func = generate_table_with_debug if debug else generate_table
        with Live(table_func(), console=console, refresh_per_second=1) as live:
            while True:
                try:
                    table, is_error = table_func()
                    if is_error or table is None:
                        break
                    live.update(table)
                    time.sleep(interval)
                except KeyboardInterrupt:
                    live.stop()
                    sys.exit()

    else:
        table, is_error = generate_table_with_debug() if debug else generate_table()
        if is_error:
            sys.exit(1)
        if table is None:
            console.print(f"we cannot find any data")
        else:
            console.print(table, overflow="fold")


@click.command('benchmark')
@click.option('--type', 'benchmark_type', type=click.Choice(['spl', 'pql']), default='spl', help='Query type (spl or pql)')
@click.option('--query', type=str, help='The spl/pql query string')
@click.option('--file-path', type=str, help='File path containing queries (one per line, takes precedence over --query)')
@click.option('--start', type=float, default=0.0, help='Start timestamp')
@click.option('--end', type=float, help='End timestamp')
@click.option('-l', '--limit', type=int, help='Limit size of query result')
@click.option('-c', '--cnt', type=int, default=1, help='Number of iterations per query')
@click.option('-w', '--workers', type=int, default=1, help='Number of parallel workers')
@click.option('-b', '--base-url', type=str, default='', help='PQL base URL')
@click.option('--window', type=float, default=0, help='Time window size in seconds for batch queries')
def benchmark(benchmark_type, query, file_path, start, end, limit, cnt, workers, base_url, window):
    result = {
        "type": benchmark_type,
        "query": query,
        "cnt": cnt,
        "results": [],
        "waiting": 0,
        'request_cnt': cnt
    }
    futures = []
    started = time.time()
    if not end:
        end = time.time()
    if file_path:
        with open(file_path, "r") as f:
            querys = f.readlines()
    elif query:
        querys = [query]
    else:
        raise Exception("query must be specified via --query or --file-path")
    with Progress() as progress:
        if window:
            new_cnt = int((end - start) / window) * cnt * len(querys)
            result['request_cnt'] = new_cnt
        else:
            new_cnt = cnt * len(querys)
            result['request_cnt'] = new_cnt
        task = progress.add_task(f"[green]Benchmarking total: {new_cnt}...", total=new_cnt)
        with ProcessPoolExecutor(max_workers=workers) as executor:

            if not window:
                for _ in range(cnt):
                    for query_item in querys:
                        if benchmark_type == "spl":
                            futures.append(
                                executor.submit(search_spl_meta, spl=query_item, start=start, end=end, limit=limit))
                        elif benchmark_type == "pql":
                            futures.append(
                                executor.submit(search_pql, base_url=base_url, pql=query_item, start=start, end=end,
                                                limit=limit))
            else:

                while True:
                    new_end = start + window
                    print(datetime.fromtimestamp(start).strftime('%d-%H:%M:%S'),
                          datetime.fromtimestamp(new_end).strftime('%H:%M:%S'), )
                    if new_end > end:
                        break
                    for query_item in querys:
                        if benchmark_type == "spl":
                            for _ in range(cnt):
                                futures.append(
                                    executor.submit(search_spl_meta, spl=query_item, start=start, end=new_end, limit=limit))
                        elif benchmark_type == "pql":
                            for _ in range(cnt):
                                futures.append(
                                    executor.submit(search_pql, base_url=base_url, pql=query_item, start=start, end=new_end,
                                                    limit=limit))
                    start += window

            for future in futures:
                resp = future.result()
                result["results"].append(resp)
                result["avg_duration"] = sum([x["duration"] for x in result["results"]]) / len(result["results"])
                progress.update(task, advance=1)
    result["waiting"] = time.time() - started
    result["total_duration"] = round(sum([x["duration"] for x in result["results"] if "duration" in x]))
    result['totalSize'] = sum([x["resultSize"] for x in result["results"] if "resultSize" in x])
    console.print(result, markup=False)