"""
Dynamic CLI module - generates `ketacli asset <resource> <operation>` commands from YAML configs.

This module reads resource definitions from the YAML configs in sdk/request/api/*.yaml
and dynamically creates Click subcommands for listing and operating on each resource type.
"""
import json
import click
from ketacli.cli import console, escape_rich, _parse_extra, get_resources
from ketacli.sdk.request.list import list_assets_request
from ketacli.sdk.request.asset_map import get_request_path, resolve_asset_id
from ketacli.sdk.base.client import request, request_get, upload_file
from ketacli.sdk.util import Template
from ketacli.sdk.output.format import format_table
from ketacli.sdk.output.output import list_output
import ketacli.sdk.render.hooks  # noqa: F401 — trigger hook registration
from ketacli.sdk.render.registry import HookRegistry


def _format_list_output(resource_name, resp, format_='table', output_fields=None,
                        field_aliases=None, field_converters=None, raw_output=False):
    if output_fields is None:
        output_fields = []
    if field_aliases is None:
        field_aliases = {}
    if field_converters is None:
        field_converters = {}

    table = list_output(
        resource_name,
        output_fields=output_fields,
        resp=resp,
        field_aliases=field_aliases,
        field_converters=field_converters,
        raw_output=raw_output,
    )
    if table is None:
        console.print(f"no {resource_name} found")
        return
    rendered = format_table(table, format_, prettify=not raw_output)
    console.print(rendered, overflow="fold")


def make_list_cmd(name, config):
    """Generate list subcommand with --query, --sort, --order, -l, -f, -e options.

    Args:
        name: Full resource name (YAML key, e.g. 'repos', 'apps/market')
        config: Resource config dict from YAML
    """
    @click.command('list')
    @click.option('--query', type=str, default='', help='Fuzzy query filter')
    @click.option('--sort', type=str, default='updateTime', help='Field to sort by')
    @click.option('--order', type=str, default='desc', help='Sort order: desc|asc')
    @click.option('-l', '--page-size', 'page_size', type=int, default=10, help='Page size')
    @click.option('-f', '--format', 'format_', type=str, default='table', help='Output format')
    @click.option('-e', '--extra', type=str, help='Extra query params, key=val,key2=val2')
    def list_cmd(query, sort, order, page_size, format_, extra):
        """List {resource} resources."""
        extra_dict = _parse_extra(extra)
        kwargs = {}
        kwargs.update(extra_dict)

        try:
            req_info = list_assets_request(
                name, groupId=-1, order=order, pageNo=1,
                pageSize=page_size, query=query, sort=sort, **kwargs,
            )
            static_data = req_info.get("_static_data")
            if static_data is not None:
                resp = {"items": static_data, "total": len(static_data)}
            else:
                resp = request_get(
                    req_info["path"],
                    req_info["query_params"],
                    req_info["custom_headers"],
                ).json()

            output_fields = req_info.get("default_fields", [])
            field_aliases = req_info.get("field_aliases", {})
            field_converters = req_info.get("field_converters", {})

            _format_list_output(
                name, resp, format_=format_,
                output_fields=output_fields,
                field_aliases=field_aliases,
                field_converters=field_converters,
            )
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")

    list_cmd.help = f"List {name} resources"
    return list_cmd


def make_operation_cmd(resource_name, method_name, method_config):
    """SINGLE FACTORY for ALL non-list operations (get/create/update/delete/install/...).

    All operations use -n/--name (optional) and -e/--extra (optional) as their ONLY parameters.
    The YAML config (retrieved via get_request_path) drives path, HTTP method, and data template.

    Args:
        resource_name: Full resource name (YAML key, e.g. 'alerts', 'apps/market')
        method_name: Operation name (e.g. 'get', 'create', 'install', 'uninstall')
        method_config: Method config from YAML (str path or dict with path/method/data)
    """
    params = [
        click.Option(['-n', '--name'], type=str, default=None, help='The target asset name/id'),
        click.Option(['-e', '--extra'], type=str, help='Extra args, key=val,key2=val2'),
    ]

    is_multipart = isinstance(method_config, dict) and method_config.get("body_type") == "multipart"
    if is_multipart:
        params.append(click.Option(['-f', '--file'], type=str, default=None, help='File path to upload'))

    if isinstance(method_config, dict) and method_config.get("options"):
        for opt_name, opt_cfg in method_config["options"].items():
            flag = f"--{opt_name.replace('_', '-')}"
            if opt_cfg.get("is_flag"):
                params.append(click.Option([flag], is_flag=True, default=False, help=opt_cfg.get("help", "")))
            else:
                params.append(click.Option([flag], type=str, default=opt_cfg.get("default"), help=opt_cfg.get("help", "")))

    def callback(name, extra, file=None, **dynamic_opts):
        try:
            extra_dict = _parse_extra(extra)
            kwargs = {}
            kwargs.update(extra_dict)

            path_template_str, http_method, data_template = get_request_path(
                resource_name, method_name
            )

            resolve_asset_id(kwargs, name)

            rendered_path = Template(path_template_str).render(**kwargs)

            if isinstance(data_template, dict) and data_template:
                data_json = json.dumps(data_template, ensure_ascii=False)
                rendered_data_str = Template(data_json).render(**kwargs)
                body_dict = json.loads(rendered_data_str)
            else:
                body_dict = None

            if is_multipart and file:
                form_fields = {}
                for param in method_config.get("form_fields", []):
                    val = kwargs.get(param["field"], param.get("default", ""))
                    if val:
                        form_fields[param["field"]] = str(val)
                resp = upload_file(rendered_path, file, form_fields)
            else:
                resp = request(http_method, rendered_path, data=body_dict)
            if resp is not None:
                hooks = []
                if isinstance(method_config, dict):
                    render_cfg = method_config.get("render")
                    if render_cfg:
                        hooks = list(render_cfg.get("hooks", []))
                        options = method_config.get("options", {})
                        for opt_name, opt_cfg in options.items():
                            hook_list = opt_cfg.get("hooks")
                            if hook_list and dynamic_opts.get(opt_name):
                                hooks = list(hook_list)
                                break

                if hooks:
                    content = resp.json().get("content", resp.text)
                    result = content
                    for hook_name in hooks:
                        fn = HookRegistry.get(hook_name)
                        result = fn(result, **dynamic_opts)
                    if result is not None:
                        if isinstance(result, str):
                            console.print(result, markup=False)
                        else:
                            console.print(result)
                else:
                    try:
                        result = resp.json()
                        console.print(json.dumps(result, ensure_ascii=False, indent=2), overflow="fold", markup=False)
                    except Exception:
                        console.print(resp.text, markup=False)
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")

    operation_cmd = click.Command(method_name, params=params, callback=callback)
    operation_cmd.help = f"{method_name} {resource_name} resource"
    return operation_cmd


def _build_resource_group(full_name, config):
    """Create a Click.Group per resource type, populated with list + operation subcommands.

    The Click group name is the full resource name with '/' replaced by '-'
    (e.g. 'apps-market' for 'apps/market'). The full_name is retained
    for YAML lookups (get_request_path, list_assets_request, etc.).

    Args:
        full_name: Full resource name (YAML key)
        config: Resource config dict from YAML

    Returns:
        click.Group with list and operation subcommands
    """
    group_name = full_name.replace('/', '-')
    desc = config.get('desc', full_name)
    group = click.Group(name=group_name, help=desc)

    methods = config.get('methods', {})

    if 'list' in methods or config.get('static_list'):
        group.add_command(make_list_cmd(full_name, config))

    for m_name, m_config in methods.items():
        if m_name == 'list':
            continue
        group.add_command(make_operation_cmd(full_name, m_name, m_config))

    return group


def register_asset_commands(cli):
    """Register `ketacli asset` Click.Group with all resource sub-groups.

    Reads all resource definitions from YAML configs via get_resources(),
    creates a Click.Group per resource type, and attaches them all under
    a top-level 'asset' command on the given CLI group.

    Resources with '/' in their name (e.g. 'apps/market') are added as
    sub-groups of their parent group (e.g. 'market' under 'apps').

    Args:
        cli: The root Click.Group (from ketacli.cli)
    """
    resources = get_resources()

    asset_group = click.Group(
        name='asset',
        help='Asset management commands (dynamic, driven by YAML configs)',
    )

    resource_groups = {}
    for resource_name, config in resources.items():
        resource_groups[resource_name] = _build_resource_group(resource_name, config)

    for group in resource_groups.values():
        asset_group.add_command(group)

    cli.add_command(asset_group)
