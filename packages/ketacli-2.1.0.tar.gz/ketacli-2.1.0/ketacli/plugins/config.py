import importlib.metadata
import getpass
import click
from rich.console import Console
from ketacli.sdk.base.config import list_clusters, set_default_cluster, delete_cluster
from ketacli.sdk.base.client import do_login, do_login_with_password
from ketacli.sdk.output.output import list_output
from ketacli.sdk.output.format import format_table

console = Console()


@click.group('config')
def config():
    """Manage ketadb cluster configuration"""
    pass


@config.command('list')
def config_list():
    """List all clusters"""
    resp = list_clusters()
    if not resp:
        console.print("No clusters configured. Use 'ketacli config add -n <name> -e <endpoint> -t <token>' to add one.")
        return
    table = list_output('cluster', [], resp=resp)
    if table:
        console.print(format_table(table, "table"), overflow="fold")


@config.command('add')
@click.option('-n', '--name', type=str, help='Cluster name')
@click.option('-e', '--endpoint', type=str, help='Cluster endpoint URL')
@click.option('-t', '--token', type=str, help='API token')
@click.option('-u', '--username', type=str, help='Login username')
@click.option('-p', '--password', type=str, help='Login password')
def config_add(name, endpoint, token, username, password):
    """Add/login to a new cluster"""
    if not name:
        console.print("[red]Please specify cluster name with -n, --name[/red]")
        return
    if not endpoint:
        console.print("[red]Please specify endpoint with -e, --endpoint[/red]")
        return

    if token:
        do_login(name=name, endpoint=endpoint, token=token)
        console.print(f"[green]Cluster '{name}' added successfully.[/green]")
    elif username:
        if not password:
            password = getpass.getpass(f"Password for {username}: ")
        do_login_with_password(endpoint=endpoint, username=username, password=password, name=name)
    else:
        console.print("[red]Please specify either --token or --username (and optionally --password).[/red]")
        return


@config.command('remove')
@click.option('-n', '--name', type=str, required=True, help='Cluster name')
def config_remove(name):
    """Remove a cluster"""
    resp = delete_cluster(name)
    if resp is None:
        console.print(f"[red]Cluster '{name}' not found.[/red]")
        return
    console.print(f"[green]Cluster '{name}' removed.[/green]")


@config.command('use')
@click.option('-n', '--name', type=str, required=True, help='Cluster name')
def config_use(name):
    """Set default cluster"""
    resp = set_default_cluster(name)
    if resp is None:
        console.print(f"[red]Cluster '{name}' not found.[/red]")
        return
    console.print(f"[green]Default cluster set to '{name}'.[/green]")


@click.command('version')
def version_cmd():
    """Show version info"""
    _version = importlib.metadata.version('ketacli')
    console.print(_version, overflow="fold")