import logging
from pathlib import Path
import click
from rich.console import Console

console = Console()
logger = logging.getLogger("ketacli.auth")

_DOC_CHOICES = ["log-search-syntax", "metric-search-syntax", "simple-search", "simple-metric-search", "system", "transformer"]


@click.command('docs')
@click.argument("name", type=str)
def docs(name):
    """打印内置文档内容
    
    可选项：log-search-syntax, metric-search-syntax, simple-search, simple-metric-search, system, transformer
    也支持直接传入 .md 文件名，例如：log_search_syntax.md"""
    logger.info(f"show name={name}")
    base_dir = Path(__file__).parent.parent / "sdk" / "ai" / "prompts"
    logger.info(f"base_dir={base_dir}")
    normalized = (name or "").strip().lower()
    normalized = normalized.replace(" ", "-")
    alias = {"logs": "log-search-syntax", "metrics": "metric-search-syntax", "repos": "log-search-syntax"}
    normalized = alias.get(normalized, normalized)
    doc_map = {
        "log-search-syntax": "log_search_syntax.md",
        "metric-search-syntax": "metric_search_syntax.md",
        "simple-search": "simple_search.md",
        "simple-metric-search": "simple_metric_search.md",
        "system": "system.md",
        "transformer": "transformer.md",
    }
    filename = normalized if normalized.endswith(".md") else doc_map.get(normalized)
    if not filename:
        console.print(f"[red]不支持的文档：{name}[/red]")
        logger.warning(f"unsupported name={name}")
        return
    target_path = base_dir / filename
    logger.info(f"target_path={target_path}")
    if not target_path.exists():
        console.print(f"[red]文档不存在：{filename}[/red]")
        logger.warning(f"doc not found path={target_path}")
        return
    with open(target_path, "r", encoding="utf-8") as f:
        content = f.read()
    logger.info(f"read size={len(content)}")
    console.print(content, overflow="fold")