"""
KetaDB CLI - Click-based command line interface

This module provides the main Click group and shared utilities for the ketacli CLI.
"""
import click
from rich.console import Console
from importlib.metadata import version as _pkg_version

def get_version():
    try:
        return _pkg_version("ketacli")
    except Exception:
        return "unknown"

# Shared console instance for consistent output
console = Console()

# Import shared utilities from ketacli
from ketacli.sdk.util import parse_url_params
from ketacli.sdk.request.asset_map import get_resources


def escape_rich(s):
    """Escape Rich markup characters to prevent rendering issues."""
    if not s:
        return s
    return s.replace('[', '[[]').replace(']', '[]]')


def _parse_extra(extra):
    """Parse extra query parameters string into a dictionary."""
    return parse_url_params(extra) if extra else {}


def format_completer(prefix, options):
    """Generate completion suggestions based on prefix."""
    return [x for x in options if x.startswith(prefix)]


def asset_type_completer(prefix, **kwargs):
    """Complete asset_type argument with resource names."""
    return [x for x in get_resources().keys() if x.startswith(prefix)]


def format_type_completer(prefix, **kwargs):
    """Complete format argument with format options."""
    formats = ["table", "text", "json", "csv", "html", "latex"]
    return [x for x in formats if x.startswith(prefix)]


# Create the main Click group
@click.group()
@click.version_option(version=get_version())
def cli():
    """KetaDB CLI - Command line interface for KetaDB"""
    pass


# Re-export utilities for use by plugins
__all__ = [
    'cli',
    'console',
    'escape_rich',
    '_parse_extra',
    'parse_url_params',
    'get_resources',
    'asset_type_completer',
    'format_type_completer',
    'format_completer',
]