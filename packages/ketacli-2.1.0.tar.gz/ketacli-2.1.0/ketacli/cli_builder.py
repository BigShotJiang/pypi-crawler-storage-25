"""
Dynamic Command Builder for ketacli

This module dynamically generates Click commands based on YAML definitions
from the SDK request/api directory. It creates subcommands for admin operations
with proper CLI options derived from query_fields definitions.
"""
import click
import re
import yaml
from pathlib import Path
import sys
import time
from functools import wraps

from ketacli.cli import cli, console
from ketacli.sdk.base.client import request_get
from ketacli.sdk.request.list import list_admin_request, list_assets_request
from ketacli.sdk.output.output import list_output
from ketacli.sdk.output.format import format_table

_admin_group = None


def _load_yaml(path):
    """Load YAML file and return parsed content."""
    with open(path) as f:
        return yaml.safe_load(f)


def _get_admin_commands():
    """Load and parse admin.yaml to get all admin asset types with their query_fields.

    Returns:
        dict: {asset_name: {path, query_fields: [...]}}
    """
    yaml_path = Path(__file__).parent / "sdk" / "request" / "api" / "admin.yaml"
    data = _load_yaml(yaml_path)
    return data


def _get_all_list_commands():
    """Scan all YAML files for asset types with list query_fields.

    Returns:
        dict: {asset_type: {path, query_fields: [...], desc: str}}
    """
    api_dir = Path(__file__).parent / "sdk" / "request" / "api"
    result = {}

    for yaml_file in api_dir.glob("*.yaml"):
        if yaml_file.stem == "admin":
            continue

        data = _load_yaml(yaml_file)
        for asset_type, config in data.items():
            if "methods" not in config or "list" not in config.get("methods", {}):
                continue

            query_fields = []
            list_method = config.get("methods", {}).get("list", {})
            if isinstance(list_method, dict) and "query_fields" in list_method:
                query_fields = list_method["query_fields"]

            if not query_fields and "query_fields" in config:
                query_fields = config["query_fields"]

            if query_fields:
                # Get path from list method if available, else top-level path
                list_path = config.get("path", asset_type)
                if "methods" in config and "list" in config["methods"]:
                    list_method = config["methods"]["list"]
                    if isinstance(list_method, dict) and "path" in list_method:
                        list_path = list_method["path"]
                
                # Skip if path still has unresolved template variables ({{ }})
                # These require special handling with path parameters, not query fields
                if '{{' in list_path:
                    continue
                
                result[asset_type] = {
                    "path": list_path,
                    "query_fields": query_fields,
                    "desc": config.get("desc", asset_type)
                }

    return result


def _build_query_options(query_fields):
    """Build click options from query_fields definition.

    Args:
        query_fields: List of field definitions from YAML

    Returns:
        list: List of (param_decls, attrs) tuples for click.option
    """
    options = []
    for qf in query_fields:
        field = qf['field']
        required = qf.get('required', False)
        default = qf.get('default', None)
        help_text = qf.get('description', '')

        # Convert field name to click option: include_defaults -> --include-defaults, WithDocSize -> --with-doc-size
        option_name = field.replace('_', '-')
        # Also handle camelCase: WithDocSize -> with-doc-size
        import re
        option_name = re.sub(r'([A-Z])', r'-\1', option_name).lower()
        option_name = option_name.replace('---', '-').strip('-')

        # Skip 'format' field as we have our own --format option
        if field == 'format':
            continue

        param_decls = [f'--{option_name}']

        # Determine the type based on default value
        field_type = str
        if default is not None:
            if isinstance(default, bool):
                field_type = bool
            elif isinstance(default, int):
                field_type = int
            elif isinstance(default, float):
                field_type = float

        # For optional fields (required=False), do NOT use YAML default as CLI default
        # YAML defaults are API-level defaults, but CLI should only send values user explicitly sets
        cli_default = default if required else None

        attrs = {
            'default': cli_default,
            'type': field_type,
            'help': help_text or f"Query parameter: {field}"
        }

        # Use is_flag=True ONLY for explicit boolean flags that should NOT accept values
        # For query_fields with boolean defaults, keep them as regular options with type=bool
        # so they accept --field-name=true/false values

        options.append((param_decls, attrs))
    return options


def _convert_field_value(value):
    """Convert string values to appropriate types for API calls."""
    if value is None:
        return None
    return value


def register_admin_commands():
    """Register all admin subcommands dynamically based on YAML definitions.

    This function reads admin.yaml and creates Click commands for each admin asset type.
    Command names are derived from asset types, with '/' converted to '-'.

    Example:
        cluster/settings -> ketacli admin cluster-settings
    """
    admin_data = _get_admin_commands()

    for asset_type, config in admin_data.items():
        # Skip if no 'list' method defined
        if 'list' not in config.get('methods', {}):
            continue

        # Convert asset_type to command name: cluster/settings -> cluster-settings
        # Click doesn't allow '/' in command names
        cmd_name = asset_type.replace('/', '-')
        query_fields = config.get('query_fields', [])
        desc = config.get('desc', asset_type)

        # Build options for this command
        cmd_options = _build_query_options(query_fields)

        # Create command function with proper options
        @click.command(cmd_name)
        @click.option('-f', '--format', 'format_', default='table',
                     help='Output format (table, text, json, csv, html, latex)')
        @click.option('-w', '--watch', is_flag=True, help='Watch resource changes')
        @click.option('--interval', type=float, default=3.0, help='Watch refresh interval')
        def make_cmd(format_, watch, interval, cmd_name=cmd_name, desc=desc, **kwargs):
            """Dynamic admin command for {}.""".format(desc)

            # Convert field names back from --option-name to field_name
            extra_dict = {}
            for k, v in kwargs.items():
                # k is the option name with dashes, convert to field name
                converted_key = k.replace('-', '_')
                converted_value = _convert_field_value(v)
                if converted_value is not None:
                    extra_dict[converted_key] = converted_value

            # Convert command name back to asset type: cluster-settings -> cluster/settings
            actual_asset_type = cmd_name.replace('-', '/')

            def generate_table():
                req = list_admin_request(actual_asset_type, **extra_dict)
                resp = request_get(req["path"], req["query_params"],
                                  req["custom_headers"]).json()
                table = list_output(actual_asset_type, output_fields=[], resp=resp)
                if table is None:
                    return None
                return format_table(table, format_)

            if watch:
                with Live(generate_table(), console=console,
                         refresh_per_second=1) as live:
                    while True:
                        try:
                            table = generate_table()
                            live.update(table)
                            time.sleep(interval)
                        except KeyboardInterrupt:
                            live.stop()
                            sys.exit()
            else:
                table = generate_table()
                if table is None:
                    console.print(f"[yellow]No data found for {cmd_name}[/yellow]")
                else:
                    console.print(table)

        # Add query field options dynamically
        for param_decls, attrs in cmd_options:
            make_cmd = click.option(*param_decls, **attrs)(make_cmd)

        # Register command under the admin group
        _register_admin_command(make_cmd, cmd_name)


# Import Live here to avoid circular import
from rich.live import Live


def _register_admin_command(cmd, cmd_name):
    """Register a command under the admin group.

    Creates an 'admin' group if it doesn't exist yet.
    """
    global _admin_group
    if _admin_group is None:
        @click.group('admin')
        def admin_group():
            """Manage ketadb internal resources (ES/OpenSearch admin APIs)"""
            pass
        _admin_group = admin_group
        cli.add_command(admin_group, 'admin')

    _admin_group.add_command(cmd, cmd_name)


def register_list_commands():
    """Register all list subcommands dynamically based on YAML definitions.

    This function scans all YAML files in sdk/request/api/ (except admin.yaml)
    and creates Click commands for each asset type that has list query_fields.
    Command names are derived from asset types directly.

    Example:
        repos -> ketacli repos --with-doc-size
        alerts -> ketacli alerts --page-no --page-size
    """
    list_data = _get_all_list_commands()

    for asset_type, config in list_data.items():
        cmd_name = asset_type.replace('/', '-')
        query_fields = config.get('query_fields', [])
        desc = config.get('desc', asset_type)

        cmd_options = _build_query_options(query_fields)

        @click.command(cmd_name)
        @click.option('-f', '--format', 'format_', default='table',
                     help='Output format (table, text, json, csv, html, latex)')
        @click.option('-w', '--watch', is_flag=True, help='Watch resource changes')
        @click.option('--interval', type=float, default=3.0, help='Watch refresh interval')
        def make_cmd(format_, watch, interval, **kwargs):
            extra_dict = {}
            for k, v in kwargs.items():
                converted_key = k.replace('-', '_')
                converted_value = _convert_field_value(v)
                if converted_value is not None:
                    extra_dict[converted_key] = converted_value

            def generate_table():
                req = list_assets_request(asset_type, **extra_dict)
                resp = request_get(req["path"], req["query_params"],
                               req["custom_headers"]).json()
                default_fields = req.get("default_fields", [])
                field_aliases = req.get("field_aliases", {})
                field_converters = req.get("field_converters", {})
                table = list_output(asset_type, output_fields=default_fields,
                                   resp=resp, field_aliases=field_aliases,
                                   field_converters=field_converters)
                if table is None:
                    return None
                return format_table(table, format_)

            if watch:
                with Live(generate_table(), console=console,
                         refresh_per_second=1) as live:
                    while True:
                        try:
                            table = generate_table()
                            live.update(table)
                            time.sleep(interval)
                        except KeyboardInterrupt:
                            live.stop()
                            sys.exit()
            else:
                table = generate_table()
                if table is None:
                    console.print(f"[yellow]No data found for {asset_type}[/yellow]")
                else:
                    console.print(table)

        for param_decls, attrs in cmd_options:
            make_cmd = click.option(*param_decls, **attrs)(make_cmd)

        cli.add_command(make_cmd, cmd_name)


def register_all_commands():
    """Register all dynamic commands.

    Call this function after importing plugins to register
    all dynamically generated commands.
    """
    register_admin_commands()
    register_list_commands()