"""Chart SDK — terminal dashboard rendering."""
