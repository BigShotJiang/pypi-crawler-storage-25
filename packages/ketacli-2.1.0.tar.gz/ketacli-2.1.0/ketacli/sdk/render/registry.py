from typing import Callable

class HookRegistry:
    _hooks: dict[str, Callable] = {}

    @classmethod
    def register(cls, name: str):
        def decorator(fn):
            cls._hooks[name] = fn
            return fn
        return decorator

    @classmethod
    def get(cls, name: str) -> Callable:
        if name not in cls._hooks:
            raise ValueError(f"Unknown render hook: {name}")
        return cls._hooks[name]
