import re
from .registry import HookRegistry

@HookRegistry.register("extract_cdata_all")
def extract_cdata_all(content, **opts):
    parts = []
    for match in re.finditer(r'<!\[CDATA\[(.*?)\]\]>', content, re.DOTALL):
        md = match.group(1).strip()
        if md:
            parts.append(md)
    return "\n\n".join(parts)

@HookRegistry.register("extract_tab_list")
def extract_tab_list(content, **opts):
    tabs = []
    pattern = re.compile(r'<tab\s+key="([^"]*)"[^>]*>.*?<title>.*?<v-text[^>]*>([^<]*)</v-text>', re.DOTALL)
    for match in pattern.finditer(content):
        tabs.append(f"  {match.group(1)}  —  {match.group(2).strip()}")
    return '\n'.join(tabs) if tabs else "no tabs found"

@HookRegistry.register("extract_tab_content")
def extract_tab_content(content, **opts):
    tab_key = opts.get("tab")
    if not tab_key:
        return content
    pattern = re.compile(rf'<tab\s+key="{re.escape(tab_key)}"[^>]*>(.*?)</tab>', re.DOTALL)
    match = pattern.search(content)
    if not match:
        return ""
    return match.group(1)

@HookRegistry.register("format_markdown")
def format_markdown(md, **opts):
    from rich.markdown import Markdown
    return Markdown(md)

@HookRegistry.register("format_tab_list")
def format_tab_list(text, **opts):
    return text

@HookRegistry.register("format_strip_frontmatter")
def format_strip_frontmatter(md, **opts):
    if not md:
        return md
    if md.startswith('---'):
        idx = md.find('---', 3)
        if idx != -1:
            return md[idx + 3:].lstrip('\n')
    return md

@HookRegistry.register("format_clean_markdown")
def format_clean_markdown(md, **opts):
    if not md:
        return md
    md = md.replace('\\n', '\n').replace('\\t', '\t').replace('\\"', '"').replace('\\\\', '\\')
    return md


@HookRegistry.register("format_image_urls")
def format_image_urls(md, **opts):
    base = _get_base_url()
    if not base:
        return md
    md = _re.sub(r'\((/appassets/[^)]+)\)', f'({base}\\1)', md)
    md = _re.sub(r'src="(/appassets/[^"]+)"', f'src="{base}\\1"', md)
    return md


_re = __import__('re')
def _get_base_url():
    try:
        from ketacli.sdk.base.config import get_current_cluster
        c = get_current_cluster()
        url = (c or {}).get('endpoint', '')
        return url.rstrip('/')
    except Exception:
        return ''
