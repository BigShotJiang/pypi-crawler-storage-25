from .asset_map import get_request_path
import json
from ..util import Template


def _extract_raw_fields(kwargs):
    """Separate values that would break JSON-in-Jinja2 rendering.
    
    Multi-line strings or strings with quotes cannot be safely embedded
    inside a Jinja2 template that is itself JSON. These are replaced
    with sentinel placeholders, then restored after JSON parsing.
    """
    raw_fields = {}
    for key in list(kwargs.keys()):
        val = kwargs[key]
        if isinstance(val, str) and (
            '\n' in val or '\r' in val or '"' in val
            or val.startswith('[') or val.startswith('{')
        ):
            raw_fields[key] = val
            kwargs[key] = f"__RAW_{key}__"
    return raw_fields


def _restore_raw_fields(data, raw_fields):
    for key, val in raw_fields.items():
        placeholder = f"__RAW_{key}__"
        _replace_placeholder_recursive(data, key, placeholder, val)

def _replace_placeholder_recursive(data, key, placeholder, original_val):
    for k, v in data.items():
        if v == placeholder:
            if original_val.startswith(('[', '{')):
                try:
                    data[k] = json.loads(original_val)
                except json.JSONDecodeError:
                    data[k] = original_val
            else:
                data[k] = original_val
        elif isinstance(v, dict):
            _replace_placeholder_recursive(v, key, placeholder, original_val)
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    _replace_placeholder_recursive(item, key, placeholder, original_val)


def create_asset_request(asset_type, name=None, data=None, operation="create", **kwargs):
    path, method, example = get_request_path(asset_type, operation)
    example = json.dumps(example, ensure_ascii=False)
    if name is not None and "name" not in kwargs:
        kwargs.update({"name": name})
    
    template_vars = kwargs.copy()
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except:
            data = {}
    if isinstance(data, dict):
        template_vars.update(data)
    
    path = Template(path).render(**template_vars)
    raw_fields = _extract_raw_fields(template_vars)
    rendered_example = Template(example).render(**template_vars)
    rendered_example = json.loads(rendered_example)
    _restore_raw_fields(rendered_example, raw_fields)

    # Fix stringified JSON arrays/objects in rendered output (e.g. "[]" -> [])
    for key, val in rendered_example.items():
        if isinstance(val, str) and len(val) > 1 and val[0] in ('[', '{'):
            try:
                parsed = json.loads(val)
                if isinstance(parsed, (list, dict)):
                    rendered_example[key] = parsed
            except (json.JSONDecodeError, TypeError):
                pass
    
    if method == "create":
        method = "post"
    if not data:
        data = rendered_example
    else:
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except:
                pass
        data = {**rendered_example, **data, **kwargs}

    # Check if this method uses multipart file upload and gather form fields
    body_type = None
    form_fields = {}
    asset_map = __import__('ketacli.sdk.request.asset_map', fromlist=['get_resources']).get_resources()
    key = __import__('ketacli.sdk.util', fromlist=['is_fuzzy_key']).is_fuzzy_key(asset_type, value_map=asset_map)
    if key and "methods" in asset_map.get(key, {}) and operation in asset_map[key]["methods"]:
        method_config = asset_map[key]["methods"][operation]
        if isinstance(method_config, dict):
            body_type = method_config.get("body_type")
            for param in method_config.get("form_fields", []):
                val = kwargs.get(param["field"], param.get("default", ""))
                if val:
                    form_fields[param["field"]] = str(val)

    return {
        "path": path,
        "query_params": form_fields if body_type == "multipart" else {},
        "method": method,
        "data": data,
        "custom_headers": {},
        "body_type": body_type,
    }
