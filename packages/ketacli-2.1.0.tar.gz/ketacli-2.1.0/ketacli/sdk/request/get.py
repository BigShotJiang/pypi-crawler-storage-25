import json
import re

from ..util import is_fuzzy_key, Template
from .asset_map import get_resources, get_request_path
from ..base.client import request_get


def is_uuid(s):
    """Check if string is a valid UUID format"""
    if s is None:
        return False
    pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    return bool(re.match(pattern, s, re.I))


def resolve_asset_id_to_uuid(asset_type, asset_id):
    if asset_type != 'alerts':
        return asset_id
    
    if is_uuid(asset_id):
        return asset_id
    
    from ..base.client import request_get
    
    resp = request_get("alerts", {}, {}).json()
    
    alerts = resp.get('alerts', [])
    for alert in alerts:
        if alert.get('name') == asset_id:
            return alert.get('id')
    
    return asset_id


def _fetch_doc_content(api_name):
    try:
        resp = request_get(f"pithos/appcontents/keta_docs/view/{api_name}.xml", {}, {})
        if resp is None:
            return None
        return resp.json()
    except Exception:
        return None


def _extract_headings(data):
    """Extract markdown headings from doc content

    Args:
        data: Parsed JSON response dict

    Returns:
        list: Heading strings found in the content
    """
    if not data:
        return []
    content = data.get("content", "")
    if not content:
        return []
    headings = []
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("#") and " " in line:
            level = 0
            for ch in line:
                if ch == "#":
                    level += 1
                else:
                    break
            heading_text = line[level:].strip()
            if heading_text:
                headings.append(f"{'  ' * (level - 1)}{heading_text}")
    return headings


def _get_doc_tabs(asset_id):
    """Get tab list from a doc

    Args:
        asset_id: The doc API name (e.g., 'developer_api_documentation')

    Returns:
        list: [{key, title}] list of tabs
    """
    data = _fetch_doc_content(asset_id)
    if not data:
        return []
    content = data.get("content", "")
    if not content:
        return []
    tabs = []
    tab_pattern = re.compile(r'<tab\s+key="([^"]*)"[^>]*>.*?<title>.*?<v-text[^>]*>([^<]*)</v-text>', re.DOTALL)
    for match in tab_pattern.finditer(content):
        tabs.append({
            "key": match.group(1),
            "title": match.group(2).strip(),
        })
    return tabs


def _find_tab_content(content, tab_key):
    """Find CDATA content for a specific tab key

    Args:
        content: Raw pithos XML content string
        tab_key: The tab key attribute value

    Returns:
        str | None: CDATA content or None
    """
    pattern = re.compile(
        rf'<tab\s+key="{re.escape(tab_key)}"[^>]*>(.*?)</tab>', re.DOTALL
    )
    match = pattern.search(content)
    if not match:
        return None
    tab_body = match.group(1)
    cdata_pattern = re.compile(r'<!\[CDATA\[(.*?)\]\]>', re.DOTALL)
    cdata_match = cdata_pattern.search(tab_body)
    if cdata_match:
        return cdata_match.group(1).strip()
    return None


def _get_tab_content(asset_id, tab_name):
    """Get content of a specific tab by title

    If tab_name matches a title (not key), auto-resolve to the correct key.

    Args:
        asset_id: The doc API name
        tab_name: Tab title or key

    Returns:
        str | None: Markdown content or None
    """
    data = _fetch_doc_content(asset_id)
    if not data:
        return None
    content = data.get("content", "")
    if not content:
        return None
    tab_pattern = re.compile(r'<tab\s+key="([^"]*)"[^>]*>.*?<title>.*?<v-text[^>]*>([^<]*)</v-text>', re.DOTALL)
    resolved_key = None
    for match in tab_pattern.finditer(content):
        key = match.group(1)
        title = match.group(2).strip()
        if title == tab_name or key == tab_name:
            resolved_key = key
            break
    if not resolved_key:
        resolved_key = tab_name
    return _find_tab_content(content, resolved_key)


def _extract_markdown(content):
    """Extract all markdown CDATA content from doc XML

    Args:
        content: Raw pithos XML content string

    Returns:
        str: Concatenated markdown content
    """
    if not content:
        return ""
    parts = []
    cdata_pattern = re.compile(r'<!\[CDATA\[(.*?)\]\]>', re.DOTALL)
    for match in cdata_pattern.finditer(content):
        md = match.group(1).strip()
        if md:
            parts.append(md)
    return "\n\n".join(parts)


def _clean_markdown(content):
    """Clean escaped characters in markdown content

    Handles cases where \n, \t, \" are literal strings instead of actual characters.

    Args:
        content: Raw markdown string with possible escape sequences

    Returns:
        str: Cleaned markdown string
    """
    if not content:
        return content
    content = content.replace('\\n', '\n')
    content = content.replace('\\t', '\t')
    content = content.replace('\\"', '"')
    content = content.replace('\\\\', '\\')
    return content


def get_asset_by_id_request(asset_type, asset_id=None, lang=None, **kwargs):
    # For alerts, resolve name to UUID if needed
    resolved_asset_id = resolve_asset_id_to_uuid(asset_type, asset_id)
    
    path, method, _ = get_request_path(asset_type, "get")
    kwargs.update({"asset_id": resolved_asset_id})
    old_path = path
    if resolved_asset_id is not None:
        path = Template(path).render(**kwargs)

        # 当通过字符串格式化方式未能获取到变化时，则将对象 id 拼到 url 后面
        if path == old_path:
            path = f"{path}/{resolved_asset_id}"

    custom_headers = {}
    if lang is not None and isinstance(lang, str):
        custom_headers["X-Pandora-Language"] = lang

    return {
        "path": path,
        "query_params": {},
        # list 操作用不到的内容
        "method": method,
        "data": {},
        "custom_headers": custom_headers,
    }
