# flopsindex-partner — partner write SDK

[![PyPI version](https://img.shields.io/pypi/v/flopsindex-partner.svg)](https://pypi.org/project/flopsindex-partner/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/flopsindex-partner.svg)](https://pypi.org/project/flopsindex-partner/)
[![PyPI Downloads](https://img.shields.io/pypi/dm/flopsindex-partner.svg)](https://pypi.org/project/flopsindex-partner/)
[![Live API](https://img.shields.io/website?label=app.flopsindex.com&url=https%3A%2F%2Fapp.flopsindex.com%2Fv2%2Fcatalog%2Fpublic)](https://app.flopsindex.com/v2/catalog/public)
[![Spec](https://img.shields.io/badge/JSON--LD-v0.1-blue)](https://schema.flopsindex.com/compute-index-spec/v0.1/)
[![Docs](https://img.shields.io/badge/docs-docs.flopsindex.com-blue)](https://docs.flopsindex.com/)

**See also** — full docs [docs.flopsindex.com](https://docs.flopsindex.com/sdk/python-write) · become a contributor [docs.flopsindex.com/become-a-contributor](https://docs.flopsindex.com/become-a-contributor) · public read SDK [`flopsindex`](https://pypi.org/project/flopsindex/) · MCP server [`flopsindex-mcp`](https://pypi.org/project/flopsindex-mcp/) (v0.6.0, mcp-publisher ready) · spec [schema.flopsindex.com](https://schema.flopsindex.com/) · adopters [schema.flopsindex.com/adopters](https://schema.flopsindex.com/adopters)

```bash
pip install flopsindex-partner
```

Authenticated **write-side** SDK for contributing partners (Modular, the
lender-wave anchors, future fleet operators) submitting fleet / SMPI / CLRI
data into the FLOPS Compute Intelligence Platform.

For the **read-side** (price / verify / catalog / methodology / timeseries
/ compute_margin / spread) install the companion package
[`flopsindex`](https://pypi.org/project/flopsindex/) — different audience,
different brand, no API key required for the public surface.

## 30-second example

```python
from flopsindex_partner import FLOPSClient

c = FLOPSClient(api_key="flops_xxxxxxxxx")

# Weekly fleet snapshot
c.submit_weekly({
    "partner_id": "modular",
    "as_of":      "2026-05-19T00:00:00Z",
    "gpus":       [{"sku": "h100_sxm5", "region": "us_east", "count": 128}, ...],
})

# Single-machine pricing index event
c.submit_smpi({
    "partner_id": "modular",
    "sku":        "h100_sxm5",
    "region":     "us_east",
    "price_usd":  2.42,
    "tier":       "on_demand",
    "ts":         "2026-05-19T22:00:00Z",
})

# CLRI lease-rate submission
c.submit_clri({
    "partner_id":      "modular",
    "sku":             "h100_sxm5",
    "tenor":           "P36M",
    "implied_rate_pct": 11.4,
    "as_of":           "2026-05-19T00:00:00Z",
})
```

## Async surface

Every method has an `a`-prefixed async sibling:

```python
import asyncio
from flopsindex_partner import FLOPSClient

async def main():
    async with FLOPSClient(api_key="...") as c:
        await c.asubmit_smpi({...})

asyncio.run(main())
```

## Renamed from `flops-client` (2026-05-19)

This package was previously published as `flops-client`. Old imports
continue to work but emit `DeprecationWarning`:

```python
# OLD — deprecated, still works
from flops_client import FLOPSClient

# NEW — canonical
from flopsindex_partner import FLOPSClient
```

The PyPI distribution name also changed (`flops-client` →
`flopsindex-partner`). Update your `requirements.txt`:

```diff
- flops-client==0.1.0
+ flopsindex-partner>=0.6.0
```

The legacy `flops-client` distribution on PyPI will be marked deprecated
in a follow-up release; it will continue to install but won't receive
updates. The recommended deadline for migration is **2026-12-31**.

## Authentication

API keys are issued by FLOPS partner ops. Email `partners@flopsindex.com`
to onboard. Once issued:

```bash
export FLOPS_API_KEY="flops_xxxxxxxxx"
```

```python
import os
from flopsindex_partner import FLOPSClient

c = FLOPSClient(api_key=os.environ["FLOPS_API_KEY"])
```

## Submission contracts

The schemas for `submit_weekly` / `submit_smpi` / `submit_clri` live in
the Submission Guide (latest at
`https://app.flopsindex.com/v1/methodology/submission-guide`).
Each method returns the server's receipt envelope:

```python
result = c.submit_smpi({...})
# {'receipt_id': '...', 'received_at': '...', 'methodology_version': '...',
#  'k_anon_floor_met': True, 'inputs_hash': 'sha256:...'}
```

Hold onto `receipt_id` + `inputs_hash` — they're the audit trail.

## Errors

`FLOPSClientError` is raised on non-retryable 4xx + exhausted 5xx
retries. The SDK retries 429/500/502/503/504 up to 3 times with
exponential backoff before surfacing.

```python
from flopsindex_partner import FLOPSClient, FLOPSClientError

try:
    c.submit_smpi({...})
except FLOPSClientError as e:
    print(f"HTTP {e.status_code}: {e.detail}")
```

## Optional metrics

If `prometheus-client` is installed (`pip install flopsindex-partner[metrics]`),
the SDK emits:

| Metric | Labels |
|--------|--------|
| `flops_sdk_submissions_total` | `endpoint`, `status` (`ok` / `error` / `exhausted`) |
| `flops_sdk_request_seconds` | `endpoint` |

Scrape via the standard Prometheus exporter.

## Related

- **Read SDK:** `pip install flopsindex` ([PyPI](https://pypi.org/project/flopsindex/))
- **MCP server:** `pip install flopsindex-mcp` ([PyPI](https://pypi.org/project/flopsindex-mcp/))
- **Schema (JSON-LD):** [`schema.flopsindex.com/compute-index-spec/v0.1/`](https://schema.flopsindex.com/compute-index-spec/v0.1/)
- **Verify endpoint:** `GET /v1/verify?index_id=<ID>&value=<v>`
- **Methodology library:** [`/v1/methodology`](https://app.flopsindex.com/v1/methodology)
