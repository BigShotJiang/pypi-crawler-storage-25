"""FLOPS partner submission SDK — write-side client.

Canonical home for the partner-tier write surface. Use when ingesting
fleet / SMPI / CLRI data into FLOPS as a contributing partner (Modular,
and the wave that follows it). For the public read-side API see the
sibling ``flopsindex`` package.

Naming:
  - PyPI package: ``flopsindex-partner``
  - Python import: ``from flopsindex_partner import FLOPSClient``
  - Legacy import (deprecated, kept for Modular's pinned imports):
    ``from flops_client import FLOPSClient`` — emits DeprecationWarning
"""

from __future__ import annotations

import logging
import time
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)

try:
    from prometheus_client import Counter, Histogram

    _prom_available = True
except ImportError:
    _prom_available = False

_DEFAULT_BASE_URL = "https://api.flopsindex.com/v2"
_DEFAULT_TIMEOUT = 30
_MAX_RETRIES = 3
_BACKOFF_BASE = 0.5
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_USER_AGENT = "flopsindex-partner/0.2.0"


def _init_metrics() -> tuple:
    """Register Prometheus collectors idempotently.

    Counter/Histogram raise ValueError on re-registration with the same name,
    which crashes any caller that reloads this module (live-reload servers,
    test suites that purge sys.modules). The double-registration only
    happens when the registry already has the collectors — at which point
    we can safely return (None, None); the original module instance still
    owns the live counters and the reloaded copy doesn't need to re-emit.
    """
    if not _prom_available:
        return None, None
    try:
        submissions = Counter(
            "flops_sdk_submissions_total",
            "Total SDK submissions",
            ["endpoint", "status"],
        )
        latency = Histogram(
            "flops_sdk_request_seconds",
            "SDK request latency",
            ["endpoint"],
        )
        return submissions, latency
    except ValueError:
        # Already registered — module is being reloaded.
        return None, None


_submissions_counter, _latency_histogram = _init_metrics()


class FLOPSClientError(Exception):
    def __init__(self, status_code: int, detail: Any):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class FLOPSClient:
    """Synchronous + async write-side client for partner submissions."""

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: int = _DEFAULT_TIMEOUT,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client: Optional[httpx.Client] = None
        self._async_client: Optional[httpx.AsyncClient] = None

    def _get_headers(self) -> dict[str, str]:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": _USER_AGENT,
        }

    def _ensure_sync_client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(
                base_url=self._base_url,
                headers=self._get_headers(),
                timeout=self._timeout,
            )
        return self._client

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        client = self._ensure_sync_client()
        last_exc: Optional[Exception] = None

        for attempt in range(_MAX_RETRIES):
            start = time.monotonic()
            try:
                response = client.request(method, path, json=json, params=params)
                elapsed = time.monotonic() - start

                if _latency_histogram:
                    _latency_histogram.labels(endpoint=path).observe(elapsed)

                if response.status_code < 400:
                    if _submissions_counter and method == "POST":
                        _submissions_counter.labels(endpoint=path, status="ok").inc()
                    return response.json()

                if response.status_code not in _RETRYABLE_STATUS_CODES:
                    if _submissions_counter and method == "POST":
                        _submissions_counter.labels(endpoint=path, status="error").inc()
                    raise FLOPSClientError(response.status_code, response.text)

                last_exc = FLOPSClientError(response.status_code, response.text)

            except httpx.TransportError as exc:
                last_exc = exc

            backoff = _BACKOFF_BASE * (2 ** attempt)
            logger.warning("Retry %d/%d for %s %s (backoff %.1fs)",
                            attempt + 1, _MAX_RETRIES, method, path, backoff)
            time.sleep(backoff)

        if _submissions_counter and method == "POST":
            _submissions_counter.labels(endpoint=path, status="exhausted").inc()
        raise last_exc  # type: ignore[misc]

    def submit_weekly(self, submission: dict) -> dict:
        return self._request("POST", "/submit/fleet", json=submission)

    def submit_smpi(self, transaction: dict) -> dict:
        return self._request("POST", "/submit/smpi", json=transaction)

    def submit_clri(self, submission: dict) -> dict:
        return self._request("POST", "/submit/clri", json=submission)

    def get_index(
        self,
        index_id: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> dict:
        params: dict[str, str] = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        return self._request("GET", f"/indices/{index_id}", params=params)

    def get_health(self) -> dict:
        return self._request("GET", "/health")

    def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None
        if self._async_client:
            pass  # must be closed with aclose()

    def __enter__(self) -> "FLOPSClient":
        self._ensure_sync_client()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # --- async interface ---

    def _ensure_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=self._get_headers(),
                timeout=self._timeout,
            )
        return self._async_client

    async def _arequest(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        import asyncio

        client = self._ensure_async_client()
        last_exc: Optional[Exception] = None

        for attempt in range(_MAX_RETRIES):
            start = time.monotonic()
            try:
                response = await client.request(method, path, json=json, params=params)
                elapsed = time.monotonic() - start

                if _latency_histogram:
                    _latency_histogram.labels(endpoint=path).observe(elapsed)

                if response.status_code < 400:
                    if _submissions_counter and method == "POST":
                        _submissions_counter.labels(endpoint=path, status="ok").inc()
                    return response.json()

                if response.status_code not in _RETRYABLE_STATUS_CODES:
                    if _submissions_counter and method == "POST":
                        _submissions_counter.labels(endpoint=path, status="error").inc()
                    raise FLOPSClientError(response.status_code, response.text)

                last_exc = FLOPSClientError(response.status_code, response.text)

            except httpx.TransportError as exc:
                last_exc = exc

            backoff = _BACKOFF_BASE * (2 ** attempt)
            logger.warning("Retry %d/%d for %s %s (backoff %.1fs)",
                            attempt + 1, _MAX_RETRIES, method, path, backoff)
            await asyncio.sleep(backoff)

        if _submissions_counter and method == "POST":
            _submissions_counter.labels(endpoint=path, status="exhausted").inc()
        raise last_exc  # type: ignore[misc]

    async def asubmit_weekly(self, submission: dict) -> dict:
        return await self._arequest("POST", "/submit/fleet", json=submission)

    async def asubmit_smpi(self, transaction: dict) -> dict:
        return await self._arequest("POST", "/submit/smpi", json=transaction)

    async def asubmit_clri(self, submission: dict) -> dict:
        return await self._arequest("POST", "/submit/clri", json=submission)

    async def aget_index(
        self,
        index_id: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> dict:
        params: dict[str, str] = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        return await self._arequest("GET", f"/indices/{index_id}", params=params)

    async def aget_health(self) -> dict:
        return await self._arequest("GET", "/health")

    async def aclose(self) -> None:
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    async def __aenter__(self) -> "FLOPSClient":
        self._ensure_async_client()
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()


__all__ = ["FLOPSClient", "FLOPSClientError"]
