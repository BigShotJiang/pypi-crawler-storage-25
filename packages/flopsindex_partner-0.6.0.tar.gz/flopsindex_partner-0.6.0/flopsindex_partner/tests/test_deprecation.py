"""Deprecation-shim tests.

Pins two halves of the rebrand contract:

  1. `import flops_client` (the legacy distribution name) MUST emit a
     DeprecationWarning at import time so partners discover the rename
     when they re-pip from a clean environment.
  2. The shim MUST still re-export every write method (submit_weekly,
     submit_smpi, submit_clri) so Modular's already-deployed integration
     keeps working through the deprecation window. Silently breaking
     the WRITE surface is the failure mode this test exists to catch.

Tests use importlib.reload + warnings.catch_warnings so the warning
fires inside the test scope even if another test imported the modules
earlier in the session.
"""
from __future__ import annotations

import importlib
import sys
import warnings
from pathlib import Path

import pytest

# Make the sibling packages importable without `pip install -e .`
_SDK_ROOT = Path(__file__).resolve().parents[2]
if str(_SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(_SDK_ROOT))


def _purge(*module_prefixes: str) -> None:
    """Drop cached modules so the next import re-fires the warning."""
    for key in list(sys.modules):
        for prefix in module_prefixes:
            if key == prefix or key.startswith(prefix + "."):
                del sys.modules[key]
                break


def test_flops_client_import_emits_deprecation_warning():
    """`from flops_client import FLOPSClient` must warn."""
    _purge("flops_client", "flopsindex_partner")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        import flops_client  # noqa: F401
    deprecation_warnings = [w for w in caught
                            if issubclass(w.category, DeprecationWarning)
                            and "flops_client" in str(w.message)]
    assert deprecation_warnings, (
        "Importing flops_client must emit a DeprecationWarning pointing at "
        "flopsindex_partner; none found."
    )


def test_flops_client_client_module_import_emits_warning():
    """`from flops_client.client import FLOPSClient` must also warn —
    Modular may have pinned the deeper import path."""
    _purge("flops_client", "flopsindex_partner")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        import flops_client.client  # noqa: F401
    deprecation_warnings = [w for w in caught
                            if issubclass(w.category, DeprecationWarning)]
    assert deprecation_warnings, (
        "Importing flops_client.client must emit a DeprecationWarning; "
        "none found."
    )


def test_shim_reexports_FLOPSClient_with_write_methods():
    """The shim MUST re-export FLOPSClient with submit_weekly /
    submit_smpi / submit_clri intact. Silently breaking the WRITE
    surface is the failure mode this test pins."""
    _purge("flops_client", "flopsindex_partner")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        from flops_client import FLOPSClient  # noqa
    # Class-level method discovery — no network call.
    for method_name in ("submit_weekly", "submit_smpi", "submit_clri",
                         "asubmit_weekly", "asubmit_smpi", "asubmit_clri",
                         "get_index", "aget_index",
                         "get_health", "aget_health"):
        assert hasattr(FLOPSClient, method_name), (
            f"FLOPSClient lost {method_name}() during rebrand — the shim "
            "did not re-export the full write surface."
        )


def test_shim_FLOPSClient_is_canonical_class():
    """The class re-exported through the shim MUST be the same identity
    as the canonical class — no shadow class that drifts."""
    _purge("flops_client", "flopsindex_partner")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        from flops_client import FLOPSClient as ShimClass
        from flopsindex_partner import FLOPSClient as CanonClass
    assert ShimClass is CanonClass, (
        "flops_client.FLOPSClient and flopsindex_partner.FLOPSClient must "
        "be the SAME class object. If they diverge, partners pinning the "
        "old import path will silently miss new methods + fixes."
    )


def test_canonical_user_agent_rebranded():
    """The User-Agent string must reflect the rebrand so traffic auditing
    can distinguish v0.2.0+ callers from legacy flops-client 0.1.0."""
    _purge("flops_client", "flopsindex_partner")
    from flopsindex_partner.client import _USER_AGENT
    assert _USER_AGENT.startswith("flopsindex-partner/"), (
        f"USER_AGENT not rebranded: {_USER_AGENT!r}"
    )
    assert "0.2" in _USER_AGENT  # tolerates patch bumps


def test_version_pinned_to_0_2():
    _purge("flopsindex_partner")
    import flopsindex_partner
    importlib.reload(flopsindex_partner)
    assert flopsindex_partner.__version__.startswith("0.2"), (
        f"flopsindex_partner.__version__ should start with 0.2, got "
        f"{flopsindex_partner.__version__!r}"
    )


def test_flops_client_exports_FLOPSClientError():
    """FLOPSClientError MUST be re-exported through both shim levels —
    partners catch this exception by name."""
    _purge("flops_client", "flopsindex_partner")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        from flops_client import FLOPSClientError as ShimErr
        from flops_client.client import FLOPSClientError as DeepShimErr
        from flopsindex_partner import FLOPSClientError as CanonErr
    assert ShimErr is CanonErr
    assert DeepShimErr is CanonErr
