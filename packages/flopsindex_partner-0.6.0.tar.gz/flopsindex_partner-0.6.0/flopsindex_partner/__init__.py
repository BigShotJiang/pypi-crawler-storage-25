"""flopsindex-partner — partner-tier write SDK for the FLOPS Compute
Intelligence Platform.

```python
from flopsindex_partner import FLOPSClient

c = FLOPSClient(api_key="flops_xxx")
c.submit_weekly({...})
c.submit_smpi({...})
c.submit_clri({...})
```

For the public read-side surface (price / verify / catalog / methodology /
timeseries / spread / compute_margin) install the sibling ``flopsindex``
package — different audience, different brand, same publisher.

Renamed from ``flops-client`` 2026-05-19. The old import path
``from flops_client import FLOPSClient`` continues to work via a
deprecation shim — but emits ``DeprecationWarning``. Move pinned imports
to ``flopsindex_partner`` for the long-term contract.
"""

from flopsindex_partner.client import FLOPSClient, FLOPSClientError

__version__ = "0.6.0"
__all__ = ["FLOPSClient", "FLOPSClientError", "__version__"]
