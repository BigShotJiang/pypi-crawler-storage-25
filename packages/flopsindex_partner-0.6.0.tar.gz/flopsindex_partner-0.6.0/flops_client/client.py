"""DEPRECATED — see ``flopsindex_partner.client``.

This module re-exports the canonical implementation so any caller pinned to
``from flops_client.client import FLOPSClient`` (or
``from sdk.flops_client.client import FLOPSClient``) keeps working. Single
source of truth lives at ``flopsindex_partner/client.py``; this file is
deliberately a thin shim to avoid drift between the two paths.
"""
import warnings as _warnings

_warnings.warn(
    "flops_client.client has been renamed to flopsindex_partner.client. "
    "Use `from flopsindex_partner.client import FLOPSClient` instead. "
    "The old import path will continue to work but is deprecated.",
    DeprecationWarning,
    stacklevel=2,
)

from flopsindex_partner.client import (  # noqa: E402,F401
    FLOPSClient,
    FLOPSClientError,
)

__all__ = ["FLOPSClient", "FLOPSClientError"]
