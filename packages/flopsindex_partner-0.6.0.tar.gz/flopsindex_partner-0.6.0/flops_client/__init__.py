"""DEPRECATED — renamed to ``flopsindex-partner`` 2026-05-19.

Imports continue to work via this shim but emit DeprecationWarning. Move
pinned imports to ``from flopsindex_partner import FLOPSClient`` for the
long-term contract. The PyPI distribution name also changed
(``flops-client`` → ``flopsindex-partner``); the legacy ``flops-client``
package on PyPI will be marked deprecated in a follow-up release.
"""
import warnings as _warnings

_warnings.warn(
    "flops_client has been renamed to flopsindex_partner. "
    "Use `from flopsindex_partner import FLOPSClient` instead. "
    "The old import path will continue to work but is deprecated.",
    DeprecationWarning,
    stacklevel=2,
)

from flopsindex_partner import FLOPSClient, FLOPSClientError  # noqa: E402,F401

__all__ = ["FLOPSClient", "FLOPSClientError"]
