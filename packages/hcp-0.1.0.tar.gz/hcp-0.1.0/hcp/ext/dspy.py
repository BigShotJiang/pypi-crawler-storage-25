"""
dspy.hcp
--------
The Human-AI Collaboration Protocol (HCP) integration for DSPy.
Empowers agents to dynamically generate DataShapes and synchronize state with external clients.
"""

import dspy
from typing import Callable, Any, Optional
from hcp.adapter import HCPMixin
from hcp.prompt import HCP_PORTAL_PROMPT
from pydantic import BaseModel

from dspy.primitives.prediction import Prediction
from dspy.primitives.example import Example

# In production, this hooks into your persistent database
CO_OP_MEMORY = []


class GenerateTopology(dspy.Signature):
    __doc__ = HCP_PORTAL_PROMPT

    context_summary = dspy.InputField()
    detailed_intention = dspy.InputField()
    hcp_json = dspy.OutputField(
        desc="Valid JSON string representing the HCP Protocol (Atom and Shape)."
    )


class Collaborate(dspy.Module, HCPMixin):
    """
    A bidirectional protocol module.
    Agent dynamically generates an HCP packet, halts execution, and resolves alignment.
    """

    def __init__(
        self,
        transport: Optional[Callable[[dict], dict]] = None,
        offline_mode: bool = False,
    ):
        super().__init__()
        self.transport = transport
        # Safety Lock: Prevent DB pollution if no transport is provided (e.g. during compilation)
        self.offline_mode = offline_mode if transport is not None else True
        self.agent_generator = dspy.Predict(GenerateTopology)

    def forward(
        self, context_summary: str, detailed_intention: str, **trace_inputs
    ) -> Any:
        # 1. Pure Agent-Driven Topology Generation
        result = self.agent_generator(
            context_summary=context_summary, detailed_intention=detailed_intention
        )

        # 2. Protocol Validation & Agent Act Logging (hcp_forward natively handles Markdown & Validation)
        wire_payload = self.hcp_forward(result.hcp_json)

        # In a real DB: db.collection.update_one({"payload.params.atom.refId": refId}, {"$set": {"dspy_inputs": trace_inputs}})
        if not self.offline_mode:
            refId = wire_payload["params"]["atom"]["refId"]
            for log in reversed(CO_OP_MEMORY):
                if (
                    log.get("actor") == "Agent"
                    and log["payload"]["params"]["atom"]["refId"] == refId
                ):
                    log["dspy_inputs"] = trace_inputs
                    break

        # 4. OFFLINE BYPASS: Compilation execution
        if self.offline_mode or not self.transport:
            return self._extract_draft_value(wire_payload["params"]["shape"])

        # 5. PRODUCTION MODE: Client Synchronization
        client_response = self.transport(wire_payload)

        # Async Transport Guard: If transport resolves via background callback (e.g. JS/WebSockets)
        if not client_response:
            return "⏳ Pending Async UI Alignment..."

        aligned_data, used_proposal = self.hcp_resolve(client_response)

        return aligned_data

    def _extract_draft_value(self, shape_dict: dict) -> Any:
        """
        Recursively reconstructs the Agent's draft state.
        Structural integrity is mathematically guaranteed by hcp_forward's Pydantic validation.
        """
        if shape_dict.get("type") == "COMPOSITE":
            return {
                f["key"]: self._extract_draft_value(f["shape"])
                for f in shape_dict["fields"]
            }
        return shape_dict["value"]

    def hcp_on_log(self, log_entry: dict):
        if not getattr(self, "offline_mode", False):
            CO_OP_MEMORY.append(log_entry)


# =====================================================================
# Protocol Metrics
# =====================================================================


def _get_pred_val(pred):
    """Safely extracts the predicted value from DSPy wrappers."""
    if isinstance(pred, Prediction) and pred.keys():
        return getattr(pred, list(pred.keys())[-1])
    return pred


# --- 1. OFFLINE COMPILER METRICS (Current DSPy) ---
# Used for MIPROv2, BootstrapFewShot, etc.
# Goal: Train the LLM to predict the exact Human Ground Truth.
def metric_data_accuracy(example: Example, pred: Any, trace=None) -> float:
    """Optimizes for ACCURACY. 1.0 if the Agent's generated value matches Human ground truth."""
    llm_val = _get_pred_val(pred)
    human_val = example.human_correction

    # Safely normalize Pydantic models to dicts for the strict type checker
    if isinstance(llm_val, BaseModel):
        llm_val = llm_val.model_dump()
    if isinstance(human_val, BaseModel):
        human_val = human_val.model_dump()

    if isinstance(llm_val, dict) or isinstance(human_val, dict):
        return 1.0 if llm_val == human_val else 0.0

    return (
        1.0 if str(llm_val).strip().lower() == str(human_val).strip().lower() else 0.0
    )


# --- 2. ONLINE REWARD METRICS (RLHF) ---
# Used for online Reinforcement Learning, DPO, or behavioral shaping.
# Goal: Maximize human engagement and acceptance of Agent Proposals.
def metric_user_acceptance(example: Example, pred: Any, trace=None) -> float:
    """Optimizes for BEHAVIOR. 1.0 if the user engaged without rejecting."""
    return 1.0 if example.usedProposal else 0.0


def metric_HCP_alignment(example: Example, pred: Any, trace=None) -> float:
    """The Universal Default HCP Metric."""
    if metric_user_acceptance(example, pred, trace) == 0.0:
        return 0.0
    return metric_data_accuracy(example, pred, trace)


# =====================================================================
# Protocol Data Extractors
# =====================================================================


def load_memory(db_cursor=None, used_proposal: Optional[bool] = None) -> list[Example]:
    """
    Reconstructs DSPy optimization traces by relationally joining
    System Trace Inputs and Client Resolutions via the HCP refId.

    Args:
        db_cursor: The database iterable.
        used_proposal:
            True  -> Returns only aligned interactions (User clicked Accept).
            False -> Returns only friction interactions (User rejected and typed text).
            None  -> Returns all interactions.
    """
    cursor = db_cursor if db_cursor is not None else CO_OP_MEMORY
    trainset = []

    # 1. Index Agent Logs to quickly grab their internal dspy_inputs
    agent_logs = {}
    for log in cursor:
        if log.get("actor") == "Agent":
            atom = log["payload"]["params"]["atom"]
            agent_logs[atom["refId"]] = {
                "direction": atom["direction"],
                "dspy_inputs": log.get("dspy_inputs", {}),
            }

    # 2. Reconstruct the DSPy traces from the User's ground truth
    for log in cursor:
        if log.get("actor") == "User":
            result = log["payload"]["result"]
            is_used = result.get("usedProposal", False)

            # 🟢 SFT PROTECTION: Skip friction logs if we only want engaged traces
            if used_proposal is not None and is_used != used_proposal:
                continue

            refId = result["context"]["refId"]
            agent_data = agent_logs.get(refId, {})
            trace_inputs = agent_data.get("dspy_inputs", {})

            ex_kwargs = {
                **trace_inputs,
                "direction": agent_data.get("direction", "REQUEST"),
                "usedProposal": used_proposal,
                "human_correction": result["value"],
            }

            input_keys = list(trace_inputs.keys())
            if input_keys:
                ex = dspy.Example(**ex_kwargs).with_inputs(*input_keys)
                trainset.append(ex)

    return trainset
