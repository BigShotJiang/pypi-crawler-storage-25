import uuid
from enum import Enum
from pydantic import BaseModel, Field

class Direction(str, Enum):
    OFFER = "OFFER"     # Push (Agent -> Human)
    REQUEST = "REQUEST" # Pull (Agent <- Human)

class Mode(str, Enum):
    BLOCKING = "BLOCKING"     # Halts execution
    BACKGROUND = "BACKGROUND" # Async stream

class IntentVector(BaseModel):
    """The 3D Energy of the Interaction (0.0 - 1.0)."""
    productivity: float = Field(..., ge=0.0, le=1.0) 
    information: float = Field(..., ge=0.0, le=1.0)  
    affect: float = Field(..., ge=0.0, le=1.0)       

    @classmethod
    def default(cls):
        return cls(productivity=0.5, information=0.5, affect=0.5)

class Atom(BaseModel):
    """The Header Packet."""
    direction: Direction
    mode: Mode
    criticality: float = Field(..., ge=0.0, le=1.0)
    vector: IntentVector
    rationale: str
    refId: str = Field(default_factory=lambda: str(uuid.uuid4()))