from __future__ import annotations
from typing import List, Union, Optional, Literal, Dict, Any
from pydantic import BaseModel


class BaseShape(BaseModel):
    label: Optional[str] = None
    description: Optional[str] = None


class DiscreteShape(BaseShape):
    type: Literal["DISCRETE"] = "DISCRETE"
    options: List[str]
    multiSelect: bool = False
    value: Union[str, List[str]]


class ContinuousShape(BaseShape):
    type: Literal["CONTINUOUS"] = "CONTINUOUS"
    min: float
    max: float
    step: Optional[float] = None
    unit: Optional[str] = None
    value: float


class SymbolicShape(BaseShape):
    type: Literal["SYMBOLIC"] = "SYMBOLIC"
    mimeType: str = "text/plain"
    value: Union[str, Dict[str, Any]]


# Explicitly define the field wrapper
class CompositeField(BaseModel):
    key: str
    shape: "DataShape"  # Forward reference


class CompositeShape(BaseShape):
    type: Literal["COMPOSITE"] = "COMPOSITE"
    # Use the class, not Dict, to ensure type safety inside the list
    fields: List[CompositeField]


# Define Union last so all classes exist
DataShape = Union[DiscreteShape, ContinuousShape, SymbolicShape, CompositeShape]

# Update forward references for Pydantic to resolve "DataShape" inside CompositeField
CompositeField.model_rebuild()
CompositeShape.model_rebuild()
