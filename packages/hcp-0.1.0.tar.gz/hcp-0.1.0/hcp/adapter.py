import logging
import json
from typing import Dict, Any, List, Optional, Union, Tuple
from datetime import datetime, timezone
from .physics import Atom, Direction, Mode, IntentVector
from .topology import (
    DataShape,
    DiscreteShape,
    ContinuousShape,
    SymbolicShape,
    CompositeShape,
    CompositeField,
)

logger = logging.getLogger(__name__)


class HCPMixin:
    """
    The HCP Adapter Layer.
    Usage:
        1. Inherit this Mixin in your Agent.
        2. Call `self.hcp_forward(llm_output)` to generate the Protocol.
        3. Call `self.hcp_resolve(client_response)` to close the loop.
    """

    # ========================================================
    # 1. THE FORWARD PASS (Entry Point)
    # ========================================================
    def hcp_forward(self, content: Union[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        The Main Interface. Transforms Agent Intent (LLM Output) into HCP Wire Protocol.

        Args:
            content: Can be a raw JSON string (from LLM) or a pre-parsed Dictionary.
        Returns:
            The HCP Protocol Dictionary ready to send to the client.
        """
        # 1. Normalize Input (String -> Dict)
        if isinstance(content, str):
            payload = self._clean_and_parse_json(content)
        elif isinstance(content, dict):
            payload = content
        else:
            raise ValueError(f"hcp_forward expects str or dict, got {type(content)}")

        # 2. Validate Structure
        method_name = payload.get("method")
        params = payload.get("params")

        if method_name not in ["HCP_Request", "HCP_Offer"]:
            raise ValueError(
                f"Invalid HCP Method Name: {method_name}, raw_input: {payload}"
            )

        if not isinstance(method_name, str) or method_name not in [
            "HCP_Request",
            "HCP_Offer",
        ]:
            raise ValueError(
                f"Invalid HCP Method Name: {method_name}, raw_input: {payload}"
            )

        if not params:
            raise ValueError("Missing 'params' in HCP payload")

        # 3. Build Protocol
        protocol_payload = self._build_protocol(method_name, params)

        # --- 4. NEW: AUTO-LOG AGENT PROPOSAL ---
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "actor": "Agent",
            "payload": protocol_payload,
        }
        self.hcp_on_log(log_entry)

        return protocol_payload

    # ========================================================
    # 2. INTERNAL ENGINE (Private)
    # ========================================================
    def _clean_and_parse_json(self, raw_text: str) -> Dict[str, Any]:
        """Helper: Strips markdown code blocks and loads JSON."""
        text = raw_text.strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()

        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"LLM produced invalid JSON: {e}")

    def _build_protocol(self, name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Helper: Inflates Pydantic objects and wraps in Atom."""
        # A. Logic Extraction
        topology = params.get("topology")
        if not isinstance(topology, str):
            raise ValueError(f"Topology must be a string, got {type(topology)}")

        physics = params.get("physics", {})
        if not isinstance(physics, dict):
            physics = {}

        shape_params = params.get("params", {})
        if not isinstance(shape_params, dict):
            shape_params = {}

        # B. Value Injection (Symmetry Fix)
        if "value" in params:
            shape_params["value"] = params["value"]

        # C. Shape Inflation (Recursive Factory)
        shape_obj = self._inflate_shape(topology, shape_params)

        # D. Physics Inflation
        vector_data = physics.get("vector", {})
        intent_vector = IntentVector(
            productivity=float(vector_data.get("productivity", 0.5)),
            information=float(vector_data.get("information", 0.5)),
            affect=float(vector_data.get("affect", 0.5)),
        )

        # E. Extract Mode (The Logic Fix)
        # Default logic: Request=BLOCKING, Offer=BACKGROUND
        # But if LLM specifies it, we respect it.
        raw_mode = physics.get("mode")
        mode_enum = None
        if raw_mode == "BLOCKING":
            mode_enum = Mode.BLOCKING
        elif raw_mode == "BACKGROUND":
            mode_enum = Mode.BACKGROUND

        # F. Wrap
        direction = Direction.REQUEST if name == "HCP_Request" else Direction.OFFER

        return self._wrap_hcp(
            direction=direction,
            shape=shape_obj,
            rationale=str(physics.get("rationale", "No rationale provided.")),
            criticality=float(physics.get("criticality", 0.5)),
            vector=intent_vector,
            mode=mode_enum,
        )

    def _inflate_shape(self, topology: str, params: dict) -> DataShape:
        """Helper: Recursive Pydantic Factory."""
        if topology == "CONTINUOUS":
            return ContinuousShape(**params)
        elif topology == "DISCRETE":
            return DiscreteShape(**params)
        elif topology == "SYMBOLIC":
            return SymbolicShape(**params)
        elif topology == "COMPOSITE":
            raw_fields = params.get("fields", {})
            inflated_fields = []
            if isinstance(raw_fields, dict):
                for key, field_def in raw_fields.items():
                    if isinstance(field_def, dict):
                        sub_top = field_def.get("topology")
                        sub_p = field_def.get("params", {})
                        # Strict Type Check for Recursion
                        if isinstance(sub_top, str) and isinstance(sub_p, dict):
                            child_shape = self._inflate_shape(sub_top, sub_p)
                            inflated_fields.append(
                                CompositeField(key=key, shape=child_shape)
                            )
            return CompositeShape(label=params.get("label"), fields=inflated_fields)

        raise ValueError(f"Unknown Topology: {topology}")

    def _wrap_hcp(
        self, direction: Direction, shape: DataShape, rationale: str, **kwargs
    ) -> Dict[str, Any]:
        """Helper: Final JSON-RPC Wrapper."""
        import uuid

        ref_id = kwargs.get("refId") or str(uuid.uuid4())

        vector = kwargs.get("vector", IntentVector.default())
        criticality = kwargs.get("criticality", 0.5)
        mode = kwargs.get(
            "mode", Mode.BLOCKING if direction == Direction.REQUEST else Mode.BACKGROUND
        )

        atom = Atom(
            direction=direction,
            mode=mode,
            criticality=criticality,
            vector=vector,
            rationale=rationale,
            refId=ref_id,
        )

        method = "hcp/request" if direction == Direction.REQUEST else "hcp/offer"
        return {
            "jsonrpc": "2.0",
            "method": method,
            "params": {
                "atom": atom.model_dump(),
                "shape": shape.model_dump(exclude_none=True),
            },
        }

    # ========================================================
    # 3. THE RESOLVER (Closing the Loop)
    # ========================================================
    def hcp_resolve(self, result_payload: Dict[str, Any]) -> Tuple[Any, bool]:
        """
        Decodes the Client Response and triggers the Co-Op Memory log.

        STRICTNESS LEVEL: HIGH.
        Raises ValueError if the Protocol Contract is violated.
        """
        # 1. Unwrap JSON-RPC wrapper if present
        payload = result_payload.get("result", result_payload)

        # 2. Extract Critical Fields
        context = payload.get("context")
        used_proposal = payload.get("usedProposal")
        value = payload.get("value")

        # 3. Enforce Protocol (The Contract)
        if used_proposal is None:
            raise ValueError(
                "[HCP Protocol Violation] 'usedProposal' boolean is missing."
            )

        if not context or "refId" not in context:
            raise ValueError("[HCP Protocol Violation] 'refId' is missing in context.")

        # 4. Handle "Lazy Client" (Missing Rationale)
        # We don't crash here because the User interaction can still succeed,
        # but we mark the log as degraded.
        rationale = context.get("rationale")
        if rationale is None:
            logger.warning(
                f"[HCP Data Loss] Client {context['refId']} dropped the 'rationale'."
            )
            rationale = "UNKNOWN_CLIENT_DROPPED_CONTEXT"

        # --- 3. CONSTRUCT STANDARDIZED USER RESOLUTION LOG ---
        standardized_result = {
            "usedProposal": used_proposal,
            "value": value,
            "context": {"refId": context["refId"], "rationale": rationale},
        }

        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "actor": "User",
            "payload": {"result": standardized_result},
        }

        # 4. Fire Hook
        self.hcp_on_log(log_entry)

        return value, used_proposal

    def hcp_on_log(self, log_entry: Dict[str, Any]):
        """Override this method to connect to your database."""
        logger.info(f"[HCP Co-Op Memory] {log_entry}")

    # ========================================================
    # 4. MANUAL HELPERS (Optional usage)
    # ========================================================
    # 4.1 THE INPUT INTERFACE (Requests / Pulls)
    # ========================================================

    def hcp_request_discrete(
        self,
        rationale: str,
        options: List[str],
        value: Union[str, List[str]],
        multi: bool = False,
        **kwargs,
    ):
        shape = DiscreteShape(
            options=options, multiSelect=multi, value=value, label=kwargs.get("label")
        )
        return self._wrap_hcp(Direction.REQUEST, shape, rationale, **kwargs)

    def hcp_request_continuous(
        self,
        rationale: str,
        value: float,
        min: float,
        max: float,
        step: Optional[float] = None,
        unit: Optional[str] = None,
        **kwargs,
    ):
        shape = ContinuousShape(
            min=min,
            max=max,
            step=step,
            unit=unit,
            value=value,
            label=kwargs.get("label"),
        )
        return self._wrap_hcp(Direction.REQUEST, shape, rationale, **kwargs)

    def hcp_request_symbolic(self, rationale: str, mimeType: str, value: Any, **kwargs):
        shape = SymbolicShape(mimeType=mimeType, value=value, label=kwargs.get("label"))
        return self._wrap_hcp(Direction.REQUEST, shape, rationale, **kwargs)

    def hcp_request_composite(
        self, rationale: str, fields: Dict[str, DataShape], **kwargs
    ):
        # Explicitly use CompositeField to satisfy Pydantic validation
        field_list = [CompositeField(key=k, shape=v) for k, v in fields.items()]
        shape = CompositeShape(fields=field_list, label=kwargs.get("label"))
        return self._wrap_hcp(Direction.REQUEST, shape, rationale, **kwargs)

    # ========================================================
    # 4.2 THE OUTPUT INTERFACE (Offers / Pushes)
    # ========================================================

    def hcp_offer_discrete(
        self, rationale: str, options: List[str], value: Union[str, List[str]], **kwargs
    ):
        """Displays a Status, Badge, or Current State."""
        shape = DiscreteShape(options=options, value=value, label=kwargs.get("label"))
        return self._wrap_hcp(Direction.OFFER, shape, rationale, **kwargs)

    def hcp_offer_continuous(
        self,
        rationale: str,
        value: float,
        min: float,
        max: float,
        step: Optional[float] = None,
        unit: Optional[str] = None,
        **kwargs,
    ):
        """Displays a Gauge, Progress Bar, or Readout."""
        shape = ContinuousShape(
            min=min,
            max=max,
            step=step,
            unit=unit,
            value=value,
            label=kwargs.get("label"),
        )
        return self._wrap_hcp(Direction.OFFER, shape, rationale, **kwargs)

    def hcp_offer_symbolic(self, rationale: str, mimeType: str, value: Any, **kwargs):
        """Displays Markdown, JSON, Images, or 3D Objects."""
        shape = SymbolicShape(mimeType=mimeType, value=value, label=kwargs.get("label"))
        return self._wrap_hcp(Direction.OFFER, shape, rationale, **kwargs)

    def hcp_offer_composite(
        self, rationale: str, fields: Dict[str, DataShape], **kwargs
    ):
        """Displays a Dashboard or Info Card."""
        field_list = [CompositeField(key=k, shape=v) for k, v in fields.items()]
        shape = CompositeShape(fields=field_list, label=kwargs.get("label"))
        return self._wrap_hcp(Direction.OFFER, shape, rationale, **kwargs)
