"""
Franchise Cloud Utilities (Single File Module)
Advanced constructs for secure, dynamic, scalable cloud-based applications.

Version 0.1.0
"""
import re
import time
import logging
import threading
from functools import wraps
from typing import Callable, Dict, List, Any

# ==============================================================================
# Data Validation Descriptors
# ==============================================================================

class BaseField:
    def __init__(self, name=None):
        self.name = name

    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        return instance.__dict__.get(self.name)

class StringField(BaseField):
    def __init__(self, min_length=0, max_length=None, pattern=None, **kwargs):
        super().__init__(**kwargs)
        self.min_length = min_length
        self.max_length = max_length
        self.pattern = re.compile(pattern) if pattern else None

    def __set__(self, instance, value):
        if not isinstance(value, str):
            raise TypeError(f"'{self.name}' must be a string, got {type(value).__name__}")
        if len(value) < self.min_length:
            raise ValueError(f"'{self.name}' must be at least {self.min_length} characters")
        if self.max_length and len(value) > self.max_length:
            raise ValueError(f"'{self.name}' cannot exceed {self.max_length} characters")
        if self.pattern and not self.pattern.match(value):
            raise ValueError(f"'{self.name}' does not match required format")
        
        instance.__dict__[self.name] = value

class IntegerField(BaseField):
    def __init__(self, min_value=None, max_value=None, **kwargs):
        super().__init__(**kwargs)
        self.min_value = min_value
        self.max_value = max_value

    def __set__(self, instance, value):
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError(f"'{self.name}' must be an integer")
        if self.min_value is not None and value < self.min_value:
            raise ValueError(f"'{self.name}' must be >= {self.min_value}")
        if self.max_value is not None and value > self.max_value:
            raise ValueError(f"'{self.name}' must be <= {self.max_value}")
            
        instance.__dict__[self.name] = value

class SchemaValidator:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            if hasattr(self.__class__, key):
                setattr(self, key, value)
            else:
                raise AttributeError(f"'{self.__class__.__name__}' does not have field '{key}'")


# ==============================================================================
# Role-Based Access Control (RBAC)
# ==============================================================================

_ROLE_REGISTRY = {}

class RoleRegistryMeta(type):
    def __new__(cls, name, bases, attrs):
        new_class = super().__new__(cls, name, bases, attrs)
        if name != 'BaseRole':
            _ROLE_REGISTRY[name] = new_class
        return new_class

class BaseRole(metaclass=RoleRegistryMeta):
    permissions = []
    @classmethod
    def can_access(cls, permission: str) -> bool:
        return permission in cls.permissions

_tls = threading.local()

class sudo:
    def __enter__(self):
        self.original = getattr(_tls, 'is_sudo', False)
        _tls.is_sudo = True
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        _tls.is_sudo = self.original

def require_roles(*allowed_roles):
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            if getattr(_tls, 'is_sudo', False):
                return view_func(request, *args, **kwargs)

            user_role = getattr(request.user, 'role', None) 
            if user_role not in allowed_roles:
                from django.core.exceptions import PermissionDenied
                raise PermissionDenied("User does not have the required cloud privileges.")
            
            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator


# ==============================================================================
# Event Observer Bus
# ==============================================================================

class EventSubscriber:
    def __init__(self, callback: Callable, is_async: bool = False):
        self.callback = callback
        self.is_async = is_async

class EventDispatcher:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(EventDispatcher, cls).__new__(cls)
                cls._instance.subscribers: Dict[str, List[EventSubscriber]] = {}
        return cls._instance

    def subscribe(self, event_type: str, callback: Callable, is_async: bool = False):
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        subscriber = EventSubscriber(callback, is_async=is_async)
        self.subscribers[event_type].append(subscriber)

    def dispatch(self, event_type: str, *args, **kwargs):
        if event_type not in self.subscribers:
            return
        for subscriber in self.subscribers[event_type]:
            if subscriber.is_async:
                thread = threading.Thread(
                    target=subscriber.callback, 
                    args=args, 
                    kwargs=kwargs,
                    daemon=True
                )
                thread.start()
            else:
                subscriber.callback(*args, **kwargs)

bus = EventDispatcher()


# ==============================================================================
# Cloud Resiliency 
# ==============================================================================

logger = logging.getLogger(__name__)

def retry_with_backoff(retries: int = 3, initial_backoff: float = 1.0, max_backoff: float = 60.0):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            backoff = initial_backoff
            for attempt in range(retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == retries - 1:
                        logger.error(f"Function {func.__name__} failed after {retries} attempts.")
                        raise e
                    logger.warning(
                        f"Attempt {attempt + 1} failed for {func.__name__}: {str(e)}. "
                        f"Retrying in {backoff} seconds..."
                    )
                    time.sleep(backoff)
                    backoff = min(backoff * 2, max_backoff)
        return wrapper
    return decorator

class AWSBorg:
    _shared_state: Dict[str, Any] = {}

    def __init__(self):
        self.__dict__ = self._shared_state
        if not hasattr(self, 'clients'):
            self.clients: Dict[str, Any] = {}

    def get_client(self, service_name: str, region_name: str = 'us-east-1'):
        import boto3
        key = f"{service_name}_{region_name}"
        if key not in self.clients:
            self.clients[key] = boto3.client(service_name, region_name=region_name)
        return self.clients[key]

class SecretManagerCache:
    def __init__(self, ttl_seconds: int = 300):
        self.ttl = ttl_seconds
        self._cache = {}
        self._timestamps = {}
        self._borg = AWSBorg()

    @retry_with_backoff(retries=3)
    def get_secret(self, secret_id: str) -> str:
        now = time.time()
        if secret_id in self._cache:
            if now - self._timestamps.get(secret_id, 0) < self.ttl:
                return self._cache[secret_id]
        
        client = self._borg.get_client('secretsmanager')
        response = client.get_secret_value(SecretId=secret_id)
        secret_string = response.get('SecretString')
        
        self._cache[secret_id] = secret_string
        self._timestamps[secret_id] = now
        return secret_string
