# franchise-cloud-utils

Advanced programming constructs and utilities to create secure, dynamic, configurable, robust, and scalable cloud-based server applications.

## Modules included:

1. **Validators** (`franchise_cloud_utils.validator`): Employs Python descriptors to securely ensure data constraints without relying strictly on ORM validation.
2. **RBAC** (`franchise_cloud_utils.rbac`): Uses metaprogramming for dynamic, robust role-based access control registries.
3. **Events** (`franchise_cloud_utils.events`): Implements an observer pattern for decoupled application logic.
4. **Cloud** (`franchise_cloud_utils.cloud`): Resilient AWS utility abstractions, featuring exponential backoff and singletons.
