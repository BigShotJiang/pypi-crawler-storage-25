"""Shim re-exporting upstream's ``pptx.chart.marker.Marker``."""

from __future__ import annotations

from ..shapes import Marker

__all__ = ["Marker"]
