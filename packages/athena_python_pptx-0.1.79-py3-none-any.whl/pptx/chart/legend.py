"""Shim re-exporting upstream's ``pptx.chart.legend.Legend``."""

from __future__ import annotations

from ..shapes import Legend

__all__ = ["Legend"]
