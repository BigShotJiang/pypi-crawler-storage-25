"""Plot-related stubs mirroring upstream's ``pptx.chart.plot`` module.

Our concrete Plot classes (``BarPlot`` / ``LinePlot`` / etc.) live in
:mod:`pptx.shapes`. This module provides parity stubs and re-exports
for any code that imports from the upstream-canonical path.
"""

from __future__ import annotations

from typing import Any


class PlotTypeInspector:
    """Inspector for chart plot types (parity stub).

    Upstream this classifies a plot's type from its XML. The REST SDK
    receives chart-type strings directly from the studio, so the
    inspector is unused here. Provided so user code that imports
    ``PlotTypeInspector`` works.
    """

    @classmethod
    def chart_type(cls, plot: Any) -> Any:
        """Return the chart-type enum value for ``plot``.

        Upstream walks the plot's XML; we delegate to the plot's
        own ``chart_type`` attribute when available.
        """
        return getattr(plot, "chart_type", None)


# Re-export concrete Plot subclasses from pptx.shapes so user code that
# imports ``from pptx.chart.plot import BarPlot`` works.
from ..shapes import (  # noqa: E402
    Area3DPlot,
    AreaPlot,
    BarPlot,
    BubblePlot,
    DoughnutPlot,
    LinePlot,
    PiePlot,
    RadarPlot,
    XyPlot,
    _BasePlot,
)

__all__ = [
    "PlotTypeInspector",
    "_BasePlot",
    "Area3DPlot",
    "AreaPlot",
    "BarPlot",
    "BubblePlot",
    "DoughnutPlot",
    "LinePlot",
    "PiePlot",
    "RadarPlot",
    "XyPlot",
]
