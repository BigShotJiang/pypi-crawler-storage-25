"""Shim re-exporting upstream's ``pptx.chart.chart`` surface."""

from __future__ import annotations

from ..shapes import Chart, ChartTitle

__all__ = ["Chart", "ChartTitle"]
