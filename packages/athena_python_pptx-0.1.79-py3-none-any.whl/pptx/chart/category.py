"""Category sequence classes for python-pptx compatibility."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Optional


class Category(str):
    """Single chart category label (python-pptx parity).

    Subclasses ``str`` so the label can be used directly in string
    contexts (``f"{category}"``, ``category.upper()``). Adds the
    upstream ``idx`` and ``label`` accessors so type-dispatch code that
    expects the python-pptx surface works unchanged.
    """

    _idx: Optional[int]

    def __new__(cls, value: Any, idx: Optional[int] = None) -> "Category":
        instance = super().__new__(cls, str(value))
        instance._idx = idx
        return instance

    @property
    def idx(self) -> Optional[int]:
        """Zero-based position of this category in its sequence, or ``None``
        when the Category was constructed bare (e.g. ``Category("Q1")``).
        Matches python-pptx — the underlying XML stores an ``@idx``
        attribute on each ``c:pt``."""
        return self._idx

    @property
    def label(self) -> str:
        """The category's display string. Same as ``str(category)`` —
        provided for python-pptx parity (where ``Category`` is built on
        an XML proxy rather than ``str``)."""
        return str(self)


class Categories(tuple[Category, ...]):
    """Read-only chart category label sequence (python-pptx parity).

    Exposes ``depth`` / ``levels`` / ``flattened_labels`` for multi-level
    category support. The current implementation treats every Categories
    instance as single-level (``depth == 1``); multi-level (hierarchical)
    categories aren't yet stored in the SDK's chart spec, so ``levels``
    returns just the top-level labels.
    """

    def __new__(cls, values: Iterable[Any] = ()) -> "Categories":
        # Assign idx so each Category carries its position. Matches
        # python-pptx, where ``categories[2].idx == 2``.
        materialized = [
            value if isinstance(value, Category) else Category(value, idx=i)
            for i, value in enumerate(values)
        ]
        return super().__new__(cls, materialized)

    @property
    def depth(self) -> int:
        """Number of category levels — always 1 for single-level chart
        categories. Multi-level hierarchies (e.g. ``Region > Country``)
        return ``2``+ upstream; our SDK doesn't yet model them so this
        is fixed at 1."""
        return 1 if len(self) > 0 else 0

    @property
    def levels(self) -> list[list[tuple[int, str]]]:
        """Category labels grouped by level.

        Each level is a list of ``(idx, label)`` tuples mirroring
        python-pptx's ``CategoryLevel`` shape. With single-level
        categories there's exactly one level containing all categories.
        """
        if len(self) == 0:
            return []
        return [[(i, str(c)) for i, c in enumerate(self)]]

    @property
    def flattened_labels(self) -> tuple[tuple[str, ...], ...]:
        """Flat tuple of label-tuples, one per category. For single-level
        categories each inner tuple has one label; multi-level hierarchies
        would return one entry per level."""
        return tuple((str(c),) for c in self)


# Re-export CategoryLevel from pptx.shapes for parity with upstream's
# ``pptx.chart.category.CategoryLevel`` import path. Done at module
# bottom (after Category/Categories are defined) so the late import
# is safe.
def __getattr__(name: str):
    if name == "CategoryLevel":
        from ..shapes import CategoryLevel
        return CategoryLevel
    raise AttributeError(name)
