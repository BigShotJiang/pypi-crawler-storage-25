"""Shim re-exporting upstream's ``pptx.chart.datalabel`` surface."""

from __future__ import annotations

from ..shapes import DataLabel, DataLabels

__all__ = ["DataLabel", "DataLabels"]
