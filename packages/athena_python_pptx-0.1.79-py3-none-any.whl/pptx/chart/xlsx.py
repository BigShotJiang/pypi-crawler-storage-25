"""Chart workbook writers (parity stubs).

Upstream generates an embedded ``.xlsx`` workbook from a
``ChartData`` object before writing the chart part. These writers
are responsible for that — but in our REST SDK the studio API
generates the workbook server-side, so we keep them as parity
stubs only.
"""

from __future__ import annotations

from typing import Any


class _BaseWorkbookWriter:
    """Base class for chart workbook writers (parity stub)."""

    def __init__(self, chart_data: Any = None) -> None:
        self._chart_data = chart_data

    @property
    def xlsx_blob(self) -> bytes:
        return b""


class CategoryWorkbookWriter(_BaseWorkbookWriter):
    """Workbook writer for category-style charts (parity stub).

    Upstream produces the embedded XLSX backing a bar/line/area/pie/
    radar/doughnut chart. REST SDK skips this — the studio API
    materializes the workbook server-side.
    """


class XyWorkbookWriter(_BaseWorkbookWriter):
    """Workbook writer for XY (scatter) charts (parity stub)."""


class BubbleWorkbookWriter(XyWorkbookWriter):
    """Workbook writer for bubble charts (parity stub)."""


__all__ = [
    "CategoryWorkbookWriter",
    "XyWorkbookWriter",
    "BubbleWorkbookWriter",
]
