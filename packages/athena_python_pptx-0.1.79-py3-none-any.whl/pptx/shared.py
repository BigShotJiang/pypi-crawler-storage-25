"""XML-proxy base classes mirroring python-pptx's ``pptx.shared`` module.

Upstream uses these as the base for many adapter classes that wrap an
``lxml`` element + parent pointer. The REST SDK has no XML elements,
so these are minimal stub classes preserved purely for ``isinstance``
dispatch parity and for any user code that imports them directly.
"""

from __future__ import annotations

from typing import Any, Optional


class ElementProxy:
    """Base class for adapter objects that wrap a single XML element.

    Parity stub: in upstream, ``ElementProxy`` exposes ``element`` /
    ``__eq__`` / ``__ne__`` based on the wrapped lxml element. Our
    REST SDK has no lxml; the ``element`` accessor returns the
    SDK's internal element-snapshot shim where applicable, or ``None``.
    """

    def __init__(self, element: Any = None) -> None:
        self._element = element

    @property
    def element(self) -> Any:
        return self._element

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ElementProxy):
            return False
        return self._element is other._element

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)


class ParentedElementProxy(ElementProxy):
    """``ElementProxy`` that also tracks a parent reference.

    Parity stub. Upstream uses this for adapters that need to walk
    up the part hierarchy (``self.part`` traverses parents to find
    the owning OPC package part). REST SDK has no OPC packages.
    """

    def __init__(self, element: Any = None, parent: Any = None) -> None:
        super().__init__(element)
        self._parent = parent

    @property
    def parent(self) -> Any:
        return self._parent


class PartElementProxy(ElementProxy):
    """``ElementProxy`` whose parent is a specific OPC ``Part``.

    Parity stub. The REST SDK has no parts; access to ``self.part``
    is a no-op returning ``None``.
    """

    def __init__(self, element: Any = None, part: Any = None) -> None:
        super().__init__(element)
        self._part = part

    @property
    def part(self) -> Any:
        return self._part


__all__ = [
    "ElementProxy",
    "ParentedElementProxy",
    "PartElementProxy",
]
