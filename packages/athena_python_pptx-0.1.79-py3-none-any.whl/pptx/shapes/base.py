"""Shim re-exporting upstream's ``pptx.shapes.base`` surface.

Upstream's ``pptx.shapes.base`` defines :class:`BaseShape` plus the
:class:`_PlaceholderFormat` adapter. Our SDK keeps these in
:mod:`pptx.shapes`; this submodule lets ``from pptx.shapes.base import …``
work verbatim.
"""

from __future__ import annotations

from . import BaseShape, PlaceholderFormat
from . import PlaceholderFormat as _PlaceholderFormat

__all__ = ["BaseShape", "PlaceholderFormat", "_PlaceholderFormat"]
