"""Shim re-exporting upstream's ``pptx.shapes.connector.Connector``."""

from __future__ import annotations

from . import Connector

__all__ = ["Connector"]
