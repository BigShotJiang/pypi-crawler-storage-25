"""Shim re-exporting upstream's ``pptx.shapes.picture`` surface.

Upstream this module defines :class:`Picture`, :class:`Movie`, and
the ``_MediaFormat`` sub-adapter.
"""

from __future__ import annotations

from . import Movie, Picture, _MediaFormat

__all__ = ["Picture", "Movie", "_MediaFormat"]
