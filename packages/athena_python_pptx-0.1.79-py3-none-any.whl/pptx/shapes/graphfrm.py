"""Shim re-exporting upstream's ``pptx.shapes.graphfrm.GraphicFrame``."""

from __future__ import annotations

from . import GraphicFrame

__all__ = ["GraphicFrame"]
