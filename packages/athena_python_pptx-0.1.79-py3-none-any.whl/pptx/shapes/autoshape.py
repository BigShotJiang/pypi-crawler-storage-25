"""Shim re-exporting upstream's ``pptx.shapes.autoshape`` surface.

Upstream defines :class:`Shape` (the autoshape variant of
:class:`BaseShape`), plus :class:`Adjustment`,
:class:`AdjustmentCollection`, :class:`AutoShapeType`, and
:class:`Subshape` here. Our SDK keeps them in :mod:`pptx.shapes`;
this submodule lets ``from pptx.shapes.autoshape import …`` work
verbatim.
"""

from __future__ import annotations

from . import (
    Adjustment,
    AdjustmentCollection,
    AutoShapeType,
    Shape,
    Subshape,
)

__all__ = ["Shape", "Adjustment", "AdjustmentCollection", "AutoShapeType", "Subshape"]
