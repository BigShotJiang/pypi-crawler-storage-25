"""Shim re-exporting upstream's ``pptx.shapes.group.GroupShape``."""

from __future__ import annotations

from . import GroupShape

__all__ = ["GroupShape"]
