"""Shim re-exporting upstream's ``pptx.shapes.shapetree`` surface.

Upstream this module defines the shape-collection containers
(SlideShapes / LayoutShapes / etc.) and placeholder-collection
containers (SlidePlaceholders / BasePlaceholders / etc.). Ours live
in the parent :mod:`pptx.shapes` module; re-export them here.
"""

from __future__ import annotations

from . import (
    BasePlaceholders,
    GroupShapes,
    LayoutPlaceholders,
    LayoutShapes,
    MasterPlaceholders,
    MasterShapes,
    NotesSlidePlaceholders,
    NotesSlideShapes,
    Shapes,
    SlidePlaceholders,
)

# Upstream calls the slide-level Shapes class ``SlideShapes``; ours is
# named ``Shapes``. Provide both names so the canonical import works.
SlideShapes = Shapes

__all__ = [
    "Shapes",
    "SlideShapes",
    "LayoutShapes",
    "MasterShapes",
    "NotesSlideShapes",
    "GroupShapes",
    "SlidePlaceholders",
    "BasePlaceholders",
    "LayoutPlaceholders",
    "MasterPlaceholders",
    "NotesSlidePlaceholders",
]
