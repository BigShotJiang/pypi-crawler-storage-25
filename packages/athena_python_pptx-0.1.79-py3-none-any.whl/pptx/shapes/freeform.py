"""Shim re-exporting upstream's ``pptx.shapes.freeform.FreeformBuilder``."""

from __future__ import annotations

from . import FreeformBuilder

__all__ = ["FreeformBuilder"]
