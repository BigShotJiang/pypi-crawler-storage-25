"""Shim re-exporting upstream's ``pptx.shapes.placeholder`` surface."""

from __future__ import annotations

from . import (
    BasePlaceholder,
    ChartPlaceholder,
    LayoutPlaceholder,
    MasterPlaceholder,
    NotesSlidePlaceholder,
    PicturePlaceholder,
    PlaceholderGraphicFrame,
    PlaceholderPicture,
    SlidePlaceholder,
    TablePlaceholder,
    _BaseSlidePlaceholder,
)

__all__ = [
    "BasePlaceholder",
    "_BaseSlidePlaceholder",
    "SlidePlaceholder",
    "ChartPlaceholder",
    "PicturePlaceholder",
    "TablePlaceholder",
    "LayoutPlaceholder",
    "MasterPlaceholder",
    "NotesSlidePlaceholder",
    "PlaceholderGraphicFrame",
    "PlaceholderPicture",
]
