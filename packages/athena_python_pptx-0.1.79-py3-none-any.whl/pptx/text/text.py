"""Shim re-exporting upstream's ``pptx.text.text`` surface.

Upstream defines :class:`TextFrame`, :class:`_Paragraph`,
:class:`_Run`, and :class:`Font` here. Our SDK keeps them in the
parent :mod:`pptx.text`; this submodule lets canonical
``from pptx.text.text import Font`` work.
"""

from __future__ import annotations

from . import Font, Paragraph, Run, TextFrame
from . import Paragraph as _Paragraph
from . import Run as _Run

__all__ = ["Font", "Paragraph", "_Paragraph", "Run", "_Run", "TextFrame"]
