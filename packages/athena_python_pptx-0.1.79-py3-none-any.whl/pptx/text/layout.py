"""Shim re-exporting upstream's ``pptx.text.layout.TextFitter``."""

from __future__ import annotations

from . import TextFitter

__all__ = ["TextFitter"]
