"""Shim re-exporting upstream's ``pptx.text.fonts.FontFiles``."""

from __future__ import annotations

from . import FontFiles

__all__ = ["FontFiles"]
