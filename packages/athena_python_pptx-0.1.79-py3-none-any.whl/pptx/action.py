"""Stock python-pptx exposes hyperlink/action classes via ``pptx.action``.

Mirror that module path so user code written for python-pptx
(``from pptx.action import Hyperlink, ActionSetting``) keeps working.

``ActionSetting`` is a python-pptx-shaped adapter over the SDK's existing
:class:`~pptx.shapes.ClickAction` (which exposes a slightly different
surface — ``hyperlink: Optional[str]`` and string-typed ``action``). The
adapter translates the python-pptx canonical surface (``action: PP_ACTION``
+ ``hyperlink: Hyperlink``) to the underlying ``ClickAction`` so existing
SDK callers and python-pptx-style callers both work without divergence.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from .enum.action import PP_ACTION_TYPE as PP_ACTION
from .text import Hyperlink

if TYPE_CHECKING:
    from .shapes import ClickAction, Shape


# Maps the SDK's internal string action codes (used by
# :class:`pptx.shapes.ClickAction`) to the python-pptx-canonical
# :class:`PP_ACTION` integer enum.
_STRING_TO_PP_ACTION: dict[str, PP_ACTION] = {
    "none": PP_ACTION.NONE,
    "hyperlink": PP_ACTION.HYPERLINK,
    "slide": PP_ACTION.NAMED_SLIDE,
    "next_slide": PP_ACTION.NEXT_SLIDE,
    "previous_slide": PP_ACTION.PREVIOUS_SLIDE,
    "first_slide": PP_ACTION.FIRST_SLIDE,
    "last_slide": PP_ACTION.LAST_SLIDE,
    "end_show": PP_ACTION.END_SHOW,
}
_PP_ACTION_TO_STRING: dict[PP_ACTION, str] = {v: k for k, v in _STRING_TO_PP_ACTION.items()}


class _ActionHyperlink:
    """Hyperlink view on an :class:`ActionSetting` (python-pptx parity).

    python-pptx's ``ActionSetting.hyperlink`` returns a :class:`Hyperlink`
    instance with ``address`` and ``tooltip`` properties; mutations are
    proxied through the underlying click-action. The SDK's existing
    :class:`pptx.shapes.ClickAction` stores ``hyperlink`` as a raw URL
    string plus a separate ``tooltip`` field — this adapter wires both.

    Note: this is intentionally a separate class from
    :class:`pptx.text.Hyperlink` (the run-level hyperlink wrapper);
    python-pptx returns ``_Hyperlink`` instances on both surfaces, but
    the two concerns are distinct enough on Athena that keeping them
    apart prevents accidental cross-mutation.
    """

    def __init__(self, click_action: "ClickAction"):
        self._click_action = click_action

    @property
    def address(self) -> Optional[str]:
        return self._click_action.hyperlink

    @address.setter
    def address(self, value: Optional[str]) -> None:
        # Setting the underlying ``ClickAction.hyperlink`` flips the action
        # to ``"hyperlink"`` automatically and emits the SetClickAction
        # patch — see ``shapes.py:ClickAction.hyperlink.setter``.
        self._click_action.hyperlink = value or ""

    @property
    def tooltip(self) -> Optional[str]:
        return self._click_action.tooltip

    @tooltip.setter
    def tooltip(self, value: Optional[str]) -> None:
        self._click_action.tooltip = value


class ActionSetting:
    """python-pptx-compatible adapter over the SDK's :class:`ClickAction`.

    Mirrors python-pptx's ``ActionSetting`` surface:

    - ``action`` returns / accepts a :class:`PP_ACTION` enum value (we
      translate the SDK's internal string codes on the fly).
    - ``hyperlink`` returns a :class:`Hyperlink` whose ``address`` writes
      back through the SDK's existing ``SetClickAction`` patch.
    - ``target_slide`` mirrors the underlying click-action's
      slide-target index.

    Construction takes the parent shape's :class:`ClickAction` so the
    adapter is cheap to allocate and never duplicates state — the
    canonical store lives on the ``ClickAction`` instance.
    """

    def __init__(self, click_action: "ClickAction"):
        self._click_action = click_action

    @property
    def action(self) -> PP_ACTION:
        return _STRING_TO_PP_ACTION.get(self._click_action.action, PP_ACTION.NONE)

    @action.setter
    def action(self, value: PP_ACTION) -> None:
        try:
            enum_val = PP_ACTION(value)
        except (ValueError, TypeError) as exc:
            raise ValueError(
                f"ActionSetting.action expects a PP_ACTION enum, got {value!r}"
            ) from exc
        string_code = _PP_ACTION_TO_STRING.get(enum_val)
        if string_code is None:
            # The PP_ACTION enum has more values than the underlying
            # ClickAction string store (e.g. RUN_PROGRAM, OLE_VERB). Those
            # aren't wired through the SetClickAction patch yet; surface
            # the gap rather than silently fall through.
            raise ValueError(
                f"PP_ACTION.{enum_val.name} is not yet supported by athena-python-pptx; "
                "supported values: " + ", ".join(sorted(k.name for k in _PP_ACTION_TO_STRING))
            )
        self._click_action.action = string_code

    @property
    def hyperlink(self) -> _ActionHyperlink:
        return _ActionHyperlink(self._click_action)

    @property
    def target_slide(self) -> Optional[int]:
        return self._click_action.target_slide

    @target_slide.setter
    def target_slide(self, value: Optional[int]) -> None:
        self._click_action.target_slide = value


__all__ = ["ActionSetting", "Hyperlink", "PP_ACTION"]
