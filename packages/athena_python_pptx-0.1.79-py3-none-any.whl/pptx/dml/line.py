"""Shim re-exporting upstream's ``pptx.dml.line`` surface."""

from __future__ import annotations

from ..shapes import LineFormat

__all__ = ["LineFormat"]
