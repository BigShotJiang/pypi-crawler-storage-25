"""Shim re-exporting upstream's ``pptx.dml.effect.ShadowFormat``."""

from __future__ import annotations

from ..shapes import ShadowFormat

__all__ = ["ShadowFormat"]
