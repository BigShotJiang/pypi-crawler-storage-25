"""Shim re-exporting upstream's ``pptx.dml.fill`` surface."""

from __future__ import annotations

from ..shapes import FillFormat

__all__ = ["FillFormat"]
