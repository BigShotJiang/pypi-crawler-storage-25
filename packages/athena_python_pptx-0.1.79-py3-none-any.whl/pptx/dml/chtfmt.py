"""Shim re-exporting upstream's ``pptx.dml.chtfmt.ChartFormat``."""

from __future__ import annotations

from ..shapes import ChartFormat

__all__ = ["ChartFormat"]
