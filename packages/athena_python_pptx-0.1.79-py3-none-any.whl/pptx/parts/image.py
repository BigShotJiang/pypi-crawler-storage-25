"""Image part + Image content stubs (parity)."""

from __future__ import annotations

from typing import Any, Optional

from ._base import _PartStub


class ImagePart(_PartStub):
    """OPC part for an embedded image (parity stub).

    Upstream owns the image bytes and exposes ``.blob`` + ``.image``.
    The REST SDK stores images in the studio's asset store; bytes are
    not materialized into Python.
    """


class Image:
    """Image content adapter (parity stub).

    Upstream's ``pptx.parts.image.Image`` exposes ``blob``, ``ext``,
    ``content_type``, ``sha1``, ``filename``, ``size`` for an embedded
    image. The REST SDK exposes the asset URL via :attr:`Picture.image`
    when set, but the raw bytes live in the studio's asset store.
    """

    def __init__(
        self,
        blob: bytes = b"",
        filename: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> None:
        self._blob = blob
        self._filename = filename
        self._content_type = content_type or "image/png"

    @classmethod
    def from_blob(cls, blob: bytes, filename: Optional[str] = None) -> "Image":
        """Return a new :class:`Image` wrapping ``blob`` (parity)."""
        return cls(blob=blob, filename=filename)

    @classmethod
    def from_file(cls, image_file: Any) -> "Image":
        """Return a new :class:`Image` loaded from a path or file-like."""
        if hasattr(image_file, "read"):
            blob = image_file.read()
            filename = getattr(image_file, "name", None)
        else:
            with open(image_file, "rb") as f:
                blob = f.read()
            filename = str(image_file)
        return cls(blob=blob, filename=filename)

    @property
    def blob(self) -> bytes:
        return self._blob

    @property
    def content_type(self) -> str:
        return self._content_type

    @property
    def filename(self) -> Optional[str]:
        return self._filename

    @property
    def ext(self) -> str:
        ct = self._content_type
        if "/" in ct:
            return ct.split("/", 1)[1].split(";", 1)[0]
        return ""

    @property
    def sha1(self) -> str:
        import hashlib

        return hashlib.sha1(self._blob).hexdigest()

    @property
    def size(self) -> tuple[int, int]:
        return (0, 0)


__all__ = ["Image", "ImagePart"]
