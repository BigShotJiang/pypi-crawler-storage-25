"""Embedded-package Part stubs (parity).

Upstream lets a chart or graphic frame embed another Office package
(another PPTX, an XLSX, a DOCX). These are parity stubs.
"""

from __future__ import annotations

from ._base import _PartStub


class EmbeddedPackagePart(_PartStub):
    """OPC part wrapping an embedded Office package (parity stub)."""


class EmbeddedDocxPart(EmbeddedPackagePart):
    """Embedded Word document Part (parity stub)."""


class EmbeddedPptxPart(EmbeddedPackagePart):
    """Embedded PowerPoint document Part (parity stub)."""


class EmbeddedXlsxPart(EmbeddedPackagePart):
    """Embedded Excel workbook Part (parity stub)."""


__all__ = [
    "EmbeddedPackagePart",
    "EmbeddedDocxPart",
    "EmbeddedPptxPart",
    "EmbeddedXlsxPart",
]
