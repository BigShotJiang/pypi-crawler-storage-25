"""Shared base for ``pptx.parts.*`` parity stubs."""

from __future__ import annotations

from typing import Any


class _PartStub:
    """Common base for all part stubs.

    Upstream parts derive from OPC ``Part`` / ``XmlPart`` and carry an
    XML element, content-type, and partname. The REST SDK has none of
    these — this stub exists so user code that imports the names works.
    """

    def __init__(self, partname: str = "", content_type: str = "") -> None:
        self._partname = partname
        self._content_type = content_type

    @property
    def partname(self) -> str:
        return self._partname

    @property
    def content_type(self) -> str:
        return self._content_type

    @property
    def blob(self) -> bytes:  # parity surface — no underlying bytes
        return b""

    @property
    def element(self) -> Any:
        return None
