"""Slide-related Part stubs (parity).

REST SDK has no OPC parts; these classes exist for ``isinstance`` /
import parity with upstream ``pptx.parts.slide``.
"""

from __future__ import annotations

from ._base import _PartStub


class BaseSlidePart(_PartStub):
    """Common base for slide-flavoured Parts (parity stub)."""


class SlidePart(BaseSlidePart):
    """OPC part wrapping a single slide's XML (parity stub)."""


class SlideLayoutPart(BaseSlidePart):
    """OPC part wrapping a slide layout's XML (parity stub)."""


class SlideMasterPart(BaseSlidePart):
    """OPC part wrapping a slide master's XML (parity stub)."""


class NotesSlidePart(BaseSlidePart):
    """OPC part wrapping a notes slide's XML (parity stub)."""


class NotesMasterPart(BaseSlidePart):
    """OPC part wrapping the notes master's XML (parity stub)."""


__all__ = [
    "BaseSlidePart",
    "SlidePart",
    "SlideLayoutPart",
    "SlideMasterPart",
    "NotesSlidePart",
    "NotesMasterPart",
]
