"""Presentation Part stub (parity)."""

from __future__ import annotations

from ._base import _PartStub


class PresentationPart(_PartStub):
    """OPC part wrapping the presentation.xml (parity stub).

    REST SDK has no OPC; reach the presentation via ``pptx.Presentation``.
    """


__all__ = ["PresentationPart"]
