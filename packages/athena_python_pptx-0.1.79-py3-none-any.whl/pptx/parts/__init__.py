"""Parity stubs for python-pptx's ``pptx.parts.*`` package.

Upstream organizes OPC package parts (one per relationship type) into
subclasses of ``BaseSlidePart`` / ``XmlPart`` / ``PartFactory``. The
REST SDK has no OPC packages; these stubs exist so user code that
imports ``from pptx.parts.image import Image`` etc. resolves to a
real class. Behaviour is intentionally minimal — these aren't
expected to be instantiated by user code; they're imported for
``isinstance`` checks and type annotations.
"""
