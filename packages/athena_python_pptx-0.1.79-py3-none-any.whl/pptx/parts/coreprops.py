"""Core-properties Part stub (parity)."""

from __future__ import annotations

from ._base import _PartStub


class CorePropertiesPart(_PartStub):
    """OPC part for core document properties (parity stub).

    Upstream this owns metadata like author, title, modified date.
    The REST SDK exposes these via deck metadata APIs, not parts.
    """


__all__ = ["CorePropertiesPart"]
