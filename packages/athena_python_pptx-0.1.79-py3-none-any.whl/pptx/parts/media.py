"""Media (video/audio) Part stub (parity)."""

from __future__ import annotations

from ._base import _PartStub


class MediaPart(_PartStub):
    """OPC part for an embedded media file (video/audio) (parity stub)."""


__all__ = ["MediaPart"]
