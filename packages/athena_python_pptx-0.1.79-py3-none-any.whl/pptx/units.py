"""
Unit conversion utilities mirroring python-pptx conventions.

EMU (English Metric Units) is the native unit used internally.
1 inch = 914400 EMU
1 cm = 360000 EMU
1 pt = 12700 EMU

Class hierarchy mirrors stock python-pptx (`pptx.util`):

    int ← Length ← Emu, Inches, Cm, Mm, Pt, Centipoints

All unit subclasses inherit ``inches`` / ``cm`` / ``mm`` / ``pt`` /
``centipoints`` / ``emu`` properties from :class:`Length`. The
constructor of each subclass converts its input from the named unit
into EMU; the underlying integer always stores EMU.

``Px`` is the SDK's non-standard pixel helper — kept as a Length
subclass for symmetry, but not in python-pptx upstream.
"""

from __future__ import annotations
from typing import Union

# EMU constants
EMU_PER_INCH = 914400
EMU_PER_CM = 360000
EMU_PER_MM = 36000
EMU_PER_PT = 12700
EMU_PER_CENTIPOINT = 127
EMU_PER_PX = 9525  # At 96 DPI


def _length_reconstruct(cls: type, emu_value: int):  # noqa: ANN201
    """Top-level reconstructor for :class:`Length` subclasses.

    Used by :meth:`Length.__reduce_ex__` so that ``copy.deepcopy`` (and
    ``pickle``) round-trip a :class:`Length` subclass without going
    through the unit-converting ``__new__``. Must be a module-level
    function so pickle can locate it by qualified name.
    """
    return cls._from_emu(emu_value)


class Length(int):
    """
    Length expressed in English Metric Units (EMU) — base unit class.

    Mirrors python-pptx's ``pptx.util.Length``. All unit-bearing
    subclasses (``Inches``, ``Cm``, ``Mm``, ``Pt``, ``Centipoints``,
    ``Emu``) extend this class and inherit the same unit-conversion
    property surface, so ``Length(914400).inches == 1.0`` regardless of
    whether you constructed via ``Inches(1)`` or ``Emu(914400)``.
    """

    def __new__(cls, value: Union[int, float, "Length"]) -> "Length":
        return super().__new__(cls, int(round(value)))

    # ``copy.deepcopy`` (used by ``dataclasses.asdict``) reconstructs ints
    # by invoking ``Type(int_value)``. For our subclasses that means
    # ``Pt(355600)`` etc., which interpret the value as user-units and
    # multiply by the unit's EMU factor → ``355600 → 4,516,120,000``.
    # Override the pickle/reduce protocol so deep-copy round-trips via
    # ``_from_emu`` (treats the value as raw EMU), preserving identity.
    def __reduce_ex__(self, protocol: int):  # type: ignore[override]
        return (_length_reconstruct, (type(self), int(self)))

    @property
    def inches(self) -> float:
        """Return value in inches."""
        return int(self) / EMU_PER_INCH

    @property
    def cm(self) -> float:
        """Return value in centimeters."""
        return int(self) / EMU_PER_CM

    @property
    def mm(self) -> float:
        """Return value in millimeters."""
        return int(self) / EMU_PER_MM

    @property
    def pt(self) -> float:
        """Return value in points."""
        return int(self) / EMU_PER_PT

    @property
    def centipoints(self) -> float:
        """Return value in centipoints (1/100 of a point)."""
        return int(self) / EMU_PER_CENTIPOINT

    @property
    def px(self) -> float:
        """Return value in pixels (at 96 DPI). SDK-only convenience."""
        return int(self) / EMU_PER_PX

    @property
    def emu(self) -> int:
        """Return raw EMU value."""
        return int(self)

    # -------------------------------------------------------------------------
    # Arithmetic operations (return Length-subclass objects)
    # -------------------------------------------------------------------------
    # Arithmetic preserves the leftmost operand's type so e.g.
    # ``Inches(1) + Inches(1)`` returns an ``Inches`` instance. Mixed-unit
    # arithmetic (``Inches(1) + Pt(72)``) returns the left operand's type;
    # the operation is correct because the underlying integer is always EMU.

    def __add__(self, other: Union[int, float, "Length"]) -> "Length":
        return type(self)._from_emu(int(self) + int(other))

    def __radd__(self, other: Union[int, float, "Length"]) -> "Length":
        return type(self)._from_emu(int(other) + int(self))

    def __sub__(self, other: Union[int, float, "Length"]) -> "Length":
        return type(self)._from_emu(int(self) - int(other))

    def __rsub__(self, other: Union[int, float, "Length"]) -> "Length":
        return type(self)._from_emu(int(other) - int(self))

    def __mul__(self, other: Union[int, float]) -> "Length":
        return type(self)._from_emu(int(self) * other)

    def __rmul__(self, other: Union[int, float]) -> "Length":
        return type(self)._from_emu(other * int(self))

    def __truediv__(self, other: Union[int, float]) -> "Length":
        return type(self)._from_emu(int(self) / other)

    def __floordiv__(self, other: Union[int, float]) -> "Length":
        return type(self)._from_emu(int(self) // other)

    def __neg__(self) -> "Length":
        return type(self)._from_emu(-int(self))

    def __abs__(self) -> "Length":
        return type(self)._from_emu(abs(int(self)))

    @classmethod
    def _from_emu(cls, value: Union[int, float]) -> "Length":
        """Bypass the unit-conversion ``__new__`` and construct the
        subclass directly from a raw EMU value. Used by arithmetic ops
        so ``Inches(1) + Inches(1)`` doesn't re-apply the
        ``* EMU_PER_INCH`` multiplier."""
        instance = int.__new__(cls, int(round(value)))
        return instance

    # -------------------------------------------------------------------------
    # Convenience conversion methods (SDK extras — not in python-pptx upstream)
    # -------------------------------------------------------------------------

    def to_inches(self) -> float:
        """Convert to inches (same as .inches property)."""
        return self.inches

    def to_cm(self) -> float:
        """Convert to centimeters (same as .cm property)."""
        return self.cm

    def to_pt(self) -> float:
        """Convert to points (same as .pt property)."""
        return self.pt

    def to_px(self, dpi: int = 96) -> float:
        """Convert to pixels at specified DPI."""
        inches = int(self) / EMU_PER_INCH
        return inches * dpi

    @classmethod
    def from_inches(cls, value: Union[int, float]) -> "Length":
        return cls._from_emu(value * EMU_PER_INCH)

    @classmethod
    def from_cm(cls, value: Union[int, float]) -> "Length":
        return cls._from_emu(value * EMU_PER_CM)

    @classmethod
    def from_pt(cls, value: Union[int, float]) -> "Length":
        return cls._from_emu(value * EMU_PER_PT)

    @classmethod
    def from_px(cls, value: Union[int, float], dpi: int = 96) -> "Length":
        inches = value / dpi
        return cls._from_emu(inches * EMU_PER_INCH)

    def __repr__(self) -> str:
        return f"{type(self).__name__}({int(self)})"


class Emu(Length):
    """Raw EMU value. ``Emu(914400)`` stores 914400 EMU (1 inch)."""

    def __new__(cls, value: Union[int, float, "Length"]) -> "Emu":
        return super().__new__(cls, int(round(value)))  # type: ignore[return-value]


class Inches(Length):
    """Length in inches. ``Inches(1)`` stores 914400 EMU."""

    def __new__(cls, value: Union[int, float]) -> "Inches":
        return int.__new__(cls, int(round(value * EMU_PER_INCH)))  # type: ignore[return-value]


class Cm(Length):
    """Length in centimeters. ``Cm(2.54)`` stores ≈914400 EMU (1 inch)."""

    def __new__(cls, value: Union[int, float]) -> "Cm":
        return int.__new__(cls, int(round(value * EMU_PER_CM)))  # type: ignore[return-value]


class Mm(Length):
    """Length in millimeters. ``Mm(25.4)`` stores ≈914400 EMU (1 inch)."""

    def __new__(cls, value: Union[int, float]) -> "Mm":
        return int.__new__(cls, int(round(value * EMU_PER_MM)))  # type: ignore[return-value]


class Pt(Length):
    """Length in points. ``Pt(72)`` stores 914400 EMU (1 inch)."""

    def __new__(cls, value: Union[int, float]) -> "Pt":
        return int.__new__(cls, int(round(value * EMU_PER_PT)))  # type: ignore[return-value]


class Centipoints(Length):
    """Length in centipoints (1/100 of a point). ``Centipoints(7200)`` stores 914400 EMU."""

    def __new__(cls, value: Union[int, float]) -> "Centipoints":
        return int.__new__(cls, int(round(value * EMU_PER_CENTIPOINT)))  # type: ignore[return-value]


class Px(Length):
    """Length in pixels at 96 DPI. SDK-only — not a python-pptx upstream class."""

    def __new__(cls, value: Union[int, float]) -> "Px":
        return int.__new__(cls, int(round(value * EMU_PER_PX)))  # type: ignore[return-value]


def ensure_emu(value: Union[int, float, Length]) -> Emu:
    """Ensure a value is an Emu instance.

    Accepts any :class:`Length` subclass (Pt/Cm/etc.) and re-wraps it as
    an :class:`Emu` instance for consistent type-checks. Raw ints / floats
    are also accepted.
    """
    if isinstance(value, Emu):
        return value
    if isinstance(value, Length):
        # Already a Length subclass with the right EMU integer — re-wrap
        # without going through the unit converters.
        return Emu._from_emu(int(value))  # type: ignore[return-value]
    return Emu(value)
