"""
Video / media-asset class (python-pptx parity).

Stock python-pptx ships :class:`pptx.media.Video` for working with
embedded video bytes. Mirrors the surface — ``blob`` / ``content_type``
/ ``ext`` / ``filename`` / ``sha1`` + the ``from_blob`` /
``from_path_or_file_like`` factory classmethods — so user code that
constructs ``Video.from_path_or_file_like("clip.mp4")`` and passes it
to ``slide.shapes.add_movie(...)`` works unchanged.

The REST SDK doesn't fully implement video upload yet; the
:class:`pptx.shapes.Movie` shape is shape-shell-only. Video objects
constructed here carry their bytes locally; a future
``SlideShapes.add_movie`` will hand them off to the studio's asset
store.
"""

from __future__ import annotations

import hashlib
import io
import os
from typing import IO, Optional, Union


# Content-type lookup table for the common video extensions python-pptx
# supports. Mirrors what stock ships in ``pptx.spec``.
_EXT_TO_CONTENT_TYPE = {
    ".mp4": "video/mp4",
    ".mpg": "video/mpeg",
    ".mpeg": "video/mpeg",
    ".mov": "video/quicktime",
    ".avi": "video/avi",
    ".wmv": "video/x-ms-wmv",
    ".m4v": "video/x-m4v",
    ".webm": "video/webm",
}


class Video:
    """Embedded-video bytes with helpers to load from blob or file path.

    Mirrors python-pptx's :class:`pptx.media.Video`. Construct via the
    :py:meth:`from_blob` or :py:meth:`from_path_or_file_like` factories
    rather than calling the constructor directly.
    """

    def __init__(self, blob: bytes, ext: str, content_type: Optional[str] = None, filename: Optional[str] = None):
        self._blob = blob
        # Normalize ``ext`` so callers can pass ``"mp4"`` or ``".mp4"``.
        if not ext.startswith("."):
            ext = "." + ext
        self._ext = ext.lower()
        self._content_type = content_type or _EXT_TO_CONTENT_TYPE.get(self._ext, "application/octet-stream")
        self._filename = filename

    # ------------------------------------------------------------------
    # Factories
    # ------------------------------------------------------------------

    @classmethod
    def from_blob(
        cls,
        blob: bytes,
        mime_type: str,
        filename: Optional[str] = None,
    ) -> "Video":
        """Construct a :class:`Video` from raw bytes + mime type.

        Mirrors python-pptx's classmethod of the same name.
        """
        # Reverse-lookup an extension for the mime type.
        ext = next(
            (e for e, ct in _EXT_TO_CONTENT_TYPE.items() if ct == mime_type),
            ".bin",
        )
        return cls(blob=blob, ext=ext, content_type=mime_type, filename=filename)

    @classmethod
    def from_path_or_file_like(
        cls,
        movie_file: Union[str, os.PathLike, IO[bytes]],
        mime_type: Optional[str] = None,
    ) -> "Video":
        """Construct a :class:`Video` from a path or open file-like object.

        Mirrors python-pptx's classmethod. The mime type is inferred
        from the path extension when not provided. Parameter is named
        ``movie_file`` to match python-pptx exactly.
        """
        if hasattr(movie_file, "read"):
            # file-like
            blob = movie_file.read()
            filename = getattr(movie_file, "name", None)
            # Derive extension from filename if available.
            ext = os.path.splitext(filename)[1].lower() if filename else ".bin"
        else:
            with open(movie_file, "rb") as f:
                blob = f.read()
            filename = os.path.basename(str(movie_file))
            ext = os.path.splitext(filename)[1].lower()
        if mime_type is None:
            mime_type = _EXT_TO_CONTENT_TYPE.get(ext, "application/octet-stream")
        return cls(blob=blob, ext=ext, content_type=mime_type, filename=filename)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def blob(self) -> bytes:
        """Raw video bytes."""
        return self._blob

    @property
    def content_type(self) -> str:
        """MIME type (e.g. ``"video/mp4"``)."""
        return self._content_type

    @property
    def ext(self) -> str:
        """File extension with leading dot (e.g. ``".mp4"``)."""
        return self._ext

    @property
    def filename(self) -> Optional[str]:
        """Original filename if known."""
        return self._filename

    @property
    def sha1(self) -> str:
        """SHA-1 hash of the video bytes (hex digest)."""
        return hashlib.sha1(self._blob).hexdigest()
