"""Typing protocols mirroring python-pptx's ``pptx.types`` module.

Upstream defines structural protocols for shape-like and part-aware
objects. Mirroring them here lets user type annotations referencing
``ProvidesExtents`` / ``ProvidesPart`` resolve cleanly without
``ImportError``.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ProvidesExtents(Protocol):
    """Structural protocol for anything exposing position / size.

    Parity stub. Both shapes and slide rectangles satisfy it.
    """

    @property
    def width(self) -> Any: ...

    @property
    def height(self) -> Any: ...


@runtime_checkable
class ProvidesPart(Protocol):
    """Structural protocol for objects with an OPC ``part`` accessor.

    Parity stub — for upstream, this is "anything reachable from an
    OPC package". The REST SDK has no parts; this protocol exists
    purely for type-annotation parity.
    """

    @property
    def part(self) -> Any: ...


__all__ = ["ProvidesExtents", "ProvidesPart"]
