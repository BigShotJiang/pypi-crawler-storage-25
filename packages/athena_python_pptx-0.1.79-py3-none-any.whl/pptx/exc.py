"""Exception classes mirroring python-pptx's ``pptx.exc`` module.

Stock python-pptx defines a small exception hierarchy rooted at
:class:`PythonPptxError`. Athena's SDK has its own
:class:`PptxSdkError` hierarchy in :mod:`pptx.errors` for runtime
behaviour, but user code that catches the canonical names should
work verbatim. ``PythonPptxError`` is therefore an alias of
``PptxSdkError`` so ``except PythonPptxError`` catches our errors.
"""

from __future__ import annotations

from .errors import PptxSdkError


# Alias: every PptxSdkError IS-A PythonPptxError as far as user code
# is concerned. Catches across both names will work identically.
PythonPptxError = PptxSdkError


class PackageNotFoundError(PythonPptxError):
    """Raised when a package cannot be found at the specified path.

    Parity with upstream's ``pptx.exc.PackageNotFoundError`` — usually
    raised by ``Presentation(path)`` when the local file doesn't exist.
    """


class InvalidXmlError(PythonPptxError):
    """Raised when a value in the XML is invalid per the schema.

    Parity with upstream's ``pptx.exc.InvalidXmlError``. The REST SDK
    doesn't manipulate XML directly so this is rarely raised, but the
    class exists so user code that catches it works verbatim.
    """


__all__ = [
    "PythonPptxError",
    "PackageNotFoundError",
    "InvalidXmlError",
]
