"""
Type definitions and protocols for the PPTX SDK.
"""

from __future__ import annotations
from typing import Any, Literal, Optional, Protocol, TypedDict, Union
from dataclasses import dataclass, field
from enum import IntEnum


# Type aliases for IDs
DeckId = str
SlideId = str
ShapeId = str
ElementId = str
ExportJobId = str
RenderJobId = str


# Placeholder types (matching OOXML spec and python-pptx's PP_PLACEHOLDER_TYPE)
PlaceholderTypeLiteral = Literal[
    "title",
    "body",
    "ctrTitle",
    "subTitle",
    "dt",
    "sldNum",
    "ftr",
    "hdr",
    "pic",
    "chart",
    "tbl",
    "clipArt",
    "dgm",
    "media",
    "sldImg",
    "obj",
    "secHead",
]


class PP_PLACEHOLDER(IntEnum):
    """
    Placeholder type enumeration.

    Mirrors python-pptx's PP_PLACEHOLDER_TYPE exactly.
    Values match the MS API PpPlaceholderType enumeration.
    """

    TITLE = 1
    BODY = 2
    CENTER_TITLE = 3
    SUBTITLE = 4
    VERTICAL_TITLE = 5
    VERTICAL_BODY = 6
    OBJECT = 7
    CHART = 8
    BITMAP = 9
    MEDIA_CLIP = 10
    ORG_CHART = 11
    TABLE = 12
    SLIDE_NUMBER = 13
    HEADER = 14
    FOOTER = 15
    DATE = 16
    VERTICAL_OBJECT = 17
    PICTURE = 18
    SLIDE_IMAGE = 101
    MIXED = -2

    # Map from OOXML string type to enum value
    @classmethod
    def from_ooxml_type(cls, ooxml_type: str) -> "PP_PLACEHOLDER":
        """Convert OOXML placeholder type string to enum value."""
        mapping = {
            "title": cls.TITLE,
            "body": cls.BODY,
            "ctrTitle": cls.CENTER_TITLE,
            "subTitle": cls.SUBTITLE,
            "dt": cls.DATE,
            "sldNum": cls.SLIDE_NUMBER,
            "ftr": cls.FOOTER,
            "hdr": cls.HEADER,
            "pic": cls.PICTURE,
            "chart": cls.CHART,
            "tbl": cls.TABLE,
            "clipArt": cls.BITMAP,
            "dgm": cls.ORG_CHART,
            "media": cls.MEDIA_CLIP,
            "sldImg": cls.SLIDE_IMAGE,
            "obj": cls.OBJECT,
            "secHead": cls.TITLE,
        }
        return mapping.get(ooxml_type, cls.OBJECT)


# Command types
CommandType = Literal[
    "AddTextBox",
    "SetText",
    "SetTransform",
    "SetRunStyle",
    "AddSlide",
    "DeleteSlide",
    "DeleteShape",
]


class Transform(TypedDict, total=False):
    """Transform specification in EMUs."""

    x: int
    y: int
    w: int
    h: int
    rot: float
    flipH: bool
    flipV: bool


class TextRunPath(TypedDict):
    """Path to a specific text run within a shape."""

    p: int  # Paragraph index
    r: int  # Run index


class TextStyle(TypedDict, total=False):
    """Text styling options."""

    fontSizePt: float
    fontFamily: str
    bold: bool
    italic: bool
    underline: bool
    colorHex: str


@dataclass
class SlideSnapshot:
    """Snapshot of a slide's state."""

    id: SlideId
    index: int
    element_ids: list[ElementId]
    background_color_hex: Optional[str] = None
    notes: Optional[str] = None
    layout_path: Optional[str] = None
    layout_name: Optional[str] = None
    inherited_element_ids: list[ElementId] = field(default_factory=list)


@dataclass
class PlaceholderSnapshot:
    """Snapshot of placeholder format info."""

    type: PlaceholderTypeLiteral
    idx: int
    sz: Optional[Literal["full", "half", "quarter"]] = None
    orient: Optional[Literal["horz", "vert"]] = None
    has_custom_prompt: Optional[bool] = None
    local_transform_override: Optional[bool] = None


@dataclass
class TextFramePropertiesSnapshot:
    """Snapshot of a text frame's structural properties (auto-size, margins, etc.).

    Carries the source PPTX's <a:bodyPr> state through `from_url` so the SDK's
    TextFrame can populate its internal `_auto_size`/`_word_wrap`/`_margin_*`
    fields. Without this, a user setter (`text_frame.margin_left = 0`) emits a
    SetTextFrameProperties command that omits the un-touched props, the server
    keeps whatever it has, and round-trip is lossy.
    """

    word_wrap: Optional[bool] = None
    auto_size: Optional[Literal["none", "shape_to_fit_text", "text_to_fit_shape"]] = None
    vertical_anchor: Optional[Literal["top", "middle", "bottom"]] = None
    margin_left: Optional[int] = None
    margin_right: Optional[int] = None
    margin_top: Optional[int] = None
    margin_bottom: Optional[int] = None


@dataclass
class ElementSnapshot:
    """Snapshot of an element's state."""

    id: ElementId
    type: Literal["text", "shape", "image", "chart", "table", "group", "unknown"]
    slide_id: SlideId
    transform: Transform
    preview_text: Optional[str] = None
    placeholder: Optional[PlaceholderSnapshot] = None
    properties: Optional[dict[str, Any]] = None
    source: Optional[Literal["ingested", "sdk", "layout", "master"]] = None
    table_data: Optional[dict[str, Any]] = None
    asset_id: Optional[str] = None
    text_frame_properties: Optional[TextFramePropertiesSnapshot] = None


@dataclass
class LayoutSnapshot:
    """Snapshot of a slide layout, sourced from the deck's theme hierarchy."""

    path: str
    name: str
    master_path: Optional[str] = None


@dataclass
class MasterSnapshot:
    """Snapshot of a slide master, sourced from the deck's theme hierarchy."""

    path: str
    name: str
    theme_path: Optional[str] = None
    layout_paths: list[str] = field(default_factory=list)


@dataclass
class ThemeHierarchySnapshot:
    """Projection of the deck's master/layout/theme structure for SDK consumption."""

    masters: list[MasterSnapshot] = field(default_factory=list)
    layouts: list[LayoutSnapshot] = field(default_factory=list)


@dataclass
class DeckSnapshot:
    """Complete snapshot of a deck's state."""

    deck_id: DeckId
    name: str
    slide_width_emu: int
    slide_height_emu: int
    slide_count: int
    slides: list[SlideSnapshot]
    elements: dict[ElementId, ElementSnapshot]
    theme_hierarchy: Optional[ThemeHierarchySnapshot] = None


class CommandDict(TypedDict, total=False):
    """Generic command dictionary."""

    type: CommandType
    slideIndex: int
    shapeId: ShapeId
    xEmu: int
    yEmu: int
    wEmu: int
    hEmu: int
    rotDeg: float
    text: str
    path: TextRunPath
    style: TextStyle


class CommandsRequest(TypedDict):
    """Request body for POST /commands."""

    client: dict[str, str]
    txn: dict[str, str]
    commands: list[CommandDict]
    return_: dict[str, bool]


class CommandsResponse(TypedDict, total=False):
    """Response from POST /commands."""

    applied: bool
    created: dict[str, list[str]]
    snapshot: DeckSnapshot
    error: dict[str, Any]


class ExportStatus(TypedDict, total=False):
    """Export job status."""

    job_id: ExportJobId
    status: Literal["queued", "processing", "completed", "failed"]
    download_url: Optional[str]
    error: Optional[str]


class RenderStatus(TypedDict, total=False):
    """Render job status."""

    job_id: RenderJobId
    status: Literal["queued", "processing", "completed", "failed"]
    image_url: Optional[str]
    error: Optional[str]


class ShapeProtocol(Protocol):
    """Protocol for shape objects."""

    @property
    def shape_id(self) -> ShapeId:
        ...

    @property
    def left(self) -> int:
        ...

    @property
    def top(self) -> int:
        ...

    @property
    def width(self) -> int:
        ...

    @property
    def height(self) -> int:
        ...


class TextFrameProtocol(Protocol):
    """Protocol for text frame objects."""

    @property
    def text(self) -> str:
        ...

    @text.setter
    def text(self, value: str) -> None:
        ...
