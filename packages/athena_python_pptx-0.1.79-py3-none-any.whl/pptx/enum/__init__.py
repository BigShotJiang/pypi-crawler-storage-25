"""
Enumerations for python-pptx compatibility.

This module provides enumerations that match the python-pptx API.
"""

from .shapes import MSO_SHAPE, MSO_SHAPE_TYPE, MSO_CONNECTOR, MSO_CONNECTOR_TYPE, PP_PLACEHOLDER
from .text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_PARAGRAPH_ALIGNMENT
from .dml import MSO_THEME_COLOR, MSO_LINE_DASH_STYLE, MSO_FILL_TYPE
from .chart import XL_CHART_TYPE, XL_DATA_LABEL_POSITION, XL_LABEL_POSITION, XL_LEGEND_POSITION
# ``PP_ACTION`` is the public alias for ``PP_ACTION_TYPE`` in python-pptx;
# expose both names so ``from pptx.enum.action import PP_ACTION`` resolves.
from .action import PP_ACTION_TYPE
from .action import PP_ACTION_TYPE as PP_ACTION
from .lang import MSO_LANGUAGE_ID

__all__ = [
    # Shapes
    "MSO_SHAPE",
    "MSO_SHAPE_TYPE",
    "MSO_CONNECTOR",
    "MSO_CONNECTOR_TYPE",
    "PP_PLACEHOLDER",
    # Text
    "MSO_ANCHOR",
    "MSO_AUTO_SIZE",
    "PP_PARAGRAPH_ALIGNMENT",
    # DML
    "MSO_THEME_COLOR",
    "MSO_LINE_DASH_STYLE",
    "MSO_FILL_TYPE",
    # Chart
    "XL_CHART_TYPE",
    "XL_DATA_LABEL_POSITION",
    "XL_LABEL_POSITION",
    "XL_LEGEND_POSITION",
    # Action
    "PP_ACTION_TYPE",
    "PP_ACTION",
    # Language
    "MSO_LANGUAGE_ID",
]
