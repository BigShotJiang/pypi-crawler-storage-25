"""Package-level stub mirroring python-pptx's ``pptx.package`` module.

Upstream's ``Package`` is the top-level OPC package adapter (loaded
from a ``.pptx`` file). The REST SDK has no OPC; this stub exists
purely for ``isinstance`` / import parity. Open a deck via
``pptx.Presentation.upload(path)`` or ``Presentation(deck_id=…)``.
"""

from __future__ import annotations

from typing import Any, Optional


class Package:
    """OPC package adapter (parity stub).

    REST SDK has no parts. ``open`` raises
    :class:`UnsupportedFeatureError` to surface the gap clearly.
    """

    @classmethod
    def open(cls, pkg_file: Any) -> "Package":  # pragma: no cover - parity-only
        from .errors import UnsupportedFeatureError

        raise UnsupportedFeatureError(
            "Package.open",
            "REST SDK uses Presentation.upload(path) instead of "
            "Package.open(path); the OPC package isn't materialized in Python.",
        )

    @property
    def main_document_part(self) -> Optional[Any]:
        return None


__all__ = ["Package"]
