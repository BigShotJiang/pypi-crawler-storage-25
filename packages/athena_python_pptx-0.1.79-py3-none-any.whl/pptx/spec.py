"""Shape specification types mirroring python-pptx's ``pptx.spec`` module.

Parity-only stub: the REST SDK doesn't operate on local autoshape specs
the way upstream does (built-in geometry tables for the ~180 preset
autoshapes). The ``ShapeSpec`` TypedDict exists so user code that
imports it for type annotations works.
"""

from __future__ import annotations

from typing import Any, TypedDict


class ShapeSpec(TypedDict, total=False):
    """TypedDict for an autoshape spec (parity stub).

    Upstream this names the keys for a row in
    ``pptx.spec.autoshape_types``. The REST SDK resolves prst →
    geometry server-side, so this is purely a typing aid.
    """

    basename: str
    prst: str
    avLst: Any
    desc: str


__all__ = ["ShapeSpec"]
