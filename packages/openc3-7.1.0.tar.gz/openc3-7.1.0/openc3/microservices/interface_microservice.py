# Copyright 2026 OpenC3, Inc.
# All Rights Reserved.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE.md for more details.

# This file may also be used under the terms of a commercial license
# if purchased from OpenC3, Inc.
#
# A portion of this file was funded by Blue Origin Enterprises, L.P.
# See https://github.com/OpenC3/cosmos/pull/1963

import contextlib
import json
import os
import sys
import threading
import time
import traceback
import uuid
from datetime import datetime, timezone

from openc3.config.config_parser import ConfigParser
from openc3.interfaces.interface import WriteRejectError
from openc3.microservices.interface_decom_common import handle_inject_tlm
from openc3.microservices.microservice import Microservice
from openc3.models.cvt_model import CvtModel
from openc3.models.interface_model import InterfaceModel
from openc3.models.interface_status_model import InterfaceStatusModel
from openc3.models.router_model import RouterModel
from openc3.models.router_status_model import RouterStatusModel
from openc3.models.scope_model import ScopeModel
from openc3.models.target_model import TargetModel
from openc3.system.system import System
from openc3.top_level import kill_thread
from openc3.topics.command_decom_topic import CommandDecomTopic
from openc3.topics.command_topic import CommandTopic
from openc3.topics.interface_topic import InterfaceTopic
from openc3.topics.router_topic import RouterTopic
from openc3.topics.telemetry_topic import TelemetryTopic
from openc3.utilities.json import JsonDecoder, JsonEncoder
from openc3.utilities.logger import Logger
from openc3.utilities.sleeper import Sleeper
from openc3.utilities.store_queued import EphemeralStoreQueued, StoreQueued
from openc3.utilities.thread_manager import ThreadManager
from openc3.utilities.time import from_nsec_from_epoch


with contextlib.suppress(ModuleNotFoundError):
    # Should never actually be used in COSMOS Core
    from openc3enterprise.models.critical_cmd_model import CriticalCmdModel


class InterfaceCmdHandlerThread:
    def __init__(self, interface, tlm, logger=None, metric=None, db_shard=0, scope=None):
        self.interface = interface
        self.tlm = tlm
        self.scope = scope
        self.db_shard = int(db_shard or 0)
        scope_model = ScopeModel.get_model(name=scope)
        if scope_model is not None:
            self.critical_commanding = scope_model.critical_commanding
        else:
            self.critical_commanding = "OFF"
        self.logger = logger
        if not self.logger:
            self.logger = Logger()
        self.metric = metric
        self.count = 0
        self.directive_count = 0
        if self.metric is not None:
            self.metric.set(
                name="interface_directive_total",
                value=self.directive_count,
                type="counter",
            )
            self.metric.set(name="interface_cmd_total", value=self.count, type="counter")

    def start(self):
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()
        ThreadManager.instance().register(self.thread, stop_object=self)
        return self.thread

    def stop(self):
        kill_thread(self, self.thread)

    def graceful_kill(self):
        InterfaceTopic.shutdown(self.interface, scope=self.scope)
        time.sleep(0.001)  # Allow other threads to run

    def run(self):
        # receive_commands does a while True and does not return
        InterfaceTopic.receive_commands(self.process_cmd, self.interface, self.scope, db_shard=self.db_shard)

    def process_cmd(self, topic, msg_id, msg_hash, _redis):
        # OpenC3.with_context(msg_hash) do
        release_critical = False
        critical_model = None

        if msg_hash.get(b"shutdown"):
            return "Shutdown"

        msgid_seconds_from_epoch = int(msg_id.split("-")[0]) / 1000.0
        delta = time.time() - msgid_seconds_from_epoch
        if self.metric is not None:
            self.metric.set(
                name="interface_topic_delta_seconds",
                value=delta,
                type="gauge",
                unit="seconds",
                help="Delta time between data written to stream and interface cmd start",
            )

        if topic == "OPENC3__SYSTEM__EVENTS":
            msg = json.loads(msg_hash.get(b"event", b"{}").decode())
            if msg["type"] == "scope" and msg["name"] == self.scope:
                self.critical_commanding = msg["critical_commanding"]
            return "SUCCESS"

        # Check for a raw write to the interface
        if "CMD}INTERFACE" in topic:
            self.directive_count += 1
            if self.metric is not None:
                self.metric.set(
                    name="interface_directive_total",
                    value=self.directive_count,
                    type="counter",
                )
            if msg_hash.get(b"shutdown"):
                self.logger.info(f"{self.interface.name}: Shutdown requested")
                InterfaceTopic.clear_topics(
                    InterfaceTopic.topics(self.interface, scope=self.scope), db_shard=self.db_shard
                )
                return "SHUTDOWN"
            if msg_hash.get(b"connect"):
                self.logger.info(f"{self.interface.name}: Connect requested")
                params = []
                if msg_hash.get(b"params"):
                    params = json.loads(msg_hash[b"params"])
                self.interface = self.tlm.attempting(*params)
                return "SUCCESS"
            if msg_hash.get(b"disconnect"):
                self.logger.info(f"{self.interface.name}: Disconnect requested")
                try:
                    self.tlm.disconnect(False)
                except Exception as e:
                    self.logger.error(f"{self.interface.name}: disconnect: {traceback.format_exc()}")
                    return str(e)
                return "SUCCESS"
            if msg_hash.get(b"raw"):
                if self.interface.connected():
                    try:
                        self.logger.info(f"{self.interface.name}: Write raw")
                        # A raw interface write results in an UNKNOWN packet
                        command = System.commands.packet("UNKNOWN", "UNKNOWN")
                        command.received_count = TargetModel.increment_command_count(
                            command.target_name,
                            command.packet_name,
                            1,
                            scope=self.scope,
                        )
                        command = command.clone()
                        command.buffer = msg_hash[b"raw"]
                        command.received_time = datetime.now(timezone.utc)
                        CommandTopic.write_packet(command, scope=self.scope)
                        self.logger.info(
                            f"write_raw sent {len(msg_hash[b'raw'])} bytes to {self.interface.name}",
                            scope=self.scope,
                        )
                        self.interface.write_raw(msg_hash[b"raw"])
                    except Exception as e:
                        self.logger.error(f"{self.interface.name}: write_raw: {traceback.format_exc()}")
                        # Return only the error message (not full traceback) to match Ruby behavior
                        return str(e)
                    return "SUCCESS"
                else:
                    return f"Interface not connected: {self.interface.name}"
            if msg_hash.get(b"log_stream"):
                if msg_hash[b"log_stream"].decode() == "true":
                    self.logger.info(f"{self.interface.name}: Enable stream logging")
                    self.interface.start_raw_logging()
                else:
                    self.logger.info(f"{self.interface.name}: Disable stream logging")
                    self.interface.stop_raw_logging()
                return "SUCCESS"
            if msg_hash.get(b"interface_cmd"):
                params = json.loads(msg_hash[b"interface_cmd"])
                try:
                    str_params = " ".join([str(i) for i in params["cmd_params"]])
                    self.logger.info(f"{self.interface.name}: interface_cmd: {params['cmd_name']} {str_params}")
                    self.interface.interface_cmd(params["cmd_name"], *params["cmd_params"])
                    InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
                except Exception as e:
                    self.logger.error(f"{self.interface.name}: interface_cmd: {traceback.format_exc()}")
                    # Return only the error message (not full traceback) to match Ruby behavior
                    return str(e)
                return "SUCCESS"
            if msg_hash.get(b"protocol_cmd"):
                params = json.loads(msg_hash[b"protocol_cmd"])
                try:
                    str_params = " ".join([str(i) for i in params["cmd_params"]])
                    self.logger.info(
                        f"{self.interface.name}: protocol_cmd: {params['cmd_name']} {str_params} read_write: {params['read_write']} index: {params['index']}"
                    )
                    self.interface.protocol_cmd(
                        params["cmd_name"],
                        *params["cmd_params"],
                        read_write=params["read_write"],
                        index=params["index"],
                    )
                    InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
                except Exception as e:
                    self.logger.error(f"{self.interface.name}: protocol_cmd:{traceback.format_exc()}")
                    # Return only the error message (not full traceback) to match Ruby behavior
                    return str(e)
                return "SUCCESS"
            if msg_hash.get(b"inject_tlm"):
                try:
                    handle_inject_tlm(msg_hash[b"inject_tlm"], self.scope)
                except Exception as e:
                    self.logger.error(f"{self.interface.name}: inject_tlm:{traceback.format_exc()}")
                    return str(e)
                return "SUCCESS"
            if msg_hash.get(b"release_critical"):
                # Note: intentional fall through below this point
                critical_model = CriticalCmdModel.get_model(
                    name=msg_hash[b"release_critical"].decode(), scope=self.scope
                )
                if critical_model is not None:
                    msg_hash = critical_model.cmd_hash
                    release_critical = True
                else:
                    return f"Critical command {msg_hash[b'release_critical'].decode()} not found"
            if msg_hash.get(b"target_control"):
                try:
                    params = json.loads(msg_hash[b"target_control"])
                    target_name = params["target_name"]
                    cmd_only = params["cmd_only"]
                    tlm_only = params["tlm_only"]
                    action = params["action"]
                    if action == "disable":
                        if not tlm_only:
                            self.interface.cmd_target_enabled[target_name] = False
                        if not cmd_only:
                            self.interface.tlm_target_enabled[target_name] = False
                        self.logger.info(
                            f"{self.interface.name}: target_disable: {target_name} cmd_only:{cmd_only} tlm_only:{tlm_only}"
                        )
                    else:  # enable
                        if not tlm_only:
                            self.interface.cmd_target_enabled[target_name] = True
                        if not cmd_only:
                            self.interface.tlm_target_enabled[target_name] = True
                        self.logger.info(
                            f"{self.interface.name}: target_enable: {target_name} cmd_only:{cmd_only} tlm_only:{tlm_only}"
                        )
                except Exception as e:
                    self.logger.error(
                        f"{self.interface.name}: target_control: {''.join(traceback.format_exception(e))}"
                    )
                    return str(e)
                return "SUCCESS"
            if msg_hash.get(b"interface_details"):
                return json.dumps(self.interface.details(), cls=JsonEncoder)

        target_name = msg_hash[b"target_name"].decode()
        if target_name and not self.interface.cmd_target_enabled.get(target_name, False):
            return None  # Return and don't ack given target_name if disabled
        cmd_name = msg_hash[b"cmd_name"].decode()
        manual = ConfigParser.handle_true_false(msg_hash.get(b"manual", b"FALSE").decode())
        cmd_params = None
        range_check = True
        raw = False
        cmd_buffer = None
        hazardous_check = None
        if msg_hash.get(b"cmd_params") is not None:
            cmd_params = json.loads(msg_hash.get(b"cmd_params"), cls=JsonDecoder)
            range_check = ConfigParser.handle_true_false(msg_hash.get(b"range_check", b"TRUE").decode())
            raw = ConfigParser.handle_true_false(msg_hash.get(b"raw", b"FALSE").decode())
            hazardous_check = ConfigParser.handle_true_false(msg_hash.get(b"hazardous_check", b"TRUE").decode())
        elif msg_hash.get(b"cmd_buffer") is not None:
            cmd_buffer = msg_hash.get(b"cmd_buffer")

        try:
            try:
                if cmd_params is not None:
                    command = System.commands.build_cmd(target_name, cmd_name, cmd_params, range_check, raw)
                elif cmd_buffer is not None:
                    if target_name:
                        command = System.commands.identify(cmd_buffer, [target_name])
                    else:
                        command = System.commands.identify(cmd_buffer, self.interface.cmd_target_names)
                    if not command:
                        command = System.commands.packet("UNKNOWN", "UNKNOWN").clone()
                        command.buffer = cmd_buffer
                else:
                    raise RuntimeError(f"Invalid command received:\n{msg_hash}")

                if not self.interface.cmd_target_enabled.get(command.target_name, False):
                    return None  # Don't ack disabled targets

                orig_command = System.commands.packet(command.target_name, command.packet_name)
                orig_command.received_count = TargetModel.increment_command_count(
                    command.target_name, command.packet_name, 1, scope=self.scope
                )
                command.received_count = orig_command.received_count
                command.received_time = datetime.now(timezone.utc)
            except Exception as e:
                self.logger.error(f"{self.interface.name}: {msg_hash}")
                self.logger.error(f"{self.interface.name}: {traceback.format_exc()}")
                # Return only the error message (not full traceback) to match Ruby behavior
                # This provides a clean error message to the GUI while still logging the full trace
                return str(e)

            command.extra = command.extra or {}
            command.extra["cmd_string"] = msg_hash.get(b"cmd_string", b"").decode()
            command.extra["username"] = msg_hash.get(b"username", b"").decode()
            # Add approver info if this was a critical command that was approved
            if critical_model is not None:
                command.extra["approver"] = critical_model.approver
            hazardous, hazardous_description = System.commands.cmd_pkt_hazardous(command)

            # Return back the error, description, and the formatted command
            # This allows the error handler to simply re-send the command
            if hazardous_check and hazardous and not release_critical:
                return f"HazardousError\n{hazardous_description}\n{command.extra['cmd_string']}"

            if self.critical_commanding is not None and self.critical_commanding != "OFF" and not release_critical:
                restricted = command.restricted
                if hazardous or restricted or (self.critical_commanding == "ALL" and manual):
                    cmd_type = "NORMAL"
                    if hazardous:
                        cmd_type = "HAZARDOUS"
                    elif restricted:
                        cmd_type = "RESTRICTED"
                    model = CriticalCmdModel(
                        name=str(uuid.uuid1()),
                        cmd_type=cmd_type,
                        interface_name=self.interface.name,
                        username=msg_hash.get(b"username", b"").decode(),
                        cmd_hash=msg_hash,
                        scope=self.scope,
                    )
                    model.create()
                    self.logger.info(
                        f"Critical Cmd Pending: {msg_hash.get(b'cmd_string', b'').decode()}",
                        user=msg_hash.get(b"username", b"").decode(),
                        scope=self.scope,
                    )
                    return f"CriticalCmdError\n{model.name}"

            validate = ConfigParser.handle_true_false(msg_hash.get(b"validate", b"TRUE").decode())
            try:
                if self.interface.connected():
                    result = True
                    reason = None
                    if command.validator and validate:
                        try:
                            result, reason = command.validator.pre_check(command)
                        except Exception:
                            result = False
                            reason = traceback.format_exc()
                        if not result:
                            message = f"pre_check returned false for {command.extra['cmd_string']} due to {reason}"
                            raise WriteRejectError(message)

                    self.count += 1
                    if self.metric is not None:
                        self.metric.set(name="interface_cmd_total", value=self.count, type="counter")

                    log_message = ConfigParser.handle_true_false(msg_hash.get(b"log_message", b"TRUE").decode())
                    if log_message:
                        self.logger.info(
                            msg_hash.get(b"cmd_string", b"").decode(),
                            user=msg_hash.get(b"username", b"").decode(),
                            scope=self.scope,
                        )

                    self.interface.write(command)

                    command.obfuscate()

                    if command.validator and validate:
                        try:
                            result, reason = command.validator.post_check(command)
                        except Exception:
                            result = False
                            reason = traceback.format_exc()
                        command.extra["cmd_success"] = result
                        if reason:
                            command.extra["cmd_reason"] = reason

                    CommandDecomTopic.write_packet(command, scope=self.scope)
                    CommandTopic.write_packet(command, scope=self.scope)
                    InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)

                    if not result:
                        message = f"post_check returned false for {command.extra['cmd_string']} due to {reason}"
                        raise WriteRejectError(message)

                    return "SUCCESS"
                else:
                    return f"Interface not connected: {self.interface.name}"
            except WriteRejectError as e:
                # Return only the error message (not full traceback) to match Ruby behavior
                return str(e)
        except Exception as e:
            self.logger.error(f"{self.interface.name}: {traceback.format_exc()}")
            # Return only the error message (not full traceback) to match Ruby behavior
            return str(e)


class RouterTlmHandlerThread:
    def __init__(self, router, tlm, logger=None, metric=None, db_shard=0, scope=None):
        self.router = router
        self.tlm = tlm
        self.scope = scope
        self.db_shard = int(db_shard or 0)
        self.logger = logger
        if not self.logger:
            self.logger = Logger
        self.metric = metric
        self.count = 0
        self.directive_count = 0
        if self.metric is not None:
            self.metric.set(
                name="router_directive_total",
                value=self.directive_count,
                type="counter",
            )
        if self.metric is not None:
            self.metric.set(name="router_tlm_total", value=self.count, type="counter")

    def start(self):
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()
        ThreadManager.instance().register(self.thread, stop_object=self)
        return self.thread

    def stop(self):
        kill_thread(self, self.thread)

    def graceful_kill(self):
        RouterTopic.shutdown(self.router, scope=self.scope)
        time.sleep(0.001)  # Allow other threads to run

    def run(self):
        generator = RouterTopic.receive_telemetry(self.router, scope=self.scope, db_shard=self.db_shard)
        topic, msg_id, msg_hash, _redis = next(generator)
        result = None

        while True:
            msgid_seconds_from_epoch = int(msg_id.split("-")[0]) / 1000.0
            delta = time.time() - msgid_seconds_from_epoch
            if self.metric is not None:
                self.metric.set(
                    name="router_topic_delta_seconds",
                    value=delta,
                    type="gauge",
                    unit="seconds",
                    help="Delta time between data written to stream and router tlm start",
                )

            result = None  # Reset result for this iteration

            # Check for commands to the router itself
            if "CMD}ROUTER" in topic:
                self.directive_count += 1
                if self.metric is not None:
                    self.metric.set(
                        name="router_directive_total",
                        value=self.directive_count,
                        type="counter",
                    )

                if msg_hash.get(b"shutdown"):
                    self.logger.info(f"{self.router.name}: Shutdown requested")
                    RouterTopic.clear_topics(RouterTopic.topics(self.router, scope=self.scope), db_shard=self.db_shard)
                    result = "SHUTDOWN"
                elif msg_hash.get(b"connect"):
                    self.logger.info(f"{self.router.name}: Connect requested")
                    params = []
                    if msg_hash.get(b"params"):
                        params = json.loads(msg_hash[b"params"])
                    self.router = self.tlm.attempting(*params)
                    result = "SUCCESS"
                elif msg_hash.get(b"disconnect"):
                    self.logger.info(f"{self.router.name}: Disconnect requested")
                    try:
                        self.tlm.disconnect(False)
                        result = "SUCCESS"
                    except Exception as e:
                        self.logger.error(f"{self.router.name}: disconnect: {traceback.format_exc()}")
                        result = str(e)
                elif msg_hash.get(b"log_stream"):
                    if msg_hash[b"log_stream"].decode() == "true":
                        self.logger.info(f"{self.router.name}: Enable stream logging")
                        self.router.start_raw_logging()
                    else:
                        self.logger.info(f"{self.router.name}: Disable stream logging")
                        self.router.stop_raw_logging()
                    result = "SUCCESS"
                elif msg_hash.get(b"router_cmd"):
                    params = json.loads(msg_hash[b"router_cmd"])
                    try:
                        self.logger.info(
                            f"{self.router.name}: router_cmd: {params['cmd_name']} {' '.join(params['cmd_params'])}"
                        )
                        self.router.interface_cmd(params["cmd_name"], *params["cmd_params"])
                        result = "SUCCESS"
                    except Exception as error:
                        self.logger.error(f"{self.router.name}: router_cmd: {traceback.format_exc()}")
                        result = str(error)
                elif msg_hash.get(b"protocol_cmd"):
                    params = json.loads(msg_hash[b"protocol_cmd"])
                    try:
                        self.logger.info(
                            f"{self.router.name}: protocol_cmd: {params['cmd_name']} {' '.join(params['cmd_params'])} read_write: {params['read_write']} index: {params['index']}"
                        )
                        self.router.protocol_cmd(
                            params["cmd_name"],
                            *params["cmd_params"],
                            read_write=params["read_write"],
                            index=params["index"],
                        )
                        result = "SUCCESS"
                    except Exception as error:
                        self.logger.error(f"{self.router.name}: protocol_cmd: {traceback.format_exc()}")
                        result = str(error)
                elif msg_hash.get(b"target_control"):
                    try:
                        params = json.loads(msg_hash[b"target_control"])
                        target_name = params["target_name"]
                        cmd_only = params["cmd_only"]
                        tlm_only = params["tlm_only"]
                        action = params["action"]
                        if action == "disable":
                            if not tlm_only:
                                self.router.cmd_target_enabled[target_name] = False
                            if not cmd_only:
                                self.router.tlm_target_enabled[target_name] = False
                            self.logger.info(
                                f"{self.router.name}: target_disable: {target_name} cmd_only:{cmd_only} tlm_only:{tlm_only}"
                            )
                        else:  # enable
                            if not tlm_only:
                                self.router.cmd_target_enabled[target_name] = True
                            if not cmd_only:
                                self.router.tlm_target_enabled[target_name] = True
                            self.logger.info(
                                f"{self.router.name}: target_enable: {target_name} cmd_only:{cmd_only} tlm_only:{tlm_only}"
                            )
                        result = "SUCCESS"
                    except Exception as e:
                        self.logger.error(
                            f"{self.router.name}: target_control: {''.join(traceback.format_exception(e))}"
                        )
                        result = str(e)
                elif msg_hash.get(b"router_details"):
                    result = json.dumps(self.router.details(), cls=JsonEncoder)
                else:
                    result = "SUCCESS"

            else:  # Not a router command, process telemetry
                if self.router.connected():
                    self.count += 1
                    if self.metric is not None:
                        self.metric.set(name="router_tlm_total", value=self.count, type="counter")

                    target_name = msg_hash[b"target_name"].decode()
                    packet_name = msg_hash[b"packet_name"].decode()

                    if self.router.tlm_target_enabled.get(target_name, False):
                        packet = System.telemetry.packet(target_name, packet_name)
                        packet.stored = ConfigParser.handle_true_false(msg_hash.get(b"stored", b"FALSE").decode())
                        packet.received_time = from_nsec_from_epoch(int(msg_hash.get(b"time", b"0")))
                        packet.received_count = int(msg_hash.get(b"received_count", b"0"))
                        packet.buffer = msg_hash.get(b"buffer", b"")

                        try:
                            self.router.write(packet)
                            RouterStatusModel.set(self.router.as_json(), queued=True, scope=self.scope)
                            result = "SUCCESS"
                        except Exception:
                            self.logger.error(f"{self.router.name}: {traceback.format_exc()}")
                            result = traceback.format_exc()
                    else:
                        result = None

            # Send result back to generator and get next message
            topic, msg_id, msg_hash, _redis = generator.send(result)

            # Exit loop if shutdown was requested
            if result == "SHUTDOWN":
                break


class InterfaceMicroservice(Microservice):
    UNKNOWN_BYTES_TO_PRINT = 16
    DISCONNECT_WAIT_TIME = 1

    def __init__(self, name):
        self.mutex = threading.Lock()
        self.interface = None
        self.interface_or_router = None
        self.interface_thread_sleeper = Sleeper()
        self.cancel_thread = False
        self.connection_failed_messages = []
        self.connection_lost_messages = []
        self.handler_thread = None

        super().__init__(name)
        self.interface_or_router = self.__class__.__name__.split("Microservice")[0].upper()
        if self.interface_or_router == "INTERFACE":
            self.metric.set(name="interface_tlm_total", value=self.count, type="counter")
        else:
            self.metric.set(name="router_cmd_total", value=self.count, type="counter")

        self.scope = name.split("__")[0]
        interface_name = name.split("__")[2]
        if self.interface_or_router == "INTERFACE":
            self.interface = InterfaceModel.get_model(name=interface_name, scope=self.scope).build()
        else:
            self.interface = RouterModel.get_model(name=interface_name, scope=self.scope).build()
        self.interface.name = interface_name
        # Map the interface to the interface's targets
        for target_name in self.interface.target_names:
            target = System.targets[target_name]
            target.interface = self.interface
        TargetModel.init_tlm_packet_counts(self.interface.tlm_target_names, scope=self.scope)
        if self.interface.connect_on_startup:
            self.interface.state = "ATTEMPTING"
        else:
            self.interface.state = "DISCONNECTED"
        if self.interface_or_router == "INTERFACE":
            InterfaceStatusModel.set(self.interface.as_json(), scope=self.scope)
        else:
            RouterStatusModel.set(self.interface.as_json(), scope=self.scope)

        self.queued = False
        for option_name, option_values in self.interface.options.items():
            # OPTIMIZE_THROUGHPUT was changed to UPDATE_INTERVAL to better represent the setting
            if option_name.upper() == "UPDATE_INTERVAL" or option_name.upper() == "OPTIMIZE_THROUGHPUT":
                self.queued = True
                update_interval = float(option_values[0])
                EphemeralStoreQueued.instance().set_update_interval(update_interval)
                StoreQueued.instance().set_update_interval(update_interval)
            if option_name.upper() == "SYNC_PACKET_COUNT_DELAY_SECONDS":
                TargetModel.sync_packet_count_delay_seconds = float(option_values[0])

        if self.interface_or_router == "INTERFACE":
            self.handler_thread = InterfaceCmdHandlerThread(
                self.interface,
                self,
                logger=self.logger,
                metric=self.metric,
                db_shard=self.db_shard,
                scope=self.scope,
            )
        else:
            self.handler_thread = RouterTlmHandlerThread(
                self.interface,
                self,
                logger=self.logger,
                metric=self.metric,
                db_shard=self.db_shard,
                scope=self.scope,
            )
        self.handler_thread.start()

    # Called to connect the interface/router. It takes optional parameters to
    # rebuilt the interface/router. Once we set the state to 'ATTEMPTING' the
    # run method handles the actual connection.
    def attempting(self, *params):
        try:
            if len(params) != 0:
                self.interface.disconnect()
                # Build New Interface, this can fail if passed bad parameters
                new_interface = self.interface.__class__(*params)
                self.interface.copy_to(new_interface)

                # Replace interface for targets
                for target_name in self.interface.target_names:
                    target = System.targets[target_name]
                    target.interface = new_interface
                self.interface = new_interface

                # Update the model
                if self.interface_or_router == "INTERFACE":
                    interface_model = InterfaceModel.get(name=self.interface.name, scope=self.scope)
                    # config_params[0] is the filename so set the rest
                    interface_model["config_params"][1:] = list(params)
                    InterfaceModel.set(interface_model, scope=self.scope)
                else:
                    router_model = RouterModel.get(name=self.interface.name, scope=self.scope)
                    # config_params[0] is the filename so set the rest
                    interface_model["config_params"][1:] = list(params)
                    RouterModel.set(router_model, scope=self.scope)

            self.interface.state = "ATTEMPTING"
            if self.interface_or_router == "INTERFACE":
                InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
            else:
                RouterStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
            return self.interface  # Return the interface/router since we may have recreated it
        # Need to rescue Exception so we cover LoadError
        except RuntimeError:
            self.logger.error(
                f"Attempting connection #{self.interface.connection_string} failed due to {traceback.format_exc()}"
            )
            # if SignalException === error:
            #   self.logger.info(f"{self.interface.name}: Closing from signal")
            #   self.cancel_thread = True
            return self.interface  # Return the original interface/router in match of error:

    def run(self):
        try:
            if self.interface.read_allowed:
                self.logger.info(f"{self.interface.name}: Starting packet reading")
            else:
                self.logger.info(f"{self.interface.name}: Starting connection maintenance")
            while True:
                if self.cancel_thread:
                    break

                match self.interface.state:
                    case "DISCONNECTED":
                        # Just wait to see if we should connect later
                        self.interface_thread_sleeper.sleep(InterfaceMicroservice.DISCONNECT_WAIT_TIME)
                    case "ATTEMPTING":
                        try:
                            with self.mutex:
                                # We need to make sure connect is not called after stop() has been called
                                if not self.cancel_thread:
                                    self.connect()
                        except Exception as error:
                            self.handle_connection_failed(self.interface.connection_string(), error)
                            if self.cancel_thread:
                                break
                    case "CONNECTED":
                        if self.interface.read_allowed:
                            try:
                                packet = self.interface.read()
                                if packet is not None:
                                    self.handle_packet(packet)
                                    self.count += 1
                                    if self.interface_or_router == "INTERFACE":
                                        self.metric.set(
                                            name="interface_tlm_total",
                                            value=self.count,
                                            type="counter",
                                        )
                                    else:
                                        self.metric.set(
                                            name="router_cmd_total",
                                            value=self.count,
                                            type="counter",
                                        )
                                else:
                                    self.logger.info(
                                        f"{self.interface.name}: Internal disconnect requested (returned None)"
                                    )
                                    self.handle_connection_lost()
                                    if self.cancel_thread:
                                        break
                            except Exception as error:
                                self.handle_connection_lost(error)
                                if self.cancel_thread:
                                    break
                        else:
                            self.interface_thread_sleeper.sleep(1)
                            if not self.interface.connected():
                                self.handle_connection_lost()
        except Exception as error:
            if not isinstance(error, SystemExit):  # or signal exception
                self.logger.error(f"{self.interface.name}: Packet reading thread died: {traceback.format_exc()}")
                # handle_fatal_exception(error)
            # Try to do clean disconnect because we're going down
            self.disconnect(False)
        if self.interface_or_router == "INTERFACE":
            InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
        else:
            RouterStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
        self.logger.info(f"{self.interface.name}: Stopped packet reading")

    def handle_packet(self, packet):
        InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
        if packet.received_time is None:
            packet.received_time = datetime.now(timezone.utc)

        if packet.stored:
            # Stored telemetry does not update the current value table
            identified_packet = System.telemetry.identify_and_define_packet(packet, self.interface.tlm_target_names)
        else:
            # Identify and update packet
            if packet.identified():
                try:
                    # Preidentifed packet - place it into the current value table
                    identified_packet = System.telemetry.update(packet.target_name, packet.packet_name, packet.buffer)
                except Exception:
                    # Packet identified but we don't know about it
                    # Clear packet_name and target_name and try to identify
                    self.logger.warn(
                        f"{self.interface.name}: Received unknown identified telemetry: {packet.target_name} {packet.packet_name}"
                    )
                    packet.target_name = None
                    packet.packet_name = None
                    identified_packet = System.telemetry.identify_and_set_buffer(
                        packet.buffer, self.interface.tlm_target_names
                    )
            else:
                # Packet needs to be identified
                identified_packet = System.telemetry.identify_and_set_buffer(
                    packet.buffer, self.interface.tlm_target_names
                )

        if identified_packet:
            identified_packet.received_time = packet.received_time
            identified_packet.stored = packet.stored
            identified_packet.extra = packet.extra
            packet = identified_packet
        else:
            unknown_packet = System.telemetry.update("UNKNOWN", "UNKNOWN", packet.buffer)
            unknown_packet.received_time = packet.received_time
            unknown_packet.stored = packet.stored
            unknown_packet.extra = packet.extra
            packet = unknown_packet
            json_hash = CvtModel.build_json_from_packet(packet)
            CvtModel.set(
                json_hash,
                packet.target_name,
                packet.packet_name,
                queued=self.queued,
                scope=self.scope,
            )
            num_bytes_to_print = min(InterfaceMicroservice.UNKNOWN_BYTES_TO_PRINT, len(packet.buffer))
            data = packet.buffer_no_copy()[0:(num_bytes_to_print)]
            prefix = "".join([format(x, "02x") for x in data])
            self.logger.warn(
                f"{self.interface.name} {packet.target_name} packet length: {len(packet.buffer)} starting with: {prefix}"
            )

        # Write to stream
        if self.interface.tlm_target_enabled.get(packet.target_name, False):
            TargetModel.sync_tlm_packet_counts(packet, self.interface.tlm_target_names, scope=self.scope)
            TelemetryTopic.write_packet(packet, queued=self.queued, scope=self.scope)

    def handle_connection_failed(self, connection, connect_error):
        self.error = connect_error
        self.logger.error(f"{self.interface.name}: Connection {connection} failed due to {repr(connect_error)}")
        # match connect_error:
        #   case OSError:
        #     self.logger.info(f"{self.interface.name}: Closing from signal")
        #     self.cancel_thread = True
        # case Errno='ECONNREFUSED', Errno='ECONNRESET', Errno='ETIMEDOUT', Errno='ENOTSOCK', Errno='EHOSTUNREACH', IOError:
        #   # Do not write an exception file for these extremely common cases
        # else _:
        if connect_error is Exception and ("canceled" in connect_error.message or "timeout" in repr(connect_error)):
            pass  # Do not write an exception file for these extremely common cases
        else:
            self.logger.error(f"{self.interface.name}: {''.join(traceback.format_exception(connect_error))}")
            if str(connect_error) not in self.connection_failed_messages:
                self.connection_failed_messages.append(str(connect_error))
        self.disconnect()  # Ensure we do a clean disconnect

    def handle_connection_lost(self, error=None, reconnect=True):
        if error:
            self.error = error
            self.logger.info(f"{self.interface.name}: Connection Lost: {repr(error)}")
            # match err:
            #   case SignalException:
            #     self.logger.info(f"{self.interface.name}: Closing from signal")
            #     self.cancel_thread = True
            #   # case Errno='ECONNABORTED', Errno='ECONNRESET', Errno='ETIMEDOUT', Errno='EBADF', Errno='ENOTSOCK', IOError:
            #     # Do not write an exception file for these extremely common cases
            #   else _:
            self.logger.error(f"{self.interface.name}: {''.join(traceback.format_exception(error))}")
            if str(error) not in self.connection_lost_messages:
                self.connection_lost_messages.append(str(error))
        else:
            self.logger.info(f"{self.interface.name}: Connection Lost")
        self.disconnect(reconnect)  # Ensure we do a clean disconnect

    def connect(self):
        self.logger.info(f"{self.interface.name}: Connect {self.interface.connection_string()}")

        try:
            self.interface.connect()
            self.interface.post_connect()
        except Exception as error:
            with contextlib.suppress(Exception):
                # We want to report any connect errors, not disconnect in this case
                self.interface.disconnect()  # Ensure disconnect is called at least once on a partial connect
            raise error from error

        self.interface.state = "CONNECTED"
        if self.interface_or_router == "INTERFACE":
            InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
        else:
            RouterStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
        self.logger.info(f"{self.interface.name}: Connection Success")

    def disconnect(self, allow_reconnect=True):
        if self.interface.state == "DISCONNECTED" and self.interface.connected() is False:
            return

        # Synchronize the calls to @interface.disconnect since it takes an unknown
        # amount of time. If two calls to disconnect stack up, the if statement
        # should avoid multiple calls to disconnect.
        with self.mutex:
            try:
                if self.interface.connected():
                    self.interface.disconnect()
            except Exception:
                self.logger.error(f"Disconnect: {self.interface.name}: {traceback.format_exc()}")

        # If the interface is set to auto_reconnect then delay so the thread
        # can come back around and allow the interface a chance to reconnect.
        if allow_reconnect and self.interface.auto_reconnect and self.interface.state != "DISCONNECTED":
            self.attempting()
            if self.cancel_thread is not None:
                self.interface_thread_sleeper.sleep(self.interface.reconnect_delay)
        else:
            self.interface.state = "DISCONNECTED"
            if self.interface_or_router == "INTERFACE":
                InterfaceStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)
            else:
                RouterStatusModel.set(self.interface.as_json(), queued=True, scope=self.scope)

    # Disconnect from the interface and stop the thread
    def stop(self):
        name = self.name
        if self.interface:
            name = self.interface.name
        self.logger.info(f"{name}: stop requested")
        with self.mutex:
            # Need to make sure that @cancel_thread is set and the interface disconnected within
            # mutex to ensure that connect() is not called when we want to stop()
            self.cancel_thread = True
            if self.handler_thread:
                self.handler_thread.stop()
            if self.interface_thread_sleeper:
                self.interface_thread_sleeper.cancel()
            if self.interface:
                self.interface.disconnect()
                if self.interface_or_router == "INTERFACE":
                    valid_interface = InterfaceStatusModel.get_model(name=self.interface.name, scope=self.scope)
                else:
                    valid_interface = RouterStatusModel.get_model(name=self.interface.name, scope=self.scope)
                if valid_interface:
                    valid_interface.destroy()

    def shutdown(self, sig=None):
        if self.shutdown_complete:
            return  # Nothing more to do
        name = self.name
        if self.interface:
            name = self.interface.name
        self.logger.info(f"{name}: shutdown requested")
        self.stop()
        if self.interface is not None and self.interface.stream_log_pair is not None:
            # In python shutdown does the join and cleanup
            self.interface.stream_log_pair.shutdown()
        super().shutdown()

    def graceful_kill(self):
        pass  # Just to avoid warning


if os.path.basename(__file__) == os.path.basename(sys.argv[0]):
    InterfaceMicroservice.class_run()
    ThreadManager.instance().shutdown()
    ThreadManager.instance().join()
