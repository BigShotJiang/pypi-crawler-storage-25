# Copyright 2026 OpenC3, Inc.
# All Rights Reserved.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE.md for more details.
#
# This file may also be used under the terms of a commercial license
# if purchased from OpenC3, Inc.

import threading
from contextlib import contextmanager

import valkey
from valkey.exceptions import TimeoutError

from openc3.environment import *
from openc3.utilities.connection_pool import ConnectionPool


class StoreConnectionPool(ConnectionPool):
    @contextmanager
    def pipelined(self):
        with self.get() as redis:
            pipeline = redis.pipeline(transaction=False)
            thread_id = threading.get_native_id()
            self.pipelines[thread_id] = pipeline
            try:
                yield
            finally:
                pipeline.execute()
                self.pipelines[thread_id] = None

    @contextmanager
    def get(self):
        thread_id = threading.get_native_id()
        if thread_id not in self.pipelines:
            self.pipelines[thread_id] = None
        pipeline = self.pipelines[thread_id]
        if pipeline:
            yield pipeline
        else:
            item = None
            with self.lock:
                if not self.pool.empty():
                    item = self.pool.get(False)
                elif self.count < self.pool_size:
                    item = self.ctor()
                    self.count += 1
                else:
                    item = self.pool.get()
            try:
                yield item
            finally:
                self.pool.put(item)


class StoreMeta(type):
    # Class attributes that should not be delegated to the instance
    _CLASS_ATTRS = frozenset(
        {
            "instance",
            "instance_mutex",
            "my_instances",
            "db_shard_for_target",
            "_db_shard_cache",
            "_db_shard_cache_lock",
            "DB_SHARD_CACHE_TIMEOUT",
        }
    )

    def __getattribute__(cls, func):
        if func in StoreMeta._CLASS_ATTRS:
            return super().__getattribute__(func)

        # Handle dunder methods to support help() and other introspection
        if func.startswith("__") and func.endswith("__"):
            return super().__getattribute__(func)

        def method(*args, **kw_args):
            return getattr(cls.instance(), func)(*args, **kw_args)

        return method


class Store(metaclass=StoreMeta):
    # Variable that holds the singleton instances per db_shard
    my_instances = {}

    # Mutex used to ensure that only one instance is created
    instance_mutex = threading.Lock()

    # DB_Shard cache
    _db_shard_cache = {}
    _db_shard_cache_lock = threading.Lock()
    DB_SHARD_CACHE_TIMEOUT = 60  # seconds

    # Get the singleton instance for a given db_shard
    @classmethod
    def instance(cls, pool_size=100, db_shard=0):
        inst = cls.my_instances.get(db_shard)
        if inst:
            return inst

        with cls.instance_mutex:
            if db_shard not in cls.my_instances:
                cls.my_instances[db_shard] = cls(pool_size, db_shard=db_shard)
            return cls.my_instances[db_shard]

    @classmethod
    def db_shard_for_target(cls, target_name, scope="DEFAULT"):
        """Look up the db_shard number for a target with a 1-minute cache."""
        import json
        import time as _time

        if not target_name:
            return 0

        cache_key = f"{scope}__{target_name}"
        now = _time.time()

        with cls._db_shard_cache_lock:
            cached = cls._db_shard_cache.get(cache_key)
            if cached:
                db_shard_val, cached_at = cached
                if (now - cached_at) < cls.DB_SHARD_CACHE_TIMEOUT:
                    return db_shard_val

        try:
            result = Store.instance(db_shard=0).hget(f"{scope}__openc3_targets", target_name)
            if result:
                if isinstance(result, bytes):
                    result = result.decode()
                db_shard_val = json.loads(result).get("db_shard", 0)
                db_shard_val = int(db_shard_val) if db_shard_val else 0
            else:
                db_shard_val = 0
        except Exception:
            db_shard_val = 0

        with cls._db_shard_cache_lock:
            cls._db_shard_cache[cache_key] = (db_shard_val, now)

        return db_shard_val

    # Delegate all unknown methods to redis through the @redis_pool
    def __getattr__(self, func):
        with self.redis_pool.get() as redis:

            def method(*args, **kwargs):
                return getattr(redis, func)(*args, **kwargs)

            return method

    def __init__(self, pool_size=10, db_shard=0):
        self.db_shard = db_shard
        self.redis_host = OPENC3_REDIS_HOSTNAME.replace("SHARDNUM", str(db_shard))
        self.redis_port = OPENC3_REDIS_PORT
        self.redis_pool = StoreConnectionPool(self.build_redis, pool_size)
        self.topic_offsets = {}
        self.pipelines = {}

    def build_redis(self):
        # NOTE: We can't use decode_response because it tries to decode the binary
        # packet buffer which does not work. Thus strings come back as bytes like
        # b"target_name" and we decode them using b"target_name".decode()
        return valkey.Valkey(
            host=self.redis_host,
            port=self.redis_port,
            username=OPENC3_REDIS_USERNAME,
            password=OPENC3_REDIS_PASSWORD,
        )

    ###########################################################################
    # Stream APIs
    ###########################################################################

    def get_oldest_message(self, topic):
        with self.redis_pool.get() as redis:
            result = redis.xrange(topic, count=1)
            if result and len(result) > 0:
                return result[0]
            else:
                return None

    def get_newest_message(self, topic):
        with self.redis_pool.get() as redis:
            # Default in xrevrange is range end '+', start '-' which means get all
            # elements from higher ID to lower ID and since we're limiting to 1
            # we get the last element. See https://redis.io/commands/xrevrange.
            result = redis.xrevrange(topic, count=1)
            if result and len(result) > 0:
                first = list(result[0])
                first[0] = first[0].decode()
                return first
            else:
                return (None, None)

    def get_last_offset(self, topic):
        with self.redis_pool.get() as redis:
            result = redis.xrevrange(topic, count=1)
            if result and result[0] and result[0][0]:
                return result[0][0].decode()
            else:
                return "0-0"

    def update_topic_offsets(self, topics):
        offsets = []
        for topic in topics:
            # Normally we will just be grabbing the topic offset
            # this allows xread to get everything past this point
            thread_id = threading.get_native_id()
            if thread_id not in self.topic_offsets:
                self.topic_offsets[thread_id] = {}
            topic_offsets = self.topic_offsets[thread_id]
            last_id = topic_offsets.get(topic)
            if last_id:
                offsets.append(last_id)
            else:
                # If there is no topic offset this is the first call.
                # Get the last offset ID so we'll start getting everything from now on
                offsets.append(self.get_last_offset(topic))
                topic_offsets[topic] = offsets[-1]
        return offsets

    def read_topics(self, topics, offsets=None, timeout_ms=1000, count=None):
        if len(topics) == 0:
            return {}
        thread_id = threading.get_native_id()
        if thread_id not in self.topic_offsets:
            self.topic_offsets[thread_id] = {}
        topic_offsets = self.topic_offsets[thread_id]
        try:
            with self.redis_pool.get() as redis:
                if not offsets:
                    offsets = self.update_topic_offsets(topics)
                streams = {}
                for index, topic in enumerate(topics):
                    streams[topic] = offsets[index]
                result = redis.xread(streams, block=timeout_ms, count=count)
                if result and len(result) > 0:
                    for topic, messages in result:
                        for msg_id, msg_hash in messages:
                            if isinstance(topic, bytes):
                                topic = topic.decode()
                            if isinstance(msg_id, bytes):
                                msg_id = msg_id.decode()
                            topic_offsets[topic] = msg_id
                            yield topic, msg_id, msg_hash, redis
                return result
        except TimeoutError:
            # Should return an empty hash not array - xread returns a hash
            return {}

    # Add new entry to the redis stream.
    # > https://www.rubydoc.info/github/redis/redis-rb/Redis:xadd
    #
    # @example Without options
    #   store.write_topic('MANGO__TOPIC', {'message' => 'something'})
    # @example With options
    #   store.write_topic('MANGO__TOPIC', {'message' => 'something'}, id: '0-0', maxlen: 1000, approximate: 'true')
    #
    # @param topic [String] the stream / topic
    # @param msg_hash [Hash]   one or multiple field-value pairs
    #
    # @option opts [String]  :id          the entry id, default value is `*`, it means auto generation,
    #   if `nil` id is passed it will be changed to `*`
    # @option opts [Integer] :maxlen      max length of entries, default value is `nil`, it means will grow forever
    # @option opts [String] :approximate whether to add `~` modifier of maxlen or not, default value is 'true'
    #
    # @return [String] the entry id
    def write_topic(self, topic, msg_hash, id="*", maxlen=None, approximate=True):
        if not id:
            id = "*"
        with self.redis_pool.get() as redis:
            return redis.xadd(topic, msg_hash, id=id, maxlen=maxlen, approximate=approximate)

    # Trims older entries of the redis stream if needed.
    # > https://www.rubydoc.info/github/redis/redis-rb/Redis:xtrim
    #
    # @example Without options
    #   store.trim_topic('MANGO__TOPIC', 1000)
    # @example With options
    #   store.trim_topic('MANGO__TOPIC', 1000, approximate: 'true', limit: 0)
    #
    # @param topic  [String]  the stream key
    # @param minid  [Integer] Id to throw away data up to
    # @param approximate [Boolean] whether to add `~` modifier of maxlen or not
    # @param limit  [Boolean] number of items to return from the call
    #
    # @return [Integer] the number of entries actually deleted
    def trim_topic(self, topic, minid, approximate=True, limit=0):
        with self.redis_pool.get() as redis:
            return redis.xtrim(name=topic, minid=minid, approximate=approximate, limit=limit)


class EphemeralStore(Store):
    # Variable that holds the singleton instances per db_shard
    my_instances = {}

    def __init__(self, pool_size=10, db_shard=0):
        super().__init__(pool_size, db_shard=db_shard)
        self.redis_host = OPENC3_REDIS_EPHEMERAL_HOSTNAME.replace("SHARDNUM", str(db_shard))
        self.redis_port = OPENC3_REDIS_EPHEMERAL_PORT
        self.redis_pool = StoreConnectionPool(self.build_redis, pool_size)
