# Copyright 2026 OpenC3, Inc.
# All Rights Reserved.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE.md for more details.
#
# This file may also be used under the terms of a commercial license
# if purchased from OpenC3, Inc.
#
# A portion of this file was funded by Blue Origin Enterprises, L.P.
# See https://github.com/OpenC3/cosmos/pull/1953 and https://github.com/OpenC3/cosmos/pull/1963

# A portion of this file was funded by Blue Origin Enterprises, L.P.
# See https://github.com/OpenC3/cosmos/pull/1957

import json
import threading
import time
from typing import Any

from openc3.environment import OPENC3_CONFIG_BUCKET, OPENC3_SCOPE
from openc3.models.microservice_model import MicroserviceModel
from openc3.models.model import Model
from openc3.system.system import System
from openc3.topics.topic import Topic
from openc3.utilities.bucket import Bucket
from openc3.utilities.json import JsonEncoder
from openc3.utilities.logger import Logger
from openc3.utilities.store import Store


# Manages the target in Redis. It stores the target itself under the
# <SCOPE>__openc3_targets key under the target name field. All the command packets
# in the target are stored under the <SCOPE>__openc3cmd__<TARGET NAME> key and the
# telemetry under the <SCOPE>__openc3tlm__<TARGET NAME> key. Any new limits sets
# are merged into the <SCOPE>__limits_sets key as fields. Any new limits groups are
# created under <SCOPE>__limits_groups with field name. These Redis key/fields are
# all removed when the undeploy method is called.
class TargetModel(Model):
    PRIMARY_KEY = "openc3_targets"
    VALID_TYPES = {"CMD", "TLM"}
    ITEM_MAP_CACHE_TIMEOUT = 10.0
    PACKET_CACHE_TIMEOUT = 10.0
    item_map_cache = {}
    packet_cache = {}
    packet_cache_lock = threading.Lock()
    sync_packet_count_data = {}
    sync_packet_count_time = None
    sync_packet_count_delay_seconds = 1.0  # Sync packet counts every second
    stale_packet_keys_warned = set()  # Track stale keys already warned about

    # Get a Store instance routed to the correct db_shard for a target
    @classmethod
    def _store_for_target(cls, target_name, scope):
        return Store.instance(db_shard=Store.db_shard_for_target(target_name, scope=scope))

    # NOTE: The following three class methods are used by the ModelController
    # and are reimplemented to enable various Model class methods to work
    @classmethod
    def get(cls, name: str, scope: str):
        return super().get(f"{scope}__{TargetModel.PRIMARY_KEY}", name)

    @classmethod
    def names(cls, scope: str):
        return super().names(f"{scope}__{TargetModel.PRIMARY_KEY}")

    @classmethod
    def all(cls, scope: str):
        return super().all(f"{scope}__{TargetModel.PRIMARY_KEY}")

    @classmethod
    def packet(
        cls,
        target_name: str,
        packet_name: str,
        type: str = "TLM",
        scope: str = OPENC3_SCOPE,
    ):
        """@return [Hash] Packet hash or raises an exception"""
        if type not in cls.VALID_TYPES:
            raise RuntimeError(f"Unknown type {type} for {target_name} {packet_name}")

        # Check cache first
        cache_key = f"{scope}__{type}__{target_name}__{packet_name}"
        with cls.packet_cache_lock:
            cached = cls.packet_cache.get(cache_key)
            if cached and (time.time() - cached["time"]) < cls.PACKET_CACHE_TIMEOUT:
                return cached["packet"]

        # Assume it exists and just try to get it to avoid an extra call to Store.exist?
        json_data = cls._store_for_target(target_name, scope).hget(
            f"{scope}__openc3{type.lower()}__{target_name}", packet_name
        )
        if not json_data:
            raise RuntimeError(f"Packet '{target_name} {packet_name}' does not exist")
        packet = json.loads(json_data)

        # Store in cache
        with cls.packet_cache_lock:
            cls.packet_cache[cache_key] = {"packet": packet, "time": time.time()}

        return packet

    @classmethod
    def packets(cls, target_name: str, type: str = "TLM", scope: str = OPENC3_SCOPE):
        """@return [Array>Hash>] All packet hashes under the target_name"""
        if type not in cls.VALID_TYPES:
            raise RuntimeError(f"Unknown type {type} for {target_name}")
        if not cls.get(name=target_name, scope=scope):
            raise RuntimeError(f"Target '{target_name}' does not exist")

        result = []
        packets = cls._store_for_target(target_name, scope).hgetall(f"{scope}__openc3{type.lower()}__{target_name}")
        for _, packet_json in packets.items():
            result.append(json.loads(packet_json))
        return result

    @classmethod
    def set_packet(
        cls,
        target_name: str,
        packet_name: str,
        packet: Any,
        type: str = "TLM",
        scope: str = OPENC3_SCOPE,
    ):
        if type not in cls.VALID_TYPES:
            raise RuntimeError(f"Unknown type {type} for {target_name} {packet_name}")

        # Invalidate cache entry
        cache_key = f"{scope}__{type}__{target_name}__{packet_name}"
        with cls.packet_cache_lock:
            cls.packet_cache.pop(cache_key, None)

        try:
            cls._store_for_target(target_name, scope).hset(
                f"{scope}__openc3{type.lower()}__{target_name}",
                packet_name,
                json.dumps(packet),
            )
        except (TypeError, RuntimeError) as error:
            Logger.error(f"Invalid text present in {target_name} {packet_name} {type.lower()} packet")
            raise error

    @classmethod
    def clear_packet_cache(cls):
        with cls.packet_cache_lock:
            cls.packet_cache.clear()

    @classmethod
    def packet_item(
        cls,
        target_name: str,
        packet_name: str,
        item_name,
        type: str = "TLM",
        scope: str = OPENC3_SCOPE,
    ):
        """@return [Hash] Item hash or raises an exception"""
        packet = cls.packet(target_name, packet_name, type=type, scope=scope)
        found = None
        for item in packet["items"]:
            if item["name"] == item_name:
                found = item
                break
        if not found:
            raise RuntimeError(f"Item '{packet['target_name']} {packet['packet_name']} {item_name}' does not exist")
        return found

    # @return [Array<Hash>] Item hash array or raises an exception
    @classmethod
    def packet_items(
        cls,
        target_name: str,
        packet_name: str,
        items: Any,
        type: str = "TLM",
        scope: str = OPENC3_SCOPE,
    ):
        packet = cls.packet(target_name, packet_name, type=type, scope=scope)
        found = []
        for item in packet["items"]:
            if item["name"] in items:
                found.append(item)
        if len(found) != len(items):  # we didn't find them all
            found_items = [item["name"] for item in found]
            not_found = []
            for item in set(items) - set(found_items):
                not_found.append(f"'{target_name} {packet_name} {item}'")
            # 'does not exist' not grammatically correct but we use it in every other exception
            raise RuntimeError(f"Item(s) {', '.join(not_found)} does not exist")
        return found

    # @return [List<String>] All the item names for every packet in a target
    @classmethod
    def all_item_names(cls, target_name: str, type: str = "TLM", scope: str = OPENC3_SCOPE):
        items = cls._store_for_target(target_name, scope).zrange(f"{scope}__openc3tlm__{target_name}__allitems", 0, -1)
        if not items:
            items = cls.rebuild_target_allitems_list(target_name, type=type, scope=scope)
        return items

    @classmethod
    def rebuild_target_allitems_list(cls, target_name: str, type: str = "TLM", scope: str = OPENC3_SCOPE):
        for packet in cls.packets(target_name, scope=scope):
            for item in packet["items"]:
                cls.add_to_target_allitems_list(target_name, item["name"], scope=scope)
        return cls._store_for_target(target_name, scope).zrange(
            f"{scope}__openc3tlm__{target_name}__allitems", 0, -1
        )  # return the new sorted set to let redis do the sorting

    @classmethod
    def add_to_target_allitems_list(cls, target_name: str, item_name: str, scope: str = OPENC3_SCOPE):
        # https://redis.io/docs/latest/develop/data-types/sorted-sets/#lexicographical-scores
        cls._store_for_target(target_name, scope).zadd(f"{scope}__openc3tlm__{target_name}__allitems", {item_name: 0})

    # @return [Hash{String => Array<Array<String, String, String>>}]
    @classmethod
    def limits_groups(cls, scope: str = OPENC3_SCOPE):
        groups = Store.hgetall(f"{scope}__limits_groups")
        if groups:
            return {k.decode(): json.loads(v) for (k, v) in groups.items()}
        else:
            return {}

    @classmethod
    def get_item_to_packet_map(cls, target_name: str, scope: str = OPENC3_SCOPE):
        if target_name in TargetModel.item_map_cache:
            cache_time, item_map = TargetModel.item_map_cache[target_name]
            if (time.time() - cache_time) < TargetModel.ITEM_MAP_CACHE_TIMEOUT:
                return item_map
        item_map_key = f"{scope}__{target_name}__item_to_packet_map"
        target_name = target_name.upper()
        store = cls._store_for_target(target_name, scope)
        json_data = store.get(item_map_key)
        if json_data:
            item_map = json.loads(json_data)
        else:
            item_map = cls.build_item_to_packet_map(target_name, scope=scope)
            store.set(item_map_key, json.dumps(item_map))
        TargetModel.item_map_cache[target_name] = [time.time(), item_map]
        return item_map

    @classmethod
    def build_item_to_packet_map(cls, target_name: str, scope: str = OPENC3_SCOPE):
        item_map = {}
        for packet in cls.packets(target_name, scope=scope):
            items = packet["items"]
            for item in items:
                item_name = item["name"]
                if item_map.get(item_name) is None:
                    item_map[item_name] = []
                item_map[item_name].append(packet["packet_name"])
        return item_map

    @classmethod
    def increment_telemetry_count(cls, target_name: str, packet_name: str, count: int, scope: str = OPENC3_SCOPE):
        result = cls._store_for_target(target_name, scope).hincrby(
            f"{scope}__TELEMETRYCNTS__{{{target_name}}}", packet_name, count
        )
        if isinstance(result, bytes | bytearray):
            return int(result)
        else:
            return result

    @classmethod
    def get_all_telemetry_counts(cls, target_name: str, scope: str = OPENC3_SCOPE):
        result = {}
        get_all = cls._store_for_target(target_name, scope).hgetall(f"{scope}__TELEMETRYCNTS__{{{target_name}}}")
        if get_all is dict:
            for key, value in get_all.items():
                result[key] = int(value)
            return result
        else:
            return get_all

    @classmethod
    def get_telemetry_count(cls, target_name: str, packet_name: str, scope: str = OPENC3_SCOPE):
        value = cls._store_for_target(target_name, scope).hget(
            f"{scope}__TELEMETRYCNTS__{{{target_name}}}", packet_name
        )
        if value is None:
            return 0
        elif isinstance(value, bytes | bytearray):
            return int(value)
        else:
            return value

    @classmethod
    def get_telemetry_counts(cls, target_packets: list, scope: str = OPENC3_SCOPE):
        # Group by db_shard, preserving original index
        db_shard_groups = {}  # db_shard => [{"index": idx, "target_name": ..., "packet_name": ...}]
        for idx, (target_name, packet_name) in enumerate(target_packets):
            target_name = target_name.upper()
            packet_name = packet_name.upper()
            db_shard = Store.db_shard_for_target(target_name, scope=scope)
            if db_shard not in db_shard_groups:
                db_shard_groups[db_shard] = []
            db_shard_groups[db_shard].append({"index": idx, "target_name": target_name, "packet_name": packet_name})

        counts = [0] * len(target_packets)
        for db_shard, entries in db_shard_groups.items():
            store = Store.instance(db_shard=db_shard)
            with store.redis_pool.get() as redis:
                pipeline = redis.pipeline(transaction=False)
                for entry in entries:
                    pipeline.hget(f"{scope}__TELEMETRYCNTS__{{{entry['target_name']}}}", entry["packet_name"])
                result = pipeline.execute()
            for i, entry in enumerate(entries):
                counts[entry["index"]] = int(result[i]) if result[i] is not None else 0
        return counts

    @classmethod
    def init_tlm_packet_counts(cls, tlm_target_names, scope):
        cls.sync_packet_count_time = time.time()
        cls.stale_packet_keys_warned = set()

        # Get all the packet counts with the global counters
        for target_name in tlm_target_names:
            for packet_name, count in TargetModel.get_all_telemetry_counts(target_name, scope=scope).items():
                try:
                    update_packet = System.telemetry.packet(target_name, packet_name.decode())
                    update_packet.received_count = int(count)
                except RuntimeError:
                    key = f"{target_name} {packet_name.decode()}"
                    if key not in cls.stale_packet_keys_warned:
                        cls.stale_packet_keys_warned.add(key)
                        Logger.warn(f"Stale tlmcnt Redis key detected for unknown packet {key} - ignoring")
        for packet_name, count in TargetModel.get_all_telemetry_counts("UNKNOWN", scope=scope).items():
            try:
                update_packet = System.telemetry.packet("UNKNOWN", packet_name.decode())
                update_packet.received_count = int(count)
            except RuntimeError:
                key = f"UNKNOWN {packet_name.decode()}"
                if key not in cls.stale_packet_keys_warned:
                    cls.stale_packet_keys_warned.add(key)
                    Logger.warn(f"Stale tlmcnt Redis key detected for unknown packet {key} - ignoring")

    @classmethod
    def sync_tlm_packet_counts(cls, packet, tlm_target_names, scope):
        if cls.sync_packet_count_delay_seconds <= 0:
            # Perfect but slow method
            packet.received_count = TargetModel.increment_telemetry_count(
                packet.target_name, packet.packet_name, 1, scope=scope
            )
        else:
            # Eventually consistent method
            # Only sync every period (default 1 second) to avoid hammering Redis
            # This is a trade off between speed and accuracy
            # The packet count is eventually consistent
            if cls.sync_packet_count_data.get(packet.target_name) is None:
                cls.sync_packet_count_data[packet.target_name] = {}
            if cls.sync_packet_count_data[packet.target_name].get(packet.packet_name) is None:
                cls.sync_packet_count_data[packet.target_name][packet.packet_name] = 0
            cls.sync_packet_count_data[packet.target_name][packet.packet_name] += 1

            # Ensures counters change between syncs
            update_packet = System.telemetry.packet(packet.target_name, packet.packet_name)
            update_packet.received_count += 1
            packet.received_count = update_packet.received_count

            # Check if we need to sync the packet counts
            if (
                cls.sync_packet_count_time is None
                or (time.time() - cls.sync_packet_count_time) > cls.sync_packet_count_delay_seconds
            ):
                cls.sync_packet_count_time = time.time()

                # Increment global counters for packets received
                for (
                    target_name,
                    packet_data,
                ) in cls.sync_packet_count_data.items():
                    for packet_name, count in packet_data.items():
                        TargetModel.increment_telemetry_count(target_name, packet_name, count, scope=scope)
                cls.sync_packet_count_data = {}

                # Get all the packet counts with the global counters
                for target_name in tlm_target_names:
                    for packet_name, count in TargetModel.get_all_telemetry_counts(target_name, scope=scope).items():
                        try:
                            update_packet = System.telemetry.packet(
                                target_name, packet_name.decode() if isinstance(packet_name, bytes) else packet_name
                            )
                            update_packet.received_count = int(count)
                        except RuntimeError:
                            key = f"{target_name} {packet_name.decode() if isinstance(packet_name, bytes) else packet_name}"
                            if key not in cls.stale_packet_keys_warned:
                                cls.stale_packet_keys_warned.add(key)
                                Logger.warn(f"Stale tlmcnt Redis key detected for unknown packet {key} - ignoring")
                for packet_name, count in TargetModel.get_all_telemetry_counts("UNKNOWN", scope=scope).items():
                    try:
                        update_packet = System.telemetry.packet(
                            "UNKNOWN", packet_name.decode() if isinstance(packet_name, bytes) else packet_name
                        )
                        update_packet.received_count = int(count)
                    except RuntimeError:
                        key = f"UNKNOWN {packet_name.decode() if isinstance(packet_name, bytes) else packet_name}"
                        if key not in cls.stale_packet_keys_warned:
                            cls.stale_packet_keys_warned.add(key)
                            Logger.warn(f"Stale tlmcnt Redis key detected for unknown packet {key} - ignoring")

    @classmethod
    def increment_command_count(cls, target_name: str, packet_name: str, count: int, scope: str = OPENC3_SCOPE):
        result = cls._store_for_target(target_name, scope).hincrby(
            f"{scope}__COMMANDCNTS__{{{target_name}}}", packet_name, count
        )
        if isinstance(result, bytes | bytearray):
            return int(result)
        else:
            return result

    @classmethod
    def get_all_command_counts(cls, target_name: str, scope: str = OPENC3_SCOPE):
        result = {}
        get_all = cls._store_for_target(target_name, scope).hgetall(f"{scope}__COMMANDCNTS__{{{target_name}}}")
        if get_all is dict:
            for key, value in get_all.items():
                result[key] = int(value)
            return result
        else:
            return get_all

    @classmethod
    def get_command_count(cls, target_name: str, packet_name: str, scope: str = OPENC3_SCOPE):
        value = cls._store_for_target(target_name, scope).hget(f"{scope}__COMMANDCNTS__{{{target_name}}}", packet_name)
        if value is None:
            return 0
        elif isinstance(value, bytes | bytearray):
            return int(value)
        else:
            return value

    @classmethod
    def get_command_counts(cls, target_packets: list, scope: str = OPENC3_SCOPE):
        # Group by db_shard, preserving original index
        db_shard_groups = {}  # db_shard => [{"index": idx, "target_name": ..., "packet_name": ...}]
        for idx, (target_name, packet_name) in enumerate(target_packets):
            target_name = target_name.upper()
            packet_name = packet_name.upper()
            db_shard = Store.db_shard_for_target(target_name, scope=scope)
            if db_shard not in db_shard_groups:
                db_shard_groups[db_shard] = []
            db_shard_groups[db_shard].append({"index": idx, "target_name": target_name, "packet_name": packet_name})

        counts = [0] * len(target_packets)
        for db_shard, entries in db_shard_groups.items():
            store = Store.instance(db_shard=db_shard)
            with store.redis_pool.get() as redis:
                pipeline = redis.pipeline(transaction=False)
                for entry in entries:
                    pipeline.hget(f"{scope}__COMMANDCNTS__{{{entry['target_name']}}}", entry["packet_name"])
                result = pipeline.execute()
            for i, entry in enumerate(entries):
                counts[entry["index"]] = int(result[i]) if result[i] is not None else 0
        return counts

    # Most of these parameters are unused but they must match the Ruby implementation
    # so we can call TargetModel.get_model which calls Model.get_model which does
    #   json_data = cls.get(name, scope)
    #   return cls.from_json(json_data, scope)
    # cls.from_json calls cls(**json_data) which is the constructor which takes
    # all the keyword arguments from the json_data which were set during installation
    # by the Ruby code
    def __init__(
        self,
        name: str,
        folder_name=None,
        requires=None,
        ignored_parameters=None,
        ignored_items=None,
        limits_groups=None,
        cmd_tlm_files=None,
        id=None,
        updated_at=None,
        plugin=None,
        cmd_buffer_depth=5,
        cmd_log_cycle_time=600,
        cmd_log_cycle_size=50_000_000,
        cmd_log_retain_time=None,
        tlm_buffer_depth=60,
        tlm_log_cycle_time=600,
        tlm_log_cycle_size=50_000_000,
        tlm_log_retain_time=None,
        cmd_decom_retain_time=None,
        tlm_decom_retain_time=None,
        cleanup_poll_time=3600,
        needs_dependencies=False,
        target_microservices=None,
        disable_erb=None,
        shard=0,
        db_shard=0,
        scope: str = OPENC3_SCOPE,
    ):
        if target_microservices is None:
            target_microservices = {"REDUCER": [[]]}
        if cmd_tlm_files is None:
            cmd_tlm_files = []
        if limits_groups is None:
            limits_groups = []
        if ignored_items is None:
            ignored_items = []
        if ignored_parameters is None:
            ignored_parameters = []
        if requires is None:
            requires = []
        self.shard = int(shard) if shard is not None else 0
        self.db_shard = int(db_shard) if db_shard is not None else 0
        super().__init__(
            f"{scope}__{self.PRIMARY_KEY}",
            name=name,
            updated_at=updated_at,
            plugin=plugin,
            scope=scope,
        )

    def update_store_telemetry(self, packet_hash, clear_old=True):
        db_shard_store = Store.instance(db_shard=self.db_shard)
        for target_name, packets in packet_hash.items():
            if clear_old:
                db_shard_store.delete(f"{self.scope}__openc3tlm__{target_name}")
                db_shard_store.delete(f"{self.scope}__openc3tlm__{target_name}__allitems")
                db_shard_store.delete(f"{self.scope}__TELEMETRYCNTS__{{{target_name}}}")
            for packet_name, packet in packets.items():
                Logger.debug(f"Configuring tlm packet= {target_name} {packet_name}")
                try:
                    db_shard_store.hset(
                        f"{self.scope}__openc3tlm__{target_name}",
                        packet_name,
                        json.dumps(packet.as_json()),
                    )
                except Exception as e:
                    Logger.error(f"Invalid text present in {target_name} {packet_name} tlm packet")
                    raise e
                json_hash = {}
                for item in packet.sorted_items:
                    json_hash[item.name] = None
                    TargetModel.add_to_target_allitems_list(target_name, item.name, scope=self.scope)
                # Use Store.hset directly instead of CvtModel.set to avoid circular dependency
                db_shard_store.hset(
                    f"{self.scope}__tlm__{packet.target_name}",
                    packet.packet_name,
                    json.dumps(json_hash, cls=JsonEncoder),
                )

    def update_store_commands(self, packet_hash, clear_old=True):
        db_shard_store = Store.instance(db_shard=self.db_shard)
        for target_name, packets in packet_hash.items():
            if clear_old:
                db_shard_store.delete(f"{self.scope}__openc3cmd__{target_name}")
                db_shard_store.delete(f"{self.scope}__COMMANDCNTS__{{{target_name}}}")
            for packet_name, packet in packets.items():
                Logger.debug(f"Configuring cmd packet= {target_name} {packet_name}")
                try:
                    db_shard_store.hset(
                        f"{self.scope}__openc3cmd__{target_name}",
                        packet_name,
                        json.dumps(packet.as_json()),
                    )
                except Exception as e:
                    Logger.error(f"Invalid text present in {target_name} {packet_name} cmd packet")
                    raise e

    def update_store_item_map(self):
        # Create item_map
        item_map_key = f"{self.scope}__{self.name}__item_to_packet_map"
        item_map = TargetModel.build_item_to_packet_map(self.name, scope=self.scope)
        Store.instance(db_shard=self.db_shard).set(item_map_key, json.dumps(item_map))
        TargetModel.item_map_cache[self.name] = [time.time(), item_map]

    def dynamic_update(self, packets, cmd_or_tlm="TELEMETRY", filename="dynamic_tlm.txt"):
        # Build hash of targets/packets
        packet_hash = {}
        for packet in packets:
            target_name = packet.target_name.upper()
            if not packet_hash.get(target_name):
                packet_hash[target_name] = {}
            packet_name = packet.packet_name.upper()
            packet_hash[target_name][packet_name] = packet

        # Update Redis
        if cmd_or_tlm == "TELEMETRY":
            self.update_store_telemetry(packet_hash, clear_old=False)
            self.update_store_item_map()
        else:
            self.update_store_commands(packet_hash, clear_old=False)

        # Build dynamic file for cmd_tlm
        configs = {}
        for packet in packets:
            target_name = packet.target_name.upper()
            if not configs.get(target_name):
                configs[target_name] = ""
            config = configs[target_name]
            config += packet.to_config(cmd_or_tlm)
            config += "\n"
        for target_name, config in configs.items():
            bucket_key = f"{self.scope}/targets_modified/{target_name}/cmd_tlm/{filename}"
            client = Bucket.get_client()
            client.put_object(
                # Use targets_modified to save modifications
                # This keeps the original target clean (read-only)
                bucket=OPENC3_CONFIG_BUCKET,
                key=bucket_key,
                body=config,
            )

        # Inform microservices of new topics
        # Need to tell loggers to log, and decom to decom
        # We do this for no downtime
        raw_topics = []
        decom_topics = []
        for packet in packets:
            if cmd_or_tlm == "TELEMETRY":
                raw_topics.append(f"{self.scope}__TELEMETRY__{{{self.name}}}__{packet.packet_name.upper()}")
                decom_topics.append(f"{self.scope}__DECOM__{{{self.name}}}__{packet.packet_name.upper()}")
            else:
                raw_topics.append(f"{self.scope}__COMMAND__{{{self.name}}}__{packet.packet_name.upper()}")
                decom_topics.append(f"{self.scope}__DECOMCMD__{{{self.name}}}__{packet.packet_name.upper()}")
        if cmd_or_tlm == "TELEMETRY":
            Topic.write_topic(
                f"MICROSERVICE__{self.scope}__PACKETLOG__{self.name}",
                {
                    "command": "ADD_TOPICS",
                    "topics": json.dumps(raw_topics, cls=JsonEncoder),
                },
                db_shard=self.db_shard,
            )
            self.add_topics_to_microservice(f"{self.scope}__PACKETLOG__{self.name}", raw_topics)
            Topic.write_topic(
                f"MICROSERVICE__{self.scope}__DECOM__{self.name}",
                {
                    "command": "ADD_TOPICS",
                    "topics": json.dumps(raw_topics, cls=JsonEncoder),
                },
                db_shard=self.db_shard,
            )
            self.add_topics_to_microservice(f"{self.scope}__DECOM__{self.name}", raw_topics)
        else:
            Topic.write_topic(
                f"MICROSERVICE__{self.scope}__COMMANDLOG__{self.name}",
                {
                    "command": "ADD_TOPICS",
                    "topics": json.dumps(raw_topics, cls=JsonEncoder),
                },
                db_shard=self.db_shard,
            )
            self.add_topics_to_microservice(f"{self.scope}__COMMANDLOG__{self.name}", raw_topics)

    def add_topics_to_microservice(self, microservice_name, topics):
        model = MicroserviceModel.get_model(name=microservice_name, scope=self.scope)
        model.topics.extend(topics)
        model.topics = list(set(model.topics))
        model.ignore_changes = True  # Don't restart the microservice right now
        model.update()
