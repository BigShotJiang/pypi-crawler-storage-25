"""Tests for ``preframr_tokens.macros.roles``."""

from __future__ import annotations

import unittest

from preframr_tokens.macros.roles import (
    DISTANCE_PAIR_OPS,
    DistancePairSpec,
    distance_pair_role,
    frame_weight_role,
    slope_subreg_role,
)
from preframr_tokens.stfconstants import (
    BACK_REF_OP,
    BACK_REF_SUBREG_DIST_HI,
    BACK_REF_SUBREG_DIST_LO,
    BACK_REF_SUBREG_LEN,
    DO_LOOP_OP,
    PATTERN_REPLAY_OP,
    PATTERN_REPLAY_SUBREG_DIST_HI,
    PATTERN_REPLAY_SUBREG_DIST_LO,
    PATTERN_REPLAY_SUBREG_LEN,
    PATTERN_REPLAY_SUBREG_OVERLAY_COUNT,
    SET_OP,
    SLOPE_FREQ_LO_OP,
    SLOPE_OPS,
    SLOPE_PW_LO_OP,
    SLOPE_SUBREG_RUNTIME,
    SLOPE_SUBREG_TERMINAL_HI,
    SLOPE_SUBREG_TERMINAL_LO,
)


class TestDistancePairRole(unittest.TestCase):
    def test_back_ref_slots(self):
        self.assertEqual(
            distance_pair_role(BACK_REF_OP, BACK_REF_SUBREG_DIST_HI), "dist_hi"
        )
        self.assertEqual(
            distance_pair_role(BACK_REF_OP, BACK_REF_SUBREG_DIST_LO), "dist_lo"
        )
        self.assertEqual(distance_pair_role(BACK_REF_OP, BACK_REF_SUBREG_LEN), "len")

    def test_pattern_replay_slots(self):
        self.assertEqual(
            distance_pair_role(PATTERN_REPLAY_OP, PATTERN_REPLAY_SUBREG_DIST_HI),
            "dist_hi",
        )
        self.assertEqual(
            distance_pair_role(PATTERN_REPLAY_OP, PATTERN_REPLAY_SUBREG_DIST_LO),
            "dist_lo",
        )
        self.assertEqual(
            distance_pair_role(PATTERN_REPLAY_OP, PATTERN_REPLAY_SUBREG_LEN), "len"
        )
        self.assertEqual(
            distance_pair_role(PATTERN_REPLAY_OP, PATTERN_REPLAY_SUBREG_OVERLAY_COUNT),
            "ov_count",
        )

    def test_back_ref_has_no_ov_count(self):
        self.assertIsNone(distance_pair_role(BACK_REF_OP, 3))

    def test_non_distance_op_returns_none(self):
        self.assertIsNone(distance_pair_role(SET_OP, 0))
        self.assertIsNone(distance_pair_role(DO_LOOP_OP, 0))

    def test_unknown_subreg_returns_none(self):
        self.assertIsNone(distance_pair_role(BACK_REF_OP, 99))


class TestDistancePairOps(unittest.TestCase):
    def test_table_contents(self):
        self.assertIn(BACK_REF_OP, DISTANCE_PAIR_OPS)
        self.assertIn(PATTERN_REPLAY_OP, DISTANCE_PAIR_OPS)
        br = DISTANCE_PAIR_OPS[BACK_REF_OP]
        self.assertEqual(br.label, "BACK_REF")
        self.assertEqual(br.extra_subregs, frozenset())
        pr = DISTANCE_PAIR_OPS[PATTERN_REPLAY_OP]
        self.assertEqual(pr.label, "PR")
        self.assertEqual(
            pr.extra_subregs, frozenset({PATTERN_REPLAY_SUBREG_OVERLAY_COUNT})
        )

    def test_spec_is_frozen(self):
        spec = DISTANCE_PAIR_OPS[BACK_REF_OP]
        with self.assertRaises(Exception):
            spec.label = "mutated"  # type: ignore[misc]
        self.assertIsInstance(spec, DistancePairSpec)


class TestSlopeSubregRole(unittest.TestCase):
    def test_each_role(self):
        op = SLOPE_FREQ_LO_OP
        self.assertEqual(slope_subreg_role(op, SLOPE_SUBREG_TERMINAL_HI), "terminal_hi")
        self.assertEqual(slope_subreg_role(op, SLOPE_SUBREG_TERMINAL_LO), "terminal_lo")
        self.assertEqual(slope_subreg_role(op, SLOPE_SUBREG_RUNTIME), "runtime")

    def test_all_slope_ops_recognised(self):
        for op in SLOPE_OPS:
            self.assertEqual(
                slope_subreg_role(op, SLOPE_SUBREG_TERMINAL_HI), "terminal_hi"
            )

    def test_non_slope_op_returns_none(self):
        self.assertIsNone(slope_subreg_role(SET_OP, SLOPE_SUBREG_TERMINAL_HI))
        self.assertIsNone(slope_subreg_role(BACK_REF_OP, SLOPE_SUBREG_TERMINAL_HI))

    def test_unknown_subreg_returns_none(self):
        self.assertIsNone(slope_subreg_role(SLOPE_PW_LO_OP, 99))


class TestFrameWeightRole(unittest.TestCase):
    def test_back_ref_len(self):
        self.assertEqual(
            frame_weight_role(BACK_REF_OP, BACK_REF_SUBREG_LEN), "back_ref_len"
        )

    def test_do_loop_len(self):
        self.assertEqual(frame_weight_role(DO_LOOP_OP, 0), "do_loop_len")

    def test_slope_runtime(self):
        for op in SLOPE_OPS:
            self.assertEqual(
                frame_weight_role(op, SLOPE_SUBREG_RUNTIME), "slope_runtime"
            )

    def test_back_ref_dist_hi_is_not_a_weight_source(self):
        self.assertIsNone(frame_weight_role(BACK_REF_OP, BACK_REF_SUBREG_DIST_HI))

    def test_do_loop_non_zero_subreg(self):
        self.assertIsNone(frame_weight_role(DO_LOOP_OP, 1))

    def test_slope_terminal_subreg_is_not_runtime(self):
        self.assertIsNone(frame_weight_role(SLOPE_FREQ_LO_OP, SLOPE_SUBREG_TERMINAL_HI))

    def test_unrelated_op(self):
        self.assertIsNone(frame_weight_role(SET_OP, 0))


if __name__ == "__main__":
    unittest.main()
