"""
Example: recharge your own Telegram Ads account with TON.

Amount must be an integer between 1 and 1 000 000 000 TON.
Your wallet must satisfy the current minimum TON threshold and transaction cost.
"""

import asyncio

from pyfragment import (
    AdsRechargeResult,
    ConfigurationError,
    FragmentClient,
    WalletError,
)
from pyfragment.utils import get_cookies_from_browser  # noqa: F401

SEED = "word1 word2 ... word24"
API_KEY = "YOUR_TONAPI_KEY"

# Option A: extract cookies directly from your browser (no manual copy-paste needed)
# COOKIES = get_cookies_from_browser("chrome").cookies  # or "firefox", "edge", "brave", ...

# Option B: provide cookies manually
COOKIES = {
    "stel_ssid": "YOUR_STEL_SSID",
    "stel_dt": "YOUR_STEL_DT",
    "stel_token": "YOUR_STEL_TOKEN",
    "stel_ton_token": "YOUR_STEL_TON_TOKEN",
}

ACCOUNT = "@mychannel"  # channel or bot username linked to your Telegram Ads account
AMOUNT = 10  # 1–1 000 000 000 TON


async def main() -> None:
    async with FragmentClient(seed=SEED, api_key=API_KEY, cookies=COOKIES) as client:
        try:
            result: AdsRechargeResult = await client.recharge_ads(ACCOUNT, amount=AMOUNT)
        except WalletError as e:
            print(f"Wallet error — insufficient balance or misconfiguration: {e}")
            return
        except ConfigurationError as e:
            print(f"Invalid argument: {e}")
            return

    print(f"{result.amount} TON recharged to Ads account {ACCOUNT} | tx: {result.transaction_id}")


if __name__ == "__main__":
    asyncio.run(main())
