from lightning.pytorch.callbacks import ModelCheckpoint


class PthModelCheckpoint(ModelCheckpoint):
    """PthModelCheckpoint saves model checkpoints using the .pth extension."""

    FILE_EXTENSION = ".pth"
