import torch
from torch import Tensor
from torchvision.ops import box_iou


def get_greedy_matches(gt_boxes: Tensor, pred_boxes: Tensor, pred_scores: Tensor, iou_threshold: float = 0.5):
    """Perform a greedy matching between ground truth and predictions bounding boxes.

    Args:
        gt_boxes (Tensor): x1, y1, x2, y2 ground truth bounding boxes
        pred_boxes (Tensor): x1, y1, x2, y2 predicted bounding boxes
        pred_scores (Tensor): predicted scores associated with each predicted box
        iou_threshold (float): Minimum IoU threshold to use for matching
    """
    if len(gt_boxes) == 0:
        return [], list(range(len(pred_boxes))), []
    if len(pred_boxes) == 0:
        return [], [], list(range(len(gt_boxes)))

    indices_sorted = torch.argsort(pred_scores, descending=True)

    ious = box_iou(gt_boxes, pred_boxes)

    matches = []
    matched_gt_indices = set()
    matched_pred_indices = set()

    for pred_idx in indices_sorted.tolist():
        iou_values = ious[:, pred_idx]
        best_gt_idx = torch.argmax(iou_values).item()
        best_iou = iou_values[best_gt_idx].item()

        if best_iou >= iou_threshold and best_gt_idx not in matched_gt_indices:
            matches.append((best_gt_idx, pred_idx, best_iou))
            matched_gt_indices.add(best_gt_idx)
            matched_pred_indices.add(pred_idx)

    fps = [i for i in range(len(pred_boxes)) if i not in matched_pred_indices]
    fns = [i for i in range(len(gt_boxes)) if i not in matched_gt_indices]

    return matches, fps, fns


def detection_to_classification(
    ground_truth: list[dict], predictions: list[dict], num_classes: int, iou_threshold: float
) -> tuple[Tensor, Tensor]:
    """Convert detection results to classification scores.

    We consider the classification problem as a multiclass problem.
    We consider each predicted bounding box as an 'image' with its associated score and label,
    If matched to a corresponding ground truth, associate them.
    If not matched to a corresponding ground truth, we create a virtual __background__ label.

    Args:
        ground_truth (list[dict]): ground truth bounding boxes
        predictions (list[dict]): prediction bounding boxes
        num_classes (int): total number of possible classes
        iou_threshold (float): Minimum IoU threshold to use for matching
    """
    all_probas = []
    all_targets = []

    for batch_idx in range(len(ground_truth)):
        gt_batch = ground_truth[batch_idx]
        pred_batch = predictions[batch_idx]

        device = pred_batch["scores"].device

        matches, fps, fns = get_greedy_matches(
            gt_batch["boxes"],
            pred_batch["boxes"],
            pred_batch["scores"],
            iou_threshold=iou_threshold,
        )

        for gt_idx, pred_idx, _ in matches:
            pred_label = pred_batch["labels"][pred_idx]
            score = pred_batch["scores"][pred_idx]

            probas = torch.zeros(num_classes, device=device)
            probas[pred_label] = score

            all_probas.append(probas)
            all_targets.append(gt_batch["labels"][gt_idx])

        for pred_idx in fps:
            pred_label = pred_batch["labels"][pred_idx]
            score = pred_batch["scores"][pred_idx]

            probas = torch.zeros(num_classes, device=device)
            probas[pred_label] = score

            all_probas.append(probas)
            all_targets.append(torch.tensor(0, device=device))

    if len(all_probas) == 0:
        return torch.empty((0, num_classes)), torch.empty(0, dtype=torch.long)

    return torch.stack(all_probas), torch.stack(all_targets)
