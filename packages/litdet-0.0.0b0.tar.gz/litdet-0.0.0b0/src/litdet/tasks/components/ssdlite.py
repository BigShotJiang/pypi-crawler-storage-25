from functools import partial
from typing import Any

from torch import nn
from torchvision.models import MobileNet_V3_Large_Weights
from torchvision.models.detection import SSDLite320_MobileNet_V3_Large_Weights, ssdlite320_mobilenet_v3_large
from torchvision.models.detection._utils import retrieve_out_channels
from torchvision.models.detection.ssdlite import SSD, SSDLiteClassificationHead


def build_ssdlite320_mobilenet_v3_large(
    weights: SSDLite320_MobileNet_V3_Large_Weights | str | None = None,
    progress: bool = True,
    num_classes: int | None = None,
    weights_backbone: MobileNet_V3_Large_Weights = MobileNet_V3_Large_Weights.DEFAULT,
    trainable_backbone_layers: int | None = None,
    **kwargs: Any,
) -> SSD:
    """Build a SSD Lite MobileNet V3 model for fine-tuning.

    The function either changes the last layer of the model with the desired number of classes
    (when `weights` is defined and `num_classes` is different than 91, i.e. the number of classes
    for COCO) or either creates the model with the passed parameters.

    Please refer to Torchvision documentation for more details on `build_ssd300_vgg16
    <https://docs.pytorch.org/vision/main/models/generated/torchvision.models.detection.ssd300_vgg16>`.


    Args:
        weights (SSDLite320_MobileNet_V3_Large_Weights, optional): The pretrained weights to use.
        progress (bool): If True, displays a progress bar of the download to stderr. Default is
        True.
        num_classes (int, optional): Number of output classes of the model (including the
        background).
        weights_backbone (MobileNet_V3_Large_Weights): The pretrained weights for the backbone.
        trainable_backbone_layers (int, optional): Number of trainable (not frozen) layers starting
        from final block. Valid values are between 0 and 6, with 6 meaning all backbone layers are
        trainable. If None is passed (the default) this value is set to 6.
        **kwargs (Any): Parameters passed to the
          torchvision.models.detection.ssdlite.SSD base class.

    Returns:
        SSD: The instantiated SSDlite model.
    """
    if num_classes != 91 and weights:
        model = ssdlite320_mobilenet_v3_large(
            weights=weights,
            progress=progress,
            weights_backbone=weights_backbone,
            trainable_backbone_layers=trainable_backbone_layers,
            **kwargs,
        )
        # Hard coded parameters in torchvision
        size = (320, 320)
        norm_layer = partial(nn.BatchNorm2d, eps=0.001, momentum=0.03)
        if "norm_layer" in kwargs:
            norm_layer = kwargs["norm_layer"]

        # Retrieve parameters
        in_channels = retrieve_out_channels(model.backbone, size)
        num_anchors = model.anchor_generator.num_anchors_per_location()

        # replace the pre-trained classification head with a new one
        model.head.classification_head = SSDLiteClassificationHead(
            in_channels=in_channels, num_anchors=num_anchors, num_classes=num_classes, norm_layer=norm_layer
        )
    else:
        model = ssdlite320_mobilenet_v3_large(
            weights=weights,
            progress=progress,
            num_classes=num_classes,
            weights_backbone=weights_backbone,
            trainable_backbone_layers=trainable_backbone_layers,
            **kwargs,
        )

    return model
