# LitDet

![Version](https://img.shields.io/badge/Version-v0.1.0-blue)
[![PyPI](https://img.shields.io/badge/PyPI-available-blue?logo=pypi&logoColor=white)](https://pypi.org/search/?q=litdet)
[![Documentation Status](https://readthedocs.org/projects/litdet/badge/?version=latest)](https://litdet.readthedocs.io/en/?badge=latest)
[![License](https://img.shields.io/badge/License-Apache_2.0-yellogreen.svg)](https://opensource.org/licenses/Apache-2.0)

[![Python](https://img.shields.io/badge/python-3.10--3.14-blue?logo=python)](https://www.python.org/)
[![pytorch](https://img.shields.io/badge/PyTorch_2.5+-ee4c2c?logo=pytorch&logoColor=white)](https://pytorch.org/get-started/locally/)
[![lightning](https://img.shields.io/badge/-Lightning_2.5+-792ee5?logo=pytorchlightning&logoColor=white)](https://pytorchlightning.ai/)
[![hydra](https://img.shields.io/badge/Config-Hydra_1.3+-89b8cd)](https://hydra.cc/)

![Platform](https://img.shields.io/badge/Platform-linux--64_%7C_win--64_wsl2%7C_aarch64-gray)
[![CUDA](https://img.shields.io/badge/CUDA-v11.8_%7c_12.1_%7c_v12.4-%2376B900?logo=nvidia)](https://developer.nvidia.com/cuda-toolkit-archive)

*LitDet* is a domain-agnostic AutoML framework to accelerate the development of 2D object detection models 🚀⚡🔥.

- **ML Workflows**: Handles model pre-training, fine-tuning or re-training at scale.
- **Key Features**: Provides a high-level CLI and python API for seamless hardware support (CPU/GPU), COCO-formatted dataset integration, and built-in experiment tracking.
- **Tech Stack**: Built on the Lightning-Hydra framework, it leverages PyTorch and Hydra for flexible, configuration-driven deep learning workflows.

<!-- [![tests](https://github.com/ashleve/lightning-hydra-template/actions/workflows/test.yml/badge.svg)](https://github.com/ashleve/lightning-hydra-template/actions/workflows/test.yml)
[![codecov](https://codecov.io/gh/ashleve/lightning-hydra-template/branch/main/graph/badge.svg)](https://codecov.io/gh/ashleve/lightning-hydra-template)
[![PRs](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://github.com/ashleve/lightning-hydra-template/pulls) -->

<img src="./logo.png" width="500" alt="LitDet overview">

<!-- SPHINX-START-QUICKSTART-TITLE -->

## Quickstart

<!-- SPHINX-START-QUICKSTART -->

You will need at least `python 3.10` and a recent GPU driver (e.g. [NVIDIA 525.147.05](https://docs.nvidia.com/datacenter/tesla/tesla-release-notes-525-147-05/index.html)).

1. First install the package (best in a [python venv](https://docs.python.org/3/library/venv.html)).

   ```bash
   python -m pip install "litdet[extras]"
   ```

2. Train a Faster-RCNN on your dataset annotated in COCO format at `/path/to/your/dir/coco_dataset_name`:

   ```bash
   light-train task.model=faster-rcnn paths.data_dir=/path/to/your/dir data.data_name=coco_dataset_name task.model.num_classes=10 trainer.max_epochs=100
   ```

You can find configuration examples in the `/examples` directory.

To build your own configuration file instead, use our [cookiecutter](https://www.cookiecutter.io/templates):

```bash
cookiecutter https://gitlab.kitware.com/litdet/litdet.git --directory "cookiecutter-litdet"
```

<!-- SPHINX-END-QUICKSTART -->

For more information on the usage, configuration, API documentation, and getting started guides, refer to our [online documentation](https://litdet.readthedocs.io/en/latest).

## Developers

See [CONTRIBUTING](CONTRIBUTING.md) for developers instructions such as code practices, or the review process.
Check also our [advanced usage guide](https://litdet.readthedocs.io/en/advanced/configuration.html), and [debugging process](https://litdet.readthedocs.io/en/developper/debugging.html).

## Citation

<!-- SPHINX-START-CITATION -->

You can cite *LitDet* with the following:

```
@article{litdet2026tetrel,
  title={LitDet: Finetuning detection models has never been so easy},
  author={},
  journal={JOSS},
  year={2026}
}
```

<!-- SPHINX-END-CITATION -->

## Model Zoo

<!-- SPHINX-START-MODELZOO -->

The *LitDet* model zoo serves as a centralized hub for users and developers to discover models.

You can explore the complete list of available pre-trained models directly in [our GitLab repository](https://gitlab.kitware.com/litdet/model-zoo).

<!-- SPHINX-END-MODELZOO -->

## Acknowledgements

<!-- SPHINX-START-ACKNOWLEDGEMENTS -->

<!-- SPHINX-END-ACKNOWLEDGEMENTS -->
