import os
import logging
import shutil
import threading
from pathlib import Path
from typing import Optional, Dict, List
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import yaml

logger = logging.getLogger(__name__)


class SyncStatus(Enum):
    PENDING = "pending"
    SYNCING = "syncing"
    SYNCED = "synced"
    FAILED = "failed"


@dataclass
class SyncResult:
    subsystem: str
    commit: str
    version: str
    local_path: str
    status: SyncStatus
    error: Optional[str] = None


@dataclass
class CacheInfo:
    subsystem: str
    version: str
    commit: str
    size: int
    last_accessed: datetime
    local_path: str


class VersionMappingError(Exception):
    pass


class CodeSyncService:
    """代码同步服务 - 管理Git仓库克隆和代码拉取"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or self._load_config()
        
        cache_config = self.config.get('cache', {})
        cache_dir = cache_config.get('dir', 'state/code_cache')
        if not Path(cache_dir).is_absolute():
            cache_dir = Path('/app') / cache_dir
        self.cache_dir = Path(cache_dir)
        self.max_cache_size = cache_config.get('max_size_gb', 5) * 1024 * 1024 * 1024
        self.cleanup_delay = cache_config.get('cleanup_delay_seconds', 300)
        self.disk_threshold = cache_config.get('disk_threshold', 0.2)
        self.lru_enabled = cache_config.get('lru_enabled', True)
        
        git_config = self.config.get('git', {})
        self.git_timeout = git_config.get('timeout', 60)
        self.retry_count = git_config.get('retry_count', 3)
        self.clone_depth = git_config.get('clone_depth', 1)
        
        conf_man_config = self.config.get('conf_man', {})
        self.conf_man_api_url = os.environ.get('CONF_MAN_API_URL', os.environ.get('CONF_MAN_URL', conf_man_config.get('api_url', 'http://localhost:8002')))
        
        concurrency_config = self.config.get('concurrency', {})
        self.max_parallel_syncs = concurrency_config.get('max_parallel_syncs', 2)
        
        self._semaphore = threading.Semaphore(self.max_parallel_syncs)
        self._pending_cleanups: Dict[str, threading.Timer] = {}
        self._version_mapping: Dict = {}
        
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _load_config(self) -> Dict:
        """Load config from yaml file"""
        config_path = Path('/app/config/test_agent_v3.0.yaml')
        if config_path.exists():
            with open(config_path, 'r') as f:
                full_config = yaml.safe_load(f)
                return full_config.get('code_sync', {})
        return {}

    def sync_subsystem(
        self,
        name: str,
        version: Optional[str] = None,
        commit: Optional[str] = None
    ) -> SyncResult:
        """同步子系统代码"""
        
        with self._semaphore:
            logger.info(f"开始同步子系统: {name}, version={version}, commit={commit}")
            
            try:
                if commit:
                    resolved_commit = commit
                elif version:
                    resolved_commit = self.get_commit_from_version(name, version)
                else:
                    raise VersionMappingError(f"必须提供version或commit")
                
                local_path = self._get_cache_path(name, resolved_commit)
                
                if local_path.exists():
                    self._update_access_time(local_path)
                    logger.info(f"使用缓存: {local_path}")
                    return SyncResult(
                        subsystem=name,
                        commit=resolved_commit,
                        version=version or "unknown",
                        local_path=str(local_path),
                        status=SyncStatus.SYNCED
                    )
                
                result = self._clone_and_checkout(name, resolved_commit, version, local_path)
                
                if result.status == SyncStatus.SYNCED:
                    self._install_test_dependencies(str(local_path))
                    self._schedule_cleanup(name, resolved_commit)
                    self.check_disk_space()
                    self.enforce_cache_limit()
                
                return result
                
            except Exception as e:
                logger.error(f"同步失败: {name}, error={e}")
                return SyncResult(
                    subsystem=name,
                    commit=commit or version or "unknown",
                    version=version or "unknown",
                    local_path="",
                    status=SyncStatus.FAILED,
                    error=str(e)
                )

    def get_commit_from_version(self, subsystem: str, version: str) -> str:
        """版本号映射到Commit - 优先调用conf-man API"""
        
        try:
            commit = self._get_commit_from_conf_man(subsystem, version)
            if commit:
                logger.info(f"从conf-man获取版本映射: {subsystem}/{version} -> {commit}")
                return commit
        except Exception as e:
            logger.warning(f"conf-man API调用失败: {e}")
        
        commit = self._get_commit_from_config(subsystem, version)
        if commit:
            logger.info(f"从配置文件获取版本映射: {subsystem}/{version} -> {commit}")
            return commit
        
        logger.warning(f"未在conf-man或配置中找到版本映射，直接使用version作为分支名: {version}")
        return version

    def get_version_from_commit(self, subsystem: str, commit: str) -> str:
        """根据commit获取版本号"""
        
        cache_path = self._get_cache_path(subsystem, commit)
        if cache_path.exists():
            version_file = cache_path / ".version"
            if version_file.exists():
                return version_file.read_text().strip()
        
        version = self._get_version_from_config(subsystem, commit)
        if version:
            return version
        
        return "unknown"
    
    def _get_version_from_config(self, subsystem: str, commit: str) -> Optional[str]:
        """从配置文件反向查找版本号（根据commit）"""
        
        if not self._version_mapping:
            self._load_version_mapping()
        
        mappings = self._version_mapping.get('mappings', {})
        if subsystem in mappings:
            for version, mapped_commit in mappings[subsystem].items():
                if mapped_commit == commit:
                    return version
        return None

    def cleanup_code(self, subsystem_name: str) -> None:
        """清理指定子系统的缓存代码"""
        
        subsystem_dir = self.cache_dir / subsystem_name
        if subsystem_dir.exists():
            shutil.rmtree(subsystem_dir)
            logger.info(f"已清理缓存: {subsystem_name}")

    def enforce_cache_limit(self) -> int:
        """强制执行缓存上限，超出时LRU淘汰"""
        
        total_size = self._get_cache_total_size()
        if total_size <= self.max_cache_size:
            return 0
        
        cache_entries = self._get_all_cache_entries()
        cache_entries.sort(key=lambda x: x.last_accessed)
        
        target_size = self.max_cache_size * 0.8
        removed_count = 0
        
        for entry in cache_entries:
            if total_size <= target_size:
                break
            self._remove_cache_entry(entry)
            total_size -= entry.size
            removed_count += 1
        
        logger.info(f"LRU淘汰清理了{removed_count}个缓存条目")
        return removed_count

    def check_disk_space(self) -> bool:
        """检查磁盘空间，低于20%时返回False"""
        
        try:
            import psutil
            usage = psutil.disk_usage(str(self.cache_dir))
            if usage.percent >= (1 - self.disk_threshold) * 100:
                self._force_cleanup()
                return False
            return True
        except ImportError:
            logger.warning("psutil未安装，无法检查磁盘空间")
            return True

    def get_cache_info(self, subsystem: str) -> List[CacheInfo]:
        """获取缓存信息"""
        
        subsystem_dir = self.cache_dir / subsystem
        if not subsystem_dir.exists():
            return []
        
        entries = []
        for commit_dir in subsystem_dir.iterdir():
            if commit_dir.is_dir():
                size = self._get_dir_size(commit_dir)
                mtime = datetime.fromtimestamp(commit_dir.stat().st_mtime)
                version = self.get_version_from_commit(subsystem, commit_dir.name)
                entries.append(CacheInfo(
                    subsystem=subsystem,
                    version=version,
                    commit=commit_dir.name,
                    size=size,
                    last_accessed=mtime,
                    local_path=str(commit_dir)
                ))
        return entries

    def _get_commit_from_conf_man(self, subsystem: str, version: str) -> Optional[str]:
        """从conf-man API获取版本映射"""
        
        try:
            import requests
            url = f"{self.conf_man_api_url}/api/v1/versions?project_id={subsystem}&version={version}"
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                data = response.json()
                if isinstance(data, list):
                    versions = data
                else:
                    versions = data.get('versions', [])
                for v in versions:
                    if v.get('version') == version:
                        return v.get('git_commit_hash')
        except Exception as e:
            logger.warning(f"调用conf-man API失败: {e}")
        return None

    def _get_commit_from_config(self, subsystem: str, version: str) -> Optional[str]:
        """从配置文件获取版本映射"""
        
        if not self._version_mapping:
            self._load_version_mapping()
        
        mappings = self._version_mapping.get('mappings', {})
        if subsystem in mappings and version in mappings[subsystem]:
            return mappings[subsystem][version]
        return None

    def _load_version_mapping(self) -> None:
        """加载版本映射配置"""
        
        import os
        file_dir = os.path.dirname(os.path.abspath(__file__))
        base_dir = os.path.dirname(os.path.dirname(file_dir))
        config_file = Path(base_dir) / 'config' / 'version_mapping.yaml'
        if config_file.exists():
            with open(config_file, 'r') as f:
                self._version_mapping = yaml.safe_load(f) or {}

    def _get_cache_path(self, subsystem: str, commit: str) -> Path:
        """获取缓存路径 - 与sync API保持一致，使用/tests/{subsystem}"""
        return self.cache_dir / subsystem

    def _clone_and_checkout(
        self,
        subsystem: str,
        commit: str,
        version: Optional[str],
        local_path: Path
    ) -> SyncResult:
        """克隆并切换到指定版本"""
        
        try:
            subsystem_config = self._get_subsystem_config(subsystem)
            git_url = subsystem_config.get('git_url')
            
            if not git_url:
                raise ValueError(f"子系统{subsystem}未配置git_url")
            
            local_path.parent.mkdir(parents=True, exist_ok=True)
            
            import git
            repo = git.Repo.clone_from(
                git_url,
                str(local_path),
                depth=self.clone_depth,
                branch="main"
            )
            
            if commit:
                try:
                    repo.git.checkout(commit)
                except git.GitCommandError:
                    repo = git.Repo.clone_from(
                        git_url,
                        str(local_path),
                        depth=100,
                        branch="main"
                    )
                    repo.git.checkout(commit)
            
            resolved_version = version or self._get_version_from_config(subsystem, commit) or "unknown"
            version_file = local_path / ".version"
            version_file.write_text(resolved_version)
            
            logger.info(f"代码同步成功: {subsystem}/{commit}")
            return SyncResult(
                subsystem=subsystem,
                commit=commit,
                version=resolved_version,
                local_path=str(local_path),
                status=SyncStatus.SYNCED
            )
            
        except Exception as e:
            if local_path.exists():
                shutil.rmtree(local_path)
            logger.error(f"代码同步失败: {e}")
            return SyncResult(
                subsystem=subsystem,
                commit=commit,
                version="unknown",
                local_path="",
                status=SyncStatus.FAILED,
                error=str(e)
            )

    def _get_subsystem_config(self, subsystem: str) -> Dict:
        """获取子系统配置"""
        
        import os
        file_dir = os.path.dirname(os.path.abspath(__file__))
        base_dir = os.path.dirname(os.path.dirname(file_dir))
        config_file = Path(base_dir) / 'config' / 'subsystems.yaml'
        if config_file.exists():
            with open(config_file, 'r') as f:
                data = yaml.safe_load(f) or {}
                subsystems = data.get('subsystems', {})
                if subsystem in subsystems:
                    return subsystems[subsystem]
        return {}

    def _install_test_dependencies(self, local_path: str) -> None:
        """安装测试依赖 - 检查requirements-test.txt并安装"""
        
        req_file = Path(local_path) / "requirements-test.txt"
        
        if not req_file.exists():
            req_file = Path(local_path) / "requirements.txt"
            if not req_file.exists():
                logger.info(f"无requirements-test.txt和requirements.txt，跳过: {local_path}")
                return
            else:
                logger.info(f"无requirements-test.txt，使用requirements.txt: {req_file}")
        
        try:
            import subprocess
            logger.info(f"安装测试依赖: {req_file}")
            
            result = subprocess.run(
                ["pip", "install", "-r", str(req_file), "--quiet"],
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode == 0:
                logger.info(f"测试依赖安装成功: {req_file}")
            else:
                logger.warning(f"测试依赖安装警告: {result.stderr}")
                
        except Exception as e:
            logger.warning(f"安装测试依赖失败: {e}")

    def _get_cache_total_size(self) -> int:
        """获取缓存总大小"""
        
        total = 0
        if self.cache_dir.exists():
            for root, dirs, files in os.walk(self.cache_dir):
                for f in files:
                    fp = os.path.join(root, f)
                    total += os.path.getsize(fp)
        return total

    def _get_all_cache_entries(self) -> List[CacheInfo]:
        """获取所有缓存条目"""
        
        entries = []
        if self.cache_dir.exists():
            for subsystem_dir in self.cache_dir.iterdir():
                if subsystem_dir.is_dir():
                    entries.extend(self.get_cache_info(subsystem_dir.name))
        return entries

    def _remove_cache_entry(self, entry: CacheInfo) -> None:
        """删除缓存条目"""
        
        path = Path(entry.local_path)
        if path.exists():
            shutil.rmtree(path)
            logger.info(f"删除缓存: {entry.subsystem}/{entry.commit}")

    def _get_dir_size(self, path: Path) -> int:
        """获取目录大小"""
        
        total = 0
        for root, dirs, files in os.walk(path):
            for f in files:
                fp = os.path.join(root, f)
                total += os.path.getsize(fp)
        return total

    def _update_access_time(self, path: Path) -> None:
        """更新访问时间"""
        
        os.utime(path, None)

    def _schedule_cleanup(self, subsystem: str, commit: str) -> None:
        """安排延迟清理"""
        
        key = f"{subsystem}/{commit}"
        if key in self._pending_cleanups:
            self._pending_cleanups[key].cancel()
        
        timer = threading.Timer(
            self.cleanup_delay,
            self.cleanup_code,
            args=(subsystem,)
        )
        self._pending_cleanups[key] = timer
        timer.start()

    def _force_cleanup(self) -> None:
        """强制清理：删除最旧的50%缓存"""
        
        cache_entries = self._get_all_cache_entries()
        cache_entries.sort(key=lambda x: x.last_accessed)
        
        delete_count = len(cache_entries) // 2
        for entry in cache_entries[:delete_count]:
            self._remove_cache_entry(entry)
        
        logger.warning(f"磁盘空间不足，强制清理了{delete_count}个缓存条目")
