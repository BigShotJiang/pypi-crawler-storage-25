"""
代码同步API路由
"""
import os
import shutil
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter
from pydantic import BaseModel
import logging

router = APIRouter(prefix="/sync", tags=["sync"])
logger = logging.getLogger(__name__)

BASE_DIR = Path(os.getenv("TEST_AGENT_BASE_DIR", "/app"))
SYSTEMS_DIR = BASE_DIR / "systems"
TESTS_DIR = BASE_DIR / "tests"
DOCS_DIR = BASE_DIR / "docs"

SYSTEMS_DIR.mkdir(parents=True, exist_ok=True)
TESTS_DIR.mkdir(parents=True, exist_ok=True)
DOCS_DIR.mkdir(parents=True, exist_ok=True)


class SyncRequest(BaseModel):
    project: str
    version: str
    git_url: str
    commit: Optional[str] = None
    sync_paths: Optional[List[str]] = None


class SyncTestsRequest(BaseModel):
    project: str
    version: str
    git_url: str
    commit: Optional[str] = None
    sync_paths: Optional[List[str]] = None


class SyncDocsRequest(BaseModel):
    project: str
    version: str
    git_url: str
    docs_type: str = "all"


class SyncResponse(BaseModel):
    success: bool
    data: Optional[dict] = None
    error: Optional[dict] = None


def validate_git_url(git_url: str) -> bool:
    """验证git_url安全性，只允许白名单域名"""
    allowed_domains = os.getenv("GIT_URL_ALLOWED_DOMAINS", "github.com,gitee.com,8.149.137.233").split(",")
    allowed_domains = [d.strip().lower() for d in allowed_domains]
    
    try:
        # SSH格式: git@gitee.com:user/repo.git
        if git_url.startswith("git@"):
            parts = git_url.split(":")
            if len(parts) >= 2:
                host = parts[0].replace("git@", "")
                return any(host.endswith(d) for d in allowed_domains)
        
        # SSH格式: ssh://git@host:port/path 或 https://host/path
        from urllib.parse import urlparse
        parsed = urlparse(git_url)
        hostname = parsed.hostname.lower() if parsed.hostname else ""
        return any(hostname.endswith(d) for d in allowed_domains)
    except Exception:
        return False


def get_file_count(path: Path) -> int:
    """获取目录下的文件数量"""
    if not path.exists():
        return 0
    return sum(1 for _ in path.rglob("*") if _.is_file())


def resolve_version_to_tag(version: str, path: Path) -> Optional[str]:
    """尝试将版本号解析为git tag"""
    if not version:
        return None
    try:
        result = subprocess.run(
            ["git", "fetch", "--tags"],
            capture_output=True,
            text=True,
            timeout=30,
            cwd=path
        )
        if result.returncode != 0:
            logger.warning(f"fetch tags failed: {result.stderr}")
        
        result = subprocess.run(
            ["git", "rev-parse", version],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=path
        )
        if result.returncode == 0:
            tag = result.stdout.strip()
            logger.info(f"Resolved {version} to {tag}")
            return tag
        return None
    except Exception as e:
        logger.warning(f"Failed to resolve version {version}: {e}")
        return None


def clone_repo(git_url: str, path: Path, commit: Optional[str] = None, sync_paths: Optional[List[str]] = None) -> tuple:
    """克隆或更新仓库，返回(成功, 文件数, 错误信息)
    
    Args:
        git_url: Git仓库URL
        path: 本地目标路径
        commit: 指定commit hash（可选）
        sync_paths: 稀疏检出目录列表（可选），如 ["src", "tests"]
                   当指定时使用 git sparse-checkout，只克隆指定目录
    """
    if not validate_git_url(git_url):
        return False, 0, "Git URL not allowed: domain not in whitelist"
    
    try:
        git_dir = path / ".git"
        is_git_repo = path.exists() and git_dir.exists()
        
        if not is_git_repo:
            if path.exists():
                shutil.rmtree(path)
            
            if sync_paths:
                result = subprocess.run(
                    ["git", "clone", "--filter=blob:none", "--sparse", git_url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if result.returncode != 0:
                    return False, 0, result.stderr
                
                result = subprocess.run(
                    ["git", "sparse-checkout", "set"] + sync_paths,
                    capture_output=True,
                    text=True,
                    timeout=60,
                    cwd=path
                )
                if result.returncode != 0:
                    return False, 0, f"sparse-checkout failed: {result.stderr}"
            elif commit:
                result = subprocess.run(
                    ["git", "clone", git_url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if result.returncode != 0:
                    return False, 0, result.stderr
            else:
                result = subprocess.run(
                    ["git", "clone", "--depth", "1", git_url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if result.returncode != 0:
                    return False, 0, result.stderr
        else:
            if path.exists():
                shutil.rmtree(path)
            
            if sync_paths:
                result = subprocess.run(
                    ["git", "clone", "--filter=blob:none", "--sparse", git_url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if result.returncode != 0:
                    return False, 0, result.stderr
                
                result = subprocess.run(
                    ["git", "sparse-checkout", "set"] + sync_paths,
                    capture_output=True,
                    text=True,
                    timeout=60,
                    cwd=path
                )
                if result.returncode != 0:
                    return False, 0, f"sparse-checkout failed: {result.stderr}"
            elif commit:
                result = subprocess.run(
                    ["git", "clone", git_url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if result.returncode != 0:
                    return False, 0, result.stderr
            else:
                result = subprocess.run(
                    ["git", "clone", "--depth", "1", git_url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                if result.returncode != 0:
                    return False, 0, result.stderr

        if commit:
            result = subprocess.run(
                ["git", "checkout", commit],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=path
            )
            if result.returncode != 0:
                logger.warning(f"checkout {commit} failed: {result.stderr}")
        else:
            subprocess.run(
                ["git", "reset", "--hard", "origin/main"],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=path
            )

        files_count = get_file_count(path)
        sync_type = "sparse" if sync_paths else "full"
        logger.info(f"Clone completed: type={sync_type}, paths={sync_paths}, files={files_count}")
        return True, files_count, None
    except subprocess.TimeoutExpired:
        return False, 0, "Git operation timeout"
    except Exception as e:
        return False, 0, str(e)


def save_sync_record(sync_type: str, project: str, version: str, 
                     git_url: str, path: str, files_synced: int, 
                     commit: Optional[str] = None, status: str = "success"):
    """保存同步记录到数据库"""
    db_path = BASE_DIR / "state" / "sync_records.db"
    import sqlite3
    
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sync_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project TEXT NOT NULL,
            version TEXT NOT NULL,
            sync_type TEXT NOT NULL,
            git_url TEXT NOT NULL,
            commit_hash TEXT,
            path TEXT NOT NULL,
            files_synced INTEGER DEFAULT 0,
            status TEXT DEFAULT 'success',
            synced_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.execute("""
        INSERT INTO sync_records (project, version, sync_type, git_url, commit_hash, path, files_synced, status, synced_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (project, version, sync_type, git_url, commit, path, files_synced, status, datetime.now().isoformat()))
    
    conn.commit()
    conn.close()


def update_test_dispatcher(project: str, sync_type: str, path: str):
    """更新test_dispatcher.yaml配置 - 只在项目首次出现时添加"""
    config_path = BASE_DIR / "config" / "test_dispatcher.yaml"
    if not config_path.exists():
        return
    
    import yaml
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f) or {}
    
    if "test_paths" not in config:
        config["test_paths"] = {}
    
    # 只在项目不存在时才添加，避免覆盖已有正确配置
    if project not in config["test_paths"]:
        if sync_type == "test":
            # 同步目录 + tests 子目录
            rel_path = path.replace(str(BASE_DIR) + "/", "")
            sync_test_path = f"{rel_path}/tests/"
            config["test_paths"][project] = [sync_test_path]
            with open(config_path, 'w') as f:
                yaml.dump(config, f)


@router.post("", response_model=SyncResponse)
async def sync_target(request: SyncRequest):
    """同步目标系统代码
    
    支持 sparse checkout，可通过 sync_paths 指定只同步特定目录
    """
    project = request.project
    version = request.version
    git_url = request.git_url
    commit = request.commit
    sync_paths = request.sync_paths
    
    target_path = SYSTEMS_DIR / project
    success, files_count, error = clone_repo(git_url, target_path, commit, sync_paths)
    
    if success:
        actual_commit = commit or "latest"
        sync_type = "sparse" if sync_paths else "target"
        save_sync_record(sync_type, project, version, git_url, str(target_path), files_count, actual_commit)
        return SyncResponse(
            success=True,
            data={
                "project": project,
                "version": version,
                "sync_type": sync_type,
                "path": str(target_path),
                "files_synced": files_count,
                "commit_hash": actual_commit,
                "sync_paths": sync_paths,
                "synced_at": datetime.now().isoformat()
            }
        )
    else:
        save_sync_record("target", project, version, git_url, str(target_path), 0, commit or "", status="failed")
        return SyncResponse(
            success=False,
            error={
                "code": 500,
                "message": "Git clone failed",
                "detail": error
            }
        )


@router.post("/tests", response_model=SyncResponse)
async def sync_tests(request: SyncTestsRequest):
    """同步测试用例代码
    
    支持 sparse checkout，可通过 sync_paths 指定只同步特定目录
    """
    project = request.project
    version = request.version
    git_url = request.git_url
    commit = request.commit
    sync_paths = request.sync_paths
    
    target_path = TESTS_DIR / project
    
    if target_path.exists():
        shutil.rmtree(target_path)
    
    if not commit and version:
        temp_path = BASE_DIR / "temp_clone_check"
        if temp_path.exists():
            shutil.rmtree(temp_path)
        subprocess.run(
            ["git", "clone", "--depth", "1", "--branch", version, git_url, str(temp_path)],
            capture_output=True,
            timeout=60
        )
        if temp_path.exists():
            resolved = resolve_version_to_tag(version, temp_path)
            if resolved:
                commit = resolved
                logger.info(f"Resolved version {version} to commit {commit}")
            shutil.rmtree(temp_path)
    
    success, files_count, error = clone_repo(git_url, target_path, commit, sync_paths)
    
    if success:
        actual_commit = commit or "latest"
        sync_type = "sparse" if sync_paths else "test"
        save_sync_record(sync_type, project, version, git_url, str(target_path), files_count, actual_commit)
        update_test_dispatcher(project, "test", str(target_path))
        return SyncResponse(
            success=True,
            data={
                "project": project,
                "version": version,
                "sync_type": sync_type,
                "path": str(target_path),
                "files_synced": files_count,
                "commit_hash": actual_commit,
                "sync_paths": sync_paths,
                "synced_at": datetime.now().isoformat()
            }
        )
    else:
        save_sync_record("test", project, version, git_url, str(target_path), 0, commit or "", status="failed")
        return SyncResponse(
            success=False,
            error={
                "code": 500,
                "message": "Git clone failed",
                "detail": error
            }
        )


@router.post("/docs", response_model=SyncResponse)
async def sync_docs(request: SyncDocsRequest):
    """同步需求和设计文档"""
    project = request.project
    version = request.version
    git_url = request.git_url
    docs_type = request.docs_type
    
    target_path = DOCS_DIR / project
    success, files_count, error = clone_repo(git_url, target_path, None)
    
    if success:
        requirements = []
        designs = []
        
        docs_path = target_path / "docs"
        if docs_path.exists():
            requirements = [str(p.name) for p in docs_path.rglob("REQUIREMENT_*.md")]
            designs = [str(p.name) for p in docs_path.rglob("DESIGN_*.md")]
        
        save_sync_record("docs", project, version, git_url, str(target_path), files_count, None)
        return SyncResponse(
            success=True,
            data={
                "project": project,
                "version": version,
                "sync_type": "docs",
                "path": str(target_path),
                "files_synced": files_count,
                "commit_hash": "",
                "requirements": requirements,
                "designs": designs,
                "synced_at": datetime.now().isoformat()
            }
        )
    else:
        save_sync_record("docs", project, version, git_url, str(target_path), 0, "", status="failed")
        return SyncResponse(
            success=False,
            error={
                "code": 500,
                "message": "Git clone failed",
                "detail": error
            }
        )


class CleanupRequest(BaseModel):
    project: str
    sync_type: str = "test"
    confirm: bool = False


@router.post("/cleanup", response_model=SyncResponse)
async def cleanup_project(request: CleanupRequest):
    """清理指定项目的同步目录（删除旧文件）
    
    注意：需要 confirm=true 才能执行清理，防止误操作
    """
    if not request.confirm:
        return SyncResponse(
            success=False,
            error={
                "code": 400,
                "message": "Cleanup not executed: confirm must be true",
                "detail": "Set confirm=true to actually cleanup"
            }
        )
    
    project = request.project
    sync_type = request.sync_type
    
    if sync_type == "test":
        target_path = TESTS_DIR / project
    elif sync_type == "target":
        target_path = SYSTEMS_DIR / project
    elif sync_type == "docs":
        target_path = DOCS_DIR / project
    else:
        return SyncResponse(
            success=False,
            error={
                "code": 400,
                "message": f"Invalid sync_type: {sync_type}",
                "detail": "sync_type must be one of: test, target, docs"
            }
        )
    
    if not target_path.exists():
        return SyncResponse(
            success=False,
            error={
                "code": 404,
                "message": f"Path not found: {target_path}",
                "detail": f"Project {project} ({sync_type}) has not been synced yet"
            }
        )
    
    try:
        import time
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_path = target_path.parent / f"{project}_{sync_type}_backup_{timestamp}"
        shutil.copytree(target_path, backup_path)
        
        shutil.rmtree(target_path)
        target_path.mkdir(parents=True, exist_ok=True)
        
        return SyncResponse(
            success=True,
            data={
                "project": project,
                "sync_type": sync_type,
                "cleanup_path": str(target_path),
                "backup_path": str(backup_path),
                "cleanup_at": datetime.now().isoformat()
            }
        )
    except Exception as e:
        return SyncResponse(
            success=False,
            error={
                "code": 500,
                "message": "Cleanup failed",
                "detail": str(e)
            }
        )
