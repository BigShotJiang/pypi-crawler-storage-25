"""Health check route - No authentication required"""

from pathlib import Path
from fastapi import APIRouter

router = APIRouter()

def _load_version() -> str:
    """Load version from pyproject.toml"""
    pyproject_path = Path('/app/pyproject.toml')
    if pyproject_path.exists():
        try:
            content = pyproject_path.read_text()
            for line in content.split('\n'):
                if line.startswith('version ='):
                    return line.split('=')[1].strip().strip('"').strip("'")
        except Exception:
            pass
    return "unknown"

API_VERSION = _load_version()


@router.get("/health")
async def health_check():
    """Health check endpoint - no authentication required"""
    return {
        "status": "ok",
        "version": API_VERSION
    }
