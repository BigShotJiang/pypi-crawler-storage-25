"""Sage core modules.

This package contains the core functionality for SAGE:
- Discovery: File and project discovery
- Task prioritization: Intelligent task ordering
- Prompts: System prompts and templates
- Validation: Code and content validation
- Shell: Safe shell execution utilities
- Project: Project structure detection
- Languages: Language and framework detection
- Commands: Safe command execution
- Dependencies: Dependency graph management
- Awareness: Repository awareness tracking
- Diagnostics: LSP and static analysis
- Prioritization: Autopolit task prioritization
- Security: Security auditing
- Swarm: Multi-agent orchestration
- Tools: Tool execution framework
- Checkpoint: Time travel checkpoint management
"""

from sage.core.discovery import (
    FileDiscovery,
    DiscoveryResult,
    ProjectInfo,
    discover_files,
    discover_modules,
)
from sage.core.task_priority import (
    TaskPrioritizer,
    TaskCategory,
    CheckClass,
    PrioritizedTask,
)
from sage.core.prompts import (
    CHAIN_OF_THOUGHT_INSTRUCTIONS,
    AGENT_SYSTEM_PROMPT_TEMPLATE,
    LOCAL_AGENT_SYSTEM_PROMPT_TEMPLATE,
    build_agent_system_prompt,
)
from sage.core.validation import (
    validate_python_syntax,
    validate_json_syntax,
    pre_validate_content,
    extract_imports_from_python,
    pending_modules_for_files,
    module_exists_in_codebase,
    validate_imports_in_content,
    is_likely_hallucinated_code,
    is_garbage_content,
    STDLIB_MODULES,
    COMMON_PACKAGES,
    LIKELY_HALLUCINATED_PATTERNS,
)
from sage.core.shell import (
    extract_scoped_prefix,
    resolve_scoped_directory,
    run_shell,
    shell_quote,
    extract_bash_blocks,
    sanitize_shell_block,
    strip_search_comment,
    read_file_context,
)
from sage.core.project import (
    detect_test_files,
    detect_runnable_files,
    discover_workspace_project_roots,
    project_root_score,
    default_project_root,
    discover_npm_script,
    discover_python_test_command,
    discover_project_test_command,
    discover_project_full_test_command,
    discover_project_root_for_file,
    command_from_project_root,
    validation_command_for_written_files,
    PROJECT_MARKERS,
    SKIP_DIRS,
)

# New P1-P3 modules
from sage.core.languages import (
    Language,
    PackageManager,
    TestFramework,
    BuildTool,
    Framework,
    LanguageInfo,
    ProjectManifest,
    DetectionResult,
    detect_languages,
    detect_project_manifest,
    detect_test_framework,
    detect_build_command,
    detect_lint_command,
    detect_format_command,
    detect_type_check_command,
    detect_frameworks,
    get_syntax_check_command,
    get_language_for_extension,
)
from sage.core.commands import (
    CommandCategory,
    CommandRisk,
    ParsedCommand,
    CommandResult,
    CommandValidation,
    parse_command,
    validate_command,
    execute_command,
    execute_argv,
    is_command_allowed,
    get_allowed_commands,
    build_test_command,
    build_lint_command,
    build_build_command,
    ALLOWED_EXECUTABLES,
    BLOCKED_PATTERNS,
    DANGEROUS_FLAGS,
)
from sage.core.dependencies import (
    FileNode as DepFileNode,
    ImportInfo,
    DependencyGraph,
    get_imports_for_file,
)
from sage.core.awareness import (
    ScanCoverage,
    RepoAwareness,
    AwarenessContext,
    build_awareness_context,
)
from sage.core.diagnostics import (
    Diagnostic,
    DiagnosticSeverity,
    DiagnosticResult,
    DiagnosticsClient,
)
from sage.core.prioritization import (
    PrioritizedTask as AutopolitTask,
    TaskPrioritizer as AutopolitPrioritizer,
    AutopolitState,
    FlakeyTestTracker,
    CIFailureAnalyzer,
)
from sage.core.security import (
    SecurityFinding,
    SecurityAuditor,
    SecuritySeverity,
)
from sage.core.swarm import (
    TaskType as SwarmTaskType,
    SwarmTask,
    ModelProfile,
    SwarmOrchestrator,
    SwarmResult,
)
from sage.core.tools import (
    ToolType,
    ToolResult,
    ToolContext,
    ToolExecutor,
    FileWriteTool,
    FileReadTool,
    ShellTool,
    SearchTool,
    WebFetchTool,
)
from sage.core.checkpoint import (
    FileChange,
    Checkpoint,
    CheckpointManager,
    RestoreResult,
)

__all__ = [
    # Discovery
    "FileDiscovery",
    "DiscoveryResult",
    "ProjectInfo",
    "discover_files",
    "discover_modules",
    # Task prioritization (original)
    "TaskPrioritizer",
    "TaskCategory",
    "CheckClass",
    "PrioritizedTask",
    # Prompts
    "CHAIN_OF_THOUGHT_INSTRUCTIONS",
    "AGENT_SYSTEM_PROMPT_TEMPLATE",
    "LOCAL_AGENT_SYSTEM_PROMPT_TEMPLATE",
    "build_agent_system_prompt",
    # Validation
    "validate_python_syntax",
    "validate_json_syntax",
    "pre_validate_content",
    "extract_imports_from_python",
    "pending_modules_for_files",
    "module_exists_in_codebase",
    "validate_imports_in_content",
    "is_likely_hallucinated_code",
    "is_garbage_content",
    "STDLIB_MODULES",
    "COMMON_PACKAGES",
    "LIKELY_HALLUCINATED_PATTERNS",
    # Shell utilities
    "extract_scoped_prefix",
    "resolve_scoped_directory",
    "run_shell",
    "shell_quote",
    "extract_bash_blocks",
    "sanitize_shell_block",
    "strip_search_comment",
    "read_file_context",
    # Project discovery
    "detect_test_files",
    "detect_runnable_files",
    "discover_workspace_project_roots",
    "project_root_score",
    "default_project_root",
    "discover_npm_script",
    "discover_python_test_command",
    "discover_project_test_command",
    "discover_project_full_test_command",
    "discover_project_root_for_file",
    "command_from_project_root",
    "validation_command_for_written_files",
    "PROJECT_MARKERS",
    "SKIP_DIRS",
    # Languages and frameworks (P1)
    "Language",
    "PackageManager",
    "TestFramework",
    "BuildTool",
    "Framework",
    "LanguageInfo",
    "ProjectManifest",
    "DetectionResult",
    "detect_languages",
    "detect_project_manifest",
    "detect_test_framework",
    "detect_build_command",
    "detect_lint_command",
    "detect_format_command",
    "detect_type_check_command",
    "detect_frameworks",
    "get_syntax_check_command",
    "get_language_for_extension",
    # Safe commands (P0)
    "CommandCategory",
    "CommandRisk",
    "ParsedCommand",
    "CommandResult",
    "CommandValidation",
    "parse_command",
    "validate_command",
    "execute_command",
    "execute_argv",
    "is_command_allowed",
    "get_allowed_commands",
    "build_test_command",
    "build_lint_command",
    "build_build_command",
    "ALLOWED_EXECUTABLES",
    "BLOCKED_PATTERNS",
    "DANGEROUS_FLAGS",
    # Dependencies (P0)
    "DepFileNode",
    "ImportInfo",
    "DependencyGraph",
    "get_imports_for_file",
    # Awareness (P0)
    "ScanCoverage",
    "RepoAwareness",
    "AwarenessContext",
    "build_awareness_context",
    # Diagnostics (P1)
    "Diagnostic",
    "DiagnosticSeverity",
    "DiagnosticResult",
    "DiagnosticsClient",
    # Prioritization (P1)
    "AutopolitTask",
    "AutopolitPrioritizer",
    "AutopolitState",
    "FlakeyTestTracker",
    "CIFailureAnalyzer",
    # Security (P3)
    "SecurityFinding",
    "SecurityAuditor",
    "SecuritySeverity",
    # Swarm (P3)
    "SwarmTaskType",
    "SwarmTask",
    "ModelProfile",
    "SwarmOrchestrator",
    "SwarmResult",
    # Tools (P3)
    "ToolType",
    "ToolResult",
    "ToolContext",
    "ToolExecutor",
    "FileWriteTool",
    "FileReadTool",
    "ShellTool",
    "SearchTool",
    "WebFetchTool",
    # Checkpoint (P0)
    "FileChange",
    "Checkpoint",
    "CheckpointManager",
    "RestoreResult",
]
