"""Terminal rendering — Rich markdown, code highlighting, streaming display, status indicators."""

from __future__ import annotations

import signal
import sys
import time
from contextlib import contextmanager
from typing import Iterator

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from rich.spinner import Spinner
from rich.columns import Columns
from rich.rule import Rule
from rich.table import Table
from rich.progress import Progress, BarColumn, TextColumn, SpinnerColumn, TaskID


console = Console()
err_console = Console(stderr=True)


# ── Phase & Status Display ─────────────────────────────────


# Phase icons and colors for the agent workflow
_PHASE_STYLES = {
    "thinking": ("bold yellow", "⟡"),
    "planning": ("bold blue", "◈"),
    "reading": ("bold cyan", "◉"),
    "coding": ("bold magenta", "◆"),
    "writing": ("bold green", "▶"),
    "testing": ("bold yellow", "⧫"),
    "fixing": ("bold red", "⟐"),
    "executing": ("bold cyan", "▷"),
    "validating": ("bold yellow", "◇"),
    "done": ("bold green", "✓"),
    "error": ("bold red", "✗"),
}


def phase(name: str, detail: str = "") -> None:
    """Print a phase indicator with icon and optional detail."""
    style, icon = _PHASE_STYLES.get(name, ("dim", "·"))
    detail_str = f"  [dim]{detail}[/dim]" if detail else ""
    console.print(f"  [{style}]{icon} {name.capitalize()}[/{style}]{detail_str}")


@contextmanager
def status_spinner(message: str, phase_name: str = "thinking"):
    """Context manager that shows a Rich spinner with a message.

    Usage:
        with status_spinner("Analyzing your request..."):
            do_work()
    """
    style, icon = _PHASE_STYLES.get(phase_name, ("dim", "·"))
    spinner = Spinner(
        "dots", text=Text.from_markup(f"  [{style}]{icon} {message}[/{style}]")
    )
    with Live(spinner, console=console, refresh_per_second=12, transient=True):
        yield


def step(number: int, total: int, description: str, style: str = "bold cyan") -> None:
    """Print a numbered step indicator."""
    console.print(
        f"  [{style}]Step {number}/{total}[/{style}] [dim]─[/dim] {description}"
    )


def step_done(description: str) -> None:
    """Print a completed step."""
    console.print(f"  [green]✓[/green] {description}")


def step_fail(description: str) -> None:
    """Print a failed step."""
    console.print(f"  [red]✗[/red] {description}")


def divider(title: str = "", style: str = "dim") -> None:
    """Print a horizontal divider."""
    if title:
        console.print(Rule(title, style=style))
    else:
        console.print(Rule(style=style))


# ── Streaming with stats ───────────────────────────────────

# Streaming buffer settings for optimal performance
_STREAM_BUFFER_SIZE = 8  # Flush after this many tokens
_STREAM_FLUSH_INTERVAL = 0.05  # Or flush after this many seconds


def stream_tokens(tokens: Iterator[str], show_stats: bool = True) -> str:
    """Print tokens to stdout in real-time and return the full text.

    Uses buffered output with periodic flushes for better performance
    while maintaining responsiveness. Flushes every 8 tokens or 50ms.

    Tracks timing and token count for display after streaming completes.
    Ctrl+C cancels generation and returns what was collected so far.
    """
    parts: list[str] = []
    token_count = 0
    t0 = time.monotonic()
    last_flush = t0
    buffer: list[str] = []
    cancelled = False

    def _flush_buffer() -> None:
        nonlocal last_flush
        if buffer:
            sys.stdout.write("".join(buffer))
            sys.stdout.flush()
            buffer.clear()
            last_flush = time.monotonic()

    try:
        for token in tokens:
            buffer.append(token)
            parts.append(token)
            token_count += 1

            # Flush on buffer size or time interval
            now = time.monotonic()
            if len(buffer) >= _STREAM_BUFFER_SIZE or (now - last_flush) >= _STREAM_FLUSH_INTERVAL:
                _flush_buffer()

    except KeyboardInterrupt:
        cancelled = True

    # Final flush
    _flush_buffer()

    elapsed = time.monotonic() - t0
    sys.stdout.write("\n")
    sys.stdout.flush()

    if cancelled:
        console.print("  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
    elif show_stats and token_count > 0 and elapsed > 0.1:
        tps = token_count / elapsed if elapsed > 0 else 0
        console.print(
            f"  [dim]─ {token_count} tokens · {elapsed:.1f}s · {tps:.0f} tok/s[/dim]"
        )

    return "".join(parts)


def stream_tokens_with_phase(tokens: Iterator[str], model_id: str = "") -> str:
    """Stream tokens with a thinking spinner that transitions to output.

    Shows 'Thinking...' spinner until first token arrives, then streams normally.
    Uses buffered output with periodic flushes for better performance.
    Ctrl+C cancels generation at any point — during thinking or streaming.

    Uses a SIGINT handler to reliably catch Ctrl+C even inside Rich.Live,
    which can swallow KeyboardInterrupt in its refresh thread.
    """
    parts: list[str] = []
    buffer: list[str] = []
    token_count = 0
    t0 = time.monotonic()
    last_flush = t0
    first_token_time = None
    cancelled = False

    def _flush_buffer() -> None:
        nonlocal last_flush
        if buffer:
            sys.stdout.write("".join(buffer))
            sys.stdout.flush()
            buffer.clear()
            last_flush = time.monotonic()

    # Install a SIGINT handler that sets a flag — Rich.Live can swallow
    # KeyboardInterrupt, but our handler always fires.
    _sigint_received = False
    _original_handler = signal.getsignal(signal.SIGINT)

    def _handle_sigint(signum, frame):
        nonlocal _sigint_received
        _sigint_received = True

    signal.signal(signal.SIGINT, _handle_sigint)

    # Show thinking spinner
    spinner = Spinner(
        "dots",
        text=Text.from_markup(
            f"  [bold yellow]⟡ Thinking...[/bold yellow]  [dim](Ctrl+C to cancel)[/dim]"
            + (f"  [dim]({model_id})[/dim]" if model_id else "")
        ),
    )
    live = Live(spinner, console=console, refresh_per_second=12, transient=True)
    live.start()

    try:
        for token in tokens:
            if _sigint_received:
                cancelled = True
                break

            if first_token_time is None:
                first_token_time = time.monotonic()
                # Kill the spinner, print the sage prompt
                live.stop()
                ttft = first_token_time - t0
                console.print(f"  [dim]─ First token in {ttft:.1f}s[/dim]")
                console.print("[bold green]sage>[/bold green] ", end="")

            buffer.append(token)
            parts.append(token)
            token_count += 1

            # Buffered flush for better performance
            now = time.monotonic()
            if len(buffer) >= _STREAM_BUFFER_SIZE or (now - last_flush) >= _STREAM_FLUSH_INTERVAL:
                _flush_buffer()

            if _sigint_received:
                cancelled = True
                break
    except KeyboardInterrupt:
        cancelled = True
    finally:
        if live.is_started:
            live.stop()
        # Restore the original signal handler
        signal.signal(signal.SIGINT, _original_handler)

    # Final flush
    _flush_buffer()

    elapsed = time.monotonic() - t0
    sys.stdout.write("\n")
    sys.stdout.flush()

    if cancelled:
        console.print("  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
    elif token_count > 0 and elapsed > 0.1:
        tps = token_count / elapsed if elapsed > 0 else 0
        console.print(
            f"  [dim]─ {token_count} tokens · {elapsed:.1f}s · {tps:.0f} tok/s[/dim]"
        )

    return "".join(parts)


# ── File operation display ─────────────────────────────────


def print_files_written(files: list[str]) -> None:
    """Print a styled list of written files."""
    console.print()
    phase("writing", f"{len(files)} file(s)")
    for f in files:
        console.print(f"    [green]+ {f}[/green]")


def print_files_deleted(files: list[str]) -> None:
    """Print a styled list of deleted files."""
    for f in files:
        console.print(f"    [red]- {f}[/red]")


def print_file_read(filepath: str, line_count: int) -> None:
    """Print a styled file-read indicator."""
    phase("reading", f"{filepath} ({line_count} lines)")


# ── Test result display ────────────────────────────────────


def print_test_results(output: str, passed: bool) -> None:
    """Print test results with pass/fail styling."""
    if passed:
        console.print()
        phase("done", "All tests passed")
        # Extract summary line if present
        for line in output.splitlines():
            if "passed" in line.lower():
                console.print(f"    [green]{line.strip()}[/green]")
                break
    else:
        console.print()
        phase("error", "Tests failed")
        # Show the failure summary
        in_failures = False
        shown = 0
        for line in output.splitlines():
            if "FAILED" in line or "ERROR" in line:
                console.print(f"    [red]{line.strip()}[/red]")
                shown += 1
            elif "short test summary" in line.lower():
                in_failures = True
            elif in_failures and line.strip() and shown < 10:
                console.print(f"    [red]{line.strip()}[/red]")
                shown += 1


def print_validation_start(cmd: str) -> None:
    """Print the start of a validation step."""
    console.print()
    phase("validating", cmd)


def print_retry(attempt: int, max_retries: int) -> None:
    """Print a retry indicator."""
    console.print()
    phase("fixing", f"Auto-fixing (attempt {attempt}/{max_retries})")


# ── Command execution display ──────────────────────────────


def print_shell_start(cmd: str) -> None:
    """Print shell command being executed."""
    phase("executing", cmd[:100] + ("..." if len(cmd) > 100 else ""))


def print_shell_output(output: str, max_lines: int = 30) -> None:
    """Print shell output, truncated if too long."""
    lines = output.splitlines()
    if len(lines) > max_lines:
        for line in lines[:10]:
            console.print(f"    [dim]{line}[/dim]")
        console.print(f"    [dim]... ({len(lines) - 20} lines hidden) ...[/dim]")
        for line in lines[-10:]:
            console.print(f"    [dim]{line}[/dim]")
    else:
        for line in lines:
            console.print(f"    [dim]{line}[/dim]")


# ── Existing functions (upgraded) ──────────────────────────


def render_markdown(text: str) -> None:
    """Render a complete response as Rich Markdown with code highlighting."""
    console.print(Markdown(text))


def print_model_table(models: list[dict]) -> None:
    """Print a formatted table of available models."""
    table = Table(title="Available Models", show_lines=False)
    table.add_column("Model ID", style="cyan bold")
    table.add_column("Provider", style="green")
    table.add_column("Name", style="white")
    table.add_column("Type", style="yellow")

    for m in models:
        table.add_row(
            m["id"],
            m["provider"],
            m["name"],
            "local" if m["local"] else "API",
        )
    console.print(table)


def print_catalog_table(models: list[dict], show_status: bool = True) -> None:
    """Print a formatted table of models from the catalog."""
    table = Table(title="Downloadable Models", show_lines=False)
    table.add_column("Name", style="cyan bold")
    table.add_column("Size", style="yellow", justify="right")
    table.add_column("Params", style="green")
    table.add_column("Family", style="magenta")
    table.add_column("Description", style="white")
    if show_status:
        table.add_column("Status", style="bold")

    for m in models:
        row = [m["name"], m["size"], m["params"], m["family"], m["description"]]
        if show_status:
            row.append(m.get("status", ""))
        table.add_row(*row)
    console.print(table)


def print_download_complete(name: str, path: str, size_gb: float) -> None:
    """Print a success message after a model download."""
    console.print()
    console.print(
        Panel(
            f"[bold green]Downloaded:[/bold green] {name}\n"
            f"[dim]Path:[/dim] {path}\n"
            f"[dim]Size:[/dim] {size_gb:.1f} GB\n\n"
            f"Run with: [bold cyan]sage run --model llama_cpp:{name}[/bold cyan]",
            title="Model Ready",
            border_style="green",
        )
    )


def print_config(data: dict) -> None:
    """Pretty-print config as a panel."""
    import json

    text = json.dumps(data, indent=2)
    console.print(Panel(text, title="~/.sage/config.json", border_style="dim"))


def header(msg: str) -> None:
    """Print a header/title message."""
    console.print(f"[bold cyan]{msg}[/bold cyan]")


def info(msg: str) -> None:
    """Print an info message."""
    console.print(f"[dim]{msg}[/dim]")


def success(msg: str) -> None:
    """Print a success message."""
    console.print(f"[green]{msg}[/green]")


def error(msg: str) -> None:
    """Print an error message to stderr."""
    err_console.print(f"[red bold]Error:[/red bold] {msg}")


def warning(msg: str) -> None:
    """Print a warning to stderr."""
    err_console.print(f"[yellow]Warning:[/yellow] {msg}")


def print_welcome(model_id: str) -> None:
    """Print the REPL welcome banner."""
    console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]Sage[/bold cyan] — local-first AI assistant\n"
                f"[dim]Model: {model_id}[/dim]\n\n"
                f"[dim]Commands: /help /clear /model /system /exit[/dim]\n"
                f'[dim]Multi-line: start with """ and end with """[/dim]'
            ),
            border_style="cyan",
        )
    )


def print_help() -> None:
    """Print REPL command reference."""
    help_text = (
        "[bold]Commands:[/bold]\n"
        "  [cyan]/help[/cyan]           Show this help\n"
        "  [cyan]/clear[/cyan]          Clear conversation history\n"
        "  [cyan]/model[/cyan] [id]     Show or change active model\n"
        "  [cyan]/system[/cyan] [text]  Show or set system prompt\n"
        "  [cyan]/history[/cyan]        Show conversation turn count\n"
        "  [cyan]/exit[/cyan]           Quit\n"
    )
    console.print(Panel(help_text, title="Help", border_style="dim"))


def print_agent_welcome(model_id: str, cwd: str) -> None:
    """Print the agent-mode welcome banner."""
    console.print()
    console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]  ╔═╗┌─┐┌─┐┌─┐[/bold cyan]\n"
                f"[bold cyan]  ╚═╗├─┤│ ┬├┤ [/bold cyan]\n"
                f"[bold cyan]  ╚═╝┴ ┴└─┘└─┘[/bold cyan]\n"
                f"\n"
                f"  [bold]Autonomous AI Coding Agent[/bold]\n"
                f"\n"
                f"  [dim]Model:[/dim]  {model_id}\n"
                f"  [dim]Dir:[/dim]    {cwd}\n"
                f"\n"
                f"  [dim]Sage plans, writes code, runs tests, and auto-fixes failures.[/dim]\n"
                f"  [dim]Watch each step as it happens in real time.[/dim]\n"
                f"\n"
                f"  [dim cyan]Commands:[/dim cyan] /help /models /prompts /autopolit /think /test /read /files /compact /clear /exit\n"
                f'  [dim cyan]Shell:[/dim cyan]    !<command>    [dim cyan]Multi-line:[/dim cyan] """..."""\n'
                f"  [dim cyan]Models:[/dim cyan]   sage pull --list    sage pull <name>"
            ),
            border_style="cyan",
            padding=(0, 2),
        )
    )
    console.print()


def print_agent_help() -> None:
    """Print agent-mode command reference."""
    help_text = (
        "[bold]Agent Commands:[/bold]\n"
        "  [cyan]/help[/cyan]           Show this help\n"
        "  [cyan]/models[/cyan]         List all available AI models\n"
        "  [cyan]/prompts[/cyan]        Browse and reuse previous prompts\n"
        "  [cyan]/autopolit[/cyan] [n]  Endless autonomous loop (optional max cycles)\n"
        "  [cyan]/think[/cyan] <task>   Force step-by-step planning before implementing\n"
        "  [cyan]/read[/cyan] <file>    Read a file into conversation context\n"
        "  [cyan]/test[/cyan] [cmd]     Run tests (default: pytest -v --tb=short)\n"
        "  [cyan]/files[/cyan]          Show all written files this session\n"
        "  [cyan]/undo[/cyan]           Delete last written files\n"
        "  [cyan]/compact[/cyan]        Trim conversation to free context space\n"
        "  [cyan]/clear[/cyan]          Clear conversation + file history\n"
        "  [cyan]/model[/cyan] [id]     Show or change active model\n"
        "  [cyan]/history[/cyan]        Show conversation turns + recent prompts\n"
        "  [cyan]/exit[/cyan]           Quit\n"
        "\n[bold]Shell:[/bold]\n"
        "  [cyan]!<command>[/cyan]      Run a shell command (e.g. !python test.py)\n"
        "\n[bold]Download Models (no API key needed):[/bold]\n"
        "  [cyan]sage pull --list[/cyan]          See all downloadable models\n"
        "  [cyan]sage pull <name>[/cyan]           Download a model\n"
        "  [cyan]sage pull --search code[/cyan]    Find code-focused models\n"
        "  [cyan]sage pull --recommended[/cyan]    Top picks for getting started\n"
        "\n[bold]How Sage Works:[/bold]\n"
        "  [dim]⟡ Thinking[/dim]     Analyzing your request\n"
        "  [dim]◈ Planning[/dim]     Breaking the task into steps\n"
        "  [dim]◆ Coding[/dim]       Generating code\n"
        "  [dim]▶ Writing[/dim]      Saving files to disk\n"
        "  [dim]⧫ Testing[/dim]      Running tests automatically\n"
        "  [dim]⟐ Fixing[/dim]       Auto-fixing failures\n"
        "  [dim]✓ Done[/dim]         Task complete\n"
        "\n[bold]Flags:[/bold]\n"
        "  [dim]--auto-run       Skip bash execution prompts[/dim]\n"
        "  [dim]--max-retries N  Auto-fix retry limit (default: 10)[/dim]\n"
        "\n[bold]Autopolit Controls:[/bold]\n"
        "  [dim]Ctrl+C once      Stop after current task finishes[/dim]\n"
        "  [dim]Ctrl+C twice     Cancel immediately[/dim]\n"
    )
    console.print(Panel(help_text, title="Agent Help", border_style="dim"))


# ── Pull-Update-Delete Cycle Progress Bar ──────────────────


class SyncProgress:
    """Multi-phase progress bar for pull-update-delete sync cycles.

    Displays a rich progress bar that tracks three phases:
    1. Pull   - Fetching/downloading new items
    2. Update - Updating existing items
    3. Delete - Removing stale items

    Usage:
        with SyncProgress() as progress:
            # Pull phase
            progress.start_pull(total=10)
            for item in items_to_pull:
                pull(item)
                progress.advance_pull()

            # Update phase
            progress.start_update(total=5)
            for item in items_to_update:
                update(item)
                progress.advance_update()

            # Delete phase
            progress.start_delete(total=3)
            for item in items_to_delete:
                delete(item)
                progress.advance_delete()
    """

    _PHASE_ICONS = {
        "pull": ("cyan", "↓"),
        "update": ("yellow", "↻"),
        "delete": ("red", "×"),
    }

    def __init__(self, title: str = "Syncing") -> None:
        self._title = title
        self._progress: Progress | None = None
        self._overall_task: TaskID | None = None
        self._phase_task: TaskID | None = None
        self._current_phase: str | None = None
        self._phases_completed = 0
        self._total_phases = 3

    def __enter__(self) -> "SyncProgress":
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[bold]{task.description}[/bold]"),
            BarColumn(bar_width=30),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("[dim]{task.fields[status]}[/dim]"),
            console=console,
            transient=False,
        )
        self._progress.start()

        # Overall progress bar
        self._overall_task = self._progress.add_task(
            f"[bold cyan]{self._title}[/bold cyan]",
            total=self._total_phases,
            status="starting...",
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._progress and self._overall_task is not None:
            if exc_type is None:
                # Success - mark complete
                self._progress.update(
                    self._overall_task,
                    completed=self._total_phases,
                    status="[green]complete[/green]",
                )
            else:
                # Error occurred
                self._progress.update(
                    self._overall_task,
                    status=f"[red]failed ({exc_type.__name__})[/red]",
                )
            self._progress.stop()

    def _start_phase(self, phase: str, total: int, description: str = "") -> None:
        """Start a new phase with its own progress bar."""
        color, icon = self._PHASE_ICONS.get(phase, ("white", "·"))
        desc = description or phase.capitalize()

        # Complete previous phase task if exists
        if self._phase_task is not None and self._progress:
            self._progress.remove_task(self._phase_task)

        self._current_phase = phase

        if self._progress and self._overall_task is not None:
            # Update overall status
            self._progress.update(
                self._overall_task,
                status=f"[{color}]{icon} {desc}[/{color}]",
            )

            # Create phase-specific task
            self._phase_task = self._progress.add_task(
                f"  [{color}]{icon}[/{color}] {desc}",
                total=total,
                status="",
            )

    def _advance_phase(self, amount: int = 1, status: str = "") -> None:
        """Advance the current phase progress."""
        if self._progress and self._phase_task is not None:
            self._progress.update(self._phase_task, advance=amount, status=status)

    def _complete_phase(self) -> None:
        """Mark the current phase as complete and update overall progress."""
        if self._progress and self._phase_task is not None:
            # Mark phase task complete
            task = self._progress.tasks[self._phase_task]
            self._progress.update(self._phase_task, completed=task.total or 0)

        self._phases_completed += 1
        if self._progress and self._overall_task is not None:
            self._progress.update(self._overall_task, completed=self._phases_completed)

    # ── Pull Phase ─────────────────────────────────────────

    def start_pull(self, total: int, description: str = "Pulling") -> None:
        """Start the pull phase."""
        self._start_phase("pull", total, description)

    def advance_pull(self, amount: int = 1, item: str = "") -> None:
        """Advance pull progress."""
        status = f"[dim]{item}[/dim]" if item else ""
        self._advance_phase(amount, status)

    def complete_pull(self) -> None:
        """Complete the pull phase."""
        self._complete_phase()

    # ── Update Phase ───────────────────────────────────────

    def start_update(self, total: int, description: str = "Updating") -> None:
        """Start the update phase."""
        self._start_phase("update", total, description)

    def advance_update(self, amount: int = 1, item: str = "") -> None:
        """Advance update progress."""
        status = f"[dim]{item}[/dim]" if item else ""
        self._advance_phase(amount, status)

    def complete_update(self) -> None:
        """Complete the update phase."""
        self._complete_phase()

    # ── Delete Phase ───────────────────────────────────────

    def start_delete(self, total: int, description: str = "Cleaning up") -> None:
        """Start the delete phase."""
        self._start_phase("delete", total, description)

    def advance_delete(self, amount: int = 1, item: str = "") -> None:
        """Advance delete progress."""
        status = f"[dim]{item}[/dim]" if item else ""
        self._advance_phase(amount, status)

    def complete_delete(self) -> None:
        """Complete the delete phase."""
        self._complete_phase()


@contextmanager
def sync_progress(title: str = "Syncing") -> Iterator[SyncProgress]:
    """Context manager for pull-update-delete sync progress.

    Usage:
        with sync_progress("Syncing models") as progress:
            progress.start_pull(total=10)
            for model in models_to_pull:
                download(model)
                progress.advance_pull(item=model.name)
            progress.complete_pull()

            progress.start_update(total=5)
            for model in models_to_update:
                update(model)
                progress.advance_update(item=model.name)
            progress.complete_update()

            progress.start_delete(total=3)
            for model in models_to_delete:
                remove(model)
                progress.advance_delete(item=model.name)
            progress.complete_delete()
    """
    sp = SyncProgress(title)
    with sp:
        yield sp


# ── Autopolit Progress Tracking (P1-28, P1-30) ──────────────


class AutopolitProgress:
    """Progress tracker for autopolit cycles.

    Tracks:
    - Current cycle number
    - Files written per cycle
    - Tests passed/failed
    - Time elapsed
    - Errors encountered
    """

    def __init__(self, max_cycles: int | None = None):
        self.max_cycles = max_cycles
        self.current_cycle = 0
        self.start_time = time.time()
        self.cycle_stats: list[dict] = []
        self._current_cycle_stats: dict = {}

    def start_cycle(self, cycle: int) -> None:
        """Start a new cycle."""
        self.current_cycle = cycle
        self._current_cycle_stats = {
            "cycle": cycle,
            "start_time": time.time(),
            "files_written": [],
            "tests_passed": False,
            "errors": [],
            "phase": "starting",
        }

        max_str = f"/{self.max_cycles}" if self.max_cycles else ""
        elapsed = time.time() - self.start_time
        elapsed_str = f"{elapsed:.0f}s" if elapsed < 60 else f"{elapsed/60:.1f}m"

        console.print()
        console.print(
            Rule(
                f"[bold cyan]Autopolit Cycle {cycle}{max_str}[/bold cyan] "
                f"[dim]({elapsed_str} elapsed)[/dim]",
                style="cyan",
            )
        )

    def update_phase(self, phase: str, detail: str = "") -> None:
        """Update current phase."""
        self._current_cycle_stats["phase"] = phase
        _phase(phase, detail)

    def add_file(self, filepath: str) -> None:
        """Record a file written."""
        self._current_cycle_stats["files_written"].append(filepath)

    def add_error(self, error: str) -> None:
        """Record an error."""
        self._current_cycle_stats["errors"].append(error)

    def set_tests_passed(self, passed: bool) -> None:
        """Record test result."""
        self._current_cycle_stats["tests_passed"] = passed

    def end_cycle(self) -> None:
        """End the current cycle and record stats."""
        self._current_cycle_stats["end_time"] = time.time()
        self._current_cycle_stats["duration"] = (
            self._current_cycle_stats["end_time"] -
            self._current_cycle_stats["start_time"]
        )
        self.cycle_stats.append(self._current_cycle_stats.copy())

        # Print cycle summary
        stats = self._current_cycle_stats
        files = len(stats["files_written"])
        errors = len(stats["errors"])
        duration = stats["duration"]

        status_parts = []
        if files > 0:
            status_parts.append(f"[green]{files} file(s)[/green]")
        if stats["tests_passed"]:
            status_parts.append("[green]tests ✓[/green]")
        elif errors > 0:
            status_parts.append(f"[red]{errors} error(s)[/red]")

        status = " · ".join(status_parts) if status_parts else "[dim]no changes[/dim]"
        console.print(f"  [dim]Cycle {self.current_cycle} completed in {duration:.1f}s[/dim] — {status}")

    def print_summary(self) -> None:
        """Print final autopolit summary (P1-30)."""
        total_time = time.time() - self.start_time
        total_cycles = len(self.cycle_stats)
        total_files = sum(len(s["files_written"]) for s in self.cycle_stats)
        total_errors = sum(len(s["errors"]) for s in self.cycle_stats)
        successful_cycles = sum(1 for s in self.cycle_stats if s["tests_passed"])

        time_str = f"{total_time:.0f}s" if total_time < 60 else f"{total_time/60:.1f}m"

        console.print()
        console.print(Rule("[bold]Autopolit Summary[/bold]", style="cyan"))
        console.print()

        # Create summary table
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column(style="dim")
        table.add_column(style="bold")

        table.add_row("Total cycles", str(total_cycles))
        table.add_row("Successful cycles", f"[green]{successful_cycles}[/green]")
        table.add_row("Files written", f"[cyan]{total_files}[/cyan]")
        table.add_row("Errors encountered", f"[red]{total_errors}[/red]" if total_errors else "[green]0[/green]")
        table.add_row("Total time", time_str)

        console.print(table)

        # List files written
        if total_files > 0:
            console.print()
            console.print("[dim]Files written:[/dim]")
            all_files = set()
            for s in self.cycle_stats:
                all_files.update(s["files_written"])
            for f in sorted(all_files)[:20]:
                console.print(f"  [green]+ {f}[/green]")
            if len(all_files) > 20:
                console.print(f"  [dim]... and {len(all_files) - 20} more[/dim]")

        console.print()


def _phase(name: str, detail: str = "") -> None:
    """Internal phase printer (avoids name conflict)."""
    style, icon = _PHASE_STYLES.get(name, ("dim", "·"))
    detail_str = f"  [dim]{detail}[/dim]" if detail else ""
    console.print(f"  [{style}]{icon} {name.capitalize()}[/{style}]{detail_str}")
