"""Review event CRUD backed by chat workflow events.

Reviewer role records live in ``_state.roles``. This module owns the Keep-shaped
review event view used by group daemon code, while durable storage stays in the
backend's generic chat workflow event primitive.
"""

from __future__ import annotations
from typing import Any

from mycel_cli.config import load_owner_config
from mycel_sdk import Client

EV_GROUP_STOP = "group_stop"

_METADATA_KEYS = (
    "task_ids",
    "task_subjects",
    "rationale",
    "requested_by",
    "task_evidence",
    "review_evidence",
    "batch_id",
    "round",
)


def _client() -> Client:
    cfg = load_owner_config()
    return Client(base_url=cfg.base_url, auth_token=cfg.auth_token)


# ── Review Events ─────────────────────────────────────────────


def _resource_refs_from_event(event: dict[str, Any]) -> list[dict[str, str]]:
    task_ids = [str(task_id) for task_id in event.get("task_ids") or []]
    if task_ids:
        return [{"type": "task", "id": task_id} for task_id in task_ids]
    if event.get("type") == EV_GROUP_STOP:
        return [{"type": "group", "id": "group"}]
    return []


def _metadata_from_event(event: dict[str, Any]) -> dict[str, Any]:
    return {key: event[key] for key in _METADATA_KEYS if key in event}


def _final_state_from_event(event: dict[str, Any]) -> dict[str, Any] | None:
    verdict = event.get("final_verdict")
    resources = event.get("final_resource_states")
    if verdict is None and resources is None:
        return None
    final_state: dict[str, Any] = {}
    if verdict is not None:
        final_state["verdict"] = verdict
    if resources is not None:
        final_state["resources"] = resources
    return final_state


def _event_state_from_event(event: dict[str, Any]) -> str | None:
    verdict = event.get("final_verdict")
    if verdict == "cancelled":
        return "cancelled"
    if verdict:
        return "settled"
    return None


def _event_from_backend(payload: dict[str, Any]) -> dict[str, Any]:
    metadata = dict(payload.get("metadata") or {})
    final_state = dict(payload.get("final_state") or {})
    resource_refs = list(payload.get("resource_refs") or [])
    task_ids = metadata.get("task_ids")
    if task_ids is None:
        task_ids = [
            str(ref.get("id"))
            for ref in resource_refs
            if isinstance(ref, dict) and ref.get("type") == "task" and ref.get("id")
        ]

    event: dict[str, Any] = {
        "id": str(payload.get("event_id") or payload.get("id") or ""),
        "type": str(payload.get("kind") or ""),
        "task_ids": [str(task_id) for task_id in task_ids],
        "user_resource_states": dict(payload.get("decision_states") or {}),
        "user_rationales": dict(payload.get("rationales") or {}),
        "round": metadata.get("round", 1),
    }
    for key in _METADATA_KEYS:
        if key in metadata:
            event[key] = metadata[key]

    state = str(payload.get("state") or "open")
    verdict = final_state.get("verdict")
    if verdict is not None:
        event["final_verdict"] = verdict
    elif state == "cancelled":
        event["final_verdict"] = "cancelled"

    resources = final_state.get("resources")
    if resources is not None:
        event["final_resource_states"] = resources
    return event


def list_review_events(group_id: str) -> list[dict[str, Any]]:
    events = _client().chats.list_workflow_events(group_id)
    if events is None:
        return []
    return sorted(
        (_event_from_backend(event) for event in events),
        key=_event_sort_key,
    )


def _event_sort_key(event: dict[str, Any]) -> tuple[int, str]:
    raw = str(event.get("id") or "")
    try:
        return int(raw), raw
    except ValueError:
        return 0, raw


def add_review_event(group_id: str, event_data: dict) -> str:
    """Add a review event to a group. Returns the generated event_id."""
    event = dict(event_data)
    event.setdefault("round", 1)
    created = _client().chats.create_workflow_event(
        group_id,
        kind=str(event["type"]),
        resource_refs=_resource_refs_from_event(event),
        decision_states=dict(event.get("user_resource_states") or {}),
        rationales=dict(event.get("user_rationales") or {}),
        final_state=_final_state_from_event(event),
        metadata=_metadata_from_event(event),
    )
    if not isinstance(created, dict):
        raise RuntimeError("backend did not return a workflow event payload")
    event_id = str(created.get("event_id") or created.get("id") or "").strip()
    if not event_id:
        raise RuntimeError("backend did not return a workflow event id")
    state = _event_state_from_event(event)
    if state is not None:
        update_review_event(group_id, event_id, state=state)
    return event_id


def get_review_event(group_id: str, event_id: str) -> dict:
    """Get a single review event by id. Raises ValueError if not found."""
    event = _client().chats.get_workflow_event(group_id, event_id)
    if not isinstance(event, dict):
        raise ValueError(f"Review event '{event_id}' 不存在")
    return _event_from_backend(event)


def update_review_event(group_id: str, event_id: str, **kwargs) -> dict:
    """Update fields on a review event. Raises ValueError if not found."""
    current = get_review_event(group_id, event_id)
    metadata = _metadata_from_event(current)
    final_state = _final_state_from_event(current)
    update_kwargs: dict[str, Any] = {}

    if "user_resource_states" in kwargs:
        update_kwargs["decision_states"] = dict(kwargs["user_resource_states"] or {})
    if "user_rationales" in kwargs:
        update_kwargs["rationales"] = dict(kwargs["user_rationales"] or {})
    if "final_verdict" in kwargs or "final_resource_states" in kwargs:
        merged = dict(current)
        merged.update(
            {
                key: kwargs[key]
                for key in ("final_verdict", "final_resource_states")
                if key in kwargs
            }
        )
        final_state = _final_state_from_event(merged)
        update_kwargs["state"] = _event_state_from_event(merged) or "open"
    if final_state is not None:
        update_kwargs["final_state"] = final_state

    for key in _METADATA_KEYS:
        if key in kwargs:
            metadata[key] = kwargs[key]
    if any(key in kwargs for key in _METADATA_KEYS):
        update_kwargs["metadata"] = metadata
    if "state" in kwargs:
        update_kwargs["state"] = kwargs["state"]

    updated = _client().chats.update_workflow_event(
        group_id,
        event_id,
        **update_kwargs,
    )
    if not isinstance(updated, dict):
        raise ValueError(f"Review event '{event_id}' 不存在")
    return _event_from_backend(updated)
