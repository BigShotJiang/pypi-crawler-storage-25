"""Group role record helpers.

RoleRecord = {session, role, local_id?, agent_type?, cache?, name?, path?, contract?}
  role:  "worker" | "supervisor" | "reviewer"
  local_id: local Mycel agent identity used for provider launch
  agent_type: "claude-code" | "codex"（缺省视为 claude-code）
  cache: 运行时信息（pid/target_id/jsonl_path/thread_id），可选

terminal_type 不存在 role record 上：group 是唯一来源。

Mutator pattern (并发安全)：
  add_*/remove_* 接 group_id，内部通过 `mutate_group` 取 per-group
  file lock，load → mutate → save 原子化。caller **不要** 自己
  `load_group + save_group` —— 那样绕开了锁，会和 daemon / 其他 CLI
  进程 race 写（后写覆盖前写，state 丢失）。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from pathlib import Path
from typing import Literal

from mycel_cli.group.agent_types import normalize_agent_type
from mycel_cli.group._state.groups import list_groups, load_group, mutate_group


@dataclass
class RoleRecord:
    session: str = ""
    role: Literal["worker", "supervisor", "reviewer"] = "worker"
    name: str = ""
    path: str = ""
    contract: dict | None = None
    local_id: str = ""
    agent_type: str | None = None
    cache: dict | None = None

    @classmethod
    def from_mapping(cls, record: dict[str, Any]) -> "RoleRecord":
        role = str(record.get("role") or "")
        if role not in {"worker", "supervisor", "reviewer"}:
            raise ValueError(f"invalid group role: {role!r}")
        cache = record.get("cache")
        if cache is not None and not isinstance(cache, dict):
            raise ValueError("invalid group role cache")
        contract = record.get("contract")
        if contract is not None and not isinstance(contract, dict):
            raise ValueError("invalid group role contract")
        return cls(
            session=str(record.get("session") or ""),
            role=role,  # type: ignore[arg-type]
            name=str(record.get("name") or ""),
            path=str(record.get("path") or ""),
            contract=contract,
            local_id=str(record.get("local_id") or ""),
            agent_type=record.get("agent_type"),
            cache=cache,
        )

    def normalized_agent_type(self) -> str:
        return normalize_agent_type(self.agent_type)

    def target_id(self) -> str | None:
        return str((self.cache or {}).get("target_id") or "") or None

    def jsonl_path(self) -> Path | None:
        raw = (self.cache or {}).get("jsonl_path")
        if not raw:
            return None
        return Path(str(raw))

    def thread_id(self) -> str | None:
        raw = (self.cache or {}).get("thread_id")
        return str(raw) if raw else None

    def is_ready(self) -> bool:
        return bool(self.target_id())


def _records_by_role(group: dict[str, Any], role: str) -> list[dict[str, Any]]:
    return [u for u in group.get("roles", []) if u.get("role") == role]


def iter_roles(
    group: dict[str, Any], *, role: str | None = None
) -> list[dict[str, Any]]:
    if role is None:
        return list(group.get("roles", []))
    return _records_by_role(group, role)


def role_agent_type(record: dict[str, Any]) -> str:
    return RoleRecord.from_mapping(record).normalized_agent_type()


def role_ready(record: dict[str, Any]) -> bool:
    return RoleRecord.from_mapping(record).is_ready()


def role_target_id(record: dict[str, Any]) -> str | None:
    return RoleRecord.from_mapping(record).target_id()


def role_jsonl_path(record: dict[str, Any]) -> Path | None:
    return RoleRecord.from_mapping(record).jsonl_path()


def role_thread_id(record: dict[str, Any]) -> str | None:
    return RoleRecord.from_mapping(record).thread_id()


def worker_session_id(worker: dict[str, Any]) -> str | None:
    """Return cel's stable role session id for routing stop files."""
    session = worker.get("session")
    if session:
        return str(session)
    thread_id = role_thread_id(worker)
    if thread_id:
        return str(thread_id)
    return None


def iter_workers(group: dict[str, Any]) -> list[dict[str, Any]]:
    """返回 group 里所有 role=worker 的 role record。"""
    return iter_roles(group, role="worker")


def iter_reviewer_roles(group: dict[str, Any]) -> list[dict[str, Any]]:
    return iter_roles(group, role="reviewer")


def iter_reviewers(group_id: str) -> list[dict[str, Any]]:
    group = load_group(group_id)
    if group is None:
        raise ValueError(f"Group '{group_id}' 不存在")
    return [
        {**reviewer, "id": reviewer.get("session")}
        for reviewer in iter_reviewer_roles(group)
    ]


def find_worker(group: dict[str, Any], session: str) -> dict[str, Any] | None:
    return find_role(group, session, role="worker")


def find_role(
    group: dict[str, Any],
    session: str,
    *,
    role: str | None = None,
) -> dict[str, Any] | None:
    records = iter_roles(group, role=role)
    return next(
        (record for record in records if record.get("session") == session),
        None,
    )


def get_role(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
) -> dict[str, Any]:
    group = load_group(group_id)
    if group is None:
        raise ValueError(f"Group '{group_id}' 不存在")
    record = find_role(group, session, role=role)
    if record is None:
        label = role or "role session"
        raise ValueError(f"{label.title()} '{session}' 不存在")
    return record


def find_worker_globally(session: str) -> str | None:
    """检查 session 是否已作为 worker 在任何 group 中，返回 group name 或 None。"""
    return find_role_globally(session, role="worker")


def find_role_globally(session: str, *, role: str | None = None) -> str | None:
    """检查 session 是否已作为 role record 在任何 group 中，返回 group name 或 None。"""
    for name in list_groups():
        m = load_group(name)
        if m and find_role(m, session, role=role):
            return name
    return None


def find_supervisor(group: dict[str, Any]) -> dict[str, Any] | None:
    """返回 group 的 supervisor role record（若有）。"""
    return next(iter(iter_roles(group, role="supervisor")), None)


def add_role(
    group_id: str,
    session: str,
    *,
    role: str,
    cache: dict | None = None,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    bootstrapped: bool | None = None,
    **extra_fields: Any,
) -> dict[str, Any]:
    existing = find_role_globally(session, role=role)
    if existing and existing != group_id:
        raise ValueError(
            f"Role session '{session}' 已在 group '{existing}' 中，先从该 group 中移除"
        )
    record: dict[str, Any] = {
        "session": session,
        "role": role,
        "name": name or "",
        "path": path or "",
        "contract": contract,
        "agent_type": normalize_agent_type(agent_type),
        "cache": cache,
    }
    if bootstrapped is not None:
        record["bootstrapped"] = bootstrapped
    record.update(extra_fields)
    with mutate_group(group_id) as group:
        group.setdefault("roles", [])
        if role == "supervisor":
            existing_supervisor = find_supervisor(group)
            if existing_supervisor is not None:
                old_id = existing_supervisor.get("name") or existing_supervisor.get(
                    "session", ""
                )
                raise ValueError(
                    f"Group already has a supervisor ({old_id}). "
                    "Remove it first: cel supervisor remove"
                )
        if find_role(group, session, role=role):
            raise ValueError(f"{role.title()} '{session}' 已在此 group 中")
        group["roles"].append(record)
    return record


def update_role(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    with mutate_group(group_id) as group:
        record = find_role(group, session, role=role)
        if record is None:
            label = role or "role session"
            raise ValueError(f"{label.title()} '{session}' 不存在")
        record.update(kwargs)
        record["session"] = session
        if role is not None:
            record["role"] = role
        return record


def remove_role(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
) -> bool:
    with mutate_group(group_id) as group:
        roles = group.get("roles", [])
        next_roles = [
            u
            for u in roles
            if not (
                u.get("session") == session and (role is None or u.get("role") == role)
            )
        ]
        if len(next_roles) == len(roles):
            return False
        group["roles"] = next_roles
    return True


def add_worker(
    group_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    local_id: str | None = None,
    bootstrapped: bool = False,
) -> dict[str, Any]:
    return add_role(
        group_id,
        session,
        role="worker",
        cache=cache,
        name=name,
        path=path,
        contract=contract,
        agent_type=agent_type,
        local_id=local_id,
        bootstrapped=bootstrapped,
    )


def remove_worker(group_id: str, session: str) -> bool:
    return remove_role(group_id, session, role="worker")


def add_supervisor(
    group_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    local_id: str | None = None,
) -> dict[str, Any]:
    return add_role(
        group_id,
        session,
        role="supervisor",
        cache=cache,
        name=name,
        path=path,
        contract=contract,
        agent_type=agent_type,
        local_id=local_id,
    )


def remove_supervisor(group_id: str) -> bool:
    group = load_group(group_id)
    if group is None:
        return False
    supervisor = find_supervisor(group)
    if supervisor is None:
        return False
    return remove_role(group_id, str(supervisor["session"]), role="supervisor")
