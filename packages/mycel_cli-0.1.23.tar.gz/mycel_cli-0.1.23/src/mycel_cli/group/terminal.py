"""Terminal abstraction layer for mycel_cli.group.

Group-container model: one group shares a single terminal container
(window / workspace / session). Users are spawned *inside* that
container at role-aware locations.

The container ref is persisted on the group
(``group["terminal_container"]``); backends introspect the live terminal
state (iterate windows by title, list workspaces by id, …) to resolve the
container for subsequent spawns. There is NO in-process cache in the
backend — state is the single source of truth.
"""

from __future__ import annotations
from typing import Protocol, runtime_checkable


@runtime_checkable
class Terminal(Protocol):
    def ensure_group_container(self, group_id: str) -> str:
        """Create or return the backend-specific container for this group.

        Idempotent: first call creates the container (window/workspace/session);
        subsequent calls return the same ref. Backend may introspect its own
        live state (e.g. iterate windows by title) rather than caching in-process.
        """
        ...

    def spawn_in_container(
        self,
        container_ref: str,
        role: str,
        role_index: int,
        cwd: str,
        cmd: str,
    ) -> str:
        """Spawn a new surface inside the container at the role-appropriate
        location, return the surface id.

        Args:
            container_ref: the container handle returned by
                ``ensure_group_container``.
            role: ``"supervisor"`` | ``"reviewer"`` | ``"worker"``.
            role_index: 0-based index within this role (workers only go > 0).
            cwd: working directory for the spawned process.
            cmd: shell command to run.
        """
        ...

    def close_group_container(self, container_ref: str) -> None:
        """Close the entire container (all panes/tabs within).

        Best-effort: callers may swallow errors. Implementations should not
        raise for "already closed" situations.
        """
        ...

    def send_text(self, target_id: str, text: str) -> None:
        """Send text followed by Enter to the session."""
        ...

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to the session. key values: 'escape', 'enter', 'ctrl-c'."""
        ...

    def read_screen(self, target_id: str) -> str:
        """Return current visible screen content of the session."""
        ...

    def close(self, target_id: str) -> None:
        """Close/kill the session."""
        ...

    def resolve_target_id(self, pid: int) -> str | None:
        """Discover a running process's target_id by introspecting the OS (env vars, etc).
        Returns None if this terminal does not support live discovery (target_id is
        only known at spawn time and must come from the user cache)."""
        ...


def _default_factory(terminal_type: str) -> Terminal:
    match terminal_type:
        case "cmux":
            from mycel_cli.group.terminals.cmux import CmuxTerminal

            return CmuxTerminal()
        case "tmux":
            from mycel_cli.group.terminals.tmux import TmuxTerminal

            return TmuxTerminal()
        case "terminal":
            from mycel_cli.group.terminals.terminal_app import TerminalAppTerminal

            return TerminalAppTerminal()
        case "kitty":
            from mycel_cli.group.terminals.kitty import KittyTerminal

            return KittyTerminal()
        case "iterm2":
            from mycel_cli.group.terminals.iterm2 import ITerm2Terminal

            return ITerm2Terminal()
        case _:
            raise ValueError(
                f"Unknown terminal type: {terminal_type!r}. Choose from: cmux, tmux, terminal, kitty, iterm2"
            )


_factory = _default_factory


def get_terminal(terminal_type: str) -> Terminal:
    """Factory: return Terminal implementation for the given type.

    Delegates to the module-level ``_factory`` so tests can swap in a fake by
    monkeypatching ``mycel_cli.group.terminal._factory`` — works regardless of how callers
    imported ``get_terminal`` (``from mycel_cli.group.terminal import get_terminal`` binds
    the function object, but the function still looks up ``_factory`` at call
    time, so the patch takes effect everywhere).
    """
    return _factory(terminal_type)
