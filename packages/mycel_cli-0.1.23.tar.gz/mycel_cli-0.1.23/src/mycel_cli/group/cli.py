"""Group CLI — command model v2 (public facade).

Wires the `typer` app tree:

    cel self <status|start|stop|reset>
    cel group config
    cel group <create|update|remove|list|show|start|stop>
    cel group <group_id> <task|worker|supervisor|reviewer> <verb> ...

Command bodies delegate to `mycel_cli.group._cli.*` sub-modules organised by
responsibility. See `mycel_cli.group._cli.__init__` for the split rationale. Any
test that used to patch `mycel_cli.group.cli.<helper>` should now patch
`mycel_cli.group._cli.<module>.<helper>` (the symbol actually used at call time).
"""

from __future__ import annotations

import json
import logging
import sys
from importlib.metadata import version as _pkg_version
from pathlib import Path

import click
import typer
from typer.core import TyperGroup

from mycel_cli.group.agent_types import (
    PROVIDER_ORDER,
    normalize_agent_type,
    resolve_provider_selection,
)
from mycel_cli.group._cli.authority import authorize_group_stop, authorize_operation
from mycel_cli.group._cli.constants import (
    COMMAND_HELP,
    CREATE_HELP,
    GROUP_HELP,
    GROUP_SCOPED_HELP,
    _HELP,
)
from mycel_cli.group._cli.dispatch import dispatch_group_scoped
from mycel_cli.group._cli.helpers import (
    ensure_file_in_messages_dir,
    format_timestamp,
    is_daemon_running,
    load_mycel_config,
    missing_review_events,
    require_global,
    require_group_by_name,
    persist_user_last_message,
    REQUIRED_REVIEW_EVENTS,
    REVIEW_EVENT_LABELS,
    reviewer_covers_event,
    review_event_coverage,
    save_mycel_config,
)
from mycel_cli.group._daemon.constants import (
    EV_GROUP_STOP,
    group_start_signal_file,
    group_stop_signal_file,
)
from mycel_cli.group._daemon.review import cancel_pending_group_stop
from mycel_cli.group._cli import spawn as _spawn_mod
from mycel_cli.group._cli.spawn import (
    check_stop_hook_or_fail,
    launch_daemon,
)
from mycel_cli.group._cli.stop_hooks import install_stop_hooks
from mycel_cli.group._cli.stop_hooks import remove_stop_hooks, stop_hook_status
from mycel_cli.group._process.processes import request_termination, wait_for_exit
from mycel_cli.group._state.config import (
    default_terminal_global,
    is_workers_enabled_for_group,
    workers_enabled_global,
)
from mycel_cli.group._state.workflow import (
    apply_header,
    create_workflow,
    delete_header,
    get_header,
    mirror_header,
    set_header,
)
from mycel_cli.group._state.content import read_mycel_home_text, resolve_content
from mycel_cli.group._state.globals_ import load_global, new_global, save_global
from mycel_cli.group._state.groups import (
    create_group,
    delete_all,
    delete_group,
    group_terminal_type,
    list_groups,
    load_group,
)
from mycel_cli.group._state.paths import VALID_TERMINALS
from mycel_cli.group._state.reviewers import (
    get_review_event,
    list_review_events,
    update_review_event,
)
from mycel_cli.group._state.tasks import list_tasks
from mycel_cli.group._state.roles import (
    find_supervisor,
    get_role,
    iter_reviewers,
    iter_workers,
    role_agent_type,
)
from mycel_cli.group.workflow_policy import ActorRole, OperationName
from mycel_cli.binding_resolver import resolve_binding
from mycel_cli.identity_store import IdentityStore
from mycel_cli.config import effective_base_url, load_owner_config
from mycel_sdk import Client
from mycel_cli.internal_hooks import (
    format_agent_context,
    format_hook_diagnostic_context,
)
from mycel_cli.providers.hooks import (
    ensure_provider_hooks,
    provider_hook_status,
    remove_provider_hooks,
)
from mycel_cli.daemon.ipc import DaemonIpcUnavailable, request as daemon_request
from mycel_cli.daemon.service import (
    group_loop_summary,
    identity_backend_summary,
    identity_summary,
    subscriber_summary,
)

_log = logging.getLogger("mycel_cli.group.cli")


_GROUP_ID_MANAGEMENT_COMMANDS = frozenset({"show", "update", "remove", "start", "stop"})
_REMOVED_GROUP_COMMANDS = frozenset({"runtime"})


def _require_group_with_backend_header(group_id: str) -> dict:
    group = require_group_by_name(group_id)
    header = get_header(group_id)
    apply_header(group, header)
    return group


def _scoped_command_help(subject: str, rest: list[str]) -> str | None:
    if not rest or rest in (["--help"], ["-h"]):
        return GROUP_SCOPED_HELP.get(subject)
    if len(rest) != 2 or rest[1] not in {"--help", "-h"}:
        return None
    command = rest[0]
    if command == "create" and subject in CREATE_HELP:
        return CREATE_HELP[subject]
    return COMMAND_HELP.get(subject, {}).get(command)


# ── typer app wiring ──────────────────────────────────────────


class GroupCommandGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0] in _REMOVED_GROUP_COMMANDS:
            ctx.meta["removed_group_command"] = args[0]
            return []
        if args and args[0] in GROUP_SCOPED_HELP and args[0] not in self.commands:
            ctx.meta["group_help_args"] = list(args)
            return []
        if args and args[0] not in self.commands and args[0] not in {"-h", "--help"}:
            if len(args) > 1 and args[1] in _GROUP_ID_MANAGEMENT_COMMANDS:
                ctx.meta["group_reversed_management_args"] = list(args)
                return []
            if len(args) > 1 and args[1] in {"-h", "--help"}:
                ctx.meta["group_scoped_args"] = list(args)
                return []
            if len(args) > 1 and args[1] not in GROUP_SCOPED_HELP:
                return super().parse_args(ctx, args)
            ctx.meta["group_scoped_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


# Non-interactive: disable Rich panels (errors fall back to Click plain text)
_rich_markup_mode = None if not sys.stdout.isatty() else "rich"

app = typer.Typer(
    help=_HELP,
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
    no_args_is_help=True,
    rich_markup_mode=_rich_markup_mode,
)
self_app = typer.Typer(
    help="manage the local Mycel daemon and inbox",
    rich_markup_mode=_rich_markup_mode,
)
self_inbox_app = typer.Typer(
    help="read local inbox notifications",
    rich_markup_mode=_rich_markup_mode,
)
group_app = typer.Typer(
    cls=GroupCommandGroup,
    help=GROUP_HELP,
    invoke_without_command=True,
    rich_markup_mode=_rich_markup_mode,
)
app.add_typer(self_app, name="self")
self_app.add_typer(self_inbox_app, name="inbox")
app.add_typer(group_app, name="group")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(_pkg_version("mycel-cli"))
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="show version",
    ),
) -> None:
    if ctx.invoked_subcommand is not None:
        return


@group_app.callback()
def group_main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is not None:
        return

    removed = ctx.meta.get("removed_group_command")
    if removed:
        typer.echo(
            f"`cel group {removed}` is not a command. Use `cel self start/status/stop/uninstall/reset`.",
            err=True,
        )
        raise typer.Exit(2)

    reversed_args = ctx.meta.get("group_reversed_management_args")
    if reversed_args:
        group_id = reversed_args[0]
        command = reversed_args[1]
        typer.echo(_group_reversed_management_help(group_id, command), err=True)
        raise typer.Exit(2)

    help_args = ctx.meta.get("group_help_args")
    if help_args:
        subject = help_args[0]
        help_text = _scoped_command_help(subject, help_args[1:])
        if help_text is not None:
            typer.echo(help_text)
            raise typer.Exit()
        typer.echo(f"No such command '{subject}'", err=True)
        raise typer.Exit(2)

    scoped_args = ctx.meta.get("group_scoped_args")
    if not scoped_args:
        return

    group_id = scoped_args[0]
    rest = scoped_args[1:]
    if not rest:
        group_show(group_id)
        raise typer.Exit()
    if rest in (["--help"], ["-h"]):
        typer.echo(_group_instance_help(group_id))
        raise typer.Exit()

    subject = rest[0]
    help_text = _scoped_command_help(subject, rest[1:])
    if help_text is not None:
        typer.echo(help_text)
        raise typer.Exit()

    dispatch_group_scoped(group_id, rest)


def _group_instance_help(group_id: str) -> str:
    return "\n".join(
        [
            f"Group '{group_id}'",
            "",
            "Use the group-scoped form:",
            f"  cel group {group_id} task ...",
            f"  cel group {group_id} supervisor ...",
            f"  cel group {group_id} worker ...",
            f"  cel group {group_id} reviewer ...",
            f"  cel group show {group_id}",
            "",
            "Keep-like shortcut for existing local groups:",
            f"  cel {group_id} task ...",
        ]
    )


def _group_reversed_management_help(group_id: str, command: str) -> str:
    return "\n".join(
        [
            f"`cel group {group_id} {command}` is not a command.",
            "",
            "Use the management form:",
            f"  cel group {command} {group_id}",
            "",
            "Use the group-scoped form for role resources:",
            f"  cel group {group_id} task ...",
            f"  cel group {group_id} supervisor ...",
            f"  cel group {group_id} worker ...",
            f"  cel group {group_id} reviewer ...",
        ]
    )


# ── self ──────────────────────────────────────────────────────


@self_app.command("start", help="Start the local Mycel daemon.")
def self_start(
    foreground: bool = typer.Option(
        False, "-f", "--foreground", help="前台运行本地 Mycel 服务"
    ),
) -> None:
    authorize_operation(OperationName.SELF_START)
    _ensure_provider_hooks_for("all")
    install_stop_hooks("all")
    global_state = load_global()
    if global_state is None:
        global_state = new_global()
    if is_daemon_running(global_state):
        typer.echo("Mycel daemon 已在运行", err=True)
        raise typer.Exit(1)
    launch_daemon(global_state, foreground)


@self_app.command("stop", help="Stop the local Mycel daemon.")
def self_stop() -> None:
    authorize_operation(OperationName.SELF_STOP)
    _stop_daemon_from_global(require_global())
    typer.echo("Mycel daemon 已停止。")


@self_app.command(
    "uninstall", help="Stop the local Mycel daemon and remove installed hooks."
)
def self_uninstall() -> None:
    authorize_operation(OperationName.SELF_UNINSTALL)
    global_state = load_global()
    if global_state is not None:
        _stop_daemon_from_global(global_state)
    _remove_mycel_hooks()
    typer.echo("Mycel hooks removed.")


@self_app.command("status", help="Show local Mycel daemon status.")
def self_status() -> None:
    global_state = load_global()
    base_url = effective_base_url()
    if global_state is None:
        typer.echo("\n".join(["Mycel daemon 未启动。", _base_url_line(base_url)]))
        return

    daemon_running = is_daemon_running(global_state)
    if global_state.get("stopped"):
        state_label = "已锁定 (stopped)"
    elif daemon_running:
        state_label = "运行中"
    else:
        state_label = "异常 (本地服务未运行)"

    lines = [f"状态: {state_label}", _base_url_line(base_url)]
    pid = global_state.get("daemon_pid")
    if pid:
        lines.append(
            f"Daemon PID: {pid}" + (" (运行中)" if daemon_running else " (已退出)")
        )
    lines.append(identity_summary())
    lines.append(identity_backend_summary())
    lines.append(subscriber_summary(daemon_running=daemon_running))
    lines.append(group_loop_summary(daemon_running=daemon_running))
    lines.append(_hook_summary_line())

    groups = []
    for name in list_groups():
        group = load_group(name)
        if group is None:
            continue
        groups.append((name, group))

    if not groups:
        lines.append("")
        lines.append(
            "没有 group。用 cel group create 创建；group id 来自后端 chat id。"
        )
    else:
        lines.append("")
        for name, group in groups:
            workers = [worker["session"] for worker in iter_workers(group)]
            supervisor = find_supervisor(group)
            tasks = list_tasks(name)
            done = sum(1 for task in tasks if task["status"] == "completed")
            running = sum(1 for task in tasks if task["status"] == "in_progress")
            pending = sum(1 for task in tasks if task["status"] == "pending")
            workers_text = ", ".join(workers) if workers else "无"
            supervisor_text = supervisor["session"] if supervisor else "(unclaimed)"
            lines.append(
                f"  {name} — supervisor: {supervisor_text} | workers: {workers_text} | tasks: {done} done, {running} running, {pending} pending ({len(tasks)} total)"
            )

    typer.echo("\n".join(lines))


def _hook_summary_line() -> str:
    mycel_home = IdentityStore.from_env().root
    inbox = ", ".join(
        f"{provider} {_installed_label(provider_hook_status(provider=provider, mycel_home=mycel_home))}"
        for provider in PROVIDER_ORDER
    )
    stop_status = stop_hook_status()
    stop = ", ".join(
        f"{provider} {_installed_label(stop_status[provider])}"
        for provider in PROVIDER_ORDER
    )
    return f"Hooks: inbox {inbox} | stop {stop}"


def _installed_label(status: dict) -> str:
    return "installed" if status.get("installed") else "missing"


@self_app.command(
    "reset", help="Stop the local Mycel daemon and clear local group state."
)
def self_reset() -> None:
    authorize_operation(OperationName.SELF_RESET)
    global_state = load_global()

    # Step 1: best-effort close every user's terminal surface while the
    # daemon is still alive. Mirrors `group_remove`'s teardown path; we delegate
    # to `kill_and_close_worker` rather than re-implementing close logic.
    for group_id in list_groups():
        try:
            group = load_group(group_id)
        except Exception as exc:
            _log.warning(
                "self reset: failed to load group %r, skipping surface close: %s",
                group_id,
                exc,
            )
            continue
        if group is None:
            continue
        supervisor = find_supervisor(group)
        if supervisor:
            _spawn_mod.kill_and_close_worker(supervisor, group)
        for worker in iter_workers(group):
            _spawn_mod.kill_and_close_worker(worker, group)
        try:
            reviewers = list(iter_reviewers(group_id))
        except ValueError as exc:
            _log.warning(
                "self reset: failed to iter reviewers for %r: %s",
                group_id,
                exc,
            )
            reviewers = []
        for reviewer in reviewers:
            _spawn_mod.kill_and_close_worker(reviewer, group)

    # Step 2: ask the daemon to stop and wait before clearing state below.
    if global_state is not None:
        _stop_daemon_from_global(global_state)

    # Step 3: wipe group + global state.
    delete_all()

    # Step 4: `delete_all()` doesn't touch daemon memory state — remove it here
    # so a fresh daemon starts with an empty in-memory model.
    from mycel_cli.group._daemon.constants import DAEMON_STATE_FILE

    DAEMON_STATE_FILE.unlink(missing_ok=True)

    typer.echo("Mycel daemon 已重置，所有状态已清除。")


def _stop_daemon_or_fail(pid: object) -> None:
    request_termination(pid)
    if wait_for_exit(pid):
        return
    typer.echo(f"Daemon PID {pid} did not exit after stop request.", err=True)
    raise typer.Exit(1)


def _stop_daemon_from_global(global_state: dict) -> None:
    daemon_pid = global_state.get("daemon_pid")
    if daemon_pid:
        _stop_daemon_or_fail(daemon_pid)
    global_state["daemon_pid"] = None
    global_state["stopped"] = True
    save_global(global_state)


@self_inbox_app.command("read", help="Read local inbox notifications.")
def self_inbox_read() -> None:
    binding = resolve_binding(
        store=IdentityStore.from_env(),
        cwd=Path.cwd(),
        provider=None,
        interactive=False,
    )
    local_id = str(binding["local_id"])
    try:
        payload = daemon_request("drain_for_hook", local_id=local_id)
    except DaemonIpcUnavailable:
        typer.echo(
            format_hook_diagnostic_context(
                f"local Mycel daemon is not running for {local_id}",
                local_id=local_id,
            ),
            nl=False,
        )
        return
    if payload.get("status") == "stale":
        typer.echo(
            format_hook_diagnostic_context(str(payload["message"]), local_id=local_id),
            nl=False,
        )
        return
    typer.echo(format_agent_context(payload, local_id=local_id), nl=False)


@group_app.command("config")
def group_config(
    terminal: str = typer.Option(
        "", "--terminal", help="Default terminal: cmux, tmux, terminal, kitty, iterm2"
    ),
    workers_enabled: str = typer.Option(
        "", "--workers-enabled", help="Default worker roles: true or false"
    ),
    base_url: str = typer.Option("", "--base-url", help="Default Mycel backend URL"),
    clear_base_url: bool = typer.Option(
        False, "--clear-base-url", help="Use the built-in Mycel backend URL"
    ),
) -> None:
    """Show or update local Mycel defaults."""
    if terminal or workers_enabled or base_url or clear_base_url:
        authorize_operation(OperationName.GROUP_CONFIG)
    if base_url and clear_base_url:
        typer.echo("Use either --base-url or --clear-base-url, not both.", err=True)
        raise typer.Exit(1)
    config = load_mycel_config()
    updates = 0

    if terminal:
        if terminal not in VALID_TERMINALS:
            typer.echo(
                f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}",
                err=True,
            )
            raise typer.Exit(1)
        config["default_terminal"] = terminal
        config.pop("terminal", None)
        updates += 1

    workers_enabled_value = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=False,
        context_label="workers-enabled",
    )
    if workers_enabled_value is not None:
        config["workers_enabled"] = workers_enabled_value
        updates += 1

    if base_url:
        config["base_url"] = base_url
        updates += 1

    if clear_base_url:
        if "base_url" in config:
            config.pop("base_url", None)
            updates += 1

    if updates:
        save_mycel_config(config)
        typer.echo("Cel defaults updated.")

    typer.echo("\n".join(_group_config_lines()))
    prereqs = {
        "cmux": "CMUX: Settings → Socket Control → set to 'Automation Mode'",
        "tmux": "TMUX: no prerequisites",
        "terminal": "Terminal.app: System Settings → Privacy → Accessibility (grant permission to your shell/terminal)",
        "kitty": "Kitty: add 'allow_remote_control yes' and 'listen_on unix:/tmp/kitty.sock' to ~/.config/kitty/kitty.conf",
        "iterm2": "iTerm2: System Settings → Privacy → Automation (grant permission to your shell/terminal to control iTerm)",
    }
    if terminal:
        typer.echo(f"Prerequisites: {prereqs[terminal]}")


@self_app.command("install-hooks", hidden=True)
def self_install_hooks(
    provider: str = typer.Option("all", "--provider", help="codex, claude, or all"),
) -> None:
    """Install Mycel hooks for local providers."""
    authorize_operation(OperationName.GROUP_CONFIG)
    provider_hooks = _ensure_provider_hooks_for(provider)
    result = install_stop_hooks(provider)
    result["provider_hooks"] = provider_hooks
    typer.echo(json.dumps(result, ensure_ascii=False, indent=2))


@self_app.command("status-hooks", hidden=True)
def self_status_hooks() -> None:
    """Show Mycel hook status for local providers."""
    mycel_home = IdentityStore.from_env().root
    typer.echo(
        json.dumps(
            {
                "provider_hooks": {
                    provider: provider_hook_status(
                        provider=provider, mycel_home=mycel_home
                    )
                    for provider in PROVIDER_ORDER
                },
                "stop_hooks": stop_hook_status(),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


@self_app.command("uninstall-hooks", hidden=True)
def self_uninstall_hooks() -> None:
    """Remove Mycel hooks from local providers."""
    authorize_operation(OperationName.GROUP_CONFIG)
    typer.echo(json.dumps(_remove_mycel_hooks(), ensure_ascii=False, indent=2))


def _remove_mycel_hooks() -> dict[str, dict]:
    mycel_home = IdentityStore.from_env().root
    return {
        "provider_hooks": {
            provider: remove_provider_hooks(provider=provider, mycel_home=mycel_home)
            for provider in PROVIDER_ORDER
        },
        "stop_hooks": remove_stop_hooks(),
    }


def _ensure_provider_hooks_for(provider: str) -> dict[str, dict]:
    mycel_home = IdentityStore.from_env().root
    statuses: dict[str, dict] = {}
    for item in resolve_provider_selection(provider):
        ensure_provider_hooks(provider=item, mycel_home=mycel_home)
        statuses[item] = provider_hook_status(provider=item, mycel_home=mycel_home)
    return statuses


# ── group ─────────────────────────────────────────────────────


@group_app.command("create")
def group_create(
    terminal: str = typer.Option(
        "", "--terminal", help="Terminal type: cmux|tmux|terminal|kitty|iterm2"
    ),
    workers_enabled: str = typer.Option(
        "", "--workers-enabled", help="Worker roles: true|false"
    ),
    no_workers: bool = typer.Option(
        False,
        "--no-workers",
        help="Create the group without worker roles.",
    ),
) -> None:
    authorize_operation(OperationName.GROUP_CREATE)
    require_global()
    # Resolve terminal: explicit flag > cel default > built-in default
    if terminal:
        if terminal not in VALID_TERMINALS:
            typer.echo(
                f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}",
                err=True,
            )
            raise typer.Exit(1)
        resolved_terminal = terminal
    else:
        resolved_terminal = default_terminal_global()
    workers_enabled_flag = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=no_workers,
        context_label="workers-enabled",
    )
    resolved_workers_enabled = (
        workers_enabled_flag
        if workers_enabled_flag is not None
        else workers_enabled_global()
    )
    try:
        cfg = load_owner_config()
        client = Client(base_url=cfg.base_url, auth_token=cfg.auth_token)
        chat = client.chats.create([], title="cel group", kind="group")
        if not isinstance(chat, dict):
            raise RuntimeError("backend did not return a group chat payload")
        group_id = str(chat.get("id") or chat.get("chat_id") or "").strip()
        if not group_id:
            raise RuntimeError("backend did not return a group chat id")
        header = create_workflow(
            group_id,
            terminal_type=resolved_terminal,
            workers_enabled=resolved_workers_enabled,
        )
        create_group(group_id)
        mirror_header(group_id, header)
    except (RuntimeError, ValueError) as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(
        f"Group '{group_id}' 已创建。"
        f"(terminal: {resolved_terminal}, "
        f"worker roles: {'enabled' if resolved_workers_enabled else 'disabled'})"
    )


@group_app.command("update")
def group_update(
    group_id: str = typer.Argument(...),
    prompt: str = typer.Argument(""),
    terminal: str = typer.Option(
        "", "--terminal", help="Change terminal type: cmux|tmux|terminal|kitty|iterm2"
    ),
    workers_enabled: str = typer.Option(
        "", "--workers-enabled", help="Change worker roles: true|false"
    ),
    no_workers: bool = typer.Option(
        False, "--no-workers", help="Update the group to run without worker roles."
    ),
) -> None:
    authorize_operation(OperationName.GROUP_UPDATE, group_id=group_id)
    require_global()
    require_group_by_name(group_id)
    workers_enabled_value = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=no_workers,
        context_label="workers-enabled",
    )
    if not prompt and not terminal and workers_enabled_value is None:
        typer.echo(
            "Nothing to update. Provide a prompt or one of --terminal/--workers-enabled.",
            err=True,
        )
        raise typer.Exit(1)
    if terminal and terminal not in VALID_TERMINALS:
        typer.echo(
            f"Invalid terminal '{terminal}'. Choose from: {', '.join(sorted(VALID_TERMINALS))}",
            err=True,
        )
        raise typer.Exit(1)
    try:
        header_patch: dict[str, object] = {}
        if prompt:
            header_patch["group_prompt"] = prompt
        if terminal:
            header_patch["terminal_type"] = terminal
        if workers_enabled_value is not None:
            header_patch["workers_enabled"] = workers_enabled_value
        header = set_header(group_id, **header_patch)
        mirror_header(group_id, header)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Group '{group_id}' 已更新。")
    # Signal daemon to sync updated group to reviewers
    from mycel_cli.group._daemon.constants import group_sync_signal_file

    group_sync_signal_file(group_id).write_text("")


@group_app.command("remove")
def group_remove(group_id: str = typer.Argument(...)) -> None:
    authorize_operation(OperationName.GROUP_REMOVE, group_id=group_id)
    require_global()
    group = load_group(group_id)
    worker_sessions: list[str] = []
    if group is not None:
        supervisor = find_supervisor(group)
        if supervisor:
            worker_sessions.append(supervisor["session"])
            _spawn_mod.kill_and_close_worker(supervisor, group)
            typer.echo(f"  Supervisor {supervisor['session'][:8]} closed")
        workers = list(iter_workers(group))
        if workers:
            worker_sessions.extend(w["session"] for w in workers)
            for w in workers:
                _spawn_mod.kill_and_close_worker(w, group)
            typer.echo(
                f"  {len(workers)} worker{'s' if len(workers) > 1 else ''} closed"
            )
        reviewers = list(iter_reviewers(group_id))
        if reviewers:
            for r in reviewers:
                if r.get("session"):
                    worker_sessions.append(r["session"])
                _spawn_mod.kill_and_close_worker(r, group)
                typer.echo(
                    f"  Reviewer {r.get('name', r['id'])} ({r['id'][:8]}) closed"
                )
        ref = group.get("terminal_container")
        if ref:
            try:
                from mycel_cli.group.terminal import get_terminal

                get_terminal(group_terminal_type(group)).close_group_container(ref)
            except Exception as exc:
                _log.warning("close_group_container %r: %s", ref, exc)
    try:
        delete_header(group_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if not delete_group(group_id):
        typer.echo(f"Group '{group_id}' 不存在", err=True)
        raise typer.Exit(1)
    from mycel_cli.group._daemon import memory_state

    memory_state.purge_group(group_id, worker_sessions)
    typer.echo(f"  Group {group_id} deleted")


@group_app.command("list")
@group_app.command("ls")
def group_list() -> None:
    require_global()
    names = list_groups()
    if not names:
        typer.echo("没有 group。")
        return
    lines = ["Groups:"]
    for name in names:
        group = load_group(name)
        if group is None:
            continue
        task_count = len(list_tasks(name))
        lines.append(
            f"  {name} — {len(iter_workers(group))} workers, {task_count} tasks"
        )
    typer.echo("\n".join(lines))


@group_app.command("show")
def group_show(group_id: str = typer.Argument(...)) -> None:
    require_global()
    try:
        group = _require_group_with_backend_header(group_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    lines = [f"Group '{group_id}':"]
    lines.append(f"  状态: {group['status']}")
    lines.append(f"  Terminal: {group_terminal_type(group)}")
    worker_roles = "enabled" if is_workers_enabled_for_group(group) else "disabled"
    lines.append(f"  Worker Roles: {worker_roles}")
    lines.append(f"  创建时间: {format_timestamp(group.get('created_at'))}")
    prompt = group.get("group_prompt")
    lines.append(f"  Prompt: {resolve_content(prompt) if prompt else '(未设置)'}")
    lines.append("  Tasks: Mycel chat task store")
    typer.echo("\n".join(lines))


@group_app.command(
    "start",
    help=(
        "mark a group active and let the local service deliver supervisor, "
        "reviewer, and worker events"
    ),
)
def group_start(group_id: str = typer.Argument(...)) -> None:
    authorize_operation(OperationName.GROUP_START, group_id=group_id)
    require_global()
    try:
        group = _require_group_with_backend_header(group_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    # Pre-flight: verify stop hook is wired up
    # Pre-flight checks: require supervisor AND at least one reviewer
    supervisor = find_supervisor(group)
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError:
        reviewers = []

    missing: list[str] = []
    if not supervisor:
        missing.append(
            f"  注册 Supervisor: cel group {group_id} supervisor create --name <name>"
        )
    if not reviewers:
        missing.append(
            f"  添加 Reviewer:   cel group {group_id} reviewer create --name <name>"
        )
    else:
        missing_events = missing_review_events(reviewers)
        for event_type in missing_events:
            label = REVIEW_EVENT_LABELS[event_type]
            missing.append(f"  Reviewer 覆盖缺失: {label} 需要至少一个 reviewer 处理")
    if missing:
        typer.echo(
            f"Group '{group_id}' 无法启动：需要 Supervisor，且 3 个 review 事件都至少有一个 reviewer 覆盖。\n"
            + "\n".join(missing),
            err=True,
        )
        raise typer.Exit(1)

    agent_types = {
        role_agent_type(supervisor),
        *(normalize_agent_type(r.get("agent_type")) for r in reviewers),
    }
    check_stop_hook_or_fail(agent_types)

    try:
        header = set_header(group_id, state="active")
        group = mirror_header(group_id, header)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    cancel_pending_group_stop(group_id)
    group_start_signal_file(group_id).write_text("")
    typer.echo(f"Group '{group_id}' 已启动。\n")

    issues: list[str] = []

    sup_label = supervisor.get("name") or supervisor.get("session", "?")
    typer.secho(f"  ✓ Supervisor: {sup_label}", fg=typer.colors.GREEN)

    if reviewers:
        reviewer_labels = ", ".join(
            r.get("name") or r.get("id", "?") for r in reviewers
        )
        typer.secho(
            f"  ✓ Reviewers ({len(reviewers)}): {reviewer_labels}",
            fg=typer.colors.GREEN,
        )
        coverage = review_event_coverage(reviewers)
        coverage_summary = "; ".join(
            f"{REVIEW_EVENT_LABELS[event_type]}=" + ",".join(coverage[event_type])
            for event_type in REQUIRED_REVIEW_EVENTS
        )
        typer.secho(f"  ✓ Review Coverage: {coverage_summary}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Reviewers: 无", fg=typer.colors.YELLOW)
        issues.append(
            f"无 Reviewer——task 送审后无人判决。添加：cel group {group_id} reviewer create --name <name>"
        )

    workers = iter_workers(group)
    workers_enabled = is_workers_enabled_for_group(group)
    if not workers_enabled:
        typer.secho(
            "  ✓ Workers: disabled for this group",
            fg=typer.colors.GREEN,
        )
    elif workers:
        labels = ", ".join(w.get("name") or w.get("session", "?") for w in workers)
        typer.secho(f"  ✓ Workers ({len(workers)}): {labels}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Workers: 无", fg=typer.colors.YELLOW)
        issues.append("无 Worker——无法执行任务")

    tasks = list_tasks(group_id)
    pending = [t for t in tasks if t.get("status") not in {"completed", "deleted"}]
    if tasks:
        typer.secho(
            f"  ✓ Tasks: {len(pending)} pending / {len(tasks)} total",
            fg=typer.colors.GREEN,
        )
    else:
        typer.secho("  ✗ Tasks: 无", fg=typer.colors.YELLOW)
        issues.append("Task 队列为空——Supervisor 收到 start 后无任务可推进")

    if issues:
        typer.echo("")
        for issue in issues:
            typer.secho(f"  ⚠  {issue}", fg=typer.colors.YELLOW)


@group_app.command(
    "stop",
    help="request or record group shutdown through the supervisor/reviewer flow",
)
def group_stop(
    group_id: str = typer.Argument(...),
    rationale: str | None = typer.Option(
        None, "--rationale", help="停止原因文件路径（说明 group 为何完成）"
    ),
    status: str | None = typer.Option(
        None, "--status", help="reviewer 决策状态：stopped 或 active"
    ),
    force: bool = typer.Option(
        False, "--force", help="跳过 reviewer 审批，直接强制停止"
    ),
) -> None:
    require_global()
    try:
        group = _require_group_with_backend_header(group_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    decision = authorize_group_stop(
        group_id,
        group,
        force=force,
    )
    actor = decision.actor
    desired_status = status or "stopped"

    if force and desired_status != "stopped":
        typer.echo("--force 只允许与 stopped 一起使用。", err=True)
        raise typer.Exit(2)

    if force:
        try:
            header = set_header(group_id, state="stopped")
            mirror_header(group_id, header)
        except RuntimeError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(1)
        cancel_pending_group_stop(group_id)
        typer.echo(f"Group '{group_id}' 已强制停止。")
        return

    if actor.role == ActorRole.REVIEWER:
        if desired_status not in {"stopped", "active"}:
            typer.echo("--status 只允许 stopped 或 active。", err=True)
            raise typer.Exit(2)
        reviewer = get_role(group_id, str(actor.user_session or ""), role="reviewer")
        rationale_path = None
        if rationale is not None:
            rationale_path = str(
                ensure_file_in_messages_dir(
                    group,
                    rationale,
                    label="rationale file",
                    record_index=True,
                )
            )
        else:
            rationale_path = persist_user_last_message(
                group_id,
                reviewer,
                event_type="reviewer_last_message",
            )
        event_id = _record_reviewer_group_stop_decision(
            group_id,
            reviewer_id=str(actor.user_session or ""),
            group_status=desired_status,
            rationale_path=str(rationale_path or ""),
        )
        typer.echo(
            f"审批已记录：group -> {desired_status}（batch {event_id}）。等待结算。"
        )
        return

    if desired_status != "stopped":
        typer.echo("supervisor 发起 group stop 时 --status 只能是 stopped。", err=True)
        raise typer.Exit(2)

    # When reviewers are configured, delegate stop decision to daemon/reviewers.
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError:
        reviewers = []

    if reviewers and group.get("status") != "stopped":
        rationale_path: str | None = None
        if rationale is not None:
            rationale_path = str(
                ensure_file_in_messages_dir(
                    group,
                    rationale,
                    label="rationale file",
                    record_index=True,
                )
            )
        _request_group_stop_review(group_id, group, rationale_path)
        return

    # No reviewers or already stopped — stop immediately.
    try:
        header = set_header(group_id, state="stopped")
        mirror_header(group_id, header)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Group '{group_id}' 已停止。")


def _has_open_group_stop_request(group: dict) -> bool:
    group_id = str(group.get("name") or "")
    return bool(_open_group_stop_events(group_id))


def _open_group_stop_events(group_id: str) -> list[dict]:
    return [
        event
        for event in list_review_events(group_id)
        if event.get("type") == EV_GROUP_STOP and not event.get("final_verdict")
    ]


def _open_group_stop_event(group_id: str) -> tuple[str, dict]:
    matches = _open_group_stop_events(group_id)
    if len(matches) != 1:
        typer.echo(
            f"Group '{group_id}' 当前没有唯一的待审批 group stop，reviewer 不能直接行权。",
            err=True,
        )
        raise typer.Exit(1)
    event = matches[0]
    return str(event["id"]), get_review_event(group_id, str(event["id"]))


def _record_reviewer_group_stop_decision(
    group_id: str,
    *,
    reviewer_id: str,
    group_status: str,
    rationale_path: str,
) -> str:
    event_id, event = _open_group_stop_event(group_id)
    reviewer = get_role(group_id, reviewer_id, role="reviewer")
    if not reviewer_covers_event(reviewer, EV_GROUP_STOP):
        typer.echo(
            f"reviewer '{reviewer_id[:8]}' 未覆盖 group_stop，不能审批该事项。",
            err=True,
        )
        raise typer.Exit(1)
    resource_states = dict(event.get("user_resource_states") or {})
    resource_states[reviewer_id] = {"group": group_status}
    rationales = dict(event.get("user_rationales") or {})
    rationales[reviewer_id] = rationale_path
    update_review_event(
        group_id,
        event_id,
        user_resource_states=resource_states,
        user_rationales=rationales,
    )
    return event_id


def _request_group_stop_review(
    group_id: str, group: dict, rationale: str | None
) -> None:
    """Request a group_stop review and return immediately."""
    signal_path = group_stop_signal_file(group_id)
    if signal_path.exists() or _has_open_group_stop_request(group):
        typer.echo(
            f"Group '{group_id}' 已有未结算的 group stop 审批；等待 review_result 后再决定下一轮。",
            err=True,
        )
        raise typer.Exit(1)
    signal_path.write_text(rationale or "", encoding="utf-8")
    typer.echo(
        f"你无权直接停止 group '{group_id}'；系统已上报给有权限的 reviewer 审批。等待后续 review_result。"
    )


def _reviewer_rationale_text(event: dict) -> str:
    parts: list[str] = []
    resource_states = dict(event.get("user_resource_states") or {})
    for reviewer_id, rationale_path in dict(event.get("user_rationales") or {}).items():
        reviewer_state = resource_states.get(reviewer_id)
        returned = (
            isinstance(reviewer_state, dict) and reviewer_state.get("group") == "active"
        )
        if not returned:
            continue
        rationale_text = read_mycel_home_text(
            rationale_path,
            missing_message="(rationale file not found: {path})",
            outside_message="(blocked: outside MYCEL_HOME: {path})",
        )
        parts.append(f"\n[{reviewer_id}] {rationale_text}")
    if parts:
        return "".join(parts)

    rationale_path = event.get("rationale", "")
    if not rationale_path:
        return ""
    return "\n" + read_mycel_home_text(
        rationale_path,
        missing_message="(rationale file not found: {path})",
        outside_message="(blocked: outside MYCEL_HOME: {path})",
    )


def _parse_workers_enabled_override_or_fail(
    *,
    workers_enabled: str,
    no_workers: bool,
    context_label: str,
) -> bool | None:
    if no_workers and workers_enabled:
        typer.echo(f"Cannot combine --no-workers with --{context_label}.", err=True)
        raise typer.Exit(1)
    if no_workers:
        return False
    if not workers_enabled:
        return None
    lower = workers_enabled.lower()
    if lower not in {"true", "false", "1", "0", "yes", "no"}:
        typer.echo(
            f"Invalid value '{workers_enabled}' for {context_label}. Use: true or false",
            err=True,
        )
        raise typer.Exit(1)
    return lower in {"true", "1", "yes"}


def _group_config_lines() -> list[str]:
    worker_roles = "enabled" if workers_enabled_global() else "disabled"
    base_url = effective_base_url()
    return [
        "Cel Defaults:",
        f"  {_base_url_line(base_url)}",
        f"  Default Terminal: {default_terminal_global()}",
        f"  Worker Roles: {worker_roles}",
    ]


def _base_url_line(base_url: dict[str, str]) -> str:
    return f"Base URL: {base_url['base_url']} ({base_url['source']})"


if __name__ == "__main__":
    app()
