"""Install provider Stop hooks used by the local Mycel service."""

from __future__ import annotations

import shlex
from pathlib import Path
from typing import Any

import typer

from mycel_cli.group.agent_types import (
    providers_for_agent_types,
    resolve_provider_selection,
)
from mycel_cli.group._cli.identity_env import (
    ENV_MYCEL_GROUP_ID,
    ENV_MYCEL_USER_SESSION,
)
from mycel_cli.providers.hook_settings import (
    codex_config_path,
    ensure_codex_hooks_feature,
    load_json_object,
    provider_dir,
    provider_config_home,
    provider_settings_path,
    write_json_object,
)
from mycel_cli.providers.hooks import MYCEL_HOOK_OWNER_KEY

HOOK_PURPOSE = "group-stop"


def install_stop_hooks(provider: str, *, home: Path | None = None) -> dict[str, Any]:
    base = home or provider_config_home()
    providers = resolve_provider_selection(provider)
    return {
        "installed": [
            _install_provider_stop_hook(provider=item, home=base) for item in providers
        ]
    }


def stop_hook_status(
    provider: str = "all", *, home: Path | None = None
) -> dict[str, Any]:
    base = home or provider_config_home()
    providers = resolve_provider_selection(provider)
    return {
        item: {
            "installed": _is_stop_hook_installed(provider=item, home=base),
            "script": str(_script_path(provider=item, home=base)),
            "settings": str(provider_settings_path(item, base)),
        }
        for item in providers
    }


def check_stop_hook_or_fail(agent_types: set[str] | None = None) -> None:
    providers = providers_for_agent_types(agent_types)
    status = stop_hook_status()
    missing = [provider for provider in providers if not status[provider]["installed"]]
    if not missing:
        return

    typer.echo(
        "Group 无法启动：stop hook 未生效，worker 完成后 supervisor 将收不到通知。\n"
        "修复：运行 `cel self start` 让本地 daemon 重新安装 provider hooks。\n"
        + "\n".join(
            f"  {provider}: {status[provider]['script']} -> {status[provider]['settings']}"
            for provider in missing
        ),
        err=True,
    )
    raise typer.Exit(1)


def remove_stop_hooks(
    provider: str = "all", *, home: Path | None = None
) -> dict[str, Any]:
    base = home or provider_config_home()
    providers = resolve_provider_selection(provider)
    removed: list[str] = []
    for item in providers:
        script = _script_path(provider=item, home=base)
        settings_path = provider_settings_path(item, base)
        settings = load_json_object(settings_path, label=f"{item} hooks")
        changed = _remove_stop_entries(settings, provider=item)
        existed = script.exists()
        if changed and settings_path.exists():
            write_json_object(settings_path, settings)
        if script.exists():
            script.unlink()
        if changed or existed:
            removed.append(item)
    return {"removed": removed}


def _install_provider_stop_hook(*, provider: str, home: Path) -> dict[str, str]:
    script = _script_path(provider=provider, home=home)
    script.parent.mkdir(parents=True, exist_ok=True)
    script.write_text(render_stop_hook_script(), encoding="utf-8")
    script.chmod(0o755)
    _install_stop_entry(
        provider=provider, home=home, command=f"bash {shlex.quote(str(script))}"
    )
    return {
        "provider": provider,
        "script": str(script),
        "settings": str(provider_settings_path(provider, home)),
    }


def render_stop_hook_script() -> str:
    return (
        "#!/bin/bash\n"
        "set -euo pipefail\n"
        "INPUT=$(cat)\n"
        "MYCEL_WRITTEN_AT=$(python3 - <<'PY'\n"
        "import time\n"
        "print(time.time())\n"
        "PY\n"
        ")\n"
        "SESSION_ID=$(echo \"$INPUT\" | jq -r '.session_id')\n"
        f'USER_SESSION="${{{ENV_MYCEL_USER_SESSION}:-${{SESSION_ID}}}}"\n'
        'STATE_DIR="${MYCEL_HOME:-$HOME/.mycel}"\n'
        'ENRICHED=$(echo "$INPUT" | jq '
        '--arg mycel_written_at "$MYCEL_WRITTEN_AT" '
        f'--arg mycel_group_id "${{{ENV_MYCEL_GROUP_ID}:-}}" '
        f'--arg mycel_user_session "$USER_SESSION" '
        "'. + {"
        "mycel_written_at: $mycel_written_at,"
        "mycel_group_id: $mycel_group_id,"
        "mycel_user_session: $mycel_user_session,"
        "}')\n"
        'printf \'%s\' "$ENRICHED" > "$STATE_DIR/stop-${USER_SESSION}"\n'
    )


def _script_path(*, provider: str, home: Path) -> Path:
    return provider_dir(provider, home) / "cel-on-stop.sh"


def _is_stop_hook_installed(*, provider: str, home: Path) -> bool:
    script = _script_path(provider=provider, home=home)
    command = f"bash {shlex.quote(str(script))}"
    return (
        script.exists()
        and _hook_script_is_current(script)
        and _has_stop_entry(provider=provider, home=home, command=command)
    )


def _install_stop_entry(*, provider: str, home: Path, command: str) -> None:
    if provider == "codex":
        ensure_codex_hooks_feature(codex_config_path(home))
    path = provider_settings_path(provider, home)
    settings = load_json_object(path, label=f"{provider} hooks")
    hooks_root = settings.setdefault("hooks", {})
    if not isinstance(hooks_root, dict):
        raise RuntimeError(f"hook settings must contain a JSON object at hooks: {path}")
    entries = hooks_root.setdefault("Stop", [])
    if not isinstance(entries, list):
        raise RuntimeError(f"hook settings hooks.Stop must be a list: {path}")
    hooks_root["Stop"] = [
        entry
        for entry in entries
        if not _entry_is_this_stop_hook(entry, provider=provider, command=command)
    ]
    hooks_root["Stop"].append(
        {
            MYCEL_HOOK_OWNER_KEY: {
                "owner": "mycel",
                "provider": provider,
                "purpose": HOOK_PURPOSE,
            },
            "hooks": [{"type": "command", "command": command}],
        }
    )
    write_json_object(path, settings)


def _has_stop_entry(*, provider: str, home: Path, command: str) -> bool:
    settings = load_json_object(
        provider_settings_path(provider, home), label=f"{provider} hooks"
    )
    hooks_root = settings.get("hooks")
    if not isinstance(hooks_root, dict):
        return False
    entries = hooks_root.get("Stop")
    if not isinstance(entries, list):
        return False
    return any(_entry_has_stop_command(entry, command=command) for entry in entries)


def _remove_stop_entries(settings: dict[str, Any], *, provider: str) -> bool:
    hooks_root = settings.get("hooks")
    if not isinstance(hooks_root, dict):
        return False
    entries = hooks_root.get("Stop")
    if not isinstance(entries, list):
        return False
    next_entries = [
        entry
        for entry in entries
        if not _entry_is_owned_stop_hook(entry, provider=provider)
    ]
    changed = len(next_entries) != len(entries)
    if next_entries:
        hooks_root["Stop"] = next_entries
    elif changed:
        del hooks_root["Stop"]
    return changed


def _entry_is_this_stop_hook(entry: object, *, provider: str, command: str) -> bool:
    if not isinstance(entry, dict):
        return False
    if _entry_is_owned_stop_hook(entry, provider=provider):
        return True
    return _entry_has_stop_command(entry, command=command)


def _entry_is_owned_stop_hook(entry: object, *, provider: str) -> bool:
    if not isinstance(entry, dict):
        return False
    owner = entry.get(MYCEL_HOOK_OWNER_KEY)
    return (
        isinstance(owner, dict)
        and owner.get("owner") == "mycel"
        and owner.get("provider") == provider
        and owner.get("purpose") == HOOK_PURPOSE
    )


def _entry_has_stop_command(entry: object, *, command: str) -> bool:
    if not isinstance(entry, dict):
        return False
    hooks = entry.get("hooks")
    if not isinstance(hooks, list):
        return False
    return any(
        isinstance(hook, dict) and hook.get("command") == command for hook in hooks
    )


def _hook_script_is_current(hook_script: Path) -> bool:
    try:
        text = hook_script.read_text(encoding="utf-8")
    except OSError:
        return False
    required_markers = (
        "MYCEL_GROUP_ID",
        "MYCEL_USER_SESSION",
        "USER_SESSION",
        "MYCEL_WRITTEN_AT",
        "mycel_written_at",
        "mycel_user_session",
    )
    return all(marker in text for marker in required_markers)
