"""Thin Mycel chat transport adapter for group-scoped messages."""

from __future__ import annotations

from typing import Any

from mycel_sdk import Client

from mycel_cli.identity_store import IdentityStore

_SENDER_ID_FIELD = "sender" + "_id"


def visible_group_bodies(
    messages: list[dict[str, Any]], *, sender_user_id: str
) -> list[str]:
    bodies: list[str] = []
    for message in messages:
        if str(message.get(_SENDER_ID_FIELD) or "") != sender_user_id:
            continue
        raw = str(message.get("content") or message.get("text") or "").strip()
        if not raw:
            continue
        bodies.append(raw)
    return [body for body in bodies if body]


def group_chat_for(
    *, group_id: str, sender: dict, recipient: dict
) -> tuple[Client, str]:
    source_identity = identity_for(sender)
    require_user_id(recipient)
    client = Client(
        auth_token=str(source_identity["auth_token"]),
        base_url=str(source_identity["base_url"]),
    )
    return client, group_id


def describe_group_route(*, chat_id: str, sender: dict, recipient: dict) -> str:
    source_identity = identity_for(sender)
    target_identity = identity_for(recipient)
    return (
        f"Resolved: chat_id={chat_id}, "
        f"from user_id={_identity_user_id(source_identity, sender)} "
        f"(local_id={source_identity['local_id']}, session={sender.get('session')}), "
        f"to user_id={_identity_user_id(target_identity, recipient)} "
        f"(local_id={target_identity['local_id']}, session={recipient.get('session')})."
    )


def require_user_id(user: dict) -> None:
    user_id_for(user)


def user_id_for(user: dict) -> str:
    identity = identity_for(user)
    user_id = str(identity.get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError(f"group role {user.get('session')!r} has no user_id")
    return user_id


def _identity_user_id(identity: dict, user: dict) -> str:
    user_id = str(identity.get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError(f"group role {user.get('session')!r} has no user_id")
    return user_id


def identity_for(user: dict) -> dict:
    local_id = str(user.get("local_id") or "").strip()
    if not local_id:
        raise RuntimeError(f"group role {user.get('session')!r} has no Mycel identity")
    identity = IdentityStore.from_env().get_identity(local_id)
    return {"local_id": local_id, **identity}
