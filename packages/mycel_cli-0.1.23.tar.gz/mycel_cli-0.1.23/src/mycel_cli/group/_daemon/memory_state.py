"""Daemon in-memory state + disk persistence.

All dicts/sets here are **module-level singletons**. Importers must reference
them via attribute (`memory_state._last_notify`) rather than rebinding names,
otherwise updates will not be seen across modules.

`load()` is called once from `run_daemon` startup; `save()` is called after any
mutation that must survive a daemon restart.
"""

from __future__ import annotations

import json

from mycel_cli.group._daemon import constants as _constants
from mycel_cli.group._daemon.constants import log
from mycel_cli.group._state.groups import list_groups, load_group
from mycel_cli.group._state.roles import iter_roles
from mycel_cli.group._state.paths import atomic_write_text

# ── Per-(group, session) throttling ─────────────────────────────
# key format: "group:session"
last_notify: dict[str, float] = {}
last_silent: dict[str, float] = {}

# ── Silent escalation state ───────────────────────────────────────
silent_count: dict[str, int] = {}
silent_closed: set[str] = set()  # A0 terminal — stop re-announcing

# ── First-stop suppression ────────────────────────────────────────
# cel 管理的 user（worker / reviewer）在 bootstrap 阶段都会自然 stop
# 一次；这个首个 stop 只用于确认会话已 ready，不应进入业务事件流。
first_stop_suppressed: set[str] = set()

# ── Idle tracking ─────────────────────────────────────────────────
idle_since: dict[str, float] = {}
idle_fired: set[str] = set()

# ── Review event dispatch ─────────────────────────────────────────
# key: "group:event_id"
review_dispatched: set[str] = set()
# {group_name: event_id}
pending_stop_event: dict[str, str] = {}
_dirty = False


def load() -> None:
    """Restore daemon memory state on daemon startup.

    Two kinds of state are restored here:
    - **Persisted** (read from disk): the transient throttling / silent /
      idle / review-dispatch containers written by ``save()``.
    - **Derived** (rebuilt from group state): ``first_stop_suppressed`` is
      not persisted because its single source of truth is
      ``user.bootstrapped`` — every already-bootstrapped user
      must cel its first real stop unsuppressed.

    Each container is mutated in-place (``.clear()`` + ``.update()``) rather
    than rebound, so existing module references keep pointing at the same live
    objects.
    """
    try:
        state_file = _constants.DAEMON_STATE_FILE
        if state_file.exists():
            data = json.loads(state_file.read_text())

            def _replace_dict(target: dict, src: dict) -> None:
                target.clear()
                target.update(src)

            def _replace_set(target: set, src) -> None:
                target.clear()
                target.update(src)

            _replace_dict(last_notify, data.get("last_notify", {}))
            _replace_dict(last_silent, data.get("last_silent", {}))
            _replace_dict(silent_count, data.get("silent_count", {}))
            _replace_set(silent_closed, data.get("silent_closed", []))
            _replace_dict(idle_since, data.get("idle_since", {}))
            _replace_set(idle_fired, data.get("idle_fired", []))
            _replace_set(review_dispatched, data.get("review_dispatched", []))
            _replace_dict(pending_stop_event, data.get("pending_stop_event", {}))
            log.info(
                "Loaded daemon memory state: %d silent keys, %d closed",
                len(silent_count),
                len(silent_closed),
            )
    except Exception as e:
        log.warning("Failed to load daemon memory state, starting fresh: %s", e)

    first_stop_suppressed.clear()
    for mn in list_groups():
        m = load_group(mn)
        if not m:
            continue
        for user in iter_roles(m):
            if user.get("bootstrapped", False):
                first_stop_suppressed.add(user["session"])
    if first_stop_suppressed:
        log.info(
            "Rebuilt first_stop_suppressed from groups: %d sessions",
            len(first_stop_suppressed),
        )
    global _dirty
    _dirty = False


def save() -> None:
    """Atomically persist daemon memory state so it survives daemon restart."""
    global _dirty
    try:
        data = {
            "last_notify": last_notify,
            "last_silent": last_silent,
            "silent_count": silent_count,
            "silent_closed": list(silent_closed),
            "idle_since": idle_since,
            "idle_fired": list(idle_fired),
            "review_dispatched": list(review_dispatched),
            "pending_stop_event": pending_stop_event,
        }
        atomic_write_text(_constants.DAEMON_STATE_FILE, json.dumps(data))
        _dirty = False
    except Exception as e:
        log.warning("Failed to save daemon memory state: %s", e)


def mark_dirty() -> None:
    global _dirty
    _dirty = True


def flush_if_dirty() -> None:
    if _dirty:
        save()


def purge_worker(group_name: str, session: str) -> None:
    """Drop every daemon-state entry tied to a single (group, session).

    Call after CLI removes a worker so stale throttling/silent/suppression
    state doesn't leak. The live daemon keeps its own in-memory copy, so a
    subsequent restart is what actually adopts the clean state.
    """
    key = f"{group_name}:{session}"
    last_notify.pop(key, None)
    last_silent.pop(key, None)
    silent_count.pop(key, None)
    silent_closed.discard(key)
    first_stop_suppressed.discard(session)
    save()


def purge_group(group_name: str, worker_sessions: list[str]) -> None:
    """Drop every daemon-state entry tied to a group.

    `worker_sessions` must be collected *before* group deletion since we
    need the bare session ids to evict `first_stop_suppressed` (keyed by
    session, not group:session).
    """
    worker_keys = {f"{group_name}:{s}" for s in worker_sessions}
    for s in worker_sessions:
        first_stop_suppressed.discard(s)

    for container in (last_notify, last_silent, silent_count):
        for k in list(container.keys()):
            if k in worker_keys:
                container.pop(k, None)
    for k in list(silent_closed):
        if k in worker_keys:
            silent_closed.discard(k)

    # group-only keys
    idle_since.pop(group_name, None)
    idle_fired.discard(group_name)
    pending_stop_event.pop(group_name, None)

    # group:event_id keys (review_dispatched)
    prefix = f"{group_name}:"
    for k in list(review_dispatched):
        if k.startswith(prefix):
            review_dispatched.discard(k)

    save()
