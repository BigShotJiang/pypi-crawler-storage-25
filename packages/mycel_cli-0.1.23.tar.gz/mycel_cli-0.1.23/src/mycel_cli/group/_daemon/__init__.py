"""Internal daemon package.

Modules are split by responsibility (memory_state, xml_format, notify,
review, worker_check, idle, loop). The unified process entry point is
`mycel_cli.daemon.main`; this package owns only the group-loop task.
"""
