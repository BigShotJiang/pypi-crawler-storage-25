from __future__ import annotations

import shlex
import shutil
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from mycel_cli.providers.hook_settings import (
    codex_config_path,
    ensure_codex_hooks_feature,
    load_json_object,
    provider_config_home,
    provider_settings_path,
    write_json_object,
)


@dataclass(frozen=True)
class HookSpec:
    matcher: str | None = None
    command_args: tuple[str, ...] = ()
    hook_options: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProviderHookSpec:
    settings_label: str
    events: dict[str, HookSpec]
    prepare: Callable[[Path], None] | None = None


def _prepare_codex_hooks(home: Path) -> None:
    ensure_codex_hooks_feature(codex_config_path(home))


CODEX_HOOK_EVENTS: dict[str, HookSpec] = {
    "SessionStart": HookSpec(matcher="startup|resume"),
    "UserPromptSubmit": HookSpec(),
    "PostToolUse": HookSpec(matcher=".*"),
    "PostToolUseFailure": HookSpec(matcher=".*"),
    "Notification": HookSpec(matcher=".*"),
}

CLAUDE_HOOK_EVENTS: dict[str, HookSpec] = {
    "SessionStart": HookSpec(matcher="startup|resume|compact"),
    "UserPromptSubmit": HookSpec(),
    "PostToolUse": HookSpec(),
    "PostToolUseFailure": HookSpec(),
    "Notification": HookSpec(),
    "Stop": HookSpec(
        command_args=("--rewake",),
        hook_options={"asyncRewake": True},
    ),
}

PROVIDER_HOOK_SPECS: dict[str, ProviderHookSpec] = {
    "codex": ProviderHookSpec(
        settings_label="Codex hooks",
        events=CODEX_HOOK_EVENTS,
        prepare=_prepare_codex_hooks,
    ),
    "claude": ProviderHookSpec(
        settings_label="Claude Code settings",
        events=CLAUDE_HOOK_EVENTS,
    ),
}

MYCEL_HOOK_OWNER_KEY = "_mycel"
MYCEL_HOOK_PURPOSE_INBOX = "inbox"


def provider_hook_spec(provider: str) -> ProviderHookSpec:
    try:
        return PROVIDER_HOOK_SPECS[provider]
    except KeyError as exc:
        raise RuntimeError(f"unsupported provider: {provider}") from exc


def ensure_provider_hooks(*, provider: str, mycel_home: Path) -> None:
    home = provider_config_home()
    spec = provider_hook_spec(provider)
    script_path = _provider_hook_script_path(provider, home)
    cli_command = _cel_command()
    _write_hook_script(
        script_path,
        provider=provider,
        cli_command=cli_command,
    )
    command = " ".join(["bash", shlex.quote(str(script_path))])
    _ensure_provider_hook_entries(
        home=home,
        command=command,
        provider=provider,
        spec=spec,
    )


def provider_hook_status(*, provider: str, mycel_home: Path) -> dict[str, Any]:
    provider_hook_spec(provider)
    home = provider_config_home()
    script_path = _provider_hook_script_path(provider, home)
    settings_path = provider_settings_path(provider, home)
    settings = load_json_object(settings_path, label=f"{provider} hooks")
    command = " ".join(["bash", shlex.quote(str(script_path))])
    return {
        "provider": provider,
        "installed": script_path.exists()
        and _has_current_provider_hook_entries(
            settings, provider=provider, command=command
        ),
        "script": str(script_path),
        "settings": str(settings_path),
    }


def remove_provider_hooks(*, provider: str, mycel_home: Path) -> dict[str, Any]:
    provider_hook_spec(provider)
    home = provider_config_home()
    script_path = _provider_hook_script_path(provider, home)
    settings_path = provider_settings_path(provider, home)
    settings = load_json_object(settings_path, label=f"{provider} hooks")
    _remove_provider_hook_entries(settings, provider=provider)
    if settings_path.exists():
        write_json_object(settings_path, settings)
    if script_path.exists():
        script_path.unlink()
    return {"provider": provider, "removed": True}


def _write_hook_script(path: Path, *, provider: str, cli_command: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "#!/usr/bin/env bash",
        "set -euo pipefail",
        'payload="$(cat)"',
        'printf "%s" "$payload" | '
        + " ".join(
            [
                "env",
                f"MYCEL_CLI_COMMAND={shlex.quote(cli_command)}",
                shlex.quote(cli_command),
                "internal",
                "hook",
                shlex.quote(provider),
                '"$@"',
            ]
        ),
    ]
    text = "\n".join(lines) + "\n"
    if not path.exists() or path.read_text(encoding="utf-8") != text:
        path.write_text(text, encoding="utf-8")
    path.chmod(0o755)


def _provider_hook_script_path(provider: str, home: Path) -> Path:
    return provider_settings_path(provider, home).parent / "mycel-inbox-hook.sh"


def _cel_command() -> str:
    command = shutil.which("cel")
    if command:
        return str(Path(command).resolve())
    return "cel"


def _ensure_provider_hook_entries(
    *,
    home: Path,
    command: str,
    provider: str,
    spec: ProviderHookSpec,
) -> None:
    settings_path = provider_settings_path(provider, home)
    if spec.prepare is not None:
        spec.prepare(home)
    settings = load_json_object(settings_path, label=spec.settings_label)
    _remove_provider_hook_entries(settings, provider=provider)
    _ensure_events(settings, spec.events, command, provider=provider)
    write_json_object(settings_path, settings)


def _ensure_events(
    settings: dict[str, Any],
    events: dict[str, HookSpec],
    command: str,
    *,
    provider: str,
) -> None:
    hooks_root = settings.setdefault("hooks", {})
    if not isinstance(hooks_root, dict):
        raise RuntimeError("hook settings must contain a JSON object at hooks")
    for event, spec in events.items():
        entries = hooks_root.setdefault(event, [])
        if not isinstance(entries, list):
            raise RuntimeError(f"hook settings hooks.{event} must be a list")
        event_command = _command_with_args(command, spec.command_args)
        if _entries_have_owned_command(entries, event_command, provider=provider):
            continue
        hook = {"type": "command", "command": event_command}
        hook.update(spec.hook_options)
        entry: dict[str, Any] = {
            MYCEL_HOOK_OWNER_KEY: {
                "owner": "mycel",
                "provider": provider,
                "purpose": MYCEL_HOOK_PURPOSE_INBOX,
            },
            "hooks": [hook],
        }
        if spec.matcher is not None:
            entry["matcher"] = spec.matcher
        entries.append(entry)


def _command_with_args(command: str, args: tuple[str, ...]) -> str:
    if not args:
        return command
    return " ".join([command, *(shlex.quote(arg) for arg in args)])


def _entries_have_owned_command(
    entries: list[Any], command: str, *, provider: str
) -> bool:
    for entry in entries:
        if _entry_is_owned_provider_hook(
            entry, provider=provider, purpose=MYCEL_HOOK_PURPOSE_INBOX
        ) and _entry_has_command(entry, command):
            return True
    return False


def _remove_provider_hook_entries(settings: dict[str, Any], *, provider: str) -> None:
    hooks_root = settings.get("hooks")
    if not isinstance(hooks_root, dict):
        return
    for event in list(hooks_root):
        entries = hooks_root.get(event)
        if not isinstance(entries, list):
            continue
        next_entries = [
            entry
            for entry in entries
            if not _entry_is_owned_inbox_hook(entry, provider=provider)
        ]
        if next_entries:
            hooks_root[event] = next_entries
        else:
            del hooks_root[event]


def _has_current_provider_hook_entries(
    settings: dict[str, Any], *, provider: str, command: str
) -> bool:
    hooks_root = settings.get("hooks")
    if not isinstance(hooks_root, dict):
        return False
    for event, spec in provider_hook_spec(provider).events.items():
        entries = hooks_root.get(event)
        if not isinstance(entries, list):
            return False
        expected = _command_with_args(command, spec.command_args)
        if not any(
            _entry_is_owned_provider_hook(
                entry, provider=provider, purpose=MYCEL_HOOK_PURPOSE_INBOX
            )
            and _entry_has_command(entry, expected)
            for entry in entries
        ):
            return False
    return True


def _entry_has_command(entry: object, command: str) -> bool:
    if not isinstance(entry, dict):
        return False
    hooks = entry.get("hooks")
    if not isinstance(hooks, list):
        return False
    return any(
        isinstance(hook, dict) and hook.get("command") == command for hook in hooks
    )


def _entry_is_owned_inbox_hook(entry: object, *, provider: str) -> bool:
    if not isinstance(entry, dict):
        return False
    owner = entry.get(MYCEL_HOOK_OWNER_KEY)
    return (
        isinstance(owner, dict)
        and owner.get("owner") == "mycel"
        and owner.get("provider") == provider
        and owner.get("purpose") in {None, MYCEL_HOOK_PURPOSE_INBOX}
    )


def _entry_is_owned_provider_hook(
    entry: Any,
    *,
    provider: str,
    purpose: str | None = None,
) -> bool:
    if not isinstance(entry, dict):
        return False
    owner = entry.get(MYCEL_HOOK_OWNER_KEY)
    return (
        isinstance(owner, dict)
        and owner.get("owner") == "mycel"
        and owner.get("provider") == provider
        and (purpose is None or owner.get("purpose") == purpose)
    )
