from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from mycel_cli.group.terminal import get_terminal
from mycel_cli.daemon.paths import rewake_path, wake_path
from mycel_cli.daemon.surfaces import is_group_role_identity, lookup

WAKE_HINT = "Mycel inbox has new messages. Run: cel self inbox read"


def attempt_wake(local_id: str, fresh: list[dict[str, Any]]) -> bool:
    if not fresh or is_group_role_identity(local_id):
        return False
    now = _now()
    if now - _last_time(wake_path(local_id)) < 2.0:
        return False
    if now - _last_time(rewake_path(local_id)) < 30.0:
        return False
    ref = lookup(local_id)
    if ref is None:
        return False
    get_terminal(ref.terminal_type).send_text(ref.target_id, WAKE_HINT)
    _write_time(wake_path(local_id), now)
    return True


def record_rewake(local_id: str) -> None:
    _write_time(rewake_path(local_id), _now())


def _last_time(path: Path) -> float:
    if not path.exists():
        return 0.0
    payload = json.loads(path.read_text(encoding="utf-8") or "{}")
    return float(payload.get("at") or 0.0)


def _write_time(path: Path, at: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps({"at": at}, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)


def _now() -> float:
    return time.time()
