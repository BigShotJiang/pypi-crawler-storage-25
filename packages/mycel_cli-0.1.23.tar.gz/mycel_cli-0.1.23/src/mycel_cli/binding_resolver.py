from __future__ import annotations

import os
from pathlib import Path
from typing import Any, TextIO

from .identity_store import IdentityStore


class BindingResolutionError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        reason: str = "error",
        candidates: list[str] | tuple[str, ...] = (),
    ) -> None:
        super().__init__(message)
        self.reason = reason
        self.candidates = tuple(candidates)


def resolve_binding(
    *,
    store: IdentityStore,
    cwd: Path,
    provider: str | None,
    interactive: bool,
    local_id: str | None = None,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
) -> dict[str, Any]:
    if local_id:
        return _binding_with_id(store, local_id, provider)

    env_local_id = os.getenv("MYCEL_LOCAL_ID")
    if env_local_id:
        return _binding_with_id(store, env_local_id, provider)

    candidates = [
        local_id
        for local_id in store.cwd_identities(cwd)
        if _matches_provider(store, local_id, provider)
    ]
    if len(candidates) == 1:
        return _binding_with_id(store, candidates[0], provider)
    if len(candidates) > 1:
        if interactive:
            return _select_identity(
                store=store,
                candidates=candidates,
                provider=provider,
                stdin=stdin,
                stdout=stdout,
            )
        joined = ", ".join(candidates)
        raise BindingResolutionError(
            f"multiple identities for {cwd}: {joined}",
            reason="multiple",
            candidates=tuple(candidates),
        )

    candidates = [
        local_id
        for local_id in store.identities()
        if _matches_provider(store, local_id, provider)
    ]
    if len(candidates) == 1:
        return _binding_with_id(store, candidates[0], provider)
    if len(candidates) > 1:
        raise _multiple_identities_error(sorted(candidates))

    if interactive:
        raise BindingResolutionError(
            f"no Mycel identity for {cwd}; create one with "
            "cel agent external create <local-id> --provider <provider> "
            "or launch with --identity <local-id>",
            reason="missing",
        )
    raise BindingResolutionError(f"no Mycel identity for {cwd}", reason="missing")


def _select_identity(
    *,
    store: IdentityStore,
    candidates: list[str],
    provider: str | None,
    stdin: TextIO | None,
    stdout: TextIO | None,
) -> dict[str, Any]:
    if stdin is None or stdout is None:
        raise _multiple_identities_error(candidates)
    stdout.write("Multiple Mycel identities are available:\n")
    for index, candidate in enumerate(candidates, start=1):
        identity = store.get_identity(candidate)
        display_name = str(identity.get("display_name") or candidate)
        stdout.write(f"  {index}. {candidate} ({display_name})\n")
    stdout.write(f"Select identity [1-{len(candidates)}]: ")
    try:
        line = stdin.readline().strip()
    except OSError as exc:
        raise _multiple_identities_error(candidates) from exc
    if not line:
        raise BindingResolutionError("identity selection is required")
    try:
        selected_index = int(line)
    except ValueError as exc:
        raise BindingResolutionError(f"invalid identity selection: {line}") from exc
    if selected_index < 1 or selected_index > len(candidates):
        raise BindingResolutionError(f"identity selection out of range: {line}")
    return _binding_with_id(store, candidates[selected_index - 1], provider)


def _multiple_identities_error(candidates: list[str]) -> BindingResolutionError:
    joined = ", ".join(candidates)
    return BindingResolutionError(
        f"multiple identities: {joined}; use --identity <local-id>",
        reason="multiple",
        candidates=tuple(candidates),
    )


def _binding_with_id(
    store: IdentityStore, local_id: str, provider: str | None
) -> dict[str, Any]:
    binding = store.get_identity(local_id)
    if provider is not None and binding.get("provider") != provider:
        raise BindingResolutionError(
            f"identity {local_id} is {binding.get('provider')}, not {provider}"
        )
    return {"local_id": local_id, **binding}


def _matches_provider(
    store: IdentityStore, local_id: str, provider: str | None
) -> bool:
    if provider is None:
        return True
    try:
        binding = store.get_identity(local_id)
    except RuntimeError:
        return False
    return binding.get("provider") == provider
