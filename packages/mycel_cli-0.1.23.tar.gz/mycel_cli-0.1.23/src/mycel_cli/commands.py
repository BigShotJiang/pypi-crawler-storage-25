"""Argument parsing and command dispatch for cel."""

from __future__ import annotations

import argparse
import contextlib
import json
import subprocess
import sys
from collections.abc import Sequence
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, TextIO

from mycel_sdk import Client
from mycel_sdk.errors import ApiError

from .config import (
    DEFAULT_BASE_URL,
    CliConfig,
    effective_base_url,
    load_owner_config,
    load_cli_config,
)
from .handlers import ProcessRequest, RawOutput, command_key, handle_command
from .daemon import surfaces

ROOT_COMMANDS = frozenset(
    {
        "login",
        "logout",
        "contact",
        "agent",
        "send-message",
        "read-message",
        "group",
        "self",
        "codex",
        "claude",
        "internal",
    }
)
GROUP_SHORTCUT_SUBJECTS = frozenset({"task", "supervisor", "worker", "reviewer"})


def _package_version() -> str:
    try:
        return version("mycel-cli")
    except PackageNotFoundError:
        return "0.1.22"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cel",
        description="Mycel command line interface.",
        epilog=(
            "Provider launchers pass native arguments through. "
            "Use `cel codex --identity <local-id> -- ...` or "
            "`cel claude --identity <local-id> -- ...` when a folder has "
            "multiple local agent identities. "
            "Use `cel codex --mycel-status` or `cel claude --mycel-status` "
            "to inspect local Mycel identity, hook, and provider capabilities "
            "without launching the native provider."
        ),
    )
    parser.add_argument(
        "--version",
        "-V",
        action="version",
        version=f"%(prog)s {_package_version()}",
    )

    sub = parser.add_subparsers(dest="command", required=True)
    _add_login_command(sub)
    _add_logout_command(sub)
    _add_contact_command(sub)
    _add_agent_command(sub)
    _add_send_message_command(sub)
    _add_read_message_command(sub)
    _add_group_command(sub)
    _add_self_command(sub)
    _add_provider_command(sub, "codex", "launch Codex with a Mycel identity")
    _add_provider_command(sub, "claude", "launch Claude Code with a Mycel identity")
    return parser


def build_internal_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cel internal",
        description="Internal Mycel CLI implementation commands.",
    )
    sub = parser.add_subparsers(dest="internal_command", required=True)

    hook = sub.add_parser("hook")
    hook.add_argument("provider", choices=["codex", "claude"])
    hook.add_argument("--rewake", action="store_true")
    hook.set_defaults(handler_key=("internal-hook", None))

    return parser


def _add_login_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    parser = subparsers.add_parser(
        "login",
        help="authenticate an existing human owner",
        description="Authenticate an existing human owner who creates and owns local agent identities.",
    )
    parser.add_argument("identifier", help="owner email or username")
    parser.add_argument(
        "--password-stdin",
        action="store_true",
        help="read the owner password from stdin",
    )
    parser.add_argument("--base-url", help="Mycel backend URL")
    parser.set_defaults(handler_key=("login", None))


def _add_logout_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    parser = subparsers.add_parser("logout", help="clear the active human owner login")
    parser.add_argument(
        "--all-local",
        action="store_true",
        help="clear all locally cached owner logins",
    )
    parser.set_defaults(handler_key=("logout", None))


def _add_contact_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    contact = subparsers.add_parser(
        "contact",
        help="manage user-level relationship requests",
        description="Manage user-level relationship requests.",
    )
    contact_sub = contact.add_subparsers(dest="relationship_command", required=True)
    contact_sub.add_parser("list", help="list visible relationships").set_defaults(
        handler_key=("relationships", "list")
    )
    request = contact_sub.add_parser("request", help="request a relationship")
    request.add_argument("target_user_id")
    request.add_argument("--message")
    request.set_defaults(handler_key=("relationships", "request"))
    for action in ("approve", "reject"):
        action_parser = contact_sub.add_parser(action, help=f"{action} a relationship")
        action_parser.add_argument("relationship_id")
        action_parser.set_defaults(handler_key=("relationships", action))


def _add_agent_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    agent = subparsers.add_parser(
        "agent",
        help="inspect and manage external agent identities",
        description="Inspect and manage external agent identities.",
    )
    agent_sub = agent.add_subparsers(dest="agent_command", required=True)
    agent_sub.add_parser("show", help="show the current agent identity").set_defaults(
        handler_key=("agent", "show")
    )
    external = agent_sub.add_parser(
        "external",
        help="manage external agent identities",
        description="Manage external agent identities for local code agents.",
    )
    external_sub = external.add_subparsers(dest="external_command", required=True)
    create = external_sub.add_parser(
        "create",
        help="create an external agent identity",
        description=(
            "Create an external agent identity owned by the current human owner.\n"
            "Run `cel login <email-or-username>` first."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    create.add_argument("local_id")
    create.add_argument("--name", required=True)
    create.add_argument("--provider", choices=["codex", "claude"], required=True)
    create.set_defaults(handler_key=("agent-external", "create"))
    external_sub.add_parser("list", help="list local agent identities").set_defaults(
        handler_key=("agent-external", "list")
    )
    remove = external_sub.add_parser("remove", help="remove a local agent identity")
    remove.add_argument("local_id")
    remove.set_defaults(handler_key=("agent-external", "remove"))
    unbind = external_sub.add_parser(
        "unbind", help="remove an identity binding from a local folder"
    )
    unbind.add_argument("local_id")
    unbind.add_argument("--path", help="folder to unbind; defaults to current folder")
    unbind.set_defaults(handler_key=("agent-external", "unbind"))
    external_sub.add_parser(
        "cleanup", help="remove stale local state for missing identities"
    ).set_defaults(handler_key=("agent-external", "cleanup"))


def _add_provider_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
    name: str,
    help_text: str,
) -> None:
    options = [
        "  --identity <local-id>    choose a local agent identity for this launch",
        "  --mycel-status          inspect identity, hook, and provider state",
    ]
    parser = subparsers.add_parser(
        name,
        help=help_text,
        description=help_text,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Mycel options:\n" + "\n".join(options) + "\n\n"
            f"Native {name.title()} arguments must follow `--` when they look like "
            f"Mycel wrapper options. Example: `cel {name} --identity agent-a -- "
            f"exec hello`."
        ),
    )
    parser.add_argument("provider_args", nargs=argparse.REMAINDER)
    parser.set_defaults(handler_key=(name, None))


def _add_send_message_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    parser = subparsers.add_parser(
        "send-message",
        help="send a direct or chat-scoped message",
        description=(
            "Send a durable Mycel message. Targets are explicit: "
            ":<chat_id>, @<user_id>, or :<chat_id>@<user_id>."
        ),
    )
    parser.add_argument(
        "target",
        help=":<chat_id>, @<user_id>, or :<chat_id>@<user_id>",
    )
    parser.add_argument("content")
    parser.add_argument("--reply-to")
    parser.add_argument(
        "--mention",
        action="append",
        dest="mentions",
        default=[],
        help="user id to mention; repeat to mention multiple users",
    )
    parser.set_defaults(handler_key=("send-message", None))


def _add_read_message_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    parser = subparsers.add_parser(
        "read-message",
        help="read messages from a chat or direct user target",
        description=(
            "Read durable Mycel messages. Targets are explicit: :<chat_id> or "
            "@<user_id>. By default this consumes unread messages; --last peeks "
            "without advancing the read cursor."
        ),
    )
    parser.add_argument("target", help=":<chat_id> or @<user_id>")
    parser.add_argument(
        "--last",
        type=int,
        help="peek at the last N messages without advancing the read cursor",
    )
    parser.add_argument("--before", help="message id cursor for older messages")
    parser.set_defaults(handler_key=("read-message", None))


def _add_self_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    subparsers.add_parser(
        "self",
        help="inspect and manage the local Mycel daemon and inbox",
        description="Inspect and manage the local Mycel daemon and inbox.",
    )


def _add_group_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    subparsers.add_parser(
        "group",
        help="manage cel group orchestration",
        description="Manage cel group orchestration.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Local service commands:\n"
            "  cel self start\n"
            "  cel self status\n"
            "  cel self stop\n\n"
            "Resource commands are scoped by group id:\n"
            "  cel group <id> task ...\n"
            "  cel group <id> supervisor ...\n"
            "  cel group <id> worker ...\n"
            "  cel group <id> reviewer ..."
        ),
    )


def _client_from_openapi_root(
    *,
    package_root: str,
    base_url: str,
    auth_token: str | None,
) -> Any:
    return Client.from_openapi_client_root(
        package_root,
        base_url=base_url,
        auth_token=auth_token,
    )


def _client_from_config(
    *,
    auth_token: str | None,
    base_url: str,
) -> Client:
    return Client(
        auth_token=auth_token,
        base_url=base_url,
    )


def _openapi_client_root() -> str | None:
    import os

    root = os.getenv("MYCEL_OPENAPI_CLIENT_ROOT")
    if root is None:
        return None
    root = root.strip()
    return root or None


def _command_needs_client(key: tuple[str, str | None]) -> bool:
    return key not in {
        ("logout", None),
        ("codex", None),
        ("claude", None),
        ("internal-hook", None),
        ("agent-external", "list"),
        ("agent-external", "remove"),
        ("agent-external", "unbind"),
        ("agent-external", "cleanup"),
    }


def _config_for_command(
    key: tuple[str, str | None], args: argparse.Namespace
) -> CliConfig:
    if key == ("login", None):
        base_url = args.base_url or effective_base_url()["base_url"]
        return CliConfig(base_url=base_url, auth_token=None)
    if key == ("agent-external", "create"):
        return load_owner_config()
    return load_cli_config(cwd=Path.cwd())


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = build_parser()
    if argv and argv[0] == "internal":
        args = build_internal_parser().parse_args(argv[1:])
        args.command = "internal"
        return args
    if argv and argv[0] in {"codex", "claude"}:
        if len(argv) > 1 and argv[1] in {"--help", "-h"}:
            return parser.parse_args(argv[:2])
        args = parser.parse_args([argv[0]])
        args.provider_args = argv[1:]
        return args
    return parser.parse_args(argv)


def run_cli(
    argv: Sequence[str],
    *,
    client: Any | None = None,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    in_stream = stdin or sys.stdin
    out = stdout or sys.stdout
    err = stderr or sys.stderr

    try:
        normalized_argv = list(argv)
        if not normalized_argv:
            parser = build_parser()
            parser.print_help(file=out)
            out.write(
                "\nStart here:\n"
                "  cel login <email-or-username>\n"
                '  cel agent external create codex-a --name "Codex A" --provider codex\n'
                '  cel send-message :<chat-id> "hello"\n'
                "  cel read-message :<chat-id>\n"
                "  cel codex\n"
            )
            return 0
        if _uses_typer_app(normalized_argv):
            return _run_typer_app(normalized_argv, stdout=out, stderr=err)
        args = _parse_args(normalized_argv)
        key = command_key(args)
        needs_client = _command_needs_client(key)
        cfg = (
            _config_for_command(key, args)
            if needs_client
            else CliConfig(base_url=DEFAULT_BASE_URL, auth_token=None)
        )
        resolved_client = client
        if resolved_client is None and needs_client:
            openapi_client_root = _openapi_client_root()
            if openapi_client_root is not None:
                resolved_client = _client_from_openapi_root(
                    package_root=openapi_client_root,
                    base_url=cfg.base_url,
                    auth_token=cfg.auth_token,
                )
            else:
                resolved_client = _client_from_config(
                    auth_token=cfg.auth_token,
                    base_url=cfg.base_url,
                )
        if resolved_client is None:
            resolved_client = object()

        payload = handle_command(
            args=args,
            client=resolved_client,
            config=cfg,
            stdin=in_stream,
            stdout=out,
        )
    except ApiError as exc:
        err.write(f"error: {exc}\n")
        return 1
    except RuntimeError as exc:
        err.write(f"error: {exc}\n")
        return 1
    except SystemExit as exc:
        return int(exc.code or 0)

    if isinstance(payload, RawOutput):
        out.write(payload.text)
        return payload.return_code
    elif isinstance(payload, ProcessRequest):
        surface_ref = surfaces.register_from_env(payload.env)
        try:
            return subprocess.run(
                payload.command, env=payload.env, check=False
            ).returncode
        finally:
            if surface_ref is not None:
                surfaces.unregister_from_env(payload.env)
    else:
        out.write(json.dumps(payload, ensure_ascii=False))
        out.write("\n")
    return 0


def _uses_typer_app(argv: list[str]) -> bool:
    if not argv:
        return False
    first = argv[0]
    if first.startswith("-"):
        return False
    if first == "group":
        return True
    if first == "self":
        return True
    if first in ROOT_COMMANDS:
        return False
    return _is_group_shortcut_invocation(argv)


def _is_group_shortcut_invocation(argv: list[str]) -> bool:
    if len(argv) > 1 and argv[1] not in GROUP_SHORTCUT_SUBJECTS:
        return False
    from mycel_cli.group._state.groups import list_groups

    return argv[0] in list_groups()


def _run_typer_app(
    argv: list[str],
    *,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    import click

    from mycel_cli.group.cli import app

    args = argv if argv and argv[0] in {"group", "self"} else ["group", *argv]
    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            result = app(args=args, prog_name="cel", standalone_mode=False)
    except click.ClickException as exc:
        with contextlib.redirect_stderr(stderr):
            exc.show()
        return int(exc.exit_code)
    except click.exceptions.Exit as exc:
        return int(exc.exit_code or 0)
    except SystemExit as exc:
        return int(exc.code or 0)
    return int(result or 0)
