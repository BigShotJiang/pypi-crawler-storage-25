from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.format import Format
from ..properties.content import Content


import logging

_LOGGER = logging.getLogger(__name__)

# 说话
class Say(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:say:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Say"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "说话"


    # 执行 Action 调用
    async def invoke(self, format: Optional[int], content: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if format is None:
            raise ValueError("参数format不能为空")
        arguments[Format.IID] = ArgumentOperation(piid = Format.IID, value = format)

        if content is None:
            raise ValueError("参数content不能为空")
        arguments[Content.IID] = ArgumentOperation(piid = Content.IID, value = content)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
