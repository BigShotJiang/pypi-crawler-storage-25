from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.did import Did

from ..properties.did import Did

import logging

_LOGGER = logging.getLogger(__name__)

# 批量添加设备
class AddDevices(ActionController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:action:add-devices:00000d4a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "add-devices"
        self.description["zh-CN"] = "批量添加设备"

    # Action 出参
    class Result:
        # 设备did列表
        dids: list[str]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _3: Optional[ArgumentOperation] = result[Did.IID]
            if _3 is not None:
                self.dids = [str(item) for item in _3.values]
            else:
                _LOGGER.error("result error, not found: %s.IID}", Did)

            return

    # 执行 Action 调用
    async def invoke(self, dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if dids is None or len(dids) == 0:
            raise ValueError("参数dids不能为空")
        arguments[Did.IID] = ArgumentOperation(piid = Did.IID, values = dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return AddDevices.Result(out)
