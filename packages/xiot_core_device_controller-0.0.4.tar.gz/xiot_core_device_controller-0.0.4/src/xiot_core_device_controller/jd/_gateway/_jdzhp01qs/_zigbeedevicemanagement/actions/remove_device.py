from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.did import Did


import logging

_LOGGER = logging.getLogger(__name__)

# 删除设备
class RemoveDevice(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:remove-device:00000d4c:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "remove-device"
        self.description["zh-CN"] = "删除设备"


    # 执行 Action 调用
    async def invoke(self, did: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if did is None:
            raise ValueError("参数did不能为空")
        arguments[Did.IID] = ArgumentOperation(piid = Did.IID, value = did)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
