from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.rule_id import RuleId


import logging

_LOGGER = logging.getLogger(__name__)

# 执行场景
class TriggerRule(ActionController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:action:trigger-rule:00000d53:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "trigger-rule"
        self.description["zh-CN"] = "执行场景"


    # 执行 Action 调用
    async def invoke(self, rule_id: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if rule_id is None:
            raise ValueError("参数rule_id不能为空")
        arguments[RuleId.IID] = ArgumentOperation(piid = RuleId.IID, value = rule_id)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
