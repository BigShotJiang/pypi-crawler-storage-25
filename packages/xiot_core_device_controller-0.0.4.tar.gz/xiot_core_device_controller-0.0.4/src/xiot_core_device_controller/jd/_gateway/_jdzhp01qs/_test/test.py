from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.test1 import Test1
from .actions.test2 import Test2
from .actions.test3 import Test3
from .actions.test4 import Test4
from .actions.test5 import Test5


from .properties.red import Red
from .properties.green import Green
from .properties.blue import Blue
from .properties.color4 import Color4
from .properties.brightness import Brightness
from .properties.hue import Hue
from .properties.saturation import Saturation
from .properties.color_temperature import ColorTemperature
from .properties.color9 import Color9
from .properties.settings import Settings

# 测试服务
class Test(ServiceController):
    IID: int = 999
    TYPE: str = "urn:jd-spec:service:test:000000d1:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "TEST Service"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "测试服务"

        self.properties[Red.IID] = Red()
        self.properties[Green.IID] = Green()
        self.properties[Blue.IID] = Blue()
        self.properties[Color4.IID] = Color4()
        self.properties[Brightness.IID] = Brightness()
        self.properties[Hue.IID] = Hue()
        self.properties[Saturation.IID] = Saturation()
        self.properties[ColorTemperature.IID] = ColorTemperature()
        self.properties[Color9.IID] = Color9()
        self.properties[Settings.IID] = Settings()

        self.actions[Test1.IID] = Test1()
        self.actions[Test2.IID] = Test2()
        self.actions[Test3.IID] = Test3()
        self.actions[Test4.IID] = Test4()
        self.actions[Test5.IID] = Test5()


    # 红色
    def red_(self) -> Red:
        return self.properties[Red.IID] # type: ignore[no-any-return]

    # 绿色
    def green_(self) -> Green:
        return self.properties[Green.IID] # type: ignore[no-any-return]

    # 蓝色
    def blue_(self) -> Blue:
        return self.properties[Blue.IID] # type: ignore[no-any-return]

    # 颜色
    def color4_(self) -> Color4:
        return self.properties[Color4.IID] # type: ignore[no-any-return]

    # 亮度
    def brightness_(self) -> Brightness:
        return self.properties[Brightness.IID] # type: ignore[no-any-return]

    # 色度
    def hue_(self) -> Hue:
        return self.properties[Hue.IID] # type: ignore[no-any-return]

    # 饱和度
    def saturation_(self) -> Saturation:
        return self.properties[Saturation.IID] # type: ignore[no-any-return]

    # 色温
    def color_temperature_(self) -> ColorTemperature:
        return self.properties[ColorTemperature.IID] # type: ignore[no-any-return]

    # 颜色
    def color9_(self) -> Color9:
        return self.properties[Color9.IID] # type: ignore[no-any-return]

    # 设置
    def settings_(self) -> Settings:
        return self.properties[Settings.IID] # type: ignore[no-any-return]


    # 测试方法1（只有参数）
    def test1_(self) -> Test1:
        return self.actions[Test1.IID] # type: ignore[no-any-return]

    # 测试方法2（有参数、有结果）
    def test2_(self) -> Test2:
        return self.actions[Test2.IID] # type: ignore[no-any-return]

    # 测试方法3（组合属性）
    def test3_(self) -> Test3:
        return self.actions[Test3.IID] # type: ignore[no-any-return]

    # 测试方法4（组合属性）
    def test4_(self) -> Test4:
        return self.actions[Test4.IID] # type: ignore[no-any-return]

    # 测试方法5（嵌套组合属性）
    def test5_(self) -> Test5:
        return self.actions[Test5.IID] # type: ignore[no-any-return]


