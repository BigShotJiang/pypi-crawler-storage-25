from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.create_groups import CreateGroups
from .actions.delete_groups import DeleteGroups
from .actions.get_group_info import GetGroupInfo
from .actions.add_devices_to_group import AddDevicesToGroup
from .actions.remove_devices_from_group import RemoveDevicesFromGroup
from .actions.get_groups_list import GetGroupsList
from .actions.update_group import UpdateGroup

from .events.device_joined_group import DeviceJoinedGroup

from .properties.group_did import GroupDid
from .properties.did import Did

# 组管理
class GroupManagement(ServiceController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:service:group-management:00000ce5:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Group Mangement"
        self.description["zh-CN"] = "组管理"

        self.properties[GroupDid.IID] = GroupDid()
        self.properties[Did.IID] = Did()

        self.actions[CreateGroups.IID] = CreateGroups()
        self.actions[DeleteGroups.IID] = DeleteGroups()
        self.actions[GetGroupInfo.IID] = GetGroupInfo()
        self.actions[AddDevicesToGroup.IID] = AddDevicesToGroup()
        self.actions[RemoveDevicesFromGroup.IID] = RemoveDevicesFromGroup()
        self.actions[GetGroupsList.IID] = GetGroupsList()
        self.actions[UpdateGroup.IID] = UpdateGroup()

        self.events[DeviceJoinedGroup.IID] = DeviceJoinedGroup()

    # 组did
    def group_did_(self) -> GroupDid:
        return self.properties[GroupDid.IID] # type: ignore[no-any-return]

    # 设备did
    def did_(self) -> Did:
        return self.properties[Did.IID] # type: ignore[no-any-return]


    # 创建组
    def create_groups_(self) -> CreateGroups:
        return self.actions[CreateGroups.IID] # type: ignore[no-any-return]

    # 删除组
    def delete_groups_(self) -> DeleteGroups:
        return self.actions[DeleteGroups.IID] # type: ignore[no-any-return]

    # 获取组信息
    def get_group_info_(self) -> GetGroupInfo:
        return self.actions[GetGroupInfo.IID] # type: ignore[no-any-return]

    # 将设备添加到群组
    def add_devices_to_group_(self) -> AddDevicesToGroup:
        return self.actions[AddDevicesToGroup.IID] # type: ignore[no-any-return]

    # 从组中移除设备
    def remove_devices_from_group_(self) -> RemoveDevicesFromGroup:
        return self.actions[RemoveDevicesFromGroup.IID] # type: ignore[no-any-return]

    # 获取组列表
    def get_groups_list_(self) -> GetGroupsList:
        return self.actions[GetGroupsList.IID] # type: ignore[no-any-return]

    # 更新组内设备
    def update_group_(self) -> UpdateGroup:
        return self.actions[UpdateGroup.IID] # type: ignore[no-any-return]


    # 设备加入了组
    def device_joined_group_(self) -> DeviceJoinedGroup:
        return self.events[DeviceJoinedGroup.IID] # type: ignore[no-any-return]

