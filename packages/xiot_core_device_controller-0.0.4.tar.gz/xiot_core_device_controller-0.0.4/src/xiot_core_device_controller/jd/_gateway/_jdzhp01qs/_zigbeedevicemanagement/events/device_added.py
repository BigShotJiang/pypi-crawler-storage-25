from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.device_info_c import DeviceInfoC
from ..properties.device_info_c import DeviceInfoCValue

# 设备添加
class DeviceAdded(EventController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:event:device-added:00000a2d:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(self.TYPE))

        self.description["en-US"] = "device-added"
        self.description["zh-CN"] = "设备添加"

        self._observer: Callable[[list[DeviceInfoCValue]], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            device_info_cs: list[DeviceInfoCValue]  = self.__device_info_cs(o)
            self._observer(device_info_cs)

    def observer(self, observer: Callable[[list[DeviceInfoCValue]], None]) -> None:
        self._observer = observer

    @staticmethod
    def __device_info_cs(o: EventOperation) -> list[DeviceInfoCValue]:
        argument: ArgumentOperation = o.arguments[DeviceInfoC.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(DeviceInfoC.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(DeviceInfoC.IID))

        values: list[DeviceInfoCValue] = []
        for item in objects:
            if isinstance(item, dict):
                values.append(DeviceInfoCValue(item))
            else:
                _LOGGER.error("argument value invalid: %s", type(item).__name__)

        return values

