from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.iconid import Iconid
from ..properties.rule_name import RuleName
from ..properties.delete_after_execution import DeleteAfterExecution
from ..properties.rule_id import RuleId
from ..properties.rule_enable import RuleEnable
from ..properties.rule_content import RuleContent
from ..properties.content_formatter import ContentFormatter
from ..properties.roomid import Roomid
from ..properties.r_description import RDescription


import logging

_LOGGER = logging.getLogger(__name__)

# 修改场景
class EditRule(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:edit-rule:00000d51:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "edit-rule"
        self.description["zh-CN"] = "修改场景"


    # 执行 Action 调用
    async def invoke(self, iconid: Optional[str], rule_name: Optional[str], delete_after_execution: Optional[bool], rule_id: Optional[str], rule_enable: Optional[bool], rule_content: Optional[str], content_formatter: Optional[int], roomid: Optional[int], r_description: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if iconid is None:
            arguments[Iconid.IID] = ArgumentOperation(Iconid.IID, value = iconid)

        if rule_name is None:
            raise ValueError("参数rule_name不能为空")
        arguments[RuleName.IID] = ArgumentOperation(piid = RuleName.IID, value = rule_name)

        if delete_after_execution is None:
            arguments[DeleteAfterExecution.IID] = ArgumentOperation(DeleteAfterExecution.IID, value = delete_after_execution)

        if rule_id is None:
            raise ValueError("参数rule_id不能为空")
        arguments[RuleId.IID] = ArgumentOperation(piid = RuleId.IID, value = rule_id)

        if rule_enable is None:
            raise ValueError("参数rule_enable不能为空")
        arguments[RuleEnable.IID] = ArgumentOperation(piid = RuleEnable.IID, value = rule_enable)

        if rule_content is None:
            raise ValueError("参数rule_content不能为空")
        arguments[RuleContent.IID] = ArgumentOperation(piid = RuleContent.IID, value = rule_content)

        if content_formatter is None:
            raise ValueError("参数content_formatter不能为空")
        arguments[ContentFormatter.IID] = ArgumentOperation(piid = ContentFormatter.IID, value = content_formatter)

        if roomid is None:
            arguments[Roomid.IID] = ArgumentOperation(Roomid.IID, value = roomid)

        if r_description is None:
            arguments[RDescription.IID] = ArgumentOperation(RDescription.IID, value = r_description)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
