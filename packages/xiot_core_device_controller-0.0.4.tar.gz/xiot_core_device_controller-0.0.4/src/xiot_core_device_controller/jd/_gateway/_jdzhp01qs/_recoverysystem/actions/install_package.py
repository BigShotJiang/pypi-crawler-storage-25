from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.path import Path


import logging

_LOGGER = logging.getLogger(__name__)

# 升级固件包
class InstallPackage(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:install-package:00000002:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Install Package"
        self.description["zh-CN"] = "升级固件包"


    # 执行 Action 调用
    async def invoke(self, path: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if path is None:
            raise ValueError("参数path不能为空")
        arguments[Path.IID] = ArgumentOperation(piid = Path.IID, value = path)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
