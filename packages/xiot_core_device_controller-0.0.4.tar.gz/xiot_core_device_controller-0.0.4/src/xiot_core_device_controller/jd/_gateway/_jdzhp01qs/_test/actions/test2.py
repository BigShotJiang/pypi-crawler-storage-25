from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.red import Red
from ..properties.green import Green
from ..properties.blue import Blue

from ..properties.brightness import Brightness
from ..properties.hue import Hue
from ..properties.saturation import Saturation
from ..properties.color_temperature import ColorTemperature

import logging

_LOGGER = logging.getLogger(__name__)

# 测试方法2（有参数、有结果）
class Test2(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:test:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Test 2"
        self.description["zh-CN"] = "测试方法2（有参数、有结果）"

    # Action 出参
    class Result:
        # 亮度
        brightness: int
        # 色度
        hue: int
        # 饱和度
        saturation: int
        # 色温
        color_temperature: int

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _5: Optional[ArgumentOperation] = result[Brightness.IID]
            if _5 is not None:
                v = _5.values[0]
                if isinstance(v, int):
                    self.brightness = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", Brightness)

            _6: Optional[ArgumentOperation] = result[Hue.IID]
            if _6 is not None:
                v = _6.values[0]
                if isinstance(v, int):
                    self.hue = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", Hue)

            _7: Optional[ArgumentOperation] = result[Saturation.IID]
            if _7 is not None:
                v = _7.values[0]
                if isinstance(v, int):
                    self.saturation = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", Saturation)

            _8: Optional[ArgumentOperation] = result[ColorTemperature.IID]
            if _8 is not None:
                v = _8.values[0]
                if isinstance(v, int):
                    self.color_temperature = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", ColorTemperature)

            return

    # 执行 Action 调用
    async def invoke(self, red: Optional[int], green: Optional[int], blue: Optional[int]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if red is None:
            raise ValueError("参数red不能为空")
        arguments[Red.IID] = ArgumentOperation(piid = Red.IID, value = red)

        if green is None:
            raise ValueError("参数green不能为空")
        arguments[Green.IID] = ArgumentOperation(piid = Green.IID, value = green)

        if blue is None:
            raise ValueError("参数blue不能为空")
        arguments[Blue.IID] = ArgumentOperation(piid = Blue.IID, value = blue)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return Test2.Result(out)
