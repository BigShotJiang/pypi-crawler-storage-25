from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.start_easylink import StartEasylink
from .actions.delete_easylink import DeleteEasylink


from .properties.on import On
from .properties.name import Name
from .properties.enable import Enable
from .properties.power_on_state import PowerOnState

# 开关 3
class Switch20(ServiceController):
    IID: int = 20
    TYPE: str = "urn:jd-spec:service:switch:00000002:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Switch 3"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "开关 3"

        self.properties[On.IID] = On()
        self.properties[Name.IID] = Name()
        self.properties[Enable.IID] = Enable()
        self.properties[PowerOnState.IID] = PowerOnState()

        self.actions[StartEasylink.IID] = StartEasylink()
        self.actions[DeleteEasylink.IID] = DeleteEasylink()


    # 开关
    def on_(self) -> On:
        return self.properties[On.IID] # type: ignore[no-any-return]

    # 名称
    def name_(self) -> Name:
        return self.properties[Name.IID] # type: ignore[no-any-return]

    # 启用
    def enable_(self) -> Enable:
        return self.properties[Enable.IID] # type: ignore[no-any-return]

    # 上电开启
    def power_on_state_(self) -> PowerOnState:
        return self.properties[PowerOnState.IID] # type: ignore[no-any-return]


    # 打开爽连
    def start_easylink_(self) -> StartEasylink:
        return self.actions[StartEasylink.IID] # type: ignore[no-any-return]

    # 删除爽连
    def delete_easylink_(self) -> DeleteEasylink:
        return self.actions[DeleteEasylink.IID] # type: ignore[no-any-return]


