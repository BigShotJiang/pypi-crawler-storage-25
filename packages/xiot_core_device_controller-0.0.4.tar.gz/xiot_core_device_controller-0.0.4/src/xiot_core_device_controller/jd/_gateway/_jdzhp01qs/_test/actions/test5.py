from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.settings import Settings
from ..properties.settings import SettingsValue

from ..properties.settings import Settings
from ..properties.settings import SettingsValue

import logging

_LOGGER = logging.getLogger(__name__)

# 测试方法5（嵌套组合属性）
class Test5(ActionController):
    IID: int = 5
    TYPE: str = "urn:jd-spec:action:test:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Test 5"
        self.description["zh-CN"] = "测试方法5（嵌套组合属性）"

    # Action 出参
    class Result:
        # 设置
        settings: SettingsValue

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _10: Optional[ArgumentOperation] = result[Settings.IID]
            if _10 is not None:
                v = _10.values[0]
                if isinstance(v, dict):
                    self.settings = SettingsValue(v)
            else:
                _LOGGER.error("result error, not found: %s.IID}", Settings)

            return

    # 执行 Action 调用
    async def invoke(self, settings: Optional[SettingsValue]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if settings is None:
            raise ValueError("参数settings不能为空")
        arguments[Settings.IID] = ArgumentOperation(piid = Settings.IID, value = settings.to_map())

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return Test5.Result(out)
