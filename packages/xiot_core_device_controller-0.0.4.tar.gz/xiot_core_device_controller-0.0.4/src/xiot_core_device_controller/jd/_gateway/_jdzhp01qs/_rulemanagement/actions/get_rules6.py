from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.rule_id import RuleId

from ..properties.rule_info_c import RuleInfoC
from ..properties.rule_info_c import RuleInfoCValue

import logging

_LOGGER = logging.getLogger(__name__)

# 查询场景
class GetRules6(ActionController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:action:get-rules:00000d55:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "get-rule"
        self.description["zh-CN"] = "查询场景"

    # Action 出参
    class Result:
        # 规则信息
        rule_info_c: RuleInfoCValue

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _6: Optional[ArgumentOperation] = result[RuleInfoC.IID]
            if _6 is not None:
                v = _6.values[0]
                if isinstance(v, dict):
                    self.rule_info_c = RuleInfoCValue(v)
            else:
                _LOGGER.error("result error, not found: %s.IID}", RuleInfoC)

            return

    # 执行 Action 调用
    async def invoke(self, rule_id: Optional[str]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if rule_id is None:
            raise ValueError("参数rule_id不能为空")
        arguments[RuleId.IID] = ArgumentOperation(piid = RuleId.IID, value = rule_id)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return GetRules6.Result(out)
