from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController



import logging

_LOGGER = logging.getLogger(__name__)

# 登出
class Logout(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:logout:0000ec12:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Log Out"
        self.description["zh-CN"] = "登出"


    # 执行 Action 调用
    async def invoke(self, ):
        arguments: Dict[int, ArgumentOperation] = {}

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
