from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.group_did import GroupDid

from ..properties.group_did import GroupDid

import logging

_LOGGER = logging.getLogger(__name__)

# 删除组
class DeleteGroups(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:delete-groups:00000b59:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Delete Groups"
        self.description["zh-CN"] = "删除组"

    # Action 出参
    class Result:
        # 组did列表
        group_dids: list[str]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _1: Optional[ArgumentOperation] = result[GroupDid.IID]
            if _1 is not None:
                self.group_dids = [str(item) for item in _1.values]
            else:
                _LOGGER.error("result error, not found: %s.IID}", GroupDid)

            return

    # 执行 Action 调用
    async def invoke(self, group_dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if group_dids is None or len(group_dids) == 0:
            raise ValueError("参数group_dids不能为空")
        arguments[GroupDid.IID] = ArgumentOperation(piid = GroupDid.IID, values = group_dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return DeleteGroups.Result(out)
