from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.rule_id import RuleId
from ..properties.progress import Progress

# 场景执行中
class RuleRunning(EventController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:event:rule-running:00000a39:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(self.TYPE))

        self.description["en-US"] = "rule-running"
        self.description["zh-CN"] = "场景执行中"

        self._observer: Callable[[str, int], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            rule_id = self.__rule_id(o)
            progress = self.__progress(o)
            self._observer(rule_id, progress)

    def observer(self, observer: Callable[[str, int], None]) -> None:
        self._observer = observer

    @staticmethod
    def __rule_id(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[RuleId.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(RuleId.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(RuleId.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(RuleId.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __progress(o: EventOperation) -> int :
        argument: ArgumentOperation = o.arguments[Progress.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(Progress.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(Progress.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(Progress.IID))

        value: object = objects[0]
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

