from ....device_mapping import register_device

from xiot_core.spec.typedef.definition.urn.device_type import DeviceType
from xiot_core.support.typedef.controller.device_controller import DeviceController

from ._button128.button128 import Button128
from ._deviceinformation.device_information import DeviceInformation
from ._button129.button129 import Button129
from ._button130.button130 import Button130
from ._debug.debug import Debug
from ._button131.button131 import Button131
from ._groupmanagement.group_management import GroupManagement
from ._button132.button132 import Button132
from ._otamanagement.ota_management import OtaManagement
from ._button133.button133 import Button133
from ._bledevicemanagement.ble_device_management import BleDeviceManagement
from ._button134.button134 import Button134
from ._zigbeedevicemanagement.zigbee_device_management import ZigbeeDeviceManagement
from ._button135.button135 import Button135
from ._rulemanagement.rule_management import RuleManagement
from ._button136.button136 import Button136
from ._button137.button137 import Button137
from ._button138.button138 import Button138
from ._button139.button139 import Button139
from ._lightpanel140.light_panel140 import LightPanel140
from ._lightpanel141.light_panel141 import LightPanel141
from ._curtainpanel142.curtain_panel142 import CurtainPanel142
from ._curtainpanel143.curtain_panel143 import CurtainPanel143
from ._voice.voice import Voice
from ._systemsetup.system_setup import SystemSetup
from ._repeater.repeater import Repeater
from ._switch18.switch18 import Switch18
from ._multiswitchcontrol.multi_switch_control import MultiSwitchControl
from ._switch19.switch19 import Switch19
from ._switch20.switch20 import Switch20
from ._desktopmanagement.desktop_management import DesktopManagement
from ._recoverysystem.recovery_system import RecoverySystem
from ._test.test import Test

# 智慧屏4英寸
@register_device
class Jdzhp01qs(DeviceController):
    TYPE: str = "urn:jd-spec:device:gateway:0000012d:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(DeviceType(self.TYPE))

        self.description["en-US"] = "Smart Screen 4 inch"
        self.description["zh-CN"] = "智慧屏4英寸"

        self.services[Button128.IID] = Button128()
        self.services[DeviceInformation.IID] = DeviceInformation()
        self.services[Button129.IID] = Button129()
        self.services[Button130.IID] = Button130()
        self.services[Debug.IID] = Debug()
        self.services[Button131.IID] = Button131()
        self.services[GroupManagement.IID] = GroupManagement()
        self.services[Button132.IID] = Button132()
        self.services[OtaManagement.IID] = OtaManagement()
        self.services[Button133.IID] = Button133()
        self.services[BleDeviceManagement.IID] = BleDeviceManagement()
        self.services[Button134.IID] = Button134()
        self.services[ZigbeeDeviceManagement.IID] = ZigbeeDeviceManagement()
        self.services[Button135.IID] = Button135()
        self.services[RuleManagement.IID] = RuleManagement()
        self.services[Button136.IID] = Button136()
        self.services[Button137.IID] = Button137()
        self.services[Button138.IID] = Button138()
        self.services[Button139.IID] = Button139()
        self.services[LightPanel140.IID] = LightPanel140()
        self.services[LightPanel141.IID] = LightPanel141()
        self.services[CurtainPanel142.IID] = CurtainPanel142()
        self.services[CurtainPanel143.IID] = CurtainPanel143()
        self.services[Voice.IID] = Voice()
        self.services[SystemSetup.IID] = SystemSetup()
        self.services[Repeater.IID] = Repeater()
        self.services[Switch18.IID] = Switch18()
        self.services[MultiSwitchControl.IID] = MultiSwitchControl()
        self.services[Switch19.IID] = Switch19()
        self.services[Switch20.IID] = Switch20()
        self.services[DesktopManagement.IID] = DesktopManagement()
        self.services[RecoverySystem.IID] = RecoverySystem()
        self.services[Test.IID] = Test()

    # 按键 1
    def button128_(self) -> Button128:
        return self.services[Button128.IID] # type: ignore[no-any-return]

    # 设备信息
    def device_information_(self) -> DeviceInformation:
        return self.services[DeviceInformation.IID] # type: ignore[no-any-return]

    # 按键 2
    def button129_(self) -> Button129:
        return self.services[Button129.IID] # type: ignore[no-any-return]

    # 按键 3
    def button130_(self) -> Button130:
        return self.services[Button130.IID] # type: ignore[no-any-return]

    # 调试
    def debug_(self) -> Debug:
        return self.services[Debug.IID] # type: ignore[no-any-return]

    # 按键 4
    def button131_(self) -> Button131:
        return self.services[Button131.IID] # type: ignore[no-any-return]

    # 组管理
    def group_management_(self) -> GroupManagement:
        return self.services[GroupManagement.IID] # type: ignore[no-any-return]

    # 按键 5
    def button132_(self) -> Button132:
        return self.services[Button132.IID] # type: ignore[no-any-return]

    # ota管理服务
    def ota_management_(self) -> OtaManagement:
        return self.services[OtaManagement.IID] # type: ignore[no-any-return]

    # 按键 6
    def button133_(self) -> Button133:
        return self.services[Button133.IID] # type: ignore[no-any-return]

    # 蓝牙设备管理服务
    def ble_device_management_(self) -> BleDeviceManagement:
        return self.services[BleDeviceManagement.IID] # type: ignore[no-any-return]

    # 按键 7
    def button134_(self) -> Button134:
        return self.services[Button134.IID] # type: ignore[no-any-return]

    # zigbee设备管理服务
    def zigbee_device_management_(self) -> ZigbeeDeviceManagement:
        return self.services[ZigbeeDeviceManagement.IID] # type: ignore[no-any-return]

    # 按键 8
    def button135_(self) -> Button135:
        return self.services[Button135.IID] # type: ignore[no-any-return]

    # 场景管理服务
    def rule_management_(self) -> RuleManagement:
        return self.services[RuleManagement.IID] # type: ignore[no-any-return]

    # 按键 9
    def button136_(self) -> Button136:
        return self.services[Button136.IID] # type: ignore[no-any-return]

    # 按键 10
    def button137_(self) -> Button137:
        return self.services[Button137.IID] # type: ignore[no-any-return]

    # 按键 11
    def button138_(self) -> Button138:
        return self.services[Button138.IID] # type: ignore[no-any-return]

    # 按键 12
    def button139_(self) -> Button139:
        return self.services[Button139.IID] # type: ignore[no-any-return]

    # 灯控面板
    def light_panel140_(self) -> LightPanel140:
        return self.services[LightPanel140.IID] # type: ignore[no-any-return]

    # 灯控面板
    def light_panel141_(self) -> LightPanel141:
        return self.services[LightPanel141.IID] # type: ignore[no-any-return]

    # 窗帘面板
    def curtain_panel142_(self) -> CurtainPanel142:
        return self.services[CurtainPanel142.IID] # type: ignore[no-any-return]

    # 窗帘面板
    def curtain_panel143_(self) -> CurtainPanel143:
        return self.services[CurtainPanel143.IID] # type: ignore[no-any-return]

    # 语音服务
    def voice_(self) -> Voice:
        return self.services[Voice.IID] # type: ignore[no-any-return]

    # 系统设置
    def system_setup_(self) -> SystemSetup:
        return self.services[SystemSetup.IID] # type: ignore[no-any-return]

    # 中继
    def repeater_(self) -> Repeater:
        return self.services[Repeater.IID] # type: ignore[no-any-return]

    # 开关 1
    def switch18_(self) -> Switch18:
        return self.services[Switch18.IID] # type: ignore[no-any-return]

    # 多路开关控制
    def multi_switch_control_(self) -> MultiSwitchControl:
        return self.services[MultiSwitchControl.IID] # type: ignore[no-any-return]

    # 开关 2
    def switch19_(self) -> Switch19:
        return self.services[Switch19.IID] # type: ignore[no-any-return]

    # 开关 3
    def switch20_(self) -> Switch20:
        return self.services[Switch20.IID] # type: ignore[no-any-return]

    # 桌面管理
    def desktop_management_(self) -> DesktopManagement:
        return self.services[DesktopManagement.IID] # type: ignore[no-any-return]

    # Recovery系统
    def recovery_system_(self) -> RecoverySystem:
        return self.services[RecoverySystem.IID] # type: ignore[no-any-return]

    # 测试服务
    def test_(self) -> Test:
        return self.services[Test.IID] # type: ignore[no-any-return]

