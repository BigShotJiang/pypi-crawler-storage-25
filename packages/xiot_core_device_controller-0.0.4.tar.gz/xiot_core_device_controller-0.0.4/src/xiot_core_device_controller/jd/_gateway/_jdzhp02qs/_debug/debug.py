from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.debug_enable import DebugEnable
from .properties.url import Url
from .properties.port import Port
from .properties.token import Token

# 调试
class Debug(ServiceController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:service:debug:00000c81:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Debug"
        self.description["zh-CN"] = "调试"

        self.properties[DebugEnable.IID] = DebugEnable()
        self.properties[Url.IID] = Url()
        self.properties[Port.IID] = Port()
        self.properties[Token.IID] = Token()



    # 调试功能开关
    def debug_enable_(self) -> DebugEnable:
        return self.properties[DebugEnable.IID] # type: ignore[no-any-return]

    # RTTY URL
    def url_(self) -> Url:
        return self.properties[Url.IID] # type: ignore[no-any-return]

    # RTTY PORT
    def port_(self) -> Port:
        return self.properties[Port.IID] # type: ignore[no-any-return]

    # RTTY TOKEN
    def token_(self) -> Token:
        return self.properties[Token.IID] # type: ignore[no-any-return]



