from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.open_curtain import OpenCurtain
from .actions.close_curtain import CloseCurtain
from .actions.stop_curtain import StopCurtain
from .actions.send_easylink import SendEasylink


from .properties.target_position import TargetPosition

# 窗帘面板
class CurtainPanel143(ServiceController):
    IID: int = 143
    TYPE: str = "urn:jd-spec:service:curtain-panel:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Curtain Panel"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "窗帘面板"

        self.properties[TargetPosition.IID] = TargetPosition()

        self.actions[OpenCurtain.IID] = OpenCurtain()
        self.actions[CloseCurtain.IID] = CloseCurtain()
        self.actions[StopCurtain.IID] = StopCurtain()
        self.actions[SendEasylink.IID] = SendEasylink()


    # 目标位置
    def target_position_(self) -> TargetPosition:
        return self.properties[TargetPosition.IID] # type: ignore[no-any-return]


    # 打开窗帘
    def open_curtain_(self) -> OpenCurtain:
        return self.actions[OpenCurtain.IID] # type: ignore[no-any-return]

    # 关闭窗帘
    def close_curtain_(self) -> CloseCurtain:
        return self.actions[CloseCurtain.IID] # type: ignore[no-any-return]

    # 暂停窗帘
    def stop_curtain_(self) -> StopCurtain:
        return self.actions[StopCurtain.IID] # type: ignore[no-any-return]

    # 发出爽连指令
    def send_easylink_(self) -> SendEasylink:
        return self.actions[SendEasylink.IID] # type: ignore[no-any-return]


