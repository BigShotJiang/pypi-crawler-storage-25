from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.time_out import TimeOut


import logging

_LOGGER = logging.getLogger(__name__)

# 开启扫描设备
class StartScanDevice(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:start-scan-device:00000d4a:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "start-scan-device"
        self.description["zh-CN"] = "开启扫描设备"


    # 执行 Action 调用
    async def invoke(self, time_out: Optional[int]):
        arguments: Dict[int, ArgumentOperation] = {}

        if time_out is None:
            raise ValueError("参数time_out不能为空")
        arguments[TimeOut.IID] = ArgumentOperation(piid = TimeOut.IID, value = time_out)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
