from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.upgrade_firmware import UpgradeFirmware

from .events.firmware_upgrade_succeeded import FirmwareUpgradeSucceeded
from .events.firmware_upgrade_failed import FirmwareUpgradeFailed
from .events.firmware_upgrade_progress import FirmwareUpgradeProgress

from .properties.protocol import Protocol
from .properties.progress import Progress
from .properties.md5 import Md5
from .properties.sha256 import Sha256
from .properties.firmware_revision import FirmwareRevision
from .properties.firmware_url import FirmwareUrl
from .properties.firmware_info_c import FirmwareInfoC
from .properties.code import Code
from .properties.firmware_type import FirmwareType
from .properties.file_size import FileSize
from .properties.did import Did

# ota管理服务
class OtaManagement(ServiceController):
    IID: int = 5
    TYPE: str = "urn:jd-spec:service:ota-management:00000e75:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "ota-management"
        self.description["zh-CN"] = "ota管理服务"

        self.properties[Protocol.IID] = Protocol()
        self.properties[Progress.IID] = Progress()
        self.properties[Md5.IID] = Md5()
        self.properties[Sha256.IID] = Sha256()
        self.properties[FirmwareRevision.IID] = FirmwareRevision()
        self.properties[FirmwareUrl.IID] = FirmwareUrl()
        self.properties[FirmwareInfoC.IID] = FirmwareInfoC()
        self.properties[Code.IID] = Code()
        self.properties[FirmwareType.IID] = FirmwareType()
        self.properties[FileSize.IID] = FileSize()
        self.properties[Did.IID] = Did()

        self.actions[UpgradeFirmware.IID] = UpgradeFirmware()

        self.events[FirmwareUpgradeSucceeded.IID] = FirmwareUpgradeSucceeded()
        self.events[FirmwareUpgradeFailed.IID] = FirmwareUpgradeFailed()
        self.events[FirmwareUpgradeProgress.IID] = FirmwareUpgradeProgress()

    # 通信方式
    def protocol_(self) -> Protocol:
        return self.properties[Protocol.IID] # type: ignore[no-any-return]

    # 进度
    def progress_(self) -> Progress:
        return self.properties[Progress.IID] # type: ignore[no-any-return]

    # md5
    def md5_(self) -> Md5:
        return self.properties[Md5.IID] # type: ignore[no-any-return]

    # sha256
    def sha256_(self) -> Sha256:
        return self.properties[Sha256.IID] # type: ignore[no-any-return]

    # 固件版本
    def firmware_revision_(self) -> FirmwareRevision:
        return self.properties[FirmwareRevision.IID] # type: ignore[no-any-return]

    # 固件地址
    def firmware_url_(self) -> FirmwareUrl:
        return self.properties[FirmwareUrl.IID] # type: ignore[no-any-return]

    # 固件信息
    def firmware_info_c_(self) -> FirmwareInfoC:
        return self.properties[FirmwareInfoC.IID] # type: ignore[no-any-return]

    # 回复码
    def code_(self) -> Code:
        return self.properties[Code.IID] # type: ignore[no-any-return]

    # 固件类型
    def firmware_type_(self) -> FirmwareType:
        return self.properties[FirmwareType.IID] # type: ignore[no-any-return]

    # 文件大小
    def file_size_(self) -> FileSize:
        return self.properties[FileSize.IID] # type: ignore[no-any-return]

    # 设备did
    def did_(self) -> Did:
        return self.properties[Did.IID] # type: ignore[no-any-return]


    # 升级固件
    def upgrade_firmware_(self) -> UpgradeFirmware:
        return self.actions[UpgradeFirmware.IID] # type: ignore[no-any-return]


    # 升级固件成功
    def firmware_upgrade_succeeded_(self) -> FirmwareUpgradeSucceeded:
        return self.events[FirmwareUpgradeSucceeded.IID] # type: ignore[no-any-return]

    # 固件升级失败
    def firmware_upgrade_failed_(self) -> FirmwareUpgradeFailed:
        return self.events[FirmwareUpgradeFailed.IID] # type: ignore[no-any-return]

    # 固件升级进度上报
    def firmware_upgrade_progress_(self) -> FirmwareUpgradeProgress:
        return self.events[FirmwareUpgradeProgress.IID] # type: ignore[no-any-return]

