from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.did import Did

from ..properties.status_code import StatusCode

import logging

_LOGGER = logging.getLogger(__name__)

# 添加设备
class AddDevice(ActionController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:action:add-device:00000d4a:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "add-device"
        self.description["zh-CN"] = "添加设备"

    # Action 出参
    class Result:
        # 状态码
        status_code: int

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _8: Optional[ArgumentOperation] = result[StatusCode.IID]
            if _8 is not None:
                v = _8.values[0]
                if isinstance(v, int):
                    self.status_code = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", StatusCode)

            return

    # 执行 Action 调用
    async def invoke(self, did: Optional[str]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if did is None:
            raise ValueError("参数did不能为空")
        arguments[Did.IID] = ArgumentOperation(piid = Did.IID, value = did)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return AddDevice.Result(out)
