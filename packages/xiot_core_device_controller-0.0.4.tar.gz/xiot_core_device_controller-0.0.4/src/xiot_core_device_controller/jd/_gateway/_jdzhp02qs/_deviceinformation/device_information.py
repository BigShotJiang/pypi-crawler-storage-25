from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.firmware_revision import FirmwareRevision
from .properties.manufacturer import Manufacturer
from .properties.hardware_revision import HardwareRevision
from .properties.ipv4_subnet_mask import Ipv4SubnetMask
from .properties.serial_number import SerialNumber
from .properties.mac_address import MacAddress
from .properties.ip import Ip
from .properties.support_time_configuration_for_automation import SupportTimeConfigurationForAutomation
from .properties.support_scene_embed_for_automation import SupportSceneEmbedForAutomation
from .properties.rssi import Rssi
from .properties.gateway import Gateway

# 设备信息
class DeviceInformation(ServiceController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:service:device-information:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Device Information"
        self.description["zh-CN"] = "设备信息"

        self.properties[FirmwareRevision.IID] = FirmwareRevision()
        self.properties[Manufacturer.IID] = Manufacturer()
        self.properties[HardwareRevision.IID] = HardwareRevision()
        self.properties[Ipv4SubnetMask.IID] = Ipv4SubnetMask()
        self.properties[SerialNumber.IID] = SerialNumber()
        self.properties[MacAddress.IID] = MacAddress()
        self.properties[Ip.IID] = Ip()
        self.properties[SupportTimeConfigurationForAutomation.IID] = SupportTimeConfigurationForAutomation()
        self.properties[SupportSceneEmbedForAutomation.IID] = SupportSceneEmbedForAutomation()
        self.properties[Rssi.IID] = Rssi()
        self.properties[Gateway.IID] = Gateway()



    # 固件版本
    def firmware_revision_(self) -> FirmwareRevision:
        return self.properties[FirmwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def manufacturer_(self) -> Manufacturer:
        return self.properties[Manufacturer.IID] # type: ignore[no-any-return]

    # 硬件版本
    def hardware_revision_(self) -> HardwareRevision:
        return self.properties[HardwareRevision.IID] # type: ignore[no-any-return]

    # 子网掩码
    def ipv4_subnet_mask_(self) -> Ipv4SubnetMask:
        return self.properties[Ipv4SubnetMask.IID] # type: ignore[no-any-return]

    # 序列号
    def serial_number_(self) -> SerialNumber:
        return self.properties[SerialNumber.IID] # type: ignore[no-any-return]

    # 设备本机 Mac 地址
    def mac_address_(self) -> MacAddress:
        return self.properties[MacAddress.IID] # type: ignore[no-any-return]

    # ipv4地址
    def ip_(self) -> Ip:
        return self.properties[Ip.IID] # type: ignore[no-any-return]

    # 网关本地自动化是否支持时间配置
    def support_time_configuration_for_automation_(self) -> SupportTimeConfigurationForAutomation:
        return self.properties[SupportTimeConfigurationForAutomation.IID] # type: ignore[no-any-return]

    # 网关本地自动化是否支持嵌入场景
    def support_scene_embed_for_automation_(self) -> SupportSceneEmbedForAutomation:
        return self.properties[SupportSceneEmbedForAutomation.IID] # type: ignore[no-any-return]

    # Wi-Fi信号强度
    def rssi_(self) -> Rssi:
        return self.properties[Rssi.IID] # type: ignore[no-any-return]

    # 网关功能
    def gateway_(self) -> Gateway:
        return self.properties[Gateway.IID] # type: ignore[no-any-return]



