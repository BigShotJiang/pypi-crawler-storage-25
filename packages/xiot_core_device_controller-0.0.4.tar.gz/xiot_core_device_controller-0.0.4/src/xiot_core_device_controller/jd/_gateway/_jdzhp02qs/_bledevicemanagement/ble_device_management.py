from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.start_scan_device import StartScanDevice
from .actions.stop_scan_device import StopScanDevice
from .actions.get_scan_result import GetScanResult
from .actions.add_device import AddDevice
from .actions.remove_device import RemoveDevice
from .actions.get_device_rssi import GetDeviceRssi
from .actions.add_devices import AddDevices

from .events.device_removed import DeviceRemoved
from .events.device_added import DeviceAdded

from .properties.ble_mac import BleMac
from .properties.time_out import TimeOut
from .properties.did import Did
from .properties.device_type import DeviceType
from .properties.rssi import Rssi
from .properties.device_info_c import DeviceInfoC
from .properties.device_rssi_c import DeviceRssiC
from .properties.status_code import StatusCode

# 蓝牙设备管理服务
class BleDeviceManagement(ServiceController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:service:ble-device-management:00000e76:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "ble-device-management"
        self.description["zh-CN"] = "蓝牙设备管理服务"

        self.properties[BleMac.IID] = BleMac()
        self.properties[TimeOut.IID] = TimeOut()
        self.properties[Did.IID] = Did()
        self.properties[DeviceType.IID] = DeviceType()
        self.properties[Rssi.IID] = Rssi()
        self.properties[DeviceInfoC.IID] = DeviceInfoC()
        self.properties[DeviceRssiC.IID] = DeviceRssiC()
        self.properties[StatusCode.IID] = StatusCode()

        self.actions[StartScanDevice.IID] = StartScanDevice()
        self.actions[StopScanDevice.IID] = StopScanDevice()
        self.actions[GetScanResult.IID] = GetScanResult()
        self.actions[AddDevice.IID] = AddDevice()
        self.actions[RemoveDevice.IID] = RemoveDevice()
        self.actions[GetDeviceRssi.IID] = GetDeviceRssi()
        self.actions[AddDevices.IID] = AddDevices()

        self.events[DeviceRemoved.IID] = DeviceRemoved()
        self.events[DeviceAdded.IID] = DeviceAdded()

    # 蓝牙Mac
    def ble_mac_(self) -> BleMac:
        return self.properties[BleMac.IID] # type: ignore[no-any-return]

    # 超时时间
    def time_out_(self) -> TimeOut:
        return self.properties[TimeOut.IID] # type: ignore[no-any-return]

    # 设备did
    def did_(self) -> Did:
        return self.properties[Did.IID] # type: ignore[no-any-return]

    # 设备类型
    def device_type_(self) -> DeviceType:
        return self.properties[DeviceType.IID] # type: ignore[no-any-return]

    # 蓝牙信号强度
    def rssi_(self) -> Rssi:
        return self.properties[Rssi.IID] # type: ignore[no-any-return]

    # 设备信息
    def device_info_c_(self) -> DeviceInfoC:
        return self.properties[DeviceInfoC.IID] # type: ignore[no-any-return]

    # 设备rssi
    def device_rssi_c_(self) -> DeviceRssiC:
        return self.properties[DeviceRssiC.IID] # type: ignore[no-any-return]

    # 状态码
    def status_code_(self) -> StatusCode:
        return self.properties[StatusCode.IID] # type: ignore[no-any-return]


    # 开启扫描设备
    def start_scan_device_(self) -> StartScanDevice:
        return self.actions[StartScanDevice.IID] # type: ignore[no-any-return]

    # 停止扫描设备
    def stop_scan_device_(self) -> StopScanDevice:
        return self.actions[StopScanDevice.IID] # type: ignore[no-any-return]

    # 读取扫描结果
    def get_scan_result_(self) -> GetScanResult:
        return self.actions[GetScanResult.IID] # type: ignore[no-any-return]

    # 添加设备
    def add_device_(self) -> AddDevice:
        return self.actions[AddDevice.IID] # type: ignore[no-any-return]

    # 删除设备
    def remove_device_(self) -> RemoveDevice:
        return self.actions[RemoveDevice.IID] # type: ignore[no-any-return]

    # 读取子设备rssi
    def get_device_rssi_(self) -> GetDeviceRssi:
        return self.actions[GetDeviceRssi.IID] # type: ignore[no-any-return]

    # 批量添加设备
    def add_devices_(self) -> AddDevices:
        return self.actions[AddDevices.IID] # type: ignore[no-any-return]


    # 设备删除
    def device_removed_(self) -> DeviceRemoved:
        return self.events[DeviceRemoved.IID] # type: ignore[no-any-return]

    # 设备添加
    def device_added_(self) -> DeviceAdded:
        return self.events[DeviceAdded.IID] # type: ignore[no-any-return]

