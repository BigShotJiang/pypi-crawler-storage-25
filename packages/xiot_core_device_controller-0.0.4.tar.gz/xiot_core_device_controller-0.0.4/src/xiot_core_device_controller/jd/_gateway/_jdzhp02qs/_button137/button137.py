from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.click import Click
from .actions.send_easylink import SendEasylink

from .events.clicked import Clicked

from .properties.name import Name

# 按键 10
class Button137(ServiceController):
    IID: int = 137
    TYPE: str = "urn:jd-spec:service:button:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Button 10"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "按键 10"

        self.properties[Name.IID] = Name()

        self.actions[Click.IID] = Click()
        self.actions[SendEasylink.IID] = SendEasylink()

        self.events[Clicked.IID] = Clicked()

    # 名称
    def name_(self) -> Name:
        return self.properties[Name.IID] # type: ignore[no-any-return]


    # 点击
    def click_(self) -> Click:
        return self.actions[Click.IID] # type: ignore[no-any-return]

    # 发出爽连指令
    def send_easylink_(self) -> SendEasylink:
        return self.actions[SendEasylink.IID] # type: ignore[no-any-return]


    # 已被点击
    def clicked_(self) -> Clicked:
        return self.events[Clicked.IID] # type: ignore[no-any-return]

