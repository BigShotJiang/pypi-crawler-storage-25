from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.did import Did

from ..properties.group_did import GroupDid

import logging

_LOGGER = logging.getLogger(__name__)

# 创建组
class CreateGroups(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:create-groups:00000b57:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Create Groups"
        self.description["zh-CN"] = "创建组"

    # Action 出参
    class Result:
        # 组did
        group_did: str

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _1: Optional[ArgumentOperation] = result[GroupDid.IID]
            if _1 is not None:
                v = _1.values[0]
                if isinstance(v, str):
                    self.group_did = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", GroupDid)

            return

    # 执行 Action 调用
    async def invoke(self, dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if dids is None or len(dids) == 0:
            raise ValueError("参数dids不能为空")
        arguments[Did.IID] = ArgumentOperation(piid = Did.IID, values = dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return CreateGroups.Result(out)
