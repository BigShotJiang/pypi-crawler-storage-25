from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController


from ..properties.group_did import GroupDid

import logging

_LOGGER = logging.getLogger(__name__)

# 获取组列表
class GetGroupsList(ActionController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:action:get-groups-list:00000b5a:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Get Groups List"
        self.description["zh-CN"] = "获取组列表"

    # Action 出参
    class Result:
        # 组did列表
        group_dids: list[str]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _1: Optional[ArgumentOperation] = result[GroupDid.IID]
            if _1 is not None:
                self.group_dids = [str(item) for item in _1.values]
            else:
                _LOGGER.error("result error, not found: %s.IID}", GroupDid)

            return

    # 执行 Action 调用
    async def invoke(self, ) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return GetGroupsList.Result(out)
