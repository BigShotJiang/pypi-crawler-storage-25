from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.firmware_revision import FirmwareRevision


import logging

_LOGGER = logging.getLogger(__name__)

# 发送指令
class SendCommand(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:send-command:00000028:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(self.TYPE))
        self.description["en-US"] = "Send Command"
        self.description["zh-CN"] = "发送指令"


    # 执行 Action 调用
    async def invoke(self, firmware_revision: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if firmware_revision is None:
            raise ValueError("参数firmware_revision不能为空")
        arguments[FirmwareRevision.IID] = ArgumentOperation(piid = FirmwareRevision.IID, value = firmware_revision)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
