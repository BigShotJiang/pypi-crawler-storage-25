from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.heartbeat_intertval import HeartbeatIntertval
from .properties.heartbeat_timeout import HeartbeatTimeout

# 心跳
class Heartbeat(ServiceController):
    IID: int = 129
    TYPE: str = "urn:jd-spec:service:heartbeat:000007d1:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Heartbeat"
        self.description["zh-CN"] = "心跳"

        self.properties[HeartbeatIntertval.IID] = HeartbeatIntertval()
        self.properties[HeartbeatTimeout.IID] = HeartbeatTimeout()



    # 心跳间隔
    def heartbeat_intertval_(self) -> HeartbeatIntertval:
        return self.properties[HeartbeatIntertval.IID] # type: ignore[no-any-return]

    # 心跳超时次数
    def heartbeat_timeout_(self) -> HeartbeatTimeout:
        return self.properties[HeartbeatTimeout.IID] # type: ignore[no-any-return]



