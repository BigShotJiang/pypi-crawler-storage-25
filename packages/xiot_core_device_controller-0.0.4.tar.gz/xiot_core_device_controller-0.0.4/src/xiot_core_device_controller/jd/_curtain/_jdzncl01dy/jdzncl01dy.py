from ....device_mapping import register_device

from xiot_core.spec.typedef.definition.urn.device_type import DeviceType
from xiot_core.support.typedef.controller.device_controller import DeviceController

from ._moduleinformation.module_information import ModuleInformation
from ._deviceinformation.device_information import DeviceInformation
from ._heartbeat.heartbeat import Heartbeat
from ._curtain.curtain import Curtain
from ._repeater.repeater import Repeater
from ._interaction.interaction import Interaction

# 窗帘电机
@register_device
class Jdzncl01dy(DeviceController):
    TYPE: str = "urn:jd-spec:device:curtain:00000010:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(DeviceType(self.TYPE))

        self.description["en-US"] = "Curtain Motor"
        self.description["zh-CN"] = "窗帘电机"

        self.services[ModuleInformation.IID] = ModuleInformation()
        self.services[DeviceInformation.IID] = DeviceInformation()
        self.services[Heartbeat.IID] = Heartbeat()
        self.services[Curtain.IID] = Curtain()
        self.services[Repeater.IID] = Repeater()
        self.services[Interaction.IID] = Interaction()

    # 模组信息
    def module_information_(self) -> ModuleInformation:
        return self.services[ModuleInformation.IID] # type: ignore[no-any-return]

    # 设备信息
    def device_information_(self) -> DeviceInformation:
        return self.services[DeviceInformation.IID] # type: ignore[no-any-return]

    # 心跳
    def heartbeat_(self) -> Heartbeat:
        return self.services[Heartbeat.IID] # type: ignore[no-any-return]

    # 窗帘
    def curtain_(self) -> Curtain:
        return self.services[Curtain.IID] # type: ignore[no-any-return]

    # 中继
    def repeater_(self) -> Repeater:
        return self.services[Repeater.IID] # type: ignore[no-any-return]

    # 本地自动化设置
    def interaction_(self) -> Interaction:
        return self.services[Interaction.IID] # type: ignore[no-any-return]

