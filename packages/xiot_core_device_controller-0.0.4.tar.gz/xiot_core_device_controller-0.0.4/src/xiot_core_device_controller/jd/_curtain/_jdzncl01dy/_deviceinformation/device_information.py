from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.reset import Reset
from .actions.erase_network import EraseNetwork
from .actions.send_command import SendCommand
from .actions.delete_easylink import DeleteEasylink
from .actions.start_easylink import StartEasylink


from .properties.firmware_revision import FirmwareRevision
from .properties.manufacturer import Manufacturer
from .properties.hardware_revision import HardwareRevision
from .properties.spec_version import SpecVersion

# 设备信息
class DeviceInformation(ServiceController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:service:device-information:00000001:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Device Information"
        self.description["zh-CN"] = "设备信息"

        self.properties[FirmwareRevision.IID] = FirmwareRevision()
        self.properties[Manufacturer.IID] = Manufacturer()
        self.properties[HardwareRevision.IID] = HardwareRevision()
        self.properties[SpecVersion.IID] = SpecVersion()

        self.actions[Reset.IID] = Reset()
        self.actions[EraseNetwork.IID] = EraseNetwork()
        self.actions[SendCommand.IID] = SendCommand()
        self.actions[DeleteEasylink.IID] = DeleteEasylink()
        self.actions[StartEasylink.IID] = StartEasylink()


    # 固件版本
    def firmware_revision_(self) -> FirmwareRevision:
        return self.properties[FirmwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def manufacturer_(self) -> Manufacturer:
        return self.properties[Manufacturer.IID] # type: ignore[no-any-return]

    # 硬件版本
    def hardware_revision_(self) -> HardwareRevision:
        return self.properties[HardwareRevision.IID] # type: ignore[no-any-return]

    # 物模型版本
    def spec_version_(self) -> SpecVersion:
        return self.properties[SpecVersion.IID] # type: ignore[no-any-return]


    # 恢复出厂设置
    def reset_(self) -> Reset:
        return self.actions[Reset.IID] # type: ignore[no-any-return]

    # 删除网络信息
    def erase_network_(self) -> EraseNetwork:
        return self.actions[EraseNetwork.IID] # type: ignore[no-any-return]

    # 发送指令
    def send_command_(self) -> SendCommand:
        return self.actions[SendCommand.IID] # type: ignore[no-any-return]

    # 删除爽连
    def delete_easylink_(self) -> DeleteEasylink:
        return self.actions[DeleteEasylink.IID] # type: ignore[no-any-return]

    # 打开爽连
    def start_easylink_(self) -> StartEasylink:
        return self.actions[StartEasylink.IID] # type: ignore[no-any-return]


