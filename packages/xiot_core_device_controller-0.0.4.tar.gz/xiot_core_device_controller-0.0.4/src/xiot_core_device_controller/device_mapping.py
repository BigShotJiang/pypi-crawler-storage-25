"""JD xIoT 设备类注册接口.

用于统一注册各类京东智能设备类到 device_mapping 中
"""

from typing import Optional

import logging

from xiot_core.support.typedef.controller.device_controller import DeviceController

_LOGGER = logging.getLogger(__name__)

_registry: dict[str, type[DeviceController]] = {}

def register_device(cls):
    """注册设备类到设备映射注册表中.

    Args:
        cls: 待注册的设备控制器类，需包含 TYPE 类属性

    Returns:
        传入的设备控制器类
    """
    _LOGGER.info("Register_device: %s", cls.TYPE)
    _registry[cls.TYPE] = cls
    return cls

def create_device(device_type: str, *args, **kwargs) -> Optional[DeviceController]:
    """根据 TYPE 字符串创建设备实例.

    Args:
        device_type: 设备类型字符串
        *args: 设备类初始化位置参数
        **kwargs: 设备类初始化关键字参数

    Returns:
        初始化后的设备控制器实例，若设备类型不存在则返回 None
    """
    _LOGGER.info("Create Device Controller: %s", device_type)
    device_class = _registry.get(device_type)
    if device_class is None:
        _LOGGER.info("Unknown device type: %s", device_type)
        return None
    else:
        return device_class(*args, **kwargs)