from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.firmware_revision import FirmwareRevision
from .properties.hardware_revision import HardwareRevision
from .properties.manufacturer import Manufacturer
from .properties.name import Name

# mcu信息
class McuInformation(ServiceController):
    IID: int = 130
    TYPE: str = "urn:jd:service:mcu-information:00001d03:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Mcu Information"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "mcu信息"

        self.properties[FirmwareRevision.IID] = FirmwareRevision()
        self.properties[HardwareRevision.IID] = HardwareRevision()
        self.properties[Manufacturer.IID] = Manufacturer()
        self.properties[Name.IID] = Name()



    # mcu固件版本
    def firmware_revision_(self) -> FirmwareRevision:
        return self.properties[FirmwareRevision.IID] # type: ignore[no-any-return]

    # mcu硬件版本
    def hardware_revision_(self) -> HardwareRevision:
        return self.properties[HardwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def manufacturer_(self) -> Manufacturer:
        return self.properties[Manufacturer.IID] # type: ignore[no-any-return]

    # 固件名称
    def name_(self) -> Name:
        return self.properties[Name.IID] # type: ignore[no-any-return]



