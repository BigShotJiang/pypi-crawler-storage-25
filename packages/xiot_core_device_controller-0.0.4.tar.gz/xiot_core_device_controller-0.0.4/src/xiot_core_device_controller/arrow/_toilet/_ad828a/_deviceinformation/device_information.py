from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.firmware_revision import FirmwareRevision
from .properties.manufacturer import Manufacturer
from .properties.hardware_revision import HardwareRevision

# 设备信息
class DeviceInformation(ServiceController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:service:device-information:00000001:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Device Information"
        self.description["zh-CN"] = "设备信息"

        self.properties[FirmwareRevision.IID] = FirmwareRevision()
        self.properties[Manufacturer.IID] = Manufacturer()
        self.properties[HardwareRevision.IID] = HardwareRevision()



    # 固件版本
    def firmware_revision_(self) -> FirmwareRevision:
        return self.properties[FirmwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def manufacturer_(self) -> Manufacturer:
        return self.properties[Manufacturer.IID] # type: ignore[no-any-return]

    # 硬件版本
    def hardware_revision_(self) -> HardwareRevision:
        return self.properties[HardwareRevision.IID] # type: ignore[no-any-return]



