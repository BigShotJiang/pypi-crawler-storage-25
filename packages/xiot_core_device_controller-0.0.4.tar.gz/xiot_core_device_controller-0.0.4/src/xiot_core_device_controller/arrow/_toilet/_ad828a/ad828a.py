from ....device_mapping import register_device

from xiot_core.spec.typedef.definition.urn.device_type import DeviceType
from xiot_core.support.typedef.controller.device_controller import DeviceController

from ._deviceinformation.device_information import DeviceInformation
from ._mcuinformation.mcu_information import McuInformation
from ._wificonnectivity.wifi_connectivity import WifiConnectivity
from ._otamanagement.ota_management import OtaManagement
from ._toilet.toilet import Toilet

# 箭牌马桶
@register_device
class Ad828a(DeviceController):
    TYPE: str = "urn:jd-spec:device:toilet:0000a02e:arrow:ad828a:1"

    def __init__(self):
        super().__init__(DeviceType(self.TYPE))

        self.description["en-US"] = "Arrow Toilet"
        self.description["zh-CN"] = "箭牌马桶"

        self.services[DeviceInformation.IID] = DeviceInformation()
        self.services[McuInformation.IID] = McuInformation()
        self.services[WifiConnectivity.IID] = WifiConnectivity()
        self.services[OtaManagement.IID] = OtaManagement()
        self.services[Toilet.IID] = Toilet()

    # 设备信息
    def device_information_(self) -> DeviceInformation:
        return self.services[DeviceInformation.IID] # type: ignore[no-any-return]

    # mcu信息
    def mcu_information_(self) -> McuInformation:
        return self.services[McuInformation.IID] # type: ignore[no-any-return]

    # 无线网络连接
    def wifi_connectivity_(self) -> WifiConnectivity:
        return self.services[WifiConnectivity.IID] # type: ignore[no-any-return]

    # ota管理服务
    def ota_management_(self) -> OtaManagement:
        return self.services[OtaManagement.IID] # type: ignore[no-any-return]

    # 马桶
    def toilet_(self) -> Toilet:
        return self.services[Toilet.IID] # type: ignore[no-any-return]

