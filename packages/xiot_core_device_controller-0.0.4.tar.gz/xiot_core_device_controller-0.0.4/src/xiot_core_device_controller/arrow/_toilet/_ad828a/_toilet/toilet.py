from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.full_flush import FullFlush
from .actions.partial_flush import PartialFlush


from .properties.on1 import On1
from .properties.seat_temperature_gear import SeatTemperatureGear
from .properties.on3 import On3
from .properties.on4 import On4
from .properties.on5 import On5
from .properties.on6 import On6
from .properties.on8 import On8

# 马桶
class Toilet(ServiceController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:service:toilet:000007d6:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(self.TYPE))

        self.description["en-US"] = "Toilet"
        self.description["zh-CN"] = "马桶"

        self.properties[On1.IID] = On1()
        self.properties[SeatTemperatureGear.IID] = SeatTemperatureGear()
        self.properties[On3.IID] = On3()
        self.properties[On4.IID] = On4()
        self.properties[On5.IID] = On5()
        self.properties[On6.IID] = On6()
        self.properties[On8.IID] = On8()

        self.actions[FullFlush.IID] = FullFlush()
        self.actions[PartialFlush.IID] = PartialFlush()


    # 座温开关
    def on1_(self) -> On1:
        return self.properties[On1.IID] # type: ignore[no-any-return]

    # 座温档位
    def seat_temperature_gear_(self) -> SeatTemperatureGear:
        return self.properties[SeatTemperatureGear.IID] # type: ignore[no-any-return]

    # 离座自动冲水
    def on3_(self) -> On3:
        return self.properties[On3.IID] # type: ignore[no-any-return]

    # 离座智感冲水
    def on4_(self) -> On4:
        return self.properties[On4.IID] # type: ignore[no-any-return]

    # 自动润壁开关
    def on5_(self) -> On5:
        return self.properties[On5.IID] # type: ignore[no-any-return]

    # 夜灯开关
    def on6_(self) -> On6:
        return self.properties[On6.IID] # type: ignore[no-any-return]

    # 脚感开关
    def on8_(self) -> On8:
        return self.properties[On8.IID] # type: ignore[no-any-return]


    # 大冲
    def full_flush_(self) -> FullFlush:
        return self.actions[FullFlush.IID] # type: ignore[no-any-return]

    # 小冲
    def partial_flush_(self) -> PartialFlush:
        return self.actions[PartialFlush.IID] # type: ignore[no-any-return]


