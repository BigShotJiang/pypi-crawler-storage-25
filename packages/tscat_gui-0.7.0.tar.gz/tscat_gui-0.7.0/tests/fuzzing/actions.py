from __future__ import annotations

import inspect
import time
from dataclasses import dataclass
from typing import Any, Callable

from hypothesis.stateful import (
    RuleBasedStateMachine,
    rule,
    precondition,
    initialize,
)
from hypothesis import settings as hypothesis_settings
from PySide6.QtWidgets import QApplication

from tests.fuzzing.model import AppModel
from tests.fuzzing.story import Step, Story


class _Skip:
    """Sentinel returned by actions to skip model_update and verify."""
    pass


SKIP = _Skip()


@dataclass
class ActionMeta:
    narrate: str
    model_update: Callable
    verify: Callable
    precondition: Callable | None = None
    target: str | None = None
    bundles: dict[str, str] | None = None
    strategies: dict[str, Any] | None = None
    settle_timeout_ms: int = 200
    manages_own_snapshots: bool = False


def ui_action(
    *,
    narrate: str,
    model_update: Callable,
    verify: Callable,
    precondition: Callable | None = None,
    target: str | None = None,
    bundles: dict[str, str] | None = None,
    strategies: dict[str, Any] | None = None,
    settle_timeout_ms: int = 200,
    manages_own_snapshots: bool = False,
):
    meta = ActionMeta(
        narrate=narrate,
        model_update=model_update,
        verify=verify,
        precondition=precondition,
        target=target,
        bundles=bundles,
        strategies=strategies,
        settle_timeout_ms=settle_timeout_ms,
        manages_own_snapshots=manages_own_snapshots,
    )

    def decorator(fn):
        fn._ui_meta = meta
        return fn

    return decorator


def settle(timeout_ms: int = 200):
    app = QApplication.instance()
    if app is None:
        return
    deadline = time.monotonic() + timeout_ms / 1000.0
    while time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.001)


def _bind_kwargs(fn: Callable, kwargs: dict[str, Any]) -> dict[str, Any]:
    params = set(inspect.signature(fn).parameters.keys())
    return {k: v for k, v in kwargs.items() if k in params}


def _defaults_for(fn: Callable) -> dict[str, Any]:
    defaults = {}
    for name, param in inspect.signature(fn).parameters.items():
        if param.default is not inspect.Parameter.empty:
            defaults[name] = param.default
    return defaults


def run_action(fn: Callable, gui, model: AppModel, story: Story, **kwargs) -> Any:
    meta: ActionMeta = fn._ui_meta  # type: ignore[attr-defined]

    if not meta.manages_own_snapshots:
        model.push_snapshot()

    try:
        result = fn(gui, model, **kwargs)
    except Exception as e:
        narrate_args = {k: str(v) for k, v in kwargs.items()}
        step = Step(
            action_name=fn.__name__,
            args=narrate_args,
            narrate_template=meta.narrate,
            error=e,
        )
        story.record(step)
        _dump_story(story)
        raise

    if isinstance(result, _Skip):
        if not meta.manages_own_snapshots:
            model.pop_snapshot()
        return None

    effective_kwargs = {**_defaults_for(fn), **kwargs}
    if isinstance(result, dict):
        cb_kwargs = {**effective_kwargs, **result, "result": result}
        narrate_args = {k: str(v) for k, v in result.items()}
    else:
        cb_kwargs = {**effective_kwargs, "result": result}
        narrate_args = {k: str(v) for k, v in effective_kwargs.items()}
        if result is not None:
            narrate_args["result"] = str(result)

    step = Step(
        action_name=fn.__name__,
        args=narrate_args,
        narrate_template=meta.narrate,
        result=result if not isinstance(result, dict) else None,
    )
    story.record(step)

    settle(meta.settle_timeout_ms)

    model_kwargs = _bind_kwargs(meta.model_update, cb_kwargs)
    meta.model_update(model, **model_kwargs)

    verify_kwargs = _bind_kwargs(meta.verify, cb_kwargs)
    try:
        ok = meta.verify(gui, model, **verify_kwargs)
        if ok is False:
            raise AssertionError(f"Verification failed after {fn.__name__}")
    except Exception as e:
        story.steps[-1].error = e
        _dump_story(story)
        raise

    return result


def _reset_tscat_backend(gui) -> None:
    from tscat_gui.tscat_driver.driver import tscat_driver
    from tscat_gui.tscat_driver.actions import GetCataloguesAction
    import tscat

    gui.catalogues_view.selectionModel().clearSelection()
    gui.events_view.selectionModel().clearSelection()
    settle(200)

    gui.state.undo_stack().clear()
    gui.state.updated('active_select', tscat._Catalogue, [])

    for cat in tscat.get_catalogues() + tscat.get_catalogues(removed_items=True):
        cat.remove(permanently=True)
    tscat.save()

    tscat_driver._entity_cache.clear()

    tscat_driver.do(GetCataloguesAction(None, False))
    tscat_driver.do(GetCataloguesAction(None, True))
    settle(500)


class StoryRunner:
    def __init__(self, gui):
        self.gui = gui
        self.model = AppModel()
        self.story = Story()

    def run(self, action_fn: Callable, **kwargs) -> Any:
        return run_action(action_fn, self.gui, self.model, self.story, **kwargs)

    def cleanup(self):
        try:
            _reset_tscat_backend(self.gui)
        except Exception:
            pass
        settle()


class ActionRegistry:
    def __init__(self):
        self.actions: list[Callable] = []

    def register(self, fn: Callable) -> Callable:
        if not hasattr(fn, "_ui_meta"):
            raise ValueError(f"{fn.__name__} must be decorated with @ui_action")
        self.actions.append(fn)
        return fn

    def build_state_machine(
        self,
        name: str = "UIFuzzTest",
        *,
        max_examples: int = 10,
        stateful_step_count: int = 15,
    ) -> type:
        registry = self
        class_dict: dict[str, Any] = {}

        @initialize()
        def _init_model(self):
            _reset_tscat_backend(self.__class__.gui)
            self._model = AppModel()
            self._story = Story()

        class_dict["_init_model"] = _init_model

        def teardown(self):
            if self._story.steps:
                last = self._story.steps[-1]
                if last.error is not None:
                    _dump_story(self._story)
            try:
                _reset_tscat_backend(self.__class__.gui)
            except Exception:
                pass
            settle(500)

        class_dict["teardown"] = teardown

        for action_fn in registry.actions:
            meta: ActionMeta = action_fn._ui_meta  # type: ignore[attr-defined]
            method_name = action_fn.__name__

            rule_kwargs: dict[str, Any] = {}
            for param_name, strategy in (meta.strategies or {}).items():
                rule_kwargs[param_name] = strategy

            def make_rule_method(fn, fn_meta):
                def rule_method(self, **kwargs):
                    run_action(
                        fn,
                        self.__class__.gui,
                        self._model,
                        self._story,
                        **kwargs,
                    )

                return rule_method

            method = make_rule_method(action_fn, meta)
            method.__name__ = method_name

            if meta.precondition:
                user_precond = meta.precondition
                method = precondition(
                    lambda self, _p=user_precond: _p(self._model)  # type: ignore[misc]
                )(method)

            method = rule(**rule_kwargs)(method)
            class_dict[method_name] = method

        sm_class = type(name, (RuleBasedStateMachine,), class_dict)

        sm_class.TestCase.settings = hypothesis_settings(  # type: ignore[attr-defined]
            max_examples=max_examples,
            stateful_step_count=stateful_step_count,
            deadline=None,
            database=None,
        )

        return sm_class


def _dump_story(story: Story):
    import os
    from datetime import datetime

    narrative = story.narrative()
    reproducer = story.reproducer()

    print("\n=== FAILURE STORY ===")
    print(narrative)
    print("\n=== REPRODUCER ===")
    print(reproducer)
    print("=== END ===\n")

    reports_dir = os.environ.get("TSCAT_TEST_REPORTS", "test-reports")
    os.makedirs(reports_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    with open(os.path.join(reports_dir, f"story-{timestamp}.txt"), "w") as f:
        f.write(narrative)
    with open(os.path.join(reports_dir, f"story-{timestamp}.py"), "w") as f:
        f.write(reproducer)
