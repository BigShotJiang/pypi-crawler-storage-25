from functools import wraps
from urllib.parse import urlparse

import structlog
from django.conf import settings
from django.contrib.auth import REDIRECT_FIELD_NAME
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Prefetch
from django.http import Http404, HttpRequest, HttpResponse, HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render, resolve_url
from django.utils import timezone
from django.views.decorators.http import require_POST
from render_block import render_block_to_string
from waffle.decorators import waffle_switch

from nomnom.base.feature_switches import SWITCH_HUGO_PACKET
from nomnom.hugopacket.models import (
    DistributionCode,
    ElectionPacket,
    PacketFile,
    PacketItemAccess,
)
from nomnom.nominate.models import Election

logger = structlog.get_logger(__name__)


def request_passes_test(
    test_func, login_url=None, redirect_field_name=REDIRECT_FIELD_NAME
):
    """
    Decorator for views that checks that the user passes the given test,
    redirecting to the log-in page if necessary. The test should be a callable
    that takes the user object and returns True if the user passes.
    """

    def decorator(view_func):
        @wraps(view_func)
        def _wrapper_view(request, *args, **kwargs):
            if test_func(request):
                return view_func(request, *args, **kwargs)
            path = request.build_absolute_uri()
            resolved_login_url = resolve_url(login_url or settings.LOGIN_URL)
            # If the login url is the same scheme and net location then just
            # use the path as the "next" url.
            login_scheme, login_netloc = urlparse(resolved_login_url)[:2]
            current_scheme, current_netloc = urlparse(path)[:2]
            if (not login_scheme or login_scheme == current_scheme) and (
                not login_netloc or login_netloc == current_netloc
            ):
                path = request.get_full_path()
            from django.contrib.auth.views import redirect_to_login

            return redirect_to_login(path, resolved_login_url, redirect_field_name)

        return _wrapper_view

    return decorator


def member_can_vote():
    def test_func(request: HttpRequest) -> bool:
        election_id = request.resolver_match.kwargs.get("election_id")

        if not get_object_or_404(Election, slug=election_id).user_can_vote(
            request.user
        ):
            raise PermissionDenied()

        return True

    return request_passes_test(test_func)


def either_of(*predicates):
    def test_func(request: HttpRequest) -> bool:
        for predicate in predicates:
            try:
                if predicate(request):
                    return True
            except PermissionDenied:
                continue
        raise PermissionDenied()

    return request_passes_test(test_func)


@waffle_switch(SWITCH_HUGO_PACKET)
@login_required
@either_of(member_can_vote(), permission_required("hugopacket.preview_packet"))
def index(request: HttpRequest, election_id: str) -> HttpResponse:
    election: Election = get_object_or_404(Election, slug=election_id)
    packet: ElectionPacket = get_object_or_404(ElectionPacket, election=election)

    # the packet is allowed for members with voting preview, even if inactive
    if not packet.enabled and not request.user.has_perm("hugopacket.preview_packet"):
        return HttpResponseForbidden()

    # if the election is in a state where even packet preview is inpermissible,
    # then also block users with preview permissions
    if election.state not in [
        Election.STATE.NOMINATIONS_CLOSED,
        Election.STATE.VOTING_PREVIEW,
        Election.STATE.VOTING,
    ]:
        return HttpResponseForbidden()

    # Get member profile for access tracking
    member = request.user.convention_profile

    # Prefetch access records for the current member to avoid N+1 queries
    member_access_prefetch = Prefetch(
        "member_accesses",
        queryset=PacketItemAccess.objects.filter(member=member),
        to_attr="prefetched_member_access",
    )

    # Build hierarchical section structure
    root_sections = packet.sections.filter(parent__isnull=True).prefetch_related(
        "subsections",
        Prefetch(
            "files",
            queryset=PacketFile.objects.prefetch_related(member_access_prefetch),
        ),
    )

    # For backward compatibility: get files without sections
    orphan_files = packet.packetfile_set.filter(section__isnull=True).prefetch_related(
        member_access_prefetch
    )

    def annotate_file(pf):
        """Attach access tracking info directly onto the PacketFile instance."""
        if member:
            prefetched_access = getattr(pf, "prefetched_member_access", [])
            if prefetched_access:
                access = prefetched_access[0]
                pf.access_count = access.access_count
                pf.has_code = (
                    pf.access_type == PacketFile.AccessType.CODE
                    and access.distribution_code is not None
                )
            else:
                pf.access_count = 0
                pf.has_code = False
        else:
            pf.access_count = 0
            pf.has_code = False
        return pf

    # Recursively build section hierarchy with files
    def build_section_tree(section):
        return {
            "section": section,
            "files": [annotate_file(f) for f in section.files.all()],
            "subsections": [build_section_tree(s) for s in section.subsections.all()],
        }

    section_tree = [build_section_tree(s) for s in root_sections]

    orphan_file_list = [annotate_file(pf) for pf in orphan_files]

    return render(
        request,
        "hugopacket/index.html",
        {
            "election": election,
            "packet": packet,
            "section_tree": section_tree,
            "orphan_files": orphan_file_list,
        },
    )


@waffle_switch(SWITCH_HUGO_PACKET)
@login_required
@member_can_vote()
def download_packet(
    request: HttpRequest, election_id: str, packet_file_id: int
) -> HttpResponse:
    election = get_object_or_404(Election, slug=election_id)
    packet_file = get_object_or_404(PacketFile, pk=packet_file_id)
    # ensure that the packet file belongs to the election
    if packet_file.packet.election != election:
        raise Http404()

    if not packet_file.packet.enabled and not request.user.has_perm(
        "hugopacket.preview_packet"
    ):
        raise Http404()

    if not packet_file.available:
        return HttpResponseForbidden()

    # Get member profile (required for tracking access)
    member = request.user.convention_profile

    # Handle code-based access
    if packet_file.access_type == PacketFile.AccessType.CODE:
        # Get or create access record
        access, created = PacketItemAccess.objects.get_or_create(
            packet_file=packet_file, member=member
        )

        if access.distribution_code:
            # Record the access
            access.increment_access()

            # Format code for display and get raw version for copying
            raw_code = access.distribution_code.code
            display_code = packet_file.format_code(raw_code)
        else:
            display_code = None
            raw_code = None

        # Display the code to the user
        return render(
            request,
            "hugopacket/display_code.html",
            {
                "packet_file": packet_file,
                "display_code": display_code,
                "copy_code": raw_code,
                "access_count": access.access_count,
            },
        )

    # Handle download-based access
    elif packet_file.access_type == PacketFile.AccessType.DOWNLOAD:
        # Get or create access record
        access, created = PacketItemAccess.objects.get_or_create(
            packet_file=packet_file, member=member
        )

        # Record the access
        access.increment_access()

        # Get presigned URL and redirect
        download_url = access.get_access_url(request)
        return redirect(download_url)

    else:
        raise ValueError(f"Unknown access type: {packet_file.access_type}")


@waffle_switch(SWITCH_HUGO_PACKET)
@login_required
@member_can_vote()
@require_POST
def claim_code(
    request: HttpRequest, election_id: str, packet_file_id: int
) -> HttpResponse:
    election = get_object_or_404(Election, slug=election_id)
    packet_file = get_object_or_404(PacketFile, pk=packet_file_id)
    # ensure that the packet file belongs to the election
    if packet_file.packet.election != election:
        raise Http404()

    if not packet_file.packet.enabled and not request.user.has_perm(
        "hugopacket.preview_packet"
    ):
        raise Http404()

    if not packet_file.available:
        return HttpResponseForbidden()

    # Handle code-based access
    if packet_file.access_type != PacketFile.AccessType.CODE:
        raise Http404("Invalid access type for code generation.")

    # Get member profile (required for tracking access)
    member = request.user.convention_profile

    with transaction.atomic():
        # Get or create access record
        access, created = PacketItemAccess.objects.get_or_create(
            packet_file=packet_file, member=member
        )

        # Assign a code if not already assigned
        if not access.distribution_code:
            # Get IDs of already assigned codes
            assigned_code_ids = PacketItemAccess.objects.filter(
                distribution_code__packet_file=packet_file
            ).values_list("distribution_code_id", flat=True)

            # Find an unassigned code from the pool
            unassigned_code = (
                DistributionCode.objects.filter(packet_file=packet_file)
                .exclude(id__in=assigned_code_ids)
                .select_for_update()
                .first()
            )

            if not unassigned_code:
                logger.error(
                    "no distribution codes available",
                    packet_file_id=packet_file.id,
                    member_id=member.id,
                )
                return render(
                    request,
                    "hugopacket/no_codes_available.html",
                    {"packet_file": packet_file},
                    status=503,
                )

            # Assign the code
            access.distribution_code = unassigned_code
            unassigned_code.assigned_at = timezone.now()
            unassigned_code.save(update_fields=["assigned_at"])
            access.save(update_fields=["distribution_code"])

            logger.info(
                "assigned distribution code",
                packet_file_id=packet_file.id,
                member_id=member.id,
                code_id=unassigned_code.id,
            )

    if request.htmx:
        # render the template fragment for the code only
        template_name = ("hugopacket/display_code.html",)
        context_data = {
            "packet_file": packet_file,
            "display_code": packet_file.format_code(access.distribution_code.code),
            "copy_code": access.distribution_code.code,
            "access_count": access.access_count,
        }
        return HttpResponse(
            render_block_to_string(template_name, "display_code", context_data, request)
        )
    else:
        # Redirect to the download page
        return redirect(
            "hugopacket:download_packet",
            election_id=election.slug,
            packet_file_id=packet_file.id,
        )
