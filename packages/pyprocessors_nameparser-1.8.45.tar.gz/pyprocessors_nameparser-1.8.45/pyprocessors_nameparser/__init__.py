"""Processor based on Nameparser"""

__version__ = "1.8.45"
