"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};

// node_modules/commander/lib/error.js
var require_error = __commonJS({
  "node_modules/commander/lib/error.js"(exports2) {
    var CommanderError = class extends Error {
      /**
       * Constructs the CommanderError class
       * @param {number} exitCode suggested exit code which could be used with process.exit
       * @param {string} code an id string representing the error
       * @param {string} message human-readable description of the error
       */
      constructor(exitCode, code, message) {
        super(message);
        Error.captureStackTrace(this, this.constructor);
        this.name = this.constructor.name;
        this.code = code;
        this.exitCode = exitCode;
        this.nestedError = void 0;
      }
    };
    var InvalidArgumentError = class extends CommanderError {
      /**
       * Constructs the InvalidArgumentError class
       * @param {string} [message] explanation of why argument is invalid
       */
      constructor(message) {
        super(1, "commander.invalidArgument", message);
        Error.captureStackTrace(this, this.constructor);
        this.name = this.constructor.name;
      }
    };
    exports2.CommanderError = CommanderError;
    exports2.InvalidArgumentError = InvalidArgumentError;
  }
});

// node_modules/commander/lib/argument.js
var require_argument = __commonJS({
  "node_modules/commander/lib/argument.js"(exports2) {
    var { InvalidArgumentError } = require_error();
    var Argument = class {
      /**
       * Initialize a new command argument with the given name and description.
       * The default is that the argument is required, and you can explicitly
       * indicate this with <> around the name. Put [] around the name for an optional argument.
       *
       * @param {string} name
       * @param {string} [description]
       */
      constructor(name, description) {
        this.description = description || "";
        this.variadic = false;
        this.parseArg = void 0;
        this.defaultValue = void 0;
        this.defaultValueDescription = void 0;
        this.argChoices = void 0;
        switch (name[0]) {
          case "<":
            this.required = true;
            this._name = name.slice(1, -1);
            break;
          case "[":
            this.required = false;
            this._name = name.slice(1, -1);
            break;
          default:
            this.required = true;
            this._name = name;
            break;
        }
        if (this._name.endsWith("...")) {
          this.variadic = true;
          this._name = this._name.slice(0, -3);
        }
      }
      /**
       * Return argument name.
       *
       * @return {string}
       */
      name() {
        return this._name;
      }
      /**
       * @package
       */
      _collectValue(value, previous) {
        if (previous === this.defaultValue || !Array.isArray(previous)) {
          return [value];
        }
        previous.push(value);
        return previous;
      }
      /**
       * Set the default value, and optionally supply the description to be displayed in the help.
       *
       * @param {*} value
       * @param {string} [description]
       * @return {Argument}
       */
      default(value, description) {
        this.defaultValue = value;
        this.defaultValueDescription = description;
        return this;
      }
      /**
       * Set the custom handler for processing CLI command arguments into argument values.
       *
       * @param {Function} [fn]
       * @return {Argument}
       */
      argParser(fn) {
        this.parseArg = fn;
        return this;
      }
      /**
       * Only allow argument value to be one of choices.
       *
       * @param {string[]} values
       * @return {Argument}
       */
      choices(values) {
        this.argChoices = values.slice();
        this.parseArg = (arg, previous) => {
          if (!this.argChoices.includes(arg)) {
            throw new InvalidArgumentError(
              `Allowed choices are ${this.argChoices.join(", ")}.`
            );
          }
          if (this.variadic) {
            return this._collectValue(arg, previous);
          }
          return arg;
        };
        return this;
      }
      /**
       * Make argument required.
       *
       * @returns {Argument}
       */
      argRequired() {
        this.required = true;
        return this;
      }
      /**
       * Make argument optional.
       *
       * @returns {Argument}
       */
      argOptional() {
        this.required = false;
        return this;
      }
    };
    function humanReadableArgName(arg) {
      const nameOutput = arg.name() + (arg.variadic === true ? "..." : "");
      return arg.required ? "<" + nameOutput + ">" : "[" + nameOutput + "]";
    }
    exports2.Argument = Argument;
    exports2.humanReadableArgName = humanReadableArgName;
  }
});

// node_modules/commander/lib/help.js
var require_help = __commonJS({
  "node_modules/commander/lib/help.js"(exports2) {
    var { humanReadableArgName } = require_argument();
    var Help = class {
      constructor() {
        this.helpWidth = void 0;
        this.minWidthToWrap = 40;
        this.sortSubcommands = false;
        this.sortOptions = false;
        this.showGlobalOptions = false;
      }
      /**
       * prepareContext is called by Commander after applying overrides from `Command.configureHelp()`
       * and just before calling `formatHelp()`.
       *
       * Commander just uses the helpWidth and the rest is provided for optional use by more complex subclasses.
       *
       * @param {{ error?: boolean, helpWidth?: number, outputHasColors?: boolean }} contextOptions
       */
      prepareContext(contextOptions) {
        this.helpWidth = this.helpWidth ?? contextOptions.helpWidth ?? 80;
      }
      /**
       * Get an array of the visible subcommands. Includes a placeholder for the implicit help command, if there is one.
       *
       * @param {Command} cmd
       * @returns {Command[]}
       */
      visibleCommands(cmd) {
        const visibleCommands = cmd.commands.filter((cmd2) => !cmd2._hidden);
        const helpCommand = cmd._getHelpCommand();
        if (helpCommand && !helpCommand._hidden) {
          visibleCommands.push(helpCommand);
        }
        if (this.sortSubcommands) {
          visibleCommands.sort((a, b) => {
            return a.name().localeCompare(b.name());
          });
        }
        return visibleCommands;
      }
      /**
       * Compare options for sort.
       *
       * @param {Option} a
       * @param {Option} b
       * @returns {number}
       */
      compareOptions(a, b) {
        const getSortKey = (option) => {
          return option.short ? option.short.replace(/^-/, "") : option.long.replace(/^--/, "");
        };
        return getSortKey(a).localeCompare(getSortKey(b));
      }
      /**
       * Get an array of the visible options. Includes a placeholder for the implicit help option, if there is one.
       *
       * @param {Command} cmd
       * @returns {Option[]}
       */
      visibleOptions(cmd) {
        const visibleOptions = cmd.options.filter((option) => !option.hidden);
        const helpOption = cmd._getHelpOption();
        if (helpOption && !helpOption.hidden) {
          const removeShort = helpOption.short && cmd._findOption(helpOption.short);
          const removeLong = helpOption.long && cmd._findOption(helpOption.long);
          if (!removeShort && !removeLong) {
            visibleOptions.push(helpOption);
          } else if (helpOption.long && !removeLong) {
            visibleOptions.push(
              cmd.createOption(helpOption.long, helpOption.description)
            );
          } else if (helpOption.short && !removeShort) {
            visibleOptions.push(
              cmd.createOption(helpOption.short, helpOption.description)
            );
          }
        }
        if (this.sortOptions) {
          visibleOptions.sort(this.compareOptions);
        }
        return visibleOptions;
      }
      /**
       * Get an array of the visible global options. (Not including help.)
       *
       * @param {Command} cmd
       * @returns {Option[]}
       */
      visibleGlobalOptions(cmd) {
        if (!this.showGlobalOptions) return [];
        const globalOptions = [];
        for (let ancestorCmd = cmd.parent; ancestorCmd; ancestorCmd = ancestorCmd.parent) {
          const visibleOptions = ancestorCmd.options.filter(
            (option) => !option.hidden
          );
          globalOptions.push(...visibleOptions);
        }
        if (this.sortOptions) {
          globalOptions.sort(this.compareOptions);
        }
        return globalOptions;
      }
      /**
       * Get an array of the arguments if any have a description.
       *
       * @param {Command} cmd
       * @returns {Argument[]}
       */
      visibleArguments(cmd) {
        if (cmd._argsDescription) {
          cmd.registeredArguments.forEach((argument) => {
            argument.description = argument.description || cmd._argsDescription[argument.name()] || "";
          });
        }
        if (cmd.registeredArguments.find((argument) => argument.description)) {
          return cmd.registeredArguments;
        }
        return [];
      }
      /**
       * Get the command term to show in the list of subcommands.
       *
       * @param {Command} cmd
       * @returns {string}
       */
      subcommandTerm(cmd) {
        const args2 = cmd.registeredArguments.map((arg) => humanReadableArgName(arg)).join(" ");
        return cmd._name + (cmd._aliases[0] ? "|" + cmd._aliases[0] : "") + (cmd.options.length ? " [options]" : "") + // simplistic check for non-help option
        (args2 ? " " + args2 : "");
      }
      /**
       * Get the option term to show in the list of options.
       *
       * @param {Option} option
       * @returns {string}
       */
      optionTerm(option) {
        return option.flags;
      }
      /**
       * Get the argument term to show in the list of arguments.
       *
       * @param {Argument} argument
       * @returns {string}
       */
      argumentTerm(argument) {
        return argument.name();
      }
      /**
       * Get the longest command term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestSubcommandTermLength(cmd, helper) {
        return helper.visibleCommands(cmd).reduce((max, command) => {
          return Math.max(
            max,
            this.displayWidth(
              helper.styleSubcommandTerm(helper.subcommandTerm(command))
            )
          );
        }, 0);
      }
      /**
       * Get the longest option term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestOptionTermLength(cmd, helper) {
        return helper.visibleOptions(cmd).reduce((max, option) => {
          return Math.max(
            max,
            this.displayWidth(helper.styleOptionTerm(helper.optionTerm(option)))
          );
        }, 0);
      }
      /**
       * Get the longest global option term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestGlobalOptionTermLength(cmd, helper) {
        return helper.visibleGlobalOptions(cmd).reduce((max, option) => {
          return Math.max(
            max,
            this.displayWidth(helper.styleOptionTerm(helper.optionTerm(option)))
          );
        }, 0);
      }
      /**
       * Get the longest argument term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      longestArgumentTermLength(cmd, helper) {
        return helper.visibleArguments(cmd).reduce((max, argument) => {
          return Math.max(
            max,
            this.displayWidth(
              helper.styleArgumentTerm(helper.argumentTerm(argument))
            )
          );
        }, 0);
      }
      /**
       * Get the command usage to be displayed at the top of the built-in help.
       *
       * @param {Command} cmd
       * @returns {string}
       */
      commandUsage(cmd) {
        let cmdName = cmd._name;
        if (cmd._aliases[0]) {
          cmdName = cmdName + "|" + cmd._aliases[0];
        }
        let ancestorCmdNames = "";
        for (let ancestorCmd = cmd.parent; ancestorCmd; ancestorCmd = ancestorCmd.parent) {
          ancestorCmdNames = ancestorCmd.name() + " " + ancestorCmdNames;
        }
        return ancestorCmdNames + cmdName + " " + cmd.usage();
      }
      /**
       * Get the description for the command.
       *
       * @param {Command} cmd
       * @returns {string}
       */
      commandDescription(cmd) {
        return cmd.description();
      }
      /**
       * Get the subcommand summary to show in the list of subcommands.
       * (Fallback to description for backwards compatibility.)
       *
       * @param {Command} cmd
       * @returns {string}
       */
      subcommandDescription(cmd) {
        return cmd.summary() || cmd.description();
      }
      /**
       * Get the option description to show in the list of options.
       *
       * @param {Option} option
       * @return {string}
       */
      optionDescription(option) {
        const extraInfo = [];
        if (option.argChoices) {
          extraInfo.push(
            // use stringify to match the display of the default value
            `choices: ${option.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`
          );
        }
        if (option.defaultValue !== void 0) {
          const showDefault = option.required || option.optional || option.isBoolean() && typeof option.defaultValue === "boolean";
          if (showDefault) {
            extraInfo.push(
              `default: ${option.defaultValueDescription || JSON.stringify(option.defaultValue)}`
            );
          }
        }
        if (option.presetArg !== void 0 && option.optional) {
          extraInfo.push(`preset: ${JSON.stringify(option.presetArg)}`);
        }
        if (option.envVar !== void 0) {
          extraInfo.push(`env: ${option.envVar}`);
        }
        if (extraInfo.length > 0) {
          const extraDescription = `(${extraInfo.join(", ")})`;
          if (option.description) {
            return `${option.description} ${extraDescription}`;
          }
          return extraDescription;
        }
        return option.description;
      }
      /**
       * Get the argument description to show in the list of arguments.
       *
       * @param {Argument} argument
       * @return {string}
       */
      argumentDescription(argument) {
        const extraInfo = [];
        if (argument.argChoices) {
          extraInfo.push(
            // use stringify to match the display of the default value
            `choices: ${argument.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`
          );
        }
        if (argument.defaultValue !== void 0) {
          extraInfo.push(
            `default: ${argument.defaultValueDescription || JSON.stringify(argument.defaultValue)}`
          );
        }
        if (extraInfo.length > 0) {
          const extraDescription = `(${extraInfo.join(", ")})`;
          if (argument.description) {
            return `${argument.description} ${extraDescription}`;
          }
          return extraDescription;
        }
        return argument.description;
      }
      /**
       * Format a list of items, given a heading and an array of formatted items.
       *
       * @param {string} heading
       * @param {string[]} items
       * @param {Help} helper
       * @returns string[]
       */
      formatItemList(heading, items, helper) {
        if (items.length === 0) return [];
        return [helper.styleTitle(heading), ...items, ""];
      }
      /**
       * Group items by their help group heading.
       *
       * @param {Command[] | Option[]} unsortedItems
       * @param {Command[] | Option[]} visibleItems
       * @param {Function} getGroup
       * @returns {Map<string, Command[] | Option[]>}
       */
      groupItems(unsortedItems, visibleItems, getGroup) {
        const result = /* @__PURE__ */ new Map();
        unsortedItems.forEach((item) => {
          const group = getGroup(item);
          if (!result.has(group)) result.set(group, []);
        });
        visibleItems.forEach((item) => {
          const group = getGroup(item);
          if (!result.has(group)) {
            result.set(group, []);
          }
          result.get(group).push(item);
        });
        return result;
      }
      /**
       * Generate the built-in help text.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {string}
       */
      formatHelp(cmd, helper) {
        const termWidth = helper.padWidth(cmd, helper);
        const helpWidth = helper.helpWidth ?? 80;
        function callFormatItem(term, description) {
          return helper.formatItem(term, termWidth, description, helper);
        }
        let output = [
          `${helper.styleTitle("Usage:")} ${helper.styleUsage(helper.commandUsage(cmd))}`,
          ""
        ];
        const commandDescription = helper.commandDescription(cmd);
        if (commandDescription.length > 0) {
          output = output.concat([
            helper.boxWrap(
              helper.styleCommandDescription(commandDescription),
              helpWidth
            ),
            ""
          ]);
        }
        const argumentList = helper.visibleArguments(cmd).map((argument) => {
          return callFormatItem(
            helper.styleArgumentTerm(helper.argumentTerm(argument)),
            helper.styleArgumentDescription(helper.argumentDescription(argument))
          );
        });
        output = output.concat(
          this.formatItemList("Arguments:", argumentList, helper)
        );
        const optionGroups = this.groupItems(
          cmd.options,
          helper.visibleOptions(cmd),
          (option) => option.helpGroupHeading ?? "Options:"
        );
        optionGroups.forEach((options, group) => {
          const optionList = options.map((option) => {
            return callFormatItem(
              helper.styleOptionTerm(helper.optionTerm(option)),
              helper.styleOptionDescription(helper.optionDescription(option))
            );
          });
          output = output.concat(this.formatItemList(group, optionList, helper));
        });
        if (helper.showGlobalOptions) {
          const globalOptionList = helper.visibleGlobalOptions(cmd).map((option) => {
            return callFormatItem(
              helper.styleOptionTerm(helper.optionTerm(option)),
              helper.styleOptionDescription(helper.optionDescription(option))
            );
          });
          output = output.concat(
            this.formatItemList("Global Options:", globalOptionList, helper)
          );
        }
        const commandGroups = this.groupItems(
          cmd.commands,
          helper.visibleCommands(cmd),
          (sub) => sub.helpGroup() || "Commands:"
        );
        commandGroups.forEach((commands, group) => {
          const commandList = commands.map((sub) => {
            return callFormatItem(
              helper.styleSubcommandTerm(helper.subcommandTerm(sub)),
              helper.styleSubcommandDescription(helper.subcommandDescription(sub))
            );
          });
          output = output.concat(this.formatItemList(group, commandList, helper));
        });
        return output.join("\n");
      }
      /**
       * Return display width of string, ignoring ANSI escape sequences. Used in padding and wrapping calculations.
       *
       * @param {string} str
       * @returns {number}
       */
      displayWidth(str) {
        return stripColor(str).length;
      }
      /**
       * Style the title for displaying in the help. Called with 'Usage:', 'Options:', etc.
       *
       * @param {string} str
       * @returns {string}
       */
      styleTitle(str) {
        return str;
      }
      styleUsage(str) {
        return str.split(" ").map((word) => {
          if (word === "[options]") return this.styleOptionText(word);
          if (word === "[command]") return this.styleSubcommandText(word);
          if (word[0] === "[" || word[0] === "<")
            return this.styleArgumentText(word);
          return this.styleCommandText(word);
        }).join(" ");
      }
      styleCommandDescription(str) {
        return this.styleDescriptionText(str);
      }
      styleOptionDescription(str) {
        return this.styleDescriptionText(str);
      }
      styleSubcommandDescription(str) {
        return this.styleDescriptionText(str);
      }
      styleArgumentDescription(str) {
        return this.styleDescriptionText(str);
      }
      styleDescriptionText(str) {
        return str;
      }
      styleOptionTerm(str) {
        return this.styleOptionText(str);
      }
      styleSubcommandTerm(str) {
        return str.split(" ").map((word) => {
          if (word === "[options]") return this.styleOptionText(word);
          if (word[0] === "[" || word[0] === "<")
            return this.styleArgumentText(word);
          return this.styleSubcommandText(word);
        }).join(" ");
      }
      styleArgumentTerm(str) {
        return this.styleArgumentText(str);
      }
      styleOptionText(str) {
        return str;
      }
      styleArgumentText(str) {
        return str;
      }
      styleSubcommandText(str) {
        return str;
      }
      styleCommandText(str) {
        return str;
      }
      /**
       * Calculate the pad width from the maximum term length.
       *
       * @param {Command} cmd
       * @param {Help} helper
       * @returns {number}
       */
      padWidth(cmd, helper) {
        return Math.max(
          helper.longestOptionTermLength(cmd, helper),
          helper.longestGlobalOptionTermLength(cmd, helper),
          helper.longestSubcommandTermLength(cmd, helper),
          helper.longestArgumentTermLength(cmd, helper)
        );
      }
      /**
       * Detect manually wrapped and indented strings by checking for line break followed by whitespace.
       *
       * @param {string} str
       * @returns {boolean}
       */
      preformatted(str) {
        return /\n[^\S\r\n]/.test(str);
      }
      /**
       * Format the "item", which consists of a term and description. Pad the term and wrap the description, indenting the following lines.
       *
       * So "TTT", 5, "DDD DDDD DD DDD" might be formatted for this.helpWidth=17 like so:
       *   TTT  DDD DDDD
       *        DD DDD
       *
       * @param {string} term
       * @param {number} termWidth
       * @param {string} description
       * @param {Help} helper
       * @returns {string}
       */
      formatItem(term, termWidth, description, helper) {
        const itemIndent = 2;
        const itemIndentStr = " ".repeat(itemIndent);
        if (!description) return itemIndentStr + term;
        const paddedTerm = term.padEnd(
          termWidth + term.length - helper.displayWidth(term)
        );
        const spacerWidth = 2;
        const helpWidth = this.helpWidth ?? 80;
        const remainingWidth = helpWidth - termWidth - spacerWidth - itemIndent;
        let formattedDescription;
        if (remainingWidth < this.minWidthToWrap || helper.preformatted(description)) {
          formattedDescription = description;
        } else {
          const wrappedDescription = helper.boxWrap(description, remainingWidth);
          formattedDescription = wrappedDescription.replace(
            /\n/g,
            "\n" + " ".repeat(termWidth + spacerWidth)
          );
        }
        return itemIndentStr + paddedTerm + " ".repeat(spacerWidth) + formattedDescription.replace(/\n/g, `
${itemIndentStr}`);
      }
      /**
       * Wrap a string at whitespace, preserving existing line breaks.
       * Wrapping is skipped if the width is less than `minWidthToWrap`.
       *
       * @param {string} str
       * @param {number} width
       * @returns {string}
       */
      boxWrap(str, width) {
        if (width < this.minWidthToWrap) return str;
        const rawLines = str.split(/\r\n|\n/);
        const chunkPattern = /[\s]*[^\s]+/g;
        const wrappedLines = [];
        rawLines.forEach((line) => {
          const chunks = line.match(chunkPattern);
          if (chunks === null) {
            wrappedLines.push("");
            return;
          }
          let sumChunks = [chunks.shift()];
          let sumWidth = this.displayWidth(sumChunks[0]);
          chunks.forEach((chunk) => {
            const visibleWidth = this.displayWidth(chunk);
            if (sumWidth + visibleWidth <= width) {
              sumChunks.push(chunk);
              sumWidth += visibleWidth;
              return;
            }
            wrappedLines.push(sumChunks.join(""));
            const nextChunk = chunk.trimStart();
            sumChunks = [nextChunk];
            sumWidth = this.displayWidth(nextChunk);
          });
          wrappedLines.push(sumChunks.join(""));
        });
        return wrappedLines.join("\n");
      }
    };
    function stripColor(str) {
      const sgrPattern = /\x1b\[\d*(;\d*)*m/g;
      return str.replace(sgrPattern, "");
    }
    exports2.Help = Help;
    exports2.stripColor = stripColor;
  }
});

// node_modules/commander/lib/option.js
var require_option = __commonJS({
  "node_modules/commander/lib/option.js"(exports2) {
    var { InvalidArgumentError } = require_error();
    var Option = class {
      /**
       * Initialize a new `Option` with the given `flags` and `description`.
       *
       * @param {string} flags
       * @param {string} [description]
       */
      constructor(flags, description) {
        this.flags = flags;
        this.description = description || "";
        this.required = flags.includes("<");
        this.optional = flags.includes("[");
        this.variadic = /\w\.\.\.[>\]]$/.test(flags);
        this.mandatory = false;
        const optionFlags = splitOptionFlags(flags);
        this.short = optionFlags.shortFlag;
        this.long = optionFlags.longFlag;
        this.negate = false;
        if (this.long) {
          this.negate = this.long.startsWith("--no-");
        }
        this.defaultValue = void 0;
        this.defaultValueDescription = void 0;
        this.presetArg = void 0;
        this.envVar = void 0;
        this.parseArg = void 0;
        this.hidden = false;
        this.argChoices = void 0;
        this.conflictsWith = [];
        this.implied = void 0;
        this.helpGroupHeading = void 0;
      }
      /**
       * Set the default value, and optionally supply the description to be displayed in the help.
       *
       * @param {*} value
       * @param {string} [description]
       * @return {Option}
       */
      default(value, description) {
        this.defaultValue = value;
        this.defaultValueDescription = description;
        return this;
      }
      /**
       * Preset to use when option used without option-argument, especially optional but also boolean and negated.
       * The custom processing (parseArg) is called.
       *
       * @example
       * new Option('--color').default('GREYSCALE').preset('RGB');
       * new Option('--donate [amount]').preset('20').argParser(parseFloat);
       *
       * @param {*} arg
       * @return {Option}
       */
      preset(arg) {
        this.presetArg = arg;
        return this;
      }
      /**
       * Add option name(s) that conflict with this option.
       * An error will be displayed if conflicting options are found during parsing.
       *
       * @example
       * new Option('--rgb').conflicts('cmyk');
       * new Option('--js').conflicts(['ts', 'jsx']);
       *
       * @param {(string | string[])} names
       * @return {Option}
       */
      conflicts(names) {
        this.conflictsWith = this.conflictsWith.concat(names);
        return this;
      }
      /**
       * Specify implied option values for when this option is set and the implied options are not.
       *
       * The custom processing (parseArg) is not called on the implied values.
       *
       * @example
       * program
       *   .addOption(new Option('--log', 'write logging information to file'))
       *   .addOption(new Option('--trace', 'log extra details').implies({ log: 'trace.txt' }));
       *
       * @param {object} impliedOptionValues
       * @return {Option}
       */
      implies(impliedOptionValues) {
        let newImplied = impliedOptionValues;
        if (typeof impliedOptionValues === "string") {
          newImplied = { [impliedOptionValues]: true };
        }
        this.implied = Object.assign(this.implied || {}, newImplied);
        return this;
      }
      /**
       * Set environment variable to check for option value.
       *
       * An environment variable is only used if when processed the current option value is
       * undefined, or the source of the current value is 'default' or 'config' or 'env'.
       *
       * @param {string} name
       * @return {Option}
       */
      env(name) {
        this.envVar = name;
        return this;
      }
      /**
       * Set the custom handler for processing CLI option arguments into option values.
       *
       * @param {Function} [fn]
       * @return {Option}
       */
      argParser(fn) {
        this.parseArg = fn;
        return this;
      }
      /**
       * Whether the option is mandatory and must have a value after parsing.
       *
       * @param {boolean} [mandatory=true]
       * @return {Option}
       */
      makeOptionMandatory(mandatory = true) {
        this.mandatory = !!mandatory;
        return this;
      }
      /**
       * Hide option in help.
       *
       * @param {boolean} [hide=true]
       * @return {Option}
       */
      hideHelp(hide = true) {
        this.hidden = !!hide;
        return this;
      }
      /**
       * @package
       */
      _collectValue(value, previous) {
        if (previous === this.defaultValue || !Array.isArray(previous)) {
          return [value];
        }
        previous.push(value);
        return previous;
      }
      /**
       * Only allow option value to be one of choices.
       *
       * @param {string[]} values
       * @return {Option}
       */
      choices(values) {
        this.argChoices = values.slice();
        this.parseArg = (arg, previous) => {
          if (!this.argChoices.includes(arg)) {
            throw new InvalidArgumentError(
              `Allowed choices are ${this.argChoices.join(", ")}.`
            );
          }
          if (this.variadic) {
            return this._collectValue(arg, previous);
          }
          return arg;
        };
        return this;
      }
      /**
       * Return option name.
       *
       * @return {string}
       */
      name() {
        if (this.long) {
          return this.long.replace(/^--/, "");
        }
        return this.short.replace(/^-/, "");
      }
      /**
       * Return option name, in a camelcase format that can be used
       * as an object attribute key.
       *
       * @return {string}
       */
      attributeName() {
        if (this.negate) {
          return camelcase(this.name().replace(/^no-/, ""));
        }
        return camelcase(this.name());
      }
      /**
       * Set the help group heading.
       *
       * @param {string} heading
       * @return {Option}
       */
      helpGroup(heading) {
        this.helpGroupHeading = heading;
        return this;
      }
      /**
       * Check if `arg` matches the short or long flag.
       *
       * @param {string} arg
       * @return {boolean}
       * @package
       */
      is(arg) {
        return this.short === arg || this.long === arg;
      }
      /**
       * Return whether a boolean option.
       *
       * Options are one of boolean, negated, required argument, or optional argument.
       *
       * @return {boolean}
       * @package
       */
      isBoolean() {
        return !this.required && !this.optional && !this.negate;
      }
    };
    var DualOptions = class {
      /**
       * @param {Option[]} options
       */
      constructor(options) {
        this.positiveOptions = /* @__PURE__ */ new Map();
        this.negativeOptions = /* @__PURE__ */ new Map();
        this.dualOptions = /* @__PURE__ */ new Set();
        options.forEach((option) => {
          if (option.negate) {
            this.negativeOptions.set(option.attributeName(), option);
          } else {
            this.positiveOptions.set(option.attributeName(), option);
          }
        });
        this.negativeOptions.forEach((value, key) => {
          if (this.positiveOptions.has(key)) {
            this.dualOptions.add(key);
          }
        });
      }
      /**
       * Did the value come from the option, and not from possible matching dual option?
       *
       * @param {*} value
       * @param {Option} option
       * @returns {boolean}
       */
      valueFromOption(value, option) {
        const optionKey = option.attributeName();
        if (!this.dualOptions.has(optionKey)) return true;
        const preset = this.negativeOptions.get(optionKey).presetArg;
        const negativeValue = preset !== void 0 ? preset : false;
        return option.negate === (negativeValue === value);
      }
    };
    function camelcase(str) {
      return str.split("-").reduce((str2, word) => {
        return str2 + word[0].toUpperCase() + word.slice(1);
      });
    }
    function splitOptionFlags(flags) {
      let shortFlag;
      let longFlag;
      const shortFlagExp = /^-[^-]$/;
      const longFlagExp = /^--[^-]/;
      const flagParts = flags.split(/[ |,]+/).concat("guard");
      if (shortFlagExp.test(flagParts[0])) shortFlag = flagParts.shift();
      if (longFlagExp.test(flagParts[0])) longFlag = flagParts.shift();
      if (!shortFlag && shortFlagExp.test(flagParts[0]))
        shortFlag = flagParts.shift();
      if (!shortFlag && longFlagExp.test(flagParts[0])) {
        shortFlag = longFlag;
        longFlag = flagParts.shift();
      }
      if (flagParts[0].startsWith("-")) {
        const unsupportedFlag = flagParts[0];
        const baseError = `option creation failed due to '${unsupportedFlag}' in option flags '${flags}'`;
        if (/^-[^-][^-]/.test(unsupportedFlag))
          throw new Error(
            `${baseError}
- a short flag is a single dash and a single character
  - either use a single dash and a single character (for a short flag)
  - or use a double dash for a long option (and can have two, like '--ws, --workspace')`
          );
        if (shortFlagExp.test(unsupportedFlag))
          throw new Error(`${baseError}
- too many short flags`);
        if (longFlagExp.test(unsupportedFlag))
          throw new Error(`${baseError}
- too many long flags`);
        throw new Error(`${baseError}
- unrecognised flag format`);
      }
      if (shortFlag === void 0 && longFlag === void 0)
        throw new Error(
          `option creation failed due to no flags found in '${flags}'.`
        );
      return { shortFlag, longFlag };
    }
    exports2.Option = Option;
    exports2.DualOptions = DualOptions;
  }
});

// node_modules/commander/lib/suggestSimilar.js
var require_suggestSimilar = __commonJS({
  "node_modules/commander/lib/suggestSimilar.js"(exports2) {
    var maxDistance = 3;
    function editDistance(a, b) {
      if (Math.abs(a.length - b.length) > maxDistance)
        return Math.max(a.length, b.length);
      const d = [];
      for (let i = 0; i <= a.length; i++) {
        d[i] = [i];
      }
      for (let j = 0; j <= b.length; j++) {
        d[0][j] = j;
      }
      for (let j = 1; j <= b.length; j++) {
        for (let i = 1; i <= a.length; i++) {
          let cost = 1;
          if (a[i - 1] === b[j - 1]) {
            cost = 0;
          } else {
            cost = 1;
          }
          d[i][j] = Math.min(
            d[i - 1][j] + 1,
            // deletion
            d[i][j - 1] + 1,
            // insertion
            d[i - 1][j - 1] + cost
            // substitution
          );
          if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
            d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
          }
        }
      }
      return d[a.length][b.length];
    }
    function suggestSimilar(word, candidates) {
      if (!candidates || candidates.length === 0) return "";
      candidates = Array.from(new Set(candidates));
      const searchingOptions = word.startsWith("--");
      if (searchingOptions) {
        word = word.slice(2);
        candidates = candidates.map((candidate) => candidate.slice(2));
      }
      let similar = [];
      let bestDistance = maxDistance;
      const minSimilarity = 0.4;
      candidates.forEach((candidate) => {
        if (candidate.length <= 1) return;
        const distance = editDistance(word, candidate);
        const length = Math.max(word.length, candidate.length);
        const similarity = (length - distance) / length;
        if (similarity > minSimilarity) {
          if (distance < bestDistance) {
            bestDistance = distance;
            similar = [candidate];
          } else if (distance === bestDistance) {
            similar.push(candidate);
          }
        }
      });
      similar.sort((a, b) => a.localeCompare(b));
      if (searchingOptions) {
        similar = similar.map((candidate) => `--${candidate}`);
      }
      if (similar.length > 1) {
        return `
(Did you mean one of ${similar.join(", ")}?)`;
      }
      if (similar.length === 1) {
        return `
(Did you mean ${similar[0]}?)`;
      }
      return "";
    }
    exports2.suggestSimilar = suggestSimilar;
  }
});

// node_modules/commander/lib/command.js
var require_command = __commonJS({
  "node_modules/commander/lib/command.js"(exports2) {
    var EventEmitter = require("node:events").EventEmitter;
    var childProcess = require("node:child_process");
    var path4 = require("node:path");
    var fs2 = require("node:fs");
    var process2 = require("node:process");
    var { Argument, humanReadableArgName } = require_argument();
    var { CommanderError } = require_error();
    var { Help, stripColor } = require_help();
    var { Option, DualOptions } = require_option();
    var { suggestSimilar } = require_suggestSimilar();
    var Command = class _Command extends EventEmitter {
      /**
       * Initialize a new `Command`.
       *
       * @param {string} [name]
       */
      constructor(name) {
        super();
        this.commands = [];
        this.options = [];
        this.parent = null;
        this._allowUnknownOption = false;
        this._allowExcessArguments = false;
        this.registeredArguments = [];
        this._args = this.registeredArguments;
        this.args = [];
        this.rawArgs = [];
        this.processedArgs = [];
        this._scriptPath = null;
        this._name = name || "";
        this._optionValues = {};
        this._optionValueSources = {};
        this._storeOptionsAsProperties = false;
        this._actionHandler = null;
        this._executableHandler = false;
        this._executableFile = null;
        this._executableDir = null;
        this._defaultCommandName = null;
        this._exitCallback = null;
        this._aliases = [];
        this._combineFlagAndOptionalValue = true;
        this._description = "";
        this._summary = "";
        this._argsDescription = void 0;
        this._enablePositionalOptions = false;
        this._passThroughOptions = false;
        this._lifeCycleHooks = {};
        this._showHelpAfterError = false;
        this._showSuggestionAfterError = true;
        this._savedState = null;
        this._outputConfiguration = {
          writeOut: (str) => process2.stdout.write(str),
          writeErr: (str) => process2.stderr.write(str),
          outputError: (str, write) => write(str),
          getOutHelpWidth: () => process2.stdout.isTTY ? process2.stdout.columns : void 0,
          getErrHelpWidth: () => process2.stderr.isTTY ? process2.stderr.columns : void 0,
          getOutHasColors: () => useColor() ?? (process2.stdout.isTTY && process2.stdout.hasColors?.()),
          getErrHasColors: () => useColor() ?? (process2.stderr.isTTY && process2.stderr.hasColors?.()),
          stripColor: (str) => stripColor(str)
        };
        this._hidden = false;
        this._helpOption = void 0;
        this._addImplicitHelpCommand = void 0;
        this._helpCommand = void 0;
        this._helpConfiguration = {};
        this._helpGroupHeading = void 0;
        this._defaultCommandGroup = void 0;
        this._defaultOptionGroup = void 0;
      }
      /**
       * Copy settings that are useful to have in common across root command and subcommands.
       *
       * (Used internally when adding a command using `.command()` so subcommands inherit parent settings.)
       *
       * @param {Command} sourceCommand
       * @return {Command} `this` command for chaining
       */
      copyInheritedSettings(sourceCommand) {
        this._outputConfiguration = sourceCommand._outputConfiguration;
        this._helpOption = sourceCommand._helpOption;
        this._helpCommand = sourceCommand._helpCommand;
        this._helpConfiguration = sourceCommand._helpConfiguration;
        this._exitCallback = sourceCommand._exitCallback;
        this._storeOptionsAsProperties = sourceCommand._storeOptionsAsProperties;
        this._combineFlagAndOptionalValue = sourceCommand._combineFlagAndOptionalValue;
        this._allowExcessArguments = sourceCommand._allowExcessArguments;
        this._enablePositionalOptions = sourceCommand._enablePositionalOptions;
        this._showHelpAfterError = sourceCommand._showHelpAfterError;
        this._showSuggestionAfterError = sourceCommand._showSuggestionAfterError;
        return this;
      }
      /**
       * @returns {Command[]}
       * @private
       */
      _getCommandAndAncestors() {
        const result = [];
        for (let command = this; command; command = command.parent) {
          result.push(command);
        }
        return result;
      }
      /**
       * Define a command.
       *
       * There are two styles of command: pay attention to where to put the description.
       *
       * @example
       * // Command implemented using action handler (description is supplied separately to `.command`)
       * program
       *   .command('clone <source> [destination]')
       *   .description('clone a repository into a newly created directory')
       *   .action((source, destination) => {
       *     console.log('clone command called');
       *   });
       *
       * // Command implemented using separate executable file (description is second parameter to `.command`)
       * program
       *   .command('start <service>', 'start named service')
       *   .command('stop [service]', 'stop named service, or all if no name supplied');
       *
       * @param {string} nameAndArgs - command name and arguments, args are `<required>` or `[optional]` and last may also be `variadic...`
       * @param {(object | string)} [actionOptsOrExecDesc] - configuration options (for action), or description (for executable)
       * @param {object} [execOpts] - configuration options (for executable)
       * @return {Command} returns new command for action handler, or `this` for executable command
       */
      command(nameAndArgs, actionOptsOrExecDesc, execOpts) {
        let desc = actionOptsOrExecDesc;
        let opts = execOpts;
        if (typeof desc === "object" && desc !== null) {
          opts = desc;
          desc = null;
        }
        opts = opts || {};
        const [, name, args2] = nameAndArgs.match(/([^ ]+) *(.*)/);
        const cmd = this.createCommand(name);
        if (desc) {
          cmd.description(desc);
          cmd._executableHandler = true;
        }
        if (opts.isDefault) this._defaultCommandName = cmd._name;
        cmd._hidden = !!(opts.noHelp || opts.hidden);
        cmd._executableFile = opts.executableFile || null;
        if (args2) cmd.arguments(args2);
        this._registerCommand(cmd);
        cmd.parent = this;
        cmd.copyInheritedSettings(this);
        if (desc) return this;
        return cmd;
      }
      /**
       * Factory routine to create a new unattached command.
       *
       * See .command() for creating an attached subcommand, which uses this routine to
       * create the command. You can override createCommand to customise subcommands.
       *
       * @param {string} [name]
       * @return {Command} new command
       */
      createCommand(name) {
        return new _Command(name);
      }
      /**
       * You can customise the help with a subclass of Help by overriding createHelp,
       * or by overriding Help properties using configureHelp().
       *
       * @return {Help}
       */
      createHelp() {
        return Object.assign(new Help(), this.configureHelp());
      }
      /**
       * You can customise the help by overriding Help properties using configureHelp(),
       * or with a subclass of Help by overriding createHelp().
       *
       * @param {object} [configuration] - configuration options
       * @return {(Command | object)} `this` command for chaining, or stored configuration
       */
      configureHelp(configuration) {
        if (configuration === void 0) return this._helpConfiguration;
        this._helpConfiguration = configuration;
        return this;
      }
      /**
       * The default output goes to stdout and stderr. You can customise this for special
       * applications. You can also customise the display of errors by overriding outputError.
       *
       * The configuration properties are all functions:
       *
       *     // change how output being written, defaults to stdout and stderr
       *     writeOut(str)
       *     writeErr(str)
       *     // change how output being written for errors, defaults to writeErr
       *     outputError(str, write) // used for displaying errors and not used for displaying help
       *     // specify width for wrapping help
       *     getOutHelpWidth()
       *     getErrHelpWidth()
       *     // color support, currently only used with Help
       *     getOutHasColors()
       *     getErrHasColors()
       *     stripColor() // used to remove ANSI escape codes if output does not have colors
       *
       * @param {object} [configuration] - configuration options
       * @return {(Command | object)} `this` command for chaining, or stored configuration
       */
      configureOutput(configuration) {
        if (configuration === void 0) return this._outputConfiguration;
        this._outputConfiguration = {
          ...this._outputConfiguration,
          ...configuration
        };
        return this;
      }
      /**
       * Display the help or a custom message after an error occurs.
       *
       * @param {(boolean|string)} [displayHelp]
       * @return {Command} `this` command for chaining
       */
      showHelpAfterError(displayHelp = true) {
        if (typeof displayHelp !== "string") displayHelp = !!displayHelp;
        this._showHelpAfterError = displayHelp;
        return this;
      }
      /**
       * Display suggestion of similar commands for unknown commands, or options for unknown options.
       *
       * @param {boolean} [displaySuggestion]
       * @return {Command} `this` command for chaining
       */
      showSuggestionAfterError(displaySuggestion = true) {
        this._showSuggestionAfterError = !!displaySuggestion;
        return this;
      }
      /**
       * Add a prepared subcommand.
       *
       * See .command() for creating an attached subcommand which inherits settings from its parent.
       *
       * @param {Command} cmd - new subcommand
       * @param {object} [opts] - configuration options
       * @return {Command} `this` command for chaining
       */
      addCommand(cmd, opts) {
        if (!cmd._name) {
          throw new Error(`Command passed to .addCommand() must have a name
- specify the name in Command constructor or using .name()`);
        }
        opts = opts || {};
        if (opts.isDefault) this._defaultCommandName = cmd._name;
        if (opts.noHelp || opts.hidden) cmd._hidden = true;
        this._registerCommand(cmd);
        cmd.parent = this;
        cmd._checkForBrokenPassThrough();
        return this;
      }
      /**
       * Factory routine to create a new unattached argument.
       *
       * See .argument() for creating an attached argument, which uses this routine to
       * create the argument. You can override createArgument to return a custom argument.
       *
       * @param {string} name
       * @param {string} [description]
       * @return {Argument} new argument
       */
      createArgument(name, description) {
        return new Argument(name, description);
      }
      /**
       * Define argument syntax for command.
       *
       * The default is that the argument is required, and you can explicitly
       * indicate this with <> around the name. Put [] around the name for an optional argument.
       *
       * @example
       * program.argument('<input-file>');
       * program.argument('[output-file]');
       *
       * @param {string} name
       * @param {string} [description]
       * @param {(Function|*)} [parseArg] - custom argument processing function or default value
       * @param {*} [defaultValue]
       * @return {Command} `this` command for chaining
       */
      argument(name, description, parseArg, defaultValue) {
        const argument = this.createArgument(name, description);
        if (typeof parseArg === "function") {
          argument.default(defaultValue).argParser(parseArg);
        } else {
          argument.default(parseArg);
        }
        this.addArgument(argument);
        return this;
      }
      /**
       * Define argument syntax for command, adding multiple at once (without descriptions).
       *
       * See also .argument().
       *
       * @example
       * program.arguments('<cmd> [env]');
       *
       * @param {string} names
       * @return {Command} `this` command for chaining
       */
      arguments(names) {
        names.trim().split(/ +/).forEach((detail) => {
          this.argument(detail);
        });
        return this;
      }
      /**
       * Define argument syntax for command, adding a prepared argument.
       *
       * @param {Argument} argument
       * @return {Command} `this` command for chaining
       */
      addArgument(argument) {
        const previousArgument = this.registeredArguments.slice(-1)[0];
        if (previousArgument?.variadic) {
          throw new Error(
            `only the last argument can be variadic '${previousArgument.name()}'`
          );
        }
        if (argument.required && argument.defaultValue !== void 0 && argument.parseArg === void 0) {
          throw new Error(
            `a default value for a required argument is never used: '${argument.name()}'`
          );
        }
        this.registeredArguments.push(argument);
        return this;
      }
      /**
       * Customise or override default help command. By default a help command is automatically added if your command has subcommands.
       *
       * @example
       *    program.helpCommand('help [cmd]');
       *    program.helpCommand('help [cmd]', 'show help');
       *    program.helpCommand(false); // suppress default help command
       *    program.helpCommand(true); // add help command even if no subcommands
       *
       * @param {string|boolean} enableOrNameAndArgs - enable with custom name and/or arguments, or boolean to override whether added
       * @param {string} [description] - custom description
       * @return {Command} `this` command for chaining
       */
      helpCommand(enableOrNameAndArgs, description) {
        if (typeof enableOrNameAndArgs === "boolean") {
          this._addImplicitHelpCommand = enableOrNameAndArgs;
          if (enableOrNameAndArgs && this._defaultCommandGroup) {
            this._initCommandGroup(this._getHelpCommand());
          }
          return this;
        }
        const nameAndArgs = enableOrNameAndArgs ?? "help [command]";
        const [, helpName, helpArgs] = nameAndArgs.match(/([^ ]+) *(.*)/);
        const helpDescription = description ?? "display help for command";
        const helpCommand = this.createCommand(helpName);
        helpCommand.helpOption(false);
        if (helpArgs) helpCommand.arguments(helpArgs);
        if (helpDescription) helpCommand.description(helpDescription);
        this._addImplicitHelpCommand = true;
        this._helpCommand = helpCommand;
        if (enableOrNameAndArgs || description) this._initCommandGroup(helpCommand);
        return this;
      }
      /**
       * Add prepared custom help command.
       *
       * @param {(Command|string|boolean)} helpCommand - custom help command, or deprecated enableOrNameAndArgs as for `.helpCommand()`
       * @param {string} [deprecatedDescription] - deprecated custom description used with custom name only
       * @return {Command} `this` command for chaining
       */
      addHelpCommand(helpCommand, deprecatedDescription) {
        if (typeof helpCommand !== "object") {
          this.helpCommand(helpCommand, deprecatedDescription);
          return this;
        }
        this._addImplicitHelpCommand = true;
        this._helpCommand = helpCommand;
        this._initCommandGroup(helpCommand);
        return this;
      }
      /**
       * Lazy create help command.
       *
       * @return {(Command|null)}
       * @package
       */
      _getHelpCommand() {
        const hasImplicitHelpCommand = this._addImplicitHelpCommand ?? (this.commands.length && !this._actionHandler && !this._findCommand("help"));
        if (hasImplicitHelpCommand) {
          if (this._helpCommand === void 0) {
            this.helpCommand(void 0, void 0);
          }
          return this._helpCommand;
        }
        return null;
      }
      /**
       * Add hook for life cycle event.
       *
       * @param {string} event
       * @param {Function} listener
       * @return {Command} `this` command for chaining
       */
      hook(event, listener) {
        const allowedValues = ["preSubcommand", "preAction", "postAction"];
        if (!allowedValues.includes(event)) {
          throw new Error(`Unexpected value for event passed to hook : '${event}'.
Expecting one of '${allowedValues.join("', '")}'`);
        }
        if (this._lifeCycleHooks[event]) {
          this._lifeCycleHooks[event].push(listener);
        } else {
          this._lifeCycleHooks[event] = [listener];
        }
        return this;
      }
      /**
       * Register callback to use as replacement for calling process.exit.
       *
       * @param {Function} [fn] optional callback which will be passed a CommanderError, defaults to throwing
       * @return {Command} `this` command for chaining
       */
      exitOverride(fn) {
        if (fn) {
          this._exitCallback = fn;
        } else {
          this._exitCallback = (err) => {
            if (err.code !== "commander.executeSubCommandAsync") {
              throw err;
            } else {
            }
          };
        }
        return this;
      }
      /**
       * Call process.exit, and _exitCallback if defined.
       *
       * @param {number} exitCode exit code for using with process.exit
       * @param {string} code an id string representing the error
       * @param {string} message human-readable description of the error
       * @return never
       * @private
       */
      _exit(exitCode, code, message) {
        if (this._exitCallback) {
          this._exitCallback(new CommanderError(exitCode, code, message));
        }
        process2.exit(exitCode);
      }
      /**
       * Register callback `fn` for the command.
       *
       * @example
       * program
       *   .command('serve')
       *   .description('start service')
       *   .action(function() {
       *      // do work here
       *   });
       *
       * @param {Function} fn
       * @return {Command} `this` command for chaining
       */
      action(fn) {
        const listener = (args2) => {
          const expectedArgsCount = this.registeredArguments.length;
          const actionArgs = args2.slice(0, expectedArgsCount);
          if (this._storeOptionsAsProperties) {
            actionArgs[expectedArgsCount] = this;
          } else {
            actionArgs[expectedArgsCount] = this.opts();
          }
          actionArgs.push(this);
          return fn.apply(this, actionArgs);
        };
        this._actionHandler = listener;
        return this;
      }
      /**
       * Factory routine to create a new unattached option.
       *
       * See .option() for creating an attached option, which uses this routine to
       * create the option. You can override createOption to return a custom option.
       *
       * @param {string} flags
       * @param {string} [description]
       * @return {Option} new option
       */
      createOption(flags, description) {
        return new Option(flags, description);
      }
      /**
       * Wrap parseArgs to catch 'commander.invalidArgument'.
       *
       * @param {(Option | Argument)} target
       * @param {string} value
       * @param {*} previous
       * @param {string} invalidArgumentMessage
       * @private
       */
      _callParseArg(target, value, previous, invalidArgumentMessage) {
        try {
          return target.parseArg(value, previous);
        } catch (err) {
          if (err.code === "commander.invalidArgument") {
            const message = `${invalidArgumentMessage} ${err.message}`;
            this.error(message, { exitCode: err.exitCode, code: err.code });
          }
          throw err;
        }
      }
      /**
       * Check for option flag conflicts.
       * Register option if no conflicts found, or throw on conflict.
       *
       * @param {Option} option
       * @private
       */
      _registerOption(option) {
        const matchingOption = option.short && this._findOption(option.short) || option.long && this._findOption(option.long);
        if (matchingOption) {
          const matchingFlag = option.long && this._findOption(option.long) ? option.long : option.short;
          throw new Error(`Cannot add option '${option.flags}'${this._name && ` to command '${this._name}'`} due to conflicting flag '${matchingFlag}'
-  already used by option '${matchingOption.flags}'`);
        }
        this._initOptionGroup(option);
        this.options.push(option);
      }
      /**
       * Check for command name and alias conflicts with existing commands.
       * Register command if no conflicts found, or throw on conflict.
       *
       * @param {Command} command
       * @private
       */
      _registerCommand(command) {
        const knownBy = (cmd) => {
          return [cmd.name()].concat(cmd.aliases());
        };
        const alreadyUsed = knownBy(command).find(
          (name) => this._findCommand(name)
        );
        if (alreadyUsed) {
          const existingCmd = knownBy(this._findCommand(alreadyUsed)).join("|");
          const newCmd = knownBy(command).join("|");
          throw new Error(
            `cannot add command '${newCmd}' as already have command '${existingCmd}'`
          );
        }
        this._initCommandGroup(command);
        this.commands.push(command);
      }
      /**
       * Add an option.
       *
       * @param {Option} option
       * @return {Command} `this` command for chaining
       */
      addOption(option) {
        this._registerOption(option);
        const oname = option.name();
        const name = option.attributeName();
        if (option.negate) {
          const positiveLongFlag = option.long.replace(/^--no-/, "--");
          if (!this._findOption(positiveLongFlag)) {
            this.setOptionValueWithSource(
              name,
              option.defaultValue === void 0 ? true : option.defaultValue,
              "default"
            );
          }
        } else if (option.defaultValue !== void 0) {
          this.setOptionValueWithSource(name, option.defaultValue, "default");
        }
        const handleOptionValue = (val, invalidValueMessage, valueSource) => {
          if (val == null && option.presetArg !== void 0) {
            val = option.presetArg;
          }
          const oldValue = this.getOptionValue(name);
          if (val !== null && option.parseArg) {
            val = this._callParseArg(option, val, oldValue, invalidValueMessage);
          } else if (val !== null && option.variadic) {
            val = option._collectValue(val, oldValue);
          }
          if (val == null) {
            if (option.negate) {
              val = false;
            } else if (option.isBoolean() || option.optional) {
              val = true;
            } else {
              val = "";
            }
          }
          this.setOptionValueWithSource(name, val, valueSource);
        };
        this.on("option:" + oname, (val) => {
          const invalidValueMessage = `error: option '${option.flags}' argument '${val}' is invalid.`;
          handleOptionValue(val, invalidValueMessage, "cli");
        });
        if (option.envVar) {
          this.on("optionEnv:" + oname, (val) => {
            const invalidValueMessage = `error: option '${option.flags}' value '${val}' from env '${option.envVar}' is invalid.`;
            handleOptionValue(val, invalidValueMessage, "env");
          });
        }
        return this;
      }
      /**
       * Internal implementation shared by .option() and .requiredOption()
       *
       * @return {Command} `this` command for chaining
       * @private
       */
      _optionEx(config, flags, description, fn, defaultValue) {
        if (typeof flags === "object" && flags instanceof Option) {
          throw new Error(
            "To add an Option object use addOption() instead of option() or requiredOption()"
          );
        }
        const option = this.createOption(flags, description);
        option.makeOptionMandatory(!!config.mandatory);
        if (typeof fn === "function") {
          option.default(defaultValue).argParser(fn);
        } else if (fn instanceof RegExp) {
          const regex = fn;
          fn = (val, def) => {
            const m = regex.exec(val);
            return m ? m[0] : def;
          };
          option.default(defaultValue).argParser(fn);
        } else {
          option.default(fn);
        }
        return this.addOption(option);
      }
      /**
       * Define option with `flags`, `description`, and optional argument parsing function or `defaultValue` or both.
       *
       * The `flags` string contains the short and/or long flags, separated by comma, a pipe or space. A required
       * option-argument is indicated by `<>` and an optional option-argument by `[]`.
       *
       * See the README for more details, and see also addOption() and requiredOption().
       *
       * @example
       * program
       *     .option('-p, --pepper', 'add pepper')
       *     .option('--pt, --pizza-type <TYPE>', 'type of pizza') // required option-argument
       *     .option('-c, --cheese [CHEESE]', 'add extra cheese', 'mozzarella') // optional option-argument with default
       *     .option('-t, --tip <VALUE>', 'add tip to purchase cost', parseFloat) // custom parse function
       *
       * @param {string} flags
       * @param {string} [description]
       * @param {(Function|*)} [parseArg] - custom option processing function or default value
       * @param {*} [defaultValue]
       * @return {Command} `this` command for chaining
       */
      option(flags, description, parseArg, defaultValue) {
        return this._optionEx({}, flags, description, parseArg, defaultValue);
      }
      /**
       * Add a required option which must have a value after parsing. This usually means
       * the option must be specified on the command line. (Otherwise the same as .option().)
       *
       * The `flags` string contains the short and/or long flags, separated by comma, a pipe or space.
       *
       * @param {string} flags
       * @param {string} [description]
       * @param {(Function|*)} [parseArg] - custom option processing function or default value
       * @param {*} [defaultValue]
       * @return {Command} `this` command for chaining
       */
      requiredOption(flags, description, parseArg, defaultValue) {
        return this._optionEx(
          { mandatory: true },
          flags,
          description,
          parseArg,
          defaultValue
        );
      }
      /**
       * Alter parsing of short flags with optional values.
       *
       * @example
       * // for `.option('-f,--flag [value]'):
       * program.combineFlagAndOptionalValue(true);  // `-f80` is treated like `--flag=80`, this is the default behaviour
       * program.combineFlagAndOptionalValue(false) // `-fb` is treated like `-f -b`
       *
       * @param {boolean} [combine] - if `true` or omitted, an optional value can be specified directly after the flag.
       * @return {Command} `this` command for chaining
       */
      combineFlagAndOptionalValue(combine = true) {
        this._combineFlagAndOptionalValue = !!combine;
        return this;
      }
      /**
       * Allow unknown options on the command line.
       *
       * @param {boolean} [allowUnknown] - if `true` or omitted, no error will be thrown for unknown options.
       * @return {Command} `this` command for chaining
       */
      allowUnknownOption(allowUnknown = true) {
        this._allowUnknownOption = !!allowUnknown;
        return this;
      }
      /**
       * Allow excess command-arguments on the command line. Pass false to make excess arguments an error.
       *
       * @param {boolean} [allowExcess] - if `true` or omitted, no error will be thrown for excess arguments.
       * @return {Command} `this` command for chaining
       */
      allowExcessArguments(allowExcess = true) {
        this._allowExcessArguments = !!allowExcess;
        return this;
      }
      /**
       * Enable positional options. Positional means global options are specified before subcommands which lets
       * subcommands reuse the same option names, and also enables subcommands to turn on passThroughOptions.
       * The default behaviour is non-positional and global options may appear anywhere on the command line.
       *
       * @param {boolean} [positional]
       * @return {Command} `this` command for chaining
       */
      enablePositionalOptions(positional = true) {
        this._enablePositionalOptions = !!positional;
        return this;
      }
      /**
       * Pass through options that come after command-arguments rather than treat them as command-options,
       * so actual command-options come before command-arguments. Turning this on for a subcommand requires
       * positional options to have been enabled on the program (parent commands).
       * The default behaviour is non-positional and options may appear before or after command-arguments.
       *
       * @param {boolean} [passThrough] for unknown options.
       * @return {Command} `this` command for chaining
       */
      passThroughOptions(passThrough = true) {
        this._passThroughOptions = !!passThrough;
        this._checkForBrokenPassThrough();
        return this;
      }
      /**
       * @private
       */
      _checkForBrokenPassThrough() {
        if (this.parent && this._passThroughOptions && !this.parent._enablePositionalOptions) {
          throw new Error(
            `passThroughOptions cannot be used for '${this._name}' without turning on enablePositionalOptions for parent command(s)`
          );
        }
      }
      /**
       * Whether to store option values as properties on command object,
       * or store separately (specify false). In both cases the option values can be accessed using .opts().
       *
       * @param {boolean} [storeAsProperties=true]
       * @return {Command} `this` command for chaining
       */
      storeOptionsAsProperties(storeAsProperties = true) {
        if (this.options.length) {
          throw new Error("call .storeOptionsAsProperties() before adding options");
        }
        if (Object.keys(this._optionValues).length) {
          throw new Error(
            "call .storeOptionsAsProperties() before setting option values"
          );
        }
        this._storeOptionsAsProperties = !!storeAsProperties;
        return this;
      }
      /**
       * Retrieve option value.
       *
       * @param {string} key
       * @return {object} value
       */
      getOptionValue(key) {
        if (this._storeOptionsAsProperties) {
          return this[key];
        }
        return this._optionValues[key];
      }
      /**
       * Store option value.
       *
       * @param {string} key
       * @param {object} value
       * @return {Command} `this` command for chaining
       */
      setOptionValue(key, value) {
        return this.setOptionValueWithSource(key, value, void 0);
      }
      /**
       * Store option value and where the value came from.
       *
       * @param {string} key
       * @param {object} value
       * @param {string} source - expected values are default/config/env/cli/implied
       * @return {Command} `this` command for chaining
       */
      setOptionValueWithSource(key, value, source) {
        if (this._storeOptionsAsProperties) {
          this[key] = value;
        } else {
          this._optionValues[key] = value;
        }
        this._optionValueSources[key] = source;
        return this;
      }
      /**
       * Get source of option value.
       * Expected values are default | config | env | cli | implied
       *
       * @param {string} key
       * @return {string}
       */
      getOptionValueSource(key) {
        return this._optionValueSources[key];
      }
      /**
       * Get source of option value. See also .optsWithGlobals().
       * Expected values are default | config | env | cli | implied
       *
       * @param {string} key
       * @return {string}
       */
      getOptionValueSourceWithGlobals(key) {
        let source;
        this._getCommandAndAncestors().forEach((cmd) => {
          if (cmd.getOptionValueSource(key) !== void 0) {
            source = cmd.getOptionValueSource(key);
          }
        });
        return source;
      }
      /**
       * Get user arguments from implied or explicit arguments.
       * Side-effects: set _scriptPath if args included script. Used for default program name, and subcommand searches.
       *
       * @private
       */
      _prepareUserArgs(argv, parseOptions) {
        if (argv !== void 0 && !Array.isArray(argv)) {
          throw new Error("first parameter to parse must be array or undefined");
        }
        parseOptions = parseOptions || {};
        if (argv === void 0 && parseOptions.from === void 0) {
          if (process2.versions?.electron) {
            parseOptions.from = "electron";
          }
          const execArgv = process2.execArgv ?? [];
          if (execArgv.includes("-e") || execArgv.includes("--eval") || execArgv.includes("-p") || execArgv.includes("--print")) {
            parseOptions.from = "eval";
          }
        }
        if (argv === void 0) {
          argv = process2.argv;
        }
        this.rawArgs = argv.slice();
        let userArgs;
        switch (parseOptions.from) {
          case void 0:
          case "node":
            this._scriptPath = argv[1];
            userArgs = argv.slice(2);
            break;
          case "electron":
            if (process2.defaultApp) {
              this._scriptPath = argv[1];
              userArgs = argv.slice(2);
            } else {
              userArgs = argv.slice(1);
            }
            break;
          case "user":
            userArgs = argv.slice(0);
            break;
          case "eval":
            userArgs = argv.slice(1);
            break;
          default:
            throw new Error(
              `unexpected parse option { from: '${parseOptions.from}' }`
            );
        }
        if (!this._name && this._scriptPath)
          this.nameFromFilename(this._scriptPath);
        this._name = this._name || "program";
        return userArgs;
      }
      /**
       * Parse `argv`, setting options and invoking commands when defined.
       *
       * Use parseAsync instead of parse if any of your action handlers are async.
       *
       * Call with no parameters to parse `process.argv`. Detects Electron and special node options like `node --eval`. Easy mode!
       *
       * Or call with an array of strings to parse, and optionally where the user arguments start by specifying where the arguments are `from`:
       * - `'node'`: default, `argv[0]` is the application and `argv[1]` is the script being run, with user arguments after that
       * - `'electron'`: `argv[0]` is the application and `argv[1]` varies depending on whether the electron application is packaged
       * - `'user'`: just user arguments
       *
       * @example
       * program.parse(); // parse process.argv and auto-detect electron and special node flags
       * program.parse(process.argv); // assume argv[0] is app and argv[1] is script
       * program.parse(my-args, { from: 'user' }); // just user supplied arguments, nothing special about argv[0]
       *
       * @param {string[]} [argv] - optional, defaults to process.argv
       * @param {object} [parseOptions] - optionally specify style of options with from: node/user/electron
       * @param {string} [parseOptions.from] - where the args are from: 'node', 'user', 'electron'
       * @return {Command} `this` command for chaining
       */
      parse(argv, parseOptions) {
        this._prepareForParse();
        const userArgs = this._prepareUserArgs(argv, parseOptions);
        this._parseCommand([], userArgs);
        return this;
      }
      /**
       * Parse `argv`, setting options and invoking commands when defined.
       *
       * Call with no parameters to parse `process.argv`. Detects Electron and special node options like `node --eval`. Easy mode!
       *
       * Or call with an array of strings to parse, and optionally where the user arguments start by specifying where the arguments are `from`:
       * - `'node'`: default, `argv[0]` is the application and `argv[1]` is the script being run, with user arguments after that
       * - `'electron'`: `argv[0]` is the application and `argv[1]` varies depending on whether the electron application is packaged
       * - `'user'`: just user arguments
       *
       * @example
       * await program.parseAsync(); // parse process.argv and auto-detect electron and special node flags
       * await program.parseAsync(process.argv); // assume argv[0] is app and argv[1] is script
       * await program.parseAsync(my-args, { from: 'user' }); // just user supplied arguments, nothing special about argv[0]
       *
       * @param {string[]} [argv]
       * @param {object} [parseOptions]
       * @param {string} parseOptions.from - where the args are from: 'node', 'user', 'electron'
       * @return {Promise}
       */
      async parseAsync(argv, parseOptions) {
        this._prepareForParse();
        const userArgs = this._prepareUserArgs(argv, parseOptions);
        await this._parseCommand([], userArgs);
        return this;
      }
      _prepareForParse() {
        if (this._savedState === null) {
          this.saveStateBeforeParse();
        } else {
          this.restoreStateBeforeParse();
        }
      }
      /**
       * Called the first time parse is called to save state and allow a restore before subsequent calls to parse.
       * Not usually called directly, but available for subclasses to save their custom state.
       *
       * This is called in a lazy way. Only commands used in parsing chain will have state saved.
       */
      saveStateBeforeParse() {
        this._savedState = {
          // name is stable if supplied by author, but may be unspecified for root command and deduced during parsing
          _name: this._name,
          // option values before parse have default values (including false for negated options)
          // shallow clones
          _optionValues: { ...this._optionValues },
          _optionValueSources: { ...this._optionValueSources }
        };
      }
      /**
       * Restore state before parse for calls after the first.
       * Not usually called directly, but available for subclasses to save their custom state.
       *
       * This is called in a lazy way. Only commands used in parsing chain will have state restored.
       */
      restoreStateBeforeParse() {
        if (this._storeOptionsAsProperties)
          throw new Error(`Can not call parse again when storeOptionsAsProperties is true.
- either make a new Command for each call to parse, or stop storing options as properties`);
        this._name = this._savedState._name;
        this._scriptPath = null;
        this.rawArgs = [];
        this._optionValues = { ...this._savedState._optionValues };
        this._optionValueSources = { ...this._savedState._optionValueSources };
        this.args = [];
        this.processedArgs = [];
      }
      /**
       * Throw if expected executable is missing. Add lots of help for author.
       *
       * @param {string} executableFile
       * @param {string} executableDir
       * @param {string} subcommandName
       */
      _checkForMissingExecutable(executableFile, executableDir, subcommandName) {
        if (fs2.existsSync(executableFile)) return;
        const executableDirMessage = executableDir ? `searched for local subcommand relative to directory '${executableDir}'` : "no directory for search for local subcommand, use .executableDir() to supply a custom directory";
        const executableMissing = `'${executableFile}' does not exist
 - if '${subcommandName}' is not meant to be an executable command, remove description parameter from '.command()' and use '.description()' instead
 - if the default executable name is not suitable, use the executableFile option to supply a custom name or path
 - ${executableDirMessage}`;
        throw new Error(executableMissing);
      }
      /**
       * Execute a sub-command executable.
       *
       * @private
       */
      _executeSubCommand(subcommand, args2) {
        args2 = args2.slice();
        let launchWithNode = false;
        const sourceExt = [".js", ".ts", ".tsx", ".mjs", ".cjs"];
        function findFile(baseDir, baseName) {
          const localBin = path4.resolve(baseDir, baseName);
          if (fs2.existsSync(localBin)) return localBin;
          if (sourceExt.includes(path4.extname(baseName))) return void 0;
          const foundExt = sourceExt.find(
            (ext) => fs2.existsSync(`${localBin}${ext}`)
          );
          if (foundExt) return `${localBin}${foundExt}`;
          return void 0;
        }
        this._checkForMissingMandatoryOptions();
        this._checkForConflictingOptions();
        let executableFile = subcommand._executableFile || `${this._name}-${subcommand._name}`;
        let executableDir = this._executableDir || "";
        if (this._scriptPath) {
          let resolvedScriptPath;
          try {
            resolvedScriptPath = fs2.realpathSync(this._scriptPath);
          } catch {
            resolvedScriptPath = this._scriptPath;
          }
          executableDir = path4.resolve(
            path4.dirname(resolvedScriptPath),
            executableDir
          );
        }
        if (executableDir) {
          let localFile = findFile(executableDir, executableFile);
          if (!localFile && !subcommand._executableFile && this._scriptPath) {
            const legacyName = path4.basename(
              this._scriptPath,
              path4.extname(this._scriptPath)
            );
            if (legacyName !== this._name) {
              localFile = findFile(
                executableDir,
                `${legacyName}-${subcommand._name}`
              );
            }
          }
          executableFile = localFile || executableFile;
        }
        launchWithNode = sourceExt.includes(path4.extname(executableFile));
        let proc;
        if (process2.platform !== "win32") {
          if (launchWithNode) {
            args2.unshift(executableFile);
            args2 = incrementNodeInspectorPort(process2.execArgv).concat(args2);
            proc = childProcess.spawn(process2.argv[0], args2, { stdio: "inherit" });
          } else {
            proc = childProcess.spawn(executableFile, args2, { stdio: "inherit" });
          }
        } else {
          this._checkForMissingExecutable(
            executableFile,
            executableDir,
            subcommand._name
          );
          args2.unshift(executableFile);
          args2 = incrementNodeInspectorPort(process2.execArgv).concat(args2);
          proc = childProcess.spawn(process2.execPath, args2, { stdio: "inherit" });
        }
        if (!proc.killed) {
          const signals = ["SIGUSR1", "SIGUSR2", "SIGTERM", "SIGINT", "SIGHUP"];
          signals.forEach((signal) => {
            process2.on(signal, () => {
              if (proc.killed === false && proc.exitCode === null) {
                proc.kill(signal);
              }
            });
          });
        }
        const exitCallback = this._exitCallback;
        proc.on("close", (code) => {
          code = code ?? 1;
          if (!exitCallback) {
            process2.exit(code);
          } else {
            exitCallback(
              new CommanderError(
                code,
                "commander.executeSubCommandAsync",
                "(close)"
              )
            );
          }
        });
        proc.on("error", (err) => {
          if (err.code === "ENOENT") {
            this._checkForMissingExecutable(
              executableFile,
              executableDir,
              subcommand._name
            );
          } else if (err.code === "EACCES") {
            throw new Error(`'${executableFile}' not executable`);
          }
          if (!exitCallback) {
            process2.exit(1);
          } else {
            const wrappedError = new CommanderError(
              1,
              "commander.executeSubCommandAsync",
              "(error)"
            );
            wrappedError.nestedError = err;
            exitCallback(wrappedError);
          }
        });
        this.runningCommand = proc;
      }
      /**
       * @private
       */
      _dispatchSubcommand(commandName, operands, unknown) {
        const subCommand = this._findCommand(commandName);
        if (!subCommand) this.help({ error: true });
        subCommand._prepareForParse();
        let promiseChain;
        promiseChain = this._chainOrCallSubCommandHook(
          promiseChain,
          subCommand,
          "preSubcommand"
        );
        promiseChain = this._chainOrCall(promiseChain, () => {
          if (subCommand._executableHandler) {
            this._executeSubCommand(subCommand, operands.concat(unknown));
          } else {
            return subCommand._parseCommand(operands, unknown);
          }
        });
        return promiseChain;
      }
      /**
       * Invoke help directly if possible, or dispatch if necessary.
       * e.g. help foo
       *
       * @private
       */
      _dispatchHelpCommand(subcommandName) {
        if (!subcommandName) {
          this.help();
        }
        const subCommand = this._findCommand(subcommandName);
        if (subCommand && !subCommand._executableHandler) {
          subCommand.help();
        }
        return this._dispatchSubcommand(
          subcommandName,
          [],
          [this._getHelpOption()?.long ?? this._getHelpOption()?.short ?? "--help"]
        );
      }
      /**
       * Check this.args against expected this.registeredArguments.
       *
       * @private
       */
      _checkNumberOfArguments() {
        this.registeredArguments.forEach((arg, i) => {
          if (arg.required && this.args[i] == null) {
            this.missingArgument(arg.name());
          }
        });
        if (this.registeredArguments.length > 0 && this.registeredArguments[this.registeredArguments.length - 1].variadic) {
          return;
        }
        if (this.args.length > this.registeredArguments.length) {
          this._excessArguments(this.args);
        }
      }
      /**
       * Process this.args using this.registeredArguments and save as this.processedArgs!
       *
       * @private
       */
      _processArguments() {
        const myParseArg = (argument, value, previous) => {
          let parsedValue = value;
          if (value !== null && argument.parseArg) {
            const invalidValueMessage = `error: command-argument value '${value}' is invalid for argument '${argument.name()}'.`;
            parsedValue = this._callParseArg(
              argument,
              value,
              previous,
              invalidValueMessage
            );
          }
          return parsedValue;
        };
        this._checkNumberOfArguments();
        const processedArgs = [];
        this.registeredArguments.forEach((declaredArg, index) => {
          let value = declaredArg.defaultValue;
          if (declaredArg.variadic) {
            if (index < this.args.length) {
              value = this.args.slice(index);
              if (declaredArg.parseArg) {
                value = value.reduce((processed, v) => {
                  return myParseArg(declaredArg, v, processed);
                }, declaredArg.defaultValue);
              }
            } else if (value === void 0) {
              value = [];
            }
          } else if (index < this.args.length) {
            value = this.args[index];
            if (declaredArg.parseArg) {
              value = myParseArg(declaredArg, value, declaredArg.defaultValue);
            }
          }
          processedArgs[index] = value;
        });
        this.processedArgs = processedArgs;
      }
      /**
       * Once we have a promise we chain, but call synchronously until then.
       *
       * @param {(Promise|undefined)} promise
       * @param {Function} fn
       * @return {(Promise|undefined)}
       * @private
       */
      _chainOrCall(promise, fn) {
        if (promise?.then && typeof promise.then === "function") {
          return promise.then(() => fn());
        }
        return fn();
      }
      /**
       *
       * @param {(Promise|undefined)} promise
       * @param {string} event
       * @return {(Promise|undefined)}
       * @private
       */
      _chainOrCallHooks(promise, event) {
        let result = promise;
        const hooks = [];
        this._getCommandAndAncestors().reverse().filter((cmd) => cmd._lifeCycleHooks[event] !== void 0).forEach((hookedCommand) => {
          hookedCommand._lifeCycleHooks[event].forEach((callback) => {
            hooks.push({ hookedCommand, callback });
          });
        });
        if (event === "postAction") {
          hooks.reverse();
        }
        hooks.forEach((hookDetail) => {
          result = this._chainOrCall(result, () => {
            return hookDetail.callback(hookDetail.hookedCommand, this);
          });
        });
        return result;
      }
      /**
       *
       * @param {(Promise|undefined)} promise
       * @param {Command} subCommand
       * @param {string} event
       * @return {(Promise|undefined)}
       * @private
       */
      _chainOrCallSubCommandHook(promise, subCommand, event) {
        let result = promise;
        if (this._lifeCycleHooks[event] !== void 0) {
          this._lifeCycleHooks[event].forEach((hook) => {
            result = this._chainOrCall(result, () => {
              return hook(this, subCommand);
            });
          });
        }
        return result;
      }
      /**
       * Process arguments in context of this command.
       * Returns action result, in case it is a promise.
       *
       * @private
       */
      _parseCommand(operands, unknown) {
        const parsed = this.parseOptions(unknown);
        this._parseOptionsEnv();
        this._parseOptionsImplied();
        operands = operands.concat(parsed.operands);
        unknown = parsed.unknown;
        this.args = operands.concat(unknown);
        if (operands && this._findCommand(operands[0])) {
          return this._dispatchSubcommand(operands[0], operands.slice(1), unknown);
        }
        if (this._getHelpCommand() && operands[0] === this._getHelpCommand().name()) {
          return this._dispatchHelpCommand(operands[1]);
        }
        if (this._defaultCommandName) {
          this._outputHelpIfRequested(unknown);
          return this._dispatchSubcommand(
            this._defaultCommandName,
            operands,
            unknown
          );
        }
        if (this.commands.length && this.args.length === 0 && !this._actionHandler && !this._defaultCommandName) {
          this.help({ error: true });
        }
        this._outputHelpIfRequested(parsed.unknown);
        this._checkForMissingMandatoryOptions();
        this._checkForConflictingOptions();
        const checkForUnknownOptions = () => {
          if (parsed.unknown.length > 0) {
            this.unknownOption(parsed.unknown[0]);
          }
        };
        const commandEvent = `command:${this.name()}`;
        if (this._actionHandler) {
          checkForUnknownOptions();
          this._processArguments();
          let promiseChain;
          promiseChain = this._chainOrCallHooks(promiseChain, "preAction");
          promiseChain = this._chainOrCall(
            promiseChain,
            () => this._actionHandler(this.processedArgs)
          );
          if (this.parent) {
            promiseChain = this._chainOrCall(promiseChain, () => {
              this.parent.emit(commandEvent, operands, unknown);
            });
          }
          promiseChain = this._chainOrCallHooks(promiseChain, "postAction");
          return promiseChain;
        }
        if (this.parent?.listenerCount(commandEvent)) {
          checkForUnknownOptions();
          this._processArguments();
          this.parent.emit(commandEvent, operands, unknown);
        } else if (operands.length) {
          if (this._findCommand("*")) {
            return this._dispatchSubcommand("*", operands, unknown);
          }
          if (this.listenerCount("command:*")) {
            this.emit("command:*", operands, unknown);
          } else if (this.commands.length) {
            this.unknownCommand();
          } else {
            checkForUnknownOptions();
            this._processArguments();
          }
        } else if (this.commands.length) {
          checkForUnknownOptions();
          this.help({ error: true });
        } else {
          checkForUnknownOptions();
          this._processArguments();
        }
      }
      /**
       * Find matching command.
       *
       * @private
       * @return {Command | undefined}
       */
      _findCommand(name) {
        if (!name) return void 0;
        return this.commands.find(
          (cmd) => cmd._name === name || cmd._aliases.includes(name)
        );
      }
      /**
       * Return an option matching `arg` if any.
       *
       * @param {string} arg
       * @return {Option}
       * @package
       */
      _findOption(arg) {
        return this.options.find((option) => option.is(arg));
      }
      /**
       * Display an error message if a mandatory option does not have a value.
       * Called after checking for help flags in leaf subcommand.
       *
       * @private
       */
      _checkForMissingMandatoryOptions() {
        this._getCommandAndAncestors().forEach((cmd) => {
          cmd.options.forEach((anOption) => {
            if (anOption.mandatory && cmd.getOptionValue(anOption.attributeName()) === void 0) {
              cmd.missingMandatoryOptionValue(anOption);
            }
          });
        });
      }
      /**
       * Display an error message if conflicting options are used together in this.
       *
       * @private
       */
      _checkForConflictingLocalOptions() {
        const definedNonDefaultOptions = this.options.filter((option) => {
          const optionKey = option.attributeName();
          if (this.getOptionValue(optionKey) === void 0) {
            return false;
          }
          return this.getOptionValueSource(optionKey) !== "default";
        });
        const optionsWithConflicting = definedNonDefaultOptions.filter(
          (option) => option.conflictsWith.length > 0
        );
        optionsWithConflicting.forEach((option) => {
          const conflictingAndDefined = definedNonDefaultOptions.find(
            (defined) => option.conflictsWith.includes(defined.attributeName())
          );
          if (conflictingAndDefined) {
            this._conflictingOption(option, conflictingAndDefined);
          }
        });
      }
      /**
       * Display an error message if conflicting options are used together.
       * Called after checking for help flags in leaf subcommand.
       *
       * @private
       */
      _checkForConflictingOptions() {
        this._getCommandAndAncestors().forEach((cmd) => {
          cmd._checkForConflictingLocalOptions();
        });
      }
      /**
       * Parse options from `argv` removing known options,
       * and return argv split into operands and unknown arguments.
       *
       * Side effects: modifies command by storing options. Does not reset state if called again.
       *
       * Examples:
       *
       *     argv => operands, unknown
       *     --known kkk op => [op], []
       *     op --known kkk => [op], []
       *     sub --unknown uuu op => [sub], [--unknown uuu op]
       *     sub -- --unknown uuu op => [sub --unknown uuu op], []
       *
       * @param {string[]} args
       * @return {{operands: string[], unknown: string[]}}
       */
      parseOptions(args2) {
        const operands = [];
        const unknown = [];
        let dest = operands;
        function maybeOption(arg) {
          return arg.length > 1 && arg[0] === "-";
        }
        const negativeNumberArg = (arg) => {
          if (!/^-(\d+|\d*\.\d+)(e[+-]?\d+)?$/.test(arg)) return false;
          return !this._getCommandAndAncestors().some(
            (cmd) => cmd.options.map((opt) => opt.short).some((short) => /^-\d$/.test(short))
          );
        };
        let activeVariadicOption = null;
        let activeGroup = null;
        let i = 0;
        while (i < args2.length || activeGroup) {
          const arg = activeGroup ?? args2[i++];
          activeGroup = null;
          if (arg === "--") {
            if (dest === unknown) dest.push(arg);
            dest.push(...args2.slice(i));
            break;
          }
          if (activeVariadicOption && (!maybeOption(arg) || negativeNumberArg(arg))) {
            this.emit(`option:${activeVariadicOption.name()}`, arg);
            continue;
          }
          activeVariadicOption = null;
          if (maybeOption(arg)) {
            const option = this._findOption(arg);
            if (option) {
              if (option.required) {
                const value = args2[i++];
                if (value === void 0) this.optionMissingArgument(option);
                this.emit(`option:${option.name()}`, value);
              } else if (option.optional) {
                let value = null;
                if (i < args2.length && (!maybeOption(args2[i]) || negativeNumberArg(args2[i]))) {
                  value = args2[i++];
                }
                this.emit(`option:${option.name()}`, value);
              } else {
                this.emit(`option:${option.name()}`);
              }
              activeVariadicOption = option.variadic ? option : null;
              continue;
            }
          }
          if (arg.length > 2 && arg[0] === "-" && arg[1] !== "-") {
            const option = this._findOption(`-${arg[1]}`);
            if (option) {
              if (option.required || option.optional && this._combineFlagAndOptionalValue) {
                this.emit(`option:${option.name()}`, arg.slice(2));
              } else {
                this.emit(`option:${option.name()}`);
                activeGroup = `-${arg.slice(2)}`;
              }
              continue;
            }
          }
          if (/^--[^=]+=/.test(arg)) {
            const index = arg.indexOf("=");
            const option = this._findOption(arg.slice(0, index));
            if (option && (option.required || option.optional)) {
              this.emit(`option:${option.name()}`, arg.slice(index + 1));
              continue;
            }
          }
          if (dest === operands && maybeOption(arg) && !(this.commands.length === 0 && negativeNumberArg(arg))) {
            dest = unknown;
          }
          if ((this._enablePositionalOptions || this._passThroughOptions) && operands.length === 0 && unknown.length === 0) {
            if (this._findCommand(arg)) {
              operands.push(arg);
              unknown.push(...args2.slice(i));
              break;
            } else if (this._getHelpCommand() && arg === this._getHelpCommand().name()) {
              operands.push(arg, ...args2.slice(i));
              break;
            } else if (this._defaultCommandName) {
              unknown.push(arg, ...args2.slice(i));
              break;
            }
          }
          if (this._passThroughOptions) {
            dest.push(arg, ...args2.slice(i));
            break;
          }
          dest.push(arg);
        }
        return { operands, unknown };
      }
      /**
       * Return an object containing local option values as key-value pairs.
       *
       * @return {object}
       */
      opts() {
        if (this._storeOptionsAsProperties) {
          const result = {};
          const len = this.options.length;
          for (let i = 0; i < len; i++) {
            const key = this.options[i].attributeName();
            result[key] = key === this._versionOptionName ? this._version : this[key];
          }
          return result;
        }
        return this._optionValues;
      }
      /**
       * Return an object containing merged local and global option values as key-value pairs.
       *
       * @return {object}
       */
      optsWithGlobals() {
        return this._getCommandAndAncestors().reduce(
          (combinedOptions, cmd) => Object.assign(combinedOptions, cmd.opts()),
          {}
        );
      }
      /**
       * Display error message and exit (or call exitOverride).
       *
       * @param {string} message
       * @param {object} [errorOptions]
       * @param {string} [errorOptions.code] - an id string representing the error
       * @param {number} [errorOptions.exitCode] - used with process.exit
       */
      error(message, errorOptions) {
        this._outputConfiguration.outputError(
          `${message}
`,
          this._outputConfiguration.writeErr
        );
        if (typeof this._showHelpAfterError === "string") {
          this._outputConfiguration.writeErr(`${this._showHelpAfterError}
`);
        } else if (this._showHelpAfterError) {
          this._outputConfiguration.writeErr("\n");
          this.outputHelp({ error: true });
        }
        const config = errorOptions || {};
        const exitCode = config.exitCode || 1;
        const code = config.code || "commander.error";
        this._exit(exitCode, code, message);
      }
      /**
       * Apply any option related environment variables, if option does
       * not have a value from cli or client code.
       *
       * @private
       */
      _parseOptionsEnv() {
        this.options.forEach((option) => {
          if (option.envVar && option.envVar in process2.env) {
            const optionKey = option.attributeName();
            if (this.getOptionValue(optionKey) === void 0 || ["default", "config", "env"].includes(
              this.getOptionValueSource(optionKey)
            )) {
              if (option.required || option.optional) {
                this.emit(`optionEnv:${option.name()}`, process2.env[option.envVar]);
              } else {
                this.emit(`optionEnv:${option.name()}`);
              }
            }
          }
        });
      }
      /**
       * Apply any implied option values, if option is undefined or default value.
       *
       * @private
       */
      _parseOptionsImplied() {
        const dualHelper = new DualOptions(this.options);
        const hasCustomOptionValue = (optionKey) => {
          return this.getOptionValue(optionKey) !== void 0 && !["default", "implied"].includes(this.getOptionValueSource(optionKey));
        };
        this.options.filter(
          (option) => option.implied !== void 0 && hasCustomOptionValue(option.attributeName()) && dualHelper.valueFromOption(
            this.getOptionValue(option.attributeName()),
            option
          )
        ).forEach((option) => {
          Object.keys(option.implied).filter((impliedKey) => !hasCustomOptionValue(impliedKey)).forEach((impliedKey) => {
            this.setOptionValueWithSource(
              impliedKey,
              option.implied[impliedKey],
              "implied"
            );
          });
        });
      }
      /**
       * Argument `name` is missing.
       *
       * @param {string} name
       * @private
       */
      missingArgument(name) {
        const message = `error: missing required argument '${name}'`;
        this.error(message, { code: "commander.missingArgument" });
      }
      /**
       * `Option` is missing an argument.
       *
       * @param {Option} option
       * @private
       */
      optionMissingArgument(option) {
        const message = `error: option '${option.flags}' argument missing`;
        this.error(message, { code: "commander.optionMissingArgument" });
      }
      /**
       * `Option` does not have a value, and is a mandatory option.
       *
       * @param {Option} option
       * @private
       */
      missingMandatoryOptionValue(option) {
        const message = `error: required option '${option.flags}' not specified`;
        this.error(message, { code: "commander.missingMandatoryOptionValue" });
      }
      /**
       * `Option` conflicts with another option.
       *
       * @param {Option} option
       * @param {Option} conflictingOption
       * @private
       */
      _conflictingOption(option, conflictingOption) {
        const findBestOptionFromValue = (option2) => {
          const optionKey = option2.attributeName();
          const optionValue = this.getOptionValue(optionKey);
          const negativeOption = this.options.find(
            (target) => target.negate && optionKey === target.attributeName()
          );
          const positiveOption = this.options.find(
            (target) => !target.negate && optionKey === target.attributeName()
          );
          if (negativeOption && (negativeOption.presetArg === void 0 && optionValue === false || negativeOption.presetArg !== void 0 && optionValue === negativeOption.presetArg)) {
            return negativeOption;
          }
          return positiveOption || option2;
        };
        const getErrorMessage = (option2) => {
          const bestOption = findBestOptionFromValue(option2);
          const optionKey = bestOption.attributeName();
          const source = this.getOptionValueSource(optionKey);
          if (source === "env") {
            return `environment variable '${bestOption.envVar}'`;
          }
          return `option '${bestOption.flags}'`;
        };
        const message = `error: ${getErrorMessage(option)} cannot be used with ${getErrorMessage(conflictingOption)}`;
        this.error(message, { code: "commander.conflictingOption" });
      }
      /**
       * Unknown option `flag`.
       *
       * @param {string} flag
       * @private
       */
      unknownOption(flag) {
        if (this._allowUnknownOption) return;
        let suggestion = "";
        if (flag.startsWith("--") && this._showSuggestionAfterError) {
          let candidateFlags = [];
          let command = this;
          do {
            const moreFlags = command.createHelp().visibleOptions(command).filter((option) => option.long).map((option) => option.long);
            candidateFlags = candidateFlags.concat(moreFlags);
            command = command.parent;
          } while (command && !command._enablePositionalOptions);
          suggestion = suggestSimilar(flag, candidateFlags);
        }
        const message = `error: unknown option '${flag}'${suggestion}`;
        this.error(message, { code: "commander.unknownOption" });
      }
      /**
       * Excess arguments, more than expected.
       *
       * @param {string[]} receivedArgs
       * @private
       */
      _excessArguments(receivedArgs) {
        if (this._allowExcessArguments) return;
        const expected = this.registeredArguments.length;
        const s = expected === 1 ? "" : "s";
        const forSubcommand = this.parent ? ` for '${this.name()}'` : "";
        const message = `error: too many arguments${forSubcommand}. Expected ${expected} argument${s} but got ${receivedArgs.length}.`;
        this.error(message, { code: "commander.excessArguments" });
      }
      /**
       * Unknown command.
       *
       * @private
       */
      unknownCommand() {
        const unknownName = this.args[0];
        let suggestion = "";
        if (this._showSuggestionAfterError) {
          const candidateNames = [];
          this.createHelp().visibleCommands(this).forEach((command) => {
            candidateNames.push(command.name());
            if (command.alias()) candidateNames.push(command.alias());
          });
          suggestion = suggestSimilar(unknownName, candidateNames);
        }
        const message = `error: unknown command '${unknownName}'${suggestion}`;
        this.error(message, { code: "commander.unknownCommand" });
      }
      /**
       * Get or set the program version.
       *
       * This method auto-registers the "-V, --version" option which will print the version number.
       *
       * You can optionally supply the flags and description to override the defaults.
       *
       * @param {string} [str]
       * @param {string} [flags]
       * @param {string} [description]
       * @return {(this | string | undefined)} `this` command for chaining, or version string if no arguments
       */
      version(str, flags, description) {
        if (str === void 0) return this._version;
        this._version = str;
        flags = flags || "-V, --version";
        description = description || "output the version number";
        const versionOption = this.createOption(flags, description);
        this._versionOptionName = versionOption.attributeName();
        this._registerOption(versionOption);
        this.on("option:" + versionOption.name(), () => {
          this._outputConfiguration.writeOut(`${str}
`);
          this._exit(0, "commander.version", str);
        });
        return this;
      }
      /**
       * Set the description.
       *
       * @param {string} [str]
       * @param {object} [argsDescription]
       * @return {(string|Command)}
       */
      description(str, argsDescription) {
        if (str === void 0 && argsDescription === void 0)
          return this._description;
        this._description = str;
        if (argsDescription) {
          this._argsDescription = argsDescription;
        }
        return this;
      }
      /**
       * Set the summary. Used when listed as subcommand of parent.
       *
       * @param {string} [str]
       * @return {(string|Command)}
       */
      summary(str) {
        if (str === void 0) return this._summary;
        this._summary = str;
        return this;
      }
      /**
       * Set an alias for the command.
       *
       * You may call more than once to add multiple aliases. Only the first alias is shown in the auto-generated help.
       *
       * @param {string} [alias]
       * @return {(string|Command)}
       */
      alias(alias) {
        if (alias === void 0) return this._aliases[0];
        let command = this;
        if (this.commands.length !== 0 && this.commands[this.commands.length - 1]._executableHandler) {
          command = this.commands[this.commands.length - 1];
        }
        if (alias === command._name)
          throw new Error("Command alias can't be the same as its name");
        const matchingCommand = this.parent?._findCommand(alias);
        if (matchingCommand) {
          const existingCmd = [matchingCommand.name()].concat(matchingCommand.aliases()).join("|");
          throw new Error(
            `cannot add alias '${alias}' to command '${this.name()}' as already have command '${existingCmd}'`
          );
        }
        command._aliases.push(alias);
        return this;
      }
      /**
       * Set aliases for the command.
       *
       * Only the first alias is shown in the auto-generated help.
       *
       * @param {string[]} [aliases]
       * @return {(string[]|Command)}
       */
      aliases(aliases) {
        if (aliases === void 0) return this._aliases;
        aliases.forEach((alias) => this.alias(alias));
        return this;
      }
      /**
       * Set / get the command usage `str`.
       *
       * @param {string} [str]
       * @return {(string|Command)}
       */
      usage(str) {
        if (str === void 0) {
          if (this._usage) return this._usage;
          const args2 = this.registeredArguments.map((arg) => {
            return humanReadableArgName(arg);
          });
          return [].concat(
            this.options.length || this._helpOption !== null ? "[options]" : [],
            this.commands.length ? "[command]" : [],
            this.registeredArguments.length ? args2 : []
          ).join(" ");
        }
        this._usage = str;
        return this;
      }
      /**
       * Get or set the name of the command.
       *
       * @param {string} [str]
       * @return {(string|Command)}
       */
      name(str) {
        if (str === void 0) return this._name;
        this._name = str;
        return this;
      }
      /**
       * Set/get the help group heading for this subcommand in parent command's help.
       *
       * @param {string} [heading]
       * @return {Command | string}
       */
      helpGroup(heading) {
        if (heading === void 0) return this._helpGroupHeading ?? "";
        this._helpGroupHeading = heading;
        return this;
      }
      /**
       * Set/get the default help group heading for subcommands added to this command.
       * (This does not override a group set directly on the subcommand using .helpGroup().)
       *
       * @example
       * program.commandsGroup('Development Commands:);
       * program.command('watch')...
       * program.command('lint')...
       * ...
       *
       * @param {string} [heading]
       * @returns {Command | string}
       */
      commandsGroup(heading) {
        if (heading === void 0) return this._defaultCommandGroup ?? "";
        this._defaultCommandGroup = heading;
        return this;
      }
      /**
       * Set/get the default help group heading for options added to this command.
       * (This does not override a group set directly on the option using .helpGroup().)
       *
       * @example
       * program
       *   .optionsGroup('Development Options:')
       *   .option('-d, --debug', 'output extra debugging')
       *   .option('-p, --profile', 'output profiling information')
       *
       * @param {string} [heading]
       * @returns {Command | string}
       */
      optionsGroup(heading) {
        if (heading === void 0) return this._defaultOptionGroup ?? "";
        this._defaultOptionGroup = heading;
        return this;
      }
      /**
       * @param {Option} option
       * @private
       */
      _initOptionGroup(option) {
        if (this._defaultOptionGroup && !option.helpGroupHeading)
          option.helpGroup(this._defaultOptionGroup);
      }
      /**
       * @param {Command} cmd
       * @private
       */
      _initCommandGroup(cmd) {
        if (this._defaultCommandGroup && !cmd.helpGroup())
          cmd.helpGroup(this._defaultCommandGroup);
      }
      /**
       * Set the name of the command from script filename, such as process.argv[1],
       * or require.main.filename, or __filename.
       *
       * (Used internally and public although not documented in README.)
       *
       * @example
       * program.nameFromFilename(require.main.filename);
       *
       * @param {string} filename
       * @return {Command}
       */
      nameFromFilename(filename) {
        this._name = path4.basename(filename, path4.extname(filename));
        return this;
      }
      /**
       * Get or set the directory for searching for executable subcommands of this command.
       *
       * @example
       * program.executableDir(__dirname);
       * // or
       * program.executableDir('subcommands');
       *
       * @param {string} [path]
       * @return {(string|null|Command)}
       */
      executableDir(path5) {
        if (path5 === void 0) return this._executableDir;
        this._executableDir = path5;
        return this;
      }
      /**
       * Return program help documentation.
       *
       * @param {{ error: boolean }} [contextOptions] - pass {error:true} to wrap for stderr instead of stdout
       * @return {string}
       */
      helpInformation(contextOptions) {
        const helper = this.createHelp();
        const context = this._getOutputContext(contextOptions);
        helper.prepareContext({
          error: context.error,
          helpWidth: context.helpWidth,
          outputHasColors: context.hasColors
        });
        const text = helper.formatHelp(this, helper);
        if (context.hasColors) return text;
        return this._outputConfiguration.stripColor(text);
      }
      /**
       * @typedef HelpContext
       * @type {object}
       * @property {boolean} error
       * @property {number} helpWidth
       * @property {boolean} hasColors
       * @property {function} write - includes stripColor if needed
       *
       * @returns {HelpContext}
       * @private
       */
      _getOutputContext(contextOptions) {
        contextOptions = contextOptions || {};
        const error = !!contextOptions.error;
        let baseWrite;
        let hasColors;
        let helpWidth;
        if (error) {
          baseWrite = (str) => this._outputConfiguration.writeErr(str);
          hasColors = this._outputConfiguration.getErrHasColors();
          helpWidth = this._outputConfiguration.getErrHelpWidth();
        } else {
          baseWrite = (str) => this._outputConfiguration.writeOut(str);
          hasColors = this._outputConfiguration.getOutHasColors();
          helpWidth = this._outputConfiguration.getOutHelpWidth();
        }
        const write = (str) => {
          if (!hasColors) str = this._outputConfiguration.stripColor(str);
          return baseWrite(str);
        };
        return { error, write, hasColors, helpWidth };
      }
      /**
       * Output help information for this command.
       *
       * Outputs built-in help, and custom text added using `.addHelpText()`.
       *
       * @param {{ error: boolean } | Function} [contextOptions] - pass {error:true} to write to stderr instead of stdout
       */
      outputHelp(contextOptions) {
        let deprecatedCallback;
        if (typeof contextOptions === "function") {
          deprecatedCallback = contextOptions;
          contextOptions = void 0;
        }
        const outputContext = this._getOutputContext(contextOptions);
        const eventContext = {
          error: outputContext.error,
          write: outputContext.write,
          command: this
        };
        this._getCommandAndAncestors().reverse().forEach((command) => command.emit("beforeAllHelp", eventContext));
        this.emit("beforeHelp", eventContext);
        let helpInformation = this.helpInformation({ error: outputContext.error });
        if (deprecatedCallback) {
          helpInformation = deprecatedCallback(helpInformation);
          if (typeof helpInformation !== "string" && !Buffer.isBuffer(helpInformation)) {
            throw new Error("outputHelp callback must return a string or a Buffer");
          }
        }
        outputContext.write(helpInformation);
        if (this._getHelpOption()?.long) {
          this.emit(this._getHelpOption().long);
        }
        this.emit("afterHelp", eventContext);
        this._getCommandAndAncestors().forEach(
          (command) => command.emit("afterAllHelp", eventContext)
        );
      }
      /**
       * You can pass in flags and a description to customise the built-in help option.
       * Pass in false to disable the built-in help option.
       *
       * @example
       * program.helpOption('-?, --help' 'show help'); // customise
       * program.helpOption(false); // disable
       *
       * @param {(string | boolean)} flags
       * @param {string} [description]
       * @return {Command} `this` command for chaining
       */
      helpOption(flags, description) {
        if (typeof flags === "boolean") {
          if (flags) {
            if (this._helpOption === null) this._helpOption = void 0;
            if (this._defaultOptionGroup) {
              this._initOptionGroup(this._getHelpOption());
            }
          } else {
            this._helpOption = null;
          }
          return this;
        }
        this._helpOption = this.createOption(
          flags ?? "-h, --help",
          description ?? "display help for command"
        );
        if (flags || description) this._initOptionGroup(this._helpOption);
        return this;
      }
      /**
       * Lazy create help option.
       * Returns null if has been disabled with .helpOption(false).
       *
       * @returns {(Option | null)} the help option
       * @package
       */
      _getHelpOption() {
        if (this._helpOption === void 0) {
          this.helpOption(void 0, void 0);
        }
        return this._helpOption;
      }
      /**
       * Supply your own option to use for the built-in help option.
       * This is an alternative to using helpOption() to customise the flags and description etc.
       *
       * @param {Option} option
       * @return {Command} `this` command for chaining
       */
      addHelpOption(option) {
        this._helpOption = option;
        this._initOptionGroup(option);
        return this;
      }
      /**
       * Output help information and exit.
       *
       * Outputs built-in help, and custom text added using `.addHelpText()`.
       *
       * @param {{ error: boolean }} [contextOptions] - pass {error:true} to write to stderr instead of stdout
       */
      help(contextOptions) {
        this.outputHelp(contextOptions);
        let exitCode = Number(process2.exitCode ?? 0);
        if (exitCode === 0 && contextOptions && typeof contextOptions !== "function" && contextOptions.error) {
          exitCode = 1;
        }
        this._exit(exitCode, "commander.help", "(outputHelp)");
      }
      /**
       * // Do a little typing to coordinate emit and listener for the help text events.
       * @typedef HelpTextEventContext
       * @type {object}
       * @property {boolean} error
       * @property {Command} command
       * @property {function} write
       */
      /**
       * Add additional text to be displayed with the built-in help.
       *
       * Position is 'before' or 'after' to affect just this command,
       * and 'beforeAll' or 'afterAll' to affect this command and all its subcommands.
       *
       * @param {string} position - before or after built-in help
       * @param {(string | Function)} text - string to add, or a function returning a string
       * @return {Command} `this` command for chaining
       */
      addHelpText(position, text) {
        const allowedValues = ["beforeAll", "before", "after", "afterAll"];
        if (!allowedValues.includes(position)) {
          throw new Error(`Unexpected value for position to addHelpText.
Expecting one of '${allowedValues.join("', '")}'`);
        }
        const helpEvent = `${position}Help`;
        this.on(helpEvent, (context) => {
          let helpStr;
          if (typeof text === "function") {
            helpStr = text({ error: context.error, command: context.command });
          } else {
            helpStr = text;
          }
          if (helpStr) {
            context.write(`${helpStr}
`);
          }
        });
        return this;
      }
      /**
       * Output help information if help flags specified
       *
       * @param {Array} args - array of options to search for help flags
       * @private
       */
      _outputHelpIfRequested(args2) {
        const helpOption = this._getHelpOption();
        const helpRequested = helpOption && args2.find((arg) => helpOption.is(arg));
        if (helpRequested) {
          this.outputHelp();
          this._exit(0, "commander.helpDisplayed", "(outputHelp)");
        }
      }
    };
    function incrementNodeInspectorPort(args2) {
      return args2.map((arg) => {
        if (!arg.startsWith("--inspect")) {
          return arg;
        }
        let debugOption;
        let debugHost = "127.0.0.1";
        let debugPort = "9229";
        let match;
        if ((match = arg.match(/^(--inspect(-brk)?)$/)) !== null) {
          debugOption = match[1];
        } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+)$/)) !== null) {
          debugOption = match[1];
          if (/^\d+$/.test(match[3])) {
            debugPort = match[3];
          } else {
            debugHost = match[3];
          }
        } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+):(\d+)$/)) !== null) {
          debugOption = match[1];
          debugHost = match[3];
          debugPort = match[4];
        }
        if (debugOption && debugPort !== "0") {
          return `${debugOption}=${debugHost}:${parseInt(debugPort) + 1}`;
        }
        return arg;
      });
    }
    function useColor() {
      if (process2.env.NO_COLOR || process2.env.FORCE_COLOR === "0" || process2.env.FORCE_COLOR === "false")
        return false;
      if (process2.env.FORCE_COLOR || process2.env.CLICOLOR_FORCE !== void 0)
        return true;
      return void 0;
    }
    exports2.Command = Command;
    exports2.useColor = useColor;
  }
});

// node_modules/commander/index.js
var require_commander = __commonJS({
  "node_modules/commander/index.js"(exports2) {
    var { Argument } = require_argument();
    var { Command } = require_command();
    var { CommanderError, InvalidArgumentError } = require_error();
    var { Help } = require_help();
    var { Option } = require_option();
    exports2.program = new Command();
    exports2.createCommand = (name) => new Command(name);
    exports2.createOption = (flags, description) => new Option(flags, description);
    exports2.createArgument = (name, description) => new Argument(name, description);
    exports2.Command = Command;
    exports2.Option = Option;
    exports2.Argument = Argument;
    exports2.Help = Help;
    exports2.CommanderError = CommanderError;
    exports2.InvalidArgumentError = InvalidArgumentError;
    exports2.InvalidOptionArgumentError = InvalidArgumentError;
  }
});

// node/playwright-wrapper/index.ts
var import_grpc_js3 = require("@grpc/grpc-js");

// node/playwright-wrapper/browser_logger.ts
var import_pino = require("pino");
var _seq = 0;
var currentRFContext = {};
var _kwContextStack = [];
function setRFKeywordContext(ctx) {
  _kwContextStack.push({
    kw_name: currentRFContext.kw_name,
    kw_file: currentRFContext.kw_file,
    kw_line: currentRFContext.kw_line
  });
  if (ctx.kw_name !== void 0) {
    currentRFContext.kw_name = ctx.kw_name;
  } else {
    delete currentRFContext.kw_name;
  }
  if (ctx.kw_file !== void 0) {
    currentRFContext.kw_file = ctx.kw_file;
  } else {
    delete currentRFContext.kw_file;
  }
  if (ctx.kw_line !== void 0) {
    currentRFContext.kw_line = ctx.kw_line;
  } else {
    delete currentRFContext.kw_line;
  }
}
function clearRFKeywordContext() {
  const prev = _kwContextStack.pop();
  if (prev) {
    if (prev.kw_name !== void 0) {
      currentRFContext.kw_name = prev.kw_name;
    } else {
      delete currentRFContext.kw_name;
    }
    if (prev.kw_file !== void 0) {
      currentRFContext.kw_file = prev.kw_file;
    } else {
      delete currentRFContext.kw_file;
    }
    if (prev.kw_line !== void 0) {
      currentRFContext.kw_line = prev.kw_line;
    } else {
      delete currentRFContext.kw_line;
    }
  } else {
    delete currentRFContext.kw_name;
    delete currentRFContext.kw_file;
    delete currentRFContext.kw_line;
  }
}
function setRFTestContext(testId, testName) {
  if (testId) {
    currentRFContext.test_id = testId;
  } else {
    delete currentRFContext.test_id;
  }
  if (testName) {
    currentRFContext.test_name = testName;
  } else {
    delete currentRFContext.test_name;
  }
}
function setRFSuiteContext(suiteId, suiteName) {
  if (suiteId) {
    currentRFContext.suite_id = suiteId;
  } else {
    delete currentRFContext.suite_id;
  }
  if (suiteName) {
    currentRFContext.suite_name = suiteName;
  } else {
    delete currentRFContext.suite_name;
  }
}
function errorType(e) {
  return e instanceof Error ? e.constructor.name : "UnknownError";
}
function createLogger(destination) {
  return (0, import_pino.pino)(
    {
      timestamp: import_pino.stdTimeFunctions.isoTime,
      level: process.env.ROBOT_FRAMEWORK_BROWSER_PINO_LOG_LEVEL || "info",
      base: null,
      formatters: {
        level(label) {
          return { level: label };
        }
      },
      mixin() {
        const { kw_name, kw_file, kw_line, test_id, test_name, suite_id, suite_name } = currentRFContext;
        return {
          seq: ++_seq,
          ...suite_id !== void 0 && { suite_id },
          ...suite_name !== void 0 && { suite_name },
          ...test_name !== void 0 && { test_name },
          ...kw_name !== void 0 && { kw_name },
          ...kw_file !== void 0 && { kw_file },
          ...kw_line !== void 0 && { kw_line },
          ...test_id !== void 0 && { test_id },
          component: "browser-library"
        };
      }
    },
    destination ?? process.stdout
  );
}
var logger = createLogger();

// node/playwright-wrapper/generated/playwright.ts
var import_wire = require("@bufbuild/protobuf/wire");
var import_grpc_js = require("@grpc/grpc-js");
function createBaseRequest_Empty() {
  return {};
}
var Request_Empty = {
  encode(_, writer = new import_wire.BinaryWriter()) {
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Empty();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(_) {
    return {};
  },
  toJSON(_) {
    const obj = {};
    return obj;
  },
  create(base) {
    return Request_Empty.fromPartial(base ?? {});
  },
  fromPartial(_) {
    const message = createBaseRequest_Empty();
    return message;
  }
};
function createBaseRequest_AriaSnapShot() {
  return { locator: "", strict: false };
}
var Request_AriaSnapShot = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.locator !== "") {
      writer.uint32(10).string(message.locator);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_AriaSnapShot();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.locator = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      locator: isSet(object.locator) ? globalThis.String(object.locator) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.locator !== "") {
      obj.locator = message.locator;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_AriaSnapShot.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_AriaSnapShot();
    message.locator = object.locator ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_ClosePage() {
  return { runBeforeUnload: false };
}
var Request_ClosePage = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.runBeforeUnload !== false) {
      writer.uint32(8).bool(message.runBeforeUnload);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClosePage();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.runBeforeUnload = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { runBeforeUnload: isSet(object.runBeforeUnload) ? globalThis.Boolean(object.runBeforeUnload) : false };
  },
  toJSON(message) {
    const obj = {};
    if (message.runBeforeUnload !== false) {
      obj.runBeforeUnload = message.runBeforeUnload;
    }
    return obj;
  },
  create(base) {
    return Request_ClosePage.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClosePage();
    message.runBeforeUnload = object.runBeforeUnload ?? false;
    return message;
  }
};
function createBaseRequest_ClockSetTime() {
  return { time: 0, setType: "" };
}
var Request_ClockSetTime = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.time !== 0) {
      writer.uint32(8).int32(message.time);
    }
    if (message.setType !== "") {
      writer.uint32(18).string(message.setType);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClockSetTime();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.time = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.setType = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      time: isSet(object.time) ? globalThis.Number(object.time) : 0,
      setType: isSet(object.setType) ? globalThis.String(object.setType) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.time !== 0) {
      obj.time = Math.round(message.time);
    }
    if (message.setType !== "") {
      obj.setType = message.setType;
    }
    return obj;
  },
  create(base) {
    return Request_ClockSetTime.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClockSetTime();
    message.time = object.time ?? 0;
    message.setType = object.setType ?? "";
    return message;
  }
};
function createBaseRequest_ClockAdvance() {
  return { time: 0, advanceType: "" };
}
var Request_ClockAdvance = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.time !== 0) {
      writer.uint32(8).int32(message.time);
    }
    if (message.advanceType !== "") {
      writer.uint32(18).string(message.advanceType);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClockAdvance();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.time = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.advanceType = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      time: isSet(object.time) ? globalThis.Number(object.time) : 0,
      advanceType: isSet(object.advanceType) ? globalThis.String(object.advanceType) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.time !== 0) {
      obj.time = Math.round(message.time);
    }
    if (message.advanceType !== "") {
      obj.advanceType = message.advanceType;
    }
    return obj;
  },
  create(base) {
    return Request_ClockAdvance.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClockAdvance();
    message.time = object.time ?? 0;
    message.advanceType = object.advanceType ?? "";
    return message;
  }
};
function createBaseRequest_CoverageStart() {
  return {
    coverageType: "",
    resetOnNavigation: false,
    reportAnonymousScripts: false,
    configFile: "",
    coverageDir: "",
    raw: false
  };
}
var Request_CoverageStart = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.coverageType !== "") {
      writer.uint32(10).string(message.coverageType);
    }
    if (message.resetOnNavigation !== false) {
      writer.uint32(16).bool(message.resetOnNavigation);
    }
    if (message.reportAnonymousScripts !== false) {
      writer.uint32(24).bool(message.reportAnonymousScripts);
    }
    if (message.configFile !== "") {
      writer.uint32(34).string(message.configFile);
    }
    if (message.coverageDir !== "") {
      writer.uint32(42).string(message.coverageDir);
    }
    if (message.raw !== false) {
      writer.uint32(48).bool(message.raw);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_CoverageStart();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.coverageType = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.resetOnNavigation = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.reportAnonymousScripts = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.configFile = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.coverageDir = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 48) {
            break;
          }
          message.raw = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      coverageType: isSet(object.coverageType) ? globalThis.String(object.coverageType) : "",
      resetOnNavigation: isSet(object.resetOnNavigation) ? globalThis.Boolean(object.resetOnNavigation) : false,
      reportAnonymousScripts: isSet(object.reportAnonymousScripts) ? globalThis.Boolean(object.reportAnonymousScripts) : false,
      configFile: isSet(object.configFile) ? globalThis.String(object.configFile) : "",
      coverageDir: isSet(object.coverageDir) ? globalThis.String(object.coverageDir) : "",
      raw: isSet(object.raw) ? globalThis.Boolean(object.raw) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.coverageType !== "") {
      obj.coverageType = message.coverageType;
    }
    if (message.resetOnNavigation !== false) {
      obj.resetOnNavigation = message.resetOnNavigation;
    }
    if (message.reportAnonymousScripts !== false) {
      obj.reportAnonymousScripts = message.reportAnonymousScripts;
    }
    if (message.configFile !== "") {
      obj.configFile = message.configFile;
    }
    if (message.coverageDir !== "") {
      obj.coverageDir = message.coverageDir;
    }
    if (message.raw !== false) {
      obj.raw = message.raw;
    }
    return obj;
  },
  create(base) {
    return Request_CoverageStart.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_CoverageStart();
    message.coverageType = object.coverageType ?? "";
    message.resetOnNavigation = object.resetOnNavigation ?? false;
    message.reportAnonymousScripts = object.reportAnonymousScripts ?? false;
    message.configFile = object.configFile ?? "";
    message.coverageDir = object.coverageDir ?? "";
    message.raw = object.raw ?? false;
    return message;
  }
};
function createBaseRequest_CoverageMerge() {
  return { inputFolder: "", outputFolder: "", config: "", name: "", reports: [] };
}
var Request_CoverageMerge = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.inputFolder !== "") {
      writer.uint32(10).string(message.inputFolder);
    }
    if (message.outputFolder !== "") {
      writer.uint32(18).string(message.outputFolder);
    }
    if (message.config !== "") {
      writer.uint32(26).string(message.config);
    }
    if (message.name !== "") {
      writer.uint32(34).string(message.name);
    }
    for (const v of message.reports) {
      writer.uint32(42).string(v);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_CoverageMerge();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.inputFolder = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.outputFolder = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.config = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.reports.push(reader.string());
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      inputFolder: isSet(object.inputFolder) ? globalThis.String(object.inputFolder) : isSet(object.input_folder) ? globalThis.String(object.input_folder) : "",
      outputFolder: isSet(object.outputFolder) ? globalThis.String(object.outputFolder) : isSet(object.output_folder) ? globalThis.String(object.output_folder) : "",
      config: isSet(object.config) ? globalThis.String(object.config) : "",
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      reports: globalThis.Array.isArray(object?.reports) ? object.reports.map((e) => globalThis.String(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.inputFolder !== "") {
      obj.inputFolder = message.inputFolder;
    }
    if (message.outputFolder !== "") {
      obj.outputFolder = message.outputFolder;
    }
    if (message.config !== "") {
      obj.config = message.config;
    }
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.reports?.length) {
      obj.reports = message.reports;
    }
    return obj;
  },
  create(base) {
    return Request_CoverageMerge.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_CoverageMerge();
    message.inputFolder = object.inputFolder ?? "";
    message.outputFolder = object.outputFolder ?? "";
    message.config = object.config ?? "";
    message.name = object.name ?? "";
    message.reports = object.reports?.map((e) => e) || [];
    return message;
  }
};
function createBaseRequest_TraceGroup() {
  return { name: "", file: "", line: 0, column: 0, contextId: "" };
}
var Request_TraceGroup = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.name !== "") {
      writer.uint32(10).string(message.name);
    }
    if (message.file !== "") {
      writer.uint32(18).string(message.file);
    }
    if (message.line !== 0) {
      writer.uint32(24).int32(message.line);
    }
    if (message.column !== 0) {
      writer.uint32(32).int32(message.column);
    }
    if (message.contextId !== "") {
      writer.uint32(42).string(message.contextId);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_TraceGroup();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.file = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.line = reader.int32();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.column = reader.int32();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.contextId = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      file: isSet(object.file) ? globalThis.String(object.file) : "",
      line: isSet(object.line) ? globalThis.Number(object.line) : 0,
      column: isSet(object.column) ? globalThis.Number(object.column) : 0,
      contextId: isSet(object.contextId) ? globalThis.String(object.contextId) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.file !== "") {
      obj.file = message.file;
    }
    if (message.line !== 0) {
      obj.line = Math.round(message.line);
    }
    if (message.column !== 0) {
      obj.column = Math.round(message.column);
    }
    if (message.contextId !== "") {
      obj.contextId = message.contextId;
    }
    return obj;
  },
  create(base) {
    return Request_TraceGroup.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_TraceGroup();
    message.name = object.name ?? "";
    message.file = object.file ?? "";
    message.line = object.line ?? 0;
    message.column = object.column ?? 0;
    message.contextId = object.contextId ?? "";
    return message;
  }
};
function createBaseRequest_RFContext() {
  return { testId: "", testName: "", suiteId: "", suiteName: "" };
}
var Request_RFContext = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.testId !== "") {
      writer.uint32(10).string(message.testId);
    }
    if (message.testName !== "") {
      writer.uint32(18).string(message.testName);
    }
    if (message.suiteId !== "") {
      writer.uint32(26).string(message.suiteId);
    }
    if (message.suiteName !== "") {
      writer.uint32(34).string(message.suiteName);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_RFContext();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.testId = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.testName = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.suiteId = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.suiteName = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      testId: isSet(object.testId) ? globalThis.String(object.testId) : isSet(object.test_id) ? globalThis.String(object.test_id) : "",
      testName: isSet(object.testName) ? globalThis.String(object.testName) : isSet(object.test_name) ? globalThis.String(object.test_name) : "",
      suiteId: isSet(object.suiteId) ? globalThis.String(object.suiteId) : isSet(object.suite_id) ? globalThis.String(object.suite_id) : "",
      suiteName: isSet(object.suiteName) ? globalThis.String(object.suiteName) : isSet(object.suite_name) ? globalThis.String(object.suite_name) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.testId !== "") {
      obj.testId = message.testId;
    }
    if (message.testName !== "") {
      obj.testName = message.testName;
    }
    if (message.suiteId !== "") {
      obj.suiteId = message.suiteId;
    }
    if (message.suiteName !== "") {
      obj.suiteName = message.suiteName;
    }
    return obj;
  },
  create(base) {
    return Request_RFContext.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_RFContext();
    message.testId = object.testId ?? "";
    message.testName = object.testName ?? "";
    message.suiteId = object.suiteId ?? "";
    message.suiteName = object.suiteName ?? "";
    return message;
  }
};
function createBaseRequest_Label() {
  return { label: "" };
}
var Request_Label = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.label !== "") {
      writer.uint32(10).string(message.label);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Label();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.label = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { label: isSet(object.label) ? globalThis.String(object.label) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.label !== "") {
      obj.label = message.label;
    }
    return obj;
  },
  create(base) {
    return Request_Label.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Label();
    message.label = object.label ?? "";
    return message;
  }
};
function createBaseRequest_GetByOptions() {
  return { strategy: "", text: "", options: "", strict: false, all: false, frameSelector: "" };
}
var Request_GetByOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.strategy !== "") {
      writer.uint32(10).string(message.strategy);
    }
    if (message.text !== "") {
      writer.uint32(18).string(message.text);
    }
    if (message.options !== "") {
      writer.uint32(26).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    if (message.all !== false) {
      writer.uint32(40).bool(message.all);
    }
    if (message.frameSelector !== "") {
      writer.uint32(50).string(message.frameSelector);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_GetByOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.strategy = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.text = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.all = reader.bool();
          continue;
        }
        case 6: {
          if (tag !== 50) {
            break;
          }
          message.frameSelector = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      strategy: isSet(object.strategy) ? globalThis.String(object.strategy) : "",
      text: isSet(object.text) ? globalThis.String(object.text) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      all: isSet(object.all) ? globalThis.Boolean(object.all) : false,
      frameSelector: isSet(object.frameSelector) ? globalThis.String(object.frameSelector) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.strategy !== "") {
      obj.strategy = message.strategy;
    }
    if (message.text !== "") {
      obj.text = message.text;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.all !== false) {
      obj.all = message.all;
    }
    if (message.frameSelector !== "") {
      obj.frameSelector = message.frameSelector;
    }
    return obj;
  },
  create(base) {
    return Request_GetByOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_GetByOptions();
    message.strategy = object.strategy ?? "";
    message.text = object.text ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    message.all = object.all ?? false;
    message.frameSelector = object.frameSelector ?? "";
    return message;
  }
};
function createBaseRequest_Pdf() {
  return {
    displayHeaderFooter: false,
    footerTemplate: "",
    format: "",
    headerTemplate: "",
    height: "",
    landscape: false,
    margin: "",
    outline: false,
    pageRanges: "",
    path: "",
    preferCSSPageSize: false,
    printBackground: false,
    scale: 0,
    tagged: false,
    width: ""
  };
}
var Request_Pdf = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.displayHeaderFooter !== false) {
      writer.uint32(8).bool(message.displayHeaderFooter);
    }
    if (message.footerTemplate !== "") {
      writer.uint32(18).string(message.footerTemplate);
    }
    if (message.format !== "") {
      writer.uint32(26).string(message.format);
    }
    if (message.headerTemplate !== "") {
      writer.uint32(34).string(message.headerTemplate);
    }
    if (message.height !== "") {
      writer.uint32(42).string(message.height);
    }
    if (message.landscape !== false) {
      writer.uint32(48).bool(message.landscape);
    }
    if (message.margin !== "") {
      writer.uint32(58).string(message.margin);
    }
    if (message.outline !== false) {
      writer.uint32(64).bool(message.outline);
    }
    if (message.pageRanges !== "") {
      writer.uint32(74).string(message.pageRanges);
    }
    if (message.path !== "") {
      writer.uint32(82).string(message.path);
    }
    if (message.preferCSSPageSize !== false) {
      writer.uint32(88).bool(message.preferCSSPageSize);
    }
    if (message.printBackground !== false) {
      writer.uint32(96).bool(message.printBackground);
    }
    if (message.scale !== 0) {
      writer.uint32(109).float(message.scale);
    }
    if (message.tagged !== false) {
      writer.uint32(112).bool(message.tagged);
    }
    if (message.width !== "") {
      writer.uint32(122).string(message.width);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Pdf();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.displayHeaderFooter = reader.bool();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.footerTemplate = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.format = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.headerTemplate = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.height = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 48) {
            break;
          }
          message.landscape = reader.bool();
          continue;
        }
        case 7: {
          if (tag !== 58) {
            break;
          }
          message.margin = reader.string();
          continue;
        }
        case 8: {
          if (tag !== 64) {
            break;
          }
          message.outline = reader.bool();
          continue;
        }
        case 9: {
          if (tag !== 74) {
            break;
          }
          message.pageRanges = reader.string();
          continue;
        }
        case 10: {
          if (tag !== 82) {
            break;
          }
          message.path = reader.string();
          continue;
        }
        case 11: {
          if (tag !== 88) {
            break;
          }
          message.preferCSSPageSize = reader.bool();
          continue;
        }
        case 12: {
          if (tag !== 96) {
            break;
          }
          message.printBackground = reader.bool();
          continue;
        }
        case 13: {
          if (tag !== 109) {
            break;
          }
          message.scale = reader.float();
          continue;
        }
        case 14: {
          if (tag !== 112) {
            break;
          }
          message.tagged = reader.bool();
          continue;
        }
        case 15: {
          if (tag !== 122) {
            break;
          }
          message.width = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      displayHeaderFooter: isSet(object.displayHeaderFooter) ? globalThis.Boolean(object.displayHeaderFooter) : false,
      footerTemplate: isSet(object.footerTemplate) ? globalThis.String(object.footerTemplate) : "",
      format: isSet(object.format) ? globalThis.String(object.format) : "",
      headerTemplate: isSet(object.headerTemplate) ? globalThis.String(object.headerTemplate) : "",
      height: isSet(object.height) ? globalThis.String(object.height) : "",
      landscape: isSet(object.landscape) ? globalThis.Boolean(object.landscape) : false,
      margin: isSet(object.margin) ? globalThis.String(object.margin) : "",
      outline: isSet(object.outline) ? globalThis.Boolean(object.outline) : false,
      pageRanges: isSet(object.pageRanges) ? globalThis.String(object.pageRanges) : "",
      path: isSet(object.path) ? globalThis.String(object.path) : "",
      preferCSSPageSize: isSet(object.preferCSSPageSize) ? globalThis.Boolean(object.preferCSSPageSize) : false,
      printBackground: isSet(object.printBackground) ? globalThis.Boolean(object.printBackground) : false,
      scale: isSet(object.scale) ? globalThis.Number(object.scale) : 0,
      tagged: isSet(object.tagged) ? globalThis.Boolean(object.tagged) : false,
      width: isSet(object.width) ? globalThis.String(object.width) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.displayHeaderFooter !== false) {
      obj.displayHeaderFooter = message.displayHeaderFooter;
    }
    if (message.footerTemplate !== "") {
      obj.footerTemplate = message.footerTemplate;
    }
    if (message.format !== "") {
      obj.format = message.format;
    }
    if (message.headerTemplate !== "") {
      obj.headerTemplate = message.headerTemplate;
    }
    if (message.height !== "") {
      obj.height = message.height;
    }
    if (message.landscape !== false) {
      obj.landscape = message.landscape;
    }
    if (message.margin !== "") {
      obj.margin = message.margin;
    }
    if (message.outline !== false) {
      obj.outline = message.outline;
    }
    if (message.pageRanges !== "") {
      obj.pageRanges = message.pageRanges;
    }
    if (message.path !== "") {
      obj.path = message.path;
    }
    if (message.preferCSSPageSize !== false) {
      obj.preferCSSPageSize = message.preferCSSPageSize;
    }
    if (message.printBackground !== false) {
      obj.printBackground = message.printBackground;
    }
    if (message.scale !== 0) {
      obj.scale = message.scale;
    }
    if (message.tagged !== false) {
      obj.tagged = message.tagged;
    }
    if (message.width !== "") {
      obj.width = message.width;
    }
    return obj;
  },
  create(base) {
    return Request_Pdf.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Pdf();
    message.displayHeaderFooter = object.displayHeaderFooter ?? false;
    message.footerTemplate = object.footerTemplate ?? "";
    message.format = object.format ?? "";
    message.headerTemplate = object.headerTemplate ?? "";
    message.height = object.height ?? "";
    message.landscape = object.landscape ?? false;
    message.margin = object.margin ?? "";
    message.outline = object.outline ?? false;
    message.pageRanges = object.pageRanges ?? "";
    message.path = object.path ?? "";
    message.preferCSSPageSize = object.preferCSSPageSize ?? false;
    message.printBackground = object.printBackground ?? false;
    message.scale = object.scale ?? 0;
    message.tagged = object.tagged ?? false;
    message.width = object.width ?? "";
    return message;
  }
};
function createBaseRequest_EmulateMedia() {
  return { colorScheme: "", forcedColors: "", media: "", reducedMotion: "" };
}
var Request_EmulateMedia = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.colorScheme !== "") {
      writer.uint32(10).string(message.colorScheme);
    }
    if (message.forcedColors !== "") {
      writer.uint32(18).string(message.forcedColors);
    }
    if (message.media !== "") {
      writer.uint32(26).string(message.media);
    }
    if (message.reducedMotion !== "") {
      writer.uint32(34).string(message.reducedMotion);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_EmulateMedia();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.colorScheme = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.forcedColors = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.media = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.reducedMotion = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      colorScheme: isSet(object.colorScheme) ? globalThis.String(object.colorScheme) : "",
      forcedColors: isSet(object.forcedColors) ? globalThis.String(object.forcedColors) : "",
      media: isSet(object.media) ? globalThis.String(object.media) : "",
      reducedMotion: isSet(object.reducedMotion) ? globalThis.String(object.reducedMotion) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.colorScheme !== "") {
      obj.colorScheme = message.colorScheme;
    }
    if (message.forcedColors !== "") {
      obj.forcedColors = message.forcedColors;
    }
    if (message.media !== "") {
      obj.media = message.media;
    }
    if (message.reducedMotion !== "") {
      obj.reducedMotion = message.reducedMotion;
    }
    return obj;
  },
  create(base) {
    return Request_EmulateMedia.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_EmulateMedia();
    message.colorScheme = object.colorScheme ?? "";
    message.forcedColors = object.forcedColors ?? "";
    message.media = object.media ?? "";
    message.reducedMotion = object.reducedMotion ?? "";
    return message;
  }
};
function createBaseRequest_ScreenshotOptions() {
  return { selector: "", mask: "", options: "", strict: false };
}
var Request_ScreenshotOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.mask !== "") {
      writer.uint32(18).string(message.mask);
    }
    if (message.options !== "") {
      writer.uint32(26).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ScreenshotOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.mask = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      mask: isSet(object.mask) ? globalThis.String(object.mask) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.mask !== "") {
      obj.mask = message.mask;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ScreenshotOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ScreenshotOptions();
    message.selector = object.selector ?? "";
    message.mask = object.mask ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_KeywordCall() {
  return { name: "", arguments: "" };
}
var Request_KeywordCall = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.name !== "") {
      writer.uint32(10).string(message.name);
    }
    if (message.arguments !== "") {
      writer.uint32(18).string(message.arguments);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_KeywordCall();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.arguments = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      arguments: isSet(object.arguments) ? globalThis.String(object.arguments) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.arguments !== "") {
      obj.arguments = message.arguments;
    }
    return obj;
  },
  create(base) {
    return Request_KeywordCall.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_KeywordCall();
    message.name = object.name ?? "";
    message.arguments = object.arguments ?? "";
    return message;
  }
};
function createBaseRequest_FilePath() {
  return { path: "" };
}
var Request_FilePath = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.path !== "") {
      writer.uint32(10).string(message.path);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_FilePath();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.path = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { path: isSet(object.path) ? globalThis.String(object.path) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.path !== "") {
      obj.path = message.path;
    }
    return obj;
  },
  create(base) {
    return Request_FilePath.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_FilePath();
    message.path = object.path ?? "";
    return message;
  }
};
function createBaseRequest_FileBySelector() {
  return { path: [], selector: "", strict: false, name: "", mimeType: "", buffer: "" };
}
var Request_FileBySelector = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.path) {
      writer.uint32(10).string(v);
    }
    if (message.selector !== "") {
      writer.uint32(18).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    if (message.name !== "") {
      writer.uint32(34).string(message.name);
    }
    if (message.mimeType !== "") {
      writer.uint32(42).string(message.mimeType);
    }
    if (message.buffer !== "") {
      writer.uint32(50).string(message.buffer);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_FileBySelector();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.path.push(reader.string());
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.mimeType = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 50) {
            break;
          }
          message.buffer = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      path: globalThis.Array.isArray(object?.path) ? object.path.map((e) => globalThis.String(e)) : [],
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      mimeType: isSet(object.mimeType) ? globalThis.String(object.mimeType) : "",
      buffer: isSet(object.buffer) ? globalThis.String(object.buffer) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.path?.length) {
      obj.path = message.path;
    }
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.mimeType !== "") {
      obj.mimeType = message.mimeType;
    }
    if (message.buffer !== "") {
      obj.buffer = message.buffer;
    }
    return obj;
  },
  create(base) {
    return Request_FileBySelector.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_FileBySelector();
    message.path = object.path?.map((e) => e) || [];
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    message.name = object.name ?? "";
    message.mimeType = object.mimeType ?? "";
    message.buffer = object.buffer ?? "";
    return message;
  }
};
function createBaseRequest_LocatorHandlerAddCustom() {
  return { selector: "", noWaitAfter: false, times: "", handlerSpecs: [] };
}
var Request_LocatorHandlerAddCustom = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.noWaitAfter !== false) {
      writer.uint32(16).bool(message.noWaitAfter);
    }
    if (message.times !== "") {
      writer.uint32(26).string(message.times);
    }
    for (const v of message.handlerSpecs) {
      Request_LocatorHandlerAddCustomAction.encode(v, writer.uint32(34).fork()).join();
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_LocatorHandlerAddCustom();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.noWaitAfter = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.times = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.handlerSpecs.push(Request_LocatorHandlerAddCustomAction.decode(reader, reader.uint32()));
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      noWaitAfter: isSet(object.noWaitAfter) ? globalThis.Boolean(object.noWaitAfter) : false,
      times: isSet(object.times) ? globalThis.String(object.times) : "",
      handlerSpecs: globalThis.Array.isArray(object?.handlerSpecs) ? object.handlerSpecs.map((e) => Request_LocatorHandlerAddCustomAction.fromJSON(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.noWaitAfter !== false) {
      obj.noWaitAfter = message.noWaitAfter;
    }
    if (message.times !== "") {
      obj.times = message.times;
    }
    if (message.handlerSpecs?.length) {
      obj.handlerSpecs = message.handlerSpecs.map((e) => Request_LocatorHandlerAddCustomAction.toJSON(e));
    }
    return obj;
  },
  create(base) {
    return Request_LocatorHandlerAddCustom.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_LocatorHandlerAddCustom();
    message.selector = object.selector ?? "";
    message.noWaitAfter = object.noWaitAfter ?? false;
    message.times = object.times ?? "";
    message.handlerSpecs = object.handlerSpecs?.map((e) => Request_LocatorHandlerAddCustomAction.fromPartial(e)) || [];
    return message;
  }
};
function createBaseRequest_LocatorHandlerAddCustomAction() {
  return { action: "", selector: "", value: "", optionsAsJson: "" };
}
var Request_LocatorHandlerAddCustomAction = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.selector !== "") {
      writer.uint32(18).string(message.selector);
    }
    if (message.value !== "") {
      writer.uint32(26).string(message.value);
    }
    if (message.optionsAsJson !== "") {
      writer.uint32(34).string(message.optionsAsJson);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_LocatorHandlerAddCustomAction();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.value = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.optionsAsJson = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      value: isSet(object.value) ? globalThis.String(object.value) : "",
      optionsAsJson: isSet(object.optionsAsJson) ? globalThis.String(object.optionsAsJson) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.value !== "") {
      obj.value = message.value;
    }
    if (message.optionsAsJson !== "") {
      obj.optionsAsJson = message.optionsAsJson;
    }
    return obj;
  },
  create(base) {
    return Request_LocatorHandlerAddCustomAction.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_LocatorHandlerAddCustomAction();
    message.action = object.action ?? "";
    message.selector = object.selector ?? "";
    message.value = object.value ?? "";
    message.optionsAsJson = object.optionsAsJson ?? "";
    return message;
  }
};
function createBaseRequest_LocatorHandlerRemove() {
  return { selector: "" };
}
var Request_LocatorHandlerRemove = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_LocatorHandlerRemove();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { selector: isSet(object.selector) ? globalThis.String(object.selector) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    return obj;
  },
  create(base) {
    return Request_LocatorHandlerRemove.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_LocatorHandlerRemove();
    message.selector = object.selector ?? "";
    return message;
  }
};
function createBaseRequest_Json() {
  return { body: "" };
}
var Request_Json = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.body !== "") {
      writer.uint32(10).string(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Json();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.body = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { body: isSet(object.body) ? globalThis.String(object.body) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.body !== "") {
      obj.body = message.body;
    }
    return obj;
  },
  create(base) {
    return Request_Json.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Json();
    message.body = object.body ?? "";
    return message;
  }
};
function createBaseRequest_MouseButtonOptions() {
  return { action: "", json: "" };
}
var Request_MouseButtonOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.json !== "") {
      writer.uint32(18).string(message.json);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_MouseButtonOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.json = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      json: isSet(object.json) ? globalThis.String(object.json) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.json !== "") {
      obj.json = message.json;
    }
    return obj;
  },
  create(base) {
    return Request_MouseButtonOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_MouseButtonOptions();
    message.action = object.action ?? "";
    message.json = object.json ?? "";
    return message;
  }
};
function createBaseRequest_MouseWheel() {
  return { deltaX: 0, deltaY: 0 };
}
var Request_MouseWheel = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.deltaX !== 0) {
      writer.uint32(8).int32(message.deltaX);
    }
    if (message.deltaY !== 0) {
      writer.uint32(16).int32(message.deltaY);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_MouseWheel();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.deltaX = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.deltaY = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      deltaX: isSet(object.deltaX) ? globalThis.Number(object.deltaX) : 0,
      deltaY: isSet(object.deltaY) ? globalThis.Number(object.deltaY) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.deltaX !== 0) {
      obj.deltaX = Math.round(message.deltaX);
    }
    if (message.deltaY !== 0) {
      obj.deltaY = Math.round(message.deltaY);
    }
    return obj;
  },
  create(base) {
    return Request_MouseWheel.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_MouseWheel();
    message.deltaX = object.deltaX ?? 0;
    message.deltaY = object.deltaY ?? 0;
    return message;
  }
};
function createBaseRequest_KeyboardKeypress() {
  return { action: "", key: "" };
}
var Request_KeyboardKeypress = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.key !== "") {
      writer.uint32(18).string(message.key);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_KeyboardKeypress();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.key = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      key: isSet(object.key) ? globalThis.String(object.key) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.key !== "") {
      obj.key = message.key;
    }
    return obj;
  },
  create(base) {
    return Request_KeyboardKeypress.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_KeyboardKeypress();
    message.action = object.action ?? "";
    message.key = object.key ?? "";
    return message;
  }
};
function createBaseRequest_KeyboardInputOptions() {
  return { action: "", input: "", delay: 0 };
}
var Request_KeyboardInputOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.input !== "") {
      writer.uint32(18).string(message.input);
    }
    if (message.delay !== 0) {
      writer.uint32(24).int32(message.delay);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_KeyboardInputOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.input = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.delay = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      input: isSet(object.input) ? globalThis.String(object.input) : "",
      delay: isSet(object.delay) ? globalThis.Number(object.delay) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.input !== "") {
      obj.input = message.input;
    }
    if (message.delay !== 0) {
      obj.delay = Math.round(message.delay);
    }
    return obj;
  },
  create(base) {
    return Request_KeyboardInputOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_KeyboardInputOptions();
    message.action = object.action ?? "";
    message.input = object.input ?? "";
    message.delay = object.delay ?? 0;
    return message;
  }
};
function createBaseRequest_Browser() {
  return { browser: "", rawOptions: "" };
}
var Request_Browser = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.browser !== "") {
      writer.uint32(10).string(message.browser);
    }
    if (message.rawOptions !== "") {
      writer.uint32(18).string(message.rawOptions);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Browser();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.browser = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.rawOptions = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      browser: isSet(object.browser) ? globalThis.String(object.browser) : "",
      rawOptions: isSet(object.rawOptions) ? globalThis.String(object.rawOptions) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.browser !== "") {
      obj.browser = message.browser;
    }
    if (message.rawOptions !== "") {
      obj.rawOptions = message.rawOptions;
    }
    return obj;
  },
  create(base) {
    return Request_Browser.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Browser();
    message.browser = object.browser ?? "";
    message.rawOptions = object.rawOptions ?? "";
    return message;
  }
};
function createBaseRequest_Context() {
  return { rawOptions: "", defaultTimeout: 0, traceFile: "" };
}
var Request_Context = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.rawOptions !== "") {
      writer.uint32(10).string(message.rawOptions);
    }
    if (message.defaultTimeout !== 0) {
      writer.uint32(16).int32(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      writer.uint32(26).string(message.traceFile);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Context();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.rawOptions = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.defaultTimeout = reader.int32();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.traceFile = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      rawOptions: isSet(object.rawOptions) ? globalThis.String(object.rawOptions) : "",
      defaultTimeout: isSet(object.defaultTimeout) ? globalThis.Number(object.defaultTimeout) : 0,
      traceFile: isSet(object.traceFile) ? globalThis.String(object.traceFile) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.rawOptions !== "") {
      obj.rawOptions = message.rawOptions;
    }
    if (message.defaultTimeout !== 0) {
      obj.defaultTimeout = Math.round(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      obj.traceFile = message.traceFile;
    }
    return obj;
  },
  create(base) {
    return Request_Context.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Context();
    message.rawOptions = object.rawOptions ?? "";
    message.defaultTimeout = object.defaultTimeout ?? 0;
    message.traceFile = object.traceFile ?? "";
    return message;
  }
};
function createBaseRequest_PersistentContext() {
  return { browser: "", rawOptions: "", defaultTimeout: 0, traceFile: "" };
}
var Request_PersistentContext = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.browser !== "") {
      writer.uint32(10).string(message.browser);
    }
    if (message.rawOptions !== "") {
      writer.uint32(18).string(message.rawOptions);
    }
    if (message.defaultTimeout !== 0) {
      writer.uint32(24).int32(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      writer.uint32(34).string(message.traceFile);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_PersistentContext();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.browser = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.rawOptions = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.defaultTimeout = reader.int32();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.traceFile = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      browser: isSet(object.browser) ? globalThis.String(object.browser) : "",
      rawOptions: isSet(object.rawOptions) ? globalThis.String(object.rawOptions) : "",
      defaultTimeout: isSet(object.defaultTimeout) ? globalThis.Number(object.defaultTimeout) : 0,
      traceFile: isSet(object.traceFile) ? globalThis.String(object.traceFile) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.browser !== "") {
      obj.browser = message.browser;
    }
    if (message.rawOptions !== "") {
      obj.rawOptions = message.rawOptions;
    }
    if (message.defaultTimeout !== 0) {
      obj.defaultTimeout = Math.round(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      obj.traceFile = message.traceFile;
    }
    return obj;
  },
  create(base) {
    return Request_PersistentContext.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_PersistentContext();
    message.browser = object.browser ?? "";
    message.rawOptions = object.rawOptions ?? "";
    message.defaultTimeout = object.defaultTimeout ?? 0;
    message.traceFile = object.traceFile ?? "";
    return message;
  }
};
function createBaseRequest_Permissions() {
  return { permissions: [], origin: "" };
}
var Request_Permissions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.permissions) {
      writer.uint32(10).string(v);
    }
    if (message.origin !== "") {
      writer.uint32(18).string(message.origin);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Permissions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.permissions.push(reader.string());
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.origin = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      permissions: globalThis.Array.isArray(object?.permissions) ? object.permissions.map((e) => globalThis.String(e)) : [],
      origin: isSet(object.origin) ? globalThis.String(object.origin) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.permissions?.length) {
      obj.permissions = message.permissions;
    }
    if (message.origin !== "") {
      obj.origin = message.origin;
    }
    return obj;
  },
  create(base) {
    return Request_Permissions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Permissions();
    message.permissions = object.permissions?.map((e) => e) || [];
    message.origin = object.origin ?? "";
    return message;
  }
};
function createBaseRequest_Url() {
  return { url: "", defaultTimeout: 0 };
}
var Request_Url = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== "") {
      writer.uint32(10).string(message.url);
    }
    if (message.defaultTimeout !== 0) {
      writer.uint32(16).int32(message.defaultTimeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Url();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.defaultTimeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      defaultTimeout: isSet(object.defaultTimeout) ? globalThis.Number(object.defaultTimeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.defaultTimeout !== 0) {
      obj.defaultTimeout = Math.round(message.defaultTimeout);
    }
    return obj;
  },
  create(base) {
    return Request_Url.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Url();
    message.url = object.url ?? "";
    message.defaultTimeout = object.defaultTimeout ?? 0;
    return message;
  }
};
function createBaseRequest_DownloadOptions() {
  return { url: "", path: "", waitForFinish: false, downloadTimeout: 0 };
}
var Request_DownloadOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== "") {
      writer.uint32(10).string(message.url);
    }
    if (message.path !== "") {
      writer.uint32(18).string(message.path);
    }
    if (message.waitForFinish !== false) {
      writer.uint32(24).bool(message.waitForFinish);
    }
    if (message.downloadTimeout !== 0) {
      writer.uint32(32).int32(message.downloadTimeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_DownloadOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.path = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.waitForFinish = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.downloadTimeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      path: isSet(object.path) ? globalThis.String(object.path) : "",
      waitForFinish: isSet(object.waitForFinish) ? globalThis.Boolean(object.waitForFinish) : false,
      downloadTimeout: isSet(object.downloadTimeout) ? globalThis.Number(object.downloadTimeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.path !== "") {
      obj.path = message.path;
    }
    if (message.waitForFinish !== false) {
      obj.waitForFinish = message.waitForFinish;
    }
    if (message.downloadTimeout !== 0) {
      obj.downloadTimeout = Math.round(message.downloadTimeout);
    }
    return obj;
  },
  create(base) {
    return Request_DownloadOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_DownloadOptions();
    message.url = object.url ?? "";
    message.path = object.path ?? "";
    message.waitForFinish = object.waitForFinish ?? false;
    message.downloadTimeout = object.downloadTimeout ?? 0;
    return message;
  }
};
function createBaseRequest_DownloadID() {
  return { id: "" };
}
var Request_DownloadID = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_DownloadID();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { id: isSet(object.id) ? globalThis.String(object.id) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    return obj;
  },
  create(base) {
    return Request_DownloadID.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_DownloadID();
    message.id = object.id ?? "";
    return message;
  }
};
function createBaseRequest_UrlOptions() {
  return { url: void 0, waitUntil: "" };
}
var Request_UrlOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== void 0) {
      Request_Url.encode(message.url, writer.uint32(10).fork()).join();
    }
    if (message.waitUntil !== "") {
      writer.uint32(18).string(message.waitUntil);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_UrlOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = Request_Url.decode(reader, reader.uint32());
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.waitUntil = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? Request_Url.fromJSON(object.url) : void 0,
      waitUntil: isSet(object.waitUntil) ? globalThis.String(object.waitUntil) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== void 0) {
      obj.url = Request_Url.toJSON(message.url);
    }
    if (message.waitUntil !== "") {
      obj.waitUntil = message.waitUntil;
    }
    return obj;
  },
  create(base) {
    return Request_UrlOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_UrlOptions();
    message.url = object.url !== void 0 && object.url !== null ? Request_Url.fromPartial(object.url) : void 0;
    message.waitUntil = object.waitUntil ?? "";
    return message;
  }
};
function createBaseRequest_PageLoadState() {
  return { state: "", timeout: 0 };
}
var Request_PageLoadState = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.state !== "") {
      writer.uint32(10).string(message.state);
    }
    if (message.timeout !== 0) {
      writer.uint32(16).int32(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_PageLoadState();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.state = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.timeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      state: isSet(object.state) ? globalThis.String(object.state) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.state !== "") {
      obj.state = message.state;
    }
    if (message.timeout !== 0) {
      obj.timeout = Math.round(message.timeout);
    }
    return obj;
  },
  create(base) {
    return Request_PageLoadState.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_PageLoadState();
    message.state = object.state ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_ConnectBrowser() {
  return { browser: "", url: "", connectCDP: false, timeout: 0 };
}
var Request_ConnectBrowser = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.browser !== "") {
      writer.uint32(10).string(message.browser);
    }
    if (message.url !== "") {
      writer.uint32(18).string(message.url);
    }
    if (message.connectCDP !== false) {
      writer.uint32(24).bool(message.connectCDP);
    }
    if (message.timeout !== 0) {
      writer.uint32(32).int32(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ConnectBrowser();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.browser = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.connectCDP = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.timeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      browser: isSet(object.browser) ? globalThis.String(object.browser) : "",
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      connectCDP: isSet(object.connectCDP) ? globalThis.Boolean(object.connectCDP) : false,
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.browser !== "") {
      obj.browser = message.browser;
    }
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.connectCDP !== false) {
      obj.connectCDP = message.connectCDP;
    }
    if (message.timeout !== 0) {
      obj.timeout = Math.round(message.timeout);
    }
    return obj;
  },
  create(base) {
    return Request_ConnectBrowser.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ConnectBrowser();
    message.browser = object.browser ?? "";
    message.url = object.url ?? "";
    message.connectCDP = object.connectCDP ?? false;
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_ElementProperty() {
  return { selector: "", property: "", strict: false };
}
var Request_ElementProperty = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.property !== "") {
      writer.uint32(18).string(message.property);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementProperty();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.property = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      property: isSet(object.property) ? globalThis.String(object.property) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.property !== "") {
      obj.property = message.property;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ElementProperty.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementProperty();
    message.selector = object.selector ?? "";
    message.property = object.property ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_TypeText() {
  return { selector: "", text: "", delay: 0, clear: false, strict: false };
}
var Request_TypeText = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.text !== "") {
      writer.uint32(18).string(message.text);
    }
    if (message.delay !== 0) {
      writer.uint32(24).int32(message.delay);
    }
    if (message.clear !== false) {
      writer.uint32(32).bool(message.clear);
    }
    if (message.strict !== false) {
      writer.uint32(40).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_TypeText();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.text = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.delay = reader.int32();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.clear = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      text: isSet(object.text) ? globalThis.String(object.text) : "",
      delay: isSet(object.delay) ? globalThis.Number(object.delay) : 0,
      clear: isSet(object.clear) ? globalThis.Boolean(object.clear) : false,
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.text !== "") {
      obj.text = message.text;
    }
    if (message.delay !== 0) {
      obj.delay = Math.round(message.delay);
    }
    if (message.clear !== false) {
      obj.clear = message.clear;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_TypeText.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_TypeText();
    message.selector = object.selector ?? "";
    message.text = object.text ?? "";
    message.delay = object.delay ?? 0;
    message.clear = object.clear ?? false;
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_FillText() {
  return { selector: "", text: "", strict: false, force: false };
}
var Request_FillText = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.text !== "") {
      writer.uint32(18).string(message.text);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    if (message.force !== false) {
      writer.uint32(32).bool(message.force);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_FillText();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.text = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.force = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      text: isSet(object.text) ? globalThis.String(object.text) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      force: isSet(object.force) ? globalThis.Boolean(object.force) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.text !== "") {
      obj.text = message.text;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.force !== false) {
      obj.force = message.force;
    }
    return obj;
  },
  create(base) {
    return Request_FillText.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_FillText();
    message.selector = object.selector ?? "";
    message.text = object.text ?? "";
    message.strict = object.strict ?? false;
    message.force = object.force ?? false;
    return message;
  }
};
function createBaseRequest_ClearText() {
  return { selector: "", strict: false };
}
var Request_ClearText = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClearText();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ClearText.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClearText();
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_PressKeys() {
  return { selector: "", strict: false, key: [], pressDelay: 0, keyDelay: 0 };
}
var Request_PressKeys = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    for (const v of message.key) {
      writer.uint32(26).string(v);
    }
    if (message.pressDelay !== 0) {
      writer.uint32(32).int32(message.pressDelay);
    }
    if (message.keyDelay !== 0) {
      writer.uint32(40).int32(message.keyDelay);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_PressKeys();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.key.push(reader.string());
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.pressDelay = reader.int32();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.keyDelay = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      key: globalThis.Array.isArray(object?.key) ? object.key.map((e) => globalThis.String(e)) : [],
      pressDelay: isSet(object.pressDelay) ? globalThis.Number(object.pressDelay) : 0,
      keyDelay: isSet(object.keyDelay) ? globalThis.Number(object.keyDelay) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.key?.length) {
      obj.key = message.key;
    }
    if (message.pressDelay !== 0) {
      obj.pressDelay = Math.round(message.pressDelay);
    }
    if (message.keyDelay !== 0) {
      obj.keyDelay = Math.round(message.keyDelay);
    }
    return obj;
  },
  create(base) {
    return Request_PressKeys.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_PressKeys();
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    message.key = object.key?.map((e) => e) || [];
    message.pressDelay = object.pressDelay ?? 0;
    message.keyDelay = object.keyDelay ?? 0;
    return message;
  }
};
function createBaseRequest_ElementSelector() {
  return { selector: "", strict: false, force: false };
}
var Request_ElementSelector = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    if (message.force !== false) {
      writer.uint32(24).bool(message.force);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementSelector();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.force = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      force: isSet(object.force) ? globalThis.Boolean(object.force) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.force !== false) {
      obj.force = message.force;
    }
    return obj;
  },
  create(base) {
    return Request_ElementSelector.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementSelector();
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    message.force = object.force ?? false;
    return message;
  }
};
function createBaseRequest_Timeout() {
  return { timeout: 0 };
}
var Request_Timeout = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.timeout !== 0) {
      writer.uint32(13).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Timeout();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 13) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0 };
  },
  toJSON(message) {
    const obj = {};
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_Timeout.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Timeout();
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_Index() {
  return { index: "" };
}
var Request_Index = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.index !== "") {
      writer.uint32(10).string(message.index);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Index();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.index = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { index: isSet(object.index) ? globalThis.String(object.index) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.index !== "") {
      obj.index = message.index;
    }
    return obj;
  },
  create(base) {
    return Request_Index.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Index();
    message.index = object.index ?? "";
    return message;
  }
};
function createBaseRequest_IdWithTimeout() {
  return { id: "", timeout: 0 };
}
var Request_IdWithTimeout = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    if (message.timeout !== 0) {
      writer.uint32(21).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_IdWithTimeout();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 21) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      id: isSet(object.id) ? globalThis.String(object.id) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_IdWithTimeout.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_IdWithTimeout();
    message.id = object.id ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_StyleTag() {
  return { content: "" };
}
var Request_StyleTag = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.content !== "") {
      writer.uint32(10).string(message.content);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_StyleTag();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.content = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { content: isSet(object.content) ? globalThis.String(object.content) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.content !== "") {
      obj.content = message.content;
    }
    return obj;
  },
  create(base) {
    return Request_StyleTag.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_StyleTag();
    message.content = object.content ?? "";
    return message;
  }
};
function createBaseRequest_ElementSelectorWithOptions() {
  return { selector: "", options: "", strict: false };
}
var Request_ElementSelectorWithOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.options !== "") {
      writer.uint32(18).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementSelectorWithOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ElementSelectorWithOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementSelectorWithOptions();
    message.selector = object.selector ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_ElementSelectorWithDuration() {
  return { selector: "", duration: 0, width: "", style: "", color: "", strict: false, mode: "" };
}
var Request_ElementSelectorWithDuration = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.duration !== 0) {
      writer.uint32(16).int32(message.duration);
    }
    if (message.width !== "") {
      writer.uint32(26).string(message.width);
    }
    if (message.style !== "") {
      writer.uint32(34).string(message.style);
    }
    if (message.color !== "") {
      writer.uint32(42).string(message.color);
    }
    if (message.strict !== false) {
      writer.uint32(48).bool(message.strict);
    }
    if (message.mode !== "") {
      writer.uint32(58).string(message.mode);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementSelectorWithDuration();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.duration = reader.int32();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.width = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.style = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.color = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 48) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 7: {
          if (tag !== 58) {
            break;
          }
          message.mode = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      duration: isSet(object.duration) ? globalThis.Number(object.duration) : 0,
      width: isSet(object.width) ? globalThis.String(object.width) : "",
      style: isSet(object.style) ? globalThis.String(object.style) : "",
      color: isSet(object.color) ? globalThis.String(object.color) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      mode: isSet(object.mode) ? globalThis.String(object.mode) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.duration !== 0) {
      obj.duration = Math.round(message.duration);
    }
    if (message.width !== "") {
      obj.width = message.width;
    }
    if (message.style !== "") {
      obj.style = message.style;
    }
    if (message.color !== "") {
      obj.color = message.color;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.mode !== "") {
      obj.mode = message.mode;
    }
    return obj;
  },
  create(base) {
    return Request_ElementSelectorWithDuration.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementSelectorWithDuration();
    message.selector = object.selector ?? "";
    message.duration = object.duration ?? 0;
    message.width = object.width ?? "";
    message.style = object.style ?? "";
    message.color = object.color ?? "";
    message.strict = object.strict ?? false;
    message.mode = object.mode ?? "";
    return message;
  }
};
function createBaseRequest_SelectElementSelector() {
  return { selector: "", matcherJson: "", strict: false };
}
var Request_SelectElementSelector = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.matcherJson !== "") {
      writer.uint32(18).string(message.matcherJson);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_SelectElementSelector();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.matcherJson = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      matcherJson: isSet(object.matcherJson) ? globalThis.String(object.matcherJson) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.matcherJson !== "") {
      obj.matcherJson = message.matcherJson;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_SelectElementSelector.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_SelectElementSelector();
    message.selector = object.selector ?? "";
    message.matcherJson = object.matcherJson ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_WaitForFunctionOptions() {
  return { script: "", selector: "", options: "", strict: false };
}
var Request_WaitForFunctionOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.script !== "") {
      writer.uint32(10).string(message.script);
    }
    if (message.selector !== "") {
      writer.uint32(18).string(message.selector);
    }
    if (message.options !== "") {
      writer.uint32(26).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_WaitForFunctionOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.script = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      script: isSet(object.script) ? globalThis.String(object.script) : "",
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.script !== "") {
      obj.script = message.script;
    }
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_WaitForFunctionOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_WaitForFunctionOptions();
    message.script = object.script ?? "";
    message.selector = object.selector ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_Viewport() {
  return { width: 0, height: 0 };
}
var Request_Viewport = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.width !== 0) {
      writer.uint32(8).int32(message.width);
    }
    if (message.height !== 0) {
      writer.uint32(16).int32(message.height);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Viewport();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.width = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.height = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      width: isSet(object.width) ? globalThis.Number(object.width) : 0,
      height: isSet(object.height) ? globalThis.Number(object.height) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.width !== 0) {
      obj.width = Math.round(message.width);
    }
    if (message.height !== 0) {
      obj.height = Math.round(message.height);
    }
    return obj;
  },
  create(base) {
    return Request_Viewport.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Viewport();
    message.width = object.width ?? 0;
    message.height = object.height ?? 0;
    return message;
  }
};
function createBaseRequest_HttpRequest() {
  return { url: "", method: "", body: "", headers: "" };
}
var Request_HttpRequest = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== "") {
      writer.uint32(10).string(message.url);
    }
    if (message.method !== "") {
      writer.uint32(18).string(message.method);
    }
    if (message.body !== "") {
      writer.uint32(26).string(message.body);
    }
    if (message.headers !== "") {
      writer.uint32(34).string(message.headers);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_HttpRequest();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.method = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.body = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.headers = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      method: isSet(object.method) ? globalThis.String(object.method) : "",
      body: isSet(object.body) ? globalThis.String(object.body) : "",
      headers: isSet(object.headers) ? globalThis.String(object.headers) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.method !== "") {
      obj.method = message.method;
    }
    if (message.body !== "") {
      obj.body = message.body;
    }
    if (message.headers !== "") {
      obj.headers = message.headers;
    }
    return obj;
  },
  create(base) {
    return Request_HttpRequest.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_HttpRequest();
    message.url = object.url ?? "";
    message.method = object.method ?? "";
    message.body = object.body ?? "";
    message.headers = object.headers ?? "";
    return message;
  }
};
function createBaseRequest_HttpCapture() {
  return { urlOrPredicate: "", timeout: 0 };
}
var Request_HttpCapture = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.urlOrPredicate !== "") {
      writer.uint32(10).string(message.urlOrPredicate);
    }
    if (message.timeout !== 0) {
      writer.uint32(21).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_HttpCapture();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.urlOrPredicate = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 21) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      urlOrPredicate: isSet(object.urlOrPredicate) ? globalThis.String(object.urlOrPredicate) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.urlOrPredicate !== "") {
      obj.urlOrPredicate = message.urlOrPredicate;
    }
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_HttpCapture.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_HttpCapture();
    message.urlOrPredicate = object.urlOrPredicate ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_Device() {
  return { name: "" };
}
var Request_Device = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.name !== "") {
      writer.uint32(10).string(message.name);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Device();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.name = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { name: isSet(object.name) ? globalThis.String(object.name) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.name !== "") {
      obj.name = message.name;
    }
    return obj;
  },
  create(base) {
    return Request_Device.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Device();
    message.name = object.name ?? "";
    return message;
  }
};
function createBaseRequest_AlertAction() {
  return { alertAction: "", promptInput: "", timeout: 0 };
}
var Request_AlertAction = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.alertAction !== "") {
      writer.uint32(10).string(message.alertAction);
    }
    if (message.promptInput !== "") {
      writer.uint32(18).string(message.promptInput);
    }
    if (message.timeout !== 0) {
      writer.uint32(29).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_AlertAction();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.alertAction = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.promptInput = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 29) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      alertAction: isSet(object.alertAction) ? globalThis.String(object.alertAction) : "",
      promptInput: isSet(object.promptInput) ? globalThis.String(object.promptInput) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.alertAction !== "") {
      obj.alertAction = message.alertAction;
    }
    if (message.promptInput !== "") {
      obj.promptInput = message.promptInput;
    }
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_AlertAction.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_AlertAction();
    message.alertAction = object.alertAction ?? "";
    message.promptInput = object.promptInput ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_AlertActions() {
  return { items: [] };
}
var Request_AlertActions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.items) {
      Request_AlertAction.encode(v, writer.uint32(10).fork()).join();
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_AlertActions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.items.push(Request_AlertAction.decode(reader, reader.uint32()));
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      items: globalThis.Array.isArray(object?.items) ? object.items.map((e) => Request_AlertAction.fromJSON(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.items?.length) {
      obj.items = message.items.map((e) => Request_AlertAction.toJSON(e));
    }
    return obj;
  },
  create(base) {
    return Request_AlertActions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_AlertActions();
    message.items = object.items?.map((e) => Request_AlertAction.fromPartial(e)) || [];
    return message;
  }
};
function createBaseRequest_Bool() {
  return { value: false };
}
var Request_Bool = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.value !== false) {
      writer.uint32(8).bool(message.value);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Bool();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.value = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { value: isSet(object.value) ? globalThis.Boolean(object.value) : false };
  },
  toJSON(message) {
    const obj = {};
    if (message.value !== false) {
      obj.value = message.value;
    }
    return obj;
  },
  create(base) {
    return Request_Bool.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Bool();
    message.value = object.value ?? false;
    return message;
  }
};
function createBaseRequest_EvaluateAll() {
  return { selector: "", script: "", arg: "", allElements: false, strict: false };
}
var Request_EvaluateAll = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.script !== "") {
      writer.uint32(18).string(message.script);
    }
    if (message.arg !== "") {
      writer.uint32(26).string(message.arg);
    }
    if (message.allElements !== false) {
      writer.uint32(32).bool(message.allElements);
    }
    if (message.strict !== false) {
      writer.uint32(40).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_EvaluateAll();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.script = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.arg = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.allElements = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      script: isSet(object.script) ? globalThis.String(object.script) : "",
      arg: isSet(object.arg) ? globalThis.String(object.arg) : "",
      allElements: isSet(object.allElements) ? globalThis.Boolean(object.allElements) : false,
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.script !== "") {
      obj.script = message.script;
    }
    if (message.arg !== "") {
      obj.arg = message.arg;
    }
    if (message.allElements !== false) {
      obj.allElements = message.allElements;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_EvaluateAll.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_EvaluateAll();
    message.selector = object.selector ?? "";
    message.script = object.script ?? "";
    message.arg = object.arg ?? "";
    message.allElements = object.allElements ?? false;
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_ElementStyle() {
  return { selector: "", pseudo: "", styleKey: "", strict: false };
}
var Request_ElementStyle = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.pseudo !== "") {
      writer.uint32(18).string(message.pseudo);
    }
    if (message.styleKey !== "") {
      writer.uint32(26).string(message.styleKey);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementStyle();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.pseudo = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.styleKey = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      pseudo: isSet(object.pseudo) ? globalThis.String(object.pseudo) : "",
      styleKey: isSet(object.styleKey) ? globalThis.String(object.styleKey) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.pseudo !== "") {
      obj.pseudo = message.pseudo;
    }
    if (message.styleKey !== "") {
      obj.styleKey = message.styleKey;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ElementStyle.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementStyle();
    message.selector = object.selector ?? "";
    message.pseudo = object.pseudo ?? "";
    message.styleKey = object.styleKey ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseTypes_SelectEntry() {
  return { value: "", label: "", index: 0, selected: false };
}
var Types_SelectEntry = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.value !== "") {
      writer.uint32(18).string(message.value);
    }
    if (message.label !== "") {
      writer.uint32(26).string(message.label);
    }
    if (message.index !== 0) {
      writer.uint32(32).int32(message.index);
    }
    if (message.selected !== false) {
      writer.uint32(40).bool(message.selected);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseTypes_SelectEntry();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.value = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.label = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.index = reader.int32();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.selected = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      value: isSet(object.value) ? globalThis.String(object.value) : "",
      label: isSet(object.label) ? globalThis.String(object.label) : "",
      index: isSet(object.index) ? globalThis.Number(object.index) : 0,
      selected: isSet(object.selected) ? globalThis.Boolean(object.selected) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.value !== "") {
      obj.value = message.value;
    }
    if (message.label !== "") {
      obj.label = message.label;
    }
    if (message.index !== 0) {
      obj.index = Math.round(message.index);
    }
    if (message.selected !== false) {
      obj.selected = message.selected;
    }
    return obj;
  },
  create(base) {
    return Types_SelectEntry.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseTypes_SelectEntry();
    message.value = object.value ?? "";
    message.label = object.label ?? "";
    message.index = object.index ?? 0;
    message.selected = object.selected ?? false;
    return message;
  }
};
function createBaseResponse_Empty() {
  return { log: "" };
}
var Response_Empty = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Empty();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { log: isSet(object.log) ? globalThis.String(object.log) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    return obj;
  },
  create(base) {
    return Response_Empty.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Empty();
    message.log = object.log ?? "";
    return message;
  }
};
function createBaseResponse_String() {
  return { log: "", body: "" };
}
var Response_String = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== "") {
      writer.uint32(18).string(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_String();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.body = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.String(object.body) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== "") {
      obj.body = message.body;
    }
    return obj;
  },
  create(base) {
    return Response_String.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_String();
    message.log = object.log ?? "";
    message.body = object.body ?? "";
    return message;
  }
};
function createBaseResponse_ListString() {
  return { items: [] };
}
var Response_ListString = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.items) {
      writer.uint32(10).string(v);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_ListString();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.items.push(reader.string());
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { items: globalThis.Array.isArray(object?.items) ? object.items.map((e) => globalThis.String(e)) : [] };
  },
  toJSON(message) {
    const obj = {};
    if (message.items?.length) {
      obj.items = message.items;
    }
    return obj;
  },
  create(base) {
    return Response_ListString.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_ListString();
    message.items = object.items?.map((e) => e) || [];
    return message;
  }
};
function createBaseResponse_Keywords() {
  return { log: "", keywords: [], keywordDocumentations: [], keywordArguments: [] };
}
var Response_Keywords = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    for (const v of message.keywords) {
      writer.uint32(18).string(v);
    }
    for (const v of message.keywordDocumentations) {
      writer.uint32(26).string(v);
    }
    for (const v of message.keywordArguments) {
      writer.uint32(34).string(v);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Keywords();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.keywords.push(reader.string());
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.keywordDocumentations.push(reader.string());
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.keywordArguments.push(reader.string());
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      keywords: globalThis.Array.isArray(object?.keywords) ? object.keywords.map((e) => globalThis.String(e)) : [],
      keywordDocumentations: globalThis.Array.isArray(object?.keywordDocumentations) ? object.keywordDocumentations.map((e) => globalThis.String(e)) : [],
      keywordArguments: globalThis.Array.isArray(object?.keywordArguments) ? object.keywordArguments.map((e) => globalThis.String(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.keywords?.length) {
      obj.keywords = message.keywords;
    }
    if (message.keywordDocumentations?.length) {
      obj.keywordDocumentations = message.keywordDocumentations;
    }
    if (message.keywordArguments?.length) {
      obj.keywordArguments = message.keywordArguments;
    }
    return obj;
  },
  create(base) {
    return Response_Keywords.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Keywords();
    message.log = object.log ?? "";
    message.keywords = object.keywords?.map((e) => e) || [];
    message.keywordDocumentations = object.keywordDocumentations?.map((e) => e) || [];
    message.keywordArguments = object.keywordArguments?.map((e) => e) || [];
    return message;
  }
};
function createBaseResponse_Bool() {
  return { log: "", body: false };
}
var Response_Bool = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== false) {
      writer.uint32(16).bool(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Bool();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.body = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.Boolean(object.body) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== false) {
      obj.body = message.body;
    }
    return obj;
  },
  create(base) {
    return Response_Bool.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Bool();
    message.log = object.log ?? "";
    message.body = object.body ?? false;
    return message;
  }
};
function createBaseResponse_Int() {
  return { log: "", body: 0 };
}
var Response_Int = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== 0) {
      writer.uint32(16).int32(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Int();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.body = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.Number(object.body) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== 0) {
      obj.body = Math.round(message.body);
    }
    return obj;
  },
  create(base) {
    return Response_Int.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Int();
    message.log = object.log ?? "";
    message.body = object.body ?? 0;
    return message;
  }
};
function createBaseResponse_Select() {
  return { entry: [] };
}
var Response_Select = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.entry) {
      Types_SelectEntry.encode(v, writer.uint32(10).fork()).join();
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Select();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.entry.push(Types_SelectEntry.decode(reader, reader.uint32()));
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      entry: globalThis.Array.isArray(object?.entry) ? object.entry.map((e) => Types_SelectEntry.fromJSON(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.entry?.length) {
      obj.entry = message.entry.map((e) => Types_SelectEntry.toJSON(e));
    }
    return obj;
  },
  create(base) {
    return Response_Select.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Select();
    message.entry = object.entry?.map((e) => Types_SelectEntry.fromPartial(e)) || [];
    return message;
  }
};
function createBaseResponse_Json() {
  return { log: "", json: "", bodyPart: "" };
}
var Response_Json = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.json !== "") {
      writer.uint32(18).string(message.json);
    }
    if (message.bodyPart !== "") {
      writer.uint32(26).string(message.bodyPart);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Json();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.json = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.bodyPart = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      json: isSet(object.json) ? globalThis.String(object.json) : "",
      bodyPart: isSet(object.bodyPart) ? globalThis.String(object.bodyPart) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.json !== "") {
      obj.json = message.json;
    }
    if (message.bodyPart !== "") {
      obj.bodyPart = message.bodyPart;
    }
    return obj;
  },
  create(base) {
    return Response_Json.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Json();
    message.log = object.log ?? "";
    message.json = object.json ?? "";
    message.bodyPart = object.bodyPart ?? "";
    return message;
  }
};
function createBaseResponse_JavascriptExecutionResult() {
  return { log: "", result: "" };
}
var Response_JavascriptExecutionResult = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.result !== "") {
      writer.uint32(18).string(message.result);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_JavascriptExecutionResult();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.result = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      result: isSet(object.result) ? globalThis.String(object.result) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.result !== "") {
      obj.result = message.result;
    }
    return obj;
  },
  create(base) {
    return Response_JavascriptExecutionResult.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_JavascriptExecutionResult();
    message.log = object.log ?? "";
    message.result = object.result ?? "";
    return message;
  }
};
function createBaseResponse_NewContextResponse() {
  return { id: "", log: "", contextOptions: "", newBrowser: false };
}
var Response_NewContextResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    if (message.log !== "") {
      writer.uint32(18).string(message.log);
    }
    if (message.contextOptions !== "") {
      writer.uint32(26).string(message.contextOptions);
    }
    if (message.newBrowser !== false) {
      writer.uint32(32).bool(message.newBrowser);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_NewContextResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.contextOptions = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.newBrowser = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      id: isSet(object.id) ? globalThis.String(object.id) : "",
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      contextOptions: isSet(object.contextOptions) ? globalThis.String(object.contextOptions) : "",
      newBrowser: isSet(object.newBrowser) ? globalThis.Boolean(object.newBrowser) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.contextOptions !== "") {
      obj.contextOptions = message.contextOptions;
    }
    if (message.newBrowser !== false) {
      obj.newBrowser = message.newBrowser;
    }
    return obj;
  },
  create(base) {
    return Response_NewContextResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_NewContextResponse();
    message.id = object.id ?? "";
    message.log = object.log ?? "";
    message.contextOptions = object.contextOptions ?? "";
    message.newBrowser = object.newBrowser ?? false;
    return message;
  }
};
function createBaseResponse_NewPersistentContextResponse() {
  return { id: "", log: "", contextOptions: "", newBrowser: false, video: "", pageId: "", browserId: "" };
}
var Response_NewPersistentContextResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    if (message.log !== "") {
      writer.uint32(18).string(message.log);
    }
    if (message.contextOptions !== "") {
      writer.uint32(26).string(message.contextOptions);
    }
    if (message.newBrowser !== false) {
      writer.uint32(32).bool(message.newBrowser);
    }
    if (message.video !== "") {
      writer.uint32(42).string(message.video);
    }
    if (message.pageId !== "") {
      writer.uint32(50).string(message.pageId);
    }
    if (message.browserId !== "") {
      writer.uint32(58).string(message.browserId);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_NewPersistentContextResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.contextOptions = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.newBrowser = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.video = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 50) {
            break;
          }
          message.pageId = reader.string();
          continue;
        }
        case 7: {
          if (tag !== 58) {
            break;
          }
          message.browserId = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      id: isSet(object.id) ? globalThis.String(object.id) : "",
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      contextOptions: isSet(object.contextOptions) ? globalThis.String(object.contextOptions) : "",
      newBrowser: isSet(object.newBrowser) ? globalThis.Boolean(object.newBrowser) : false,
      video: isSet(object.video) ? globalThis.String(object.video) : "",
      pageId: isSet(object.pageId) ? globalThis.String(object.pageId) : "",
      browserId: isSet(object.browserId) ? globalThis.String(object.browserId) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.contextOptions !== "") {
      obj.contextOptions = message.contextOptions;
    }
    if (message.newBrowser !== false) {
      obj.newBrowser = message.newBrowser;
    }
    if (message.video !== "") {
      obj.video = message.video;
    }
    if (message.pageId !== "") {
      obj.pageId = message.pageId;
    }
    if (message.browserId !== "") {
      obj.browserId = message.browserId;
    }
    return obj;
  },
  create(base) {
    return Response_NewPersistentContextResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_NewPersistentContextResponse();
    message.id = object.id ?? "";
    message.log = object.log ?? "";
    message.contextOptions = object.contextOptions ?? "";
    message.newBrowser = object.newBrowser ?? false;
    message.video = object.video ?? "";
    message.pageId = object.pageId ?? "";
    message.browserId = object.browserId ?? "";
    return message;
  }
};
function createBaseResponse_NewPageResponse() {
  return { log: "", body: "", video: "", newBrowser: false, newContext: false };
}
var Response_NewPageResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== "") {
      writer.uint32(18).string(message.body);
    }
    if (message.video !== "") {
      writer.uint32(26).string(message.video);
    }
    if (message.newBrowser !== false) {
      writer.uint32(32).bool(message.newBrowser);
    }
    if (message.newContext !== false) {
      writer.uint32(40).bool(message.newContext);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_NewPageResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.body = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.video = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.newBrowser = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.newContext = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.String(object.body) : "",
      video: isSet(object.video) ? globalThis.String(object.video) : "",
      newBrowser: isSet(object.newBrowser) ? globalThis.Boolean(object.newBrowser) : false,
      newContext: isSet(object.newContext) ? globalThis.Boolean(object.newContext) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== "") {
      obj.body = message.body;
    }
    if (message.video !== "") {
      obj.video = message.video;
    }
    if (message.newBrowser !== false) {
      obj.newBrowser = message.newBrowser;
    }
    if (message.newContext !== false) {
      obj.newContext = message.newContext;
    }
    return obj;
  },
  create(base) {
    return Response_NewPageResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_NewPageResponse();
    message.log = object.log ?? "";
    message.body = object.body ?? "";
    message.video = object.video ?? "";
    message.newBrowser = object.newBrowser ?? false;
    message.newContext = object.newContext ?? false;
    return message;
  }
};
function createBaseResponse_PageReportResponse() {
  return { log: "", errors: "", console: "", pageId: "" };
}
var Response_PageReportResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.errors !== "") {
      writer.uint32(18).string(message.errors);
    }
    if (message.console !== "") {
      writer.uint32(26).string(message.console);
    }
    if (message.pageId !== "") {
      writer.uint32(34).string(message.pageId);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_PageReportResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.errors = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.console = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.pageId = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      errors: isSet(object.errors) ? globalThis.String(object.errors) : "",
      console: isSet(object.console) ? globalThis.String(object.console) : "",
      pageId: isSet(object.pageId) ? globalThis.String(object.pageId) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.errors !== "") {
      obj.errors = message.errors;
    }
    if (message.console !== "") {
      obj.console = message.console;
    }
    if (message.pageId !== "") {
      obj.pageId = message.pageId;
    }
    return obj;
  },
  create(base) {
    return Response_PageReportResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_PageReportResponse();
    message.log = object.log ?? "";
    message.errors = object.errors ?? "";
    message.console = object.console ?? "";
    message.pageId = object.pageId ?? "";
    return message;
  }
};
var PlaywrightService = {
  /** Aria Snapshot */
  ariaSnapShot: {
    path: "/Playwright/AriaSnapShot",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_AriaSnapShot.encode(value).finish()),
    requestDeserialize: (value) => Request_AriaSnapShot.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Cookie messages */
  addCookie: {
    path: "/Playwright/AddCookie",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getCookies: {
    path: "/Playwright/GetCookies",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  deleteAllCookies: {
    path: "/Playwright/DeleteAllCookies",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Screen shot method */
  takeScreenshot: {
    path: "/Playwright/TakeScreenshot",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ScreenshotOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ScreenshotOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Opens the url in currently open Playwright page */
  goTo: {
    path: "/Playwright/GoTo",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_UrlOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_UrlOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Navigate to the next page in history */
  goBack: {
    path: "/Playwright/GoBack",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Navigate to the previous page in history. */
  goForward: {
    path: "/Playwright/GoForward",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets title of currently open Playwright page */
  getTitle: {
    path: "/Playwright/GetTitle",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Returns the count of elements found with selector */
  getElementCount: {
    path: "/Playwright/GetElementCount",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  /** Wraps playwrights page.type to type text into input specified with selector */
  typeText: {
    path: "/Playwright/TypeText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_TypeText.encode(value).finish()),
    requestDeserialize: (value) => Request_TypeText.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Wraps playwrights page.fill to fill text of input specified with selector */
  fillText: {
    path: "/Playwright/FillText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FillText.encode(value).finish()),
    requestDeserialize: (value) => Request_FillText.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Wraps playwrights page.fill with empty text to clear input specified with selector */
  clearText: {
    path: "/Playwright/ClearText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClearText.encode(value).finish()),
    requestDeserialize: (value) => Request_ClearText.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets the DOM property 'property' of selector specified element */
  getDomProperty: {
    path: "/Playwright/GetDomProperty",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementProperty.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementProperty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  getText: {
    path: "/Playwright/GetText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Gets the XML attribute 'attribute' of selector specified element */
  getElementAttribute: {
    path: "/Playwright/GetElementAttribute",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementProperty.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementProperty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Gets the boolean DOM property 'property' of selector specified element */
  getBoolProperty: {
    path: "/Playwright/GetBoolProperty",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementProperty.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementProperty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Bool.encode(value).finish()),
    responseDeserialize: (value) => Response_Bool.decode(value)
  },
  /** Wraps playwrights page.textContent, returns textcontent of element by selector */
  getViewportSize: {
    path: "/Playwright/GetViewportSize",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Returns current playwright page url */
  getUrl: {
    path: "/Playwright/GetUrl",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Gets page HTML code as a stream of Response.Json messages, with the source split into chunks via bodyPart */
  getPageSource: {
    path: "/Playwright/GetPageSource",
    requestStream: false,
    responseStream: true,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Inputs a list of keypresses to element specified by selector */
  press: {
    path: "/Playwright/Press",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_PressKeys.encode(value).finish()),
    requestDeserialize: (value) => Request_PressKeys.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets the Select element specified by selector and returns the contents */
  getSelectContent: {
    path: "/Playwright/GetSelectContent",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Select.encode(value).finish()),
    responseDeserialize: (value) => Response_Select.decode(value)
  },
  /** Selects option matching matcher in Select element matching selector */
  selectOption: {
    path: "/Playwright/SelectOption",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_SelectElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_SelectElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Select.encode(value).finish()),
    responseDeserialize: (value) => Response_Select.decode(value)
  },
  /** Deselects options in Select element matching selector */
  deselectOption: {
    path: "/Playwright/DeselectOption",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Checks checkbox specified by selector */
  checkCheckbox: {
    path: "/Playwright/CheckCheckbox",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Unchecks checkbox specified by selector */
  uncheckCheckbox: {
    path: "/Playwright/UncheckCheckbox",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Health check endpoint for the service */
  health: {
    path: "/Playwright/Health",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Returns a reference to a Playwirght element handle. */
  getElement: {
    path: "/Playwright/GetElement",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Returns references to multiple Playwirght element handles. */
  getElements: {
    path: "/Playwright/GetElements",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Returns references to a Playwirght element handle. */
  getByX: {
    path: "/Playwright/GetByX",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_GetByOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_GetByOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Returns all Element states as IntFlag */
  getElementStates: {
    path: "/Playwright/GetElementStates",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Set's  playwright timeout */
  setTimeout: {
    path: "/Playwright/SetTimeout",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Timeout.encode(value).finish()),
    requestDeserialize: (value) => Request_Timeout.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Adds a <style> to head of site. */
  addStyleTag: {
    path: "/Playwright/AddStyleTag",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_StyleTag.encode(value).finish()),
    requestDeserialize: (value) => Request_StyleTag.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Highlights elements matching selector for duration */
  highlightElements: {
    path: "/Playwright/HighlightElements",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithDuration.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithDuration.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  /** Download url content */
  download: {
    path: "/Playwright/Download",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Clicks element specified by selector and options */
  click: {
    path: "/Playwright/Click",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Taps element specified by selector and options */
  tap: {
    path: "/Playwright/Tap",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Hovers an element specified by selector and options */
  hover: {
    path: "/Playwright/Hover",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Focuses element specified by selector */
  focus: {
    path: "/Playwright/Focus",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Waits for element be in a specific state */
  waitForElementsState: {
    path: "/Playwright/WaitForElementsState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Executes javascript on the active page and retries until the expression is true */
  waitForFunction: {
    path: "/Playwright/WaitForFunction",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_WaitForFunctionOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_WaitForFunctionOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Evaluates javascript on the active page */
  evaluateJavascript: {
    path: "/Playwright/EvaluateJavascript",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_EvaluateAll.encode(value).finish()),
    requestDeserialize: (value) => Request_EvaluateAll.decode(value),
    responseSerialize: (value) => Buffer.from(Response_JavascriptExecutionResult.encode(value).finish()),
    responseDeserialize: (value) => Response_JavascriptExecutionResult.decode(value)
  },
  recordSelector: {
    path: "/Playwright/RecordSelector",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Label.encode(value).finish()),
    requestDeserialize: (value) => Request_Label.decode(value),
    responseSerialize: (value) => Buffer.from(Response_JavascriptExecutionResult.encode(value).finish()),
    responseDeserialize: (value) => Response_JavascriptExecutionResult.decode(value)
  },
  /** Get Page State JSON */
  setViewportSize: {
    path: "/Playwright/SetViewportSize",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Viewport.encode(value).finish()),
    requestDeserialize: (value) => Request_Viewport.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets an elements computed style */
  getStyle: {
    path: "/Playwright/GetStyle",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementStyle.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementStyle.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Gets elements x, y coordinates and width, height as json object */
  getBoundingBox: {
    path: "/Playwright/GetBoundingBox",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Makes a `fetch` request in the browser */
  httpRequest: {
    path: "/Playwright/HttpRequest",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_HttpRequest.encode(value).finish()),
    requestDeserialize: (value) => Request_HttpRequest.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  waitForRequest: {
    path: "/Playwright/WaitForRequest",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_HttpCapture.encode(value).finish()),
    requestDeserialize: (value) => Request_HttpCapture.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  waitForResponse: {
    path: "/Playwright/WaitForResponse",
    requestStream: false,
    responseStream: true,
    requestSerialize: (value) => Buffer.from(Request_HttpCapture.encode(value).finish()),
    requestDeserialize: (value) => Request_HttpCapture.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  waitForDownload: {
    path: "/Playwright/WaitForDownload",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  waitForNavigation: {
    path: "/Playwright/WaitForNavigation",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_UrlOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_UrlOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  waitForPageLoadState: {
    path: "/Playwright/WaitForPageLoadState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_PageLoadState.encode(value).finish()),
    requestDeserialize: (value) => Request_PageLoadState.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Geolocation */
  setGeolocation: {
    path: "/Playwright/SetGeolocation",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getDevice: {
    path: "/Playwright/GetDevice",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Device.encode(value).finish()),
    requestDeserialize: (value) => Request_Device.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getDevices: {
    path: "/Playwright/GetDevices",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Locator handlers */
  addLocatorHandlerCustom: {
    path: "/Playwright/AddLocatorHandlerCustom",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_LocatorHandlerAddCustom.encode(value).finish()),
    requestDeserialize: (value) => Request_LocatorHandlerAddCustom.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  removeLocatorHandler: {
    path: "/Playwright/RemoveLocatorHandler",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_LocatorHandlerRemove.encode(value).finish()),
    requestDeserialize: (value) => Request_LocatorHandlerRemove.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  handleAlert: {
    path: "/Playwright/HandleAlert",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_AlertAction.encode(value).finish()),
    requestDeserialize: (value) => Request_AlertAction.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  waitForAlerts: {
    path: "/Playwright/WaitForAlerts",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_AlertActions.encode(value).finish()),
    requestDeserialize: (value) => Request_AlertActions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_ListString.encode(value).finish()),
    responseDeserialize: (value) => Response_ListString.decode(value)
  },
  mouseButton: {
    path: "/Playwright/MouseButton",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_MouseButtonOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_MouseButtonOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  mouseMove: {
    path: "/Playwright/MouseMove",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  mouseWheel: {
    path: "/Playwright/MouseWheel",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_MouseWheel.encode(value).finish()),
    requestDeserialize: (value) => Request_MouseWheel.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  keyboardKey: {
    path: "/Playwright/KeyboardKey",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_KeyboardKeypress.encode(value).finish()),
    requestDeserialize: (value) => Request_KeyboardKeypress.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  keyboardInput: {
    path: "/Playwright/KeyboardInput",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_KeyboardInputOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_KeyboardInputOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getTableRowIndex: {
    path: "/Playwright/GetTableRowIndex",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  getTableCellIndex: {
    path: "/Playwright/GetTableCellIndex",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  uploadFile: {
    path: "/Playwright/UploadFile",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FilePath.encode(value).finish()),
    requestDeserialize: (value) => Request_FilePath.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  uploadFileBySelector: {
    path: "/Playwright/UploadFileBySelector",
    requestStream: true,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FileBySelector.encode(value).finish()),
    requestDeserialize: (value) => Request_FileBySelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  scrollToElement: {
    path: "/Playwright/ScrollToElement",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  setOffline: {
    path: "/Playwright/SetOffline",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  reload: {
    path: "/Playwright/Reload",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Playwright State handling keywords */
  switchPage: {
    path: "/Playwright/SwitchPage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_IdWithTimeout.encode(value).finish()),
    requestDeserialize: (value) => Request_IdWithTimeout.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  switchContext: {
    path: "/Playwright/SwitchContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Index.encode(value).finish()),
    requestDeserialize: (value) => Request_Index.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  switchBrowser: {
    path: "/Playwright/SwitchBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Index.encode(value).finish()),
    requestDeserialize: (value) => Request_Index.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  newPage: {
    path: "/Playwright/NewPage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_UrlOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_UrlOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_NewPageResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_NewPageResponse.decode(value)
  },
  newContext: {
    path: "/Playwright/NewContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Context.encode(value).finish()),
    requestDeserialize: (value) => Request_Context.decode(value),
    responseSerialize: (value) => Buffer.from(Response_NewContextResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_NewContextResponse.decode(value)
  },
  newBrowser: {
    path: "/Playwright/NewBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Browser.encode(value).finish()),
    requestDeserialize: (value) => Request_Browser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  launchBrowserServer: {
    path: "/Playwright/LaunchBrowserServer",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Browser.encode(value).finish()),
    requestDeserialize: (value) => Request_Browser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  closeBrowserServer: {
    path: "/Playwright/CloseBrowserServer",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ConnectBrowser.encode(value).finish()),
    requestDeserialize: (value) => Request_ConnectBrowser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  newPersistentContext: {
    path: "/Playwright/NewPersistentContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_PersistentContext.encode(value).finish()),
    requestDeserialize: (value) => Request_PersistentContext.decode(value),
    responseSerialize: (value) => Buffer.from(Response_NewPersistentContextResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_NewPersistentContextResponse.decode(value)
  },
  connectToBrowser: {
    path: "/Playwright/ConnectToBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ConnectBrowser.encode(value).finish()),
    requestDeserialize: (value) => Request_ConnectBrowser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  closeBrowser: {
    path: "/Playwright/CloseBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  closeAllBrowsers: {
    path: "/Playwright/CloseAllBrowsers",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  closeContext: {
    path: "/Playwright/CloseContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  closePage: {
    path: "/Playwright/ClosePage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClosePage.encode(value).finish()),
    requestDeserialize: (value) => Request_ClosePage.decode(value),
    responseSerialize: (value) => Buffer.from(Response_PageReportResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_PageReportResponse.decode(value)
  },
  openTraceGroup: {
    path: "/Playwright/OpenTraceGroup",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_TraceGroup.encode(value).finish()),
    requestDeserialize: (value) => Request_TraceGroup.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  closeTraceGroup: {
    path: "/Playwright/CloseTraceGroup",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  setRfContext: {
    path: "/Playwright/SetRFContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_RFContext.encode(value).finish()),
    requestDeserialize: (value) => Request_RFContext.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getConsoleLog: {
    path: "/Playwright/GetConsoleLog",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getErrorMessages: {
    path: "/Playwright/GetErrorMessages",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getBrowserCatalog: {
    path: "/Playwright/GetBrowserCatalog",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getDownloadState: {
    path: "/Playwright/GetDownloadState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadID.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadID.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  cancelDownload: {
    path: "/Playwright/CancelDownload",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadID.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadID.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  saveStorageState: {
    path: "/Playwright/SaveStorageState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FilePath.encode(value).finish()),
    requestDeserialize: (value) => Request_FilePath.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  grantPermissions: {
    path: "/Playwright/GrantPermissions",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Permissions.encode(value).finish()),
    requestDeserialize: (value) => Request_Permissions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  executePlaywright: {
    path: "/Playwright/ExecutePlaywright",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  clearPermissions: {
    path: "/Playwright/ClearPermissions",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Extension handling */
  initializeExtension: {
    path: "/Playwright/InitializeExtension",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FilePath.encode(value).finish()),
    requestDeserialize: (value) => Request_FilePath.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Keywords.encode(value).finish()),
    responseDeserialize: (value) => Response_Keywords.decode(value)
  },
  callExtensionKeyword: {
    path: "/Playwright/CallExtensionKeyword",
    requestStream: false,
    responseStream: true,
    requestSerialize: (value) => Buffer.from(Request_KeywordCall.encode(value).finish()),
    requestDeserialize: (value) => Request_KeywordCall.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  setPeerId: {
    path: "/Playwright/SetPeerId",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Index.encode(value).finish()),
    requestDeserialize: (value) => Request_Index.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** pdf */
  pdf: {
    path: "/Playwright/Pdf",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Pdf.encode(value).finish()),
    requestDeserialize: (value) => Request_Pdf.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  emulateMedia: {
    path: "/Playwright/EmulateMedia",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_EmulateMedia.encode(value).finish()),
    requestDeserialize: (value) => Request_EmulateMedia.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Clock messages */
  setTime: {
    path: "/Playwright/SetTime",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClockSetTime.encode(value).finish()),
    requestDeserialize: (value) => Request_ClockSetTime.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  clockResume: {
    path: "/Playwright/ClockResume",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  clockPauseAt: {
    path: "/Playwright/ClockPauseAt",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClockSetTime.encode(value).finish()),
    requestDeserialize: (value) => Request_ClockSetTime.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  advanceClock: {
    path: "/Playwright/AdvanceClock",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClockAdvance.encode(value).finish()),
    requestDeserialize: (value) => Request_ClockAdvance.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Coverage */
  startCoverage: {
    path: "/Playwright/StartCoverage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_CoverageStart.encode(value).finish()),
    requestDeserialize: (value) => Request_CoverageStart.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  stopCoverage: {
    path: "/Playwright/StopCoverage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  mergeCoverage: {
    path: "/Playwright/MergeCoverage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_CoverageMerge.encode(value).finish()),
    requestDeserialize: (value) => Request_CoverageMerge.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  }
};
var PlaywrightClient = (0, import_grpc_js.makeGenericClientConstructor)(PlaywrightService, "Playwright");
function isSet(value) {
  return value !== null && value !== void 0;
}

// node/playwright-wrapper/playwright-invoke.ts
async function findLocator(state, selector, strictMode, firstOnly) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  if (strictMode) {
    selector = selector.replaceAll(" >>> ", " >> internal:control=enter-frame >> ");
  } else {
    selector = selector.replaceAll(" >>> ", " >> nth=0 >> internal:control=enter-frame >> ");
  }
  if (strictMode) {
    logger.info(`Strict mode is enabled, find Locator with ${selector} in page.`);
    return activePage.locator(selector);
  } else {
    return await findLocatorNotStrict(activePage, selector, firstOnly);
  }
}
async function findLocatorNotStrict(activePage, selector, firstOnly) {
  if (firstOnly) {
    logger.info(`Strict mode is disabled, return first Locator: ${selector} in page.`);
    return activePage.locator(selector).first();
  } else {
    logger.info(`Strict mode is disabled, return Locator: ${selector} in page.`);
    return activePage.locator(selector);
  }
}
async function invokeOnMouse(page, methodName, args2) {
  exists(page, `Tried to execute mouse action '${methodName}' but no open page`);
  logger.info(`Invoking mouse action ${methodName} with params ${JSON.stringify(args2)}`);
  const fn = page?.mouse[methodName].bind(page.mouse);
  exists(fn, `Bind failure with '${fn}'`);
  return await fn(...Object.values(args2));
}
async function invokeOnKeyboard(page, methodName, ...args2) {
  logger.info(`Invoking keyboard action ${methodName} with params ${JSON.stringify(args2)}`);
  const fn = page.keyboard[methodName].bind(page.keyboard);
  exists(fn, `Bind failure with '${fn}'`);
  return await fn(...Object.values(args2));
}
function exists(obj, message) {
  if (!obj) {
    throw new Error(message);
  }
}

// node/playwright-wrapper/response-util.ts
var import_grpc_js2 = require("@grpc/grpc-js");
var import_playwright = require("playwright");
function emptyWithLog(text) {
  return { log: text };
}
function pageReportResponse(log, page) {
  return {
    log,
    console: JSON.stringify(
      page.consoleMessages.map((m) => ({
        time: m.time,
        type: m.type,
        text: m.text,
        location: m.location
      }))
    ),
    errors: JSON.stringify(
      page.pageErrors.map((e) => e ? `${e.name}: ${e.message}
${e.stack}` : "unknown error")
    ),
    pageId: page.id
  };
}
function getConsoleLogResponse(page, fullLog, message) {
  const consoleMessages = page.consoleMessages;
  const responseMessages = fullLog ? consoleMessages : consoleMessages.slice(page.consoleIndex);
  page.consoleIndex = consoleMessages.length;
  return { log: message, json: JSON.stringify(responseMessages), bodyPart: "" };
}
function getErrorMessagesResponse(page, fullLog, message) {
  const pageErrors = page.pageErrors;
  const responseErrors = fullLog ? pageErrors : pageErrors.slice(page.errorIndex);
  page.errorIndex = pageErrors.length;
  return { log: message, json: JSON.stringify(responseErrors), bodyPart: "" };
}
function stringResponse(body, logMessage) {
  return { body, log: logMessage };
}
function jsonResponse(body, logMessage, bodyPart = "") {
  return { json: body, log: logMessage, bodyPart };
}
function intResponse(body, logMessage) {
  return { body, log: logMessage };
}
function boolResponse(value, logMessage) {
  return { body: value, log: logMessage };
}
function jsResponse(result, logMessage) {
  return { result: JSON.stringify(result), log: logMessage };
}
function errorResponse(e) {
  logger.error(
    { event_kind: "grpc_error", status: "failed", error_type: errorType(e) },
    e instanceof Error ? e.stack ?? e.message : String(e)
  );
  if (!(e instanceof Error)) return null;
  const errorMessage = e.toString().substring(0, 5e3);
  let errorCode = import_grpc_js2.status.RESOURCE_EXHAUSTED;
  if (e instanceof import_playwright.errors.TimeoutError) {
    errorCode = import_grpc_js2.status.DEADLINE_EXCEEDED;
  }
  return { code: errorCode, message: errorMessage };
}
function keywordsResponse(keywords, keywordArguments, keywordDocs, logMessage) {
  return {
    keywords,
    keywordDocumentations: keywordDocs,
    keywordArguments,
    log: logMessage
  };
}
function parseRegExpOrKeepString(str) {
  const regex = /^\/(?<matcher>.*)\/(?<flags>[gimsuy]+)?$/;
  try {
    const match = str.match(regex);
    if (match) {
      const { matcher, flags } = match.groups;
      return new RegExp(matcher, flags);
    }
    return str;
  } catch {
    return str;
  }
}

// node/playwright-wrapper/browser-control.ts
var { libCli } = require("playwright-core/lib/coreBundle");
var { Command: PlaywrightCommand } = require_commander();
async function executePlaywright(request) {
  const args2 = JSON.parse(request.body);
  const pwProgram = new PlaywrightCommand();
  libCli.decorateProgram(pwProgram);
  pwProgram.exitOverride();
  await pwProgram.parseAsync(args2, { from: "user" });
  return emptyWithLog("Executed Playwright command: " + args2.join(" "));
}
async function grantPermissions(request, state) {
  const browserContext = state.getActiveContext();
  if (!browserContext) {
    return emptyWithLog(`No browser context is active. Use 'Open Browser' to open a new one.`);
  }
  await browserContext.grantPermissions(request.permissions, {
    ...request.origin.length > 0 && { origin: request.origin }
  });
  return emptyWithLog(
    `Granted permissions "${request.permissions.join(", ")}"` + (request.origin.length > 0 ? ` for origin "${request.origin}"` : "")
  );
}
async function clearPermissions(request, state) {
  const browserContext = state.getActiveContext();
  if (!browserContext) {
    return emptyWithLog(`No browser context is active. Use 'Open Browser' to open a new one.`);
  }
  await browserContext.clearPermissions();
  return emptyWithLog("Cleared all permissions");
}
async function goTo(request, page) {
  const url = request.url?.url || "about:blank";
  const timeout = request.url?.defaultTimeout;
  const goToOptions = { timeout };
  const waitUntil = request.waitUntil;
  if (waitUntil) {
    goToOptions.waitUntil = waitUntil;
  }
  const response = await page.goto(url, goToOptions);
  return stringResponse(response?.status().toString() || "", `Successfully opened URL ${url}`);
}
async function takeScreenshot(request, state) {
  const selector = request.selector;
  const options = JSON.parse(request.options);
  const mask = JSON.parse(request.mask);
  const strictMode = request.strict;
  const page = state.getActivePage();
  exists(page, "Tried to take screenshot, but no page was open.");
  if (mask) {
    const mask_locators = [];
    for (const sel of mask) {
      mask_locators.push(await findLocator(state, sel, false, false));
    }
    options.mask = mask_locators;
  }
  logger.info({ "Take screenshot with options: ": options });
  if (selector) {
    logger.info({ "Using selecotr: ": selector });
    const locator = await findLocator(state, selector, strictMode, true);
    await locator.screenshot(options);
  } else {
    await page.screenshot(options);
  }
  const message = "Screenshot successfully captured to: " + options.path;
  return stringResponse(options.path, message);
}
async function setTimeout2(request, context) {
  if (!context) {
    return emptyWithLog(`No context open.`);
  }
  const timeout = request.timeout;
  context.setDefaultTimeout(timeout);
  return emptyWithLog(`Set timeout to: ${timeout}`);
}
async function setViewportSize(request, page) {
  const size = { width: request.width, height: request.height };
  await page.setViewportSize(size);
  return emptyWithLog(`Set viewport size to: ${JSON.stringify(size)}`);
}
async function setOffline(request, context) {
  exists(context, "Tried to toggle context to offline, no open context");
  const offline = request.value;
  await context.setOffline(offline);
  return emptyWithLog(`Set context to ${offline}`);
}
async function reload(page, body) {
  const options = JSON.parse(body);
  logger.info(`Reload page with options: ${body}`);
  await page.reload(options);
  return emptyWithLog(`Reloaded page with options: ${body}`);
}
async function setGeolocation(request, context) {
  const geolocation = JSON.parse(request.body);
  await context?.setGeolocation(geolocation);
  return emptyWithLog("Geolocation set to: " + JSON.stringify(geolocation));
}

// node/playwright-wrapper/clock.ts
async function setTime(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  let time = request.time;
  time = time * 1e3;
  const clockType = request.setType;
  const setTime2 = new Date(time).toISOString();
  if (clockType === "fixed") {
    logger.info(`Setting time to ${time} ${setTime2} as fixed`);
    await activePage.clock.setFixedTime(time);
  } else if (clockType === "system") {
    logger.info(`Setting time to ${time} ${setTime2} as system`);
    await activePage.clock.setSystemTime(time);
  } else if (clockType === "install") {
    logger.info(`Setting time to ${time} ${setTime2} as install`);
    await activePage.clock.install({ time });
  } else {
    logger.info(`Invalid clock type ${clockType}`);
    return emptyWithLog("Invalid clock type");
  }
  return emptyWithLog(`Time set to ${setTime2} as ${clockType}`);
}
async function clockResume(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  await activePage.clock.resume();
  return emptyWithLog("Clock resumed");
}
async function clockPauseAt(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  let time = request.time;
  time = time * 1e3;
  const setTime2 = new Date(time).toISOString();
  logger.info(`Pausing clock at ${time} ${setTime2}`);
  await activePage.clock.pauseAt(time);
  return emptyWithLog(`Clock paused at ${setTime2}`);
}
async function advanceClock(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const time = request.time;
  const timeMs = time * 1e3;
  const advanceType = request.advanceType;
  logger.info(`Advancing clock by ${timeMs} ${advanceType}`);
  if (advanceType === "fast_forward") {
    await activePage.clock.fastForward(timeMs);
  } else if (advanceType === "run_for") {
    await activePage.clock.runFor(timeMs);
  }
  return emptyWithLog(`Clock advanced by ${timeMs} seconds by ${advanceType}`);
}

// node/playwright-wrapper/cookie.ts
async function getCookies(context) {
  const allCookies = await context.cookies();
  logger.info({ "Cookies: ": allCookies });
  const cookieName = [];
  for (const cookie of allCookies) {
    cookieName.push(cookie.name);
  }
  return jsonResponse(JSON.stringify(allCookies), cookieName.toString());
}
async function addCookie(request, context) {
  const cookie = JSON.parse(request.body);
  logger.info({ "Cookie data: ": request.body });
  await context.addCookies([cookie]);
  return emptyWithLog('Cookie "' + cookie.name + '" added.');
}
async function deleteAllCookies(context) {
  await context.clearCookies();
  return emptyWithLog("All cookies deleted.");
}

// node/playwright-wrapper/device-descriptors.ts
var import_playwright2 = require("playwright");
function getDevice(request) {
  const name = request.name;
  const device = import_playwright2.devices[name];
  if (!device) throw new Error(`No device named ${name}`);
  return jsonResponse(JSON.stringify(device), "");
}
function getDevices() {
  return jsonResponse(JSON.stringify(import_playwright2.devices), "");
}

// node/playwright-wrapper/evaluation.ts
var path2 = __toESM(require("path"));

// node/playwright-wrapper/network.ts
var path = __toESM(require("path"));

// node_modules/uuid/dist-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

// node_modules/uuid/dist-node/rng.js
var rnds8 = new Uint8Array(16);
function rng() {
  return crypto.getRandomValues(rnds8);
}

// node_modules/uuid/dist-node/v4.js
function v4(options, buf, offset) {
  if (!buf && !options && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return _v4(options, buf, offset);
}
function _v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random ?? options.rng?.() ?? rng();
  if (rnds.length < 16) {
    throw new Error("Random bytes length must be >= 16");
  }
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    if (offset < 0 || offset + 16 > buf.length) {
      throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
    }
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// node/playwright-wrapper/chunking.ts
var MAX_RESPONSE_CHUNK_BYTES = 1e6;
function splitUtf8ByMaxBytes(text, maxBytes) {
  if (!text) {
    return [];
  }
  const chunks = [];
  let current = "";
  let currentBytes = 0;
  for (const char of text) {
    const charBytes = Buffer.byteLength(char, "utf8");
    if (currentBytes + charBytes > maxBytes && current.length > 0) {
      chunks.push(current);
      current = char;
      currentBytes = charBytes;
    } else {
      current += char;
      currentBytes += charBytes;
    }
  }
  if (current.length > 0) {
    chunks.push(current);
  }
  return chunks;
}

// node/playwright-wrapper/network.ts
async function httpRequest(request, page) {
  const opts = {
    method: request.method,
    url: request.url,
    headers: JSON.parse(request.headers)
  };
  if (opts.method != "GET") {
    opts.body = request.body;
  }
  const response = await page.evaluate(({ url, method, body, headers }) => {
    return fetch(url, { method, body, headers }).then((data) => {
      return data.text().then((body2) => {
        const headers2 = {};
        data.headers.forEach((value, name) => headers2[name] = value);
        return {
          status: data.status,
          body: body2,
          headers: JSON.stringify(headers2),
          type: data.type,
          statusText: data.statusText,
          url: data.url,
          ok: data.ok,
          redirected: data.redirected
        };
      });
    });
  }, opts);
  return jsonResponse(JSON.stringify(response), "Request performed successfully.");
}
function deserializeUrlOrPredicate(urlOrPredicate) {
  if (/^function.*{.*}$/.test(urlOrPredicate) || /([a-zA-Z]\w*|\([a-zA-Z]\w*(,\s*[a-zA-Z]\w*)*\)) =>/.test(urlOrPredicate)) {
    const fn = new Function(`return (${urlOrPredicate})`)();
    if (typeof fn === "function" || Object.prototype.toString.call(fn) === "[object Function]") {
      return fn;
    }
  }
  return parseRegExpOrKeepString(urlOrPredicate);
}
async function waitForResponse(request, page) {
  const urlOrPredicate = deserializeUrlOrPredicate(request.urlOrPredicate);
  const timeout = request.timeout;
  const data = await page.waitForResponse(urlOrPredicate, { timeout });
  let body = null;
  try {
    body = await data.text();
  } catch (e) {
    logger.info(`Error reading response ${String(e)}`);
  }
  const jsonData = JSON.stringify({
    status: data.status(),
    headers: JSON.stringify(data.headers()),
    statusText: data.statusText(),
    url: data.url(),
    ok: data.ok(),
    request: {
      headers: JSON.stringify(data.request().headers()),
      method: data.request().method(),
      postData: data.request().postData()
    }
  });
  const responseChunks = [];
  if (body !== null) {
    const bodyChunks = splitUtf8ByMaxBytes(body, MAX_RESPONSE_CHUNK_BYTES);
    if (bodyChunks.length > 1) {
      logger.info(`body.length: ${body.length}`);
      for (let i = 0; i < bodyChunks.length; i++) {
        const response = jsonResponse(jsonData, `Response received, chunk ${i}`, bodyChunks[i]);
        logger.info(`chunked response: ${i}`);
        responseChunks.push(response);
      }
    } else {
      responseChunks.push(jsonResponse(jsonData, "Response received", body));
    }
  } else {
    const jsonDataMap = JSON.parse(jsonData);
    jsonDataMap.body = null;
    responseChunks.push(jsonResponse(JSON.stringify(jsonDataMap), "Response received with empty body", ""));
  }
  logger.info(`responseChunks.length: ${responseChunks.length}`);
  return responseChunks;
}
async function waitForRequest(request, page) {
  const urlOrPredicate = deserializeUrlOrPredicate(request.urlOrPredicate);
  const timeout = request.timeout;
  const result = await page.waitForRequest(urlOrPredicate, { timeout });
  return stringResponse(result.url(), "Request completed within timeout.");
}
async function waitForNavigation(request, page) {
  const url = parseRegExpOrKeepString(request.url?.url);
  const timeout = request.url?.defaultTimeout;
  const waitUntil = request.waitUntil;
  await page.waitForNavigation({ timeout, url, waitUntil });
  return emptyWithLog(`Navigated to: ${url}, location is: ${page.url()}`);
}
async function WaitForPageLoadState(request, page) {
  const state = request.state;
  const timeout = request.timeout;
  logger.info(`timeout: ${timeout} state: ${state}`);
  await page.waitForLoadState(state, { timeout });
  return emptyWithLog(`Load state ${state} got in ${timeout}`);
}
async function waitForDownload(request, state, page) {
  const saveAs = request.path;
  const waitForFinish = request.waitForFinish;
  const downloadTimeout = request.downloadTimeout;
  return await _waitForDownload(page, state, saveAs, downloadTimeout, waitForFinish);
}
async function _waitForDownload(page, state, saveAs, downloadTimeout, waitForFinished) {
  const downloadObject = await page.waitForEvent("download");
  const downloadsPath = state.activeBrowser.browser?._options?.downloadsPath;
  if (downloadsPath && saveAs) {
    logger.info("saveAs: " + path.resolve(downloadsPath, saveAs));
    if (!path.isAbsolute(saveAs)) {
      saveAs = path.resolve(downloadsPath, saveAs);
    }
  }
  const fileName = downloadObject.suggestedFilename();
  if (!waitForFinished) {
    const downloadID = v4_default();
    const activeIndexedPage = state.activeBrowser?.page;
    if (activeIndexedPage) {
      activeIndexedPage.activeDownloads.set(downloadID, {
        downloadObject,
        suggestedFilename: fileName,
        saveAs
      });
      return jsonResponse(
        JSON.stringify({
          saveAs: "",
          suggestedFilename: fileName,
          state: "in_progress",
          downloadID
        }),
        "Download started successfully."
      );
    } else {
      throw new Error("No active page found");
    }
  }
  if (downloadTimeout > 0) {
    const readStream = await Promise.race([
      downloadObject.createReadStream(),
      new Promise((resolve2) => setTimeout(resolve2, downloadTimeout))
    ]);
    if (!readStream) {
      await downloadObject.cancel();
      throw new Error("Download failed, Timeout exceeded.");
    }
  }
  let filePath;
  if (saveAs) {
    await downloadObject.saveAs(saveAs);
    filePath = path.resolve(saveAs);
  } else {
    filePath = await downloadObject.path();
  }
  logger.info("suggestedFilename: " + fileName + " saveAs path: " + filePath);
  return jsonResponse(
    JSON.stringify({ saveAs: filePath, suggestedFilename: fileName, state: "finished", downloadID: null }),
    "Download done successfully to: " + filePath
  );
}
async function getDownloadState(request, state) {
  const downloadID = request.id;
  const activeIndexedPage = state.activeBrowser?.page;
  if (!activeIndexedPage) {
    throw new Error("No active page found");
  }
  const downloadInfo = activeIndexedPage.activeDownloads.get(downloadID);
  if (!downloadInfo) {
    throw new Error("No download object found for id: " + downloadID);
  }
  const downloadObject = downloadInfo.downloadObject;
  const suggestedFilename = downloadInfo.suggestedFilename;
  const failure = await Promise.race([downloadObject.failure(), new Promise((resolve2) => setTimeout(resolve2, 50))]);
  if (failure === null) {
    const saveAs = downloadInfo.saveAs;
    let filePath;
    if (saveAs) {
      await downloadObject.saveAs(saveAs);
      filePath = path.resolve(saveAs);
    } else {
      filePath = await downloadObject.path();
    }
    return jsonResponse(
      JSON.stringify({
        saveAs: filePath,
        suggestedFilename,
        state: "finished",
        downloadID
      }),
      "Download state received"
    );
  } else if (failure) {
    return jsonResponse(
      JSON.stringify({
        saveAs: "",
        suggestedFilename,
        state: failure,
        downloadID
      }),
      "Download state received"
    );
  } else {
    return jsonResponse(
      JSON.stringify({
        saveAs: "",
        suggestedFilename,
        state: "in_progress",
        downloadID
      }),
      "Download state received"
    );
  }
}
async function cancelDownload(request, state) {
  const downloadID = request.id;
  const activeIndexedPage = state.activeBrowser?.page;
  if (!activeIndexedPage) {
    throw new Error("No active page found");
  }
  const downloadInfo = activeIndexedPage.activeDownloads.get(downloadID);
  if (!downloadInfo) {
    throw new Error("No download object found for id: " + downloadID);
  }
  const downloadObject = downloadInfo.downloadObject;
  await downloadObject.cancel();
  const failure = await downloadObject.failure();
  if (failure == "canceled") {
    return emptyWithLog("Download canceled successfully.");
  } else if (failure === null) {
    return emptyWithLog("Canceling download not possible anymore, download finished.");
  } else {
    return emptyWithLog(`Canceling download not possible anymore, download ${failure}.`);
  }
}

// node/playwright-wrapper/evaluation.ts
async function getElement(request, state) {
  const strictMode = request.strict;
  const selector = request.selector;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.waitFor({ state: "attached" });
  return stringResponse(locator._selector, "Locator found successfully.");
}
async function getElements(request, state) {
  const selector = request.selector;
  const locator = await findLocator(state, selector, false, false);
  logger.info(`Wait element to reach attached state.`);
  try {
    await locator.first().waitFor({ state: "attached" });
  } catch (e) {
    logger.debug(`Attached state not reached, suppress error: ${String(e)}.`);
  }
  const allLocators = await locator.all();
  logger.info(`Found ${allLocators.length} elements.`);
  const allSelectors = allLocators.map((locator2) => locator2._selector);
  return jsonResponse(JSON.stringify(allSelectors), `Found ${allLocators.length} Locators successfully.`);
}
async function getByX(request, state) {
  const strategy = request.strategy;
  const text = parseRegExpOrKeepString(request.text);
  const options = JSON.parse(request.options);
  const strictMode = request.strict;
  const allElements = request.all;
  const frameSelector = request.frameSelector;
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  let document2 = activePage;
  if (frameSelector) {
    document2 = activePage.frameLocator(frameSelector);
    if (!strictMode) {
      document2 = document2.first();
    }
  }
  let locator;
  switch (strategy) {
    case "AltText": {
      locator = document2.getByAltText(text, options);
      break;
    }
    case "Label": {
      locator = document2.getByLabel(text, options);
      break;
    }
    case "Placeholder": {
      locator = document2.getByPlaceholder(text, options);
      break;
    }
    case "Role": {
      if (options?.name) {
        options.name = parseRegExpOrKeepString(options.name);
      }
      locator = document2.getByRole(text, options);
      break;
    }
    case "TestId": {
      locator = document2.getByTestId(text);
      break;
    }
    case "Text": {
      locator = document2.getByText(text, options);
      break;
    }
    case "Title": {
      locator = document2.getByTitle(text, options);
      break;
    }
    default: {
      throw new Error(`Strategy ${strategy} not supported.`);
    }
  }
  if (!allElements) {
    if (!strictMode) {
      locator = locator.first();
    }
    await locator.waitFor({ state: "attached" });
    return jsonResponse(JSON.stringify(locator._selector), "Locator found successfully.");
  }
  let allSelectors = [];
  try {
    await locator.first().waitFor({ state: "attached" });
    allSelectors = await locator.all().then((locators) => locators.map((loc) => loc._selector));
  } catch (e) {
    logger.debug(`Attached state not reached, suppress error: ${String(e)}.`);
  }
  return jsonResponse(JSON.stringify(allSelectors), `${allSelectors.length} locators found successfully.`);
}
var tryToTransformStringToFunction = (str) => {
  try {
    return new Function("return " + str)();
  } catch (ignored) {
    logger.debug(`Failed to transform string to function: ${String(ignored)}`);
    return str;
  }
};
async function evaluateJavascript(request, state, page) {
  const selector = request.selector;
  const script = tryToTransformStringToFunction(request.script);
  const strictMode = request.strict;
  const arg = JSON.parse(request.arg);
  const allElements = request.allElements;
  async function getJSResult() {
    if (selector !== "") {
      const locator = await findLocator(state, selector, strictMode, !allElements);
      if (allElements) {
        return await locator.evaluateAll(script, arg);
      }
      return await locator.evaluate(script, arg);
    }
    return await page.evaluate(script, arg);
  }
  return jsResponse(await getJSResult(), "JavaScript executed successfully.");
}
async function waitForElementState(request, state) {
  const selector = request.selector;
  const { state: elementState, timeout } = JSON.parse(request.options);
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  if (elementState === "detached" || elementState === "attached" || elementState === "hidden" || elementState === "visible") {
    await locator.waitFor({ state: elementState, timeout });
  } else {
    const element = await locator.elementHandle({ timeout });
    await element?.waitForElementState(elementState, { timeout });
  }
  return emptyWithLog(`Waited for Element with selector ${selector} at state ${elementState}`);
}
async function waitForFunction(request, state, page) {
  const script = tryToTransformStringToFunction(request.script);
  const selector = request.selector;
  const options = JSON.parse(request.options);
  const strictMode = request.strict;
  logger.info(`unparsed args: ${request.script}, ${request.selector}, ${request.options}`);
  let elem;
  if (selector) {
    const locator = await findLocator(state, selector, strictMode, true);
    elem = await locator.elementHandle();
  }
  const result = await page.waitForFunction(script, elem, options);
  return jsonResponse(JSON.stringify(await result.jsonValue()), "Wait For Function completed successfully.");
}
async function addStyleTag(request, page) {
  const content = request.content;
  await page.addStyleTag({ content });
  return emptyWithLog("added Style: " + content);
}
var selectorsForPage = {};
async function recordSelector(request, state) {
  if (state.getActiveBrowser().headless) {
    throw Error("Record Selector works only with visible browser. Use Open Browser or New Browser  headless=False");
  }
  const activeBrowser = state.activeBrowser;
  if (!activeBrowser) {
    throw Error("No active browser.");
  }
  const indexedPage2 = activeBrowser.page;
  if (!indexedPage2) {
    throw Error("No active page.");
  }
  const page = indexedPage2.p;
  await page.bringToFront();
  if (!(indexedPage2.id in selectorsForPage)) {
    const myselectors = [];
    selectorsForPage[indexedPage2.id] = myselectors;
    await page.exposeFunction("setRecordedSelector", (index, item) => {
      while (myselectors.length > index) {
        myselectors.pop();
      }
      myselectors.push(item);
    });
    await page.exposeFunction("getRecordedSelectors", () => {
      return myselectors;
    });
    await page.exposeFunction("highlightPWSelector", (selector) => {
      void highlightAll(selector, 1e3, "3px", "dotted", "blue", false, state);
    });
  }
  const result = await recordSelectorIterator(request.label, page.mainFrame());
  while (selectorsForPage[indexedPage2.id].length) {
    selectorsForPage[indexedPage2.id].pop();
  }
  return jsResponse(result, "Selector recorded.");
}
async function attachSelectorFinderScript(frame) {
  try {
    await frame.addScriptTag({
      type: "module",
      path: path2.join(__dirname, "/static/selector-finder.js")
    });
  } catch (e) {
    throw new Error(
      `Adding selector recorder to page failed.
Try New Context  bypassCSP=True and retry recording.`,
      { cause: e }
    );
  }
  await Promise.all(frame.childFrames().map((child) => attachSelectorFinderScript(child)));
}
async function attachSubframeListeners(subframe, index) {
  await subframe.evaluate((index2) => {
    function rafAsync() {
      return new Promise((resolve2) => {
        requestAnimationFrame(resolve2);
      });
    }
    function waitUntilRecorderAvailable() {
      if (!window.subframeSelectorRecorderFindSelector) {
        return rafAsync().then(() => waitUntilRecorderAvailable());
      } else {
        return Promise.resolve(window.subframeSelectorRecorderFindSelector(index2));
      }
    }
    return waitUntilRecorderAvailable();
  }, index);
  await Promise.all(
    subframe.childFrames().filter((f) => f.parentFrame() === subframe).map((child) => attachSubframeListeners(child, index + 1))
  );
}
async function recordSelectorIterator(label, frame) {
  await attachSelectorFinderScript(frame);
  await Promise.all(
    frame.childFrames().filter((f) => f.parentFrame() === frame).map((child) => attachSubframeListeners(child, 1))
  );
  return await frame.evaluate((label2) => {
    function rafAsync() {
      return new Promise((resolve2) => {
        requestAnimationFrame(resolve2);
      });
    }
    function waitUntilRecorderAvailable() {
      if (!window.selectorRecorderFindSelector) {
        return rafAsync().then(() => waitUntilRecorderAvailable());
      } else {
        return Promise.resolve(window.selectorRecorderFindSelector(label2));
      }
    }
    return waitUntilRecorderAvailable();
  }, label);
}
async function highlightElements(request, state) {
  const selector = request.selector;
  const duration = request.duration;
  const width = request.width;
  const style = request.style;
  const color = request.color;
  const strictMode = request.strict;
  const mode = request.mode;
  const count = await highlightAll(
    selector,
    duration,
    width,
    style,
    color,
    strictMode,
    state,
    mode
  );
  const message = duration ? `Highlighted ${count} elements for ${duration} ms.` : `Highlighting ${count} elements`;
  return intResponse(count, message);
}
var HighlightDisposableCache = class {
  disposables;
  constructor() {
    this.disposables = [];
  }
  add(disposable) {
    this.disposables.push(disposable);
  }
  async disposeAll() {
    await Promise.all(this.disposables.map((d) => d.dispose()));
    this.disposables = [];
  }
};
var highlightDisposableCache = new HighlightDisposableCache();
async function highlightAll(selector, duration, width, style, color, strictMode, state, mode = "border") {
  const locator = await findLocator(state, selector, strictMode, false);
  let count;
  try {
    count = await locator.count();
  } catch (e) {
    logger.info(e);
    return 0;
  }
  if (selector === "ROBOT_FRAMEWORK_BROWSER_NO_ELEMENT") {
    logger.info(`Dispose all highlights because ROBOT_FRAMEWORK_BROWSER_NO_ELEMENT selector was used.`);
    await highlightDisposableCache.disposeAll();
    return 0;
  }
  logger.info(`Locator count is ${count}`);
  if (["playwright", "both"].includes(mode)) {
    const highlight = await locator.highlight();
    if (duration === 0) {
      logger.info(`Adding highlight to cache without timeout, it will be disposed later.`);
      highlightDisposableCache.add(highlight);
    }
    if (duration !== 0) {
      setTimeout(() => {
        logger.info(`Disposing highlight after ${duration} ms.`);
        void highlight.dispose();
      }, duration);
    }
    if (mode === "playwright") {
      return count;
    }
  }
  await locator.evaluateAll(
    (elements, options) => {
      elements.forEach((e) => {
        const d = document.createElement("div");
        d.className = "robotframework-browser-highlight";
        d.appendChild(document.createTextNode(""));
        d.style.position = "fixed";
        const rect = e.getBoundingClientRect();
        d.style.zIndex = "2147483647";
        d.style.top = `calc(${rect.top}px - ${options?.wdt ?? "1px"})`;
        d.style.left = `calc(${rect.left}px - ${options?.wdt ?? "1px"})`;
        d.style.width = `${rect.width}px`;
        d.style.height = `${rect.height}px`;
        d.style.border = `${options?.wdt ?? "1px"} ${options?.stl ?? `dotted`} ${options?.clr ?? `blue`}`;
        d.style.boxSizing = "content-box";
        document.body.appendChild(d);
        if (options?.dur !== 0) {
          setTimeout(() => {
            d.remove();
          }, options?.dur ?? 5e3);
        }
      });
    },
    { dur: duration, wdt: width, stl: style, clr: color }
  );
  return count;
}
async function download(request, state) {
  const browserState = state.activeBrowser;
  if (browserState === void 0) {
    throw new Error("Download requires an active browser");
  }
  const context = browserState.context;
  if (context === void 0) {
    throw new Error("Download requires an active context");
  }
  if (!(context.options?.acceptDownloads ?? false)) {
    throw new Error("Context acceptDownloads is false");
  }
  const page = state.getActivePage();
  if (page === void 0) {
    throw new Error("Download requires an active page");
  }
  const urlString = request.url;
  const saveAs = request.path;
  const downloadTimeout = request.downloadTimeout;
  const waitForFinish = request.waitForFinish;
  const fromUrl = page.url();
  if (fromUrl === "about:blank") {
    throw new Error("Download requires that the page has been navigated to an url");
  }
  const script = (urlString2) => {
    return fetch(urlString2).then((resp) => {
      return resp.blob();
    }).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = urlString2;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      return a.download;
    });
  };
  const downloadStarted = _waitForDownload(page, state, saveAs, downloadTimeout, waitForFinish);
  logger.info(`Starting download from ${urlString} to ${saveAs}`);
  await page.evaluate(script, urlString);
  return await downloadStarted;
}

// node/playwright-wrapper/getters.ts
var import_playwright3 = require("playwright");
async function getAriaSnapshot(request, state) {
  const selector = request.locator;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  const snapshot = await locator.ariaSnapshot();
  logger.info(`Aria snapshot for ${selector}: ${snapshot}`);
  return stringResponse(snapshot, "Aria snapshot received successfully.");
}
async function getTitle(page) {
  const title = await page.title();
  return stringResponse(title, "Active page title is: " + title);
}
async function getUrl(page) {
  const url = page.url();
  return stringResponse(url, url);
}
async function getElementCount(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, false);
  let count = 0;
  try {
    count = await locator.count();
  } catch (e) {
    if (!(e instanceof Error && e.message.includes("failed to find frame for selector"))) {
      throw e;
    }
  }
  return intResponse(count, `Found ${count} element(s).`);
}
async function getSelections(locator) {
  const selectElement = await locator.elementHandle();
  const selectOptions = await selectElement?.evaluate((e) => {
    return Array.from(e.options).map((option) => ({
      label: option.label,
      value: option.value,
      index: option.index,
      selected: option.selected
    }));
  });
  const entry = [];
  if (selectOptions) {
    const entries = selectOptions.map((e) => ({
      value: e.value,
      label: e.label,
      index: e.index,
      selected: e.selected
    }));
    logger.info(`Option entries: ${entries.length}`);
    logger.info(`Selected entries: ${entries.filter((e) => e.selected).length}`);
    entry.push(...entries);
  }
  return { entry };
}
async function getSelectContent(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.elementHandle();
  return await getSelections(locator);
}
async function getDomProperty(request, state) {
  const content = await getProperty(request, state);
  return stringResponse(JSON.stringify(content), "Property received successfully.");
}
async function getTextContent(locator) {
  const element = await locator.elementHandle();
  exists(element, "Locator did not resolve to elementHandle.");
  const tag = await (await element.getProperty("tagName")).jsonValue();
  if (tag === "INPUT" || tag === "TEXTAREA") {
    return await (await element.getProperty("value")).jsonValue();
  }
  return await element.innerText();
}
async function getText(request, state) {
  const selector = request.selector;
  const strict = request.strict;
  const locator = await findLocator(state, selector, strict, true);
  let content;
  try {
    content = await getTextContent(locator);
    logger.info(`Retrieved text for element ${selector} containing ${content}`);
  } catch (e) {
    if (e instanceof Error) {
      logger.error(e);
    }
    throw e;
  }
  return stringResponse(content, "Text received successfully.");
}
async function getBoolProperty(request, state) {
  const selector = request.selector;
  const content = await getProperty(request, state);
  return boolResponse(content || false, "Retrieved dom property for element " + selector + " containing " + content);
}
async function getProperty(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = findLocator(state, selector, strictMode, true);
  try {
    const element = await (await locator).elementHandle();
    const propertyName = request.property;
    const property = await element?.getProperty(propertyName);
    const content = await property?.jsonValue();
    logger.info(`Retrieved dom property for element ${selector} containing ${content}`);
    return content;
  } catch (e) {
    if (e instanceof Error) {
      logger.error(e);
    }
    throw e;
  }
}
async function getElementAttribute(request, state) {
  const content = await getAttributeValue(request, state);
  return stringResponse(JSON.stringify(content), "Property received successfully.");
}
async function getAttributeValue(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const attributeName = request.property;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.elementHandle();
  const attribute = await locator.getAttribute(attributeName);
  logger.info(`Retrieved attribute for element ${selector} containing ${attribute}`);
  return attribute;
}
var stateEnum = {
  attached: 1,
  detached: 2,
  visible: 4,
  hidden: 8,
  enabled: 16,
  disabled: 32,
  editable: 64,
  readonly: 128,
  selected: 256,
  deselected: 512,
  focused: 1024,
  defocused: 2048,
  checked: 4096,
  unchecked: 8192,
  stable: 16384
};
async function getCheckedState(locator) {
  try {
    return await locator.isChecked() ? stateEnum.checked : stateEnum.unchecked;
  } catch {
    return 0;
  }
}
async function getSelectState(element) {
  if (await element.evaluate((e) => "selected" in e)) {
    return await element.evaluate((e) => e.selected) ? stateEnum.selected : stateEnum.deselected;
  } else {
    return 0;
  }
}
async function getElementStates(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  let states;
  try {
    await locator.waitFor({ state: "attached", timeout: 250 });
    states = stateEnum.attached;
    states += await locator.isVisible() ? stateEnum.visible : stateEnum.hidden;
    states += await locator.isEnabled() ? stateEnum.enabled : stateEnum.disabled;
    const disabled = await locator.getAttribute("disabled");
    try {
      const editable = await locator.isEditable();
      if (editable && disabled === null) {
        logger.info(`Element ${selector} is editable: ${editable}`);
        states += stateEnum.editable;
      } else if (!editable && disabled !== null) {
        logger.info(`Element ${selector} is disabled: ${disabled}`);
        states += stateEnum.readonly;
      } else {
        logger.info(`Element ${selector} is readonly: ${!editable}`);
        states += stateEnum.readonly;
      }
    } catch (error) {
      logger.info(`Element ${selector} is not editable: ${String(error)}`);
      if (disabled !== null) {
        logger.info(`Element ${selector} is disabled: ${disabled} and therefore readonly`);
        states += stateEnum.readonly;
      }
    }
    logger.info("Checking checked state");
    states += await getCheckedState(locator);
    try {
      const element = await locator.elementHandle();
      exists(element, "Locator did not resolve to elementHandle.");
      states += await getSelectState(element);
      states += await element.evaluate((e) => document.activeElement === e) ? stateEnum.focused : stateEnum.defocused;
    } catch {
    }
  } catch (e) {
    if (e instanceof import_playwright3.errors.TimeoutError) {
      states = stateEnum.detached;
    } else {
      logger.error(e);
      throw e;
    }
  }
  return jsonResponse(JSON.stringify(states), "Returned state.");
}
async function getStyle(request, state) {
  const selector = request.selector;
  const option = {
    styleKey: request.styleKey || null,
    pseudoElement: request.pseudo || null
  };
  const strictMode = request.strict;
  logger.info("Getting css of element on page");
  const locator = await findLocator(state, selector, strictMode, true);
  const result = await locator.evaluate((element, option2) => {
    const cssStyleDeclaration = window.getComputedStyle(element, option2.pseudoElement);
    if (option2.styleKey) {
      return cssStyleDeclaration.getPropertyValue(option2.styleKey);
    } else {
      return Object.fromEntries(
        Array.from(cssStyleDeclaration).map((key) => [key, cssStyleDeclaration.getPropertyValue(key)])
      );
    }
  }, option);
  return jsonResponse(JSON.stringify(result), "Style get successfully.");
}
async function getViewportSize(page) {
  const result = page.viewportSize();
  return jsonResponse(JSON.stringify(result), "View port size received successfully from page.");
}
async function getBoundingBox(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  const boundingBox = await locator.boundingBox();
  return jsonResponse(JSON.stringify(boundingBox), "Got bounding box successfully.");
}
async function getPageSource(page) {
  const result = await page.content();
  logger.info(result);
  const body = JSON.stringify(result);
  const responseChunks = [];
  const bodyChunks = splitUtf8ByMaxBytes(body, MAX_RESPONSE_CHUNK_BYTES);
  if (bodyChunks.length > 1) {
    for (let i = 0; i < bodyChunks.length; i++) {
      const chunk = bodyChunks[i];
      const response = jsonResponse("{}", `Page source obtained, chunk ${i}`, chunk);
      responseChunks.push(response);
    }
  } else {
    const response = jsonResponse("{}", "Page source obtained successfully.", body);
    responseChunks.push(response);
  }
  return responseChunks;
}
async function getTableCellIndex(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  const element = await locator.elementHandle();
  exists(element, "Locator did not resolve to elementHandle.");
  const count = await element.evaluate((element2) => {
    while (!["TD", "TH"].includes(element2.nodeName)) {
      const parent = element2.parentElement;
      if (!parent) {
        throw Error("Selector does not select a table cell!");
      }
      element2 = parent;
    }
    return Array.prototype.indexOf.call(element2.parentNode?.children, element2);
  });
  return intResponse(count, `Cell index in row is ${count}.`);
}
async function getTableRowIndex(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  const element = await locator.elementHandle();
  exists(element, "Locator did not resolve to elementHandle.");
  const count = await element.evaluate((element2) => {
    let table_row = null;
    while (element2.nodeName !== "TABLE") {
      if (element2.nodeName === "TR") {
        table_row = element2;
      }
      const parent = element2.parentElement;
      if (!parent) {
        throw Error("Selector does not select a table cell!");
      }
      element2 = parent;
    }
    let rows = element2.querySelectorAll(":scope > * > tr");
    if (rows.length == 0) {
      rows = element2.querySelectorAll(":scope > tr");
    }
    if (rows.length == 0) {
      throw Error(
        `Table rows could not be found. ChildNodes are: ${Array.prototype.slice.call(element2.childNodes).map((e) => `${String(e.nodeName)}.${String(e.className)}`).join(", ")}`
      );
    }
    return Array.prototype.indexOf.call(rows, table_row);
  });
  return intResponse(count, `Row index in table is ${count}.`);
}

// node/playwright-wrapper/interaction.ts
async function selectOption(request, state) {
  const selector = request.selector;
  const matcher = JSON.parse(request.matcherJson);
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  const result = await locator.selectOption(matcher);
  if (result.length == 0) {
    logger.info("Couldn't select any options");
    throw new Error(`No options matched ${matcher}`);
  }
  return await getSelections(locator);
}
async function deSelectOption(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = findLocator(state, selector, strictMode, true);
  await (await locator).selectOption([]);
  return emptyWithLog(`Deselected options in element ${selector}`);
}
async function typeText(request, state) {
  const selector = request.selector;
  const text = request.text;
  const delayValue = request.delay;
  const clear = request.clear;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  if (clear) {
    await locator.fill("");
  }
  await locator.type(text, { delay: delayValue });
  return emptyWithLog(`Typed text "${text}" on "${selector}"`);
}
async function fillText(request, state) {
  const selector = request.selector;
  const text = request.text;
  const strictMode = request.strict;
  const force = request.force;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.fill(text, { force });
  return emptyWithLog(`Fill text ${text} on ${selector} with force: ${force}`);
}
async function clearText(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.fill("");
  return emptyWithLog(`Text ${selector} field cleared.`);
}
async function press(request, state) {
  const selector = request.selector;
  const keyList = request.key;
  const strictMode = request.strict;
  const pressDelay = request.pressDelay;
  const keyDelay = request.keyDelay;
  const locator = await findLocator(state, selector, strictMode, true);
  for (const i of keyList) {
    await locator.press(i, { delay: pressDelay });
    if (keyDelay > 0) {
      await new Promise((r) => setTimeout(r, keyDelay));
    }
  }
  return emptyWithLog(`Pressed keys: "${keyList.join(", ")}" on ${selector} `);
}
async function click(request, state) {
  const selector = request.selector;
  const options = request.options;
  const strictMode = request.strict;
  const result = await internalClick(selector, strictMode, options, state);
  if (result) {
    return emptyWithLog(`Clicked element: '${selector}' with options: '${options}' successfully.`);
  }
  return emptyWithLog(
    `Clicked element: '${selector}' with options: '${options}' but silenced: "Target closed error".`
  );
}
async function tap(request, state) {
  const selector = request.selector;
  const options = request.options;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.tap(JSON.parse(options));
  return emptyWithLog(`Tap element: '${selector}' with options: '${options}'`);
}
async function internalClick(selector, strictMode, options, state) {
  const locator = await findLocator(state, selector, strictMode, true);
  try {
    await locator.click(JSON.parse(options));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("locator.click: Target page, context or browser has been closed")) {
      logger.warn("Supress locator.click: Target page, context or browser has been closed error");
      return false;
    }
    throw error;
  }
}
async function hover(request, state) {
  const selector = request.selector;
  const options = request.options;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.hover(JSON.parse(options));
  return emptyWithLog(`Hovered element: '${selector}' With options: '${options}'`);
}
async function focus(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.focus();
  return emptyWithLog(`Focused element: ${selector}`);
}
async function checkCheckbox(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const force = request.force;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.waitFor({ state: "attached" });
  await locator.check({ force });
  return emptyWithLog(`Checked checkbox: ${selector} with force: ${force}`);
}
async function uncheckCheckbox(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const force = request.force;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.waitFor({ state: "attached" });
  await locator.uncheck({ force });
  return emptyWithLog(`Unchecked checkbox: ${selector} with force: ${force}`);
}
async function uploadFileBySelector(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const path4 = request.path;
  const locator = await findLocator(state, selector, strictMode, true);
  if (path4.length === 0) {
    const name = request.name;
    const mimeType = request.mimeType;
    const buffer = request.buffer;
    logger.info(`Uploading file ${name} as buffer to ${selector}`);
    await locator.setInputFiles({ name, mimeType, buffer: Buffer.from(buffer) });
    return emptyWithLog("Successfully uploaded buffer as file");
  } else {
    logger.info(`Uploading file(s) ${path4.join(", ")} to ${selector}`);
    await locator.setInputFiles(path4);
    return emptyWithLog("Successfully uploaded file(s)");
  }
}
async function uploadFile(request, page) {
  const path4 = request.path;
  const fileChooser = await page.waitForEvent("filechooser");
  await fileChooser.setFiles(path4);
  return emptyWithLog("Successfully uploaded file");
}
async function handleAlert(request, page) {
  const alertAction = request.alertAction;
  const promptInput = request.promptInput;
  const fn = async (dialog) => {
    const dialogueText = dialog.message();
    if (promptInput) await dialog[alertAction](promptInput);
    else await dialog[alertAction]();
    logger.info(`Alert text: ${dialogueText}`);
  };
  page.on("dialog", fn);
  return emptyWithLog("Set event handler for next alert");
}
async function waitForAlerts(request, page) {
  const alertActions = request.items;
  const alertMessages = [];
  for (let index = 0; index < alertActions.length; index++) {
    const alertAction = alertActions[index];
    const promptInput = alertAction.promptInput;
    const timeout = alertAction.timeout;
    const action = alertAction.alertAction;
    logger.info(`Waiting for alert with action: ${action}, promptInput: "${promptInput}" and timeout: ${timeout}`);
    const dialogObject = await page.waitForEvent("dialog", { timeout });
    alertMessages.push(dialogObject.message());
    if (action === "accept" && promptInput) {
      void dialogObject.accept(promptInput);
    } else if (alertAction.alertAction === "accept") {
      void dialogObject.accept();
    } else {
      void dialogObject.dismiss();
    }
  }
  return { items: alertMessages };
}
async function mouseButton(request, page) {
  const action = request.action;
  const params = JSON.parse(request.json);
  await invokeOnMouse(page, action, params);
  return emptyWithLog(`Successfully executed ${action}`);
}
async function mouseMove(request, page) {
  const params = JSON.parse(request.body);
  await invokeOnMouse(page, "move", params);
  return emptyWithLog(`Successfully moved mouse to ${params.x}, ${params.y}`);
}
async function mouseWheel(request, page) {
  const deltaX = request.deltaX;
  const deltaY = request.deltaY;
  exists(page, `but no open page`);
  await page?.mouse.wheel(deltaX, deltaY);
  return emptyWithLog(`Successfully scrolled mouse wheel with ${deltaX}, ${deltaY}`);
}
async function keyboardKey(request, page) {
  const action = request.action;
  const key = request.key;
  await invokeOnKeyboard(page, action, key);
  return emptyWithLog(`Successfully did ${action} for ${key}`);
}
async function keyboardInput(request, page) {
  const action = request.action;
  const delay = request.delay;
  const input = request.input;
  await invokeOnKeyboard(page, action, input, { delay });
  return emptyWithLog(`Successfully did virtual keyboard action ${action} with input ${input}`);
}
async function scrollToElement(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, true);
  await locator.scrollIntoViewIfNeeded();
  return emptyWithLog(`Scrolled to ${selector} field if needed.`);
}

// node/playwright-wrapper/keyword-decorators.ts
function class_async_logger(target) {
  for (const propertyName of Object.keys(target.prototype)) {
    const descriptor = Object.getOwnPropertyDescriptor(target.prototype, propertyName);
    const isMethod = descriptor?.value instanceof Function;
    if (!isMethod || !descriptor) continue;
    const timered_method = async_logger(propertyName, descriptor);
    Object.defineProperty(target.prototype, propertyName, timered_method);
  }
}
function async_logger(propertyKey, propertyDescriptor) {
  const originalMethod = propertyDescriptor.value;
  propertyDescriptor.value = async function(...args2) {
    try {
      logger.info({ event_kind: "grpc", action: propertyKey, status: "started" });
      const result = await originalMethod.apply(this, args2);
      logger.info({ event_kind: "grpc", action: propertyKey, status: "succeeded" });
      return result;
    } catch (err) {
      logger.info({ event_kind: "grpc", action: propertyKey, status: "failed" });
      throw err;
    }
  };
  return propertyDescriptor;
}

// node/playwright-wrapper/playwright-state.ts
var import_fs = __toESM(require("fs"));
var import_module = require("module");
var import_monocart_coverage_reports = require("monocart-coverage-reports");
var path3 = __toESM(require("path"));
var playwright = __toESM(require("playwright"));
var import_playwright4 = require("playwright");
var import_strip_comments = __toESM(require("strip-comments"));
function lastItem(array) {
  return array[array.length - 1];
}
var extractArgumentsStringFromJavascript = (javascript) => {
  const regex = /\((.*?)\)/;
  const match = regex.exec((0, import_strip_comments.default)(javascript).replace(/\r?\n/g, ""));
  if (match) {
    return match[1];
  }
  logger.error(`Could not extract arguments from javascript:
${javascript}
defaulting to *args`);
  return "*args";
};
async function initializeExtension(request, state) {
  logger.info(`Initializing extension: ${request.path}`);
  const extension = require(request.path);
  state.extensions.push(extension);
  const kws = Object.keys(extension).filter((key) => extension[key] instanceof Function && !key.startsWith("__"));
  logger.info(`Adding ${kws.length} keywords from JS Extension`);
  return keywordsResponse(
    kws,
    kws.map((v) => {
      return extractArgumentsStringFromJavascript(extension[v].toString());
    }),
    kws.map((v) => {
      const typedV = extension[v];
      return typedV.rfdoc ?? "TODO: Add rfdoc string to exposed function to create documentation";
    }),
    "ok"
  );
}
var getArgumentNamesFromJavascriptKeyword = (keyword) => extractArgumentsStringFromJavascript(keyword.toString()).split(",").map((s) => s.trim().match(/^\w*/)?.[0] || s.trim());
async function extensionKeywordCall(request, call, state) {
  const keywordName = request.name;
  const args2 = JSON.parse(request.arguments);
  const extension = state.extensions.find((extension2) => Object.keys(extension2).includes(keywordName));
  if (!extension) throw Error(`Could not find keyword ${keywordName}`);
  const keyword = extension[keywordName];
  const namedArguments = Object.fromEntries(args2["arguments"]);
  const apiArguments = /* @__PURE__ */ new Map();
  apiArguments.set("page", state.getActivePage());
  apiArguments.set("context", state.getActiveContext());
  apiArguments.set("browser", state.getActiveBrowser()?.browser);
  apiArguments.set("logger", (msg) => call.write(jsonResponse("", msg)));
  apiArguments.set("playwright", playwright);
  const functionArguments = getArgumentNamesFromJavascriptKeyword(keyword).map(
    (argName) => apiArguments.get(argName) || namedArguments[argName]
  );
  const result = await keyword(...functionArguments);
  if (result === void 0) {
    return [jsonResponse("", "ok")];
  }
  const body = JSON.stringify(result);
  const bodyChunks = splitUtf8ByMaxBytes(body, MAX_RESPONSE_CHUNK_BYTES);
  if (bodyChunks.length === 0) {
    return [jsonResponse("", "ok")];
  }
  return bodyChunks.map(
    (chunk, index) => jsonResponse("", index === bodyChunks.length - 1 ? "ok" : `ok chunk ${index}`, chunk)
  );
}
async function _newBrowser(browserType, headless, timeout, options) {
  const browser = await _getBrowserType(browserType).launch({ ...options, headless, timeout });
  return {
    browser,
    browserType,
    headless
  };
}
function _getBrowserType(browserType) {
  let browserTyp;
  switch (browserType) {
    case "chromium":
      browserTyp = import_playwright4.chromium;
      break;
    case "firefox":
      browserTyp = import_playwright4.firefox;
      break;
    case "webkit":
      browserTyp = import_playwright4.webkit;
      break;
    default:
      throw new Error(`"${browserType} is an unsupported browser."`);
  }
  return browserTyp;
}
async function _launchBrowserServer(browserType, headless, timeout, options) {
  let browser;
  const launchOptions = { ...options, headless, timeout };
  if (browserType === "firefox") {
    browser = await import_playwright4.firefox.launchServer(launchOptions);
  } else if (browserType === "chromium") {
    browser = await import_playwright4.chromium.launchServer(launchOptions);
  } else if (browserType === "webkit") {
    browser = await import_playwright4.webkit.launchServer(launchOptions);
  } else {
    throw new Error("unsupported browser");
  }
  return browser;
}
async function _connectBrowser(browserName, url, connectCDP, timeout) {
  logger.info(`Connecting to browser: ${browserName} at ${url} via ${connectCDP ? "CDP" : "WebSocket"}`);
  const browserType = _getBrowserType(browserName);
  timeout = timeout || 3e4;
  const browser = connectCDP ? await browserType.connectOverCDP(url, { timeout }) : await browserType.connect(url, { timeout });
  return {
    browser,
    browserType: browserName,
    headless: false
  };
}
async function _createIndexedContext(context, defaultTimeout, traceFile, options) {
  const contextId = `context=${v4_default()}`;
  if (defaultTimeout) {
    logger.info(`Setting default timeout for context ${contextId} to ${defaultTimeout}`);
    context.setDefaultTimeout(defaultTimeout);
  }
  if (traceFile) {
    if (!traceFile.toLowerCase().endsWith(".zip")) {
      traceFile = path3.join(traceFile, `trace_${contextId}.zip`);
    }
    traceFile = traceFile.replace("{contextid}", contextId);
  }
  const indexedContext = {
    id: contextId,
    c: context,
    pageStack: [],
    options,
    traceFile
  };
  if (traceFile) {
    logger.info("Tracing enabled with: { screenshots: true, snapshots: true }");
    await context.tracing.start({ screenshots: true, snapshots: true });
  }
  indexedContext.c.on("page", async (page) => {
    indexedContext.pageStack.unshift(await _newPage(indexedContext, page));
  });
  return indexedContext;
}
function indexedPage(newPage2) {
  const timestamp = (/* @__PURE__ */ new Date()).getTime() / 1e3;
  const pageErrors = [];
  const consoleMessages = [];
  newPage2.on("pageerror", (error) => {
    logger.warn(
      { event_kind: "internal_error", status: "failed", error_type: error.name },
      error.stack ?? error.message
    );
    const timedError = {
      name: error.name,
      message: error.message,
      stack: error.stack,
      time: /* @__PURE__ */ new Date()
    };
    pageErrors.push(timedError);
  });
  newPage2.on("console", (message) => {
    const timedMessage = {
      type: message.type(),
      text: message.text(),
      location: message.location(),
      time: /* @__PURE__ */ new Date()
    };
    consoleMessages.push(timedMessage);
  });
  return {
    id: `page=${v4_default()}`,
    p: newPage2,
    timestamp,
    pageErrors,
    errorIndex: 0,
    consoleMessages,
    consoleIndex: 0,
    activeDownloads: /* @__PURE__ */ new Map(),
    coverage: void 0
  };
}
async function _newPage(context, page = void 0) {
  const newPage2 = page === void 0 ? await context.c.newPage() : page;
  const contextPage = indexedPage(newPage2);
  newPage2.on("close", () => {
    const oldPageStackLength = context.pageStack.length;
    const filteredPageStack = context.pageStack.filter((page2) => page2.p != contextPage.p);
    if (oldPageStackLength != filteredPageStack.length) {
      context.pageStack = filteredPageStack;
      logger.info("Removed " + contextPage.id + " from " + context.id + " page stack");
    }
  });
  return contextPage;
}
var PlaywrightState = class {
  constructor() {
    this.browserStack = [];
    this.extensions = [];
    this.browserServer = [];
  }
  extensions;
  browserStack;
  browserServer;
  get activeBrowser() {
    return lastItem(this.browserStack);
  }
  getActiveBrowser = () => {
    const currentBrowser = this.activeBrowser;
    if (currentBrowser === void 0) {
      throw new Error("Browser has been closed.");
    }
    return currentBrowser;
  };
  switchTo = (id) => {
    const browser = this.browserStack.find((b) => b.id === id);
    this.browserStack = this.browserStack.filter((b) => b.id !== id);
    exists(browser, `No browser for id '${id}'`);
    this.browserStack.push(browser);
    return this.getActiveBrowser();
  };
  async getOrCreateActiveBrowser(browserType, timeout) {
    const currentBrowser = this.activeBrowser;
    if (currentBrowser === void 0) {
      logger.info("No active browser, creating a new one");
      const browserAndConfs = await _newBrowser(browserType || "chromium", true, timeout);
      const newState = new BrowserState(browserAndConfs);
      this.browserStack.push(newState);
      return { browser: newState, newBrowser: true };
    } else {
      logger.info(`currentBrowser: ${JSON.stringify(currentBrowser)}`);
      return { browser: currentBrowser, newBrowser: false };
    }
  }
  async closeAll() {
    const browsers = this.browserStack;
    for (const browser of browsers) {
      try {
        await browser.close();
      } catch (e) {
      }
    }
    this.browserStack = [];
  }
  async closeAllServers() {
    const servers = this.browserServer;
    for (const server2 of servers) {
      try {
        await server2.close();
      } catch (e) {
      }
    }
    this.browserServer = [];
  }
  getBrowserServer(wsEndpoint) {
    return this.browserServer.find((server2) => server2.wsEndpoint() === wsEndpoint);
  }
  async closeServer(selectedServer) {
    if (!this.browserServer.includes(selectedServer)) {
      throw new Error(`BrowserServer not found.`);
    }
    this.browserServer.splice(this.browserServer.indexOf(selectedServer), 1);
    await selectedServer.close();
  }
  async getCatalog(includePageDetails = true) {
    const pageToContents = async (page) => {
      let title = null;
      let url = "";
      if (includePageDetails) {
        url = page.p.url();
        const titlePromise = page.p.title();
        const titleTimeout = new Promise((_r, rej) => setTimeout(() => rej(new Error("title timeout")), 350));
        try {
          title = await Promise.race([titlePromise, titleTimeout]);
        } catch (e) {
        }
      }
      return {
        type: "page",
        title: title || "",
        url,
        id: page.id,
        timestamp: page.timestamp
      };
    };
    const contextToContents = async (context) => {
      const activePage = lastItem(context.pageStack)?.id;
      return {
        type: "context",
        id: context?.id,
        activePage,
        pages: await Promise.all(context.pageStack.map(pageToContents))
      };
    };
    return Promise.all(
      this.browserStack.map(async (browser) => {
        return {
          type: browser.name,
          id: browser.id,
          contexts: await Promise.all(browser.contextStack.map(contextToContents)),
          activeContext: browser.context?.id,
          activeBrowser: this.activeBrowser === browser
        };
      })
    );
  }
  addBrowser(browserAndConfs) {
    const adding_browser = browserAndConfs.browser;
    logger.info(`Adding browser to stack: ${browserAndConfs.browserType}, version: ${adding_browser?.version()}`);
    let browserState = this.browserStack.find((b) => b.browser === adding_browser);
    if (browserState !== void 0) {
      this.browserStack = this.browserStack.filter((b) => b.browser !== adding_browser);
    } else {
      browserState = new BrowserState(browserAndConfs);
    }
    const browserContexts = browserState.browser?.contexts();
    if (browserContexts !== void 0) {
      logger.info(`Adding ${browserContexts.length} contexts to browser`);
      for (const context of browserContexts) {
        const indexedPages = context.pages().map((page) => indexedPage(page));
        logger.info(`Adding ${indexedPages.length} pages to context`);
        const indexedContext = {
          id: `context=${v4_default()}`,
          c: context,
          pageStack: indexedPages,
          options: {},
          traceFile: ""
        };
        indexedContext.c.on("page", async (page) => {
          indexedContext.pageStack.unshift(await _newPage(indexedContext, page));
        });
        browserState?.pushContext(indexedContext);
      }
    }
    this.browserStack.push(browserState);
    return browserState;
  }
  addBrowserServer = (browserServer) => {
    this.browserServer.push(browserServer);
  };
  popBrowser = () => {
    return this.browserStack.pop();
  };
  getActiveContext = () => {
    return this.activeBrowser?.context?.c;
  };
  getTraceFile = () => {
    return this.activeBrowser?.context?.traceFile;
  };
  getActivePage = () => {
    return this.activeBrowser?.page?.p;
  };
  getActivePageId = () => {
    return this.activeBrowser?.page?.id;
  };
  getCoverageOptions = () => {
    return this.activeBrowser?.page?.coverage;
  };
  addCoverageOptions = (coverage) => {
    if (this.activeBrowser?.page) {
      this.activeBrowser.page.coverage = coverage;
    }
  };
};
var LocatorCache = class {
  cache;
  constructor() {
    this.cache = /* @__PURE__ */ new Map();
  }
  add(key, locator) {
    this.cache.set(key, locator);
  }
  get(key) {
    return this.cache.get(key);
  }
  delete(key) {
    return this.cache.delete(key);
  }
  has(key) {
    return this.cache.has(key);
  }
  clear() {
    this.cache.clear();
  }
};
var locatorCache = new LocatorCache();
var BrowserState = class {
  constructor(browserAndConfs) {
    this.name = browserAndConfs.browserType;
    this.browser = browserAndConfs.browser;
    this.headless = browserAndConfs.headless;
    this._contextStack = [];
    this.id = `browser=${v4_default()}`;
  }
  _contextStack;
  browser;
  name;
  id;
  headless;
  async close() {
    for (const context of this.contextStack) {
      const traceFile = context.traceFile;
      if (traceFile) {
        await context.c.tracing.stop({ path: traceFile });
      }
      await context.c.close();
    }
    this._contextStack = [];
    if (this.browser === null) {
      return;
    }
    await this.browser.close();
  }
  async getOrCreateActiveContext(defaultTimeout) {
    if (this.context) {
      return { context: this.context, newContext: false };
    } else if (this.browser === null) {
      throw new Error("Invalid persistent context browser without context");
    } else {
      const context = await _createIndexedContext(await this.browser.newContext(), defaultTimeout, "");
      this.pushContext(context);
      return { context, newContext: true };
    }
  }
  get context() {
    return lastItem(this._contextStack);
  }
  pushContext(newContext2) {
    if (newContext2 !== void 0) {
      if (newContext2.options === void 0) {
        newContext2.options = this._contextStack.find((c) => c.c === newContext2.c)?.options;
      }
      this._contextStack = this._contextStack.filter((c) => c.c !== newContext2.c);
      if (!newContext2.c) {
        throw new Error("Tried to switch to context, which did not exist anymore.");
      }
      this._contextStack.push(newContext2);
      logger.info(`Changed active context: ${newContext2.id}`);
    } else logger.info("Set active context to undefined");
  }
  unshiftContext(newContext2) {
    this._contextStack.unshift(newContext2);
  }
  get page() {
    const context = this.context;
    if (context) return lastItem(context.pageStack);
    else return void 0;
  }
  async activatePage(page) {
    this.pushPage(page);
    await page.p.bringToFront();
  }
  pushPage(newPage2) {
    const currentContext = this.context;
    if (newPage2 !== void 0 && currentContext !== void 0) {
      currentContext.pageStack = currentContext.pageStack.filter((p) => p.p !== newPage2.p);
      if (!newPage2.p) {
        throw new Error("Tried to switch to page, which did not exist anymore.");
      }
      currentContext.pageStack.push(newPage2);
      logger.info("Changed active page");
    } else {
      logger.info("Set active page to undefined");
    }
  }
  get contextStack() {
    return this._contextStack;
  }
  popPage() {
    const pageStack = this.context?.pageStack || [];
    return pageStack.pop();
  }
  popContext() {
    this._contextStack.pop();
  }
};
async function closeBrowserServer(request, openBrowsers) {
  const wsEndpoint = request.url;
  if (wsEndpoint === "ALL") {
    await openBrowsers.closeAllServers();
    return emptyWithLog("Closed all browser servers");
  }
  const browserServer = openBrowsers.getBrowserServer(wsEndpoint);
  if (!browserServer) throw new Error(`BrowserServer with endpoint ${wsEndpoint} not found.`);
  await openBrowsers.closeServer(browserServer);
  return emptyWithLog(`Closed browser server with endpoint: ${wsEndpoint}`);
}
async function closeBrowser(openBrowsers) {
  const currentBrowser = openBrowsers.activeBrowser;
  if (currentBrowser === void 0) {
    return stringResponse("no-browser", "No browser open, doing nothing");
  }
  openBrowsers.popBrowser();
  try {
    await currentBrowser.close();
    return stringResponse(currentBrowser.id, "Closed browser");
  } catch {
    return stringResponse("", `Browser ${currentBrowser.id} was already closed`);
  }
}
async function closeAllBrowsers(openBrowsers) {
  await openBrowsers.closeAll();
  return emptyWithLog("Closed all browsers");
}
async function closeContext(request, openBrowsers) {
  const saveTrace = request.value;
  const activeBrowser = openBrowsers.getActiveBrowser();
  const traceFile = openBrowsers.getTraceFile();
  if (traceFile && saveTrace) {
    await openBrowsers.getActiveContext()?.tracing.stop({ path: traceFile });
  }
  for (const page of activeBrowser.context?.pageStack || []) {
    await _saveCoverageReport(page);
  }
  await openBrowsers.getActiveContext()?.close();
  activeBrowser.popContext();
  if (activeBrowser.contextStack.length === 0 && activeBrowser.browser === null) {
    void closeBrowser(openBrowsers);
  }
  return emptyWithLog("Successfully closed Context");
}
async function closePage(request, openBrowsers) {
  const activeBrowser = openBrowsers.getActiveBrowser();
  const closedPage = activeBrowser.popPage();
  if (closedPage) {
    await _saveCoverageReport(closedPage);
  }
  const unload = request.runBeforeUnload;
  if (!closedPage) throw new Error("No open page");
  logger.info(`Closing page with runBeforeUnload ${unload}`);
  await closedPage.p.close({ runBeforeUnload: unload });
  return pageReportResponse(`Successfully closed Page with runBeforeUnload ${unload}`, closedPage);
}
async function newPage(request, openBrowsers) {
  const defaultTimeout = request.url?.defaultTimeout;
  const waitUntil = request.waitUntil;
  const browserState = await openBrowsers.getOrCreateActiveBrowser(null, defaultTimeout);
  const newBrowser2 = browserState.newBrowser;
  const context = await browserState.browser.getOrCreateActiveContext(defaultTimeout);
  const page = await _newPage(context.context);
  let videoPath = "";
  try {
    videoPath = await page.p.video()?.path();
  } catch {
    logger.info("Suppress video().path() error");
  }
  logger.info("Video path: " + videoPath);
  browserState.browser.pushPage(page);
  const url = request.url?.url || "about:blank";
  try {
    const goToOptions = { timeout: defaultTimeout };
    if (waitUntil) {
      goToOptions.waitUntil = waitUntil;
    }
    await page.p.goto(url, goToOptions);
    const video = { video_path: videoPath || null, contextUuid: context.context.id };
    return {
      body: page.id,
      log: `Successfully initialized new page object and opened url: ${url}`,
      video: JSON.stringify(video),
      newBrowser: newBrowser2,
      newContext: context.newContext
    };
  } catch (e) {
    void browserState.browser.popPage()?.p.close();
    throw e;
  }
}
async function newContext(request, openBrowsers) {
  const options = JSON.parse(request.rawOptions);
  logger.info("Creating new context with options: " + JSON.stringify(options));
  const defaultTimeout = request.defaultTimeout;
  const browserState = await openBrowsers.getOrCreateActiveBrowser(options.defaultBrowserType, defaultTimeout);
  const traceFile = request.traceFile;
  logger.info(`Trace file: ${traceFile}`);
  if (browserState.browser.browser === null) {
    throw new Error("Trying to create a new context when a persistentContext is active");
  }
  const indexedContext = await _createIndexedContext(
    await browserState.browser.browser.newContext(options),
    defaultTimeout,
    traceFile,
    options
  );
  return await _finishContextResponse(indexedContext, browserState, options);
}
async function _finishContextResponse(indexedContext, browserState, options) {
  browserState.browser.pushContext(indexedContext);
  const log = indexedContext.traceFile ? `Successfully created context and trace file will be saved to: ${indexedContext.traceFile}` : "Successfully created context. ";
  if (indexedContext.traceFile) {
    options.trace = { screenshots: true, snapshots: true };
  }
  return {
    id: indexedContext.id,
    log,
    contextOptions: JSON.stringify(options),
    newBrowser: browserState.newBrowser
  };
}
async function newBrowser(request, openBrowsers) {
  const browserType = request.browser;
  const options = JSON.parse(request.rawOptions);
  const browserAndConfs = await _newBrowser(
    browserType,
    options["headless"],
    options["timeout"],
    options
  );
  const browserState = openBrowsers.addBrowser(browserAndConfs);
  return stringResponse(browserState.id, "Successfully created browser with options: " + JSON.stringify(options));
}
async function launchBrowserServer(request, openBrowsers) {
  const browserType = request.browser;
  const options = JSON.parse(request.rawOptions);
  logger.info(`Launching browser server: ${browserType}`);
  logger.info("Launching browser server with options: " + JSON.stringify(options));
  const browserServer = await _launchBrowserServer(
    browserType,
    options["headless"],
    options["timeout"],
    options
  );
  logger.info(`Browser server launched. Endpoint: ${browserServer.wsEndpoint()}`);
  openBrowsers.addBrowserServer(browserServer);
  return stringResponse(
    browserServer.wsEndpoint(),
    "Successfully created browser server with options: " + JSON.stringify(options)
  );
}
async function newPersistentContext(request, openBrowsers) {
  const traceFile = request.traceFile;
  const timeout = request.defaultTimeout;
  const options = JSON.parse(request.rawOptions);
  const userDataDir = options?.userDataDir;
  const browserName = options.defaultBrowserType || options.browser || "chromium";
  const context = await _getBrowserType(browserName).launchPersistentContext(userDataDir, options);
  const browserAndConfs = {
    browserType: browserName,
    browser: null,
    headless: options?.headless || true
  };
  openBrowsers.addBrowser(browserAndConfs);
  const browserState = await openBrowsers.getOrCreateActiveBrowser(null, timeout);
  if (browserState.newBrowser === true) {
    throw new Error("A new browser was created in error while trying to create a persistent context");
  }
  const indexedContext = await _createIndexedContext(context, timeout, traceFile, options);
  const page = indexedContext.c.pages()[0];
  indexedContext.pageStack.unshift(await _newPage(indexedContext, page));
  const baseResponse = await _finishContextResponse(indexedContext, browserState, options);
  const currentBrowser = openBrowsers.activeBrowser;
  const currentPage = indexedContext.pageStack[0];
  const videoPath = await currentPage.p.video()?.path();
  const video = { video_path: videoPath || null, contextUuid: indexedContext.id };
  return {
    ...baseResponse,
    video: JSON.stringify(video),
    pageId: currentPage.id,
    browserId: currentBrowser?.id || ""
  };
}
async function connectToBrowser(request, openBrowsers) {
  const browserType = request.browser;
  const url = request.url;
  const connectCDP = request.connectCDP;
  const timeout = request.timeout;
  const browserAndConfs = await _connectBrowser(browserType, url, connectCDP, timeout);
  const browserState = openBrowsers.addBrowser(browserAndConfs);
  return stringResponse(browserState.id, "Successfully connected to browser");
}
async function openTraceGroup(request, openBrowsers) {
  const name = request.name;
  const file = request.file;
  const line = request.line;
  const column = request.column;
  const contextId = request.contextId;
  if (openBrowsers?.browserStack) {
    for (const browserState of openBrowsers.browserStack) {
      for (const indexedContext of browserState.contextStack) {
        if (!contextId || indexedContext.id === contextId) {
          await indexedContext.c?.tracing?.group(name, { location: { file, line, column } });
        }
      }
    }
  }
  setRFKeywordContext({ kw_name: name, kw_file: file || void 0, kw_line: line || void 0 });
  return emptyWithLog("Opened trace group");
}
async function closeTraceGroup(openBrowsers) {
  if (openBrowsers?.browserStack) {
    for (const browserState of openBrowsers.browserStack) {
      for (const indexedContext of browserState.contextStack) {
        await indexedContext.c?.tracing?.groupEnd();
      }
    }
  }
  clearRFKeywordContext();
  return emptyWithLog("Closed trace group");
}
async function setRFContext(request) {
  setRFTestContext(request.testId, request.testName);
  setRFSuiteContext(request.suiteId, request.suiteName);
  return emptyWithLog("RF context updated");
}
async function _switchPage(id, browserState) {
  const context = browserState.context?.c;
  if (!context) throw new Error("Tried to switch page, no open context");
  const pages = browserState.context?.pageStack;
  logger.info("Changing current active page: " + id);
  const page = pages?.find((elem) => elem.id == id);
  if (page) {
    await browserState.activatePage(page);
    return;
  } else {
    const mapped = pages?.map((page2) => `{ id: ${page2.id}, url: ${page2.p.url()} }`).join(",");
    const message = `No page for id ${id}. Open pages: ${mapped}`;
    const error = new Error(message);
    throw error;
  }
}
async function _switchContext(id, browserState) {
  const contexts = browserState.contextStack;
  const context = contexts.find((context2) => context2.id === id);
  if (contexts && context) {
    browserState.pushContext(context);
    return;
  } else {
    const mapped = contexts.map((context2) => context2.id);
    const message = `No context for id ${id}. Open contexts: ${mapped.join(", ")}`;
    throw new Error(message);
  }
}
async function switchPage(request, browserState) {
  exists(browserState, "Tried to switch Page but browser wasn't open");
  const context = browserState.context;
  exists(context, "Tried to switch Page but no context was open");
  const id = request.id;
  if (id === "CURRENT") {
    const previous2 = browserState.page?.id || "NO PAGE OPEN";
    void browserState.page?.p.bringToFront();
    return stringResponse(previous2, "Returned active page id");
  }
  if (id === "NEW") {
    const previous2 = browserState.page?.id || "NO PAGE OPEN";
    const previousTime = browserState.page?.timestamp || 0;
    const latest = await findLatestPageAfter(previousTime, request.timeout, context);
    exists(latest, "Tried to activate a new page but no new pages were detected in context.");
    await browserState.activatePage(latest);
    return stringResponse(previous2, `Activated new page ${latest.id}`);
  }
  const previous = browserState.page?.id || "";
  await _switchPage(id, browserState);
  return stringResponse(previous, "Successfully changed active page: " + id);
}
async function findLatestPageAfter(timestamp, timeout, context) {
  if (timeout < 0) {
    return null;
  }
  const latest = context.pageStack.reduce((acc, val) => {
    if (acc === void 0 || acc.timestamp < val.timestamp) {
      return val;
    }
    return acc;
  });
  if (!latest || timestamp && latest.timestamp <= timestamp) {
    await new Promise((resolve2) => setTimeout(resolve2, Math.min(15, timeout)));
    return findLatestPageAfter(timestamp, timeout - 15, context);
  }
  return latest;
}
async function switchContext(request, browserState) {
  const id = request.index;
  const previous = browserState.context?.id || "";
  if (id === "CURRENT") {
    if (!previous) {
      return stringResponse("NO CONTEXT OPEN", "Returned info that no contexts are open");
    }
  } else {
    await _switchContext(id, browserState);
  }
  const page = browserState.page;
  if (page !== void 0) {
    await _switchPage(page.id, browserState);
  }
  return stringResponse(
    previous,
    id === "CURRENT" ? "Returned active context id: " + id : "Successfully changed active context: " + id
  );
}
async function switchBrowser(request, openBrowsers) {
  const id = request.index;
  const previous = openBrowsers.activeBrowser;
  if (id !== "CURRENT") {
    openBrowsers.switchTo(id);
  }
  void openBrowsers.getActivePage()?.bringToFront();
  return stringResponse(
    previous?.id || "NO BROWSER OPEN",
    id === "CURRENT" ? "Returned active browser id. " + id : "Successfully changed active browser: " + id
  );
}
async function getBrowserCatalog(request, openBrowsers) {
  const includePageDetails = request.value ?? true;
  return jsonResponse(JSON.stringify(await openBrowsers.getCatalog(includePageDetails)), "Catalog received");
}
async function getConsoleLog(request, openBrowsers) {
  const activePage = openBrowsers.getActiveBrowser().page;
  if (!activePage) throw new Error("No open page");
  return getConsoleLogResponse(activePage, request.value, "Console log received");
}
async function getErrorMessages(request, openBrowsers) {
  const activePage = openBrowsers.getActiveBrowser().page;
  if (!activePage) throw new Error("No open page");
  return getErrorMessagesResponse(activePage, request.value, "Error messages received");
}
async function saveStorageState(request, browserState) {
  exists(browserState, "Tried to save storage state but browser wasn't open");
  const context = browserState.context;
  exists(context, "Tried to save storage state butno context was open");
  const stateFile = request.path;
  await context.c.storageState({ path: stateFile });
  return emptyWithLog("Current context state is saved to: " + stateFile);
}
async function startCoverage(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const coverageOptions = {
    type: request.coverageType,
    directory: request.coverageDir,
    configFile: request.configFile,
    raw: request.raw
  };
  state.addCoverageOptions(coverageOptions);
  const resetOnNavigation = request.resetOnNavigation;
  const reportAnonymousScripts = request.reportAnonymousScripts;
  if (["js", "all"].includes(coverageOptions.type)) {
    logger.info(
      `Starting JS coverage with resetOnNavigation: ${resetOnNavigation} and reportAnonymousScripts: ${reportAnonymousScripts}`
    );
    await activePage.coverage.startJSCoverage({ reportAnonymousScripts, resetOnNavigation });
  }
  if (["css", "all"].includes(coverageOptions.type)) {
    logger.info(`Starting CSS coverage with resetOnNavigation: ${resetOnNavigation}`);
    await activePage.coverage.startCSSCoverage({ resetOnNavigation });
  }
  return emptyWithLog(`Coverage started for ${coverageOptions.type}`);
}
async function stopCoverage(request, state) {
  const activeIndexedPage = state.activeBrowser?.page;
  exists(activeIndexedPage, "Could not find active page");
  return _saveCoverageReport(activeIndexedPage);
}
async function _saveCoverageReport(activeIndexedPage) {
  const { coverage: coverageOptions, p: activePage, id: pageId } = activeIndexedPage;
  activeIndexedPage.coverage = void 0;
  if (!coverageOptions) {
    return stringResponse("", "Coverage not started");
  }
  const { directory: coverageDir = "", configFile = "", type: coverageType, raw = false } = coverageOptions;
  const allCoverage = [];
  if (["js", "all"].includes(coverageType)) {
    logger.info("Stopping JS coverage");
    allCoverage.push(...await activePage.coverage.stopJSCoverage());
  }
  if (["css", "all"].includes(coverageType)) {
    logger.info("Stopping CSS coverage");
    allCoverage.push(...await activePage.coverage.stopCSSCoverage());
  }
  const outputDir = path3.normalize(path3.join(coverageDir, pageId));
  const options = { outputDir };
  if (raw && configFile === "") {
    logger.info("Raw and v8 coverage enabled");
    options.reports = [["raw"], ["v8"]];
  } else {
    logger.info("v8 coverage disabled");
  }
  let mergedOptions;
  if (import_fs.default.existsSync(configFile)) {
    logger.info({ "Config file exists: ": configFile });
    const configFileModule = require(configFile);
    mergedOptions = { ...configFileModule, ...options };
    console.log({ "Merged options: ": mergedOptions });
  } else {
    console.log({ "No config file found": configFile });
    mergedOptions = { ...options };
  }
  const mcr = new import_monocart_coverage_reports.CoverageReport(mergedOptions);
  await mcr.add(allCoverage);
  await mcr.generate();
  let message = "Coverage stopped and report generated";
  if (!import_fs.default.existsSync(configFile)) {
    message += `. But no config file found at ${configFile}`;
  }
  return stringResponse(outputDir, message);
}
async function mergeCoverage(request, state) {
  state.getActivePage();
  const inputFolder = request.inputFolder;
  const outputFolder = request.outputFolder;
  const configFile = request.config;
  const name = request.name;
  const reports = request.reports;
  if (!inputFolder) {
    throw Error("No input folders specified");
  }
  if (!outputFolder) {
    throw Error("No output folder specified");
  }
  const options = {
    name,
    inputDir: inputFolder,
    outputDir: outputFolder
  };
  logger.info(`Reports to generate: ${reports.join(", ")}`);
  if (reports && reports.length > 0) {
    options.reports = reports.map((r) => [r]);
  }
  const defaultName = "Browser library Merged Coverage Report";
  let mergedOptions;
  if (import_fs.default.existsSync(configFile)) {
    logger.info(`Config file exists:  ${configFile}`);
    const configFileModule = (0, import_module.createRequire)(__filename)(configFile);
    logger.info(`configFileModule options: ${JSON.stringify(configFileModule)}`);
    mergedOptions = { ...configFileModule, ...options };
    if (reports && reports.length === 1 && reports[0] === "v8") {
      mergedOptions.reports = [["v8"], configFileModule.reports || []].flat();
    }
    if (mergedOptions.name === "" && configFileModule.name) {
      mergedOptions.name = configFileModule.name;
    } else {
      mergedOptions.name = defaultName;
    }
    logger.info(`Merged options: ${JSON.stringify(mergedOptions)}`);
  } else {
    logger.info(`No config file found: ${configFile}`);
    mergedOptions = { ...options };
    if (mergedOptions.name === "") {
      mergedOptions.name = defaultName;
    }
  }
  logger.info(`Final options: ${JSON.stringify(mergedOptions)}`);
  logger.info(`Merging coverage from ${inputFolder} into ${outputFolder}`);
  await new import_monocart_coverage_reports.CoverageReport(mergedOptions).generate();
  return emptyWithLog(`Coverage merged from ${inputFolder} into ${outputFolder}`);
}

// node/playwright-wrapper/locator-handler.ts
async function addLocatorHandlerCustom(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const overlaySelector = request.selector;
  const timesString = request.times;
  let times;
  if (timesString === "None") {
    times = void 0;
  } else {
    times = parseInt(timesString);
  }
  logger.info(`Adding locator handler for ${overlaySelector} as times: ${times}`);
  const noWaitAfter = request.noWaitAfter;
  const handlerSpecs = request.handlerSpecs;
  const overlayLocator = await findLocator(state, overlaySelector, false, true);
  locatorCache.add(`${state.getActivePageId()}-${overlaySelector}`, overlayLocator);
  await activePage.addLocatorHandler(
    overlayLocator,
    async () => {
      logger.info(`Overlay locator ${overlaySelector} is found`);
      for (const handlerSpec of handlerSpecs) {
        const action = handlerSpec.action;
        const actionSelector = handlerSpec.selector;
        const actionLocator = await findLocator(state, actionSelector, false, true);
        const options = JSON.parse(handlerSpec.optionsAsJson);
        try {
          if (action === "click") {
            logger.info(
              `Overlay click on element ${actionSelector} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.click({ ...options });
          } else if (action === "fill") {
            const value = handlerSpec.value;
            logger.info(
              `Overlay fill on element ${actionSelector} with value ${value} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.fill(value, { ...options });
          } else if (action === "check") {
            logger.info(
              `Overlay check on element ${actionSelector} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.check({ ...options });
          } else if (action === "uncheck") {
            logger.info(
              `Overlay uncheck on element ${actionSelector} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.uncheck({ ...options });
          }
        } catch (error) {
          logger.error(
            { event_kind: "internal_error", status: "failed", error_type: errorType(error) },
            `Error in custom locator handler: ${String(error)}`
          );
        }
      }
    },
    { times, noWaitAfter }
  );
  return emptyWithLog(`Custom locator handler added for element ${overlaySelector}`);
}
async function removeLocatorHandler(request, state) {
  logger.info(`Removing locator handler for ${request.selector}`);
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const activePageId = state.getActivePageId();
  const overlaySelector = request.selector;
  const locator = locatorCache.get(`${activePageId}-${overlaySelector}`);
  locatorCache.delete(`${activePageId}-${overlaySelector}`);
  if (locator === void 0) {
    return emptyWithLog(`No locator handler found for ${overlaySelector}`);
  }
  await activePage.removeLocatorHandler(locator);
  return emptyWithLog(`Removed locator handler ${overlaySelector}`);
}

// node/playwright-wrapper/pdf.ts
async function savePageAsPdf(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const pdfPath = request.path;
  const displayheaderfooter = request.displayHeaderFooter;
  const footertemplate = request.footerTemplate;
  const format = request.format;
  const headerTemplate = request.headerTemplate;
  const height = request.height;
  const landscape = request.landscape;
  const marginString = request.margin;
  const marging = JSON.parse(marginString);
  const outline = request.outline;
  const pageRanges = request.pageRanges;
  const preferCSSPageSize = request.preferCSSPageSize;
  const printBackground = request.printBackground;
  const scale = request.scale;
  const tagged = request.tagged;
  const width = request.width;
  logger.info(`Saving pdf to ${pdfPath}`);
  const message = `Using options: displayHeaderFooter: ${displayheaderfooter}, footerTemplate: ${footertemplate}, format: ${format}, headerTemplate: ${headerTemplate}, height: ${height}, landscape: ${landscape}, margin (as string): ${marginString}, outline: ${outline}, pageRanges: ${pageRanges}, preferCSSPageSize: ${preferCSSPageSize}, printBackground: ${printBackground}, scale: ${scale}, tagged: ${tagged}  and width: ${width}`;
  logger.info(message);
  await activePage.pdf({
    path: pdfPath,
    displayHeaderFooter: displayheaderfooter,
    footerTemplate: footertemplate,
    format,
    headerTemplate,
    height,
    landscape,
    margin: marging,
    outline,
    pageRanges,
    preferCSSPageSize,
    printBackground,
    scale,
    tagged,
    width
  });
  return stringResponse(pdfPath, `Pdf is saved to ${pdfPath}`);
}
async function emulateMedia(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const options = {};
  const colorScheme = request.colorScheme;
  if (colorScheme === "not_set") {
    logger.info(`Emulating colorScheme not set`);
  } else if (colorScheme === "null") {
    logger.info(`Emulating colorScheme null`);
    options.colorScheme = null;
  } else {
    logger.info(`Emulating colorScheme ${colorScheme}`);
    options.colorScheme = colorScheme;
  }
  const forcedColors = request.forcedColors;
  if (forcedColors === "not_set") {
    logger.info(`Emulating forcedColors not set`);
  } else if (forcedColors === "null") {
    logger.info(`Emulating forcedColors null`);
    options.forcedColors = null;
  } else {
    logger.info(`Emulating forcedColors ${forcedColors}`);
    options.forcedColors = forcedColors;
  }
  const media = request.media;
  if (media === "not_set") {
    logger.info(`Emulating media not set`);
  } else if (media === "null") {
    logger.info(`Emulating media null`);
    options.media = null;
  } else {
    logger.info(`Emulating media ${media}`);
    options.media = media;
  }
  const reducedMotion = request.reducedMotion;
  if (reducedMotion === "not_set") {
    logger.info(`Emulating reducedMotion not set`);
  } else if (reducedMotion === "null") {
    logger.info(`Emulating reducedMotion null`);
    options.reducedMotion = null;
  } else {
    logger.info(`Emulating reducedMotion ${reducedMotion}`);
    options.reducedMotion = reducedMotion;
  }
  await activePage.emulateMedia(options);
  return stringResponse(JSON.stringify(options), `Emulating media ${JSON.stringify(options)}`);
}

// node/playwright-wrapper/grpc-service.ts
var PlaywrightServer = class {
  states = {};
  peerMap = {};
  createState = (key) => {
    if (!(key in this.states)) {
      this.states[key] = new PlaywrightState();
    }
    return this.states[key];
  };
  getState = (peer) => {
    const mapPeer = this.peerMap[peer.getPeer()];
    if (mapPeer) {
      return this.createState(mapPeer);
    } else {
      this.peerMap[peer.getPeer()] = peer.getPeer();
      const p = peer.getPeer();
      return this.createState(p);
    }
  };
  getActiveBrowser = (peer) => this.getState(peer).getActiveBrowser();
  getActiveContext = (peer) => this.getState(peer).getActiveContext();
  getActivePage = (peer) => {
    const page = this.getState(peer).getActivePage();
    if (!page) throw Error("No page open.");
    return page;
  };
  wrapping = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getState(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingDebug = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.debug({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getState(call));
        logger.debug({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.debug({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingState = (func) => {
    return async (call, callback) => {
      try {
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(this.getState(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingPage = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getActivePage(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingStatePage = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getState(call), this.getActivePage(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  initializeExtension = this.wrapping(initializeExtension);
  async callExtensionKeyword(call) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const results = await extensionKeywordCall(request, call, this.getState(call));
      for (const result of results) {
        call.write(result);
      }
    } catch (e) {
      logger.error(
        { event_kind: "internal_error", status: "failed", error_type: errorType(e) },
        "Error in callExtensionKeyword"
      );
      call.emit("error", errorResponse(e));
    }
    call.end();
  }
  closeBrowser = this.wrappingState(closeBrowser);
  closeBrowserServer = this.wrapping(closeBrowserServer);
  closeAllBrowsers = this.wrappingState(closeAllBrowsers);
  closeContext = this.wrapping(closeContext);
  closePage = this.wrapping(closePage);
  openTraceGroup = this.wrapping(openTraceGroup);
  closeTraceGroup = this.wrappingState(closeTraceGroup);
  setRfContext = this.wrappingDebug(setRFContext);
  getBrowserCatalog = this.wrapping(getBrowserCatalog);
  getConsoleLog = this.wrapping(getConsoleLog);
  getErrorMessages = this.wrapping(getErrorMessages);
  async getCookies(call, callback) {
    try {
      const context = this.getActiveContext(call);
      if (!context) throw Error("no open context.");
      const result = await getCookies(context);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async addCookie(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const context = this.getActiveContext(call);
      if (!context) throw Error("no open context.");
      const result = await addCookie(request, context);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async deleteAllCookies(call, callback) {
    try {
      const context = this.getActiveContext(call);
      if (!context) throw Error("no open context.");
      const result = await deleteAllCookies(context);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async switchPage(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await switchPage(request, this.getActiveBrowser(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async switchContext(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await switchContext(request, this.getActiveBrowser(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async saveStorageState(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await saveStorageState(request, this.getActiveBrowser(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  switchBrowser = this.wrapping(switchBrowser);
  newPage = this.wrapping(newPage);
  newContext = this.wrapping(newContext);
  newBrowser = this.wrapping(newBrowser);
  startCoverage = this.wrapping(startCoverage);
  stopCoverage = this.wrapping(stopCoverage);
  mergeCoverage = this.wrapping(mergeCoverage);
  launchBrowserServer = this.wrapping(launchBrowserServer);
  newPersistentContext = this.wrapping(newPersistentContext);
  connectToBrowser = this.wrapping(connectToBrowser);
  goTo = this.wrappingPage(goTo);
  pdf = this.wrapping(savePageAsPdf);
  emulateMedia = this.wrapping(emulateMedia);
  async goBack(call, callback) {
    try {
      await this.getActivePage(call).goBack();
      callback(null, emptyWithLog("Did Go Back"));
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async goForward(call, callback) {
    try {
      await this.getActivePage(call).goForward();
      callback(null, emptyWithLog("Did Go Forward"));
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  takeScreenshot = this.wrapping(takeScreenshot);
  getBoundingBox = this.wrapping(getBoundingBox);
  ariaSnapShot = this.wrappingStatePage(getAriaSnapshot);
  async getPageSource(call) {
    try {
      const results = await getPageSource(this.getActivePage(call));
      for (const result of results) {
        call.write(result);
      }
    } catch (e) {
      call.emit("error", errorResponse(e));
    }
    call.end();
  }
  async setTimeout(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await setTimeout2(request, this.getActiveBrowser(call)?.context?.c);
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async getTitle(call, callback) {
    try {
      const response = await getTitle(this.getActivePage(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async getUrl(call, callback) {
    try {
      const response = await getUrl(this.getActivePage(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  getElementCount = this.wrapping(getElementCount);
  getSelectContent = this.wrapping(getSelectContent);
  getDomProperty = this.wrapping(getDomProperty);
  getText = this.wrapping(getText);
  getBoolProperty = this.wrapping(getBoolProperty);
  getElementAttribute = this.wrapping(getElementAttribute);
  getElementStates = this.wrapping(getElementStates);
  getStyle = this.wrapping(getStyle);
  getTableCellIndex = this.wrapping(getTableCellIndex);
  getTableRowIndex = this.wrapping(getTableRowIndex);
  scrollToElement = this.wrapping(scrollToElement);
  async getViewportSize(call, callback) {
    try {
      const response = await getViewportSize(this.getActivePage(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  selectOption = this.wrapping(selectOption);
  executePlaywright = this.wrapping(executePlaywright);
  grantPermissions = this.wrapping(grantPermissions);
  clearPermissions = this.wrapping(clearPermissions);
  deselectOption = this.wrapping(deSelectOption);
  typeText = this.wrapping(typeText);
  fillText = this.wrapping(fillText);
  clearText = this.wrapping(clearText);
  press = this.wrapping(press);
  click = this.wrapping(click);
  addLocatorHandlerCustom = this.wrapping(addLocatorHandlerCustom);
  removeLocatorHandler = this.wrapping(removeLocatorHandler);
  tap = this.wrapping(tap);
  hover = this.wrapping(hover);
  focus = this.wrapping(focus);
  checkCheckbox = this.wrapping(checkCheckbox);
  uncheckCheckbox = this.wrapping(uncheckCheckbox);
  getElement = this.wrapping(getElement);
  getElements = this.wrapping(getElements);
  getByX = this.wrapping(getByX);
  addStyleTag = this.wrappingPage(addStyleTag);
  setTime = this.wrapping(setTime);
  clockResume = this.wrapping(clockResume);
  clockPauseAt = this.wrapping(clockPauseAt);
  advanceClock = this.wrapping(advanceClock);
  waitForElementsState = this.wrapping(waitForElementState);
  waitForRequest = this.wrappingPage(waitForRequest);
  async waitForResponse(call) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const results = await waitForResponse(request, this.getActivePage(call));
      for (const result of results) {
        logger.info(`Sending response ${result.log}`);
        call.write(result);
      }
    } catch (e) {
      call.emit("error", errorResponse(e));
    }
    call.end();
  }
  waitForNavigation = this.wrappingPage(waitForNavigation);
  waitForPageLoadState = this.wrappingPage(WaitForPageLoadState);
  getDownloadState = this.wrapping(getDownloadState);
  cancelDownload = this.wrapping(cancelDownload);
  async waitForFunction(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = await waitForFunction(request, this.getState(call), this.getActivePage(call));
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  waitForDownload = this.wrappingStatePage(waitForDownload);
  evaluateJavascript = this.wrappingStatePage(evaluateJavascript);
  recordSelector = this.wrapping(recordSelector);
  async health(call, callback) {
    callback(null, { body: "OK", log: "" });
  }
  highlightElements = this.wrapping(highlightElements);
  download = this.wrapping(download);
  setViewportSize = this.wrappingPage(setViewportSize);
  httpRequest = this.wrappingPage(httpRequest);
  async getDevice(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = getDevice(request);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async getDevices(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = getDevices();
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async uploadFileBySelector(call, callback) {
    let buffer = "";
    let lastRequest;
    call.on("data", (request) => {
      void (async () => {
        try {
          logger.info(`Reading multiplepart uploadFileBySelector`);
          const newBuffer = request.buffer;
          buffer += newBuffer;
          lastRequest = request;
        } catch (e) {
          callback(errorResponse(e), null);
        }
      })();
    });
    call.on("error", (e) => {
      logger.error(
        { event_kind: "internal_error", status: "failed", error_type: errorType(e) },
        "Stream error in uploadFileBySelector"
      );
      callback(errorResponse(e), null);
    });
    call.on("end", () => {
      void (async () => {
        try {
          if (!lastRequest) {
            callback(errorResponse(new Error("No data received for uploadFileBySelector")), null);
            return;
          }
          const finalRequest = { ...lastRequest, buffer };
          const result = await uploadFileBySelector(finalRequest, this.getState(call));
          callback(null, result);
        } catch (e) {
          callback(errorResponse(e), null);
        }
      })();
    });
  }
  uploadFile = this.wrappingPage(uploadFile);
  handleAlert = this.wrappingPage(handleAlert);
  waitForAlerts = this.wrappingPage(waitForAlerts);
  mouseMove = this.wrappingPage(mouseMove);
  mouseWheel = this.wrappingPage(mouseWheel);
  mouseButton = this.wrappingPage(mouseButton);
  keyboardKey = this.wrappingPage(keyboardKey);
  keyboardInput = this.wrappingPage(keyboardInput);
  async setOffline(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = await setOffline(request, this.getActiveContext(call));
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async setGeolocation(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = await setGeolocation(request, this.getActiveContext(call));
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async reload(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const body = request.body;
      const result = await reload(this.getActivePage(call), body);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async setPeerId(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const oldPeer = this.peerMap[call.getPeer()];
      this.peerMap[call.getPeer()] = request.index;
      callback(null, stringResponse(oldPeer, "Successfully overrode peer id"));
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
};
PlaywrightServer = __decorateClass([
  class_async_logger
], PlaywrightServer);

// node/playwright-wrapper/index.ts
var args = process.argv.slice(2);
var host = args[0];
var port = args[1];
if (!host) {
  throw new Error(`No host defined`);
}
if (!port) {
  throw new Error(`No port defined`);
}
var server = new import_grpc_js3.Server();
server.addService(PlaywrightService, new PlaywrightServer());
server.bindAsync(`${host}:${port}`, import_grpc_js3.ServerCredentials.createInsecure(), () => {
  logger.info(`Listening on ${host}:${port}`);
});
process.on("SIGTERM", () => {
  logger.info("Received SIGTERM, shutting down gracefully");
  server.tryShutdown(() => {
    process.exit(0);
  });
});
