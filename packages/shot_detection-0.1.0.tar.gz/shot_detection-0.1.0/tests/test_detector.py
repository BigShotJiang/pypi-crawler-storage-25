from shot_detection.detector import boundaries_to_shots, find_peaks, merge_short_shots
from shot_detection.types import ShotBoundary, ShotSegment


def test_find_peaks_prefers_stronger_peak_when_too_close() -> None:
    peaks = find_peaks(__import__("numpy").array([0.0, 0.7, 0.0, 0.8, 0.0], dtype="float32"), 0.5, min_distance=10)
    assert peaks == [3]


def test_boundaries_to_shots_returns_ranges_in_ms() -> None:
    boundaries = [
        ShotBoundary(frame_index=10, timestamp_ms=1000, confidence=0.9),
        ShotBoundary(frame_index=20, timestamp_ms=2500, confidence=0.8),
    ]
    shots = boundaries_to_shots(boundaries, duration_ms=4000, min_shot_duration_ms=100)
    assert shots == [
        ShotSegment(index=0, start_ms=0, end_ms=1000),
        ShotSegment(index=1, start_ms=1000, end_ms=2500),
        ShotSegment(index=2, start_ms=2500, end_ms=4000),
    ]


def test_merge_short_shots_merges_short_middle_segment() -> None:
    shots = [
        ShotSegment(index=0, start_ms=0, end_ms=1000),
        ShotSegment(index=1, start_ms=1000, end_ms=1200),
        ShotSegment(index=2, start_ms=1200, end_ms=3000),
    ]
    merged = merge_short_shots(shots, min_shot_duration_ms=500)
    assert merged == [
        ShotSegment(index=0, start_ms=0, end_ms=1200),
        ShotSegment(index=1, start_ms=1200, end_ms=3000),
    ]
