from __future__ import annotations

import io
from pathlib import Path

from shot_detection.model_manager import ensure_default_model, get_default_model_path


class _FakeResponse:
    def __init__(self, payload: bytes) -> None:
        self._buffer = io.BytesIO(payload)

    def read(self, size: int = -1) -> bytes:
        return self._buffer.read(size)

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


def test_get_default_model_path_uses_cache_dir(tmp_path: Path) -> None:
    model_path = get_default_model_path(tmp_path)
    assert model_path == tmp_path / "models" / "transnetv2_open_fp16.onnx"


def test_ensure_default_model_downloads_once(monkeypatch, tmp_path: Path) -> None:
    payload = b"fake-onnx-model"
    calls: list[str] = []

    def fake_urlopen(url: str, timeout: int = 60) -> _FakeResponse:
        calls.append(url)
        return _FakeResponse(payload)

    monkeypatch.setattr("shot_detection.model_manager.urllib.request.urlopen", fake_urlopen)

    model_path = ensure_default_model(cache_dir=tmp_path)
    assert model_path.is_file()
    assert model_path.read_bytes() == payload
    assert len(calls) == 1

    same_path = ensure_default_model(cache_dir=tmp_path)
    assert same_path == model_path
    assert len(calls) == 1
