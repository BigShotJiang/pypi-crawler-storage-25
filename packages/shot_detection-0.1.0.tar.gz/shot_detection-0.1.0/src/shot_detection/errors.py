class ShotDetectionError(RuntimeError):
    """Raised when shot detection preprocessing or inference fails."""
