from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class VideoMetadata:
    duration_ms: int
    width: int
    height: int
    fps: float
    codec: str | None = None


@dataclass(frozen=True)
class ShotBoundary:
    frame_index: int
    timestamp_ms: int
    confidence: float


@dataclass(frozen=True)
class ShotSegment:
    index: int
    start_ms: int
    end_ms: int


@dataclass(frozen=True)
class DetectionResult:
    boundaries: list[ShotBoundary]
    shots: list[ShotSegment]
    total_frames: int
    fps: float
    duration_ms: int
