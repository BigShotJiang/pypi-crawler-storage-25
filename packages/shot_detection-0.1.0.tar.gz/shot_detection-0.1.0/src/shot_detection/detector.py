from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from .errors import ShotDetectionError
from .ffmpeg import MODEL_INPUT_HEIGHT, MODEL_INPUT_WIDTH, extract_low_res_rgb_frames, probe_video
from .inference import MODEL_INPUT_CHANNELS, WINDOW_SIZE, TransNetV2ONNX
from .model_manager import ensure_default_model
from .types import DetectionResult, ShotBoundary, ShotSegment

WINDOW_STEP = WINDOW_SIZE - 10
DEFAULT_THRESHOLD = 0.5
DEFAULT_MIN_SHOT_DURATION_MS = 500


class ShotDetector:
    def __init__(
        self,
        *,
        model_path: str | Path | None = None,
        threshold: float = DEFAULT_THRESHOLD,
        min_shot_duration_ms: int = DEFAULT_MIN_SHOT_DURATION_MS,
        model_cache_dir: str | Path | None = None,
    ) -> None:
        resolved_model_path = ensure_default_model(model_path=model_path, cache_dir=model_cache_dir)
        self.model = TransNetV2ONNX(resolved_model_path)
        self.threshold = threshold
        self.min_shot_duration_ms = min_shot_duration_ms

    def detect(self, video_path: str | Path) -> list[ShotSegment]:
        return self.detect_detailed(video_path).shots

    def detect_detailed(self, video_path: str | Path) -> DetectionResult:
        metadata = probe_video(video_path)
        raw_frames = extract_low_res_rgb_frames(video_path)
        frame_size = MODEL_INPUT_WIDTH * MODEL_INPUT_HEIGHT * MODEL_INPUT_CHANNELS
        total_frames = len(raw_frames) // frame_size

        if total_frames <= 0:
            raise ShotDetectionError("No frames were extracted from the input video")

        frames = np.frombuffer(raw_frames[: total_frames * frame_size], dtype=np.uint8).reshape(
            total_frames,
            MODEL_INPUT_HEIGHT,
            MODEL_INPUT_WIDTH,
            MODEL_INPUT_CHANNELS,
        )

        all_probs: list[float] = []

        for start in range(0, total_frames, WINDOW_STEP):
            end = min(start + WINDOW_SIZE, total_frames)
            window_frames = end - start
            if window_frames < 10:
                break

            buffer = np.zeros(
                (1, WINDOW_SIZE, MODEL_INPUT_HEIGHT, MODEL_INPUT_WIDTH, MODEL_INPUT_CHANNELS),
                dtype=np.uint8,
            )
            buffer[0, :window_frames] = frames[start:end]

            probs = self.model.infer(buffer)
            for offset in range(window_frames):
                frame_index = start + offset
                if frame_index >= len(all_probs):
                    all_probs.append(_to_boundary_probability(float(probs[offset])))

        peak_indices = find_peaks(np.asarray(all_probs, dtype=np.float32), self.threshold)
        boundaries = [
            ShotBoundary(
                frame_index=frame_index,
                timestamp_ms=int(round((frame_index / metadata.fps) * 1000)),
                confidence=float(all_probs[frame_index]),
            )
            for frame_index in peak_indices
        ]
        shots = boundaries_to_shots(boundaries, metadata.duration_ms, self.min_shot_duration_ms)

        return DetectionResult(
            boundaries=boundaries,
            shots=shots,
            total_frames=total_frames,
            fps=metadata.fps,
            duration_ms=metadata.duration_ms,
        )


def detect_shots(
    *,
    video_path: str | Path,
    model_path: str | Path | None = None,
    threshold: float = DEFAULT_THRESHOLD,
    min_shot_duration_ms: int = DEFAULT_MIN_SHOT_DURATION_MS,
    model_cache_dir: str | Path | None = None,
) -> list[ShotSegment]:
    detector = ShotDetector(
        model_path=model_path,
        threshold=threshold,
        min_shot_duration_ms=min_shot_duration_ms,
        model_cache_dir=model_cache_dir,
    )
    return detector.detect(video_path)


def detect_shots_detailed(
    *,
    video_path: str | Path,
    model_path: str | Path | None = None,
    threshold: float = DEFAULT_THRESHOLD,
    min_shot_duration_ms: int = DEFAULT_MIN_SHOT_DURATION_MS,
    model_cache_dir: str | Path | None = None,
) -> DetectionResult:
    detector = ShotDetector(
        model_path=model_path,
        threshold=threshold,
        min_shot_duration_ms=min_shot_duration_ms,
        model_cache_dir=model_cache_dir,
    )
    return detector.detect_detailed(video_path)


def _to_boundary_probability(value: float) -> float:
    if 0.0 <= value <= 1.0:
        return value
    return 1.0 / (1.0 + math.exp(-value))


def find_peaks(probs: np.ndarray, threshold: float, min_distance: int = 10) -> list[int]:
    peaks: list[int] = []

    for index in range(1, len(probs) - 1):
        current = float(probs[index])
        previous = float(probs[index - 1])
        following = float(probs[index + 1])

        if current > threshold and current > previous and current > following:
            if not peaks or index - peaks[-1] >= min_distance:
                peaks.append(index)
            elif current > float(probs[peaks[-1]]):
                peaks[-1] = index

    return peaks


def boundaries_to_shots(
    boundaries: list[ShotBoundary],
    duration_ms: int,
    min_shot_duration_ms: int = DEFAULT_MIN_SHOT_DURATION_MS,
) -> list[ShotSegment]:
    start_points = [0, *[boundary.timestamp_ms for boundary in boundaries]]
    end_points = [*[boundary.timestamp_ms for boundary in boundaries], duration_ms]

    shots = [
        ShotSegment(index=index, start_ms=start_points[index], end_ms=end_points[index])
        for index in range(len(start_points))
    ]
    return merge_short_shots(shots, min_shot_duration_ms)


def merge_short_shots(shots: list[ShotSegment], min_shot_duration_ms: int) -> list[ShotSegment]:
    if len(shots) <= 1:
        return shots

    merged = [
        {"index": shot.index, "start_ms": shot.start_ms, "end_ms": shot.end_ms}
        for shot in shots
    ]

    has_short = True
    while has_short:
        has_short = False
        next_shots: list[dict[str, int]] = []

        for index, shot in enumerate(merged):
            duration = shot["end_ms"] - shot["start_ms"]
            if duration >= min_shot_duration_ms:
                next_shots.append(shot)
                continue

            has_short = True
            previous = next_shots[-1] if next_shots else None
            following = merged[index + 1] if index + 1 < len(merged) else None

            if previous is None and following is not None:
                following["start_ms"] = shot["start_ms"]
            elif previous is not None and following is None:
                previous["end_ms"] = shot["end_ms"]
            elif previous is not None and following is not None:
                previous_duration = previous["end_ms"] - previous["start_ms"]
                following_duration = following["end_ms"] - following["start_ms"]
                if previous_duration <= following_duration:
                    previous["end_ms"] = shot["end_ms"]
                else:
                    following["start_ms"] = shot["start_ms"]

        merged = next_shots
        if len(merged) <= 1:
            break

    return [
        ShotSegment(index=index, start_ms=shot["start_ms"], end_ms=shot["end_ms"])
        for index, shot in enumerate(merged)
    ]
