from .detector import ShotDetector, detect_shots, detect_shots_detailed
from .errors import ShotDetectionError
from .model_manager import (
    DEFAULT_MODEL_URL,
    ensure_default_model,
    get_default_cache_dir,
    get_default_model_path,
)
from .types import DetectionResult, ShotBoundary, ShotSegment, VideoMetadata

__all__ = [
    "ShotDetector",
    "ShotDetectionError",
    "DEFAULT_MODEL_URL",
    "ShotBoundary",
    "ShotSegment",
    "VideoMetadata",
    "DetectionResult",
    "ensure_default_model",
    "get_default_cache_dir",
    "get_default_model_path",
    "detect_shots",
    "detect_shots_detailed",
]
