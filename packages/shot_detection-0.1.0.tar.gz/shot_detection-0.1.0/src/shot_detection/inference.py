from __future__ import annotations

from pathlib import Path

import numpy as np
import onnxruntime as ort

from .errors import ShotDetectionError

WINDOW_SIZE = 100
MODEL_INPUT_WIDTH = 48
MODEL_INPUT_HEIGHT = 27
MODEL_INPUT_CHANNELS = 3
MODEL_INPUT_SIZE = WINDOW_SIZE * MODEL_INPUT_WIDTH * MODEL_INPUT_HEIGHT * MODEL_INPUT_CHANNELS


class TransNetV2ONNX:
    def __init__(self, model_path: str | Path) -> None:
        self.model_path = str(model_path)
        self._session = self._create_session(self.model_path)
        self._input_name = self._session.get_inputs()[0].name
        self._output_name = self._session.get_outputs()[0].name
        self._input_type = self._session.get_inputs()[0].type

    def _create_session(self, model_path: str) -> ort.InferenceSession:
        path = Path(model_path)
        if not path.is_file():
            raise ShotDetectionError(f"Model file not found: {model_path}")

        available_providers = ort.get_available_providers()
        preferred_order = [
            "CoreMLExecutionProvider",
            "DmlExecutionProvider",
            "CPUExecutionProvider",
        ]
        providers = [provider for provider in preferred_order if provider in available_providers]
        if not providers:
            providers = available_providers
        if not providers:
            raise ShotDetectionError("No ONNX Runtime execution provider is available")

        try:
            return ort.InferenceSession(model_path, providers=providers)
        except Exception as exc:  # pragma: no cover
            raise ShotDetectionError(f"Failed to initialize ONNX Runtime session: {exc}") from exc

    def infer(self, frames: np.ndarray) -> np.ndarray:
        if frames.shape != (1, WINDOW_SIZE, MODEL_INPUT_HEIGHT, MODEL_INPUT_WIDTH, MODEL_INPUT_CHANNELS):
            raise ShotDetectionError(f"Unexpected frame tensor shape: {frames.shape}")

        if self._input_type == "tensor(uint8)":
            input_data = frames.astype(np.uint8, copy=False)
        else:
            input_data = frames.astype(np.float32, copy=False)

        try:
            outputs = self._session.run([self._output_name], {self._input_name: input_data})
        except Exception as exc:  # pragma: no cover
            raise ShotDetectionError(f"ONNX inference failed: {exc}") from exc

        output = np.asarray(outputs[0]).reshape(-1)
        if output.size < WINDOW_SIZE:
            raise ShotDetectionError(f"Model output is too short: {output.size}")

        return output[:WINDOW_SIZE]
