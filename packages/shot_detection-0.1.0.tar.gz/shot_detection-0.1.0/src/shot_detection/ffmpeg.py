from __future__ import annotations

import json
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from .errors import ShotDetectionError
from .types import VideoMetadata

MODEL_INPUT_WIDTH = 48
MODEL_INPUT_HEIGHT = 27


@dataclass(frozen=True)
class FfmpegRuntimeCapabilities:
    hwaccels: set[str]
    decoders: set[str]


@dataclass(frozen=True)
class FfmpegInputPlan:
    label: str
    input_options: list[str]
    uses_hardware_decode: bool


def resolve_binary(name: str) -> str:
    binary = shutil.which(name)
    if binary is None:
        raise ShotDetectionError(
            f"Required binary '{name}' was not found on PATH. Please install FFmpeg before running shot detection."
        )
    return binary


def run_command(command: list[str]) -> subprocess.CompletedProcess[bytes]:
    try:
        return subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as exc:
        message = exc.stderr.decode("utf-8", errors="replace").strip() or str(exc)
        raise ShotDetectionError(message) from exc


def _parse_ffmpeg_list(output: str) -> set[str]:
    values: set[str] = set()
    for line in output.splitlines():
        trimmed = line.strip()
        if not trimmed:
            continue

        parts = trimmed.split()
        if len(parts) >= 2 and parts[0].isupper():
            values.add(parts[1].lower())
        elif trimmed.isidentifier():
            values.add(trimmed.lower())

    return values


def get_runtime_capabilities(ffmpeg_path: str) -> FfmpegRuntimeCapabilities:
    hwaccels = _parse_ffmpeg_list(run_command([ffmpeg_path, "-hide_banner", "-hwaccels"]).stdout.decode("utf-8"))
    decoders = _parse_ffmpeg_list(run_command([ffmpeg_path, "-hide_banner", "-decoders"]).stdout.decode("utf-8"))
    return FfmpegRuntimeCapabilities(hwaccels=hwaccels, decoders=decoders)


def _linux_vaapi_options() -> list[str] | None:
    dri_dir = Path("/dev/dri")
    if not dri_dir.exists():
        return None

    render_nodes = sorted(dri_dir.glob("renderD*"))
    if not render_nodes:
        return None

    return [
        "-threads",
        "1",
        "-hwaccel",
        "vaapi",
        "-hwaccel_output_format",
        "vaapi",
        "-vaapi_device",
        str(render_nodes[0]),
    ]


def get_decode_plans(platform_name: str | None = None) -> list[FfmpegInputPlan]:
    ffmpeg_path = resolve_binary("ffmpeg")
    capabilities = get_runtime_capabilities(ffmpeg_path)
    platform_name = platform_name or sys.platform

    plans: list[FfmpegInputPlan] = []

    if platform_name == "darwin" and "videotoolbox" in capabilities.hwaccels:
        plans.append(
            FfmpegInputPlan(
                label="videotoolbox-hardware",
                input_options=["-threads", "1", "-hwaccel", "videotoolbox"],
                uses_hardware_decode=True,
            )
        )

    if platform_name == "win32":
        if "d3d12va" in capabilities.hwaccels:
            plans.append(
                FfmpegInputPlan(
                    label="d3d12va-hardware",
                    input_options=["-threads", "1", "-hwaccel", "d3d12va", "-hwaccel_output_format", "d3d12"],
                    uses_hardware_decode=True,
                )
            )
        if "d3d11va" in capabilities.hwaccels:
            plans.append(
                FfmpegInputPlan(
                    label="d3d11va-hardware",
                    input_options=["-threads", "1", "-hwaccel", "d3d11va", "-hwaccel_output_format", "d3d11"],
                    uses_hardware_decode=True,
                )
            )
        if "dxva2" in capabilities.hwaccels:
            plans.append(
                FfmpegInputPlan(
                    label="dxva2-hardware",
                    input_options=["-threads", "1", "-hwaccel", "dxva2", "-hwaccel_output_format", "dxva2_vld"],
                    uses_hardware_decode=True,
                )
            )

    if platform_name.startswith("linux") and "vaapi" in capabilities.hwaccels:
        vaapi_options = _linux_vaapi_options()
        if vaapi_options is not None:
            plans.append(
                FfmpegInputPlan(
                    label="vaapi-hardware",
                    input_options=vaapi_options,
                    uses_hardware_decode=True,
                )
            )

    plans.append(
        FfmpegInputPlan(
            label="software-fallback",
            input_options=["-threads", "1"],
            uses_hardware_decode=False,
        )
    )
    return plans


def _requires_hwdownload(plan: FfmpegInputPlan, platform_name: str | None = None) -> bool:
    platform_name = platform_name or sys.platform
    if platform_name == "darwin" and plan.label == "videotoolbox-hardware":
        return False
    return plan.uses_hardware_decode


def probe_video(video_path: str | Path) -> VideoMetadata:
    ffprobe_path = resolve_binary("ffprobe")
    result = run_command(
        [
            ffprobe_path,
            "-v",
            "error",
            "-show_streams",
            "-show_format",
            "-print_format",
            "json",
            str(video_path),
        ]
    )

    try:
        payload = json.loads(result.stdout.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise ShotDetectionError("Failed to parse ffprobe output") from exc

    streams = payload.get("streams")
    if not isinstance(streams, list):
        raise ShotDetectionError("ffprobe did not return stream metadata")

    video_stream = next((stream for stream in streams if stream.get("codec_type") == "video"), None)
    if not isinstance(video_stream, dict):
        raise ShotDetectionError("No video stream found in the input file")

    width = int(video_stream.get("width") or 0)
    height = int(video_stream.get("height") or 0)
    fps = _parse_frame_rate(video_stream.get("avg_frame_rate") or video_stream.get("r_frame_rate"))
    duration_seconds = _parse_duration_seconds(payload.get("format"), video_stream)

    if width <= 0 or height <= 0 or fps <= 0 or duration_seconds <= 0:
        raise ShotDetectionError("Unable to determine valid video metadata")

    return VideoMetadata(
        duration_ms=int(round(duration_seconds * 1000)),
        width=width,
        height=height,
        fps=fps,
        codec=video_stream.get("codec_name"),
    )


def _parse_frame_rate(value: object) -> float:
    if not isinstance(value, str) or not value:
        return 0.0

    if "/" in value:
        numerator_text, denominator_text = value.split("/", 1)
        try:
            numerator = float(numerator_text)
            denominator = float(denominator_text)
        except ValueError:
            return 0.0
        return 0.0 if denominator == 0 else numerator / denominator

    try:
        return float(value)
    except ValueError:
        return 0.0


def _parse_duration_seconds(format_info: object, video_stream: dict[str, object]) -> float:
    if isinstance(format_info, dict):
        try:
            duration = float(format_info.get("duration") or 0.0)
        except (TypeError, ValueError):
            duration = 0.0
        if duration > 0:
            return duration

    try:
        return float(video_stream.get("duration") or 0.0)
    except (TypeError, ValueError):
        return 0.0


def extract_low_res_rgb_frames(
    video_path: str | Path,
    *,
    width: int = MODEL_INPUT_WIDTH,
    height: int = MODEL_INPUT_HEIGHT,
) -> bytes:
    ffmpeg_path = resolve_binary("ffmpeg")
    last_error: ShotDetectionError | None = None

    for plan in get_decode_plans():
        scale_filter = f"scale={width}:{height}:flags=fast_bilinear"
        if _requires_hwdownload(plan):
            filter_chain = f"hwdownload,format=nv12,{scale_filter},format=rgb24"
        else:
            filter_chain = f"{scale_filter},format=rgb24"

        command = [
            ffmpeg_path,
            "-v",
            "error",
            *plan.input_options,
            "-i",
            str(video_path),
            "-vf",
            filter_chain,
            "-pix_fmt",
            "rgb24",
            "-vsync",
            "0",
            "-f",
            "rawvideo",
            "pipe:1",
        ]

        try:
            return run_command(command).stdout
        except ShotDetectionError as exc:
            last_error = exc

    if last_error is not None:
        raise last_error

    raise ShotDetectionError("No FFmpeg decode plan was available")
