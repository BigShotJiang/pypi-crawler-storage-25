from __future__ import annotations

import os
import tempfile
import urllib.request
from pathlib import Path

from .errors import ShotDetectionError

DEFAULT_MODEL_URL = "https://download.shotai.io/model/shot-detection/transnetv2_open_fp16.onnx"
DEFAULT_MODEL_FILENAME = "transnetv2_open_fp16.onnx"
DEFAULT_CACHE_DIRNAME = "shot-detection"


def get_default_cache_dir() -> Path:
    override = os.environ.get("SHOT_DETECTION_CACHE_DIR")
    if override:
        return Path(override).expanduser()

    if os.name == "nt":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            return Path(local_app_data) / DEFAULT_CACHE_DIRNAME

    xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache_home:
        return Path(xdg_cache_home) / DEFAULT_CACHE_DIRNAME

    return Path.home() / ".cache" / DEFAULT_CACHE_DIRNAME


def get_default_model_path(cache_dir: str | Path | None = None) -> Path:
    base_dir = Path(cache_dir).expanduser() if cache_dir is not None else get_default_cache_dir()
    return base_dir / "models" / DEFAULT_MODEL_FILENAME


def ensure_default_model(
    *,
    model_path: str | Path | None = None,
    cache_dir: str | Path | None = None,
    model_url: str = DEFAULT_MODEL_URL,
    timeout_seconds: int = 60,
) -> Path:
    resolved_path = Path(model_path).expanduser() if model_path is not None else get_default_model_path(cache_dir)
    if resolved_path.is_file():
        return resolved_path

    resolved_path.parent.mkdir(parents=True, exist_ok=True)
    temp_file_handle = tempfile.NamedTemporaryFile(
        prefix=resolved_path.stem + ".",
        suffix=".tmp",
        dir=resolved_path.parent,
        delete=False,
    )
    temp_path = Path(temp_file_handle.name)
    temp_file_handle.close()

    try:
        with urllib.request.urlopen(model_url, timeout=timeout_seconds) as response, temp_path.open("wb") as file_obj:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                file_obj.write(chunk)

        if temp_path.stat().st_size == 0:
            raise ShotDetectionError(f"Downloaded model is empty: {model_url}")

        os.replace(temp_path, resolved_path)
        return resolved_path
    except Exception as exc:
        temp_path.unlink(missing_ok=True)
        raise ShotDetectionError(
            f"Failed to download the default shot detection model from {model_url}: {exc}"
        ) from exc
