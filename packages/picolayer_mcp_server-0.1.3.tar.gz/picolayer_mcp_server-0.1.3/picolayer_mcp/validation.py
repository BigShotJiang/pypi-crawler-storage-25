"""Picolayer YAML validation used by the MCP ``picolayer_validate_config`` tool.

Mirrors ``containers/renode-executor/generators/config_schema.py`` but is
intentionally a separate, dependency-free copy so the MCP server can ship as
a standalone wheel without pulling in the executor's transitive dependencies
(pyrenode3, etc.).

When ``config_schema.py`` evolves, this file must be kept in sync. The
``test_validation_parity`` test in ``tests/test_validation.py`` checks that
basic shapes match.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import yaml

from picolayer_mcp.catalog import get_board

# Single source of truth for valid CPU types — keep in lockstep with
# containers/renode-executor/generators/repl_generator.py::_CPU_MAP
VALID_CPUS: set[str] = {
    "cortex-m0",
    "cortex-m0plus",
    "cortex-m3",
    "cortex-m4",
    "cortex-m4f",
    "cortex-m7",
    "cortex-m7f",
    "cortex-m33",
    "cortex-r52",
    "riscv32",
    "riscv64",
}

# Peripheral types the simple-mode generator understands. Anything outside
# this set must be expressed via `renode.platform_repl_inline`.
VALID_PERIPHERAL_TYPES: set[str] = {
    "uart",
    "gpio",
    "i2c",
    "spi",
    "timer",
    "adc",
    "i2c_device",
    "ble",
}

# Valid escape-hatch enum values
VALID_CUSTOM_PERIPHERAL_KINDS: set[str] = {"python", "csharp", "svd_tag"}
VALID_COSIM_SIMULATORS: set[str] = {"verilator", "questa", "vcs"}
VALID_COSIM_MODES: set[str] = {"direct_link", "dpi"}
VALID_COSIM_BUSES: set[str] = {"ahb", "apb3", "axi4", "axi4_lite", "wishbone", "cfu"}


@dataclass
class ValidationResult:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    escape_hatch_unverified: bool = False

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, object]:
        return {
            "ok": self.ok,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "escape_hatch_unverified": self.escape_hatch_unverified,
        }


def _coerce_int(value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value, 0)
        except ValueError:
            return None
    return None


def _parse_size_bytes(size: str) -> int | None:
    s = size.strip().upper()
    try:
        if s.endswith("MB"):
            return int(float(s[:-2]) * 1024 * 1024)
        if s.endswith("KB"):
            return int(float(s[:-2]) * 1024)
        if s.endswith("B"):
            return int(s[:-1])
        return int(s)
    except (ValueError, IndexError):  # fmt: skip
        return None


def _validate_top_level(data: object, result: ValidationResult) -> dict[str, object] | None:
    if not isinstance(data, dict):
        result.errors.append("picolayer.yml must be a YAML mapping")
        return None
    has_board = "board" in data
    has_hardware = "hardware" in data
    if has_board and has_hardware:
        result.errors.append("Cannot specify both 'board' and 'hardware'")
        return None
    if not has_board and not has_hardware:
        result.errors.append("Must specify either 'board' or 'hardware'")
        return None
    return data


def _validate_board(data: dict[str, object], result: ValidationResult) -> None:
    board = data.get("board")
    if not isinstance(board, str) or not board:
        result.errors.append("'board' must be a non-empty string")
        return
    if get_board(board) is None:
        result.errors.append(
            f"Unknown board '{board}'. See picolayer://board-catalog for valid names."
        )


def _validate_memory(  # noqa: C901  (parsing + overlap detection in one pass)
    memory: object, result: ValidationResult
) -> list[tuple[str, int, int]]:
    if not isinstance(memory, dict):
        if memory is not None:
            result.errors.append("hardware.memory must be a mapping")
        return []
    regions: list[tuple[str, int, int]] = []
    for name, spec in memory.items():
        if not isinstance(spec, dict):
            result.errors.append(f"memory.{name} must be a mapping with 'base' and 'size'")
            continue
        base = _coerce_int(spec.get("base"))
        size_raw = spec.get("size")
        if base is None:
            result.errors.append(f"memory.{name}: 'base' missing or invalid")
            continue
        if not isinstance(size_raw, str):
            result.errors.append(f"memory.{name}: 'size' must be a string like '1MB'")
            continue
        size_bytes = _parse_size_bytes(size_raw)
        if size_bytes is None or size_bytes <= 0:
            result.errors.append(f"memory.{name}: cannot parse size '{size_raw}'")
            continue
        regions.append((str(name), base, size_bytes))
    # Memory overlap detection
    for i, (n1, b1, s1) in enumerate(regions):
        end1 = b1 + s1
        for n2, b2, s2 in regions[i + 1 :]:
            end2 = b2 + s2
            if b1 < end2 and b2 < end1:
                result.errors.append(
                    f"Memory regions overlap: '{n1}' (0x{b1:08x}-0x{end1:08x}) "
                    f"and '{n2}' (0x{b2:08x}-0x{end2:08x})"
                )
    return regions


def _validate_peripherals(  # noqa: C901  (per-peripheral checks add branches)
    peripherals: object, result: ValidationResult
) -> None:
    if not isinstance(peripherals, dict):
        if peripherals is not None:
            result.errors.append("hardware.peripherals must be a mapping")
        return
    bases: dict[int, str] = {}
    for name, spec in peripherals.items():
        if not isinstance(spec, dict):
            result.errors.append(f"peripherals.{name} must be a mapping")
            continue
        ptype = spec.get("type")
        if not isinstance(ptype, str) or not ptype:
            result.errors.append(f"peripherals.{name}: 'type' is required")
            continue
        if ptype not in VALID_PERIPHERAL_TYPES:
            result.warnings.append(
                f"peripherals.{name}: unknown type '{ptype}'. The generator will skip this "
                f"peripheral. Use one of {sorted(VALID_PERIPHERAL_TYPES)} or drop down to "
                f"renode.platform_repl_inline."
            )
        # UART naming consistency
        if str(name).lower().startswith("uart") and ptype != "uart":
            result.warnings.append(f"peripherals.{name}: name suggests UART but type is '{ptype}'")
        if ptype == "uart" and not str(name).lower().startswith(("uart", "usart", "serial")):
            result.warnings.append(
                f"peripherals.{name}: type is 'uart' but name does not look like a UART"
            )
        # Base address conflict
        base = _coerce_int(spec.get("base"))
        if base is not None:
            existing = bases.get(base)
            if existing is not None and existing != name:
                result.errors.append(
                    f"peripherals.{name} and peripherals.{existing} both register at 0x{base:08x}"
                )
            else:
                bases[base] = str(name)


def _validate_hardware(data: dict[str, object], result: ValidationResult) -> None:
    hardware = data.get("hardware")
    if not isinstance(hardware, dict):
        result.errors.append("'hardware' must be a mapping")
        return
    cpu = hardware.get("cpu")
    if not isinstance(cpu, str) or not cpu:
        result.errors.append("hardware.cpu is required")
    elif cpu.lower() not in VALID_CPUS:
        result.warnings.append(
            f"hardware.cpu '{cpu}' is not in the built-in CPU map. The job will fail unless "
            f"you also provide renode.platform_repl_inline. Valid CPUs: {sorted(VALID_CPUS)}"
        )
    _validate_memory(hardware.get("memory"), result)
    _validate_peripherals(hardware.get("peripherals"), result)


def _validate_register_at(text: str) -> bool:
    """Cheap surface validation of a Renode `register_at` string."""
    s = text.strip()
    if not s.startswith("sysbus"):
        return False
    rest = s[len("sysbus") :].strip()
    if rest.startswith("<") and rest.endswith(">"):
        body = rest[1:-1].strip()
        # <addr> or <addr, +size>
        if "," in body:
            addr_part, size_part = (p.strip() for p in body.split(",", 1))
            if not size_part.startswith("+"):
                return False
            return _coerce_int(addr_part) is not None and _coerce_int(size_part[1:]) is not None
        return _coerce_int(body) is not None
    # bare address: "sysbus 0x40000000"
    return _coerce_int(rest) is not None


def _validate_renode_block(  # noqa: C901  (covers all 7 escape-hatch fields)
    data: dict[str, object], result: ValidationResult
) -> None:
    renode = data.get("renode")
    if renode is None:
        return
    if not isinstance(renode, dict):
        result.errors.append("'renode' must be a mapping")
        return
    result.escape_hatch_unverified = True

    # 4. machines
    machines = renode.get("machines")
    if machines is not None:
        if not isinstance(machines, list):
            result.errors.append("renode.machines must be a list")
        else:
            for i, m in enumerate(machines):
                if not isinstance(m, dict):
                    result.errors.append(f"renode.machines[{i}] must be a mapping")
                    continue
                has_board = "board" in m
                has_hw = "hardware" in m
                if has_board and has_hw:
                    result.errors.append(
                        f"renode.machines[{i}] cannot specify both 'board' and 'hardware'"
                    )
                if not has_board and not has_hw:
                    result.errors.append(
                        f"renode.machines[{i}] must specify either 'board' or 'hardware'"
                    )

    # 5. custom_peripherals
    customs = renode.get("custom_peripherals")
    if customs is not None:
        if not isinstance(customs, list):
            result.errors.append("renode.custom_peripherals must be a list")
        else:
            for i, c in enumerate(customs):
                if not isinstance(c, dict):
                    result.errors.append(f"renode.custom_peripherals[{i}] must be a mapping")
                    continue
                kind = c.get("kind")
                if kind not in VALID_CUSTOM_PERIPHERAL_KINDS:
                    result.errors.append(
                        f"renode.custom_peripherals[{i}].kind must be one of "
                        f"{sorted(VALID_CUSTOM_PERIPHERAL_KINDS)}"
                    )
                source = c.get("source")
                if not isinstance(source, str) or not source:
                    result.errors.append(f"renode.custom_peripherals[{i}].source is required")
                register_at = c.get("register_at")
                if isinstance(register_at, str) and not _validate_register_at(register_at):
                    result.errors.append(
                        f"renode.custom_peripherals[{i}].register_at: invalid syntax. "
                        f"Expected 'sysbus <addr, +size>' or 'sysbus addr'."
                    )

    # 6. cosimulation
    cosims = renode.get("cosimulation")
    if cosims is not None:
        if not isinstance(cosims, list):
            result.errors.append("renode.cosimulation must be a list")
        else:
            for i, cs in enumerate(cosims):
                if not isinstance(cs, dict):
                    result.errors.append(f"renode.cosimulation[{i}] must be a mapping")
                    continue
                simulator = cs.get("simulator")
                if simulator not in VALID_COSIM_SIMULATORS:
                    result.errors.append(
                        f"renode.cosimulation[{i}].simulator must be one of "
                        f"{sorted(VALID_COSIM_SIMULATORS)}"
                    )
                mode = cs.get("mode")
                if mode is not None and mode not in VALID_COSIM_MODES:
                    result.errors.append(
                        f"renode.cosimulation[{i}].mode must be one of {sorted(VALID_COSIM_MODES)}"
                    )
                if mode == "direct_link" and simulator != "verilator":
                    result.errors.append(
                        f"renode.cosimulation[{i}]: direct_link mode is only supported "
                        f"with verilator"
                    )
                bus = cs.get("bus")
                if bus not in VALID_COSIM_BUSES:
                    result.errors.append(
                        f"renode.cosimulation[{i}].bus must be one of {sorted(VALID_COSIM_BUSES)}"
                    )
                library = cs.get("library")
                if not isinstance(library, str) or not library:
                    result.errors.append(f"renode.cosimulation[{i}].library is required")

    # 7. irqs (light validation)
    irqs = renode.get("irqs")
    if irqs is not None and not isinstance(irqs, list):
        result.errors.append("renode.irqs must be a list")


def _validate_timeout(data: dict[str, object], result: ValidationResult) -> None:
    timeout = data.get("timeout", 300)
    if not isinstance(timeout, int) or timeout <= 0:
        result.errors.append("'timeout' must be a positive integer")
        return
    if timeout < 10:
        result.warnings.append(
            f"timeout={timeout}s is very short — UART boot lines may not arrive in time"
        )
    if timeout > 3600:
        result.warnings.append(
            f"timeout={timeout}s exceeds typical infrastructure max (3600s); the executor "
            f"task or session container may be killed before completion"
        )


def validate_config_string(text: str) -> ValidationResult:
    """Parse and validate a picolayer.yml string. Never raises."""
    result = ValidationResult()
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        result.errors.append(f"YAML parse error: {exc}")
        return result
    parsed = _validate_top_level(data, result)
    if parsed is None:
        return result
    if "board" in parsed:
        _validate_board(parsed, result)
    elif "hardware" in parsed:
        _validate_hardware(parsed, result)
    _validate_renode_block(parsed, result)
    _validate_timeout(parsed, result)
    return result
