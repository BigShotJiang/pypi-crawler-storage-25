"""API key resolution for the Picolayer MCP server.

Search order:
  1. ``PICOLAYER_API_KEY`` environment variable
  2. ``~/.picolayer/config.toml`` (the same file the CLI writes via ``picolayer login``)

The endpoint follows the same precedence:
  1. ``PICOLAYER_API_ENDPOINT`` environment variable
  2. ``api_endpoint`` in ``~/.picolayer/config.toml``
  3. ``DEFAULT_API_ENDPOINT``
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

DEFAULT_API_ENDPOINT = "https://api.picolayer.dev"
CONFIG_PATH = Path.home() / ".picolayer" / "config.toml"


class AuthError(Exception):
    """Raised when no API key can be located."""


@dataclass(frozen=True)
class AuthContext:
    """Resolved API key + endpoint."""

    api_key: str
    api_endpoint: str


def _read_config_file() -> dict[str, object]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        with open(CONFIG_PATH, "rb") as f:
            return tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):  # fmt: skip
        return {}


def resolve_auth() -> AuthContext:
    """Resolve API credentials from env or the CLI's shared config file."""
    api_key = os.environ.get("PICOLAYER_API_KEY")
    api_endpoint = os.environ.get("PICOLAYER_API_ENDPOINT")

    if not api_key or not api_endpoint:
        cfg = _read_config_file()
        auth_section = cfg.get("auth", {})
        if isinstance(auth_section, dict):
            if not api_key:
                value = auth_section.get("api_key")
                if isinstance(value, str):
                    api_key = value
            if not api_endpoint:
                value = auth_section.get("api_endpoint")
                if isinstance(value, str):
                    api_endpoint = value

    if not api_key:
        raise AuthError(
            "No Picolayer API key found. Set PICOLAYER_API_KEY or run `picolayer login`."
        )

    return AuthContext(
        api_key=api_key,
        api_endpoint=api_endpoint or DEFAULT_API_ENDPOINT,
    )
