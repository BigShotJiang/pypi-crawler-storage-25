"""``picolayer://robot-keywords`` — Robot Framework keyword reference for Renode tests.

These are the keywords most commonly used in Picolayer test suites. The
agent uses this when generating ``.robot`` files. Renode ships a much
larger keyword library — see
https://renode.readthedocs.io/en/latest/basic/testing.html for the full set.
"""

from __future__ import annotations

import json

KEYWORDS: list[dict[str, object]] = [
    {
        "keyword": "Execute Script",
        "args": ["script_path"],
        "description": "Run a .resc setup script. Picolayer auto-generates one at ${CURDIR}/setup.resc.",
        "example": "Execute Script  ${CURDIR}/setup.resc",
    },
    {
        "keyword": "Create LED Tester",
        "args": ["led_path", "defaultTimeout=<seconds>"],
        "description": "Create a tester observing an LED GPIO output.",
        "example": "Create LED Tester  sysbus.gpioPortD.UserLED  defaultTimeout=5",
    },
    {
        "keyword": "Assert LED State",
        "args": ["state", "timeout=<seconds>"],
        "description": "Wait for the LED to reach the given state (true|false).",
        "example": "Assert LED State  true",
    },
    {
        "keyword": "Create Terminal Tester",
        "args": ["uart_path", "defaultTimeout=<seconds>"],
        "description": "Attach a terminal tester to a UART so subsequent Wait For Line keywords work.",
        "example": "Create Terminal Tester  sysbus.usart2  defaultTimeout=10",
    },
    {
        "keyword": "Wait For Line On Uart",
        "args": ["expected_text", "timeout=<seconds>", "treatAsRegex=<bool>"],
        "description": "Block until the given line appears on the most recent terminal tester.",
        "example": "Wait For Line On Uart  Boot OK  timeout=5",
    },
    {
        "keyword": "Write Line To Uart",
        "args": ["text"],
        "description": "Inject a line on the most recent terminal tester.",
        "example": "Write Line To Uart  status",
    },
    {
        "keyword": "Start Emulation",
        "args": [],
        "description": "Start the Renode emulation. Required after machine setup before any assertions.",
        "example": "Start Emulation",
    },
    {
        "keyword": "Pause Emulation",
        "args": [],
        "description": "Pause the running emulation.",
    },
    {
        "keyword": "Reset Emulation",
        "args": [],
        "description": "Reset the current machine.",
    },
    {
        "keyword": "Execute Command",
        "args": ["renode_monitor_command"],
        "description": "Run an arbitrary Renode Monitor command.",
        "example": "Execute Command  cpu PerformanceInMips 125",
    },
]

GUIDANCE = """\
A Picolayer Robot test always starts by calling `Execute Script` against
`${CURDIR}/setup.resc` (which Picolayer generates from your `picolayer.yml`),
then either drives UART input/output via Terminal Tester keywords or watches
GPIO state via LED Tester keywords. `Start Emulation` must be called before
the first assertion. Use `Wait For Line On Uart` (with a sensible timeout)
rather than `Sleep` to keep tests deterministic.
"""


def robot_keywords_resource() -> str:
    return json.dumps(
        {
            "version": 1,
            "guidance": GUIDANCE.strip(),
            "keywords": KEYWORDS,
        },
        indent=2,
    )
