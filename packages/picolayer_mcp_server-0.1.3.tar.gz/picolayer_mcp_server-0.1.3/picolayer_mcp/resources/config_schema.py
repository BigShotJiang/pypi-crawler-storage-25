"""``picolayer://config-schema`` — picolayer.yml field reference.

This is the document an agent reads before generating a ``picolayer.yml``.
It is intentionally human-and-LLM-readable rather than a JSON Schema, because
LLMs trained on YAML/Markdown reference docs produce more accurate emit-the-
file results than ones reading raw JSON Schema.

Includes the **escape-hatch** ``renode:`` block (P0.8) so the agent never
hits a wall when the simple surface can't express the target.
"""

from __future__ import annotations

CONFIG_SCHEMA_DOC = """\
# picolayer.yml schema

`picolayer.yml` describes the **board / hardware** Picolayer should emulate.
Firmware and tests are supplied separately (via the CLI, GitHub Action, or
session API).

There are three layers of expressiveness, in order of complexity:

  1. **Board shortcut** — `board: <name>` (one line, uses the board catalog)
  2. **Custom hardware** — `hardware: { ... }` (CPU + memory + peripherals)
  3. **Renode escape hatches** — `renode: { ... }` (custom .repl, custom
     peripherals, co-simulation, multi-machine setups, explicit IRQs)

Pick the simplest layer that fits the target. Use escape hatches only when
the simple surface cannot express what you need.

---

## Top-level fields

| Field | Type | Required | Default | Description |
|---|---|---|---|---|
| `board` | string | XOR `hardware` | — | Board name from the catalog. Use `picolayer://board-catalog` to enumerate. |
| `hardware` | object | XOR `board` | — | Custom hardware definition. |
| `timeout` | int (seconds) | no | `300` | Per-test timeout. |
| `renode` | object | no | — | Escape-hatch fields (see below). |

Exactly one of `board` or `hardware` is required. `renode` is optional and
can be combined with either.

---

## `hardware:` block (custom boards)

```yaml
hardware:
  cpu: cortex-m4f          # see picolayer://cpu-types for valid values
  memory:
    flash:
      base: 0x08000000
      size: 1MB
    sram:
      base: 0x20000000
      size: 256KB
  peripherals:
    uart0:
      type: uart           # see picolayer://peripheral-types
      base: 0x40004400
    gpio0:
      type: gpio
      base: 0x40020000
    sensor:
      type: i2c            # I2C controller
      base: 0x40005400
    tmp102:
      type: i2c_device
      address: 0x48        # 7-bit I2C address
      model: TMP102
```

`base:` (peripheral base address) and `address:` (I2C device address) are
both accepted as hex literals or strings (`0x40004400` or `"0x40004400"`).

---

## `renode:` escape hatches (power users)

Use these when the simple surface cannot express what Renode needs.
Picolayer **does not statically validate** anything inside this block —
it surface-checks file references and registration syntax, then trusts you.
Configurations that use any of these fields are flagged
`escape_hatch_unverified` so the dashboard can mark the run as
"used advanced features (not statically verified)".

```yaml
renode:
  # 1. A complete .repl file you wrote yourself.
  platform_repl: platforms/my_custom_soc.repl

  # 2. Inline .repl snippet — merged with the catalog/hardware-generated .repl.
  platform_repl_inline: |
    dmaController: DMA.CustomDMAController @ sysbus <0x40080000, +0x400>
        numberOfChannels: 8
        IRQ -> nvic@11

  # 3. Init script appended to the generated .resc before `start`.
  init_resc: |
    logLevel 0 sysbus.uart0
    sysbus.uart0 CreateFileBackend @/tmp/uart0.log true
    emulation CreateSwitch "switch1"

  # 4. Multi-machine setups — each entry becomes a `mach create` in .resc.
  machines:
    - name: primary
      board: stm32f4_discovery   # OR an inline hardware: { ... } block
      firmware: build/primary.elf
      connect_uart_to: switch1
    - name: sniffer
      board: nrf52840dk
      firmware: build/sniffer.elf
      connect_radio_to: wirelessMedium1

  # 5. Custom peripherals — Python (fast path) or C# (Register Framework).
  custom_peripherals:
    - name: myAccelerator
      kind: python              # python | csharp | svd_tag
      source: peripherals/my_accel.py
      register_at: "sysbus <0x50000000, +0x1000>"
      irq: "nvic@27"
    - name: fastCrypto
      kind: csharp
      source: peripherals/FastCrypto.cs
      register_at: "sysbus <0x60000000, +0x2000>"

  # 6. HDL co-simulation (Verilator, Questa, VCS).
  cosimulation:
    - name: verilatedDma
      simulator: verilator      # verilator | questa | vcs
      mode: direct_link         # direct_link (Verilator only) | dpi
      library: sim/build/VDmaController.so
      bus: axi4_lite            # ahb | apb3 | axi4 | axi4_lite | wishbone | cfu
      register_at: "sysbus <0x70000000, +0x1000>"

  # 7. Explicit IRQ wiring overriding auto-generated fan-out.
  irqs:
    - from: "uart0.IRQ"
      to: ["nvic@37", "dma1.channel4@0"]
```

### Path resolution for escape-hatch files

`platform_repl`, `custom_peripherals[].source`, `cosimulation[].library`,
`machines[].firmware`, etc. are resolved against the
`.picolayer/attachments/` directory in the upload bundle. The CLI (and the
GitHub Action) automatically include any files in `.picolayer/attachments/`
when uploading.

---

## Examples

See `picolayer://examples/{id}` for working `picolayer.yml` files. Use them
as few-shot prompts when generating new configs.

## Validation

`picolayer_validate_config` (MCP tool) parses + validates a config string and
returns errors and warnings. Use it before submitting a job or creating a
session.
"""


def config_schema_resource() -> str:
    return CONFIG_SCHEMA_DOC
