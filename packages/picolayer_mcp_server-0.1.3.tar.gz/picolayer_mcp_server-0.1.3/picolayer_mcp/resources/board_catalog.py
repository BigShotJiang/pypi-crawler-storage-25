"""``picolayer://board-catalog`` — full board catalog as JSON."""

from __future__ import annotations

import json

from picolayer_mcp.catalog import board_to_dict, load_catalog


def board_catalog_resource() -> str:
    """Return the canonical board catalog as a JSON string.

    Includes alias entries (with ``alias_of``) so an agent can map a board
    name in code to its canonical entry, but the agent should prefer
    canonical names when emitting ``picolayer.yml``.
    """
    boards = [board_to_dict(b) for b in load_catalog()]
    return json.dumps(
        {
            "version": 1,
            "description": (
                "Canonical Picolayer board catalog. Use the 'name' field as "
                "the value for `board:` in picolayer.yml. base_address is a "
                "hex string. If a board has alias_of set, prefer the canonical "
                "name in generated configs."
            ),
            "boards": boards,
        },
        indent=2,
    )
