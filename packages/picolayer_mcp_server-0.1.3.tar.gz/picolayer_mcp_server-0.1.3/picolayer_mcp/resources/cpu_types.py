"""``picolayer://cpu-types`` — CPU types + architecture families.

Mirrors ``containers/renode-executor/generators/repl_generator.py``'s
``_CPU_MAP``. Tells the agent which `cpu:` strings are valid in the
``hardware:`` block and what each maps to in Renode.
"""

from __future__ import annotations

import json

CPU_TYPES: list[dict[str, object]] = [
    {
        "cpu": "cortex-m0",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m0",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-m0plus",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m0+",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-m3",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m3",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-m4",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m4",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-m4f",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m4f",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-m7",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m7",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-m7f",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m7f",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-m33",
        "renode_class": "CPU.CortexM",
        "renode_cpu_type": "cortex-m33",
        "family": "cortex-m",
        "needs_nvic": True,
    },
    {
        "cpu": "cortex-r52",
        "renode_class": "CPU.ARMv8R",
        "renode_cpu_type": "cortex-r52",
        "family": "cortex-r",
        "needs_nvic": False,
    },
    {
        "cpu": "riscv32",
        "renode_class": "CPU.RiscV32",
        "renode_cpu_type": "rv32imac_zicsr_zifencei",
        "family": "riscv",
        "needs_nvic": False,
    },
    {
        "cpu": "riscv64",
        "renode_class": "CPU.RiscV64",
        "renode_cpu_type": "rv64imac_zicsr_zifencei",
        "family": "riscv",
        "needs_nvic": False,
    },
]

GUIDANCE = """\
- For Cortex-M targets, Picolayer auto-emits an NVIC at 0xE000E000 — you do
  not need to declare it.
- For CPUs not in this list, you have two options:
    1. Use the `renode:` escape hatch with `platform_repl_inline` to declare
       the CPU directly.
    2. Add the CPU to `_CPU_MAP` in repl_generator.py upstream — Picolayer
       welcomes PRs to expand this set.
- Renode's full supported-board list is at
  https://renode.readthedocs.io/en/latest/introduction/supported-boards.html
- Picolayer currently runs Renode 1.16.1; verify CPU types against that
  version's `.repl` files when adding new entries.
"""


def cpu_types_resource() -> str:
    return json.dumps(
        {
            "version": 1,
            "guidance": GUIDANCE.strip(),
            "cpus": CPU_TYPES,
        },
        indent=2,
    )
