"""``picolayer://peripheral-types`` — peripheral types + Renode model mappings.

Mirrors ``containers/renode-executor/generators/repl_generator.py``'s
``_PERIPHERAL_MAP`` so the agent knows what types it can use in the
``hardware.peripherals`` block and what each maps to in Renode.
"""

from __future__ import annotations

import json

PERIPHERAL_TYPES: list[dict[str, object]] = [
    {
        "type": "uart",
        "renode_model_by_family": {
            "cortex-m": "UART.STM32_UART",
            "riscv": "UART.SiFive_UART",
            "cortex-r": "UART.PL011",
        },
        "requires_register_window": True,
        "register_window_size": "0x100",
        "notes": "Picolayer auto-selects the model from the CPU family.",
    },
    {
        "type": "gpio",
        "renode_model": "GPIOPort.STM32_GPIOPort",
        "requires_register_window": True,
        "register_window_size": "0x400",
        "notes": "Currently uses STM32 model regardless of CPU family. Bug-for-bug compatible with stm32f4.repl.",
    },
    {
        "type": "i2c",
        "renode_model": "I2C.STM32F4_I2C",
        "requires_register_window": False,
        "notes": "I2C controller. Bare-address registration.",
    },
    {
        "type": "spi",
        "renode_model": "SPI.STM32SPI",
        "requires_register_window": False,
        "notes": "SPI controller. Bare-address registration.",
    },
    {
        "type": "timer",
        "renode_model": "Timers.STM32_Timer",
        "requires_register_window": True,
        "register_window_size": "0x400",
        "notes": "Auto-emits frequency=10000000 and initialLimit=0xFFFFFFFF as defaults.",
    },
    {
        "type": "adc",
        "renode_model": "Analog.STM32_ADC",
        "requires_register_window": False,
    },
    {
        "type": "i2c_device",
        "renode_model": "depends on `model:` field (e.g. TMP102)",
        "requires_register_window": False,
        "notes": (
            "I2C *device* (not controller). Use `address:` instead of `base:` "
            "for the 7-bit I2C address. Set `model:` to a Renode I2C device class."
        ),
    },
]

GUIDANCE = """\
- Picolayer's peripheral schema is intentionally minimal — `type:` plus a
  base address (or I2C device address) is all you need for the common case.
- For peripherals not in this list, drop down to the `renode:` escape hatch
  and emit the Renode `.repl` line directly via `platform_repl_inline`.
- Renode's full peripheral library is documented at
  https://renode.readthedocs.io/en/latest/advanced/writing-peripherals.html
- The CPU family determines the UART variant. There is currently no
  per-architecture map for GPIO/SPI/I2C/Timer/ADC — they always use the
  STM32 model. For non-STM32 boards, use `platform_repl_inline` to emit
  the right model.
"""


def peripheral_types_resource() -> str:
    return json.dumps(
        {
            "version": 1,
            "guidance": GUIDANCE.strip(),
            "types": PERIPHERAL_TYPES,
        },
        indent=2,
    )
