"""``picolayer://project-setup`` — the firmware contract and project bootstrap guide.

This is the document an agent should read **first** when a user asks to
start a new embedded project or wire an existing repo into Picolayer. It
establishes the contract — *Picolayer runs a pre-built ELF/BIN in Renode,
it does not compile firmware* — and then lets the agent pick whatever
build toolchain fits the job.
"""

from __future__ import annotations

PROJECT_SETUP_DOC = """\
# Picolayer project setup

Read this first when a user asks you to **start a new firmware project**
or **wire an existing firmware repo into Picolayer**. It is the authoritative
description of the firmware contract and the bootstrap workflow.

---

## The contract (read this carefully)

**Picolayer runs a pre-built firmware binary inside Renode.** It does not
compile firmware. You (the agent) or the user are fully responsible for the
build toolchain — Picolayer only needs the output.

| Picolayer needs | Format |
|---|---|
| Firmware binary | `.elf` (preferred — has symbols + sections) or `.bin` / `.hex` |
| Config | `picolayer.yml` (board or hardware block) |
| Tests | `.robot` files (Robot Framework, Renode's keyword library) |

That's it. Everything else — CMake, west, PlatformIO, ESP-IDF, vendor HAL,
bare-metal Makefile, Rust `cargo-embed`, Zig — is your call. If the user's
existing workflow produces an ELF, point Picolayer at it. If the project
doesn't exist yet, pick the lightest toolchain that gets the user to a
running ELF the fastest, and own that choice.

**You are the build engineer. Picolayer is the virtual target.**

---

## Bootstrapping a new project from scratch

When the user says *"start a new embedded project for board X"*:

1. **Pick a build system.** Default recommendations, pick one:

   | Use case | Pick | Why |
   |---|---|---|
   | Quickest "hello world" on a well-known board | **Zephyr** via `west` | Board support for every catalog entry. `west init` + `west build -b <board> samples/hello_world` → ELF. Zero C to write for the smoke test. |
   | ESP32 family | **ESP-IDF** | First-party, reproducible, `idf.py build` → ELF. |
   | "I want to see the linker + startup myself" | **Bare-metal CMake + arm-none-eabi-gcc** | Minimal, transparent, no framework magic. Good for teaching. |
   | Existing Makefile project | Keep it | Just read where it writes its `.elf`. |
   | Rust | **`probe-rs` + `cargo build --release`** | `target/thumbv7em-none-eabihf/release/<name>` is your ELF. |

   If none of these fit, use what the user already has installed. Ask
   `which west`, `which idf.py`, `which cargo`, `which pio`, etc. before
   assuming.

2. **Scaffold the project.** Write the build files and a minimal `main.c`
   (or equivalent) that does something observable on UART — a print, a
   counter, anything Robot Framework can grep for with `Wait For Line On Uart`.

3. **Build it locally.** Run the toolchain. Capture the full path to the
   produced ELF — you'll need it for `picolayer_submit_job` or
   `picolayer_create_session`.

4. **Generate `picolayer.yml`.** Read `picolayer://board-catalog` to see
   if the target is in the catalog. If yes, `board: <name>`. If no, emit
   a `hardware:` block (see `picolayer://config-schema`).

5. **Generate a `.robot` test.** Read `picolayer://robot-keywords` for
   the keyword reference and `picolayer://examples/stm32-blinky` for a
   complete working example. Assert at minimum one UART line the firmware
   prints at boot.

6. **Validate.** Call `picolayer_validate_config` on the generated YAML
   before submission. Fix any errors it reports.

7. **Run it.** Call `picolayer_submit_job` (fire-and-forget test run) or
   `picolayer_create_session` (persistent interactive device for iterative
   development).

---

## Wiring an existing firmware repo into Picolayer

When the user already has a firmware project:

1. **Find the ELF.** Look for build output in `build/`, `.pio/build/`,
   `zephyr/build/`, `build/zephyr/zephyr.elf`, `target/`, `Debug/`, `out/`,
   etc. If you can't find one, ask the user to run their build and tell
   you the path.

2. **Identify the board.** Read `CMakeLists.txt`, `platformio.ini`,
   `prj.conf`, `west.yml`, `boards.yaml`, `Kconfig`, `Makefile`,
   linker scripts (`*.ld`), or Zephyr `.overlay` files. Common markers:
   - Zephyr: `CONFIG_BOARD="nrf52840dk"`
   - PlatformIO: `board = nucleo_f401re`
   - bare-metal: linker script memory regions, `-mcpu=cortex-m4` flags

3. **Map it to a catalog entry.** Cross-reference against
   `picolayer://board-catalog`. If the exact board is listed, use it. If
   it's a close variant (same MCU, same peripherals you care about), use
   the catalog entry. If neither, emit a `hardware:` block.

4. From here, the flow is the same as steps 4-7 above.

---

## What you should *not* do

- **Do not try to compile firmware on Picolayer infrastructure.** There is
  no `picolayer build` command today. The CLI `picolayer test --remote`
  takes an existing ELF.
- **Do not upload source code as "firmware".** Picolayer will reject
  anything that isn't a recognised binary format.
- **Do not assume the user has your preferred toolchain installed.** Ask
  before running `west init` or `pio run` — both download hundreds of MB
  on first use.
- **Do not couple the build system to Picolayer.** The point of this
  boundary is that the user's existing CI/build should work unchanged, and
  Picolayer only plugs in at the "run the ELF" step.

---

## Recommended demo for "start a new project from scratch"

If the user asks for a showcase: **Zephyr `hello_world` on `nrf52840dk`**
is the least fragile end-to-end demo today. The flow is ~5 shell commands,
the ELF is deterministic, and the UART output is a single line Robot can
assert on:

```bash
west init -m https://github.com/zephyrproject-rtos/zephyr myproject
cd myproject && west update
west build -b nrf52840dk/nrf52840 zephyr/samples/hello_world
# build/zephyr/zephyr.elf is ready
```

`picolayer.yml`:

```yaml
board: nrf52840dk
timeout: 60
```

Robot test (`tests/test_boot.robot`):

```
*** Settings ***
Suite Setup     Setup
Suite Teardown  Teardown
Resource        ${RENODEKEYWORDS}

*** Test Cases ***
Should Print Hello World
    Create Machine
    Start Emulation
    Wait For Line On Uart    Hello World! nrf52840dk    timeout=10
```

Then `picolayer_submit_job`, poll `picolayer_get_job`, done.

---

## Cross-references

- `picolayer://board-catalog` — every board Picolayer knows out of the box
- `picolayer://config-schema` — full `picolayer.yml` field reference
- `picolayer://robot-keywords` — Robot Framework keywords for Renode tests
- `picolayer://examples` — working end-to-end reference configurations
- `picolayer://cpu-types` and `picolayer://peripheral-types` — for custom
  `hardware:` blocks
"""


def project_setup_resource() -> str:
    return PROJECT_SETUP_DOC
