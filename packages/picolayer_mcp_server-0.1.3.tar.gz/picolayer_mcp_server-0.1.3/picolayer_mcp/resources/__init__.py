"""MCP resource providers — exposed as ``picolayer://...`` URIs.

Resources are *context*: read-only documents an agent loads to understand
how to drive Picolayer (board catalog, config schema, examples, peripheral
types, CPU types, Robot keyword reference). Tools are *actions*: things the
agent calls to do work.
"""

from __future__ import annotations

from picolayer_mcp.resources.board_catalog import board_catalog_resource
from picolayer_mcp.resources.config_schema import config_schema_resource
from picolayer_mcp.resources.cpu_types import cpu_types_resource
from picolayer_mcp.resources.examples import (
    example_resource,
    examples_index_resource,
    list_example_ids,
)
from picolayer_mcp.resources.peripheral_types import peripheral_types_resource
from picolayer_mcp.resources.project_setup import project_setup_resource
from picolayer_mcp.resources.robot_keywords import robot_keywords_resource

__all__ = [
    "board_catalog_resource",
    "config_schema_resource",
    "cpu_types_resource",
    "example_resource",
    "examples_index_resource",
    "list_example_ids",
    "peripheral_types_resource",
    "project_setup_resource",
    "robot_keywords_resource",
]
