"""``picolayer://examples/{id}`` — example projects shipped with Picolayer.

Each example is a working ``picolayer.yml`` plus its Robot test files. The
agent uses these as few-shot prompts when generating new configs and tests.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

EXAMPLES_DIRNAME = "examples"


def _examples_root() -> Path:
    """Locate the repo's ``examples/`` directory.

    Resolution order matches the board catalog loader: env override, then
    walking up from this module looking for an ``examples/`` sibling.
    """
    env_override = os.environ.get("PICOLAYER_EXAMPLES_DIR")
    if env_override:
        return Path(env_override)
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / EXAMPLES_DIRNAME
        if candidate.is_dir():
            return candidate
    # Fall back to a non-existent path so callers can handle the absence
    # explicitly via list_example_ids() returning [].
    return here.parent / EXAMPLES_DIRNAME


def list_example_ids() -> list[str]:
    """Return the IDs of every example project (directory name)."""
    root = _examples_root()
    if not root.is_dir():
        return []
    return sorted(
        p.name
        for p in root.iterdir()
        if p.is_dir() and not p.name.startswith(".") and (p / "picolayer.yml").is_file()
    )


def _read_text(path: Path, max_bytes: int = 64 * 1024) -> str:
    try:
        data = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    if len(data) > max_bytes:
        return data[:max_bytes] + f"\n... [truncated, {len(data)} bytes total]\n"
    return data


def example_resource(example_id: str) -> str:
    """Return JSON describing one example: picolayer.yml + every test file."""
    root = _examples_root()
    example_dir = root / example_id
    if not example_dir.is_dir():
        raise FileNotFoundError(f"Unknown example: {example_id}")
    payload: dict[str, object] = {
        "id": example_id,
        "path": str(example_dir.relative_to(root.parent)),
        "files": {},
    }
    files: dict[str, str] = {}
    config_path = example_dir / "picolayer.yml"
    if config_path.is_file():
        files["picolayer.yml"] = _read_text(config_path)
    readme_path = example_dir / "README.md"
    if readme_path.is_file():
        files["README.md"] = _read_text(readme_path)
    tests_dir = example_dir / "tests"
    if tests_dir.is_dir():
        for test_file in sorted(tests_dir.iterdir()):
            if test_file.is_file() and test_file.suffix in {".robot", ".resc"}:
                files[f"tests/{test_file.name}"] = _read_text(test_file)
    payload["files"] = files
    return json.dumps(payload, indent=2)


def examples_index_resource() -> str:
    """Return a JSON index of all examples (used by ``picolayer://examples``)."""
    ids = list_example_ids()
    return json.dumps(
        {
            "version": 1,
            "examples": [{"id": eid, "uri": f"picolayer://examples/{eid}"} for eid in ids],
            "guidance": (
                "Read picolayer://examples/{id} for one specific example. "
                "Each entry contains picolayer.yml plus every .robot/.resc file "
                "in tests/. Use these as few-shot prompts when generating new "
                "configs and test suites."
            ),
        },
        indent=2,
    )
