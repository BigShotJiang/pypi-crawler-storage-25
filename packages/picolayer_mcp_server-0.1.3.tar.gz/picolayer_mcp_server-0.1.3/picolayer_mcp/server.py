"""FastMCP server entry point.

Run with ``uvx picolayer-mcp-server`` (or ``picolayer-mcp-server`` after a
local install). Reads ``PICOLAYER_API_KEY`` from the environment, falling
back to ``~/.picolayer/config.toml``.

The MCP SDK is an optional import: the server is structured so that the
business logic (tools, resources, validation) can be tested without the
``mcp`` package installed.
"""

from __future__ import annotations

from picolayer_mcp.resources import (
    board_catalog_resource,
    config_schema_resource,
    cpu_types_resource,
    example_resource,
    examples_index_resource,
    peripheral_types_resource,
    project_setup_resource,
    robot_keywords_resource,
)
from picolayer_mcp.tools import boards as boards_tools
from picolayer_mcp.tools import jobs as jobs_tools
from picolayer_mcp.tools import sessions as sessions_tools
from picolayer_mcp.tools import validation as validation_tools


def build_mcp() -> object:
    """Construct a FastMCP instance with all Picolayer tools and resources.

    Imports the ``mcp`` package lazily so unit tests for tools/resources/
    validation can run without installing the SDK.
    """
    from mcp.server.fastmcp import FastMCP  # type: ignore[import-not-found]

    mcp = FastMCP(name="picolayer")

    # ── Tools — Boards ────────────────────────────────────────────────
    mcp.tool(name="picolayer_list_boards")(boards_tools.list_boards)
    mcp.tool(name="picolayer_get_board")(boards_tools.get_board_info)

    # ── Tools — Validation ────────────────────────────────────────────
    mcp.tool(name="picolayer_validate_config")(validation_tools.validate_config)

    # ── Tools — Jobs (Use Case A) ─────────────────────────────────────
    mcp.tool(name="picolayer_submit_job")(jobs_tools.submit_job)
    mcp.tool(name="picolayer_get_job")(jobs_tools.get_job)
    mcp.tool(name="picolayer_list_jobs")(jobs_tools.list_jobs)
    mcp.tool(name="picolayer_get_artifacts")(jobs_tools.get_artifacts)

    # ── Tools — Sessions (Use Case B) ─────────────────────────────────
    mcp.tool(name="picolayer_create_session")(sessions_tools.create_session)
    mcp.tool(name="picolayer_destroy_session")(sessions_tools.destroy_session)
    mcp.tool(name="picolayer_list_sessions")(sessions_tools.list_sessions)
    mcp.tool(name="picolayer_session_status")(sessions_tools.session_status)
    mcp.tool(name="picolayer_load_firmware")(sessions_tools.load_firmware)
    mcp.tool(name="picolayer_execute_monitor")(sessions_tools.execute_monitor)
    mcp.tool(name="picolayer_start_emulation")(sessions_tools.start_emulation)
    mcp.tool(name="picolayer_pause_emulation")(sessions_tools.pause_emulation)
    mcp.tool(name="picolayer_step_emulation")(sessions_tools.step_emulation)
    mcp.tool(name="picolayer_read_registers")(sessions_tools.read_registers)
    mcp.tool(name="picolayer_read_memory")(sessions_tools.read_memory)
    mcp.tool(name="picolayer_get_uart_output")(sessions_tools.get_uart_output)
    mcp.tool(name="picolayer_run_session_test")(sessions_tools.run_session_test)
    mcp.tool(name="picolayer_hot_reload_firmware")(sessions_tools.hot_reload_firmware)
    mcp.tool(name="picolayer_read_register_by_name")(sessions_tools.read_register_by_name)
    mcp.tool(name="picolayer_list_peripherals")(sessions_tools.list_peripherals)
    mcp.tool(name="picolayer_read_peripheral")(sessions_tools.read_peripheral)
    mcp.tool(name="picolayer_create_snapshot")(sessions_tools.create_snapshot)
    mcp.tool(name="picolayer_restore_snapshot")(sessions_tools.restore_snapshot)
    mcp.tool(name="picolayer_start_tracing")(sessions_tools.start_tracing)
    mcp.tool(name="picolayer_stop_tracing")(sessions_tools.stop_tracing)
    mcp.tool(name="picolayer_get_gdb_info")(sessions_tools.get_gdb_info)

    # ── Resources ─────────────────────────────────────────────────────
    @mcp.resource("picolayer://project-setup")
    def _project_setup() -> str:
        return project_setup_resource()

    @mcp.resource("picolayer://board-catalog")
    def _board_catalog() -> str:
        return board_catalog_resource()

    @mcp.resource("picolayer://config-schema")
    def _config_schema() -> str:
        return config_schema_resource()

    @mcp.resource("picolayer://peripheral-types")
    def _peripheral_types() -> str:
        return peripheral_types_resource()

    @mcp.resource("picolayer://cpu-types")
    def _cpu_types() -> str:
        return cpu_types_resource()

    @mcp.resource("picolayer://robot-keywords")
    def _robot_keywords() -> str:
        return robot_keywords_resource()

    @mcp.resource("picolayer://examples")
    def _examples_index() -> str:
        return examples_index_resource()

    @mcp.resource("picolayer://examples/{example_id}")
    def _example(example_id: str) -> str:
        return example_resource(example_id)

    return mcp


def main() -> None:
    """Console-script entry point: run the FastMCP server over stdio."""
    mcp = build_mcp()
    mcp.run()  # type: ignore[attr-defined]


if __name__ == "__main__":
    main()
