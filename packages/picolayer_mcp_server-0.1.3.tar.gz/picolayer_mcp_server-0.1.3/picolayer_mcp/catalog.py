"""Shared loader for ``platforms/board_catalog.json``.

The MCP server bundles the canonical JSON via ``[tool.hatch.build.force-include]``
into ``picolayer_mcp/data/board_catalog.json`` so that ``uvx picolayer-mcp-server``
ships with everything it needs to answer ``picolayer://board-catalog`` without
hitting the network.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from importlib import resources
from pathlib import Path


@dataclass(frozen=True)
class Peripheral:
    name: str
    type: str
    base_address: int | None


@dataclass(frozen=True)
class Board:
    name: str
    display_name: str
    mcu: str
    architecture: str
    renode_platform: str
    description: str
    flash_size: str
    sram_size: str
    peripherals: tuple[Peripheral, ...]
    alias_of: str | None


def _candidate_paths(here: Path | None = None) -> list[Path]:
    """Search paths for ``board_catalog.json``, in priority order.

    ``here`` is exposed for unit tests so they can simulate alternate
    layouts (e.g. shallow paths that would have made ``parents[N]``
    overflow before this loader walked the ancestor chain instead).
    """
    candidates: list[Path] = []
    env_override = os.environ.get("PICOLAYER_BOARD_CATALOG")
    if env_override:
        candidates.append(Path(env_override))
    if here is None:
        here = Path(__file__).resolve()
    for parent in here.parents:
        candidates.append(parent / "platforms" / "board_catalog.json")
    return candidates


def _read_catalog_text() -> str:
    for candidate in _candidate_paths():
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8")
    try:
        return (
            resources.files("picolayer_mcp.data")
            .joinpath("board_catalog.json")
            .read_text(encoding="utf-8")
        )
    except (FileNotFoundError, ModuleNotFoundError) as exc:
        raise FileNotFoundError(
            "Could not locate platforms/board_catalog.json. Set "
            "PICOLAYER_BOARD_CATALOG to override the search path."
        ) from exc


def _parse_int(value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        return int(value, 0)
    return None


def _parse_board(raw: dict[str, object]) -> Board:
    peripherals_raw = raw.get("peripherals", []) or []
    peripherals: list[Peripheral] = []
    if isinstance(peripherals_raw, list):
        for entry in peripherals_raw:
            if not isinstance(entry, dict):
                continue
            peripherals.append(
                Peripheral(
                    name=str(entry["name"]),
                    type=str(entry["type"]),
                    base_address=_parse_int(entry.get("base_address")),
                )
            )
    alias_of = raw.get("alias_of")
    return Board(
        name=str(raw["name"]),
        display_name=str(raw["display_name"]),
        mcu=str(raw["mcu"]),
        architecture=str(raw["architecture"]),
        renode_platform=str(raw["renode_platform"]),
        description=str(raw["description"]),
        flash_size=str(raw.get("flash_size", "")),
        sram_size=str(raw.get("sram_size", "")),
        peripherals=tuple(peripherals),
        alias_of=str(alias_of) if isinstance(alias_of, str) else None,
    )


def load_catalog() -> list[Board]:
    """Return all boards in the catalog (including aliases)."""
    raw = json.loads(_read_catalog_text())
    boards_raw = raw.get("boards", [])
    if not isinstance(boards_raw, list):
        return []
    return [_parse_board(b) for b in boards_raw if isinstance(b, dict)]


def load_unique_boards() -> list[Board]:
    """Return one entry per ``renode_platform`` (aliases collapsed)."""
    seen: set[str] = set()
    out: list[Board] = []
    for board in load_catalog():
        if board.renode_platform in seen:
            continue
        seen.add(board.renode_platform)
        out.append(board)
    return out


def get_board(name: str) -> Board | None:
    if not name:
        return None
    normalized = name.lower().replace("-", "_")
    for board in load_catalog():
        if board.name == normalized:
            return board
    return None


def board_to_dict(board: Board) -> dict[str, object]:
    return {
        "name": board.name,
        "display_name": board.display_name,
        "mcu": board.mcu,
        "architecture": board.architecture,
        "renode_platform": board.renode_platform,
        "description": board.description,
        "flash_size": board.flash_size,
        "sram_size": board.sram_size,
        "alias_of": board.alias_of,
        "peripherals": [
            {
                "name": p.name,
                "type": p.type,
                "base_address": (f"0x{p.base_address:08x}" if p.base_address is not None else None),
            }
            for p in board.peripherals
        ],
    }
