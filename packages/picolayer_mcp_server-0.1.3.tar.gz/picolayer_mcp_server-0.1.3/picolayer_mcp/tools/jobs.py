"""MCP tools for the existing job (Use Case A) flow."""

from __future__ import annotations

import base64
from typing import Any

from picolayer_mcp.api_client import ApiError, PicolayerApiClient
from picolayer_mcp.auth import AuthError, resolve_auth


def _client() -> PicolayerApiClient:
    auth = resolve_auth()
    return PicolayerApiClient(api_key=auth.api_key, base_url=auth.api_endpoint)


def submit_job(
    firmware_b64: str,
    firmware_name: str,
    test_script_b64: str,
    test_script_name: str,
    *,
    test_type: str = "auto",
    timeout_seconds: int | None = None,
    picolayer_config: str | None = None,
) -> dict[str, Any]:
    """Submit a fire-and-forget test job (Use Case A — CI/CD flow).

    Firmware and test script are passed as base64-encoded blobs so an agent
    can submit a job without needing filesystem access on the host.
    """
    try:
        firmware_bytes = base64.b64decode(firmware_b64, validate=True)
        test_script_bytes = base64.b64decode(test_script_b64, validate=True)
    except (ValueError, TypeError) as exc:
        return {"ok": False, "error": f"base64 decode failed: {exc}"}

    try:
        with _client() as client:
            firmware_url = client.upload_file_bytes(firmware_name, firmware_bytes)
            test_script_url = client.upload_file_bytes(test_script_name, test_script_bytes)
            job = client.submit_job(
                firmware_url=firmware_url,
                test_script=test_script_name,
                test_script_url=test_script_url,
                test_type=test_type,
                timeout_seconds=timeout_seconds,
                picolayer_config=picolayer_config,
            )
            return {
                "ok": True,
                "job_id": job.job_id,
                "status": job.status,
            }
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}


def get_job(job_id: str) -> dict[str, Any]:
    """Fetch the current status, result, and output of a job."""
    try:
        with _client() as client:
            job = client.get_job(job_id)
            return {
                "ok": True,
                "job_id": job.job_id,
                "status": job.status,
                "result": job.result,
                "output": job.output,
                "error_message": job.error_message,
                "test_type": job.test_type,
            }
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}


def list_jobs(status: str | None = None, limit: int = 25) -> dict[str, Any]:
    """List the current tenant's recent jobs, optionally filtered by status."""
    try:
        with _client() as client:
            jobs = client.list_jobs(status=status, limit=limit)
            return {
                "ok": True,
                "jobs": [
                    {
                        "job_id": j.job_id,
                        "status": j.status,
                        "result": j.result,
                    }
                    for j in jobs
                ],
            }
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}


def get_artifacts(job_id: str) -> dict[str, Any]:
    """List a job's artifacts with presigned download URLs."""
    try:
        with _client() as client:
            artifacts = client.get_artifacts(job_id)
            return {
                "ok": True,
                "job_id": artifacts.job_id,
                "is_streaming": artifacts.is_streaming,
                "artifacts": [
                    {
                        "name": a.name,
                        "size_bytes": a.size_bytes,
                        "content_type": a.content_type,
                        "download_url": a.download_url,
                    }
                    for a in artifacts.artifacts
                ],
            }
    except (AuthError, ApiError) as exc:
        return {"ok": False, "error": str(exc)}
