"""MCP tools for the session (Use Case B — interactive dev) flow.

These call the new Picolayer session API endpoints (P1.3). They are stub-safe:
if the API returns 404, the tool returns ``{ok: False, error: ...}`` with a
helpful message about session support not being deployed.
"""

from __future__ import annotations

import base64
import functools
from collections.abc import Callable
from typing import Any

from picolayer_mcp.api_client import ApiError, PicolayerApiClient
from picolayer_mcp.auth import AuthError, resolve_auth

ToolFn = Callable[..., dict[str, Any]]


def _client() -> PicolayerApiClient:
    auth = resolve_auth()
    return PicolayerApiClient(api_key=auth.api_key, base_url=auth.api_endpoint)


def _wrap(fn: ToolFn) -> ToolFn:
    """Catch AuthError + ApiError and return a uniform error shape."""

    @functools.wraps(fn)
    def inner(*args: Any, **kwargs: Any) -> dict[str, Any]:
        try:
            result: dict[str, Any] = fn(*args, **kwargs)
            return result
        except (AuthError, ApiError) as exc:
            return {"ok": False, "error": str(exc)}

    return inner


@_wrap
def create_session(
    picolayer_config: str,
    *,
    firmware_b64: str | None = None,
    firmware_name: str | None = None,
    label: str | None = None,
) -> dict[str, Any]:
    """Create a persistent Renode session for interactive use.

    The session stays up until idle timeout, max lifetime, or explicit destroy.
    Pass ``firmware_b64`` to load firmware as part of creation, or load it
    later with ``picolayer_load_firmware``.
    """
    body: dict[str, Any] = {"picolayer_config": picolayer_config}
    if label:
        body["label"] = label
    if firmware_b64 and firmware_name:
        try:
            firmware_bytes = base64.b64decode(firmware_b64, validate=True)
        except (ValueError, TypeError) as exc:
            return {"ok": False, "error": f"base64 decode failed: {exc}"}
        with _client() as client:
            firmware_url = client.upload_file_bytes(firmware_name, firmware_bytes)
            body["firmware_url"] = firmware_url
            body["firmware_name"] = firmware_name
            session = client.create_session(body)
            return {"ok": True, "session": session}
    with _client() as client:
        session = client.create_session(body)
        return {"ok": True, "session": session}


@_wrap
def destroy_session(session_id: str) -> dict[str, Any]:
    """Tear down a session and stop its ECS task."""
    with _client() as client:
        return {"ok": True, "result": client.destroy_session(session_id)}


@_wrap
def list_sessions(
    status: str | None = None,
    created_by: str | None = None,
    limit: int = 25,
) -> dict[str, Any]:
    """List the current tenant's sessions, optionally filtered."""
    params: dict[str, Any] = {"limit": limit}
    if status:
        params["status"] = status
    if created_by:
        params["created_by"] = created_by
    with _client() as client:
        return {"ok": True, "sessions": client.list_sessions(**params)}


@_wrap
def session_status(session_id: str) -> dict[str, Any]:
    """Get the current state of a session (status, board, uptime, idle, etc.)."""
    with _client() as client:
        return {"ok": True, "session": client.get_session(session_id)}


@_wrap
def load_firmware(session_id: str, firmware_b64: str, firmware_name: str) -> dict[str, Any]:
    """Upload and load firmware into an existing session."""
    try:
        firmware_bytes = base64.b64decode(firmware_b64, validate=True)
    except (ValueError, TypeError) as exc:
        return {"ok": False, "error": f"base64 decode failed: {exc}"}
    with _client() as client:
        firmware_url = client.upload_file_bytes(firmware_name, firmware_bytes)
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                "/firmware",
                method="POST",
                json={"firmware_url": firmware_url, "firmware_name": firmware_name},
            ),
        }


@_wrap
def execute_monitor(session_id: str, command: str) -> dict[str, Any]:
    """Execute an arbitrary Renode Monitor command in a session."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id, "/monitor", method="POST", json={"command": command}
            ),
        }


@_wrap
def start_emulation(session_id: str, duration_seconds: float | None = None) -> dict[str, Any]:
    body: dict[str, Any] = {}
    if duration_seconds is not None:
        body["duration_seconds"] = duration_seconds
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id, "/emulation/start", method="POST", json=body
            ),
        }


@_wrap
def pause_emulation(session_id: str) -> dict[str, Any]:
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(session_id, "/emulation/pause", method="POST"),
        }


@_wrap
def step_emulation(session_id: str, count: int = 1) -> dict[str, Any]:
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id, "/emulation/step", method="POST", json={"count": count}
            ),
        }


@_wrap
def read_registers(session_id: str) -> dict[str, Any]:
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(session_id, "/registers", method="GET"),
        }


@_wrap
def read_memory(session_id: str, address: int, length: int) -> dict[str, Any]:
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                "/memory",
                method="POST",
                json={"address": address, "length": length},
            ),
        }


@_wrap
def get_uart_output(session_id: str, name: str = "uart0") -> dict[str, Any]:
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(session_id, f"/uart/{name}", method="GET"),
        }


@_wrap
def hot_reload_firmware(session_id: str, firmware_b64: str, firmware_name: str) -> dict[str, Any]:
    """P2.1 — pause, reset, and load new firmware into an existing session."""
    try:
        firmware_bytes = base64.b64decode(firmware_b64, validate=True)
    except (ValueError, TypeError) as exc:
        return {"ok": False, "error": f"base64 decode failed: {exc}"}
    with _client() as client:
        firmware_url = client.upload_file_bytes(firmware_name, firmware_bytes)
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                "/hot-reload",
                method="POST",
                json={"firmware_url": firmware_url, "firmware_name": firmware_name},
            ),
        }


@_wrap
def read_register_by_name(session_id: str, name: str) -> dict[str, Any]:
    """P2.2 — read a single CPU register by name."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(session_id, f"/registers/{name}", method="GET"),
        }


@_wrap
def list_peripherals(session_id: str) -> dict[str, Any]:
    """P2.2 — list all sysbus peripherals."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(session_id, "/peripherals", method="GET"),
        }


@_wrap
def read_peripheral(session_id: str, name: str) -> dict[str, Any]:
    """P2.2 — read a single peripheral's register state."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(session_id, f"/peripherals/{name}", method="GET"),
        }


@_wrap
def create_snapshot(session_id: str, snapshot_id: str) -> dict[str, Any]:
    """P3.1 — save the session's machine state."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                "/snapshots",
                method="POST",
                json={"snapshot_id": snapshot_id, "name": snapshot_id},
            ),
        }


@_wrap
def restore_snapshot(session_id: str, snapshot_id: str) -> dict[str, Any]:
    """P3.1 — restore a previously saved snapshot."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                f"/snapshots/{snapshot_id}/restore",
                method="POST",
            ),
        }


@_wrap
def start_tracing(session_id: str, trace_id: str = "trace1") -> dict[str, Any]:
    """P3.2 — begin instruction-level execution tracing."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                "/tracing/start",
                method="POST",
                json={"trace_id": trace_id},
            ),
        }


@_wrap
def stop_tracing(session_id: str, trace_id: str = "trace1") -> dict[str, Any]:
    """P3.2 — stop tracing."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                "/tracing/stop",
                method="POST",
                json={"trace_id": trace_id},
            ),
        }


@_wrap
def get_gdb_info(session_id: str, port: int = 3333) -> dict[str, Any]:
    """P3.3 — start the GDB server and return connection info."""
    with _client() as client:
        return {
            "ok": True,
            "result": client.session_proxy(session_id, f"/gdb-info?port={port}", method="GET"),
        }


@_wrap
def run_session_test(
    session_id: str,
    test_script_b64: str,
    test_script_name: str = "test.robot",
) -> dict[str, Any]:
    """Run a Robot Framework test against a live session and return per-test results."""
    try:
        test_script_bytes = base64.b64decode(test_script_b64, validate=True)
    except (ValueError, TypeError) as exc:
        return {"ok": False, "error": f"base64 decode failed: {exc}"}
    with _client() as client:
        test_script_url = client.upload_file_bytes(test_script_name, test_script_bytes)
        return {
            "ok": True,
            "result": client.session_proxy(
                session_id,
                "/test",
                method="POST",
                json={
                    "test_script_url": test_script_url,
                    "test_script_name": test_script_name,
                },
            ),
        }
