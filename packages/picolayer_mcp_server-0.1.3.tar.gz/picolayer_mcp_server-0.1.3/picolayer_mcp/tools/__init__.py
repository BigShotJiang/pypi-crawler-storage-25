"""MCP tool registrations.

Tools are *actions* an agent can call. Resources (under
``picolayer_mcp.resources``) are *context* it reads to understand how to
shape its inputs.

The tool modules export ``register(mcp)`` functions that the server's
``server.py`` calls during startup. Each tool is a thin wrapper that
delegates to ``PicolayerApiClient``.
"""

from __future__ import annotations

from picolayer_mcp.tools import boards, jobs, sessions, validation

__all__ = ["boards", "jobs", "sessions", "validation"]
