"""MCP tools for board catalog enumeration and lookup.

These work entirely from the bundled ``platforms/board_catalog.json`` —
no network access, no API key required. They are the cheapest tools the
agent can call when it needs to pick a target.
"""

from __future__ import annotations

from typing import Any

from picolayer_mcp.catalog import board_to_dict, get_board, load_unique_boards


def list_boards() -> dict[str, Any]:
    """Return all supported boards (deduplicated by Renode platform).

    The agent should prefer this over reading ``picolayer://board-catalog``
    when it just needs the names; the resource version is for full context.
    """
    boards = load_unique_boards()
    return {
        "ok": True,
        "count": len(boards),
        "boards": [
            {
                "name": b.name,
                "display_name": b.display_name,
                "mcu": b.mcu,
                "architecture": b.architecture,
                "description": b.description,
            }
            for b in boards
        ],
    }


def get_board_info(name: str) -> dict[str, Any]:
    """Return full metadata for a single board."""
    board = get_board(name)
    if board is None:
        return {
            "ok": False,
            "error": f"Unknown board: {name!r}. Use picolayer_list_boards to enumerate.",
        }
    return {"ok": True, "board": board_to_dict(board)}
