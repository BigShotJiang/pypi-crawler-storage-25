"""``picolayer_validate_config`` MCP tool.

Wraps ``picolayer_mcp.validation.validate_config_string`` and returns a JSON
shape suitable for an agent to consume.
"""

from __future__ import annotations

from typing import Any

from picolayer_mcp.validation import validate_config_string


def validate_config(config_text: str) -> dict[str, Any]:
    """Validate a ``picolayer.yml`` source string.

    Returns ``{ok, errors, warnings, escape_hatch_unverified}``. Use this
    before ``picolayer_submit_job`` or ``picolayer_create_session`` to catch
    obvious mistakes upfront.
    """
    result = validate_config_string(config_text)
    return result.to_dict()
