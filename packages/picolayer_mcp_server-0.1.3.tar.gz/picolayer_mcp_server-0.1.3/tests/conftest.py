"""Shared fixtures for the MCP server tests."""

from __future__ import annotations

import json
import sys
from collections.abc import Iterator
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest


@pytest.fixture(autouse=True)
def _isolated_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """Wipe Picolayer-related env vars and isolate the config file so tests
    are reproducible regardless of what credentials the developer has stored
    in ``~/.picolayer/config.toml``."""
    for var in ("PICOLAYER_API_KEY", "PICOLAYER_API_ENDPOINT", "PICOLAYER_BOARD_CATALOG"):
        monkeypatch.delenv(var, raising=False)
    # Redirect the auth module's CONFIG_PATH to a temp file that does not
    # exist, so that a real developer config never leaks into tests.
    monkeypatch.setattr("picolayer_mcp.auth.CONFIG_PATH", tmp_path / "config.toml")
    yield


@pytest.fixture
def fake_config_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point ``picolayer_mcp.auth.CONFIG_PATH`` at a temp file."""
    fake_path = tmp_path / "config.toml"
    monkeypatch.setattr("picolayer_mcp.auth.CONFIG_PATH", fake_path)
    return fake_path


@pytest.fixture
def mock_httpx_client() -> Iterator[dict[str, Any]]:  # noqa: C901  (fake HTTP client class)
    """Patch ``httpx.Client`` so the api_client never hits the network.

    Returns a dict that captures requests and lets each test set responses.
    """
    state: dict[str, Any] = {"requests": [], "responses": {}}

    class _FakeResponse:
        def __init__(self, status_code: int, body: dict[str, Any] | list[Any] | str | None) -> None:
            self.status_code = status_code
            self._body = body
            self.text = (
                body if isinstance(body, str) else json.dumps(body) if body is not None else ""
            )

        def json(self) -> Any:
            return self._body

    class _FakeClient:
        def __init__(self, *_args: Any, **kwargs: Any) -> None:
            self._headers = kwargs.get("headers", {})

        def close(self) -> None:
            return None

        def _record(self, method: str, url: str, **kwargs: Any) -> _FakeResponse:
            state["requests"].append({"method": method, "url": url, "kwargs": kwargs})
            key = (method.upper(), url)
            spec = state["responses"].get(key)
            if spec is None:
                return _FakeResponse(200, {})
            return _FakeResponse(spec.get("status", 200), spec.get("body"))

        def get(self, url: str, **kwargs: Any) -> _FakeResponse:
            return self._record("GET", url, **kwargs)

        def post(self, url: str, **kwargs: Any) -> _FakeResponse:
            return self._record("POST", url, **kwargs)

        def delete(self, url: str, **kwargs: Any) -> _FakeResponse:
            return self._record("DELETE", url, **kwargs)

        def request(self, method: str, url: str, **kwargs: Any) -> _FakeResponse:
            return self._record(method, url, **kwargs)

    with patch("picolayer_mcp.api_client.httpx.Client", _FakeClient):
        yield state


@pytest.fixture(autouse=True)
def _ensure_imports() -> None:
    """Make sure ``picolayer_mcp`` is importable from the source tree."""
    here = Path(__file__).resolve().parent
    src = here.parent
    if str(src) not in sys.path:
        sys.path.insert(0, str(src))
