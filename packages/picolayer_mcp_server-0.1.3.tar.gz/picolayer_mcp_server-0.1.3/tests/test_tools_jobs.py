"""Tests for picolayer_mcp.tools.jobs — fire-and-forget job tools."""

from __future__ import annotations

import base64

import pytest

from picolayer_mcp.tools import jobs as jobs_tools


class TestSubmitJob:
    def test_no_api_key_returns_error(self, mock_httpx_client) -> None:  # type: ignore[no-untyped-def]
        result = jobs_tools.submit_job(
            firmware_b64=base64.b64encode(b"\x7fELF").decode(),
            firmware_name="firmware.elf",
            test_script_b64=base64.b64encode(b"*** Test Cases ***").decode(),
            test_script_name="test.robot",
        )
        assert result["ok"] is False
        assert "API key" in result["error"] or "PICOLAYER_API_KEY" in result["error"]

    def test_invalid_base64_returns_error(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        result = jobs_tools.submit_job(
            firmware_b64="!!!not-base64!!!",
            firmware_name="firmware.elf",
            test_script_b64="!!!nope!!!",
            test_script_name="test.robot",
        )
        assert result["ok"] is False
        assert "base64" in result["error"]

    def test_submit_happy_path(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("POST", "/api/v1/upload")] = {
            "status": 200,
            "body": {"url": "https://presigned/firmware"},
        }
        mock_httpx_client["responses"][("POST", "/api/v1/jobs")] = {
            "status": 200,
            "body": {"job_id": "abc123", "status": "pending"},
        }

        result = jobs_tools.submit_job(
            firmware_b64=base64.b64encode(b"\x7fELF").decode(),
            firmware_name="firmware.elf",
            test_script_b64=base64.b64encode(b"*** Test Cases ***").decode(),
            test_script_name="test.robot",
        )
        assert result["ok"] is True
        assert result["job_id"] == "abc123"
        # 2 uploads + 1 submit
        assert len(mock_httpx_client["requests"]) == 3


class TestGetJob:
    def test_get_job_happy_path(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("GET", "/api/v1/jobs/abc123")] = {
            "status": 200,
            "body": {
                "job_id": "abc123",
                "status": "completed",
                "result": "passed",
                "output": "PASS",
            },
        }
        result = jobs_tools.get_job("abc123")
        assert result["ok"] is True
        assert result["status"] == "completed"
        assert result["result"] == "passed"

    def test_get_job_404(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("GET", "/api/v1/jobs/nope")] = {
            "status": 404,
            "body": {"detail": "not found"},
        }
        result = jobs_tools.get_job("nope")
        assert result["ok"] is False
        assert "404" in result["error"]


class TestListJobs:
    def test_list_jobs_returns_list(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("GET", "/api/v1/jobs")] = {
            "status": 200,
            "body": {
                "jobs": [
                    {"job_id": "1", "status": "completed", "result": "passed"},
                    {"job_id": "2", "status": "running"},
                ]
            },
        }
        result = jobs_tools.list_jobs()
        assert result["ok"] is True
        assert len(result["jobs"]) == 2

    def test_list_jobs_handles_bare_list(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("GET", "/api/v1/jobs")] = {
            "status": 200,
            "body": [{"job_id": "1", "status": "completed"}],
        }
        result = jobs_tools.list_jobs()
        assert result["ok"] is True
        assert len(result["jobs"]) == 1


class TestArtifacts:
    def test_get_artifacts(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("GET", "/api/v1/jobs/abc/artifacts")] = {
            "status": 200,
            "body": {
                "job_id": "abc",
                "is_streaming": False,
                "artifacts": [
                    {
                        "name": "uart0_transcript.txt",
                        "size_bytes": 1234,
                        "content_type": "text/plain",
                        "download_url": "https://presigned/uart0",
                    }
                ],
            },
        }
        result = jobs_tools.get_artifacts("abc")
        assert result["ok"] is True
        assert len(result["artifacts"]) == 1
        assert result["artifacts"][0]["name"] == "uart0_transcript.txt"
