"""Tests for picolayer_mcp.tools.sessions — session lifecycle tools."""

from __future__ import annotations

import base64

import pytest

from picolayer_mcp.tools import sessions as sessions_tools


class TestCreateSession:
    def test_no_auth_returns_error(self, mock_httpx_client) -> None:  # type: ignore[no-untyped-def]
        result = sessions_tools.create_session(picolayer_config="board: nrf52840dk\n")
        assert result["ok"] is False

    def test_create_without_firmware(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("POST", "/api/v1/sessions")] = {
            "status": 200,
            "body": {"session_id": "s-1", "status": "creating"},
        }
        result = sessions_tools.create_session(picolayer_config="board: nrf52840dk\n")
        assert result["ok"] is True
        assert result["session"]["session_id"] == "s-1"

    def test_create_with_firmware_uploads_first(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("POST", "/api/v1/upload")] = {
            "status": 200,
            "body": {"url": "https://presigned/firmware"},
        }
        mock_httpx_client["responses"][("POST", "/api/v1/sessions")] = {
            "status": 200,
            "body": {"session_id": "s-2", "status": "creating"},
        }
        result = sessions_tools.create_session(
            picolayer_config="board: nrf52840dk\n",
            firmware_b64=base64.b64encode(b"\x7fELF").decode(),
            firmware_name="firmware.elf",
        )
        assert result["ok"] is True
        # Upload then create
        assert mock_httpx_client["requests"][0]["url"] == "/api/v1/upload"
        assert mock_httpx_client["requests"][1]["url"] == "/api/v1/sessions"

    def test_invalid_firmware_b64(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        result = sessions_tools.create_session(
            picolayer_config="board: nrf52840dk\n",
            firmware_b64="!!!nope!!!",
            firmware_name="firmware.elf",
        )
        assert result["ok"] is False
        assert "base64" in result["error"]


class TestSessionLifecycle:
    def test_status(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("GET", "/api/v1/sessions/s-1")] = {
            "status": 200,
            "body": {"session_id": "s-1", "status": "ready"},
        }
        result = sessions_tools.session_status("s-1")
        assert result["ok"] is True
        assert result["session"]["status"] == "ready"

    def test_destroy(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("DELETE", "/api/v1/sessions/s-1")] = {
            "status": 200,
            "body": {"session_id": "s-1", "status": "ended"},
        }
        result = sessions_tools.destroy_session("s-1")
        assert result["ok"] is True

    def test_list(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("GET", "/api/v1/sessions")] = {
            "status": 200,
            "body": {"sessions": [{"session_id": "s-1", "status": "running"}]},
        }
        result = sessions_tools.list_sessions()
        assert result["ok"] is True
        assert len(result["sessions"]) == 1


class TestSessionInteraction:
    def test_execute_monitor(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("POST", "/api/v1/sessions/s-1/monitor")] = {
            "status": 200,
            "body": {"stdout": "OK", "exit_code": 0},
        }
        result = sessions_tools.execute_monitor("s-1", "sysbus ReadByte 0x20000000")
        assert result["ok"] is True

    def test_start_emulation(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("POST", "/api/v1/sessions/s-1/emulation/start")] = {
            "status": 200,
            "body": {"status": "running"},
        }
        result = sessions_tools.start_emulation("s-1", duration_seconds=5.0)
        assert result["ok"] is True

    def test_read_memory(
        self,
        monkeypatch: pytest.MonkeyPatch,
        mock_httpx_client,  # type: ignore[no-untyped-def]
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        mock_httpx_client["responses"][("POST", "/api/v1/sessions/s-1/memory")] = {
            "status": 200,
            "body": {"data_b64": "AAA="},
        }
        result = sessions_tools.read_memory("s-1", 0x20000000, 64)
        assert result["ok"] is True
