"""Smoke tests for the MCP server entry point.

These tests stub out the FastMCP SDK so they run without ``mcp`` installed —
the goal is to verify that all tools/resources are wired up correctly, not
to exercise the SDK itself.
"""

from __future__ import annotations

import sys
import types
from typing import Any
from unittest.mock import MagicMock

import pytest


class _FakeFastMCP:
    """Stand-in for ``mcp.server.fastmcp.FastMCP`` used by tests."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.tools: dict[str, Any] = {}
        self.resources: dict[str, Any] = {}

    def tool(self, name: str | None = None, **_kwargs: Any):  # type: ignore[no-untyped-def]
        def decorator(fn):  # type: ignore[no-untyped-def]
            self.tools[name or fn.__name__] = fn
            return fn

        return decorator

    def resource(self, uri: str, **_kwargs: Any):  # type: ignore[no-untyped-def]
        def decorator(fn):  # type: ignore[no-untyped-def]
            self.resources[uri] = fn
            return fn

        return decorator

    def run(self) -> None:
        pass


@pytest.fixture
def stub_mcp(monkeypatch: pytest.MonkeyPatch) -> None:
    """Inject fake mcp.server.fastmcp.FastMCP into sys.modules."""
    mcp_pkg = types.ModuleType("mcp")
    mcp_server = types.ModuleType("mcp.server")
    mcp_fastmcp = types.ModuleType("mcp.server.fastmcp")
    mcp_fastmcp.FastMCP = _FakeFastMCP  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "mcp", mcp_pkg)
    monkeypatch.setitem(sys.modules, "mcp.server", mcp_server)
    monkeypatch.setitem(sys.modules, "mcp.server.fastmcp", mcp_fastmcp)


class TestBuildMcp:
    def test_registers_all_tools(self, stub_mcp: None) -> None:
        from picolayer_mcp.server import build_mcp

        mcp = build_mcp()
        names = set(mcp.tools.keys())  # type: ignore[attr-defined]

        # Boards
        assert {"picolayer_list_boards", "picolayer_get_board"}.issubset(names)
        # Validation
        assert "picolayer_validate_config" in names
        # Jobs
        assert {
            "picolayer_submit_job",
            "picolayer_get_job",
            "picolayer_list_jobs",
            "picolayer_get_artifacts",
        }.issubset(names)
        # Sessions
        assert {
            "picolayer_create_session",
            "picolayer_destroy_session",
            "picolayer_list_sessions",
            "picolayer_session_status",
            "picolayer_load_firmware",
            "picolayer_execute_monitor",
            "picolayer_start_emulation",
            "picolayer_pause_emulation",
            "picolayer_step_emulation",
            "picolayer_read_registers",
            "picolayer_read_memory",
            "picolayer_get_uart_output",
            "picolayer_run_session_test",
        }.issubset(names)

    def test_registers_all_resources(self, stub_mcp: None) -> None:
        from picolayer_mcp.server import build_mcp

        mcp = build_mcp()
        uris = set(mcp.resources.keys())  # type: ignore[attr-defined]

        assert "picolayer://board-catalog" in uris
        assert "picolayer://config-schema" in uris
        assert "picolayer://peripheral-types" in uris
        assert "picolayer://cpu-types" in uris
        assert "picolayer://robot-keywords" in uris
        assert "picolayer://examples" in uris
        # Templated example URI
        assert any("examples/{example_id}" in u for u in uris)

    def test_main_runs(self, stub_mcp: None, monkeypatch: pytest.MonkeyPatch) -> None:
        from picolayer_mcp import server

        monkeypatch.setattr(server, "build_mcp", lambda: MagicMock(run=MagicMock()))
        server.main()  # should not raise
