"""Tests for picolayer_mcp.auth — API key resolution."""

from __future__ import annotations

from pathlib import Path

import pytest

from picolayer_mcp.auth import (
    DEFAULT_API_ENDPOINT,
    AuthError,
    resolve_auth,
)


class TestResolveAuth:
    def test_env_var_wins(self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "env-key-123")
        ctx = resolve_auth()
        assert ctx.api_key == "env-key-123"
        assert ctx.api_endpoint == DEFAULT_API_ENDPOINT

    def test_env_endpoint_overrides_default(
        self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path
    ) -> None:
        monkeypatch.setenv("PICOLAYER_API_KEY", "k")
        monkeypatch.setenv("PICOLAYER_API_ENDPOINT", "https://staging.picolayer.dev")
        ctx = resolve_auth()
        assert ctx.api_endpoint == "https://staging.picolayer.dev"

    def test_falls_back_to_config_file(self, fake_config_dir: Path) -> None:
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text(
            '[auth]\napi_key = "file-key"\napi_endpoint = "https://from-file"\n'
        )
        ctx = resolve_auth()
        assert ctx.api_key == "file-key"
        assert ctx.api_endpoint == "https://from-file"

    def test_env_key_overrides_file_key(
        self, monkeypatch: pytest.MonkeyPatch, fake_config_dir: Path
    ) -> None:
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text('[auth]\napi_key = "file-key"\n')
        monkeypatch.setenv("PICOLAYER_API_KEY", "env-key")
        ctx = resolve_auth()
        assert ctx.api_key == "env-key"

    def test_no_key_anywhere_raises(self, fake_config_dir: Path) -> None:
        with pytest.raises(AuthError):
            resolve_auth()

    def test_malformed_config_file_treated_as_missing(self, fake_config_dir: Path) -> None:
        fake_config_dir.parent.mkdir(parents=True, exist_ok=True)
        fake_config_dir.write_text("not toml at all }}}")
        with pytest.raises(AuthError):
            resolve_auth()
