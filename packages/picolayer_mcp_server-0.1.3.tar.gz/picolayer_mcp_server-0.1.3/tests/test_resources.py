"""Tests for picolayer_mcp.resources — context resources exposed via MCP."""

from __future__ import annotations

import json

import pytest

from picolayer_mcp.resources import (
    board_catalog_resource,
    config_schema_resource,
    cpu_types_resource,
    example_resource,
    examples_index_resource,
    list_example_ids,
    peripheral_types_resource,
    project_setup_resource,
    robot_keywords_resource,
)


class TestBoardCatalogResource:
    def test_returns_valid_json(self) -> None:
        data = json.loads(board_catalog_resource())
        assert "boards" in data
        assert len(data["boards"]) >= 12

    def test_known_board_present(self) -> None:
        data = json.loads(board_catalog_resource())
        names = [b["name"] for b in data["boards"]]
        assert "stm32f4_discovery" in names
        assert "nrf52840dk" in names

    def test_peripheral_addresses_are_hex_strings(self) -> None:
        data = json.loads(board_catalog_resource())
        stm32 = next(b for b in data["boards"] if b["name"] == "stm32f4_discovery")
        usart2 = next(p for p in stm32["peripherals"] if p["name"] == "usart2")
        assert usart2["base_address"].startswith("0x")


class TestProjectSetupResource:
    def test_states_contract(self) -> None:
        # Normalise whitespace so the assertion survives line wrapping.
        doc = " ".join(project_setup_resource().lower().split())
        # The two sentences an agent MUST see on first read
        assert "pre-built" in doc
        assert "does not compile" in doc

    def test_documents_accepted_binary_formats(self) -> None:
        doc = project_setup_resource()
        for fmt in [".elf", ".bin", ".hex"]:
            assert fmt in doc, f"missing firmware format: {fmt}"

    def test_lists_build_system_options(self) -> None:
        doc = project_setup_resource()
        # At least a few toolchains should be suggested so the agent knows
        # it has latitude to pick one.
        for tool in ["Zephyr", "ESP-IDF", "CMake", "PlatformIO"]:
            assert tool in doc, f"missing build system: {tool}"

    def test_cross_links_to_other_resources(self) -> None:
        doc = project_setup_resource()
        for uri in [
            "picolayer://board-catalog",
            "picolayer://config-schema",
            "picolayer://robot-keywords",
            "picolayer://examples",
        ]:
            assert uri in doc, f"missing cross-link: {uri}"


class TestConfigSchemaResource:
    def test_documents_three_layers(self) -> None:
        doc = config_schema_resource()
        assert "Board shortcut" in doc
        assert "Custom hardware" in doc
        assert "escape hatches" in doc

    def test_mentions_renode_block_fields(self) -> None:
        doc = config_schema_resource()
        # All seven escape hatches must be documented
        for field in [
            "platform_repl",
            "platform_repl_inline",
            "init_resc",
            "machines",
            "custom_peripherals",
            "cosimulation",
            "irqs",
        ]:
            assert field in doc, f"missing escape hatch: {field}"

    def test_mentions_escape_hatch_unverified(self) -> None:
        assert "escape_hatch_unverified" in config_schema_resource()


class TestPeripheralTypesResource:
    def test_returns_valid_json(self) -> None:
        data = json.loads(peripheral_types_resource())
        assert "types" in data
        types = {t["type"] for t in data["types"]}
        assert {"uart", "gpio", "i2c", "spi", "timer", "adc"}.issubset(types)


class TestCpuTypesResource:
    def test_returns_valid_json(self) -> None:
        data = json.loads(cpu_types_resource())
        cpus = {c["cpu"] for c in data["cpus"]}
        assert "cortex-m4f" in cpus
        assert "riscv32" in cpus
        assert "cortex-r52" in cpus

    def test_marks_nvic_requirement(self) -> None:
        data = json.loads(cpu_types_resource())
        cm4 = next(c for c in data["cpus"] if c["cpu"] == "cortex-m4f")
        assert cm4["needs_nvic"] is True
        rv = next(c for c in data["cpus"] if c["cpu"] == "riscv32")
        assert rv["needs_nvic"] is False


class TestRobotKeywordsResource:
    def test_returns_keywords(self) -> None:
        data = json.loads(robot_keywords_resource())
        keywords = [k["keyword"] for k in data["keywords"]]
        assert "Execute Script" in keywords
        assert "Wait For Line On Uart" in keywords
        assert "Start Emulation" in keywords


class TestExamplesResource:
    def test_index_lists_examples(self) -> None:
        data = json.loads(examples_index_resource())
        ids = [e["id"] for e in data["examples"]]
        assert "stm32-blinky" in ids

    def test_list_example_ids_matches(self) -> None:
        ids = list_example_ids()
        data = json.loads(examples_index_resource())
        assert ids == [e["id"] for e in data["examples"]]

    def test_example_resource_returns_files(self) -> None:
        data = json.loads(example_resource("stm32-blinky"))
        assert data["id"] == "stm32-blinky"
        assert "picolayer.yml" in data["files"]
        # Should also include at least one .robot test
        test_files = [k for k in data["files"] if k.startswith("tests/") and k.endswith(".robot")]
        assert len(test_files) >= 1

    def test_unknown_example_raises(self) -> None:
        with pytest.raises(FileNotFoundError):
            example_resource("does-not-exist")


class TestCandidateCatalogPaths:
    """Edge cases for the MCP server's catalog loader path-discovery walk.

    Mirrors the executor regression: a shallow ``__file__`` location must
    not crash. The walk-the-ancestors implementation must produce one
    candidate per ancestor without indexing a fixed depth.
    """

    def test_dev_layout_includes_repo_root_candidate(self) -> None:
        from pathlib import Path

        from picolayer_mcp.catalog import _candidate_paths

        fake = Path("/Users/me/repo/mcp-server/picolayer_mcp/catalog.py")
        paths = _candidate_paths(here=fake)
        assert Path("/Users/me/repo/platforms/board_catalog.json") in paths

    def test_shallow_path_does_not_index_error(self) -> None:
        """A 1-parent path used to crash with IndexError on parents[2]."""
        from pathlib import Path

        from picolayer_mcp.catalog import _candidate_paths

        fake = Path("/x/y.py")
        paths = _candidate_paths(here=fake)
        assert len(paths) >= 1
        assert Path("/x/platforms/board_catalog.json") in paths

    def test_env_override_takes_precedence(
        self,
        tmp_path,
        monkeypatch,  # type: ignore[no-untyped-def]
    ) -> None:
        from pathlib import Path

        from picolayer_mcp.catalog import _candidate_paths

        override = tmp_path / "override.json"
        monkeypatch.setenv("PICOLAYER_BOARD_CATALOG", str(override))
        paths = _candidate_paths(here=Path("/x/y.py"))
        assert paths[0] == override


class TestExamplesRoot:
    """Edge cases for the MCP server's examples directory discovery."""

    def test_walks_up_for_examples_dir(self, tmp_path) -> None:  # type: ignore[no-untyped-def]
        """Build a fake repo at tmp_path with an examples/ dir, then point
        the loader at a deep `examples.py` location and confirm it finds
        the fake examples dir."""
        from pathlib import Path

        from picolayer_mcp.resources import examples as ex_mod

        fake_repo = tmp_path / "repo"
        examples_dir = fake_repo / "examples"
        examples_dir.mkdir(parents=True)
        (examples_dir / "demo").mkdir()

        # Create a fake module path inside the repo so the walk reaches
        # the examples dir.
        fake_module = fake_repo / "mcp-server" / "picolayer_mcp" / "resources" / "examples.py"
        fake_module.parent.mkdir(parents=True)
        fake_module.write_text("# placeholder")

        # The function reads __file__ at module-load — patch it via env
        # override which is what the loader honours.
        import os

        os.environ["PICOLAYER_EXAMPLES_DIR"] = str(examples_dir)
        try:
            root = ex_mod._examples_root()
            assert root == examples_dir
        finally:
            os.environ.pop("PICOLAYER_EXAMPLES_DIR", None)

    def test_falls_back_gracefully_when_no_examples_dir(
        self,
        tmp_path,
        monkeypatch,  # type: ignore[no-untyped-def]
    ) -> None:
        """When no `examples/` dir exists anywhere up the tree, the loader
        must NOT raise — it returns a non-existent fallback path so
        `list_example_ids()` returns []."""
        from picolayer_mcp.resources import examples as ex_mod
        from picolayer_mcp.resources.examples import list_example_ids

        # Point the override at a path that doesn't exist
        monkeypatch.setenv("PICOLAYER_EXAMPLES_DIR", str(tmp_path / "nope"))
        # The override returns the missing path directly, and
        # list_example_ids handles `not is_dir()` by returning [].
        ids = list_example_ids()
        assert ids == []
