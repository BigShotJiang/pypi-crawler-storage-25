"""Tests for picolayer_mcp.tools.boards — board catalog tools."""

from __future__ import annotations

from picolayer_mcp.tools import boards as board_tools


class TestListBoards:
    def test_returns_unique_boards(self) -> None:
        result = board_tools.list_boards()
        assert result["ok"] is True
        names = [b["name"] for b in result["boards"]]
        assert "stm32f4_discovery" in names
        # Aliases collapsed
        assert "nrf52840dk_nrf52840" not in names
        assert len(set(names)) == len(names)


class TestGetBoardInfo:
    def test_known_board(self) -> None:
        result = board_tools.get_board_info("stm32f4_discovery")
        assert result["ok"] is True
        assert result["board"]["mcu"] == "STM32F407VG"
        peripherals = result["board"]["peripherals"]
        assert any(p["name"] == "usart2" for p in peripherals)

    def test_unknown_board(self) -> None:
        result = board_tools.get_board_info("nonexistent")
        assert result["ok"] is False
        assert "Unknown board" in result["error"]

    def test_case_insensitive(self) -> None:
        result = board_tools.get_board_info("STM32F4_DISCOVERY")
        assert result["ok"] is True
