#!/usr/bin/env python3
"""Run each test file in a separate subprocess to prevent memory leaks.

pytest keeps references to test objects for the entire session. With 2000+
tests this can grow to 100+ GB. Running each file in its own process caps
memory at whatever a single file needs (~200MB max).

Usage:
    python scripts/run_tests.py              # run all unit tests
    python scripts/run_tests.py -x           # stop on first failure
    python scripts/run_tests.py -k adapter   # filter by keyword
    python scripts/run_tests.py --parallel 4 # run 4 files at once
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


def discover_test_files(test_dir: Path, keyword: str | None = None) -> list[Path]:
    """Find all test_*.py files, optionally filtered by keyword."""
    files = sorted(test_dir.glob("test_*.py"))
    if keyword:
        files = [f for f in files if keyword in f.stem]
    return files


def run_file(path: Path, extra_args: list[str]) -> tuple[Path, int, float, str]:
    """Run a single test file in a subprocess. Returns (path, exitcode, duration, output)."""
    cmd = [sys.executable, "-m", "pytest", str(path), "-x", "-q", "--tb=short", *extra_args]
    start = time.monotonic()
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    duration = time.monotonic() - start
    output = result.stdout + result.stderr
    return path, result.returncode, duration, output


def run_sequential(files: list[Path], extra_args: list[str], fail_fast: bool) -> int:
    """Run test files one by one."""
    passed = 0
    failed = 0
    total_duration = 0.0

    for i, path in enumerate(files, 1):
        label = f"[{i}/{len(files)}] {path.name}"
        try:
            fpath, code, duration, output = run_file(path, extra_args)
        except subprocess.TimeoutExpired:
            print(f"  TIMEOUT {label} (>120s)")
            failed += 1
            if fail_fast:
                break
            continue

        total_duration += duration
        if code == 0:
            passed += 1
            # Extract test count from output
            last_line = [l for l in output.strip().split("\n") if l.strip()][-1] if output.strip() else ""
            print(f"  PASS {label} ({duration:.1f}s) {last_line}")
        elif code == 5:
            # No tests collected — not a failure
            passed += 1
            print(f"  SKIP {label} (no tests)")
        else:
            failed += 1
            print(f"  FAIL {label} ({duration:.1f}s)")
            # Show failure details
            for line in output.strip().split("\n"):
                if line.strip():
                    print(f"       {line}")
            if fail_fast:
                break

    print(f"\n{'=' * 60}")
    print(f"Files: {passed} passed, {failed} failed, {len(files)} total")
    print(f"Time:  {total_duration:.1f}s")
    return 1 if failed else 0


def run_parallel(files: list[Path], extra_args: list[str], workers: int, fail_fast: bool) -> int:
    """Run test files in parallel using concurrent.futures."""
    from concurrent.futures import ProcessPoolExecutor, as_completed

    passed = 0
    failed = 0
    total = len(files)
    abort = False

    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(run_file, f, extra_args): f for f in files}
        for future in as_completed(futures):
            if abort:
                continue
            try:
                fpath, code, duration, output = future.result(timeout=120)
            except Exception as exc:
                fpath = futures[future]
                print(f"  ERROR {fpath.name}: {exc}")
                failed += 1
                if fail_fast:
                    abort = True
                continue

            if code == 0 or code == 5:
                passed += 1
                last_line = [l for l in output.strip().split("\n") if l.strip()][-1] if output.strip() else ""
                print(f"  PASS {fpath.name} ({duration:.1f}s) {last_line}")
            else:
                failed += 1
                print(f"  FAIL {fpath.name} ({duration:.1f}s)")
                for line in output.strip().split("\n")[-5:]:
                    if line.strip():
                        print(f"       {line}")
                if fail_fast:
                    abort = True

    print(f"\n{'=' * 60}")
    print(f"Files: {passed} passed, {failed} failed, {total} total")
    return 1 if failed else 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Run tests in isolated subprocesses")
    parser.add_argument("-x", "--fail-fast", action="store_true", help="Stop on first failure")
    parser.add_argument("-k", "--keyword", help="Filter test files by keyword")
    parser.add_argument("--parallel", type=int, default=0, help="Number of parallel workers (0=sequential)")
    parser.add_argument("--test-dir", default="tests/unit", help="Test directory")
    parser.add_argument("extra", nargs="*", help="Extra args passed to pytest")
    args = parser.parse_args()

    test_dir = Path(args.test_dir)
    if not test_dir.exists():
        print(f"Test directory not found: {test_dir}")
        sys.exit(1)

    files = discover_test_files(test_dir, args.keyword)
    if not files:
        print("No test files found")
        sys.exit(0)

    print(f"Running {len(files)} test files (each in its own process)")
    print(f"{'=' * 60}")

    if args.parallel > 0:
        code = run_parallel(files, args.extra, args.parallel, args.fail_fast)
    else:
        code = run_sequential(files, args.extra, args.fail_fast)

    sys.exit(code)


if __name__ == "__main__":
    main()
