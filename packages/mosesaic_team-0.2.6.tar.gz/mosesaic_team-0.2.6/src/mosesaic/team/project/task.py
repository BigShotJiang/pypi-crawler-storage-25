from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from uuid import UUID, uuid4


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    FAILED = "failed"


_VALID_TIERS = frozenset({"simple", "medium", "complex"})


@dataclass
class SprintTask:
    """One unit of work in a sprint — assigned to a single developer agent."""
    title: str
    description: str
    tier: str                           # "simple" | "medium" | "complex"
    id: UUID = field(default_factory=uuid4)
    status: TaskStatus = TaskStatus.PENDING
    result: str = ""
    assigned_to: str = ""

    def __post_init__(self) -> None:
        if self.tier not in _VALID_TIERS:
            raise ValueError(f"Invalid tier {self.tier!r}. Must be one of: {sorted(_VALID_TIERS)}")

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "title": self.title,
            "description": self.description,
            "tier": self.tier,
            "status": self.status.value,
            "result": self.result,
            "assigned_to": self.assigned_to,
        }

    @classmethod
    def from_dict(cls, d: dict) -> SprintTask:
        return cls(
            id=UUID(d["id"]),
            title=d["title"],
            description=d["description"],
            tier=d["tier"],
            status=TaskStatus(d["status"]),
            result=d.get("result", ""),
            assigned_to=d.get("assigned_to", ""),
        )
