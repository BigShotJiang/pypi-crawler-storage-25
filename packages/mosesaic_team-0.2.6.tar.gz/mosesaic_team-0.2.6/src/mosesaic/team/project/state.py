from __future__ import annotations
import json
from pathlib import Path
from mosesaic.team.project.task import SprintTask


class ProjectState:
    """Manages .mosesaic/state.json — sprint goal, task list, budget ledger.

    Reads existing state on construction (if the file exists).
    Every mutation immediately persists to disk.
    """

    def __init__(self, project_root: str | Path) -> None:
        self._root = Path(project_root).resolve()
        self._path = self._root / ".mosesaic" / "state.json"
        self._data: dict = {"goal": "", "tasks": [], "budget_spent": 0.0}
        if self._path.exists():
            self._data = json.loads(self._path.read_text(encoding="utf-8"))

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(self._data, indent=2), encoding="utf-8")

    @property
    def goal(self) -> str:
        return self._data.get("goal", "")

    @goal.setter
    def goal(self, value: str) -> None:
        self._data["goal"] = value
        self._save()

    @property
    def budget_spent(self) -> float:
        return self._data.get("budget_spent", 0.0)

    def record_spend(self, amount: float) -> None:
        self._data["budget_spent"] = self.budget_spent + amount
        self._save()

    def add_task(self, task: SprintTask) -> None:
        self._data.setdefault("tasks", []).append(task.to_dict())
        self._save()

    def update_task(self, task: SprintTask) -> None:
        for i, t in enumerate(self._data.get("tasks", [])):
            if t["id"] == str(task.id):
                self._data["tasks"][i] = task.to_dict()
                self._save()
                return
        raise KeyError(f"Task {task.id} not found in project state")

    def get_tasks(self) -> list[SprintTask]:
        return [SprintTask.from_dict(t) for t in self._data.get("tasks", [])]

    def clear(self) -> None:
        """Reset for a new sprint."""
        self._data = {"goal": "", "tasks": [], "budget_spent": 0.0}
        self._save()
