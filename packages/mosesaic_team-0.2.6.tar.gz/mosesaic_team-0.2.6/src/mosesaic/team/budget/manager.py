from __future__ import annotations

import logging

from mosesaic.llm.provider import LLMProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.team.budget.tiers import TIER_CONFIG, TaskTier

_log = logging.getLogger(__name__)


class BudgetManager:
    """Tracks sprint budget, selects models by tier, warns and downgrades.

    Usage:
        mgr = BudgetManager(registry=provider_registry, sprint_budget_usd=10.0)
        model_id, provider = mgr.select_model(TaskTier.MEDIUM)
        # after the call:
        mgr.record_spend(response.cost_usd, provider=provider.name)
    """

    def __init__(
        self,
        registry: ProviderRegistry,
        sprint_budget_usd: float = 10.0,
        warn_at_usd: float | None = None,
        auto_downgrade: bool = True,
    ) -> None:
        self._registry = registry
        self._sprint_budget = sprint_budget_usd
        self._warn_at = warn_at_usd if warn_at_usd is not None else sprint_budget_usd * 0.5
        self._auto_downgrade = auto_downgrade
        self._total_spent: float = 0.0
        self._by_provider: dict[str, float] = {}
        self._warned: bool = False

    @property
    def total_spent_usd(self) -> float:
        return self._total_spent

    @property
    def remaining_usd(self) -> float:
        return max(0.0, self._sprint_budget - self._total_spent)

    @property
    def is_exhausted(self) -> bool:
        return self._total_spent >= self._sprint_budget

    def _find_for_provider(
        self,
        provider_name: str,
        task_hint: str,
        budget_usd: float,
    ) -> tuple[str, LLMProvider] | None:
        """Return (model_id, provider) for the first model from provider_name
        within budget, or None if no such model exists."""
        for model_id, provider, caps in self._registry.iter_models():
            if provider.name != provider_name:
                continue
            estimated = caps.estimate_cost(input_tokens=4096, output_tokens=4096)
            if estimated <= budget_usd:
                return model_id, provider
        return None

    def record_spend(self, amount_usd: float, provider: str = "unknown") -> None:
        """Record spend after an LLM call. Logs a warning if threshold crossed."""
        self._total_spent += amount_usd
        self._by_provider[provider] = self._by_provider.get(provider, 0.0) + amount_usd

        if not self._warned and self._total_spent >= self._warn_at:
            self._warned = True
            _log.warning(
                "[Budget warning]: $%.2f of $%.2f used ($%.2f remaining)",
                self._total_spent,
                self._sprint_budget,
                self.remaining_usd,
            )

    def select_model(self, tier: TaskTier) -> tuple[str, LLMProvider]:
        """Pick the best available model for the given complexity tier.

        When budget is exhausted:
        - auto_downgrade=True  -> fall back to cheapest free model available
        - auto_downgrade=False -> raise RuntimeError
        """
        if self.is_exhausted:
            if not self._auto_downgrade:
                raise RuntimeError(
                    f"Sprint budget exhausted (${self._total_spent:.2f} / "
                    f"${self._sprint_budget:.2f}). Set auto_downgrade=True to "
                    "continue with free models."
                )
            return self._registry.find(task_hint="cheap", budget_usd=0.0)

        cfg = TIER_CONFIG[tier]
        for provider_name in cfg.preferred_providers:
            result = self._find_for_provider(
                provider_name, cfg.task_hint, cfg.max_cost_per_call_usd
            )
            if result is not None:
                return result

        # No preferred provider matched — fall back to registry's best within budget
        return self._registry.find(
            task_hint=cfg.task_hint,
            budget_usd=cfg.max_cost_per_call_usd,
        )

    def spend_summary(self) -> dict:
        """Return a summary dict for display/logging."""
        return {
            "total": self._total_spent,
            "budget": self._sprint_budget,
            "remaining": self.remaining_usd,
            "exhausted": self.is_exhausted,
            "by_provider": dict(self._by_provider),
        }
