from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum


class TaskTier(str, Enum):
    """Complexity tier — determines which model class the PM selects."""
    SIMPLE = "simple"    # summaries, formatting, task writing, classification
    MEDIUM = "medium"    # code generation, test writing, debugging
    COMPLEX = "complex"  # architecture, design, multi-step reasoning, review


@dataclass(frozen=True)
class TierConfig:
    """Model selection preferences for one complexity tier."""
    preferred_providers: list[str]       # try in order; fall back to next
    task_hint: str                        # passed to ProviderRegistry.find()
    max_cost_per_call_usd: float          # hard cap per single LLM call
    description: str = ""


# Default tier configuration.
TIER_CONFIG: dict[TaskTier, TierConfig] = {
    TaskTier.SIMPLE: TierConfig(
        preferred_providers=["ollama", "groq", "openai"],
        task_hint="cheap",
        max_cost_per_call_usd=0.01,
        description="Simple transforms, summaries, task writing",
    ),
    TaskTier.MEDIUM: TierConfig(
        preferred_providers=["openai", "anthropic", "groq"],
        task_hint="general",
        max_cost_per_call_usd=0.10,
        description="Code generation, debugging, test writing",
    ),
    TaskTier.COMPLEX: TierConfig(
        preferred_providers=["anthropic", "openai"],
        task_hint="reasoning",
        max_cost_per_call_usd=1.00,
        description="Architecture, multi-step reasoning, final review",
    ),
}
