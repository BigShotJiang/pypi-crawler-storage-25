"""Sprint execution agents — Developer, QA, Scribe.

These agents are registered with WorkflowRuntime (not the AgentRuntime from Plan 2).
They use ctx.llm directly (routed via ProviderRegistry) and are chartered via
system prompts loaded from mosesaic.team.charters.

QA anti-fabrication gate:
  - project_root provided → runs `pytest --tb=short -q`
  - tests fail → confidence=UNTESTED, passed=False, no LLM call (immediate rejection)
  - tests pass → confidence=VERIFIED, proceeds to LLM quality review
  - project_root empty → confidence=REVIEWED, LLM review only
"""
from __future__ import annotations

from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.team.charters.charter_loader import load_charter
from mosesaic.team.sprint.protocol import (
    QAInput, QAOutput,
    ScribeInput, ScribeOutput,
    SprintDeveloperInput, SprintDeveloperOutput,
)


@agent(name="developer", system_prompt=load_charter("developer"))
async def sprint_developer_agent(ctx: AgentContext) -> None:
    """Implements a sprint task using ctx.llm and reports what was built."""
    msg = await ctx.receive()
    payload: SprintDeveloperInput = msg.payload

    task = payload.task
    feedback_section = (
        f"\n\nQA feedback to address:\n{payload.feedback}"
        if payload.feedback
        else ""
    )
    prompt = (
        f"Task: {task.title}\n\n"
        f"Description: {task.description}\n\n"
        f"Tier: {task.tier}\n"
        f"Project root: {payload.project_root}"
        f"{feedback_section}\n\n"
        "Implement this task. Describe what you built and which files you changed."
    )
    task_hint = "code" if task.tier in ("medium", "complex") else "cheap"
    response = await ctx.llm.chat(
        messages=[{"role": "user", "content": prompt}],
        task_hint=task_hint,
    )
    output = SprintDeveloperOutput(
        task_id=str(task.id),
        summary=response.content,
    )
    await ctx.send(msg.from_agent, output)


@agent(name="qa", system_prompt=load_charter("qa"))
async def qa_agent(ctx: AgentContext) -> None:
    """Verifies sprint work.

    Anti-fabrication gate: if project_root is set, runs pytest first.
    Tests failing → immediate UNTESTED rejection, no LLM call.
    Tests passing → VERIFIED confidence, LLM review for quality.
    No project_root → REVIEWED confidence, LLM review only.
    """
    msg = await ctx.receive()
    payload: QAInput = msg.payload

    test_output = ""
    tests_passed = False

    if payload.project_root:
        # Run actual tests — anti-fabrication gate
        from mosesaic.team.tools.shell import ShellTools
        shell = ShellTools(project_root=payload.project_root, default_timeout_seconds=120.0)
        result = shell.run(f"pytest {payload.project_root} --tb=short -q")
        test_output = str(result)

        if not result.success:
            # Tests failed — reject immediately, do not call LLM
            await ctx.send(
                msg.from_agent,
                QAOutput(
                    passed=False,
                    confidence="UNTESTED",
                    feedback=f"Tests failed. Fix the failures before review:\n{test_output}",
                    test_output=test_output,
                ),
            )
            return

        tests_passed = True

    # LLM quality review
    test_section = (
        f"\n\nTest execution output (all passed):\n{test_output}"
        if tests_passed
        else "\n\n(No test execution — reviewing code only)"
    )
    confidence_note = "VERIFIED" if tests_passed else "REVIEWED"
    prompt = (
        f"Review this sprint task implementation:\n\n"
        f"Task ID: {payload.developer_output.task_id}\n"
        f"Developer summary:\n{payload.developer_output.summary}"
        f"{test_section}\n\n"
        f"Assess the implementation. Is it complete and correct?\n"
        f"Confidence will be {confidence_note}. "
        f"Reply with your assessment and whether this passes review."
    )
    response = await ctx.llm.chat(
        messages=[{"role": "user", "content": prompt}],
        task_hint="cheap",
    )
    await ctx.send(
        msg.from_agent,
        QAOutput(
            passed=True,
            confidence=confidence_note,
            feedback=response.content,
            test_output=test_output,
        ),
    )


@agent(name="scribe", system_prompt=load_charter("scribe"))
async def scribe_agent(ctx: AgentContext) -> None:
    """Writes a concise technical summary of completed sprint work."""
    msg = await ctx.receive()
    payload: ScribeInput = msg.payload

    prompt = (
        f"Summarise this completed sprint task:\n\n"
        f"Task: {payload.task.title}\n"
        f"Description: {payload.task.description}\n\n"
        f"Developer summary:\n{payload.developer_output.summary}\n\n"
        f"QA result: {payload.qa_output.confidence}\n"
        f"QA feedback: {payload.qa_output.feedback}\n\n"
        "Write a concise technical summary for the project record."
    )
    response = await ctx.llm.chat(
        messages=[{"role": "user", "content": prompt}],
        task_hint="cheap",
    )
    await ctx.send(
        msg.from_agent,
        ScribeOutput(
            summary=response.content,
            confidence=payload.qa_output.confidence,
            artifacts=payload.developer_output.files_changed,
        ),
    )
