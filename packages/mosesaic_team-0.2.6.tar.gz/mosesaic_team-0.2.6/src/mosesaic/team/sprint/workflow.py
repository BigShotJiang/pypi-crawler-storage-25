"""sprint_task_workflow — developer → QA verify loop → scribe.

The workflow retries up to 3 times when QA rejects the developer's output.
On each retry the developer receives the QA feedback so it can address specific issues.
After QA passes, the scribe writes a summary.
If QA never passes after 3 attempts, VerificationFailed is raised and
WorkflowRuntime returns WorkflowResult.failed().
"""
from __future__ import annotations

from mosesaic.workflow import WorkflowContext, step, verify, workflow
from mosesaic.team.sprint.protocol import (
    QAInput, QAOutput,
    ScribeInput,
    SprintDeveloperInput,
)


@workflow(name="sprint-task")
async def sprint_task_workflow(ctx: WorkflowContext):
    """Run developer → QA → retry loop → scribe.

    ctx.input must be a SprintDeveloperInput with task and project_root.
    Returns a ScribeOutput on success.
    Raises VerificationFailed after 3 failed QA attempts.
    """
    initial_input: SprintDeveloperInput = ctx.input
    qa_output: QAOutput | None = None
    dev_output = None

    async for attempt in verify(max_attempts=3):
        dev_input = SprintDeveloperInput(
            task=initial_input.task,
            project_root=initial_input.project_root,
            feedback=qa_output.feedback if qa_output is not None else "",
        )
        dev_output = await step(
            "developer",
            input=dev_input,
            key=f"dev_{attempt.attempt}",
        )
        qa_output = await step(
            "qa",
            input=QAInput(
                developer_output=dev_output,
                project_root=initial_input.project_root,
            ),
            key=f"qa_{attempt.attempt}",
        )
        if qa_output.passed:
            break

    return await step(
        "scribe",
        input=ScribeInput(
            developer_output=dev_output,
            qa_output=qa_output,
            task=initial_input.task,
        ),
    )
