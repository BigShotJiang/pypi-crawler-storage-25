"""Protocol types (inputs/outputs) for sprint execution agents."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal

from mosesaic.team.project.task import SprintTask


@dataclass
class SprintDeveloperInput:
    """Input to the sprint developer agent."""
    task: SprintTask
    project_root: str
    feedback: str = ""  # QA feedback from a previous failed attempt


@dataclass
class SprintDeveloperOutput:
    """Output from the sprint developer agent."""
    task_id: str
    summary: str
    files_changed: list[str] = field(default_factory=list)


@dataclass
class QAInput:
    """Input to the QA agent."""
    developer_output: SprintDeveloperOutput
    project_root: str  # empty string = skip test execution, confidence = REVIEWED


@dataclass
class QAOutput:
    """Output from the QA agent."""
    passed: bool
    confidence: Literal["VERIFIED", "REVIEWED", "UNTESTED"]
    feedback: str
    test_output: str = ""


@dataclass
class ScribeInput:
    """Input to the scribe agent."""
    developer_output: SprintDeveloperOutput
    qa_output: QAOutput
    task: SprintTask


@dataclass
class ScribeOutput:
    """Output from the scribe agent — stored in project state."""
    summary: str
    confidence: Literal["VERIFIED", "REVIEWED", "UNTESTED"]
    artifacts: list[str] = field(default_factory=list)
