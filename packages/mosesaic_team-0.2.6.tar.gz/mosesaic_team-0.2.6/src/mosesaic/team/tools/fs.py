from __future__ import annotations
import fnmatch
from pathlib import Path


class FileSystemTools:
    """Sandboxed filesystem operations for agent use within a project directory.

    All paths are relative to project_root. Any attempt to access paths outside
    project_root raises PermissionError.
    """

    def __init__(self, project_root: str | Path) -> None:
        self._root = Path(project_root).resolve()

    def _resolve(self, relative_path: str) -> Path:
        target = (self._root / relative_path).resolve()
        try:
            target.relative_to(self._root)
        except ValueError:
            raise PermissionError(
                f"Path '{relative_path}' resolves outside project root '{self._root}'"
            )
        return target

    def read_file(self, path: str) -> str:
        """Read a file and return its text content."""
        target = self._resolve(path)
        if not target.exists():
            raise FileNotFoundError(f"File not found: {path}")
        return target.read_text(encoding="utf-8")

    def write_file(self, path: str, content: str) -> None:
        """Write text content to a file, creating parent directories as needed."""
        target = self._resolve(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    def list_files(self, directory: str = ".", pattern: str = "*") -> list[str]:
        """List files in a directory matching an optional glob pattern.

        Returns paths relative to project root.
        """
        target = self._resolve(directory)
        if not target.is_dir():
            raise FileNotFoundError(f"Directory not found: {directory}")
        results = []
        for f in sorted(target.rglob(pattern)):
            if f.is_file():
                results.append(str(f.relative_to(self._root)))
        return results

    def search_files(
        self, query: str, directory: str = ".", pattern: str = "*"
    ) -> list[dict]:
        """Search file contents for a string. Returns matches with file + line info."""
        target = self._resolve(directory)
        matches = []
        for f in sorted(target.rglob(pattern)):
            if not f.is_file():
                continue
            try:
                lines = f.read_text(encoding="utf-8").splitlines()
            except UnicodeDecodeError:
                continue
            for i, line in enumerate(lines, start=1):
                if query in line:
                    matches.append({
                        "file": str(f.relative_to(self._root)),
                        "line_number": i,
                        "line": line.strip(),
                    })
        return matches
