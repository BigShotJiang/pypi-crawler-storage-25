from __future__ import annotations
import os
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path

# Commands that are always blocked regardless of context
_BLOCKED_PATTERNS = [
    "rm -rf /",
    "sudo",
    "mkfs",
    ":(){:|:&};:",   # fork bomb
    "dd if=/dev/",
    "> /dev/sda",
]

# Injection patterns detected when shell=True
_INJECTION_PATTERNS = ["$(", "`", "${"]


@dataclass
class ShellResult:
    """Output from a shell command."""
    command: str
    exit_code: int
    stdout: str
    stderr: str

    @property
    def success(self) -> bool:
        return self.exit_code == 0

    def __str__(self) -> str:
        parts = [f"$ {self.command}  [exit {self.exit_code}]"]
        if self.stdout.strip():
            parts.append(self.stdout.rstrip())
        if self.stderr.strip():
            parts.append(f"[stderr] {self.stderr.rstrip()}")
        return "\n".join(parts)


class ShellTools:
    """Run shell commands inside the project directory with safety guardrails.

    Commands are blocked if they match known dangerous patterns.
    All commands run with cwd=project_root.
    """

    def __init__(
        self,
        project_root: str | Path,
        default_timeout_seconds: float = 60.0,
    ) -> None:
        self._root = Path(project_root).resolve()
        self._default_timeout = default_timeout_seconds

    def _check_blocked(self, command: str) -> None:
        for pattern in _BLOCKED_PATTERNS:
            if pattern in command:
                raise PermissionError(
                    f"Command blocked for safety: '{pattern}' detected in: {command}"
                )

    def _check_injection(self, command: str) -> None:
        for pattern in _INJECTION_PATTERNS:
            if pattern in command:
                raise PermissionError(
                    f"Potential shell injection detected: {pattern!r} in command. "
                    "Use shell=False (default) to pass arguments as separate tokens."
                )

    @staticmethod
    def quote(value: str) -> str:
        """Shell-quote a value for safe embedding in string commands (wraps shlex.quote)."""
        return shlex.quote(value)

    def run(
        self,
        command: str,
        *,
        shell: bool = False,
        timeout_seconds: float | None = None,
        env: dict[str, str] | None = None,
    ) -> ShellResult:
        """Run a shell command in the project directory.

        Args:
            command:          Command string to run.
            shell:            If True, run via /bin/sh -c (allows pipes, redirects).
            timeout_seconds:  Override default timeout.
            env:              Additional environment variables.

        Raises:
            PermissionError: If command matches a blocked pattern or injection detected (shell=True).
            TimeoutError:    If command exceeds the timeout.
        """
        self._check_blocked(command)
        if shell:
            self._check_injection(command)
        timeout = timeout_seconds if timeout_seconds is not None else self._default_timeout
        effective_env = {**os.environ, **env} if env else None

        args = command if shell else shlex.split(command)
        try:
            proc = subprocess.run(
                args,
                shell=shell,
                cwd=self._root,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=effective_env,
            )
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError(
                f"Command timed out after {timeout}s: {command}"
            ) from exc

        return ShellResult(
            command=command,
            exit_code=proc.returncode,
            stdout=proc.stdout,
            stderr=proc.stderr,
        )
