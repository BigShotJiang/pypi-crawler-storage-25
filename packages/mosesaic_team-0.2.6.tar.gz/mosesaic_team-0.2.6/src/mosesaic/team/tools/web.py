"""WebSearchTools — DuckDuckGo search and HTML page fetch. No API key required."""
from __future__ import annotations

import re
from dataclasses import dataclass

import httpx


@dataclass
class SearchResult:
    """A single search result returned by WebSearchTools.search()."""
    title: str
    url: str
    snippet: str


_DDG_API = "https://api.duckduckgo.com/"
_HTML_TAG = re.compile(r"<[^>]+>")


class WebSearchTools:
    """Web search and page fetch using DuckDuckGo Instant Answer API.

    No API key required. Results come from DuckDuckGo's public JSON endpoint.

    Args:
        timeout_seconds: HTTP request timeout. Default 10s.
    """

    def __init__(self, timeout_seconds: float = 10.0) -> None:
        self._timeout = timeout_seconds

    def search(self, query: str, max_results: int = 5) -> list[SearchResult]:
        """Search using DuckDuckGo Instant Answer API.

        Returns up to max_results SearchResult objects.

        Args:
            query:       Search query string.
            max_results: Maximum number of results to return.
        """
        params = {
            "q": query,
            "format": "json",
            "no_html": "1",
            "skip_disambig": "1",
        }
        with httpx.Client(timeout=self._timeout) as client:
            response = client.get(_DDG_API, params=params)
            response.raise_for_status()
            data = response.json()

        results: list[SearchResult] = []

        # Main abstract (e.g. Wikipedia summary)
        if data.get("AbstractText") and data.get("AbstractURL"):
            results.append(SearchResult(
                title=data.get("Heading", query),
                url=data["AbstractURL"],
                snippet=data["AbstractText"][:300],
            ))

        # Related topics
        for topic in data.get("RelatedTopics", []):
            if len(results) >= max_results:
                break
            if "FirstURL" not in topic or "Text" not in topic:
                continue
            text: str = topic["Text"]
            title = text.split(" - ")[0] if " - " in text else text[:60]
            results.append(SearchResult(
                title=title,
                url=topic["FirstURL"],
                snippet=text[:300],
            ))

        return results[:max_results]

    def fetch_page(self, url: str, max_chars: int = 4000) -> str:
        """Fetch a URL and return its plain-text content (HTML tags stripped).

        Args:
            url:       URL to fetch.
            max_chars: Truncate output to this many characters.
        """
        with httpx.Client(timeout=self._timeout) as client:
            response = client.get(url, follow_redirects=True)
            response.raise_for_status()
            text = _HTML_TAG.sub(" ", response.text)
            text = re.sub(r"\s+", " ", text).strip()
        return text[:max_chars]
