from __future__ import annotations
import shlex
import shutil
import subprocess
from pathlib import Path
from mosesaic.team.tools.shell import ShellTools, ShellResult


class GitTools:
    """Git access for agents. Read operations via ShellTools; write operations
    via subprocess list form (injection-safe — LLM content is never interpolated
    into a shell string).
    """

    def __init__(self, project_root: str | Path) -> None:
        self._root = Path(project_root).resolve()
        self._shell = ShellTools(project_root=project_root)

    def _run(self, args: list[str], *, timeout: float = 60.0) -> ShellResult:
        """Run a command using subprocess list form. Never uses shell=True."""
        try:
            proc = subprocess.run(
                args,
                cwd=self._root,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError(f"Command timed out: {args}") from exc
        return ShellResult(
            command=shlex.join(args),
            exit_code=proc.returncode,
            stdout=proc.stdout,
            stderr=proc.stderr,
        )

    # ── Read operations ───────────────────────────────────────────────────────

    def status(self) -> str:
        """Return the output of `git status` — shows modified/untracked files."""
        result = self._shell.run("git status")
        if not result.success:
            return f"[git error] {result.stderr}"
        return result.stdout

    def diff(self, path: str = "") -> str:
        """Return `git diff` output, optionally for a specific path."""
        cmd = f"git diff -- {shlex.quote(path)}".strip() if path else "git diff"
        result = self._shell.run(cmd)
        if not result.success:
            return f"[git error] {result.stderr}"
        return result.stdout

    def log(self, max_entries: int = 10, oneline: bool = True) -> str:
        """Return recent commit log.

        Args:
            max_entries: Maximum number of commits to show.
            oneline:     If True, compact one-line format. If False, full format.
        """
        fmt = "--oneline" if oneline else "--format=medium"
        result = self._shell.run(f"git log {fmt} -n {max_entries}")
        if not result.success:
            return f"[git error] {result.stderr}"
        return result.stdout

    # ── Write operations (subprocess list form) ───────────────────────────────

    def add(self, paths: list[str] | None = None) -> ShellResult:
        """Stage files for commit. If paths is None, stages all changes (git add .)."""
        args = ["git", "add"] + (list(paths) if paths else ["."])
        return self._run(args)

    def commit(self, message: str) -> ShellResult:
        """Create a commit. Message is passed as a separate argv item — never interpolated."""
        return self._run(["git", "commit", "-m", message])

    def push(
        self,
        remote: str = "origin",
        branch: str | None = None,
    ) -> ShellResult:
        """Push to remote. If branch is given, uses --set-upstream."""
        if branch:
            return self._run(["git", "push", "--set-upstream", remote, branch])
        return self._run(["git", "push", remote])

    def create_pr(
        self,
        title: str,
        body: str,
        base: str = "main",
    ) -> ShellResult:
        """Open a GitHub pull request via the gh CLI.

        Raises:
            FileNotFoundError: If gh is not installed.
        """
        if not shutil.which("gh"):
            raise FileNotFoundError(
                "gh CLI not found. Install from: https://cli.github.com/"
            )
        return self._run(["gh", "pr", "create",
                          "--title", title, "--body", body, "--base", base])
