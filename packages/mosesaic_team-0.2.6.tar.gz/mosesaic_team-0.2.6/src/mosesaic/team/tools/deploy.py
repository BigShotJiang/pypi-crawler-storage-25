"""DeployTools — kubectl, helm, docker wrappers with dry_run safety defaults.

All methods default to dry_run=True. Only pass dry_run=False after a
human_gate() has explicitly approved the deployment in the calling workflow.
"""
from __future__ import annotations

import shlex
import shutil
import subprocess
from pathlib import Path

from mosesaic.team.tools.shell import ShellResult


class DeployTools:
    """Deployment tools: kubectl, helm, docker.

    Args:
        project_root: Working directory for all subprocess calls.
    """

    def __init__(self, project_root: str | Path) -> None:
        self._root = Path(project_root).resolve()

    def _run(self, args: list[str], *, timeout: float = 120.0) -> ShellResult:
        """Execute a command using subprocess list form (injection-safe)."""
        try:
            proc = subprocess.run(
                args,
                cwd=self._root,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError(f"Deploy command timed out: {args}") from exc
        return ShellResult(
            command=shlex.join(args),
            exit_code=proc.returncode,
            stdout=proc.stdout,
            stderr=proc.stderr,
        )

    def _require_tool(self, name: str) -> None:
        if not shutil.which(name):
            raise FileNotFoundError(
                f"'{name}' not found in PATH. "
                f"Install it before using deploy tools."
            )

    def kubectl_apply(
        self,
        manifest_path: str,
        *,
        namespace: str | None = None,
        dry_run: bool = True,
    ) -> ShellResult:
        """Apply a Kubernetes manifest file.

        Args:
            manifest_path: Path to the YAML manifest.
            namespace:     Kubernetes namespace. None = cluster default.
            dry_run:       If True (default), passes --dry-run=client.

        Raises:
            FileNotFoundError: If kubectl is not in PATH.
        """
        self._require_tool("kubectl")
        args = ["kubectl", "apply", "-f", manifest_path]
        if namespace:
            args += ["-n", namespace]
        if dry_run:
            args += ["--dry-run=client"]
        return self._run(args)

    def helm_upgrade(
        self,
        release: str,
        chart: str,
        *,
        namespace: str = "default",
        values_file: str | None = None,
        dry_run: bool = True,
    ) -> ShellResult:
        """Run helm upgrade --install for a release.

        Args:
            release:     Helm release name.
            chart:       Chart path or name.
            namespace:   Kubernetes namespace.
            values_file: Path to values YAML (-f flag).
            dry_run:     If True (default), passes --dry-run.

        Raises:
            FileNotFoundError: If helm is not in PATH.
        """
        self._require_tool("helm")
        args = ["helm", "upgrade", "--install", release, chart, "-n", namespace]
        if values_file:
            args += ["-f", values_file]
        if dry_run:
            args += ["--dry-run"]
        return self._run(args)

    def docker_push(
        self,
        image: str,
        tag: str = "latest",
        *,
        dry_run: bool = True,
    ) -> ShellResult:
        """Push a Docker image to a registry.

        Args:
            image:   Image name (e.g. 'myrepo/myimage').
            tag:     Image tag (default 'latest').
            dry_run: If True (default), returns description without calling docker.

        Raises:
            FileNotFoundError: If docker is not in PATH (only when dry_run=False).
        """
        full_image = f"{image}:{tag}"
        if dry_run:
            return ShellResult(
                command=f"docker push {full_image}",
                exit_code=0,
                stdout=f"[dry-run] Would push {full_image}",
                stderr="",
            )
        self._require_tool("docker")
        return self._run(["docker", "push", full_image])
