"""MachineCapabilities — per-environment tool availability from JSON config.

Reads `.mosesaic/machine-capabilities.json` at project root. If the file is
absent, conservative defaults apply (git read-only, no deploy tools).

File format:
    {
        "git.read":       true,
        "git.write":      true,
        "shell":          true,
        "web_search":     true,
        "deploy.kubectl": false,
        "deploy.helm":    false,
        "deploy.docker":  false
    }
"""
from __future__ import annotations

import json
from pathlib import Path


_CAPABILITIES_FILE = ".mosesaic/machine-capabilities.json"

_DEFAULTS: dict[str, bool] = {
    "git.read":       True,
    "git.write":      False,
    "shell":          True,
    "web_search":     True,
    "deploy.kubectl": False,
    "deploy.helm":    False,
    "deploy.docker":  False,
}


class MachineCapabilities:
    """Reads per-environment tool availability config.

    Conservative defaults apply when the config file is absent.

    Args:
        project_root: Root directory to look for .mosesaic/machine-capabilities.json.
    """

    def __init__(self, project_root: str | Path) -> None:
        self._root = Path(project_root).resolve()
        self._caps: dict[str, bool] = dict(_DEFAULTS)
        cap_file = self._root / _CAPABILITIES_FILE
        if cap_file.exists():
            data = json.loads(cap_file.read_text(encoding="utf-8"))
            self._caps.update(data)

    def is_allowed(self, capability: str) -> bool:
        """Return True if the capability is enabled in this environment.

        Unknown capabilities return False (fail-closed).
        """
        return self._caps.get(capability, False)

    def available(self) -> list[str]:
        """Return the list of capability names that are enabled (value=True)."""
        return [k for k, v in self._caps.items() if v]

    @classmethod
    def create(cls, project_root: str | Path, **overrides: bool) -> "MachineCapabilities":
        """Factory for tests and programmatic construction — bypasses file I/O.

        Args:
            project_root: Project root (used for _root attribute only).
            **overrides:  Capability overrides applied on top of defaults.
        """
        instance = cls.__new__(cls)
        instance._root = Path(project_root).resolve()
        instance._caps = dict(_DEFAULTS)
        instance._caps.update(overrides)
        return instance
