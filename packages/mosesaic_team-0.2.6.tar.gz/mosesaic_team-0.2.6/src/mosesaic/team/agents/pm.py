from __future__ import annotations
from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.team.agents.developer import developer_agent
from mosesaic.team.agents.protocol import DeveloperTask, TeamResponse, TeamTask
from mosesaic.team.agents.task_writer import task_writer_agent


@agent(name="pm")
async def pm_agent(ctx: AgentContext) -> None:
    """PM orchestrates the sprint: task_writer → pool(developer per task)."""
    msg = await ctx.receive()
    team_task: TeamTask = msg.payload

    # Phase 1: plan — break request into SprintTasks
    writer_result: TeamResponse | None = await ctx.spawn(
        task_writer_agent, team_task, timeout=300.0
    )

    if not writer_result or not writer_result.success:
        error = writer_result.error if writer_result else "task writer returned nothing"
        await ctx.send(
            "__out__",
            TeamResponse(
                success=False,
                content=f"Sprint planning failed: {error}",
                error=error,
            ),
        )
        return

    sprint_tasks = writer_result.tasks

    # Phase 2: execute — spawn one developer per task (parallel, max 3)
    dev_payloads = [
        DeveloperTask(
            sprint_task=t,
            project_root=team_task.project_root,
            budget_manager=team_task.budget_manager,
            project_state=team_task.project_state,
        )
        for t in sprint_tasks
    ]

    dev_results: list[TeamResponse | None] = await ctx.pool(
        developer_agent, dev_payloads, concurrency=3, timeout=300.0
    )

    done = [r for r in dev_results if r and r.success]
    failed = [r for r in dev_results if not r or not r.success]

    summary_lines = [f"Sprint complete: {len(done)}/{len(sprint_tasks)} tasks done."]
    for r in done:
        summary_lines.append(f"  - {r.content}")
    for r in failed:
        err = r.error if r else "no response"
        summary_lines.append(f"  - FAILED: {err}")

    await ctx.send(
        "__out__",
        TeamResponse(
            success=len(failed) == 0,
            content="\n".join(summary_lines),
            tasks=sprint_tasks,
        ),
    )
