from __future__ import annotations
import json
from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.llm.provider import LLMMessage
from mosesaic.team.budget.tiers import TaskTier
from mosesaic.team.agents.protocol import TeamTask, TeamResponse
from mosesaic.team.project.task import SprintTask

_ASSIGNED_TO_DEVELOPER = "developer"

_SYSTEM_PROMPT = """\
You are a technical Task Writer for a software development team.
Given a feature request, break it into concrete development tasks.
Each task should be achievable by one developer in a focused coding session.

Output ONLY a JSON array — no markdown, no explanation. Each element has:
- "title": short imperative title (≤10 words)
- "description": what to build and exactly how (2-4 sentences, specific enough to implement)
- "tier": "simple" | "medium" | "complex"

Example output:
[
  {"title": "Add JWT middleware", "description": "Create middleware/auth.py that validates Bearer tokens using PyJWT. Raise 401 for missing or invalid tokens. Register on all /api/* routes.", "tier": "medium"},
  {"title": "Write auth unit tests", "description": "Add tests/test_auth.py with pytest fixtures. Test valid token, expired token, missing header.", "tier": "simple"}
]
"""


def _extract_json(text: str) -> str:
    """Strip markdown code fences if the model wrapped the JSON."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        return "\n".join(lines).strip()
    return text


@agent(name="task_writer")
async def task_writer_agent(ctx: AgentContext) -> None:
    msg = await ctx.receive()
    task: TeamTask = msg.payload

    model_id, provider = task.budget_manager.select_model(TaskTier.SIMPLE)
    messages = [
        LLMMessage(role="system", content=_SYSTEM_PROMPT),
        LLMMessage(
            role="user",
            content=f"Feature request: {task.request}"
            + (f"\n\nContext: {task.context}" if task.context else ""),
        ),
    ]

    try:
        response = await provider.chat(model=model_id, messages=messages, max_tokens=2048)
        task.budget_manager.record_spend(response.cost_usd, provider=provider.name)
        task.project_state.record_spend(response.cost_usd)

        tasks_data = json.loads(_extract_json(response.content))
        tasks = [
            SprintTask(
                title=t["title"],
                description=t["description"],
                tier=t["tier"],
                assigned_to=_ASSIGNED_TO_DEVELOPER,
            )
            for t in tasks_data
        ]
        for t in tasks:
            task.project_state.add_task(t)

        await ctx.send(
            "__out__",
            TeamResponse(success=True, content=response.content, tasks=tasks),
        )
    except Exception as exc:
        await ctx.send(
            "__out__",
            TeamResponse(success=False, content="", error=str(exc)),
        )
