from __future__ import annotations
import json
from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.llm.provider import LLMMessage
from mosesaic.team.budget.tiers import TaskTier
from mosesaic.team.agents.protocol import DeveloperTask, TeamResponse
from mosesaic.team.project.task import TaskStatus
from mosesaic.team.tools.fs import FileSystemTools

_SYSTEM_PROMPT = """\
You are a software developer implementing a specific task.
Output ONLY a JSON object — no markdown, no explanation outside the JSON.

The JSON must have:
- "files": array of {"path": "relative/path/to/file.ext", "content": "full file content"}
- "explanation": 1-2 sentences describing what you implemented

All file paths are relative to the project root.
Write complete, working code — no placeholders.

Example:
{
  "files": [
    {"path": "src/auth.py", "content": "import jwt\n\ndef verify_token(token: str) -> dict:\n    ..."}
  ],
  "explanation": "Implemented JWT token verification with PyJWT."
}
"""


def _extract_json(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        return "\n".join(lines).strip()
    return text


@agent(name="developer")
async def developer_agent(ctx: AgentContext) -> None:
    msg = await ctx.receive()
    dev_task: DeveloperTask = msg.payload
    sprint_task = dev_task.sprint_task

    model_id, provider = dev_task.budget_manager.select_model(TaskTier.MEDIUM)
    messages = [
        LLMMessage(role="system", content=_SYSTEM_PROMPT),
        LLMMessage(
            role="user",
            content=(
                f"Task: {sprint_task.title}\n\n"
                f"Description: {sprint_task.description}\n\n"
                f"Tier: {sprint_task.tier}"
            ),
        ),
    ]

    try:
        response = await provider.chat(model=model_id, messages=messages, max_tokens=4096)
        dev_task.budget_manager.record_spend(response.cost_usd, provider=provider.name)
        dev_task.project_state.record_spend(response.cost_usd)

        data = json.loads(_extract_json(response.content))
        fs = FileSystemTools(project_root=dev_task.project_root)
        for f in data["files"]:
            fs.write_file(f["path"], f["content"])

        sprint_task.status = TaskStatus.DONE
        sprint_task.result = data.get("explanation", "")
        try:
            dev_task.project_state.update_task(sprint_task)
        except KeyError:
            pass  # task not in state (e.g. created inline by PM without adding first)

        await ctx.send(
            "__out__",
            TeamResponse(
                success=True,
                content=data.get("explanation", ""),
            ),
        )
    except Exception as exc:
        sprint_task.status = TaskStatus.FAILED
        sprint_task.result = str(exc)
        try:
            dev_task.project_state.update_task(sprint_task)
        except KeyError:
            pass
        await ctx.send(
            "__out__",
            TeamResponse(success=False, content="", error=str(exc)),
        )
