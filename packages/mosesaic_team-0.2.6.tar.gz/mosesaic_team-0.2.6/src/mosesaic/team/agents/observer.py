"""Observer specialist agent — describes monitoring setup for a deployment."""
from __future__ import annotations

import json
from dataclasses import dataclass

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.team.charters.charter_loader import load_charter
from mosesaic.team.prompt.spawn_context import SpawnContext


@dataclass
class ObserverInput:
    """Input for the observer specialist."""
    goal: str
    deployment_state: str
    spawn_context: SpawnContext | None = None


@dataclass
class ObserverOutput:
    """Output from the observer specialist."""
    summary: str
    cost_usd: float = 0.0


def _strip_fences(content: str) -> str:
    if content.startswith("```"):
        lines = content.splitlines()
        return "\n".join(line for line in lines if not line.startswith("```")).strip()
    return content


@agent(
    name="observer_agent",
    system_prompt=load_charter("observer"),
    supervisor=SupervisorPolicy(budget_usd=0.05, on_failure="stop"),
    governance_tier=1,
)
async def observer_agent(ctx: AgentContext) -> None:
    """Describes monitoring and observability setup for a deployed change."""
    msg = await ctx.receive()
    payload: ObserverInput = msg.payload

    if payload.spawn_context:
        user_message = payload.spawn_context.to_prompt() + "\n\nRespond with JSON only."
    else:
        user_message = (
            f"Goal: {payload.goal}\n\n"
            f"Deployment state: {payload.deployment_state}\n\n"
            "Respond with JSON only."
        )

    response = await ctx.llm.chat([{"role": "user", "content": user_message}])
    data = json.loads(_strip_fences(response.content.strip()))

    await ctx.send(msg.from_agent, ObserverOutput(
        summary=data.get("summary", ""),
        cost_usd=ctx.cost.spent_usd,
    ))
