from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from mosesaic.team.budget.manager import BudgetManager
from mosesaic.team.project.state import ProjectState
from mosesaic.team.project.task import SprintTask


@dataclass
class TeamTask:
    """Payload PM sends to the full team (task_writer receives this)."""
    request: str                    # feature/goal description from the developer
    project_root: Path              # absolute path to the developer's project
    budget_manager: BudgetManager
    project_state: ProjectState
    context: str = ""               # optional extra context (existing code, constraints)


@dataclass
class DeveloperTask:
    """Payload PM sends to each developer agent — one per SprintTask."""
    sprint_task: SprintTask
    project_root: Path
    budget_manager: BudgetManager
    project_state: ProjectState


@dataclass
class TeamResponse:
    """Response returned by any team agent."""
    success: bool
    content: str                            # agent's output / explanation
    tasks: list[SprintTask] = field(default_factory=list)   # tasks produced (task_writer)
    error: str = ""
