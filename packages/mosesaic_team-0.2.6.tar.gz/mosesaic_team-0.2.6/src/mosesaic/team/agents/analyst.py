"""Analyst specialist agent — extracts requirements from a goal description."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.team.charters.charter_loader import load_charter
from mosesaic.team.prompt.spawn_context import SpawnContext


@dataclass
class AnalystInput:
    """Input for the analyst specialist."""
    goal: str
    constraints: list[str] = field(default_factory=list)
    spawn_context: SpawnContext | None = None


@dataclass
class AnalystOutput:
    """Output from the analyst specialist."""
    acceptance_criteria: list[str]
    constraints: list[str]
    summary: str
    cost_usd: float = 0.0


def _strip_fences(content: str) -> str:
    if content.startswith("```"):
        lines = content.splitlines()
        return "\n".join(line for line in lines if not line.startswith("```")).strip()
    return content


@agent(
    name="analyst",
    system_prompt=load_charter("analyst"),
    supervisor=SupervisorPolicy(budget_usd=0.05, on_failure="stop"),
    governance_tier=1,
)
async def analyst(ctx: AgentContext) -> None:
    """Extracts acceptance criteria and constraints from a goal description."""
    msg = await ctx.receive()
    payload: AnalystInput = msg.payload

    if payload.spawn_context:
        user_message = payload.spawn_context.to_prompt() + "\n\nRespond with JSON only."
    else:
        user_message = (
            f"Goal: {payload.goal}\n\n"
            f"Constraints: {payload.constraints or 'None'}\n\n"
            "Respond with JSON only."
        )

    response = await ctx.llm.chat([{"role": "user", "content": user_message}])
    data = json.loads(_strip_fences(response.content.strip()))

    await ctx.send(msg.from_agent, AnalystOutput(
        acceptance_criteria=data.get("acceptance_criteria", []),
        constraints=data.get("constraints", []),
        summary=data.get("summary", ""),
        cost_usd=ctx.cost.spent_usd,
    ))
