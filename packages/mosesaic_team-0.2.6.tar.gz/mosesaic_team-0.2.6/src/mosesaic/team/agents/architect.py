"""Architect specialist agent — designs technical solutions."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.team.charters.charter_loader import load_charter
from mosesaic.team.prompt.spawn_context import SpawnContext


@dataclass
class ArchitectInput:
    """Input for the architect specialist."""
    goal: str
    acceptance_criteria: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    spawn_context: SpawnContext | None = None


@dataclass
class ArchitectOutput:
    """Output from the architect specialist."""
    adr: str
    design_spec: str
    summary: str
    cost_usd: float = 0.0


def _strip_fences(content: str) -> str:
    if content.startswith("```"):
        lines = content.splitlines()
        return "\n".join(line for line in lines if not line.startswith("```")).strip()
    return content


@agent(
    name="architect_agent",
    system_prompt=load_charter("architect_specialist"),
    supervisor=SupervisorPolicy(budget_usd=0.10, on_failure="stop"),
    governance_tier=1,
)
async def architect_agent(ctx: AgentContext) -> None:
    """Designs ADR and design specification for a clarified goal."""
    msg = await ctx.receive()
    payload: ArchitectInput = msg.payload

    if payload.spawn_context:
        user_message = payload.spawn_context.to_prompt() + "\n\nRespond with JSON only."
    else:
        user_message = (
            f"Goal: {payload.goal}\n\n"
            f"Acceptance criteria:\n{payload.acceptance_criteria or 'Not provided'}\n\n"
            f"Constraints:\n{payload.constraints or 'None'}\n\n"
            "Respond with JSON only."
        )

    response = await ctx.llm.chat([{"role": "user", "content": user_message}])
    data = json.loads(_strip_fences(response.content.strip()))

    await ctx.send(msg.from_agent, ArchitectOutput(
        adr=data.get("adr", ""),
        design_spec=data.get("design_spec", ""),
        summary=data.get("summary", ""),
        cost_usd=ctx.cost.spent_usd,
    ))
