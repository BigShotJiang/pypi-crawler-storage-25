"""Loads role charter .md files as system prompt strings.

Charter files are hash-verified at load time to detect tampering (Directive
Drift protection). KNOWN_HASHES is committed to source control and updated
whenever a charter is legitimately changed.
"""
from __future__ import annotations
import hashlib
from pathlib import Path

_CHARTER_DIR = Path(__file__).parent
_KNOWN_ROLES = {
    "developer", "qa", "scribe", "chief_director",
    "clarify", "architect", "build", "verify", "deploy", "monitor",
    "analyst", "architect_specialist", "devops", "observer",
}

# SHA-256 hashes of each charter file (content stripped of leading/trailing whitespace).
# Regenerate with: python3 -c "
#   import hashlib; from pathlib import Path
#   d = Path('python/mosesaic-team/src/mosesaic/team/charters')
#   [print(f'    \"{f.stem}\": \"{hashlib.sha256(f.read_text().strip().encode()).hexdigest()}\",')
#    for f in sorted(d.glob('*.md'))]"
KNOWN_HASHES: dict[str, str] = {
    "analyst": "96a7aed2a8780c0c30336baf9478dc8028587787fffa20254f43a0a04fa68941",
    "architect": "a8937fbb84afee4446299f795396d584c2bbf26145fd116dd86d9c3e656fee62",
    "architect_specialist": "d1a365faa89636da81940f91ae7214e8b3f38c9dbbb94a3a6e8e658f869f09fe",
    "build": "02f03e7387bb8970b3a7d8878428f4f5ae1766ba45fab393d55b30f538916b8f",
    "chief_director": "a11c9faccc7204efbbf7b0b785f32155233737acf935d325fc979b45c97f4346",
    "clarify": "5a6d54353db134f6ecc2f1b45cdc988cff73493348075e0c2e21a035d1cc0902",
    "deploy": "572fc92433c65862053fb3a3a619ada95d1e85ffe29f5d07a2d4c17dc4c6c5b7",
    "developer": "288f695ac4fc376e23246de4ce76f3af715a74502d70b979997e9314f8706394",
    "devops": "c489bccec09d414c1a979dbc1166e5450ec5ec87fcd7280d72bbd868bf1e6cc5",
    "monitor": "2f7496441875b3b01ff4c1681cad332c7e92b89bb8f47f55d6fb852438234075",
    "observer": "929e1fdcbdf1fd261d1885799e969abc5575825dac88958539991f80203bd797",
    "qa": "af3d858dd6bf7e686c269605685664e11d42994e44db0a95d9397f320eec24ae",
    "scribe": "a0a26d8f881d585e0c102c8b7153cf2260f13659d5ddee646b0141b39dade1dd",
    "verify": "ed3e1cac69f2a8a73a86e19fde8a1b0aec02672745d3b7188dda67675e3567e3",
}


def _compute_hash(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def load_charter(role: str) -> str:
    """Return the charter content for the given role, with hash verification.

    Args:
        role: One of the known roles (developer, qa, scribe, chief_director,
              clarify, architect, build, verify, deploy, monitor).

    Raises:
        ValueError: If the role is not known.
        RuntimeError: If the charter file's content does not match its known hash.
    """
    if role not in _KNOWN_ROLES:
        raise ValueError(
            f"Charter for unknown role {role!r}. "
            f"Available roles: {sorted(_KNOWN_ROLES)}"
        )
    content = (_CHARTER_DIR / f"{role}.md").read_text(encoding="utf-8").strip()
    expected = KNOWN_HASHES.get(role)
    if expected is not None:
        actual = _compute_hash(content)
        if actual != expected:
            raise RuntimeError(
                f"Charter for {role!r} has been tampered with. "
                f"Expected hash {expected[:12]}..., got {actual[:12]}..."
            )
    return content
