"""mosesaic.team.serve — server startup logic for `mosesaic serve`.

Owns all startup behaviour:
  - Build runtimes from config
  - Start uvicorn in a background anyio thread
  - Optionally run MCP stdio in foreground (--with-mcp)
  - Graceful degradation when mosesaic.toml is missing

Called by: python/mosesaic-cli/src/mosesaic/cli/main.py (lazy import)
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import anyio

# ── TOML template written when no config exists ───────────────────────────────

_TEMPLATE = """\
# mosesaic.toml — project configuration
# https://github.com/you/mosesaic

[server]
host = "127.0.0.1"
port = 8000

# Enable providers by uncommenting and setting api_key,
# or set the corresponding environment variable instead.

# [[provider]]
# name = "anthropic"
# api_key = "sk-ant-..."   # or: export ANTHROPIC_API_KEY=...

# [[provider]]
# name = "groq"            # free tier
# api_key = "gsk-..."      # or: export GROQ_API_KEY=...

# [[provider]]
# name = "gemini"          # free tier
# api_key = "AIza..."      # or: export GEMINI_API_KEY=...

# [[provider]]
# name = "openrouter"      # free tier available
# api_key = "sk-or-..."    # or: export OPENROUTER_API_KEY=...

# [[provider]]
# name = "cerebras"        # free tier
# api_key = "csk-..."      # or: export CEREBRAS_API_KEY=...

# [[provider]]
# name = "ollama"          # local, no API key needed
# base_url = "http://localhost:11434"

# Per-director model overrides (optional).
# Directors without an entry use registry auto-routing.
# [director.chief]
# provider = "anthropic"
# model = "claude-opus-4-6"
"""


def _write_template() -> None:
    """Write mosesaic.toml template to cwd if it doesn't already exist."""
    dest = Path("mosesaic.toml")
    if dest.exists():
        return
    dest.write_text(_TEMPLATE)


def _handle_no_config(*, with_mcp: bool, host: str | None, port: int | None) -> None:
    """Handle the case where load_config() raised RuntimeError (no config found).

    MCP mode: auto-write template, print to stderr, exit 1.
    Terminal mode: prompt user; if yes, run `mosesaic init --interactive` then retry serve.
    """
    if with_mcp:
        _write_template()
        print(
            "No providers configured. Edit mosesaic.toml and restart.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Non-interactive (background process / no TTY) — print and exit immediately
    if not sys.stdin.isatty():
        print(
            "No providers configured. Set an API key env var (e.g. ANTHROPIC_API_KEY) "
            "or run `mosesaic init` to create mosesaic.toml, then `mosesaic serve`.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Terminal mode — interactive prompt
    try:
        answer = input("No mosesaic.toml found. Run mosesaic init now? [Y/n]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        answer = "n"

    if answer in ("", "y", "yes"):
        result = subprocess.run(["mosesaic", "init", "--interactive"])
        if result.returncode == 0:
            main(host=host, port=port, with_mcp=False)
        else:
            print("Init failed. Run `mosesaic init` manually, then `mosesaic serve`.")
    else:
        print("Run `mosesaic init` to create a config file, then `mosesaic serve`.")


def _build_runtimes(config):
    """Build AgentRuntime + WorkflowRuntime from a loaded ServerConfig, return FastAPI app."""
    from mosesaic.core.runtime import AgentRuntime
    from mosesaic.workflow.runtime import WorkflowRuntime
    from mosesaic.server.app import create_app
    from mosesaic.team.orchestrator.director import chief_director
    from mosesaic.team.orchestrator.directors import (
        clarify_director,
        architect_director,
        build_director,
        verify_director,
        deploy_director,
        monitor_director,
    )
    from mosesaic.team.orchestrator.workflow import orchestrate_workflow

    agent_rt = AgentRuntime(
        llm=config.registry,
        llm_overrides=config.director_overrides,
    )
    wf_rt = WorkflowRuntime(llm=config.registry, llm_overrides=config.director_overrides)

    for director in [
        chief_director,
        clarify_director,
        architect_director,
        build_director,
        verify_director,
        deploy_director,
        monitor_director,
    ]:
        agent_rt.register(director)
        wf_rt.register_agent(director)

    wf_rt.register_workflow(orchestrate_workflow)

    return create_app(agent_rt, wf_rt)


def _make_uvicorn_server(config, host: str | None, port: int | None):
    """Build and return a configured uvicorn.Server (does not start it)."""
    import uvicorn

    app = _build_runtimes(config)
    cfg = uvicorn.Config(
        app,
        host=host or config.host,
        port=port or config.port,
        log_level="warning",
    )
    return uvicorn.Server(cfg)


async def _run_mcp() -> None:
    """Run the MCP stdio server in a background thread (blocks until disconnect)."""
    from mosesaic.mcp_server._server import mcp
    await anyio.to_thread.run_sync(lambda: mcp.run(transport="stdio"))


async def _serve_with_mcp(config, host: str | None, port: int | None) -> None:
    """Start uvicorn in background, run MCP stdio in foreground.

    When MCP disconnects, signals uvicorn to shut down gracefully before
    cancelling the task group scope.
    """
    server = _make_uvicorn_server(config, host, port)
    async with anyio.create_task_group() as tg:
        # server.run() is synchronous (starts its own asyncio loop) — run in thread
        tg.start_soon(anyio.to_thread.run_sync, server.run)
        await _run_mcp()           # blocks until Claude Code disconnects
        server.should_exit = True  # signal uvicorn to stop gracefully
        tg.cancel_scope.cancel()   # cancel scope; thread finishes imminently


async def _serve_rest(config, host: str | None, port: int | None) -> None:
    """Run REST server only (terminal mode)."""
    server = _make_uvicorn_server(config, host, port)
    await anyio.to_thread.run_sync(server.run)


def main(host: str | None, port: int | None, with_mcp: bool) -> None:
    """Entry point called by the `mosesaic serve` CLI command."""
    try:
        from mosesaic.server.config import load_config
        config = load_config()
    except RuntimeError:
        _handle_no_config(with_mcp=with_mcp, host=host, port=port)
        return

    if with_mcp:
        anyio.run(_serve_with_mcp, config, host, port)
    else:
        anyio.run(_serve_rest, config, host, port)
