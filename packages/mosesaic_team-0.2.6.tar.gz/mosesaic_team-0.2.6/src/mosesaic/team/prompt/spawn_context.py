"""SpawnContext — rich task-specific context assembled by a director before spawning.

Directors build a SpawnContext from ProjectContext and pass it as the
optional `spawn_context` field on a specialist's Input dataclass. The
specialist calls to_prompt() to build its structured user-turn message.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SpawnContext:
    """Task-specific context assembled by a director before spawning a specialist.

    Args:
        role:                 Which specialist is being spawned (e.g. "analyst").
        task_description:     What specifically to do for this task.
        in_scope:             Explicit list of what to do.
        out_of_scope:         Explicit list of what NOT to do.
        checklist:            Ordered steps the specialist must complete.
        acceptance_criteria:  How to know the task is done.
        constraints:          Hard constraints to respect.
    """
    role: str
    task_description: str
    in_scope: list[str] = field(default_factory=list)
    out_of_scope: list[str] = field(default_factory=list)
    checklist: list[str] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)

    def to_prompt(self) -> str:
        """Render as a structured markdown user-turn message."""
        parts: list[str] = []

        parts.append(f"## Your Task\n{self.task_description}")

        if self.in_scope or self.out_of_scope:
            scope_lines: list[str] = ["## Scope"]
            if self.in_scope:
                scope_lines.append("**In scope:**")
                scope_lines.extend(f"- {item}" for item in self.in_scope)
            if self.out_of_scope:
                scope_lines.append("**Out of scope:**")
                scope_lines.extend(f"- {item}" for item in self.out_of_scope)
            parts.append("\n".join(scope_lines))

        if self.checklist:
            checklist_lines: list[str] = ["## Checklist"]
            checklist_lines.extend(f"- [ ] {item}" for item in self.checklist)
            parts.append("\n".join(checklist_lines))

        if self.acceptance_criteria:
            ac_lines: list[str] = ["## Acceptance Criteria"]
            ac_lines.extend(f"- {item}" for item in self.acceptance_criteria)
            parts.append("\n".join(ac_lines))

        if self.constraints:
            c_lines: list[str] = ["## Constraints"]
            c_lines.extend(f"- {item}" for item in self.constraints)
            parts.append("\n".join(c_lines))

        return "\n\n".join(parts)
