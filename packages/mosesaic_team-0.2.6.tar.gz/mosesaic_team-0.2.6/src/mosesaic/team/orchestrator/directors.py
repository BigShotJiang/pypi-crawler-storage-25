"""Phase director agents — one per lifecycle phase.

Directors are orchestration agents: they spawn domain specialist sub-agents
via ctx.spawn(), aggregate results, update ProjectContext, and return PhaseOutput.
"""
from __future__ import annotations

import json

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.team.charters.charter_loader import load_charter
from mosesaic.team.orchestrator.protocol import PhaseInput, PhaseOutput
from mosesaic.team.agents.analyst import analyst, AnalystInput
from mosesaic.team.agents.architect import architect_agent, ArchitectInput
from mosesaic.team.agents.devops import devops_agent, DevopsInput
from mosesaic.team.agents.observer import observer_agent, ObserverInput
from mosesaic.team.prompt.spawn_context import SpawnContext
from mosesaic.team.tools.fs import FileSystemTools
from mosesaic.team.tools.shell import ShellTools


@agent(
    name="clarify_director",
    system_prompt=load_charter("clarify"),
    supervisor=SupervisorPolicy(budget_usd=0.05, on_failure="stop"),
    governance_tier=1,
)
async def clarify_director(ctx: AgentContext) -> None:
    """Spawns the analyst specialist to extract requirements from the goal."""
    msg = await ctx.receive()
    payload: PhaseInput = msg.payload
    project_ctx = payload.context

    spawn_ctx = SpawnContext(
        role="analyst",
        task_description=(
            f"Extract precise, testable requirements from the following goal:\n\n"
            f"{project_ctx.goal}"
        ),
        in_scope=[
            "Testable acceptance criteria that define 'done'",
            "Hard constraints (technical, business, compliance, time)",
            "Ambiguities that must be resolved before building",
            "Non-functional requirements (performance, security, reliability)",
        ],
        out_of_scope=[
            "Solution design or technology selection",
            "Implementation details",
            "Any requirement not present in or clearly implied by the goal",
        ],
        checklist=[
            "Read the goal carefully and identify what success looks like",
            "Write each acceptance criterion as an independently testable condition",
            "Identify all hard constraints that cannot be changed",
            "Flag any ambiguities explicitly rather than silently resolving them",
            "Identify unhappy paths: what happens on invalid input or dependency failure?",
            "Produce a one-sentence summary of what was clarified",
        ],
        acceptance_criteria=project_ctx.acceptance_criteria or [],
        constraints=project_ctx.constraints or [],
    )

    result = await ctx.spawn(analyst, AnalystInput(
        goal=project_ctx.goal,
        constraints=project_ctx.constraints,
        spawn_context=spawn_ctx,
    ))

    project_ctx.acceptance_criteria = result.acceptance_criteria
    project_ctx.constraints = result.constraints
    project_ctx.phase_history.append("clarify")

    await ctx.send(msg.from_agent, PhaseOutput(
        phase="clarify",
        summary=result.summary,
        context=project_ctx,
        cost_usd=result.cost_usd,
    ))


@agent(
    name="architect_director",
    system_prompt=load_charter("architect"),
    supervisor=SupervisorPolicy(budget_usd=0.10, on_failure="stop"),
    governance_tier=1,
)
async def architect_director(ctx: AgentContext) -> None:
    """Spawns the architect specialist to produce ADR and design spec."""
    msg = await ctx.receive()
    payload: PhaseInput = msg.payload
    project_ctx = payload.context

    spawn_ctx = SpawnContext(
        role="architect_agent",
        task_description=(
            f"Design the technical solution for the following goal:\n\n"
            f"{project_ctx.goal}"
        ),
        in_scope=[
            "Architecture Decision Record (ADR) with alternatives considered",
            "Design specification naming every file and its single responsibility",
            "Interface definitions between components",
            "Security and failure mode analysis",
        ],
        out_of_scope=[
            "Writing code or tests",
            "Requirements clarification (already done)",
            "Anything not required by the acceptance criteria (YAGNI)",
        ],
        checklist=[
            "Identify at least two alternative architectural approaches",
            "Choose the simplest approach that satisfies all acceptance criteria",
            "Document why the alternatives were rejected",
            "Map each design component to an acceptance criterion",
            "Address security at trust boundaries — do not defer to implementation",
            "Describe how each component fails gracefully",
            "Name every file to create or modify with its single responsibility",
            "Produce a one-sentence summary of the architectural approach",
        ],
        acceptance_criteria=project_ctx.acceptance_criteria or [],
        constraints=project_ctx.constraints or [],
    )

    result = await ctx.spawn(architect_agent, ArchitectInput(
        goal=project_ctx.goal,
        acceptance_criteria=project_ctx.acceptance_criteria,
        constraints=project_ctx.constraints,
        spawn_context=spawn_ctx,
    ))

    project_ctx.adr = result.adr
    project_ctx.design_spec = result.design_spec
    project_ctx.phase_history.append("architect")

    await ctx.send(msg.from_agent, PhaseOutput(
        phase="architect",
        summary=result.summary,
        context=project_ctx,
        cost_usd=result.cost_usd,
    ))


@agent(
    name="deploy_director",
    system_prompt=load_charter("deploy"),
    supervisor=SupervisorPolicy(budget_usd=0.10, on_failure="stop"),
    governance_tier=3,
)
async def deploy_director(ctx: AgentContext) -> None:
    """Spawns the devops specialist to assess deployment readiness."""
    msg = await ctx.receive()
    payload: PhaseInput = msg.payload
    project_ctx = payload.context

    spawn_ctx = SpawnContext(
        role="devops_agent",
        task_description=(
            f"Assess deployment readiness for the following change:\n\n"
            f"Goal: {project_ctx.goal}\n"
            f"Files changed: {project_ctx.files_changed or 'None'}"
        ),
        in_scope=[
            "Deployment state determination: pending, staging, or production",
            "Identification of deployment blockers",
            "Rollback plan assessment",
            "Health check requirements",
        ],
        out_of_scope=[
            "Writing infrastructure code",
            "Re-running QA or re-verifying the build",
            "Changing the implementation",
        ],
        checklist=[
            "Check QA findings for unresolved blockers",
            "Assess whether rollback plan is documented",
            "Verify health check endpoints are defined",
            "Check for hardcoded secrets in changed files",
            "Determine appropriate deployment state: pending / staging / production",
            "Produce a one-sentence summary of the deployment assessment",
        ],
        acceptance_criteria=project_ctx.acceptance_criteria or [],
        constraints=project_ctx.constraints or [],
    )

    result = await ctx.spawn(devops_agent, DevopsInput(
        goal=project_ctx.goal,
        files_changed=project_ctx.files_changed,
        qa_findings=project_ctx.qa_findings,
        spawn_context=spawn_ctx,
    ))

    project_ctx.deployment_state = result.deployment_state
    project_ctx.phase_history.append("deploy")

    await ctx.send(msg.from_agent, PhaseOutput(
        phase="deploy",
        summary=result.summary,
        context=project_ctx,
        cost_usd=result.cost_usd,
    ))


@agent(
    name="monitor_director",
    system_prompt=load_charter("monitor"),
    supervisor=SupervisorPolicy(budget_usd=0.05, on_failure="stop"),
    governance_tier=1,
)
async def monitor_director(ctx: AgentContext) -> None:
    """Spawns the observer specialist to describe the monitoring setup."""
    msg = await ctx.receive()
    payload: PhaseInput = msg.payload
    project_ctx = payload.context

    spawn_ctx = SpawnContext(
        role="observer_agent",
        task_description=(
            f"Design the monitoring and observability setup for the following deployed change:\n\n"
            f"Goal: {project_ctx.goal}\n"
            f"Deployment state: {project_ctx.deployment_state}"
        ),
        in_scope=[
            "Key metrics to track (latency, traffic, errors, saturation)",
            "Alert thresholds with response procedures",
            "Log patterns that distinguish healthy from degraded operation",
            "Trace instrumentation requirements",
        ],
        out_of_scope=[
            "Implementing dashboards or configuring alert tools",
            "Changing the deployment or infrastructure",
            "Re-verifying the build",
        ],
        checklist=[
            "Address all four golden signals: latency, traffic, errors, saturation",
            "Define 'healthy' in measurable terms for each signal",
            "Specify alert thresholds based on expected baselines",
            "Assign a response procedure to every alert",
            "Specify structured log fields and patterns to watch",
            "Identify distributed trace instrumentation requirements",
            "Produce a one-sentence summary of the monitoring setup",
        ],
        acceptance_criteria=project_ctx.acceptance_criteria or [],
        constraints=project_ctx.constraints or [],
    )

    result = await ctx.spawn(observer_agent, ObserverInput(
        goal=project_ctx.goal,
        deployment_state=project_ctx.deployment_state,
        spawn_context=spawn_ctx,
    ))

    project_ctx.phase_history.append("monitor")

    await ctx.send(msg.from_agent, PhaseOutput(
        phase="monitor",
        summary=result.summary,
        context=project_ctx,
        cost_usd=result.cost_usd,
    ))


# ── Real directors (LLM-based) ─────────────────────────────────────────────


def _strip_fences(content: str) -> str:
    """Remove markdown code fences from LLM output."""
    if content.startswith("```"):
        lines = content.splitlines()
        return "\n".join(
            line for line in lines
            if not line.startswith("```")
        ).strip()
    return content


@agent(
    name="build_director",
    system_prompt=load_charter("build"),
    supervisor=SupervisorPolicy(budget_usd=0.20, on_failure="stop"),
    governance_tier=1,
)
async def build_director(ctx: AgentContext) -> None:
    """LLM-based: plans files, generates content, and writes them to disk."""
    msg = await ctx.receive()
    payload: PhaseInput = msg.payload
    project_ctx = payload.context

    goal = project_ctx.goal
    adr = project_ctx.adr
    design_spec = project_ctx.design_spec
    acceptance_criteria = project_ctx.acceptance_criteria

    # Step 1: Plan — ask LLM for a structured file plan
    plan_message = (
        f"Goal: {goal}\n\n"
        f"Architecture Decision Record:\n{adr or 'Not provided'}\n\n"
        f"Design Spec:\n{design_spec or 'Not provided'}\n\n"
        f"Acceptance Criteria:\n{acceptance_criteria}\n\n"
        "Respond with JSON only:\n"
        '{\n'
        '  "files": [\n'
        '    {"path": "relative/path/to/file.ext", "purpose": "one sentence"}\n'
        '  ],\n'
        '  "summary": "one sentence describing the build plan"\n'
        '}'
    )

    plan_response = await ctx.llm.chat(
        [{"role": "user", "content": plan_message}],
        task_hint="reasoning",
        max_tokens=2000,
    )
    plan_data = json.loads(_strip_fences(plan_response.content.strip()))
    file_list = plan_data.get("files", [])
    build_summary = plan_data.get("summary", "")

    # Step 2: Implement each file and write to disk
    fs = FileSystemTools(project_root=project_ctx.project_root)
    files_written: list[str] = []

    for file_info in file_list:
        file_path = file_info.get("path", "")
        file_purpose = file_info.get("purpose", "")
        if not file_path:
            continue

        impl_message = (
            "Implement this file completely. Return ONLY the raw file content — "
            "no JSON wrapper, no markdown fences, no explanation.\n\n"
            f"File: {file_path}\n"
            f"Purpose: {file_purpose}\n\n"
            f"Project goal: {goal}\n"
            f"Design spec: {design_spec or 'Not provided'}"
        )

        impl_response = await ctx.llm.chat(
            [{"role": "user", "content": impl_message}],
            task_hint="general",
            max_tokens=4096,
        )
        content = impl_response.content.strip()

        try:
            fs.write_file(file_path, content)
            files_written.append(file_path)
        except (PermissionError, OSError):
            # Skip files that can't be written (e.g. path traversal or I/O error)
            pass

    project_ctx.files_changed = files_written
    project_ctx.file_plan = [f["path"] for f in file_list if f.get("path")]
    project_ctx.phase_history.append("build")

    written_count = len(files_written)
    preview = ", ".join(files_written[:3])
    ellipsis = "..." if written_count > 3 else ""
    summary = f"Wrote {written_count} files: {preview}{ellipsis}" if files_written else build_summary

    await ctx.send(msg.from_agent, PhaseOutput(
        phase="build",
        summary=summary,
        context=project_ctx,
        cost_usd=ctx.cost.spent_usd,
    ))


@agent(
    name="verify_director",
    system_prompt=load_charter("verify"),
    supervisor=SupervisorPolicy(budget_usd=0.20, on_failure="stop"),
    governance_tier=1,
)
async def verify_director(ctx: AgentContext) -> None:
    """LLM-based: reads written files, runs tests, and calls LLM for QA findings."""
    msg = await ctx.receive()
    payload: PhaseInput = msg.payload
    project_ctx = payload.context

    goal = project_ctx.goal
    criteria = project_ctx.acceptance_criteria

    # Step 1: Read written files from disk
    fs = FileSystemTools(project_root=project_ctx.project_root)
    file_contents_block = ""
    for file_path in project_ctx.files_changed:
        try:
            content = fs.read_file(file_path)
            file_contents_block += f"=== {file_path} ===\n{content}\n\n"
        except (FileNotFoundError, PermissionError):
            file_contents_block += f"=== {file_path} ===\n[file not found or unreadable]\n\n"

    if not file_contents_block:
        file_contents_block = "No files were written."

    # Step 2: Try to run tests
    test_output: str | None = None
    shell = ShellTools(project_root=project_ctx.project_root, default_timeout_seconds=60.0)
    test_commands = ["pytest -x -q", "npm test", "python -m pytest -x -q"]
    for cmd in test_commands:
        try:
            result = shell.run(cmd, timeout_seconds=60.0)
            # exit code 127 means command not found — try next
            if result.exit_code != 127:
                test_output = str(result)
                break
        except (TimeoutError, PermissionError, OSError, FileNotFoundError):
            continue

    # Step 3: LLM review
    review_message = (
        "You are a QA engineer reviewing the following implementation.\n\n"
        f"Goal: {goal}\n"
        f"Acceptance Criteria: {criteria}\n\n"
        "Files written:\n"
        f"{file_contents_block}\n"
        "Test results:\n"
        f"{test_output or 'No test runner detected.'}\n\n"
        "Respond with JSON only:\n"
        '{\n'
        '  "qa_findings": ["finding 1", "finding 2"],\n'
        '  "summary": "one sentence QA verdict"\n'
        '}'
    )

    response = await ctx.llm.chat(
        [{"role": "user", "content": review_message}],
        task_hint="general",
    )
    data = json.loads(_strip_fences(response.content.strip()))

    project_ctx.qa_findings = data.get("qa_findings", [])
    project_ctx.test_results = {"output": test_output or "No test runner detected."}
    project_ctx.phase_history.append("verify")

    await ctx.send(msg.from_agent, PhaseOutput(
        phase="verify",
        summary=data.get("summary", ""),
        context=project_ctx,
        cost_usd=ctx.cost.spent_usd,
    ))
