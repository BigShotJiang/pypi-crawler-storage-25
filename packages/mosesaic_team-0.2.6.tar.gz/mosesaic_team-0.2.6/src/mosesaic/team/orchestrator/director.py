"""Chief Director agent — reads a user prompt and decides which phases to run."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.team.charters.charter_loader import load_charter
from mosesaic.team.orchestrator.phases import validate_phase_sequence, default_phases_for

_VALID_REQUEST_TYPES = frozenset({"feature", "bugfix", "greenfield", "incident", "refactor"})


@dataclass
class DirectorInput:
    """Input payload for the chief_director agent."""
    prompt: str
    context_summary: str = ""   # Optional: summary of existing ProjectContext state


@dataclass
class DirectorPlan:
    """Output payload: the phases the Chief Director decided to run."""
    request_type: str
    phases: list[str]
    reasoning: str


@agent(
    name="chief_director",
    system_prompt=load_charter("chief_director"),
    supervisor=SupervisorPolicy(budget_usd=0.10, on_failure="stop"),
    governance_tier=1,
)
async def chief_director(ctx: AgentContext) -> None:
    """LLM agent that reads a prompt and produces a DirectorPlan."""
    msg = await ctx.receive()
    payload: DirectorInput = msg.payload

    user_message = (
        f"Goal: {payload.prompt}\n\n"
        f"Project context:\n{payload.context_summary}\n\n"
        "Select the phases needed and respond with valid JSON only."
    )

    response = await ctx.llm.chat(
        [{"role": "user", "content": user_message}],
        task_hint="reasoning",
    )

    # Strip markdown fences if the LLM added them
    content = response.content.strip()
    if content.startswith("```"):
        lines = content.splitlines()
        content = "\n".join(
            line for line in lines
            if not line.startswith("```")
        ).strip()

    data = json.loads(content)

    request_type = data.get("request_type", "feature")
    if request_type not in _VALID_REQUEST_TYPES:
        raise ValueError(
            f"LLM returned unknown request_type {request_type!r}. "
            f"Valid: {sorted(_VALID_REQUEST_TYPES)}"
        )

    phases: list[str] = data.get("phases", default_phases_for(request_type))
    validate_phase_sequence(phases)

    plan = DirectorPlan(
        request_type=request_type,
        phases=phases,
        reasoning=data.get("reasoning", ""),
    )

    await ctx.send(msg.from_agent, plan)
