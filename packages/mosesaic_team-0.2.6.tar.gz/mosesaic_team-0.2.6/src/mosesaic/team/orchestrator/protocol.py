"""Protocol types shared by all phase directors."""
from __future__ import annotations
from dataclasses import dataclass, field

from mosesaic.team.orchestrator.context import ProjectContext


@dataclass
class RunLogEntry:
    """One record in the run log — one entry per executed phase.

    Args:
        phase:    Phase name (e.g. 'clarify', 'build').
        summary:  One-sentence summary of what the phase accomplished.
        cost_usd: Total LLM spend for this phase in USD.
    """
    phase: str
    summary: str
    cost_usd: float


@dataclass
class PhaseInput:
    """Input delivered to every phase director agent.

    Args:
        context: The shared project context to read from.
        phase:   Name of the phase being executed (e.g. 'build').
    """
    context: ProjectContext
    phase: str


@dataclass
class PhaseOutput:
    """Output returned by every phase director agent.

    Args:
        phase:    The phase that was executed.
        summary:  One-sentence summary of what the phase accomplished.
        context:  The updated project context for the next phase.
        cost_usd: Total LLM spend for this phase in USD.
    """
    phase: str
    summary: str
    context: ProjectContext
    cost_usd: float = 0.0


@dataclass
class OrchestrateResult:
    """Final result returned by the orchestrate workflow.

    Args:
        request_type:   Classification of the original request.
        phases_run:     The phases that were executed, in order.
        context:        The final project context after all phases.
        reasoning:      The chief director's reasoning for the phase selection.
        run_log:        One entry per phase with summary and cost.
        total_cost_usd: Sum of all phase costs in USD.
    """
    request_type: str
    phases_run: list[str] = field(default_factory=list)
    context: ProjectContext = field(default_factory=lambda: ProjectContext(goal=""))
    reasoning: str = ""
    run_log: list[RunLogEntry] = field(default_factory=list)
    total_cost_usd: float = 0.0
