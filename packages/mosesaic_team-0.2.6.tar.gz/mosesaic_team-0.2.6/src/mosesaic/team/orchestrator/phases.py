"""Phase library — known phases and default sequences per request type."""
from __future__ import annotations

PHASE_NAMES: frozenset[str] = frozenset(
    {"clarify", "architect", "build", "verify", "deploy", "monitor"}
)

# Default phase sequences per request type.
# build and verify are always present. Other phases are optional.
REQUEST_TYPE_PHASES: dict[str, list[str]] = {
    "feature":    ["clarify", "architect", "build", "verify", "deploy"],
    "bugfix":     ["clarify", "build", "verify", "deploy"],
    "greenfield": ["clarify", "architect", "build", "verify", "deploy", "monitor"],
    "incident":   ["clarify", "build", "verify", "deploy"],
    "refactor":   ["clarify", "architect", "build", "verify"],
}


def validate_phase_sequence(phases: list[str]) -> None:
    """Raise ValueError if any phase name is not in PHASE_NAMES.

    Args:
        phases: List of phase names to validate.

    Raises:
        ValueError: Lists the unknown phase names.
    """
    unknown = sorted(set(phases) - PHASE_NAMES)
    if unknown:
        raise ValueError(
            f"Phase sequence contains unknown phases: {unknown}. "
            f"Valid phases: {sorted(PHASE_NAMES)}"
        )


def default_phases_for(request_type: str) -> list[str]:
    """Return the default phase sequence for a request type.

    Args:
        request_type: One of feature, bugfix, greenfield, incident, refactor.

    Raises:
        ValueError: If request_type is not recognised.
    """
    if request_type not in REQUEST_TYPE_PHASES:
        raise ValueError(
            f"Unknown request_type {request_type!r}. "
            f"Known types: {sorted(REQUEST_TYPE_PHASES)}"
        )
    return list(REQUEST_TYPE_PHASES[request_type])
