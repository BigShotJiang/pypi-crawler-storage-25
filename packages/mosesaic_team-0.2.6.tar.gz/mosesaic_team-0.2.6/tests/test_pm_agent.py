from __future__ import annotations
import json
import pytest
from pathlib import Path
from mosesaic.core.spawner import Spawner
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.team.budget.manager import BudgetManager
from mosesaic.team.project.state import ProjectState
from mosesaic.team.project.task import TaskStatus
from mosesaic.team.agents.protocol import TeamTask, TeamResponse
from mosesaic.team.agents.pm import pm_agent


def _make_registry(ollama_response: str, openai_response: str) -> ProviderRegistry:
    """Two providers: ollama (SIMPLE tier) + openai (MEDIUM tier)."""
    ollama_caps = {"free-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class OllamaMock(MockProvider):
        @property
        def name(self) -> str:
            return "ollama"

    class OpenAIMock(MockProvider):
        @property
        def name(self) -> str:
            return "openai"

    ollama = OllamaMock(responses={"free-model": ollama_response}, capabilities=ollama_caps)

    openai_caps = {"gpt-mock": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=128, cost_per_1m_input=0.15, cost_per_1m_output=0.60,
    )}
    openai_p = OpenAIMock(responses={"gpt-mock": openai_response}, capabilities=openai_caps)

    r = ProviderRegistry()
    r.register(ollama)
    r.register(openai_p)
    return r


@pytest.mark.anyio
async def test_pm_full_sprint(tmp_path):
    task_list = json.dumps([
        {"title": "Add auth", "description": "JWT middleware", "tier": "medium"},
    ])
    dev_output = json.dumps({
        "files": [{"path": "src/auth.py", "content": "def verify(): pass\n"}],
        "explanation": "Added JWT auth",
    })
    registry = _make_registry(task_list, dev_output)
    budget_mgr = BudgetManager(registry=registry, sprint_budget_usd=10.0)
    state = ProjectState(tmp_path)

    team_task = TeamTask(
        request="Build login with JWT",
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    result: TeamResponse = await spawner.spawn(pm_agent, team_task, timeout=30.0)

    assert isinstance(result, TeamResponse)
    assert result.success
    assert "sprint complete" in result.content.lower()
    assert (tmp_path / "src" / "auth.py").exists()


@pytest.mark.anyio
async def test_pm_returns_failure_when_task_writer_fails(tmp_path):
    registry = _make_registry("not valid json", "{}")
    budget_mgr = BudgetManager(registry=registry, sprint_budget_usd=10.0)
    state = ProjectState(tmp_path)

    team_task = TeamTask(
        request="Build login",
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    result: TeamResponse = await spawner.spawn(pm_agent, team_task, timeout=30.0)

    assert isinstance(result, TeamResponse)
    assert not result.success
    assert "planning failed" in result.content.lower()


@pytest.mark.anyio
async def test_pm_spawns_developer_per_task(tmp_path):
    """PM should spawn one developer per task in the task list."""
    task_list = json.dumps([
        {"title": "Task 1", "description": "File A", "tier": "medium"},
        {"title": "Task 2", "description": "File B", "tier": "medium"},
    ])
    dev_output_a = json.dumps({"files": [{"path": "a.py", "content": "x=1\n"}], "explanation": "A done"})

    registry = _make_registry(task_list, dev_output_a)
    budget_mgr = BudgetManager(registry=registry, sprint_budget_usd=10.0)
    state = ProjectState(tmp_path)

    team_task = TeamTask(
        request="Build two things",
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    result: TeamResponse = await spawner.spawn(pm_agent, team_task, timeout=30.0)

    assert result.success
    assert len(result.tasks) == 2
    saved = state.get_tasks()
    assert all(t.status == TaskStatus.DONE for t in saved)
