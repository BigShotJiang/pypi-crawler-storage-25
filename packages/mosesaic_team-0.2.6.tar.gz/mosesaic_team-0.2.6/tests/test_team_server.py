"""Smoke test: setup() returns (AgentRuntime, WorkflowRuntime) with no real providers."""
from __future__ import annotations

import importlib.util
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from mosesaic.core.runtime import AgentRuntime
from mosesaic.workflow.runtime import WorkflowRuntime


def _mock_config():
    """Build a mock ServerConfig with a single fake provider."""
    from mosesaic.llm.registry import ProviderRegistry
    from mosesaic.server.config import ServerConfig

    provider = MagicMock()
    provider.name = "mock"
    provider.models = {
        "mock-model": MagicMock(
            cost_per_1m_input=0.0,
            cost_per_1m_output=0.0,
        )
    }

    registry = ProviderRegistry()
    registry.register(provider)

    return ServerConfig(
        host="127.0.0.1",
        port=8000,
        registry=registry,
        director_overrides={"chief_director": "mock-model"},
    )


def _load_team_server():
    """Load team_server.py from the repo root."""
    team_server_path = Path(__file__).parents[3] / "team_server.py"
    assert team_server_path.exists(), f"team_server.py not found at {team_server_path}"
    spec = importlib.util.spec_from_file_location("team_server", team_server_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_setup_returns_runtimes():
    """setup() returns (AgentRuntime, WorkflowRuntime) with directors registered."""
    with patch("mosesaic.server.config.load_config", return_value=_mock_config()):
        mod = _load_team_server()
        agent_rt, wf_rt = mod.setup()

    assert isinstance(agent_rt, AgentRuntime)
    assert isinstance(wf_rt, WorkflowRuntime)
    # All 7 directors must be registered
    for name in [
        "chief_director", "clarify_director", "architect_director",
        "build_director", "verify_director", "deploy_director", "monitor_director",
    ]:
        assert name in agent_rt._definitions, f"Missing director: {name}"


def test_setup_registers_orchestrate_workflow():
    """setup() registers orchestrate_workflow with the WorkflowRuntime."""
    with patch("mosesaic.server.config.load_config", return_value=_mock_config()):
        mod = _load_team_server()
        _, wf_rt = mod.setup()

    assert "orchestrate" in wf_rt._workflows
