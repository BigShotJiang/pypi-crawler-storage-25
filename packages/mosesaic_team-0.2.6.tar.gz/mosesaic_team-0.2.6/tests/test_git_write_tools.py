from __future__ import annotations
import pytest
from mosesaic.team.tools.git import GitTools


def test_add_specific_file(git, git_repo):
    (git_repo / "new.py").write_text("y = 2\n")
    result = git.add(["new.py"])
    assert result.success
    assert "new.py" in git.status()


def test_add_all_when_paths_is_none(git, git_repo):
    (git_repo / "a.py").write_text("a = 1\n")
    (git_repo / "b.py").write_text("b = 2\n")
    result = git.add()
    assert result.success
    status = git.status()
    assert "a.py" in status
    assert "b.py" in status


def test_commit_creates_commit(git, git_repo):
    (git_repo / "file.py").write_text("x = 99\n")
    git.add(["file.py"])
    result = git.commit("update x to 99")
    assert result.success
    assert "update x to 99" in git.log(max_entries=1)


def test_commit_message_with_special_chars_does_not_inject(git, git_repo):
    """Commit message with shell metacharacters must be stored literally."""
    (git_repo / "file.py").write_text("x = 2\n")
    git.add()
    result = git.commit('fix: add "quotes" & $dollar; rm -rf /')
    assert result.success
    log = git.log(max_entries=1)
    assert "quotes" in log
    assert "rm -rf" in log  # literal, not executed


def test_push_fails_gracefully_without_remote(git):
    result = git.push("nonexistent-remote")
    assert not result.success


def test_create_pr_raises_file_not_found_when_gh_missing(git, monkeypatch):
    import shutil
    monkeypatch.setattr(shutil, "which", lambda _: None)
    with pytest.raises(FileNotFoundError, match="gh CLI not found"):
        git.create_pr("My PR", "body text")
