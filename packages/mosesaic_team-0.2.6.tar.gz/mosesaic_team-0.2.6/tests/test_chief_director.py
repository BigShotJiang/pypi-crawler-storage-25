from __future__ import annotations
import json
import pytest
from mosesaic.team.orchestrator.director import DirectorInput, DirectorPlan, chief_director
from mosesaic.team.orchestrator.phases import PHASE_NAMES
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.context import LLMContext
from mosesaic.llm.provider import Capabilities
from mosesaic.core.cost import CostTracker
from mosesaic.core.bus import MessageBus
from mosesaic.core.context import AgentContext
from mosesaic.core.lifecycle import AgentLifecycle
from mosesaic.core.message import AgentMessage, MessageType


def _make_mock_llm(response_json: dict) -> LLMContext:
    caps = {"mock-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class _FixedMock(MockProvider):
        @property
        def name(self) -> str:
            return "fixed-mock"

    provider = _FixedMock(capabilities=caps)
    provider._next_response = json.dumps(response_json)

    class _Registry:
        def find(self, **_):
            return "mock-model", provider

        def all_models(self):
            return caps

    cost = CostTracker(agent_name="chief_director")
    return LLMContext(
        registry=_Registry(),
        cost_tracker=cost,
        agent_name="chief_director",
        system_prompt=None,
    )


async def _run_director(prompt: str, llm_response: dict) -> DirectorPlan:
    bus = MessageBus()
    bus.register("chief_director")
    await bus.send(AgentMessage(
        from_agent="__test__",
        to_agent="chief_director",
        type=MessageType.TASK,
        payload=DirectorInput(prompt=prompt),
    ))
    cost = CostTracker(agent_name="chief_director")
    ctx = AgentContext(
        agent_name="chief_director",
        bus=bus,
        cost_tracker=cost,
        lifecycle=AgentLifecycle(),
        llm=_make_mock_llm(llm_response),
    )
    await chief_director.fn(ctx)
    sent = [m for m in bus.event_log() if m.from_agent == "chief_director"]
    assert sent, "chief_director sent no output"
    return sent[-1].payload


@pytest.mark.anyio
async def test_director_returns_director_plan():
    plan = await _run_director(
        prompt="Add a health check endpoint",
        llm_response={
            "request_type": "feature",
            "phases": ["build", "verify"],
            "reasoning": "Simple addition, no clarification needed.",
        },
    )
    assert isinstance(plan, DirectorPlan)
    assert plan.request_type == "feature"
    assert plan.phases == ["build", "verify"]
    assert plan.reasoning


@pytest.mark.anyio
async def test_director_validates_phases():
    """If the LLM returns an unknown phase, director raises ValueError."""
    with pytest.raises(ValueError, match="unknown"):
        await _run_director(
            prompt="Do something",
            llm_response={
                "request_type": "feature",
                "phases": ["build", "launch"],  # 'launch' is not valid
                "reasoning": "testing",
            },
        )


@pytest.mark.anyio
async def test_director_validates_request_type():
    """If the LLM returns an unknown request_type, director raises ValueError."""
    with pytest.raises((ValueError, RuntimeError)):
        await _run_director(
            prompt="Do something",
            llm_response={
                "request_type": "unknown_type",
                "phases": ["build", "verify"],
                "reasoning": "testing",
            },
        )


@pytest.mark.anyio
async def test_director_all_phases_valid():
    plan = await _run_director(
        prompt="Build a new product from scratch",
        llm_response={
            "request_type": "greenfield",
            "phases": ["clarify", "architect", "build", "verify", "deploy", "monitor"],
            "reasoning": "Greenfield project needs all phases.",
        },
    )
    assert set(plan.phases) <= PHASE_NAMES


@pytest.mark.anyio
async def test_director_strips_markdown_fences():
    """LLM sometimes wraps JSON in markdown fences — director should strip them."""
    fenced_response = '```json\n{"request_type": "bugfix", "phases": ["build", "verify"], "reasoning": "quick fix"}\n```'
    bus = MessageBus()
    bus.register("chief_director")
    await bus.send(AgentMessage(
        from_agent="__test__",
        to_agent="chief_director",
        type=MessageType.TASK,
        payload=DirectorInput(prompt="Fix a bug"),
    ))
    cost = CostTracker(agent_name="chief_director")

    caps = {"mock-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class _FencedMock(MockProvider):
        @property
        def name(self) -> str:
            return "fenced-mock"

    provider = _FencedMock(capabilities=caps)
    provider._next_response = fenced_response

    class _Registry:
        def find(self, **_):
            return "mock-model", provider

        def all_models(self):
            return caps

    ctx = AgentContext(
        agent_name="chief_director",
        bus=bus,
        cost_tracker=cost,
        lifecycle=AgentLifecycle(),
        llm=LLMContext(registry=_Registry(), cost_tracker=cost, agent_name="chief_director"),
    )
    await chief_director.fn(ctx)
    sent = [m for m in bus.event_log() if m.from_agent == "chief_director"]
    plan: DirectorPlan = sent[-1].payload
    assert plan.request_type == "bugfix"
    assert plan.phases == ["build", "verify"]
