"""Tests for specialist domain execution agents."""
from __future__ import annotations
import json
import pytest
from mosesaic.core.bus import MessageBus
from mosesaic.core.cost import CostTracker
from mosesaic.core.context import AgentContext
from mosesaic.core.lifecycle import AgentLifecycle
from mosesaic.core.message import AgentMessage, MessageType
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.context import LLMContext
from mosesaic.llm.provider import Capabilities


def _make_mock_llm(agent_name: str, response_json: dict) -> LLMContext:
    caps = {"mock-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class _FixedMock(MockProvider):
        @property
        def name(self) -> str:
            return "fixed-mock"

    provider = _FixedMock(capabilities=caps)
    provider._next_response = json.dumps(response_json)

    class _Registry:
        def find(self, **_):
            return "mock-model", provider
        def all_models(self):
            return caps

    cost = CostTracker(agent_name=agent_name)
    return LLMContext(registry=_Registry(), cost_tracker=cost, agent_name=agent_name, system_prompt=None)


async def _run_specialist(agent_def, payload, llm_response: dict):
    bus = MessageBus()
    bus.register(agent_def.name)
    await bus.send(AgentMessage(
        from_agent="__test__",
        to_agent=agent_def.name,
        type=MessageType.TASK,
        payload=payload,
    ))
    agent_ctx = AgentContext(
        agent_name=agent_def.name,
        bus=bus,
        cost_tracker=CostTracker(agent_name=agent_def.name),
        lifecycle=AgentLifecycle(),
        llm=_make_mock_llm(agent_def.name, llm_response),
    )
    await agent_def.fn(agent_ctx)
    sent = [m for m in bus.event_log() if m.from_agent == agent_def.name]
    assert sent, f"{agent_def.name} sent no output"
    return sent[-1].payload


# ── Analyst ────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_analyst_populates_acceptance_criteria():
    from mosesaic.team.agents.analyst import analyst, AnalystInput, AnalystOutput
    output = await _run_specialist(
        analyst,
        AnalystInput(goal="Add a health endpoint", constraints=[]),
        {"acceptance_criteria": ["GET /health returns 200"], "constraints": [], "summary": "Health endpoint requirements clarified."},
    )
    assert isinstance(output, AnalystOutput)
    assert output.acceptance_criteria == ["GET /health returns 200"]
    assert output.summary == "Health endpoint requirements clarified."
    assert output.cost_usd >= 0.0


@pytest.mark.anyio
async def test_analyst_preserves_existing_constraints():
    from mosesaic.team.agents.analyst import analyst, AnalystInput, AnalystOutput
    output = await _run_specialist(
        analyst,
        AnalystInput(goal="Add auth", constraints=["No breaking changes"]),
        {"acceptance_criteria": ["Auth returns JWT"], "constraints": ["No breaking changes", "Use existing user table"], "summary": "Auth requirements clarified."},
    )
    assert isinstance(output, AnalystOutput)
    assert "No breaking changes" in output.constraints


@pytest.mark.anyio
async def test_analyst_handles_markdown_fences():
    from mosesaic.team.agents.analyst import analyst, AnalystInput, AnalystOutput
    caps = {"mock-model": Capabilities(vision=False, tools=False, thinking=False, context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0)}

    class _FencedMock(MockProvider):
        @property
        def name(self) -> str:
            return "fenced-mock"

    provider = _FencedMock(capabilities=caps)
    provider._next_response = '```json\n{"acceptance_criteria": ["criterion"], "constraints": [], "summary": "done."}\n```'

    class _Registry:
        def find(self, **_): return "mock-model", provider
        def all_models(self): return caps

    cost = CostTracker(agent_name="analyst")
    bus = MessageBus()
    bus.register("analyst")
    await bus.send(AgentMessage(from_agent="__test__", to_agent="analyst", type=MessageType.TASK, payload=AnalystInput(goal="test", constraints=[])))
    agent_ctx = AgentContext(
        agent_name="analyst", bus=bus, cost_tracker=cost, lifecycle=AgentLifecycle(),
        llm=LLMContext(registry=_Registry(), cost_tracker=cost, agent_name="analyst", system_prompt=None),
    )
    await analyst.fn(agent_ctx)
    sent = [m for m in bus.event_log() if m.from_agent == "analyst"]
    output = sent[-1].payload
    assert isinstance(output, AnalystOutput)
    assert output.acceptance_criteria == ["criterion"]


# ── Architect ──────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_architect_agent_populates_adr_and_design_spec():
    from mosesaic.team.agents.architect import architect_agent, ArchitectInput, ArchitectOutput
    output = await _run_specialist(
        architect_agent,
        ArchitectInput(goal="Add OAuth2", acceptance_criteria=["JWT returned"], constraints=["No breaking changes"]),
        {"adr": "Use OAuth2 code flow.", "design_spec": "Add auth.py, update routes.py.", "summary": "OAuth2 via code flow."},
    )
    assert isinstance(output, ArchitectOutput)
    assert output.adr == "Use OAuth2 code flow."
    assert output.design_spec == "Add auth.py, update routes.py."
    assert output.summary == "OAuth2 via code flow."
    assert output.cost_usd >= 0.0


@pytest.mark.anyio
async def test_architect_agent_handles_empty_acceptance_criteria():
    from mosesaic.team.agents.architect import architect_agent, ArchitectInput, ArchitectOutput
    output = await _run_specialist(
        architect_agent,
        ArchitectInput(goal="Refactor DB layer", acceptance_criteria=[], constraints=[]),
        {"adr": "Extract repository pattern.", "design_spec": "Create repo.py.", "summary": "Repository pattern extracted."},
    )
    assert isinstance(output, ArchitectOutput)
    assert output.adr == "Extract repository pattern."


# ── DevOps ─────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_devops_agent_sets_deployment_state_staging():
    from mosesaic.team.agents.devops import devops_agent, DevopsInput, DevopsOutput
    output = await _run_specialist(
        devops_agent,
        DevopsInput(goal="Add health endpoint", files_changed=["src/health.py"], qa_findings=["All tests pass."]),
        {"deployment_state": "staging", "summary": "Ready for staging."},
    )
    assert isinstance(output, DevopsOutput)
    assert output.deployment_state == "staging"
    assert output.summary == "Ready for staging."
    assert output.cost_usd >= 0.0


@pytest.mark.anyio
async def test_devops_agent_sets_deployment_state_pending_on_qa_issues():
    from mosesaic.team.agents.devops import devops_agent, DevopsInput, DevopsOutput
    output = await _run_specialist(
        devops_agent,
        DevopsInput(goal="Fix bug", files_changed=["src/fix.py"], qa_findings=["SQL injection risk found."]),
        {"deployment_state": "pending", "summary": "Deployment blocked — QA issues remain."},
    )
    assert isinstance(output, DevopsOutput)
    assert output.deployment_state == "pending"


# ── Observer ───────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_observer_agent_returns_summary():
    from mosesaic.team.agents.observer import observer_agent, ObserverInput, ObserverOutput
    output = await _run_specialist(
        observer_agent,
        ObserverInput(goal="Add health endpoint", deployment_state="staging"),
        {"summary": "Monitor /health latency p99 and 5xx error rate."},
    )
    assert isinstance(output, ObserverOutput)
    assert output.summary == "Monitor /health latency p99 and 5xx error rate."
    assert output.cost_usd >= 0.0


@pytest.mark.anyio
async def test_observer_agent_handles_pending_state():
    from mosesaic.team.agents.observer import observer_agent, ObserverInput, ObserverOutput
    output = await _run_specialist(
        observer_agent,
        ObserverInput(goal="Fix bug", deployment_state="pending"),
        {"summary": "No active monitoring — deployment is pending."},
    )
    assert isinstance(output, ObserverOutput)
    assert output.summary == "No active monitoring — deployment is pending."
