from __future__ import annotations
import pytest
from unittest.mock import MagicMock, PropertyMock
from mosesaic.team.budget.manager import BudgetManager
from mosesaic.team.budget.tiers import TaskTier
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider


def _make_registry(*providers):
    from mosesaic.llm.registry import ProviderRegistry
    r = ProviderRegistry()
    for p in providers:
        r.register(p)
    return r


def _free_provider(name: str):
    caps = {"free-model": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}
    _name = name

    class NamedMock(MockProvider):
        @property
        def name(self) -> str:
            return _name

    return NamedMock(capabilities=caps)


def _cheap_provider():
    caps = {"cheap-model": Capabilities(
        vision=False, tools=True, thinking=False,
        context_k=32, cost_per_1m_input=0.10, cost_per_1m_output=0.40,
    )}

    class OpenAIMock(MockProvider):
        @property
        def name(self) -> str:
            return "openai"

    return OpenAIMock(capabilities=caps)


def test_initial_spend_is_zero():
    mgr = BudgetManager(registry=_make_registry(), sprint_budget_usd=5.0)
    assert mgr.total_spent_usd == 0.0


def test_record_spend_accumulates():
    mgr = BudgetManager(registry=_make_registry(), sprint_budget_usd=5.0)
    mgr.record_spend(0.05)
    mgr.record_spend(0.10)
    assert abs(mgr.total_spent_usd - 0.15) < 1e-9


def test_remaining_budget():
    mgr = BudgetManager(registry=_make_registry(), sprint_budget_usd=5.0)
    mgr.record_spend(1.50)
    assert abs(mgr.remaining_usd - 3.50) < 1e-9


def test_threshold_warning_triggered(caplog):
    import logging
    mgr = BudgetManager(
        registry=_make_registry(), sprint_budget_usd=10.0, warn_at_usd=5.0
    )
    mgr.record_spend(4.99)
    assert "budget" not in caplog.text.lower() and "warning" not in caplog.text.lower()

    with caplog.at_level(logging.WARNING):
        mgr.record_spend(0.02)  # crosses 5.0
    assert "budget" in caplog.text.lower() or "warning" in caplog.text.lower()


def test_threshold_warning_fires_once(caplog):
    import logging
    mgr = BudgetManager(
        registry=_make_registry(), sprint_budget_usd=10.0, warn_at_usd=5.0
    )
    with caplog.at_level(logging.WARNING):
        mgr.record_spend(6.0)

    caplog.clear()
    mgr.record_spend(1.0)
    assert len(caplog.records) == 0  # second call doesn't re-warn


def test_is_exhausted_false_within_budget():
    mgr = BudgetManager(registry=_make_registry(), sprint_budget_usd=5.0)
    mgr.record_spend(4.99)
    assert not mgr.is_exhausted


def test_is_exhausted_true_at_limit():
    mgr = BudgetManager(registry=_make_registry(), sprint_budget_usd=5.0)
    mgr.record_spend(5.01)
    assert mgr.is_exhausted


def test_select_model_for_simple_tier_prefers_free():
    ollama = _free_provider("ollama")
    openai = _cheap_provider()
    registry = _make_registry(ollama, openai)
    mgr = BudgetManager(registry=registry, sprint_budget_usd=5.0)
    model_id, provider = mgr.select_model(TaskTier.SIMPLE)
    assert provider.name == "ollama"
    assert model_id == "free-model"


def test_select_model_auto_downgrade_when_exhausted():
    ollama = _free_provider("ollama")
    openai = _cheap_provider()
    registry = _make_registry(ollama, openai)
    mgr = BudgetManager(
        registry=registry, sprint_budget_usd=0.01, auto_downgrade=True
    )
    mgr.record_spend(0.02)  # exhausted
    model_id, provider = mgr.select_model(TaskTier.COMPLEX)
    assert provider.name == "ollama"


def test_select_model_raises_when_exhausted_no_downgrade():
    openai = _cheap_provider()
    registry = _make_registry(openai)
    mgr = BudgetManager(
        registry=registry, sprint_budget_usd=0.01, auto_downgrade=False
    )
    mgr.record_spend(0.02)
    with pytest.raises(RuntimeError, match="budget exhausted"):
        mgr.select_model(TaskTier.COMPLEX)


def test_spend_summary():
    mgr = BudgetManager(registry=_make_registry(), sprint_budget_usd=5.0)
    mgr.record_spend(1.23, provider="anthropic")
    mgr.record_spend(0.05, provider="groq")
    summary = mgr.spend_summary()
    assert summary["total"] == pytest.approx(1.28)
    assert summary["by_provider"]["anthropic"] == pytest.approx(1.23)
    assert summary["by_provider"]["groq"] == pytest.approx(0.05)
    assert summary["budget"] == pytest.approx(5.0)
    assert summary["remaining"] == pytest.approx(5.0 - 1.28)
    assert not summary["exhausted"]
