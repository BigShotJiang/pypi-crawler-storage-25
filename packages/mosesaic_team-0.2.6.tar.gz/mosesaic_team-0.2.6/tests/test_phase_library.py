from __future__ import annotations
import pytest
from mosesaic.team.orchestrator.phases import (
    PHASE_NAMES,
    REQUEST_TYPE_PHASES,
    default_phases_for,
    validate_phase_sequence,
)


def test_phase_names_contains_all_six():
    assert PHASE_NAMES == {"clarify", "architect", "build", "verify", "deploy", "monitor"}


def test_validate_phase_sequence_valid():
    validate_phase_sequence(["clarify", "build", "verify"])  # no raise


def test_validate_phase_sequence_empty_valid():
    validate_phase_sequence([])  # no raise


def test_validate_phase_sequence_unknown_raises():
    with pytest.raises(ValueError, match="unknown"):
        validate_phase_sequence(["build", "launch"])


def test_default_phases_feature():
    phases = default_phases_for("feature")
    assert "build" in phases
    assert "verify" in phases
    assert "architect" in phases


def test_default_phases_bugfix_skips_architect():
    phases = default_phases_for("bugfix")
    assert "architect" not in phases
    assert "build" in phases
    assert "verify" in phases


def test_default_phases_greenfield_includes_monitor():
    phases = default_phases_for("greenfield")
    assert "monitor" in phases


def test_default_phases_unknown_raises():
    with pytest.raises(ValueError, match="Unknown request_type"):
        default_phases_for("unknown")


def test_all_request_types_have_build_and_verify():
    for rtype in REQUEST_TYPE_PHASES:
        phases = REQUEST_TYPE_PHASES[rtype]
        assert "build" in phases, f"{rtype} missing build"
        assert "verify" in phases, f"{rtype} missing verify"
