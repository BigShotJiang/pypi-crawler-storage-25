from __future__ import annotations
import pytest
from mosesaic.team.tools.shell import ShellTools


@pytest.fixture
def shell(tmp_path):
    return ShellTools(project_root=tmp_path)


def test_shell_true_with_dollar_paren_raises(shell):
    with pytest.raises(PermissionError, match="injection"):
        shell.run("echo $(whoami)", shell=True)


def test_shell_true_with_backtick_raises(shell):
    with pytest.raises(PermissionError, match="injection"):
        shell.run("echo `whoami`", shell=True)


def test_shell_true_with_dollar_brace_raises(shell):
    with pytest.raises(PermissionError, match="injection"):
        shell.run("echo ${HOME}", shell=True)


def test_shell_true_safe_command_passes(shell):
    """A safe shell=True command with no substitution should work."""
    result = shell.run("echo hello | cat", shell=True)
    assert result.success
    assert "hello" in result.stdout


def test_shell_false_dollar_in_arg_is_safe(shell):
    """When shell=False, shlex.split tokenises safely — no PermissionError raised."""
    result = shell.run("echo $NOTHING")
    assert result.success


def test_quote_wraps_shlex_quote():
    assert ShellTools.quote("hello world") == "'hello world'"
    assert ShellTools.quote("safe") == "safe"
    assert ShellTools.quote("$(rm -rf /)") == "'$(rm -rf /)'"
