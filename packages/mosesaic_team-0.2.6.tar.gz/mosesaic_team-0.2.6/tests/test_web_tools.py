from __future__ import annotations
import pytest
import respx
import httpx
from mosesaic.team.tools.web import WebSearchTools, SearchResult


_DDG_RESPONSE = {
    "Heading": "Python",
    "AbstractText": "Python is a high-level programming language.",
    "AbstractURL": "https://python.org",
    "RelatedTopics": [
        {"Text": "Python tutorial - Official tutorial", "FirstURL": "https://python.org/tutorial"},
        {"Text": "Python docs - Reference documentation", "FirstURL": "https://docs.python.org"},
        {"Text": "PyPI - Python package index", "FirstURL": "https://pypi.org"},
    ],
}

_DDG_EMPTY_RESPONSE = {
    "Heading": "",
    "AbstractText": "",
    "AbstractURL": "",
    "RelatedTopics": [],
}


@respx.mock
def test_search_returns_search_results():
    respx.get("https://api.duckduckgo.com/").mock(
        return_value=httpx.Response(200, json=_DDG_RESPONSE)
    )
    ws = WebSearchTools()
    results = ws.search("Python programming")
    assert len(results) >= 1
    assert all(isinstance(r, SearchResult) for r in results)


@respx.mock
def test_search_includes_abstract_as_first_result():
    respx.get("https://api.duckduckgo.com/").mock(
        return_value=httpx.Response(200, json=_DDG_RESPONSE)
    )
    ws = WebSearchTools()
    results = ws.search("Python")
    assert results[0].url == "https://python.org"
    assert "programming language" in results[0].snippet


@respx.mock
def test_search_respects_max_results():
    respx.get("https://api.duckduckgo.com/").mock(
        return_value=httpx.Response(200, json=_DDG_RESPONSE)
    )
    ws = WebSearchTools()
    results = ws.search("Python", max_results=2)
    assert len(results) <= 2


@respx.mock
def test_search_empty_response_returns_empty_list():
    respx.get("https://api.duckduckgo.com/").mock(
        return_value=httpx.Response(200, json=_DDG_EMPTY_RESPONSE)
    )
    ws = WebSearchTools()
    results = ws.search("xyzzy nothing here")
    assert results == []


@respx.mock
def test_fetch_page_strips_html_tags():
    respx.get("https://example.com/page").mock(
        return_value=httpx.Response(
            200, text="<html><body><h1>Hello</h1><p>World</p></body></html>"
        )
    )
    ws = WebSearchTools()
    text = ws.fetch_page("https://example.com/page")
    assert "Hello" in text
    assert "World" in text
    assert "<html>" not in text
    assert "<p>" not in text


@respx.mock
def test_fetch_page_truncates_at_max_chars():
    long_content = "A" * 10000
    respx.get("https://example.com/long").mock(
        return_value=httpx.Response(200, text=f"<p>{long_content}</p>")
    )
    ws = WebSearchTools()
    text = ws.fetch_page("https://example.com/long", max_chars=500)
    assert len(text) <= 500


@respx.mock
def test_fetch_page_collapses_whitespace():
    respx.get("https://example.com/ws").mock(
        return_value=httpx.Response(200, text="<p>hello\n\n\n   world</p>")
    )
    ws = WebSearchTools()
    text = ws.fetch_page("https://example.com/ws")
    assert "  " not in text  # no double spaces
