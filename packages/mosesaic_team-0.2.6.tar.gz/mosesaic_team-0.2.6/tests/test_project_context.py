from __future__ import annotations
import pytest
from mosesaic.team.orchestrator.context import ProjectContext


def test_project_context_requires_goal():
    with pytest.raises(TypeError):
        ProjectContext()  # goal is required


def test_project_context_defaults():
    ctx = ProjectContext(goal="Add login")
    assert ctx.request_type == "feature"
    assert ctx.constraints == []
    assert ctx.acceptance_criteria == []
    assert ctx.adr is None
    assert ctx.design_spec is None
    assert ctx.file_plan == []
    assert ctx.files_changed == []
    assert ctx.test_results == {}
    assert ctx.qa_findings == []
    assert ctx.deployment_state == "pending"
    assert ctx.phase_history == []


def test_project_context_update_fields():
    ctx = ProjectContext(goal="Add login")
    ctx.constraints.append("must use OAuth2")
    ctx.phase_history.append("clarify")
    assert ctx.constraints == ["must use OAuth2"]
    assert ctx.phase_history == ["clarify"]


def test_project_context_valid_request_types():
    for rtype in ("feature", "bugfix", "greenfield", "incident", "refactor"):
        ctx = ProjectContext(goal="x", request_type=rtype)
        assert ctx.request_type == rtype


def test_project_context_invalid_request_type_raises():
    with pytest.raises(ValueError, match="request_type"):
        ProjectContext(goal="x", request_type="unknown")
