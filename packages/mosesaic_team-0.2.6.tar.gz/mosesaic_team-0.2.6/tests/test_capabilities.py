from __future__ import annotations
import json
import pytest
from mosesaic.team.tools.capabilities import MachineCapabilities


@pytest.fixture
def root(tmp_path):
    return tmp_path


def test_defaults_when_file_absent(root):
    caps = MachineCapabilities(root)
    assert caps.is_allowed("git.read") is True
    assert caps.is_allowed("shell") is True
    assert caps.is_allowed("web_search") is True
    assert caps.is_allowed("git.write") is False
    assert caps.is_allowed("deploy.kubectl") is False
    assert caps.is_allowed("deploy.helm") is False
    assert caps.is_allowed("deploy.docker") is False


def test_file_overrides_defaults(root):
    (root / ".mosesaic").mkdir()
    (root / ".mosesaic" / "machine-capabilities.json").write_text(
        json.dumps({"git.write": True, "deploy.kubectl": True})
    )
    caps = MachineCapabilities(root)
    assert caps.is_allowed("git.write") is True
    assert caps.is_allowed("deploy.kubectl") is True
    # defaults still apply for keys not in file
    assert caps.is_allowed("git.read") is True
    assert caps.is_allowed("deploy.helm") is False


def test_unknown_capability_returns_false(root):
    caps = MachineCapabilities(root)
    assert caps.is_allowed("unknown.tool") is False
    assert caps.is_allowed("") is False


def test_available_lists_only_enabled(root):
    caps = MachineCapabilities(root)
    available = caps.available()
    assert "git.read" in available
    assert "web_search" in available
    assert "git.write" not in available
    assert "deploy.kubectl" not in available


def test_create_factory_applies_overrides_without_file(root):
    caps = MachineCapabilities.create(root, **{"git.write": True, "deploy.kubectl": True})
    assert caps.is_allowed("git.write") is True
    assert caps.is_allowed("deploy.kubectl") is True
    assert caps.is_allowed("git.read") is True  # default preserved


def test_file_with_all_deploy_enabled(root):
    (root / ".mosesaic").mkdir()
    (root / ".mosesaic" / "machine-capabilities.json").write_text(
        json.dumps({
            "git.write": True,
            "deploy.kubectl": True,
            "deploy.helm": True,
            "deploy.docker": True,
        })
    )
    caps = MachineCapabilities(root)
    for cap in ["deploy.kubectl", "deploy.helm", "deploy.docker", "git.write"]:
        assert caps.is_allowed(cap) is True
