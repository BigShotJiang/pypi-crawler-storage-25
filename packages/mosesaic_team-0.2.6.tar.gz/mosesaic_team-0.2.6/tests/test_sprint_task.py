from __future__ import annotations
from uuid import UUID
from mosesaic.team.project.task import SprintTask, TaskStatus


def test_default_status_is_pending():
    t = SprintTask(title="Add login", description="OAuth flow", tier="medium")
    assert t.status == TaskStatus.PENDING
    assert t.result == ""
    assert t.assigned_to == ""


def test_has_uuid():
    t = SprintTask(title="x", description="y", tier="simple")
    assert isinstance(t.id, UUID)
    t2 = SprintTask(title="x", description="y", tier="simple")
    assert t.id != t2.id


def test_to_dict_fields():
    t = SprintTask(title="Add login", description="OAuth", tier="medium")
    d = t.to_dict()
    assert d["title"] == "Add login"
    assert d["description"] == "OAuth"
    assert d["tier"] == "medium"
    assert d["status"] == "pending"
    assert d["result"] == ""
    assert "id" in d


def test_roundtrip():
    t = SprintTask(
        title="Foo", description="Bar", tier="complex",
        status=TaskStatus.DONE, result="done", assigned_to="developer",
    )
    t2 = SprintTask.from_dict(t.to_dict())
    assert t2.title == t.title
    assert t2.description == t.description
    assert t2.status == TaskStatus.DONE
    assert t2.result == "done"
    assert t2.assigned_to == "developer"
    assert t2.id == t.id


def test_status_enum_from_string():
    assert TaskStatus("pending") == TaskStatus.PENDING
    assert TaskStatus("in_progress") == TaskStatus.IN_PROGRESS
    assert TaskStatus("done") == TaskStatus.DONE
    assert TaskStatus("failed") == TaskStatus.FAILED


def test_invalid_tier_raises():
    import pytest
    with pytest.raises(ValueError, match="Invalid tier"):
        SprintTask(title="x", description="y", tier="bogus")
