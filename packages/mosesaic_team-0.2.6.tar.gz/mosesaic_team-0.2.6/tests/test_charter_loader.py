"""Tests for charter_loader — loads role .md files as system prompts."""
import pytest
from mosesaic.team.charters.charter_loader import load_charter


def test_load_charter_developer_returns_content():
    charter = load_charter("developer")
    assert len(charter) > 50
    assert "developer" in charter.lower()


def test_load_charter_qa_contains_anti_fabrication_rules():
    charter = load_charter("qa")
    assert "VERIFIED" in charter
    assert "REVIEWED" in charter
    assert "UNTESTED" in charter


def test_load_charter_scribe_returns_content():
    charter = load_charter("scribe")
    assert len(charter) > 50


def test_load_charter_unknown_role_raises_value_error():
    with pytest.raises(ValueError, match="unknown"):
        load_charter("unknown-role")


def test_load_charter_chief_director():
    content = load_charter("chief_director")
    assert len(content) > 0
    assert "phases" in content.lower()


def test_load_charter_tampered_raises(tmp_path):
    """If a charter file is modified after hashing, load_charter raises RuntimeError."""
    from mosesaic.team.charters import charter_loader as _mod
    original = _mod.KNOWN_HASHES.get("developer", "")
    _mod.KNOWN_HASHES["developer"] = "0" * 64
    try:
        with pytest.raises(RuntimeError, match="tampered"):
            load_charter("developer")
    finally:
        _mod.KNOWN_HASHES["developer"] = original


def test_load_charter_hash_matches_file():
    """All charter files in KNOWN_HASHES must have matching content."""
    import hashlib
    from mosesaic.team.charters import charter_loader as _mod
    for role, expected_hash in _mod.KNOWN_HASHES.items():
        content = (_mod._CHARTER_DIR / f"{role}.md").read_text(encoding="utf-8").strip()
        actual = hashlib.sha256(content.encode("utf-8")).hexdigest()
        assert actual == expected_hash, f"Hash mismatch for {role!r}"


def test_load_charter_clarify_returns_content():
    charter = load_charter("clarify")
    assert len(charter) > 50
    assert "clarif" in charter.lower()


def test_load_charter_architect_returns_content():
    charter = load_charter("architect")
    assert len(charter) > 50
    assert "architect" in charter.lower()


def test_load_charter_build_returns_content():
    charter = load_charter("build")
    assert len(charter) > 50
    assert "build" in charter.lower()


def test_load_charter_verify_returns_content():
    charter = load_charter("verify")
    assert len(charter) > 50
    assert "verif" in charter.lower()


def test_load_charter_deploy_returns_content():
    charter = load_charter("deploy")
    assert len(charter) > 50
    assert "deploy" in charter.lower()


def test_load_charter_monitor_returns_content():
    charter = load_charter("monitor")
    assert len(charter) > 50
    assert "monitor" in charter.lower()
