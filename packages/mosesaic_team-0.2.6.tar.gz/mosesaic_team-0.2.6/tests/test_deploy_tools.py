from __future__ import annotations
import pytest
from unittest.mock import patch, MagicMock
from mosesaic.team.tools.deploy import DeployTools


@pytest.fixture
def deploy(tmp_path):
    return DeployTools(project_root=tmp_path)


def test_kubectl_apply_dry_run_passes_dry_run_flag(deploy):
    with patch("shutil.which", return_value="/usr/bin/kubectl"), \
         patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="pod/app (dry run)", stderr="")
        deploy.kubectl_apply("app.yaml", dry_run=True)
    args = mock_run.call_args[0][0]
    assert "--dry-run=client" in args
    assert "app.yaml" in args


def test_kubectl_apply_live_omits_dry_run_flag(deploy):
    with patch("shutil.which", return_value="/usr/bin/kubectl"), \
         patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="applied", stderr="")
        deploy.kubectl_apply("app.yaml", dry_run=False)
    args = mock_run.call_args[0][0]
    assert "--dry-run=client" not in args


def test_kubectl_apply_with_namespace(deploy):
    with patch("shutil.which", return_value="/usr/bin/kubectl"), \
         patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
        deploy.kubectl_apply("app.yaml", namespace="production")
    args = mock_run.call_args[0][0]
    assert "-n" in args
    assert "production" in args


def test_kubectl_apply_raises_when_not_installed(deploy):
    with patch("shutil.which", return_value=None):
        with pytest.raises(FileNotFoundError, match="kubectl"):
            deploy.kubectl_apply("app.yaml")


def test_helm_upgrade_dry_run_passes_dry_run_flag(deploy):
    with patch("shutil.which", return_value="/usr/bin/helm"), \
         patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="dry-run ok", stderr="")
        deploy.helm_upgrade("myapp", "./chart", dry_run=True)
    args = mock_run.call_args[0][0]
    assert "--dry-run" in args
    assert "myapp" in args


def test_helm_upgrade_with_values_file(deploy):
    with patch("shutil.which", return_value="/usr/bin/helm"), \
         patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
        deploy.helm_upgrade("myapp", "./chart", values_file="prod.yaml")
    args = mock_run.call_args[0][0]
    assert "-f" in args
    assert "prod.yaml" in args


def test_helm_upgrade_raises_when_not_installed(deploy):
    with patch("shutil.which", return_value=None):
        with pytest.raises(FileNotFoundError, match="helm"):
            deploy.helm_upgrade("myapp", "./chart")


def test_docker_push_dry_run_returns_without_subprocess_call(deploy):
    with patch("subprocess.run") as mock_run:
        result = deploy.docker_push("myrepo/myimage", "v1.0", dry_run=True)
    mock_run.assert_not_called()
    assert result.success
    assert "dry-run" in result.stdout
    assert "myrepo/myimage:v1.0" in result.stdout


def test_docker_push_live_calls_subprocess(deploy):
    with patch("shutil.which", return_value="/usr/bin/docker"), \
         patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="pushed", stderr="")
        deploy.docker_push("myrepo/myimage", "v1.0", dry_run=False)
    args = mock_run.call_args[0][0]
    assert "docker" in args
    assert "push" in args
    assert "myrepo/myimage:v1.0" in args


def test_docker_push_raises_when_not_installed(deploy):
    with patch("shutil.which", return_value=None):
        with pytest.raises(FileNotFoundError, match="docker"):
            deploy.docker_push("myimage", dry_run=False)
