from __future__ import annotations
import subprocess
import pytest
from mosesaic.team.tools.git import GitTools


@pytest.fixture
def git_repo(tmp_path):
    """A minimal real git repo for testing."""
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=tmp_path, check=True, capture_output=True
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=tmp_path, check=True, capture_output=True
    )
    (tmp_path / "file.py").write_text("x = 1\n")
    subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "initial commit"],
        cwd=tmp_path, check=True, capture_output=True
    )
    return tmp_path


@pytest.fixture
def git(git_repo):
    return GitTools(project_root=git_repo)
