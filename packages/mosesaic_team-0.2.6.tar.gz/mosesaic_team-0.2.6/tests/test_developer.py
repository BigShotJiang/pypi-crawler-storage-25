from __future__ import annotations
import json
import pytest
from pathlib import Path
from mosesaic.core.spawner import Spawner
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.team.budget.manager import BudgetManager
from mosesaic.team.project.state import ProjectState
from mosesaic.team.project.task import SprintTask, TaskStatus
from mosesaic.team.agents.protocol import DeveloperTask, TeamResponse
from mosesaic.team.agents.developer import developer_agent


def _make_openai_mock(response_json: str) -> MockProvider:
    """Mock provider named 'openai' — matches MEDIUM tier preference."""
    caps = {"gpt-mock": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=128, cost_per_1m_input=0.15, cost_per_1m_output=0.60,
    )}

    class OpenAIMock(MockProvider):
        @property
        def name(self) -> str:
            return "openai"

    return OpenAIMock(responses={"gpt-mock": response_json}, capabilities=caps)


def _make_budget(provider) -> BudgetManager:
    r = ProviderRegistry()
    r.register(provider)
    return BudgetManager(registry=r, sprint_budget_usd=5.0)


@pytest.mark.anyio
async def test_developer_writes_files(tmp_path):
    dev_response = json.dumps({
        "files": [
            {"path": "src/auth.py", "content": "# JWT auth\ndef verify(): pass\n"},
        ],
        "explanation": "Added JWT auth stub",
    })
    budget_mgr = _make_budget(_make_openai_mock(dev_response))
    state = ProjectState(tmp_path)
    sprint_task = SprintTask(title="Add JWT auth", description="JWT middleware", tier="medium")

    payload = DeveloperTask(
        sprint_task=sprint_task,
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    result: TeamResponse = await spawner.spawn(developer_agent, payload, timeout=10.0)

    assert isinstance(result, TeamResponse)
    assert result.success
    assert (tmp_path / "src" / "auth.py").exists()
    assert "verify" in (tmp_path / "src" / "auth.py").read_text()


@pytest.mark.anyio
async def test_developer_updates_task_status_to_done(tmp_path):
    dev_response = json.dumps({
        "files": [{"path": "out.py", "content": "x = 1\n"}],
        "explanation": "done",
    })
    budget_mgr = _make_budget(_make_openai_mock(dev_response))
    state = ProjectState(tmp_path)
    sprint_task = SprintTask(title="Simple task", description="Do something", tier="medium")
    state.add_task(sprint_task)

    payload = DeveloperTask(
        sprint_task=sprint_task,
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    await spawner.spawn(developer_agent, payload, timeout=10.0)

    saved = state.get_tasks()
    assert saved[0].status == TaskStatus.DONE


@pytest.mark.anyio
async def test_developer_handles_malformed_json(tmp_path):
    budget_mgr = _make_budget(_make_openai_mock("not valid json"))
    state = ProjectState(tmp_path)
    sprint_task = SprintTask(title="Broken", description="...", tier="medium")

    payload = DeveloperTask(
        sprint_task=sprint_task,
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    result: TeamResponse = await spawner.spawn(developer_agent, payload, timeout=10.0)

    assert not result.success
    assert result.error != ""


@pytest.mark.anyio
async def test_developer_writes_multiple_files(tmp_path):
    dev_response = json.dumps({
        "files": [
            {"path": "src/models.py", "content": "class User: pass\n"},
            {"path": "src/views.py", "content": "def index(): pass\n"},
        ],
        "explanation": "Added models and views",
    })
    budget_mgr = _make_budget(_make_openai_mock(dev_response))
    state = ProjectState(tmp_path)
    sprint_task = SprintTask(title="MVC scaffold", description="Models + views", tier="medium")

    payload = DeveloperTask(
        sprint_task=sprint_task,
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    result = await spawner.spawn(developer_agent, payload, timeout=10.0)

    assert result.success
    assert (tmp_path / "src" / "models.py").exists()
    assert (tmp_path / "src" / "views.py").exists()
