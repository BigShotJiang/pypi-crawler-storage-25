from __future__ import annotations
import pytest
from mosesaic.team.orchestrator.context import ProjectContext
from mosesaic.team.orchestrator.protocol import PhaseInput, PhaseOutput
from mosesaic.team.orchestrator.directors import (
    clarify_director,
    architect_director,
    deploy_director,
    monitor_director,
)
from mosesaic.core.bus import MessageBus
from mosesaic.core.cost import CostTracker
from mosesaic.core.context import AgentContext
from mosesaic.core.lifecycle import AgentLifecycle
from mosesaic.core.message import AgentMessage, MessageType
from mosesaic.team.agents.analyst import AnalystOutput
from mosesaic.team.agents.architect import ArchitectOutput
from mosesaic.team.agents.devops import DevopsOutput
from mosesaic.team.agents.observer import ObserverOutput


class _MockSpawner:
    """Returns a preset value for every ctx.spawn() call in director tests."""
    def __init__(self, return_value):
        self._return_value = return_value

    async def spawn(self, definition, payload, *, timeout=120.0):
        return self._return_value

    async def pool(self, definition, items, *, concurrency=4, timeout=120.0):
        return [self._return_value] * len(items)


async def _run_spawning_director(director_def, phase: str, project_ctx, spawn_return) -> PhaseOutput:
    inp = PhaseInput(context=project_ctx, phase=phase)
    bus = MessageBus()
    bus.register(director_def.name)
    await bus.send(AgentMessage(
        from_agent="__test__",
        to_agent=director_def.name,
        type=MessageType.TASK,
        payload=inp,
    ))
    agent_ctx = AgentContext(
        agent_name=director_def.name,
        bus=bus,
        cost_tracker=CostTracker(agent_name=director_def.name),
        lifecycle=AgentLifecycle(),
        spawner=_MockSpawner(spawn_return),
    )
    await director_def.fn(agent_ctx)
    sent = [m for m in bus.event_log() if m.from_agent == director_def.name]
    assert sent, f"{director_def.name} sent no output"
    return sent[-1].payload


# ── clarify_director ──────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_clarify_director_populates_acceptance_criteria():
    project_ctx = ProjectContext(goal="Add health endpoint", request_type="feature")
    spawn_return = AnalystOutput(
        acceptance_criteria=["GET /health returns 200"],
        constraints=["No breaking changes"],
        summary="Health endpoint requirements clarified.",
        cost_usd=0.12,
    )
    output = await _run_spawning_director(clarify_director, "clarify", project_ctx, spawn_return)
    assert isinstance(output, PhaseOutput)
    assert output.phase == "clarify"
    assert output.context.acceptance_criteria == ["GET /health returns 200"]
    assert "No breaking changes" in output.context.constraints
    assert "clarify" in output.context.phase_history
    assert output.cost_usd == 0.12


@pytest.mark.anyio
async def test_clarify_director_preserves_goal_and_request_type():
    project_ctx = ProjectContext(goal="My specific goal", request_type="bugfix")
    spawn_return = AnalystOutput(acceptance_criteria=[], constraints=[], summary="done.")
    output = await _run_spawning_director(clarify_director, "clarify", project_ctx, spawn_return)
    assert output.context.goal == "My specific goal"
    assert output.context.request_type == "bugfix"


# ── architect_director ────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_architect_director_populates_adr_and_design_spec():
    project_ctx = ProjectContext(goal="Add OAuth2", request_type="feature")
    project_ctx.acceptance_criteria = ["Auth returns JWT"]
    project_ctx.constraints = ["No breaking changes"]
    spawn_return = ArchitectOutput(
        adr="Use OAuth2 code flow.",
        design_spec="Add auth.py, update routes.py.",
        summary="OAuth2 via code flow.",
        cost_usd=0.08,
    )
    output = await _run_spawning_director(architect_director, "architect", project_ctx, spawn_return)
    assert output.phase == "architect"
    assert output.context.adr == "Use OAuth2 code flow."
    assert output.context.design_spec == "Add auth.py, update routes.py."
    assert "architect" in output.context.phase_history
    assert output.cost_usd == 0.08


@pytest.mark.anyio
async def test_architect_director_preserves_goal():
    project_ctx = ProjectContext(goal="Specific goal", request_type="feature")
    spawn_return = ArchitectOutput(adr="ADR.", design_spec="spec.", summary="done.")
    output = await _run_spawning_director(architect_director, "architect", project_ctx, spawn_return)
    assert output.context.goal == "Specific goal"


# ── deploy_director ───────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_deploy_director_sets_deployment_state():
    project_ctx = ProjectContext(goal="Deploy fix", request_type="bugfix")
    project_ctx.files_changed = ["src/fix.py"]
    project_ctx.qa_findings = ["All tests pass."]
    spawn_return = DevopsOutput(deployment_state="staging", summary="Ready for staging.", cost_usd=0.05)
    output = await _run_spawning_director(deploy_director, "deploy", project_ctx, spawn_return)
    assert output.phase == "deploy"
    assert output.context.deployment_state == "staging"
    assert "deploy" in output.context.phase_history
    assert output.cost_usd == 0.05


@pytest.mark.anyio
async def test_deploy_director_preserves_goal():
    project_ctx = ProjectContext(goal="Deploy feature", request_type="feature")
    spawn_return = DevopsOutput(deployment_state="pending", summary="Pending.")
    output = await _run_spawning_director(deploy_director, "deploy", project_ctx, spawn_return)
    assert output.context.goal == "Deploy feature"


# ── monitor_director ──────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_monitor_director_appends_phase_history():
    project_ctx = ProjectContext(goal="Monitor deployment", request_type="feature")
    project_ctx.deployment_state = "staging"
    spawn_return = ObserverOutput(summary="Monitor latency and error rate.", cost_usd=0.03)
    output = await _run_spawning_director(monitor_director, "monitor", project_ctx, spawn_return)
    assert output.phase == "monitor"
    assert "monitor" in output.context.phase_history
    assert output.summary == "Monitor latency and error rate."
    assert output.cost_usd == 0.03


@pytest.mark.anyio
async def test_monitor_director_preserves_goal():
    project_ctx = ProjectContext(goal="My goal", request_type="feature")
    spawn_return = ObserverOutput(summary="done.")
    output = await _run_spawning_director(monitor_director, "monitor", project_ctx, spawn_return)
    assert output.context.goal == "My goal"


# --- Real director tests (build + verify) ---
import json as _json
from mosesaic.team.orchestrator.directors import build_director, verify_director
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.context import LLMContext
from mosesaic.llm.provider import Capabilities


def _make_mock_llm_multi(agent_name: str, responses: list[str]) -> LLMContext:
    """Build an LLMContext whose mock provider cycles through ``responses`` in order."""
    caps = {"mock-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class _SequenceMock(MockProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._call_index = 0

        @property
        def name(self) -> str:
            return "sequence-mock"

        async def chat(self, model, messages, max_tokens=4096, **kwargs):
            idx = self._call_index
            self._call_index += 1
            content = responses[idx] if idx < len(responses) else responses[-1]
            from mosesaic.llm.provider import LLMResponse
            return LLMResponse(
                content=content,
                model=model,
                input_tokens=10,
                output_tokens=20,
                cost_usd=0.0,
            )

    provider = _SequenceMock(capabilities=caps)

    class _Registry:
        def find(self, **_):
            return "mock-model", provider
        def all_models(self):
            return caps

    cost = CostTracker(agent_name=agent_name)
    return LLMContext(
        registry=_Registry(),
        cost_tracker=cost,
        agent_name=agent_name,
        system_prompt=None,
    )


def _make_mock_llm(agent_name: str, response_json: dict) -> LLMContext:
    """Build an LLMContext that always returns the same JSON response."""
    return _make_mock_llm_multi(agent_name, [_json.dumps(response_json)])


async def _run_real_director(
    director_def,
    phase: str,
    project_ctx: ProjectContext,
    llm_response: dict,
    *,
    extra_responses: list[str] | None = None,
) -> PhaseOutput:
    """Run a director with a single fixed LLM JSON response (plus optional extras)."""
    responses = [_json.dumps(llm_response)] + (extra_responses or [])
    inp = PhaseInput(context=project_ctx, phase=phase)
    bus = MessageBus()
    bus.register(director_def.name)
    await bus.send(AgentMessage(
        from_agent="__test__",
        to_agent=director_def.name,
        type=MessageType.TASK,
        payload=inp,
    ))
    agent_ctx = AgentContext(
        agent_name=director_def.name,
        bus=bus,
        cost_tracker=CostTracker(agent_name=director_def.name),
        lifecycle=AgentLifecycle(),
        llm=_make_mock_llm_multi(director_def.name, responses),
    )
    await director_def.fn(agent_ctx)
    sent = [m for m in bus.event_log() if m.from_agent == director_def.name]
    assert sent, f"{director_def.name} sent no output"
    return sent[-1].payload


@pytest.mark.anyio
async def test_build_director_populates_file_plan(tmp_path):
    ctx = ProjectContext(
        goal="Add a health endpoint",
        request_type="feature",
        project_root=str(tmp_path),
    )
    ctx.design_spec = "Add GET /health that returns 200."
    # First response: plan JSON. Second response: raw content for the file.
    plan_json = _json.dumps({
        "files": [
            {"path": "src/routes/health.py", "purpose": "Health endpoint route"},
            {"path": "tests/test_health.py", "purpose": "Test for health endpoint"},
        ],
        "summary": "Created health endpoint and test.",
    })
    file_content_1 = "def health(): return 200"
    file_content_2 = "def test_health(): assert True"
    llm = _make_mock_llm_multi(
        "build_director",
        [plan_json, file_content_1, file_content_2],
    )
    inp = PhaseInput(context=ctx, phase="build")
    bus = MessageBus()
    bus.register("build_director")
    await bus.send(AgentMessage(
        from_agent="__test__", to_agent="build_director",
        type=MessageType.TASK, payload=inp,
    ))
    agent_ctx = AgentContext(
        agent_name="build_director",
        bus=bus,
        cost_tracker=CostTracker(agent_name="build_director"),
        lifecycle=AgentLifecycle(),
        llm=llm,
    )
    await build_director.fn(agent_ctx)
    sent = [m for m in bus.event_log() if m.from_agent == "build_director"]
    output: PhaseOutput = sent[-1].payload
    assert isinstance(output, PhaseOutput)
    assert output.phase == "build"
    assert output.context.file_plan == ["src/routes/health.py", "tests/test_health.py"]
    assert output.context.files_changed == ["src/routes/health.py", "tests/test_health.py"]
    assert "build" in output.context.phase_history
    # Verify files were actually written to disk
    assert (tmp_path / "src" / "routes" / "health.py").exists()
    assert (tmp_path / "tests" / "test_health.py").exists()


@pytest.mark.anyio
async def test_build_director_handles_markdown_fences(tmp_path):
    ctx = ProjectContext(
        goal="Add health endpoint",
        request_type="feature",
        project_root=str(tmp_path),
    )
    # First call returns fenced plan JSON, second call returns raw file content
    fenced_plan = '```json\n{"files": [{"path": "src/health.py", "purpose": "health route"}], "summary": "One file."}\n```'
    file_content = "# health.py content"

    caps = {"mock-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    _call_responses = [fenced_plan, file_content]
    _call_idx = [0]

    class _FencedMock(MockProvider):
        @property
        def name(self) -> str:
            return "fenced-mock"

        async def chat(self, model, messages, max_tokens=4096, **kwargs):
            idx = _call_idx[0]
            _call_idx[0] += 1
            content = _call_responses[idx] if idx < len(_call_responses) else _call_responses[-1]
            from mosesaic.llm.provider import LLMResponse
            return LLMResponse(content=content, model=model, input_tokens=10, output_tokens=20, cost_usd=0.0)

    provider = _FencedMock(capabilities=caps)

    class _Registry:
        def find(self, **_):
            return "mock-model", provider
        def all_models(self):
            return caps

    inp = PhaseInput(context=ctx, phase="build")
    bus = MessageBus()
    bus.register("build_director")
    await bus.send(AgentMessage(
        from_agent="__test__", to_agent="build_director",
        type=MessageType.TASK, payload=inp,
    ))
    cost = CostTracker(agent_name="build_director")
    agent_ctx = AgentContext(
        agent_name="build_director",
        bus=bus,
        cost_tracker=cost,
        lifecycle=AgentLifecycle(),
        llm=LLMContext(registry=_Registry(), cost_tracker=cost, agent_name="build_director"),
    )
    await build_director.fn(agent_ctx)
    sent = [m for m in bus.event_log() if m.from_agent == "build_director"]
    output: PhaseOutput = sent[-1].payload
    assert output.context.file_plan == ["src/health.py"]


@pytest.mark.anyio
async def test_verify_director_populates_qa_findings(tmp_path):
    ctx = ProjectContext(
        goal="Add a health endpoint",
        request_type="feature",
        project_root=str(tmp_path),
    )
    # Write the files so verify_director can read them
    (tmp_path / "src" / "routes").mkdir(parents=True)
    (tmp_path / "src" / "routes" / "health.py").write_text("def health(): return 200")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_health.py").write_text("def test_health(): pass")
    ctx.files_changed = ["src/routes/health.py", "tests/test_health.py"]
    output = await _run_real_director(
        verify_director, "verify", ctx,
        llm_response={
            "qa_findings": ["All tests pass.", "No security issues detected."],
            "summary": "Build verified successfully.",
        },
    )
    assert isinstance(output, PhaseOutput)
    assert output.phase == "verify"
    assert output.context.qa_findings == ["All tests pass.", "No security issues detected."]
    assert "verify" in output.context.phase_history


@pytest.mark.anyio
async def test_verify_director_handles_empty_files_changed(tmp_path):
    ctx = ProjectContext(
        goal="Fix bug",
        request_type="bugfix",
        project_root=str(tmp_path),
    )
    output = await _run_real_director(
        verify_director, "verify", ctx,
        llm_response={
            "qa_findings": ["No files were changed."],
            "summary": "Nothing to verify.",
        },
    )
    assert output.context.qa_findings == ["No files were changed."]
