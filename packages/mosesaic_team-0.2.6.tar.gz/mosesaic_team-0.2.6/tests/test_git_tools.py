from __future__ import annotations
import subprocess
from mosesaic.team.tools.git import GitTools


def test_status_clean_repo(git):
    status = git.status()
    assert isinstance(status, str)
    assert "nothing to commit" in status.lower() or "clean" in status.lower()


def test_status_shows_modified_files(git, git_repo):
    (git_repo / "file.py").write_text("x = 2\n")
    status = git.status()
    assert "file.py" in status


def test_diff_empty_on_clean_repo(git):
    diff = git.diff()
    assert diff == "" or diff.strip() == ""


def test_diff_shows_changes(git, git_repo):
    (git_repo / "file.py").write_text("x = 2\ny = 3\n")
    diff = git.diff()
    assert "+x = 2" in diff or "x = 2" in diff


def test_log_returns_commits(git):
    log = git.log(max_entries=5)
    assert "initial commit" in log


def test_log_respects_max_entries(git, git_repo):
    for i in range(3):
        (git_repo / f"f{i}.py").write_text(f"x = {i}")
        subprocess.run(["git", "add", "."], cwd=git_repo, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", f"commit {i}"],
            cwd=git_repo, capture_output=True
        )
    log = git.log(max_entries=2)
    lines = [line for line in log.strip().splitlines() if line.strip()]
    assert len(lines) <= 2


def test_write_operations_now_exposed(git):
    """Write operations are now exposed with injection-safe subprocess list form."""
    assert hasattr(git, "commit")
    assert hasattr(git, "push")
    assert hasattr(git, "add")
    assert hasattr(git, "create_pr")
