from mosesaic.team.budget.tiers import TaskTier, TierConfig, TIER_CONFIG


def test_all_tiers_present():
    assert TaskTier.SIMPLE in TIER_CONFIG
    assert TaskTier.MEDIUM in TIER_CONFIG
    assert TaskTier.COMPLEX in TIER_CONFIG


def test_tier_config_has_required_fields():
    for tier, config in TIER_CONFIG.items():
        assert isinstance(config, TierConfig)
        assert len(config.preferred_providers) > 0
        assert config.max_cost_per_call_usd >= 0


def test_simple_tier_prefers_free_providers():
    cfg = TIER_CONFIG[TaskTier.SIMPLE]
    assert "ollama" in cfg.preferred_providers or "groq" in cfg.preferred_providers


def test_complex_tier_allows_expensive_models():
    simple_max = TIER_CONFIG[TaskTier.SIMPLE].max_cost_per_call_usd
    complex_max = TIER_CONFIG[TaskTier.COMPLEX].max_cost_per_call_usd
    assert complex_max > simple_max


def test_tier_from_string():
    assert TaskTier("simple") == TaskTier.SIMPLE
    assert TaskTier("medium") == TaskTier.MEDIUM
    assert TaskTier("complex") == TaskTier.COMPLEX
