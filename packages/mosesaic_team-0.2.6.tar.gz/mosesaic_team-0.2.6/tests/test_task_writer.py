from __future__ import annotations
import json
import pytest
from pathlib import Path
from mosesaic.core.spawner import Spawner
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.team.budget.manager import BudgetManager
from mosesaic.team.project.state import ProjectState
from mosesaic.team.agents.protocol import TeamTask, TeamResponse
from mosesaic.team.agents.task_writer import task_writer_agent


def _make_ollama_mock(response_json: str) -> MockProvider:
    """Mock provider named 'ollama' — matches SIMPLE tier preference."""
    caps = {"free-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class OllamaMock(MockProvider):
        @property
        def name(self) -> str:
            return "ollama"

    return OllamaMock(responses={"free-model": response_json}, capabilities=caps)


def _make_budget(provider) -> BudgetManager:
    r = ProviderRegistry()
    r.register(provider)
    return BudgetManager(registry=r, sprint_budget_usd=5.0)


@pytest.mark.anyio
async def test_task_writer_returns_tasks(tmp_path):
    mock_response = json.dumps([
        {"title": "Add JWT auth", "description": "Implement JWT middleware", "tier": "medium"},
        {"title": "Write auth tests", "description": "Unit tests for JWT", "tier": "simple"},
    ])
    provider = _make_ollama_mock(mock_response)
    budget_mgr = _make_budget(provider)
    state = ProjectState(tmp_path)

    task = TeamTask(
        request="Build a login page with JWT auth",
        project_root=tmp_path,
        budget_manager=budget_mgr,
        project_state=state,
    )
    spawner = Spawner()
    result: TeamResponse = await spawner.spawn(task_writer_agent, task, timeout=10.0)

    assert isinstance(result, TeamResponse)
    assert result.success
    assert len(result.tasks) == 2
    assert result.tasks[0].title == "Add JWT auth"
    assert result.tasks[1].tier == "simple"


@pytest.mark.anyio
async def test_task_writer_saves_tasks_to_state(tmp_path):
    mock_response = json.dumps([
        {"title": "Task A", "description": "Do A", "tier": "medium"},
    ])
    budget_mgr = _make_budget(_make_ollama_mock(mock_response))
    state = ProjectState(tmp_path)

    task = TeamTask(request="Feature X", project_root=tmp_path,
                    budget_manager=budget_mgr, project_state=state)
    spawner = Spawner()
    await spawner.spawn(task_writer_agent, task, timeout=10.0)

    saved = state.get_tasks()
    assert len(saved) == 1
    assert saved[0].title == "Task A"


@pytest.mark.anyio
async def test_task_writer_handles_malformed_json(tmp_path):
    provider = _make_ollama_mock("this is not valid json")
    budget_mgr = _make_budget(provider)
    state = ProjectState(tmp_path)

    task = TeamTask(request="Feature", project_root=tmp_path,
                    budget_manager=budget_mgr, project_state=state)
    spawner = Spawner()
    result: TeamResponse = await spawner.spawn(task_writer_agent, task, timeout=10.0)

    assert isinstance(result, TeamResponse)
    assert not result.success
    assert result.error != ""


@pytest.mark.anyio
async def test_task_writer_records_spend(tmp_path):
    mock_response = json.dumps([{"title": "T", "description": "D", "tier": "simple"}])
    budget_mgr = _make_budget(_make_ollama_mock(mock_response))
    state = ProjectState(tmp_path)

    task = TeamTask(request="x", project_root=tmp_path,
                    budget_manager=budget_mgr, project_state=state)
    spawner = Spawner()
    await spawner.spawn(task_writer_agent, task, timeout=10.0)

    assert state.budget_spent == pytest.approx(0.0)  # mock is free; record_spend was called with 0.0
    assert len(_get_provider_from(budget_mgr).calls) == 1


def _get_provider_from(budget_mgr: BudgetManager) -> MockProvider:
    for _, provider, _ in budget_mgr._registry.iter_models():
        return provider
