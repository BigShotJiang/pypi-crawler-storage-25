"""Tests for sprint_task_workflow — developer → QA → (retry) → scribe."""
from __future__ import annotations
import pytest
from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.team.project.task import SprintTask
from mosesaic.team.sprint.protocol import (
    SprintDeveloperInput, SprintDeveloperOutput,
    QAInput, QAOutput, ScribeInput, ScribeOutput,
)
from mosesaic.team.sprint.workflow import sprint_task_workflow
from mosesaic.workflow import WorkflowRuntime


def _make_runtime(*extra_agents) -> WorkflowRuntime:
    runtime = WorkflowRuntime()
    for a in extra_agents:
        runtime.register_agent(a)
    runtime.register_workflow(sprint_task_workflow)
    return runtime


@pytest.mark.anyio
async def test_sprint_workflow_completes_on_first_qa_pass(tmp_path):
    @agent(name="developer")
    async def mock_dev(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        payload: SprintDeveloperInput = msg.payload
        await ctx.send(msg.from_agent, SprintDeveloperOutput(
            task_id=str(payload.task.id), summary="implemented the feature",
        ))

    @agent(name="qa")
    async def mock_qa(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send(msg.from_agent, QAOutput(
            passed=True, confidence="VERIFIED", feedback="tests pass",
        ))

    @agent(name="scribe")
    async def mock_scribe(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        payload: ScribeInput = msg.payload
        await ctx.send(msg.from_agent, ScribeOutput(
            summary="Feature implemented and verified.",
            confidence=payload.qa_output.confidence,
        ))

    task = SprintTask(title="Add feature", description="Build X", tier="simple")
    input_payload = SprintDeveloperInput(task=task, project_root=str(tmp_path))

    result = await _make_runtime(mock_dev, mock_qa, mock_scribe).run(
        "sprint-task", input=input_payload
    )

    assert result.status == "completed"
    scribe_output: ScribeOutput = result.output
    assert scribe_output.confidence == "VERIFIED"
    assert len(scribe_output.summary) > 0


@pytest.mark.anyio
async def test_sprint_workflow_retries_when_qa_fails(tmp_path):
    dev_call_count = 0
    qa_call_count = 0

    @agent(name="developer")
    async def mock_dev(ctx: AgentContext) -> None:
        nonlocal dev_call_count
        dev_call_count += 1
        msg = await ctx.receive()
        payload: SprintDeveloperInput = msg.payload
        await ctx.send(msg.from_agent, SprintDeveloperOutput(
            task_id=str(payload.task.id),
            summary=f"attempt {dev_call_count}",
        ))

    @agent(name="qa")
    async def mock_qa(ctx: AgentContext) -> None:
        nonlocal qa_call_count
        qa_call_count += 1
        msg = await ctx.receive()
        passed = qa_call_count >= 2  # fail first attempt, pass second
        await ctx.send(msg.from_agent, QAOutput(
            passed=passed,
            confidence="VERIFIED" if passed else "UNTESTED",
            feedback="" if passed else "Fix the null pointer.",
        ))

    @agent(name="scribe")
    async def mock_scribe(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        payload: ScribeInput = msg.payload
        await ctx.send(msg.from_agent, ScribeOutput(
            summary="done", confidence=payload.qa_output.confidence,
        ))

    task = SprintTask(title="Add feature", description="Build X", tier="simple")
    input_payload = SprintDeveloperInput(task=task, project_root=str(tmp_path))

    result = await _make_runtime(mock_dev, mock_qa, mock_scribe).run(
        "sprint-task", input=input_payload
    )

    assert result.status == "completed"
    assert dev_call_count == 2
    assert qa_call_count == 2
    assert result.output.confidence == "VERIFIED"


@pytest.mark.anyio
async def test_sprint_workflow_fails_after_max_retries(tmp_path):
    @agent(name="developer")
    async def mock_dev(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        payload: SprintDeveloperInput = msg.payload
        await ctx.send(msg.from_agent, SprintDeveloperOutput(
            task_id=str(payload.task.id), summary="broken implementation",
        ))

    @agent(name="qa")
    async def mock_qa(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send(msg.from_agent, QAOutput(
            passed=False, confidence="UNTESTED", feedback="still broken",
        ))

    @agent(name="scribe")
    async def mock_scribe(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        payload: ScribeInput = msg.payload
        await ctx.send(msg.from_agent, ScribeOutput(
            summary="", confidence=payload.qa_output.confidence,
        ))

    task = SprintTask(title="Always fails", description="Cannot be fixed", tier="simple")
    input_payload = SprintDeveloperInput(task=task, project_root=str(tmp_path))

    result = await _make_runtime(mock_dev, mock_qa, mock_scribe).run(
        "sprint-task", input=input_payload
    )

    assert result.status == "failed"
