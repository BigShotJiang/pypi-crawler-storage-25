from __future__ import annotations
import pytest
from pathlib import Path
from mosesaic.team.project.state import ProjectState
from mosesaic.team.project.task import SprintTask, TaskStatus


@pytest.fixture
def state(tmp_path):
    return ProjectState(project_root=tmp_path)


def test_initial_state_empty(state):
    assert state.goal == ""
    assert state.get_tasks() == []
    assert state.budget_spent == 0.0


def test_set_goal_persists(tmp_path):
    s = ProjectState(tmp_path)
    s.goal = "Build login feature"
    s2 = ProjectState(tmp_path)
    assert s2.goal == "Build login feature"


def test_add_task_persists(tmp_path):
    s = ProjectState(tmp_path)
    t = SprintTask(title="Auth", description="Add OAuth", tier="medium")
    s.add_task(t)
    s2 = ProjectState(tmp_path)
    tasks = s2.get_tasks()
    assert len(tasks) == 1
    assert tasks[0].title == "Auth"


def test_update_task(state):
    t = SprintTask(title="Auth", description="Add OAuth", tier="medium")
    state.add_task(t)
    t.status = TaskStatus.DONE
    t.result = "Implemented"
    state.update_task(t)
    tasks = state.get_tasks()
    assert tasks[0].status == TaskStatus.DONE
    assert tasks[0].result == "Implemented"


def test_record_spend_accumulates(state):
    state.record_spend(0.05)
    state.record_spend(0.10)
    assert abs(state.budget_spent - 0.15) < 1e-9


def test_clear_resets_all(state):
    state.goal = "Build something"
    state.add_task(SprintTask(title="x", description="y", tier="simple"))
    state.record_spend(1.0)
    state.clear()
    assert state.goal == ""
    assert state.get_tasks() == []
    assert state.budget_spent == 0.0


def test_state_file_in_mosesaic_dir(tmp_path):
    s = ProjectState(tmp_path)
    s.goal = "Test"
    assert (tmp_path / ".mosesaic" / "state.json").exists()


def test_update_task_unknown_id_raises(state):
    import pytest
    t = SprintTask(title="Ghost", description="Not in state", tier="simple")
    with pytest.raises(KeyError):
        state.update_task(t)
