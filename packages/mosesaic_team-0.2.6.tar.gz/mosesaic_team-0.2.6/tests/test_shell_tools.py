from __future__ import annotations
import pytest
from mosesaic.team.tools.shell import ShellTools, ShellResult


@pytest.fixture
def sh(tmp_path):
    return ShellTools(project_root=tmp_path)


def test_run_simple_command(sh):
    result = sh.run("echo hello")
    assert result.exit_code == 0
    assert "hello" in result.stdout


def test_run_returns_shell_result(sh):
    result = sh.run("echo hi")
    assert isinstance(result, ShellResult)
    assert isinstance(result.stdout, str)
    assert isinstance(result.stderr, str)
    assert isinstance(result.exit_code, int)


def test_run_captures_stderr(sh):
    result = sh.run("echo err >&2", shell=True)
    assert result.exit_code == 0


def test_run_nonzero_exit_code(sh):
    result = sh.run("exit 1", shell=True)
    assert result.exit_code == 1


def test_run_in_project_dir(sh, tmp_path):
    (tmp_path / "marker.txt").write_text("found")
    result = sh.run("cat marker.txt")
    assert result.exit_code == 0
    assert "found" in result.stdout


def test_blocked_command_raises(sh):
    with pytest.raises(PermissionError, match="blocked"):
        sh.run("rm -rf /")


def test_blocked_sudo_raises(sh):
    with pytest.raises(PermissionError, match="blocked"):
        sh.run("sudo apt install something")


def test_timeout_raises(sh):
    with pytest.raises(TimeoutError):
        sh.run("sleep 10", timeout_seconds=0.1)


def test_run_python_tests(sh, tmp_path):
    (tmp_path / "test_x.py").write_text("def test_ok(): assert 1 + 1 == 2")
    result = sh.run("python -m pytest test_x.py -q")
    assert result.exit_code == 0
    assert "passed" in result.stdout
