from __future__ import annotations
import pytest
from mosesaic.team.orchestrator.protocol import PhaseInput, PhaseOutput, OrchestrateResult, RunLogEntry
from mosesaic.team.orchestrator.context import ProjectContext


def _ctx(goal: str = "test goal", request_type: str = "feature") -> ProjectContext:
    return ProjectContext(goal=goal, request_type=request_type)


def test_phase_input_stores_context_and_phase():
    ctx = _ctx()
    inp = PhaseInput(context=ctx, phase="build")
    assert inp.context is ctx
    assert inp.phase == "build"


def test_phase_output_stores_fields():
    ctx = _ctx()
    out = PhaseOutput(phase="build", summary="Built it.", context=ctx)
    assert out.phase == "build"
    assert out.summary == "Built it."
    assert out.context is ctx


def test_orchestrate_result_stores_all_fields():
    ctx = _ctx()
    result = OrchestrateResult(
        request_type="feature",
        phases_run=["build", "verify"],
        context=ctx,
        reasoning="Standard feature work.",
    )
    assert result.request_type == "feature"
    assert result.phases_run == ["build", "verify"]
    assert result.context is ctx
    assert "feature" in result.reasoning


def test_phase_input_requires_context_and_phase():
    """PhaseInput is a plain dataclass — missing args raise TypeError."""
    with pytest.raises(TypeError):
        PhaseInput()  # type: ignore[call-arg]


def test_orchestrate_result_phases_run_is_list():
    ctx = _ctx()
    result = OrchestrateResult(
        request_type="bugfix",
        phases_run=[],
        context=ctx,
        reasoning="",
    )
    assert isinstance(result.phases_run, list)


def test_run_log_entry_stores_fields():
    entry = RunLogEntry(phase="clarify", summary="Done.", cost_usd=0.012)
    assert entry.phase == "clarify"
    assert entry.summary == "Done."
    assert entry.cost_usd == 0.012


def test_phase_output_has_cost_usd_default():
    ctx = _ctx()
    out = PhaseOutput(phase="build", summary="Built.", context=ctx)
    assert out.cost_usd == 0.0


def test_phase_output_accepts_cost_usd():
    ctx = _ctx()
    out = PhaseOutput(phase="build", summary="Built.", context=ctx, cost_usd=0.05)
    assert out.cost_usd == 0.05


def test_orchestrate_result_has_run_log_and_total_cost():
    ctx = _ctx()
    entry = RunLogEntry(phase="build", summary="Built.", cost_usd=0.03)
    result = OrchestrateResult(
        request_type="feature",
        phases_run=["build"],
        context=ctx,
        reasoning="Standard.",
        run_log=[entry],
        total_cost_usd=0.03,
    )
    assert len(result.run_log) == 1
    assert result.run_log[0].phase == "build"
    assert result.total_cost_usd == 0.03


def test_orchestrate_result_run_log_defaults_empty():
    ctx = _ctx()
    result = OrchestrateResult(
        request_type="feature",
        phases_run=[],
        context=ctx,
        reasoning="",
    )
    assert result.run_log == []
    assert result.total_cost_usd == 0.0
