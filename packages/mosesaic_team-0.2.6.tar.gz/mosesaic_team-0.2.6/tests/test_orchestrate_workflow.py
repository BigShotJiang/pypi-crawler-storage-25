"""Integration test: full orchestrate workflow with stub phases + mock LLM."""
from __future__ import annotations
import json
import pytest
from mosesaic.team.orchestrator.workflow import orchestrate_workflow
from mosesaic.team.orchestrator.director import DirectorInput, chief_director
from mosesaic.team.orchestrator.directors import (
    clarify_director,
    architect_director,
    deploy_director,
    monitor_director,
    build_director,
    verify_director,
)
from mosesaic.team.orchestrator.protocol import OrchestrateResult, RunLogEntry
from mosesaic.workflow.runtime import WorkflowRuntime
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.llm.provider import Capabilities


def _make_workflow_runtime(chief_response: dict) -> WorkflowRuntime:
    """WorkflowRuntime with MockProvider returning chief_response for all LLM calls.

    Use only stub phases (clarify, architect, deploy, monitor) in chief_response
    so the mock is only consumed by chief_director (stub directors don't call LLM).
    """
    caps = {"mock-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class _FixedMock(MockProvider):
        @property
        def name(self) -> str:
            return "fixed-mock"

        def all_models(self):
            return caps

    provider = _FixedMock(capabilities=caps)
    provider._next_response = json.dumps(chief_response)

    registry = ProviderRegistry()
    registry.register(provider)

    rt = WorkflowRuntime(llm=registry)
    rt.register_agent(chief_director)
    rt.register_agent(clarify_director)
    rt.register_agent(architect_director)
    rt.register_agent(build_director)
    rt.register_agent(verify_director)
    rt.register_agent(deploy_director)
    rt.register_agent(monitor_director)
    rt.register_workflow(orchestrate_workflow)
    return rt


@pytest.mark.anyio
async def test_workflow_returns_orchestrate_result():
    rt = _make_workflow_runtime({
        "request_type": "feature",
        "phases": ["clarify", "architect"],
        "reasoning": "Needs clarification and design.",
    })
    wf_result = await rt.run("orchestrate", DirectorInput(prompt="Add a health check endpoint"))
    assert wf_result.status == "completed"
    result: OrchestrateResult = wf_result.output
    assert isinstance(result, OrchestrateResult)
    assert result.request_type == "feature"
    assert result.phases_run == ["clarify", "architect"]


@pytest.mark.anyio
async def test_workflow_phase_history_reflects_executed_phases():
    rt = _make_workflow_runtime({
        "request_type": "bugfix",
        "phases": ["clarify", "deploy"],
        "reasoning": "Direct fix and deploy.",
    })
    wf_result = await rt.run("orchestrate", DirectorInput(prompt="Fix a null pointer"))
    result: OrchestrateResult = wf_result.output
    assert result.context.phase_history == ["clarify", "deploy"]


@pytest.mark.anyio
async def test_workflow_goal_is_preserved_in_context():
    rt = _make_workflow_runtime({
        "request_type": "refactor",
        "phases": ["architect"],
        "reasoning": "Design-only refactor.",
    })
    wf_result = await rt.run("orchestrate", DirectorInput(prompt="Refactor auth module"))
    result: OrchestrateResult = wf_result.output
    assert result.context.goal == "Refactor auth module"


@pytest.mark.anyio
async def test_workflow_propagates_reasoning():
    rt = _make_workflow_runtime({
        "request_type": "feature",
        "phases": ["clarify"],
        "reasoning": "Ambiguous requirements need clarification.",
    })
    wf_result = await rt.run("orchestrate", DirectorInput(prompt="Add something"))
    result: OrchestrateResult = wf_result.output
    assert "clarif" in result.reasoning.lower()


@pytest.mark.anyio
async def test_workflow_run_log_has_one_entry_per_phase():
    rt = _make_workflow_runtime({
        "request_type": "feature",
        "phases": ["clarify", "architect"],
        "reasoning": "Needs clarification and design.",
    })
    wf_result = await rt.run("orchestrate", DirectorInput(prompt="Add health check"))
    result: OrchestrateResult = wf_result.output
    assert len(result.run_log) == 2
    assert result.run_log[0].phase == "clarify"
    assert result.run_log[1].phase == "architect"
    assert all(isinstance(e, RunLogEntry) for e in result.run_log)


@pytest.mark.anyio
async def test_workflow_total_cost_usd_is_sum_of_phases():
    rt = _make_workflow_runtime({
        "request_type": "feature",
        "phases": ["clarify", "architect"],
        "reasoning": "Needs design.",
    })
    wf_result = await rt.run("orchestrate", DirectorInput(prompt="Add health check"))
    result: OrchestrateResult = wf_result.output
    expected_total = sum(e.cost_usd for e in result.run_log)
    assert result.total_cost_usd == expected_total


@pytest.mark.anyio
async def test_workflow_run_log_empty_when_no_phases():
    rt = _make_workflow_runtime({
        "request_type": "feature",
        "phases": [],
        "reasoning": "Nothing to do.",
    })
    wf_result = await rt.run("orchestrate", DirectorInput(prompt="No-op"))
    result: OrchestrateResult = wf_result.output
    assert result.run_log == []
    assert result.total_cost_usd == 0.0
