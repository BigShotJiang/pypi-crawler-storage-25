"""Tests for sprint execution agents — developer, qa, scribe."""
from __future__ import annotations
import pytest
from mosesaic.core.spawner import Spawner
from mosesaic.core.cost import CostTracker
from mosesaic.llm.context import LLMContext
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.team.project.task import SprintTask
from mosesaic.team.sprint.protocol import (
    SprintDeveloperInput, SprintDeveloperOutput,
    QAInput, QAOutput, ScribeInput, ScribeOutput,
)
from mosesaic.team.sprint.agents import sprint_developer_agent, qa_agent, scribe_agent


def _make_spawner(response: str = "ok") -> tuple[Spawner, MockProvider]:
    """Spawner wired to a MockProvider that returns a fixed response."""
    provider = MockProvider(
        responses={"mock-cheap": response},
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
        },
        input_tokens=10,
        output_tokens=10,
    )
    registry = ProviderRegistry()
    registry.register(provider)

    def llm_factory(agent_name: str, cost_tracker: CostTracker, system_prompt: str | None = None):
        return LLMContext(
            registry=registry,
            cost_tracker=cost_tracker,
            agent_name=agent_name,
            system_prompt=system_prompt,
        )

    return Spawner(llm_factory=llm_factory), provider


@pytest.mark.anyio
async def test_sprint_developer_sends_output(tmp_path):
    spawner, _ = _make_spawner("Created src/hello.py with a greeting function.")
    task = SprintTask(title="Add greeting", description="Create a greeting function", tier="simple")
    payload = SprintDeveloperInput(task=task, project_root=str(tmp_path))

    result = await spawner.spawn(sprint_developer_agent, payload)

    assert isinstance(result, SprintDeveloperOutput)
    assert result.task_id == str(task.id)
    assert "greeting" in result.summary.lower()


@pytest.mark.anyio
async def test_qa_agent_without_project_root_returns_reviewed():
    spawner, _ = _make_spawner("Code looks correct.")
    dev_output = SprintDeveloperOutput(task_id="t1", summary="added feature")
    payload = QAInput(developer_output=dev_output, project_root="")

    result = await spawner.spawn(qa_agent, payload)

    assert isinstance(result, QAOutput)
    assert result.confidence == "REVIEWED"
    assert result.passed is True


@pytest.mark.anyio
async def test_qa_agent_with_failing_tests_returns_untested(tmp_path):
    (tmp_path / "test_fail.py").write_text("def test_bad(): assert False\n")
    spawner, _ = _make_spawner("ok")
    dev_output = SprintDeveloperOutput(task_id="t1", summary="broken feature")
    payload = QAInput(developer_output=dev_output, project_root=str(tmp_path))

    result = await spawner.spawn(qa_agent, payload)

    assert result.confidence == "UNTESTED"
    assert result.passed is False
    assert "test_bad" in result.test_output


@pytest.mark.anyio
async def test_qa_agent_with_passing_tests_returns_verified(tmp_path):
    (tmp_path / "test_ok.py").write_text("def test_pass(): assert True\n")
    spawner, _ = _make_spawner("Implementation looks good.")
    dev_output = SprintDeveloperOutput(task_id="t1", summary="working feature")
    payload = QAInput(developer_output=dev_output, project_root=str(tmp_path))

    result = await spawner.spawn(qa_agent, payload)

    assert result.confidence == "VERIFIED"
    assert result.passed is True


@pytest.mark.anyio
async def test_scribe_agent_sends_output():
    spawner, _ = _make_spawner("Added greeting function to src/hello.py. Tests pass.")
    task = SprintTask(title="Add greeting", description="Create greeting", tier="simple")
    dev_output = SprintDeveloperOutput(task_id=str(task.id), summary="created greeting.py")
    qa_output = QAOutput(passed=True, confidence="VERIFIED", feedback="All good.")
    payload = ScribeInput(developer_output=dev_output, qa_output=qa_output, task=task)

    result = await spawner.spawn(scribe_agent, payload)

    assert isinstance(result, ScribeOutput)
    assert result.confidence == "VERIFIED"
    assert len(result.summary) > 0
