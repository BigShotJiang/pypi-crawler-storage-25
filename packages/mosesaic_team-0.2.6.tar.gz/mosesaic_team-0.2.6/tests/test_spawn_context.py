"""Tests for SpawnContext.to_prompt()."""
from __future__ import annotations

import pytest
from mosesaic.team.prompt.spawn_context import SpawnContext


def test_to_prompt_includes_task_header():
    ctx = SpawnContext(role="analyst", task_description="Extract requirements.")
    assert "## Your Task" in ctx.to_prompt()
    assert "Extract requirements." in ctx.to_prompt()


def test_to_prompt_all_sections_present():
    ctx = SpawnContext(
        role="analyst",
        task_description="Extract requirements from the goal.",
        in_scope=["Acceptance criteria", "Constraints"],
        out_of_scope=["Solution design"],
        checklist=["Read the goal", "Write criteria"],
        acceptance_criteria=["Criteria are testable"],
        constraints=["No invented requirements"],
    )
    prompt = ctx.to_prompt()
    assert "## Scope" in prompt
    assert "**In scope:**" in prompt
    assert "- Acceptance criteria" in prompt
    assert "**Out of scope:**" in prompt
    assert "- Solution design" in prompt
    assert "## Checklist" in prompt
    assert "- [ ] Read the goal" in prompt
    assert "- [ ] Write criteria" in prompt
    assert "## Acceptance Criteria" in prompt
    assert "- Criteria are testable" in prompt
    assert "## Constraints" in prompt
    assert "- No invented requirements" in prompt


def test_to_prompt_empty_lists_omit_sections():
    ctx = SpawnContext(role="analyst", task_description="Simple task.")
    prompt = ctx.to_prompt()
    assert "## Your Task" in prompt
    assert "## Scope" not in prompt
    assert "## Checklist" not in prompt
    assert "## Acceptance Criteria" not in prompt
    assert "## Constraints" not in prompt


def test_to_prompt_checklist_items_have_checkbox():
    ctx = SpawnContext(
        role="developer",
        task_description="Build thing.",
        checklist=["Step one", "Step two"],
    )
    prompt = ctx.to_prompt()
    assert "- [ ] Step one" in prompt
    assert "- [ ] Step two" in prompt


def test_to_prompt_in_scope_only_no_out_of_scope():
    ctx = SpawnContext(
        role="analyst",
        task_description="Task.",
        in_scope=["Thing A"],
    )
    prompt = ctx.to_prompt()
    assert "## Scope" in prompt
    assert "**In scope:**" in prompt
    assert "**Out of scope:**" not in prompt


def test_to_prompt_out_of_scope_only():
    ctx = SpawnContext(
        role="analyst",
        task_description="Task.",
        out_of_scope=["Thing B"],
    )
    prompt = ctx.to_prompt()
    assert "## Scope" in prompt
    assert "**Out of scope:**" in prompt
    assert "**In scope:**" not in prompt


# ── Integration: spawn_context flows into user_message ────────────────────────

from mosesaic.team.agents.analyst import AnalystInput


def test_analyst_input_accepts_spawn_context():
    """AnalystInput must accept an optional spawn_context field."""
    ctx = SpawnContext(role="analyst", task_description="Do thing.")
    inp = AnalystInput(goal="Build X", spawn_context=ctx)
    assert inp.spawn_context is ctx


def test_analyst_input_spawn_context_defaults_none():
    """spawn_context defaults to None for backward compatibility."""
    inp = AnalystInput(goal="Build X")
    assert inp.spawn_context is None


# ── Directors pass SpawnContext to specialists ─────────────────────────────────

from mosesaic.team.agents.devops import DevopsInput
from mosesaic.team.agents.observer import ObserverInput
from mosesaic.team.agents.architect import ArchitectInput


def test_devops_input_accepts_spawn_context():
    ctx = SpawnContext(role="devops", task_description="Assess deployment.")
    inp = DevopsInput(goal="Deploy X", spawn_context=ctx)
    assert inp.spawn_context is ctx


def test_observer_input_accepts_spawn_context():
    ctx = SpawnContext(role="observer", task_description="Monitor deployment.")
    inp = ObserverInput(goal="Monitor X", deployment_state="staging", spawn_context=ctx)
    assert inp.spawn_context is ctx


def test_architect_input_accepts_spawn_context():
    ctx = SpawnContext(role="architect_agent", task_description="Design X.")
    inp = ArchitectInput(goal="Build X", spawn_context=ctx)
    assert inp.spawn_context is ctx
