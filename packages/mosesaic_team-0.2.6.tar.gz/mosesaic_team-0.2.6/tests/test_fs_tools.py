from __future__ import annotations
import pytest
from pathlib import Path
from mosesaic.team.tools.fs import FileSystemTools


@pytest.fixture
def root(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("print('hello')")
    (tmp_path / "README.md").write_text("# My Project")
    return tmp_path


@pytest.fixture
def fs(root):
    return FileSystemTools(project_root=root)


def test_read_file(fs, root):
    content = fs.read_file("src/main.py")
    assert content == "print('hello')"


def test_read_file_not_found(fs):
    with pytest.raises(FileNotFoundError):
        fs.read_file("nonexistent.py")


def test_read_file_outside_root(fs, tmp_path):
    with pytest.raises(PermissionError, match="outside project root"):
        fs.read_file("../secret.txt")


def test_write_file_creates_file(fs, root):
    fs.write_file("src/new.py", "x = 1")
    assert (root / "src" / "new.py").read_text() == "x = 1"


def test_write_file_creates_parent_dirs(fs, root):
    fs.write_file("src/utils/helpers.py", "def foo(): pass")
    assert (root / "src" / "utils" / "helpers.py").exists()


def test_write_file_outside_root(fs):
    with pytest.raises(PermissionError, match="outside project root"):
        fs.write_file("../evil.sh", "rm -rf /")


def test_list_files_returns_relative_paths(fs):
    files = fs.list_files("src")
    assert "src/main.py" in files


def test_list_files_with_pattern(fs, root):
    (root / "src" / "test_main.py").write_text("def test(): pass")
    files = fs.list_files("src", pattern="test_*.py")
    assert all("test_" in f for f in files)
    assert "src/main.py" not in files


def test_list_files_outside_root(fs):
    with pytest.raises(PermissionError, match="outside project root"):
        fs.list_files("../../etc")


def test_search_files_finds_content(fs, root):
    (root / "src" / "api.py").write_text("def get_user(): return None")
    results = fs.search_files("get_user")
    assert any("api.py" in r["file"] for r in results)
    assert any("get_user" in r["line"] for r in results)


def test_search_files_returns_line_numbers(fs):
    results = fs.search_files("hello")
    assert all("line_number" in r for r in results)
    assert results[0]["line_number"] == 1
