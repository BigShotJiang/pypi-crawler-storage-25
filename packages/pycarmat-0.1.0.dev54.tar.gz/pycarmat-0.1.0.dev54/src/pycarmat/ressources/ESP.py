import time
import logging

from numpy import sqrt
from serial import SerialException
from enum import Enum
import pyvisa


class UNIT(Enum):
    """
    Enumeration for different motion units supported by the ESP300 controller.
    """
    ENCODER_COUNT = '00'
    MOTOR_STEP = '01'
    TRANSLATION_MM = '02'
    TRANSLATION_UM = '03'
    ROTATION_DEG = '07'
    ROTATION_RAD = '09'
    ROTATION_MRAD = '10'
    ROTATION_URAD = '11'


def get_motion_time(delta: float, motion_param: tuple[float, float, float]) -> float:
    """
    Compute the estimated time required for a motion based on distance
    and trapezoidal/triangular motion profile parameters.

    Args:
        delta (float): The distance to travel.
        motion_param (tuple[float, float, float]):
            A tuple (v, a, d) containing:
                v: maximum velocity
                a: acceleration
                d: deceleration

    Returns:
        float: Estimated time in seconds to complete the motion,
               including a 0.5s buffer.
    """
    v, a, d = motion_param

    # Total distance required for full acceleration and deceleration
    va = v * v / 2 * (1/a + 1/d)

    if delta > va:
        # Trapezoidal profile: acceleration → constant speed → deceleration
        t_acc = v / a
        t_dec = v / d
        t_flat = (delta - va) / v
        return t_acc + t_flat + t_dec + 0.5
    else:
        # Triangular profile: acceleration → deceleration (never reaches max speed)
        vm = sqrt(2 * delta / (1/a + 1/d))
        return vm / a + vm / d + 0.5


class ESP30xController:
    """
    A controller class for interfacing with the Newport ESP30x motion controller via serial communication.

    This class provides methods to control motorized stages, move axes to absolute or relative positions,
    and perform homing operations.
    """

    @staticmethod
    def detect(get_info: bool = False, connection_type: str = 'serial'):
        """
        Detects available ESP30x controllers connected via serial ports or USB.

        Args:
            get_info (bool): If True, returns detailed resource information; otherwise, returns resource names only.
            connection_type (str): Type of connection to detect ('serial' or 'usb'). Default is 'serial'.

        Returns:
            list or dict: A list of available resources or a dictionary with detailed information.
        """
        rm = pyvisa.ResourceManager()
        if connection_type.lower() == 'usb':
            pattern = 'USB?*::INSTR'
        else:
            pattern = 'ASRL?*::INSTR'

        if get_info:
            return rm.list_resources_info(pattern)
        else:
            return rm.list_resources(pattern)

    def __init__(self, port: str = 'ASRL1', raise_error: bool = True, connection_type: str = 'serial'):
        """
        Initializes the ESP30xController instance. The serial port can be retrieved by using ESP30xController.detect().

        Args:
            port (str): The port to connect to the ESP30x device (default is 'ASRL1').
            raise_error (bool): If True, exceptions are raised for connection errors; otherwise, errors are logged.
            connection_type (str): Type of connection ('serial' or 'usb'). Default is 'serial'.
        """
        self.esp301 = None
        self._port = port
        self._connection_type = connection_type.lower()
        self._baud_rate = 19200  # The ESP300 operates at a fixed baud rate of 19200.
        self._raise_error = raise_error

    def __enter__(self):
        """
        Establishes a connection to the ESP30x when entering a context.

        Returns:
            ESP30xController: The current instance, allowing the use of 'with ESP300Controller() as esp:'.

        Raises:
            SerialException: If the serial connection cannot be established (unless raise_error is False).
        """
        try:
            rm = pyvisa.ResourceManager()
            resource_name = self._port if '::INSTR' in self._port else f'{self._port}::INSTR'

            if self._connection_type == 'usb':
                # USB connection - no baud rate needed
                self.esp301 = rm.open_resource(resource_name)
            else:
                self.esp301 = rm.open_resource(resource_name,
                                               resource_pyclass=pyvisa.resources.SerialInstrument,
                                               baud_rate=self._baud_rate)
                self.esp301.baud_rate = self._baud_rate
            self.esp301.read_termination = '\r'
        except SerialException as e:
            logging.error(f"Failed to connect to ESP300: {e}")
            if self._raise_error:
                raise
        return self

    def __exit__(self, *exc):
        """
        Closes the connection when exiting the context manager.
        """
        if self.esp301 is not None:
            self.esp301.close()

    def get_motion_parameters(self, axis) -> tuple[float, float, float]:
        """
        Retrieves the motion parameters for the specified axis.

        Args:
            axis (int): The axis number to query.

        Returns:
            tuple[float, float, float]: A tuple containing (velocity, acceleration, deceleration) for the axis.
        """
        return float(self.query(f'{axis}VA?')), float(self.query(f'{axis}AC?')), float(self.query(f'{axis}AG?'))

    def set_motion_parameters(self, axis, parameters: tuple[float, float, float]) -> None:
        """
        Set the motion parameters for the specified axis.

        Args:
            axis (int): The axis number to query.
            parameters (tuple[float, float, float]): A tuple containing (velocity, acceleration, deceleration) for the axis.
        """
        v, a, d = parameters
        self.write(f'{axis}VA{v:.2f}')
        self.write(f'{axis}AC{a:.2f}')
        self.write(f'{axis}AG{d:.2f}')

    def connected(self):
        """
        Checks whether the controller is currently connected.

        Returns:
            bool: True if connected, False otherwise.
        """
        return self.esp301 is not None

    def clear_errors(self):
        """
        Clears all errors from the ESP30x controller by querying and resetting error codes.

        This method continuously queries the controller until no errors remain.
        """
        err = 1
        if self.esp301 is None:
            return
        while err != 0:
            err = int(self.esp301.query("TE?"))

    def get_motion_status(self, axis):
        """
        Queries the motion status of axis 1 to determine if it is currently moving.

        Returns:
            bool: True if the axis is moving, False if it is stationary.

        Raises:
            ValueError: If the response cannot be converted to an integer.
            SerialException: If there is a communication error with the device.
            TimeoutError: If the query times out waiting for a response.
        """
        return int(self.query(f"{axis}MD?")) == 0

    def write(self, command: str) -> None:
        """
        Sends a command to the ESP30x controller without expecting a response.

        Args:
            command (str): The command string to send.

        Note:
            This is an alias for send_command().
        """
        self.send_command(command)

    def send_command(self, command: str) -> None:
        """
        Sends a command to the ESP30x controller and retrieves the response.

        Args:
            command (str): The command string to send.

        Returns:
            str: The response received from the ESP30x device.
        """
        if self.esp301 is None:
            return
        self.esp301.write(command)

    def query(self, command: str) -> str:
        """
        Sends a query command to the ESP30x controller and returns the response.

        Args:
            command (str): The query command string to send.

        Returns:
            str: The response from the ESP30x device, or "Fail" if not connected.
        """
        if self.esp301 is None:
            return "Fail"
        return self.esp301.query(command)

    def _wait_for_completion(self, axis):
        is_moving = self.get_motion_status(axis)
        while is_moving:
            time.sleep(0.1)
            is_moving = self.get_motion_status(axis)
        time.sleep(0.5)

    def homing(self, axis: int) -> None:
        """
        Performs a homing operation on the specified axis.

        Args:
            axis (int): The axis number to home.

        This method enables the motor, initiates the homing procedure, waits for its completion,
        and then disables the motor.
        """
        self.send_command(f'{axis}MO')  # Enable motor
        self.send_command(f'{axis}OR')  # Start homing sequence
        self._wait_for_completion(axis)
        self.send_command(f'{axis}MF')  # Disable motor

    def move_absolute(self, axis: int, value: float, motion_unit: UNIT) -> None:
        """
        Moves the specified axis to an absolute position.

        Args:
            axis (int): The axis number to move.
            value (float): The target position.
            motion_unit (UNIT): The unit of motion (e.g., rotation degrees or translation millimeters).

        This method enables the motor, sets the motion unit, moves the axis to the target position,
        waits for completion, and then disables the motor.
        """
        # motion_params = self.get_motion_parameters(axis)
        current_value = float(self.query(f'{axis}TP?'))
        self.send_command(f'{axis}MO')  # Enable motor
        self.send_command(f'{axis}SN{motion_unit.value}')  # Set motion unit
        self.send_command(f'{axis}PA {value}')  # Move to absolute position
        # time.sleep(get_motion_time(abs(value - current_value), motion_params))
        self._wait_for_completion(axis)
        self.send_command(f'{axis}MF')  # Disable motor

    def move_relative(self, axis: int, value: float, motion_unit: UNIT) -> None:
        """
        Moves the specified axis by a relative amount from its current position.

        Args:
            axis (int): The axis number to move.
            value (float): The relative movement amount.
            motion_unit (UNIT): The unit of motion (e.g., rotation degrees or translation millimeters).

        This method enables the motor, sets the motion unit, moves the axis by the specified amount,
        waits for completion, and then disables the motor.
        """
        # motion_params = self.get_motion_parameters(axis)
        self.send_command(f'{axis}MO')  # Enable motor
        self.send_command(f'{axis}SN{motion_unit.value}')  # Set motion unit
        self.send_command(f'{axis}PR {value}')  # Move relative to current position
        # time.sleep(get_motion_time(value, motion_params))
        self._wait_for_completion(axis)
        self.send_command(f'{axis}MF')  # Disable motor


if __name__ == '__main__':
    """
    Example usage of the ESP30xController class.
    """
    print(ESP30xController.detect())

    with ESP30xController(raise_error=False) as esp:
        esp.clear_errors()

        # homing
        esp.homing(axis=1)

        # Set platform rotation to +10 deg
        esp.move_absolute(axis=1, value=10.0, motion_unit=UNIT.ROTATION_DEG)

        # Rotate platform of -2 deg from current position
        esp.move_relative(axis=1, value=10.0, motion_unit=UNIT.ROTATION_DEG)