import subprocess
import sys

from pycarmat.gui import main
from pycarmat.GUI.meas.fake_serial import main as main_fake

if __name__ == "__main__":
    if 'fake_psd' in ' '.join(sys.argv):
        main_fake()
    elif len(sys.argv) >= 2:
        if 'detached' in sys.argv[1]:
            main()
        else:
            app = sys.argv[1]
            args = sys.argv[2:] if len(sys.argv) > 2 else []
            subprocess.Popen([sys.executable, '-m', f'pycarmat.GUI.{app}', ' '.join(args)])
    else:
        subprocess.Popen([sys.executable, '-m', 'pycarmat', 'detached'])
        exit(0)
