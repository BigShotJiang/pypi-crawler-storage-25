import inspect
from copy import deepcopy

from numpy import ones_like, abs, asarray, zeros_like, sum, sqrt

from qosm.propagation import GBTC
from pycarmat.inverse_model.score_functions.metrics import tanh_score_1d


def cost_function(x, freq_ghz, metric_fn, kwargs):
    s21_meas = kwargs['s21_meas']

    coefficient_3d = kwargs.get('coefficient_3d', 10)
    model = kwargs.get('model', GBTC)
    config = kwargs.get('config')
    unknown_layer = kwargs.get('unknown_layer')
    theta_y_deg_array = kwargs.get('theta_y_deg_array')
    use_weights = kwargs.get('use_angular_weights', True)
    if use_weights:
        _w = kwargs.get('theta_weight_array', ones_like(theta_y_deg_array))
    else:
        _w = ones_like(theta_y_deg_array)
    unknown_thicknesses = kwargs.get('unknown_thicknesses', [])
    _config = deepcopy(config)
    _config['mut'][unknown_layer]['epsilon_r'] = x[0] + x[1] * 1j
    for _index, unknown_thickness in enumerate(unknown_thicknesses):
        _config['mut'][unknown_thickness]['thickness'] = x[_index+2] * 1e-3

    _arr_err = zeros_like(theta_y_deg_array)

    phys_constraint = kwargs.get('phys_constraint', True)
    penalty = (1e10 if x[1] > 0 else 0) if phys_constraint else 0

    for ii, theta_deg in enumerate(theta_y_deg_array):
        _config['sample_attitude_deg'] = (0, theta_deg, 0)
        _s11, _s12, _s21, _ = model.simulate(_config, freq_ghz)
        sig = inspect.signature(metric_fn)
        if 'alpha' in sig.parameters:
            res = abs(tanh_score_1d(s21_meas[ii], .5*(_s12 + _s21), alpha=1 / coefficient_3d) + penalty)
        else:
            res = abs(tanh_score_1d(s21_meas[ii], .5*(_s12 + _s21)) + penalty)

        _arr_err[ii] = res * _w[ii]

    return sqrt(sum(_arr_err**2))
