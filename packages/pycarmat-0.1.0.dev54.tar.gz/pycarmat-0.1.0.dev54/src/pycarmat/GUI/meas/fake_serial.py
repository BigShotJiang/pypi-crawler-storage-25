#!/usr/bin/env python3
"""
fake_psd_gui.py — Raspberry Pi Pico simulator with PySide6 GUI

Start socat first:
    socat -d -d pty,raw,echo=0,link=/tmp/ttyV0 pty,raw,echo=0,link=/tmp/ttyV1

Then run:
    python fake_psd_gui.py

Connect tab2.py to /tmp/ttyV0 @ 115200 baud.

Protocol:
  On serial connect  → simulator sends  READY (retried every 500 ms until CMD:SYSTEM:ON)
  CMD:SYSTEM:ON      → start streaming, lasers OFF
  CMD:SYSTEM:OFF     → stop streaming,  lasers OFF
  CMD:TX:A:1/0       → Laser A ON/OFF
  CMD:TX:B:1/0       → Laser B ON/OFF
  CMD:TTL:<n>        → TTL frequency (logged)

Keyboard shortcuts:
  1 / 2        — select Laser A / B  (arrow keys will move it)
  Arrow keys   — move selected laser
  R            — simulate Pico reboot (sends READY again)
"""

import sys
import time
import random
import threading

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QLabel, QPushButton, QGroupBox, QScrollArea,
    QLineEdit, QSizePolicy,
)
from PySide6.QtCore import Qt, QTimer, Signal, QObject, QPointF
from PySide6.QtGui import QPainter, QColor, QPen, QFont, QKeyEvent

try:
    import serial
    _SERIAL_OK = True
except ImportError:
    _SERIAL_OK = False

HALF     = 4.5
RATE     = 100
STEP     = 0.08
PORT_OUT = '/tmp/ttyV1'
BAUD     = 115200

C_BG       = '#0f0f13'
C_SURFACE  = '#1a1a24'
C_BORDER   = '#2a2a3a'
C_TEXT     = '#c8c8e8'
C_MUTED    = '#666680'
C_GREEN    = '#22dd66'
C_ORANGE   = '#ff9922'
C_GREY_LED = '#555566'
C_BLUE     = '#44aaff'
C_RED      = '#ff4444'

def _clr(hex_: str, alpha: int = 255) -> QColor:
    c = QColor(hex_); c.setAlpha(alpha); return c


class LED(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._state = 'unknown'
        self.setFixedSize(16, 16)

    def set_state(self, s: str):
        self._state = s; self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        col = {
            'on':  QColor(C_GREEN),
            'off': QColor(C_ORANGE),
        }.get(self._state, QColor(C_GREY_LED))
        glow = QColor(col); glow.setAlpha(40)
        p.setPen(Qt.NoPen); p.setBrush(glow)
        p.drawEllipse(0, 0, 16, 16)
        p.setBrush(col); p.setPen(QPen(col.darker(140), 1.2))
        p.drawEllipse(2, 2, 12, 12)
        p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 70))
        p.drawEllipse(4, 4, 5, 4)


class Badge(QLabel):
    def __init__(self, text='', parent=None):
        super().__init__(text, parent)
        self.setFixedHeight(22)
        self._color = C_MUTED; self._bg = '#22222e'; self._apply()

    def _apply(self):
        self.setStyleSheet(f"color:{self._color};background:{self._bg};"
                           f"border-radius:4px;padding:0 8px;"
                           f"font-size:11px;font-weight:600;letter-spacing:0.05em;")

    def set_online(self):  self._color=C_GREEN;  self._bg='#0d3322'; self._apply()
    def set_offline(self): self._color=C_MUTED;  self._bg='#22222e'; self._apply()
    def set_stream(self):  self._color=C_BLUE;   self._bg='#0d1f3a'; self._apply()
    def set_warn(self):    self._color=C_ORANGE; self._bg='#2a1e0a'; self._apply()
    def set_on(self):      self._color=C_GREEN;  self._bg='#0d3322'; self._apply()
    def set_off(self):     self._color=C_MUTED;  self._bg='#22222e'; self._apply()


class PSDMini(QWidget):
    def __init__(self, color: str, title: str, parent=None):
        super().__init__(parent)
        self._color    = QColor(color)
        self._title    = title
        self._x = self._y = self._sum = 0.0
        self._on = self._selected = False
        self.setMinimumSize(160, 160)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def update_beam(self, x, y, on, sum_v, selected=False):
        self._x, self._y, self._on, self._sum, self._selected = x, y, on, sum_v, selected
        self.update()

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h   = self.width(), self.height()
        margin = 22
        size   = min(w, h) - margin * 2
        ox, oy = (w - size) / 2, (h - size) / 2
        cx, cy = ox + size / 2, oy + size / 2

        def mm2px(v): return size / (HALF * 2) * v

        p.fillRect(0, 0, w, h, _clr(C_SURFACE))
        p.setPen(QPen(_clr(C_BORDER), 0.6))
        for i in range(1, 4):
            gx, gy = ox + size*i/4, oy + size*i/4
            p.drawLine(int(gx), int(oy), int(gx), int(oy+size))
            p.drawLine(int(ox), int(gy), int(ox+size), int(gy))
        dash = QPen(_clr(C_BORDER, 160), 0.8, Qt.DashLine)
        p.setPen(dash)
        p.drawLine(int(cx), int(oy), int(cx), int(oy+size))
        p.drawLine(int(ox), int(cy), int(ox+size), int(cy))

        on_sensor = self._on and abs(self._x)<=HALF and abs(self._y)<=HALF and self._sum>1.0
        if on_sensor:
            bc, lw = QColor('#22cc44'), 2.5
        elif self._selected:
            bc = QColor(self._color); bc.setAlpha(200); lw = 2.0
        else:
            bc, lw = _clr(C_BORDER, 200), 1.2
        p.setPen(QPen(bc, lw)); p.setBrush(Qt.NoBrush)
        p.drawRect(int(ox), int(oy), int(size), int(size))

        f = QFont(); f.setPixelSize(11); f.setBold(True); p.setFont(f)
        tc = QColor(self._color)
        if self._selected: tc = tc.lighter(130)
        p.setPen(tc)
        p.drawText(int(ox), int(oy)-5, ('▶ ' if self._selected else '  ') + self._title)

        if self._on:
            bx, by = cx + mm2px(self._x), cy - mm2px(self._y)
            for i in range(8, 0, -1):
                hc = QColor(self._color); hc.setAlpha(int(30*i/8))
                p.setPen(Qt.NoPen); p.setBrush(hc)
                p.drawEllipse(QPointF(bx, by), i*3.0, i*3.0)
            p.setBrush(self._color); p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(bx, by), 5.0, 5.0)
            ch = QPen(QColor(self._color.red(), self._color.green(), self._color.blue(), 100), 0.6)
            p.setPen(ch)
            p.drawLine(int(ox), int(by), int(ox+size), int(by))
            p.drawLine(int(bx), int(oy), int(bx), int(oy+size))


class Console(QScrollArea):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._inner  = QWidget()
        self._layout = QVBoxLayout(self._inner)
        self._layout.setContentsMargins(8, 6, 8, 6)
        self._layout.setSpacing(0)
        self._layout.addStretch()
        self.setWidget(self._inner)
        self.setWidgetResizable(True)
        self.setFixedHeight(170)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setStyleSheet(
            f"QScrollArea{{background:#0a0a12;border:1px solid {C_BORDER};border-radius:6px;}}"
            f"QScrollBar:vertical{{width:4px;background:transparent;}}"
            f"QScrollBar::handle:vertical{{background:{C_BORDER};border-radius:2px;}}")

    def append(self, text: str, kind: str = ''):
        col = {'cmd':C_BLUE,'ok':C_GREEN,'data':C_MUTED,'warn':C_ORANGE,'err':C_RED}.get(kind, C_TEXT)
        ts  = time.strftime('%H:%M:%S')
        lbl = QLabel(f'<span style="color:{C_MUTED}">[{ts}]</span> <span style="color:{col}">{text}</span>')
        lbl.setFont(QFont('Monospace', 10))
        lbl.setTextFormat(Qt.RichText)
        lbl.setWordWrap(True)
        self._layout.insertWidget(self._layout.count()-1, lbl)
        while self._layout.count() > 202:
            item = self._layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        QTimer.singleShot(10, lambda: self.verticalScrollBar().setValue(
            self.verticalScrollBar().maximum()))


class Comms(QObject):
    command_received = Signal(str)
    connected        = Signal()

    def __init__(self, port: str, baud: int):
        super().__init__()
        self._port  = port
        self._baud  = baud
        self._ser   = None
        self._lock  = threading.Lock()
        self._stop  = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self): self._thread.start()
    def stop(self):  self._stop.set()

    def send(self, line: str):
        with self._lock:
            if self._ser and self._ser.is_open:
                try:
                    self._ser.write((line+'\n').encode())
                    self._ser.flush()
                except Exception:
                    pass

    def _run(self):
        if not _SERIAL_OK: return
        try:
            self._ser = serial.Serial(self._port, self._baud, timeout=0.05)
        except Exception:
            return
        self.connected.emit()
        buf = ''
        while not self._stop.is_set():
            try:
                chunk = self._ser.read(self._ser.in_waiting or 1)
                if chunk:
                    buf += chunk.decode(errors='replace')
                    while '\n' in buf:
                        line, buf = buf.split('\n', 1)
                        line = line.strip()
                        if line: self.command_received.emit(line)
            except Exception:
                time.sleep(0.01)
        if self._ser and self._ser.is_open:
            self._ser.close()


class PicoSim(QMainWindow):
    _log_signal = Signal(str, str)

    def __init__(self):
        super().__init__()
        self.setWindowTitle('Virtual Raspberry Pi Pico — PSD Simulator')
        self.setMinimumSize(820, 680)

        self._online = self._streaming = self._la = self._lb = False
        self._ttl    = 50
        self._xA = self._yA = self._xB = self._yB = 0.0
        self._mode     = 'keyboard'
        self._selected = 'A'
        self._comms: Comms | None = None
        self._frame_count = 0
        # ── CHANGE 1: timer that retries READY until CMD:SYSTEM:ON is received
        self._ready_timer = QTimer()
        self._ready_timer.setInterval(500)
        self._ready_timer.timeout.connect(self._retry_ready)

        self._log_signal.connect(self._on_log)
        self._build_ui()
        self._apply_style()

        self._timer = QTimer()
        self._timer.setInterval(int(1000 / RATE))
        self._timer.timeout.connect(self._emit_frame)
        self._timer.start()

    def _build_ui(self):
        root = QWidget(); self.setCentralWidget(root)
        rl   = QHBoxLayout(root)
        rl.setContentsMargins(16, 16, 16, 16); rl.setSpacing(12)

        left = QWidget(); left.setFixedWidth(280)
        ll   = QVBoxLayout(left); ll.setContentsMargins(0,0,0,0); ll.setSpacing(10)

        grp_con = self._group('Serial port')
        gc = QGridLayout(grp_con); gc.setSpacing(6)
        self._port_edit = QLineEdit(PORT_OUT)
        gc.addWidget(QLabel('Port'), 0, 0); gc.addWidget(self._port_edit, 0, 1)
        self._btn_connect = QPushButton('Connect')
        self._btn_connect.clicked.connect(self._toggle_connect)
        gc.addWidget(self._btn_connect, 1, 0, 1, 2)
        ll.addWidget(grp_con)

        grp_sys = self._group('System')
        gs = QGridLayout(grp_sys); gs.setSpacing(6)
        self._led_sys    = LED(); self._badge_sys    = Badge('OFFLINE')
        self._led_stream = LED(); self._badge_stream = Badge('STOPPED')
        gs.addWidget(QLabel('System'), 0,0); gs.addWidget(self._led_sys,    0,1,Qt.AlignCenter); gs.addWidget(self._badge_sys,    0,2)
        gs.addWidget(QLabel('Stream'), 1,0); gs.addWidget(self._led_stream, 1,1,Qt.AlignCenter); gs.addWidget(self._badge_stream, 1,2)
        ll.addWidget(grp_sys)

        grp_las = self._group('Lasers')
        gl = QGridLayout(grp_las); gl.setSpacing(6)
        self._led_a = LED(); self._badge_a = Badge('OFF')
        self._led_b = LED(); self._badge_b = Badge('OFF')
        self._lbl_ttl = QLabel('50 kHz')
        self._lbl_ttl.setStyleSheet(f'color:{C_MUTED};font-size:12px;')
        gl.addWidget(QLabel('Laser A'), 0,0); gl.addWidget(self._led_a, 0,1,Qt.AlignCenter); gl.addWidget(self._badge_a, 0,2)
        gl.addWidget(QLabel('Laser B'), 1,0); gl.addWidget(self._led_b, 1,1,Qt.AlignCenter); gl.addWidget(self._badge_b, 1,2)
        gl.addWidget(QLabel('TTL freq'),2,0); gl.addWidget(self._lbl_ttl, 2,2)
        ll.addWidget(grp_las)

        grp_met = self._group('Beam position')
        gm = QGridLayout(grp_met); gm.setSpacing(6)
        self._met = {}
        for i, (key, lbl) in enumerate([
            ('xA','X — sensor A'),('yA','Y — sensor A'),
            ('xB','X — sensor B'),('yB','Y — sensor B'),
            ('sA','Sum A'),       ('sB','Sum B'),
        ]):
            row, col = divmod(i, 2)
            card = QWidget(); card.setObjectName('metric-card')
            cl = QVBoxLayout(card); cl.setContentsMargins(8,6,8,6); cl.setSpacing(2)
            t = QLabel(lbl); t.setStyleSheet(f'color:{C_MUTED};font-size:10px;')
            v = QLabel('—'); v.setStyleSheet(f'color:{C_TEXT};font-size:13px;font-weight:600;')
            v.setFont(QFont('Monospace', 10))
            cl.addWidget(t); cl.addWidget(v)
            self._met[key] = v
            gm.addWidget(card, row, col)
        ll.addWidget(grp_met)
        ll.addStretch()
        rl.addWidget(left)

        right = QWidget()
        rr    = QVBoxLayout(right); rr.setContentsMargins(0,0,0,0); rr.setSpacing(10)

        grp_psd    = self._group('PSD sensors')
        psd_layout = QHBoxLayout(grp_psd); psd_layout.setSpacing(10)
        self._psd_a = PSDMini(C_RED,  'Sensor A — mmWave Converters')
        self._psd_b = PSDMini(C_BLUE, 'Sensor B — Sample holder')
        psd_layout.addWidget(self._psd_a); psd_layout.addWidget(self._psd_b)
        rr.addWidget(grp_psd)

        grp_mode = self._group('Walk mode')
        ml = QVBoxLayout(grp_mode); ml.setSpacing(8)
        row1 = QHBoxLayout()
        self._btn_kbd = QPushButton('Keyboard'); self._btn_kbd.setCheckable(True); self._btn_kbd.setChecked(True)
        self._btn_rnd = QPushButton('Random');   self._btn_rnd.setCheckable(True)
        self._btn_kbd.clicked.connect(lambda: self._set_mode('keyboard'))
        self._btn_rnd.clicked.connect(lambda: self._set_mode('random'))
        row1.addWidget(self._btn_kbd); row1.addWidget(self._btn_rnd); row1.addStretch()
        ml.addLayout(row1)
        row2 = QHBoxLayout(); row2.setSpacing(8)
        sel_lbl = QLabel('Arrow keys move:'); sel_lbl.setStyleSheet(f'color:{C_MUTED};font-size:11px;')
        self._btn_sel_a = QPushButton('Laser A'); self._btn_sel_a.setCheckable(True); self._btn_sel_a.setChecked(True); self._btn_sel_a.setFixedHeight(26)
        self._btn_sel_b = QPushButton('Laser B'); self._btn_sel_b.setCheckable(True); self._btn_sel_b.setFixedHeight(26)
        self._btn_sel_a.clicked.connect(lambda: self._set_selected('A'))
        self._btn_sel_b.clicked.connect(lambda: self._set_selected('B'))
        hint = QLabel('  1/2 to switch  |  R = simulate reboot')
        hint.setStyleSheet(f'color:{C_MUTED};font-size:11px;')
        row2.addWidget(sel_lbl); row2.addWidget(self._btn_sel_a); row2.addWidget(self._btn_sel_b); row2.addWidget(hint, 1)
        ml.addLayout(row2)
        rr.addWidget(grp_mode)

        grp_log    = self._group('Serial console')
        log_layout = QVBoxLayout(grp_log)
        self._console   = Console()
        self._cmd_input = QLineEdit()
        self._cmd_input.setPlaceholderText('Send command manually, e.g. CMD:TX:A:1')
        self._cmd_input.setFont(QFont('Monospace', 10))
        self._cmd_input.returnPressed.connect(self._manual_cmd)
        log_layout.addWidget(self._console); log_layout.addWidget(self._cmd_input)
        rr.addWidget(grp_log)
        rl.addWidget(right, 1)

        self.setFocusPolicy(Qt.StrongFocus)
        self._log('Virtual Pico ready — connect to start', 'warn')
        self._log('Keys: 1/2=select laser  ↑↓←→=move  R=simulate reboot', 'warn')

    def _group(self, title): return QGroupBox(title)

    def _apply_style(self):
        self.setStyleSheet(f"""
        QMainWindow,QWidget{{background:{C_BG};color:{C_TEXT};font-family:'Segoe UI','SF Pro Display',sans-serif;font-size:13px;}}
        QGroupBox{{background:{C_SURFACE};border:1px solid {C_BORDER};border-radius:8px;margin-top:10px;padding:10px;font-size:11px;font-weight:600;color:{C_MUTED};letter-spacing:0.08em;}}
        QGroupBox::title{{subcontrol-origin:margin;subcontrol-position:top left;left:10px;top:2px;}}
        QPushButton{{background:transparent;border:1px solid {C_BORDER};border-radius:5px;padding:5px 14px;color:{C_TEXT};font-size:12px;}}
        QPushButton:hover{{background:#2a2a3a;border-color:#44445a;}}
        QPushButton:checked{{background:#0d1f3a;border-color:{C_BLUE};color:{C_BLUE};}}
        QPushButton#connect-on{{background:#0d3322;border-color:{C_GREEN};color:{C_GREEN};}}
        QPushButton#connect-off{{background:#3a1222;border-color:#cc3355;color:#cc3355;}}
        QPushButton#sel-a-active{{background:#2a1212;border-color:{C_RED};color:{C_RED};}}
        QPushButton#sel-b-active{{background:#0d1f3a;border-color:{C_BLUE};color:{C_BLUE};}}
        QLineEdit{{background:#12121e;border:1px solid {C_BORDER};border-radius:5px;padding:4px 8px;color:{C_TEXT};font-size:12px;}}
        QLineEdit:focus{{border-color:{C_BLUE};}}
        QLabel{{color:{C_TEXT};font-size:12px;background:transparent;}}
        QWidget#metric-card{{background:#12121e;border-radius:5px;}}
        QScrollBar:vertical{{background:transparent;width:4px;}}
        QScrollBar::handle:vertical{{background:{C_BORDER};border-radius:2px;}}
        """)

    def _log(self, text, kind=''): self._log_signal.emit(text, kind)
    def _on_log(self, text, kind): self._console.append(text, kind)

    def _set_selected(self, laser: str):
        self._selected = laser
        self._btn_sel_a.setChecked(laser == 'A')
        self._btn_sel_b.setChecked(laser == 'B')
        self._btn_sel_a.setObjectName('sel-a-active' if laser == 'A' else '')
        self._btn_sel_b.setObjectName('sel-b-active' if laser == 'B' else '')
        self._apply_style()
        self._log(f'Arrow keys → Laser {laser}', 'ok')

    def _update_status(self):
        self._led_sys.set_state('on' if self._online else 'unknown')
        if self._online: self._badge_sys.set_online();  self._badge_sys.setText('ONLINE')
        else:            self._badge_sys.set_offline(); self._badge_sys.setText('OFFLINE')
        self._led_stream.set_state('on' if self._streaming else ('off' if self._online else 'unknown'))
        if self._streaming:  self._badge_stream.set_stream(); self._badge_stream.setText('STREAMING')
        elif self._online:   self._badge_stream.set_warn();   self._badge_stream.setText('STOPPED')
        else:                self._badge_stream.set_offline(); self._badge_stream.setText('STOPPED')
        for led, badge, on in [(self._led_a, self._badge_a, self._la),
                                (self._led_b, self._badge_b, self._lb)]:
            led.set_state('on' if on else 'off')
            badge.set_on() if on else badge.set_off()
            badge.setText('ON' if on else 'OFF')
        self._lbl_ttl.setText(f'{self._ttl} kHz')

    def _update_metrics(self):
        def fmt(v): return f'{v:+.4f} mm'
        self._met['xA'].setText(fmt(self._xA)); self._met['yA'].setText(fmt(self._yA))
        self._met['xB'].setText(fmt(self._xB)); self._met['yB'].setText(fmt(self._yB))
        sA = self._sum(self._xA, self._yA, self._la)
        sB = self._sum(self._xB, self._yB, self._lb)
        self._met['sA'].setText(f'{sA:.4f} V')
        self._met['sB'].setText(f'{sB:.4f} V')
        self._psd_a.update_beam(self._xA, self._yA, self._la, sA, self._selected=='A')
        self._psd_b.update_beam(self._xB, self._yB, self._lb, sB, self._selected=='B')

    @staticmethod
    def _sum(x, y, on):
        if not on: return 0.2
        return random.uniform(4.8, 6.0) if abs(x)<=HALF and abs(y)<=HALF else 0.2

    # ── connection ────────────────────────────────────────────────────────

    def _toggle_connect(self):
        if self._comms is None: self._start_comms()
        else:                   self._stop_comms()

    def _start_comms(self):
        if not _SERIAL_OK:
            self._log('pyserial not installed!', 'err'); return
        port = self._port_edit.text().strip() or PORT_OUT
        self._comms = Comms(port, BAUD)
        self._comms.command_received.connect(self._on_command)
        self._comms.connected.connect(self._on_serial_connected)
        self._comms.start()
        self._btn_connect.setText('Disconnect')
        self._btn_connect.setObjectName('connect-off')
        self._btn_connect.setStyleSheet('')
        self._apply_style()
        self._log(f'Listening on {port} @ {BAUD}', 'ok')

    def _stop_comms(self):
        self._ready_timer.stop()          # ── CHANGE 2: stop retries on disconnect
        if self._comms: self._comms.stop(); self._comms = None
        self._online = self._streaming = self._la = self._lb = False
        self._btn_connect.setText('Connect')
        self._btn_connect.setObjectName('connect-on')
        self._apply_style(); self._update_status()
        self._log('Disconnected', 'warn')

    def _on_serial_connected(self):
        self._send_ready()

    def _send_ready(self):
        """Simulate Pico boot: reset state, send READY, start retry timer."""
        self._streaming = False
        self._la = self._lb = False
        self._update_status()
        if self._comms:
            self._comms.send('READY')
        self._log('→ READY  (retrying every 500 ms until CMD:SYSTEM:ON)', 'warn')
        self._ready_timer.start()         # ── CHANGE 3: start 500 ms retry loop

    def _retry_ready(self):
        """Called every 500 ms — resend READY if still waiting for SYSTEM:ON."""
        if self._comms:
            self._comms.send('READY')
            self._log('→ READY  (retry)', 'warn')

    # ── command handling ──────────────────────────────────────────────────

    def _on_command(self, cmd: str):
        if not cmd.startswith('CMD:'): return
        body = cmd[4:]
        self._log(f'← {cmd}', 'cmd')
        if body == 'SYSTEM:ON':
            self._ready_timer.stop()      # ── CHANGE 4: stop retrying once acknowledged
            self._online = self._streaming = True
            self._la = self._lb = False
            self._log('  system ON — stream started, lasers OFF', 'ok')
        elif body == 'SYSTEM:OFF':
            self._streaming = self._la = self._lb = False
            self._log('  system OFF — stream stopped, lasers OFF', 'ok')
        elif body == 'TX:A:1': self._la = True;  self._log('  laser A → ON',  'ok')
        elif body == 'TX:A:0': self._la = False; self._log('  laser A → OFF', 'ok')
        elif body == 'TX:B:1': self._lb = True;  self._log('  laser B → ON',  'ok')
        elif body == 'TX:B:0': self._lb = False; self._log('  laser B → OFF', 'ok')
        elif body.startswith('TTL:'):
            try: self._ttl = int(body[4:]); self._log(f'  TTL → {self._ttl} kHz', 'ok')
            except ValueError: pass
        else:
            self._log(f'  unknown: {body}', 'warn')
        self._update_status()

    def _manual_cmd(self):
        txt = self._cmd_input.text().strip()
        if txt: self._on_command(txt); self._cmd_input.clear()

    # ── frame emission ────────────────────────────────────────────────────

    def _emit_frame(self):
        if self._mode == 'random' and self._streaming:
            self._xA += random.gauss(0, 0.05); self._yA += random.gauss(0, 0.05)
            self._xB += random.gauss(0, 0.05); self._yB += random.gauss(0, 0.05)
        self._update_metrics()
        if not self._streaming or self._comms is None: return
        sA = self._sum(self._xA, self._yA, self._la)
        sB = self._sum(self._xB, self._yB, self._lb)
        if self._la and random.random() < 0.005: sA = 0.2
        if self._lb and random.random() < 0.005: sB = 0.2
        line = (f'{self._xA:.4f},{self._yA:.4f},{sA:.4f},'
                f'{self._xB:.4f},{self._yB:.4f},{sB:.4f},'
                f'{int(self._la)},{int(self._lb)}')
        self._comms.send(line)
        self._frame_count += 1
        if self._frame_count % 20 == 0:
            self._log(f'→ {line}', 'data')

    # ── keyboard ──────────────────────────────────────────────────────────

    def _set_mode(self, m):
        self._mode = m
        self._btn_kbd.setChecked(m == 'keyboard')
        self._btn_rnd.setChecked(m == 'random')

    def keyPressEvent(self, e: QKeyEvent):
        k = e.key()
        if k == Qt.Key_1: self._set_selected('A'); return
        if k == Qt.Key_2: self._set_selected('B'); return
        if k == Qt.Key_R:
            self._log('R pressed — simulating Pico reboot', 'warn')
            self._send_ready()
            return
        if self._mode != 'keyboard': return
        if self._selected == 'A':
            if   k == Qt.Key_Up:    self._yA += STEP
            elif k == Qt.Key_Down:  self._yA -= STEP
            elif k == Qt.Key_Right: self._xA += STEP
            elif k == Qt.Key_Left:  self._xA -= STEP
        else:
            if   k == Qt.Key_Up:    self._yB += STEP
            elif k == Qt.Key_Down:  self._yB -= STEP
            elif k == Qt.Key_Right: self._xB += STEP
            elif k == Qt.Key_Left:  self._xB -= STEP

    def closeEvent(self, e):
        self._ready_timer.stop()
        self._timer.stop(); self._stop_comms(); super().closeEvent(e)


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    win = PicoSim()
    win.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()