import sys
from time import sleep

from PySide6.QtGui import QFont, QPalette
from PySide6.QtWidgets import (QApplication, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QFormLayout,
                               QDialog, QMessageBox)
from PySide6.QtCore import Qt, QThread, Signal

from pycarmat.ressources.ESP import ESP30xController, UNIT
from pycarmat.ressources.VNA import RohdeSchwarzVNA, KeysightVNA
from pycarmat.GUI.meas.gui.core import Worker



class ManualTRLWindow(QDialog):
    def __init__(self, callback=None):
        super().__init__()
        self.setWindowTitle("Confirm Manual TRL")
        self.setFixedSize(300, 150)
        self.callback = callback
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.init_ui()

        # Variables for dragging the window
        self.dragging = False
        self.drag_position = None

    def is_dark_theme(self):
        """Detect if the application is using a dark theme"""
        palette = QApplication.palette()
        bg_color = palette.color(QPalette.Window)
        # If background is dark (luminance < 128), it's dark mode
        luminance = (0.299 * bg_color.red() +
                     0.587 * bg_color.green() +
                     0.114 * bg_color.blue())
        return luminance < 128

    def init_ui(self):

        layout = QVBoxLayout()
        self.setLayout(layout)

        if self.is_dark_theme():
            btn_color = "#3c3c3c"
            btn_hover = "#4c4c4c"
        else:
            btn_color = "#95a5a6"
            btn_hover = "#7f8c8d"

        # Start button
        self.start_button = QPushButton("TRL manually done on VNA")
        self.start_button.clicked.connect(self.trl_done)
        self.start_button.setMinimumHeight(50)
        self.start_button.setFont(QFont("Arial", 12))
        layout.addWidget(self.start_button)
        self.start_button.setCursor(Qt.PointingHandCursor)

        self.start_button.setStyleSheet(f"""
                    QPushButton {{
                        border: none;
                        border-radius: 5px;
                        padding: 10px 20px;
                    }}
                """)

        # Quit button
        self.btnb = QPushButton("❌ Close")
        self.btnb.setFont(QFont("Arial", 12))
        self.btnb.setMinimumHeight(50)
        self.btnb.setCursor(Qt.PointingHandCursor)

        self.btnb.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {btn_color};
                        color: white;
                        border: none;
                        border-radius: 5px;
                        padding: 10px 20px;
                    }}
                    QPushButton:hover {{
                        background-color: {btn_hover};
                    }}
                    QPushButton:pressed {{
                        background-color: {self.darken_color(btn_color)};
                    }}
                """)
        self.btnb.clicked.connect(self.close)

        layout.addWidget(self.btnb, 0, Qt.AlignCenter)

    def trl_done(self):
        if self.callback is not None:
            self.callback('trl')
            self.close()

    def lighten_color(self, hex_color):
        """Lighten a hex color"""
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        lighter_rgb = tuple(min(255, int(c + (255 - c) * 0.3)) for c in rgb)
        return f'#{lighter_rgb[0]:02x}{lighter_rgb[1]:02x}{lighter_rgb[2]:02x}'

    def darken_color(self, hex_color):
        """Darken a hex color"""
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        darker_rgb = tuple(max(0, int(c * 0.8)) for c in rgb)
        return f'#{darker_rgb[0]:02x}{darker_rgb[1]:02x}{darker_rgb[2]:02x}'

    def center_window(self):
        """Center the window on screen"""
        screen = QApplication.primaryScreen().geometry()
        window_geometry = self.frameGeometry()
        center_point = screen.center()
        window_geometry.moveCenter(center_point)
        self.move(window_geometry.topLeft())

    def mousePressEvent(self, event):
        """Handle mouse press for window dragging"""
        if event.button() == Qt.LeftButton:
            self.dragging = True
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        """Handle mouse move for window dragging"""
        if self.dragging and event.buttons() == Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()

    def mouseReleaseEvent(self, event):
        """Handle mouse release for window dragging"""
        if event.button() == Qt.LeftButton:
            self.dragging = False
            event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    band_settings = {
        'num_points': 5001,
        'meas_bandwidth': '1kHz',
        'band_id': 3
    }
    window = TRLWindow(band_settings=band_settings, ip_address='192.168.0.5', is_rs=False)
    window.exec()
    sys.exit(app.exec())