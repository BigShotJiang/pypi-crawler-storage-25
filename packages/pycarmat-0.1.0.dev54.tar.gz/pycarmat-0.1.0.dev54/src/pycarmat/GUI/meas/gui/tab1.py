import numpy as np
from PySide6.QtWidgets import QVBoxLayout, QCheckBox, QHBoxLayout, QWidget
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.qt_compat import QtWidgets as QTW
from matplotlib.figure import Figure

from skrf import Network
from scipy.signal import savgol_filter

from .core import Tab, is_dark_mode
from pycarmat.GUI.meas.gui.sidebar_tab1 import SidebarS2P


def smoothing(s_param, window_length, polyorder):
    """Apply Savitzky-Golay smoothing"""
    s_real = savgol_filter(np.real(s_param), window_length, polyorder)
    s_imag = savgol_filter(np.imag(s_param), window_length, polyorder)
    return s_real + 1j * s_imag


def s2p_filtering(data: Network, smoothing_window:int = 41, smoothing_poly:int = 3):
    s_param = np.full_like(data.s, np.nan, dtype=complex)
    s_param[:, 0, 0] = smoothing(data.s[:, 0, 0], smoothing_window, smoothing_poly)
    s_param[:, 0, 1] = smoothing(data.s[:, 0, 1], smoothing_window, smoothing_poly)
    s_param[:, 1, 0] = smoothing(data.s[:, 1, 0], smoothing_window, smoothing_poly)
    s_param[:, 1, 1] = smoothing(data.s[:, 1, 1], smoothing_window, smoothing_poly)
    freq = data.frequency
    return Network(s=s_param, frequency=freq.f, f_unit=freq.unit)


class Tab1(Tab):
    def __init__(self, gui_elements: tuple = (), **kargs):
        super().__init__(gui_elements, **kargs)
        self.ntw = None

    def _init(self):
        main_layout = QHBoxLayout(self)
        sidebar = SidebarS2P((self,), min_width=300)
        main_layout.addWidget(sidebar)

        main = QWidget()
        layout = QVBoxLayout(main)
        self.smooth_checkbox = QCheckBox("Smoothing")
        self.smooth_checkbox.stateChanged.connect(self.refresh_graph)
        layout.addWidget(self.smooth_checkbox)

        self._main = QTW.QWidget()
        layout_fig = QTW.QVBoxLayout(self._main)
        self.fig = Figure(figsize=(8, 6))
        self.axes = self.fig.subplots(2, 2)
        self.fig.tight_layout()

        for ax in self.axes.flat:
            ax.grid(axis='both', which='both')

        self.axes[0, 0].set_title("S11, S22 mag (dB)", color="white" if is_dark_mode() else "black")
        self.axes[0, 1].set_title("S11, S22 phase", color="white" if is_dark_mode() else "black")
        self.axes[1, 0].set_title("S12, S21 mag (dB)", color="white" if is_dark_mode() else "black")
        self.axes[1, 1].set_title("S12, S21 phase", color="white" if is_dark_mode() else "black")

        self.canvas = FigureCanvas(self.fig)
        layout_fig.addWidget(self.canvas)
        layout.addWidget(self._main)
        main_layout.addWidget(main, 1)

    def refresh_graph(self):
        if self.ntw is not None:
            self.update_graph(self.ntw)

    def update_graph(self, ntw):
        if ntw is None:
            return

        self.ntw = ntw
        _ntw = s2p_filtering(ntw) if self.smooth_checkbox.isChecked() else ntw

        f_min = np.min(_ntw.f / 1e9)
        f_max = np.max(_ntw.f / 1e9)

        freq = _ntw.f / 1e9

        self.axes[0, 0].clear()
        self.axes[0, 0].plot(freq, _ntw.s_db[:, 0, 0], color="lightcoral", label="S11", linewidth=2)
        self.axes[0, 0].plot(freq, _ntw.s_db[:, 1, 1], color="lightskyblue", label="S22", linewidth=2)
        self.axes[0, 0].set_title("S11, S22 mag (dB)", color="white" if is_dark_mode() else "black")
        l00 = self.axes[0, 0].legend(loc='lower right')
        self.axes[0, 0].set_xlim(f_min, f_max)

        self.axes[0, 1].clear()
        self.axes[0, 1].plot(freq, np.angle(_ntw.s[:, 0, 0], deg=True), color="lightcoral", label="S11", linewidth=2)
        self.axes[0, 1].plot(freq, np.angle(_ntw.s[:, 1, 1], deg=True), color="lightskyblue", label="S22", linewidth=2)
        self.axes[0, 1].set_title("S11, S22 phase", color="white" if is_dark_mode() else "black")
        l01 = self.axes[0, 1].legend(loc='lower right')
        self.axes[0, 1].set_xlim(f_min, f_max)

        self.axes[1, 0].clear()
        self.axes[1, 0].plot(freq, _ntw.s_db[:, 0, 1], color="lightcoral", label="S12", linewidth=2)
        self.axes[1, 0].plot(freq, _ntw.s_db[:, 1, 0], color="lightskyblue", label="S21", linewidth=2)
        self.axes[1, 0].set_title("S12, S21 mag (dB)", color="white" if is_dark_mode() else "black")
        l10 = self.axes[1, 0].legend(loc='lower right')
        self.axes[1, 0].set_xlim(f_min, f_max)

        self.axes[1, 1].clear()
        self.axes[1, 1].plot(freq, np.angle(_ntw.s[:, 1, 0], deg=True), color="lightcoral", label="S12")
        self.axes[1, 1].plot(freq, np.angle(_ntw.s[:, 0, 1], deg=True), color="lightskyblue", label="S21")
        self.axes[1, 1].set_title("S12, S21 phase", color="white" if is_dark_mode() else "black")
        l11 = self.axes[1, 1].legend(loc='lower right')
        self.axes[1, 1].set_xlim(f_min, f_max)

        for ax in self.axes.flat:
            if is_dark_mode():
                ax.grid(color=(.25, .25, .25))
            else:
                ax.grid(color="#bbb")

        def set_legend_style(_legend):
            if is_dark_mode():
                _legend.get_frame().set_facecolor("#222")
                _legend.get_frame().set_edgecolor("#222")
                for text in _legend.get_texts():
                    text.set_color("white")

        set_legend_style(l00)
        set_legend_style(l01)
        set_legend_style(l10)
        set_legend_style(l11)

        self.canvas.draw()


