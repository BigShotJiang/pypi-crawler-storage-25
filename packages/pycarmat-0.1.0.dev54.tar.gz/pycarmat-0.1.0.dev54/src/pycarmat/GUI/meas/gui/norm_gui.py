import sys
from time import sleep

from PySide6.QtGui import QFont, QPalette
from PySide6.QtWidgets import (QApplication, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QFormLayout,
                               QDialog, QMessageBox)
from PySide6.QtCore import Qt, QThread, Signal

from pycarmat.GUI.meas.gui.vna_config import load_config
from pycarmat.ressources.ESP import ESP30xController, UNIT
from pycarmat.ressources.VNA import RohdeSchwarzVNA, KeysightVNA
from pycarmat.GUI.meas.gui.core import Worker


class NormWorker(Worker):
    result_signal = Signal(bool)
    progress_signal = Signal(int)

    def __init__(self, params: dict):
        super().__init__(None, params)
        self.cancel = False

    def _run(self):
        self._running = True

        __vna__ = RohdeSchwarzVNA if self.params['is_rs'] else KeysightVNA
        try:
            with __vna__(ip_address=self.params['ip_address'], simulate=False) as vna:
                vna.set_sweep(
                    freq_start_GHz=self.params['freq_start_GHz'],
                    freq_end_GHz=self.params['freq_end_GHz'],
                    num_pts=int(self.params['num_points']),
                    bandwidth=self.params['bandwidth']
                )

                self.progress_signal.emit(-2)
                res, err = vna.perform_normalization_calibration(cal_kit=self.params['kit'])
                self.progress_signal.emit(int(res))
                self.result_signal.emit(res)
                if not res:
                    self.error_signal.emit(str(err))
        except Exception as e:
            self.error_signal.emit(str(e))


class NormWindow(QDialog):
    def __init__(self, band_settings: dict, ip_address: str, is_rs:bool = True, callback=None):
        super().__init__()
        self.setWindowTitle("Normalization Settings")
        self.setFixedSize(300, 350)
        self.callback = callback

        # Default settings
        self.band_settings = {
            'num_points' : band_settings['num_points'],
            'bandwidth' : band_settings['meas_bandwidth']
        }
        band_id  = band_settings['band_id']
        band_cfg = band_settings.get('band_cfg')   # BandConfig | None, injected by Sidebar

        # Determine whether this is the dynamic Custom entry (last item in the combo)
        # A band is "custom" when band_cfg is None (no config entry exists for it)
        # or when band_id points past all config-defined bands.
        if band_cfg is not None:
            # Config-defined band: use values from BandConfig
            self.norm_settings = {
                'kit':  band_cfg.calkit,
            }
            self.band_settings['start'] = band_cfg.start_GHz
            self.band_settings['stop']  = band_cfg.stop_GHz
        else:
            # Dynamic Custom band: compute line from the GUI-supplied frequencies
            custom_start = band_settings.get('custom_start_GHz', 100.0)
            custom_stop  = band_settings.get('custom_stop_GHz',  200.0)
            self.norm_settings = {'kit': 'Custom'}
            self.band_settings['start'] = custom_start
            self.band_settings['stop']  = custom_stop

        # LED states
        self.led_states = {'norm': False}

        self.setWindowFlags(Qt.FramelessWindowHint)
        self.init_ui()
        self.load_settings()
        self.worker = None
        self.is_rs = is_rs
        self.ip_address = ip_address

        # Variables for dragging the window
        self.dragging = False
        self.drag_position = None

    def _start_worker(self, worker):
        self.worker = worker
        self.thread = QThread()
        self.thread.started.connect(self.worker.start)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.finished.connect(self.cal_ended)
        self.worker.error_signal.connect(self.show_error_dialog)
        self.worker.progress_signal.connect(self.set_led)

        self.thread.start()

    def show_error_dialog(self, message):
        msg_box = QMessageBox(self)
        msg_box.setIcon(QMessageBox.Critical)
        msg_box.setInformativeText(message)
        msg_box.setWindowTitle("Error")
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.exec()

    def is_dark_theme(self):
        """Detect if the application is using a dark theme"""
        palette = QApplication.palette()
        bg_color = palette.color(QPalette.Window)
        # If background is dark (luminance < 128), it's dark mode
        luminance = (0.299 * bg_color.red() +
                     0.587 * bg_color.green() +
                     0.114 * bg_color.blue())
        return luminance < 128

    def init_ui(self):

        layout = QVBoxLayout()
        self.setLayout(layout)

        # Form layout for settings
        form_layout = QFormLayout()

        # Kit input
        self.kit_edit = QLineEdit()
        form_layout.addRow("Kit:", self.kit_edit)

        layout.addLayout(form_layout)

        # LEDs layout
        leds_layout = QHBoxLayout()

        # THRU LED
        thru_container = QVBoxLayout()
        thru_container.setAlignment(Qt.AlignCenter)
        self.thru_led = QLabel()
        self.thru_led.setStyleSheet(self.get_led_style("orange"))
        self.thru_led.setFixedSize(40, 40)
        thru_label = QLabel("THRU")
        thru_label.setAlignment(Qt.AlignCenter)
        thru_container.addWidget(self.thru_led)
        thru_container.addWidget(thru_label)
        leds_layout.addLayout(thru_container)

        layout.addLayout(leds_layout)


        if self.is_dark_theme():
            btn_color = "#3c3c3c"
            btn_hover = "#4c4c4c"
        else:
            btn_color = "#95a5a6"
            btn_hover = "#7f8c8d"

        # Start button
        self.start_button = QPushButton("Start")
        self.start_button.clicked.connect(self.start_norm)
        self.start_button.setMinimumHeight(50)
        self.start_button.setFont(QFont("Arial", 12))
        layout.addWidget(self.start_button)
        self.start_button.setCursor(Qt.PointingHandCursor)

        self.start_button.setStyleSheet(f"""
                    QPushButton {{
                        border: none;
                        border-radius: 5px;
                        padding: 10px 20px;
                    }}
                """)

        # Quit button
        self.btnb = QPushButton("❌ Close")
        self.btnb.setFont(QFont("Arial", 12))
        self.btnb.setMinimumHeight(50)
        self.btnb.setCursor(Qt.PointingHandCursor)

        self.btnb.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {btn_color};
                        color: white;
                        border: none;
                        border-radius: 5px;
                        padding: 10px 20px;
                    }}
                    QPushButton:hover {{
                        background-color: {btn_hover};
                    }}
                    QPushButton:pressed {{
                        background-color: {self.darken_color(btn_color)};
                    }}
                """)
        self.btnb.clicked.connect(self.close)

        layout.addWidget(self.btnb, 0, Qt.AlignCenter)

    def get_led_style(self, color):
        """Get LED style based on color"""
        colors = {
            'red': '#ff4444',
            'green': '#44ff44',
            'orange': 'orange',
            'white': '#f0f5a9'
        }
        return f"""
            QLabel {{
                background-color: {colors[color]};
                border: 2px solid #333;
                border-radius: 20px;
                text-align: center;
            }}
        """

    def cal_ended(self):
        self.start_button.setDisabled(False)
        self.btnb.setDisabled(False)

    def set_led(self, state: int):
        """Toggle LED state"""
        if state == -2:
            color = 'white'
        else:
            color = 'green' if state == 1 else 'red' if state == 0 else 'orange'

        self.thru_led.setStyleSheet(self.get_led_style(color))
        if state == 1 and self.callback is not None:
                self.callback('norm')

    def load_settings(self):
        """Load default settings into fields"""
        self.kit_edit.setText(self.norm_settings['kit'])

    def get_settings(self):
        """Get current settings from fields"""
        return {
            'kit': self.kit_edit.text(),
            'freq_start_GHz': self.band_settings['start'],
            'freq_end_GHz': self.band_settings['stop'],
            'num_points': self.band_settings['num_points'],
            'bandwidth': self.band_settings['bandwidth'],
            'is_rs': self.is_rs,
            'ip_address': self.ip_address
        }

    def start_norm(self):
        """Start Norm calibration"""
        if self.callback is not None:
            self.callback('none')
        self.set_led(-1)
        self.start_button.setDisabled(True)
        self.btnb.setDisabled(True)
        norm_settings = self.get_settings()
        worker = NormWorker(norm_settings)
        self._start_worker(worker)


    def lighten_color(self, hex_color):
        """Lighten a hex color"""
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        lighter_rgb = tuple(min(255, int(c + (255 - c) * 0.3)) for c in rgb)
        return f'#{lighter_rgb[0]:02x}{lighter_rgb[1]:02x}{lighter_rgb[2]:02x}'

    def darken_color(self, hex_color):
        """Darken a hex color"""
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        darker_rgb = tuple(max(0, int(c * 0.8)) for c in rgb)
        return f'#{darker_rgb[0]:02x}{darker_rgb[1]:02x}{darker_rgb[2]:02x}'

    def center_window(self):
        """Center the window on screen"""
        screen = QApplication.primaryScreen().geometry()
        window_geometry = self.frameGeometry()
        center_point = screen.center()
        window_geometry.moveCenter(center_point)
        self.move(window_geometry.topLeft())

    def mousePressEvent(self, event):
        """Handle mouse press for window dragging"""
        if event.button() == Qt.LeftButton:
            self.dragging = True
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        """Handle mouse move for window dragging"""
        if self.dragging and event.buttons() == Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()

    def mouseReleaseEvent(self, event):
        """Handle mouse release for window dragging"""
        if event.button() == Qt.LeftButton:
            self.dragging = False
            event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    cfg = load_config('../config.toml')
    band_settings = {
        'num_points': 5001,
        'meas_bandwidth': '1kHz',
        'band_id': 3,
        'band_cfg': cfg.get_band('J-Band'),
    }
    window = NormWindow(band_settings=band_settings, ip_address='192.168.0.5', is_rs=False)
    window.exec()
    sys.exit(app.exec())