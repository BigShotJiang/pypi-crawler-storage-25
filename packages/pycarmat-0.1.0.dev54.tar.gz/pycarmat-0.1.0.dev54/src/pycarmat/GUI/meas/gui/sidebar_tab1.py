import contextlib
import os
from datetime import datetime
from pathlib import Path
from time import sleep

from PySide6.QtWidgets import QVBoxLayout, QPushButton, QLineEdit, \
    QLabel, QComboBox, QFileDialog, QCheckBox, QProgressBar, QGroupBox, QGridLayout, QDoubleSpinBox, \
    QAbstractSpinBox
from numpy import arange
import serial.tools.list_ports

from skrf import Network
from pycarmat.ressources.ESP import ESP30xController, UNIT
from pycarmat.ressources.VNA import RohdeSchwarzVNA, KeysightVNA
from .axes_settings_gui import AxesSettingsWindow
from .core import Worker, Tab
from .manual_trl_gui import ManualTRLWindow
from .trl_gui import TRLWindow
from .norm_gui import NormWindow
from .vna_config import load_config, BandConfig, save_init_config_path, ConfigError, load_init_config_path


class QInt(QDoubleSpinBox):
    def __init__(self, default: int = 0., arrows: bool = True):
        super().__init__()
        self.setMaximum(90000)
        self.setDecimals(0)
        if not arrows:
            self.setButtonSymbols(QDoubleSpinBox.NoButtons)
        self.setValue(default)


class QDouble(QDoubleSpinBox):
    def __init__(self, default: float = 0., arrows: bool = False):
        super().__init__()
        self.setDecimals(3)
        self.setRange(-2000., 2000.)
        self.setStepType(QAbstractSpinBox.AdaptiveDecimalStepType)
        if not arrows:
            self.setButtonSymbols(QDoubleSpinBox.NoButtons)
        self.setValue(default)


class ResetWorker(Worker):
    def _run(self):
        ip_address = self.params['ip_address']
        __vna__ = RohdeSchwarzVNA if self.params['is_rs'] else KeysightVNA
        with __vna__(ip_address=ip_address, simulate=False) as vna:
            vna.reset()


class MeasureWorker(Worker):
    def _run(self):
        self._running = True

        ip_address = self.params['ip_address']
        range_freq_GHz = self.params['range_freq_GHz']
        num_freq_points = self.params['num_freq_points']
        meas_bandwidth = self.params['meas_bandwidth']
        num_meas = self.params['num_meas']
        cal_id = self.params['cal_id']
        cal_type = self.params['cal_type']
        band = self.params['band']
        angles_deg = self.params['angles']
        refl_mode = self.params['refl_mode']
        esp_axis2_enabled = self.params['esp_axis2_enabled']
        esp_port = self.params['esp_port']

        sub_folder = self.params['sub_folder']

        mat_name = self.params['mat_name']
        mat_properties = self.params['mat_properties']
        mat_properties = f"_{mat_properties}".replace(".", "-") if mat_properties else ''

        if mat_name == '':
            self.error_signal.emit(str('Material name cannot be empty'))
            self.progress_signal.emit(0)
            self.finished.emit()
            return

        axis_rot = 2
        cal_subfolder = f'/trl{cal_id:02d}' if cal_type != 'none' else ''

        __vna__ = RohdeSchwarzVNA if self.params['is_rs'] else KeysightVNA

        today = datetime.today().strftime("%Y%m%d")  # Format YYYYMMDD
        with (__vna__(ip_address=ip_address, simulate=False) as vna, \
              ESP30xController(port=esp_port, raise_error=False)
              if esp_axis2_enabled else contextlib.nullcontext() as esp):

            results_dirpath = f'{sub_folder}/{band}/{today}/{mat_name}{mat_properties}{cal_subfolder}'
            os.makedirs(results_dirpath, exist_ok=self.params['overwrite'])

            if esp_axis2_enabled:
                esp.set_motion_parameters(axis_rot, (2.0, 5.0, 5.0))

            idx_meas = 0
            for angle_deg in angles_deg:
                _angle_deg_esp = angle_deg + 45. if refl_mode else angle_deg
                if esp_axis2_enabled and esp.connected():
                    # change the angle only if a motor is detected or if user asks to use current settings
                    esp.clear_errors()
                    esp.move_absolute(axis=axis_rot, value=_angle_deg_esp, motion_unit=UNIT.ROTATION_DEG)

                vna.set_sweep(freq_start_GHz=range_freq_GHz[0], freq_end_GHz=range_freq_GHz[1],
                              num_pts=num_freq_points,
                              bandwidth=meas_bandwidth)

                for i in range(num_meas):
                    if not self._running:
                        return

                    suffix = '-refl' if refl_mode else ''

                    if esp_axis2_enabled:
                        angle_str = f'{angle_deg:05.2f}'.replace('.', '-')
                        filename = f"{mat_name}_ang{angle_str}{suffix}_{i:03d}.s2p"
                    else:
                        filename = f"{mat_name}{suffix}_{i:03d}.s2p"

                    s2p = vna.measure(num_iterations=1, return_format='s2p',
                                      file_path=f'{results_dirpath}/{filename}')
                    self.result_signal.emit(s2p)
                    idx_meas += 1
                    self.progress_signal.emit(idx_meas)

    def stop(self):
        self._running = False

class SidebarS2P(Tab):

    def __init__(self, gui_elements: tuple, **kargs):
        super().__init__(gui_elements, **kargs)

        # ── Load configuration (blocking on error) ────────────────────────────
        self._cfg = self._load_config_or_abort()
        # ─────────────────────────────────────────────────────────────────────
        self._cal_indexes = {
            'trl' : 0,
            'norm' : 0,
        }

        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        self._previous_dir_path = 'none'
        self._vna_locked = False
        layout.addStretch()

        self.group_box = QGroupBox("Enable VNA sweep")
        self.group_box.setCheckable(True)  # Allows toggling
        self.group_box.setChecked(True)  # Initially expanded
        self.group_box.toggled.connect(self.set_status)

        group_layout = QGridLayout(self.group_box)

        self.group_box_con = QGroupBox("Connection")
        self.group_box_con.setCheckable(False)
        self.group_box_con.setChecked(True)
        group_layout_con = QGridLayout(self.group_box_con)
        group_layout_con.addWidget(QLabel("IP Address"), 0, 0)
        self.ip_address = QLineEdit(self._cfg.keysight_ip)
        group_layout_con.addWidget(self.ip_address, 0, 2)
        self.ip_address.setFixedWidth(101)

        self._config_path_label = QLabel(self._cfg.source_path.name)
        self._config_path_label.setStyleSheet("color: grey; font-size: 9px;")
        self._browse_config_button = QPushButton("Browse config…")
        self._browse_config_button.clicked.connect(self._browse_config_file)
        group_layout_con.addWidget(self._browse_config_button, 1, 0, 1, 2)
        group_layout_con.addWidget(self._config_path_label, 1, 2)

        group_layout.addWidget(self.group_box_con, 0, 0)

        def brand_combo_changed(index: int):
            self.ip_address.setText(self._cfg.rs_ip if index == 0 else self._cfg.keysight_ip)

        self.brand_combo = QComboBox()
        self.brand_combo.addItems(["R&S", "Keysight"])
        group_layout_con.addWidget(self.brand_combo, 0, 1)
        self.brand_combo.currentIndexChanged.connect(brand_combo_changed)
        # NOTE: _on_brand_combo_changed is connected AFTER band_combo is created
        # (see below), to avoid an AttributeError during __init__.

        self.group_box_sweep = QGroupBox("Sweep settings")
        self.group_box_sweep.setCheckable(False)
        self.group_box_sweep.setChecked(True)
        group_layout_sweep = QGridLayout(self.group_box_sweep)
        group_layout_sweep.addWidget(QLabel("Band"), 3, 0)
        self.band_combo = QComboBox()
        # Items are populated by _on_brand_combo_changed, triggered below via setCurrentIndex.
        self.band_combo.currentIndexChanged.connect(self._on_band_combo_changed)
        group_layout_sweep.addWidget(self.band_combo, 3, 1)

        # --- Custom band frequency inputs (hidden by default) ---
        self._custom_start_label = QLabel("Start freq. [GHz]")
        self._custom_start_spin = QDoubleSpinBox(decimals=3, minimum=0.001, maximum=5000.0, value=100.0)
        self._custom_start_spin.setButtonSymbols(QDoubleSpinBox.NoButtons)
        self._custom_stop_label = QLabel("Stop freq. [GHz]")
        self._custom_stop_spin = QDoubleSpinBox(decimals=3, minimum=0.001, maximum=5000.0, value=200.0)
        self._custom_stop_spin.setButtonSymbols(QDoubleSpinBox.NoButtons)
        group_layout_sweep.addWidget(self._custom_start_label, 4, 0)
        group_layout_sweep.addWidget(self._custom_start_spin, 4, 1)
        group_layout_sweep.addWidget(self._custom_stop_label, 5, 0)
        group_layout_sweep.addWidget(self._custom_stop_spin, 5, 1)
        self._custom_start_label.setVisible(False)
        self._custom_start_spin.setVisible(False)
        self._custom_stop_label.setVisible(False)
        self._custom_stop_spin.setVisible(False)
        # --------------------------------------------------------

        group_layout_sweep.addWidget(QLabel("Num. Points"), 6, 0)
        default_band = self._cfg.bands[0] if self._cfg.bands else None
        self.num_points = QInt(default_band.num_points if default_band else 1001)
        group_layout_sweep.addWidget(self.num_points, 6, 1)

        group_layout_sweep.addWidget(QLabel("Meas. Bandwidth"), 7, 0)
        self.meas_bandwidth = QComboBox()
        self.meas_bandwidth.addItems(["1 kHz", "10 kHz", "100 kHz"])
        default_bw = default_band.bandwidth if default_band else "1 kHz"
        bw_index = {"1 kHz": 0, "10 kHz": 1, "100 kHz": 2}.get(default_bw, 0)
        self.meas_bandwidth.setCurrentIndex(bw_index)
        group_layout_sweep.addWidget(self.meas_bandwidth, 7, 1)

        # All widgets that slots depend on are now created — safe to connect and
        # trigger brand_combo signals.
        self.brand_combo.currentIndexChanged.connect(self._on_brand_combo_changed)
        self.brand_combo.setCurrentIndex(1)   # triggers brand_combo_changed + _on_brand_combo_changed

        group_layout.addWidget(QLabel(''), 1, 0)
        group_layout.addWidget(self.group_box_sweep, 2, 0)

        self.eps_axis1_enabled = False
        self.esp_axis2_enabled = False
        self.eps_axis2_homing = False
        # ── ESP port selector ─────────────────────────────────────────────
        self.group_box_esp = QGroupBox("ESP Motion Controller")
        group_layout_esp = QGridLayout(self.group_box_esp)

        group_layout_esp.addWidget(QLabel("Serial port"), 0, 0)
        self._esp_port_combo = QComboBox()
        group_layout_esp.addWidget(self._esp_port_combo, 0, 1)

        self._esp_refresh_btn = QPushButton("↺")
        self._esp_refresh_btn.setFixedWidth(52)
        self._esp_refresh_btn.setToolTip("Refresh port list")
        self._esp_refresh_btn.clicked.connect(self._refresh_esp_ports)
        group_layout_esp.addWidget(self._esp_refresh_btn, 0, 2)

        self._esp_status_label = QLabel("")
        self._esp_status_label.setStyleSheet("color: grey; font-size: 9px;")
        group_layout_esp.addWidget(self._esp_status_label, 1, 0, 1, 3)

        layout.insertWidget(layout.count() - 1, self.group_box_esp)  # before trailing stretch
        # ─────────────────────────────────────────────────────────────────

        self.group_box_meas = QGroupBox("Meas. settings")
        self.group_box_meas.setCheckable(False)
        self.group_box_meas.setChecked(True)
        group_layout_meas = QGridLayout(self.group_box_meas)
        self.cal_index_label = QLabel("Cal. Index")
        group_layout_meas.addWidget(self.cal_index_label, 6, 0)
        self.cal_index = QInt(0)
        group_layout_meas.addWidget(self.cal_index, 6, 1)
        self.cal_index_label.setDisabled(True)
        self.cal_index.setDisabled(True)
        self.norm_button = QPushButton("Norm")
        self.trl_button = QPushButton("TRL")
        self.manual_trl_button = QPushButton("TRL")
        self._cal_type = 'none'
        self.manual_trl_button.clicked.connect(lambda: ManualTRLWindow(callback=self._cal_changed).exec())
        self.manual_trl_button.setVisible(False)
        self.trl_button.clicked.connect(lambda: TRLWindow(band_settings={
            'num_points':       int(self.num_points.text()),
            'meas_bandwidth':   self.meas_bandwidth.currentText(),
            'band_id':          self.band_combo.currentIndex(),
            'custom_start_GHz': self._custom_start_spin.value(),
            'custom_stop_GHz':  self._custom_stop_spin.value(),
            'band_cfg':         self._cfg.get_band(self.band_combo.currentText()),
        }, ip_address=self.ip_address.text(), is_rs=self.brand_combo.currentIndex() == 0,
            callback=self._cal_changed).exec())
        self.norm_button.clicked.connect(lambda: NormWindow(band_settings={
            'num_points':       int(self.num_points.text()),
            'meas_bandwidth':   self.meas_bandwidth.currentText(),
            'band_id':          self.band_combo.currentIndex(),
            'custom_start_GHz': self._custom_start_spin.value(),
            'custom_stop_GHz':  self._custom_stop_spin.value(),
            'band_cfg':         self._cfg.get_band(self.band_combo.currentText()),
        }, ip_address=self.ip_address.text(), is_rs=self.brand_combo.currentIndex() == 0,
            callback=self._cal_changed).exec())
        group_layout_meas.addWidget(self.norm_button, 6, 2)
        group_layout_meas.addWidget(self.trl_button, 6, 3)
        group_layout_meas.addWidget(self.manual_trl_button, 6, 3)

        group_layout_meas.addWidget(QLabel("Num. of sweep(s)"), 7, 0)
        self.num_meas = QInt(1)
        group_layout_meas.addWidget(self.num_meas, 7, 1, 1, 3)

        group_layout_meas.addWidget(QLabel("Material name"), 8, 0)
        self.material_name = QLineEdit("")
        group_layout_meas.addWidget(self.material_name, 8, 1, 1, 3)

        group_layout_meas.addWidget(QLabel("Properties"), 9, 0)
        self.material_properties = QLineEdit("")
        group_layout_meas.addWidget(self.material_properties, 9, 1, 1, 3)
        self.material_angle_label = QLabel("Angle(s) [°]")
        group_layout_meas.addWidget(self.material_angle_label, 10, 0)
        self.material_angle_start = QDoubleSpinBox(suffix='°', prefix='From: ', decimals=1, minimum=-45, maximum=45)
        self.material_angle_end = QDoubleSpinBox(suffix='°', prefix='to: ', decimals=1, minimum=-45, maximum=45)
        self.material_angle_step = QDoubleSpinBox(suffix='°', prefix='step: ', decimals=1, value=1, minimum=0)
        group_layout_meas.addWidget(self.material_angle_start, 10, 1)
        group_layout_meas.addWidget(self.material_angle_end, 10, 2)
        group_layout_meas.addWidget(self.material_angle_step, 10, 3)
        self.material_angle_start.setFixedWidth(101)
        self.material_angle_end.setFixedWidth(86)
        self.material_angle_step.setFixedWidth(86)

        self.angle_reset_button = QPushButton("Reset Rot.")
        self.angle_homing_button = QPushButton("Homing Rot.")
        self.angle_reset_button.clicked.connect(self.reset_angle)
        self.angle_homing_button.clicked.connect(self.homing_angle)
        group_layout_meas.addWidget(self.angle_reset_button, 11, 0)
        if self.eps_axis2_homing:
            group_layout_meas.addWidget(self.angle_homing_button, 11, 1)
        self.refl_mode = QCheckBox("Refl. mode")
        group_layout_meas.addWidget(self.refl_mode, 11,
                                    2 if self.eps_axis2_homing else 1, 1, 2 if self.eps_axis2_homing else 3)


        group_layout.addWidget(QLabel(''), 3, 0)
        group_layout.addWidget(self.group_box_meas, 4, 0)

        self.group_box_output = QGroupBox("Output")
        self.group_box_output.setCheckable(False)
        self.group_box_output.setChecked(True)
        group_layout_output = QGridLayout(self.group_box_output)
        self.choose_dir_button = QPushButton("Project data dir.")
        self.choose_dir_button.clicked.connect(self.choose_root_dir)
        self.sub_folder = QLineEdit('')
        self.sub_folder.setReadOnly(True)
        self.set_default_root_dir()
        self.overwrite_switch = QCheckBox("Replace files if exists")
        group_layout_output.addWidget(self.choose_dir_button, 11, 0)
        group_layout_output.addWidget(self.sub_folder, 11, 1)
        group_layout_output.addWidget(self.overwrite_switch, 12, 1)

        group_layout.addWidget(QLabel(''), 5, 0)
        group_layout.addWidget(self.group_box_output, 6, 0)

        group_layout.addWidget(QLabel(''), 7, 0)
        self.start_button = QPushButton("Start")
        self.start_button.setStyleSheet("background-color: #339955; color: #fff; padding:10px")
        self.start_button.clicked.connect(self.measure_s2p)
        group_layout.addWidget(self.start_button, 8, 0)

        self.stop_button = QPushButton("Stop")
        self.stop_button.setStyleSheet("background-color: #993355; color: #fff; padding:10px")
        self.stop_button.clicked.connect(self.stop_measure)
        self.stop_button.setVisible(False)
        group_layout.addWidget(self.stop_button, 9, 0)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        group_layout.addWidget(self.progress_bar, 10, 0)

        group_layout.addWidget(QLabel(''), 11, 0)
        self.reset_button = QPushButton("Reset VNA Display")
        self.reset_button.setStyleSheet("background-color: #36185c; color: #fff; padding:10px")
        self.reset_button.clicked.connect(self.reset_vna)
        group_layout.addWidget(self.reset_button, 12, 0)

        layout.addWidget(self.group_box)

        self.load_s2p_button = QPushButton("Load s2p")
        self.load_s2p_button.setStyleSheet("background-color: #2266aa; color: #fff;")
        self.load_s2p_button.clicked.connect(self.load_s2p_file)
        layout.addWidget(self.load_s2p_button)

        layout.addStretch()

        self._refresh_esp_ports()  # populate list
        self._esp_port_combo.currentIndexChanged.connect(self._on_esp_port_changed)

    def _cal_changed(self, cal_type:str):
        self._cal_type = cal_type
        self.cal_index_label.setDisabled(cal_type == 'none')
        self.cal_index.setDisabled(cal_type == 'none')
        if cal_type is not None:
            if self.cal_index.value() > self._cal_indexes[cal_type]:
                self._cal_indexes[cal_type] = int(self.cal_index.value())
            self._cal_indexes[cal_type] += 1
            self.cal_index.setValue(self._cal_indexes[cal_type])

    # ------------------------------------------------------------------
    # Configuration loading
    # ------------------------------------------------------------------

    def _load_config_or_abort(self, path=None):
        """
        Load the VNA config and return a :class:`VNAConfig`.
        On failure shows a blocking critical dialog and exits the application.
        """
        from PySide6.QtWidgets import QMessageBox
        try:
            return load_config(path)
        except Exception as exc:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setWindowTitle("Configuration Error")
            msg.setText("Failed to load the VNA configuration file.")
            msg.setInformativeText(str(exc))
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec()
            import sys as _sys
            _sys.exit(1)

    def _browse_config_file(self):
        """
        Open a file dialog to pick a new config.toml, reload the config,
        and persist the chosen path to init.toml.
        On parse/validation error shows a blocking critical dialog and exits.
        """
        from PySide6.QtWidgets import QFileDialog
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select config file",
            str(self._cfg.source_path.parent),
            "TOML Files (*.toml);;All Files (*)",
        )
        if not file_path:
            return   # user cancelled — keep current config

        new_cfg = self._load_config_or_abort(path=file_path)

        # Persist the new path to init.toml
        save_init_config_path(file_path)

        # Reload all config-driven GUI state
        self._cfg = new_cfg
        self._config_path_label.setText(Path(file_path).name)

        # Refresh IP addresses
        self.ip_address.setText(
            self._cfg.rs_ip if self.brand_combo.currentIndex() == 0
            else self._cfg.keysight_ip
        )

        # Rebuild band_combo for the current brand (delegates to _on_brand_combo_changed)
        self._on_brand_combo_changed(self.brand_combo.currentIndex())

    # ------------------------------------------------------------------
    # Custom band helpers
    # ------------------------------------------------------------------

    def _on_band_combo_changed(self, index: int):
        """Show/hide Custom frequency inputs and update num_points/bandwidth from config."""
        band_name = self.band_combo.currentText()
        is_custom = (band_name == 'Custom')
        self._custom_start_label.setVisible(is_custom)
        self._custom_start_spin.setVisible(is_custom)
        self._custom_stop_label.setVisible(is_custom)
        self._custom_stop_spin.setVisible(is_custom)

        # Update num_points and bandwidth from the band's config when not Custom
        if not is_custom:
            band_cfg = self._cfg.get_band(band_name)
            if band_cfg is not None:
                self.num_points.setValue(band_cfg.num_points)
                bw_index = {"1 kHz": 0, "10 kHz": 1, "100 kHz": 2}.get(band_cfg.bandwidth, 0)
                self.meas_bandwidth.setCurrentIndex(bw_index)

    def _on_brand_combo_changed(self, index: int):
        """Rebuild band_combo to only show bands available for the selected VNA brand.

        Bands whose ``vna`` list does not include the current brand are fully
        removed from the combo (not just greyed out).  The Custom entry is always
        present.  If the previously selected band is no longer available the
        selection falls back to the first available band.
        """
        brand = 'R&S' if index == 0 else 'Keysight'
        available_names = self._cfg.band_names_for_brand(brand) + ['Custom']

        current_band = self.band_combo.currentText()
        self.band_combo.blockSignals(True)
        self.band_combo.clear()
        self.band_combo.addItems(available_names)
        # Restore previous selection if still available, otherwise pick first
        if current_band in available_names:
            self.band_combo.setCurrentIndex(available_names.index(current_band))
        else:
            self.band_combo.setCurrentIndex(0)
        self.band_combo.blockSignals(False)
        # Manually fire the band slot since signals were blocked during rebuild
        self._on_band_combo_changed(self.band_combo.currentIndex())

    def _get_freq_range_GHz(self) -> tuple:
        """Return the (start, stop) frequency range in GHz for the current band selection."""
        band_name = self.band_combo.currentText()
        if band_name == 'Custom':
            return (self._custom_start_spin.value(), self._custom_stop_spin.value())
        band_cfg = self._cfg.get_band(band_name)
        if band_cfg is not None:
            return (band_cfg.start_GHz, band_cfg.stop_GHz)
        raise RuntimeError(f"Unknown band '{band_name}' — not found in config.")

    # ------------------------------------------------------------------

    def deactivate_eps(self, axis1=False, axis2=False, axis2_homing=False):
        self.eps_axis1_enabled = not axis1
        self.esp_axis2_enabled = not axis2
        self.eps_axis2_homing = axis2_homing
        self.trl_button.setVisible(self.eps_axis1_enabled )
        self.manual_trl_button.setVisible(not self.eps_axis1_enabled )
        self.angle_reset_button.setVisible(self.esp_axis2_enabled)
        self.angle_homing_button.setVisible(self.esp_axis2_enabled)
        self.material_angle_label.setVisible(self.esp_axis2_enabled)
        self.material_angle_start.setVisible(self.esp_axis2_enabled)
        self.material_angle_end.setVisible(self.esp_axis2_enabled)
        self.material_angle_step.setVisible(self.esp_axis2_enabled)
        self.angle_homing_button.setVisible(self.esp_axis2_enabled and not axis2_homing)

    def set_default_root_dir(self):
        previous_chosen_dirpath = self._previous_dir_path if self._previous_dir_path != 'none' else './measures'
        default_dir = previous_chosen_dirpath
        self.sub_folder.setText(default_dir)

    def choose_root_dir(self):
        default_dir = './measures'
        dir_path = QFileDialog.getExistingDirectory(self, "Select root dir", f"./{default_dir}")
        if dir_path:
            self._previous_dir_path = dir_path
            self.sub_folder.setText(dir_path)

    def load_s2p_file(self):
        self.progress_bar.setValue(0)
        file_path, _ = QFileDialog.getOpenFileName(self, "Select s2p File", "", "Touchstone Files (*.s2p)")
        if file_path:
            self.group_box.setChecked(False)
            ntw = Network(file_path)
            self.tabs[0].update_graph(ntw)

    def reset_vna(self):
        params = {
            'ip_address': self.ip_address.text(),
            'is_rs': self.brand_combo.currentIndex() == 0
        }

        worker = ResetWorker(self, params)
        worker.finished.connect(self.release_vna)

        self._start_worker(worker)
        self.lock_vna()

    def homing_angle(self):
        port = self._esp_port_combo.currentText()
        if not port:
            return
        with ESP30xController(port=port, raise_error=False) as esp:
            if esp.connected() and self.esp_axis2_enabled:
                esp.clear_errors()
                esp.set_motion_parameters(2, (5.0, 10.0, 10.0))
                esp.homing(axis=2)

    def reset_angle(self):
        port = self._esp_port_combo.currentText()
        if not port:
            return
        with ESP30xController(port=port, raise_error=False) as esp:
            if esp.connected() and self.esp_axis2_enabled:
                esp.clear_errors()
                esp.set_motion_parameters(2, (10.0, 5.0, 5.0))
                esp.move_absolute(axis=2, value=0, motion_unit=UNIT.ROTATION_DEG)

    def measure_s2p(self):
        if self._vna_locked:
            return

        band = self.band_combo.currentText()
        range_freq_GHz = self._get_freq_range_GHz()

        angles_array = arange(self.material_angle_start.value(),
                              self.material_angle_end.value() + self.material_angle_step.value(),
                              self.material_angle_step.value())
        params = {
            'band': band,
            'ip_address': self.ip_address.text(),
            'range_freq_GHz': range_freq_GHz,
            'num_freq_points': int(self.num_points.value()),
            'meas_bandwidth': self.meas_bandwidth.currentText(),
            'num_meas': int(self.num_meas.value()),
            'mat_name': self.material_name.text(),
            'mat_properties': self.material_properties.text(),
            'cal_id': int(self.cal_index.value()),
            'cal_type': self._cal_type,
            'overwrite': self.overwrite_switch.isChecked(),
            'angles': angles_array,
            'refl_mode': self.refl_mode.isChecked(),
            'sub_folder': self.sub_folder.text(),
            'is_rs': self.brand_combo.currentIndex() == 0,
            'esp_axis2_enabled': self.esp_axis2_enabled,
            'esp_port': self._esp_port_combo.currentText()
        }

        self.progress_bar.setMaximum(int(self.num_meas.text()) * angles_array.shape[0])

        worker = MeasureWorker(self, params)
        worker.result_signal.connect(lambda ntw: self.tabs[0].update_graph(ntw))
        worker.finished.connect(self.release_vna)

        self._start_worker(worker)
        self.lock_vna()

    def stop_measure(self):
        if self.worker is not None:
            self.worker.stop()

    def lock_vna(self):
        self._vna_locked = True
        self.group_box_con.setEnabled(False)
        self.group_box_sweep.setEnabled(False)
        self.group_box_meas.setEnabled(False)
        self.group_box_output.setEnabled(False)
        self.start_button.setVisible(False)
        self.stop_button.setVisible(True)
        self.progress_bar.setValue(0)

    def release_vna(self):
        self._vna_locked = False
        self.group_box_con.setEnabled(True)
        self.group_box_sweep.setEnabled(True)
        self.group_box_meas.setEnabled(True)
        self.group_box_output.setEnabled(True)
        self.start_button.setVisible(True)
        self.stop_button.setVisible(False)

    # ------------------------------------------------------------------
    # ESP port helpers
    # ------------------------------------------------------------------

    def _refresh_esp_ports(self):
        """Repopulate the port combo with currently visible serial ports."""
        ports = [f"ASRL{p.device}"
                 for p in serial.tools.list_ports.comports()
                 if p.vid is not None]
        self._esp_port_combo.blockSignals(True)
        current = self._esp_port_combo.currentText()
        self._esp_port_combo.clear()
        if ports:
            self._esp_port_combo.addItems(ports)
            # Restore previous selection if still present
            if current in ports:
                self._esp_port_combo.setCurrentText(current)
            else:
                self._try_connect_esp()
        else:
            self._esp_status_label.setText("No port available.")
            self.deactivate_eps(axis1=True, axis2=True)
        self._esp_port_combo.blockSignals(False)

    def _on_esp_port_changed(self, _index: int):
        """Called whenever the user picks a different port — retry connection."""
        self._try_connect_esp()

    def _try_connect_esp(self):
        """
        Attempt to connect to the ESP controller on the currently selected port.
        On success, run the stage-detection logic and update the UI accordingly.
        On failure (no ports / connection error), disable both axes.
        """
        port = self._esp_port_combo.currentText()
        if not port:
            self._esp_status_label.setText("No port available.")
            self.deactivate_eps(axis1=True, axis2=True)
            return

        with ESP30xController(port=port, raise_error=False) as esp:
            if esp.connected():
                stage1_model_name = esp.query('1ID?').split(',')[0]
                stage2_model_name = esp.query('2ID?').split(',')[0]
                if 'Unknown' in stage1_model_name:
                    stage1_model_name = None
                if 'Unknown' in stage2_model_name:
                    stage2_model_name = None
                detected_esp_stage_models = (stage1_model_name, stage2_model_name)
                self._esp_status_label.setText(
                    f"Connected — axes: {stage1_model_name or '?'}, {stage2_model_name or '?'}"
                )
                if stage1_model_name is None or stage2_model_name is None:
                    AxesSettingsWindow(port, self.deactivate_eps, detected_esp_stage_models).exec()
                else:
                    self.deactivate_eps(axis1=False, axis2=False)
            else:
                self._esp_status_label.setText(f"Not found on {port}.")
                self.deactivate_eps(axis1=True, axis2=True)

    def set_status(self):
        bg_color = '339955' if self.group_box.isChecked() else '444'
        txt_color = 'fff' if self.group_box.isChecked() else '111'
        self.start_button.setStyleSheet(f'background-color: #{bg_color}; color: #{txt_color}; padding:10px')