import math

from PySide6.QtGui import QPalette, QValidator
from PySide6.QtWidgets import QMessageBox, QWidget, QApplication, QDoubleSpinBox
from PySide6.QtCore import QThread

import sys
import subprocess

def is_dark_mode() -> bool:
    if sys.platform == 'win32':
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                r'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize')
            val, _ = winreg.QueryValueEx(key, 'AppsUseLightTheme')
            return val == 0
        except Exception:
            return False

    if sys.platform == 'darwin':
        try:
            out = subprocess.check_output(
                ['defaults', 'read', '-g', 'AppleInterfaceStyle'],
                stderr=subprocess.DEVNULL, timeout=1
            ).decode().strip()
            return out.lower() == 'dark'
        except Exception:
            return False  # pas de clé = light mode

    # Linux
    try:
        out = subprocess.check_output(
            ['gsettings', 'get', 'org.gnome.desktop.interface', 'color-scheme'],
            stderr=subprocess.DEVNULL, timeout=1
        ).decode().strip().strip("'")
        return 'dark' in out.lower()
    except Exception:
        pass

    try:
        out = subprocess.check_output(
            ['gsettings', 'get', 'org.gnome.desktop.interface', 'gtk-theme'],
            stderr=subprocess.DEVNULL, timeout=1
        ).decode().strip().lower()
        return 'dark' in out
    except Exception:
        pass

    # Fallback Qt
    app = QApplication.instance()
    if app:
        bg = app.palette().color(QPalette.Window)
        return (0.299 * bg.redF() + 0.587 * bg.greenF() + 0.114 * bg.blueF()) < 0.5

    return False


class NaNSpinBox(QDoubleSpinBox):
    _NAN_TEXT = 'NaN'

    def __init__(self, *args, value=None, **kwargs):
        self._is_nan = False
        super().__init__(*args, **kwargs)
        self.__suffix = self.suffix()
        # Surveille toute réécriture du lineEdit par Qt
        self.lineEdit().textChanged.connect(self._on_text_changed)
        if value is not None and math.isnan(value):
            self._set_nan()
        elif value is not None:
            super().setValue(value)

    def _set_nan(self):
        self._is_nan = True
        self.lineEdit().blockSignals(True)
        self.lineEdit().setText(self._NAN_TEXT)
        self.lineEdit().blockSignals(False)
        self.setSuffix('')

    def _on_text_changed(self, text: str):
        # Qt a réécrit le champ → restaure NaN si nécessaire
        if self._is_nan and text.strip() != self._NAN_TEXT:
            self._set_nan()

    def setValue(self, val: float):
        if math.isnan(val):
            self._set_nan()
        else:
            self._is_nan = False
            self.setSuffix(self.__suffix)
            super().setValue(val)

    def value(self) -> float:
        if self._is_nan:
            return float('nan')
        return super().value()

    def textFromValue(self, val: float) -> str:
        if self._is_nan or math.isnan(val):
            return self._NAN_TEXT
        return super().textFromValue(val)

    def valueFromText(self, text: str) -> float:
        if text.strip() == self._NAN_TEXT:
            return float('nan')
        return super().valueFromText(text)

    def validate(self, text: str, pos: int):
        if text.strip() == self._NAN_TEXT:
            return (QValidator.Acceptable, text, pos)
        return super().validate(text, pos)


class Tab(QWidget):
    def __init__(self, gui_elements: tuple, **kargs):
        super().__init__()
        self.tabs = gui_elements
        self.gui = object()
        self.vars = object()
        self.worker = None
        self.thread = None
        self.progress_bar = None

        if 'min_width' in kargs:
            self.setMinimumWidth(kargs['min_width'])
        if 'width' in kargs:
            self.setFixedWidth(kargs['width'])
        if 'min_height' in kargs:
            self.setMinimumHeight(kargs['min_height'])
        if 'height' in kargs:
            self.setFixedHeight(kargs['height'])

        self._init()

    def _init(self):
        pass

    def _start_worker(self, worker):
        self.worker = worker
        self.thread = QThread()
        self.thread.started.connect(self.worker.start)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.error_signal.connect(self.show_error_dialog)
        self.worker.progress_signal.connect(self.progress_bar.setValue)

        self.thread.start()

    def show_error_dialog(self, message):
        msg_box = QMessageBox(self)
        msg_box.setIcon(QMessageBox.Critical)
        msg_box.setInformativeText(message)
        msg_box.setWindowTitle("Error")
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.exec()
