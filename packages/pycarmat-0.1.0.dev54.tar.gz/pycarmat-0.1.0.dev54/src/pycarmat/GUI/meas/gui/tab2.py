"""
tab2.py — Laser Spot Position Monitor
======================================
Displays real-time position of two laser spots (A and B) from a serial data
stream.  Each line of the stream must contain three comma-separated values:

    sensorA_x, sensorA_y, sensorA_sum, sensorB_x, sensorB_y, sensorB_sum

where coordinates are in mm (relative to the PSD centre) and sum_voltages is
the integrated signal voltage.

If sum_voltages < threshold (default 0.2 V) the laser is considered off /
not impacting the detector and a warning is drawn on the plot.
If no data is received the sensor is shown as "no signal".

Serial commands sent:
  CMD:SYSTEM:ON      — System on (sent on connect, and on READY received)
  CMD:SYSTEM:OFF     — System off (sent on disconnect)
  CMD:TX:A:1 / 0     — Laser A on/off
  CMD:TX:B:1 / 0     — Laser B on/off
  CMD:TTL:value      — Set TTL frequency (kHz)

Messages received:
  READY              — Pico just (re)booted; app replies with CMD:SYSTEM:ON
  xA,yA,sumA,xB,yB,sumB,stateA,stateB  — data frame
"""

import time
import threading
from collections import deque

import numpy as np
from PySide6.QtWidgets import (
    QVBoxLayout, QHBoxLayout, QGroupBox, QGridLayout,
    QLabel, QLineEdit, QDoubleSpinBox, QPushButton,
    QComboBox, QCheckBox, QSizePolicy, QWidget,
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPainter, QColor, QPen, QFont, QPalette
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.patches import Circle, Rectangle
import matplotlib.colors as mcolors

from .core import Tab, is_dark_mode

# ── Serial import (optional — graceful degradation) ────────────────────────
try:
    import serial
    import serial.tools.list_ports
    _SERIAL_AVAILABLE = True
except ImportError:
    _SERIAL_AVAILABLE = False

# ── Constants ───────────────────────────────────────────────────────────────
PSD_SIZE_MM = 9.0
HALF        = PSD_SIZE_MM / 2.0
GRID_DIVS   = 4
SPOT_RADIUS = 1.5
TIMEOUT_S   = 2.0
HISTORY_LEN = 8


# ── LED indicator widget ────────────────────────────────────────────────────
class LEDIndicator(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._on      = False
        self._unknown = True
        self.setFixedSize(20, 20)

    def set_on(self, on: bool):
        self._on      = on
        self._unknown = False
        self.update()

    def set_unknown(self):
        self._unknown = True
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        if self._unknown:
            color, glow, border = QColor('#888888'), QColor('#aaaaaa'), QColor('#555555')
        elif self._on:
            color, glow, border = QColor('#22dd66'), QColor('#66ffaa'), QColor('#118844')
        else:
            color, glow, border = QColor('#ff9922'), QColor('#ffcc66'), QColor('#cc6600')
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(glow.red(), glow.green(), glow.blue(), 60))
        painter.drawEllipse(1, 1, 18, 18)
        painter.setBrush(color)
        painter.setPen(QPen(border, 1.5))
        painter.drawEllipse(3, 3, 14, 14)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(255, 255, 255, 90))
        painter.drawEllipse(5, 5, 6, 5)


# ───────────────────────────────────────────────────────────────────────────
class SerialReader(threading.Thread):
    """Background thread — reads data frames and special messages."""

    def __init__(self, port: str, baudrate: int, data_callback, message_callback):
        super().__init__(daemon=True)
        self._port             = port
        self._baudrate         = baudrate
        self._data_callback    = data_callback     # called with list[float] for data frames
        self._message_callback = message_callback  # called with str for non-data lines
        self._stop_evt         = threading.Event()
        self._ser              = None
        self._ser_lock         = threading.Lock()

    def run(self):
        if not _SERIAL_AVAILABLE:
            return
        try:
            self._ser = serial.Serial(self._port, self._baudrate, timeout=0.05)
        except Exception:
            return

        while not self._stop_evt.is_set():
            try:
                raw = self._ser.read_all()
                if raw:
                    raw = raw.decode(errors='replace')
                    lines = raw.split('\n')
                    line = lines[-2] # -2 because last line is always empty (always end by \n)
                    line = line.strip()
                    if not line:
                        continue
                    parts = [p.strip() for p in line.split(',')]
                    if len(parts) == 9:
                        try:
                            vals = list(map(float, parts))
                            self._data_callback(vals)
                        except ValueError:
                            pass
                    else:
                        self._message_callback(line)
            except Exception:
                time.sleep(0.01)

        if self._ser and self._ser.is_open:
            self._ser.close()

    def send(self, command: str):
        if not _SERIAL_AVAILABLE:
            return
        with self._ser_lock:
            if self._ser and self._ser.is_open:
                try:
                    self._ser.write((command + '\n').encode())
                except Exception:
                    pass

    def stop(self):
        self._stop_evt.set()


# ───────────────────────────────────────────────────────────────────────────
class PSDCanvas(FigureCanvas):
    _COL_SPOT         = ('#ff4444', '#44aaff')
    _COL_GRID_DARK    = '#2a2a3a'
    _COL_GRID_LIGHT   = '#e0e0e8'
    _COL_BG_DARK      = '#12121c'
    _COL_BG_LIGHT     = '#f8f8fc'
    _COL_BORDER_DARK  = '#808080'
    _COL_BORDER_LIGHT = '#bbbbbb'

    def __init__(self, label: str, label_name: str, color_idx: int = 0, show_trails: bool = True):
        self._label       = label
        self._label_name  = label_name
        self._cidx        = color_idx
        self._show_trails = show_trails
        fig = Figure(figsize=(3.6, 3.6), dpi=96)
        fig.patch.set_alpha(0)
        super().__init__(fig)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._ax       = fig.add_subplot(111, aspect='equal')
        self._history  = deque(maxlen=HISTORY_LEN)
        self._state    = 'idle'
        self._laser_on = True
        self._pos      = (0.0, 0.0)
        self._sum_v    = 0.0
        self._draw_base()

    def update_state(self, state: str, x: float = 0.0, y: float = 0.0, sum_v: float = 0.0):
        self._state = state
        if state == 'ok':
            self._pos   = (x, y)
            self._sum_v = sum_v
            self._history.append((x, y))
        self._redraw()

    def set_laser_on(self, on: bool):
        self._laser_on = on

    def show_trails(self, display: bool):
        self._show_trails = display

    def _draw_base(self):
        ax   = self._ax
        dark = is_dark_mode()
        gc   = self._COL_GRID_DARK if dark else self._COL_GRID_LIGHT
        bc   = self._COL_BORDER_DARK if dark else self._COL_BORDER_LIGHT
        tc   = '#c8c8e8' if dark else '#303050'
        self.figure.patch.set_facecolor('none')
        rect = Rectangle((-HALF, -HALF), PSD_SIZE_MM, PSD_SIZE_MM,
                         linewidth=2, edgecolor=bc, facecolor='none', zorder=2)
        ax.add_patch(rect)
        step = PSD_SIZE_MM / GRID_DIVS
        for i in range(1, GRID_DIVS):
            v = -HALF + i * step
            ax.axvline(v, color=gc, linewidth=0.8, zorder=1)
            ax.axhline(v, color=gc, linewidth=0.8, zorder=1)
        ax.axvline(0, color=bc, linewidth=1.2, linestyle='--', alpha=0.6, zorder=1)
        ax.axhline(0, color=bc, linewidth=1.2, linestyle='--', alpha=0.6, zorder=1)
        ax.set_xlim(-HALF * 1.12, HALF * 1.12)
        ax.set_ylim(-HALF * 1.12, HALF * 1.12)
        ax.set_xlabel('X (mm)', color=tc, fontsize=8, labelpad=2)
        ax.set_ylabel('Y (mm)', color=tc, fontsize=8, labelpad=2)
        ax.tick_params(colors=tc, labelsize=7)
        for spine in ax.spines.values():
            spine.set_edgecolor(bc)
        spot_col = self._COL_SPOT[self._cidx % 2]
        ax.set_title(f'Sensor {self._label}\n({self._label_name})',
                     color=spot_col, fontsize=12, fontweight='bold', pad=6)
        self.figure.tight_layout(pad=0.6)

    def _redraw(self):
        ax       = self._ax
        dark     = is_dark_mode()
        tc       = '#c8c8e8' if dark else '#303050'
        bc       = self._COL_BORDER_DARK if dark else self._COL_BORDER_LIGHT
        spot_col = self._COL_SPOT[self._cidx % 2]
        ax.cla()
        ax.set_xlim(-HALF * 1.12, HALF * 1.12)
        ax.set_ylim(-HALF * 1.12, HALF * 1.12)
        ax.set_xlabel('X (mm)', color=tc, fontsize=8, labelpad=2)
        ax.set_ylabel('Y (mm)', color=tc, fontsize=8, labelpad=2)
        ax.tick_params(colors=tc, labelsize=7)
        for spine in ax.spines.values():
            spine.set_edgecolor(bc)
        ax.set_title(f'Sensor {self._label}\n({self._label_name})',
                     color=spot_col, fontsize=12, fontweight='bold', pad=6)
        ax.set_aspect('equal')

        bc_color = ('green' if self._state == 'ok' and
                    abs(self._pos[0]) < 1e-1 and abs(self._pos[1]) < 1e-1 else bc)
        lw = 5.0 if bc_color == 'green' else 2.0
        rect = Rectangle((-HALF, -HALF), PSD_SIZE_MM, PSD_SIZE_MM,
                         linewidth=lw, edgecolor=bc_color, facecolor='none', zorder=2)
        ax.add_patch(rect)

        gc = self._COL_GRID_DARK if dark else self._COL_GRID_LIGHT
        step = PSD_SIZE_MM / GRID_DIVS
        for i in range(1, GRID_DIVS):
            v = -HALF + i * step
            ax.axvline(v, color=gc, linewidth=0.8, zorder=1)
            ax.axhline(v, color=gc, linewidth=0.8, zorder=1)
        ax.axvline(0, color=bc, linewidth=1.2, linestyle='--', alpha=0.6, zorder=1)
        ax.axhline(0, color=bc, linewidth=1.2, linestyle='--', alpha=0.6, zorder=1)

        if self._show_trails and len(self._history) > 1:
            xs     = [p[0] for p in self._history]
            ys     = [p[1] for p in self._history]
            alphas = np.linspace(0.05, 0.35, len(xs))
            for i in range(len(xs) - 1):
                ax.plot(xs[i:i+2], ys[i:i+2], color=spot_col,
                        alpha=float(alphas[i]), linewidth=1.5, zorder=3)

        base  = np.array(mcolors.to_rgb(spot_col))
        white = np.array([1.0, 1.0, 1.0]) if dark else base

        if self._state == 'ok':
            x, y  = self._pos
            N     = 11
            sigma = SPOT_RADIUS * 0.8
            r_max = SPOT_RADIUS * 1.2
            for i in range(N, 0, -1):
                r     = r_max * (i / N)
                t     = np.exp(-(r**2) / (1.25 * sigma**2))
                color = t * white + (1 - t) * base
                halo  = Circle((x, y), r, color=color, alpha=0.55*t, linewidth=0, zorder=5)
                ax.add_patch(halo)
            core = Circle((x, y), SPOT_RADIUS * 0.5,
                          color='white' if dark else base, alpha=0.9, linewidth=0, zorder=6)
            ax.add_patch(core)
            ax.axvline(x, color=spot_col, linewidth=0.7, alpha=0.5, zorder=4)
            ax.axhline(y, color=spot_col, linewidth=0.7, alpha=0.5, zorder=4)
        else:
            if self._state == 'out':
                msg, col = '⚠  BEAM OUT OF RANGE\n(not impacting sensor)', '#ff9900'
            elif self._state == 'off':
                msg, col = '⊘  LASER OFF', '#888888'
            elif self._state == 'no_signal':
                msg, col = '⚡  NO SIGNAL\n(serial unavailable)', '#cc3333'
            else:   # 'idle'
                self.draw_idle()
                return
            ax.text(0, 0, msg, ha='center', va='center',
                    fontsize=11, fontweight='bold', color=col,
                    transform=ax.transData,
                    bbox=dict(boxstyle='round,pad=0.5',
                              facecolor=self._COL_BG_DARK if dark else self._COL_BG_LIGHT,
                              edgecolor=col, alpha=0.9, linewidth=1.5),
                    zorder=6)
        self.draw_idle()


# ── Position metric card ────────────────────────────────────────────────────
class PositionCard(QWidget):
    _COL_BG_DARK    = '#0d0d14'
    _COL_BG_LIGHT   = '#ffffff'
    _COL_LABEL_DARK = '#666680'
    _COL_LABEL_LIGHT= '#888899'
    _COL_VAL_DARK   = '#c8c8e8'
    _COL_VAL_LIGHT  = '#1a1a2e'
    _COL_NAN_DARK   = '#44444a'
    _COL_NAN_LIGHT  = '#aaaaaa'

    def __init__(self, var_name: str, parent=None):
        super().__init__(parent)
        self._nan   = True
        self._value = 0.0
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 7, 10, 7)
        layout.setSpacing(2)
        self._lbl_name = QLabel(var_name)
        self._lbl_val  = QLabel('—')
        nf = QFont(); nf.setPixelSize(10)
        self._lbl_name.setFont(nf)
        vf = QFont('Monospace'); vf.setPixelSize(14); vf.setBold(True)
        self._lbl_val.setFont(vf)
        layout.addWidget(self._lbl_name)
        layout.addWidget(self._lbl_val)
        self.setMinimumWidth(110)
        self.setAutoFillBackground(True)
        self._apply_palette()
        self._refresh_style()

    def _apply_palette(self):
        dark = is_dark_mode()
        pal  = self.palette()
        pal.setColor(QPalette.Window, QColor(self._COL_BG_DARK if dark else self._COL_BG_LIGHT))
        self.setPalette(pal)

    def setValue(self, v: float):
        dark = is_dark_mode()
        if v != v:
            self._nan = True
            col = self._COL_NAN_DARK if dark else self._COL_NAN_LIGHT
            self._lbl_val.setText('—')
            self._lbl_val.setStyleSheet(f'color: {col}; background: transparent;')
        else:
            self._nan   = False
            self._value = v
            col  = self._COL_VAL_DARK if dark else self._COL_VAL_LIGHT
            sign = '+' if v >= 0 else ''
            self._lbl_val.setText(f'{sign}{v:.4f} mm')
            self._lbl_val.setStyleSheet(f'color: {col}; background: transparent;')

    def _refresh_style(self):
        dark  = is_dark_mode()
        lc    = self._COL_LABEL_DARK  if dark else self._COL_LABEL_LIGHT
        nan_c = self._COL_NAN_DARK    if dark else self._COL_NAN_LIGHT
        self._lbl_name.setStyleSheet(f'color: {lc}; background: transparent;')
        if self._nan:
            self._lbl_val.setStyleSheet(f'color: {nan_c}; background: transparent;')


# ───────────────────────────────────────────────────────────────────────────
class Tab2(Tab):
    def __init__(self, gui_elements: tuple = (), **kargs):
        super().__init__(gui_elements, **kargs)
        self._reader: SerialReader | None = None
        self._last_data_time: float       = 0.0
        self._latest: list | None         = None
        self._lock                        = threading.Lock()
        self._laser_a_on: bool | None     = None
        self._laser_b_on: bool | None     = None

    def _init(self):
        main_layout = QHBoxLayout(self)
        main_layout.setSpacing(8)

        sidebar        = QWidget()
        sidebar_layout = QVBoxLayout(sidebar)

        # ── Connection ────────────────────────────────────────────────────
        grp_con    = QGroupBox("Serial connection")
        con_layout = QGridLayout(grp_con)
        con_layout.addWidget(QLabel("Port"), 0, 0)
        self._port_combo = QComboBox()
        self._port_combo.setEditable(True)
        self._refresh_ports()
        con_layout.addWidget(self._port_combo, 0, 1)
        self._refresh_btn = QPushButton("↻")
        self._refresh_btn.setFixedWidth(52)
        self._refresh_btn.clicked.connect(self._refresh_ports)
        con_layout.addWidget(self._refresh_btn, 0, 2)
        con_layout.addWidget(QLabel("Baudrate"), 1, 0)
        self._baud_combo = QComboBox()
        self._baud_combo.addItems(["9600","19200","38400","57600",
                                   "115200","230400","460800","921600"])
        self._baud_combo.setCurrentText("115200")
        con_layout.addWidget(self._baud_combo, 1, 1)
        con_layout.addWidget(QLabel("Sum threshold"), 2, 0)
        self._thresh_spin = QDoubleSpinBox()
        self._thresh_spin.setDecimals(3)
        self._thresh_spin.setRange(0.0, 10.0)
        self._thresh_spin.setSingleStep(0.01)
        self._thresh_spin.setValue(4.8)
        self._thresh_spin.setSuffix(' V')
        self._thresh_spin.setButtonSymbols(QDoubleSpinBox.NoButtons)
        con_layout.addWidget(self._thresh_spin, 2, 1)
        self._trail_cb = QCheckBox("Show trail")
        self._trail_cb.setChecked(False)
        self._trail_cb.stateChanged.connect(self._show_trails)
        con_layout.addWidget(self._trail_cb, 3, 0, 1, 2)
        self._connect_btn = QPushButton("Connect")
        self._connect_btn.setStyleSheet(
            "background-color: #339955; color: #fff; padding: 6px 16px;")
        self._connect_btn.clicked.connect(self._toggle_connection)
        con_layout.addWidget(self._connect_btn, 4, 0, 1, 3)
        self._status_lbl = QLabel("● Disconnected")
        self._status_lbl.setStyleSheet("color: #cc3333; font-weight: bold;")
        con_layout.addWidget(self._status_lbl, 5, 0, 1, 3)

        # ── Laser control ─────────────────────────────────────────────────
        grp_laser    = QGroupBox("Laser control")
        laser_layout = QGridLayout(grp_laser)
        laser_layout.setHorizontalSpacing(8)
        laser_layout.setVerticalSpacing(8)
        self._led_a      = LEDIndicator()
        self._btn_laser_a = QPushButton("Laser A  UNK")
        self._btn_laser_a.setStyleSheet(self._laser_btn_style(None))
        self._btn_laser_a.clicked.connect(self._on_laser_a_clicked)
        laser_layout.addWidget(self._led_a,        0, 1, Qt.AlignCenter)
        laser_layout.addWidget(self._btn_laser_a,  0, 0)
        self._led_b      = LEDIndicator()
        self._btn_laser_b = QPushButton("Laser B  UNK")
        self._btn_laser_b.setStyleSheet(self._laser_btn_style(None))
        self._btn_laser_b.clicked.connect(self._on_laser_b_clicked)
        laser_layout.addWidget(self._led_b,        1, 1, Qt.AlignCenter)
        laser_layout.addWidget(self._btn_laser_b,  1, 0)
        self._ttl_spin = QDoubleSpinBox()
        self._ttl_spin.setDecimals(3)
        self._ttl_spin.setRange(0.01, 1)
        self._ttl_spin.setSingleStep(0.01)
        self._ttl_spin.setValue(1.0)
        self._ttl_spin.setPrefix('TTL frequency:  ')
        self._ttl_spin.setSuffix(' kHz')
        self._ttl_spin.setButtonSymbols(QDoubleSpinBox.UpDownArrows)
        self._ttl_send_btn = QPushButton("Send")
        self._ttl_send_btn.setFixedWidth(72)
        self._ttl_send_btn.clicked.connect(self._on_ttl_changed)
        self._ttl_spin.setEnabled(False)
        self._ttl_send_btn.setEnabled(False)
        laser_layout.addWidget(self._ttl_spin,     2, 0)
        laser_layout.addWidget(self._ttl_send_btn, 2, 1)

        # ── Read-only TTL frequency returned by Pico ───────────────
        self._data_freq_disp = QLineEdit()
        self._data_freq_disp.setReadOnly(True)
        self._data_freq_disp.setAlignment(Qt.AlignCenter)
        self._data_freq_disp.setPlaceholderText("Data Frequency (Hz)")
        laser_layout.addWidget(self._data_freq_disp, 3, 0, 1, 2)  # span 2 columns

        # ── Position ──────────────────────────────────────────────────────
        grp_pos    = QGroupBox("Position estimation")
        pos_layout = QGridLayout(grp_pos)
        pos_layout.setSpacing(6)
        pos_layout.setContentsMargins(8, 8, 8, 8)
        self._x_pos_a = PositionCard('X — sensor A')
        self._y_pos_a = PositionCard('Y — sensor A')
        self._x_pos_b = PositionCard('X — sensor B')
        self._y_pos_b = PositionCard('Y — sensor B')
        pos_layout.addWidget(self._x_pos_a, 0, 0)
        pos_layout.addWidget(self._y_pos_a, 1, 0)
        pos_layout.addWidget(self._x_pos_b, 0, 1)
        pos_layout.addWidget(self._y_pos_b, 1, 1)

        sidebar_layout.addStretch()
        sidebar_layout.addWidget(grp_con)
        sidebar_layout.addWidget(QLabel(' '))
        sidebar_layout.addWidget(grp_laser)
        sidebar_layout.addWidget(QLabel(' '))
        sidebar_layout.addWidget(grp_pos)
        sidebar_layout.addStretch()
        main_layout.addWidget(sidebar)

        plots_layout = QHBoxLayout()
        self._psd_a = PSDCanvas('A', 'mmWave Converters', color_idx=0,
                                show_trails=self._trail_cb.isChecked())
        self._psd_b = PSDCanvas('B', 'Sample holder',     color_idx=1,
                                show_trails=self._trail_cb.isChecked())
        plots_layout.addWidget(self._psd_a)
        plots_layout.addWidget(self._psd_b)
        main_layout.addLayout(plots_layout)

        self._timer = QTimer()
        self._timer.setInterval(60)
        self._timer.timeout.connect(self._update_display)
        self._timer.start()

    # ── Style ─────────────────────────────────────────────────────────────

    @staticmethod
    def _laser_btn_style(on) -> str:
        if on is None:
            return ("QPushButton { background-color: #555555; color: #aaaaaa;"
                    " font-weight: bold; padding: 5px 12px; border-radius: 4px; }"
                    "QPushButton:hover { background-color: #666666; }")
        elif on:
            return ("QPushButton { background-color: #22883a; color: #ffffff;"
                    " font-weight: bold; padding: 5px 12px; border-radius: 4px; }"
                    "QPushButton:hover { background-color: #2aaa48; }")
        else:
            return ("QPushButton { background-color: #885522; color: #ffffff;"
                    " font-weight: bold; padding: 5px 12px; border-radius: 4px; }"
                    "QPushButton:hover { background-color: #aa6633; }")

    # ── Ports ─────────────────────────────────────────────────────────────

    def _refresh_ports(self):
        self._port_combo.clear()
        if _SERIAL_AVAILABLE:
            ports = [p.device for p in serial.tools.list_ports.comports()
                     if p.vid is not None]
            if ports:
                self._port_combo.addItems(ports)
        self._port_combo.addItem('/tmp/ttyV0')

    # ── Connection ────────────────────────────────────────────────────────

    def _toggle_connection(self):
        if self._reader is not None:
            self._stop_reader()
        else:
            self._start_reader()

    def _start_reader(self):
        if not _SERIAL_AVAILABLE:
            self._status_lbl.setText("● pyserial not installed")
            self._status_lbl.setStyleSheet("color: #ff9900; font-weight: bold;")
            return
        port = self._port_combo.currentText().strip()
        baud = int(self._baud_combo.currentText())
        self._reader = SerialReader(port, baud, self._on_data, self._on_message)
        self._reader.start()
        self._connect_btn.setText("Disconnect")
        self._connect_btn.setStyleSheet(
            "background-color: #993355; color: #fff; padding: 6px 16px;")
        self._status_lbl.setText(f"● Connected  {port}  @ {baud}")
        self._status_lbl.setStyleSheet("color: #33aa55; font-weight: bold;")
        self._last_data_time = 0.0
        # Send SYSTEM:ON after port opens; also sent again if READY is received
        QTimer.singleShot(300, self._send_system_on)

    def _stop_reader(self):
        if self._reader is not None:
            self._reader.send("CMD:SYSTEM:OFF")
            deadline = time.time() + 1.0
            while time.time() < deadline:
                with self._lock:
                    vals = self._latest
                if vals is not None and int(vals[6]) == 0 and int(vals[7]) == 0:
                    break
                time.sleep(0.02)
            self._reader.stop()
            self._reader = None
            with self._lock:
                self._latest = None
        self._connect_btn.setText("Connect")
        self._connect_btn.setStyleSheet(
            "background-color: #339955; color: #fff; padding: 6px 16px;")
        self._status_lbl.setText("● Disconnected")
        self._status_lbl.setStyleSheet("color: #cc3333; font-weight: bold;")
        self._psd_a.update_state('idle')
        self._psd_b.update_state('idle')
        self._led_a.set_unknown()
        self._led_b.set_unknown()
        self._btn_laser_a.setText("Laser A  UNK")
        self._btn_laser_b.setText("Laser B  UNK")
        self._btn_laser_a.setStyleSheet(self._laser_btn_style(None))
        self._btn_laser_b.setStyleSheet(self._laser_btn_style(None))
        self._laser_a_on = None
        self._laser_b_on = None
        self._ttl_spin.setEnabled(False)
        self._ttl_send_btn.setEnabled(False)
        self._x_pos_a.setValue(float('nan'))
        self._x_pos_b.setValue(float('nan'))
        self._y_pos_a.setValue(float('nan'))
        self._y_pos_b.setValue(float('nan'))
        self._data_freq_disp.setText("Data Freq.: —")

    def _send_system_on(self):
        if self._reader is not None:
            self._reader.send("CMD:SYSTEM:ON")

    # ── Message handler (non-data serial lines) ───────────────────────────

    def _on_message(self, msg: str):
        """Called from serial thread for non-data lines (e.g. READY)."""
        if 'READY' in msg.strip().upper():
            # Pico just (re)booted — reply with SYSTEM:ON immediately.
            self._send_system_on()

    # ── Laser control ─────────────────────────────────────────────────────

    def _on_laser_a_clicked(self):
        new_state = not self._laser_a_on if self._laser_a_on is not None else True
        if self._reader is not None:
            self._reader.send(f"CMD:TX:A:{'1' if new_state else '0'}")

    def _on_laser_b_clicked(self):
        new_state = not self._laser_b_on if self._laser_b_on is not None else True
        if self._reader is not None:
            self._reader.send(f"CMD:TX:B:{'1' if new_state else '0'}")

    def _on_ttl_changed(self):
        if self._reader is not None:
            self._reader.send(f"CMD:TTL:{int(self._ttl_spin.value()*1000)}")

    # ── Data callback ─────────────────────────────────────────────────────

    def _on_data(self, vals: list):
        with self._lock:
            self._latest         = vals
            self._last_data_time = time.time()

    # ── Display refresh ───────────────────────────────────────────────────

    def _show_trails(self):
        self._psd_a.show_trails(self._trail_cb.isChecked())
        self._psd_b.show_trails(self._trail_cb.isChecked())

    def _update_display(self):
        with self._lock:
            vals   = self._latest
            last_t = self._last_data_time

        if self._reader is None:
            return

        now        = time.time()
        data_fresh = (vals is not None) and (now - last_t <= TIMEOUT_S)

        if not data_fresh:
            self._psd_a.update_state('no_signal')
            self._psd_b.update_state('no_signal')
            self._x_pos_a.setValue(float('nan'))
            self._x_pos_b.setValue(float('nan'))
            self._y_pos_a.setValue(float('nan'))
            self._y_pos_b.setValue(float('nan'))
            if self._laser_a_on is not None:
                self._laser_a_on = None
                self._laser_b_on = None
                self._led_a.set_unknown()
                self._led_b.set_unknown()
                self._btn_laser_a.setText("Laser A  UNK")
                self._btn_laser_b.setText("Laser B  UNK")
                self._btn_laser_a.setStyleSheet(self._laser_btn_style(None))
                self._btn_laser_b.setStyleSheet(self._laser_btn_style(None))
                self._ttl_spin.setEnabled(False)
                self._ttl_send_btn.setEnabled(False)
                self._data_freq_disp.setText("Data Freq.: —")
            return

        thresh = self._thresh_spin.value()
        xA, yA, sumA, xB, yB, sumB, laser_a_state, laser_b_state, ttl_freq_khz = vals
        laser_a_on = bool(int(laser_a_state))
        laser_b_on = bool(int(laser_b_state))

        if laser_a_on != self._laser_a_on:
            self._laser_a_on = laser_a_on
            self._led_a.set_on(laser_a_on)
            self._btn_laser_a.setText(f"Laser A  {'ON ' if laser_a_on else 'OFF'}")
            self._btn_laser_a.setStyleSheet(self._laser_btn_style(laser_a_on))
            self._psd_a.set_laser_on(laser_a_on)
            self._ttl_spin.setEnabled(True)
            self._ttl_send_btn.setEnabled(True)

        if laser_b_on != self._laser_b_on:
            self._laser_b_on = laser_b_on
            self._led_b.set_on(laser_b_on)
            self._btn_laser_b.setText(f"Laser B  {'ON ' if laser_b_on else 'OFF'}")
            self._btn_laser_b.setStyleSheet(self._laser_btn_style(laser_b_on))
            self._psd_b.set_laser_on(laser_b_on)

        state_a = 'ok' if sumA >= thresh else ('out' if laser_a_on else 'off')
        state_b = 'ok' if sumB >= thresh else ('out' if laser_b_on else 'off')

        self._psd_a.update_state(state_a, xA, yA, sumA)
        self._psd_b.update_state(state_b, xB, yB, sumB)
        self._x_pos_a.setValue(xA if state_a == 'ok' else float('nan'))
        self._x_pos_b.setValue(xB if state_b == 'ok' else float('nan'))
        self._y_pos_a.setValue(yA if state_a == 'ok' else float('nan'))
        self._y_pos_b.setValue(yB if state_b == 'ok' else float('nan'))

        # ── Update read-only TTL frequency display ────────────────
        ttl_freq_hz = vals[8]
        self._data_freq_disp.setText(f"Data Freq.: {ttl_freq_hz:.0f} Hz")
    # ── Cleanup ───────────────────────────────────────────────────────────

    def closeEvent(self, event):
        self._timer.stop()
        self._stop_reader()
        super().closeEvent(event)