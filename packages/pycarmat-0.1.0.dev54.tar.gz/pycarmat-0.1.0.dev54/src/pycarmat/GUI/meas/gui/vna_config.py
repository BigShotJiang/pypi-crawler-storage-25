"""
vna_config.py
-------------
Loads the pycarmat VNA configuration from a user-defined TOML file.

Path resolution (in priority order)
-------------------------------------
1. Explicit ``path`` argument passed to :func:`load_config`.
2. Path stored in ``init.toml`` (next to the executable) under the key
   ``config_path``.  This file is written automatically by
   :func:`save_init_config_path` whenever the user browses for a new config.
3. Default: ``./config.toml`` relative to the executable.

Error policy
------------
If the resolved config file is missing, unreadable, or fails validation,
a :class:`ConfigError` is raised.  The caller (GUI layer) is responsible
for catching it and blocking startup with an appropriate error dialog.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

# tomllib is part of the stdlib from Python 3.11+.
# For Python 3.9/3.10 fall back to the third-party tomli package.
try:
    import tomllib          # type: ignore[import]
except ImportError:
    try:
        import tomli as tomllib   # type: ignore[import]
    except ImportError:
        tomllib = None        # type: ignore[assignment]

# ── Physical constant ──────────────────────────────────────────────────────────
_C_MM_PER_S = 3e11           # speed of light in mm/s
_VALID_BANDWIDTHS = {"1 kHz", "10 kHz", "100 kHz"}

# ── init.toml location (fixed, next to the executable) ────────────────────────
def _exe_dir() -> Path:
    return Path(sys.argv[0]).resolve().parent

def _init_toml_path() -> Path:
    return _exe_dir() / "init.toml"

def _default_config_path() -> Path:
    return _exe_dir() / "config.toml"


# ── Public helpers ─────────────────────────────────────────────────────────────

def load_init_config_path() -> Path:
    """
    Return the config file path stored in ``init.toml``, or the default
    ``./config.toml`` if ``init.toml`` does not exist or contains no entry.
    """
    init_path = _init_toml_path()
    if tomllib is None or not init_path.exists():
        return _default_config_path()
    try:
        with open(init_path, "rb") as fh:
            data = tomllib.load(fh)
        stored = data.get("config_path", "")
        if stored:
            return Path(stored)
    except Exception:
        pass
    return _default_config_path()


def save_init_config_path(config_path: str | Path) -> None:
    """
    Persist *config_path* into ``init.toml`` so that the next launch
    remembers the user's choice.  Writes a minimal TOML file; any previous
    content is replaced.
    """
    init_path = _init_toml_path()
    try:
        init_path.write_text(
            f'# pycarmat init — do not edit manually\n'
            f'config_path = "{Path(config_path).as_posix()}"\n',
            encoding="utf-8",
        )
    except OSError as exc:
        # Non-fatal: the path simply won't be remembered next launch.
        import warnings
        warnings.warn(f"Could not write init.toml: {exc}", stacklevel=2)


# ── Exceptions ─────────────────────────────────────────────────────────────────

class ConfigError(RuntimeError):
    """Raised when the config file is missing, unreadable, or invalid."""


# ── Data model ─────────────────────────────────────────────────────────────────

@dataclass
class BandConfig:
    """Configuration for a single frequency band."""
    name:       str
    start_GHz:  float
    stop_GHz:   float
    calkit:     str
    vna:        List[str]   # e.g. ["R&S", "Keysight"]; empty list = all brands
    line_mm:    float       # TRL line length
    refl_mm:    float       # TRL reflect offset
    num_points: int         # number of sweep points
    bandwidth:  str         # IF bandwidth string, e.g. "1 kHz"


@dataclass
class VNAConfig:
    """Top-level configuration object."""
    rs_ip:       str
    keysight_ip: str
    bands:       List[BandConfig]
    source_path: Path       # the file this config was loaded from

    # ── Convenience helpers ────────────────────────────────────────────────────

    def bands_for_brand(self, brand: str) -> List[BandConfig]:
        """Return bands whose ``vna`` list includes *brand* (or is empty = all)."""
        return [b for b in self.bands if not b.vna or brand in b.vna]

    def band_names_for_brand(self, brand: str) -> List[str]:
        return [b.name for b in self.bands_for_brand(brand)]

    def all_band_names(self) -> List[str]:
        return [b.name for b in self.bands]

    def get_band(self, name: str) -> Optional[BandConfig]:
        return next((b for b in self.bands if b.name == name), None)


# ── Internal helpers ───────────────────────────────────────────────────────────

def _default_line_mm(start_GHz: float, stop_GHz: float) -> float:
    """Optimal TRL line length (mm) for 90° electrical length at band centre."""
    f_center_Hz = ((start_GHz + stop_GHz) / 2.0) * 1e9
    return round(_C_MM_PER_S / (4.0 * f_center_Hz), 4)


def _parse_toml(data: dict, source_path: Path) -> VNAConfig:
    """
    Validate and convert a raw TOML dict into a :class:`VNAConfig`.

    Raises :class:`ConfigError` on any validation failure.
    """
    if tomllib is None:
        raise ConfigError(
            "Neither 'tomllib' (Python ≥ 3.11) nor 'tomli' is installed.\n"
            "Install tomli:  pip install tomli"
        )

    vna_sec     = data.get("vna", {})
    sw_defaults = data.get("sweep_defaults", {})
    bands_raw   = data.get("band", [])

    rs_ip       = str(vna_sec.get("rs_ip",       "192.168.0.4"))
    keysight_ip = str(vna_sec.get("keysight_ip", "192.168.0.5"))

    # Global sweep defaults
    global_num_points = int(sw_defaults.get("num_points", 1001))
    global_bandwidth  = str(sw_defaults.get("bandwidth",  "1 kHz"))
    if global_bandwidth not in _VALID_BANDWIDTHS:
        raise ConfigError(
            f"[sweep_defaults] bandwidth must be one of {sorted(_VALID_BANDWIDTHS)}, "
            f"got '{global_bandwidth}'."
        )

    if not bands_raw:
        raise ConfigError("No [[band]] entries found — at least one band is required.")

    bands: List[BandConfig] = []
    for i, raw in enumerate(bands_raw):
        tag = f"[[band]] entry #{i + 1}"

        for key in ("name", "start_GHz", "stop_GHz", "calkit"):
            if key not in raw:
                raise ConfigError(f"{tag}: missing required field '{key}'.")

        name      = str(raw["name"])
        start_GHz = float(raw["start_GHz"])
        stop_GHz  = float(raw["stop_GHz"])
        calkit    = str(raw["calkit"])

        if start_GHz <= 0 or stop_GHz <= start_GHz:
            raise ConfigError(
                f"{tag} '{name}': start_GHz must be > 0 and strictly less than stop_GHz."
            )

        vna_list   = [str(v) for v in raw.get("vna", [])]
        line_mm    = float(raw["line_mm"]) if "line_mm" in raw \
                     else _default_line_mm(start_GHz, stop_GHz)
        refl_mm    = float(raw.get("refl_mm",    2.0))
        num_points = int(raw.get("num_points",   global_num_points))
        bandwidth  = str(raw.get("bandwidth",    global_bandwidth))

        if bandwidth not in _VALID_BANDWIDTHS:
            raise ConfigError(
                f"{tag} '{name}': bandwidth must be one of {sorted(_VALID_BANDWIDTHS)}, "
                f"got '{bandwidth}'."
            )

        bands.append(BandConfig(
            name=name, start_GHz=start_GHz, stop_GHz=stop_GHz,
            calkit=calkit, vna=vna_list, line_mm=line_mm, refl_mm=refl_mm,
            num_points=num_points, bandwidth=bandwidth,
        ))

    return VNAConfig(
        rs_ip=rs_ip, keysight_ip=keysight_ip,
        bands=bands, source_path=source_path,
    )


# ── Public entry point ─────────────────────────────────────────────────────────

def load_config(path: str | Path | None = None) -> VNAConfig:
    """
    Load and validate the VNA configuration from a TOML file.

    Args:
        path: Explicit path to the TOML file.  When *None*, the path is read
              from ``init.toml`` (next to the executable), falling back to
              ``./config.toml``.

    Returns:
        A validated :class:`VNAConfig` instance.

    Raises:
        :class:`ConfigError`: If the file does not exist, cannot be parsed, or
            fails validation.  The caller must handle this and block startup.
    """
    if tomllib is None:
        raise ConfigError(
            "Neither 'tomllib' (Python ≥ 3.11) nor 'tomli' is installed.\n"
            "Install tomli:  pip install tomli"
        )

    config_path = Path(path) if path is not None else load_init_config_path()

    if not config_path.exists():
        raise ConfigError(
            f"Configuration file not found:\n  {config_path}\n\n"
            "Create the file or use the 'Browse config…' button to select one."
        )

    try:
        with open(config_path, "rb") as fh:
            raw = tomllib.load(fh)
    except Exception as exc:
        raise ConfigError(
            f"Cannot read configuration file:\n  {config_path}\n\n{exc}"
        ) from exc

    try:
        return _parse_toml(raw, config_path)
    except ConfigError:
        raise
    except Exception as exc:
        raise ConfigError(
            f"Unexpected error while parsing '{config_path}':\n{exc}"
        ) from exc
