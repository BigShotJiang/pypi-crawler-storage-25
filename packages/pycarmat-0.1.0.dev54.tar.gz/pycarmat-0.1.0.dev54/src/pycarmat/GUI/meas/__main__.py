import sys

from pycarmat.GUI.meas.gui_meas import main
from pycarmat.GUI.meas.fake_serial import main as main_fake

if __name__ == "__main__":
    if len(sys.argv) > 1 and 'fake_psd' in sys.argv[1]:
        main_fake()
    else:
        main()