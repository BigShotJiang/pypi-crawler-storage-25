"""Relic CLI — entry point for all commands.

Visual style is centralised in `relic.style`: any header, success/error glyph,
table layout, or spinner pulse comes from there. Touch `style.py` to retheme
the whole tool.
"""

import subprocess
import sys
from pathlib import Path
from typing import Optional

import typer
import yaml

from relic import __version__, style
from relic.agent_config import AGENTS, init_agent, init_all_agents, uninit_agent
from relic.audit import compute_audit, compute_usage_audit, render_audit, render_usage_audit
from relic.benchmark import run_benchmark
from relic.coverage import compute_coverage, render_coverage
from relic.diff import compute_diff, diff_to_toon
from relic.indexer import compute_stats, load_graph, run_index
from relic.mcp_server import run as run_mcp
from relic.search import (
    available_subprojects,
    render_search_toon,
    search_graph,
)
from relic.style import console, err_console
from relic.toon import full_index_to_toon

app = typer.Typer(
    name="relic",
    help="Codebase knowledge management — build and query a static knowledge graph.",
    add_completion=False,
    no_args_is_help=True,
)

CONFIG_FILE = Path("relic.yaml")
KNOWLEDGE_DIR = Path(".knowledge")
PROJECT_ROOT = Path.cwd()


def _load_subprojects() -> dict | None:
    """Return subprojects dict from relic.yaml, or None if the file is absent."""
    if not CONFIG_FILE.exists():
        return None
    try:
        with CONFIG_FILE.open(encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh)
    except yaml.YAMLError:
        return None
    if not cfg or "subprojects" not in cfg:
        return None
    return cfg["subprojects"]


def _add_to_gitignore(project_root: Path, entries: list[str]) -> None:
    """Append entries to .gitignore if not already present."""
    gitignore = project_root / ".gitignore"
    existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
    additions = [e for e in entries if e not in existing]
    if additions:
        block = "\n# relic\n" + "\n".join(additions) + "\n"
        with gitignore.open("a", encoding="utf-8") as f:
            f.write(block)
        console.print(style.dim(f"   added to .gitignore: {', '.join(additions)}"))


@app.command(name="init")
def project_init() -> None:
    """Scan the project, build the knowledge graph, and get ready to go."""
    from collections import Counter

    from relic.indexer import LANGUAGE_MAP, MAX_FILE_BYTES, SKIP_DIRS

    console.print(style.header("init"))
    console.print()

    # Scan — count source files by language
    lang_counts: Counter[str] = Counter()
    for p in sorted(PROJECT_ROOT.rglob("*")):
        if p.is_symlink() or not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.relative_to(PROJECT_ROOT).parts):
            continue
        if p.suffix in LANGUAGE_MAP and p.stat().st_size <= MAX_FILE_BYTES:
            lang_counts[LANGUAGE_MAP[p.suffix]] += 1

    total = sum(lang_counts.values())
    if total == 0:
        console.print(style.error("no source files found in this directory."))
        raise SystemExit(1)

    parts = [f"{count} {lang}" for lang, count in lang_counts.most_common()]
    console.print(style.dim(f"   found {total} files ({', '.join(parts)})"))
    console.print()

    # Index
    config = CONFIG_FILE if CONFIG_FILE.exists() else None
    with style.make_spinner("indexing codebase…") as spinner:
        spinner.add_task("", total=None)
        G, _skip = run_index(PROJECT_ROOT, KNOWLEDGE_DIR, config)

    file_count = sum(1 for _, d in G.nodes(data=True) if d.get("ntype") == "file")
    symbol_count = sum(1 for _, d in G.nodes(data=True) if d.get("ntype") == "symbol")
    edge_count = G.number_of_edges()

    console.print(style.kv("files", file_count))
    console.print(style.kv("symbols", symbol_count))
    console.print(style.kv("edges", edge_count))
    console.print()

    toon_path = KNOWLEDGE_DIR / "index.toon"
    toon_path.write_text(full_index_to_toon(G), encoding="utf-8")

    _add_to_gitignore(PROJECT_ROOT, [".knowledge/"])

    console.print(style.success("knowledge graph built"))
    console.print()
    console.print(style.dim("next:"))
    arrow = style.ARROW
    sec = style.SECONDARY
    console.print(f"   {arrow}  [bold {sec}]relic --init cursor[/]   set up Cursor")
    console.print(f"   {arrow}  [bold {sec}]relic --init claude[/]   set up Claude Code")
    console.print(f"   {arrow}  [bold {sec}]relic query <file>[/]    query the graph")


@app.command(name="index")
def index_cmd() -> None:
    """Rebuild the knowledge graph. Shows what changed, what's skipped, and respects .relicignore."""
    console.print(style.header("index"))
    console.print()

    # Load previous index for delta comparison
    prev_files = prev_symbols = prev_edges = 0
    try:
        prev_G = load_graph(KNOWLEDGE_DIR)
        prev_files = sum(1 for _, d in prev_G.nodes(data=True) if d.get("ntype") == "file")
        prev_symbols = sum(1 for _, d in prev_G.nodes(data=True) if d.get("ntype") == "symbol")
        prev_edges = prev_G.number_of_edges()
    except FileNotFoundError:
        pass

    config = CONFIG_FILE if CONFIG_FILE.exists() else None
    with style.make_spinner("indexing codebase…") as spinner:
        spinner.add_task("", total=None)
        G, skip_stats = run_index(PROJECT_ROOT, KNOWLEDGE_DIR, config)

    file_count = sum(1 for _, d in G.nodes(data=True) if d.get("ntype") == "file")
    symbol_count = sum(1 for _, d in G.nodes(data=True) if d.get("ntype") == "symbol")
    edge_count = G.number_of_edges()

    console.print(style.kv("files", file_count))
    console.print(style.kv("symbols", symbol_count))
    console.print(style.kv("edges", edge_count))

    # Delta
    if prev_files or prev_symbols or prev_edges:
        df = file_count - prev_files
        ds = symbol_count - prev_symbols
        de = edge_count - prev_edges
        parts = []
        if df:
            parts.append(f"{df:+d} files")
        if ds:
            parts.append(f"{ds:+d} symbols")
        if de:
            parts.append(f"{de:+d} edges")
        if parts:
            console.print(style.kv("delta", ", ".join(parts)))
        else:
            console.print(style.kv("delta", "no changes"))

    # Skip info
    skipped_dirs = skip_stats.get("skipped_dirs", set())
    ignored_count = skip_stats.get("ignored_count", 0)
    if skipped_dirs:
        dirs_str = ", ".join(sorted(f"{d}/" for d in skipped_dirs))
        console.print(style.kv("skipped", dirs_str))
    if ignored_count:
        console.print(style.kv("ignored", f"{ignored_count} files via .relicignore"))

    console.print()

    toon_path = KNOWLEDGE_DIR / "index.toon"
    toon_path.write_text(full_index_to_toon(G), encoding="utf-8")

    console.print(style.success(f"saved   {style.dim(str(KNOWLEDGE_DIR / 'index.pkl'))}"))
    console.print(style.success(f"toon    {style.dim(str(toon_path))}"))

    fit = G.graph.get("codebase_fit", {})
    if fit.get("verdict") == "small":
        console.print()
        console.print(
            style.warn(
                f"small codebase ({fit['files']} files) — relic adds most value above ~40 files. "
                f"Direct file reads may be faster here. Run `relic --uninit claude` to disable MCP."
            )
        )


@app.command(name="query")
def query_cmd(
    target: str = typer.Argument(
        ..., help="File path, symbol name, Class.method, or space-separated targets.", metavar="TARGET"
    ),
    depth: int = typer.Option(2, "--depth", "-d", help="Graph traversal depth (hops)."),
    exclude_tests: bool = typer.Option(True, help="Drop test-file symbols from neighbor_symbols."),
) -> None:
    """Query the knowledge graph for a file or symbol and print a TOON context subgraph.

    Supports dotted notation (Class.method) and space-separated batch queries.
    Coding agents run this before editing a file to get precise, token-efficient context.
    Output goes to stdout — agents read it directly from the bash tool result.
    """
    from relic.mcp_server import _handle_query

    result = _handle_query({"target": target, "depth": depth, "exclude_tests": exclude_tests})
    text = result[0].text

    if text.startswith("Error:") or text.startswith("Not found:"):
        console.print(style.error(text.split("\n")[0]))
        for line in text.split("\n")[1:]:
            if line.strip():
                console.print(style.dim(f"   {line.strip()}"))
        raise SystemExit(1)

    print(text)
    err_console.print(style.dim(f"query: {target} {style.DOT} depth={depth}"))


@app.command(name="search")
def search_cmd(
    query: str = typer.Argument(..., help="Search term — file path or symbol name."),
    kind: str = typer.Option("all", "--kind", "-k", help="Filter results: file, symbol, or all."),
    subproject: Optional[str] = typer.Option(
        None,
        "--subproject",
        "-s",
        help="Restrict results to a single subproject (as named in relic.yaml).",
    ),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results per category."),
) -> None:
    """Search the knowledge graph for files and symbols by name.

    Results are ranked: exact > prefix > substring, with well-connected nodes
    surfacing first on ties. Output is TOON, same format as the relic_search
    MCP tool.
    """
    if kind not in ("file", "symbol", "all"):
        console.print(style.error(f"invalid --kind: {kind!r}. choose file, symbol, or all."))
        raise SystemExit(1)

    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    if subproject:
        available = available_subprojects(G)
        if subproject not in available:
            avail_str = ", ".join(sorted(available)) or "(none indexed)"
            console.print(style.error(f"no such subproject {subproject!r}. available: {avail_str}."))
            raise SystemExit(1)

    file_matches, symbol_matches, literal_matches = search_graph(
        G,
        query,
        kind=kind,
        subproject=subproject,
        limit=limit,  # type: ignore[arg-type]
    )

    print(render_search_toon(query, file_matches, symbol_matches, literal_matches))

    suffix = f" {style.DOT} subproject={subproject}" if subproject else ""
    err_console.print(
        style.dim(f"search: '{query}' {style.DOT} {len(file_matches)} file(s), {len(symbol_matches)} symbol(s){suffix}")
    )


@app.command(name="stats")
def stats_cmd() -> None:
    """Print health metrics for the knowledge graph.

    Human-facing report.  Agents read freshness from the per-response
    `index{...}` header instead — the matching MCP tool was removed in 7.5a.
    """
    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    stats = compute_stats(G, KNOWLEDGE_DIR)

    console.print(style.header("stats"))
    console.print()
    console.print(style.kv("last_updated", stats["last_updated"]))
    console.print(style.kv("files", stats["files"]))
    console.print(style.kv("symbols", stats["symbols"]))
    console.print(style.kv("edges", stats["edges"]))
    for et, count in sorted(stats["edges_by_type"].items()):
        console.print(style.kv(f"  {et}", count))
    if stats["subprojects"]:
        console.print(style.kv("subprojects", ", ".join(stats["subprojects"])))


@app.command(name="coverage")
def coverage_cmd(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="List every skipped file, not just samples."),
) -> None:
    """Show what relic indexed and what it skipped, with reasons.

    Without this, files dropped silently because of size limits, missing
    parsers, or symlink rules look like model errors instead of tool limits.
    Use it after `relic index` to audit coverage.
    """
    subprojects = _load_subprojects()
    coverage = compute_coverage(PROJECT_ROOT, subprojects)
    render_coverage(coverage, console, verbose=verbose)


@app.command(name="mcp")
def mcp_cmd() -> None:
    """Start the relic MCP server (stdio transport).

    Exposes four tools: relic_query, relic_search, relic_reindex, relic_diff.
    Every response is prefixed with an `index{...}` freshness header so agents
    know when to call relic_reindex without a separate stats roundtrip.
    Works with any MCP-compatible agent (Claude Code, Cursor, Copilot, Codex).
    Configure in agent settings:

        "mcpServers": { "relic": { "command": "relic", "args": ["mcp"] } }
    """
    run_mcp()


@app.command(name="audit")
def audit_cmd(
    usage: bool = typer.Option(False, "--usage", help="Show MCP call usage stats instead of token footprint."),
) -> None:
    """Measure relic's own token footprint in the agent context.

    Shows the instruction block written to CLAUDE.md / .cursorrules,
    the MCP tool schemas the agent loads every turn, and a sample
    relic_query against your real graph. Use this to verify relic isn't
    itself part of the 73% overhead problem documented for AI coding
    agents — the baseline tax should stay well under 1,500 tokens.

    Pass --usage to show MCP call counts and response token totals instead.
    """
    if usage:
        render_usage_audit(compute_usage_audit(KNOWLEDGE_DIR), console)
        return
    audit = compute_audit(PROJECT_ROOT, KNOWLEDGE_DIR)
    render_audit(audit, console)


@app.command(name="benchmark")
def benchmark_cmd(
    target: str = typer.Argument(..., help="File path or symbol name.", metavar="TARGET"),
    depth: int = typer.Option(1, "--depth", "-d", help="Graph traversal depth (default 1)."),
    vs: Optional[str] = typer.Option(None, "--vs", help="Compare against a tool: 'ripgrep' or 'rg'."),
) -> None:
    """Compare token cost of agent context with vs without relic.

    Shows files an agent would read manually, tokens saved by TOON injection,
    and hidden callers it would miss entirely. Run this to prove relic's value.

    Use --vs ripgrep to compare relic against a ripgrep search for the same symbol.
    """
    from relic.benchmark import run_rg_benchmark

    if vs and vs.lower() in {"ripgrep", "rg"}:
        run_rg_benchmark(target, PROJECT_ROOT, KNOWLEDGE_DIR)
    else:
        run_benchmark(target, PROJECT_ROOT, KNOWLEDGE_DIR, depth=depth)


@app.command(name="diff")
def diff_cmd() -> None:
    """Show what changed since the last index.

    Compares on-disk source files against the indexed graph to surface
    new files, deleted files, and changed symbols. Helps agents decide
    whether to call relic_reindex.
    """
    if not KNOWLEDGE_DIR.exists():
        err_console.print(style.error("no index found — run `relic index` first"))
        raise SystemExit(1)

    config = CONFIG_FILE if CONFIG_FILE.exists() else None
    result = compute_diff(PROJECT_ROOT, KNOWLEDGE_DIR, config)
    if not result["stale"]:
        console.print(style.success("index is up-to-date — no changes detected"))
        return

    console.print(style.header("diff"))
    toon = diff_to_toon(result)
    console.print(toon)


@app.command(name="impact")
def impact_cmd(
    target: str = typer.Argument(..., help="File path or symbol (name@path) to trace impact for.", metavar="TARGET"),
    depth: int = typer.Option(0, "--depth", "-d", help="Max hops (0 = full transitive closure)."),
) -> None:
    """Show every file transitively affected if TARGET changes.

    Walks imported_by + uses edges from TARGET outward, collecting all
    dependents. Use this for blast-radius analysis before refactoring.
    Output is TOON for agent consumption or human review.
    """
    from relic.impact import compute_impact, render_impact_toon

    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    result = compute_impact(G, target, max_depth=depth)
    if result is None:
        console.print(style.error(f"not found in graph: {target!r}"))
        raise SystemExit(1)

    print(render_impact_toon(target, result))
    err_console.print(style.dim(f"impact: {target} {style.DOT} {len(result['affected_files'])} file(s) affected"))


@app.command(name="path")
def path_cmd(
    source: str = typer.Argument(..., help="Source file or symbol.", metavar="SOURCE"),
    dest: str = typer.Argument(..., help="Destination file or symbol.", metavar="DEST"),
) -> None:
    """Find the shortest dependency path between two nodes.

    Useful for understanding how A → B are connected through the import/call
    graph. Output is TOON listing the path nodes and their edge types.
    """
    from relic.impact import compute_path, render_path_toon

    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    result = compute_path(G, source, dest)
    if result is None:
        console.print(style.error(f"no path found between {source!r} and {dest!r}"))
        raise SystemExit(1)

    print(render_path_toon(source, dest, result))
    err_console.print(style.dim(f"path: {source} → {dest} {style.DOT} {len(result['nodes'])} hop(s)"))


@app.command(name="communities")
def communities_cmd(
    limit: int = typer.Option(20, "--limit", "-l", help="Max communities to show."),
) -> None:
    """Show file communities discovered by graph clustering.

    Groups files by how they cluster in the import graph (Louvain method).
    Each community is a cohesive module boundary — useful for architecture
    review and spotting unexpected cross-community coupling.
    """
    from relic.impact import render_communities_toon

    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    communities = G.graph.get("communities", {})
    if not communities:
        console.print(style.dim("no communities detected — run `relic index` to rebuild"))
        return

    print(render_communities_toon(communities, limit=limit))
    err_console.print(style.dim(f"communities: {len(communities)} total"))


@app.command(name="centrality")
def centrality_cmd(
    top: int = typer.Option(20, "--top", "-n", help="Max rows to show (0 = all)."),
    sort_by: str = typer.Option(
        "pagerank", "--by", "-b", help="Sort key: pagerank, betweenness, in_degree, out_degree."
    ),  # noqa: E501
) -> None:
    """Show graph centrality weights for every file.

    PageRank identifies structurally important files (many important files
    depend on them). Betweenness identifies bridge files that sit between
    communities — highest risk to change. Use before refactoring to find
    the load-bearing files.
    """
    from relic.centrality import compute_centrality, render_centrality_toon

    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    rows = compute_centrality(G)
    if not rows:
        console.print(style.dim("no file nodes in graph — run `relic index` first"))
        return

    print(render_centrality_toon(rows, top=top, sort_by=sort_by))
    err_console.print(style.dim(f"centrality: {len(rows)} files · sorted by {sort_by}"))


@app.command(name="viz")
def viz_cmd(
    out: Optional[str] = typer.Option(
        None, "--out", "-o", help="Save HTML to this path instead of opening in browser."
    ),  # noqa: E501
) -> None:
    """Open an interactive knowledge graph in your browser.

    Force-directed D3 visualization. Node size = PageRank importance,
    color = community, edge opacity = evidence quality. Click any node
    to see its blast-radius highlighted in red and inspect its metadata.
    Drag nodes, filter by language/community, search by filename.
    """
    from relic.viz import open_viz

    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    out_path = Path(out) if out else None
    target = open_viz(G, out_path=out_path)

    if out:
        console.print(style.success(f"saved → {target}"))
    else:
        err_console.print(style.dim(f"viz: opened {target}"))


@app.command(name="cycles")
def cycles_cmd(
    limit: int = typer.Option(20, "--limit", "-l", help="Max cycles to show (0 = all)."),
    min_len: int = typer.Option(2, "--min-len", "-m", help="Minimum cycle length to report."),
) -> None:
    """Detect circular dependencies in the file dependency graph.

    Circular imports cause subtle bugs and make refactoring painful.
    Each cycle is shown as a chain of files that mutually depend on each other.
    Fix by extracting shared symbols into a common module that neither side imports from.
    MCP shorthand: relic_query "cycles"
    """
    from relic.cycles import compute_cycles, render_cycles_toon

    try:
        G = load_graph(KNOWLEDGE_DIR)
    except FileNotFoundError as exc:
        console.print(style.error(str(exc)))
        raise SystemExit(1)

    cycles = compute_cycles(G, min_len=min_len)
    print(render_cycles_toon(cycles, limit=limit))
    err_console.print(style.dim(f"cycles: {len(cycles)} found"))


checkpoint_app = typer.Typer(name="checkpoint", help="Persistent task state across sessions.", no_args_is_help=True)
app.add_typer(checkpoint_app)


@checkpoint_app.command(name="save")
def checkpoint_save_cmd(
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Named task (omit for default)."),
    task_name: Optional[str] = typer.Option(None, "--name", "-n", help="Display name (e.g. 'oauth-payments')."),
    phase: Optional[str] = typer.Option(None, "--phase", "-p", help="Current phase description."),
) -> None:
    """Save or update the current task checkpoint.

    Creates a checkpoint if none exists. Subsequent calls merge delta updates —
    you do not need to resend the full done list each time.
    """
    from relic.checkpoint import save_checkpoint

    cp = save_checkpoint(task=task, phase=phase, task_name=task_name)
    console.print(style.success(f"checkpoint saved: {cp.task}"))
    if cp.phase:
        console.print(style.dim(f"   phase: {cp.phase}"))
    console.print(
        style.dim(f"   done: {len(cp.done)}  in_progress: {len(cp.in_progress)}  constraints: {len(cp.constraints)}")
    )


@checkpoint_app.command(name="load")
def checkpoint_load_cmd(
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Named task (omit for default)."),
) -> None:
    """Print current checkpoint state as TOON."""
    from relic.checkpoint import checkpoint_to_toon, load_checkpoint

    cp = load_checkpoint(task)
    if not cp:
        console.print(style.warn("no active checkpoint — run `relic checkpoint save` to create one."))
        raise SystemExit(1)
    print(checkpoint_to_toon(cp))


@checkpoint_app.command(name="close")
def checkpoint_close_cmd(
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Named task (omit for default)."),
) -> None:
    """Close task: delete checkpoint and log one summary line.

    Run this when a PR is merged or a task is abandoned. Keeps .knowledge/ clean.
    """
    from relic.checkpoint import close_checkpoint

    existed = close_checkpoint(task)
    if not existed:
        console.print(style.warn("no active checkpoint to close."))
        raise SystemExit(1)
    console.print(style.success("checkpoint closed — task logged, checkpoint.toon deleted."))


@checkpoint_app.command(name="list")
def checkpoint_list_cmd() -> None:
    """List all active checkpoints."""
    from relic.checkpoint import list_checkpoints, load_checkpoint

    active = list_checkpoints()
    if not active:
        console.print(style.dim("   no active checkpoints."))
        return
    console.print(style.header("checkpoints"))
    console.print()
    for name, path in active:
        cp = load_checkpoint(None if "checkpoint.toon" == Path(path).name else Path(path).stem)
        phase = cp.phase if cp else ""
        done_count = len(cp.done) if cp else 0
        console.print(f"   {style.BRAND} [bold]{name}[/bold]  {style.dim(phase)}")
        console.print(style.dim(f"         done: {done_count}  path: {path}"))
    console.print()


@checkpoint_app.command(name="log")
def checkpoint_log_cmd(
    clear: bool = typer.Option(False, "--clear", help="Wipe the log."),
) -> None:
    """Show or clear the checkpoint history log."""
    from relic.checkpoint import _LOG_FILE

    if clear:
        if _LOG_FILE.exists():
            _LOG_FILE.unlink()
            console.print(style.success("checkpoint log cleared."))
        else:
            console.print(style.dim("   log is already empty."))
        return

    if not _LOG_FILE.exists():
        console.print(style.dim("   no closed tasks yet."))
        return
    print(_LOG_FILE.read_text(encoding="utf-8"))


@app.command(name="annotate")
def annotate_cmd(
    file: str = typer.Argument(..., help="File path to annotate (relative to project root)."),
    rule: str = typer.Argument(..., help="Constraint or note to attach."),
    permanent: bool = typer.Option(False, "--permanent", "-p", help="Survive checkpoint close (codebase invariant)."),
) -> None:
    """Attach a constraint or note to a file.

    Surfaces automatically in relic_query output for that file.
    Use --permanent for codebase invariants (e.g. frozen signatures, intentional quirks).
    Default is task-scoped — removed when `relic checkpoint close` is run.
    """
    from relic.annotations import add_annotation

    add_annotation(file, rule, permanent=permanent)
    scope = "permanent" if permanent else "task-scoped"
    console.print(style.success(f"annotated: {file}"))
    console.print(style.dim(f"   scope: {scope}"))
    console.print(style.dim(f"   rule:  {rule}"))


@app.command(name="annotations")
def annotations_cmd(
    file: Optional[str] = typer.Argument(None, help="Filter to a specific file (omit for all)."),
) -> None:
    """List all annotations, optionally filtered by file."""
    from relic.annotations import list_annotations

    entries = list_annotations(file)
    if not entries:
        label = f" for {file}" if file else ""
        console.print(style.dim(f"   no annotations{label}."))
        return
    console.print(style.header("annotations"))
    console.print()
    for e in entries:
        scope_color = "green" if e["scope"] == "permanent" else style.DIM
        console.print(f"   [{scope_color}]{e['scope']:<10}[/]  [bold]{e['file']}[/bold]")
        console.print(f"   {' ' * 10}  {style.dim(e['rule'])}")
        console.print(f"   {' ' * 10}  {style.dim('added: ' + e['added'])}")
        console.print()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    list_all: bool = typer.Option(False, "--list", "-l", help="List all defined subprojects."),
    init: Optional[str] = typer.Option(
        None,
        "--init",
        "-i",
        help=(f"Write relic instructions into agent config file. Pass agent name ({', '.join(AGENTS)}) or 'all'."),
        metavar="AGENT",
    ),
    uninit: Optional[str] = typer.Option(
        None,
        "--uninit",
        help=(f"Remove relic instructions and MCP registration. Pass agent name ({', '.join(AGENTS)}) or 'all'."),
        metavar="AGENT",
    ),
    update: bool = typer.Option(False, "--update", "-u", help="Upgrade to the latest version from PyPI."),
    version: bool = typer.Option(False, "--version", "-v", help="Show version and exit."),
) -> None:
    """Relic — build and query a static knowledge graph for AI coding agents."""
    if version:
        console.print(style.banner(__version__))
        return

    if init is not None:
        if init == "all":
            init_all_agents(PROJECT_ROOT)
        elif init in AGENTS:
            init_agent(init, PROJECT_ROOT)
        else:
            console.print(style.error(f"unknown agent: '{init}' — choose from {', '.join(AGENTS)} or 'all'"))
            raise SystemExit(1)
        return

    if uninit is not None:
        targets = list(AGENTS.keys()) if uninit == "all" else [uninit]
        if uninit != "all" and uninit not in AGENTS:
            console.print(style.error(f"unknown agent: '{uninit}' — choose from {', '.join(AGENTS)} or 'all'"))
            raise SystemExit(1)
        for key in targets:
            uninit_agent(key, PROJECT_ROOT)
        return

    if update:
        console.print(style.header("update"))
        console.print(style.dim("   upgrading relic-graph from PyPI…\n"))

        pip_result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "relic-graph"],
            capture_output=True,
            text=True,
        )
        if pip_result.returncode == 0:
            console.print(style.success("relic updated from PyPI"))
            return

        console.print(style.dim("   pip upgrade failed, trying uv…\n"))
        uv_result = subprocess.run(
            ["uv", "tool", "install", "--upgrade", "relic-graph"],
            text=True,
        )
        if uv_result.returncode == 0:
            console.print(style.success("relic updated via uv"))
            return

        console.print(style.error("update failed — is pip or uv installed and on PATH?"))
        raise SystemExit(1)

    if ctx.invoked_subcommand is not None:
        return

    if list_all:
        subs = _load_subprojects()
        if not subs:
            console.print(style.dim("   no relic.yaml found — subproject labels not configured"))
            console.print(style.dim("   relic works without it; create one only if you need per-subproject filtering"))
            return
        table = style.make_table(title="subprojects")
        table.add_column("name", style=f"bold {style.SECONDARY}")
        table.add_column("path")
        table.add_column("description", style=style.DIM)
        for name, info in subs.items():
            table.add_row(name, info.get("path", ""), info.get("description", ""))
        console.print(table)
        return

    console.print(ctx.get_help())
