"""Checkpoint — persistent task state across sessions and context compactions.

Agents working on long PRs (days, many context compactions) lose task state
when context is compacted. Checkpoint stores phase, done files, in-progress
focus, constraints discovered, and next steps in .knowledge/checkpoint.toon.

Agent workflow:
  new session      → relic_session_start  (reads checkpoint + index header)
  marking progress → relic_checkpoint save (delta updates, not full resend)
  task done        → relic_checkpoint close (deletes file, logs one line)
  parallel tasks   → relic_checkpoint save --task NAME (named checkpoints)

Storage: .knowledge/checkpoint.toon (default) or .knowledge/checkpoints/NAME.toon
Log:     .knowledge/checkpoint_log.toon (one line per closed task, survives close)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

KNOWLEDGE_DIR = Path(".knowledge")
_CHECKPOINTS_DIR = KNOWLEDGE_DIR / "checkpoints"
_DEFAULT_FILE = KNOWLEDGE_DIR / "checkpoint.toon"
_LOG_FILE = KNOWLEDGE_DIR / "checkpoint_log.toon"

_SEP = " | "  # row field separator (avoids comma ambiguity in notes)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class Checkpoint:
    task: str
    phase: str = ""
    updated: str = ""
    sessions: int = 1
    done: list[tuple[str, str]] = field(default_factory=list)  # (file, note)
    in_progress: list[tuple[str, str, int]] = field(default_factory=list)  # (file, focus, line)
    constraints: list[tuple[str, str]] = field(default_factory=list)  # (file, rule)
    next_steps: list[tuple[str, str]] = field(default_factory=list)  # (task, priority)


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _clean(s: str) -> str:
    """Strip the separator character from user-provided strings."""
    return str(s).replace(_SEP.strip(), "/").replace("\n", " ").strip()


def _checkpoint_path(task: str | None) -> Path:
    if task:
        _CHECKPOINTS_DIR.mkdir(parents=True, exist_ok=True)
        return _CHECKPOINTS_DIR / f"{_clean(task)}.toon"
    return _DEFAULT_FILE


def _write(cp: Checkpoint, path: Path) -> None:
    lines: list[str] = []
    lines.append(f"checkpoint: {_clean(cp.task)}{_SEP}{_clean(cp.phase)}{_SEP}{cp.updated}{_SEP}{cp.sessions}")
    lines.append("")

    if cp.done:
        lines.append(f"done[{len(cp.done)}]:")
        for f, note in cp.done:
            lines.append(f"  {_clean(f)}{_SEP}{_clean(note)}")
        lines.append("")

    if cp.in_progress:
        lines.append(f"in_progress[{len(cp.in_progress)}]:")
        for f, focus, ln in cp.in_progress:
            lines.append(f"  {_clean(f)}{_SEP}{_clean(focus)}{_SEP}{ln}")
        lines.append("")

    if cp.constraints:
        lines.append(f"constraints[{len(cp.constraints)}]:")
        for f, rule in cp.constraints:
            lines.append(f"  {_clean(f)}{_SEP}{_clean(rule)}")
        lines.append("")

    if cp.next_steps:
        lines.append(f"next[{len(cp.next_steps)}]:")
        for task_name, priority in cp.next_steps:
            lines.append(f"  {_clean(task_name)}{_SEP}{_clean(priority)}")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def _read(path: Path) -> Checkpoint | None:
    if not path.exists():
        return None
    lines = path.read_text(encoding="utf-8").splitlines()
    cp = Checkpoint(task="")
    section: str | None = None

    for raw in lines:
        line = raw.strip()
        if not line:
            section = None
            continue

        if line.startswith("checkpoint:"):
            parts = [p.strip() for p in line[len("checkpoint:") :].split(_SEP.strip())]
            cp.task = parts[0] if len(parts) > 0 else ""
            cp.phase = parts[1] if len(parts) > 1 else ""
            cp.updated = parts[2] if len(parts) > 2 else ""
            cp.sessions = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 1
        elif line.startswith("done["):
            section = "done"
        elif line.startswith("in_progress["):
            section = "in_progress"
        elif line.startswith("constraints["):
            section = "constraints"
        elif line.startswith("next["):
            section = "next"
        elif raw.startswith("  ") and section:
            parts = [p.strip() for p in line.split(_SEP.strip())]
            if section == "done" and len(parts) >= 2:
                cp.done.append((parts[0], parts[1]))
            elif section == "in_progress" and len(parts) >= 2:
                ln = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
                cp.in_progress.append((parts[0], parts[1], ln))
            elif section == "constraints" and len(parts) >= 2:
                cp.constraints.append((parts[0], parts[1]))
            elif section == "next" and len(parts) >= 2:
                cp.next_steps.append((parts[0], parts[1]))

    return cp if cp.task else None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def save_checkpoint(
    task: str | None = None,
    *,
    phase: str | None = None,
    done: list[dict] | None = None,
    in_progress: list[dict] | None = None,
    constraints: list[dict] | None = None,
    next_steps: list[dict] | None = None,
    task_name: str | None = None,
) -> Checkpoint:
    """Merge delta into existing checkpoint (or create new). Returns updated checkpoint."""
    path = _checkpoint_path(task)
    cp = _read(path) or Checkpoint(task=task_name or task or "unnamed")

    if task_name:
        cp.task = task_name
    if phase is not None:
        cp.phase = phase

    # done and constraints are additive — agent sends new entries only
    done_files = {f for f, _ in cp.done}
    if done:
        for entry in done:
            f = entry.get("file", "")
            note = entry.get("note", "")
            if f and f not in done_files:
                cp.done.append((f, note))
                done_files.add(f)
            elif f in done_files:
                # update note if file already marked done
                cp.done = [(ef, note if ef == f else en) for ef, en in cp.done]

    constraint_keys = {(f, r) for f, r in cp.constraints}
    if constraints:
        for entry in constraints:
            f = entry.get("file", "")
            rule = entry.get("rule", "")
            if f and (f, rule) not in constraint_keys:
                cp.constraints.append((f, rule))
                constraint_keys.add((f, rule))

    # in_progress and next_steps replace — these change frequently
    if in_progress is not None:
        cp.in_progress = [(e.get("file", ""), e.get("focus", ""), int(e.get("line", 0))) for e in in_progress]

    if next_steps is not None:
        cp.next_steps = [(e.get("task", ""), e.get("priority", "medium")) for e in next_steps]

    cp.sessions = cp.sessions + (1 if not _read(path) else 0)
    cp.updated = datetime.now(timezone.utc).isoformat(timespec="seconds")
    _write(cp, path)
    return cp


def load_checkpoint(task: str | None = None) -> Checkpoint | None:
    """Load checkpoint. None if no checkpoint exists."""
    return _read(_checkpoint_path(task))


def close_checkpoint(task: str | None = None) -> bool:
    """Delete checkpoint and append one summary line to the log. Returns True if existed."""
    path = _checkpoint_path(task)
    cp = _read(path)
    if not cp:
        return False

    # Append to log
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    _LOG_FILE.parent.mkdir(exist_ok=True)
    existing_entries: list[str] = []
    if _LOG_FILE.exists():
        for line in _LOG_FILE.read_text(encoding="utf-8").splitlines():
            if line.startswith("  "):
                existing_entries.append(line.strip())
    existing_entries.append(f"{_clean(cp.task)}{_SEP}{now}{_SEP}{len(cp.done)}")
    header = f"log[{len(existing_entries)}]{{task,closed,files_done}}:"
    _LOG_FILE.write_text(header + "\n" + "\n".join(f"  {e}" for e in existing_entries), encoding="utf-8")

    path.unlink()

    # Clean up task-scoped annotations alongside the checkpoint
    from relic.annotations import delete_task_annotations

    delete_task_annotations()
    return True


def list_checkpoints() -> list[tuple[str, str]]:
    """Return list of (name, path_str) for all active checkpoints."""
    result: list[tuple[str, str]] = []
    if _DEFAULT_FILE.exists():
        cp = _read(_DEFAULT_FILE)
        result.append((cp.task if cp else "unnamed", str(_DEFAULT_FILE)))
    if _CHECKPOINTS_DIR.exists():
        for f in sorted(_CHECKPOINTS_DIR.glob("*.toon")):
            result.append((f.stem, str(f)))
    return result


def checkpoint_to_toon(cp: Checkpoint) -> str:
    """Render checkpoint as TOON for agent consumption."""
    lines: list[str] = []
    lines.append(f"checkpoint{{task,phase,updated,sessions}}: {cp.task},{cp.phase},{cp.updated},{cp.sessions}")

    if cp.done:
        lines.append(f"\ndone[{len(cp.done)}]{{file,note}}:")
        for f, note in cp.done:
            lines.append(f"  {f},{note}")

    if cp.in_progress:
        lines.append(f"\nin_progress[{len(cp.in_progress)}]{{file,focus,line}}:")
        for f, focus, ln in cp.in_progress:
            lines.append(f"  {f},{focus},{ln}")

    if cp.constraints:
        lines.append(f"\nconstraints[{len(cp.constraints)}]{{file,rule}}:")
        for f, rule in cp.constraints:
            lines.append(f"  {f},{rule}")

    if cp.next_steps:
        lines.append(f"\nnext[{len(cp.next_steps)}]{{task,priority}}:")
        for task_name, priority in cp.next_steps:
            lines.append(f"  {task_name},{priority}")

    return "\n".join(lines)
