from __future__ import annotations

import json
import shutil
from collections.abc import Mapping
from pathlib import Path
from typing import cast

from ..artifacts import resolve_build_root, resolve_report_path
from ..models import AnalysisResult, PrunedDistribution, ResolvedEnvironment
from ..report import render_report, report_payload
from .vendor import emit_vendor_modules


def emit_distribution(
    environment: ResolvedEnvironment,
    analysis: AnalysisResult,
    pruned: PrunedDistribution,
    *,
    output_dir: Path | None = None,
) -> Path:
    build_root = resolve_build_root(environment.project_root, environment.workspace_root, output_dir=output_dir)
    if build_root.exists():
        shutil.rmtree(build_root)
    build_root.mkdir(parents=True, exist_ok=True)

    for source_path in sorted(pruned.kept_files):
        relative_path = source_path.relative_to(environment.project_root)
        target_path = build_root / _runtime_relative_path(relative_path)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, target_path)

    _sync_static_assets(environment, build_root)
    vendor_root = build_root / "python_modules"
    emit_vendor_modules(environment, analysis, pruned, vendor_root)
    _sync_project_runtime_resources(pruned, environment, vendor_root)

    payload = report_payload(environment, analysis, pruned)
    report_path = resolve_report_path(environment.project_root, environment.workspace_root, environment.config.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))

    manifest_path = report_path.with_name("manifest.json")
    manifest_path.write_text(json.dumps(payload["manifest"], indent=2, ensure_ascii=False))

    human_report_path = report_path.with_suffix(".txt")
    human_report_path.write_text(render_report(payload))

    return build_root


def _runtime_relative_path(relative_path: Path) -> Path:
    parts = relative_path.parts
    if parts and parts[0] == "src":
        return Path("python_modules", *parts[1:]) if len(parts) > 1 else Path("python_modules")
    return relative_path


def _sync_project_runtime_resources(
    pruned: PrunedDistribution,
    environment: ResolvedEnvironment,
    vendor_root: Path,
) -> None:
    for source_path in sorted(pruned.kept_files):
        relative_path = source_path.relative_to(environment.project_root)
        if relative_path.suffix == ".py":
            continue
        target_relative = _python_modules_relative_path(relative_path)
        target_path = vendor_root / target_relative
        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, target_path)


def _sync_static_assets(environment: ResolvedEnvironment, build_root: Path) -> None:
    assets = environment.wrangler_config.get("assets")
    if not isinstance(assets, Mapping):
        return
    assets_mapping = cast(Mapping[str, object], assets)
    directory = assets_mapping.get("directory")
    if not isinstance(directory, str):
        return
    source_dir = (environment.project_root / directory).resolve()
    if not source_dir.exists() or not source_dir.is_dir():
        return
    target_dir = build_root / directory
    if target_dir.exists():
        shutil.rmtree(target_dir)
    shutil.copytree(source_dir, target_dir)


def _python_modules_relative_path(relative_path: Path) -> Path:
    parts = relative_path.parts
    if parts and parts[0] == "src":
        return Path(*parts[1:]) if len(parts) > 1 else Path()
    return relative_path
