#!/usr/bin/env python3
# Legacy shim — packaging is now defined in pyproject.toml.
# pip install . will use pyproject.toml automatically (PEP 517).
import setuptools
setuptools.setup()
