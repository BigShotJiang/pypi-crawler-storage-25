import datetime

class EmbedFinder:
    def accept(self, url: str) -> bool: ...
    def find_embed(
        self, url: str, max_width: int | None = None, max_height: int | None = None
    ) -> dict[str, str | int | datetime.datetime | None]: ...
