from django.apps import AppConfig

class WagtailSettingsAppConfig(AppConfig):
    name: str
    label: str
    verbose_name: str
