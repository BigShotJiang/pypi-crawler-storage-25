from wagtail import hooks as hooks
from wagtail.admin.admin_url_finder import (
    ModelAdminURLFinder as ModelAdminURLFinder,
)
from wagtail.admin.admin_url_finder import (
    register_admin_url_finder as register_admin_url_finder,
)
from wagtail.admin.menu import MenuItem as MenuItem
from wagtail.admin.navigation import get_site_for_user as get_site_for_user
from wagtail.admin.search import SearchArea as SearchArea
from wagtail.admin.site_summary import SummaryItem as SummaryItem
from wagtail.images import (
    admin_urls as admin_urls,
)
from wagtail.images import (
    get_image_model as get_image_model,
)
from wagtail.images import (
    image_operations as image_operations,
)
from wagtail.images.api.admin.views import ImagesAdminAPIViewSet as ImagesAdminAPIViewSet
from wagtail.images.forms import GroupImagePermissionFormSet as GroupImagePermissionFormSet
from wagtail.images.permissions import permission_policy as permission_policy
from wagtail.images.rich_text import ImageEmbedHandler as ImageEmbedHandler
from wagtail.images.rich_text.contentstate import ContentstateImageConversionRule as ContentstateImageConversionRule
from wagtail.images.rich_text.editor_html import EditorHTMLImageConversionRule as EditorHTMLImageConversionRule
from wagtail.images.views.bulk_actions import (
    AddTagsBulkAction as AddTagsBulkAction,
)
from wagtail.images.views.bulk_actions import (
    AddToCollectionBulkAction as AddToCollectionBulkAction,
)
from wagtail.images.views.bulk_actions import (
    DeleteBulkAction as DeleteBulkAction,
)

def register_admin_urls(): ...
def construct_admin_api(router) -> None: ...

class ImagesMenuItem(MenuItem):
    def is_shown(self, request): ...

def register_images_menu_item(): ...
def register_image_feature(features) -> None: ...
def register_image_operations(): ...

class ImagesSummaryItem(SummaryItem):
    order: int
    template_name: str
    def get_context_data(self, parent_context): ...
    def is_shown(self): ...

def add_images_summary_item(request, items) -> None: ...

class ImagesSearchArea(SearchArea):
    def is_shown(self, request): ...

def register_images_search_area(): ...
def register_image_permissions_panel(): ...
def describe_collection_docs(collection): ...

class ImageAdminURLFinder(ModelAdminURLFinder):
    edit_url_name: str
    permission_policy = permission_policy

def register_image_chooser_viewset(): ...
