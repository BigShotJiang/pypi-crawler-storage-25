"""Pure-Python tests for eval evaluators against synthetic outputs.

These don't hit any RPC or AI provider — they verify the evaluator logic
correctly grades known-good and known-bad strings.
"""

from __future__ import annotations

import pytest

from hypnex_bench._evals.coding import build_suite as build_coding
from hypnex_bench._evals.json_mode import build_suite as build_json
from hypnex_bench._evals.math import build_suite as build_math


# --- coding ---------------------------------------------------------------
def test_coding_palindrome_correct():
    suite = build_coding()
    palindrome = next(p for p in suite.problems if p.id == "palindrome_alnum")
    correct_output = """```python
def is_palindrome(s: str) -> bool:
    cleaned = ''.join(c.lower() for c in s if c.isalnum())
    return cleaned == cleaned[::-1]
```"""
    assert palindrome.evaluator(correct_output) is True


def test_coding_palindrome_wrong():
    suite = build_coding()
    palindrome = next(p for p in suite.problems if p.id == "palindrome_alnum")
    wrong_output = """```python
def is_palindrome(s):
    return s == s[::-1]
```"""
    # Fails on case-insensitivity / non-alnum cleaning
    assert palindrome.evaluator(wrong_output) is False


def test_coding_no_code_block_fails():
    suite = build_coding()
    fib = next(p for p in suite.problems if p.id == "fibonacci_n")
    assert fib.evaluator("I would write a function called fib that returns numbers.") is False


def test_coding_fenced_without_python_marker():
    """Plain ``` fences (no `python`) should still parse."""
    suite = build_coding()
    fib = next(p for p in suite.problems if p.id == "fibonacci_n")
    output = """Here's the code:
```
def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
```"""
    assert fib.evaluator(output) is True


# --- math -----------------------------------------------------------------
def test_math_train_correct():
    suite = build_math()
    train = next(p for p in suite.problems if p.id == "train_distance")
    assert train.evaluator("60 mph * 2.5 hours = 150 miles. #### 150") is True


def test_math_last_number_extraction():
    suite = build_math()
    train = next(p for p in suite.problems if p.id == "train_distance")
    assert train.evaluator("Some reasoning here, then the answer: 150") is True


def test_math_wrong_answer():
    suite = build_math()
    train = next(p for p in suite.problems if p.id == "train_distance")
    assert train.evaluator("Hmm, I think 120") is False


def test_math_no_numbers():
    suite = build_math()
    train = next(p for p in suite.problems if p.id == "train_distance")
    assert train.evaluator("I don't know") is False


def test_math_tolerance():
    suite = build_math()
    tip = next(p for p in suite.problems if p.id == "tip_split")  # tolerance 0.01
    assert tip.evaluator("#### 25.20") is True
    assert tip.evaluator("#### 25.21") is True   # within tolerance
    assert tip.evaluator("#### 26.00") is False  # outside tolerance


# --- json -----------------------------------------------------------------
def test_json_person_correct():
    suite = build_json()
    person = next(p for p in suite.problems if p.id == "person_record")
    assert person.evaluator('{"name": "Ada Lovelace", "age": 35}') is True


def test_json_person_fenced():
    suite = build_json()
    person = next(p for p in suite.problems if p.id == "person_record")
    assert person.evaluator('```json\n{"name": "Ada Lovelace", "age": 35}\n```') is True


def test_json_invalid_parses_fail():
    suite = build_json()
    person = next(p for p in suite.problems if p.id == "person_record")
    assert person.evaluator("not json") is False


def test_json_strict_no_extra_keys():
    suite = build_json()
    reject = next(p for p in suite.problems if p.id == "reject_extra")
    assert reject.evaluator('{"ok": true}') is True
    assert reject.evaluator('{"ok": true, "extra": 1}') is False


def test_json_primes():
    suite = build_json()
    primes = next(p for p in suite.problems if p.id == "list_of_ints")
    correct = '{"primes_under_20": [2, 3, 5, 7, 11, 13, 17, 19]}'
    wrong   = '{"primes_under_20": [2, 3, 5, 7, 11, 13, 17, 19, 23]}'
    assert primes.evaluator(correct) is True
    assert primes.evaluator(wrong) is False


# --- runner stats ---------------------------------------------------------
def test_percentile_basic():
    from hypnex_bench.runner import percentile

    xs = [10.0, 20.0, 30.0, 40.0, 50.0]
    assert percentile(xs, 0.0) == 10.0
    assert percentile(xs, 0.5) == 30.0
    assert percentile(xs, 1.0) == 50.0


def test_percentile_empty_returns_zero():
    from hypnex_bench.runner import percentile

    assert percentile([], 0.5) == 0.0


# --- leaderboard rendering ------------------------------------------------
def test_leaderboard_renders_with_no_results():
    from hypnex_bench.leaderboard import to_markdown

    md = to_markdown([])
    assert "Hypnex Bench" in md


# --- suite registry -------------------------------------------------------
def test_all_suites_have_unique_problem_ids():
    from hypnex_bench import all_suites

    seen: set[tuple[str, str]] = set()
    for suite in all_suites():
        for p in suite.problems:
            key = (suite.name, p.id)
            assert key not in seen
            seen.add(key)


def test_by_name_unknown_raises():
    from hypnex_bench import by_name

    with pytest.raises(KeyError):
        by_name("does-not-exist")
