"""hypnex-bench — public eval + leaderboard for the Morpheus AI inference network.

Quickstart:

    pip install hypnex-bench
    HYPNEX_API_KEY=mor_...  hypnex-bench run --suite coding,math,json
    hypnex-bench leaderboard

Programmatic:

    from hypnex_bench import BenchRunner, all_suites, to_markdown

    runner = BenchRunner(api_key="mor_...")
    results = runner.run(["mistral-31-24b", "glm-5"], all_suites())
    print(to_markdown(results))

Each probe is short and the suite is small (~19 probes total), so a full run
across the live LLM set is typically <$0.20 of MOR.
"""

from ._evals import EvalSuite, ModelResult, Problem, ProbeResult, all_suites, by_name
from .leaderboard import to_markdown
from .runner import BenchRunner, fetch_active_models, llm_models, summarize
from .storage import read_latest, write_run

__version__ = "0.1.0"

__all__ = [
    "BenchRunner",
    "EvalSuite",
    "Problem",
    "ProbeResult",
    "ModelResult",
    "all_suites",
    "by_name",
    "fetch_active_models",
    "llm_models",
    "summarize",
    "to_markdown",
    "write_run",
    "read_latest",
    "__version__",
]
