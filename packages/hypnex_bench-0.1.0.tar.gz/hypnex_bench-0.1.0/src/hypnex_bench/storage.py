"""Append-only JSONL storage for bench results + a 'latest' summary writer."""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from ._evals import ModelResult, ProbeResult


def _to_jsonable(obj):  # type: ignore[no-untyped-def]
    if isinstance(obj, ModelResult):
        return {
            "model": obj.model,
            "started_at": obj.started_at,
            "finished_at": obj.finished_at,
            "total_probes": obj.total_probes,
            "passed_probes": obj.passed_probes,
            "pass_rate": obj.pass_rate,
            "by_suite": obj.by_suite(),
            "total_tokens": obj.total_tokens(),
            "probes": [_to_jsonable(p) for p in obj.probes],
        }
    if isinstance(obj, ProbeResult):
        return asdict(obj)
    raise TypeError(f"don't know how to serialize {type(obj)!r}")


def write_run(out_dir: Path, results: Iterable[ModelResult]) -> Path:
    """Append one run's results as a single JSONL file timestamped to UTC."""
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_path = out_dir / f"run-{ts}.jsonl"
    with out_path.open("w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(_to_jsonable(r), ensure_ascii=False))
            f.write("\n")
    update_latest(out_dir, results)
    return out_path


def update_latest(out_dir: Path, results: Iterable[ModelResult]) -> Path:
    """Refresh `latest.json` — a single document with the most recent run."""
    out_dir.mkdir(parents=True, exist_ok=True)
    latest_path = out_dir / "latest.json"
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "models": [_to_jsonable(r) for r in results],
    }
    latest_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    return latest_path


def read_latest(out_dir: Path) -> dict:
    p = out_dir / "latest.json"
    if not p.exists():
        return {"generated_at": None, "models": []}
    return json.loads(p.read_text())
