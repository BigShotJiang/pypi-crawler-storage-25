"""hypnex-bench CLI.

Usage:
    hypnex-bench models                              # list LLMs from active.mor.org
    hypnex-bench run                                 # run all suites on default models
    hypnex-bench run --models a,b,c --suite coding   # narrow models / suites
    hypnex-bench leaderboard                         # render markdown from data/latest.json
    hypnex-bench leaderboard --output README.md      # write to file
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from ._constants import ACTIVE_MODELS_URL, DEFAULT_BASE_URL, ENV_API_KEY
from ._evals import all_suites, by_name
from .leaderboard import to_markdown
from .runner import BenchRunner, fetch_active_models, llm_models, summarize
from .storage import read_latest, write_run


def _cmd_models(_: argparse.Namespace) -> int:
    try:
        models = fetch_active_models()
    except Exception as e:  # noqa: BLE001
        print(f"error fetching {ACTIVE_MODELS_URL}: {e}", file=sys.stderr)
        return 2
    print(f"{len(models)} active models on the Morpheus network:\n")
    for m in models:
        print(f"  {m['name']:<42}  type={m['type']:<10}  fee={m.get('fee', 0)}")
    return 0


def _cmd_run(args: argparse.Namespace) -> int:
    api_key = args.api_key or os.environ.get(ENV_API_KEY)
    if not api_key:
        print(f"error: set {ENV_API_KEY} or use --api-key. Get one at https://app.mor.org",
              file=sys.stderr)
        return 2

    if args.models:
        models = [m.strip() for m in args.models.split(",") if m.strip()]
    else:
        models = llm_models()
        if args.limit and args.limit > 0:
            models = models[: args.limit]

    if args.suite == "all":
        suites = all_suites()
    else:
        suites = [by_name(s) for s in args.suite.split(",")]

    out_dir = Path(args.output)
    runner = BenchRunner(api_key=api_key, base_url=args.base_url or DEFAULT_BASE_URL)
    print(
        f"Running {len(suites)} suite(s) ({sum(len(s.problems) for s in suites)} probes/model) "
        f"× {len(models)} models against {args.base_url or DEFAULT_BASE_URL}\n"
    )

    def _on_done(r):
        s = summarize(r)
        suite_str = " ".join(f"{n}={p}/{t}" for n, (p, t) in s["by_suite"].items())
        print(
            f"  {r.model:<42}  pass {s['passed']:>2}/{s['total']:<2} "
            f"({s['pass_rate']*100:5.1f}%)  p50={s['p50_ms']:>5.0f}ms  {suite_str}"
        )

    results = runner.run(models, suites, on_model_done=_on_done)
    out_path = write_run(out_dir, results)
    print(f"\nwrote {out_path}")
    print(f"latest snapshot: {out_dir / 'latest.json'}")
    return 0


def _cmd_leaderboard(args: argparse.Namespace) -> int:
    data = read_latest(Path(args.input))
    models = data.get("models", [])
    if not models:
        print("No latest results found. Run `hypnex-bench run` first.", file=sys.stderr)
        return 1

    # Reconstruct minimal ModelResult-shaped objects for the renderer.
    class _Lite:
        def __init__(self, m):
            self.model = m["model"]
            self.started_at = m.get("started_at", "")
            self.finished_at = m.get("finished_at", "")
            self._lat = [p.get("latency_ms", 0) for p in m.get("probes", []) if not p.get("error")]
            self._tokens = m.get("total_tokens", 0)
            self._by = m.get("by_suite", {})
            self._passed = m.get("passed_probes", 0)
            self._total = m.get("total_probes", 0)
            self.probes = []  # not used by summarize() in leaderboard mode

        @property
        def total_probes(self):
            return self._total

        @property
        def passed_probes(self):
            return self._passed

        @property
        def pass_rate(self):
            return self._passed / self._total if self._total else 0.0

        def latencies_ms(self):
            return self._lat

        def total_tokens(self):
            return self._tokens

        def by_suite(self):
            # keys are stored as JSON arrays after our custom serializer; coerce to tuples
            return {k: tuple(v) for k, v in self._by.items()}

    rendered = to_markdown([_Lite(m) for m in models])
    if args.output:
        Path(args.output).write_text(rendered)
        print(f"wrote {args.output}")
    else:
        print(rendered)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="hypnex-bench",
        description="Public eval + leaderboard for the Morpheus AI inference network.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("models", help="list active LLMs on the Morpheus network").set_defaults(fn=_cmd_models)

    rp = sub.add_parser("run", help="run eval suites against each model")
    rp.add_argument("--models", default=None, help="comma-separated model names (default: all live LLMs)")
    rp.add_argument("--limit", type=int, default=0, help="limit to first N models (when --models is omitted)")
    rp.add_argument("--suite", default="all", help="all | coding | math | json | a,b,c")
    rp.add_argument("--output", default="./data", help="output directory (default: ./data)")
    rp.add_argument("--api-key", default=None, help=f"override {ENV_API_KEY}")
    rp.add_argument("--base-url", default=None, help="override Morpheus inference URL")
    rp.set_defaults(fn=_cmd_run)

    lp = sub.add_parser("leaderboard", help="render markdown leaderboard from latest run")
    lp.add_argument("--input", default="./data", help="directory containing latest.json")
    lp.add_argument("--output", default=None, help="output file (default: stdout)")
    lp.set_defaults(fn=_cmd_leaderboard)

    args = p.parse_args(argv)
    return int(args.fn(args))


if __name__ == "__main__":
    raise SystemExit(main())
