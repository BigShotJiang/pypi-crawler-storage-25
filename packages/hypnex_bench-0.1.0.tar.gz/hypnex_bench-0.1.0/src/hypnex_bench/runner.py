"""BenchRunner — orchestrate eval probes against each model on api.mor.org."""

from __future__ import annotations

import os
import time
from datetime import datetime, timezone
from typing import Iterable, Optional

import httpx
from openai import OpenAI

from ._constants import (
    ACTIVE_MODELS_URL,
    DEFAULT_BASE_URL,
    DEFAULT_MAX_TOKENS,
    DEFAULT_MODELS,
    DEFAULT_REQUEST_TIMEOUT_S,
    DEFAULT_TEMPERATURE,
    ENV_API_KEY,
    ENV_BASE_URL,
)
from ._evals import EvalSuite, ModelResult, ProbeResult, all_suites


def fetch_active_models() -> list[dict]:
    """Public no-auth fetch of the live model registry. Filters out
    tombstoned entries and normalizes PascalCase / lowercase keys."""
    with httpx.Client(timeout=15.0) as h:
        r = h.get(ACTIVE_MODELS_URL)
        r.raise_for_status()
        raw = r.json().get("models", []) or []
    out: list[dict] = []
    for m in raw:
        name = m.get("Name") or m.get("name")
        mtype = m.get("ModelType") or m.get("type")
        is_deleted = m.get("IsDeleted") or m.get("is_deleted")
        if not name or is_deleted:
            continue
        out.append({
            "name": name,
            "type": str(mtype).upper() if mtype else "",
            "fee": m.get("Fee") or m.get("fee") or 0,
            "owner": m.get("Owner") or m.get("owner"),
        })
    return out


def llm_models() -> list[str]:
    """Return only the LLM model names (skip embedding/STT/TTS)."""
    try:
        models = fetch_active_models()
        names = sorted({m["name"] for m in models if m["type"] == "LLM"})
        return names if names else list(DEFAULT_MODELS)
    except Exception:
        return list(DEFAULT_MODELS)


class BenchRunner:
    """Run a fixed list of probes against each model, time them, score them."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout_s: float = DEFAULT_REQUEST_TIMEOUT_S,
    ) -> None:
        api_key = api_key or os.environ.get(ENV_API_KEY)
        if not api_key:
            raise ValueError(
                f"Set {ENV_API_KEY} (api key from app.mor.org) or pass api_key=..."
            )
        base_url = base_url or os.environ.get(ENV_BASE_URL, DEFAULT_BASE_URL)
        self.client = OpenAI(api_key=api_key, base_url=base_url, timeout=timeout_s)

    def run_probe(self, model: str, prompt: str) -> tuple[str, float, int, int, str]:
        """Return (output, latency_ms, prompt_tokens, completion_tokens, error_str)."""
        t0 = time.perf_counter()
        try:
            resp = self.client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=DEFAULT_MAX_TOKENS,
                temperature=DEFAULT_TEMPERATURE,
            )
            elapsed = (time.perf_counter() - t0) * 1000
            output = (resp.choices[0].message.content or "").strip()
            usage = getattr(resp, "usage", None)
            ptok = getattr(usage, "prompt_tokens", 0) if usage else 0
            ctok = getattr(usage, "completion_tokens", 0) if usage else 0
            return output, elapsed, ptok, ctok, ""
        except Exception as e:  # noqa: BLE001
            elapsed = (time.perf_counter() - t0) * 1000
            return "", elapsed, 0, 0, f"{type(e).__name__}: {str(e)[:160]}"

    def run_suite(self, model: str, suite: EvalSuite) -> list[ProbeResult]:
        results: list[ProbeResult] = []
        for problem in suite.problems:
            output, latency, ptok, ctok, err = self.run_probe(model, problem.prompt)
            passed = False if err else False
            try:
                if not err:
                    passed = bool(problem.evaluator(output))
            except Exception as e:  # noqa: BLE001
                err = f"evaluator error: {type(e).__name__}: {e}"
            results.append(
                ProbeResult(
                    suite=suite.name,
                    problem_id=problem.id,
                    model=model,
                    passed=passed,
                    latency_ms=latency,
                    prompt_tokens=ptok,
                    completion_tokens=ctok,
                    output_excerpt=(output or "")[:200].replace("\n", " "),
                    error=err,
                )
            )
        return results

    def run_model(
        self,
        model: str,
        suites: Optional[Iterable[EvalSuite]] = None,
    ) -> ModelResult:
        suites = list(suites) if suites is not None else all_suites()
        started = datetime.now(timezone.utc).isoformat()
        probes: list[ProbeResult] = []
        for suite in suites:
            probes.extend(self.run_suite(model, suite))
        finished = datetime.now(timezone.utc).isoformat()
        return ModelResult(model=model, started_at=started, finished_at=finished, probes=probes)

    def run(
        self,
        models: Iterable[str],
        suites: Optional[Iterable[EvalSuite]] = None,
        on_model_done=None,  # callable(model_result) -> None
    ) -> list[ModelResult]:
        suites_list = list(suites) if suites is not None else all_suites()
        results: list[ModelResult] = []
        for model in models:
            r = self.run_model(model, suites_list)
            results.append(r)
            if on_model_done is not None:
                on_model_done(r)
        return results


# --- latency stats ----------------------------------------------------------


def percentile(xs: list[float], q: float) -> float:
    """Linear-interp percentile for a small list. q in 0..1."""
    if not xs:
        return 0.0
    s = sorted(xs)
    if q <= 0:
        return s[0]
    if q >= 1:
        return s[-1]
    pos = q * (len(s) - 1)
    lo = int(pos)
    hi = min(lo + 1, len(s) - 1)
    frac = pos - lo
    return s[lo] + (s[hi] - s[lo]) * frac


def summarize(result: ModelResult) -> dict:
    lat = result.latencies_ms()
    return {
        "model": result.model,
        "pass_rate": result.pass_rate,
        "passed": result.passed_probes,
        "total": result.total_probes,
        "by_suite": result.by_suite(),
        "p50_ms": percentile(lat, 0.5),
        "p95_ms": percentile(lat, 0.95),
        "mean_ms": sum(lat) / len(lat) if lat else 0.0,
        "tokens": result.total_tokens(),
        "errors": sum(1 for p in result.probes if p.error),
    }
