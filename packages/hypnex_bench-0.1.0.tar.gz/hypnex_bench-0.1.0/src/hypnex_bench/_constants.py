"""Bench-runner constants."""

from __future__ import annotations

# Default Morpheus inference endpoint. Same as @hypnex/openai DEFAULT_BASE_URL.
DEFAULT_BASE_URL = "https://api.mor.org/api/v1"

# Public model registry (chain-of-truth, refreshed ~5 min by the API server).
ACTIVE_MODELS_URL = "https://active.mor.org/active_models.json"

# Health endpoint (used to derive total daily emission, model count, etc.)
HEALTH_URL = "https://api.mor.org/health"

# A safe default model set if the live registry can't be reached. These are
# the most commonly-cited Morpheus LLMs (May 2026). Override at runtime.
DEFAULT_MODELS: tuple[str, ...] = (
    "mistral-31-24b",
    "glm-5",
    "qwen3-235b",
    "qwen3-coder-480b-a35b-instruct",
    "minimax-m25",
)

# Latency probe: number of warm calls to average for p50/p95.
LATENCY_PROBE_RUNS = 3

# Per-call request settings — tuned to be cheap.
DEFAULT_MAX_TOKENS = 256
DEFAULT_TEMPERATURE = 0.0  # deterministic for evals where possible
DEFAULT_REQUEST_TIMEOUT_S = 60.0

# Environment variables (mirror hypnex-openai for muscle memory).
ENV_API_KEY = "HYPNEX_API_KEY"
ENV_BASE_URL = "HYPNEX_BASE_URL"
