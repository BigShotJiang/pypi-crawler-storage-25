"""HumanEval-lite — 6 coding probes that exec model output and check unit tests.

Each problem asks the model to write a Python function. We pull the code out
of the response, exec it in an isolated namespace, then run a small assertion
suite against it.
"""

from __future__ import annotations

import re
import textwrap
from dataclasses import dataclass

from ._base import EvalSuite, Problem


@dataclass(frozen=True)
class _CodeProblem:
    pid: str
    prompt: str
    function_name: str
    tests: str  # Python test code that must pass


def _extract_python(text: str) -> str:
    """Pull a Python code block out of the model's response.

    Looks for fenced ```python blocks first; falls back to any ``` block, then
    to the raw text.
    """
    fenced = re.search(r"```(?:python|py)?\s*\n(.*?)```", text, re.DOTALL)
    if fenced:
        return fenced.group(1)
    fenced_any = re.search(r"```\s*\n(.*?)```", text, re.DOTALL)
    if fenced_any:
        return fenced_any.group(1)
    return text


def _make_evaluator(p: _CodeProblem):
    def _evaluate(output: str) -> bool:
        code = _extract_python(output).strip()
        if not code:
            return False
        ns: dict = {}
        try:
            # Compile + exec the generated function definition
            exec(compile(code, "<model_output>", "exec"), ns, ns)
            if p.function_name not in ns:
                return False
            # Then exec the tests in the same namespace
            exec(compile(textwrap.dedent(p.tests), "<test>", "exec"), ns, ns)
            return True
        except Exception:
            return False

    return _evaluate


PROBLEMS: list[_CodeProblem] = [
    _CodeProblem(
        pid="palindrome_alnum",
        prompt=(
            "Write a Python function `is_palindrome(s: str) -> bool` that returns "
            "True if `s` reads the same forwards and backwards (case-insensitive, "
            "ignoring non-alphanumerics). Output the function ONLY, in a single "
            "```python``` block."
        ),
        function_name="is_palindrome",
        tests="""
            assert is_palindrome("A man a plan a canal Panama") is True
            assert is_palindrome("Hello") is False
            assert is_palindrome("") is True
            assert is_palindrome("Was it a car or a cat I saw?") is True
            assert is_palindrome("No 'x' in Nixon") is True
        """,
    ),
    _CodeProblem(
        pid="fibonacci_n",
        prompt=(
            "Write a Python function `fib(n: int) -> int` that returns the n-th "
            "Fibonacci number, with fib(0) = 0 and fib(1) = 1. Use iteration. "
            "Output the function ONLY, in a ```python``` block."
        ),
        function_name="fib",
        tests="""
            assert fib(0) == 0
            assert fib(1) == 1
            assert fib(10) == 55
            assert fib(20) == 6765
        """,
    ),
    _CodeProblem(
        pid="count_vowels",
        prompt=(
            "Write a Python function `count_vowels(s: str) -> int` that counts "
            "the vowels (a, e, i, o, u — both cases) in `s`. Output the function "
            "ONLY, in a ```python``` block."
        ),
        function_name="count_vowels",
        tests="""
            assert count_vowels("hello") == 2
            assert count_vowels("AEIOU") == 5
            assert count_vowels("xyz") == 0
            assert count_vowels("") == 0
        """,
    ),
    _CodeProblem(
        pid="merge_sorted",
        prompt=(
            "Write a Python function `merge(a: list[int], b: list[int]) -> list[int]` "
            "that merges two already-sorted ascending lists into one sorted list "
            "(stable, O(len(a)+len(b))). Output the function ONLY in a ```python``` block."
        ),
        function_name="merge",
        tests="""
            assert merge([], []) == []
            assert merge([1, 3, 5], [2, 4, 6]) == [1, 2, 3, 4, 5, 6]
            assert merge([1, 1, 2], [1, 3]) == [1, 1, 1, 2, 3]
            assert merge([], [1, 2]) == [1, 2]
        """,
    ),
    _CodeProblem(
        pid="word_frequency",
        prompt=(
            "Write a Python function `word_freq(text: str) -> dict[str, int]` that "
            "returns a dict mapping each lowercase word in `text` to how many times "
            "it appears. Words are split on whitespace and lowercased; punctuation "
            "is removed. Output the function ONLY in a ```python``` block."
        ),
        function_name="word_freq",
        tests="""
            r = word_freq("Hello, world! Hello.")
            assert r["hello"] == 2 and r["world"] == 1
            assert word_freq("") == {}
        """,
    ),
    _CodeProblem(
        pid="balanced_brackets",
        prompt=(
            "Write a Python function `is_balanced(s: str) -> bool` that returns True "
            "iff `()`, `[]`, `{}` brackets in `s` are matched and properly nested. "
            "Other characters are ignored. Output the function ONLY in a ```python``` block."
        ),
        function_name="is_balanced",
        tests="""
            assert is_balanced("()[]{}") is True
            assert is_balanced("({[]})") is True
            assert is_balanced("(") is False
            assert is_balanced("([)]") is False
            assert is_balanced("hello (world)") is True
            assert is_balanced("") is True
        """,
    ),
]


def build_suite() -> EvalSuite:
    return EvalSuite(
        name="coding",
        description="Six HumanEval-style probes — model writes a Python function, we exec + assert.",
        problems=[
            Problem(
                id=p.pid,
                prompt=p.prompt,
                evaluator=_make_evaluator(p),
                category="coding",
                source="hypnex-bench/coding",
            )
            for p in PROBLEMS
        ],
    )
