"""GSM8K-lite — 8 grade-school math word problems.

The model is asked to output the answer as a number (after any reasoning).
We strip commas, find the first integer or decimal in the response (or, if the
prompt nudges "after ####", look for that pattern first), and compare to the
expected value.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from ._base import EvalSuite, Problem


@dataclass(frozen=True)
class _MathProblem:
    pid: str
    prompt: str
    answer: float
    tolerance: float = 0.0  # allow small rounding error (e.g. 0.01)


def _extract_number(text: str) -> float | None:
    """Heuristic: look for the answer after a `####` marker (canonical GSM8K
    style); else take the LAST number in the response (most models put the
    final answer at the end after reasoning)."""
    cleaned = text.replace(",", "")
    after_hash = re.search(r"####\s*(-?\d+(?:\.\d+)?)", cleaned)
    if after_hash:
        return float(after_hash.group(1))
    nums = re.findall(r"-?\d+(?:\.\d+)?", cleaned)
    if not nums:
        return None
    return float(nums[-1])


_FP_EPSILON = 1e-9


def _make_evaluator(p: _MathProblem):
    def _evaluate(output: str) -> bool:
        n = _extract_number(output)
        if n is None:
            return False
        if p.tolerance > 0:
            return abs(n - p.answer) <= p.tolerance + _FP_EPSILON
        return abs(n - p.answer) <= _FP_EPSILON

    return _evaluate


_INSTRUCTION_FOOTER = (
    "\n\nThink step by step, then put the final numeric answer on its own "
    "line prefixed with '#### '. Example: '#### 42'."
)


PROBLEMS: list[_MathProblem] = [
    _MathProblem(
        pid="train_distance",
        prompt="A train travels 60 mph for 2.5 hours. How far does it travel, in miles?" + _INSTRUCTION_FOOTER,
        answer=150.0,
    ),
    _MathProblem(
        pid="apples_baskets",
        prompt=(
            "Sara has 4 baskets of 12 apples each. She gives 7 apples to her brother and "
            "eats 3 herself. How many apples are left?" + _INSTRUCTION_FOOTER
        ),
        answer=38.0,
    ),
    _MathProblem(
        pid="tip_split",
        prompt=(
            "A bill is $84 and a 20% tip is added. The total is split between 4 friends. "
            "How much does each friend pay (in dollars)?" + _INSTRUCTION_FOOTER
        ),
        answer=25.20,
        tolerance=0.01,
    ),
    _MathProblem(
        pid="discount_chain",
        prompt=(
            "A jacket costs $200. It is discounted 25%, then a further 10% is taken off "
            "the discounted price. What is the final price in dollars?" + _INSTRUCTION_FOOTER
        ),
        answer=135.0,
    ),
    _MathProblem(
        pid="age_problem",
        prompt=(
            "Alice is twice as old as Bob. In 5 years, the sum of their ages will be 40. "
            "How old is Alice now?" + _INSTRUCTION_FOOTER
        ),
        answer=20.0,
    ),
    _MathProblem(
        pid="rectangle_area",
        prompt=(
            "A rectangle has perimeter 30 cm and length 9 cm. What is its area in square cm?"
            + _INSTRUCTION_FOOTER
        ),
        answer=54.0,
    ),
    _MathProblem(
        pid="batch_compound",
        prompt=(
            "$1000 is invested at 5% annual interest, compounded yearly. After 3 years, "
            "what is the value to the nearest dollar?" + _INSTRUCTION_FOOTER
        ),
        answer=1158.0,
        tolerance=1.0,
    ),
    _MathProblem(
        pid="pencils_packs",
        prompt=(
            "A pack of pencils costs $3.50 and contains 12 pencils. A teacher buys "
            "enough packs to give each of 30 students 2 pencils. What is the total cost in dollars?"
            + _INSTRUCTION_FOOTER
        ),
        answer=17.50,
        tolerance=0.01,
    ),
]


def build_suite() -> EvalSuite:
    return EvalSuite(
        name="math",
        description="Eight GSM8K-style word problems. Final-answer extraction by '#### N' marker or last number.",
        problems=[
            Problem(
                id=p.pid,
                prompt=p.prompt,
                evaluator=_make_evaluator(p),
                category="math",
                source="hypnex-bench/math",
            )
            for p in PROBLEMS
        ],
    )
