"""JSON adherence — does the model produce a valid JSON object matching a schema?

Each problem ships a strict prompt asking for raw JSON only, plus a schema
checker that validates the parsed dict.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Callable

from ._base import EvalSuite, Problem


@dataclass(frozen=True)
class _JsonProblem:
    pid: str
    prompt: str
    schema_check: Callable[[Any], bool]


def _extract_json(text: str) -> str:
    """Pull the first JSON object out of the model's response.

    1. ``` json``` fenced block → take its content
    2. ``` ``` fenced block → take its content
    3. Otherwise: greedy substring from first '{' to matching '}'.
    """
    fenced = re.search(r"```(?:json)?\s*\n(.*?)```", text, re.DOTALL)
    if fenced:
        return fenced.group(1).strip()
    start = text.find("{")
    end = text.rfind("}")
    if 0 <= start < end:
        return text[start : end + 1]
    return text.strip()


def _make_evaluator(p: _JsonProblem):
    def _evaluate(output: str) -> bool:
        raw = _extract_json(output)
        try:
            parsed = json.loads(raw)
        except Exception:
            return False
        try:
            return bool(p.schema_check(parsed))
        except Exception:
            return False

    return _evaluate


PROBLEMS: list[_JsonProblem] = [
    _JsonProblem(
        pid="person_record",
        prompt=(
            'Return raw JSON (no prose, no fences) with exactly the keys '
            '"name" (string) and "age" (integer) for a person named Ada Lovelace, '
            "born 1815, age based on 1850."
        ),
        schema_check=lambda d: (
            isinstance(d, dict)
            and d.get("name") == "Ada Lovelace"
            and isinstance(d.get("age"), int)
            and d.get("age") == 35
        ),
    ),
    _JsonProblem(
        pid="address_nested",
        prompt=(
            'Return raw JSON with keys "user" (object with "first" and "last" string keys) '
            'and "address" (object with "city" string and "zip" string keys). Use exactly: '
            "first=Alan, last=Turing, city=London, zip=NW1."
        ),
        schema_check=lambda d: (
            isinstance(d, dict)
            and d.get("user", {}).get("first") == "Alan"
            and d.get("user", {}).get("last") == "Turing"
            and d.get("address", {}).get("city") == "London"
            and d.get("address", {}).get("zip") == "NW1"
        ),
    ),
    _JsonProblem(
        pid="list_of_ints",
        prompt=(
            'Return raw JSON: a single object with key "primes_under_20" whose value is a '
            "JSON array of integers — the prime numbers strictly less than 20, ascending."
        ),
        schema_check=lambda d: (
            isinstance(d, dict)
            and d.get("primes_under_20") == [2, 3, 5, 7, 11, 13, 17, 19]
        ),
    ),
    _JsonProblem(
        pid="bool_and_null",
        prompt=(
            'Return raw JSON with keys "active" (boolean true) and "deleted_at" (JSON null).'
        ),
        schema_check=lambda d: (
            isinstance(d, dict)
            and d.get("active") is True
            and "deleted_at" in d
            and d.get("deleted_at") is None
        ),
    ),
    _JsonProblem(
        pid="reject_extra",
        prompt=(
            'Return ONLY a JSON object with the single key "ok" set to true. '
            "Do not include any other keys, prose, or markdown."
        ),
        schema_check=lambda d: (
            isinstance(d, dict) and d == {"ok": True}
        ),
    ),
]


def build_suite() -> EvalSuite:
    return EvalSuite(
        name="json",
        description="Five JSON-adherence probes. Tests parseability + schema match.",
        problems=[
            Problem(
                id=p.pid,
                prompt=p.prompt,
                evaluator=_make_evaluator(p),
                category="json",
                source="hypnex-bench/json",
            )
            for p in PROBLEMS
        ],
    )
