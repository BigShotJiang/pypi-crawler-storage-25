"""Eval primitives — Problem + EvalSuite + Result dataclasses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable


@dataclass
class Problem:
    """One probe in an eval suite."""

    id: str
    prompt: str
    # The evaluator returns True if the model's output is correct.
    evaluator: Callable[[str], bool]
    # Display category (e.g. "coding/strings").
    category: str = ""
    # Reference / source of the probe.
    source: str = ""


@dataclass
class EvalSuite:
    """A collection of probes that share a name + scoring rubric."""

    name: str
    description: str
    problems: list[Problem]


@dataclass
class ProbeResult:
    """Outcome of running one Problem against one model."""

    suite: str
    problem_id: str
    model: str
    passed: bool
    latency_ms: float
    prompt_tokens: int = 0
    completion_tokens: int = 0
    output_excerpt: str = ""  # first ~200 chars for debugging
    error: str = ""


@dataclass
class ModelResult:
    """Aggregate across all probes for one model."""

    model: str
    started_at: str  # ISO8601
    finished_at: str
    probes: list[ProbeResult] = field(default_factory=list)

    # --- aggregates ---
    @property
    def total_probes(self) -> int:
        return len(self.probes)

    @property
    def passed_probes(self) -> int:
        return sum(1 for p in self.probes if p.passed)

    @property
    def pass_rate(self) -> float:
        return self.passed_probes / self.total_probes if self.total_probes else 0.0

    def latencies_ms(self) -> list[float]:
        return [p.latency_ms for p in self.probes if p.error == ""]

    def total_tokens(self) -> int:
        return sum(p.prompt_tokens + p.completion_tokens for p in self.probes)

    def by_suite(self) -> dict[str, tuple[int, int]]:
        """suite_name -> (passed, total)."""
        agg: dict[str, list[int]] = {}
        for p in self.probes:
            entry = agg.setdefault(p.suite, [0, 0])
            entry[1] += 1
            if p.passed:
                entry[0] += 1
        return {k: (v[0], v[1]) for k, v in agg.items()}
