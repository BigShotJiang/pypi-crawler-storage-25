"""Built-in eval suites."""

from ._base import EvalSuite, ModelResult, Problem, ProbeResult
from .coding import build_suite as build_coding
from .json_mode import build_suite as build_json
from .math import build_suite as build_math


def all_suites() -> list[EvalSuite]:
    return [build_coding(), build_math(), build_json()]


def by_name(name: str) -> EvalSuite:
    suites = {s.name: s for s in all_suites()}
    if name not in suites:
        raise KeyError(
            f"Unknown eval suite {name!r}. Known: {sorted(suites)}"
        )
    return suites[name]


__all__ = [
    "EvalSuite",
    "Problem",
    "ProbeResult",
    "ModelResult",
    "all_suites",
    "by_name",
    "build_coding",
    "build_math",
    "build_json",
]
