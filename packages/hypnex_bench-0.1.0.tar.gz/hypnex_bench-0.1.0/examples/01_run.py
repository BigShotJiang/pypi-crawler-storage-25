"""Run all eval suites on the default LLM set, save results, print leaderboard.

Run:
    HYPNEX_API_KEY=mor_...  python examples/01_run.py
"""

import os
from pathlib import Path

from hypnex_bench import BenchRunner, all_suites, llm_models, summarize, to_markdown, write_run


def main() -> None:
    runner = BenchRunner(api_key=os.environ["HYPNEX_API_KEY"])
    models = llm_models()[:3]  # first 3 LLMs to keep this example cheap
    suites = all_suites()
    print(f"Running {len(suites)} suites x {len(models)} models...")
    results = runner.run(models, suites)
    for r in results:
        s = summarize(r)
        print(f"  {r.model}: {s['passed']}/{s['total']} ({s['pass_rate']*100:.0f}%) p50={s['p50_ms']:.0f}ms")
    out = write_run(Path("./data"), results)
    print(f"\nwrote {out}")
    print()
    print(to_markdown(results))


if __name__ == "__main__":
    main()
