from django.db import models
from django.core.validators import MinValueValidator
from .utils.j_ulid_field import JULIDField


class ExamSubject(models.Model):
    """科目"""
    name = models.CharField(max_length=100, verbose_name="科目名称")
    description = models.TextField(blank=True, verbose_name="科目描述")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        db_table = 'exam_subject'
        verbose_name = "科目"
        verbose_name_plural = "01. 考试 - 科目"

    def __str__(self):
        return self.name


class ExamQuestion(models.Model):
    """考试题目"""
    subject = models.ForeignKey(ExamSubject, on_delete=models.CASCADE, related_name='questions', db_constraint=False, db_index=True, verbose_name="所属科目")
    question = models.TextField(verbose_name="题目内容")
    score = models.IntegerField(default=1, validators=[MinValueValidator(1)], verbose_name="分值")
    analysis = models.TextField(verbose_name="答案解析")
    column = models.IntegerField(verbose_name="选项展示列数", blank=True, null=True, default=0, help_text="默认值 0，即一行显示，不分列。")
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="创建时间")

    class Meta:
        db_table = 'exam_question'
        verbose_name = "考试题目"
        verbose_name_plural = "02. 考试 - 考试题目"
        ordering = ['-create_time']

    def __str__(self):
        return f"{self.question[:50]}..."


class ExamQuestionOption(models.Model):
    """题目选项"""
    question_id = models.ForeignKey(ExamQuestion, on_delete=models.CASCADE, related_name='options', db_constraint=False, db_column="question_id", db_index=True, verbose_name="所属题目")
    option = models.CharField(max_length=1, verbose_name="选项标签")
    content = models.TextField(verbose_name="选项内容")
    is_correct = models.BooleanField(default=False, db_index=True, verbose_name="是否正确答案")

    class Meta:
        db_table = 'exam_question_option'
        verbose_name = "题目选项"
        verbose_name_plural = "03. 考试 - 题目选项"
        ordering = ['option']

    def __str__(self):
        return f"{self.option}. {self.content[:30]}"


class ExamPaper(models.Model):
    """试卷"""
    title = models.CharField(max_length=200, verbose_name="考试标题")
    subject = models.ForeignKey(ExamSubject, on_delete=models.CASCADE, related_name='exams', db_constraint=False, db_index=True, verbose_name="所属科目")
    duration = models.IntegerField(default=60, validators=[MinValueValidator(1)], verbose_name="考试时长(分钟)")
    total_score = models.IntegerField(default=100, verbose_name="总分")
    pass_score = models.IntegerField(default=60, verbose_name="及格分")
    questions = models.ManyToManyField(ExamQuestion, through='ExamPaperQuestion', related_name='exams', verbose_name="试卷题目", blank=True)
    create_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="创建时间")

    class Meta:
        db_table = 'exam_paper'
        verbose_name = "试卷"
        verbose_name_plural = "06. 考试 - 试卷"
        ordering = ['-create_time']

    def __str__(self):
        return self.title

    def get_all_questions(self):
        """获取试卷的所有题目（按 section.sort + number 排序）"""
        return ExamQuestion.objects.filter(exampaperquestion__exam_paper=self).distinct().order_by('exampaperquestion__section__sort', 'exampaperquestion__number')

    def get_questions_by_section(self):
        """按专项分组获取题目 - 返回格式：{section: [question1, question2, ...]}"""
        from collections import OrderedDict
        result = OrderedDict()
        sections = ExamPaperSection.objects.filter(exam_paper=self).prefetch_related('exampaperquestion_set__exam_question').order_by('sort')
        for section in sections:
            questions = [epq.exam_question for epq in section.exampaperquestion_set.all().order_by('number')]
            result[section] = questions
        return result


class ExamPaperSection(models.Model):
    """试卷专项部分（可选）"""
    exam_paper = models.ForeignKey('ExamPaper', on_delete=models.CASCADE, related_name='sections', db_constraint=False, db_column='exam_paper_id', db_index=True, verbose_name="所属试卷")
    title = models.CharField(max_length=200, verbose_name="专项标题", help_text="例如：单选题、多选题、判断题等")
    description = models.TextField(blank=True, verbose_name="专项描述", help_text="专项说明文字")
    sort = models.IntegerField(default=0, db_index=True, verbose_name="专项顺序", help_text="专项在试卷中的顺序，数字越小越靠前")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")

    class Meta:
        db_table = 'exam_paper_section'
        verbose_name = "试卷专项"
        verbose_name_plural = "04. 考试 - 试卷专项"
        ordering = ['exam_paper', 'sort']

    def __str__(self):
        try:
            return f"{self.exam_paper.title} - {self.title}"
        except:
            return f"专项 #{self.pk or '新建'}"

    def get_questions(self):
        """获取该专项的所有题目"""
        return ExamQuestion.objects.filter(exampaperquestion__section=self).order_by('exampaperquestion__number')


class ExamPaperQuestion(models.Model):
    """试卷-题目关联表（中间表） - 三者完全解耦，灵活搭配"""
    exam_paper = models.ForeignKey(ExamPaper, on_delete=models.CASCADE, db_column='exam_paper_id', db_constraint=False, db_index=True, verbose_name="所属试卷")
    section = models.ForeignKey(ExamPaperSection, on_delete=models.CASCADE, db_column='section_id', db_constraint=False, db_index=True, verbose_name="所属专项", blank=True, null=True, help_text="可选：留空则为简单试卷")
    exam_question = models.ForeignKey(ExamQuestion, on_delete=models.CASCADE, db_column='exam_question_id', db_constraint=False, db_index=True, verbose_name="所属题目")
    number = models.IntegerField(default=0, db_index=True, verbose_name="题目序号", help_text="题目顺序，数字越小越靠前")

    class Meta:
        db_table = 'exam_paper_questions'
        verbose_name = "试卷题目"
        verbose_name_plural = "05. 考试 - 试卷题目"
        ordering = ['exam_paper', 'number']

    def __str__(self):
        try:
            paper = self.exam_paper.title if self.exam_paper_id else f"试卷#{self.exam_paper_id}"
            question = self.exam_question.question[:30] if self.exam_question_id else f"题目#{self.exam_question_id}"
            section = f" - {self.section.title}" if self.section_id else ""
            return f"{paper}{section} - {question}"
        except:
            return f"题目关联 #{self.pk or '新建'}"


class ExamRecord(models.Model):
    """考试记录"""
    STATUS_CHOICES = [('testing', '进行中'), ('tested', '已完成')]
    paper = models.ForeignKey(ExamPaper, on_delete=models.CASCADE, related_name='records', db_constraint=False, db_index=True, verbose_name="考试")
    user_id = models.BigIntegerField(verbose_name='用户ID', db_column='user_id', db_index=True, blank=True, null=True)
    user_uuid = JULIDField(verbose_name='用户UUID', editable=True, blank=True, null=True, db_index=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='testing', db_index=True, verbose_name="状态")
    score = models.FloatField(default=0, verbose_name="得分")
    is_passed = models.BooleanField(default=False, db_index=True, verbose_name="是否通过")
    start_time = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name="开始时间")
    submit_time = models.DateTimeField(null=True, blank=True, verbose_name="提交时间")

    class Meta:
        db_table = 'exam_record'
        verbose_name = "考试记录"
        verbose_name_plural = "07. 考试 - 考试记录"
        ordering = ['-start_time']

    def __str__(self):
        return f"{self.user_id or self.user_uuid} - {self.paper.title}"


class ExamAnswerRecord(models.Model):
    """答题记录"""
    exam_record = models.ForeignKey(ExamRecord, on_delete=models.CASCADE, related_name='answers', db_constraint=False, db_index=True, verbose_name="考试记录")
    question = models.ForeignKey(ExamQuestion, on_delete=models.CASCADE, db_constraint=False, db_index=True, verbose_name="题目")
    question_option = models.ForeignKey(ExamQuestionOption, on_delete=models.CASCADE, null=True, db_constraint=False, db_index=True, blank=True, verbose_name="选择的选项")
    is_correct = models.BooleanField(default=False, db_index=True, verbose_name="是否正确")
    score = models.FloatField(default=0, verbose_name="得分")
    snapshot = models.JSONField(blank=True, null=True, verbose_name="答题快照", help_text="存储答题时的题目、选项等完整信息的JSON快照")

    class Meta:
        db_table = 'exam_answer_record'
        verbose_name = "答题记录"
        verbose_name_plural = "08. 考试 - 答题记录"

    def __str__(self):
        return f"{self.exam_record.user_id or self.exam_record.user_uuid} - {self.question.question[:30]}"