# encoding: utf-8
"""
@project: exam_paper_api
@author:
@Email:
@synopsis: 试卷API接口
@created_time: 2026
"""

from rest_framework.views import APIView

from ..services.exam_paper_service import ExamPaperService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper
from ..utils.j_transform_type import JTransformType

class ExamPaperItemAPI(APIView):
    """
    试卷详情API：获取单个试卷的详细信息
    @description
    - 获取试卷基本信息
    - 包含题目总数统计
    - 包含专项信息
    - 包含每个专项的题目数量
    """
    @request_params_wrapper
    def get(self, *args, pk=None, request_params=None, **kwargs):
        """
        获取试卷详情
        @param pk: 试卷ID（从URL路径获取）
        @example
        GET /api/exam/paper/1/
        @return
        {
            "err": 0,
            "data": {
                "id": 1,
                "title": "2024年高考数学模拟试卷",
                "subject_id": 1,
                "subject_name": "数学",
                "duration": 120,
                "total_score": 150,
                "pass_score": 90,
                "create_time": "2024-01-15 10:00:00",
                "question_count": 50,
                "section_count": 3,
                "sections": [
                    {
                        "id": 1,
                        "title": "单选题",
                        "description": "每题5分，共40分",
                        "sort": 1,
                        "create_time": "2024-01-15 10:00:00",
                        "question_count": 8
                    }
                ]
            }
        }
        @error_codes
        - 8401: 缺少试卷ID
        - 8404: 试卷不存在
        - 8405: 查询失败
        """
        # ========== 参数验证 ==========
        if not pk:
            return util_response(err=8401, msg="缺少试卷ID(id)字段。")
        # 转换为整数
        try:
            pk = int(pk)
        except (ValueError, TypeError):
            return util_response(err=8401, msg="试卷ID格式错误。")
        # ========== 调用服务层 ==========
        data, error_text = ExamPaperService.item(pk=pk)
        if not error_text:
            return util_response(data=data)
        # ========== 错误处理 ==========
        if "不存在" in error_text:
            return util_response(err=8404, msg=error_text)
        else:
            return util_response(err=8405, msg=error_text)


class ExamPaperListAPI(APIView):
    """
    试卷列表API：列表查询

    @description
    - 支持多条件查询
    - 支持ID列表查询
    - 支持分页
    - 支持排序
    - 可选返回专项信息
    - 可选返回题目统计信息
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取试卷列表

        @param page: 页码，默认1
        @param size: 每页数量，默认20（别名：page_size）
        @param sort: 排序字段，默认-create_time（别名：order_by）
        @param search: 搜索关键词（试卷标题）
        @param id_list: 试卷ID列表（逗号分隔或数组）
        @param subject_id: 科目ID
        @param subject_id_list: 科目ID列表（逗号分隔或数组）
        @param title: 试卷标题（模糊查询）
        @param duration: 考试时长（精确查询）
        @param duration_min: 最小时长
        @param duration_max: 最大时长
        @param total_score: 总分（精确查询）
        @param total_score_min: 最小总分
        @param total_score_max: 最大总分
        @param pass_score: 及格分（精确查询）
        @param pass_score_min: 最小及格分
        @param pass_score_max: 最大及格分
        @param create_time_start: 创建开始时间
        @param create_time_end: 创建结束时间
        @param with_sections: 是否包含专项信息，默认false
        @param with_questions: 是否包含题目统计信息，默认false

        @example
        GET /api/exam/paper_list/?page=1&size=20
        GET /api/exam/paper_list/?subject_id=1
        GET /api/exam/paper_list/?with_sections=true&with_questions=true
        GET /api/exam/paper_list/?search=期末考试
        """

        # ========== 分页参数 ==========
        page, is_void = JTransformType.to(request_params.get('page', 1), "int", 1)
        size, is_void = JTransformType.to(
            request_params.get('size') or request_params.get('page_size', 20),
            "int",
            20
        )

        # ========== 排序参数 ==========
        sort, is_void = JTransformType.to(
            request_params.get('sort') or request_params.get('order_by', '-create_time'),
            "str",
            "-create_time"
        )

        # ========== 显示选项 ==========
        with_sections, is_void = JTransformType.to(
            request_params.get('with_sections', False),
            "bool",
            False
        )
        with_questions, is_void = JTransformType.to(
            request_params.get('with_questions', False),
            "bool",
            False
        )

        # ========== ID列表参数 ==========
        id_list_param = request_params.get('id_list', None)
        id_list = None
        if id_list_param:
            if isinstance(id_list_param, str):
                id_list = [int(x.strip()) for x in id_list_param.split(',') if x.strip().isdigit()]
            elif isinstance(id_list_param, list):
                id_list = [int(x) for x in id_list_param if str(x).isdigit()]

        # ========== 科目ID ==========
        subject_id, is_void = JTransformType.to(request_params.get('subject_id', None), "int", None)

        # ========== 科目ID列表 ==========
        subject_id_list_param = request_params.get('subject_id_list', None)
        subject_id_list = None
        if subject_id_list_param:
            if isinstance(subject_id_list_param, str):
                subject_id_list = [int(x.strip()) for x in subject_id_list_param.split(',') if x.strip().isdigit()]
            elif isinstance(subject_id_list_param, list):
                subject_id_list = [int(x) for x in subject_id_list_param if str(x).isdigit()]

        # ========== 构建查询参数 ==========
        query_params = {}

        # 搜索关键词
        search = request_params.get('search', None)
        if search:
            query_params['search'] = search

        # 其他查询条件
        query_fields = [
            'id', 'title', 'duration', 'duration_min', 'duration_max',
            'total_score', 'total_score_min', 'total_score_max',
            'pass_score', 'pass_score_min', 'pass_score_max',
            'create_time_start', 'create_time_end'
        ]
        for field in query_fields:
            value = request_params.get(field, None)
            if value:
                query_params[field] = value

        # 科目ID列表
        if subject_id_list:
            query_params['subject_id_list'] = subject_id_list

        # ========== 参数验证 ==========
        if page < 1:
            page = 1
        if size < 1 or size > 100:
            size = 20

        # 排序字段验证
        sort_choices = [
            "id", "-id",
            "title", "-title",
            "subject_id", "-subject_id",
            "duration", "-duration",
            "total_score", "-total_score",
            "pass_score", "-pass_score",
            "create_time", "-create_time"
        ]
        if sort not in sort_choices:
            return util_response(
                err=8402,
                msg=f"排序字段无效，可选值：{'、'.join(sort_choices)}。"
            )

        # ========== 调用服务层 ==========
        data, error_text = ExamPaperService.list(
            id_list=id_list,
            subject_id=subject_id,
            query_params=query_params,
            page=page,
            size=size,
            sort=sort,
            with_sections=with_sections,
            with_questions=with_questions,
        )

        if not error_text:
            return util_response(data=data)
        return util_response(err=8406, msg=error_text)