# encoding: utf-8
"""
@project: exam_subject_api
@author: 
@Email: 
@synopsis: 考试科目API接口
@created_time: 2026
"""

import sys
from rest_framework.views import APIView

if 'xj_user' in sys.modules:
    from xj_user.services.user_service import UserService

from ..services.exam_subject_service import ExamSubjectService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper
from ..utils.user_wrapper import user_authentication_force_wrapper
from ..utils.x_request_wrapper import x_request_wrapper
from ..utils.j_transform_type import JTransformType


class ExamSubjectItemAPI(APIView):
    """
    考试科目单项操作API：详情、编辑、删除
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取科目详情
        @param pk: 主键ID或科目名称
        """
        pk = kwargs.get("pk", None)
        if not pk:
            return util_response(msg="缺少主键ID或科目名称。", err=1000)

        # 判断是ID还是名称
        subject_id = int(pk) if str.isdigit(pk) else None
        subject_name = pk if not str.isdigit(pk) else None

        data, error_text = ExamSubjectService.item(pk=subject_id, name=subject_name)
        if not error_text:
            return util_response(data=data)
        return util_response(err=8206, msg=error_text)

    @request_params_wrapper
    def post(self, *args, request_params=None, **kwargs):
        """
        添加科目
        """

        # 调用服务层
        data, err_txt = ExamSubjectService.add(params=request_params)
        if not err_txt:
            return util_response(data=data)
        return util_response(err=47767, msg=err_txt)

    @request_params_wrapper
    def put(self, *args, request_params=None, **kwargs):
        """
        编辑科目
        @param pk: 科目ID
        """
        pk = kwargs.get("pk", None)
        if not pk:
            return util_response(msg="缺少主键ID。", err=1000)

        # 转换为整数
        try:
            subject_id = int(pk)
        except ValueError:
            return util_response(msg="主键ID格式错误。", err=1001)

        # 调用服务层
        data, error_text = ExamSubjectService.edit(pk=subject_id, params=request_params)
        if error_text:
            return util_response(err=1002, msg=error_text)

        return util_response(data=data)

    @user_authentication_force_wrapper
    def delete(self, *args, **kwargs):
        """
        删除科目
        @param pk: 科目ID
        """
        pk = kwargs.get("pk", None)
        if not pk:
            return util_response(msg="缺少主键ID。", err=1000)

        # 转换为整数
        try:
            subject_id = int(pk)
        except ValueError:
            return util_response(msg="主键ID格式错误。", err=1001)

        # 调用服务层
        data, error_text = ExamSubjectService.delete(pk=subject_id)
        if not error_text:
            return util_response(msg="删除成功")
        return util_response(err=47767, msg=error_text)


class ExamSubjectListAPI(APIView):
    """
    考试科目列表API：列表查询、批量添加

    @description
    [2024.12.10] 参考 thread_list_service_v2.py 重构
    - 支持多条件查询
    - 支持ID列表查询
    - 支持分页
    - 支持排序
    - 支持批量添加
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取科目列表

        @param page: 页码，默认1
        @param size: 每页数量，默认20（别名：page_size）
        @param sort: 排序字段，默认-create_time（别名：order_by）
        @param search: 搜索关键词（科目名称或描述）
        @param id_list: 科目ID列表（逗号分隔或数组）
        @param name: 科目名称（模糊查询）
        @param description: 科目描述（模糊查询）
        @param create_time_start: 创建开始时间
        @param create_time_end: 创建结束时间
        @param filter_fields: 返回字段筛选

        @example
        GET /api/exam/subject_list/?page=1&size=20
        GET /api/exam/subject_list/?search=数学
        GET /api/exam/subject_list/?id_list=1,2,3
        GET /api/exam/subject_list/?name=数学&sort=-id
        """

        # ========== 参数提取与转换 ==========
        # 分页参数
        page, is_void = JTransformType.to(request_params.get('page', 1), "int", 1)
        # 兼容 page_size 和 size
        size, is_void = JTransformType.to(
            request_params.get('size') or request_params.get('page_size', 20),
            "int",
            20
        )

        # 排序参数（兼容 sort 和 order_by）
        sort, is_void = JTransformType.to(
            request_params.get('sort') or request_params.get('order_by', '-create_time'),
            "str",
            "-create_time"
        )

        # ID列表参数
        id_list_param = request_params.get('id_list', None)
        id_list = None
        if id_list_param:
            # 支持逗号分隔的字符串或数组
            if isinstance(id_list_param, str):
                id_list = [int(x.strip()) for x in id_list_param.split(',') if x.strip().isdigit()]
            elif isinstance(id_list_param, list):
                id_list = [int(x) for x in id_list_param if str(x).isdigit()]

        # ========== 构建查询参数 ==========
        query_params = {}

        # 搜索关键词
        search = request_params.get('search', None)
        if search:
            query_params['search'] = search

        # 其他查询条件
        query_fields = [
            'id', 'name', 'description',
            'create_time_start', 'create_time_end',
        ]
        for field in query_fields:
            value = request_params.get(field, None)
            if value:
                query_params[field] = value

        # ========== 参数验证 ==========
        if page < 1:
            page = 1
        if size < 1 or size > 100:
            size = 20

        # 排序字段验证
        sort_choices = [
            "id", "-id",
            "name", "-name",
            "create_time", "-create_time",
        ]
        if sort not in sort_choices:
            return util_response(
                err=8202,
                msg=f"排序字段无效，可选值：{'、'.join(sort_choices)}。"
            )

        # ========== 调用服务层 ==========
        data, error_text = ExamSubjectService.list(
            id_list=id_list,
            query_params=query_params,
            page=page,
            size=size,
            sort=sort,
        )

        if not error_text:
            return util_response(data=data)
        return util_response(err=8206, msg=error_text)

    @x_request_wrapper
    def post(self, request, request_params, *args, **kwargs):
        """
        批量添加科目

        @param subjects: 科目列表，格式：[{"name": "数学", "description": "数学科目"}, ...]

        @example
        POST /api/exam/subject_list/
        {
            "subjects": [
                {"name": "语文", "description": "语文科目"},
                {"name": "数学", "description": "数学科目"},
                {"name": "英语", "description": "英语科目"}
            ]
        }

        @return
        {
            "err": 0,
            "data": {
                "success_count": 2,
                "error_count": 1,
                "success_list": [...],
                "error_list": [...]
            }
        }
        """

        # ========== 用户令牌验证（可选） ==========
        token = request.META.get('HTTP_AUTHORIZATION', None)
        if token and 'xj_user' in sys.modules:
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)

        # ========== 参数验证 ==========
        subjects = request_params.get('subjects', [])

        # 类型验证
        if not subjects:
            return util_response(err=8201, msg="批量数据(subjects)不能为空。")

        if not isinstance(subjects, list):
            return util_response(err=8201, msg="批量数据(subjects)必须是列表格式。")

        # 数量限制
        if len(subjects) > 100:
            return util_response(err=8203, msg="单次批量添加不能超过100条数据。")

        # 数据格式验证
        for index, subject_data in enumerate(subjects):
            if not isinstance(subject_data, dict):
                return util_response(
                    err=8204,
                    msg=f"第 {index + 1} 条数据格式错误，必须是字典格式。"
                )
            if not subject_data.get('name'):
                return util_response(
                    err=8205,
                    msg=f"第 {index + 1} 条数据缺少必填字段：name（科目名称）。"
                )

        # ========== 批量添加 ==========
        success_list = []
        error_list = []

        for index, subject_data in enumerate(subjects):
            data, err_txt = ExamSubjectService.add(params=subject_data)
            if not err_txt:
                success_list.append(data)
            else:
                error_list.append({
                    "index": index + 1,
                    "data": subject_data,
                    "error": err_txt
                })

        # ========== 返回结果 ==========
        result = {
            "success_count": len(success_list),
            "error_count": len(error_list),
            "success_list": success_list,
            "error_list": error_list,
        }

        # 如果全部失败，返回错误
        if len(error_list) == len(subjects):
            return util_response(err=8207, msg="批量添加失败，所有数据都未成功添加。", data=result)

        # 部分成功或全部成功
        return util_response(data=result)