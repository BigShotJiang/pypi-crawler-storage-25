# encoding: utf-8
"""
@project: exam_record_api
@author:
@Email:
@synopsis: 考试记录API接口
@created_time: 2026
"""
import sys

from rest_framework.views import APIView
from ..services.exam_record_service import ExamRecordService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper
from ..utils.j_transform_type import JTransformType
from ..utils.parse_data import parse_data

class ExamRecordAPI(APIView):
    def post(self, request):
        """添加考试记录"""
        # 用户令牌验证
        token = request.headers.get('Authorization')
        print("token::", token)
        if 'xj_user' in sys.modules:
            from xj_user.services.user_service import UserService
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)
            user_uuid = token_serv.get('user_uuid', None)
            user_id = token_serv.get('user_id', None)
        else:
            return util_response(err=6046, msg="用户模块未安装")
        params = parse_data(request)
        # 获取试卷ID
        paper_id, is_void = JTransformType.to(params.get('paper_id', None), "int", None)
        if not paper_id:
            return util_response(err=8501, msg="试卷ID(paper_id)必填")

        # 调用服务层
        data, error_text = ExamRecordService.add(user_uuid=user_uuid, user_id=user_id, paper_id=paper_id, params=params)

        if not error_text:
            return util_response(data=data)
        return util_response(err=8502, msg=error_text)

class ExamRecordListAPI(APIView):
    """考试记录列表API"""

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """获取考试记录列表"""

        # 分页参数
        page, is_void = JTransformType.to(request_params.get('page', 1), "int", 1)
        size, is_void = JTransformType.to(request_params.get('size') or request_params.get('page_size', 20), "int", 20)
        sort, is_void = JTransformType.to(request_params.get('sort') or request_params.get('order_by', '-start_time'),
                                          "str", "-start_time")

        # 筛选参数
        paper_id, is_void = JTransformType.to(request_params.get('paper_id', None), "int", None)
        user_id, is_void = JTransformType.to(request_params.get('user_id', None), "int", None)
        user_uuid, is_void = JTransformType.to(request_params.get('user_uuid', None), "str", None)

        # 直接调用服务层
        data, error_text = ExamRecordService.list(paper_id=paper_id, user_id=user_id, user_uuid=user_uuid,
                                                  query_params=request_params, page=page, size=size, sort=sort)

        if not error_text:
            return util_response(data=data)
        return util_response(err=8506, msg=error_text)