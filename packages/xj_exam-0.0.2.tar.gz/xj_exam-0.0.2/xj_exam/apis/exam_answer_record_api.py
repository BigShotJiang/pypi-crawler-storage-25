# encoding: utf-8
"""
@project: exam_answer_record_api
@author:
@Email:
@synopsis: 答题记录API接口
@created_time: 2024
"""

from rest_framework.views import APIView
from ..services.exam_answer_record_service import ExamAnswerRecordService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper
from ..utils.j_transform_type import JTransformType


class ExamAnswerRecordAPI(APIView):
    """答题记录API：批量添加答题记录（一次提交一张试卷的所有答题）"""

    @request_params_wrapper
    def post(self, *args, request_params=None, **kwargs):
        """批量添加答题记录"""
        # ========== 参数类型验证 ==========
        if not isinstance(request_params, dict):
            return util_response(err=8501, msg="参数必须是字典格式。")

        # ========== 获取考试记录ID ==========
        exam_record_id, is_void = JTransformType.to(request_params.get('exam_record_id'), "int", None)
        if not exam_record_id:
            return util_response(err=8502, msg="考试记录ID(exam_record_id)必填且必须是整数。")

        # ========== 获取答题列表 ==========
        answer_list = request_params.get('list', [])
        if not isinstance(answer_list, list):
            return util_response(err=8503, msg="答题列表(list)必须是数组格式。")

        if not answer_list:
            return util_response(err=8504, msg="答题列表(list)不能为空。")

        # ========== 数量限制 ==========
        if len(answer_list) > 200:
            return util_response(err=8505, msg="单次批量添加不能超过200条答题记录。")

        # ========== 基础字段验证 ==========
        for index, answer_data in enumerate(answer_list):
            if not isinstance(answer_data, dict):
                return util_response(err=8506, msg=f"第 {index + 1} 条答案格式错误，必须是字典格式。")
            if not answer_data.get('question_id'):
                return util_response(err=8507, msg=f"第 {index + 1} 条答案缺少必填字段：question_id（题目ID）。")
            if not answer_data.get('question_option_id'):
                return util_response(err=8508, msg=f"第 {index + 1} 条答案缺少必填字段：question_option_id（选项ID）。")

        # ========== 调用服务层 ==========
        data, error_text = ExamAnswerRecordService.add(exam_record_id=exam_record_id, answer_list=answer_list)

        if not error_text:
            return util_response(data=data)

        # ========== 错误处理 ==========
        return util_response(err=8509, msg=error_text)

class ExamAnswerRecordListAPI(APIView):
    """答题记录列表API"""

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """获取答题记录列表"""
        exam_record_id = request_params.get('exam_record_id')
        question_id = request_params.get('question_id')
        query_params = request_params.get('query_params', {})
        page = request_params.get('page', 1)
        size = request_params.get('size', 20)
        sort = request_params.get('sort', '-id')

        data, error_text = ExamAnswerRecordService.list(exam_record_id=exam_record_id,query_params=query_params, page=page, size=size, sort=sort)

        if not error_text:
            return util_response(data=data)

        return util_response(err=8510, msg=error_text)