# encoding: utf-8
"""
@project: exam urls
@author:
@Email:
@synopsis: 考试模块路由分发
@created_time: 2026
"""

from django.urls import re_path

from .apis.exam_subject_api import ExamSubjectItemAPI, ExamSubjectListAPI
from .apis.exam_question_api import ExamQuestionItemAPI, ExamQuestionListAPI
from .apis.exam_paper_api import ExamPaperListAPI, ExamPaperItemAPI
from .apis.exam_answer_record_api import ExamAnswerRecordAPI, ExamAnswerRecordListAPI
from .apis.exam_record_api import ExamRecordListAPI, ExamRecordAPI

# 应用名称
# app_name = 'exam'

urlpatterns = [
    # ==================== 科目相关 ====================
    # 科目列表（查询、批量添加）
    re_path(r'^subject_list/?$', ExamSubjectListAPI.as_view(), name='科目列表'),
    # 科目单项操作（新增）
    re_path(r'^subject/?$', ExamSubjectItemAPI.as_view(), name='科目新增'),
    # 科目单项操作（详情、编辑、删除）
    re_path(r'^subject/(?P<pk>[\w\d]+)?/?$', ExamSubjectItemAPI.as_view(), name='科目详情'),

    # ==================== 题目相关 ====================
    # 题目列表（查询、批量添加、批量删除）
    re_path(r'^question_list/?$', ExamQuestionListAPI.as_view(), name='题目列表'),
    # 题目单项操作（新增）
    re_path(r'^question/?$', ExamQuestionItemAPI.as_view(), name='题目新增'),
    # 题目单项操作（详情、编辑、删除）
    re_path(r'^question/(?P<pk>\d+)?/?$', ExamQuestionItemAPI.as_view(), name='题目详情'),
    # 添加答题记录
    re_path(r'^answer_record/?$', ExamAnswerRecordAPI.as_view(), name='添加答题记录'),
    # 答题记录列表
    re_path(r'^answer_record_list/?$', ExamAnswerRecordListAPI.as_view(), name='答题记录列表'),

    # ==================== 试卷相关 ====================
    # 题目列表（查询、批量添加、批量删除）
    re_path(r'^paper_list/?$', ExamPaperListAPI.as_view(), name='题目列表'),
    # 试卷详情
    re_path(r'^paper/(?P<pk>\d+)/?$', ExamPaperItemAPI.as_view(), name='试卷详情'),

    # ==================== 考试记录相关 ====================
    # 考试记录列表
    re_path(r'^record_list/?$', ExamRecordListAPI.as_view(), name='考试记录列表'),
    # 考试记录新增
    re_path(r'^record/?$', ExamRecordAPI.as_view(), name='考试记录新增'),
]