# admin.py
from django.contrib import admin
from django import forms
from django.db import transaction
from .models import (ExamSubject, ExamQuestion, ExamQuestionOption, ExamPaper, ExamPaperSection, ExamPaperQuestion,
                     ExamRecord, ExamAnswerRecord)


@admin.register(ExamSubject)
class ExamSubjectAdmin(admin.ModelAdmin):
    """科目管理"""
    fields = ('id', 'name', 'description', 'create_time')
    list_display = ('id', 'name', 'description', 'create_time')
    list_display_links = ['id', 'name']
    search_fields = ('id', 'name', 'description')
    readonly_fields = ('id', 'create_time')
    ordering = ['-create_time']
    list_per_page = 20


@admin.register(ExamQuestion)
class ExamQuestionAdmin(admin.ModelAdmin):
    """题目管理"""

    class ExamQuestionOptionInline(admin.TabularInline):
        """题目选项内联编辑"""
        model = ExamQuestionOption
        fields = ['option', 'content', 'is_correct']
        extra = 0
        ordering = ['option']

    inlines = [ExamQuestionOptionInline]
    fieldsets = [
        ('基本信息', {'fields': ('id', 'subject', 'question', 'score')}),
        ('答案解析', {'fields': ('analysis',)}),
        ('时间信息', {'fields': ('column', 'create_time',)})
    ]
    list_display = ('id', 'subject', 'question_short', 'score', 'analysis_short', 'column', 'create_time')
    list_filter = ['subject', 'score', 'create_time']
    list_display_links = ['id', 'question_short']
    search_fields = ('id', 'question', 'analysis', 'subject__name')
    raw_id_fields = ['subject']
    readonly_fields = ('id', 'create_time')
    ordering = ['-create_time']
    list_per_page = 20

    def question_short(self, obj):
        """题目内容缩略显示"""
        return f"{obj.question[:50]}..." if len(obj.question) > 50 else obj.question

    question_short.short_description = '题目内容'

    def analysis_short(self, obj):
        """答案解析缩略显示"""
        return f"{obj.analysis[:30]}..." if len(obj.analysis) > 30 else obj.analysis

    analysis_short.short_description = '答案解析'


@admin.register(ExamQuestionOption)
class ExamQuestionOptionAdmin(admin.ModelAdmin):
    """题目选项管理"""
    fields = ('id', 'question_id', 'option', 'content', 'is_correct')
    list_display = ('id', 'question_link', 'option', 'content_short', 'is_correct')
    list_filter = ['is_correct', 'option']
    list_display_links = ['id', 'content_short', 'option']
    search_fields = ('id', 'option', 'content', 'question_id__question')
    raw_id_fields = ['question_id']
    readonly_fields = ('id',)
    ordering = ['question_id', 'option']
    list_per_page = 20

    def content_short(self, obj):
        """选项内容缩略显示"""
        return f"{obj.content[:50]}..." if len(obj.content) > 50 else obj.content

    content_short.short_description = '选项内容'

    def question_link(self, obj):
        """生成可点击的题目链接，跳转到题目编辑页"""
        from django.utils.html import format_html
        from django.urls import reverse
        url = reverse('admin:xj_exam_examquestion_change', args=[obj.question_id.id])
        return format_html('<a href="{}">{}</a>', url, obj.question_id.question[:50] + '...')

    question_link.short_description = '所属题目'
    question_link.admin_order_field = 'question_id'


@admin.register(ExamPaperSection)
class ExamPaperSectionAdmin(admin.ModelAdmin):
    """试卷专项管理"""

    class ExamPaperSectionForm(forms.ModelForm):
        """自定义表单：添加批量选择题目功能"""
        select_questions = forms.ModelMultipleChoiceField(queryset=ExamQuestion.objects.all().select_related('subject'), required=False, widget=admin.widgets.FilteredSelectMultiple(
                verbose_name='题目', is_stacked=False), label='批量选择题目',
                help_text='使用左右箭头批量添加/移除题目，题目将按选择顺序排序')

        class Meta:
            model = ExamPaperSection
            fields = ['exam_paper', 'title', 'description', 'sort']

        def __init__(self, *args, **kwargs):
            """初始化表单：编辑时回显已选题目"""
            super().__init__(*args, **kwargs)
            if self.instance.pk:
                # 编辑模式：加载当前专项已关联的题目，按题号排序
                self.fields['select_questions'].initial = ExamQuestion.objects.filter(
                    exampaperquestion__section=self.instance).order_by('exampaperquestion__number')
            # 自定义下拉选项显示格式：[科目] 题目内容... (分值:X)
            self.fields['select_questions'].label_from_instance = lambda \
                obj: f"[{obj.subject.name}] {obj.question[:60]}... (分值:{obj.score})"

        @transaction.atomic
        def save(self, commit=True):
            instance = super().save(commit=commit)
            if instance.pk and instance.exam_paper_id:
                selected_questions = self.cleaned_data.get('select_questions', [])
                selected_ids = set(q.pk for q in selected_questions)
                existing_ids = set(
                    ExamPaperQuestion.objects.filter(section=instance).values_list('exam_question_id', flat=True))

                to_delete = existing_ids - selected_ids
                if to_delete:
                    # 报错Please correct the errors below.
                    ExamPaperQuestion.objects.filter(section=instance, exam_question_id__in=to_delete).delete()

                to_add = selected_ids - existing_ids
                if to_add:
                    ExamPaperQuestion.objects.bulk_create(
                        [ExamPaperQuestion(exam_paper_id=instance.exam_paper_id,
                        section_id=instance.pk, exam_question_id=q.pk, number=0)
                         for q in selected_questions if q.pk in to_add]
                    )
            return instance

    form = ExamPaperSectionForm

    class ExamPaperQuestionInline(admin.TabularInline):
        """题目内联编辑：用于微调题目顺序"""
        model = ExamPaperQuestion
        fields = ['exam_question', 'number']
        raw_id_fields = ['exam_question']
        extra = 0
        ordering = ['number']
        verbose_name = '题目'
        verbose_name_plural = '题目列表（可微调排序）'

    inlines = [ExamPaperQuestionInline]
    fieldsets = [
        ('基本信息', {'fields': ('id', 'exam_paper', 'title', 'description', 'sort')}),
        ('批量题目管理', {'fields': ('select_questions',),
                          'description': '✅ 使用双列选择器批量添加/移除题目，题目将按选择顺序自动排序（1, 2, 3...）'}),
        ('时间信息', {'fields': ('create_time',)})
    ]
    list_display = ('id', 'exam_paper', 'title', 'description_short', 'sort', 'question_count', 'create_time')
    list_filter = ['exam_paper', 'create_time']
    list_display_links = ['id', 'title']
    search_fields = ('id', 'title', 'description', 'exam_paper__title')
    raw_id_fields = ['exam_paper']
    readonly_fields = ('id', 'create_time')
    ordering = ['exam_paper', 'sort']
    list_per_page = 20

    def description_short(self, obj):
        """专项描述缩略显示"""
        return f"{obj.description[:30]}..." if obj.description and len(obj.description) > 30 else (
                    obj.description or '-')

    description_short.short_description = '专项描述'

    def question_count(self, obj):
        """统计专项下的题目数量"""
        return obj.exampaperquestion_set.count()

    question_count.short_description = '题目数量'

    class Media:
        """加载双列选择器所需的 CSS 和 JS"""
        css = {'all': ('admin/css/widgets.css',)}
        js = ['admin/js/core.js', 'admin/js/SelectBox.js', 'admin/js/SelectFilter2.js']


@admin.register(ExamPaper)
class ExamPaperAdmin(admin.ModelAdmin):
    """试卷管理"""

    class ExamPaperForm(forms.ModelForm):
        """自定义表单：添加批量选择题目功能（无专项模式）"""
        select_questions = forms.ModelMultipleChoiceField(queryset=ExamQuestion.objects.all().select_related('subject'),
                                                          required=False, widget=admin.widgets.FilteredSelectMultiple(
                verbose_name='题目', is_stacked=False), label='批量选择题目',
                                                          help_text='直接批量添加题目到试卷（不使用专项）')

        class Meta:
            model = ExamPaper
            fields = ['title', 'subject', 'duration', 'total_score', 'pass_score']

        def __init__(self, *args, **kwargs):
            """初始化表单：编辑时回显已选题目"""
            super().__init__(*args, **kwargs)
            if self.instance.pk:
                # 编辑模式：加载试卷已关联的所有题目
                self.fields['select_questions'].initial = self.instance.questions.all()
            # 自定义下拉选项显示格式：[科目] 题目内容... (分值:X)
            self.fields['select_questions'].label_from_instance = lambda \
                obj: f"[{obj.subject.name}] {obj.question[:60]}... (分值:{obj.score})"

        @transaction.atomic
        def save(self, commit=True):
            """保存试卷及关联题目（无专项模式）"""
            # 先保存试卷基本信息
            instance = super().save(commit=True)  # 强制提交以获取 instance.pk

            # 仅在试卷已保存（有 pk）时处理题目关联
            if instance.pk:
                # 获取用户选择的题目列表
                selected_questions = self.cleaned_data.get('select_questions', [])

                # 删除试卷下所有无专项的题目关联
                ExamPaperQuestion.objects.filter(exam_paper=instance, section__isnull=True).delete()

                # 批量创建新的题目关联（使用 _id 字段避免触发外键查询）
                ExamPaperQuestion.objects.bulk_create([
                    ExamPaperQuestion(
                        exam_paper_id=instance.pk,  # 使用 _id 字段避免外键验证
                        section_id=None,  # 无专项模式
                        exam_question_id=q.pk,
                        number=idx + 1  # 按选择顺序自动编号
                    ) for idx, q in enumerate(selected_questions)
                ])

            return instance

    form = ExamPaperForm

    class ExamPaperSectionInline(admin.TabularInline):
        """专项内联显示：点击标题跳转到专项编辑页"""
        model = ExamPaperSection
        fields = ['title', 'description', 'sort']
        extra = 0
        ordering = ['sort']
        verbose_name = '专项'
        verbose_name_plural = '专项列表（点击专项标题管理题目）'
        show_change_link = True  # 显示跳转链接

    class ExamPaperQuestionInline(admin.TabularInline):
        """题目内联编辑：仅显示无专项的题目"""
        model = ExamPaperQuestion
        fields = ['exam_question', 'number']
        raw_id_fields = ['exam_question']
        extra = 0
        ordering = ['number']
        verbose_name = '题目'
        verbose_name_plural = '题目列表（无专项）'

        def get_queryset(self, request):
            """过滤：仅显示无专项的题目"""
            qs = super().get_queryset(request)
            return qs.filter(section__isnull=True)

    inlines = [ExamPaperQuestionInline, ExamPaperSectionInline]
    fieldsets = [
        ('基本信息', {'fields': ('id', 'title', 'subject')}),
        ('考试设置', {'fields': (('duration', 'total_score', 'pass_score'),)}),
        ('批量添加题目（无专项）',
         {'fields': ('select_questions',), 'description': '✅ 直接批量添加题目到试卷，不使用专项分类',
          'classes': ['collapse']}),
        ('时间信息', {'fields': ('create_time',)})
    ]
    list_display = (
    'id', 'title', 'subject', 'duration', 'total_score', 'pass_score', 'section_count', 'question_count', 'create_time')
    list_filter = ['subject', 'create_time']
    list_display_links = ['id', 'title']
    search_fields = ('id', 'title', 'subject__name')
    raw_id_fields = ['subject']
    readonly_fields = ('id', 'create_time')
    ordering = ['-create_time']
    list_per_page = 20

    def section_count(self, obj):
        """统计试卷的专项数量"""
        return obj.sections.count()

    section_count.short_description = '专项数量'

    def question_count(self, obj):
        """统计试卷的题目总数"""
        return obj.questions.count()

    question_count.short_description = '题目数量'

    class Media:
        """加载双列选择器所需的 CSS 和 JS"""
        css = {'all': ('admin/css/widgets.css',)}
        js = ['admin/js/core.js', 'admin/js/SelectBox.js', 'admin/js/SelectFilter2.js']


@admin.register(ExamPaperQuestion)
class ExamPaperQuestionAdmin(admin.ModelAdmin):
    """试卷题目关联管理（底层数据）"""
    fields = ('id', 'exam_paper', 'section', 'exam_question', 'number')
    list_display = ('id', 'exam_paper_safe', 'section_safe', 'exam_question_safe', 'number')
    list_filter = ['exam_paper', 'section']
    list_display_links = ['id']
    search_fields = ('id', 'exam_paper__title', 'section__title', 'exam_question__question')
    raw_id_fields = ['exam_paper', 'section', 'exam_question']
    readonly_fields = ('id',)
    ordering = ['exam_paper', 'number']
    list_per_page = 20

    def exam_paper_safe(self, obj):
        """安全显示试卷（防止逻辑外键失效）"""
        try:
            return obj.exam_paper.title if obj.exam_paper_id else '-'
        except:
            return f'试卷#{obj.exam_paper_id}(已删除)'

    exam_paper_safe.short_description = '试卷'

    def section_safe(self, obj):
        """安全显示专项（防止逻辑外键失效）"""
        try:
            return obj.section.title if obj.section_id else '-'
        except:
            return f'专项#{obj.section_id}(已删除)'

    section_safe.short_description = '专项'

    def exam_question_safe(self, obj):
        """安全显示题目（防止逻辑外键失效）"""
        try:
            return f"{obj.exam_question.question[:40]}..." if obj.exam_question_id else '-'
        except:
            return f'题目#{obj.exam_question_id}(已删除)'

    exam_question_safe.short_description = '题目'


@admin.register(ExamRecord)
class ExamRecordAdmin(admin.ModelAdmin):
    """考试记录管理"""

    class ExamAnswerRecordInline(admin.TabularInline):
        """答题记录内联显示（只读）"""
        model = ExamAnswerRecord
        fields = ['question', 'question_option', 'is_correct', 'score']
        readonly_fields = ['question', 'question_option', 'is_correct', 'score']
        extra = 0
        can_delete = False

    inlines = [ExamAnswerRecordInline]
    fieldsets = [
        ('考试信息', {'fields': ('id', 'paper', ('user_id', 'user_uuid'))}),
        ('考试状态', {'fields': ('status', 'score', 'is_passed')}),
        ('时间信息', {'fields': (('start_time', 'submit_time'),)})
    ]
    list_display = ('id', 'paper', 'user_id', 'user_uuid', 'status', 'score', 'is_passed', 'start_time', 'submit_time',
                    'duration_display')
    list_filter = ['paper', 'status', 'is_passed', 'start_time']
    list_display_links = ['id']
    search_fields = ('id', 'user_id', 'user_uuid', 'paper__title')
    raw_id_fields = ['paper']
    readonly_fields = ('id', 'start_time')
    ordering = ['-start_time']
    list_per_page = 20

    def duration_display(self, obj):
        """计算并显示答题时长（分钟）"""
        if obj.submit_time and obj.start_time:
            duration = obj.submit_time - obj.start_time
            minutes = int(duration.total_seconds() / 60)
            return f"{minutes}分钟"
        return "-"

    duration_display.short_description = '答题时长'


@admin.register(ExamAnswerRecord)
class ExamAnswerRecordAdmin(admin.ModelAdmin):
    """答题记录管理"""
    fields = ('id', 'exam_record', 'question', 'question_option', 'is_correct', 'score')
    list_display = ('id', 'exam_record', 'question_short', 'question_option', 'is_correct', 'score')
    list_filter = ['is_correct', 'exam_record__paper']
    list_display_links = ['id']
    search_fields = ('id', 'exam_record__user_id', 'exam_record__user_uuid', 'question__question')
    raw_id_fields = ['exam_record', 'question', 'question_option']
    readonly_fields = ('id',)
    ordering = ['exam_record', 'question']
    list_per_page = 20

    def question_short(self, obj):
        """题目内容缩略显示"""
        return f"{obj.question.question[:40]}..." if len(obj.question.question) > 40 else obj.question.question

    question_short.short_description = '题目'