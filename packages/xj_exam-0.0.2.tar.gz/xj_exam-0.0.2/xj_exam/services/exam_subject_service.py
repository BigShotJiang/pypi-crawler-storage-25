# encoding: utf-8
"""
@project: exam_subject_service
@author:
@Email:
@synopsis: 考试科目服务层
@created_time: 2024
"""

from django.db.models import Q, Count, F
from django.core.paginator import Paginator, EmptyPage
from ..models import ExamSubject
from ..utils.j_transform_type import JTransformType
from ..utils.j_parameter import JParameter


class ExamSubjectService:
    """
    考试科目服务类：提供科目的增删改查服务
    """

    # 查询字段说明
    __support_queries = {
        "id": "科目ID",
        "id_list": "科目ID列表",
        "name": "科目名称（模糊查询）",
        "description": "科目描述（模糊查询）",
        "search": "搜索关键词（科目名称或描述）",
        "create_time_start|date": "创建开始时间",
        "create_time_end|date": "创建结束时间",
        "page": "页号，默认第1页",
        "size": "每页行数，默认20行",
        "sort": "排序字段，默认 -create_time",
        "filter_fields": "返回字段筛选",
    }

    # 所有字段
    all_fields = [
        "id",
        "name",
        "description",
        "create_time",
    ]

    # 添加字段
    add_fields = [
        "name",
        "description",
    ]

    # 编辑字段
    edit_fields = [
        "name",
        "description",
    ]

    # 格式化字段
    format_fields = [
        "id|int",
        "name|str",
        "description|str",
        "create_time|date",
    ]

    # 搜索条件映射
    __condition_alias = {
        "id_list": "id__in",
        "name": "name__icontains",
        "description": "description__icontains",
        "create_time_start": "create_time__gte",
        "create_time_end": "create_time__lte",
    }

    # 默认字段类型
    filter_filed_list = [
        "id|int",
        "id_list|list",
        "name|str",
        "description|str",
        "create_time_start|date",
        "create_time_end|date",
    ]

    @staticmethod
    def add(params: dict = None, **kwargs):
        """
        添加科目
        :param params: 添加参数字典
        :param kwargs: 额外参数
        :return: (科目数据字典, 错误信息)
        """
        # 参数整合与空值验证
        whole, is_void = JTransformType.to(params, "dict", {})
        args, is_void = JTransformType.to(kwargs, "dict", {})
        whole.update(args)

        # 必填字段验证
        name = whole.get("name")
        if not name:
            return None, "科目名称(name)必填。"

        # 检查科目名称是否已存在
        exist_subject = ExamSubject.objects.filter(name=name).first()
        if exist_subject:
            return None, f"科目名称({name})已存在。"

        # 参数格式化
        query_params = JParameter.format(whole, filter_fields=ExamSubjectService.format_fields)
        query_params = {k: v for k, v in query_params.items() if k in ExamSubjectService.add_fields}

        try:
            # 创建科目
            subject_set = ExamSubject.objects.create(**query_params)

            # 返回结果
            result = {
                "id": subject_set.id,
                "name": subject_set.name,
                "description": subject_set.description,
                "create_time": subject_set.create_time.strftime(
                    "%Y-%m-%d %H:%M:%S") if subject_set.create_time else None,
            }
            return result, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def item(pk: int = None, name: str = None):
        """
        获取科目详情
        :param pk: 科目ID
        :param name: 科目名称
        :return: (科目数据字典, 错误信息)
        """
        if pk is None and name is None:
            return None, "缺少科目ID(id)或科目名称(name)字段。"

        # 构建查询条件
        query_filter = Q()
        if pk:
            query_filter &= Q(id=pk)
        if name:
            query_filter &= Q(name=name)

        try:
            # 查询科目
            subject_set = ExamSubject.objects.filter(query_filter)

            # 统计关联数据
            subject_item = subject_set.annotate(
                question_count=Count('questions', distinct=True),
                paper_count=Count('exams', distinct=True),
            ).extra(
                select={
                    # ✅ 使用表名前缀明确指定字段
                    "create_time": 'DATE_FORMAT(exam_subject.create_time, "%%Y-%%m-%%d %%H:%%i:%%s")',
                }
            ).values(
                *ExamSubjectService.all_fields,
                'question_count',
                'paper_count'
            ).first()

            if not subject_item:
                return None, f"科目不存在，ID：{pk}，名称：{name}。"

            return subject_item, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def edit(pk: int = None, params: dict = None):
        """
        编辑科目
        :param pk: 科目ID
        :param params: 编辑参数字典
        :return: (科目数据字典, 错误信息)
        """
        if pk is None:
            return None, "缺少科目ID(id)字段。"

        # 参数转换校验
        params, error = JTransformType.to(params, "dict", {})
        if error:
            return None, error

        try:
            # 检查科目是否存在
            exist_set = ExamSubject.objects.filter(id=pk).first()
            if not exist_set:
                return None, f"科目(ID:{pk})不存在，无法进行修改。"

            # 检查科目名称是否重复（排除自身）
            name = params.get("name")
            if name and name != exist_set.name:
                duplicate_subject = ExamSubject.objects.filter(name=name).exclude(id=pk).first()
                if duplicate_subject:
                    return None, f"科目名称({name})已存在。"

            # 主表修改
            main_params = {k: v for k, v in params.items() if k in ExamSubjectService.edit_fields}
            main_params = JParameter.format(main_params, filter_fields=ExamSubjectService.format_fields,
                                            is_remove_null=True)

            # 更新字段
            for k, v in main_params.items():
                setattr(exist_set, k, v)
            exist_set.save()

            # 返回结果
            result = {
                "id": exist_set.id,
                "name": exist_set.name,
                "description": exist_set.description,
                "create_time": exist_set.create_time.strftime("%Y-%m-%d %H:%M:%S") if exist_set.create_time else None,
            }
            return result, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def delete(pk: int = None):
        """
        删除科目（硬删除）
        :param pk: 科目ID
        :return: (None, 错误信息)
        """
        if not pk:
            return None, "缺少科目ID(id)字段。"

        try:
            # 检查科目是否存在
            subject_set = ExamSubject.objects.filter(id=pk).first()
            if not subject_set:
                return None, f"科目(ID:{pk})不存在，无法进行删除。"

            # 检查是否有关联数据
            question_count = subject_set.questions.count()
            paper_count = subject_set.exams.count()

            if question_count > 0 or paper_count > 0:
                return None, f"该科目下存在 {question_count} 个题目和 {paper_count} 个试卷，无法删除。"

            # 执行删除
            subject_set.delete()
            return None, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def list(
            id_list: list = None,
            query_params: dict = None,
            page: int = 1,
            size: int = 20,
            sort: str = "-create_time",
    ):
        """
        获取科目列表
        :param id_list: 科目ID列表（如果提供，则只查询指定ID的科目）
        :param query_params: 筛选条件字典
        :param page: 页码，默认1
        :param size: 每页数量，默认20
        :param sort: 排序字段，默认 -create_time
        :return: (列表数据, 错误信息)

        @description
        [2024.12.10] 参考 thread_list_service_v2.py 重构
        - 支持分页查询
        - 支持多条件筛选
        - 支持字段过滤
        - 支持排序
        - 记录SQL查询
        """

        # ========== 参数类型处理 ==========
        # 参数转换
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort, is_void = JTransformType.to(sort, "str", "-create_time")

        # 参数验证
        if page < 1:
            page = 1
        if size < 1 or size > 100:
            size = 20

        # 检查排序有效性
        sort_choices = [
            "id", "-id",
            "name", "-name",
            "create_time", "-create_time",
        ]
        if sort not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        try:
            # ==================== 准备执行查询列表 start ====================
            # 声明查询集
            subject_set = ExamSubject.objects

            # 排序条件
            subject_set = subject_set.order_by(sort)

            # 如果提供了ID列表，则只查询指定ID
            if id_list and len(id_list) > 0:
                subject_set = subject_set.filter(id__in=id_list)

            # 格式化日期
            subject_set = subject_set.extra(
                select={
                    # ✅ 使用表名前缀明确指定字段
                    "create_time": 'DATE_FORMAT(exam_subject.create_time, "%%Y-%%m-%%d %%H:%%i:%%s")',
                }
            )

            # 新增统计字段
            subject_set = subject_set.annotate(
                question_count=Count('questions', distinct=True),
                paper_count=Count('exams', distinct=True),
            )

            # ========== 设置查询条件 ==========
            # 处理搜索关键词（特殊处理）
            search = query_params.pop("search", None)
            if search:
                search, is_void = JTransformType.to(search, "str")
                if search:
                    subject_set = subject_set.filter(
                        Q(name__icontains=search) | Q(description__icontains=search)
                    )

            # 处理其他查询条件
            from ..utils.custom_tool import format_params_handle
            conditions = format_params_handle(
                param_dict=query_params,
                filter_filed_list=ExamSubjectService.filter_filed_list,
                alias_dict=ExamSubjectService.__condition_alias,
                split_list=["id_list"],
                is_remove_empty=True,
            )

            # 添加搜索条件
            if conditions:
                subject_set = subject_set.filter(**conditions)

            # 记录查询语句
            subject_query = subject_set.query
            # ==================== 准备执行查询列表 end ====================

            # ========== 执行分页查询 ==========
            # 用分页器分页
            paginator = Paginator(subject_set, per_page=size)

            # 正式请求数据
            total = paginator.count

            # 页号溢出返回空列表
            if page > paginator.num_pages and paginator.num_pages > 0:
                return {
                    "page": page,
                    "size": size,
                    "total": total,
                    "list": [],
                    "query": str(subject_query),
                }, None

            # 获取当前页数据
            paginator_set = paginator.page(page) if total > 0 else []

            # ========== 导出分页结果 ==========
            if total > 0:
                # 返回 QuerySet 列表
                main_set = paginator_set.object_list

                # 获取结果数据
                main_list = list(main_set.values(
                    *ExamSubjectService.all_fields,
                    'question_count',
                    'paper_count'
                ))
            else:
                main_list = []

            # 返回结果
            result = {
                "page": int(page),
                "size": int(size),
                "total": total,
                "list": main_list,
                "query": str(subject_query),
            }

            return result, None

        except EmptyPage:
            return {
                "page": page,
                "size": size,
                "total": 0,
                "list": [],
                "query": "",
            }, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def search(id_list: list = None):
        """
        按照ID搜索科目（简化版）
        :param id_list: 科目ID列表
        :return: (科目列表, 错误信息)
        """
        id_list, is_void = JTransformType.to(id_list, "list", [])
        if not id_list:
            return [], None

        try:
            subject_set = ExamSubject.objects.filter(id__in=id_list)
            subject_set = subject_set.extra(
                select={
                    "create_time": 'DATE_FORMAT(exam_subject.create_time, "%%Y-%%m-%%d %%H:%%i:%%s")',
                }
            )
            subject_list = list(subject_set.values(*ExamSubjectService.all_fields))
            return subject_list, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def search_ids(search_params: dict = None):
        """
        根据搜索条件查询科目ID列表
        :param search_params: 搜索参数
        :return: (ID列表, 错误信息)
        """
        search_params, is_void = JTransformType.to(search_params, "dict", {})
        if not search_params:
            return [], None

        try:
            from ..utils.custom_tool import format_params_handle

            # 格式化查询条件
            conditions = format_params_handle(
                param_dict=search_params,
                filter_filed_list=ExamSubjectService.filter_filed_list,
                alias_dict=ExamSubjectService.__condition_alias,
                is_remove_empty=True,
            )

            if not conditions:
                return [], None

            # 查询ID列表
            subject_set = ExamSubject.objects.filter(**conditions)
            subject_id_list = list(subject_set.values_list('id', flat=True))

            return subject_id_list, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""