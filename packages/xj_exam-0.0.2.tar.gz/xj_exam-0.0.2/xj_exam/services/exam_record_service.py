# encoding: utf-8
"""
@project: exam_record_service
@author:
@Email:
@synopsis: 考试记录服务层
@created_time: 2026
"""

from django.db.models import Q, Count, F
from django.core.paginator import Paginator, EmptyPage

from ..models import ExamRecord
from ..models import ExamPaper

from ..utils.j_transform_type import JTransformType


class ExamRecordService:
    """
    考试记录服务类：提供考试记录查询服务
    """

    # 所有字段
    all_fields = [
        "id",
        "paper_id",
        "user_id",
        "user_uuid",
        "status",
        "score",
        "is_passed",
        "start_time",
        "submit_time",
    ]

    # 搜索条件映射
    __condition_alias = {
        "id_list": "id__in",
        "paper_id_list": "paper_id__in",
        "user_id_list": "user_id__in",
        "user_uuid_list": "user_uuid__in",
        "status_list": "status__in",
        "score_min": "score__gte",
        "score_max": "score__lte",
        "is_passed": "is_passed",
        "start_time_start": "start_time__gte",
        "start_time_end": "start_time__lte",
        "submit_time_start": "submit_time__gte",
        "submit_time_end": "submit_time__lte",
    }

    # 默认字段类型
    filter_filed_list = [
        "id|int",
        "id_list|list",
        "paper_id|int",
        "paper_id_list|list",
        "user_id|int",
        "user_id_list|list",
        "user_uuid|str",
        "user_uuid_list|list",
        "status|str",
        "status_list|list",
        "score|float",
        "score_min|float",
        "score_max|float",
        "is_passed|bool",
        "start_time_start|datetime",
        "start_time_end|datetime",
        "submit_time_start|datetime",
        "submit_time_end|datetime",
    ]

    @staticmethod
    def add(user_uuid: str = None, user_id: int = None, paper_id: int = None, params: dict = None):
        """
        添加考试记录
        :param user_uuid: 用户UUID
        :param user_id: 用户ID
        :param paper_id: 试卷ID
        :param params: 其他参数
        :return: (记录数据, 错误信息)
        """

        # 参数验证
        if not user_uuid and not user_id:
            return None, "用户UUID或用户ID至少提供一个"

        if not paper_id:
            paper_id = params.get('paper_id') if params else None
            if not paper_id:
                return None, "试卷ID(paper_id)必填"

        # 参数类型转换
        paper_id, is_void = JTransformType.to(paper_id, "int", None)
        if not paper_id:
            return None, "试卷ID格式错误"

        # 验证试卷是否存在
        paper_set = ExamPaper.objects.filter(id=paper_id).first()
        if not paper_set:
            return None, f"试卷不存在，ID：{paper_id}"

        # 参数整合
        params, is_void = JTransformType.to(params, "dict", {})

        # 允许添加的字段
        add_fields = ["status", "score", "is_passed", "submit_time"]

        # 过滤参数
        from ..utils.custom_tool import format_params_handle
        add_params = format_params_handle(param_dict=params,filter_filed_list=add_fields,is_remove_null=True)

        try:
            # 创建考试记录
            record_set = ExamRecord.objects.create(paper_id=paper_id, user_id=user_id, user_uuid=user_uuid, **add_params)

            # 返回创建的记录
            return record_set.to_json(), None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def list(id_list: list = None, paper_id: int = None, user_id: int = None, user_uuid: str = None, query_params: dict = None, page: int = 1, size: int = 20, sort: str = "-start_time"):
        """
        获取考试记录列表
        :param id_list: 记录ID列表
        :param paper_id: 试卷ID
        :param user_id: 用户ID
        :param user_uuid: 用户UUID
        :param query_params: 筛选条件字典
        :param page: 页码，默认1
        :param size: 每页数量，默认20
        :param sort: 排序字段，默认 -start_time
        :return: (列表数据, 错误信息)
        """
        # ========== 参数类型处理 ==========
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-start_time")

        # 参数验证
        if page < 1:
            page = 1
        if size < 1 or size > 100:
            size = 20

        # 排序字段验证
        sort_choices = [
            "id", "-id",
            "paper_id", "-paper_id",
            "user_id", "-user_id",
            "status", "-status",
            "score", "-score",
            "is_passed", "-is_passed",
            "start_time", "-start_time",
            "submit_time", "-submit_time"
        ]

        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        try:
            # ========== 构建基础查询 ==========
            record_set = ExamRecord.objects.select_related('paper', 'paper__subject').order_by(sort_param)

            # 如果提供了ID列表，则只查询指定ID
            if id_list and len(id_list) > 0:
                record_set = record_set.filter(id__in=id_list)

            # 如果提供了试卷ID，则只查询该试卷
            if paper_id:
                record_set = record_set.filter(paper_id=paper_id)

            # 如果提供了用户ID，则只查询该用户
            if user_id:
                record_set = record_set.filter(user_id=user_id)

            # 如果提供了用户UUID，则只查询该用户
            if user_uuid:
                record_set = record_set.filter(user_uuid=user_uuid)

            # 格式化日期和关联数据
            record_set = record_set.extra(
                select={
                    "start_time": 'DATE_FORMAT(exam_record.start_time, "%%Y-%%m-%%d %%H:%%i:%%s")',
                    "submit_time": 'DATE_FORMAT(exam_record.submit_time, "%%Y-%%m-%%d %%H:%%i:%%s")',
                }
            ).annotate(
                paper_title=F('paper__title'),
                paper_total_score=F('paper__total_score'),
                paper_pass_score=F('paper__pass_score'),
                subject_id=F('paper__subject_id'),
                subject_name=F('paper__subject__name'),
                answer_count=Count('answers', distinct=True)
            )

            # ========== 处理查询条件 ==========
            search = query_params.pop("search", None)
            if search:
                search, is_void = JTransformType.to(search, "str")
                if search:
                    # 搜索试卷标题或用户ID
                    record_set = record_set.filter(
                        Q(paper__title__icontains=search) |
                        Q(user_id__icontains=search) |
                        Q(user_uuid__icontains=search)
                    )

            # 处理其他筛选条件
            from ..utils.custom_tool import format_params_handle
            conditions = format_params_handle(
                param_dict=query_params,
                filter_filed_list=ExamRecordService.filter_filed_list,
                alias_dict=ExamRecordService.__condition_alias,
                split_list=["id_list", "paper_id_list", "user_id_list", "user_uuid_list", "status_list"],
                is_remove_empty=True
            )

            if conditions:
                record_set = record_set.filter(**conditions)

            # 记录查询SQL
            record_query = record_set.query

            # ========== 执行分页查询 ==========
            paginator = Paginator(record_set, per_page=size)
            total = paginator.count

            # 页号溢出返回空列表
            if page > paginator.num_pages and paginator.num_pages > 0:
                result = {
                    "page": page,
                    "size": size,
                    "total": total,
                    "list": [],
                    "query": str(record_query)
                }
                return result, None

            # 获取当前页数据
            paginator_set = paginator.page(page) if total > 0 else []

            # ========== 导出分页结果 ==========
            if total > 0:
                main_set = paginator_set.object_list

                # 获取考试记录基本信息
                main_list = list(main_set.values(*ExamRecordService.all_fields, 'paper_title', 'paper_total_score', 'paper_pass_score', 'subject_id', 'subject_name', 'answer_count'))
            else:
                main_list = []

            # 返回结果
            result = {
                "page": int(page),
                "size": int(size),
                "total": total,
                "list": main_list,
                "query": str(record_query)
            }

            return result, None

        except EmptyPage:
            result = {
                "page": page,
                "size": size,
                "total": 0,
                "list": [],
                "query": ""
            }
            return result, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""