# encoding: utf-8
"""
@project: exam_paper_service
@author:
@Email:
@synopsis: 试卷服务层
@created_time: 2026
"""

from django.db.models import Q, Count, F
from django.core.paginator import Paginator, EmptyPage

from ..models import ExamPaper, ExamPaperQuestion, ExamPaperSection
from ..utils.j_transform_type import JTransformType


class ExamPaperService:
    """
    试卷服务类：提供试卷查询服务
    """

    # 所有字段
    all_fields = [
        "id",
        "title",
        "subject_id",
        "duration",
        "total_score",
        "pass_score",
        "create_time",
    ]

    # 搜索条件映射
    __condition_alias = {
        "id_list": "id__in",
        "subject_id_list": "subject_id__in",
        "title": "title__icontains",
        "duration_min": "duration__gte",
        "duration_max": "duration__lte",
        "total_score_min": "total_score__gte",
        "total_score_max": "total_score__lte",
        "pass_score_min": "pass_score__gte",
        "pass_score_max": "pass_score__lte",
        "create_time_start": "create_time__gte",
        "create_time_end": "create_time__lte",
    }

    # 默认字段类型
    filter_filed_list = [
        "id|int",
        "id_list|list",
        "title|str",
        "subject_id|int",
        "subject_id_list|list",
        "duration|int",
        "duration_min|int",
        "duration_max|int",
        "total_score|int",
        "total_score_min|int",
        "total_score_max|int",
        "pass_score|int",
        "pass_score_min|int",
        "pass_score_max|int",
        "create_time_start|date",
        "create_time_end|date",
    ]

    @staticmethod
    def item(pk: int = None):
        """
        获取试卷详情

        :param pk: 试卷ID
        :return: (试卷数据字典, 错误信息)

        @description
        获取单个试卷的详细信息，包括题目总数、专项信息及每个专项的题目数量

        @example
        data, error = ExamPaperService.item(pk=1)

        @return_format
        {
            "id": 1,
            "title": "期末考试",
            "subject_id": 1,
            "subject_name": "数学",
            "duration": 120,
            "total_score": 100,
            "pass_score": 60,
            "create_time": "2024-01-15 10:00:00",
            "question_count": 50,  # 题目总数
            "section_count": 3,    # 专项总数
            "sections": [
                {
                    "id": 1,
                    "title": "单选题",
                    "description": "每题5分",
                    "sort": 1,
                    "create_time": "2024-01-15 10:00:00",
                    "question_count": 20
                },
                ...
            ]
        }
        """
        if pk is None:
            return None, "缺少试卷ID(id)字段。"

        try:
            # 查询试卷基本信息
            paper_set = ExamPaper.objects.filter(id=pk)

            # 统计关联数据
            paper_item = paper_set.annotate(
                subject_name=F("subject__name"),
                question_count=Count('exampaperquestion', distinct=True),
                section_count=Count('sections', distinct=True)
            ).extra(
                select={
                    "create_time": 'DATE_FORMAT(exam_paper.create_time, "%%Y-%%m-%%d %%H:%%i:%%s")',
                }
            ).values(*ExamPaperService.all_fields,'subject_name','question_count','section_count').first()

            if not paper_item:
                return None, f"试卷不存在，ID：{pk}。"

            # 查询专项信息
            sections_query = ExamPaperSection.objects.filter(
                exam_paper_id=pk
            ).order_by('sort').values(
                'id',
                'title',
                'description',
                'sort',
                'create_time'
            )

            # 格式化专项的创建时间
            sections_list = []
            for section in sections_query:
                section_item = dict(section)
                if section_item.get('create_time'):
                    section_item['create_time'] = section_item['create_time'].strftime("%Y-%m-%d %H:%M:%S")
                sections_list.append(section_item)

            # 统计每个专项的题目数量
            if sections_list:
                section_ids = [s['id'] for s in sections_list]

                # 统计每个专项的题目数量
                question_counts = ExamPaperQuestion.objects.filter(
                    section_id__in=section_ids
                ).values('section_id').annotate(count=Count('id'))

                question_count_map = {item['section_id']: item['count'] for item in question_counts}

                # 添加题目数量到每个专项
                for section_item in sections_list:
                    section_item['question_count'] = question_count_map.get(section_item['id'], 0)

            # 添加专项列表到试卷信息
            paper_item['sections'] = sections_list

            return paper_item, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def list(id_list: list = None, subject_id: int = None, query_params: dict = None,
             page: int = 1, size: int = 20, sort: str = "-create_time",
             with_sections: bool = False, with_questions: bool = False):
        """
        获取试卷列表

        :param id_list: 试卷ID列表
        :param subject_id: 科目ID
        :param query_params: 筛选条件字典
        :param page: 页码，默认1
        :param size: 每页数量，默认20
        :param sort: 排序字段，默认 -create_time
        :param with_sections: 是否包含专项信息，默认False
        :param with_questions: 是否包含题目统计信息，默认False
        :return: (列表数据, 错误信息)
        """
        # ========== 参数类型处理 ==========
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-create_time")
        with_sections, is_void = JTransformType.to(with_sections, "bool", False)
        with_questions, is_void = JTransformType.to(with_questions, "bool", False)

        # 参数验证
        if page < 1:
            page = 1
        if size < 1 or size > 200:
            size = 20

        # 排序字段验证
        sort_choices = [
            "id", "-id",
            "title", "-title",
            "subject_id", "-subject_id",
            "duration", "-duration",
            "total_score", "-total_score",
            "pass_score", "-pass_score",
            "create_time", "-create_time"
        ]

        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        try:
            # ========== 构建基础查询 ==========
            paper_set = ExamPaper.objects.select_related('subject').order_by(sort_param)

            # 如果提供了ID列表，则只查询指定ID
            if id_list and len(id_list) > 0:
                paper_set = paper_set.filter(id__in=id_list)

            # 如果提供了科目ID，则只查询该科目
            if subject_id:
                paper_set = paper_set.filter(subject_id=subject_id)

            # 格式化日期和统计关联数据
            paper_set = paper_set.extra(
                select={
                    "create_time": 'DATE_FORMAT(exam_paper.create_time, "%%Y-%%m-%%d %%H:%%i:%%s")'
                }
            ).annotate(
                subject_name=F('subject__name'),
                question_count=Count('exampaperquestion', distinct=True),
                section_count=Count('sections', distinct=True)
            )

            # ========== 处理查询条件 ==========
            search = query_params.pop("search", None)
            if search:
                search, is_void = JTransformType.to(search, "str")
                if search:
                    paper_set = paper_set.filter(Q(title__icontains=search))

            # 处理其他筛选条件
            from ..utils.custom_tool import format_params_handle
            conditions = format_params_handle(
                param_dict=query_params,
                filter_filed_list=ExamPaperService.filter_filed_list,
                alias_dict=ExamPaperService.__condition_alias,
                split_list=["id_list", "subject_id_list"],
                is_remove_empty=True
            )

            if conditions:
                paper_set = paper_set.filter(**conditions)

            # 记录查询SQL
            paper_query = paper_set.query

            # ========== 执行分页查询 ==========
            paginator = Paginator(paper_set, per_page=size)
            total = paginator.count

            # 页号溢出返回空列表
            if page > paginator.num_pages and paginator.num_pages > 0:
                result = {
                    "page": page,
                    "size": size,
                    "total": total,
                    "list": [],
                    "query": str(paper_query)
                }
                return result, None

            # 获取当前页数据
            paginator_set = paginator.page(page) if total > 0 else []

            # ========== 导出分页结果 ==========
            if total > 0:
                main_set = paginator_set.object_list

                # 获取试卷基本信息
                main_list = list(main_set.values(
                    *ExamPaperService.all_fields,
                    'subject_name',
                    'question_count',
                    'section_count'
                ))

                # ========== 如果需要专项信息 ==========
                if with_sections and main_list:
                    paper_ids = [item['id'] for item in main_list]

                    # 批量查询专项信息（避免 N+1 问题）
                    sections_query = ExamPaperSection.objects.filter(
                        exam_paper_id__in=paper_ids
                    ).order_by('exam_paper_id', 'sort').values(
                        'id',
                        'exam_paper_id',
                        'title',
                        'description',
                        'sort',
                        'create_time'
                    )

                    # 格式化专项的创建时间
                    sections_list = []
                    for section in sections_query:
                        section_item = dict(section)
                        if section_item.get('create_time'):
                            section_item['create_time'] = section_item['create_time'].strftime("%Y-%m-%d %H:%M:%S")
                        sections_list.append(section_item)

                    # 如果需要题目统计，统计每个专项的题目数量
                    if with_questions:
                        section_ids = [s['id'] for s in sections_list]
                        question_counts = ExamPaperQuestion.objects.filter(
                            section_id__in=section_ids
                        ).values('section_id').annotate(count=Count('id'))

                        question_count_map = {item['section_id']: item['count'] for item in question_counts}

                        for section_item in sections_list:
                            section_item['question_count'] = question_count_map.get(section_item['id'], 0)

                    # 构建专项映射
                    sections_map = {}
                    for section in sections_list:
                        paper_id = section.pop('exam_paper_id')
                        if paper_id not in sections_map:
                            sections_map[paper_id] = []
                        sections_map[paper_id].append(section)

                    # 添加专项到试卷
                    for item in main_list:
                        item['sections'] = sections_map.get(item['id'], [])
                else:
                    # 不需要专项信息时，添加空列表
                    if with_sections:
                        for item in main_list:
                            item['sections'] = []
            else:
                main_list = []

            # 返回结果
            result = {
                "page": int(page),
                "size": int(size),
                "total": total,
                "list": main_list,
                "query": str(paper_query)
            }

            return result, None

        except EmptyPage:
            result = {
                "page": page,
                "size": size,
                "total": 0,
                "list": [],
                "query": ""
            }
            return result, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""