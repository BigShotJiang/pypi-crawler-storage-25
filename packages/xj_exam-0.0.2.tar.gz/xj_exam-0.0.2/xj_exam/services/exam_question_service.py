# encoding: utf-8
"""
@project: exam_question_service
@author:
@Email:
@synopsis: 考试题目服务层
@created_time: 2026
"""

from django.db import transaction
from django.db.models import Q, Count, F
from django.core.paginator import Paginator, EmptyPage

from ..models import ExamQuestion, ExamQuestionOption, ExamSubject
from ..utils.j_transform_type import JTransformType
from ..utils.j_parameter import JParameter


class ExamQuestionService:
    """
    考试题目服务类：提供题目的增删改查服务
    """

    # 查询字段说明
    __support_queries = {
        "id": "题目ID",
        "id_list": "题目ID列表",
        "subject_id": "科目ID",
        "subject_id_list": "科目ID列表",
        "paper_id": "试卷ID",
        "question": "题目内容（模糊查询）",
        "analysis": "答案解析（模糊查询）",
        "search": "搜索关键词（题目内容或答案解析）",
        "score": "分值",
        "score_min": "最小分值",
        "score_max": "最大分值",
        "column": "选项展示列数",
        "create_time_start|date": "创建开始时间",
        "create_time_end|date": "创建结束时间",
        "page": "页号，默认第1页",
        "size": "每页行数，默认20行",
        "sort": "排序字段，默认 -create_time",
        "filter_fields": "返回字段筛选",
    }

    # 所有字段
    all_fields = [
        "id",
        "subject_id",
        "question",
        "score",
        "analysis",
        "column",
        "create_time",
    ]

    # 添加字段
    add_fields = [
        "subject_id",
        "question",
        "score",
        "analysis",
        "column",
    ]

    # 编辑字段
    edit_fields = [
        "subject_id",
        "question",
        "score",
        "analysis",
        "column",
    ]

    # 格式化字段
    format_fields = [
        "id|int",
        "subject_id|int",
        "question|str",
        "score|int",
        "analysis|str",
        "column|int",
        "create_time|date",
    ]

    # 搜索条件映射
    __condition_alias = {
        "id_list": "id__in",
        "subject_id_list": "subject_id__in",
        "question": "question__icontains",
        "analysis": "analysis__icontains",
        "score_min": "score__gte",
        "score_max": "score__lte",
        "create_time_start": "create_time__gte",
        "create_time_end": "create_time__lte",
    }

    # 默认字段类型
    filter_filed_list = [
        "id|int",
        "id_list|list",
        "subject_id|int",
        "subject_id_list|list",
        "question|str",
        "analysis|str",
        "score|int",
        "score_min|int",
        "score_max|int",
        "column|int",
        "create_time_start|date",
        "create_time_end|date",
    ]

    @staticmethod
    def add(params: dict = None, options: list = None, **kwargs):
        """
        添加题目（包含选项）
        :param params: 添加参数字典
        :param options: 选项列表，格式：[{"option": "A", "content": "选项A", "is_correct": True}, ...]
        :param kwargs: 额外参数
        :return: (题目数据字典, 错误信息)

        @example
        params = {
            "subject_id": 1,
            "question": "1+1=?",
            "score": 5,
            "analysis": "基础加法",
            "column": 2
        }
        options = [
            {"option": "A", "content": "1", "is_correct": False},
            {"option": "B", "content": "2", "is_correct": True},
            {"option": "C", "content": "3", "is_correct": False},
            {"option": "D", "content": "4", "is_correct": False}
        ]
        """
        # ========== 参数整合 ==========
        whole, is_void = JTransformType.to(params, "dict", {})
        args, is_void = JTransformType.to(kwargs, "dict", {})
        whole.update(args)
        # ========== 必填字段验证 ==========
        subject_id = whole.get("subject_id")
        question = whole.get("question")
        if not subject_id:
            return None, "所属科目(subject_id)必填。"
        if not question:
            return None, "题目内容(question)必填。"
        # ========== 参数格式化 ==========
        query_params = JParameter.format(whole, filter_fields=ExamQuestionService.format_fields)
        query_params = {k: v for k, v in query_params.items() if k in ExamQuestionService.add_fields}
        # 验证并转换科目ID
        try:
            query_params['subject_id'], is_void = JTransformType.to(query_params.get('subject_id'), "int")
            if not query_params['subject_id']:
                return None, "科目ID不能为空。"
        except (ValueError, TypeError):
            return None, "科目ID格式错误，必须是整数。"
        # ========== 验证选项列表 ==========
        options, is_void = JTransformType.to(options, "list", [])
        if not options or len(options) < 2:
            return None, "至少需要2个选项。"
        # ========== 验证选项格式和内容 ==========
        correct_count = 0
        option_labels = set()
        validated_options = []
        for idx, opt in enumerate(options, start=1):
            if not isinstance(opt, dict):
                return None, f"第 {idx} 个选项格式错误，必须是字典格式。"
            option_label = opt.get("option")
            content = opt.get("content")
            is_correct = opt.get("is_correct", False)
            # 验证选项标签
            if not option_label:
                return None, f"第 {idx} 个选项缺少选项标签(option)。"
            option_label, is_void = JTransformType.to(option_label, "str")
            option_label = option_label.strip().upper()
            if not option_label:
                return None, f"第 {idx} 个选项标签不能为空。"
            if len(option_label) > 1:
                return None, f"第 {idx} 个选项标签({option_label})长度不能超过1个字符。"
            if option_label in option_labels:
                return None, f"选项标签({option_label})重复。"
            # 验证选项内容
            if not content:
                return None, f"第 {idx} 个选项缺少选项内容(content)。"
            content, is_void = JTransformType.to(content, "str")
            content = content.strip()
            if not content:
                return None, f"第 {idx} 个选项内容不能为空。"
            # 验证正确答案标记
            is_correct, is_void = JTransformType.to(is_correct, "bool", False)
            option_labels.add(option_label)
            if is_correct:
                correct_count += 1
            validated_options.append({
                "option": option_label,
                "content": content,
                "is_correct": is_correct
            })
        # 验证至少有一个正确答案
        if correct_count == 0:
            return None, "至少需要一个正确答案。"
        # ========== 数据库操作（使用事务） ==========
        try:
            with transaction.atomic():
                # 验证科目是否存在（使用 select_for_update 防止并发问题）
                subject = ExamSubject.objects.filter(id=query_params['subject_id']).only('id', 'name').first()
                if not subject:
                    return None, f"科目(ID:{query_params['subject_id']})不存在。"
                # 创建题目
                question_obj = ExamQuestion.objects.create(**query_params)
                # 批量创建选项
                option_objects = [
                    ExamQuestionOption(
                        question_id=question_obj,
                        option=opt["option"],
                        content=opt["content"],
                        is_correct=opt["is_correct"]
                    )
                    for opt in validated_options
                ]
                ExamQuestionOption.objects.bulk_create(option_objects)
                # 查询创建的选项（用于返回结果）
                created_options = list(
                    ExamQuestionOption.objects.filter(question_id=question_obj.id)
                    .order_by('option')
                    .values('id', 'option', 'content', 'is_correct')
                )
                # 构建返回结果
                result = {
                    "id": question_obj.id,
                    "subject_id": question_obj.subject_id,
                    "subject_name": subject.name,
                    "question": question_obj.question,
                    "score": question_obj.score,
                    "analysis": question_obj.analysis,
                    "column": question_obj.column,
                    "create_time": question_obj.create_time.strftime("%Y-%m-%d %H:%M:%S") if question_obj.create_time else None,
                    "options": created_options,
                }

                return result, None
        except ExamSubject.DoesNotExist:
            return None, f"科目(ID:{query_params['subject_id']})不存在。"
        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def item(pk: int = None):
        """
        获取题目详情（包含选项）
        :param pk: 题目ID
        :return: (题目数据字典, 错误信息)
        """
        if pk is None:
            return None, "缺少题目ID(id)字段。"

        try:
            # 查询题目
            question_set = ExamQuestion.objects.filter(id=pk)

            # 统计关联数据
            question_item = question_set.annotate(
                subject_name=F("subject__name"),
                paper_count=Count('exams', distinct=True),
            ).extra(
                select={
                    # ✅ 使用表名前缀明确指定字段
                    "create_time": 'DATE_FORMAT(exam_question.create_time, "%%Y-%%m-%%d %%H:%%i:%%s")',
                }
            ).values(
                *ExamQuestionService.all_fields,
                'subject_name',
                'paper_count'
            ).first()

            if not question_item:
                return None, f"题目不存在，ID：{pk}。"

            # 查询选项
            options = ExamQuestionOption.objects.filter(question_id=pk).order_by('option').values(
                'id', 'option', 'content', 'is_correct'
            )
            question_item['options'] = list(options)

            return question_item, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def edit(pk: int = None, params: dict = None, options: list = None):
        """
        编辑题目（包含选项）
        :param pk: 题目ID
        :param params: 编辑参数字典
        :param options: 选项列表（如果提供，则完全替换原有选项）
        :return: (题目数据字典, 错误信息)

        @description
        如果 options 为 None，则不修改选项
        如果 options 为空列表或有值，则完全替换原有选项
        """
        if pk is None:
            return None, "缺少题目ID(id)字段。"

        # 参数转换校验
        params, error = JTransformType.to(params, "dict", {})
        if error:
            return None, error

        try:
            # 检查题目是否存在
            exist_set = ExamQuestion.objects.filter(id=pk).first()
            if not exist_set:
                return None, f"题目(ID:{pk})不存在，无法进行修改。"

            # 验证科目是否存在（如果修改科目）
            subject_id = params.get("subject_id")
            if subject_id:
                subject_id, is_void = JTransformType.to(subject_id, "int")
                subject = ExamSubject.objects.filter(id=subject_id).first()
                if not subject:
                    return None, f"科目(ID:{subject_id})不存在。"

            # 主表修改
            main_params = {k: v for k, v in params.items() if k in ExamQuestionService.edit_fields}
            main_params = JParameter.format(main_params, filter_fields=ExamQuestionService.format_fields,
                                            is_remove_null=True)

            # 更新字段
            for k, v in main_params.items():
                setattr(exist_set, k, v)
            exist_set.save()

            # 处理选项（如果提供）
            if options is not None:
                # 验证选项
                options, is_void = JTransformType.to(options, "list", [])
                if len(options) < 2:
                    return None, "至少需要2个选项。"

                # 验证选项格式
                correct_count = 0
                option_labels = set()
                for idx, opt in enumerate(options):
                    if not isinstance(opt, dict):
                        return None, f"第 {idx + 1} 个选项格式错误，必须是字典格式。"

                    option_label = opt.get("option")
                    content = opt.get("content")
                    is_correct = opt.get("is_correct", False)

                    if not option_label:
                        return None, f"第 {idx + 1} 个选项缺少选项标签(option)。"
                    if not content:
                        return None, f"第 {idx + 1} 个选项缺少选项内容(content)。"
                    if option_label in option_labels:
                        return None, f"选项标签({option_label})重复。"

                    option_labels.add(option_label)

                    if is_correct:
                        correct_count += 1

                if correct_count == 0:
                    return None, "至少需要一个正确答案。"

                # 删除原有选项
                ExamQuestionOption.objects.filter(question_id=pk).delete()

                # 创建新选项
                for opt in options:
                    ExamQuestionOption.objects.create(
                        question_id=exist_set,
                        option=opt.get("option"),
                        content=opt.get("content"),
                        is_correct=opt.get("is_correct", False)
                    )

            # 返回结果
            # 刷新对象以获取最新数据
            exist_set.refresh_from_db()
            subject = ExamSubject.objects.get(id=exist_set.subject_id)

            # 获取选项
            option_list = list(ExamQuestionOption.objects.filter(question_id=pk).order_by('option').values(
                'id', 'option', 'content', 'is_correct'
            ))

            result = {
                "id": exist_set.id,
                "subject_id": exist_set.subject_id,
                "subject_name": subject.name,
                "question": exist_set.question,
                "score": exist_set.score,
                "analysis": exist_set.analysis,
                "column": exist_set.column,
                "create_time": exist_set.create_time.strftime("%Y-%m-%d %H:%M:%S") if exist_set.create_time else None,
                "options": option_list,
            }
            return result, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def delete(pk: int = None):
        """
        删除题目（硬删除，级联删除选项）
        :param pk: 题目ID
        :return: (None, 错误信息)
        """
        if not pk:
            return None, "缺少题目ID(id)字段。"

        try:
            # 检查题目是否存在
            question_set = ExamQuestion.objects.filter(id=pk).first()
            if not question_set:
                return None, f"题目(ID:{pk})不存在，无法进行删除。"

            # 检查是否有关联数据
            paper_count = question_set.exams.count()
            if paper_count > 0:
                return None, f"该题目被 {paper_count} 个试卷使用，无法删除。"

            # 执行删除（选项会级联删除）
            question_set.delete()
            return None, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def list(id_list: list = None, subject_id: int = None, paper_id: int = None, section_id: int = None,
             query_params: dict = None, page: int = 1, size: int = 20, sort: str = "-create_time",
             with_options: bool = True, show_correct: bool = False):
        """
        获取题目列表
        :param id_list: 题目ID列表（如果提供，则只查询指定ID的题目）
        :param subject_id: 科目ID（如果提供，则只查询该科目的题目）
        :param paper_id: 试卷ID（如果提供，则只查询该试卷的题目，并返回 number）
        :param section_id: 专项ID（如果提供,则只查询该专项的题目，并返回 number）
        :param query_params: 筛选条件字典
        :param page: 页码，默认1
        :param size: 每页数量，默认20
        :param sort: 排序字段，默认 -create_time
        :param with_options: 是否包含选项信息，默认True
        :param show_correct: 是否显示正确答案和解析，默认False
        :return: (列表数据, 错误信息)
        """
        # ========== 参数类型处理 ==========
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-create_time")
        with_options, is_void = JTransformType.to(with_options, "bool", True)
        show_correct, is_void = JTransformType.to(show_correct, "bool", False)
        paper_id, is_void = JTransformType.to(paper_id, "int")
        section_id, is_void = JTransformType.to(section_id, "int")

        # 参数验证
        if page < 1:
            page = 1
        if size < 1:
            size = 1
        if size > 200:
            size = 200

        # ✅ 判断是否启用中间表查询模式（paper_id 或 section_id 存在）
        is_relation_mode = paper_id is not None or section_id is not None

        # ✅ 如果启用中间表模式，默认按 number 排序
        if is_relation_mode and sort_param == "-create_time":
            sort_param = "number"

        # ✅ 排序字段验证（永远支持 number 排序）
        sort_choices = ["id", "-id", "subject_id", "-subject_id", "score", "-score", "create_time", "-create_time",
                        "number", "-number"]
        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"

        try:
            # ==================== 准备执行查询列表 start ====================
            if is_relation_mode:
                # ✅ 中间表模式：从 ExamPaperQuestion 查询
                from ..models import ExamPaperQuestion, ExamPaper, ExamPaperSection

                # 验证试卷或专项是否存在
                if paper_id:
                    paper_exists = ExamPaper.objects.filter(id=paper_id).exists()
                    if not paper_exists:
                        return None, f"试卷(ID:{paper_id})不存在。"

                if section_id:
                    section_exists = ExamPaperSection.objects.filter(id=section_id).exists()
                    if not section_exists:
                        return None, f"专项(ID:{section_id})不存在。"

                # 从中间表查询题目
                relation_set = ExamPaperQuestion.objects.select_related('exam_question', 'exam_question__subject')

                # 添加试卷或专项过滤
                if paper_id:
                    relation_set = relation_set.filter(exam_paper_id=paper_id)
                if section_id:
                    relation_set = relation_set.filter(section_id=section_id)

                # ✅ 排序条件处理
                if sort_param in ["number", "-number"]:
                    is_desc = sort_param.startswith('-')
                    if is_desc:
                        relation_set = relation_set.order_by(F('number').desc(nulls_last=True))
                    else:
                        relation_set = relation_set.order_by(F('number').asc(nulls_last=True))
                elif sort_param in ["create_time", "-create_time"]:
                    actual_sort = (
                        "exam_question__create_time" if sort_param == "create_time" else "-exam_question__create_time")
                    relation_set = relation_set.order_by(actual_sort)
                elif sort_param in ["id", "-id", "score", "-score", "subject_id", "-subject_id"]:
                    field = sort_param.lstrip('-')
                    prefix = '-' if sort_param.startswith('-') else ''
                    actual_sort = f"{prefix}exam_question__{field}"
                    relation_set = relation_set.order_by(actual_sort)

                # 如果提供了ID列表，则只查询指定ID
                if id_list and len(id_list) > 0:
                    relation_set = relation_set.filter(exam_question_id__in=id_list)

                # 如果提供了科目ID，则只查询该科目
                if subject_id:
                    relation_set = relation_set.filter(exam_question__subject_id=subject_id)

                # ========== 处理查询条件 ==========
                search = query_params.pop("search", None)
                if search:
                    search, is_void = JTransformType.to(search, "str")
                    if search:
                        relation_set = relation_set.filter(
                            Q(exam_question__question__icontains=search) | Q(exam_question__analysis__icontains=search))

                from ..utils.custom_tool import format_params_handle
                conditions = format_params_handle(param_dict=query_params,
                                                  filter_filed_list=ExamQuestionService.filter_filed_list,
                                                  alias_dict=ExamQuestionService.__condition_alias,
                                                  split_list=["id_list", "subject_id_list"], is_remove_empty=True)

                # 为中间表查询添加前缀
                prefixed_conditions = {}
                for key, value in conditions.items():
                    if key.startswith('id'):
                        prefixed_conditions[f'exam_question__{key}'] = value
                    elif not key.startswith('exam_question__'):
                        prefixed_conditions[f'exam_question__{key}'] = value
                    else:
                        prefixed_conditions[key] = value

                if prefixed_conditions:
                    relation_set = relation_set.filter(**prefixed_conditions)

                question_query = relation_set.query

            else:
                # ✅ 普通模式：从题目表查询（但支持 number 排序）
                from ..models import ExamPaperQuestion

                # ✅ 如果需要按 number 排序，即使没有指定 paper_id，也使用中间表
                if sort_param in ["number", "-number"]:
                    # 使用中间表关联查询
                    question_set = ExamQuestion.objects.select_related('subject').annotate(
                        number_order=F('exampaperquestion__number'))

                    # 排序
                    is_desc = sort_param.startswith('-')
                    if is_desc:
                        question_set = question_set.order_by(F('number_order').desc(nulls_last=True), '-id')
                    else:
                        question_set = question_set.order_by(F('number_order').asc(nulls_last=True), 'id')
                else:
                    question_set = ExamQuestion.objects.select_related('subject').order_by(sort_param)

                # 如果提供了ID列表，则只查询指定ID
                if id_list and len(id_list) > 0:
                    question_set = question_set.filter(id__in=id_list)

                # 如果提供了科目ID，则只查询该科目
                if subject_id:
                    question_set = question_set.filter(subject_id=subject_id)

                # 格式化日期和统计关联数据
                question_set = question_set.extra(select={
                    "create_time": 'DATE_FORMAT(exam_question.create_time, "%%Y-%%m-%%d %%H:%%i:%%s")'}).annotate(
                    subject_name=F('subject__name'), option_count=Count('options', distinct=True),
                    paper_count=Count('exams', distinct=True))

                # ========== 设置查询条件 ==========
                search = query_params.pop("search", None)
                if search:
                    search, is_void = JTransformType.to(search, "str")
                    if search:
                        question_set = question_set.filter(
                            Q(question__icontains=search) | Q(analysis__icontains=search))

                from ..utils.custom_tool import format_params_handle
                conditions = format_params_handle(param_dict=query_params,
                                                  filter_filed_list=ExamQuestionService.filter_filed_list,
                                                  alias_dict=ExamQuestionService.__condition_alias,
                                                  split_list=["id_list", "subject_id_list"], is_remove_empty=True)

                if conditions:
                    question_set = question_set.filter(**conditions)

                question_query = question_set.query

            # ========== 执行分页查询 ==========
            if is_relation_mode:
                paginator = Paginator(relation_set, per_page=size)
            else:
                paginator = Paginator(question_set, per_page=size)

            total = paginator.count

            # 页号溢出返回空列表
            if page > paginator.num_pages and paginator.num_pages > 0:
                result = {"page": page, "size": size, "total": total, "list": [], "query": str(question_query)}
                if is_relation_mode:
                    if paper_id:
                        result['paper_id'] = paper_id
                    if section_id:
                        result['section_id'] = section_id
                    result['is_relation_mode'] = True
                return result, None

            # 获取当前页数据
            paginator_set = paginator.page(page) if total > 0 else []

            # ========== 导出分页结果 ==========
            if total > 0:
                main_set = paginator_set.object_list

                if is_relation_mode:
                    # 中间表模式：处理中间表数据
                    main_list = []
                    question_ids = []

                    for rel in main_set:
                        question = rel.exam_question
                        question_ids.append(question.id)

                        item = {'id': question.id, 'subject_id': question.subject_id,
                                'subject_name': question.subject.name, 'question': question.question,
                                'score': question.score, 'column': question.column,
                                'create_time': question.create_time.strftime(
                                    "%Y-%m-%d %H:%M:%S") if question.create_time else None, 'number': rel.number}

                        if show_correct:
                            item['analysis'] = question.analysis

                        if paper_id:
                            item['paper_id'] = paper_id
                        if section_id:
                            item['section_id'] = section_id

                        main_list.append(item)

                    # 包含选项信息（批量查询避免 N+1 问题）
                    if with_options and question_ids:
                        if show_correct:
                            option_fields = ['id', 'question_id', 'option', 'content', 'is_correct']
                        else:
                            option_fields = ['id', 'question_id', 'option', 'content']

                        options_query = ExamQuestionOption.objects.filter(question_id__in=question_ids).order_by(
                            'option').values(*option_fields)
                        options_list = list(options_query)

                        # 构建选项映射
                        options_map = {}
                        for opt in options_list:
                            q_id = opt.pop('question_id')
                            if q_id not in options_map:
                                options_map[q_id] = []
                            options_map[q_id].append(opt)

                        # 添加选项到题目
                        for item in main_list:
                            item['options'] = options_map.get(item['id'], [])
                    else:
                        for item in main_list:
                            item['options'] = []

                else:
                    # 普通模式：处理题目表数据
                    if show_correct:
                        query_fields = list(ExamQuestionService.all_fields)
                    else:
                        query_fields = [f for f in ExamQuestionService.all_fields if f != 'analysis']

                    main_list = list(main_set.values(*query_fields, 'subject_name', 'option_count', 'paper_count'))

                    if with_options and main_list:
                        question_ids = [item['id'] for item in main_list]

                        if show_correct:
                            option_fields = ['id', 'question_id', 'option', 'content', 'is_correct']
                        else:
                            option_fields = ['id', 'question_id', 'option', 'content']

                        options_query = ExamQuestionOption.objects.filter(question_id__in=question_ids).order_by(
                            'option').values(*option_fields)
                        options_list = list(options_query)

                        # 构建选项映射
                        options_map = {}
                        for opt in options_list:
                            q_id = opt.pop('question_id')
                            if q_id not in options_map:
                                options_map[q_id] = []
                            options_map[q_id].append(opt)

                        # 添加选项到题目
                        for item in main_list:
                            item['options'] = options_map.get(item['id'], [])
                    else:
                        for item in main_list:
                            item['options'] = []
            else:
                main_list = []

            # 返回结果
            result = {"page": int(page), "size": int(size), "total": total, "list": main_list,
                      "query": str(question_query)}

            # 如果是中间表模式，添加额外信息
            if is_relation_mode:
                if paper_id:
                    result['paper_id'] = paper_id
                if section_id:
                    result['section_id'] = section_id
                result['is_relation_mode'] = True

            return result, None

        except EmptyPage:
            result = {"page": page, "size": size, "total": 0, "list": [], "query": ""}
            if is_relation_mode:
                if paper_id:
                    result['paper_id'] = paper_id
                if section_id:
                    result['section_id'] = section_id
                result['is_relation_mode'] = True
            return result, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""