from django.apps import AppConfig


class ExamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'xj_exam'
    verbose_name = 'Ⅱ 考试系统'
    sort = 12
