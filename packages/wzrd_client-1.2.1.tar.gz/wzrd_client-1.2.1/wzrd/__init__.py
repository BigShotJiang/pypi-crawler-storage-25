"""WZRD client.

Use WZRD as a momentum prior before execution routers, model calls,
or agent policy decisions.
"""

from importlib.metadata import PackageNotFoundError, version as _dist_version

try:
    __version__ = _dist_version("wzrd-client")
except PackageNotFoundError:
    __version__ = "1.2.1"

from .agent import (
    DEFAULT_API_BASE_URL,
    SLOTS_PER_DAY,
    AgentChallenge,
    AgentSession,
    WZRDAgent,
    agent_auth_message,
    load_keypair,
)
from .client import (
    DEFAULT_API_URL,
    DEFAULT_PREMIUM_API_URL,
    FeedMeta,
    PickResult,
    Signal,
    WZRDError,
    WZRDClient,
    clear_cache,
    compare,
    pick,
    pick_details,
    shortlist,
)

from .loop import run_loop
from .oracle import pick_onchain, read_velocity, read_price, list_feeds as list_oracle_feeds
from .router import WZRDRouter

__all__ = [
    "__version__",
    "DEFAULT_API_BASE_URL",
    "DEFAULT_API_URL",
    "SLOTS_PER_DAY",
    "DEFAULT_PREMIUM_API_URL",
    "AgentChallenge",
    "AgentSession",
    "FeedMeta",
    "PickResult",
    "Signal",
    "WZRDAgent",
    "WZRDError",
    "WZRDClient",
    "WZRDRouter",
    "agent_auth_message",
    "clear_cache",
    "compare",
    "load_keypair",
    "list_oracle_feeds",
    "pick",
    "pick_details",
    "pick_onchain",
    "read_price",
    "read_velocity",
    "run_loop",
    "shortlist",
]
