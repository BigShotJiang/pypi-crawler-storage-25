"""
Command-line interface for TorchForge.
"""

import sys

def main():
    if len(sys.argv) > 1 and sys.argv[1] in ['--help', '-h']:
        print("TorchForge CLI")
        print("Usage: torchforge [command]")
        print("")
        print("Commands:")
        print("  status    Show TorchForge system status")
        print("  --help    Show this help message")
        print("  --version Show version information")
    elif len(sys.argv) > 1 and sys.argv[1] == '--version':
        print("TorchForge 1.0.0")
    else:
        print("TorchForge CLI")
        print("Usage: torchforge <command>")
        print("Available commands: status")
        print("Use 'torchforge --help' for more information")

if __name__ == "__main__":
    main()