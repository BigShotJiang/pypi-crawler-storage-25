"""
Core ForgeModel implementation.

Wraps PyTorch nn.Module with enterprise features including governance,
monitoring, optimization, and deployment capabilities.
"""

import torch
import torch.nn as nn
from typing import Any, Dict, Optional, List, Tuple, Union
from datetime import datetime
import uuid
import logging
from pathlib import Path
import json

from torchforge.core.config import ForgeConfig
from torchforge.governance.lineage import LineageTracker
from torchforge.monitoring.metrics import MetricsCollector
from torchforge.optimization.profiler import ModelProfiler

logger = logging.getLogger(__name__)


class ForgeModel(nn.Module):
    """
    Enterprise-grade PyTorch model wrapper.
    
    Provides governance, monitoring, and optimization capabilities while
    maintaining full compatibility with PyTorch's nn.Module interface.
    
    Features:
        - Automatic lineage tracking
        - Real-time performance monitoring
        - Bias and fairness detection
        - Model profiling and optimization
        - Audit logging
        - Version control
    
    Example:
        >>> import torch.nn as nn
        >>> from torchforge import ForgeModel, ForgeConfig
        >>> 
        >>> base_model = nn.Linear(10, 2)
        >>> config = ForgeConfig(model_name="classifier", version="1.0.0")
        >>> model = ForgeModel(base_model, config=config)
        >>> 
        >>> x = torch.randn(32, 10)
        >>> output = model(x)
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: Optional[ForgeConfig] = None,
        model_id: Optional[str] = None,
    ):
        """
        Initialize ForgeModel.
        
        Args:
            model: PyTorch model to wrap
            config: TorchForge configuration
            model_id: Unique model identifier (auto-generated if not provided)
        """
        super().__init__()
        
        self.base_model = model
        self.config = config or ForgeConfig(
            model_name="unnamed_model",
            version="0.1.0"
        )
        self.model_id = model_id or str(uuid.uuid4())
        
        # Metadata
        self._metadata = {
            "model_id": self.model_id,
            "model_name": self.config.model_name,
            "version": self.config.version,
            "created_at": datetime.utcnow().isoformat(),
            "framework": "pytorch",
            "torchforge_version": "1.0.0",
        }
        
        # Initialize components
        self._initialize_components()
        
        # Training state
        self.training_history: List[Dict[str, Any]] = []
        self.prediction_history: List[Dict[str, Any]] = []
        
        logger.info(f"ForgeModel initialized: {self.config.model_name} v{self.config.version}")
    
    def _initialize_components(self) -> None:
        """Initialize governance, monitoring, and optimization components."""
        
        # Lineage tracking
        if self.config.enable_governance and self.config.governance.lineage_tracking:
            self.lineage_tracker = LineageTracker(
                model_id=self.model_id,
                model_name=self.config.model_name,
            )
        else:
            self.lineage_tracker = None
        
        # Metrics collection
        if self.config.enable_monitoring:
            self.metrics_collector = MetricsCollector(
                model_id=self.model_id,
                config=self.config.monitoring,
            )
        else:
            self.metrics_collector = None
        
        # Model profiler
        if self.config.enable_optimization and self.config.optimization.auto_profiling:
            self.profiler = ModelProfiler(model=self.base_model)
        else:
            self.profiler = None
    
    def forward(self, *args, **kwargs) -> Any:
        """
        Forward pass with automatic monitoring and profiling.
        
        Args:
            *args: Positional arguments for the base model
            **kwargs: Keyword arguments for the base model
            
        Returns:
            Model output
        """
        start_time = datetime.utcnow()
        
        # Profile if enabled
        if self.profiler and self.training:
            with torch.autograd.profiler.profile(use_cuda=torch.cuda.is_available()) as prof:
                output = self.base_model(*args, **kwargs)
            self.profiler.record_profile(prof)
        else:
            output = self.base_model(*args, **kwargs)
        
        # Collect metrics
        if self.metrics_collector:
            end_time = datetime.utcnow()
            latency_ms = (end_time - start_time).total_seconds() * 1000
            self.metrics_collector.record_inference(
                latency_ms=latency_ms,
                input_shape=args[0].shape if args else None,
                output_shape=output.shape if hasattr(output, 'shape') else None,
            )
        
        return output
    
    def track_prediction(
        self,
        output: torch.Tensor,
        target: Optional[torch.Tensor] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Track predictions for governance and monitoring.
        
        Args:
            output: Model output tensor
            target: Ground truth labels (optional)
            metadata: Additional metadata to track
        """
        prediction_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "output_shape": list(output.shape),
            "target_shape": list(target.shape) if target is not None else None,
            "metadata": metadata or {},
        }
        
        # Bias detection
        if self.config.enable_governance and self.config.governance.bias_detection:
            if target is not None:
                prediction_record["bias_metrics"] = self._compute_bias_metrics(output, target)
        
        self.prediction_history.append(prediction_record)
        
        # Track in lineage
        if self.lineage_tracker:
            self.lineage_tracker.track_prediction(prediction_record)
    
    def _compute_bias_metrics(
        self,
        output: torch.Tensor,
        target: torch.Tensor,
    ) -> Dict[str, float]:
        """
        Compute bias and fairness metrics.
        
        Args:
            output: Model predictions
            target: Ground truth labels
            
        Returns:
            Dictionary of bias metrics
        """
        # Simple demographic parity metric
        # In production, use more sophisticated fairness metrics
        predictions = output.argmax(dim=1) if output.dim() > 1 else output
        
        # Calculate basic metrics
        accuracy = (predictions == target).float().mean().item()
        
        return {
            "accuracy": accuracy,
            "sample_count": len(target),
            "timestamp": datetime.utcnow().isoformat(),
        }
    
    def save_checkpoint(
        self,
        path: Union[str, Path],
        include_optimizer: bool = False,
        optimizer: Optional[torch.optim.Optimizer] = None,
    ) -> None:
        """
        Save model checkpoint with governance metadata.
        
        Args:
            path: Path to save checkpoint
            include_optimizer: Whether to include optimizer state
            optimizer: Optimizer to save (if include_optimizer=True)
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        checkpoint = {
            "model_state_dict": self.base_model.state_dict(),
            "metadata": self._metadata,
            "config": self.config.to_dict(),
            "training_history": self.training_history[-100:],  # Last 100 entries
            "saved_at": datetime.utcnow().isoformat(),
        }
        
        if include_optimizer and optimizer is not None:
            checkpoint["optimizer_state_dict"] = optimizer.state_dict()
        
        torch.save(checkpoint, path)
        
        # Track in lineage
        if self.lineage_tracker:
            self.lineage_tracker.track_checkpoint(str(path))
        
        logger.info(f"Checkpoint saved: {path}")
    
    @classmethod
    def load_checkpoint(
        cls,
        path: Union[str, Path],
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
    ) -> "ForgeModel":
        """
        Load model from checkpoint.
        
        Args:
            path: Path to checkpoint file
            model: Base PyTorch model (architecture)
            optimizer: Optimizer to load state into (optional)
            
        Returns:
            Loaded ForgeModel instance
        """
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)
        
        # Load model state
        model.load_state_dict(checkpoint["model_state_dict"])
        
        # Recreate config
        config = ForgeConfig.from_dict(checkpoint["config"])
        
        # Create ForgeModel
        forge_model = cls(model, config=config)
        forge_model._metadata = checkpoint["metadata"]
        forge_model.training_history = checkpoint.get("training_history", [])
        
        # Load optimizer if provided
        if optimizer is not None and "optimizer_state_dict" in checkpoint:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        
        logger.info(f"Checkpoint loaded: {path}")
        return forge_model
    
    def export_onnx(
        self,
        path: Union[str, Path],
        example_input: torch.Tensor,
        opset_version: int = 14,
    ) -> None:
        """
        Export model to ONNX format with governance metadata.
        
        Args:
            path: Path to save ONNX model
            example_input: Example input for tracing
            opset_version: ONNX opset version
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # Export to ONNX
        torch.onnx.export(
            self.base_model,
            example_input,
            path,
            opset_version=opset_version,
            export_params=True,
            do_constant_folding=True,
        )
        
        # Save metadata separately
        metadata_path = path.with_suffix(".json")
        with open(metadata_path, "w") as f:
            json.dump(self._metadata, f, indent=2)
        
        logger.info(f"ONNX model exported: {path}")
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """
        Get summary of model metrics.
        
        Returns:
            Dictionary containing metrics summary
        """
        if not self.metrics_collector:
            return {}
        
        return self.metrics_collector.get_summary()
    
    def get_lineage(self) -> Dict[str, Any]:
        """
        Get model lineage information.
        
        Returns:
            Dictionary containing lineage information
        """
        if not self.lineage_tracker:
            return {}
        
        return self.lineage_tracker.get_lineage()
    
    def get_profile_report(self) -> Optional[str]:
        """
        Get profiling report.
        
        Returns:
            Formatted profiling report or None
        """
        if not self.profiler:
            return None
        
        return self.profiler.get_report()
    
    def __repr__(self) -> str:
        """String representation."""
        return (
            f"ForgeModel(\n"
            f"  name={self.config.model_name},\n"
            f"  version={self.config.version},\n"
            f"  model_id={self.model_id},\n"
            f"  governance={'enabled' if self.config.enable_governance else 'disabled'},\n"
            f"  monitoring={'enabled' if self.config.enable_monitoring else 'disabled'}\n"
            f")"
        )
