"""
Configuration management for TorchForge.

Provides type-safe configuration using Pydantic with validation,
serialization, and environment variable support.
"""

from enum import Enum
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field, validator
import yaml
import json
from pathlib import Path


class LogLevel(str, Enum):
    """Logging levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class DeploymentTarget(str, Enum):
    """Deployment target platforms."""
    LOCAL = "local"
    DOCKER = "docker"
    KUBERNETES = "kubernetes"
    AWS_SAGEMAKER = "aws_sagemaker"
    AZURE_ML = "azure_ml"
    GCP_VERTEX = "gcp_vertex"


class ComplianceFramework(str, Enum):
    """Supported compliance frameworks."""
    NIST_RMF = "nist_rmf"
    EU_AI_ACT = "eu_ai_act"
    ISO_42001 = "iso_42001"
    CUSTOM = "custom"


class MonitoringConfig(BaseModel):
    """Configuration for model monitoring."""
    enabled: bool = Field(default=True, description="Enable monitoring")
    metrics_interval: int = Field(default=60, ge=1, description="Metrics collection interval in seconds")
    drift_detection: bool = Field(default=True, description="Enable drift detection")
    fairness_tracking: bool = Field(default=True, description="Enable fairness metrics")
    prometheus_enabled: bool = Field(default=False, description="Enable Prometheus metrics")
    prometheus_port: int = Field(default=8001, ge=1024, le=65535)
    
    class Config:
        validate_assignment = True


class GovernanceConfig(BaseModel):
    """Configuration for governance and compliance."""
    enabled: bool = Field(default=True, description="Enable governance features")
    framework: ComplianceFramework = Field(default=ComplianceFramework.NIST_RMF)
    audit_logging: bool = Field(default=True, description="Enable audit logging")
    bias_detection: bool = Field(default=True, description="Enable bias detection")
    explainability: bool = Field(default=True, description="Enable model explainability")
    model_cards: bool = Field(default=True, description="Generate model cards")
    lineage_tracking: bool = Field(default=True, description="Track model lineage")
    
    class Config:
        validate_assignment = True


class OptimizationConfig(BaseModel):
    """Configuration for performance optimization."""
    enabled: bool = Field(default=True, description="Enable optimizations")
    auto_profiling: bool = Field(default=True, description="Enable automatic profiling")
    memory_optimization: bool = Field(default=True, description="Enable memory optimization")
    graph_optimization: bool = Field(default=True, description="Enable graph optimization")
    quantization: Optional[str] = Field(default=None, description="Quantization method: int8, fp16, dynamic")
    fusion: bool = Field(default=True, description="Enable operator fusion")
    
    class Config:
        validate_assignment = True


class DeploymentConfig(BaseModel):
    """Configuration for deployment."""
    target: DeploymentTarget = Field(default=DeploymentTarget.LOCAL)
    containerize: bool = Field(default=False, description="Create container image")
    health_check_enabled: bool = Field(default=True, description="Enable health checks")
    health_check_path: str = Field(default="/health")
    autoscaling: bool = Field(default=False, description="Enable autoscaling")
    min_instances: int = Field(default=1, ge=1)
    max_instances: int = Field(default=10, ge=1)
    
    @validator("max_instances")
    def validate_max_instances(cls, v, values):
        if "min_instances" in values and v < values["min_instances"]:
            raise ValueError("max_instances must be >= min_instances")
        return v
    
    class Config:
        validate_assignment = True


class ForgeConfig(BaseModel):
    """
    Main configuration class for TorchForge.
    
    Provides comprehensive configuration for all TorchForge features including
    governance, monitoring, optimization, and deployment.
    
    Example:
        >>> config = ForgeConfig(
        ...     model_name="my_classifier",
        ...     version="1.0.0",
        ...     enable_monitoring=True,
        ...     enable_governance=True
        ... )
    """
    
    # Model Metadata
    model_name: str = Field(..., description="Model name")
    version: str = Field(..., description="Model version (semver)")
    description: Optional[str] = Field(default=None, description="Model description")
    tags: List[str] = Field(default_factory=list, description="Model tags")
    author: Optional[str] = Field(default=None, description="Model author")
    
    # Feature Flags
    enable_monitoring: bool = Field(default=True, description="Enable monitoring")
    enable_governance: bool = Field(default=True, description="Enable governance")
    enable_optimization: bool = Field(default=True, description="Enable optimization")
    
    # Sub-configurations
    monitoring: MonitoringConfig = Field(default_factory=MonitoringConfig)
    governance: GovernanceConfig = Field(default_factory=GovernanceConfig)
    optimization: OptimizationConfig = Field(default_factory=OptimizationConfig)
    deployment: DeploymentConfig = Field(default_factory=DeploymentConfig)
    
    # Logging
    log_level: LogLevel = Field(default=LogLevel.INFO)
    log_file: Optional[str] = Field(default=None, description="Log file path")
    
    # Custom settings
    custom_settings: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        validate_assignment = True
        use_enum_values = True
    
    @validator("version")
    def validate_version(cls, v):
        """Validate semantic versioning."""
        parts = v.split(".")
        if len(parts) != 3:
            raise ValueError("Version must be in semver format (e.g., 1.0.0)")
        try:
            [int(p) for p in parts]
        except ValueError:
            raise ValueError("Version parts must be integers")
        return v
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return self.model_dump()
    
    def to_json(self, file_path: Optional[str] = None) -> str:
        """
        Serialize configuration to JSON.
        
        Args:
            file_path: Optional path to save JSON file
            
        Returns:
            JSON string representation
        """
        json_str = self.model_dump_json(indent=2)
        if file_path:
            Path(file_path).write_text(json_str)
        return json_str
    
    def to_yaml(self, file_path: Optional[str] = None) -> str:
        """
        Serialize configuration to YAML.
        
        Args:
            file_path: Optional path to save YAML file
            
        Returns:
            YAML string representation
        """
        yaml_str = yaml.dump(self.model_dump(), default_flow_style=False)
        if file_path:
            Path(file_path).write_text(yaml_str)
        return yaml_str
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "ForgeConfig":
        """Create configuration from dictionary."""
        return cls(**config_dict)
    
    @classmethod
    def from_json(cls, file_path: str) -> "ForgeConfig":
        """Load configuration from JSON file."""
        with open(file_path, "r") as f:
            config_dict = json.load(f)
        return cls.from_dict(config_dict)
    
    @classmethod
    def from_yaml(cls, file_path: str) -> "ForgeConfig":
        """Load configuration from YAML file."""
        with open(file_path, "r") as f:
            config_dict = yaml.safe_load(f)
        return cls.from_dict(config_dict)
    
    def update(self, **kwargs) -> None:
        """Update configuration with new values."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
    
    def merge(self, other: "ForgeConfig") -> "ForgeConfig":
        """
        Merge with another configuration.
        
        Args:
            other: Configuration to merge with
            
        Returns:
            New merged configuration
        """
        merged_dict = self.dict()
        merged_dict.update(other.dict())
        return ForgeConfig.from_dict(merged_dict)


# Default configurations for common use cases
DEFAULT_PRODUCTION_CONFIG = ForgeConfig(
    model_name="production_model",
    version="1.0.0",
    enable_monitoring=True,
    enable_governance=True,
    enable_optimization=True,
    monitoring=MonitoringConfig(
        drift_detection=True,
        fairness_tracking=True,
        prometheus_enabled=True,
    ),
    governance=GovernanceConfig(
        framework=ComplianceFramework.NIST_RMF,
        audit_logging=True,
        bias_detection=True,
    ),
)

DEFAULT_DEVELOPMENT_CONFIG = ForgeConfig(
    model_name="dev_model",
    version="0.1.0",
    enable_monitoring=True,
    enable_governance=False,
    enable_optimization=False,
    log_level=LogLevel.DEBUG,
)
