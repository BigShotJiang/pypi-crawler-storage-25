"""Metrics collection and monitoring for models."""

from typing import Dict, List, Any, Optional
from datetime import datetime
from collections import deque
import statistics


class MetricsCollector:
    """Collect and aggregate model performance metrics."""
    
    def __init__(self, model_id: str, config: Any, window_size: int = 1000):
        self.model_id = model_id
        self.config = config
        self.window_size = window_size
        
        # Metrics storage (circular buffer)
        self.latencies: deque = deque(maxlen=window_size)
        self.inference_count = 0
        self.error_count = 0
        self.start_time = datetime.utcnow()
        
    def record_inference(
        self,
        latency_ms: float,
        input_shape: Optional[tuple] = None,
        output_shape: Optional[tuple] = None,
    ) -> None:
        """Record an inference event."""
        self.latencies.append(latency_ms)
        self.inference_count += 1
        
    def record_error(self, error: Exception) -> None:
        """Record an error event."""
        self.error_count += 1
        
    def get_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        if not self.latencies:
            return {
                "inference_count": 0,
                "error_count": 0,
            }
        
        latencies_list = list(self.latencies)
        
        return {
            "inference_count": self.inference_count,
            "error_count": self.error_count,
            "error_rate": self.error_count / max(self.inference_count, 1),
            "latency_mean_ms": statistics.mean(latencies_list),
            "latency_median_ms": statistics.median(latencies_list),
            "latency_p95_ms": sorted(latencies_list)[int(len(latencies_list) * 0.95)] if latencies_list else 0,
            "latency_p99_ms": sorted(latencies_list)[int(len(latencies_list) * 0.99)] if latencies_list else 0,
            "uptime_seconds": (datetime.utcnow() - self.start_time).total_seconds(),
        }
