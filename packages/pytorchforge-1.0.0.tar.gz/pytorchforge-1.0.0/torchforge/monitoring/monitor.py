"""Model monitoring and observability."""

from typing import Any, Dict, Optional
import logging

logger = logging.getLogger(__name__)


class ModelMonitor:
    """
    Comprehensive model monitoring.
    
    Provides drift detection, performance tracking, and alerting.
    
    Example:
        >>> from torchforge.monitoring import ModelMonitor
        >>> monitor = ModelMonitor(model)
        >>> monitor.enable_drift_detection()
        >>> monitor.enable_fairness_tracking()
    """
    
    def __init__(self, model: Any):
        self.model = model
        self.drift_detection_enabled = False
        self.fairness_tracking_enabled = False
        
    def enable_drift_detection(self) -> None:
        """Enable drift detection."""
        self.drift_detection_enabled = True
        logger.info("Drift detection enabled")
        
    def enable_fairness_tracking(self) -> None:
        """Enable fairness tracking."""
        self.fairness_tracking_enabled = True
        logger.info("Fairness tracking enabled")
        
    def get_health_status(self) -> Dict[str, Any]:
        """Get model health status."""
        metrics = self.model.get_metrics_summary()
        
        return {
            "status": "healthy" if metrics.get("error_rate", 0) < 0.01 else "degraded",
            "metrics": metrics,
            "drift_detection": self.drift_detection_enabled,
            "fairness_tracking": self.fairness_tracking_enabled,
        }
