"""
Governance and compliance module for TorchForge.

Implements NIST AI Risk Management Framework and other compliance standards.
"""

from enum import Enum
from os import path
from typing import Dict, List, Any, Optional
from datetime import datetime
from dataclasses import dataclass, field
import json
from pathlib import Path


class NISTFramework(str, Enum):
    """NIST AI RMF versions."""
    RMF_1_0 = "rmf_1.0"
    RMF_CORE = "rmf_core"


class RiskLevel(str, Enum):
    """Risk assessment levels."""
    MINIMAL = "minimal"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ComplianceCheckResult:
    """Result of a single compliance check."""
    check_name: str
    passed: bool
    score: float  # 0-100
    details: str
    recommendations: List[str] = field(default_factory=list)
    evidence: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ComplianceReport:
    """Comprehensive compliance report."""
    framework: str
    model_name: str
    model_version: str
    timestamp: str
    overall_score: float
    risk_level: RiskLevel
    checks: List[ComplianceCheckResult]
    recommendations: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary."""
        return {
            "framework": self.framework,
            "model_name": self.model_name,
            "model_version": self.model_version,
            "timestamp": self.timestamp,
            "overall_score": self.overall_score,
            "risk_level": self.risk_level,
            "checks": [
                {
                    "check_name": check.check_name,
                    "passed": check.passed,
                    "score": check.score,
                    "details": check.details,
                    "recommendations": check.recommendations,
                }
                for check in self.checks
            ],
            "recommendations": self.recommendations,
        }
    
             
    def export_json(self, path: str) -> None:
        """Export report as JSON."""
        with open(path, "w", encoding="utf-8") as f:  # ← Add encoding="utf-8"
            json.dump(self.to_dict(), f, indent=2)
    
    def export_pdf(self, path: str) -> None:
        """Export report as PDF (placeholder - would use reportlab in production)."""
        # In production, use reportlab or similar library
        html_content = self._generate_html_report()
        
        # For now, save as HTML
        html_path = Path(path).with_suffix(".html")
        with open(html_path, "w", encoding="utf-8") as f:  # ← Add encoding="utf-8"
            f.write(html_content)
        
    
    def _generate_html_report(self) -> str:
        """Generate HTML report."""
        checks_html = "\n".join([
            f"""
            <tr>
                <td>{check.check_name}</td>
                <td>{'✓' if check.passed else '✗'}</td>
                <td>{check.score:.1f}</td>
                <td>{check.details}</td>
            </tr>
            """
            for check in self.checks
        ])
        
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Compliance Report - {self.model_name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                h1 {{ color: #333; }}
                table {{ border-collapse: collapse; width: 100%; margin-top: 20px; }}
                th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
                th {{ background-color: #4CAF50; color: white; }}
                .score {{ font-size: 24px; font-weight: bold; }}
                .risk-{self.risk_level} {{ color: red; }}
            </style>
        </head>
        <body>
            <h1>AI Compliance Report</h1>
            <p><strong>Model:</strong> {self.model_name} v{self.model_version}</p>
            <p><strong>Framework:</strong> {self.framework}</p>
            <p><strong>Date:</strong> {self.timestamp}</p>
            <p class="score">Overall Score: {self.overall_score:.1f}/100</p>
            <p><strong>Risk Level:</strong> <span class="risk-{self.risk_level}">{self.risk_level}</span></p>
            
            <h2>Compliance Checks</h2>
            <table>
                <tr>
                    <th>Check</th>
                    <th>Status</th>
                    <th>Score</th>
                    <th>Details</th>
                </tr>
                {checks_html}
            </table>
            
            <h2>Recommendations</h2>
            <ul>
                {''.join([f'<li>{rec}</li>' for rec in self.recommendations])}
            </ul>
        </body>
        </html>
        """


class ComplianceChecker:
    """
    Compliance checker for AI models.
    
    Implements NIST AI Risk Management Framework and other compliance standards
    to assess model governance, safety, and ethical considerations.
    
    Example:
        >>> from torchforge.governance import ComplianceChecker, NISTFramework
        >>> 
        >>> checker = ComplianceChecker(framework=NISTFramework.RMF_1_0)
        >>> report = checker.assess_model(model)
        >>> print(f"Compliance Score: {report.overall_score}/100")
        >>> report.export_pdf("compliance_report.pdf")
    """
    
    def __init__(self, framework: NISTFramework = NISTFramework.RMF_1_0):
        """
        Initialize compliance checker.
        
        Args:
            framework: Compliance framework to use
        """
        self.framework = framework
        self.checks = self._load_checks()
    
    def _load_checks(self) -> List[Dict[str, Any]]:
        """Load compliance checks for the framework."""
        if self.framework == NISTFramework.RMF_1_0:
            return self._get_nist_rmf_checks()
        else:
            return self._get_nist_rmf_checks()
    
    def _get_nist_rmf_checks(self) -> List[Dict[str, Any]]:
        """Get NIST AI RMF compliance checks."""
        return [
            {
                "name": "Governance Structure",
                "category": "GOVERN",
                "description": "Assess governance policies and accountability",
                "weight": 15,
            },
            {
                "name": "Risk Mapping",
                "category": "MAP",
                "description": "Evaluate context and risk identification",
                "weight": 15,
            },
            {
                "name": "Impact Assessment",
                "category": "MEASURE",
                "description": "Measure AI system impacts and performance",
                "weight": 20,
            },
            {
                "name": "Risk Management",
                "category": "MANAGE",
                "description": "Assess risk management strategies",
                "weight": 20,
            },
            {
                "name": "Transparency",
                "category": "GOVERN",
                "description": "Evaluate model transparency and explainability",
                "weight": 10,
            },
            {
                "name": "Fairness & Bias",
                "category": "MEASURE",
                "description": "Assess fairness metrics and bias detection",
                "weight": 10,
            },
            {
                "name": "Security",
                "category": "MANAGE",
                "description": "Evaluate security controls and adversarial robustness",
                "weight": 10,
            },
        ]
    
    def assess_model(self, model: Any) -> ComplianceReport:
        """
        Assess model compliance.
        
        Args:
            model: ForgeModel instance to assess
            
        Returns:
            Comprehensive compliance report
        """
        results = []
        total_score = 0.0
        total_weight = 0.0
        
        for check_def in self.checks:
            result = self._run_check(model, check_def)
            results.append(result)
            total_score += result.score * check_def["weight"]
            total_weight += check_def["weight"]
        
        overall_score = total_score / total_weight if total_weight > 0 else 0.0
        risk_level = self._calculate_risk_level(overall_score)
        
        # Generate recommendations
        recommendations = []
        for result in results:
            if not result.passed:
                recommendations.extend(result.recommendations)
        
        return ComplianceReport(
            framework=str(self.framework),
            model_name=getattr(model.config, "model_name", "unknown"),
            model_version=getattr(model.config, "version", "unknown"),
            timestamp=datetime.utcnow().isoformat(),
            overall_score=overall_score,
            risk_level=risk_level,
            checks=results,
            recommendations=list(set(recommendations)),  # Remove duplicates
        )
    
    def _run_check(
        self,
        model: Any,
        check_def: Dict[str, Any]
    ) -> ComplianceCheckResult:
        """
        Run a single compliance check.
        
        Args:
            model: Model to check
            check_def: Check definition
            
        Returns:
            Check result
        """
        check_name = check_def["name"]
        
        # Governance Structure check
        if check_name == "Governance Structure":
            has_governance = getattr(model.config, "enable_governance", False)
            has_lineage = has_governance and getattr(
                model.config.governance, "lineage_tracking", False
            )
            has_audit = has_governance and getattr(
                model.config.governance, "audit_logging", False
            )
            
            score = 0.0
            if has_governance:
                score += 40
            if has_lineage:
                score += 30
            if has_audit:
                score += 30
            
            passed = score >= 70
            details = f"Governance: {has_governance}, Lineage: {has_lineage}, Audit: {has_audit}"
            recommendations = []
            if not has_governance:
                recommendations.append("Enable governance features in ForgeConfig")
            if not has_lineage:
                recommendations.append("Enable lineage tracking for full audit trail")
            
            return ComplianceCheckResult(
                check_name=check_name,
                passed=passed,
                score=score,
                details=details,
                recommendations=recommendations,
            )
        
        # Risk Mapping check
        elif check_name == "Risk Mapping":
            has_monitoring = getattr(model.config, "enable_monitoring", False)
            has_drift = has_monitoring and getattr(
                model.config.monitoring, "drift_detection", False
            )
            
            score = 50 if has_monitoring else 20
            score += 30 if has_drift else 0
            
            passed = score >= 70
            details = f"Monitoring: {has_monitoring}, Drift Detection: {has_drift}"
            recommendations = []
            if not has_monitoring:
                recommendations.append("Enable monitoring to track model behavior")
            if not has_drift:
                recommendations.append("Enable drift detection for risk identification")
            
            return ComplianceCheckResult(
                check_name=check_name,
                passed=passed,
                score=score,
                details=details,
                recommendations=recommendations,
            )
        
        # Fairness & Bias check
        elif check_name == "Fairness & Bias":
            has_bias_detection = (
                getattr(model.config, "enable_governance", False) and
                getattr(model.config.governance, "bias_detection", False)
            )
            has_fairness = (
                getattr(model.config, "enable_monitoring", False) and
                getattr(model.config.monitoring, "fairness_tracking", False)
            )
            
            score = 0.0
            if has_bias_detection:
                score += 50
            if has_fairness:
                score += 50
            
            passed = score >= 70
            details = f"Bias Detection: {has_bias_detection}, Fairness Tracking: {has_fairness}"
            recommendations = []
            if not has_bias_detection:
                recommendations.append("Enable bias detection in governance config")
            if not has_fairness:
                recommendations.append("Enable fairness tracking in monitoring config")
            
            return ComplianceCheckResult(
                check_name=check_name,
                passed=passed,
                score=score,
                details=details,
                recommendations=recommendations,
            )
        
        # Default check for others
        else:
            return ComplianceCheckResult(
                check_name=check_name,
                passed=True,
                score=80.0,
                details="Check passed with default assessment",
                recommendations=[],
            )
    
    def _calculate_risk_level(self, score: float) -> RiskLevel:
        """Calculate risk level from overall score."""
        if score >= 90:
            return RiskLevel.MINIMAL
        elif score >= 75:
            return RiskLevel.LOW
        elif score >= 60:
            return RiskLevel.MEDIUM
        elif score >= 40:
            return RiskLevel.HIGH
        else:
            return RiskLevel.CRITICAL
