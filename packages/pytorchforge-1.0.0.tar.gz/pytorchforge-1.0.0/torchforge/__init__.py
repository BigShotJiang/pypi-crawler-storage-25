"""
TorchForge: Enterprise-Grade PyTorch Framework

A production-ready PyTorch wrapper with built-in governance, monitoring,
and deployment capabilities.

Author: Anil Prasad
License: MIT
"""

__version__ = "1.0.0"
__author__ = "Anil Prasad"
__email__ = "anilprasad@example.com"

from torchforge.core.forge_model import ForgeModel
from torchforge.core.config import ForgeConfig
from torchforge.governance.compliance import ComplianceChecker, NISTFramework
from torchforge.monitoring.monitor import ModelMonitor
from torchforge.deployment.manager import DeploymentManager

__all__ = [
    "ForgeModel",
    "ForgeConfig",
    "ComplianceChecker",
    "NISTFramework",
    "ModelMonitor",
    "DeploymentManager",
]
