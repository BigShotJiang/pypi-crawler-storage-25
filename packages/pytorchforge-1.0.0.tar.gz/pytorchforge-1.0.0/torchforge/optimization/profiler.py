"""Model profiling and performance analysis."""

import torch
from typing import Any, Optional, List
from collections import defaultdict


class ModelProfiler:
    """Profile PyTorch model performance."""
    
    def __init__(self, model: torch.nn.Module):
        self.model = model
        self.profiles: List[Any] = []
        self.operation_stats = defaultdict(lambda: {"count": 0, "total_time": 0.0})
        
    def record_profile(self, profile: Any) -> None:
        """Record a profiling session."""
        self.profiles.append(profile)
        
        # Aggregate operation statistics
        if hasattr(profile, 'key_averages'):
            for event in profile.key_averages():
                key = event.key
                self.operation_stats[key]["count"] += 1
                self.operation_stats[key]["total_time"] += event.cpu_time_total
        
    def get_report(self) -> str:
        """Generate profiling report."""
        if not self.profiles:
            return "No profiling data available"
        
        report_lines = ["Model Profiling Report", "=" * 50, ""]
        
        # Top operations by time
        sorted_ops = sorted(
            self.operation_stats.items(),
            key=lambda x: x[1]["total_time"],
            reverse=True
        )[:10]
        
        report_lines.append("Top 10 Operations by Time:")
        for op_name, stats in sorted_ops:
            avg_time = stats["total_time"] / stats["count"] if stats["count"] > 0 else 0
            report_lines.append(
                f"  {op_name}: {stats['total_time']:.2f}ms total, "
                f"{avg_time:.2f}ms avg ({stats['count']} calls)"
            )
        
        return "\n".join(report_lines)
