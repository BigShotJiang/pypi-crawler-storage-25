"""Performance optimization module."""

from torchforge.optimization.profiler import ModelProfiler

__all__ = [
    "ModelProfiler",
]
