"""
TorchForge: Enterprise-Grade PyTorch Framework
Author: Anil Prasad
author_email="anil@ambharii.com",
url="https://github.com/anilatambharii/torchforge",
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

# Read requirements
def read_requirements(filename):
    with open(this_directory / filename) as f:
        return [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    name="pytorchforge",
    version="1.0.0",
    author="Anil Prasad",
    author_email="anil@ambharii.com",
    description="Enterprise-grade PyTorch framework with governance, monitoring, and production deployment capabilities",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/anilatambharii/torchforge",
    project_urls={
        "Bug Tracker": "https://github.com/anilatambharii/torchforge/issues",
        "Documentation": "https://torchforge.readthedocs.io",
        "Source Code":  "https://github.com/anilatambharii/torchforge",             
    },
    packages=find_packages(exclude=["tests*", "docs*", "examples*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements("requirements.txt"),
    extras_require={
        "cloud": [
            "boto3>=1.26.0",
            "azure-ai-ml>=1.11.0",
            "google-cloud-aiplatform>=1.35.0",
            "kubernetes>=27.0.0",
        ],
        "monitoring": [
            "prometheus-client>=0.18.0",
            "grafana-api>=1.0.3",
            "mlflow>=2.8.0",
            "wandb>=0.16.0",
        ],
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-benchmark>=4.0.0",
            "black>=23.9.0",
            "isort>=5.12.0",
            "flake8>=6.1.0",
            "mypy>=1.5.0",
            "pre-commit>=3.4.0",
            "sphinx>=7.2.0",
            "sphinx-rtd-theme>=1.3.0",
        ],
        "all": [
            "boto3>=1.26.0",
            "azure-ai-ml>=1.11.0",
            "google-cloud-aiplatform>=1.35.0",
            "kubernetes>=27.0.0",
            "prometheus-client>=0.18.0",
            "grafana-api>=1.0.3",
            "mlflow>=2.8.0",
            "wandb>=0.16.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "torchforge=torchforge.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords=[
        "pytorch",
        "deep-learning",
        "machine-learning",
        "mlops",
        "enterprise-ai",
        "governance",
        "compliance",
        "nist",
        "production",
        "deployment",
    ],
)
