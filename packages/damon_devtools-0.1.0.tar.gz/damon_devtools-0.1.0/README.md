# devtools

Developer CLI tools: portkill, removebg, apkpull.

## Tools

### portkill
Kill Node.js processes by port or scan all node processes.

```bash
python -m devtools portkill
python -m devtools portkill --listen-only
```

### apkpull
Pull APK files from Android device via ADB.

```bash
python -m devtools apkpull [target_dir]
```

### removebg
Remove image backgrounds using the remove.bg API.

```bash
python -m devtools removebg input.jpg
```

## Install

```bash
pip install damon-devtools
```

Requires: Python >=3.10
