import sys
from importlib import import_module
from devtools.tools import get_tool


def run_tool(tool_name: str, args: list[str]):
    tool = get_tool(tool_name)
    if tool is None:
        print(f"Unknown tool: {tool_name}")
        print("Run `devtools` to see available tools.")
        sys.exit(1)

    module_name = tool.module

    # Try module.run directly (if tool exposes run at module root)
    mod = import_module(module_name)
    if hasattr(mod, "run"):
        mod.run(args)
        return

    # Try module.cli.run (removebg pattern)
    try:
        cli_mod = import_module(f"{module_name}.cli")
        if hasattr(cli_mod, "run"):
            cli_mod.run(args)
            return
    except ImportError:
        pass

    # Try module.ui.run (portkill pattern)
    try:
        ui_mod = import_module(f"{module_name}.ui")
        if hasattr(ui_mod, "run"):
            ui_mod.run(args)
            return
    except ImportError:
        pass

    print(f"Tool module {module_name} has no run() function")
    sys.exit(1)


def main():
    if len(sys.argv) > 1:
        run_tool(sys.argv[1], sys.argv[2:])
    else:
        from devtools.launcher import render_launcher
        result = render_launcher()
        if result:
            run_tool(result, [])

if __name__ == "__main__":
    main()
