from dataclasses import dataclass

@dataclass
class Tool:
    """A tool available in devtools"""
    name: str
    category: str
    description: str
    module: str
