import sys

from devtools.tools.portkill.ui import run

if __name__ == "__main__":
    run(sys.argv[1:])
