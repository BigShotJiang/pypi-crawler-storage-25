import sys
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

from devtools.tools.portkill.models import ProcessInfo


def show_processes(processes: list[ProcessInfo], short: bool = False) -> None:
    """Display processes in a simple table"""
    print()
    print(f"{'#':<4} {'PORT':<6} {'PID':<8} {'NAME':<20} {'CMDLINE'}")
    print("-" * 120)
    for i, p in enumerate(processes):
        port_str = str(p.port) if p.port > 0 else "-"
        cmdline = p.cmdline
        if short:
            cmdline = (p.cmdline[:50] + "...") if len(p.cmdline) > 50 else p.cmdline
        print(f"{i+1:<4} {port_str:<6} {p.pid:<8} {p.name:<20} {cmdline}")


def select_processes(processes: list[ProcessInfo], user_input: str) -> list[ProcessInfo]:
    """
    Parse user selection from input string.
    Supports: 1,3-5 or 1,3,5 or 1-3 style selection.
    Returns selected ProcessInfo list.
    """
    if not processes:
        print("没有发现 Node.js 进程")
        return []

    if not user_input:
        return []

    # Parse selection
    indices: list[int] = []
    for part in user_input.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start, end = part.split("-", 1)
            try:
                indices.extend(range(int(start) - 1, int(end)))
            except ValueError:
                print(f"无效输入: {part}")
                return []
        else:
            try:
                indices.append(int(part) - 1)
            except ValueError:
                print(f"无效输入: {part}")
                return []

    selected = [processes[i] for i in indices if 0 <= i < len(processes)]
    return selected


def confirm_kill(processes: list[ProcessInfo]) -> bool:
    """Show confirmation with process details"""
    print()
    print("=" * 60)
    for p in processes:
        print(f"  端口: {p.port}  |  PID: {p.pid}  |  进程名: {p.name}")
        print(f"  命令: {p.cmdline}")
        print(f"  目录: {p.cwd}")
        if p.children:
            print(f"  子进程: {p.children}")
        print("-" * 60)
    print()

    try:
        answer = input("确认关闭以上进程？ (y/N): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    return answer in ("y", "yes")


def execute_kill(pids: list[int], kill_children: bool = False) -> dict:
    """
    Execute kill on given PIDs.
    Returns {"killed": [...], "failed": [...]}
    """
    from devtools.tools.portkill.core import kill_process, get_process_tree

    killed: list[int] = []
    failed: list[tuple] = []

    all_pids: list[int] = []
    for pid in pids:
        if kill_children:
            all_pids.extend(get_process_tree(pid))
        else:
            all_pids.append(pid)

    seen = set()
    unique_pids = []
    for pid in all_pids:
        if pid not in seen:
            seen.add(pid)
            unique_pids.append(pid)

    for pid in unique_pids:
        if kill_process(pid, kill_children=False):
            killed.append(pid)
        else:
            failed.append((pid, "进程不存在或无权限"))

    return {"killed": killed, "failed": failed}


def run(args: list[str] | None = None):
    """Main entry point for portkill CLI"""
    from devtools.tools.portkill.core import scan_node_ports

    if args is None:
        args = []

    short = "--long" not in args      # short mode by default
    listen_only = "--listen-only" in args

    print("扫描 Node.js 进程...")

    try:
        all_processes = scan_node_ports()
    except Exception as e:
        print(f"扫描失败: {e}")
        return

    if not all_processes:
        print("未发现 Node.js 进程")
        return

    short_mode = short
    listen_filter = listen_only

    while True:
        # Apply filters
        processes = all_processes
        if listen_filter:
            processes = [p for p in processes if p.port > 0]

        if not processes:
            print("没有符合条件的进程")
            print("提示: 按 l 切换显示模式，或 p 关闭端口筛选")
        else:
            show_processes(processes, short=short_mode)

        print()
        print("快捷: l=长短显示  p=端口筛选  r=重新扫描  回车=退出")

        try:
            user_input = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if not user_input:
            print("未选择任何进程，退出")
            return

        # Interactive commands
        if user_input == "l":
            short_mode = not short_mode
            continue
        if user_input == "p":
            listen_filter = not listen_filter
            continue
        if user_input == "r":
            try:
                all_processes = scan_node_ports()
            except Exception as e:
                print(f"扫描失败: {e}")
                return
            if not all_processes:
                print("未发现 Node.js 进程")
                return
            continue

        # Try to parse as selection
        selected = select_processes(processes, user_input)
        if not selected:
            print("未选择任何进程，退出")
            return

        if not confirm_kill(selected):
            print("取消关闭")
            continue

        try:
            child_answer = input("是否同时关闭子进程？ (y/N): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            child_answer = "n"
        kill_children = child_answer in ("y", "yes")

        pids = [p.pid for p in selected]
        result = execute_kill(pids, kill_children=kill_children)

        print()
        if result["killed"]:
            print(f"已关闭: {result['killed']}")
        if result["failed"]:
            print(f"失败: {result['failed']}")
        return
