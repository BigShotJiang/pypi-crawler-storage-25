from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ProcessInfo:
    """Node.js 进程信息"""
    pid: int
    port: int
    name: str
    cmdline: str
    cwd: str
    children: list[int] = field(default_factory=list)
    cmdline_short: Optional[str] = None  # 截断后的命令摘要

    def __post_init__(self):
        self.cmdline_short = self.cmdline
