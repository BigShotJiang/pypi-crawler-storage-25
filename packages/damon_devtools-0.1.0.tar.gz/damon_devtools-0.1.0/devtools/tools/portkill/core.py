import os
import signal
import psutil
from typing import List, Dict
from devtools.tools.portkill.models import ProcessInfo


def scan_node_ports() -> List[ProcessInfo]:
    """扫描所有 Node.js 进程，返回按 PID 升序排列的列表"""
    results: List[ProcessInfo] = []
    seen_pids: Dict[int, ProcessInfo] = {}

    # 首先找出所有 Node.js 进程
    node_processes = []
    for proc in psutil.process_iter():
        try:
            name = proc.name().lower()
            if "node" not in name:
                continue
            node_processes.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    # 获取所有监听中的 TCP 连接（用于查端口）
    connections_by_pid: Dict[int, List[int]] = {}
    for conn in psutil.net_connections(kind="inet"):
        if conn.status != "LISTEN":
            continue
        if not conn.laddr:
            continue
        pid = conn.pid
        port = conn.laddr.port
        if pid not in connections_by_pid:
            connections_by_pid[pid] = []
        connections_by_pid[pid].append(port)

    # 为每个 Node.js 进程创建 ProcessInfo
    for proc in node_processes:
        pid = proc.pid
        if pid in seen_pids:
            continue

        ports = connections_by_pid.get(pid, [])
        port = ports[0] if ports else 0

        try:
            cmdline = " ".join(proc.cmdline())
            cwd = proc.cwd()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            cmdline = ""
            cwd = ""

        try:
            children = [child.pid for child in proc.children(recursive=True)]
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            children = []

        seen_pids[pid] = ProcessInfo(
            pid=pid,
            port=port,
            name=proc.name(),
            cmdline=cmdline,
            cwd=cwd,
            children=children,
        )

    results = list(seen_pids.values())
    results.sort(key=lambda x: (-x.port, x.pid))  # 有端口优先，按端口降序；无端口按 PID 升序
    return results


def get_process_tree(pid: int) -> List[int]:
    """获取指定进程及其所有子进程的 PID 列表"""
    try:
        proc = psutil.Process(pid)
        pids = [pid]
        for child in proc.children(recursive=True):
            pids.append(child.pid)
        return pids
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return [pid]  # 进程不存在时只返回自身


def kill_process(pid: int, kill_children: bool = False) -> bool:
    """向目标进程发送 SIGTERM 信号，成功返回 True"""
    try:
        proc = psutil.Process(pid)
        if kill_children:
            for child in proc.children(recursive=True):
                try:
                    os.kill(child.pid, signal.SIGTERM)
                except (OSError, psutil.NoSuchProcess):
                    pass
        os.kill(pid, signal.SIGTERM)
        return True
    except (psutil.NoSuchProcess, psutil.AccessDenied, OSError):
        return False
