import sys
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

import os
import threading
from devtools.tools.apkpull.models import PackageInfo

def scan_packages_with_labels() -> list[PackageInfo]:
    """Scan packages and fetch labels in parallel threads (max 10 concurrent)"""
    from devtools.tools.apkpull.core import scan_packages, check_adb, check_device, get_app_name

    if not check_adb():
        print("错误: 未找到 adb 命令，请确保 Android SDK platform-tools 已安装并加入 PATH")
        return []
    if not check_device():
        print("错误: 未检测到设备，请确保手机已通过 USB 连接并开启了 USB 调试模式")
        return []

    print("正在获取应用列表...")
    pkgs = scan_packages()
    if not pkgs:
        print("未找到第三方应用")
        return []

    print(f"共 {len(pkgs)} 个应用，正在获取应用名称...")

    packages: list[PackageInfo] = []
    lock = threading.Lock()

    def fetch(pkg: str):
        try:
            label = get_app_name(pkg)
        except Exception:
            label = pkg  # fallback on error
        with lock:
            packages.append(PackageInfo(pkg=pkg, label=label))

    threads: list[threading.Thread] = []
    for pkg in pkgs:
        t = threading.Thread(target=fetch, args=(pkg,))
        t.start()
        threads.append(t)
        if len(threads) >= 10:
            threads[0].join()
            threads = threads[1:]

    for t in threads:
        t.join()

    packages.sort(key=lambda x: x.label.lower())
    return packages

def show_packages(packages: list[PackageInfo], short: bool = True) -> None:
    print()
    print(f"{'#':<5} {'应用名':<30} {'包名'}")
    print("-" * 90)
    for i, p in enumerate(packages):
        label = p.label[:28] + ".." if short and len(p.label) > 30 else p.label
        pkg = p.pkg[:50] if short and len(p.pkg) > 50 else p.pkg
        print(f"{i+1:<5} {label:<30} {pkg}")

def select_packages(packages: list[PackageInfo], user_input: str) -> list[PackageInfo]:
    """Parse user input: keyword search or numeric selection (1,3-5, 1,3,5)"""
    if not user_input:
        return []
    # If input contains letters, treat as search keyword
    if any(c.isalpha() for c in user_input):
        keyword = user_input.lower()
        return [p for p in packages if keyword in p.label.lower() or keyword in p.pkg.lower()]
    # Numeric selection
    indices: list[int] = []
    for part in user_input.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            try:
                indices.extend(range(int(start) - 1, int(end) + 1))  # +1 because range end is exclusive
            except ValueError:
                print(f"无效输入: {part}")
                return []
        else:
            try:
                indices.append(int(part) - 1)
            except ValueError:
                print(f"无效输入: {part}")
                return []
    return [packages[i] for i in indices if 0 <= i < len(packages)]

def confirm_pull(packages: list[PackageInfo], dest_dir: str) -> bool:
    print()
    print("=" * 70)
    for p in packages:
        print(f"  应用名: {p.label}")
        print(f"  包名: {p.pkg}")
        print("-" * 70)
    print(f"目标目录: {dest_dir}")
    print(f"共 {len(packages)} 个 APK")
    print()
    try:
        answer = input("确认拉取？ (y/N): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    return answer in ("y", "yes")

def run(args: list[str] | None = None):
    """Main entry point"""
    if args is None:
        args = []

    # Determine destination directory
    if args:
        dest_dir = args[0]
    else:
        dest_dir = os.getcwd()

    packages = scan_packages_with_labels()
    if not packages:
        return

    show_packages(packages)

    while True:
        print()
        print("输入应用名/包名关键字搜索，或输入序号选择 (1,3-5, 1,3,5)")
        print("回车退出")

        try:
            user_input = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if not user_input:
            print("未选择，退出")
            return

        selected = select_packages(packages, user_input)
        if not selected:
            print("未匹配到应用")
            continue

        show_packages(selected, short=False)

        if not confirm_pull(selected, dest_dir):
            print("取消拉取")
            continue

        # Pull APKs
        from devtools.tools.apkpull.core import get_apk_path, pull_apk
        succeeded: list[str] = []
        failed: list[tuple] = []

        for p in selected:
            apk_path = get_apk_path(p.pkg)
            if not apk_path:
                failed.append((p.label, "未找到 APK 路径"))
                continue
            if pull_apk(apk_path, dest_dir):
                succeeded.append(p.label)
            else:
                failed.append((p.label, "拉取失败"))

        print()
        if succeeded:
            print(f"成功: {len(succeeded)} 个")
        if failed:
            print(f"失败: {len(failed)} 个")
            for label, reason in failed:
                print(f"  {label}: {reason}")
        return