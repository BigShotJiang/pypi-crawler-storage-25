import subprocess
import re
import os
import tempfile

def _find_aapt() -> str | None:
    """Find aapt.exe — checks PATH first, then Android SDK build-tools"""
    # 1. Check PATH
    import shutil as _shutil
    path_aapt = _shutil.which("aapt")
    if path_aapt and os.path.isfile(path_aapt):
        return path_aapt
    path_aapt2 = _shutil.which("aapt2")
    if path_aapt2 and os.path.isfile(path_aapt2):
        return path_aapt2
    # 2. Check Android SDK build-tools
    sdk_base = os.environ.get("LOCALAPPDATA", "") + "/Android/Sdk"
    build_tools = os.path.join(sdk_base, "build-tools")
    if os.path.isdir(build_tools):
        versions = sorted(os.listdir(build_tools), reverse=True)
        for v in versions:
            for binary in ("aapt.exe", "aapt2.exe"):
                aapt = os.path.join(build_tools, v, binary)
                if os.path.isfile(aapt):
                    return aapt
    return None

AAPT_PATH = _find_aapt()

def check_adb() -> bool:
    """检查 ADB 是否可用"""
    try:
        subprocess.run(["adb", "version"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def check_device() -> bool:
    """检查设备是否连接"""
    try:
        result = subprocess.run(["adb", "devices"], capture_output=True, text=True, encoding="utf-8", errors="replace", check=True)
        lines = result.stdout.strip().split("\n")
        for line in lines[1:]:
            if line.strip() and not line.startswith("*"):
                parts = line.split()
                if len(parts) >= 2 and parts[1] == "device":
                    return True
        return False
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def scan_packages() -> list[str]:
    """执行 adb shell pm list packages -3，返回包名列表"""
    result = subprocess.run(
        ["adb", "shell", "pm", "list", "packages", "-3"],
        capture_output=True, text=True, encoding="utf-8", errors="replace", check=True
    )
    pkgs = []
    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if line.startswith("package:"):
            pkgs.append(line[8:])
    return pkgs

def get_apk_path(pkg: str) -> str | None:
    """执行 pm path，返回 APK 物理路径"""
    try:
        result = subprocess.run(
            ["adb", "shell", "pm", "path", pkg],
            capture_output=True, text=True, encoding="utf-8", errors="replace", check=True
        )
        for line in result.stdout.strip().split("\n"):
            if line.startswith("package:"):
                return line[8:].strip()
        return None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None

def get_app_name(pkg: str) -> str:
    """通过 aapt 提取 APK 的 application label"""
    if not AAPT_PATH:
        return pkg
    apk_path = get_apk_path(pkg)
    if not apk_path:
        return pkg
    tmp = os.path.join(tempfile.gettempdir(), f"apkpull_{os.getpid()}_{pkg.replace('.', '_')}.apk")
    try:
        # pull APK to temp file
        pull_ok = subprocess.run(
            ["adb", "pull", apk_path, tmp],
            capture_output=True, encoding="utf-8", errors="replace"
        ).returncode == 0
        if not pull_ok or not os.path.exists(tmp):
            return pkg
        # extract label via aapt
        result = subprocess.run(
            [AAPT_PATH, "dump", "badging", tmp],
            capture_output=True, encoding="utf-8", errors="replace"
        )
        for line in result.stdout.split("\n"):
            m = re.search(r"application-label:'(.+?)'", line)
            if m:
                return m.group(1)
        return pkg
    except Exception:
        return pkg
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass

def pull_apk(apk_path: str, dest_dir: str) -> bool:
    """执行 adb pull，拉取 APK 到目标目录"""
    try:
        subprocess.run(
            ["adb", "pull", apk_path, dest_dir],
            capture_output=True, text=True, encoding="utf-8", errors="replace", check=True
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False