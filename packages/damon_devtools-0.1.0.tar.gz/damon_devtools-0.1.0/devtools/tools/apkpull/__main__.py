from devtools.tools.apkpull.ui import run

if __name__ == "__main__":
    import sys
    run(sys.argv[1:])