from dataclasses import dataclass

@dataclass
class PackageInfo:
    pkg: str   # 包名 (com.example.app)
    label: str  # 应用名 (My App)