"""Tools registry for devtools"""
from devtools.types import Tool

TOOLS = [
    Tool(
        name="portkill",
        category="进程/端口",
        description="按端口杀 Node.js 进程",
        module="devtools.tools.portkill",
    ),
    Tool(
        name="removebg",
        category="图像处理",
        description="批量删除图片背景",
        module="devtools.tools.removebg",
    ),
    Tool(
        name="apkpull",
        category="设备管理",
        description="提取手机 APK 文件",
        module="devtools.tools.apkpull",
    ),
]

def get_tool(name: str):
    for tool in TOOLS:
        if tool.name == name:
            return tool
    return None
