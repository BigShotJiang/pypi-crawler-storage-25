"""CLI entry point for removebg"""
import argparse
import sys
from pathlib import Path

from devtools.tools.removebg.core import process_images


MODELS = ["u2net", "u2netp", "u2net_human_seg"]


def run(args: list[str] | None = None):
    if args is None:
        args = sys.argv[1:]

    parser = argparse.ArgumentParser(
        prog="python -m devtools removebg",
        description="Remove background from images using rembg",
    )
    parser.add_argument(
        "-o", "--output",
        type=Path,
        default=None,
        metavar="DIR",
        help="Output directory (default: overwrite originals)",
    )
    parser.add_argument(
        "-m", "--model",
        choices=MODELS,
        default="u2net",
        help="Model to use (default: u2net)",
    )
    parser.add_argument(
        "-a", "--alpha-matting",
        action="store_true",
        help="Enable alpha matting for better edge quality",
    )
    parser.add_argument(
        "files",
        nargs="+",
        type=Path,
        help="Image files to process",
    )

    ns = parser.parse_args(args)

    # Validate files exist
    missing = [f for f in ns.files if not f.exists()]
    if missing:
        for f in missing:
            print(f"文件不存在: {f}", file=sys.stderr)
        sys.exit(1)

    # Create output dir if specified
    if ns.output is not None:
        ns.output.mkdir(parents=True, exist_ok=True)

    print(f"开始处理 {len(ns.files)} 个文件...")

    result = process_images(
        input_paths=ns.files,
        output_dir=ns.output,
        model=ns.model,
        alpha_matting=ns.alpha_matting,
    )

    # Report results
    print()
    for path in result["succeeded"]:
        print(f"  OK: {path}")

    for path, err in result["failed"]:
        print(f"  FAIL: {path} — {err}")

    total = len(result["succeeded"]) + len(result["failed"])
    print()
    print(f"完成: {total} 文件, {len(result['succeeded'])} 成功, {len(result['failed'])} 失败")

    if result["failed"]:
        sys.exit(1)
