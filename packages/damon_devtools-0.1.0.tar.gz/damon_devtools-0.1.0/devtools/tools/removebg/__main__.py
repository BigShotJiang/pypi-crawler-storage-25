import sys
from devtools.tools.removebg.cli import run

if __name__ == "__main__":
    run(sys.argv[1:])
