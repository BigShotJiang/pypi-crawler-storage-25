"""rembg core wrapper"""
from pathlib import Path
from typing import Optional

from rembg import remove, new_session
from PIL import Image


def process_images(
    input_paths: list[Path],
    output_dir: Optional[Path],
    model: str = "u2net",
    alpha_matting: bool = False,
    alpha_matting_foreground_threshold: int = 240,
    alpha_matting_background_threshold: int = 10,
    alpha_matting_erode_size: int = 0,
) -> dict:
    """
    Process a list of image files with rembg.

    Args:
        input_paths: List of image file paths
        output_dir: If set, write output files here. If None, overwrite originals.
        model: u2net | u2netp | u2net_human_seg
        alpha_matting: Enable alpha matting
        alpha_matting_foreground_threshold: Foreground threshold for alpha matting
        alpha_matting_background_threshold: Background threshold for alpha matting
        alpha_matting_erode_size: Erode size for alpha matting

    Returns:
        {"succeeded": [...], "failed": [(path, error_message), ...]}
    """
    succeeded = []
    failed = []

    session = new_session(model_name=model)

    for input_path in input_paths:
        try:
            with Image.open(input_path) as img:
                # rembg returns RGBA
                output = remove(
                    img,
                    session=session,
                    alpha_matting=alpha_matting,
                    alpha_matting_foreground_threshold=alpha_matting_foreground_threshold,
                    alpha_matting_background_threshold=alpha_matting_background_threshold,
                    alpha_matting_erode_size=alpha_matting_erode_size,
                )

            if output_dir is None:
                # Overwrite original
                output_path = input_path
            else:
                output_path = output_dir / input_path.name

            # Ensure output directory exists
            output_path.parent.mkdir(parents=True, exist_ok=True)

            output.save(output_path, "PNG")
            succeeded.append(str(output_path))

        except Exception as e:
            failed.append((str(input_path), str(e)))

    return {"succeeded": succeeded, "failed": failed}
