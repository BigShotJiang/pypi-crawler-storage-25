import sys
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

from devtools.tools import TOOLS


def render_launcher():
    """
    CLI launcher — list all tools with numbers, read selection.
    Returns: tool name string to launch, or None to quit
    """
    if not TOOLS:
        print("No tools registered!")
        return None

    print()
    print("=" * 50)
    print("  devtools — 开发者工具箱")
    print("=" * 50)
    print()
    for i, tool in enumerate(TOOLS):
        print(f"  {i + 1}. {tool.name:15s} — {tool.description}")
    print()
    print(f"  [1-{len(TOOLS)}] 选择工具  |  [Q] 退出")
    print()

    try:
        choice = input("> ").strip()
    except (EOFError, KeyboardInterrupt):
        return None

    if choice.lower() == "q":
        return None

    try:
        idx = int(choice) - 1
        if 0 <= idx < len(TOOLS):
            return TOOLS[idx].name
    except ValueError:
        pass

    return None
