from __future__ import annotations

from typing import Any, List, Mapping, Optional

from ._http import HttpTransport
from .base import BasePRCClient, SupportsRequest
from .models import (
    CommandLogEntry,
    CommandResult,
    EmergencyCall,
    JoinLogEntry,
    KillLogEntry,
    ModCallEntry,
    StaffV2,
    V2Player,
    V2ServerInfo,
    V2Vehicle,
)


class PRCClientV2(BasePRCClient):
    def __init__(
        self,
        server_key: str,
        *,
        base_url: str = "https://api.policeroleplay.community",
        transport: Optional[SupportsRequest] = None,
        timeout: float = 10.0,
        global_api_key: Optional[str] = None,
        respect_rate_limits: bool = True,
        retry_on_rate_limit: bool = True,
        max_rate_limit_retries: int = 1,
        default_headers: Optional[Mapping[str, str]] = None,
    ) -> None:
        super().__init__(
            server_key=server_key,
            base_url=base_url,
            transport=transport
            or HttpTransport(
                timeout=timeout,
                respect_rate_limits=respect_rate_limits,
                retry_on_rate_limit=retry_on_rate_limit,
                max_rate_limit_retries=max_rate_limit_retries,
            ),
            global_api_key=global_api_key,
            default_headers=default_headers,
        )

    def get_server(
        self,
        *,
        players: bool = False,
        staff: bool = False,
        join_logs: bool = False,
        queue: bool = False,
        kill_logs: bool = False,
        command_logs: bool = False,
        mod_calls: bool = False,
        emergency_calls: bool = False,
        vehicles: bool = False,
    ) -> V2ServerInfo:
        params = {}
        if players:
            params["Players"] = True
        if staff:
            params["Staff"] = True
        if join_logs:
            params["JoinLogs"] = True
        if queue:
            params["Queue"] = True
        if kill_logs:
            params["KillLogs"] = True
        if command_logs:
            params["CommandLogs"] = True
        if mod_calls:
            params["ModCalls"] = True
        if emergency_calls:
            params["EmergencyCalls"] = True
        if vehicles:
            params["Vehicles"] = True

        return V2ServerInfo.from_api(self._request("GET", "/v2/server", params=params))

    def run_command(self, command: str) -> CommandResult:
        _validate_command(command)
        response = self._request("POST", "/v2/server/command", json_body={"command": command}) or {}
        return CommandResult.from_api(response)

    def get_players(self) -> List[V2Player]:
        return self.get_server(players=True).players or []

    def get_staff(self) -> Optional[StaffV2]:
        return self.get_server(staff=True).staff

    def get_join_logs(self) -> List[JoinLogEntry]:
        return self.get_server(join_logs=True).join_logs or []

    def get_queue(self) -> List[int]:
        return self.get_server(queue=True).queue or []

    def get_kill_logs(self) -> List[KillLogEntry]:
        return self.get_server(kill_logs=True).kill_logs or []

    def get_command_logs(self) -> List[CommandLogEntry]:
        return self.get_server(command_logs=True).command_logs or []

    def get_mod_calls(self) -> List[ModCallEntry]:
        return self.get_server(mod_calls=True).mod_calls or []

    def get_emergency_calls(self) -> List[EmergencyCall]:
        return self.get_server(emergency_calls=True).emergency_calls or []

    def get_vehicles(self) -> List[V2Vehicle]:
        return self.get_server(vehicles=True).vehicles or []


def _validate_command(command: Any) -> None:
    if not isinstance(command, str) or not command.strip():
        raise ValueError("command must be a non-empty string")
