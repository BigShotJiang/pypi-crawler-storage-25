from __future__ import annotations

import base64
import hashlib
from typing import Tuple

PRC_EVENT_WEBHOOK_PUBLIC_KEY_SPKI_B64 = "MCowBQYDK2VwAyEAjSICb9pp0kHizGQtdG8ySWsDChfGqi+gyFCttigBNOA="

_ED25519_SPKI_PREFIX = bytes.fromhex("302a300506032b6570032100")
_Q = 2**255 - 19
_L = 2**252 + 27742317777372353535851937790883648493
_IDENTITY = (0, 1)


class WebhookVerificationError(ValueError):
    pass


def verify_prc_event_signature(
    timestamp: str,
    raw_body: bytes,
    signature_hex: str,
    *,
    public_key_spki_b64: str = PRC_EVENT_WEBHOOK_PUBLIC_KEY_SPKI_B64,
) -> bool:
    try:
        assert_valid_prc_event_signature(
            timestamp,
            raw_body,
            signature_hex,
            public_key_spki_b64=public_key_spki_b64,
        )
        return True
    except WebhookVerificationError:
        return False


def assert_valid_prc_event_signature(
    timestamp: str,
    raw_body: bytes,
    signature_hex: str,
    *,
    public_key_spki_b64: str = PRC_EVENT_WEBHOOK_PUBLIC_KEY_SPKI_B64,
) -> None:
    if not isinstance(timestamp, str):
        raise WebhookVerificationError("Timestamp must be provided as a string.")

    if not isinstance(raw_body, (bytes, bytearray)):
        raise WebhookVerificationError("raw_body must contain the exact request bytes.")

    if not isinstance(signature_hex, str) or not signature_hex:
        raise WebhookVerificationError("Signature header is missing or empty.")

    try:
        signature = bytes.fromhex(signature_hex)
    except ValueError as exc:
        raise WebhookVerificationError("Signature header is not valid hex.") from exc

    if len(signature) != 64:
        raise WebhookVerificationError("Ed25519 signatures must be 64 bytes long.")

    public_key = extract_ed25519_public_key_from_spki(public_key_spki_b64)
    message = timestamp.encode("utf-8") + bytes(raw_body)

    if not _verify_ed25519(public_key, message, signature):
        raise WebhookVerificationError("Signature verification failed.")


def extract_ed25519_public_key_from_spki(public_key_spki_b64: str) -> bytes:
    try:
        spki = base64.b64decode(public_key_spki_b64, validate=True)
    except Exception as exc:
        raise WebhookVerificationError("Public key is not valid base64 SPKI data.") from exc

    if not spki.startswith(_ED25519_SPKI_PREFIX):
        raise WebhookVerificationError("Public key is not an Ed25519 SPKI value.")

    raw_key = spki[len(_ED25519_SPKI_PREFIX) :]
    if len(raw_key) != 32:
        raise WebhookVerificationError("Ed25519 public keys must be 32 bytes long.")

    return raw_key


def _verify_ed25519(public_key: bytes, message: bytes, signature: bytes) -> bool:
    if len(public_key) != 32 or len(signature) != 64:
        return False

    r_encoded = signature[:32]
    s = int.from_bytes(signature[32:], "little")
    if s >= _L:
        return False

    try:
        public_point = _decode_point(public_key)
        r_point = _decode_point(r_encoded)
    except WebhookVerificationError:
        return False

    challenge = int.from_bytes(
        hashlib.sha512(r_encoded + public_key + message).digest(),
        "little",
    ) % _L

    left = _scalar_mult(_BASE_POINT, s)
    right = _point_add(r_point, _scalar_mult(public_point, challenge))

    return _scalar_mult(left, 8) == _scalar_mult(right, 8)


def _inv(value: int) -> int:
    return pow(value, _Q - 2, _Q)


_D = (-121665 * _inv(121666)) % _Q
_I = pow(2, (_Q - 1) // 4, _Q)


def _recover_x(y: int, sign: int) -> int:
    if y >= _Q:
        raise WebhookVerificationError("Compressed point has an invalid y coordinate.")

    xx = ((y * y - 1) * _inv(_D * y * y + 1)) % _Q
    x = pow(xx, (_Q + 3) // 8, _Q)

    if (x * x - xx) % _Q != 0:
        x = (x * _I) % _Q
    if (x * x - xx) % _Q != 0:
        raise WebhookVerificationError("Compressed point is not on the Ed25519 curve.")

    if x & 1 != sign:
        x = _Q - x
    return x


_BASE_Y = (4 * _inv(5)) % _Q
_BASE_X = _recover_x(_BASE_Y, 0)
_BASE_POINT = (_BASE_X, _BASE_Y)


def _decode_point(encoded: bytes) -> Tuple[int, int]:
    if len(encoded) != 32:
        raise WebhookVerificationError("Compressed points must be 32 bytes long.")

    y = int.from_bytes(encoded, "little") & ((1 << 255) - 1)
    sign = encoded[31] >> 7
    x = _recover_x(y, sign)
    point = (x, y)

    if not _is_on_curve(point):
        raise WebhookVerificationError("Point failed the Ed25519 curve check.")

    return point


def _is_on_curve(point: Tuple[int, int]) -> bool:
    x, y = point
    left = (-x * x + y * y - 1) % _Q
    right = (_D * x * x * y * y) % _Q
    return left == right


def _point_add(p: Tuple[int, int], q: Tuple[int, int]) -> Tuple[int, int]:
    x1, y1 = p
    x2, y2 = q

    denominator_x = _inv((1 + _D * x1 * x2 * y1 * y2) % _Q)
    denominator_y = _inv((1 - _D * x1 * x2 * y1 * y2) % _Q)

    x3 = ((x1 * y2 + x2 * y1) * denominator_x) % _Q
    y3 = ((y1 * y2 + x1 * x2) * denominator_y) % _Q

    return (x3, y3)


def _scalar_mult(point: Tuple[int, int], scalar: int) -> Tuple[int, int]:
    result = _IDENTITY
    addend = point
    n = scalar

    while n > 0:
        if n & 1:
            result = _point_add(result, addend)
        addend = _point_add(addend, addend)
        n >>= 1

    return result
