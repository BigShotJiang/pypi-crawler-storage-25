from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


def _to_int_list(value: Any) -> List[int]:
    return [int(item) for item in value or []]


def _to_str_dict(value: Any) -> Dict[str, str]:
    if not isinstance(value, Mapping):
        return {}
    return {str(key): str(item) for key, item in value.items()}


@dataclass(frozen=True)
class ServerStatus:
    name: str
    owner_id: int
    co_owner_ids: List[int]
    current_players: int
    max_players: int
    join_key: str
    account_verification_requirement: str
    team_balance: bool

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "ServerStatus":
        return cls(
            name=str(data["Name"]),
            owner_id=int(data["OwnerId"]),
            co_owner_ids=_to_int_list(data.get("CoOwnerIds")),
            current_players=int(data["CurrentPlayers"]),
            max_players=int(data["MaxPlayers"]),
            join_key=str(data["JoinKey"]),
            account_verification_requirement=str(data["AccVerifiedReq"]),
            team_balance=bool(data["TeamBalance"]),
        )


@dataclass(frozen=True)
class V1Player:
    player: str
    permission: str
    callsign: Optional[str]
    team: str

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "V1Player":
        return cls(
            player=str(data["Player"]),
            permission=str(data["Permission"]),
            callsign=_optional_string(data.get("Callsign")),
            team=str(data["Team"]),
        )


@dataclass(frozen=True)
class JoinLogEntry:
    join: bool
    timestamp: int
    player: str

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "JoinLogEntry":
        return cls(
            join=bool(data["Join"]),
            timestamp=int(data["Timestamp"]),
            player=str(data["Player"]),
        )


@dataclass(frozen=True)
class KillLogEntry:
    killed: str
    timestamp: int
    killer: str

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "KillLogEntry":
        return cls(
            killed=str(data["Killed"]),
            timestamp=int(data["Timestamp"]),
            killer=str(data["Killer"]),
        )


@dataclass(frozen=True)
class CommandLogEntry:
    player: str
    timestamp: int
    command: str

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "CommandLogEntry":
        return cls(
            player=str(data["Player"]),
            timestamp=int(data["Timestamp"]),
            command=str(data["Command"]),
        )


@dataclass(frozen=True)
class ModCallEntry:
    caller: str
    moderator: Optional[str]
    timestamp: int

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "ModCallEntry":
        return cls(
            caller=str(data["Caller"]),
            moderator=_optional_string(data.get("Moderator")),
            timestamp=int(data["Timestamp"]),
        )


@dataclass(frozen=True)
class V1Vehicle:
    texture: Optional[str]
    name: str
    owner: str

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "V1Vehicle":
        return cls(
            texture=_optional_string(data.get("Texture")),
            name=str(data["Name"]),
            owner=str(data["Owner"]),
        )


@dataclass(frozen=True)
class StaffV1:
    co_owners: List[int]
    admins: Dict[str, str]
    mods: Dict[str, str]

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "StaffV1":
        return cls(
            co_owners=_to_int_list(data.get("CoOwners")),
            admins=_to_str_dict(data.get("Admins")),
            mods=_to_str_dict(data.get("Mods")),
        )


@dataclass(frozen=True)
class PlayerLocation:
    location_x: float
    location_z: float
    postal_code: Optional[str]
    street_name: Optional[str]
    building_number: Optional[str]

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "PlayerLocation":
        return cls(
            location_x=float(data["LocationX"]),
            location_z=float(data["LocationZ"]),
            postal_code=_optional_string(data.get("PostalCode")),
            street_name=_optional_string(data.get("StreetName")),
            building_number=_optional_string(data.get("BuildingNumber")),
        )


@dataclass(frozen=True)
class V2Player:
    team: str
    player: str
    callsign: Optional[str]
    location: Optional[PlayerLocation]
    permission: str
    wanted_stars: Optional[int]

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "V2Player":
        location_data = data.get("Location")
        return cls(
            team=str(data["Team"]),
            player=str(data["Player"]),
            callsign=_optional_string(data.get("Callsign")),
            location=PlayerLocation.from_api(location_data) if isinstance(location_data, Mapping) else None,
            permission=str(data["Permission"]),
            wanted_stars=_optional_int(data.get("WantedStars")),
        )


@dataclass(frozen=True)
class StaffV2:
    admins: Dict[str, str]
    mods: Dict[str, str]
    helpers: Dict[str, str]

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "StaffV2":
        return cls(
            admins=_to_str_dict(data.get("Admins")),
            mods=_to_str_dict(data.get("Mods")),
            helpers=_to_str_dict(data.get("Helpers")),
        )


@dataclass(frozen=True)
class EmergencyCall:
    team: str
    caller: Optional[int]
    players: List[Any]
    position: Tuple[float, float]
    started_at: int
    call_number: int
    description: str
    position_descriptor: Optional[str]

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "EmergencyCall":
        raw_position = list(data.get("Position") or [])
        if len(raw_position) != 2:
            position = (0.0, 0.0)
        else:
            position = (float(raw_position[0]), float(raw_position[1]))

        return cls(
            team=str(data["Team"]),
            caller=_optional_int(data.get("Caller")),
            players=list(data.get("Players") or []),
            position=position,
            started_at=int(data["StartedAt"]),
            call_number=int(data["CallNumber"]),
            description=str(data["Description"]),
            position_descriptor=_optional_string(data.get("PositionDescriptor")),
        )


@dataclass(frozen=True)
class V2Vehicle:
    name: str
    owner: str
    plate: Optional[str]
    texture: Optional[str]
    color_hex: Optional[str]
    color_name: Optional[str]

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "V2Vehicle":
        return cls(
            name=str(data["Name"]),
            owner=str(data["Owner"]),
            plate=_optional_string(data.get("Plate")),
            texture=_optional_string(data.get("Texture")),
            color_hex=_optional_string(data.get("ColorHex")),
            color_name=_optional_string(data.get("ColorName")),
        )


@dataclass(frozen=True)
class CommandResult:
    message: str

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "CommandResult":
        return cls(message=str(data.get("message") or data.get("Message") or "Success"))


@dataclass(frozen=True)
class V2ServerInfo(ServerStatus):
    players: Optional[List[V2Player]] = None
    staff: Optional[StaffV2] = None
    join_logs: Optional[List[JoinLogEntry]] = None
    queue: Optional[List[int]] = None
    kill_logs: Optional[List[KillLogEntry]] = None
    command_logs: Optional[List[CommandLogEntry]] = None
    mod_calls: Optional[List[ModCallEntry]] = None
    emergency_calls: Optional[List[EmergencyCall]] = None
    vehicles: Optional[List[V2Vehicle]] = None

    @classmethod
    def from_api(cls, data: Mapping[str, Any]) -> "V2ServerInfo":
        base = ServerStatus.from_api(data)
        return cls(
            name=base.name,
            owner_id=base.owner_id,
            co_owner_ids=base.co_owner_ids,
            current_players=base.current_players,
            max_players=base.max_players,
            join_key=base.join_key,
            account_verification_requirement=base.account_verification_requirement,
            team_balance=base.team_balance,
            players=_parse_list(data.get("Players"), V2Player),
            staff=StaffV2.from_api(data["Staff"]) if isinstance(data.get("Staff"), Mapping) else None,
            join_logs=_parse_list(data.get("JoinLogs"), JoinLogEntry),
            queue=_to_int_list(data.get("Queue")) if "Queue" in data else None,
            kill_logs=_parse_list(data.get("KillLogs"), KillLogEntry),
            command_logs=_parse_list(data.get("CommandLogs"), CommandLogEntry),
            mod_calls=_parse_list(data.get("ModCalls"), ModCallEntry),
            emergency_calls=_parse_list(data.get("EmergencyCalls"), EmergencyCall),
            vehicles=_parse_list(data.get("Vehicles"), V2Vehicle),
        )


def _parse_list(value: Any, model_cls: Any) -> Optional[List[Any]]:
    if value is None:
        return None
    return [model_cls.from_api(item) for item in value]


def _optional_string(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value)
    return text if text else None


def _optional_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    return int(value)
