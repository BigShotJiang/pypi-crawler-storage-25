from __future__ import annotations

from typing import Any, List, Mapping, Optional

from ._http import HttpTransport
from .base import BasePRCClient, SupportsRequest
from .models import (
    CommandLogEntry,
    JoinLogEntry,
    KillLogEntry,
    ModCallEntry,
    ServerStatus,
    StaffV1,
    V1Player,
    V1Vehicle,
)


class PRCClientV1(BasePRCClient):
    def __init__(
        self,
        server_key: str,
        *,
        base_url: str = "https://api.policeroleplay.community",
        transport: Optional[SupportsRequest] = None,
        timeout: float = 10.0,
        global_api_key: Optional[str] = None,
        respect_rate_limits: bool = True,
        retry_on_rate_limit: bool = True,
        max_rate_limit_retries: int = 1,
        default_headers: Optional[Mapping[str, str]] = None,
    ) -> None:
        super().__init__(
            server_key=server_key,
            base_url=base_url,
            transport=transport
            or HttpTransport(
                timeout=timeout,
                respect_rate_limits=respect_rate_limits,
                retry_on_rate_limit=retry_on_rate_limit,
                max_rate_limit_retries=max_rate_limit_retries,
            ),
            global_api_key=global_api_key,
            default_headers=default_headers,
        )

    def run_command(self, command: str) -> None:
        _validate_command(command)
        self._request("POST", "/v1/server/command", json_body={"command": command})

    def get_server(self) -> ServerStatus:
        return ServerStatus.from_api(self._request("GET", "/v1/server"))

    def get_players(self) -> List[V1Player]:
        return [V1Player.from_api(item) for item in self._request("GET", "/v1/server/players")]

    def get_join_logs(self) -> List[JoinLogEntry]:
        return [JoinLogEntry.from_api(item) for item in self._request("GET", "/v1/server/joinlogs")]

    def get_queue(self) -> List[int]:
        return [int(item) for item in self._request("GET", "/v1/server/queue")]

    def get_kill_logs(self) -> List[KillLogEntry]:
        return [KillLogEntry.from_api(item) for item in self._request("GET", "/v1/server/killlogs")]

    def get_command_logs(self) -> List[CommandLogEntry]:
        return [CommandLogEntry.from_api(item) for item in self._request("GET", "/v1/server/commandlogs")]

    def get_mod_calls(self) -> List[ModCallEntry]:
        return [ModCallEntry.from_api(item) for item in self._request("GET", "/v1/server/modcalls")]

    def get_bans(self) -> dict[str, str]:
        data = self._request("GET", "/v1/server/bans")
        if not isinstance(data, dict):
            raise TypeError("Expected a JSON object from /v1/server/bans")
        return {str(key): str(value) for key, value in data.items()}

    def get_vehicles(self) -> List[V1Vehicle]:
        return [V1Vehicle.from_api(item) for item in self._request("GET", "/v1/server/vehicles")]

    def get_staff(self) -> StaffV1:
        return StaffV1.from_api(self._request("GET", "/v1/server/staff"))


def _validate_command(command: Any) -> None:
    if not isinstance(command, str) or not command.strip():
        raise ValueError("command must be a non-empty string")
