from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Protocol

from .errors import PRCError
from .metadata import ResponseInfo

DEFAULT_CLIENT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/135.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}


class SupportsRequest(Protocol):
    def request(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str],
        params: Optional[Mapping[str, Any]] = None,
        json_body: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        ...


@dataclass
class _UrlBuilder:
    base_url: str

    def build(self, path: str) -> str:
        clean_base = self.base_url.rstrip("/")
        clean_path = path if path.startswith("/") else f"/{path}"
        return f"{clean_base}{clean_path}"


class BasePRCClient:
    def __init__(
        self,
        server_key: str,
        *,
        base_url: str,
        transport: SupportsRequest,
        global_api_key: Optional[str] = None,
        default_headers: Optional[Mapping[str, str]] = None,
    ) -> None:
        if not server_key or not server_key.strip():
            raise ValueError("server_key must be a non-empty string")

        self.server_key = server_key
        self.global_api_key = global_api_key.strip() if isinstance(global_api_key, str) and global_api_key.strip() else None
        self._url_builder = _UrlBuilder(base_url=base_url)
        self._transport = transport
        self._default_headers = dict(default_headers or {})

    def _headers(self) -> Dict[str, str]:
        headers = dict(DEFAULT_CLIENT_HEADERS)
        headers.update(self._default_headers)
        headers["Server-Key"] = self.server_key
        if self.global_api_key:
            headers["Authorization"] = self.global_api_key
        headers.setdefault("Accept", "application/json")
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
        json_body: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        return self._transport.request(
            method,
            self._url_builder.build(path),
            headers=self._headers(),
            params=params,
            json_body=json_body,
        )

    @property
    def last_response(self) -> Optional[ResponseInfo]:
        return getattr(self._transport, "last_response", None)


class PRCAPI:
    def __init__(
        self,
        server_key: str,
        *,
        base_url: str = "https://api.policeroleplay.community",
        timeout: float = 10.0,
        global_api_key: Optional[str] = None,
        respect_rate_limits: bool = True,
        retry_on_rate_limit: bool = True,
        max_rate_limit_retries: int = 1,
        default_headers: Optional[Mapping[str, str]] = None,
        transport: Optional[SupportsRequest] = None,
    ) -> None:
        from ._http import HttpTransport
        from .v1 import PRCClientV1
        from .v2 import PRCClientV2

        shared_transport = transport or HttpTransport(
            timeout=timeout,
            respect_rate_limits=respect_rate_limits,
            retry_on_rate_limit=retry_on_rate_limit,
            max_rate_limit_retries=max_rate_limit_retries,
        )

        self.v1 = PRCClientV1(
            server_key=server_key,
            base_url=base_url,
            global_api_key=global_api_key,
            default_headers=default_headers,
            transport=shared_transport,
        )
        self.v2 = PRCClientV2(
            server_key=server_key,
            base_url=base_url,
            global_api_key=global_api_key,
            default_headers=default_headers,
            transport=shared_transport,
        )

    def assert_clients(self) -> None:
        if self.v1 is None or self.v2 is None:
            raise PRCError("Versioned clients are not available")

    @property
    def last_response(self) -> Optional[ResponseInfo]:
        return getattr(self.v1, "last_response", None)
