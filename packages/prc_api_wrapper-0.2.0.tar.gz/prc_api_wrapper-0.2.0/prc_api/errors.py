from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Optional

from .metadata import build_rate_limit_info

if TYPE_CHECKING:
    from .metadata import RateLimitInfo

ERROR_CODE_MESSAGES = {
    0: "Unknown error occurred. If this is persistent, contact PRC via an API ticket.",
    1001: "An error occurred communicating with Roblox / the in-game private server.",
    1002: "An internal system error occurred.",
    2000: "You did not provide a server-key.",
    2001: "You provided an incorrectly formatted server-key.",
    2002: "You provided an invalid (or expired) server-key.",
    2003: "You provided an invalid global API key.",
    2004: "Your server-key is currently banned from accessing the API.",
    3001: "You did not provide a valid command in the request body.",
    3002: "The server you are attempting to reach is currently offline (has no players).",
    4001: "You are being rate limited.",
    4002: "The command you are attempting to run is restricted.",
    4003: "The message you're trying to send is prohibited.",
    9998: "The resource you are accessing is restricted.",
    9999: "The module running on the in-game server is out of date, please kick all and try again.",
}

DEFAULT_STATUS_MESSAGES = {
    400: "Bad request.",
    401: "Unauthorized.",
    403: "Unauthorized.",
    422: "The private server has no players in it.",
    429: "You are being rate limited.",
    500: "Problem communicating with Roblox.",
}


class PRCError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        error_code: Optional[int] = None,
        details: Optional[str] = None,
        response_body: Any = None,
        response_headers: Optional[Mapping[str, str]] = None,
        rate_limit: Optional["RateLimitInfo"] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.details = details
        self.response_body = response_body
        self.response_headers = dict(response_headers or {})
        self.rate_limit = rate_limit
        self.retry_after = retry_after


class TransportError(PRCError):
    pass


class ResponseDecodeError(PRCError):
    pass


class BadRequestError(PRCError):
    pass


class AuthenticationError(PRCError):
    pass


class NoPlayersError(PRCError):
    pass


class RateLimitError(PRCError):
    pass


class ServerCommunicationError(PRCError):
    pass


class RestrictedResourceError(PRCError):
    pass


def build_api_error(
    status_code: int,
    payload: Any,
    *,
    headers: Optional[Mapping[str, str]] = None,
) -> PRCError:
    error_code = _extract_error_code(payload)
    message = _extract_message(payload) or ERROR_CODE_MESSAGES.get(error_code) or DEFAULT_STATUS_MESSAGES.get(status_code) or "PRC API request failed."
    rate_limit = build_rate_limit_info(headers=headers, payload=payload)

    error_cls = _error_class(status_code=status_code, error_code=error_code)
    return error_cls(
        message,
        status_code=status_code,
        error_code=error_code,
        details=_extract_details(payload),
        response_body=payload,
        response_headers=headers,
        rate_limit=rate_limit,
        retry_after=rate_limit.retry_after,
    )


def _error_class(*, status_code: int, error_code: Optional[int]) -> type[PRCError]:
    if error_code in {2000, 2001, 2002, 2003, 2004} or status_code in {401, 403}:
        return AuthenticationError
    if error_code == 3002 or status_code == 422:
        return NoPlayersError
    if error_code == 4001 or status_code == 429:
        return RateLimitError
    if error_code == 9998:
        return RestrictedResourceError
    if error_code in {1001, 1002, 9999} or status_code >= 500:
        return ServerCommunicationError
    if status_code == 400:
        return BadRequestError
    return PRCError


def _extract_error_code(payload: Any) -> Optional[int]:
    if isinstance(payload, Mapping):
        for key in ("error_code", "errorCode", "code", "Code", "ErrorCode"):
            value = payload.get(key)
            if value is not None:
                try:
                    return int(value)
                except (TypeError, ValueError):
                    return None
    return None


def _extract_message(payload: Any) -> Optional[str]:
    if isinstance(payload, Mapping):
        for key in ("message", "Message", "error", "Error", "detail", "Detail"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    if isinstance(payload, str) and payload.strip():
        return payload.strip()
    return None


def _extract_details(payload: Any) -> Optional[str]:
    if isinstance(payload, Mapping):
        for key in ("details", "Details", "description", "Description"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None
