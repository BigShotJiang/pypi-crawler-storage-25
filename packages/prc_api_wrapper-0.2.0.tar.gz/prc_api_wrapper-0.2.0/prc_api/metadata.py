from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class RateLimitInfo:
    bucket: Optional[str] = None
    limit: Optional[int] = None
    remaining: Optional[int] = None
    reset_at: Optional[int] = None
    retry_after: Optional[float] = None


@dataclass(frozen=True)
class ResponseInfo:
    method: str
    url: str
    status_code: int
    headers: Dict[str, str] = field(default_factory=dict)
    elapsed_seconds: float = 0.0
    rate_limit: RateLimitInfo = field(default_factory=RateLimitInfo)


def build_rate_limit_info(
    *,
    headers: Optional[Mapping[str, str]] = None,
    payload: Any = None,
) -> RateLimitInfo:
    normalized_headers = {str(key).lower(): str(value) for key, value in (headers or {}).items()}

    bucket = _extract_string(payload, "bucket", "Bucket") or normalized_headers.get("x-ratelimit-bucket")
    limit = _extract_int_header(normalized_headers, "x-ratelimit-limit")
    remaining = _extract_int_header(normalized_headers, "x-ratelimit-remaining")
    reset_at = _extract_int_header(normalized_headers, "x-ratelimit-reset")
    retry_after = _extract_float(payload, "retry_after", "retryAfter", "RetryAfter")
    if retry_after is None:
        retry_after = _extract_float_header(normalized_headers, "retry-after")

    return RateLimitInfo(
        bucket=bucket,
        limit=limit,
        remaining=remaining,
        reset_at=reset_at,
        retry_after=retry_after,
    )


def _extract_string(payload: Any, *keys: str) -> Optional[str]:
    if isinstance(payload, Mapping):
        for key in keys:
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    return None


def _extract_int_header(headers: Mapping[str, str], key: str) -> Optional[int]:
    value = headers.get(key)
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _extract_float_header(headers: Mapping[str, str], key: str) -> Optional[float]:
    value = headers.get(key)
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _extract_float(payload: Any, *keys: str) -> Optional[float]:
    if isinstance(payload, Mapping):
        for key in keys:
            value = payload.get(key)
            if value is None:
                continue
            try:
                return float(value)
            except (TypeError, ValueError):
                return None
    return None
