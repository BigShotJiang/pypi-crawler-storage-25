from __future__ import annotations

import json
import threading
import time
from typing import Any, Mapping, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .errors import ResponseDecodeError, TransportError, build_api_error
from .metadata import ResponseInfo, build_rate_limit_info


class HttpTransport:
    def __init__(
        self,
        *,
        timeout: float = 10.0,
        respect_rate_limits: bool = True,
        retry_on_rate_limit: bool = True,
        max_rate_limit_retries: int = 1,
    ) -> None:
        self.timeout = timeout
        self.respect_rate_limits = respect_rate_limits
        self.retry_on_rate_limit = retry_on_rate_limit
        self.max_rate_limit_retries = max(0, int(max_rate_limit_retries))
        self.last_response: Optional[ResponseInfo] = None
        self._route_buckets: dict[str, str] = {}
        self._bucket_resume_times: dict[str, float] = {}
        self._lock = threading.Lock()

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str],
        params: Optional[Mapping[str, Any]] = None,
        json_body: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        request_url = self._build_url(url, params)
        payload = None
        request_headers = dict(headers)
        route_key = self._route_key(method, url)

        if json_body is not None:
            payload = json.dumps(json_body).encode("utf-8")
            request_headers["Content-Type"] = "application/json"

        attempts = 0
        while True:
            self._wait_for_rate_limit_window(route_key)
            request = Request(
                request_url,
                data=payload,
                headers=request_headers,
                method=method.upper(),
            )
            started = time.monotonic()

            try:
                with urlopen(request, timeout=self.timeout) as response:
                    raw_body = response.read()
                    headers_dict = self._headers_to_dict(response.headers)
                    parsed = self._parse_body(
                        raw_body,
                        getattr(response.headers, "get_content_charset", lambda *_: None)() or "utf-8",
                    )
                    elapsed = time.monotonic() - started
                    self._record_response(
                        method=method,
                        url=request_url,
                        status_code=getattr(response, "status", 200),
                        headers=headers_dict,
                        elapsed_seconds=elapsed,
                        payload=parsed,
                    )
                    self._update_rate_limit_state(route_key, headers_dict, parsed)
                    return parsed
            except HTTPError as exc:
                body = exc.read()
                headers_dict = self._headers_to_dict(exc.headers)
                parsed_payload = self._parse_error_body(body, exc)
                elapsed = time.monotonic() - started
                self._record_response(
                    method=method,
                    url=request_url,
                    status_code=exc.code,
                    headers=headers_dict,
                    elapsed_seconds=elapsed,
                    payload=parsed_payload,
                )
                self._update_rate_limit_state(route_key, headers_dict, parsed_payload)
                error = build_api_error(exc.code, parsed_payload, headers=headers_dict)

                if self._should_retry_rate_limit(error, attempts):
                    self._sleep_for_retry(error.retry_after)
                    attempts += 1
                    continue

                raise error from exc
            except URLError as exc:
                raise TransportError(f"Could not reach PRC API: {exc.reason}") from exc

    def _build_url(self, base_url: str, params: Optional[Mapping[str, Any]]) -> str:
        if not params:
            return base_url

        filtered = {}
        for key, value in params.items():
            if value is None:
                continue
            if isinstance(value, bool):
                filtered[key] = str(value).lower()
            else:
                filtered[key] = value

        if not filtered:
            return base_url

        return f"{base_url}?{urlencode(filtered, doseq=True)}"

    def _parse_body(self, body: bytes, encoding: str) -> Any:
        if not body:
            return None

        try:
            text = body.decode(encoding or "utf-8")
        except UnicodeDecodeError as exc:
            raise ResponseDecodeError("Could not decode PRC API response body.") from exc

        if not text.strip():
            return None

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text

    def _parse_error_body(self, body: bytes, error: HTTPError) -> Any:
        try:
            encoding = getattr(error.headers, "get_content_charset", lambda *_: None)() or "utf-8"
            return self._parse_body(body, encoding)
        except ResponseDecodeError:
            return body.decode("utf-8", errors="replace")

    def _record_response(
        self,
        *,
        method: str,
        url: str,
        status_code: int,
        headers: Mapping[str, str],
        elapsed_seconds: float,
        payload: Any,
    ) -> None:
        self.last_response = ResponseInfo(
            method=method.upper(),
            url=url,
            status_code=status_code,
            headers=dict(headers),
            elapsed_seconds=elapsed_seconds,
            rate_limit=build_rate_limit_info(headers=headers, payload=payload),
        )

    def _headers_to_dict(self, headers: Optional[Mapping[str, Any]]) -> dict[str, str]:
        if headers is None:
            return {}
        return {str(key): str(value) for key, value in headers.items()}

    def _route_key(self, method: str, url: str) -> str:
        parsed = urlparse(url)
        return f"{method.upper()} {parsed.path}"

    def _wait_for_rate_limit_window(self, route_key: str) -> None:
        if not self.respect_rate_limits:
            return

        delay = 0.0
        with self._lock:
            bucket = self._route_buckets.get(route_key)
            if bucket is None:
                return
            resume_at = self._bucket_resume_times.get(bucket, 0.0)
            delay = max(0.0, resume_at - time.time())

        if delay > 0:
            time.sleep(delay)

    def _update_rate_limit_state(
        self,
        route_key: str,
        headers: Mapping[str, str],
        payload: Any,
    ) -> None:
        if not self.respect_rate_limits:
            return

        rate_limit = build_rate_limit_info(headers=headers, payload=payload)
        bucket = rate_limit.bucket
        resume_at = self._compute_resume_time(rate_limit)

        with self._lock:
            if bucket:
                self._route_buckets[route_key] = bucket
            else:
                bucket = self._route_buckets.get(route_key)

            if bucket and resume_at is not None:
                current = self._bucket_resume_times.get(bucket, 0.0)
                self._bucket_resume_times[bucket] = max(current, resume_at)

    def _compute_resume_time(self, rate_limit: Any) -> Optional[float]:
        retry_after = getattr(rate_limit, "retry_after", None)
        if retry_after is not None:
            return time.time() + max(0.0, float(retry_after))

        remaining = getattr(rate_limit, "remaining", None)
        reset_at = getattr(rate_limit, "reset_at", None)
        if remaining is not None and remaining <= 0 and reset_at is not None:
            return float(reset_at)

        return None

    def _should_retry_rate_limit(self, error: Any, attempts: int) -> bool:
        return bool(
            self.retry_on_rate_limit
            and getattr(error, "status_code", None) == 429
            and attempts < self.max_rate_limit_retries
            and getattr(error, "retry_after", None) is not None
        )

    def _sleep_for_retry(self, retry_after: Optional[float]) -> None:
        if retry_after is None:
            return
        time.sleep(max(0.0, float(retry_after)))
