class StreamEvent:
    pass