#!/usr/bin/env python3
"""Classify user messages and inject MemoryMaster routing hints.

Mirrors the obsidian-mind classify-message.py pattern but adapted for the
coding-agent use case: instead of routing to vault folders, routes to
MemoryMaster claim_types (decision, gotcha, constraint, architecture, bug,
environment, reference).

Data-driven regex signal matching with Latin-letter lookarounds
(?<![a-zA-Z]) instead of \\b — safe for mixed Spanish/English technical
text. Zero LLM calls, zero external deps, ~5ms runtime.

Output: hookSpecificOutput.additionalContext with routing hints.
Claude reads them and decides whether to call ingest_claim.
"""
import json
import os
import sys
import re
from datetime import datetime


def _log(event, **kw):
    """Minimal inline hook logger (no stdlib-external deps; stays ~5ms)."""
    try:
        log_dir = os.path.join(os.path.expanduser("~"), ".memorymaster", "hook_state")
        os.makedirs(log_dir, exist_ok=True)
        parts = [f"[{datetime.now().strftime('%H:%M:%S')}] hook=classify event={event}"]
        for k, v in kw.items():
            if v is None:
                continue
            parts.append(f"{k}={v}")
        with open(os.path.join(log_dir, "hook.log"), "a", encoding="utf-8") as fh:
            fh.write(" ".join(parts) + "\n")
    except Exception:
        pass


SIGNALS = [
    {
        "name": "DECISION",
        "message": (
            "DECISION detected — if this is a durable architectural/design "
            "decision, call mcp__memorymaster__ingest_claim with "
            "claim_type='decision', source_agent='claude-session'."
        ),
        "patterns": [
            # English
            "decided", "decision", "we chose", "we picked", "going with",
            "the call is", "we're going with", "agreed to", "agreed on",
            "let's go with", "final answer", "settled on",
            # Spanish (Argentina)
            "decidimos", "decidí", "elegimos", "vamos con", "nos quedamos con",
            "la decisión es", "la decision es", "quedó que", "quedo que",
            "acordamos", "zanjamos", "se definio", "se definió", "definimos",
            # Negative-decision (we are NOT going to do X) — durable "no-go"
            "no vamos a", "no lo vamos a", "olvidate", "olvidá",
            # Imperative command form signals a choice being made
            "más vale", "mas vale",
        ],
    },
    {
        "name": "BUG_ROOT_CAUSE",
        "message": (
            "BUG ROOT CAUSE detected — after fixing, call ingest_claim with "
            "claim_type='bug' and describe the root cause (not the fix) so "
            "future sessions avoid re-debugging it."
        ),
        "patterns": [
            # English — root-cause phrasing
            "root cause", "the bug is", "the bug was", "turned out to be",
            "was caused by", "is caused by", "fails because",
            "broken because", "regression", "was due to",
            # English — bug-report phrasing (user describing a failure)
            "dont work", "don't work", "doesn't work", "doesnt work",
            "not working", "is broken", "are broken",
            "help me debug", "debug this", "having an issue",
            "dropping error", "throwing error", "throws error", "throwing a",
            # HTTP error codes inside a bug description
            "429 error", "500 error", "502 error", "503 error", "504 error",
            "404 error", "400 error",
            # Spanish
            "la causa es", "la causa era", "el problema es", "el problema era",
            "se rompe cuando", "se rompia cuando", "se rompía cuando",
            "fallaba porque", "falla porque", "fue por", "era por",
            "el bug es", "el bug era", "resulta que",
            # Spanish — bug-report phrasing
            "no anda", "no funciona", "no andaba", "no funcionaba",
            "tira error", "tira eso", "sigue fallando", "se rompió",
            "se rompio", "está roto", "esta roto",
        ],
    },
    {
        "name": "GOTCHA",
        "message": (
            "GOTCHA detected — non-obvious trap worth remembering. Call "
            "ingest_claim with claim_type='gotcha', volatility='low'."
        ),
        "patterns": [
            # English
            "gotcha", "watch out", "be careful", "heads up", "caveat",
            "the trick is", "the catch is", "beware", "footgun",
            "silently fails", "silent failure", "surprising behavior",
            # Spanish
            "ojo con", "cuidado con", "cuidado que", "el truco es",
            "la trampa es", "atenti", "atención que", "atencion que",
            "no es obvio", "sorprendentemente", "silenciosamente",
            "falla en silencio",
        ],
    },
    {
        "name": "CONSTRAINT",
        "message": (
            "CONSTRAINT detected — hard limit or requirement. Call "
            "ingest_claim with claim_type='constraint' so future sessions "
            "respect it."
        ),
        "patterns": [
            # English
            "must not", "cannot", "can't", "never", "always", "required to",
            "requires", "mandatory", "forbidden", "not allowed", "only if",
            "only when", "must be", "has to be", "limited to",
            # English — numeric/technical limits (specs & rate limits).
            # Specific trailing colon/phrasing to avoid rhetorical matches.
            "rate limits:", "rate-limits:", "free tier limits",
            "hard limit", "soft limit", "token limits:",
            "requests per minute", "requests per day",
            "tokens per minute",
            # Spanish
            "no puede", "nunca", "siempre", "obligatorio",
            "obligatoria", "prohibido", "requiere", "tiene que", "debe ser",
            "debe estar", "no permitido", "solo si", "sólo si", "sólo cuando",
            "solo cuando", "limitado a",
            # Spanish — negated capabilities ("we don't have X", hard block).
            # Specific object heads (llave, acceso, permiso) avoid matching
            # idioms like "no tenemos nada que perder".
            "no tenemos llave", "no tenemos acceso",
            "no tenemos permiso", "no tenemos permisos",
            "no tenemos api", "sin llave", "no hay forma",
            # Explicit "we won't install X" is both decision & constraint
            "no lo instalamos", "no la instalamos",
        ],
    },
    {
        "name": "ARCHITECTURE",
        "message": (
            "ARCHITECTURE discussion detected — call "
            "mcp__memorymaster__query_memory BEFORE deciding, then "
            "ingest_claim with claim_type='architecture' after."
        ),
        "patterns": [
            # English
            "architecture", "system design", "refactor", "restructure",
            "rewrite", "data flow", "module boundary", "separation of concerns",
            "adr", "design doc", "trade-off", "tradeoff",
            # English — concrete architectural components
            "mcp server", "json-rpc", "stdio json", "knowledge base",
            "orchestrator", "vault structure", "exposes tools",
            "exposes 6 tools", "multi-session", "cross-session",
            # Spanish
            "arquitectura", "diseño del sistema", "diseno del sistema",
            "estructura", "refactor", "reescribir", "reestructurar",
            "separación", "separacion", "acoplamiento", "flujo de datos",
            "módulo", "modulo", "límites", "limites",
        ],
    },
    {
        "name": "ENVIRONMENT",
        "message": (
            "ENVIRONMENT/SETUP detected — install steps, env vars, config "
            "quirks. Call ingest_claim with claim_type='environment' so "
            "setup pain is documented."
        ),
        "patterns": [
            # English
            "env var", "environment variable", ".env", "export ",
            "install", "installing", "configure",
            "configuration", "path issue", "venv", "virtualenv",
            "dependency", "pip install", "npm install",
            # English — model/runtime switches (coding-agent specific)
            "using model", "using the model", "using opus", "using sonnet",
            "using haiku", "using gemini", "using gpt",
            "switched to", "switch model", "claude desktop",
            # Spanish
            "variable de entorno", "instalación", "instalacion",
            "configurar", "configuración", "configuracion", "entorno",
            "dependencia", "problema de path",
            # Spanish — model/runtime switches
            "usando el modelo", "estamos usando", "cambiamos al modelo",
            "cambié al modelo", "cambie al modelo",
            # MCP/agent runtime config changes
            "agregar mcp", "sacar el mcp", "agregar memorymaster",
        ],
    },
    {
        "name": "REFERENCE",
        "message": (
            "REFERENCE detected — docs/URL/paper/repo worth remembering. "
            "Call ingest_claim with claim_type='reference' and include the "
            "source in sources_json."
        ),
        "patterns": [
            # English
            "see the docs", "check the docs", "documentation says",
            "according to", "per the spec", "as documented",
            "github.com/", "https://", "http://",
            # Spanish
            "según la doc", "segun la doc", "según el", "segun el",
            "la doc dice", "documentación", "documentacion",
        ],
    },
]


def _any_word_match(pattern_words: list, text: str) -> bool:
    """Check if any phrase appears as a whole word/phrase.

    Conditional Latin-letter lookarounds: add (?<![a-zA-Z]) only if the
    phrase STARTS with a letter, and (?![a-zA-Z]) only if it ENDS with a
    letter. This prevents URL/symbol phrases like "https://" or
    "github.com/" from failing the right boundary when followed by a
    letter ("https://github..." — the 'g' after '/' used to block the
    match). Still safe for plain English keywords like "decided" /
    "cannot" — they have letter edges so both lookarounds apply.
    """
    for phrase in pattern_words:
        if not phrase:
            continue
        left = r'(?<![a-zA-Z])' if phrase[0].isalpha() else ''
        right = r'(?![a-zA-Z])' if phrase[-1].isalpha() else ''
        pat = left + re.escape(phrase) + right
        if re.search(pat, text, re.IGNORECASE):
            return True
    return False


# Meta-prompt wrappers injected by the Claude CLI that should NOT be
# classified (they're control messages, not user intent).
_META_STRIP_RE = re.compile(
    r'<local-command-caveat>.*?</local-command-caveat>',
    re.IGNORECASE | re.DOTALL,
)


def _strip_meta(text: str) -> str:
    """Remove Claude CLI meta-prompt wrappers before classification."""
    return _META_STRIP_RE.sub(' ', text)


def classify(prompt: str) -> list:
    cleaned = _strip_meta(prompt)
    signals = []
    for sig in SIGNALS:
        if _any_word_match(sig["patterns"], cleaned):
            signals.append((sig["name"], sig["message"]))
    return signals


def main():
    try:
        input_data = json.loads(sys.stdin.read() or "{}")
    except (ValueError, OSError):
        sys.exit(0)

    prompt = input_data.get("prompt", "")
    if not isinstance(prompt, str) or len(prompt) < 5:
        _log("skip", reason="short-prompt", chars=len(prompt) if isinstance(prompt, str) else 0)
        sys.exit(0)

    try:
        signals = classify(prompt)
    except Exception as e:
        _log("error", message=str(e)[:200])
        sys.exit(0)

    if not signals:
        _log("no-match", chars=len(prompt))
        sys.exit(0)

    _log("matched", count=len(signals), names=",".join(n for n, _ in signals))

    hints = "\n".join(f"- [{name}] {msg}" for name, msg in signals)
    output = {
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": (
                "[MemoryMaster routing hints]\n"
                "The user's message contains signals. If the content is durable "
                "and non-obvious, consider calling ingest_claim AFTER doing the work:\n"
                + hints
                + "\n\nNever ingest credentials, IPs, tokens, or raw code."
            ),
        }
    }
    sys.stdout.write(json.dumps(output))
    sys.stdout.flush()
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(0)
