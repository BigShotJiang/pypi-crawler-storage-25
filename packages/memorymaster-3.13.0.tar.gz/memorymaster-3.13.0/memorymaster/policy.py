from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime, timezone

from memorymaster.config import get_config
from memorymaster.models import Claim

POLICY_MODES = ("legacy", "cadence")


def _env_mode_override() -> str | None:
    """Read ``MEMORYMASTER_POLICY_MODE`` env var, return a valid mode or None.

    Lets operators opt into proactive cadence-based revalidation without
    editing the six callers that hardcode ``policy_mode='legacy'`` as the
    default. An unset or invalid value is ignored so existing behavior is
    preserved.
    """
    value = os.environ.get("MEMORYMASTER_POLICY_MODE", "").strip().lower()
    if value in POLICY_MODES:
        return value
    return None

_CLAIM_TYPE_MULTIPLIER = {
    "security_fact": 0.5,
    "infra_fact": 0.7,
    "filesystem_fact": 1.0,
}

_STATE_MULTIPLIER = {
    "confirmed": 1.0,
    "stale": 0.55,
    "conflicted": 0.35,
}


@dataclass(slots=True)
class RevalidationSelection:
    mode: str
    considered: int
    due: int
    selected: list[Claim]


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        return None


def _base_cadence_hours(claim: Claim) -> float:
    cadence = get_config().cadence_hours
    base = cadence.get(claim.volatility, cadence["medium"])
    type_mult = _CLAIM_TYPE_MULTIPLIER.get(claim.claim_type or "", 1.0)
    state_mult = _STATE_MULTIPLIER.get(claim.status, 1.0)
    return max(1.0, base * type_mult * state_mult)


def _age_seconds(claim: Claim, now: datetime) -> float:
    anchor = _parse_iso(claim.last_validated_at) or _parse_iso(claim.updated_at) or _parse_iso(claim.created_at)
    if anchor is None:
        return 0.0
    return max(0.0, (now - anchor).total_seconds())


def _priority_score(claim: Claim, age_seconds: float, cadence_seconds: float) -> float:
    overdue_ratio = age_seconds / max(1.0, cadence_seconds)
    status_bonus = 0.25 if claim.status == "stale" else (0.4 if claim.status == "conflicted" else 0.0)
    confidence_bonus = (1.0 - max(0.0, min(1.0, claim.confidence))) * 0.2
    volatility_bonus = 0.2 if claim.volatility == "high" else (0.1 if claim.volatility == "medium" else 0.0)
    return overdue_ratio + status_bonus + confidence_bonus + volatility_bonus


def select_revalidation_candidates(
    store,
    *,
    mode: str = "legacy",
    limit: int = 200,
) -> RevalidationSelection:
    # Operators can flip the six hardcoded ``legacy`` defaults at runtime by
    # setting MEMORYMASTER_POLICY_MODE=cadence. If the caller passed an
    # explicit mode (anything non-legacy), honor it; only override the
    # default-legacy path so this never clobbers deliberate choices.
    if mode == "legacy":
        override = _env_mode_override()
        if override is not None:
            mode = override
    if mode not in POLICY_MODES:
        raise ValueError(f"Unknown policy mode: {mode}")
    if mode == "legacy":
        return RevalidationSelection(mode=mode, considered=0, due=0, selected=[])
    if limit <= 0:
        return RevalidationSelection(mode=mode, considered=0, due=0, selected=[])

    fetch_limit = max(limit * 4, 200)
    pool = store.list_claims(
        status_in=["confirmed", "stale", "conflicted"],
        limit=fetch_limit,
        include_archived=False,
        include_citations=False,
    )

    now = datetime.now(timezone.utc)
    due_rows: list[tuple[float, Claim]] = []

    for claim in pool:
        cadence_seconds = _base_cadence_hours(claim) * 3600.0
        age_seconds = _age_seconds(claim, now)
        if age_seconds < cadence_seconds:
            continue
        score = _priority_score(claim, age_seconds, cadence_seconds)
        due_rows.append((score, claim))

    due_rows.sort(
        key=lambda row: (
            row[0],
            row[1].pinned,
            row[1].confidence,
            row[1].updated_at,
            row[1].id,
        ),
        reverse=True,
    )
    selected = [claim for _, claim in due_rows[:limit]]
    return RevalidationSelection(mode=mode, considered=len(pool), due=len(due_rows), selected=selected)
