---
title: Configuration
nav_order: 2
---

Configuration is optional. Create `rockgarden.toml` in your project root to customize behavior.

## Site

```toml
[site]
title = "My Site"     # Page title suffix
source = "."          # Source directory
output = "_site"      # Output directory
clean_urls = true     # Use /path/ instead of /path.html (default: true)
```

### Clean URLs

When `clean_urls = true` (the default):
- Pages output to directories: `about.md` → `about/index.html`
- URLs use trailing slashes: `/about/`
- Links in content transform: `[text](page.md)` → `[text](page/)`

When `clean_urls = false`:
- Pages output as files: `about.md` → `about.html`
- URLs use `.html` extension: `/about.html`
- Links in content transform: `[text](page.md)` → `[text](page.html)`

Index pages (`index.md`) always output as `index.html` in their folder.

## Build

```toml
[build]
ignore_patterns = [
    ".obsidian",      # Ignored by default
    "private",
    "templates",
    "Templates",
]
```

Ignored paths are completely excluded from the build.

## Navigation

```toml
[nav]
default_state = "collapsed"   # or "expanded"
sort = "files-first"          # "folders-first", "alphabetical"
hide = ["/drafts", "/private"]
labels = { "/api" = "API Reference" }
```

See [[Navigation]] for details.

## Theme

```toml
[theme]
name = ""                        # Custom theme directory (empty = built-in)
daisyui_default = "light"        # Default DaisyUI theme
daisyui_themes = ["light", "dark", "cupcake", "cyberpunk"]  # Theme switcher options
```

When `daisyui_themes` is set, a theme switcher dropdown appears. When omitted, a simple dark/light toggle is shown.

## Frontmatter

Page-level options in YAML frontmatter:

```yaml
---
title: Page Title     # Used in nav and <title>
slug: custom-slug     # Override generated URL slug
nav_order: 1          # Pin position in nav (lower = first)
tags: [doc, guide]    # Shown in folder listings
unlisted: true        # Hide from nav (URL still works)
---
```

`unlisted: true` on an `index.md` or folder-note keeps the page at `/folder/` reachable by URL but removes the nav link to it; the folder itself stays in nav with its children.

### Folder Metadata (`_folder.md`)

Per-folder options live in an optional `_folder.md` file inside the folder. Frontmatter only — body is ignored. The file is not published as a page.

```yaml
---
nav_order: 2           # Pin folder in parent nav
label: My Folder       # Folder display label override
sort: alphabetical     # Child sort strategy
sort_reverse: false
unlisted: true         # Hide folder (and descendants) from nav
show_index: true       # Use auto-listing at /folder/ even if index.md exists
---
```

See [[Navigation]] for full details.

### Folder Index Pages

A folder is served at `/folder/` when it contains any of:

| Scenario | Result at `/folder/` |
|----------|----------------------|
| Nothing | Auto-generated folder listing |
| `index.md` | `index.md` renders as a normal page |
| Folder-note (`folder/folder.md`) | Equivalent to `index.md` — same URL |
| `_folder.md` with `show_index: true` and `index.md` | Auto-listing with `index.md` body as prose prefix |

## URL Slugs

Rockgarden generates URL-safe slugs from filenames:

| Filename | Generated Slug |
|----------|----------------|
| `Getting Started.md` | `getting-started` |
| `NPCs/Olvir the Wise.md` | `npcs/olvir-the-wise` |
| `my_page.md` | `my-page` |

Slug rules:
- Lowercase the entire path
- Replace spaces and underscores with dashes
- Preserve directory structure

Override the generated slug with frontmatter:

```yaml
---
title: Getting Started
slug: quickstart
---
```

This produces `/quickstart/` instead of `/getting-started/`. Use this as the escape hatch to place a page literally at `/folder/folder/` (bypassing the folder-note rewrite).

## CLI Overrides

CLI flags override config file values:

```bash
rockgarden build --source ./vault --output ./dist
rockgarden serve --port 3000
```
