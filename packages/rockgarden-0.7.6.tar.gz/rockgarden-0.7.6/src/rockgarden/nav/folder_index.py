"""Folder index page generation."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from rockgarden.config import NavConfig
from rockgarden.content import FolderMeta, Page
from rockgarden.nav.labels import resolve_label
from rockgarden.nav.sort import resolve_sort
from rockgarden.urls import get_folder_url, get_url


@dataclass
class FolderChild:
    """A child item in a folder listing."""

    title: str
    subtitle: str
    path: str
    is_folder: bool
    modified: datetime | None = None
    tags: list[str] = field(default_factory=list)
    nav_order: int | None = None


@dataclass
class FolderIndex:
    """Data for rendering a folder index page."""

    slug: str
    title: str
    children: list[FolderChild]
    custom_content: str | None = None
    frontmatter: dict = field(default_factory=dict)


def find_folders(pages: list[Page]) -> set[str]:
    """Find all folder paths that need index pages, including root."""
    folders: set[str] = set()

    if pages:
        folders.add("")

    for page in pages:
        parts = page.slug.split("/")
        if len(parts) > 1:
            for i in range(1, len(parts)):
                folder_path = "/".join(parts[:i])
                folders.add(folder_path)

    return folders


def generate_folder_indexes(
    pages: list[Page],
    config: NavConfig | None = None,
    clean_urls: bool = True,
    base_path: str = "",
    site_title: str = "",
    folder_metas: dict[str, FolderMeta] | None = None,
) -> list[FolderIndex]:
    """Generate folder index data for all folders.

    Args:
        pages: All pages from the content store
        config: Navigation config for hide patterns and labels
        clean_urls: If True, use /path/ instead of /path/index.html
        site_title: Site title used as the root index title fallback
        folder_metas: Optional dict of folder-path → FolderMeta (from
            `_folder.md` files). Controls folder unlisting and label.

    Returns:
        List of FolderIndex objects for folders that need generated indexes
    """
    if config is None:
        config = NavConfig()
    if folder_metas is None:
        folder_metas = {}

    folders = find_folders(pages)

    existing_indexes: dict[str, Page] = {}
    for page in pages:
        parts = page.slug.split("/")
        if parts[-1] == "index":
            folder_path = "/".join(parts[:-1])
            existing_indexes[folder_path] = page

    folder_indexes: list[FolderIndex] = []

    for folder_path in sorted(folders):
        if _should_hide(folder_path, config.hide):
            continue
        folder_meta = folder_metas.get(folder_path)
        if folder_meta and folder_meta.unlisted:
            continue

        children = _get_folder_children(
            folder_path, pages, config, clean_urls, base_path, folder_metas
        )

        if folder_path in existing_indexes:
            index_page = existing_indexes[folder_path]
            title = index_page.title
            custom_content = index_page.content
            frontmatter = index_page.frontmatter
        else:
            folder_name = folder_path.split("/")[-1]
            title = resolve_label(
                folder_path, folder_name, config.labels, folder_metas, existing_indexes
            )
            if not title and not folder_path:
                title = site_title or "Home"
            custom_content = None
            frontmatter = {}

        folder_indexes.append(
            FolderIndex(
                slug=f"{folder_path}/index" if folder_path else "index",
                title=title,
                children=children,
                custom_content=custom_content,
                frontmatter=frontmatter,
            )
        )

    return folder_indexes


def _should_hide(path: str, hide_patterns: list[str]) -> bool:
    """Check if a path should be hidden."""
    from fnmatch import fnmatch

    for pattern in hide_patterns:
        normalized_pattern = pattern.strip("/")
        normalized_path = path.strip("/")
        if fnmatch(normalized_path, normalized_pattern):
            return True
        if normalized_path.startswith(f"{normalized_pattern}/"):
            return True
    return False


def _sort_folder_children(
    children: list[FolderChild], sort_strategy: str, reverse: bool = False
) -> list[FolderChild]:
    """Sort folder children by nav_order (pinned first) then by strategy."""
    pinned = [c for c in children if c.nav_order is not None]
    unpinned = [c for c in children if c.nav_order is None]

    pinned.sort(key=lambda c: (c.nav_order, c.title.lower()))

    if sort_strategy == "date":
        # Sort by modified date; items with no date sort last
        _none_date = datetime.max
        unpinned = sorted(unpinned, key=lambda c: c.modified or _none_date)
    elif sort_strategy == "folders-first":
        folders = sorted(
            [c for c in unpinned if c.is_folder], key=lambda c: c.title.lower()
        )
        files = sorted(
            [c for c in unpinned if not c.is_folder], key=lambda c: c.title.lower()
        )
        unpinned = folders + files
    elif sort_strategy == "alphabetical":
        unpinned = sorted(unpinned, key=lambda c: c.title.lower())
    else:  # files-first (default)
        files = sorted(
            [c for c in unpinned if not c.is_folder], key=lambda c: c.title.lower()
        )
        folders = sorted(
            [c for c in unpinned if c.is_folder], key=lambda c: c.title.lower()
        )
        unpinned = files + folders

    if reverse:
        unpinned.reverse()

    return pinned + unpinned


def _get_folder_children(
    folder_path: str,
    pages: list[Page],
    config: NavConfig,
    clean_urls: bool = True,
    base_path: str = "",
    folder_metas: dict[str, FolderMeta] | None = None,
) -> list[FolderChild]:
    """Get direct children of a folder."""
    if folder_metas is None:
        folder_metas = {}

    children: list[FolderChild] = []
    seen_subfolders: set[str] = set()

    folder_index_pages: dict[str, Page] = {}
    for page in pages:
        parts = page.slug.split("/")
        if parts[-1] == "index":
            idx_folder_path = "/".join(parts[:-1])
            folder_index_pages[idx_folder_path] = page

    prefix = f"{folder_path}/" if folder_path else ""

    for page in pages:
        if not page.slug.startswith(prefix):
            continue

        relative = page.slug[len(prefix) :]
        if not relative:
            continue

        parts = relative.split("/")

        if len(parts) == 1:
            if parts[0] == "index":
                continue
            if _should_hide(page.slug, config.hide) or page.frontmatter.get(
                "unlisted", False
            ):
                continue

            modified = None
            if page.source_path.exists():
                modified = datetime.fromtimestamp(page.source_path.stat().st_mtime)

            children.append(
                FolderChild(
                    title=page.title,
                    subtitle=page.frontmatter.get("subtitle", ""),
                    path=get_url(page.slug, clean_urls, base_path),
                    is_folder=False,
                    modified=modified,
                    tags=page.frontmatter.get("tags", []),
                    nav_order=page.frontmatter.get("nav_order"),
                )
            )
        else:
            subfolder = parts[0]
            subfolder_path = f"{prefix}{subfolder}" if prefix else subfolder

            if subfolder_path not in seen_subfolders:
                if _should_hide(subfolder_path, config.hide):
                    continue
                subfolder_meta = folder_metas.get(subfolder_path)
                if subfolder_meta and subfolder_meta.unlisted:
                    continue

                seen_subfolders.add(subfolder_path)
                label = resolve_label(
                    subfolder_path,
                    subfolder,
                    config.labels,
                    folder_metas,
                    folder_index_pages,
                )

                nav_order = None
                if subfolder_path in folder_metas:
                    nav_order = folder_metas[subfolder_path].nav_order

                children.append(
                    FolderChild(
                        title=label,
                        subtitle="",
                        path=get_folder_url(subfolder_path, clean_urls, base_path),
                        is_folder=True,
                        nav_order=nav_order,
                    )
                )

    folder_fm = (
        folder_metas[folder_path].frontmatter if folder_path in folder_metas else None
    )
    resolved = resolve_sort(folder_path, config, folder_fm)
    return _sort_folder_children(children, resolved.sort, resolved.reverse)
