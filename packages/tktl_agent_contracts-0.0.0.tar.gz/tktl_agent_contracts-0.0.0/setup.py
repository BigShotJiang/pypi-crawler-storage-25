from setuptools import setup
setup(
    name="tktl_agent_contracts",
    version="0.0.0",
    py_modules=[],
)
