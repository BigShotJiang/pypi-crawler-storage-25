import argparse
import os

from mira_core.analyzer import analyze_target
from mira_core.commands import run_mira_command
from mira_core.generator import generate_outputs


def main():
    parser = argparse.ArgumentParser(description="MIRA - LLM Context Transpiler")
    parser.add_argument("entry", nargs="?", default=".", help="Target path, 'build', or a !command")
    parser.add_argument("extra", nargs=argparse.REMAINDER, help="Additional arguments for builds or !commands")
    args = parser.parse_args()

    entry = args.entry
    if entry.startswith("!"):
        raise SystemExit(run_mira_command(os.getcwd(), entry, args.extra))

    if entry == "build":
        target_path = os.path.abspath(args.extra[0] if args.extra else ".")
    else:
        target_path = os.path.abspath(entry)

    print(f"Analyzing {target_path}...")
    project_data = analyze_target(target_path)

    print("Generating MIRA output...")
    generate_outputs(target_path, project_data)
    print("Done! Check the .mira directory.")