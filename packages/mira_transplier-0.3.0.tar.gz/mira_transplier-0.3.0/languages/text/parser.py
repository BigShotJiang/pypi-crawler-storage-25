from languages.base import BaseParser
from languages.document_utils import build_document_metadata, summarize_text_structure


class TextParser(BaseParser):
    def parse(self, file_path):
        return build_document_metadata(file_path, "text", summarize_text_structure())