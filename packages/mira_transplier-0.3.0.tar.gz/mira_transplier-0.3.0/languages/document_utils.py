import json
import os


DOCUMENT_RETRIEVAL_CHAR_LIMIT = 10000
DOCUMENT_SECTION_CHAR_TARGET = 8000
DOCUMENT_SECTION_LINE_TARGET = 200
JSON_PARSE_LIMIT_BYTES = 5 * 1024 * 1024
JSONL_SAMPLE_LIMIT = 50
KEY_SUMMARY_LIMIT = 24


def build_document_metadata(file_path, language, structure_lines, origin="manual_or_external"):
    byte_size = os.path.getsize(file_path)
    total_lines, sections = build_document_sections(file_path)
    return {
        "language": language,
        "file_kind": "document",
        "storage_mode": "metadata-only",
        "retrieval_char_limit": DOCUMENT_RETRIEVAL_CHAR_LIMIT,
        "byte_size": byte_size,
        "total_lines": total_lines,
        "source_signature": build_source_signature(file_path, byte_size),
        "document_structure": list(structure_lines),
        "origin": origin,
        "global_variables": {},
        "imports": [],
        "classes": {},
        "functions": {},
        "sections": sections,
    }


def build_document_sections(file_path, label_prefix="section"):
    sections = []
    total_lines = 0
    section_start = 1
    section_chars = 0
    section_line_count = 0

    with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            total_lines += 1
            section_chars += len(line)
            section_line_count += 1

            if section_chars >= DOCUMENT_SECTION_CHAR_TARGET or section_line_count >= DOCUMENT_SECTION_LINE_TARGET:
                sections.append(_make_section(label_prefix, section_start, total_lines, section_chars))
                section_start = total_lines + 1
                section_chars = 0
                section_line_count = 0

    if total_lines and section_start <= total_lines:
        sections.append(_make_section(label_prefix, section_start, total_lines, section_chars))

    return total_lines, sections


def summarize_text_structure():
    return ["format: text", "origin: manual_or_external"]


def summarize_json_structure(file_path):
    lines = ["format: json", "origin: manual_or_external"]
    byte_size = os.path.getsize(file_path)
    if byte_size > JSON_PARSE_LIMIT_BYTES:
        lines.append(f"structure omitted: file larger than {JSON_PARSE_LIMIT_BYTES} bytes")
        return lines

    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
            payload = json.load(handle)
    except Exception as error:
        lines.append(f"parse summary unavailable: {error.__class__.__name__}")
        return lines

    if isinstance(payload, dict):
        keys = sorted(payload)
        lines.append(f"top-level type: object ({len(keys)} keys)")
        lines.append(f"top-level keys: {_summarize_values(keys)}")
        container_keys = [key for key, value in payload.items() if isinstance(value, (dict, list))]
        if container_keys:
            lines.append(f"container keys: {_summarize_values(sorted(container_keys))}")
        return lines

    if isinstance(payload, list):
        lines.append(f"top-level type: array ({len(payload)} items)")
        object_items = [item for item in payload[:KEY_SUMMARY_LIMIT] if isinstance(item, dict)]
        if object_items:
            union_keys = sorted({key for item in object_items for key in item})
            lines.append(f"sample object keys: {_summarize_values(union_keys)}")
        return lines

    lines.append(f"top-level type: {type(payload).__name__}")
    return lines


def summarize_jsonl_structure(file_path):
    lines = ["format: jsonl", "origin: manual_or_external"]
    sampled_rows = 0
    object_rows = 0
    invalid_rows = 0
    common_keys = None
    union_keys = set()

    with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
        for raw_line in handle:
            stripped = raw_line.strip()
            if not stripped:
                continue
            sampled_rows += 1
            if sampled_rows > JSONL_SAMPLE_LIMIT:
                break
            try:
                payload = json.loads(stripped)
            except Exception:
                invalid_rows += 1
                continue
            if not isinstance(payload, dict):
                continue
            object_rows += 1
            keys = set(payload)
            union_keys.update(keys)
            common_keys = keys if common_keys is None else common_keys & keys

    lines.append(f"sampled rows: {sampled_rows}")
    if object_rows:
        lines.append(f"sample object rows: {object_rows}")
        if common_keys:
            lines.append(f"common keys: {_summarize_values(sorted(common_keys))}")
        if union_keys:
            lines.append(f"union keys: {_summarize_values(sorted(union_keys))}")
    if invalid_rows:
        lines.append(f"invalid sampled rows: {invalid_rows}")
    return lines


def build_source_signature(file_path, byte_size=None):
    stat = os.stat(file_path)
    return {
        "size": byte_size if byte_size is not None else stat.st_size,
        "mtime_ns": getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)),
    }


def _make_section(label_prefix, start_line, end_line, char_count):
    return {
        "label": f"{label_prefix} lines {start_line}-{end_line}",
        "start": start_line,
        "end": end_line,
        "char_count": char_count,
        "members": [],
    }


def _summarize_values(values):
    if not values:
        return "none"
    visible = values[:KEY_SUMMARY_LIMIT]
    suffix = f" +{len(values) - len(visible)} more" if len(values) > len(visible) else ""
    return ", ".join(visible) + suffix