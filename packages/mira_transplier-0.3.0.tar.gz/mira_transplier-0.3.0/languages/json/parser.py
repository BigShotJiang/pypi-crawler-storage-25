from languages.base import BaseParser
from languages.document_utils import build_document_metadata, summarize_json_structure, summarize_jsonl_structure


class JsonParser(BaseParser):
    def __init__(self, language):
        self.language = language

    def parse(self, file_path):
        if self.language == "jsonl":
            structure = summarize_jsonl_structure(file_path)
        else:
            structure = summarize_json_structure(file_path)
        return build_document_metadata(file_path, self.language, structure)