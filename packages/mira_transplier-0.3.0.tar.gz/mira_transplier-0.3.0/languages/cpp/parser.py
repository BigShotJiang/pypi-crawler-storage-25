import os
import re

from languages.base import BaseParser


CPP_BLOCK_KEYWORDS = {"if", "for", "while", "switch", "catch", "return", "else", "case"}
CPP_CALL_KEYWORDS = CPP_BLOCK_KEYWORDS | {
    "sizeof",
    "alignof",
    "decltype",
    "static_cast",
    "dynamic_cast",
    "reinterpret_cast",
    "const_cast",
    "new",
    "delete",
    "throw",
}
CPP_BUILTIN_TYPES = {
    "bool",
    "char",
    "double",
    "float",
    "int",
    "long",
    "short",
    "signed",
    "size_t",
    "std::size_t",
    "unsigned",
    "void",
    "wchar_t",
}


class CppParser(BaseParser):
    def parse(self, file_path):
        with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
            source_lines = handle.readlines()

        builder = _CppMetadataBuilder(source_lines)
        builder.parse()
        return builder.to_metadata(file_path)


class _CppMetadataBuilder:
    def __init__(self, source_lines):
        self.source_lines = source_lines
        self.includes = []
        self.classes = {}
        self.functions = {}

    def parse(self):
        self._collect_includes()
        self._parse_range(1, len(self.source_lines), namespace_parts=[])

    def to_metadata(self, file_path):
        return {
            "language": "cpp",
            "global_variables": {},
            "imports": self.includes,
            "classes": self.classes,
            "functions": self.functions,
            "symbols": self._build_symbols(),
            "source_signature": _build_source_signature(file_path),
        }

    def _build_symbols(self):
        symbols = []
        for qualname, function_meta in self.functions.items():
            symbols.append(
                {
                    "name": function_meta["name"],
                    "qualname": qualname,
                    "kind": function_meta["kind"],
                    "parent": function_meta.get("parent"),
                    "container_class": function_meta.get("container_class"),
                    "signature": function_meta["signature"],
                    "occupies": function_meta["occupies"],
                }
            )
        return symbols

    def _collect_includes(self):
        include_pattern = re.compile(r'^\s*#include\s*[<\"]([^>\"]+)[>\"]')
        for line_number, line in enumerate(self.source_lines, start=1):
            match = include_pattern.match(line)
            if not match:
                continue
            self.includes.append(
                {
                    "kind": "include",
                    "module": match.group(1).replace("\\", "/"),
                    "name": None,
                    "alias": None,
                    "level": 0,
                    "line": line_number,
                }
            )

    def _parse_range(self, start_line, end_line, namespace_parts, class_qualname=None):
        line_number = start_line
        while line_number <= end_line:
            raw_line = self.source_lines[line_number - 1]
            stripped = raw_line.strip()
            if not stripped or stripped.startswith("//"):
                line_number += 1
                continue

            namespace_match = re.match(r'^\s*namespace\s+([A-Za-z_][\w:]*)\s*\{', raw_line)
            if namespace_match:
                block_end = _find_matching_brace(self.source_lines, line_number)
                if block_end is None:
                    line_number += 1
                    continue
                nested_parts = [part for part in namespace_match.group(1).split("::") if part]
                self._parse_range(line_number + 1, block_end - 1, [*namespace_parts, *nested_parts], class_qualname)
                line_number = block_end + 1
                continue

            class_match = re.match(r'^\s*(class|struct)\s+([A-Za-z_][\w]*)\b', raw_line)
            if class_match:
                brace_line = _find_declaration_brace(self.source_lines, line_number, end_line)
                if brace_line is None:
                    line_number += 1
                    continue
                block_end = _find_matching_brace(self.source_lines, brace_line)
                if block_end is None:
                    line_number += 1
                    continue
                class_name = class_match.group(2)
                qualname = _join_container_name(namespace_parts, class_qualname, class_name)
                class_meta = {
                    "name": class_name,
                    "qualname": qualname,
                    "lines": {"start": line_number, "end": block_end},
                    "methods": [],
                    "children": [],
                    "parent": class_qualname,
                }
                self.classes[qualname] = class_meta
                if class_qualname and class_qualname in self.classes:
                    self.classes[class_qualname]["children"].append(qualname)
                self._parse_range(brace_line + 1, block_end - 1, namespace_parts, class_qualname=qualname)
                line_number = block_end + 1
                continue

            function_candidate = _collect_function_candidate(self.source_lines, line_number, end_line)
            if function_candidate is None:
                line_number += 1
                continue

            signature_text, brace_line, block_end = function_candidate
            parsed = _parse_function_signature(signature_text)
            if parsed is None:
                line_number += 1
                continue

            function_name, container_hint = parsed
            qualname = _normalize_cpp_name(namespace_parts, function_name)
            if class_qualname is not None and "::" not in function_name:
                qualname = f"{class_qualname}::{function_name}"

            container_class = class_qualname
            if container_class is None and container_hint is not None:
                container_class = _normalize_cpp_name(namespace_parts, container_hint)

            kind = "method" if container_class else "function"
            dependencies, returns = _collect_function_dependencies(
                self.source_lines,
                brace_line,
                block_end,
                namespace_parts,
                container_class,
            )
            function_meta = {
                "name": function_name.split("::")[-1],
                "qualname": qualname,
                "kind": kind,
                "parent": container_class,
                "container_class": container_class,
                "signature": signature_text.strip(),
                "occupies": {"start": line_number, "end": block_end},
                "dependencies": dependencies,
                "instance_bindings": dict(dependencies["instance_bindings"]),
                "returns": returns,
                "children": [],
            }
            self.functions[qualname] = function_meta
            if container_class and container_class in self.classes:
                methods = self.classes[container_class]["methods"]
                if qualname not in methods:
                    methods.append(qualname)
            line_number = block_end + 1


def _collect_function_candidate(source_lines, start_line, end_line):
    signature_parts = []
    current_line = start_line
    saw_paren = False
    paren_depth = 0

    while current_line <= end_line and current_line - start_line < 20:
        raw_line = source_lines[current_line - 1]
        stripped = raw_line.strip()
        if not stripped:
            if signature_parts:
                signature_parts.append(stripped)
            current_line += 1
            continue
        if stripped.startswith("#"):
            return None

        signature_parts.append(stripped)
        paren_depth += stripped.count("(") - stripped.count(")")
        if "(" in stripped:
            saw_paren = True
        if saw_paren and paren_depth <= 0 and "{" in stripped:
            block_end = _find_matching_brace(source_lines, current_line)
            if block_end is None:
                return None
            return " ".join(part for part in signature_parts if part), current_line, block_end
        if ";" in stripped and paren_depth <= 0:
            return None
        current_line += 1
    return None


def _parse_function_signature(signature_text):
    normalized = re.sub(r'\s+', ' ', signature_text).strip()
    if normalized.startswith("template "):
        return None
    lowered = normalized.split("(", 1)[0].strip().split()
    if lowered and lowered[-1] in CPP_BLOCK_KEYWORDS:
        return None
    if normalized.startswith(("class ", "struct ", "namespace ")):
        return None

    head = normalized.split("(", 1)[0].strip()
    match = re.search(r'([A-Za-z_~][\w:]*)\s*$', head)
    if match is None:
        return None

    full_name = match.group(1)
    if full_name in CPP_BLOCK_KEYWORDS:
        return None
    container_class = full_name.rsplit("::", 1)[0] if "::" in full_name else None
    return full_name, container_class


def _collect_function_dependencies(source_lines, brace_line, block_end, namespace_parts, container_class):
    instance_bindings = {}
    if container_class:
        instance_bindings["this"] = container_class

    calls = []
    returns = []
    seen_calls = set()

    for line_number in range(brace_line, block_end + 1):
        line = _strip_line_comments(source_lines[line_number - 1])
        if not line.strip():
            continue

        for name, class_name in _collect_instance_bindings(line, namespace_parts):
            instance_bindings[name] = class_name

        return_match = re.search(r'\breturn\b\s*(.+?)\s*;', line)
        if return_match is not None:
            returned = return_match.group(1).strip()
            if returned:
                returns.append(returned)

        for call in _collect_call_details(line, line_number, namespace_parts, container_class, instance_bindings):
            call_key = (call.get("owner"), call["name"], call["line"])
            if call_key in seen_calls:
                continue
            calls.append(call)
            seen_calls.add(call_key)

    return {
        "calls": [call["name"] for call in calls],
        "calls_detailed": calls,
        "instance_bindings": instance_bindings,
    }, returns


def _collect_instance_bindings(line, namespace_parts):
    declaration_pattern = re.compile(
        r'\b(?:const\s+)?([A-Za-z_][\w:]*)\s*(?:[*&]\s*)?([A-Za-z_][\w]*)\s*(?:[=({;]|$)'
    )
    bindings = []
    for match in declaration_pattern.finditer(line):
        type_name = match.group(1)
        variable_name = match.group(2)
        if variable_name in CPP_BLOCK_KEYWORDS:
            continue
        if type_name in CPP_BUILTIN_TYPES:
            continue
        bindings.append((variable_name, _normalize_cpp_name(namespace_parts, type_name)))
    return bindings


def _collect_call_details(line, line_number, namespace_parts, container_class, instance_bindings):
    calls = []
    occupied_spans = []

    member_call_pattern = re.compile(r'(?P<owner>[A-Za-z_][\w]*)\s*(?:\.|->)\s*(?P<name>[A-Za-z_~][\w]*)\s*\(')
    scoped_call_pattern = re.compile(r'(?P<prefix>[A-Za-z_][\w:]*)::(?P<name>[A-Za-z_~][\w]*)\s*\(')
    free_call_pattern = re.compile(r'(?<![\w:])(?P<name>[A-Za-z_~][\w]*)\s*\(')

    for match in member_call_pattern.finditer(line):
        owner = match.group("owner")
        name = match.group("name")
        call = {"name": name, "line": line_number, "owner": owner}
        bound_class = instance_bindings.get(owner)
        if bound_class:
            call["qualname_hint"] = f"{bound_class}::{name}"
        calls.append(call)
        occupied_spans.append(match.span())

    for match in scoped_call_pattern.finditer(line):
        prefix = match.group("prefix")
        name = match.group("name")
        qualname_hint = _normalize_cpp_name(namespace_parts, f"{prefix}::{name}")
        calls.append({"name": name, "line": line_number, "owner": prefix, "qualname_hint": qualname_hint})
        occupied_spans.append(match.span())

    for match in free_call_pattern.finditer(line):
        name = match.group("name")
        if name in CPP_CALL_KEYWORDS:
            continue
        if any(_spans_overlap(match.span(), span) for span in occupied_spans):
            continue
        call = {"name": name, "line": line_number}
        if container_class:
            call["qualname_hint"] = f"{container_class}::{name}"
        calls.append(call)

    return calls


def _spans_overlap(first, second):
    return first[0] < second[1] and second[0] < first[1]


def _strip_line_comments(line):
    return re.sub(r'//.*$', '', line)


def _find_declaration_brace(source_lines, start_line, end_line):
    current_line = start_line
    while current_line <= end_line and current_line - start_line < 10:
        stripped = source_lines[current_line - 1].strip()
        if ";" in stripped:
            return None
        if "{" in stripped:
            return current_line
        current_line += 1
    return None


def _find_matching_brace(source_lines, brace_line):
    depth = 0
    seen_open = False
    current_line = brace_line
    while current_line <= len(source_lines):
        line = source_lines[current_line - 1]
        depth += line.count("{")
        if "{" in line:
            seen_open = True
        depth -= line.count("}")
        if seen_open and depth <= 0:
            return current_line
        current_line += 1
    return None


def _join_container_name(namespace_parts, class_qualname, name):
    if class_qualname:
        return f"{class_qualname}::{name}"
    return _normalize_cpp_name(namespace_parts, name)


def _normalize_cpp_name(namespace_parts, name):
    if not name:
        return name
    normalized_name = name.lstrip(":")
    if not namespace_parts:
        return normalized_name

    namespace_prefix = "::".join(namespace_parts)
    if "::" not in normalized_name:
        return f"{namespace_prefix}::{normalized_name}"
    if normalized_name.startswith(f"{namespace_prefix}::"):
        return normalized_name
    return f"{namespace_prefix}::{normalized_name}"


def _build_source_signature(file_path):
    stat = os.stat(file_path)
    return {
        "size": stat.st_size,
        "mtime_ns": getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)),
    }