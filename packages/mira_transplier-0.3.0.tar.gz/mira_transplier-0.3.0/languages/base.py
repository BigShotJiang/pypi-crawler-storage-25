import ast

class BaseParser:
    def parse(self, file_path):
        raise NotImplementedError()
