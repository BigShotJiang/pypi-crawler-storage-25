import ast

from languages.base import BaseParser


class PythonParser(BaseParser):
    def parse(self, file_path):
        with open(file_path, "r", encoding="utf-8") as handle:
            source = handle.read()

        tree = ast.parse(source, filename=file_path)
        builder = _PythonMetadataBuilder()
        builder.visit(tree)
        return builder.to_metadata()


class _PythonMetadataBuilder(ast.NodeVisitor):
    def __init__(self):
        self.global_variables = {}
        self.imports = []
        self.classes = {}
        self.functions = {}
        self.symbols = []
        self.name_stack = []
        self.class_stack = []
        self.symbol_stack = []

    def to_metadata(self):
        return {
            "language": "python",
            "global_variables": self.global_variables,
            "imports": self.imports,
            "classes": self.classes,
            "functions": self.functions,
            "symbols": self.symbols,
        }

    def visit_Module(self, node):
        for statement in node.body:
            self.visit(statement)

    def visit_Import(self, node):
        for alias in node.names:
            self.imports.append(
                {
                    "kind": "import",
                    "module": alias.name,
                    "name": None,
                    "alias": alias.asname,
                    "level": 0,
                    "line": node.lineno,
                }
            )

    def visit_ImportFrom(self, node):
        for alias in node.names:
            self.imports.append(
                {
                    "kind": "from",
                    "module": node.module or "",
                    "name": alias.name,
                    "alias": alias.asname,
                    "level": node.level,
                    "line": node.lineno,
                }
            )

    def visit_Assign(self, node):
        if not self.symbol_stack:
            for target in node.targets:
                self._register_global(target, node.value, node.lineno, end_line=node.end_lineno)

    def visit_AnnAssign(self, node):
        if not self.symbol_stack:
            self._register_global(node.target, node.value, node.lineno, node.annotation, node.end_lineno)

    def visit_ClassDef(self, node):
        qualname = self._current_qualname(node.name)
        class_meta = {
            "name": node.name,
            "qualname": qualname,
            "lines": {
                "start": node.lineno,
                "end": node.end_lineno,
            },
            "methods": [],
            "children": [],
            "parent": self.symbol_stack[-1] if self.symbol_stack else None,
        }
        self.classes[qualname] = class_meta
        self._register_child(qualname)

        self.name_stack.append(node.name)
        self.class_stack.append(qualname)
        self.symbol_stack.append(qualname)
        for statement in node.body:
            self.visit(statement)
        self.symbol_stack.pop()
        self.class_stack.pop()
        self.name_stack.pop()

    def visit_FunctionDef(self, node):
        self._visit_function(node, is_async=False)

    def visit_AsyncFunctionDef(self, node):
        self._visit_function(node, is_async=True)

    def _visit_function(self, node, is_async):
        qualname = self._current_qualname(node.name)
        current_class = self.class_stack[-1] if self.class_stack else None
        kind = "method" if current_class else "function"
        raw_calls = self._collect_calls(node, current_class)
        instance_bindings = self._collect_instance_bindings(node, current_class)
        function_meta = {
            "name": node.name,
            "qualname": qualname,
            "kind": kind,
            "parent": self.symbol_stack[-1] if self.symbol_stack else None,
            "container_class": current_class,
            "signature": self._build_signature(node, is_async=is_async),
            "occupies": {
                "start": node.lineno,
                "end": node.end_lineno,
            },
            "dependencies": {
                "calls": [call["name"] for call in raw_calls],
                "calls_detailed": raw_calls,
            },
            "instance_bindings": instance_bindings,
            "returns": self._collect_returns(node),
            "children": [],
        }
        self.functions[qualname] = function_meta
        self.symbols.append(
            {
                "name": node.name,
                "qualname": qualname,
                "kind": kind,
                "parent": function_meta["parent"],
                "container_class": current_class,
                "signature": function_meta["signature"],
                "occupies": function_meta["occupies"],
            }
        )
        self._register_child(qualname)
        if current_class:
            self.classes[current_class]["methods"].append(qualname)

        self.name_stack.append(node.name)
        self.symbol_stack.append(qualname)
        for statement in node.body:
            self.visit(statement)
        self.symbol_stack.pop()
        self.name_stack.pop()

    def _register_global(self, target, value, line_number, annotation=None, end_line=None):
        if not isinstance(target, ast.Name):
            return

        global_meta = {"defined": line_number, "end": end_line or line_number}
        inferred_type = self._infer_type(annotation, value)
        if inferred_type:
            global_meta["type"] = inferred_type
        self.global_variables[target.id] = global_meta

    def _register_child(self, qualname):
        if not self.symbol_stack:
            return

        parent = self.symbol_stack[-1]
        if parent in self.classes:
            self.classes[parent]["children"].append(qualname)
        elif parent in self.functions:
            self.functions[parent]["children"].append(qualname)

    def _current_qualname(self, name):
        if not self.name_stack:
            return name
        return ".".join([*self.name_stack, name])

    def _build_signature(self, node, is_async=False):
        parts = []
        positional = [*node.args.posonlyargs, *node.args.args]
        positional_defaults = [None] * (len(positional) - len(node.args.defaults)) + list(node.args.defaults)

        for index, arg in enumerate(node.args.posonlyargs):
            parts.append(self._format_argument(arg, positional_defaults[index]))
        if node.args.posonlyargs:
            parts.append("/")

        offset = len(node.args.posonlyargs)
        for index, arg in enumerate(node.args.args):
            parts.append(self._format_argument(arg, positional_defaults[offset + index]))

        if node.args.vararg:
            parts.append(self._format_argument(node.args.vararg, prefix="*"))
        elif node.args.kwonlyargs:
            parts.append("*")

        for argument, default in zip(node.args.kwonlyargs, node.args.kw_defaults):
            parts.append(self._format_argument(argument, default))

        if node.args.kwarg:
            parts.append(self._format_argument(node.args.kwarg, prefix="**"))

        signature = f"{node.name}({', '.join(parts)})"
        if node.returns:
            rendered_return = self._render_node(node.returns)
            if rendered_return:
                signature = f"{signature} -> {rendered_return}"
        if is_async:
            signature = f"async {signature}"
        return signature

    def _format_argument(self, argument, default=None, prefix=""):
        rendered = f"{prefix}{argument.arg}"
        annotation = self._render_node(argument.annotation)
        if annotation:
            rendered = f"{rendered}: {annotation}"
        if default is not None:
            default_text = self._render_node(default)
            if default_text:
                rendered = f"{rendered}={default_text}"
        return rendered

    def _collect_calls(self, node, current_class):
        collector = _CallCollector(node, current_class)
        collector.visit(node)
        return collector.calls

    def _collect_instance_bindings(self, node, current_class):
        collector = _BindingCollector(node, current_class)
        collector.visit(node)
        return collector.bindings

    def _collect_returns(self, node):
        collector = _ReturnCollector(node)
        collector.visit(node)
        return collector.values

    def _infer_type(self, annotation, value):
        if annotation is not None:
            return self._render_node(annotation)

        if value is None:
            return None
        if isinstance(value, ast.Dict):
            return "dict"
        if isinstance(value, ast.List):
            return "list"
        if isinstance(value, ast.Tuple):
            return "tuple"
        if isinstance(value, ast.Set):
            return "set"
        if isinstance(value, ast.Constant) and value.value is not None:
            return type(value.value).__name__
        return None

    def _render_node(self, node):
        if node is None:
            return None
        try:
            return " ".join(ast.unparse(node).split())
        except Exception:
            return None


class _CallCollector(ast.NodeVisitor):
    def __init__(self, root_node, current_class):
        self.root_node = root_node
        self.current_class = current_class
        self.calls = []
        self._seen = set()

    def visit_Call(self, node):
        call_meta = self._describe_call(node)
        if call_meta is not None:
            key = (call_meta["name"], call_meta["line"], call_meta.get("qualname_hint"))
            if key not in self._seen:
                self._seen.add(key)
                self.calls.append(call_meta)
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node is self.root_node:
            self._visit_function_root(node)

    def visit_AsyncFunctionDef(self, node):
        if node is self.root_node:
            self._visit_function_root(node)

    def visit_ClassDef(self, node):
        if node is self.root_node:
            self._visit_function_root(node)

    def _visit_function_root(self, node):
        for decorator in getattr(node, "decorator_list", []):
            self.visit(decorator)
        for default in getattr(node.args, "defaults", []):
            if default is not None:
                self.visit(default)
        for default in getattr(node.args, "kw_defaults", []):
            if default is not None:
                self.visit(default)
        for statement in getattr(node, "body", []):
            if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            self.visit(statement)

    def _describe_call(self, node):
        func = node.func
        if isinstance(func, ast.Name):
            return {
                "name": func.id,
                "expression": func.id,
                "line": node.lineno,
                "qualname_hint": None,
            }
        if isinstance(func, ast.Attribute):
            owner = self._render(func.value)
            if not owner:
                return None
            qualname_hint = None
            if owner in {"self", "cls"} and self.current_class:
                qualname_hint = f"{self.current_class}.{func.attr}"
            return {
                "name": func.attr,
                "owner": owner,
                "expression": f"{owner}.{func.attr}",
                "line": node.lineno,
                "qualname_hint": qualname_hint,
            }
        return None

    def _render(self, node):
        try:
            return " ".join(ast.unparse(node).split())
        except Exception:
            return None


class _BindingCollector(ast.NodeVisitor):
    def __init__(self, root_node, current_class):
        self.root_node = root_node
        self.current_class = current_class
        self.bindings = {}

    def visit_Assign(self, node):
        constructor = self._resolve_constructor(node.value)
        if constructor:
            for target in node.targets:
                if isinstance(target, ast.Name):
                    self.bindings[target.id] = constructor
        self.generic_visit(node)

    def visit_AnnAssign(self, node):
        constructor = self._resolve_constructor(node.value)
        if constructor and isinstance(node.target, ast.Name):
            self.bindings[node.target.id] = constructor
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node is self.root_node:
            self._visit_function_root(node)

    def visit_AsyncFunctionDef(self, node):
        if node is self.root_node:
            self._visit_function_root(node)

    def visit_ClassDef(self, node):
        if node is self.root_node:
            self._visit_function_root(node)

    def _visit_function_root(self, node):
        for statement in getattr(node, "body", []):
            if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            self.visit(statement)

    def _resolve_constructor(self, value):
        if not isinstance(value, ast.Call):
            return None

        if isinstance(value.func, ast.Name):
            return value.func.id
        if isinstance(value.func, ast.Attribute):
            owner = self._render(value.func.value)
            if owner in {"self", "cls"} and self.current_class:
                return f"{self.current_class}.{value.func.attr}"
        return None

    def _render(self, node):
        try:
            return " ".join(ast.unparse(node).split())
        except Exception:
            return None


class _ReturnCollector(ast.NodeVisitor):
    def __init__(self, root_node):
        self.root_node = root_node
        self.values = []

    def visit_Return(self, node):
        rendered = self._render_value(node.value)
        if rendered is not None and rendered not in self.values:
            self.values.append(rendered)

    def visit_FunctionDef(self, node):
        if node is self.root_node:
            self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node):
        if node is self.root_node:
            self.generic_visit(node)

    def visit_ClassDef(self, node):
        if node is self.root_node:
            self.generic_visit(node)

    def _render_value(self, node):
        if node is None:
            return "None"
        if isinstance(node, ast.Constant):
            return repr(node.value)
        if isinstance(node, ast.Name):
            return node.id
        try:
            rendered = " ".join(ast.unparse(node).split())
        except Exception:
            return None
        if len(rendered) > 60:
            return None
        return rendered
