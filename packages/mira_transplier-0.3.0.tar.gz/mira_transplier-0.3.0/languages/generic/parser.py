import os

from languages.base import BaseParser


GENERIC_TARGET_CHUNK_LINES = 100
GENERIC_MIN_CHUNK_LINES = 80
GENERIC_MAX_CHUNK_LINES = 500
GENERIC_DOUBLE_NEWLINE_BONUS = 50


class GenericParser(BaseParser):
    def parse(self, file_path):
        with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
            source_lines = handle.readlines()

        sections = _build_generic_sections(source_lines)

        extension = os.path.splitext(file_path)[1].lower().lstrip(".") or "generic"
        stat = os.stat(file_path)
        return {
            "language": extension,
            "file_kind": "generic",
            "storage_mode": "mirrored",
            "global_variables": {},
            "imports": [],
            "classes": {},
            "functions": {},
            "symbols": [],
            "sections": sections,
            "source_signature": {
                "size": stat.st_size,
                "mtime_ns": getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)),
            },
            "origin": "manual_or_external",
        }


def _build_generic_sections(source_lines):
    sections = []
    total_lines = len(source_lines)
    blank_runs = _find_blank_runs(source_lines)
    start_line = 1
    chunk_number = 1

    while start_line <= total_lines:
        end_line = _choose_chunk_end(start_line, total_lines, blank_runs)
        sections.append(
            {
                "label": f"CHUNK {chunk_number}",
                "start": start_line,
                "end": end_line,
                "members": [],
            }
        )
        start_line = end_line + 1
        chunk_number += 1

    return sections


def _choose_chunk_end(start_line, total_lines, blank_runs):
    remaining_lines = total_lines - start_line + 1
    if remaining_lines <= GENERIC_TARGET_CHUNK_LINES:
        return total_lines

    minimum_end = min(total_lines, start_line + GENERIC_MIN_CHUNK_LINES - 1)
    preferred_end = min(total_lines, start_line + GENERIC_TARGET_CHUNK_LINES - 1)
    maximum_end = min(total_lines, start_line + GENERIC_MAX_CHUNK_LINES - 1)
    candidate_runs = [run for run in blank_runs if start_line <= run["start"] <= maximum_end]

    post_target_runs = [run for run in candidate_runs if run["end"] >= preferred_end]
    if post_target_runs:
        base_run = post_target_runs[0]
        if not base_run["double"]:
            promoted_run = _find_following_double_run(post_target_runs, base_run["end"], maximum_end)
            if promoted_run is not None:
                return promoted_run["end"]
        return base_run["end"]

    pre_target_runs = [run for run in candidate_runs if minimum_end <= run["end"] < preferred_end]
    if pre_target_runs:
        double_runs = [run for run in pre_target_runs if run["double"]]
        if double_runs:
            return double_runs[-1]["end"]
        return pre_target_runs[-1]["end"]

    return maximum_end


def _find_following_double_run(candidate_runs, base_end, maximum_end):
    double_limit = min(maximum_end, base_end + GENERIC_DOUBLE_NEWLINE_BONUS)
    for run in candidate_runs:
        if not run["double"]:
            continue
        if run["end"] <= base_end:
            continue
        if run["end"] <= double_limit:
            return run
    return None


def _find_blank_runs(source_lines):
    runs = []
    current_start = None

    for line_number, line in enumerate(source_lines, start=1):
        if line.strip():
            if current_start is not None:
                runs.append(
                    {
                        "start": current_start,
                        "end": line_number - 1,
                        "double": (line_number - current_start) >= 2,
                    }
                )
                current_start = None
            continue

        if current_start is None:
            current_start = line_number

    if current_start is not None:
        runs.append(
            {
                "start": current_start,
                "end": len(source_lines),
                "double": (len(source_lines) - current_start + 1) >= 2,
            }
        )

    return runs