import json
import os
import subprocess
import time
from datetime import datetime


TERMINAL_INDEX_PATH = os.path.join("runtime", "terminals.json")
TERMINAL_LOG_DIR = os.path.join("runtime", "terminal_logs")


def ensure_terminal_state(mira_dir):
    runtime_dir = os.path.join(mira_dir, "runtime")
    os.makedirs(runtime_dir, exist_ok=True)
    os.makedirs(os.path.join(mira_dir, TERMINAL_LOG_DIR), exist_ok=True)
    index_path = os.path.join(mira_dir, TERMINAL_INDEX_PATH)
    if not os.path.exists(index_path):
        _write_json(index_path, {"next_id": 1, "latest_id": None, "terminals": {}})
    return index_path


def load_terminal_state(mira_dir):
    index_path = ensure_terminal_state(mira_dir)
    state = _load_json(index_path)
    _refresh_terminal_state(mira_dir, state)
    _write_json(index_path, state)
    return state


def save_terminal_state(mira_dir, state):
    _write_json(os.path.join(mira_dir, TERMINAL_INDEX_PATH), state)


def list_terminals(mira_dir):
    state = load_terminal_state(mira_dir)
    return [state["terminals"][terminal_id] for terminal_id in sorted(state["terminals"], key=lambda item: int(item))]


def show_terminal(mira_dir, terminal_id):
    state = load_terminal_state(mira_dir)
    terminal = state["terminals"].get(str(terminal_id))
    if terminal is None:
        raise ValueError(f"Unknown terminal ID: {terminal_id}")
    log_path = os.path.join(mira_dir, terminal["log_path"])
    output = _read_text(log_path) if os.path.exists(log_path) else ""
    return terminal, output


def run_terminal_command(mira_dir, root_dir, command, terminal_id=None, wait_mode="finish", wait_seconds=None, create_new=False):
    state = load_terminal_state(mira_dir)
    terminal = None

    if terminal_id is not None:
        terminal = state["terminals"].get(str(terminal_id))
        if terminal is None:
            raise ValueError(f"Unknown terminal ID: {terminal_id}")
        if terminal["status"] == "running":
            raise ValueError(f"Terminal {terminal_id} is still running")
    else:
        latest_id = state.get("latest_id")
        if not create_new and latest_id is not None:
            latest_terminal = state["terminals"].get(str(latest_id))
            if latest_terminal and latest_terminal["status"] != "running":
                terminal = latest_terminal
        if terminal is None:
            terminal = _create_terminal_record(mira_dir, state)

    log_path = os.path.join(mira_dir, terminal["log_path"])
    with open(log_path, "a", encoding="utf-8") as handle:
        handle.write(f"\n$ {command}\n")
        process = subprocess.Popen(
            command,
            cwd=root_dir,
            shell=True,
            stdout=handle,
            stderr=subprocess.STDOUT,
        )

    terminal["command"] = command
    terminal["cwd"] = root_dir
    terminal["pid"] = process.pid
    terminal["status"] = "running"
    terminal["started_at"] = _utc_now()
    terminal["finished_at"] = None
    terminal["returncode"] = None
    state["latest_id"] = int(terminal["id"])
    save_terminal_state(mira_dir, state)

    if wait_mode == "none":
        return state["terminals"][str(terminal["id"])], _tail_log(log_path)

    try:
        if wait_mode == "seconds" and wait_seconds is not None:
            process.wait(timeout=wait_seconds)
        else:
            process.wait()
    except subprocess.TimeoutExpired:
        pass

    if process.poll() is not None:
        state = load_terminal_state(mira_dir)
        terminal = state["terminals"][str(terminal["id"])]
        terminal["status"] = "finished"
        terminal["finished_at"] = _utc_now()
        terminal["returncode"] = process.returncode
        terminal["pid"] = None
        save_terminal_state(mira_dir, state)

    state = load_terminal_state(mira_dir)
    terminal = state["terminals"][str(terminal["id"])]
    return terminal, _tail_log(log_path)


def delete_terminal(mira_dir, terminal_id):
    state = load_terminal_state(mira_dir)
    terminal = state["terminals"].get(str(terminal_id))
    if terminal is None:
        raise ValueError(f"Unknown terminal ID: {terminal_id}")
    if terminal["status"] == "running" and terminal.get("pid") is not None:
        _kill_process(int(terminal["pid"]))

    log_path = os.path.join(mira_dir, terminal["log_path"])
    if os.path.exists(log_path):
        os.remove(log_path)

    del state["terminals"][str(terminal_id)]
    if state.get("latest_id") == int(terminal_id):
        state["latest_id"] = _latest_terminal_id(state)
    save_terminal_state(mira_dir, state)
    return terminal


def kill_terminal(mira_dir, terminal_id):
    terminal = delete_terminal(mira_dir, terminal_id)
    return terminal.get("status") == "running"


def _create_terminal_record(mira_dir, state):
    terminal_id = state["next_id"]
    state["next_id"] += 1
    terminal = {
        "id": terminal_id,
        "status": "idle",
        "pid": None,
        "command": None,
        "cwd": None,
        "started_at": None,
        "finished_at": None,
        "returncode": None,
        "log_path": os.path.join(TERMINAL_LOG_DIR, f"{terminal_id}.log").replace("\\", "/"),
    }
    state["terminals"][str(terminal_id)] = terminal
    return terminal


def _latest_terminal_id(state):
    if not state.get("terminals"):
        return None
    return max(int(terminal_id) for terminal_id in state["terminals"])


def _refresh_terminal_state(mira_dir, state):
    for terminal in state.get("terminals", {}).values():
        pid = terminal.get("pid")
        if terminal.get("status") != "running" or pid is None:
            continue
        if _process_is_running(int(pid)):
            continue
        terminal["status"] = "finished"
        terminal["finished_at"] = _utc_now()
        terminal["returncode"] = terminal.get("returncode") if terminal.get("returncode") is not None else "unknown"
        terminal["pid"] = None


def _process_is_running(pid):
    if os.name == "nt":
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
            capture_output=True,
            text=True,
            check=False,
        )
        output = result.stdout.strip()
        return bool(output and not output.startswith("INFO:"))
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _kill_process(pid):
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, check=False)
    else:
        os.kill(pid, 9)


def _tail_log(path, max_lines=40):
    if not os.path.exists(path):
        return ""
    lines = _read_text(path).splitlines()
    return "\n".join(lines[-max_lines:])


def _utc_now():
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"


def _load_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _write_json(path, payload):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


def _read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()
