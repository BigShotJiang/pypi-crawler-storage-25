import os

from languages.cpp.parser import CppParser
from languages.generic.parser import GenericParser
from languages.json.parser import JsonParser
from languages.python.parser import PythonParser
from languages.text.parser import TextParser
from mira_core.indexing import collect_indexed_file_paths


IGNORED_DIRECTORIES = {".mira", "__pycache__"}


def get_parser(file_path):
    extension = os.path.splitext(file_path)[1].lower()
    if extension == ".py":
        return PythonParser()
    if extension in {".cpp", ".cc", ".cxx", ".hpp", ".hh", ".hxx", ".h"}:
        return CppParser()
    if extension == ".txt":
        return TextParser()
    if extension == ".json":
        return JsonParser("json")
    if extension == ".jsonl":
        return JsonParser("jsonl")
    if _is_probably_binary(file_path):
        return None
    return GenericParser()


def analyze_target(target_path):
    project_data = {"files": {}}

    if os.path.isfile(target_path):
        _analyze_file(target_path, target_path, project_data)
        return project_data

    for relative_path in collect_indexed_file_paths(target_path, interactive=True):
        _analyze_file(os.path.join(target_path, *relative_path.split("/")), target_path, project_data)
    return project_data


def _filter_directories(directories):
    filtered = []
    for directory in directories:
        if directory.startswith("."):
            continue
        if directory in IGNORED_DIRECTORIES:
            continue
        filtered.append(directory)
    filtered.sort()
    return filtered


def _analyze_file(file_path, base_target, project_data):
    parser = get_parser(file_path)
    if parser is None:
        return

    base_path = base_target if os.path.isdir(base_target) else os.path.dirname(base_target)
    relative_path = os.path.relpath(file_path, base_path).replace("\\", "/")

    try:
        project_data["files"][relative_path] = parser.parse(file_path)
    except Exception as error:
        print(f"Failed to parse {file_path}: {error}")


def _is_probably_binary(file_path):
    try:
        with open(file_path, "rb") as handle:
            sample = handle.read(1024)
    except OSError:
        return True
    return b"\x00" in sample
