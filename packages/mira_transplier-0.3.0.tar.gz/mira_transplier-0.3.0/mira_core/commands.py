import difflib
import json
import os
import re
import shutil
import sys

from mira_core.chunk_comments import (
    chunk_comment_signatures,
    delete_chunk_comment_signatures,
    delete_chunk_comments,
    delete_chunk_comments_for_path_prefix,
    file_chunk_signature_set,
    set_chunk_comments,
)
from mira_core.command_docs import build_public_command_lines
from mira_core.environment import (
    clear_configured_environment,
    create_workspace_environment,
    discover_workspace_environments,
    load_configured_environment,
    set_configured_environment,
)
from mira_core.indexing import list_index_entries, normalize_workspace_path, register_created_path, remove_deleted_path, set_index_entry_included
from mira_core.sync import (
    HISTORY_INDEX_PATH,
    apply_source_edit,
    append_to_source,
    delete_document_line,
    delete_document_lines,
    is_file_stale,
    list_history,
    read_document,
    replace_document_lines,
    restore_version,
    sync_workspace,
    update_document_line,
    write_document,
)
from mira_core.terminals import delete_terminal, list_terminals, run_terminal_command, show_terminal


COMMAND_HELP_LINES = build_public_command_lines()


def run_mira_command(start_path, command_token, arguments):
    root_dir, mira_dir = _find_mira_workspace(start_path)
    if mira_dir is None:
        print("No .mira output found. Run `python mira.py .` first.")
        return 1

    command = command_token.lstrip("!").strip().lower()
    if command == "project":
        sync_workspace(root_dir)
        print(_read_text(os.path.join(mira_dir, "project.mira")), end="")
        return 0
    if command == "list":
        print("\n".join(COMMAND_HELP_LINES))
        return 0
    if command == "index":
        return _handle_index_command(root_dir, arguments)
    if command == "environment":
        return _handle_environment_command(root_dir, arguments)
    if command == "create":
        return _handle_create_command(root_dir, arguments)
    if command == "delete":
        return _handle_delete_command(root_dir, mira_dir, arguments)
    if command in {"read_memory", "memory"}:
        return _read_special_document(mira_dir, "memory.txt", "memory")
    if command in {"goals", "read_goals"}:
        return _read_special_document(mira_dir, "goals.txt", "goals")
    if command == "edit_memory":
        return _edit_special_document(mira_dir, "memory.txt", arguments, "memory")
    if command == "edit_goals":
        return _edit_special_document(mira_dir, "goals.txt", arguments, "goals")
    if command == "terminals":
        return _list_terminals(mira_dir)
    if command == "terminal":
        return _handle_terminal_command(root_dir, mira_dir, arguments)
    if command == "terminal_delete":
        return _handle_terminal_delete(mira_dir, arguments)
    if command == "terminal_kill":
        return _handle_terminal_delete(mira_dir, arguments)

    global_index = _load_json(os.path.join(mira_dir, "global_index.json"))

    if command == "explore":
        return _show_file_skeleton(root_dir, mira_dir, global_index, arguments)
    if command == "expand":
        return _expand_chunks(root_dir, mira_dir, global_index, arguments)
    if command == "find_line":
        return _find_line(root_dir, mira_dir, global_index, arguments)
    if command == "deps":
        return _show_file_dependencies(root_dir, mira_dir, global_index, arguments, key="depends_on", label="Dependencies")
    if command == "callers":
        return _show_file_dependencies(root_dir, mira_dir, global_index, arguments, key="used_by", label="Used by")
    if command == "search":
        return _search_files(root_dir, mira_dir, global_index, arguments)
    if command == "diff":
        return _show_diff(root_dir, mira_dir, global_index, arguments)
    if command == "history":
        return _show_history(mira_dir, global_index, arguments)
    if command == "restore":
        return _handle_restore(root_dir, mira_dir, global_index, arguments)
    if command == "edit":
        return _handle_edit(root_dir, mira_dir, global_index, arguments)
    if command == "edit_chunk":
        return _handle_edit_chunk(root_dir, mira_dir, global_index, arguments)
    if command == "delete_chunk":
        return _handle_delete_chunk(root_dir, mira_dir, global_index, arguments)
    if command == "add_chunk":
        return _handle_add_chunk(root_dir, mira_dir, global_index, arguments)
    if command in {"add_description", "edit_description", "delete_description"}:
        return _handle_description_command(mira_dir, global_index, command, arguments)
    if command in {"add_comment", "edit_comment", "delete_comment"}:
        return _handle_chunk_comment_command(root_dir, mira_dir, global_index, command, arguments)

    print(f"Unknown command: {command_token}")
    return 1


def _find_mira_workspace(start_path):
    current = os.path.abspath(start_path)
    if os.path.isfile(current):
        current = os.path.dirname(current)

    while True:
        mira_dir = os.path.join(current, ".mira")
        if os.path.isdir(mira_dir) and os.path.isfile(os.path.join(mira_dir, "global_index.json")):
            return current, mira_dir
        parent = os.path.dirname(current)
        if parent == current:
            return None, None
        current = parent


def _read_special_document(mira_dir, filename, label):
    text = read_document(mira_dir, filename)
    if not text.strip():
        print(f"{label} is empty. Use !edit_{label} to add context.")
        return 0
    print(text, end="" if text.endswith("\n") else "\n")
    return 0


def _edit_special_document(mira_dir, filename, arguments, label):
    if not arguments and sys.stdin.isatty():
        _print_document_edit_usage(label)
        return 1

    try:
        action = arguments[0].lower()
        if action in {"line", "lines"} and len(arguments) >= 3:
            start_line, end_line = _parse_line_span(arguments[1])
            text = _resolve_text_payload(arguments[2:], allow_stdin_fallback=True)
            if text is None:
                print("Replacement text cannot be empty.")
                return 1
            replace_document_lines(mira_dir, filename, start_line, end_line, text)
            print(f"Updated {label} lines {_format_line_span(start_line, end_line)}.")
            return 0

        if action == "delete" and len(arguments) == 2:
            start_line, end_line = _parse_line_span(arguments[1])
            delete_document_lines(mira_dir, filename, start_line, end_line)
            print(f"Deleted {label} lines {_format_line_span(start_line, end_line)}.")
            return 0
    except ValueError as error:
        print(str(error))
        return 1

    try:
        text = _resolve_text_payload(arguments, allow_stdin_fallback=True)
    except ValueError as error:
        print(str(error))
        return 1
    if text is None:
        _print_document_edit_usage(label)
        return 1
    write_document(mira_dir, filename, text)
    print(f"Updated {label}.")
    return 0


def _show_file_skeleton(root_dir, mira_dir, global_index, arguments):
    file_entry = _require_file_entry(global_index, arguments)
    if file_entry is None:
        return 1
    file_entry, _ = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    skeleton_path = os.path.join(mira_dir, "files", str(file_entry["file_id"]), "skeleton.txt")
    print(_read_text(skeleton_path), end="")
    return 0


def _expand_chunks(root_dir, mira_dir, global_index, arguments):
    if not arguments:
        print("Usage: !expand <chunk_id> or !expand <chunk_a-chunk_b>")
        return 1

    spec = " ".join(arguments).strip().strip("<>")
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    if file_id is None:
        return 1

    file_entry = _get_file_entry(global_index, file_id)
    file_entry, global_index = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    meta = _load_json(os.path.join(mira_dir, "files", str(file_id), "meta.json"))

    if _is_metadata_only_file(file_entry):
        return _expand_document_chunks(root_dir, file_entry, meta, chunk_ids)

    total_lines = 0
    for chunk_id in chunk_ids:
        start_line, end_line = _parse_lines(meta["chunks"][chunk_id]["lines"])
        total_lines += end_line - start_line + 1

    if total_lines > 1000 and not _confirm_large_expand(total_lines, chunk_ids):
        print("Expansion cancelled.")
        return 1

    output_parts = []
    for chunk_id in chunk_ids:
        chunk_path = os.path.join(mira_dir, "files", str(file_id), "chunks", f"{chunk_id}.txt")
        output_parts.append(_read_text(chunk_path))
    print("".join(output_parts), end="")
    return 0


def _find_line(root_dir, mira_dir, global_index, arguments):
    if len(arguments) < 2:
        print("Usage: !find_line <file_id> <line>")
        return 1

    file_entry = _get_file_entry(global_index, arguments[0])
    if file_entry is None:
        print(f"Unknown file ID: {arguments[0]}")
        return 1
    file_entry, _ = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)

    try:
        line_number = int(arguments[1])
    except ValueError:
        print(f"Invalid line number: {arguments[1]}")
        return 1

    meta = _load_json(os.path.join(mira_dir, "files", str(file_entry["file_id"]), "meta.json"))
    for chunk_id, chunk_meta in sorted(meta["chunks"].items(), key=lambda item: _chunk_sort_key(item[0])):
        start_line, end_line = _parse_lines(chunk_meta["lines"])
        if start_line <= line_number <= end_line:
            print(
                f"Line {line_number} in file {file_entry['file_id']} ({file_entry['name']}) is in chunk {chunk_id} ({chunk_meta['lines']})"
            )
            if chunk_meta.get("functions"):
                print(f"Function: {', '.join(chunk_meta['functions'])}")
            else:
                print(f"Section: {chunk_meta.get('label', 'module section')}")
            return 0

    print(f"Line {line_number} is outside the indexed range for file {file_entry['file_id']}.")
    return 1


def _show_file_dependencies(root_dir, mira_dir, global_index, arguments, key, label):
    file_entry = _require_file_entry(global_index, arguments)
    if file_entry is None:
        return 1
    file_entry, global_index = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)

    details = global_index["files"][str(file_entry["file_id"])].get(key, [])
    print(f"{label} for [{file_entry['file_id']}] {file_entry['path']}:")
    if not details:
        print("none")
        return 0

    for detail in details:
        line = f"[{detail['file_id']}] {detail['path']}"
        chunk_ids = detail.get("chunk_ids", [])
        if chunk_ids:
            chunk_label = "ID" if len(chunk_ids) == 1 else "IDs"
            line = f"{line} ({chunk_label}: {', '.join(chunk_ids)})"
        print(line)
    return 0


def _search_files(root_dir, mira_dir, global_index, arguments):
    if not arguments:
        print("Usage: !search <text>")
        return 1

    query = " ".join(arguments).strip().lower()
    matches = []
    for file_id, file_entry in sorted(global_index["files"].items(), key=lambda item: int(item[0])):
        if file_entry.get("file_kind") == "document":
            matches.extend(_search_document_lines(root_dir, int(file_id), file_entry, query))
            continue
        skeleton_path = os.path.join(mira_dir, "files", file_id, "skeleton.txt")
        for line_number, line in enumerate(_read_text(skeleton_path).splitlines(), start=1):
            if query in line.lower():
                matches.append(f"[{file_id}] {file_entry['path']}:{line_number}: {line}")

    if not matches:
        print(f"No matches found for: {query}")
        return 0

    print("\n".join(matches))
    return 0


def _show_diff(root_dir, mira_dir, global_index, arguments):
    file_entry = _require_file_entry(global_index, arguments)
    if file_entry is None:
        return 1
    if _is_metadata_only_file(file_entry):
        print("Diff is unavailable for metadata-only document files because MIRA does not store a source snapshot.")
        return 1

    history_index = _load_json_if_exists(os.path.join(mira_dir, HISTORY_INDEX_PATH), {"files": {}})
    history_entry = history_index["files"].get(file_entry["path"])
    if history_entry is not None:
        baseline_path = os.path.join(mira_dir, history_entry["base_snapshot"])
    else:
        baseline_path = os.path.join(mira_dir, "snapshots", f"{file_entry['file_id']}.txt")

    current_path = os.path.join(root_dir, file_entry["path"])
    if not os.path.exists(baseline_path):
        print("No baseline found for this file. Rebuild .mira first.")
        return 1
    if not os.path.exists(current_path):
        print(f"Current file is missing: {current_path}")
        return 1

    baseline_lines = _read_text(baseline_path).splitlines()
    current_lines = _read_text(current_path).splitlines()
    diff_lines = list(
        difflib.unified_diff(
            baseline_lines,
            current_lines,
            fromfile=f"base:{file_entry['path']}",
            tofile=f"current:{file_entry['path']}",
            lineterm="",
        )
    )
    if not diff_lines:
        print(f"No changes since base version for file {file_entry['file_id']} ({file_entry['path']}).")
        return 0

    print("\n".join(diff_lines))
    return 0


def _show_history(mira_dir, global_index, arguments):
    file_entry = _require_file_entry(global_index, arguments)
    if file_entry is None:
        return 1
    if _is_metadata_only_file(file_entry):
        print("History is unavailable for metadata-only document files because MIRA does not store source baselines.")
        return 1

    history_items = list_history(mira_dir, file_entry["path"])
    if not history_items:
        print(f"No MIRA history for file {file_entry['file_id']}.")
        return 0

    print(f"History for [{file_entry['file_id']}] {file_entry['path']}:")
    for item in history_items:
        if item["version"] == 1:
            print("1 | base")
            continue
        print(
            f"{item['version']} | {item['command']} | +{item['added_lines']} -{item['removed_lines']} | {item['timestamp']}"
        )
    return 0


def _handle_restore(root_dir, mira_dir, global_index, arguments):
    if len(arguments) < 2:
        print("Usage: !restore <file_id> <version>")
        return 1

    file_entry = _get_file_entry(global_index, arguments[0])
    if file_entry is None:
        print(f"Unknown file ID: {arguments[0]}")
        return 1
    if _is_metadata_only_file(file_entry):
        print("Restore is unavailable for metadata-only document files because MIRA does not store source baselines.")
        return 1
    try:
        version = int(arguments[1])
    except ValueError:
        print(f"Invalid version: {arguments[1]}")
        return 1

    try:
        changed = restore_version(root_dir, mira_dir, file_entry["path"], version)
    except ValueError as error:
        print(str(error))
        return 1

    if not changed:
        print(f"File {file_entry['file_id']} is already at version {version}.")
        return 0

    print(f"Restored file {file_entry['file_id']} using version {version} and synced .mira.")
    return 0


def _handle_index_command(root_dir, arguments):
    if not arguments:
        entries = list_index_entries(root_dir, interactive=False)
        present_entries = [entry for entry in entries if entry.get("present")]
        indexed_entries = [entry for entry in present_entries if entry.get("included")]
        skipped_entries = [entry for entry in present_entries if not entry.get("included")]

        print(
            f"Known entries: {len(present_entries)} | total files: {_sum_index_entry_files(present_entries)}"
        )
        print(
            f"Indexed entries: {len(indexed_entries)} | indexed files: {_sum_index_entry_files(indexed_entries)}"
        )
        print("")
        print("Indexed:")
        if not indexed_entries:
            print("none")
        else:
            for entry in indexed_entries:
                print(_format_index_entry(entry))
        print("")
        print("Not indexed:")
        if not skipped_entries:
            print("none")
        else:
            for entry in skipped_entries:
                print(_format_index_entry(entry))
        return 0

    if len(arguments) != 2 or arguments[0].lower() not in {"add", "remove"}:
        print("Usage: !index")
        print("Usage: !index add <path>")
        print("Usage: !index remove <path>")
        return 1

    action = arguments[0].lower()
    name = arguments[1].strip()
    try:
        normalized_path = normalize_workspace_path(name)
        entry = set_index_entry_included(root_dir, normalized_path, action == "add", interactive=True)
    except ValueError as error:
        print(str(error))
        return 1

    if action == "add" and not entry.get("included"):
        print(f"Indexing cancelled for {normalized_path}.")
        return 0

    sync_workspace(root_dir)
    if action == "add":
        print(f"Indexed entry {normalized_path} and rebuilt .mira.")
    else:
        print(f"Removed entry {normalized_path} from the index and rebuilt .mira.")
    return 0


def _handle_environment_command(root_dir, arguments):
    if not arguments:
        configured_environment = load_configured_environment(root_dir)
        discovered_environments = discover_workspace_environments(root_dir)

        if configured_environment is None:
            print("Configured environment: none")
        else:
            print(f"Configured environment: {configured_environment['label']} ({configured_environment['path']})")

        print("")
        print("Detected environments:")
        if not discovered_environments:
            print("none")
        else:
            for environment in discovered_environments:
                print(_format_environment_entry(environment))

        print("")
        print("Usage: !environment")
        print("Usage: !environment <path>")
        print("Usage: !environment clear")
        print("Usage: !environment create <name>")
        return 0

    if len(arguments) == 1 and arguments[0].lower() == "clear":
        clear_configured_environment(root_dir)
        sync_workspace(root_dir)
        print("Cleared configured environment and rebuilt .mira.")
        return 0

    if len(arguments) == 2 and arguments[0].lower() == "create":
        try:
            environment = create_workspace_environment(root_dir, arguments[1])
        except ValueError as error:
            print(str(error))
            return 1

        sync_workspace(root_dir)
        print(f"Created and configured environment {environment['label']} ({environment['path']}) and rebuilt .mira.")
        return 0

    try:
        environment = set_configured_environment(root_dir, " ".join(arguments).strip())
    except ValueError as error:
        print(str(error))
        return 1

    sync_workspace(root_dir)
    print(f"Configured environment {environment['label']} ({environment['path']}) and rebuilt .mira.")
    return 0


def _handle_create_command(root_dir, arguments):
    try:
        kind, raw_path = _parse_create_arguments(arguments)
        normalized_path = _resolve_workspace_target_path(root_dir, raw_path)
    except ValueError as error:
        print(str(error))
        return 1

    target_path = _absolute_workspace_path(root_dir, normalized_path)
    if os.path.exists(target_path):
        print(f"Entry already exists: {normalized_path}")
        return 1

    if kind == "folder":
        os.makedirs(target_path)
    else:
        parent_directory = os.path.dirname(target_path)
        if parent_directory:
            os.makedirs(parent_directory, exist_ok=True)
        with open(target_path, "w", encoding="utf-8") as handle:
            handle.write("")

    register_created_path(root_dir, normalized_path, kind)
    sync_workspace(root_dir)
    print(f"Created {kind} {normalized_path} and rebuilt .mira.")
    return 0


def _handle_delete_command(root_dir, mira_dir, arguments):
    if len(arguments) != 1:
        print("Usage: !delete <path>")
        return 1

    global_index = _load_json(os.path.join(mira_dir, "global_index.json"))
    try:
        normalized_path = _resolve_delete_target_path(root_dir, global_index, arguments[0])
    except ValueError as error:
        print(str(error))
        return 1

    target_path = _absolute_workspace_path(root_dir, normalized_path)
    if not os.path.exists(target_path):
        print(f"Unknown entry: {normalized_path}")
        return 1

    if not _confirm_yes_no(f"Delete {normalized_path}? [y/n]"):
        print("Delete cancelled.")
        return 1

    delete_chunk_comments_for_path_prefix(mira_dir, normalized_path)

    if os.path.isdir(target_path):
        shutil.rmtree(target_path)
    else:
        os.remove(target_path)

        empty_parent = _find_empty_parent_folder(root_dir, target_path)
        if empty_parent is not None:
            parent_relative = os.path.relpath(empty_parent, root_dir).replace("\\", "/")
            if _confirm_yes_no(f"Delete empty parent folder {parent_relative} as well? [y/n]", eof_default=False):
                os.rmdir(empty_parent)
                remove_deleted_path(root_dir, parent_relative)

    remove_deleted_path(root_dir, normalized_path)
    sync_workspace(root_dir)
    print(f"Deleted {normalized_path} and rebuilt .mira.")
    return 0


def _handle_edit(root_dir, mira_dir, global_index, arguments):
    if not arguments:
        _print_edit_usage()
        return 1

    target = _normalize_edit_target(arguments[0])
    if target["mode"] == "delete_chunk":
        if len(arguments) != 1:
            print("Chunk delete does not accept replacement text.")
            return 1
        return _handle_delete_chunk(root_dir, mira_dir, global_index, [target["spec"]])
    if target["mode"] == "replace_chunk":
        return _handle_edit_chunk(root_dir, mira_dir, global_index, [target["spec"], *arguments[1:]])

    try:
        text = _resolve_text_payload(arguments[1:], allow_stdin_fallback=True)
    except ValueError as error:
        print(str(error))
        return 1
    if text is None:
        print("Replacement text cannot be empty.")
        return 1

    if target["mode"] == "replace_file":
        return _handle_replace_file(root_dir, mira_dir, global_index, target["file_id"], text)
    if target["mode"] == "insert_after":
        return _handle_insert_relative_to_chunk(root_dir, mira_dir, global_index, target["spec"], text, after=True)
    if target["mode"] == "insert_before":
        return _handle_insert_relative_to_chunk(root_dir, mira_dir, global_index, target["spec"], text, after=False)

    _print_edit_usage()
    return 1


def _handle_replace_file(root_dir, mira_dir, global_index, raw_file_id, replacement_text):
    file_entry = _get_file_entry(global_index, raw_file_id)
    if file_entry is None:
        print(f"Unknown file ID: {raw_file_id}")
        return 1
    file_entry, _ = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    line_count = _count_source_lines(root_dir, file_entry["path"])
    changed = apply_source_edit(
        root_dir,
        mira_dir,
        file_entry["path"],
        1,
        line_count,
        replacement_text,
        f"edit file {file_entry['file_id']}",
        track_history=not _is_metadata_only_file(file_entry),
    )
    if not changed:
        print("File edit produced no source changes.")
        return 0
    print(f"Edited file {file_entry['file_id']} and synced source -> .mira.")
    return 0


def _handle_insert_relative_to_chunk(root_dir, mira_dir, global_index, spec, text, after):
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    if file_id is None:
        return 1
    file_entry = _get_file_entry(global_index, file_id)
    file_entry, global_index = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    meta = _load_json(os.path.join(mira_dir, "files", str(file_id), "meta.json"))

    if after:
        _, anchor_line = _parse_lines(meta["chunks"][chunk_ids[-1]]["lines"])
        start_line = anchor_line + 1
        end_line = anchor_line
        command_name = f"edit {spec}+"
    else:
        start_line, _ = _parse_lines(meta["chunks"][chunk_ids[0]]["lines"])
        end_line = start_line - 1
        command_name = f"edit {spec}-"

    changed = apply_source_edit(
        root_dir,
        mira_dir,
        file_entry["path"],
        start_line,
        end_line,
        text,
        command_name,
        track_history=not _is_metadata_only_file(file_entry),
    )
    if not changed:
        print("Chunk insert produced no source changes.")
        return 0
    inserted_end_line = start_line + _count_text_lines(text) - 1
    _maybe_prompt_for_chunk_comment(root_dir, mira_dir, file_entry["path"], [], start_line, inserted_end_line)
    if after:
        print(f"Inserted after chunk {spec} and synced source -> .mira.")
    else:
        print(f"Inserted before chunk {spec} and synced source -> .mira.")
    return 0


def _print_edit_usage():
    print("Usage: !edit <file_id> [text]")
    print("Usage: !edit <chunk_id> [text]")
    print("Usage: !edit <chunk_id+> [text]")
    print("Usage: !edit <chunk_id-> [text]")
    print("Usage: !edit -<chunk_id>")


def _normalize_edit_target(raw_target):
    target = raw_target.strip()
    if target.startswith("[") and target.endswith("]"):
        target = target[1:-1].strip()

    if target.startswith("-"):
        return {"mode": "delete_chunk", "spec": target[1:]}
    if target.endswith("+"):
        return {"mode": "insert_after", "spec": target[:-1]}
    if target.endswith("-") and "_" in target:
        return {"mode": "insert_before", "spec": target[:-1]}
    if target.isdigit():
        return {"mode": "replace_file", "file_id": int(target)}
    return {"mode": "replace_chunk", "spec": target}


def _format_index_entry(entry):
    suffix = "/" if entry["kind"] == "folder" else ""
    file_count = entry.get("file_count", 0)
    count_label = "files" if file_count != 1 else "file"
    return f"- {entry['path']}{suffix} ({entry['kind']}, {file_count} {count_label})"


def _format_environment_entry(environment):
    return f"- {environment['label']} ({environment['path']})"


def _sum_index_entry_files(entries):
    total = 0
    for entry in entries:
        if entry["kind"] == "folder":
            total += entry.get("file_count", 0)
        else:
            total += 1
    return total


def _absolute_workspace_path(root_dir, relative_path):
    return os.path.join(root_dir, *relative_path.split("/"))


def _parse_create_arguments(arguments):
    if not arguments or len(arguments) > 2:
        raise ValueError("Usage: !create [folder|file] <path>")

    if len(arguments) == 2:
        kind = arguments[0].lower()
        if kind not in {"folder", "file"}:
            raise ValueError("Usage: !create [folder|file] <path>")
        raw_path = arguments[1].strip()
    else:
        raw_path = arguments[0].strip()
        kind = _infer_create_kind(raw_path)

    if not raw_path:
        raise ValueError("Invalid path.")
    return kind, raw_path


def _infer_create_kind(raw_path):
    normalized = raw_path.strip().replace("\\", "/")
    if normalized.endswith("/"):
        return "folder"

    name = normalized.rstrip("/").split("/")[-1]
    if name.startswith(".") or "." in name:
        return "file"
    return "folder"


def _resolve_delete_target_path(root_dir, global_index, raw_target):
    target = raw_target.strip()
    if target.isdigit():
        file_entry = _get_file_entry(global_index, target)
        if file_entry is None:
            raise ValueError(f"Unknown file ID: {target}")
        return file_entry["path"]
    return _resolve_workspace_target_path(root_dir, target)


def _resolve_workspace_target_path(root_dir, raw_path):
    path = raw_path.strip()
    if not path:
        raise ValueError("Invalid path.")

    if _is_absolute_user_path(path):
        absolute_path = os.path.abspath(path)
        workspace_path = os.path.abspath(root_dir)
        try:
            common_path = os.path.commonpath([workspace_path, absolute_path])
        except ValueError as error:
            raise ValueError("Paths must stay inside the workspace.") from error
        if common_path != workspace_path:
            raise ValueError("Paths must stay inside the workspace.")
        path = os.path.relpath(absolute_path, workspace_path)

    return normalize_workspace_path(path)


def _is_absolute_user_path(raw_path):
    drive, _ = os.path.splitdrive(raw_path)
    return bool(drive) or raw_path.startswith("\\\\")


def _confirm_yes_no(prompt, eof_default=False):
    print(prompt)
    try:
        response = input().strip().lower()
    except EOFError:
        return eof_default
    return response in {"y", "yes"}


def _find_empty_parent_folder(root_dir, target_path):
    workspace_path = os.path.abspath(root_dir)
    parent_path = os.path.abspath(os.path.dirname(target_path))
    if parent_path == workspace_path:
        return None
    if not parent_path.startswith(workspace_path):
        return None
    if not os.path.isdir(parent_path):
        return None
    if os.listdir(parent_path):
        return None
    return parent_path


def _count_source_lines(root_dir, relative_path):
    source_path = os.path.join(root_dir, relative_path)
    if not os.path.exists(source_path):
        return 0
    with open(source_path, "r", encoding="utf-8", errors="replace") as handle:
        return sum(1 for _ in handle)


def _handle_edit_chunk(root_dir, mira_dir, global_index, arguments):
    if not arguments:
        print("Usage: !edit_chunk <chunk_id|chunk_a-chunk_b> [text]")
        return 1

    spec = arguments[0].strip().strip("<>")
    try:
        replacement_text = _resolve_text_payload(arguments[1:], allow_stdin_fallback=True)
    except ValueError as error:
        print(str(error))
        return 1
    if replacement_text is None:
        print("Edited chunk text cannot be empty.")
        return 1

    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    if file_id is None:
        return 1
    file_entry = _get_file_entry(global_index, file_id)
    file_entry, global_index = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    meta = _load_json(os.path.join(mira_dir, "files", str(file_id), "meta.json"))
    previous_comment_signatures = _commented_chunk_signatures(root_dir, file_entry["path"], meta, chunk_ids)
    start_line, _ = _parse_lines(meta["chunks"][chunk_ids[0]]["lines"])
    _, end_line = _parse_lines(meta["chunks"][chunk_ids[-1]]["lines"])

    changed = apply_source_edit(
        root_dir,
        mira_dir,
        file_entry["path"],
        start_line,
        end_line,
        replacement_text,
        f"edit_chunk {spec}",
        track_history=not _is_metadata_only_file(file_entry),
    )
    if not changed:
        print("Chunk edit produced no source changes.")
        return 0
    replacement_end_line = start_line + _count_text_lines(replacement_text) - 1
    _maybe_prompt_for_chunk_comment(
        root_dir,
        mira_dir,
        file_entry["path"],
        previous_comment_signatures,
        start_line,
        replacement_end_line,
    )
    print(f"Edited chunk {spec} and synced source -> .mira.")
    return 0


def _handle_delete_chunk(root_dir, mira_dir, global_index, arguments):
    if not arguments:
        print("Usage: !delete_chunk <chunk_id|chunk_a-chunk_b>")
        return 1

    spec = arguments[0].strip().strip("<>")
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    if file_id is None:
        return 1
    file_entry = _get_file_entry(global_index, file_id)
    file_entry, global_index = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    meta = _load_json(os.path.join(mira_dir, "files", str(file_id), "meta.json"))
    previous_comment_signatures = _commented_chunk_signatures(root_dir, file_entry["path"], meta, chunk_ids)
    start_line, _ = _parse_lines(meta["chunks"][chunk_ids[0]]["lines"])
    _, end_line = _parse_lines(meta["chunks"][chunk_ids[-1]]["lines"])

    changed = apply_source_edit(
        root_dir,
        mira_dir,
        file_entry["path"],
        start_line,
        end_line,
        "",
        f"delete_chunk {spec}",
        track_history=not _is_metadata_only_file(file_entry),
    )
    if not changed:
        print("Chunk delete produced no source changes.")
        return 0
    _maybe_prompt_for_chunk_comment(root_dir, mira_dir, file_entry["path"], previous_comment_signatures)
    print(f"Deleted chunk {spec} and synced source -> .mira.")
    return 0


def _handle_add_chunk(root_dir, mira_dir, global_index, arguments):
    if not arguments:
        print("Usage: !add_chunk <file_id> [text] or !add_chunk before <chunk_id> [text]")
        return 1

    if arguments[0].lower() == "before":
        if len(arguments) < 2:
            print("Usage: !add_chunk before <chunk_id> [text]")
            return 1
        spec = arguments[1].strip().strip("<>")
        try:
            text = _resolve_text_payload(arguments[2:], allow_stdin_fallback=True)
        except ValueError as error:
            print(str(error))
            return 1
        if text is None:
            print("Chunk text cannot be empty.")
            return 1
        file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
        if file_id is None:
            return 1
        file_entry = _get_file_entry(global_index, file_id)
        file_entry, global_index = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
        file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
        meta = _load_json(os.path.join(mira_dir, "files", str(file_id), "meta.json"))
        start_line, _ = _parse_lines(meta["chunks"][chunk_ids[0]]["lines"])
        changed = apply_source_edit(
            root_dir,
            mira_dir,
            file_entry["path"],
            start_line,
            start_line - 1,
            text,
            f"add_chunk before {spec}",
            track_history=not _is_metadata_only_file(file_entry),
        )
        if not changed:
            print("Chunk insert produced no source changes.")
            return 0
        inserted_end_line = start_line + _count_text_lines(text) - 1
        _maybe_prompt_for_chunk_comment(root_dir, mira_dir, file_entry["path"], [], start_line, inserted_end_line)
        print(f"Inserted chunk before {spec} and synced source -> .mira.")
        return 0

    file_entry = _get_file_entry(global_index, arguments[0])
    if file_entry is None:
        print(f"Unknown file ID: {arguments[0]}")
        return 1
    try:
        text = _resolve_text_payload(arguments[1:], allow_stdin_fallback=True)
    except ValueError as error:
        print(str(error))
        return 1
    if text is None:
        print("Chunk text cannot be empty.")
        return 1
    file_entry, _ = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    append_start_line = _count_source_lines(root_dir, file_entry["path"]) + 1
    changed = append_to_source(
        root_dir,
        mira_dir,
        file_entry["path"],
        text,
        f"add_chunk {file_entry['file_id']}",
        track_history=not _is_metadata_only_file(file_entry),
    )
    if not changed:
        print("Chunk append produced no source changes.")
        return 0
    appended_end_line = append_start_line + _count_text_lines(text) - 1
    _maybe_prompt_for_chunk_comment(root_dir, mira_dir, file_entry["path"], [], append_start_line, appended_end_line)
    print(f"Appended chunk to file {file_entry['file_id']} and synced source -> .mira.")
    return 0


def _handle_chunk_comment_command(root_dir, mira_dir, global_index, command, arguments):
    if not arguments:
        print(f"Usage: !{command} <chunk_id|chunk_a-chunk_b> [text]")
        return 1

    spec = arguments[0].strip().strip("<>")
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    if file_id is None:
        return 1

    file_entry = _get_file_entry(global_index, file_id)
    file_entry, global_index = _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry)
    file_id, chunk_ids = _resolve_chunk_spec(mira_dir, global_index, spec)
    meta = _load_json(os.path.join(mira_dir, "files", str(file_id), "meta.json"))
    existing_comments = [meta["chunks"][chunk_id].get("comment", "") for chunk_id in chunk_ids]
    has_any_comment = any(existing_comments)

    if command == "delete_comment":
        if not has_any_comment:
            print(f"Chunk {spec} has no comment.")
            return 1
        delete_chunk_comments(root_dir, mira_dir, file_entry["path"], meta, chunk_ids)
        sync_workspace(root_dir, [file_entry["path"]])
        print(f"Deleted comment for chunk {spec}.")
        return 0

    if command == "add_comment" and has_any_comment:
        print(f"Chunk {spec} already has a comment. Use !edit_comment instead.")
        return 1
    if command == "edit_comment" and not has_any_comment:
        print(f"Chunk {spec} has no comment yet. Use !add_comment instead.")
        return 1

    try:
        comment = _resolve_text_payload(arguments[1:], allow_stdin_fallback=True)
    except ValueError as error:
        print(str(error))
        return 1
    if comment is None:
        print("Comment cannot be empty.")
        return 1

    set_chunk_comments(root_dir, mira_dir, file_entry["path"], meta, chunk_ids, comment)
    sync_workspace(root_dir, [file_entry["path"]])
    print(f"Updated comment for chunk {spec}.")
    return 0


def _handle_description_command(mira_dir, global_index, command, arguments):
    file_entry = _require_file_entry(global_index, arguments)
    if file_entry is None:
        return 1

    file_id = str(file_entry["file_id"])
    existing_description = global_index["files"][file_id].get("description", "")

    if command == "delete_description":
        if not existing_description:
            print(f"File {file_id} has no description.")
            return 1
        _update_description(mira_dir, global_index, file_entry, "")
        print(f"Deleted description for file {file_id}.")
        return 0

    if command == "add_description" and existing_description:
        print(f"File {file_id} already has a description. Use !edit_description instead.")
        return 1
    if command == "edit_description" and not existing_description:
        print(f"File {file_id} has no description yet. Use !add_description instead.")
        return 1

    try:
        description = _resolve_text_payload(arguments[1:], allow_stdin_fallback=True)
    except ValueError as error:
        print(str(error))
        return 1
    if description is None:
        print("Description cannot be empty.")
        return 1

    _update_description(mira_dir, global_index, file_entry, description)
    print(f"Updated description for file {file_id}.")
    return 0


def _update_description(mira_dir, global_index, file_entry, description):
    file_id = str(file_entry["file_id"])
    global_entry = global_index["files"][file_id]
    if description:
        global_entry["description"] = description
    else:
        global_entry.pop("description", None)
    _write_json(os.path.join(mira_dir, "global_index.json"), global_index)

    meta_path = os.path.join(mira_dir, "files", file_id, "meta.json")
    meta_json = _load_json(meta_path)
    if description:
        meta_json["description"] = description
    else:
        meta_json.pop("description", None)
    _write_json(meta_path, meta_json)

    skeleton_path = os.path.join(mira_dir, "files", file_id, "skeleton.txt")
    skeleton_lines = _read_text(skeleton_path).splitlines()
    skeleton_header = f"# FILE: {global_entry['name']} (ID: {file_id})"
    if description:
        skeleton_header = f"{skeleton_header} - {description}"
    if skeleton_lines:
        skeleton_lines[0] = skeleton_header
    _write_text(skeleton_path, "\n".join(skeleton_lines) + "\n")

    project_path = os.path.join(mira_dir, "project.mira")
    project_lines = _read_text(project_path).splitlines()
    for index, line in enumerate(project_lines):
        if f"[{file_id}] {global_entry['name']} (" not in line:
            continue
        base_line = line.split(" # ", 1)[0]
        if description:
            project_lines[index] = f"{base_line} # {description}"
        else:
            project_lines[index] = base_line
        break
    _write_text(project_path, "\n".join(project_lines) + "\n")


def _commented_chunk_signatures(root_dir, relative_path, meta, chunk_ids):
    commented_chunk_ids = [chunk_id for chunk_id in chunk_ids if meta["chunks"].get(chunk_id, {}).get("comment")]
    if not commented_chunk_ids:
        return []
    return chunk_comment_signatures(root_dir, relative_path, meta, commented_chunk_ids)


def _maybe_prompt_for_chunk_comment(root_dir, mira_dir, relative_path, previous_comment_signatures, start_line=None, end_line=None):
    if not sys.stdin.isatty():
        return

    global_index = _load_json(os.path.join(mira_dir, "global_index.json"))
    file_entry = _get_file_entry_by_path(global_index, relative_path)
    if file_entry is None:
        if previous_comment_signatures:
            delete_chunk_comment_signatures(mira_dir, relative_path, previous_comment_signatures)
        return

    meta = _load_json(os.path.join(mira_dir, "files", str(file_entry["file_id"]), "meta.json"))
    current_signatures = file_chunk_signature_set(root_dir, relative_path, meta)
    obsolete_signatures = [signature for signature in previous_comment_signatures if signature not in current_signatures]
    if obsolete_signatures:
        delete_chunk_comment_signatures(mira_dir, relative_path, obsolete_signatures)

    candidate_chunk_ids = _chunk_ids_covering_span(meta, start_line, end_line)
    if obsolete_signatures and candidate_chunk_ids:
        if _confirm_yes_no("Updated chunk comment no longer matches the edited code. Update comment? [y/n]", eof_default=False):
            comment = _prompt_chunk_comment_text()
            if comment:
                set_chunk_comments(root_dir, mira_dir, relative_path, meta, candidate_chunk_ids, comment)
                sync_workspace(root_dir, [relative_path])
        return

    if candidate_chunk_ids and not any(meta["chunks"][chunk_id].get("comment") for chunk_id in candidate_chunk_ids):
        if _confirm_yes_no("Edited chunk has no comment. Add one? [y/n]", eof_default=False):
            comment = _prompt_chunk_comment_text()
            if comment:
                set_chunk_comments(root_dir, mira_dir, relative_path, meta, candidate_chunk_ids, comment)
                sync_workspace(root_dir, [relative_path])


def _prompt_chunk_comment_text():
    print("Enter chunk comment:")
    try:
        comment = input().strip()
    except EOFError:
        return None
    if not comment:
        print("Comment cancelled.")
        return None
    return comment


def _chunk_ids_covering_span(meta, start_line, end_line):
    if start_line is None or end_line is None:
        return []
    if end_line < start_line:
        end_line = start_line

    chunk_ids = []
    for chunk_id, chunk_meta in meta.get("chunks", {}).items():
        chunk_start, chunk_end = _parse_lines(chunk_meta["lines"])
        if chunk_end < start_line or chunk_start > end_line:
            continue
        chunk_ids.append(chunk_id)
    return sorted(chunk_ids, key=_chunk_sort_key)


def _count_text_lines(text):
    if not text:
        return 0
    return max(1, len(text.splitlines()))


def _list_terminals(mira_dir):
    terminals = list_terminals(mira_dir)
    if not terminals:
        print("No managed terminals.")
        return 0
    for terminal in terminals:
        line = f"[{terminal['id']}] {terminal['status']}"
        if terminal.get("command"):
            line = f"{line} | {terminal['command']}"
        print(line)
    return 0


def _handle_terminal_command(root_dir, mira_dir, arguments):
    if not arguments:
        terminals = list_terminals(mira_dir)
        if not terminals:
            print("No managed terminals. Use !terminal <command> to create one.")
            return 0
        latest = terminals[-1]
        terminal, output = show_terminal(mira_dir, latest["id"])
        _print_terminal_details(terminal, output)
        return 0

    if len(arguments) == 1 and arguments[0].isdigit():
        terminal, output = show_terminal(mira_dir, int(arguments[0]))
        _print_terminal_details(terminal, output)
        return 0

    terminal_id, wait_mode, wait_seconds, create_new, command_parts = _parse_terminal_arguments(arguments)
    if terminal_id == "delete":
        return _handle_terminal_delete(mira_dir, [str(wait_mode)])
    if not command_parts:
        print("Usage: !terminal [--id <id>] [--new] [--no-wait|--wait <seconds>] <command>")
        return 1

    terminals = list_terminals(mira_dir)
    latest_running = terminals[-1] if terminals and terminals[-1]["status"] == "running" else None

    try:
        terminal, output = run_terminal_command(
            mira_dir,
            root_dir,
            " ".join(command_parts),
            terminal_id=terminal_id,
            wait_mode=wait_mode,
            wait_seconds=wait_seconds,
            create_new=create_new,
        )
    except ValueError as error:
        print(str(error))
        return 1

    if terminal_id is None and not create_new and latest_running is not None and latest_running["id"] != terminal["id"]:
        print(f"Latest terminal [{latest_running['id']}] is running, so MIRA created terminal [{terminal['id']}].")
    _print_terminal_details(terminal, output)
    return 0


def _handle_terminal_delete(mira_dir, arguments):
    if not arguments or not arguments[0].isdigit():
        print("Usage: !terminal delete <id>")
        return 1
    try:
        terminal = delete_terminal(mira_dir, int(arguments[0]))
    except ValueError as error:
        print(str(error))
        return 1
    if terminal.get("status") == "running":
        print(f"Deleted terminal {arguments[0]} and stopped the running process.")
    else:
        print(f"Deleted terminal {arguments[0]}.")
    return 0


def _print_terminal_details(terminal, output):
    print(f"Terminal [{terminal['id']}] status: {terminal['status']}")
    if terminal.get("command"):
        print(f"Command: {terminal['command']}")
    if terminal.get("cwd"):
        print(f"Cwd: {terminal['cwd']}")
    if output:
        print(output)


def _parse_terminal_arguments(arguments):
    if len(arguments) == 2 and arguments[0].lower() == "delete" and arguments[1].isdigit():
        return "delete", int(arguments[1]), None, False, []

    terminal_id = None
    wait_mode = "finish"
    wait_seconds = None
    create_new = False
    command_parts = []
    index = 0

    while index < len(arguments):
        token = arguments[index]
        if token == "--id" and index + 1 < len(arguments):
            terminal_id = int(arguments[index + 1])
            index += 2
            continue
        if token == "--new":
            create_new = True
            index += 1
            continue
        if token == "--no-wait":
            wait_mode = "none"
            index += 1
            continue
        if token == "--wait" and index + 1 < len(arguments):
            wait_mode = "seconds"
            wait_seconds = int(arguments[index + 1])
            index += 2
            continue
        command_parts = arguments[index:]
        break

    return terminal_id, wait_mode, wait_seconds, create_new, command_parts


def _print_document_edit_usage(label):
    print(f"Usage: !edit_{label} [text]")
    print(f"Usage: !edit_{label} lines <start>-<end> [text]")
    print(f"Usage: !edit_{label} delete <start>-<end>")


def _parse_line_span(raw_value):
    value = raw_value.strip()
    if not value:
        raise ValueError("Missing line range.")
    if "-" in value:
        start_text, end_text = value.split("-", 1)
    else:
        start_text = value
        end_text = value
    if not start_text.isdigit() or not end_text.isdigit():
        raise ValueError(f"Invalid line range: {raw_value}")
    start_line = int(start_text)
    end_line = int(end_text)
    if start_line < 1 or end_line < 1:
        raise ValueError(f"Invalid line range: {raw_value}")
    if end_line < start_line:
        start_line, end_line = end_line, start_line
    return start_line, end_line


def _format_line_span(start_line, end_line):
    if start_line == end_line:
        return str(start_line)
    return f"{start_line}-{end_line}"


def _require_file_entry(global_index, arguments):
    if not arguments:
        print("Missing file ID.")
        return None
    file_entry = _get_file_entry(global_index, arguments[0])
    if file_entry is None:
        print(f"Unknown file ID: {arguments[0]}")
        return None
    return file_entry


def _get_file_entry(global_index, raw_file_id):
    file_id = str(raw_file_id)
    file_entry = global_index["files"].get(file_id)
    if file_entry is None:
        return None
    return {"file_id": int(file_id), **file_entry}


def _get_file_entry_by_path(global_index, relative_path):
    for file_id, file_entry in global_index["files"].items():
        if file_entry.get("path") == relative_path:
            return {"file_id": int(file_id), **file_entry}
    return None


def _ensure_file_fresh(root_dir, mira_dir, global_index, file_entry):
    if not is_file_stale(root_dir, mira_dir, file_entry):
        return file_entry, global_index
    sync_workspace(root_dir, [file_entry["path"]])
    refreshed_index = _load_json(os.path.join(mira_dir, "global_index.json"))
    refreshed_entry = _get_file_entry(refreshed_index, file_entry["file_id"])
    return refreshed_entry, refreshed_index


def _is_metadata_only_file(file_entry):
    return file_entry.get("storage_mode") == "metadata-only"


def _expand_document_chunks(root_dir, file_entry, meta, chunk_ids):
    char_limit = int(file_entry.get("retrieval_char_limit", 10000) or 10000)
    output_parts = []
    total_chars = 0

    for chunk_id in chunk_ids:
        start_line, end_line = _parse_lines(meta["chunks"][chunk_id]["lines"])
        text = _read_source_range(root_dir, file_entry["path"], start_line, end_line)
        total_chars += len(text)
        if total_chars > char_limit:
            print(f"Document preview exceeds {char_limit} chars. Narrow the requested section or line span.")
            return 1
        output_parts.append(text)

    print("".join(output_parts), end="")
    return 0


def _search_document_lines(root_dir, file_id, file_entry, query):
    matches = []
    source_path = os.path.join(root_dir, file_entry["path"])
    if not os.path.exists(source_path):
        return matches

    with open(source_path, "r", encoding="utf-8", errors="replace") as handle:
        for line_number, line in enumerate(handle, start=1):
            if query in line.lower():
                matches.append(f"[{file_id}] {file_entry['path']}:{line_number}: {line.rstrip()}")
            if len(matches) >= 50:
                break
    return matches


def _read_source_range(root_dir, relative_path, start_line, end_line):
    source_path = os.path.join(root_dir, relative_path)
    if not os.path.exists(source_path):
        raise ValueError(f"Current file is missing: {source_path}")

    chunks = []
    with open(source_path, "r", encoding="utf-8", errors="replace") as handle:
        for line_number, line in enumerate(handle, start=1):
            if line_number < start_line:
                continue
            if line_number > end_line:
                break
            chunks.append(line)
    return "".join(chunks)


def _resolve_chunk_spec(mira_dir, global_index, spec):
    normalized = re.sub(r"\s+", "", spec)
    match = re.fullmatch(r"(\d+)_(\d+)(?:-(\d+)_(\d+))?", normalized)
    if not match:
        if normalized.isdigit():
            print("Use !explore <file_id> to show file structure.")
            return None, None
        print(f"Invalid chunk spec: {spec}")
        return None, None

    start_file_id = int(match.group(1))
    start_chunk = int(match.group(2))
    end_file_id = int(match.group(3) or start_file_id)
    end_chunk = int(match.group(4) or start_chunk)
    if start_file_id != end_file_id:
        print("Chunk ranges must stay within a single file.")
        return None, None
    if _get_file_entry(global_index, start_file_id) is None:
        print(f"Unknown file ID: {start_file_id}")
        return None, None

    meta = _load_json(os.path.join(mira_dir, "files", str(start_file_id), "meta.json"))
    if end_chunk < start_chunk:
        start_chunk, end_chunk = end_chunk, start_chunk
    chunk_ids = []
    for chunk_number in range(start_chunk, end_chunk + 1):
        chunk_id = f"{start_file_id}_{chunk_number}"
        if chunk_id not in meta["chunks"]:
            print(f"Unknown chunk ID: {chunk_id}")
            return None, None
        chunk_ids.append(chunk_id)
    return start_file_id, chunk_ids


def _confirm_large_expand(total_lines, chunk_ids):
    print(f"Are you sure you want to expand chunk with length {total_lines} lines ({', '.join(chunk_ids)})? [y/n]")
    try:
        response = input().strip().lower()
    except EOFError:
        return False
    return response in {"y", "yes"}


def _resolve_text_payload(arguments, allow_stdin_fallback=False):
    if not arguments:
        if allow_stdin_fallback and not sys.stdin.isatty():
            text = _strip_leading_bom(sys.stdin.read())
            return text if text != "" else None
        return None
    if all(argument == "--stdin" for argument in arguments):
        text = _strip_leading_bom(sys.stdin.read())
        return text if text != "" else None
    if arguments[0] == "--stdin":
        raise ValueError("`--stdin` cannot be combined with inline text.")
    if len(arguments) == 1 and arguments[0].startswith("@@"):
        return _decode_text_arguments([arguments[0][1:]])
    return _decode_text_arguments(arguments)


def _decode_text_arguments(arguments):
    if not arguments:
        return None
    text = " ".join(arguments).strip()
    if not text:
        return None
    return text.replace("\\n", "\n").replace("\\t", "\t").replace('\\"', '"').replace("\\'", "'")


def _strip_leading_bom(text):
    if text.startswith("\ufeff"):
        return text[1:]
    return text


def _parse_lines(lines_text):
    start_text, end_text = lines_text.split("-", 1)
    return int(start_text), int(end_text)


def _load_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _load_json_if_exists(path, default):
    if not os.path.exists(path):
        return default
    try:
        return _load_json(path)
    except Exception:
        return default


def _write_json(path, payload):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


def _read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def _write_text(path, text):
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


def _chunk_sort_key(chunk_id):
    file_part, local_part = chunk_id.split("_", 1)
    return int(file_part), int(local_part)