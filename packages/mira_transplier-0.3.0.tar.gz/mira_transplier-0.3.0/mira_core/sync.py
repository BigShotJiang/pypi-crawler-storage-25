import difflib
import hashlib
import json
import os
import shutil
import tempfile
from datetime import datetime

from mira_core.analyzer import analyze_target, get_parser
from mira_core.generator import generate_outputs


CACHE_PATH = os.path.join("cache", "source_index.json")
HISTORY_INDEX_PATH = os.path.join("history", "index.json")
HISTORY_BASE_DIR = os.path.join("history", "base")


def sync_workspace(root_dir, relative_paths=None):
    mira_dir = os.path.join(root_dir, ".mira")
    if relative_paths is None:
        project_data = analyze_target(root_dir)
        generate_outputs(root_dir, project_data)
        return project_data

    project_data = load_cached_project_data(mira_dir)
    if not project_data.get("files"):
        project_data = analyze_target(root_dir)
        generate_outputs(root_dir, project_data)
        return project_data

    for relative_path in relative_paths:
        absolute_path = os.path.join(root_dir, relative_path)
        if not os.path.exists(absolute_path):
            project_data["files"].pop(relative_path, None)
            continue

        parser = get_parser(absolute_path)
        if parser is None:
            project_data["files"].pop(relative_path, None)
            continue

        project_data["files"][relative_path] = parser.parse(absolute_path)

    generate_outputs(root_dir, project_data)
    return project_data


def load_cached_project_data(mira_dir):
    cache_path = os.path.join(mira_dir, CACHE_PATH)
    return _load_json_if_exists(cache_path, {"files": {}})


def apply_source_edit(root_dir, mira_dir, relative_path, start_line, end_line, replacement_text, command_name, track_history=True):
    source_path = os.path.join(root_dir, relative_path)
    if not track_history:
        return _apply_source_edit_streaming(
            root_dir,
            mira_dir,
            relative_path,
            start_line,
            end_line,
            replacement_text,
            command_name,
        )

    before_text = _read_text(source_path)
    before_lines = before_text.splitlines(keepends=True)
    replacement_lines = _normalize_replacement_text(replacement_text)

    if start_line < 1:
        start_line = 1
    if end_line < start_line - 1:
        end_line = start_line - 1

    after_lines = list(before_lines)
    start_index = max(0, start_line - 1)
    end_index = max(0, end_line)
    after_lines[start_index:end_index] = replacement_lines
    after_text = "".join(after_lines)
    return _commit_source_text(root_dir, mira_dir, relative_path, before_text, after_text, command_name, track_history=track_history)


def append_to_source(root_dir, mira_dir, relative_path, text, command_name, track_history=True):
    source_path = os.path.join(root_dir, relative_path)
    if not track_history:
        line_count = _count_file_lines(source_path)
        return _apply_source_edit_streaming(
            root_dir,
            mira_dir,
            relative_path,
            line_count + 1,
            line_count,
            text,
            command_name,
        )

    before_text = _read_text(source_path)
    addition = _normalize_input_text(text)
    if before_text and not before_text.endswith("\n") and addition:
        addition = "\n" + addition
    after_text = before_text + addition
    return _commit_source_text(root_dir, mira_dir, relative_path, before_text, after_text, command_name, track_history=track_history)


def record_history_event(mira_dir, relative_path, before_text, after_text, command_name):
    if before_text == after_text:
        return

    history_index_path = os.path.join(mira_dir, HISTORY_INDEX_PATH)
    history_index = _load_json_if_exists(history_index_path, {"files": {}})
    entry = history_index["files"].get(relative_path)
    current_hash = _stable_text_hash(before_text)

    if entry is None or entry.get("current_hash") != current_hash:
        entry = _reset_history_entry(mira_dir, relative_path, before_text)

    before_lines = before_text.splitlines(keepends=True)
    after_lines = after_text.splitlines(keepends=True)
    changes = _build_change_ops(before_lines, after_lines)
    if not changes:
        return

    version = int(entry.get("current_version", 1)) + 1
    entry.setdefault("events", []).append(
        {
            "version": version,
            "timestamp": datetime.utcnow().isoformat(timespec="seconds") + "Z",
            "command": command_name,
            "changes": changes,
            "added_lines": sum(len(change["new_lines"]) for change in changes),
            "removed_lines": sum(change["end"] - change["start"] for change in changes),
        }
    )
    entry["current_version"] = version
    entry["current_hash"] = _stable_text_hash(after_text)
    history_index["files"][relative_path] = entry
    _write_json(history_index_path, history_index)


def list_history(mira_dir, relative_path):
    history_index = _load_json_if_exists(os.path.join(mira_dir, HISTORY_INDEX_PATH), {"files": {}})
    entry = history_index["files"].get(relative_path)
    if entry is None:
        return []

    items = [
        {
            "version": 1,
            "command": "base",
            "timestamp": None,
            "added_lines": 0,
            "removed_lines": 0,
        }
    ]
    items.extend(entry.get("events", []))
    return items


def restore_version(root_dir, mira_dir, relative_path, version):
    history_index = _load_json_if_exists(os.path.join(mira_dir, HISTORY_INDEX_PATH), {"files": {}})
    entry = history_index["files"].get(relative_path)
    if entry is None:
        raise ValueError(f"No history found for {relative_path}")

    target_version = int(version)
    if target_version < 1 or target_version > int(entry.get("current_version", 1)):
        raise ValueError(f"Unknown version: {version}")

    restored_text = reconstruct_version(mira_dir, relative_path, target_version)
    source_path = os.path.join(root_dir, relative_path)
    current_text = _read_text(source_path)
    return _commit_source_text(root_dir, mira_dir, relative_path, current_text, restored_text, f"restore {target_version}")


def reconstruct_version(mira_dir, relative_path, version):
    history_index = _load_json_if_exists(os.path.join(mira_dir, HISTORY_INDEX_PATH), {"files": {}})
    entry = history_index["files"].get(relative_path)
    if entry is None:
        raise ValueError(f"No history found for {relative_path}")

    base_snapshot_path = os.path.join(mira_dir, entry["base_snapshot"])
    lines = _read_text(base_snapshot_path).splitlines(keepends=True)
    if version == 1:
        return "".join(lines)

    for event in entry.get("events", []):
        if int(event["version"]) > version:
            break
        lines = _apply_change_ops(lines, event["changes"])
    return "".join(lines)


def is_file_stale(root_dir, mira_dir, file_entry):
    source_path = os.path.join(root_dir, file_entry["path"])
    if not os.path.exists(source_path):
        return False

    source_signature = file_entry.get("source_signature")
    if source_signature:
        stat = os.stat(source_path)
        current_signature = {
            "size": stat.st_size,
            "mtime_ns": getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)),
        }
        return current_signature != source_signature

    snapshot_path = os.path.join(mira_dir, "snapshots", f"{file_entry['file_id']}.txt")
    if not os.path.exists(snapshot_path):
        return False
    return _read_text(snapshot_path) != _read_text(source_path)


def read_document(mira_dir, name):
    path = os.path.join(mira_dir, name)
    if not os.path.exists(path):
        return ""
    return _read_text(path)


def write_document(mira_dir, name, text):
    path = os.path.join(mira_dir, name)
    normalized = _normalize_input_text(text)
    _write_text(path, normalized)


def update_document_line(mira_dir, name, line_number, text):
    replace_document_lines(mira_dir, name, line_number, line_number, text)


def insert_document_line(mira_dir, name, line_number, text):
    insert_document_lines(mira_dir, name, line_number, text)


def delete_document_line(mira_dir, name, line_number):
    delete_document_lines(mira_dir, name, line_number, line_number)


def replace_document_lines(mira_dir, name, start_line, end_line, text):
    lines = read_document(mira_dir, name).splitlines()
    _validate_document_range(lines, start_line, end_line)
    replacement_lines = _normalize_document_block(text)
    lines[start_line - 1:end_line] = replacement_lines
    _write_text(os.path.join(mira_dir, name), _join_document_lines(lines))


def insert_document_lines(mira_dir, name, line_number, text):
    lines = read_document(mira_dir, name).splitlines()
    if line_number < 1 or line_number > len(lines) + 1:
        raise ValueError(f"Line {line_number} is outside the insertion range.")
    replacement_lines = _normalize_document_block(text)
    lines[line_number - 1:line_number - 1] = replacement_lines
    _write_text(os.path.join(mira_dir, name), _join_document_lines(lines))


def delete_document_lines(mira_dir, name, start_line, end_line):
    lines = read_document(mira_dir, name).splitlines()
    _validate_document_range(lines, start_line, end_line)
    del lines[start_line - 1:end_line]
    _write_text(os.path.join(mira_dir, name), _join_document_lines(lines))


def _apply_source_edit_streaming(root_dir, mira_dir, relative_path, start_line, end_line, replacement_text, command_name):
    source_path = os.path.join(root_dir, relative_path)
    replacement_lines = _normalize_replacement_text(replacement_text)

    if start_line < 1:
        start_line = 1
    if end_line < start_line - 1:
        end_line = start_line - 1

    with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8", newline="") as candidate_handle:
        candidate_path = candidate_handle.name

    backup_path = None
    try:
        _rewrite_source_lines(source_path, candidate_path, start_line, end_line, replacement_lines)
        if _files_have_same_text(source_path, candidate_path):
            return False

        _validate_candidate_source_file(source_path, candidate_path)

        with tempfile.NamedTemporaryFile(delete=False) as backup_handle:
            backup_path = backup_handle.name
        shutil.copyfile(source_path, backup_path)

        os.replace(candidate_path, source_path)
        try:
            sync_workspace(root_dir, [relative_path])
        except Exception:
            if backup_path is not None and os.path.exists(backup_path):
                os.replace(backup_path, source_path)
            sync_workspace(root_dir, [relative_path])
            raise
        return True
    finally:
        for temp_path in (candidate_path, backup_path):
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    pass


def _commit_source_text(root_dir, mira_dir, relative_path, before_text, after_text, command_name, track_history=True):
    if after_text == before_text:
        return False

    source_path = os.path.join(root_dir, relative_path)
    _validate_candidate_source(source_path, after_text)

    try:
        _write_text(source_path, after_text)
        if track_history:
            record_history_event(mira_dir, relative_path, before_text, after_text, command_name)
        sync_workspace(root_dir, [relative_path])
    except Exception:
        _write_text(source_path, before_text)
        sync_workspace(root_dir, [relative_path])
        raise
    return True


def _validate_candidate_source(source_path, candidate_text):
    parser = get_parser(source_path)
    if parser is None:
        return

    suffix = os.path.splitext(source_path)[1]
    with tempfile.NamedTemporaryFile("w", suffix=suffix, delete=False, encoding="utf-8") as handle:
        handle.write(candidate_text)
        temp_path = handle.name
    try:
        parser.parse(temp_path)
    finally:
        try:
            os.remove(temp_path)
        except OSError:
            pass


def _validate_candidate_source_file(source_path, candidate_path):
    parser = get_parser(source_path)
    if parser is None:
        return
    parser.parse(candidate_path)


def _rewrite_source_lines(source_path, candidate_path, start_line, end_line, replacement_lines):
    inserted = False
    with open(source_path, "r", encoding="utf-8", errors="replace") as source_handle, open(
        candidate_path, "w", encoding="utf-8", newline=""
    ) as candidate_handle:
        for line_number, line in enumerate(source_handle, start=1):
            if not inserted and line_number == start_line:
                for replacement_line in replacement_lines:
                    candidate_handle.write(replacement_line)
                inserted = True
            if start_line <= line_number <= end_line:
                continue
            candidate_handle.write(line)

        if not inserted:
            for replacement_line in replacement_lines:
                candidate_handle.write(replacement_line)


def _files_have_same_text(first_path, second_path):
    with open(first_path, "rb") as first_handle, open(second_path, "rb") as second_handle:
        while True:
            first_chunk = first_handle.read(65536)
            second_chunk = second_handle.read(65536)
            if first_chunk != second_chunk:
                return False
            if not first_chunk:
                return True


def _count_file_lines(path):
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        return sum(1 for _ in handle)


def _reset_history_entry(mira_dir, relative_path, base_text):
    history_dir = os.path.join(mira_dir, HISTORY_BASE_DIR)
    os.makedirs(history_dir, exist_ok=True)
    safe_name = _safe_history_name(relative_path)
    base_snapshot_path = os.path.join(history_dir, safe_name)
    _write_text(base_snapshot_path, base_text)
    return {
        "current_version": 1,
        "current_hash": _stable_text_hash(base_text),
        "base_snapshot": os.path.join(HISTORY_BASE_DIR, safe_name).replace("\\", "/"),
        "events": [],
    }


def _build_change_ops(before_lines, after_lines):
    matcher = difflib.SequenceMatcher(a=before_lines, b=after_lines)
    changes = []
    for tag, start_a, end_a, start_b, end_b in matcher.get_opcodes():
        if tag == "equal":
            continue
        changes.append(
            {
                "tag": tag,
                "start": start_a,
                "end": end_a,
                "new_lines": after_lines[start_b:end_b],
            }
        )
    return changes


def _apply_change_ops(lines, changes):
    updated = list(lines)
    for change in sorted(changes, key=lambda item: item["start"], reverse=True):
        updated[change["start"]:change["end"]] = change["new_lines"]
    return updated


def _normalize_replacement_text(text):
    normalized = _normalize_input_text(text)
    if normalized and not normalized.endswith("\n"):
        normalized = normalized + "\n"
    return normalized.splitlines(keepends=True)


def _normalize_input_text(text):
    return text.replace("\\n", "\n").replace("\\t", "\t")


def _normalize_single_line_text(text):
    normalized = _normalize_input_text(text).replace("\r\n", "\n").replace("\r", "\n").rstrip("\n")
    if "\n" in normalized:
        raise ValueError("Line edits accept exactly one logical line.")
    return normalized


def _normalize_document_block(text):
    normalized = _normalize_input_text(text).replace("\r\n", "\n").replace("\r", "\n")
    if normalized.endswith("\n"):
        normalized = normalized[:-1]
    if normalized == "":
        raise ValueError("Replacement text cannot be empty.")
    return normalized.split("\n")


def _join_document_lines(lines):
    return "\n".join(lines)


def _validate_document_range(lines, start_line, end_line):
    if start_line > end_line:
        raise ValueError(f"Invalid line range: {start_line}-{end_line}")
    if start_line < 1 or end_line > len(lines):
        raise ValueError(f"Line range {start_line}-{end_line} is outside the current document.")


def _safe_history_name(relative_path):
    return relative_path.replace("/", "__") + ".txt"


def _stable_text_hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _load_json_if_exists(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return default


def _read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def _write_text(path, text):
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


def _write_json(path, payload):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
