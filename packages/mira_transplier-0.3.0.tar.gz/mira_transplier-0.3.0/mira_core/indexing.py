import json
import os


ADMIN_DIR = "ADMIN"
INDEX_STATE_PATH = os.path.join(ADMIN_DIR, "index.json")
LARGE_FOLDER_THRESHOLD = 50
STATE_VERSION = 2
AUTO_INCLUDED_DOTFILES = {".gitignore"}
IGNORED_DIRECTORIES = {"__pycache__", "build", "dist", "env", "node_modules", "site-packages", "venv"}
IGNORED_DIRECTORY_SUFFIXES = (".dist-info", ".egg-info")


def ensure_index_state(root_dir, interactive=True):
    mira_dir = os.path.join(root_dir, ".mira")
    admin_dir = os.path.join(mira_dir, ADMIN_DIR)
    os.makedirs(admin_dir, exist_ok=True)

    index_path = os.path.join(mira_dir, INDEX_STATE_PATH)
    state = _load_state(root_dir, index_path)
    state.setdefault("version", STATE_VERSION)
    state.setdefault("entries", {})

    discovered_entries = _scan_workspace_entries(root_dir)
    for entry in state["entries"].values():
        entry["present"] = False

    for relative_path, discovered_entry in discovered_entries.items():
        existing = state["entries"].get(relative_path)
        if existing is None:
            state["entries"][relative_path] = _build_new_entry(relative_path, discovered_entry, interactive)
            continue

        existing["kind"] = discovered_entry["kind"]
        existing["present"] = True
        existing["file_count"] = discovered_entry["file_count"]
        existing.setdefault("ever_included", bool(existing.get("included")))
        existing.setdefault(
            "large_folder_confirmed",
            existing["kind"] != "folder" or discovered_entry["file_count"] < LARGE_FOLDER_THRESHOLD,
        )

    for relative_path, entry in state["entries"].items():
        if entry.get("present"):
            continue
        absolute_path = _absolute_path(root_dir, relative_path)
        if not os.path.exists(absolute_path):
            continue
        entry["present"] = True
        if os.path.isdir(absolute_path):
            entry["kind"] = "folder"
            entry["file_count"] = _count_direct_indexable_files(absolute_path)
        else:
            entry["kind"] = "file"
            entry["file_count"] = 1
        entry.setdefault("ever_included", bool(entry.get("included")))
        entry.setdefault(
            "large_folder_confirmed",
            entry["kind"] != "folder" or entry["file_count"] < LARGE_FOLDER_THRESHOLD,
        )

    for relative_path in [path for path in state["entries"] if _should_purge_entry(path)]:
        del state["entries"][relative_path]

    state["version"] = STATE_VERSION
    _write_json(index_path, state)
    return state


def list_index_entries(root_dir, interactive=True):
    state = ensure_index_state(root_dir, interactive=interactive)
    entries = []
    for relative_path in sorted(state["entries"], key=_entry_sort_key):
        entries.append({"path": relative_path, **state["entries"][relative_path]})
    return entries


def collect_indexed_file_paths(root_dir, interactive=True):
    state = ensure_index_state(root_dir, interactive=interactive)
    included_files = set()

    for relative_path in sorted(state["entries"], key=_entry_sort_key):
        entry = state["entries"][relative_path]
        if not entry.get("present") or not entry.get("included"):
            continue

        absolute_path = _absolute_path(root_dir, relative_path)
        if entry["kind"] == "file":
            if os.path.isfile(absolute_path):
                included_files.add(relative_path)
            continue

        if not os.path.isdir(absolute_path):
            continue

        for child_name in sorted(os.listdir(absolute_path)):
            child_path = os.path.join(absolute_path, child_name)
            if os.path.isdir(child_path):
                continue
            if _should_ignore_file_by_default(child_name):
                continue
            included_files.add(_join_relative_path(relative_path, child_name))

    return sorted(included_files, key=_entry_sort_key)


def set_index_entry_included(root_dir, raw_path, included, interactive=True):
    relative_path = normalize_workspace_path(raw_path)
    state = ensure_index_state(root_dir, interactive=interactive)
    entry = state["entries"].get(relative_path)
    absolute_path = _absolute_path(root_dir, relative_path)

    if entry is None:
        if not os.path.exists(absolute_path):
            raise ValueError(f"Unknown entry: {relative_path}")
        if os.path.isdir(absolute_path):
            entry = _build_manual_entry(absolute_path, "folder")
        else:
            if not _can_index_file_explicitly(relative_path):
                raise ValueError(_folder_index_message(relative_path))
            entry = _build_manual_entry(absolute_path, "file")
        state["entries"][relative_path] = entry

    if entry["kind"] == "file" and not _can_index_file_explicitly(relative_path):
        raise ValueError(_folder_index_message(relative_path))

    if included and entry["kind"] == "folder" and entry.get("file_count", 0) >= LARGE_FOLDER_THRESHOLD and not entry.get("ever_included"):
        if not _confirm_large_folder(relative_path, entry["file_count"], interactive):
            entry["included"] = False
            _write_json(os.path.join(root_dir, ".mira", INDEX_STATE_PATH), state)
            return entry
        entry["large_folder_confirmed"] = True

    entry["included"] = bool(included)
    entry["present"] = os.path.exists(absolute_path)
    if included:
        entry["ever_included"] = True

    if not included and entry["kind"] == "folder":
        prefix = f"{relative_path}/"
        for child_path, child_entry in state["entries"].items():
            if child_path.startswith(prefix):
                child_entry["included"] = False

    _write_json(os.path.join(root_dir, ".mira", INDEX_STATE_PATH), state)
    return entry


def register_created_path(root_dir, raw_path, kind):
    relative_path = normalize_workspace_path(raw_path)
    state = ensure_index_state(root_dir, interactive=False)

    for folder_path in _ancestor_folders(relative_path, include_self=kind == "folder"):
        folder_absolute_path = _absolute_path(root_dir, folder_path)
        entry = state["entries"].get(folder_path)
        if entry is None:
            entry = _build_manual_entry(folder_absolute_path, "folder")
            state["entries"][folder_path] = entry
        entry["kind"] = "folder"
        entry["present"] = os.path.isdir(folder_absolute_path)
        entry["file_count"] = _count_direct_indexable_files(folder_absolute_path) if entry["present"] else 0
        entry["included"] = True
        entry["ever_included"] = True
        entry["large_folder_confirmed"] = True

    if kind == "file" and _can_index_file_explicitly(relative_path):
        absolute_path = _absolute_path(root_dir, relative_path)
        entry = state["entries"].get(relative_path)
        if entry is None:
            entry = _build_manual_entry(absolute_path, "file")
            state["entries"][relative_path] = entry
        entry["kind"] = "file"
        entry["present"] = os.path.isfile(absolute_path)
        entry["file_count"] = 1
        entry["included"] = True
        entry["ever_included"] = True
        entry["large_folder_confirmed"] = True

    _write_json(os.path.join(root_dir, ".mira", INDEX_STATE_PATH), state)


def remove_deleted_path(root_dir, raw_path):
    relative_path = normalize_workspace_path(raw_path)
    state = ensure_index_state(root_dir, interactive=False)

    to_remove = [path for path in state["entries"] if path == relative_path or path.startswith(f"{relative_path}/")]
    for path in to_remove:
        del state["entries"][path]

    _write_json(os.path.join(root_dir, ".mira", INDEX_STATE_PATH), state)


def normalize_workspace_path(raw_path):
    path = raw_path.strip().replace("\\", "/")
    path = path.lstrip("/")
    if not path or path in {".", ".."}:
        raise ValueError("Invalid path.")
    if ":" in path:
        raise ValueError("Paths must stay inside the workspace.")

    normalized = os.path.normpath(path).replace("\\", "/")
    if normalized in {".", ""}:
        raise ValueError("Invalid path.")
    if normalized == ".." or normalized.startswith("../"):
        raise ValueError("Paths must stay inside the workspace.")
    if normalized == ".mira" or normalized.startswith(".mira/"):
        raise ValueError("Paths inside .mira are reserved.")
    return normalized


def _load_state(root_dir, index_path):
    state = _load_json_if_exists(index_path, {"version": STATE_VERSION, "entries": {}})
    if "entries" in state:
        return state
    if "roots" in state:
        return _migrate_legacy_roots(root_dir, state)
    return {"version": STATE_VERSION, "entries": {}}


def _migrate_legacy_roots(root_dir, legacy_state):
    entries = {}
    discovered_entries = _scan_workspace_entries(root_dir)
    legacy_roots = legacy_state.get("roots", {})

    for relative_path, discovered_entry in discovered_entries.items():
        root_name = relative_path.split("/", 1)[0]
        legacy_entry = legacy_roots.get(root_name)
        included = bool(legacy_entry.get("included", True)) if legacy_entry else True
        ever_included = bool(legacy_entry.get("ever_included", included)) if legacy_entry else included
        large_folder_confirmed = (
            bool(legacy_entry.get("large_folder_confirmed", True))
            if legacy_entry
            else discovered_entry["kind"] != "folder" or discovered_entry["file_count"] < LARGE_FOLDER_THRESHOLD
        )
        entries[relative_path] = {
            "kind": discovered_entry["kind"],
            "included": included,
            "present": True,
            "file_count": discovered_entry["file_count"],
            "ever_included": ever_included,
            "large_folder_confirmed": large_folder_confirmed,
        }

    return {"version": STATE_VERSION, "entries": entries}


def _scan_workspace_entries(root_dir):
    entries = {}

    for current_root, directories, files in os.walk(root_dir):
        directories[:] = _filter_auto_directories(directories)
        relative_directory = os.path.relpath(current_root, root_dir).replace("\\", "/")
        if relative_directory == ".":
            relative_directory = ""

        if relative_directory:
            entries[relative_directory] = {
                "kind": "folder",
                "file_count": _count_direct_indexable_file_names(files),
            }

        for filename in sorted(files):
            if _should_auto_include_file(relative_directory, filename):
                entries[_join_relative_path(relative_directory, filename)] = {"kind": "file", "file_count": 1}

    return entries


def _filter_auto_directories(directories):
    filtered = []
    for directory in directories:
        if directory == ".mira":
            continue
        if directory.startswith("."):
            continue
        if _is_ignored_directory(directory):
            continue
        filtered.append(directory)
    filtered.sort()
    return filtered


def _should_auto_include_file(relative_directory, filename):
    if filename in AUTO_INCLUDED_DOTFILES:
        return True
    if relative_directory:
        return False
    return not filename.startswith(".")


def _should_ignore_file_by_default(filename):
    return filename.startswith(".") and filename not in AUTO_INCLUDED_DOTFILES


def _count_direct_indexable_files(absolute_directory):
    try:
        filenames = os.listdir(absolute_directory)
    except OSError:
        return 0
    file_names = [filename for filename in filenames if os.path.isfile(os.path.join(absolute_directory, filename))]
    return _count_direct_indexable_file_names(file_names)


def _count_direct_indexable_file_names(file_names):
    count = 0
    for filename in file_names:
        if _should_ignore_file_by_default(filename):
            continue
        count += 1
    return count


def _build_new_entry(relative_path, discovered_entry, interactive):
    kind = discovered_entry["kind"]
    file_count = discovered_entry["file_count"]
    included = True
    confirmed = kind != "folder" or file_count < LARGE_FOLDER_THRESHOLD
    ever_included = included

    if kind == "folder" and file_count >= LARGE_FOLDER_THRESHOLD:
        included = _confirm_large_folder(relative_path, file_count, interactive)
        confirmed = included
        ever_included = included

    return {
        "kind": kind,
        "included": included,
        "present": True,
        "file_count": file_count,
        "ever_included": ever_included,
        "large_folder_confirmed": confirmed,
    }


def _build_manual_entry(absolute_path, kind):
    file_count = _count_direct_indexable_files(absolute_path) if kind == "folder" else 1
    return {
        "kind": kind,
        "included": False,
        "present": os.path.exists(absolute_path),
        "file_count": file_count,
        "ever_included": False,
        "large_folder_confirmed": kind != "folder" or file_count < LARGE_FOLDER_THRESHOLD,
    }


def _confirm_large_folder(relative_path, file_count, interactive):
    if not interactive:
        return False
    print(f"This {relative_path} folder has {file_count} files. Are you sure you want to index it? [y/n]")
    try:
        response = input().strip().lower()
    except EOFError:
        return False
    return response in {"y", "yes"}


def _can_index_file_explicitly(relative_path):
    filename = os.path.basename(relative_path)
    parent = relative_path.rsplit("/", 1)[0] if "/" in relative_path else ""
    return not parent or filename.startswith(".") or filename in AUTO_INCLUDED_DOTFILES


def _folder_index_message(relative_path):
    folder_path = relative_path.rsplit("/", 1)[0]
    return f"Index the folder instead: {folder_path}"


def _ancestor_folders(relative_path, include_self=False):
    segments = relative_path.split("/")
    if not segments:
        return []

    folder_count = len(segments) if include_self else len(segments) - 1
    folders = []
    for index in range(1, folder_count + 1):
        folders.append("/".join(segments[:index]))
    return folders


def _join_relative_path(parent, child):
    if not parent:
        return child
    return f"{parent}/{child}"


def _absolute_path(root_dir, relative_path):
    return os.path.join(root_dir, *relative_path.split("/"))


def _entry_sort_key(relative_path):
    return relative_path.count("/"), relative_path


def _should_purge_entry(relative_path):
    parts = relative_path.split("/")
    return any(_is_ignored_directory(part) for part in parts)


def _is_ignored_directory(directory_name):
    return directory_name in IGNORED_DIRECTORIES or directory_name.endswith(IGNORED_DIRECTORY_SUFFIXES)


def _load_json_if_exists(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return default


def _write_json(path, payload):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)