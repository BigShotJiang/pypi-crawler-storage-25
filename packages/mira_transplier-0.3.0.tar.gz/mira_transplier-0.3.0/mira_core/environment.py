import json
import os
import subprocess
import sys


ENVIRONMENT_STATE_PATH = os.path.join("ADMIN", "environment.json")
ENVIRONMENT_MARKER_FILES = ("activate", "activate.bat", "Activate.ps1")
IGNORED_SCAN_DIRECTORIES = {".git", ".mira", "__pycache__", "build", "dist", "node_modules"}


def discover_workspace_environments(root_dir):
    root_dir = os.path.abspath(root_dir)
    environments = []
    seen_paths = set()

    for current_root, directories, _ in os.walk(root_dir):
        directories[:] = [name for name in directories if name not in IGNORED_SCAN_DIRECTORIES]
        if not _has_environment_markers(current_root):
            continue

        absolute_path = os.path.abspath(current_root)
        if absolute_path not in seen_paths:
            environments.append(_build_environment_record(root_dir, absolute_path))
            seen_paths.add(absolute_path)
        directories[:] = []

    return sorted(environments, key=lambda item: (item["label"].lower(), item["path"].lower()))


def set_configured_environment(root_dir, raw_path):
    absolute_path = resolve_environment_path(root_dir, raw_path)
    validate_environment_path(absolute_path)

    _write_state(root_dir, {"path": absolute_path})
    return _build_environment_record(root_dir, absolute_path)


def create_workspace_environment(root_dir, name, python_executable=None):
    environment_name = name.strip().strip('"').strip("'")
    if not environment_name:
        raise ValueError("Environment name cannot be empty.")
    if any(separator in environment_name for separator in ("/", "\\")) or ":" in environment_name:
        raise ValueError("Environment name must be a root-level folder name.")

    absolute_path = os.path.abspath(os.path.join(root_dir, environment_name))
    if os.path.exists(absolute_path):
        raise ValueError(f"Environment already exists: {absolute_path}")

    interpreter = python_executable or sys.executable
    result = subprocess.run([interpreter, "-m", "venv", absolute_path], capture_output=True, text=True, check=False)
    if result.returncode != 0:
        details = (result.stderr or result.stdout or "venv creation failed.").strip()
        raise ValueError(f"Failed to create environment: {details}")

    validate_environment_path(absolute_path)
    _write_state(root_dir, {"path": absolute_path})
    return _build_environment_record(root_dir, absolute_path)


def clear_configured_environment(root_dir):
    _write_state(root_dir, {"path": None})


def load_configured_environment(root_dir):
    state = _load_state(root_dir)
    configured_path = state.get("path")
    if not configured_path:
        return None

    try:
        validate_environment_path(configured_path)
    except ValueError:
        return None
    return _build_environment_record(root_dir, configured_path)


def resolve_environment_path(root_dir, raw_path):
    path = raw_path.strip().strip('"').strip("'")
    if not path:
        raise ValueError("Invalid path.")

    if os.path.isabs(path):
        return os.path.abspath(path)
    return os.path.abspath(os.path.join(root_dir, path.lstrip("/\\")))


def validate_environment_path(environment_root):
    absolute_path = os.path.abspath(environment_root)
    if not os.path.isdir(absolute_path):
        raise ValueError(f"Folder does not exist: {absolute_path}")

    scripts_dir = os.path.join(absolute_path, "Scripts")
    if not os.path.isdir(scripts_dir):
        raise ValueError(f"Folder doesn't have /Scripts: {absolute_path}")

    if _has_environment_markers(absolute_path):
        return absolute_path
    raise ValueError(
        f"Folder doesn't have /Scripts/activate, /Scripts/activate.bat, or /Scripts/Activate.ps1: {absolute_path}"
    )


def _build_environment_record(root_dir, absolute_path):
    absolute_path = os.path.abspath(absolute_path)
    return {
        "label": _environment_label(root_dir, absolute_path),
        "path": absolute_path,
    }


def _environment_label(root_dir, absolute_path):
    root_dir = os.path.abspath(root_dir)
    try:
        relative_path = os.path.relpath(absolute_path, root_dir)
    except ValueError:
        relative_path = None

    if relative_path is not None and relative_path not in {".", ""} and not relative_path.startswith(".."):
        return relative_path.replace("\\", "/")

    label = os.path.basename(absolute_path.rstrip("\\/"))
    return label or absolute_path


def _has_environment_markers(environment_root):
    scripts_dir = os.path.join(environment_root, "Scripts")
    if not os.path.isdir(scripts_dir):
        return False
    return any(os.path.exists(os.path.join(scripts_dir, marker)) for marker in ENVIRONMENT_MARKER_FILES)


def _load_state(root_dir):
    state_path = _state_path(root_dir)
    if not os.path.exists(state_path):
        return {"path": None}
    try:
        with open(state_path, "r", encoding="utf-8") as handle:
            state = json.load(handle)
    except Exception:
        return {"path": None}
    if not isinstance(state, dict):
        return {"path": None}
    return {"path": state.get("path")}


def _write_state(root_dir, state):
    state_path = _state_path(root_dir)
    os.makedirs(os.path.dirname(state_path), exist_ok=True)
    with open(state_path, "w", encoding="utf-8") as handle:
        json.dump(state, handle, indent=2)


def _state_path(root_dir):
    return os.path.join(root_dir, ".mira", ENVIRONMENT_STATE_PATH)