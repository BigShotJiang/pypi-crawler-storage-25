import json
import os
import re
import shutil
from collections import defaultdict

from mira_core.chunk_comments import attach_chunk_comments
from mira_core.command_docs import build_guide_lines, build_public_command_lines
from mira_core.environment import load_configured_environment


def generate_outputs(target_path, project_data):
    base_dir = target_path if os.path.isdir(target_path) else os.path.dirname(target_path)
    mira_dir = os.path.join(base_dir, ".mira")
    existing_index = _load_json_if_exists(os.path.join(mira_dir, "global_index.json"), default={"files": {}})
    descriptions = _load_existing_descriptions(existing_index)
    configured_environment = load_configured_environment(base_dir)
    _ensure_mira_directory(mira_dir)

    file_records = _build_file_records(base_dir, project_data, descriptions, _build_existing_file_id_map(existing_index))
    attach_chunk_comments(base_dir, mira_dir, file_records)
    symbol_registry = _build_symbol_registry(file_records)
    module_index = _build_module_index(file_records)

    _resolve_internal_calls(file_records, symbol_registry)
    _resolve_import_dependencies(file_records, module_index)
    _derive_file_dependencies(file_records)
    _infer_document_origins(file_records)

    _remove_stale_generated_artifacts(mira_dir, {file_record["file_id"] for file_record in file_records})

    for file_record in file_records:
        _write_file_bundle(mira_dir, file_record)

    root_name = os.path.basename(os.path.abspath(base_dir.rstrip("\\/"))) or os.path.abspath(base_dir)
    _write_project_manifest(mira_dir, file_records, root_name, configured_environment)
    _write_global_index(mira_dir, file_records, root_name)
    _write_guide_file(mira_dir)
    _write_source_cache(mira_dir, project_data)
    _initialize_history_baselines(mira_dir, file_records)


def _ensure_mira_directory(mira_dir):
    os.makedirs(mira_dir, exist_ok=True)
    os.makedirs(os.path.join(mira_dir, "files"), exist_ok=True)
    os.makedirs(os.path.join(mira_dir, "snapshots"), exist_ok=True)
    os.makedirs(os.path.join(mira_dir, "cache"), exist_ok=True)
    os.makedirs(os.path.join(mira_dir, "history", "base"), exist_ok=True)
    os.makedirs(os.path.join(mira_dir, "runtime"), exist_ok=True)

    for name in ("memory.txt", "goals.txt"):
        path = os.path.join(mira_dir, name)
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("")


def _load_existing_descriptions(existing_index):
    descriptions = {}
    for metadata in existing_index.get("files", {}).values():
        description = metadata.get("description")
        path = metadata.get("path")
        if path and description:
            descriptions[path] = description
    return descriptions


def _write_source_cache(mira_dir, project_data):
    cache_path = os.path.join(mira_dir, "cache", "source_index.json")
    _write_json_if_changed(cache_path, project_data)


def _initialize_history_baselines(mira_dir, file_records):
    history_dir = os.path.join(mira_dir, "history")
    history_index_path = os.path.join(history_dir, "index.json")
    history_index = _load_json_if_exists(history_index_path, default={"files": {}})
    tracked_files = {}

    for file_record in file_records:
        if not file_record.get("history_enabled", True):
            continue

        relative_path = file_record["path"]
        current_text = "".join(file_record["source_lines"])
        current_hash = _stable_text_hash(current_text)
        safe_name = _safe_history_name(relative_path)
        base_snapshot_path = os.path.join(history_dir, "base", safe_name)
        existing_entry = history_index["files"].get(relative_path)

        if existing_entry and existing_entry.get("current_hash") == current_hash and os.path.exists(base_snapshot_path):
            tracked_files[relative_path] = existing_entry
            continue

        _write_text_if_changed(base_snapshot_path, current_text)

        tracked_files[relative_path] = {
            "current_version": 1,
            "current_hash": current_hash,
            "base_snapshot": os.path.join("history", "base", safe_name).replace("\\", "/"),
            "events": [],
        }

    history_index["files"] = tracked_files
    _write_json_if_changed(history_index_path, history_index)


def _build_file_records(base_dir, project_data, descriptions, existing_file_ids=None):
    file_records = []
    ordered_paths = _order_relative_paths(project_data["files"].keys())
    existing_file_ids = dict(existing_file_ids or {})
    next_file_id = max(existing_file_ids.values(), default=0) + 1

    for relative_path in ordered_paths:
        file_id = existing_file_ids.get(relative_path)
        if file_id is None:
            file_id = next_file_id
            next_file_id += 1

        file_meta = project_data["files"][relative_path]
        absolute_path = os.path.join(base_dir, relative_path)
        file_kind = file_meta.get("file_kind", "code")
        if file_kind == "document":
            source_lines = []
            total_lines = int(file_meta.get("total_lines", 0))
        else:
            with open(absolute_path, "r", encoding="utf-8") as handle:
                source_lines = handle.readlines()
            total_lines = len(source_lines)

        classes = []
        for qualname, class_meta in sorted(file_meta.get("classes", {}).items(), key=_class_sort_key):
            classes.append(
                {
                    "name": class_meta["name"],
                    "qualname": qualname,
                    "parent": class_meta.get("parent"),
                    "start": class_meta["lines"]["start"],
                    "end": class_meta["lines"]["end"],
                    "methods": list(class_meta.get("methods", [])),
                    "children": list(class_meta.get("children", [])),
                }
            )

        symbols = []
        for qualname, function_meta in sorted(file_meta.get("functions", {}).items(), key=_function_sort_key):
            symbols.append(
                {
                    "name": function_meta["name"],
                    "qualname": qualname,
                    "kind": function_meta.get("kind", "function"),
                    "parent": function_meta.get("parent"),
                    "container_class": function_meta.get("container_class"),
                    "signature": function_meta.get("signature", f"{function_meta['name']}()"),
                    "start": function_meta["occupies"]["start"],
                    "end": function_meta["occupies"]["end"],
                    "returns": _clean_returns(function_meta.get("returns", [])),
                    "children": list(function_meta.get("children", [])),
                    "calls_raw": list(function_meta.get("dependencies", {}).get("calls_detailed", [])),
                    "instance_bindings": dict(
                        function_meta.get("dependencies", {}).get(
                            "instance_bindings",
                            function_meta.get("instance_bindings", {}),
                        )
                    ),
                    "calls": [],
                    "callers": [],
                }
            )

        file_record = {
            "file_id": file_id,
            "path": relative_path,
            "filename": os.path.basename(relative_path),
            "language": file_meta.get("language", "unknown"),
            "file_kind": file_kind,
            "storage_mode": file_meta.get("storage_mode", "mirrored"),
            "byte_size": int(file_meta.get("byte_size", os.path.getsize(absolute_path))),
            "source_signature": dict(file_meta.get("source_signature", _build_source_signature(absolute_path))),
            "retrieval_char_limit": int(file_meta.get("retrieval_char_limit", 0) or 0),
            "document_structure": list(file_meta.get("document_structure", [])),
            "document_sections": list(file_meta.get("sections", [])),
            "origin": file_meta.get("origin", "manual_or_external"),
            "history_enabled": file_meta.get("storage_mode", "mirrored") != "metadata-only",
            "description": descriptions.get(relative_path, ""),
            "total_lines": total_lines,
            "source_lines": source_lines,
            "globals": dict(file_meta.get("global_variables", {})),
            "imports": list(file_meta.get("imports", [])),
            "classes": classes,
            "symbols": symbols,
            "chunks": [],
            "import_dependencies": [],
            "depends_on": [],
            "depended_on_by": [],
        }
        _attach_chunk_metadata(file_record)
        file_records.append(file_record)

    return file_records


def _attach_chunk_metadata(file_record):
    if file_record.get("file_kind") in {"document", "generic"}:
        chunks = []
        for local_id, section in enumerate(file_record.get("document_sections", []), start=1):
            chunks.append(
                {
                    "start": section["start"],
                    "end": section["end"],
                    "entries": [],
                    "label": section["label"],
                    "members": list(section.get("members", [])),
                    "functions": [],
                    "classes": [],
                    "char_count": int(section.get("char_count", 0)),
                    "local_id": local_id,
                    "public_id": f"{file_record['file_id']}_{local_id}",
                }
            )
        file_record["chunks"] = chunks
        return

    class_map = {class_meta["qualname"]: class_meta for class_meta in file_record["classes"]}
    symbol_map = {symbol["qualname"]: symbol for symbol in file_record["symbols"]}
    top_level_entries = _collect_top_level_entries(file_record)
    chunks = _build_chunk_records(file_record, top_level_entries)

    for local_id, chunk in enumerate(chunks, start=1):
        chunk["local_id"] = local_id
        chunk["public_id"] = f"{file_record['file_id']}_{local_id}"

    top_level_chunk_map = {}
    for chunk in chunks:
        for entry in chunk["entries"]:
            top_level_chunk_map[entry["qualname"]] = chunk

    for symbol in file_record["symbols"]:
        owner = _resolve_top_level_owner(symbol["qualname"], symbol_map, class_map)
        chunk = top_level_chunk_map.get(owner)
        if chunk is None:
            chunk = _find_covering_chunk(chunks, symbol["start"], symbol["end"])
        symbol["chunk_id"] = chunk["public_id"] if chunk else None

    for class_meta in file_record["classes"]:
        owner = _resolve_top_level_owner(class_meta["qualname"], symbol_map, class_map)
        chunk = top_level_chunk_map.get(owner)
        if chunk is None:
            chunk = _find_covering_chunk(chunks, class_meta["start"], class_meta["end"])
        class_meta["chunk_id"] = chunk["public_id"] if chunk else None

    for chunk in chunks:
        chunk["functions"] = [symbol["qualname"] for symbol in file_record["symbols"] if symbol["chunk_id"] == chunk["public_id"]]
        chunk["classes"] = [class_meta["qualname"] for class_meta in file_record["classes"] if class_meta["chunk_id"] == chunk["public_id"]]

    file_record["chunks"] = chunks


def _collect_top_level_entries(file_record):
    entries = []
    for class_meta in file_record["classes"]:
        if class_meta["parent"] is not None:
            continue
        entries.append(
            {
                "kind": "class",
                "qualname": class_meta["qualname"],
                "label": f"class {class_meta['name']}",
                "start": class_meta["start"],
                "end": class_meta["end"],
                "members": [_short_qualname(name) for name in class_meta.get("methods", [])],
            }
        )

    for symbol in file_record["symbols"]:
        if symbol["parent"] is not None:
            continue
        entries.append(
            {
                "kind": "function",
                "qualname": symbol["qualname"],
                "label": symbol["signature"],
                "start": symbol["start"],
                "end": symbol["end"],
                "members": [_short_qualname(name) for name in symbol.get("children", [])],
            }
        )

    entries.sort(key=lambda entry: (entry["start"], entry["end"], entry["qualname"]))
    return entries


def _build_chunk_records(file_record, top_level_entries):
    total_lines = file_record["total_lines"]
    if total_lines == 0:
        return []

    if not top_level_entries:
        return [_make_module_chunk(file_record, 1, total_lines)]

    chunks = []
    first_entry = top_level_entries[0]
    if first_entry["start"] > 1 and _has_meaningful_range(file_record, 1, first_entry["start"] - 1):
        chunks.append(_make_module_chunk(file_record, 1, first_entry["start"] - 1))
        current_start = first_entry["start"]
    else:
        current_start = 1

    current_entries = [first_entry]
    current_end = first_entry["end"]

    for entry in top_level_entries[1:]:
        gap_start = current_end + 1
        gap_end = entry["start"] - 1
        if _should_merge_entries(file_record["source_lines"], gap_start, gap_end):
            current_entries.append(entry)
            current_end = entry["end"]
            continue

        chunks.append(_make_entry_chunk(file_record, current_start, max(current_end, gap_end), current_entries))
        current_start = entry["start"]
        current_entries = [entry]
        current_end = entry["end"]

    chunks.append(_make_entry_chunk(file_record, current_start, total_lines, current_entries))
    return chunks


def _make_module_chunk(file_record, start, end):
    return {
        "start": start,
        "end": end,
        "entries": [],
        "label": _summarize_module_chunk(file_record, start, end),
        "members": [],
    }


def _make_entry_chunk(file_record, start, end, entries):
    members = []
    for entry in entries:
        members.extend(entry.get("members", []))

    return {
        "start": start,
        "end": end,
        "entries": entries,
        "label": _build_chunk_label(entries),
        "members": _unique_names(members),
    }


def _build_chunk_label(entries):
    if not entries:
        return "module section"
    if len(entries) == 1:
        return entries[0]["label"]
    return f"multi: {_summarize_names([entry['label'] for entry in entries], limit=3)}"


def _summarize_module_chunk(file_record, start, end):
    labels = []
    import_lines = {entry["line"] for entry in file_record["imports"] if start <= entry.get("line", 0) <= end}
    global_lines = set()
    for metadata in file_record["globals"].values():
        global_start = metadata.get("defined", 0)
        global_end = metadata.get("end", global_start)
        if global_end < start or global_start > end:
            continue
        global_lines.update(range(max(start, global_start), min(end, global_end) + 1))

    if import_lines:
        labels.append("imports")
    if global_lines:
        labels.append("globals")

    if _has_other_module_content(file_record, start, end, import_lines, global_lines):
        labels.append("module code")

    if not labels:
        return "module section"
    return ", ".join(labels)


def _has_other_module_content(file_record, start, end, import_lines, global_lines):
    for line_number in range(start, end + 1):
        stripped = file_record["source_lines"][line_number - 1].strip()
        if not stripped or stripped.startswith("#"):
            continue
        if line_number in import_lines or line_number in global_lines:
            continue
        return True
    return False


def _has_meaningful_range(file_record, start, end):
    if start > end:
        return False
    for line_number in range(start, end + 1):
        stripped = file_record["source_lines"][line_number - 1].strip()
        if stripped and not stripped.startswith("#"):
            return True
    return False


def _should_merge_entries(source_lines, gap_start, gap_end):
    if gap_start > gap_end:
        return True
    for line_number in range(gap_start, gap_end + 1):
        if not source_lines[line_number - 1].strip():
            return False
    return True


def _resolve_top_level_owner(qualname, symbol_map, class_map):
    current = qualname
    while current is not None:
        if current in symbol_map:
            parent = symbol_map[current]["parent"]
            if parent is None:
                return current
            current = parent
            continue
        if current in class_map:
            parent = class_map[current]["parent"]
            if parent is None:
                return current
            current = parent
            continue
        return None
    return None


def _find_covering_chunk(chunks, start, end):
    for chunk in chunks:
        if chunk["start"] <= start and end <= chunk["end"]:
            return chunk
    return None


def _build_symbol_registry(file_records):
    registry = {
        "by_qualname": {},
        "by_name": defaultdict(list),
        "by_file_and_name": defaultdict(list),
    }

    for file_record in file_records:
        for symbol in file_record["symbols"]:
            reference = {"file": file_record, "symbol": symbol}
            registry["by_qualname"][symbol["qualname"]] = reference
            registry["by_name"][symbol["name"]].append(reference)
            registry["by_file_and_name"][(file_record["file_id"], symbol["name"])] = registry["by_file_and_name"].get((file_record["file_id"], symbol["name"]), []) + [reference]

    return registry


def _resolve_internal_calls(file_records, registry):
    for file_record in file_records:
        for symbol in file_record["symbols"]:
            seen_calls = set()
            for call in symbol["calls_raw"]:
                target = _resolve_call(call, file_record, symbol, registry)
                if target is None:
                    continue

                target_file = target["file"]
                target_symbol = target["symbol"]
                call_key = (target_file["file_id"], target_symbol["qualname"], call["line"])
                if call_key not in seen_calls:
                    symbol["calls"].append(
                        {
                            "file_id": target_file["file_id"],
                            "path": target_file["path"],
                            "function": target_symbol["qualname"],
                            "chunk_id": target_symbol["chunk_id"],
                            "line": call["line"],
                        }
                    )
                    seen_calls.add(call_key)

                caller_entry = {
                    "file_id": file_record["file_id"],
                    "path": file_record["path"],
                    "function": symbol["qualname"],
                    "line": call["line"],
                }
                if caller_entry not in target_symbol["callers"]:
                    target_symbol["callers"].append(caller_entry)


def _resolve_call(call, file_record, symbol, registry):
    qualname_hint = call.get("qualname_hint")
    if qualname_hint and qualname_hint in registry["by_qualname"]:
        return registry["by_qualname"][qualname_hint]

    owner = call.get("owner")
    if owner:
        bound_class = symbol["instance_bindings"].get(owner)
        if bound_class:
            candidate = _resolve_bound_method(bound_class, call["name"], registry)
            if candidate is not None:
                return candidate
        if owner not in {"self", "cls"}:
            return None

    if symbol["container_class"]:
        same_class_qualname = _qualify_member_name(symbol["container_class"], call["name"])
        if same_class_qualname in registry["by_qualname"]:
            return registry["by_qualname"][same_class_qualname]

    same_file_matches = registry["by_file_and_name"].get((file_record["file_id"], call["name"]), [])
    if len(same_file_matches) == 1:
        return same_file_matches[0]

    global_matches = registry["by_name"].get(call["name"], [])
    if len(global_matches) == 1:
        return global_matches[0]

    return None


def _resolve_bound_method(bound_class, method_name, registry):
    direct_qualname = _qualify_member_name(bound_class, method_name)
    if direct_qualname in registry["by_qualname"]:
        return registry["by_qualname"][direct_qualname]

    matches = []
    for qualname, reference in registry["by_qualname"].items():
        if qualname.endswith(f"::{bound_class}::{method_name}") or qualname.endswith(f".{bound_class}.{method_name}"):
            matches.append(reference)
    if len(matches) == 1:
        return matches[0]
    return None


def _qualify_member_name(container_name, member_name):
    separator = "::" if "::" in container_name else "."
    return f"{container_name}{separator}{member_name}"


def _build_module_index(file_records):
    module_index = {}
    for file_record in file_records:
        for module_name in _module_names_for_path(file_record["path"]):
            module_index[module_name] = file_record
    return module_index


def _module_names_for_path(relative_path):
    if not relative_path.endswith(".py"):
        extension = os.path.splitext(relative_path)[1].lower()
        if extension in {".cpp", ".cc", ".cxx", ".hpp", ".hh", ".hxx", ".h"}:
            normalized_path = relative_path.replace("\\", "/")
            return [normalized_path, os.path.basename(normalized_path)]
        return []
    without_extension = relative_path[:-3]
    parts = without_extension.split("/")
    if parts[-1] == "__init__":
        module_name = ".".join(parts[:-1])
        return [module_name] if module_name else []
    return [".".join(parts)]


def _resolve_import_dependencies(file_records, module_index):
    for file_record in file_records:
        seen = set()
        for import_entry in file_record["imports"]:
            target = _resolve_import_target(file_record, import_entry, module_index)
            if target is None or target["file_id"] == file_record["file_id"]:
                continue
            source_chunk = _find_chunk_by_line(file_record, import_entry.get("line", 0))
            target_chunk_ids = _resolve_import_chunk_ids(target, import_entry)
            dependency_key = (target["file_id"], tuple(target_chunk_ids), source_chunk["public_id"] if source_chunk else None)
            if dependency_key in seen:
                continue
            file_record["import_dependencies"].append(
                {
                    "file_id": target["file_id"],
                    "path": target["path"],
                    "name": target["filename"],
                    "target_chunk_ids": target_chunk_ids,
                    "source_chunk_id": source_chunk["public_id"] if source_chunk else None,
                }
            )
            seen.add(dependency_key)


def _resolve_import_target(file_record, import_entry, module_index):
    if import_entry.get("kind") == "include":
        module_name = import_entry.get("module", "")
        candidates = [module_name, os.path.basename(module_name)]
        for candidate in candidates:
            target = module_index.get(candidate)
            if target is not None:
                return target
        return None
    for module_name in _candidate_modules_for_import(file_record, import_entry):
        target = module_index.get(module_name)
        if target is not None:
            return target
    return None


def _candidate_modules_for_import(file_record, import_entry):
    normalized_module = _normalize_import_module(file_record["path"], import_entry)
    candidates = []

    if import_entry.get("kind") == "import":
        if normalized_module:
            candidates.append(normalized_module)
    else:
        if normalized_module:
            candidates.append(normalized_module)
        imported_name = import_entry.get("name")
        if imported_name and imported_name != "*":
            if normalized_module:
                candidates.append(f"{normalized_module}.{imported_name}")
            else:
                candidates.append(imported_name)

    ordered = []
    seen = set()
    for candidate in candidates:
        if candidate and candidate not in seen:
            ordered.append(candidate)
            seen.add(candidate)
    return ordered


def _normalize_import_module(relative_path, import_entry):
    module_name = import_entry.get("module", "")
    level = import_entry.get("level", 0)
    if level == 0:
        return module_name or import_entry.get("module") or ""

    package_parts = _package_parts_for_path(relative_path)
    trim_count = max(level - 1, 0)
    if trim_count > len(package_parts):
        return module_name
    base_parts = package_parts[: len(package_parts) - trim_count]
    extra_parts = module_name.split(".") if module_name else []
    return ".".join(part for part in [*base_parts, *extra_parts] if part)


def _package_parts_for_path(relative_path):
    if not relative_path.endswith(".py"):
        return []
    without_extension = relative_path[:-3]
    parts = without_extension.split("/")
    if parts[-1] == "__init__":
        return parts[:-1]
    return parts[:-1]


def _resolve_import_chunk_ids(target_file, import_entry):
    imported_name = import_entry.get("name")
    chunk_ids = set()

    if imported_name and imported_name != "*":
        for class_meta in target_file["classes"]:
            if class_meta["name"] == imported_name and class_meta.get("chunk_id"):
                chunk_ids.add(class_meta["chunk_id"])
        for symbol in target_file["symbols"]:
            if symbol["name"] == imported_name and symbol.get("chunk_id"):
                chunk_ids.add(symbol["chunk_id"])

    if not chunk_ids and target_file["chunks"]:
        chunk_ids.add(target_file["chunks"][0]["public_id"])

    return _sort_chunk_ids(chunk_ids)


def _find_chunk_by_line(file_record, line_number):
    for chunk in file_record["chunks"]:
        if chunk["start"] <= line_number <= chunk["end"]:
            return chunk
    return None


def _derive_file_dependencies(file_records):
    records_by_id = {file_record["file_id"]: file_record for file_record in file_records}
    reverse_edges = defaultdict(lambda: defaultdict(set))

    for file_record in file_records:
        dependency_map = defaultdict(lambda: {"file": None, "chunk_ids": set()})

        for dependency in file_record["import_dependencies"]:
            detail = dependency_map[dependency["file_id"]]
            detail["file"] = records_by_id[dependency["file_id"]]
            detail["chunk_ids"].update(dependency.get("target_chunk_ids", []))
            if dependency.get("source_chunk_id"):
                reverse_edges[dependency["file_id"]][file_record["file_id"]].add(dependency["source_chunk_id"])

        for symbol in file_record["symbols"]:
            for call in symbol["calls"]:
                if call["file_id"] == file_record["file_id"]:
                    continue
                detail = dependency_map[call["file_id"]]
                detail["file"] = records_by_id[call["file_id"]]
                if call.get("chunk_id"):
                    detail["chunk_ids"].add(call["chunk_id"])
                if symbol.get("chunk_id"):
                    reverse_edges[call["file_id"]][file_record["file_id"]].add(symbol["chunk_id"])

        file_record["depends_on"] = []
        for dependency_id in sorted(dependency_map):
            detail = dependency_map[dependency_id]
            file_record["depends_on"].append(
                {
                    "file": detail["file"],
                    "chunk_ids": _sort_chunk_ids(detail["chunk_ids"]),
                }
            )

    for file_record in file_records:
        detail_map = reverse_edges.get(file_record["file_id"], {})
        file_record["depended_on_by"] = []
        for source_file_id in sorted(detail_map):
            file_record["depended_on_by"].append(
                {
                    "file": records_by_id[source_file_id],
                    "chunk_ids": _sort_chunk_ids(detail_map[source_file_id]),
                }
            )


def _write_file_bundle(mira_dir, file_record):
    file_dir = os.path.join(mira_dir, "files", str(file_record["file_id"]))
    chunks_dir = os.path.join(file_dir, "chunks")
    os.makedirs(chunks_dir, exist_ok=True)

    meta_json = {
        "file_id": file_record["file_id"],
        "filename": file_record["filename"],
        "path": file_record["path"],
        "language": file_record["language"],
        "file_kind": file_record["file_kind"],
        "storage_mode": file_record["storage_mode"],
        "byte_size": file_record["byte_size"],
        "total_lines": file_record["total_lines"],
        "source_signature": file_record["source_signature"],
        "dependencies": {
            "depends_on": [
                {
                    "file_id": dependency["file"]["file_id"],
                    "path": dependency["file"]["path"],
                    "chunk_ids": dependency["chunk_ids"],
                }
                for dependency in file_record["depends_on"]
            ],
            "used_by": [
                {
                    "file_id": dependency["file"]["file_id"],
                    "path": dependency["file"]["path"],
                    "chunk_ids": dependency["chunk_ids"],
                }
                for dependency in file_record["depended_on_by"]
            ],
        },
        "classes": {},
        "functions": {},
        "chunks": {},
    }

    if file_record["description"]:
        meta_json["description"] = file_record["description"]
    if file_record.get("origin"):
        meta_json["origin"] = file_record["origin"]
    if file_record.get("retrieval_char_limit"):
        meta_json["retrieval_char_limit"] = file_record["retrieval_char_limit"]
    if file_record.get("document_structure"):
        meta_json["document_structure"] = list(file_record["document_structure"])

    for class_meta in file_record["classes"]:
        meta_json["classes"][class_meta["qualname"]] = {
            "name": class_meta["name"],
            "chunk_id": class_meta["chunk_id"],
            "lines": _format_lines(class_meta["start"], class_meta["end"]),
            "parent": class_meta["parent"],
            "methods": class_meta["methods"],
        }

    for symbol in file_record["symbols"]:
        meta_json["functions"][symbol["qualname"]] = {
            "name": symbol["name"],
            "kind": symbol["kind"],
            "signature": symbol["signature"],
            "chunk_id": symbol["chunk_id"],
            "lines": _format_lines(symbol["start"], symbol["end"]),
            "returns": symbol["returns"],
            "callers": symbol["callers"],
            "calls": symbol["calls"],
        }

    chunk_index = {}
    chunk_files = {}
    for chunk in file_record["chunks"]:
        chunk_id = chunk["public_id"]
        lines_text = _format_lines(chunk["start"], chunk["end"])
        meta_json["chunks"][chunk_id] = {
            "lines": lines_text,
            "label": chunk["label"],
            "functions": chunk["functions"],
            "classes": chunk["classes"],
        }
        if chunk.get("comment"):
            meta_json["chunks"][chunk_id]["comment"] = chunk["comment"]
        if chunk.get("char_count"):
            meta_json["chunks"][chunk_id]["char_count"] = chunk["char_count"]
        chunk_index[chunk_id] = {
            "lines": lines_text,
            "label": chunk["label"],
            "functions": chunk["functions"],
        }
        if chunk.get("comment"):
            chunk_index[chunk_id]["comment"] = chunk["comment"]
        if chunk.get("char_count"):
            chunk_index[chunk_id]["char_count"] = chunk["char_count"]

        if not _is_metadata_only(file_record):
            start_index = max(0, chunk["start"] - 1)
            end_index = min(len(file_record["source_lines"]), chunk["end"])
            chunk_files[f"{chunk_id}.txt"] = "".join(file_record["source_lines"][start_index:end_index])

    _write_json_if_changed(os.path.join(file_dir, "meta.json"), meta_json)

    if not _is_metadata_only(file_record):
        snapshot_path = os.path.join(mira_dir, "snapshots", f"{file_record['file_id']}.txt")
        _write_text_if_changed(snapshot_path, "".join(file_record["source_lines"]))
    else:
        _remove_path_if_exists(os.path.join(mira_dir, "snapshots", f"{file_record['file_id']}.txt"))

    _write_text_if_changed(os.path.join(file_dir, "skeleton.txt"), "\n".join(_build_skeleton_lines(file_record)))

    chunk_files["index.json"] = json.dumps(chunk_index, indent=2)
    _sync_directory_text_files(chunks_dir, chunk_files)


def _build_skeleton_lines(file_record):
    file_header = f"# FILE: {file_record['filename']} (ID: {file_record['file_id']})"
    if file_record["description"]:
        file_header = f"{file_header} - {file_record['description']}"

    lines = [file_header, f"# LINES: {file_record['total_lines']} | CHUNKS: {len(file_record['chunks'])}"]

    if file_record.get("file_kind") == "document":
        lines.append(
            f"# SIZE: {_format_byte_size(file_record['byte_size'])} | STORAGE: {file_record['storage_mode']} | SHOW LIMIT: {file_record['retrieval_char_limit']} chars"
        )
        lines.append(f"# ORIGIN: {file_record.get('origin', 'manual_or_external')}")
        if file_record.get("document_structure"):
            lines.extend(["", "## DOCUMENT", *file_record["document_structure"]])
    elif file_record.get("file_kind") == "generic":
        lines.append(
            f"# MODE: generic adaptive chunks (target 100, min 80, max 500) | ORIGIN: {file_record.get('origin', 'manual_or_external')}"
        )

    if file_record["depends_on"] or file_record["depended_on_by"]:
        lines.extend(["", "## DEPENDENCIES"])
        if file_record["depends_on"]:
            lines.append(f"depends_on: {_format_dependency_refs(file_record['depends_on'])}")
        if file_record["depended_on_by"]:
            lines.append(f"used_by: {_format_dependency_refs(file_record['depended_on_by'])}")

    global_lines = _format_globals(file_record["globals"])
    if global_lines:
        lines.extend(["", "## GLOBALS", *global_lines])

    has_chunk_comments = any(chunk.get("comment") for chunk in file_record["chunks"])
    format_line = "# FORMAT: item | lines | id | comment" if has_chunk_comments else "# FORMAT: item | lines | id"
    lines.extend(["", "## STRUCTURE", format_line])
    structure_lines = _render_structure(file_record)
    if structure_lines:
        lines.extend(structure_lines)
    else:
        lines.append("module section | 1-0 | none")

    lines.extend(["", "## COMMANDS", "!list"])

    return lines


def _format_globals(global_variables):
    ordered = sorted(global_variables.items(), key=lambda item: (item[1].get("defined", 0), item[0]))
    lines = []
    for name, metadata in ordered:
        type_label = f": {metadata['type']}" if metadata.get("type") else ""
        lines.append(f"{name}{type_label}  # line {metadata['defined']}")
    return lines


def _render_structure(file_record):
    lines = []
    for chunk in file_record["chunks"]:
        line = f"{chunk['label']} | {_format_lines(chunk['start'], chunk['end'])} | {chunk['public_id']}"
        if chunk.get("comment"):
            line = f"{line} | #{chunk['comment']}"
        lines.append(line)
        if chunk["members"]:
            lines.append(f"  contains: {_summarize_names(chunk['members'], limit=8)}")
    return lines


def _format_dependency_refs(details):
    ordered = sorted(details, key=lambda item: (item["file"]["file_id"], item["file"]["path"]))
    rendered = []
    for detail in ordered:
        label = f"[{detail['file']['file_id']}] {detail['file']['path']}"
        if detail["chunk_ids"]:
            chunk_label = "ID" if len(detail["chunk_ids"]) == 1 else "IDs"
            label = f"{label} ({chunk_label}: {', '.join(detail['chunk_ids'])})"
        rendered.append(label)
    return ", ".join(rendered)


def _write_project_manifest(mira_dir, file_records, root_name, configured_environment=None):
    total_lines = sum(file_record["total_lines"] for file_record in file_records)
    total_chunks = sum(len(file_record["chunks"]) for file_record in file_records)

    lines = [root_name, ""]
    lines.extend(_render_project_tree(file_records))
    lines.extend(["", f"TOTAL: {len(file_records)} files, {total_lines} lines, {total_chunks} chunks"])
    if configured_environment is not None:
        lines.extend(["", f"ENVIRONMENT: {configured_environment['label']} ({configured_environment['path']})"])
    lines.extend(["", "COMMANDS:", *build_public_command_lines()])

    _write_text_if_changed(os.path.join(mira_dir, "project.mira"), "\n".join(lines))


def _render_project_tree(file_records):
    tree = {"dirs": {}, "files": []}
    for file_record in file_records:
        parts = file_record["path"].split("/")
        current = tree
        for directory in parts[:-1]:
            current = current["dirs"].setdefault(directory, {"dirs": {}, "files": []})
        current["files"].append(file_record)

    lines = []
    _append_tree_lines(tree, lines, indent="")
    return lines


def _append_tree_lines(node, lines, indent):
    for file_record in sorted(node["files"], key=lambda item: item["path"]):
        if file_record.get("file_kind") == "document":
            line = (
                f"{indent}[{file_record['file_id']}] {file_record['filename']} "
                f"({file_record['total_lines']} lines, {_format_byte_size(file_record['byte_size'])}, metadata-only, {len(file_record['chunks'])} sections)"
            )
        else:
            line = f"{indent}[{file_record['file_id']}] {file_record['filename']} ({file_record['total_lines']} lines, {len(file_record['chunks'])} chunks)"
        if file_record["description"]:
            line = f"{line} # {file_record['description']}"
        lines.append(line)
    for directory_name in sorted(node["dirs"]):
        lines.append(f"{indent}/{directory_name}")
        _append_tree_lines(node["dirs"][directory_name], lines, indent=f"{indent}  ")


def _write_global_index(mira_dir, file_records, root_name):
    global_index = {
        "root": root_name,
        "files": {},
        "cross_references": {},
        "name_index": {},
        "chunk_count": 0,
        "total_lines": 0,
    }
    name_index = defaultdict(list)

    for file_record in file_records:
        file_id = str(file_record["file_id"])
        file_entry = {
            "name": file_record["filename"],
            "path": file_record["path"],
            "language": file_record["language"],
            "file_kind": file_record["file_kind"],
            "storage_mode": file_record["storage_mode"],
            "byte_size": file_record["byte_size"],
            "total_lines": file_record["total_lines"],
            "chunk_count": len(file_record["chunks"]),
            "source_signature": file_record["source_signature"],
            "depends_on": [
                {
                    "file_id": dependency["file"]["file_id"],
                    "path": dependency["file"]["path"],
                    "chunk_ids": dependency["chunk_ids"],
                }
                for dependency in file_record["depends_on"]
            ],
            "used_by": [
                {
                    "file_id": dependency["file"]["file_id"],
                    "path": dependency["file"]["path"],
                    "chunk_ids": dependency["chunk_ids"],
                }
                for dependency in file_record["depended_on_by"]
            ],
        }
        if file_record["description"]:
            file_entry["description"] = file_record["description"]
        if file_record.get("retrieval_char_limit"):
            file_entry["retrieval_char_limit"] = file_record["retrieval_char_limit"]
        global_index["files"][file_id] = file_entry
        global_index["total_lines"] += file_record["total_lines"]
        global_index["chunk_count"] += len(file_record["chunks"])

        for symbol in file_record["symbols"]:
            global_index["cross_references"][symbol["qualname"]] = {
                "file_id": file_record["file_id"],
                "chunk_id": symbol["chunk_id"],
                "path": file_record["path"],
                "lines": _format_lines(symbol["start"], symbol["end"]),
                "called_by": symbol["callers"],
                "calls": symbol["calls"],
            }
            name_index[symbol["name"]].append(symbol["qualname"])

    global_index["name_index"] = dict(sorted(name_index.items()))

    _write_json_if_changed(os.path.join(mira_dir, "global_index.json"), global_index)


def _order_relative_paths(paths):
    tree = {"dirs": {}, "files": []}
    for relative_path in paths:
        parts = relative_path.split("/")
        current = tree
        for directory in parts[:-1]:
            current = current["dirs"].setdefault(directory, {"dirs": {}, "files": []})
        current["files"].append(relative_path)

    ordered = []
    _collect_tree_paths(tree, ordered)
    return ordered


def _collect_tree_paths(node, ordered):
    ordered.extend(sorted(node["files"]))
    for directory_name in sorted(node["dirs"]):
        _collect_tree_paths(node["dirs"][directory_name], ordered)


def _function_sort_key(item):
    qualname, function_meta = item
    occupies = function_meta["occupies"]
    return occupies["start"], occupies["end"], qualname


def _class_sort_key(item):
    qualname, class_meta = item
    lines = class_meta["lines"]
    return lines["start"], lines["end"], qualname


def _format_lines(start, end):
    return f"{start}-{end}"


def _clean_returns(values):
    cleaned = []
    for value in values:
        if value is None:
            continue
        if value in {"None", "'None'", '"None"'}:
            continue
        if _is_simple_return(value) and value not in cleaned:
            cleaned.append(value)
    return cleaned


def _is_simple_return(value):
    return bool(
        re.fullmatch(r"None|True|False|-?\d+(\.\d+)?", value)
        or re.fullmatch(r"'.*'|\".*\"", value)
    )


def _short_qualname(qualname):
    return qualname.replace("::", ".").split(".")[-1]


def _unique_names(names):
    ordered = []
    seen = set()
    for name in names:
        if name and name not in seen:
            ordered.append(name)
            seen.add(name)
    return ordered


def _summarize_names(names, limit):
    unique_names = _unique_names(names)
    if len(unique_names) <= limit:
        return ", ".join(unique_names)
    visible = ", ".join(unique_names[:limit])
    return f"{visible} +{len(unique_names) - limit} more"


def _sort_chunk_ids(chunk_ids):
    return sorted(chunk_ids, key=_chunk_sort_key)


def _chunk_sort_key(chunk_id):
    file_part, local_part = chunk_id.split("_", 1)
    return int(file_part), int(local_part)


def _infer_document_origins(file_records):
    document_records = [file_record for file_record in file_records if file_record.get("file_kind") == "document"]
    code_records = [file_record for file_record in file_records if file_record.get("storage_mode") != "metadata-only"]

    for document_record in document_records:
        if document_record.get("origin") not in {None, "manual_or_external"}:
            continue
        evidence = _find_document_origin_evidence(document_record, code_records)
        if evidence is None:
            continue
        document_record["origin"] = evidence
        if document_record.get("document_structure"):
            if not any(line.startswith("origin:") for line in document_record["document_structure"]):
                document_record["document_structure"] = [
                    *document_record["document_structure"][:1],
                    f"origin: {evidence}",
                    *document_record["document_structure"][1:],
                ]


def _find_document_origin_evidence(document_record, code_records):
    write_hints = ("write", "dump", "save", "export", "emit", "generate", "open(", "ofstream", "write_text", "write_bytes")
    path_tokens = {document_record["path"], document_record["filename"]}

    for code_record in code_records:
        for line_number, line in enumerate(code_record.get("source_lines", []), start=1):
            lowered = line.lower()
            if not any(token.lower() in lowered for token in path_tokens):
                continue
            if not any(hint in lowered for hint in write_hints):
                continue
            return f"written_by [{code_record['file_id']}] {code_record['path']} line {line_number}"
    return None


def _write_guide_file(mira_dir):
    _write_text_if_changed(os.path.join(mira_dir, "GUIDE.txt"), "\n".join(build_guide_lines()) + "\n")


def _is_metadata_only(file_record):
    return file_record.get("storage_mode") == "metadata-only"


def _build_source_signature(file_path):
    stat = os.stat(file_path)
    return {
        "size": stat.st_size,
        "mtime_ns": getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)),
    }


def _format_byte_size(byte_size):
    size = float(byte_size)
    units = ["B", "KB", "MB", "GB", "TB"]
    for unit in units:
        if size < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.1f} {unit}"
        size /= 1024


def _load_json_if_exists(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return default


def _safe_history_name(relative_path):
    return relative_path.replace("/", "__") + ".txt"


def _stable_text_hash(text):
    import hashlib

    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _build_existing_file_id_map(existing_index):
    file_ids = {}
    for raw_file_id, metadata in existing_index.get("files", {}).items():
        path = metadata.get("path")
        if not path:
            continue
        try:
            file_ids[path] = int(raw_file_id)
        except (TypeError, ValueError):
            continue
    return file_ids


def _remove_stale_generated_artifacts(mira_dir, active_file_ids):
    files_dir = os.path.join(mira_dir, "files")
    if os.path.isdir(files_dir):
        for name in os.listdir(files_dir):
            if not name.isdigit() or int(name) in active_file_ids:
                continue
            shutil.rmtree(os.path.join(files_dir, name), ignore_errors=True)

    snapshots_dir = os.path.join(mira_dir, "snapshots")
    if os.path.isdir(snapshots_dir):
        for name in os.listdir(snapshots_dir):
            if not name.endswith(".txt"):
                continue
            stem = name[:-4]
            if not stem.isdigit() or int(stem) in active_file_ids:
                continue
            _remove_path_if_exists(os.path.join(snapshots_dir, name))


def _sync_directory_text_files(directory_path, expected_files):
    os.makedirs(directory_path, exist_ok=True)
    for filename, text in expected_files.items():
        _write_text_if_changed(os.path.join(directory_path, filename), text)

    for existing_name in os.listdir(directory_path):
        if existing_name in expected_files:
            continue
        _remove_path_if_exists(os.path.join(directory_path, existing_name))


def _write_json_if_changed(path, payload):
    return _write_text_if_changed(path, json.dumps(payload, indent=2))


def _write_text_if_changed(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                if handle.read() == text:
                    return False
        except Exception:
            pass

    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return True


def _remove_path_if_exists(path):
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)
    elif os.path.exists(path):
        os.remove(path)
