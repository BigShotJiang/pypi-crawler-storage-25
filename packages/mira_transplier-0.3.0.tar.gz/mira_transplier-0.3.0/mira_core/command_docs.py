PUBLIC_COMMANDS = [
    ("!project", "show this file tree"),
    ("!list", "show commands only"),
    (
        "!create [folder|file] <path>",
        "create a file or folder (example: !create /tests/confirmaiton.py | !create /docs)",
    ),
    ("!delete <path>", "delete a file or folder after confirmation (!delete /tests | !delete main.py)"),
    ("!explore <file_id>", "show file structure"),
    ("!expand <chunk_id>", "show chunk"),
    ("!expand <chunk_a-chunk_b>", "show chunk range"),
    ("!edit <file_id> [text]", "replace an entire file"),
    ("!edit <chunk_id> [text]", "replace a chunk or chunk range"),
    ("!edit <chunk_id+> [text]", "insert after a chunk"),
    ("!edit <chunk_id-> [text]", "insert before a chunk"),
    ("!edit -<chunk_id>", "delete a chunk or chunk range"),
    ("!callers <file_id>", "what depends on this file"),
    ("!deps <file_id>", "what this file depends on"),
    ("!find_line <file_id> <line>", "find chunk by line number"),
    ("!diff <file_id>", "show changes since base version"),
    ("!history <file_id>", "show MIRA edit history"),
    ("!restore <file_id> <version>", "restore file version"),
    ("!search <text>", "search across files"),
    ("!add_description <file_id>", "add file description"),
    ("!edit_description <file_id>", "edit file description"),
    ("!delete_description <file_id>", "delete file description"),
    ("!add_comment <chunk_id>", "add chunk comment"),
    ("!edit_comment <chunk_id>", "edit chunk comment"),
    ("!delete_comment <chunk_id>", "delete chunk comment"),
    ("!memory", "show memory"),
    ("!edit_memory [text]", "replace the full memory document"),
    ("!edit_memory lines <a-b> [text]", "replace a memory line range"),
    ("!edit_memory delete <a-b>", "delete a memory line range"),
    ("!goals", "show goals"),
    ("!edit_goals [text]", "replace the full goals document"),
    ("!edit_goals lines <a-b> [text]", "replace a goals line range"),
    ("!edit_goals delete <a-b>", "delete a goals line range"),
    ("!terminals", "list managed terminals"),
    ("!terminal", "show latest managed terminal"),
    ("!terminal <id>", "show managed terminal by id"),
    ("!terminal <cmd>", "run command in managed terminal"),
    ("!terminal [--id <id>] [--new] [--no-wait|--wait <seconds>] <cmd>", "run with options"),
    ("!terminal delete <id>", "delete terminal and stop it if running"),
]

ADMIN_COMMANDS = [
    ("!index", "show indexed entries"),
    ("!index add <path>", "index a file or folder"),
    ("!index remove <path>", "stop indexing a file or folder"),
    ("!environment [path|clear|create <name>]", "list, create, or set environment"),
]

GUIDE_NOTES = [
    "If inline text is omitted and stdin is piped, MIRA reads the piped text automatically.",
    "Folder indexing only includes files directly inside that folder. Subfolders need their own index entry.",
    "Dotfiles are ignored by default except .gitignore, but you can index other dotfiles explicitly with !index add.",
    "Create and delete accept workspace-relative paths, leading-slash paths, and absolute paths inside the workspace. Delete also accepts file IDs.",
]


def build_public_command_lines():
    return _format_command_lines(PUBLIC_COMMANDS)


def build_admin_command_lines():
    return _format_command_lines(ADMIN_COMMANDS)


def build_guide_lines():
    lines = ["MIRA USER COMMANDS", ""]
    lines.extend(build_public_command_lines())
    lines.extend(["", "ADMIN COMMANDS:"])
    lines.extend(build_admin_command_lines())
    lines.extend(["", "NOTES:"])
    lines.extend(f"- {note}" for note in GUIDE_NOTES)
    return lines


def _format_command_lines(commands):
    width = max(len(command) for command, _ in [*PUBLIC_COMMANDS, *ADMIN_COMMANDS])
    return [f"{command:<{width}} - {description}" for command, description in commands]