import hashlib
import json
import os


CHUNK_COMMENT_STATE_PATH = os.path.join("ADMIN", "chunk_comments.json")


def attach_chunk_comments(root_dir, mira_dir, file_records):
    state = _load_state(mira_dir)
    entries_by_path = {}
    for entry in state["entries"]:
        path = entry.get("path")
        signature = entry.get("signature")
        comment = entry.get("comment", "")
        if not path or not signature or not comment:
            continue
        entries_by_path.setdefault(path, []).append(entry)

    for file_record in file_records:
        chunks = file_record.get("chunks", [])
        if file_record.get("file_kind") == "document":
            for chunk in chunks:
                chunk["comment"] = ""
                chunk["signature"] = None
            continue

        for chunk in chunks:
            chunk["comment"] = ""
            chunk["signature"] = _signature_for_source_lines(file_record.get("source_lines", []), chunk["start"], chunk["end"])

        matched_chunk_indexes = set()
        for entry in entries_by_path.get(file_record["path"], []):
            for chunk_index, chunk in enumerate(chunks):
                if chunk_index in matched_chunk_indexes:
                    continue
                if chunk.get("signature") != entry["signature"]:
                    continue
                chunk["comment"] = entry["comment"]
                matched_chunk_indexes.add(chunk_index)
                break


def set_chunk_comments(root_dir, mira_dir, relative_path, meta, chunk_ids, comment):
    signatures = chunk_comment_signatures(root_dir, relative_path, meta, chunk_ids)
    state = _load_state(mira_dir)
    state["entries"] = [
        entry
        for entry in state["entries"]
        if not (entry.get("path") == relative_path and entry.get("signature") in signatures)
    ]
    for signature in signatures:
        state["entries"].append({"path": relative_path, "signature": signature, "comment": comment})
    _write_state(mira_dir, state)
    return signatures


def delete_chunk_comments(root_dir, mira_dir, relative_path, meta, chunk_ids):
    signatures = chunk_comment_signatures(root_dir, relative_path, meta, chunk_ids)
    return delete_chunk_comment_signatures(mira_dir, relative_path, signatures)


def delete_chunk_comment_signatures(mira_dir, relative_path, signatures):
    if not signatures:
        return 0

    state = _load_state(mira_dir)
    previous_count = len(state["entries"])
    state["entries"] = [
        entry
        for entry in state["entries"]
        if not (entry.get("path") == relative_path and entry.get("signature") in signatures)
    ]
    _write_state(mira_dir, state)
    return previous_count - len(state["entries"])


def delete_chunk_comments_for_path_prefix(mira_dir, relative_path):
    prefix = f"{relative_path}/"
    state = _load_state(mira_dir)
    state["entries"] = [
        entry
        for entry in state["entries"]
        if entry.get("path") != relative_path and not entry.get("path", "").startswith(prefix)
    ]
    _write_state(mira_dir, state)


def chunk_comment_signatures(root_dir, relative_path, meta, chunk_ids):
    chunk_spans = []
    for chunk_id in chunk_ids:
        chunk_meta = meta["chunks"].get(chunk_id)
        if chunk_meta is None:
            continue
        chunk_spans.append(_parse_lines(chunk_meta["lines"]))
    return _signatures_for_spans(root_dir, relative_path, chunk_spans)


def file_chunk_signature_set(root_dir, relative_path, meta):
    return set(chunk_comment_signatures(root_dir, relative_path, meta, meta.get("chunks", {}).keys()))


def _signatures_for_spans(root_dir, relative_path, chunk_spans):
    source_lines = _read_source_lines(root_dir, relative_path)
    signatures = []
    for start_line, end_line in chunk_spans:
        signatures.append(_signature_for_source_lines(source_lines, start_line, end_line))
    return list(dict.fromkeys(signatures))


def _signature_for_source_lines(source_lines, start_line, end_line):
    start_index = max(0, start_line - 1)
    end_index = max(start_index, min(len(source_lines), end_line))
    text = _normalize_chunk_text(source_lines[start_index:end_index])
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _normalize_chunk_text(chunk_lines):
    normalized_lines = [line.replace("\r\n", "\n") for line in chunk_lines]
    while normalized_lines and not normalized_lines[0].strip():
        normalized_lines.pop(0)
    while normalized_lines and not normalized_lines[-1].strip():
        normalized_lines.pop()
    return "".join(normalized_lines)


def _read_source_lines(root_dir, relative_path):
    source_path = os.path.join(root_dir, *relative_path.split("/"))
    with open(source_path, "r", encoding="utf-8", errors="replace") as handle:
        return handle.readlines()


def _parse_lines(lines_text):
    start_text, end_text = lines_text.split("-", 1)
    return int(start_text), int(end_text)


def _load_state(mira_dir):
    state_path = os.path.join(mira_dir, CHUNK_COMMENT_STATE_PATH)
    if not os.path.exists(state_path):
        return {"entries": []}
    try:
        with open(state_path, "r", encoding="utf-8") as handle:
            state = json.load(handle)
    except Exception:
        return {"entries": []}

    entries = state.get("entries", []) if isinstance(state, dict) else []
    if not isinstance(entries, list):
        entries = []
    return {"entries": entries}


def _write_state(mira_dir, state):
    state_path = os.path.join(mira_dir, CHUNK_COMMENT_STATE_PATH)
    os.makedirs(os.path.dirname(state_path), exist_ok=True)
    with open(state_path, "w", encoding="utf-8") as handle:
        json.dump(state, handle, indent=2)