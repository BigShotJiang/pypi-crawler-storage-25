"""Package metadata."""

__version__ = "0.1.5"
