# Changelog

All notable changes to the `niansys` SDK are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

*(nothing yet — open a PR if you have ideas!)*

---

## [0.1.0] — 2026-05-17

Initial alpha release of the NIANSYS Python SDK.

### Added

- **`Guardian` client** with both synchronous and asynchronous APIs:
  - `Guardian.check(action, target=None, metadata=None) -> CheckResult` — synchronous risk check.
  - `Guardian.acheck(action, target=None, metadata=None) -> CheckResult` — asynchronous variant, usable with `asyncio.gather` for concurrent batches.
- **`CheckResult`** Pydantic model exposing `allowed`, `risk_score`, `risk_level`, `reason`, `event_id`.
- **Typed exception hierarchy**, all rooted at `NiansysError`:
  - `NiansysAuthError` (401 / 403)
  - `NiansysValidationError` (400 / 422)
  - `NiansysRateLimitError` (429)
  - `NiansysServerError` (5xx after retries, only with `fail_open=False`)
  - `NiansysNetworkError` (transport failure after retries, only with `fail_open=False`)
- **Automatic retries** on 5xx and network errors: 3 attempts with exponential backoff (0.5s → 1s → 2s).
- **`fail_open` policy** (default `True`): graceful degradation — if NIANSYS is unreachable, the host agent keeps running with a permissive result.
- **`observe` and `control` modes** (control mode reserved for Phase 5+).
- **Context-manager lifecycle**: `with Guardian(...)` for sync, `async with Guardian(...)` for async, plus explicit `close()` / `aclose()` methods.
- **PEP 561 typed package** (`py.typed` marker): mypy and pyright pick up types automatically.
- **58 unit tests** with `respx` covering every reliability scenario.
- **Two runnable examples** in `examples/`:
  - `openai_integration.py` — protect every OpenAI tool call with a NIANSYS check.
  - `concurrent_batch.py` — validate 50+ actions in parallel via `asyncio.gather`.

### Supported

- Python 3.9, 3.10, 3.11, 3.12.

[Unreleased]: https://github.com/gildasassande/niansys/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/gildasassande/niansys/releases/tag/v0.1.0
