"""Structural smoke tests for the SDK package.

These tests don't exercise real HTTP — they just verify:

1. The public API can be imported the documented way.
2. The version is exposed.
3. The :class:`Guardian` constructor validates its inputs.
4. The :class:`CheckResult` model has sensible defaults.
5. The exception hierarchy roots at :class:`NiansysError`.

The actual HTTP behavior of :meth:`Guardian.check` is tested in
``test_check_sync.py`` and :meth:`Guardian.acheck` in
``test_check_async.py``, both with respx mocks.
"""

from __future__ import annotations

import pytest

import niansys
from niansys import (
    CheckResult,
    Guardian,
    NiansysAuthError,
    NiansysError,
    NiansysNetworkError,
    NiansysRateLimitError,
    NiansysServerError,
    NiansysValidationError,
)

# ---------------------------------------------------------------------------
# Package metadata
# ---------------------------------------------------------------------------

def test_version_is_exposed() -> None:
    assert isinstance(niansys.__version__, str)
    assert niansys.__version__ == "0.1.0"


def test_public_api_is_complete() -> None:
    for name in (
        "Guardian",
        "CheckResult",
        "NiansysError",
        "NiansysAuthError",
        "NiansysNetworkError",
        "NiansysRateLimitError",
        "NiansysServerError",
        "NiansysValidationError",
    ):
        assert name in niansys.__all__, f"{name} missing from niansys.__all__"


# ---------------------------------------------------------------------------
# Guardian construction
# ---------------------------------------------------------------------------

def test_guardian_requires_agent_key() -> None:
    with pytest.raises(ValueError, match="agent_key is required"):
        Guardian(agent_key="")


def test_guardian_has_sensible_defaults() -> None:
    g = Guardian(agent_key="iag_test")
    assert g.agent_key == "iag_test"
    assert g.mode == "observe"
    assert g.fail_open is True
    assert g.timeout == 5.0
    assert g.base_url.startswith("https://")
    g.close()


def test_guardian_rejects_invalid_mode() -> None:
    with pytest.raises(ValueError, match="mode must be"):
        Guardian(agent_key="iag_test", mode="paranoid")


def test_guardian_rejects_non_positive_timeout() -> None:
    with pytest.raises(ValueError, match="timeout must be"):
        Guardian(agent_key="iag_test", timeout=0)


def test_guardian_strips_trailing_slash_in_base_url() -> None:
    g = Guardian(agent_key="iag_test", base_url="https://api.niansys.com/")
    assert g.base_url == "https://api.niansys.com"
    g.close()


def test_guardian_repr_is_informative() -> None:
    g = Guardian(agent_key="iag_test", mode="control", fail_open=False)
    text = repr(g)
    assert "control" in text
    assert "fail_open=False" in text
    g.close()


# ---------------------------------------------------------------------------
# CheckResult model
# ---------------------------------------------------------------------------

def test_check_result_defaults() -> None:
    r = CheckResult()
    assert r.allowed is True
    assert r.risk_score == 0
    assert r.risk_level == "low"
    assert r.reason is None
    assert r.event_id is None


def test_check_result_rejects_out_of_range_score() -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        CheckResult(risk_score=150)


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "exc",
    [
        NiansysAuthError,
        NiansysNetworkError,
        NiansysRateLimitError,
        NiansysServerError,
        NiansysValidationError,
    ],
)
def test_all_exceptions_inherit_from_base(exc: type) -> None:
    assert issubclass(exc, NiansysError)
    assert issubclass(exc, Exception)
