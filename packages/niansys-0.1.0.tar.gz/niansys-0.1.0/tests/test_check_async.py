"""Tests for the asynchronous :meth:`Guardian.acheck` implementation (step B3).

Mirrors ``test_check_sync.py`` but with the async API. The classification
logic is shared between sync and async, so these tests primarily verify
that the async **transport** behaves the same way.
"""

from __future__ import annotations

import asyncio
import json

import httpx
import pytest
import respx

from niansys import (
    CheckResult,
    Guardian,
    NiansysAuthError,
    NiansysNetworkError,
    NiansysRateLimitError,
    NiansysServerError,
    NiansysValidationError,
)
from niansys import __version__ as sdk_version

BASE_URL = "http://test.niansys.local"
CHECK_URL = f"{BASE_URL}/api/v1/check"
AGENT_KEY = "iag_test_key_xxx"


def _make_guardian(**overrides) -> Guardian:
    kwargs = {
        "agent_key": AGENT_KEY,
        "base_url": BASE_URL,
        "fail_open": True,
        "timeout": 1.0,
    }
    kwargs.update(overrides)
    return Guardian(**kwargs)


def _success_payload(**overrides) -> dict:
    data = {
        "allowed": True,
        "risk_score": 12,
        "risk_level": "low",
        "reason": None,
        "event_id": "evt_abc",
    }
    data.update(overrides)
    return data


@pytest.fixture(autouse=True)
def _no_real_async_sleep(monkeypatch):
    """Make async retry backoff instant so tests stay fast."""
    async def _noop(_attempt):
        return None
    monkeypatch.setattr("niansys.client._asleep_backoff", _noop)


# =========================================================
# Happy path
# =========================================================

@respx.mock
async def test_acheck_returns_a_check_result():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    async with _make_guardian() as g:
        result = await g.acheck(action="send_email")
    assert isinstance(result, CheckResult)


@respx.mock
async def test_acheck_parses_all_response_fields():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(
            200,
            json=_success_payload(
                risk_score=80,
                risk_level="high",
                reason="Sensitive action 'drop_table' (+65)",
                event_id="evt_xyz",
            ),
        )
    )
    async with _make_guardian() as g:
        result = await g.acheck(action="drop_table", target="prod.users")
    assert result.allowed is True
    assert result.risk_score == 80
    assert result.risk_level == "high"
    assert result.reason == "Sensitive action 'drop_table' (+65)"
    assert result.event_id == "evt_xyz"


@respx.mock
async def test_acheck_sends_agent_key_header():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    async with _make_guardian() as g:
        await g.acheck(action="send_email")
    sent = route.calls.last.request
    assert sent.headers["x-agent-key"] == AGENT_KEY


@respx.mock
async def test_acheck_sends_user_agent_header():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    async with _make_guardian() as g:
        await g.acheck(action="send_email")
    sent = route.calls.last.request
    assert sent.headers["user-agent"] == f"niansys-python/{sdk_version}"


@respx.mock
async def test_acheck_sends_correct_json_body():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    async with _make_guardian() as g:
        await g.acheck(
            action="send_email",
            target="ceo@acme.com",
            metadata={"subject": "Q4"},
        )
    body = json.loads(route.calls.last.request.content)
    assert body == {
        "action": "send_email",
        "target": "ceo@acme.com",
        "metadata": {"subject": "Q4"},
    }


# =========================================================
# 4xx — always raise, never retry
# =========================================================

@pytest.mark.parametrize("status_code", [401, 403])
@respx.mock
async def test_acheck_auth_errors_raise_without_retry(status_code):
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(status_code, json={"detail": "Invalid agent key"})
    )
    async with _make_guardian() as g:
        with pytest.raises(NiansysAuthError, match="Invalid agent key"):
            await g.acheck(action="send_email")
    assert route.call_count == 1


@pytest.mark.parametrize("status_code", [400, 422])
@respx.mock
async def test_acheck_validation_errors_raise_without_retry(status_code):
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(status_code, json={"detail": "Malformed"})
    )
    async with _make_guardian() as g:
        with pytest.raises(NiansysValidationError):
            await g.acheck(action="send_email")
    assert route.call_count == 1


@respx.mock
async def test_acheck_rate_limit_raises_without_retry():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(429, json={"detail": "Too many requests"})
    )
    async with _make_guardian() as g:
        with pytest.raises(NiansysRateLimitError):
            await g.acheck(action="send_email")
    assert route.call_count == 1


# =========================================================
# 5xx — retry 3 times, then raise (fail_closed) or permissive (fail_open)
# =========================================================

@respx.mock
async def test_acheck_5xx_retried_3_times_then_raised_when_fail_closed():
    route = respx.post(CHECK_URL).mock(return_value=httpx.Response(503))
    async with _make_guardian(fail_open=False) as g:
        with pytest.raises(NiansysServerError):
            await g.acheck(action="send_email")
    assert route.call_count == 3


@respx.mock
async def test_acheck_5xx_then_success_succeeds():
    route = respx.post(CHECK_URL).mock(
        side_effect=[
            httpx.Response(503),
            httpx.Response(503),
            httpx.Response(200, json=_success_payload(risk_score=42)),
        ]
    )
    async with _make_guardian(fail_open=False) as g:
        result = await g.acheck(action="send_email")
    assert result.risk_score == 42
    assert route.call_count == 3


@respx.mock
async def test_acheck_5xx_with_fail_open_returns_permissive():
    respx.post(CHECK_URL).mock(return_value=httpx.Response(503))
    async with _make_guardian(fail_open=True) as g:
        result = await g.acheck(action="send_email")
    assert result.allowed is True
    assert result.risk_score == 0
    assert result.reason is not None
    assert "fail-open" in result.reason


# =========================================================
# Network errors
# =========================================================

@respx.mock
async def test_acheck_network_error_with_fail_open_returns_permissive():
    respx.post(CHECK_URL).mock(side_effect=httpx.ConnectError("nope"))
    async with _make_guardian(fail_open=True) as g:
        result = await g.acheck(action="send_email")
    assert result.allowed is True
    assert result.reason is not None
    assert "fail-open" in result.reason


@respx.mock
async def test_acheck_network_error_with_fail_closed_raises():
    route = respx.post(CHECK_URL).mock(side_effect=httpx.ConnectError("nope"))
    async with _make_guardian(fail_open=False) as g:
        with pytest.raises(NiansysNetworkError):
            await g.acheck(action="send_email")
    assert route.call_count == 3


@respx.mock
async def test_acheck_timeout_is_retried():
    route = respx.post(CHECK_URL).mock(side_effect=httpx.ReadTimeout("slow"))
    async with _make_guardian(fail_open=False) as g:
        with pytest.raises(NiansysNetworkError):
            await g.acheck(action="send_email")
    assert route.call_count == 3


# =========================================================
# URL handling
# =========================================================

@respx.mock
async def test_acheck_targets_the_correct_path():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    async with _make_guardian() as g:
        await g.acheck(action="send_email")
    sent = route.calls.last.request
    assert sent.url.path == "/api/v1/check"
    assert sent.method == "POST"


# =========================================================
# Lifecycle — async client is lazy, async context manager closes both
# =========================================================

@respx.mock
async def test_async_client_is_created_lazily():
    """Until you call acheck, no async client should be instantiated."""
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    g = _make_guardian()
    assert g._async_client is None
    await g.acheck(action="send_email")
    assert g._async_client is not None
    await g.aclose()


@respx.mock
async def test_async_context_manager_closes_both_clients():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    g = _make_guardian()
    async with g:
        await g.acheck(action="send_email")
    assert g._async_client is not None and g._async_client.is_closed
    assert g._client.is_closed


@respx.mock
async def test_aclose_is_idempotent():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    g = _make_guardian()
    await g.acheck(action="send_email")
    await g.aclose()
    await g.aclose()  # second call must not raise
    assert g._async_client is not None and g._async_client.is_closed


@respx.mock
async def test_aclose_without_acheck_is_safe():
    """Calling aclose() when acheck() was never used should not crash."""
    g = _make_guardian()
    await g.aclose()
    assert g._client.is_closed
    assert g._async_client is None  # was never created


# =========================================================
# Concurrent execution — THE killer feature of async
# =========================================================

@respx.mock
async def test_acheck_supports_concurrent_gather():
    """asyncio.gather() of multiple acheck() runs them concurrently."""
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    async with _make_guardian() as g:
        results = await asyncio.gather(
            g.acheck(action="a1"),
            g.acheck(action="a2"),
            g.acheck(action="a3"),
            g.acheck(action="a4"),
            g.acheck(action="a5"),
        )
    assert len(results) == 5
    assert all(isinstance(r, CheckResult) for r in results)
    assert route.call_count == 5
