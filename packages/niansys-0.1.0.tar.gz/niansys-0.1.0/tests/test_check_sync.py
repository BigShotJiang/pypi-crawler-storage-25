"""Tests for the synchronous :meth:`Guardian.check` implementation (step B2).

We use **respx** to mock the underlying httpx transport, so no real HTTP
calls happen. Every scenario the SDK can encounter is exercised here:

- happy path with all response fields
- correct headers / body shape
- 4xx errors raised, never retried
- 5xx errors retried with backoff, then raised or permissive (fail_open)
- network errors retried, then raised or permissive (fail_open)
- URL construction (trailing slash, custom base_url)
"""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from niansys import (
    CheckResult,
    Guardian,
    NiansysAuthError,
    NiansysNetworkError,
    NiansysRateLimitError,
    NiansysServerError,
    NiansysValidationError,
)
from niansys import __version__ as sdk_version

BASE_URL = "http://test.niansys.local"
CHECK_URL = f"{BASE_URL}/api/v1/check"
AGENT_KEY = "iag_test_key_xxx"


def _make_guardian(**overrides) -> Guardian:
    """Helper to build a Guardian with sensible test defaults."""
    kwargs = {
        "agent_key": AGENT_KEY,
        "base_url": BASE_URL,
        "fail_open": True,
        "timeout": 1.0,
    }
    kwargs.update(overrides)
    return Guardian(**kwargs)


def _success_payload(**overrides) -> dict:
    """A valid CheckResponse JSON payload from the server."""
    data = {
        "allowed": True,
        "risk_score": 12,
        "risk_level": "low",
        "reason": None,
        "event_id": "evt_abc",
    }
    data.update(overrides)
    return data


@pytest.fixture(autouse=True)
def _no_real_sleep(monkeypatch):
    """Make retry backoff instant so tests stay fast."""
    monkeypatch.setattr("niansys.client._sleep_backoff", lambda _: None)


# =========================================================
# Happy path
# =========================================================

@respx.mock
def test_check_returns_a_check_result():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    with _make_guardian() as g:
        result = g.check(action="send_email")
    assert isinstance(result, CheckResult)


@respx.mock
def test_check_parses_all_response_fields():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(
            200,
            json=_success_payload(
                risk_score=80,
                risk_level="high",
                reason="Sensitive action 'drop_table' (+65)",
                event_id="evt_xyz",
            ),
        )
    )
    with _make_guardian() as g:
        result = g.check(action="drop_table", target="prod.users")
    assert result.allowed is True
    assert result.risk_score == 80
    assert result.risk_level == "high"
    assert result.reason == "Sensitive action 'drop_table' (+65)"
    assert result.event_id == "evt_xyz"


@respx.mock
def test_check_sends_agent_key_header():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    with _make_guardian() as g:
        g.check(action="send_email")
    sent = route.calls.last.request
    assert sent.headers["x-agent-key"] == AGENT_KEY


@respx.mock
def test_check_sends_user_agent_header():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    with _make_guardian() as g:
        g.check(action="send_email")
    sent = route.calls.last.request
    assert sent.headers["user-agent"] == f"niansys-python/{sdk_version}"


@respx.mock
def test_check_sends_correct_json_body():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    with _make_guardian() as g:
        g.check(
            action="send_email",
            target="ceo@acme.com",
            metadata={"subject": "Q4"},
        )
    body = json.loads(route.calls.last.request.content)
    assert body == {
        "action": "send_email",
        "target": "ceo@acme.com",
        "metadata": {"subject": "Q4"},
    }


@respx.mock
def test_check_omits_optional_fields_correctly():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    with _make_guardian() as g:
        g.check(action="send_email")
    body = json.loads(route.calls.last.request.content)
    assert body["action"] == "send_email"
    assert body["target"] is None
    assert body["metadata"] == {}


# =========================================================
# 4xx — always raise, never retry
# =========================================================

@pytest.mark.parametrize("status_code", [401, 403])
@respx.mock
def test_auth_errors_raise_without_retry(status_code):
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(status_code, json={"detail": "Invalid agent key"})
    )
    with _make_guardian() as g, pytest.raises(NiansysAuthError, match="Invalid agent key"):
        g.check(action="send_email")
    assert route.call_count == 1


@pytest.mark.parametrize("status_code", [400, 422])
@respx.mock
def test_validation_errors_raise_without_retry(status_code):
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(status_code, json={"detail": "Malformed payload"})
    )
    with _make_guardian() as g, pytest.raises(NiansysValidationError):
        g.check(action="send_email")
    assert route.call_count == 1


@respx.mock
def test_rate_limit_error_raises_without_retry():
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(429, json={"detail": "Too many requests"})
    )
    with _make_guardian() as g, pytest.raises(NiansysRateLimitError):
        g.check(action="send_email")
    assert route.call_count == 1


# =========================================================
# 5xx — retry 3 times, then raise (fail_closed) or permissive (fail_open)
# =========================================================

@respx.mock
def test_5xx_is_retried_3_times_then_raised_when_fail_closed():
    route = respx.post(CHECK_URL).mock(return_value=httpx.Response(503))
    with _make_guardian(fail_open=False) as g, pytest.raises(NiansysServerError):
        g.check(action="send_email")
    assert route.call_count == 3  # initial + 2 retries


@respx.mock
def test_5xx_then_success_succeeds():
    route = respx.post(CHECK_URL).mock(
        side_effect=[
            httpx.Response(503),
            httpx.Response(503),
            httpx.Response(200, json=_success_payload(risk_score=42)),
        ]
    )
    with _make_guardian(fail_open=False) as g:
        result = g.check(action="send_email")
    assert result.risk_score == 42
    assert route.call_count == 3


@respx.mock
def test_5xx_with_fail_open_returns_permissive_result():
    respx.post(CHECK_URL).mock(return_value=httpx.Response(503))
    with _make_guardian(fail_open=True) as g:
        result = g.check(action="send_email")
    assert result.allowed is True
    assert result.risk_score == 0
    assert result.reason is not None
    assert "fail-open" in result.reason


# =========================================================
# Network errors — retry, then permissive (fail_open) or raise (fail_closed)
# =========================================================

@respx.mock
def test_network_error_with_fail_open_returns_permissive():
    respx.post(CHECK_URL).mock(side_effect=httpx.ConnectError("nope"))
    with _make_guardian(fail_open=True) as g:
        result = g.check(action="send_email")
    assert result.allowed is True
    assert result.reason is not None
    assert "fail-open" in result.reason


@respx.mock
def test_network_error_with_fail_closed_raises_after_retries():
    route = respx.post(CHECK_URL).mock(side_effect=httpx.ConnectError("nope"))
    with _make_guardian(fail_open=False) as g, pytest.raises(NiansysNetworkError):
        g.check(action="send_email")
    assert route.call_count == 3  # initial + 2 retries


@respx.mock
def test_timeout_is_retried_like_other_network_errors():
    route = respx.post(CHECK_URL).mock(side_effect=httpx.ReadTimeout("slow"))
    with _make_guardian(fail_open=False) as g, pytest.raises(NiansysNetworkError):
        g.check(action="send_email")
    assert route.call_count == 3


# =========================================================
# URL handling
# =========================================================

@respx.mock
def test_base_url_with_trailing_slash_is_normalized():
    respx.post(f"{BASE_URL}/api/v1/check").mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    with Guardian(
        agent_key=AGENT_KEY, base_url=f"{BASE_URL}/", timeout=1.0
    ) as g:
        result = g.check(action="send_email")
    assert result.allowed is True


@respx.mock
def test_check_targets_the_correct_path():
    """Make sure we hit /api/v1/check and not anything else."""
    route = respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    with _make_guardian() as g:
        g.check(action="send_email")
    sent = route.calls.last.request
    assert sent.url.path == "/api/v1/check"
    assert sent.method == "POST"


# =========================================================
# Context manager / lifecycle
# =========================================================

@respx.mock
def test_context_manager_closes_client():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    g = _make_guardian()
    with g:
        g.check(action="send_email")
    # After __exit__, the underlying httpx client should be closed.
    assert g._client.is_closed


@respx.mock
def test_close_is_idempotent():
    respx.post(CHECK_URL).mock(
        return_value=httpx.Response(200, json=_success_payload())
    )
    g = _make_guardian()
    g.check(action="send_email")
    g.close()
    g.close()  # second call must not raise
    assert g._client.is_closed
