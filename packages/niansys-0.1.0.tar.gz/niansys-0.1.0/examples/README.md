# NIANSYS SDK — Examples

Runnable scripts showing how to plug NIANSYS into real agent workflows. Each example is intentionally short, self-contained, and well commented so you can read it in 2 minutes and copy-paste it into your own project in 5.

| File | What it shows |
|---|---|
| [`openai_integration.py`](./openai_integration.py) | Plug NIANSYS into an OpenAI tool-calling agent. Every tool call is validated **before** execution; blocked calls are reported back to the model. The canonical integration pattern — same idea works with Anthropic, LangChain, autogen, etc. |
| [`concurrent_batch.py`](./concurrent_batch.py) | Validate 52 agent actions in parallel via `asyncio.gather`. Common pattern for high-throughput agents. Showcases the async API. |

## Running them

Each example needs your NIANSYS agent key. Get one from the NIANSYS dashboard, then:

```bash
export NIANSYS_AGENT_KEY=iag_...

# OpenAI example also needs an OpenAI key.
export OPENAI_API_KEY=sk-...
python examples/openai_integration.py

# Concurrent batch example is self-sufficient.
python examples/concurrent_batch.py
```

## Pointing at a local backend

If you're running the NIANSYS backend locally (for development):

```bash
export NIANSYS_BASE_URL=http://127.0.0.1:8000
```

The examples honor this environment variable (or fall back to the public production cloud).

## Want to contribute an example?

Open a PR with your script in this folder and add a row to the table above. We love new integration patterns — especially with frameworks the existing examples don't cover.
