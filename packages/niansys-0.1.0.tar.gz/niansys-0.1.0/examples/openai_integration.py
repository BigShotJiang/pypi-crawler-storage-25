"""Example: NIANSYS validates every tool call in an OpenAI agent.

This is the canonical integration pattern. The same idea works with
Anthropic's tool-use, with LangChain tools, with autogen agents, etc.

Pattern in 4 steps
------------------
1. Define the tools your agent can call.
2. Let the model decide *when* to call a tool.
3. **Before** executing the tool, call ``guardian.check(...)``.
4. If allowed, execute. If blocked, feed the rejection back to the model.

Requirements
------------
Two environment variables:

- ``NIANSYS_AGENT_KEY`` — from your NIANSYS dashboard (``iag_...``).
- ``OPENAI_API_KEY``   — from your OpenAI account (``sk-...``).

Install
-------
    pip install niansys openai

Run
---
    python examples/openai_integration.py
"""

from __future__ import annotations

import json
import os
import sys

try:
    from openai import OpenAI
except ImportError:
    sys.exit("Please run: pip install openai")

from niansys import Guardian, NiansysError

# --------------------------------------------------------------------------
# 1. Define the tools your agent can call.
# --------------------------------------------------------------------------
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "send_email",
            "description": "Send an email to a recipient.",
            "parameters": {
                "type": "object",
                "properties": {
                    "to": {"type": "string", "description": "Email address"},
                    "subject": {"type": "string"},
                    "body": {"type": "string"},
                },
                "required": ["to", "subject", "body"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "drop_table",
            "description": "Drop a database table. IRREVERSIBLE.",
            "parameters": {
                "type": "object",
                "properties": {
                    "table": {"type": "string"},
                },
                "required": ["table"],
            },
        },
    },
]


# --------------------------------------------------------------------------
# 2. Real tool implementations (stubs here — replace with your real code).
# --------------------------------------------------------------------------
def send_email(to: str, subject: str, body: str) -> dict:
    print(f"    [tool] sending email to {to}: {subject!r}")
    return {"status": "sent", "recipient": to}


def drop_table(table: str) -> dict:
    print(f"    [tool] dropping table {table}")
    return {"status": "dropped", "table": table}


TOOL_REGISTRY = {
    "send_email": send_email,
    "drop_table": drop_table,
}


# --------------------------------------------------------------------------
# 3. NIANSYS-protected tool executor.
#    THIS is where the SDK plugs in.
# --------------------------------------------------------------------------
def execute_with_niansys(
    guardian: Guardian, tool_name: str, tool_args: dict
) -> str:
    """Validate the tool call with NIANSYS, then execute it (or block).

    Returns a string suitable to feed back to the model as a tool result.
    """
    # Build a `target` value from the tool args. Convention here: pick the
    # first identifying argument. In a real app you'd map this per-tool.
    target = tool_args.get("to") or tool_args.get("table") or ""

    try:
        result = guardian.check(
            action=tool_name,
            target=target,
            metadata=tool_args,
        )
    except NiansysError as exc:
        # When fail_open=False (high-security mode), this can raise. We
        # convert it into a model-readable message so the agent doesn't crash.
        return f"NIANSYS error: {exc}. Tool call aborted."

    if not result.allowed:
        return (
            f"BLOCKED by NIANSYS (risk_score={result.risk_score}): "
            f"{result.reason}"
        )

    # Action approved — execute the real tool.
    fn = TOOL_REGISTRY[tool_name]
    output = fn(**tool_args)
    return json.dumps(
        {
            "tool_output": output,
            "niansys_risk_score": result.risk_score,
            "niansys_event_id": result.event_id,
        }
    )


# --------------------------------------------------------------------------
# 4. Main agent loop.
# --------------------------------------------------------------------------
def run_agent(user_message: str) -> None:
    agent_key = os.environ.get("NIANSYS_AGENT_KEY")
    if not agent_key:
        sys.exit("Please set NIANSYS_AGENT_KEY in your environment.")

    openai_client = OpenAI()  # reads OPENAI_API_KEY automatically

    with Guardian(agent_key=agent_key) as guardian:
        messages: list[dict] = [
            {
                "role": "system",
                "content": (
                    "You are an agent that can send emails and drop tables. "
                    "Use the available tools to fulfill the user's request."
                ),
            },
            {"role": "user", "content": user_message},
        ]

        # Cap iterations to avoid runaway tool-call loops.
        for step in range(5):
            response = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=messages,
                tools=TOOLS,
            )
            msg = response.choices[0].message

            if not msg.tool_calls:
                # Agent is done — print its final reply and exit.
                print(f"[agent] {msg.content}")
                return

            # Add the assistant's tool-call request to history.
            messages.append(msg)

            # Validate + execute every tool call requested in this step.
            for tool_call in msg.tool_calls:
                tool_name = tool_call.function.name
                tool_args = json.loads(tool_call.function.arguments)
                print(f"[step {step}] tool call: {tool_name}({tool_args})")
                result_text = execute_with_niansys(
                    guardian, tool_name, tool_args
                )
                print(f"          result: {result_text}")
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": result_text,
                    }
                )

        print("[agent] Iteration limit reached without a final answer.")


if __name__ == "__main__":
    # Edit this prompt or call run_agent("...") with your own to try things.
    # The high-risk prompt below should produce a `BLOCKED by NIANSYS` line.
    run_agent("Please send a short email to ceo@acme.com about today's Q4 results.")
    # run_agent("Drop the prod.users table to free up space.")  # ← gets blocked
