"""Example: validate a batch of 52 agent actions in parallel.

Pattern: an agent has a queue of actions to perform. Instead of validating
them one by one (52 sequential round-trips to NIANSYS), we batch-validate
them concurrently in roughly one wall-clock round-trip using
``asyncio.gather``. This is the killer feature of the SDK's async API and
a common production pattern for high-throughput agents.

Run
---
    pip install niansys
    export NIANSYS_AGENT_KEY=iag_...
    # Optional: point at a local backend for testing.
    # export NIANSYS_BASE_URL=http://127.0.0.1:8000
    python examples/concurrent_batch.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Any

from niansys import CheckResult, Guardian


@dataclass
class AgentAction:
    """A single action an agent wants to perform."""

    action: str
    target: str
    metadata: dict[str, Any] = field(default_factory=dict)


# Simulated batch of 52 actions the agent collected during one tick:
# 50 routine sends + 2 suspicious ones that should bubble up to the top.
BATCH: list[AgentAction] = [
    AgentAction(
        action="send_email",
        target=f"user{i}@example.com",
        metadata={"campaign": "newsletter", "subject": "Weekly digest"},
    )
    for i in range(50)
] + [
    AgentAction(
        action="drop_table",
        target="prod.users",
        metadata={"reason": "cleanup"},
    ),
    AgentAction(
        action="transfer_funds",
        target="iban_unknown_external",
        metadata={"amount": 50000, "currency": "EUR"},
    ),
]


async def validate_batch(
    guardian: Guardian, batch: list[AgentAction]
) -> list[tuple[AgentAction, CheckResult]]:
    """Validate every action in parallel."""
    coroutines = [
        guardian.acheck(
            action=a.action,
            target=a.target,
            metadata=a.metadata,
        )
        for a in batch
    ]
    results = await asyncio.gather(*coroutines)
    return list(zip(batch, results))


async def main() -> None:
    agent_key = os.environ.get("NIANSYS_AGENT_KEY")
    if not agent_key:
        sys.exit("Please set NIANSYS_AGENT_KEY in your environment.")

    base_url = os.environ.get("NIANSYS_BASE_URL", "https://api.niansys.com")

    print(f"Validating {len(BATCH)} actions in parallel ...")
    start = time.perf_counter()

    async with Guardian(agent_key=agent_key, base_url=base_url) as guardian:
        pairs = await validate_batch(guardian, BATCH)

    elapsed = time.perf_counter() - start

    allowed = [(a, r) for a, r in pairs if r.allowed]
    blocked = [(a, r) for a, r in pairs if not r.allowed]
    high_risk = [(a, r) for a, r in pairs if r.risk_score >= 70]

    print()
    print(f"Done in {elapsed:.2f}s wall-clock time.")
    print(f"  Total actions       : {len(pairs)}")
    print(f"  Allowed             : {len(allowed)}")
    print(f"  Blocked             : {len(blocked)}")
    print(f"  High-risk (score>=70): {len(high_risk)}")

    if high_risk:
        print()
        print("High-risk actions worth a human review:")
        for action, result in high_risk:
            print(
                f"  {action.action:18} -> {action.target:32} "
                f"score={result.risk_score:3}  reason={result.reason}"
            )


if __name__ == "__main__":
    asyncio.run(main())
