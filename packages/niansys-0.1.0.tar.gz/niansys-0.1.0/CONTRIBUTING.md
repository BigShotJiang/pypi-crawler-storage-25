# Contributing to `niansys`

Thanks for considering a contribution! NIANSYS is in early alpha, the surface is small, and clear contributions move things faster.

## Reporting a bug

Open an [issue](https://github.com/gildasassande/niansys/issues) with:

- What you tried (a minimal code snippet helps a lot).
- What you expected.
- What actually happened (full error message / traceback).
- Your Python version + OS + `niansys` version.

## Suggesting a feature

Same — open an issue. Describe the use case before the implementation. If the use case is convincing, the implementation usually follows quickly.

## Submitting a pull request

1. **Fork** the repo and create a feature branch: `git checkout -b feature/your-thing`
2. **Make the change**, keeping it focused on one concern per PR.
3. **Add tests** — we aim for 100% coverage on new code.
4. **Run the full suite locally**:
   ```bash
   pytest -v
   ruff check src tests
   ```
5. **Open the PR** with a clear description: what changed, why, how to verify.

## Coding conventions

- Python 3.9+ compatible (`from __future__ import annotations` is fine).
- Type hints on every public API. Internal helpers are typed too when it adds clarity.
- Docstrings in NumPy style (see existing modules for the pattern).
- 100-character line limit, enforced by `ruff`.
- One test file per source module.

## Local dev setup

```bash
git clone https://github.com/gildasassande/niansys.git
cd niansys
python -m venv .venv
source .venv/bin/activate          # macOS / Linux
# or: .venv\Scripts\activate        # Windows PowerShell
pip install -e ".[dev]"
pytest
```

## Code of conduct

Be kind, be specific, focus on the code not the person. That's it.

## License

By contributing, you agree that your code will be licensed under [MIT](./LICENSE) — the same license as the rest of the SDK.
