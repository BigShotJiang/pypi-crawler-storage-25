"""Guardian client — sync (check) + async (acheck) entry points of the NIANSYS SDK.

Same public contract for both methods:

* Endpoint: ``POST <base_url>/api/v1/check``
* Auth: ``X-Agent-Key`` header
* Body: ``{action, target?, metadata?}``
* Response: ``{allowed, risk_score, risk_level, reason?, event_id}``

The retry / error-classification logic is shared between :meth:`Guardian.check`
and :meth:`Guardian.acheck` through module-level helpers
(:func:`_classify_response` / :func:`_classify_network_error`), so any future
change to reliability semantics applies uniformly to both.

Reliability semantics
---------------------
* **4xx** → always raise (typed). The developer must fix something.
* **5xx** → retry 3 times with exponential backoff (0.5s → 1s → 2s). Then:

  - ``fail_open=True`` *(default)*: permissive :class:`CheckResult`.
  - ``fail_open=False``: :class:`NiansysServerError`.

* **Network error** (timeout, DNS, connection refused) → retry 3 times. Then:

  - ``fail_open=True``: permissive :class:`CheckResult`.
  - ``fail_open=False``: :class:`NiansysNetworkError`.

Lifecycle
---------
A :class:`Guardian` holds **two** httpx clients internally:

* A :class:`httpx.Client` for sync, created eagerly in ``__init__``.
* A :class:`httpx.AsyncClient` for async, created lazily on the first
  :meth:`acheck` call.

Use ``with Guardian(...) as g:`` if you only use :meth:`check`.
Use ``async with Guardian(...) as g:`` if you use :meth:`acheck` (it cleans
up both clients).
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Optional, Union

import httpx

from niansys.exceptions import (
    NiansysAuthError,
    NiansysNetworkError,
    NiansysRateLimitError,
    NiansysServerError,
    NiansysValidationError,
)
from niansys.models import CheckResult

# --------------------------------------------------------------------------
# Public defaults
# --------------------------------------------------------------------------
DEFAULT_BASE_URL = "https://api.niansys.com"
DEFAULT_TIMEOUT = 5.0
ALLOWED_MODES = ("observe", "control")

# --------------------------------------------------------------------------
# Internal — wire details and retry policy.
# --------------------------------------------------------------------------
_CHECK_PATH = "/api/v1/check"
_MAX_ATTEMPTS = 3                       # initial + 2 retries
_BACKOFF_BASE_SECONDS = 0.5             # 0.5s → 1s → 2s

# Outcome kinds returned by the classification helpers.
_SUCCESS = "success"
_RETRY = "retry"
_RAISE = "raise"
_PERMISSIVE = "permissive"

# Type alias for what _classify_* helpers return. Uses PEP 585 builtin
# generics (`tuple[...]`) which are evaluated at runtime on Python 3.9+,
# plus typing.Optional/Union for cross-version compatibility down to 3.9.
Outcome = tuple[str, Optional[Union[CheckResult, Exception]]]


def _sdk_version() -> str:
    # Lazy import to avoid a circular import at module load time.
    from niansys import __version__
    return __version__


def _sleep_backoff(attempt: int) -> None:
    """Sync backoff — isolated so tests can mock cheaply."""
    time.sleep(_BACKOFF_BASE_SECONDS * (2 ** attempt))


async def _asleep_backoff(attempt: int) -> None:
    """Async backoff — isolated so tests can mock cheaply."""
    await asyncio.sleep(_BACKOFF_BASE_SECONDS * (2 ** attempt))


class Guardian:
    """Main client. Same instance is used for both ``check`` and ``acheck``.

    Parameters
    ----------
    agent_key:
        The agent's API key (created from the NIANSYS dashboard). Required.
    base_url:
        URL of the NIANSYS cloud. Defaults to the public production cloud.
    mode:
        ``"observe"`` (default) or ``"control"`` (Phase 5+).
    fail_open:
        ``True`` (default) returns a permissive result when NIANSYS is
        unavailable. ``False`` raises ``NiansysNetworkError`` /
        ``NiansysServerError``.
    timeout:
        HTTP timeout in seconds. Defaults to ``5.0``.

    Examples
    --------
    Sync use::

        with Guardian(agent_key="iag_...") as guardian:
            result = guardian.check(action="send_email", target="ceo@acme.com")

    Async use::

        async with Guardian(agent_key="iag_...") as guardian:
            result = await guardian.acheck(action="run_sql", target="prod.users")

    Concurrent checks (the killer feature of async)::

        async with Guardian(agent_key="iag_...") as guardian:
            results = await asyncio.gather(*(
                guardian.acheck(action="send_email", target=addr)
                for addr in addresses
            ))
    """

    def __init__(
        self,
        agent_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        mode: str = "observe",
        fail_open: bool = True,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        if not agent_key:
            raise ValueError("agent_key is required")
        if mode not in ALLOWED_MODES:
            raise ValueError(
                f"mode must be one of {ALLOWED_MODES!r}, got {mode!r}"
            )
        if timeout <= 0:
            raise ValueError("timeout must be > 0")

        self.agent_key: str = agent_key
        self.base_url: str = base_url.rstrip("/")
        self.mode: str = mode
        self.fail_open: bool = fail_open
        self.timeout: float = timeout

        # Sync client — created eagerly. Connection pooling, headers set once.
        self._client: httpx.Client = httpx.Client(
            timeout=timeout,
            headers=self._default_headers(),
        )
        # Async client — lazy. Created on first acheck() call so that just
        # constructing a Guardian doesn't require an event loop.
        self._async_client: httpx.AsyncClient | None = None

    # ----------------------------------------------------------------------
    # Internals — shared between sync and async paths
    # ----------------------------------------------------------------------
    def _default_headers(self) -> dict[str, str]:
        return {
            "X-Agent-Key": self.agent_key,
            "User-Agent": f"niansys-python/{_sdk_version()}",
            "Accept": "application/json",
        }

    def _ensure_async_client(self) -> httpx.AsyncClient:
        """Get (and lazily create) the async httpx client."""
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(
                timeout=self.timeout,
                headers=self._default_headers(),
            )
        return self._async_client

    @staticmethod
    def _build_body(
        action: str,
        target: str | None,
        metadata: dict[str, Any] | None,
    ) -> dict[str, Any]:
        return {
            "action": action,
            "target": target,
            "metadata": metadata or {},
        }

    @property
    def _url(self) -> str:
        return f"{self.base_url}{_CHECK_PATH}"

    # ----------------------------------------------------------------------
    # Lifecycle
    # ----------------------------------------------------------------------
    def close(self) -> None:
        """Close the sync HTTP client. Use :meth:`aclose` if you've used acheck()."""
        self._client.close()

    async def aclose(self) -> None:
        """Close both the sync and the async HTTP clients."""
        self._client.close()
        if self._async_client is not None and not self._async_client.is_closed:
            await self._async_client.aclose()

    def __enter__(self) -> Guardian:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    async def __aenter__(self) -> Guardian:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()

    def __repr__(self) -> str:
        return (
            f"Guardian(mode={self.mode!r}, base_url={self.base_url!r}, "
            f"fail_open={self.fail_open})"
        )

    # ----------------------------------------------------------------------
    # Public API — sync
    # ----------------------------------------------------------------------
    def check(
        self,
        action: str,
        *,
        target: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CheckResult:
        """Synchronously send an agent action to NIANSYS and get a decision.

        See the class-level docstring for reliability semantics.

        Raises
        ------
        NiansysAuthError, NiansysValidationError, NiansysRateLimitError
            Always raised (4xx responses are never retried).
        NiansysServerError, NiansysNetworkError
            Raised only when ``fail_open=False``.
        """
        body = self._build_body(action, target, metadata)

        for attempt in range(_MAX_ATTEMPTS):
            is_last = attempt == _MAX_ATTEMPTS - 1
            try:
                response = self._client.post(self._url, json=body)
                outcome = _classify_response(
                    response, is_last_attempt=is_last, fail_open=self.fail_open
                )
            except httpx.RequestError as exc:
                outcome = _classify_network_error(
                    exc, is_last_attempt=is_last, fail_open=self.fail_open
                )

            kind, value = outcome
            if kind in (_SUCCESS, _PERMISSIVE):
                return value  # type: ignore[return-value]
            if kind == _RAISE:
                raise value  # type: ignore[misc]
            # kind == _RETRY
            _sleep_backoff(attempt)

        # Defensive — the loop above always returns or raises before exhausting.
        raise NiansysServerError(  # pragma: no cover
            "Retries exhausted without response"
        )

    # ----------------------------------------------------------------------
    # Public API — async
    # ----------------------------------------------------------------------
    async def acheck(
        self,
        action: str,
        *,
        target: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CheckResult:
        """Asynchronously send an agent action to NIANSYS and get a decision.

        Same semantics as :meth:`check`. Use this inside ``async def`` agent
        code, and use :func:`asyncio.gather` to run many checks in parallel.

        Raises
        ------
        Same as :meth:`check`.
        """
        body = self._build_body(action, target, metadata)
        async_client = self._ensure_async_client()

        for attempt in range(_MAX_ATTEMPTS):
            is_last = attempt == _MAX_ATTEMPTS - 1
            try:
                response = await async_client.post(self._url, json=body)
                outcome = _classify_response(
                    response, is_last_attempt=is_last, fail_open=self.fail_open
                )
            except httpx.RequestError as exc:
                outcome = _classify_network_error(
                    exc, is_last_attempt=is_last, fail_open=self.fail_open
                )

            kind, value = outcome
            if kind in (_SUCCESS, _PERMISSIVE):
                return value  # type: ignore[return-value]
            if kind == _RAISE:
                raise value  # type: ignore[misc]
            # kind == _RETRY
            await _asleep_backoff(attempt)

        raise NiansysServerError(  # pragma: no cover
            "Retries exhausted without response"
        )


# ==========================================================================
# Module-level classification helpers — shared by check() and acheck().
# Pure functions: no I/O, no sleep. They decide WHAT to do given a response
# or an exception, and the caller (sync or async) carries out the action.
# ==========================================================================
def _classify_response(
    response: httpx.Response,
    *,
    is_last_attempt: bool,
    fail_open: bool,
) -> Outcome:
    """Map an HTTP response to one of (_SUCCESS, _RETRY, _RAISE, _PERMISSIVE)."""
    status = response.status_code

    if status == 200:
        return (_SUCCESS, _parse_success(response))

    # 4xx — never retried; the developer must fix something.
    if status in (401, 403):
        return (_RAISE, NiansysAuthError(_extract_detail(response)))
    if status in (400, 422):
        return (_RAISE, NiansysValidationError(_extract_detail(response)))
    if status == 429:
        return (_RAISE, NiansysRateLimitError(_extract_detail(response)))

    # 5xx — retried with backoff.
    if 500 <= status < 600:
        if not is_last_attempt:
            return (_RETRY, None)
        if fail_open:
            return (
                _PERMISSIVE,
                _permissive_result(f"NIANSYS error {status} (fail-open)"),
            )
        return (
            _RAISE,
            NiansysServerError(f"HTTP {status}: {_extract_detail(response)}"),
        )

    # Anything else (1xx/3xx/unknown) — surface as a server error.
    return (
        _RAISE,
        NiansysServerError(
            f"Unexpected HTTP {status}: {_extract_detail(response)}"
        ),
    )


def _classify_network_error(
    exc: httpx.RequestError,
    *,
    is_last_attempt: bool,
    fail_open: bool,
) -> Outcome:
    """Map a transport-level exception to one of (_RETRY, _RAISE, _PERMISSIVE)."""
    if not is_last_attempt:
        return (_RETRY, None)
    if fail_open:
        return (
            _PERMISSIVE,
            _permissive_result("NIANSYS unreachable (fail-open)"),
        )
    return (
        _RAISE,
        NiansysNetworkError(
            f"Could not reach NIANSYS after {_MAX_ATTEMPTS} attempts: {exc}"
        ),
    )


def _parse_success(response: httpx.Response) -> CheckResult:
    try:
        data = response.json()
    except Exception as exc:
        raise NiansysServerError(
            f"NIANSYS returned 200 with non-JSON body: {response.text[:200]}"
        ) from exc
    return CheckResult(**data)


def _extract_detail(response: httpx.Response) -> str:
    """Best-effort extraction of a human-readable error message from a response."""
    try:
        data = response.json()
        if isinstance(data, dict) and "detail" in data:
            return str(data["detail"])
    except Exception:
        pass
    return response.text or f"HTTP {response.status_code}"


def _permissive_result(reason: str) -> CheckResult:
    """Result returned when ``fail_open=True`` and NIANSYS is unavailable."""
    return CheckResult(
        allowed=True,
        risk_score=0,
        risk_level="low",
        reason=reason,
        event_id=None,
    )
