"""NIANSYS — Monitoring & security SDK for autonomous AI agents.

Public API
----------
- :class:`Guardian` — main client.
- :class:`CheckResult` — result of a check call.
- Exception hierarchy (:class:`NiansysError` and subclasses).

Example
-------
>>> from niansys import Guardian
>>> guardian = Guardian(agent_key="ngk_...")
>>> result = guardian.check(action="send_email", target="ceo@acme.com")
>>> result.allowed
True
"""

from niansys.client import Guardian
from niansys.exceptions import (
    NiansysAuthError,
    NiansysError,
    NiansysNetworkError,
    NiansysRateLimitError,
    NiansysServerError,
    NiansysValidationError,
)
from niansys.models import CheckResult

__version__ = "0.1.0"

__all__ = [
    "Guardian",
    "CheckResult",
    "NiansysError",
    "NiansysAuthError",
    "NiansysNetworkError",
    "NiansysRateLimitError",
    "NiansysServerError",
    "NiansysValidationError",
    "__version__",
]
