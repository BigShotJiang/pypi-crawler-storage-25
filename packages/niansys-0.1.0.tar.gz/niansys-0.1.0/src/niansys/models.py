"""Pydantic models exposed by the NIANSYS SDK.

These are the data shapes a caller of the SDK sees. Internal request payloads
sent to the NIANSYS cloud may use additional private models, defined alongside
the client.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

RiskLevel = str  # "low" | "medium" | "high" | "critical"


class CheckResult(BaseModel):
    """Result of a :meth:`Guardian.check` or :meth:`Guardian.acheck` call.

    Attributes
    ----------
    allowed:
        Whether the action should be allowed. In ``observe`` mode this is
        always ``True``. In ``control`` mode it may be ``False``; the caller
        is responsible for honoring the decision.
    risk_score:
        Risk score on a 0–100 scale (0 = no risk, 100 = critical).
    risk_level:
        Human-readable level: ``"low"``, ``"medium"``, ``"high"``,
        ``"critical"``.
    reason:
        Short, human-readable explanation of the decision (matched rule,
        baseline drift, etc.). ``None`` for routine allowed events.
    event_id:
        Server-side event ID. Useful to cross-reference the event in the
        NIANSYS dashboard or in support tickets.
    """

    model_config = ConfigDict(extra="allow")

    allowed: bool = True
    risk_score: int = Field(default=0, ge=0, le=100)
    risk_level: RiskLevel = "low"
    reason: str | None = None
    event_id: str | None = None
