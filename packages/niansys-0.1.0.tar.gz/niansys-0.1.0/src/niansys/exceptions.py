"""Exception hierarchy for the NIANSYS SDK.

All exceptions raised by the SDK inherit from :class:`NiansysError`, so
callers can catch *all* SDK errors with a single ``except NiansysError``.
"""

from __future__ import annotations


class NiansysError(Exception):
    """Base exception for all NIANSYS SDK errors.

    Catch this to handle any SDK-raised error in one block.
    """


class NiansysNetworkError(NiansysError):
    """The SDK could not reach the NIANSYS cloud (timeout, DNS, connection reset).

    Only raised when ``Guardian(fail_open=False)``. When ``fail_open=True``
    (default), the SDK swallows the error and returns a permissive
    :class:`CheckResult` so the calling agent keeps running.
    """


class NiansysAuthError(NiansysError):
    """The agent key is missing, invalid, or revoked (HTTP 401 / 403)."""


class NiansysRateLimitError(NiansysError):
    """The NIANSYS cloud is rate-limiting this agent (HTTP 429)."""


class NiansysValidationError(NiansysError):
    """The event payload sent to NIANSYS is malformed (HTTP 400 / 422)."""


class NiansysServerError(NiansysError):
    """The NIANSYS cloud returned a 5xx error.

    The SDK retries 5xx responses internally a few times before raising.
    """
