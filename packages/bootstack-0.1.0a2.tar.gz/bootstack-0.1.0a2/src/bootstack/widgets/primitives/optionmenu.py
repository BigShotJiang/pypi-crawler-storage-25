from __future__ import annotations

from tkinter import StringVar
from typing import Any, Callable, Literal, Optional, TYPE_CHECKING, TypedDict

from typing_extensions import Unpack

from bootstack.widgets.composites.contextmenu import ContextMenu, ContextMenuItem
from bootstack.widgets.primitives.menubutton import MenuButton
from bootstack.widgets.mixins import configure_delegate
from bootstack.widgets.types import Master

if TYPE_CHECKING:
    from bootstack.core.signals import Signal


class OptionMenuKwargs(TypedDict, total=False):
    command: Optional[Callable[[], Any]]
    image: Any
    icon: Any
    icon_only: bool
    compound: Literal['text', 'image', 'top', 'bottom', 'left', 'right', 'center', 'none'] | str
    padding: Any
    width: int
    underline: int
    state: Literal['normal', 'active', 'disabled', 'readonly'] | str
    takefocus: Any
    style: str
    class_: str
    cursor: str
    default: Any
    name: str
    textvariable: Any
    textsignal: Signal[str]
    bootstyle: str  # DEPRECATED: Use accent and variant instead
    accent: str
    variant: str
    surface: str
    style_options: dict[str, Any]
    show_dropdown_button: bool
    dropdown_button_icon: str | dict


class OptionMenu(MenuButton):
    """A single-selection dropdown menu backed by a ContextMenu.

    Renders as a `MenuButton` with a chevron icon. Clicking the button opens
    a popup menu containing the provided options as radiobutton items. Selecting
    an item updates the displayed text and fires a `<<Change>>` event.

    !!! note "Events"
        - `<<Change>>`: Fired when the selected value changes.
          `event.data = {'value': Any}`
    """

    def __init__(
            self,
            master: Master = None,
            value: Any = None,
            options: list[Any] = None,
            **kwargs: Unpack[OptionMenuKwargs],
    ):
        """Create an OptionMenu backed by a ContextMenu.

        !!! note "Events"
            - `<<Change>>`: Fired when the selected value changes. `event.data = {'value': Any}`

        Args:
            master: Parent widget. If None, uses the default root window.
            value: Initial selected value.
            options (list): List of values to populate the menu.

        Other Parameters:
            command (Callable): Callback invoked when the value changes via menu selection.
            image (PhotoImage): Tk image to display.
            icon (str | dict): Bootstyle icon spec for the label content.
            icon_only (bool): Whether to reserve label padding when showing only an icon.
            compound (str): Placement of image relative to text.
            padding (int | tuple): Extra padding around the menubutton content.
            width (int): Width of the menubutton.
            underline (int): Index of underlined character in text.
            state (str): Widget state ('normal', 'active', 'disabled', 'readonly').
            takefocus (bool): Participation in focus traversal.
            style (str): Explicit ttk style name (overrides accent/variant).
            textvariable (Variable): Existing Tk variable to bind; new StringVar created if omitted.
            textsignal (Signal[str]): Signal bound to the textvariable.
            accent (str): Accent token for styling, e.g. 'primary', 'danger', 'success'.
            variant (str): Style variant, e.g. 'solid', 'outline'.
            bootstyle (str): DEPRECATED - Use `accent` and `variant` instead.
                Combined style tokens (e.g., 'primary-outline').
            surface (str): Surface token for style.
            style_options (dict): Dict forwarded to the style builder (e.g., icon_only, surface).
            show_dropdown_button (bool): Toggle visibility of the dropdown chevron.
            dropdown_button_icon (str | dict): Icon name for the chevron; defaults to 'caret-down-fill'.
        """
        style_options = kwargs.pop('style_options', {})
        style_options.update(
            self._capture_style_options(
                options=['icon_only', 'icon', 'show_dropdown_button', 'dropdown_button_icon'],
                source=kwargs
            )
        )

        self._bind_id = None
        self._menu_options = options if options is not None else []

        # Store the textvariable if provided, or create a new one
        self._textvariable = kwargs.pop('textvariable', None)
        if self._textvariable is None:
            self._textvariable = StringVar(value=str(value) if value is not None else "")

        super().__init__(master, text=value, **kwargs)

        # Configure the menubutton to use the textvariable
        self.configure(textvariable=self._textvariable)

        # Bind signal to change event
        self._bind_id = self._bind_change_event()

        # Create menu items that update the shared variable
        self._context_menu = self._build_context_menu()

        # Bind menu display to button events
        self.bind('<Button-1>', lambda _: self.show_menu(), add="+")
        self.bind('<Return>', lambda _: self.show_menu(), add="+")
        self.bind('<KP_Enter>', lambda _: self.show_menu(), add="+")

    def _bind_change_event(self):
        """(Re)bind textsignal to emit <<Change>> Tk events."""
        if self._bind_id is not None:
            self.textsignal.unsubscribe(self._bind_id)
        return self.textsignal.subscribe(lambda v: self.event_generate('<<Change>>', data={"value": v}))

    def _build_context_menu(self):
        # Affordance baked into the button image (focus ring + border line in
        # source-px); aligning the menu's left edge to it matches the visible
        # button border the same way the combobox popdown does.
        from bootstack.style.bootstyle_builder_base import BootstyleBuilderBase
        offset_x = BootstyleBuilderBase.scale_from_source(10)

        density = self.configure_style_options('density') or 'default'

        menu_items = [
            ContextMenuItem(
                type="radiobutton",
                text=str(item),
                variable=self._textvariable,
                value=str(item)
            )
            for item in self._menu_options
        ]
        return ContextMenu(
            self, target=self, items=menu_items,
            anchor="nw", attach="sw",
            offset=(offset_x, 0),
            density=density,
            # OptionMenu drives activation via `show_menu` (left-click,
            # Return/KP_Enter), not ContextMenu's auto-trigger.
            trigger=None,
        )

    def show_menu(self):
        """Show the dropdown menu unless disabled or readonly."""
        if not self.instate(("!disabled", "!readonly")):
            return
        # Match the menu's minimum width to the visible button width so the
        # dropdown never renders narrower than its trigger.
        from bootstack.style.bootstyle_builder_base import BootstyleBuilderBase
        affordance = BootstyleBuilderBase.scale_from_source(10)
        target_w = self.winfo_width() - 2 * affordance
        if target_w > 0:
            self._context_menu.configure(minwidth=max(150, target_w))
        self._context_menu.show()

    def get(self) -> str:
        """Return the current value."""
        return self._textvariable.get()

    def set(self, value: Any) -> None:
        """Set the current value (coerced to string)."""
        self._textvariable.set(str(value))

    @property
    def value(self) -> str:
        """Get or set the current value."""
        return self.get()

    @value.setter
    def value(self, value: Any) -> None:
        self.set(value)

    def on_changed(self, callback: Callable) -> str:
        """Bind to `<<Change>>`. Callback receives `event.data = {'value': Any}`."""
        return self.bind('<<Change>>', callback, add="+")

    def off_changed(self, bind_id: str | None = None) -> None:
        """Unbind from `<<Change>>`."""
        self.unbind('<<Change>>', bind_id)

    @configure_delegate('options')
    def _delegate_options(self, value=None):
        """Get or set the menu options list."""
        if value is None:
            return self._menu_options
        else:
            self._menu_options = value
            if self._context_menu:
                self._context_menu.destroy()
            self._context_menu = self._build_context_menu()
        return None

    @configure_delegate('value')
    def _delegate_value(self, value):
        """Get or set the current value."""
        if value is None:
            return self.value
        else:
            self.value = value
        return None

    @configure_delegate('textsignal')
    def _delegate_textsignal(self, value=None):
        """Get or set the textsignal binding."""
        if value is None:
            return super()._delegate_textsignal()
        else:
            super()._delegate_textsignal(value)
            self._bind_change_event()
        return None

    @configure_delegate('show_dropdown_button')
    def _delegate_show_dropdown_button(self, value=None):
        """Get or set visibility of the dropdown chevron."""
        if value is None:
            return self.configure_style_options('show_dropdown_button')
        else:
            self.configure_style_options(show_dropdown_button=value)
            return self.rebuild_style()

    @configure_delegate('dropdown_button_icon')
    def _delegate_dropdown_button_icon(self, value):
        """Get or set the dropdown chevron icon name."""
        if value is None:
            return self.configure_style_options('dropdown_button_icon')
        else:
            self.configure_style_options(dropdown_button_icon=value)
            return self.rebuild_style()

