from typing import Literal

from bootstack.widgets.primitives.radiobutton import RadioButton
from bootstack.widgets.types import Master


class RadioToggle(RadioButton):
    """bootstack wrapper for `ttk.Radiobutton` that renders with a toggle badge style."""

    def __init__(self, master: Master = None, **kwargs):
        """Create a themed bootstack RadioToggle.

        Args:
            master: Parent widget. If None, uses the default root window.

        Other Parameters:
            text (str): Text to display.
            textvariable (Variable): Tk variable linked to the text.
            textsignal (Signal[str]): Reactive Signal linked to the text (auto-synced with textvariable).
            command (Callable): Callable invoked when the value is selected.
            image (PhotoImage): Image to display.
            icon (str | dict): Theme-aware icon spec handled by the style system.
            icon_only (bool): Removes the additional padding added for label text.
            compound (str): Placement of the image relative to text.
            variable (Variable): Linked Tk variable that receives the selected value.
            signal (Signal): Reactive Signal that receives the selected value (auto-synced with variable).
            value (Any): The value assigned to `variable` when this radio is selected.
            padding (int | tuple): Extra space around the content.
            anchor (str): Determines how the content is aligned in the container. Combination of 'n', 's', 'e', 'w', or 'center' (default).
            density (str): The vertical and horizontal compactness of widget content, e.g. 'default', 'compact'.
            width (int): Width of the control in characters.
            underline (int): Index of character to underline in `text`.
            state (str): Widget state ('normal', 'active', 'disabled', 'readonly').
            takefocus (bool): Whether the widget participates in focus traversal.
            accent (str): Accent token for styling, e.g. 'primary', 'success', 'danger'.
            surface (str): Optional surface token; otherwise inherited.
            style_options (dict): Optional dict forwarded to the style builder.
            localize (bool | Literal['auto']): Determines the widget's localization mode.
        """
        self._capture_density_option(kwargs)
        kwargs.setdefault('ttk_class', 'Toolbutton')
        super().__init__(master, **kwargs)

    @staticmethod
    def _capture_density_option(kwargs: dict) -> None:
        """Capture density from kwargs into style_options."""
        density: Literal['default', 'compact'] | None = kwargs.pop('density', None)
        if density is not None:
            style_options = kwargs.setdefault('style_options', {})
            style_options['density'] = density
