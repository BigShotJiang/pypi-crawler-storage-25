from __future__ import annotations

from tkinter import ttk
from typing import Any, TypedDict
from typing_extensions import Unpack

from bootstack.core.mixins.ttk_state import TtkStateMixin
from bootstack.core.mixins.widget import WidgetCapabilitiesMixin
from bootstack.widgets.internal.wrapper_base import TTKWrapperBase
from bootstack.widgets.types import Master


class ScrollbarKwargs(TypedDict, total=False):
    # Standard ttk.Scrollbar options
    orient: Any
    command: Any
    takefocus: Any
    style: str
    class_: str
    cursor: str
    name: str

    # bootstack-specific extensions
    bootstyle: str  # DEPRECATED: Use accent and variant instead
    accent: str
    variant: str
    surface: str
    style_options: dict[str, Any]


class Scrollbar(TTKWrapperBase, WidgetCapabilitiesMixin, TtkStateMixin, ttk.Scrollbar):
    """bootstack wrapper for `ttk.Scrollbar` with bootstyle support."""

    _ttk_base = ttk.Scrollbar

    def __init__(self, master: Master = None, **kwargs: Unpack[ScrollbarKwargs]) -> None:
        """Create a themed bootstack Scrollbar.

        Args:
            master: Parent widget. If None, uses the default root window.

        Other Parameters:
            orient (str): Orientation of the scrollbar ('horizontal' or 'vertical').
            command (Callable): Scroll command callback.
            takefocus (bool): Whether the widget participates in focus traversal.
            style (str): Explicit ttk style name (overrides accent/variant).
            accent (str): Accent token for styling, e.g. 'primary', 'danger', 'success'.
            variant (str): Style variant, e.g. 'default', 'round', 'square'.
            bootstyle (str): DEPRECATED - Use `accent` and `variant` instead.
                Combined style tokens (e.g., 'primary', 'danger-square').
            surface (str): Optional surface token; otherwise inherited.
            style_options (dict): Optional dict forwarded to the style builder.
        """
        super().__init__(master, **kwargs)


