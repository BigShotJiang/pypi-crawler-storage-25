__version__ = "0.99.0"
__author__ = "ARX Security"
__email__ = "support@arx-security.ru"
__license__ = "MIT"
