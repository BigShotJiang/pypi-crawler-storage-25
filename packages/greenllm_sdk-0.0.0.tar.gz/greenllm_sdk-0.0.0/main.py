def main():
    print("Hello from greenllm-sdk!")


if __name__ == "__main__":
    main()
