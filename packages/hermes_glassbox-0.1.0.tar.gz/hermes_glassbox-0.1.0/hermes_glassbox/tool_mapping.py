"""Mapping built-in Hermes → Glassbox action_type.

Verbatim de la spec §7 :

    write_file    → file_write
    edit_file     → file_write
    delete_file   → file_delete
    bash          → shell_command
    python        → code_execution
    web_fetch     → network_read
    http_request  → network_read si GET, network_write sinon
    send_telegram → external_message
    *             → tool_call_unknown (fallback safe)

Pour les tools custom (MCP `stripe-pay`, plugin maison) le fallback enveloppe
les args bruts dans `descriptor.raw` (tronqué 500 chars). JM peut pousser des
`metadata.*` custom utilisables dans ses règles d'autonomie.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from glassbox_sdk import Descriptor

ToolMapper = Callable[[dict[str, Any]], Descriptor]


def _map_write_file(args: dict[str, Any]) -> Descriptor:
    path = args.get("path", "")
    content = args.get("content", "")
    size: int | None = None
    if isinstance(content, str):
        size = len(content)
    elif isinstance(content, bytes):
        size = len(content)
    return Descriptor.file_write(path=path, size=size)


def _map_edit_file(args: dict[str, Any]) -> Descriptor:
    return Descriptor.file_write(path=args.get("path", ""))


def _map_delete_file(args: dict[str, Any]) -> Descriptor:
    return Descriptor.file_delete(path=args.get("path", ""))


def _map_bash(args: dict[str, Any]) -> Descriptor:
    return Descriptor.shell_command(command=args.get("command", ""))


def _map_python(args: dict[str, Any]) -> Descriptor:
    snippet = str(args.get("code", ""))[:500]
    return Descriptor(action_type="code_execution", descriptor={"snippet": snippet})


def _map_web_fetch(args: dict[str, Any]) -> Descriptor:
    return Descriptor.network_read(url=args.get("url", ""), method=args.get("method", "GET"))


def _map_http_request(args: dict[str, Any]) -> Descriptor:
    method = args.get("method", "GET").upper()
    url = args.get("url", "")
    if method == "GET":
        return Descriptor.network_read(url=url, method=method)
    return Descriptor.network_write(url=url, method=method)


def _map_send_telegram(args: dict[str, Any]) -> Descriptor:
    return Descriptor.external_message(
        recipient=args.get("recipient", "?"),
        excerpt=args.get("text") or args.get("message"),
    )


HERMES_TOOL_MAPPINGS: dict[str, ToolMapper] = {
    "write_file": _map_write_file,
    "edit_file": _map_edit_file,
    "delete_file": _map_delete_file,
    "bash": _map_bash,
    "python": _map_python,
    "web_fetch": _map_web_fetch,
    "http_request": _map_http_request,
    "send_telegram": _map_send_telegram,
}


def _fallback_unknown(tool_name: str, args: dict[str, Any]) -> Descriptor:
    raw = str(args)[:500]
    return Descriptor(
        action_type="tool_call_unknown",
        descriptor={"tool": tool_name, "raw": raw},
    )


def map_tool_to_descriptor(tool_name: str, args: dict[str, Any]) -> Descriptor:
    """Convertit (tool_name, args) Hermes en Descriptor Glassbox.

    Tools inconnus → fallback safe `tool_call_unknown` avec `raw` tronqué.
    """
    mapper = HERMES_TOOL_MAPPINGS.get(tool_name)
    if mapper is None:
        return _fallback_unknown(tool_name, args)
    return mapper(args)
