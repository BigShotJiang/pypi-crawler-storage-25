"""CLI hermes-glassbox — utilitaires pour vérifier la config + tester l'install.

Disponible :
  - en standalone : `hermes-glassbox status / test / panic on/off`
  - en sous-commande Hermes (à confirmer) : `hermes glassbox status / ...`

Note V0 — le toggle `panic` réel se fait via la PWA (auth session user).
La CLI plugin agit avec un token Bearer (auth agent) qui n'a PAS le droit de
toggle panic. La CLI affiche donc juste les instructions pour le faire côté PWA
ou via curl avec une cookie session.
"""

from __future__ import annotations

import argparse
import sys
import uuid

from glassbox_sdk import Client, Descriptor
from glassbox_sdk.exceptions import GlassboxError


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hermes-glassbox",
        description="Utilitaires Glassbox côté plugin Hermes.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status", help="Connectivité + token + agent_name + panic_mode")
    sub.add_parser("test", help="Smoke test event bout en bout")
    p_panic = sub.add_parser("panic", help="Voir les instructions pour le mode panique")
    p_panic.add_argument("action", choices=["on", "off"])
    return parser


def run_status(client: Client) -> int:
    try:
        cfg = client.fetch_config()
    except GlassboxError as e:
        print(f"[KO] Erreur Glassbox : {e}", file=sys.stderr)
        return 1
    print(f"[OK] api_url={client._config.api_url}")
    print(f"     agent_name={client._config.agent_name}")
    print(f"     fail_mode={client._config.fail_mode}")
    print(f"     config.version={cfg.version}")
    print(f"     panic_mode={cfg.settings.panic_mode}")
    print(f"     preflight_timeout_seconds={cfg.settings.preflight_timeout_seconds}")
    print(f"     rules count={len(cfg.rules)}")
    return 0


def run_test(client: Client) -> int:
    try:
        event_id = client.push_event(
            external_id=f"hermes-glassbox-cli-{uuid.uuid4()}",
            source="hermes-plugin",
            type="cli_test",
            descriptor=Descriptor(action_type="cli_test", descriptor={"hello": "world"}),
        )
    except GlassboxError as e:
        print(f"[KO] Push event échoué : {e}", file=sys.stderr)
        return 1
    print(f"[OK] Event poussé id={event_id} — vérifier dans la PWA Glassbox.")
    return 0


def run_panic(client: Client, action: str) -> int:
    """V0 : pas de toggle direct côté plugin (auth Bearer != session user)."""
    print(f"Pour activer/désactiver le mode panique ({action}) :")
    print("  1. Ouvre la PWA Glassbox -> Dashboard -> bouton 'Mode panique'")
    print("  2. Ou via curl avec ta cookie session :")
    print(
        f"     curl -X POST {client._config.api_url}/api/organization-settings/panic "
        '-H "Cookie: better-auth.session_token=..." '
        f"-d '{{\"enabled\":{'true' if action == 'on' else 'false'}}}'"
    )
    print("La propagation au plugin prend < 60s (cache config TTL).")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        client = Client.from_env()
    except Exception as e:
        print(f"[KO] Config invalide : {e}", file=sys.stderr)
        return 2
    if args.cmd == "status":
        return run_status(client)
    if args.cmd == "test":
        return run_test(client)
    if args.cmd == "panic":
        return run_panic(client, args.action)
    return 1


if __name__ == "__main__":
    sys.exit(main())
