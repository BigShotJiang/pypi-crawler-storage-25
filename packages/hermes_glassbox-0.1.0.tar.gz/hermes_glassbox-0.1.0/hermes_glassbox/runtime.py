"""Singleton SDK Client wired depuis l'env Hermes.

Le SDK Client est instancié 1x par process Hermes au moment de l'init du plugin
(entry_point), puis partagé par tous les hooks. Stateful pour le cache TTL.
"""

from __future__ import annotations

from glassbox_sdk import Client
from glassbox_sdk.exceptions import GlassboxConfigError

_client: Client | None = None


def get_or_create_client() -> Client | None:
    """Retourne le Client caché. None si la config n'est pas valide.

    Si la config n'est pas dispo (ex : utilisateur n'a pas encore exporté
    GLASSBOX_API_TOKEN), on N'écrit pas dans stderr de manière intrusive — on
    renvoie None et le entry_point logue 1x un warning au démarrage.
    """
    global _client
    if _client is not None:
        return _client
    try:
        _client = Client.from_env()
    except GlassboxConfigError:
        _client = None
    return _client


def reset_client_for_tests() -> None:
    """Réinitialise le singleton (uniquement pour pytest)."""
    global _client
    _client = None
