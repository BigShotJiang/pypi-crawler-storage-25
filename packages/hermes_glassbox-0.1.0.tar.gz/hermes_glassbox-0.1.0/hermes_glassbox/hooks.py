"""Bind les hooks lifecycle Hermes au SDK Glassbox.

Compatibilité Hermes : ce module utilise un pattern d'enregistrement via
`ctx.on(<event>)` comme décorateur. Si l'API réelle Hermes diffère (ex :
sous-classe AIAgent, registry, async middleware), adapter ce module selon
la documentation officielle et le fallback monkey-patch documenté ci-dessous.

Hooks enregistrés :
  pre_tool_use(tool_name, args)        → Pre-flight bloquant, retourne allow/deny
  post_tool_use(tool_name, args, result, duration_ms)  → Push event fire-and-forget
  on_message_received(message, channel)
  on_message_sent(message, channel)
  on_session_start() / on_session_end()
  on_error(error, context)

Si Hermes V0.14+ change la signature, ajuster ce module + tests.
"""

from __future__ import annotations

import uuid
from typing import Any

from glassbox_sdk import Client, Descriptor

from hermes_glassbox.tool_mapping import map_tool_to_descriptor


def register_hooks(client: Client, hermes_context: Any) -> None:
    """Enregistre tous les hooks Glassbox sur l'instance Hermes.

    Appelé depuis `__init__.init()` au démarrage. `hermes_context` est l'objet
    passé par Hermes via entry_points (cf. B.5).
    """
    _bind_pre_tool_use(client, hermes_context)
    _bind_post_tool_use(client, hermes_context)
    _bind_messages(client, hermes_context)
    _bind_sessions(client, hermes_context)
    _bind_errors(client, hermes_context)


# --- Pre-tool — bloquant, retourne allow/deny ---


def _bind_pre_tool_use(client: Client, ctx: Any) -> None:
    @ctx.on("pre_tool_use")
    def _pre(tool_name: str, args: dict[str, Any]) -> Any:
        # Mode panique propagé < 60s via fetch_config (cache TTL).
        try:
            cfg = client.fetch_config()
            if cfg.settings.panic_mode:
                # Tout require_approval — le serveur applique panic_mode en POST /preflight.
                pass
        except Exception:
            pass  # failsafe géré par le client
        descriptor = map_tool_to_descriptor(tool_name, args)
        decision = client.preflight(
            descriptor=descriptor,
            client_request_id=str(uuid.uuid4()),
            wait=True,
        )
        if decision.is_approved:
            return ctx.tool_use_result.allow()
        return ctx.tool_use_result.deny(reason=decision.reason or "Action refusée par Glassbox")


# --- Post-tool — fire-and-forget event timeline ---


def _bind_post_tool_use(client: Client, ctx: Any) -> None:
    @ctx.on("post_tool_use")
    def _post(tool_name: str, args: dict[str, Any], result: Any, duration_ms: int) -> None:
        descriptor = map_tool_to_descriptor(tool_name, args)
        try:
            client.push_event(
                external_id=f"hermes-evt-{uuid.uuid4()}",
                source="hermes-plugin",
                type="tool_use",
                descriptor=descriptor,
                duration_ms=duration_ms,
            )
        except Exception:
            # Fire-and-forget — on swallow tout ce qui n'est pas auth.
            pass


# --- Messages (Telegram, Slack, Discord...) ---


def _bind_messages(client: Client, ctx: Any) -> None:
    @ctx.on("on_message_received")
    def _recv(message: Any, channel: str) -> None:
        try:
            client.push_event(
                external_id=f"hermes-msg-recv-{uuid.uuid4()}",
                source="hermes-plugin",
                type="message_received",
                descriptor=Descriptor(
                    action_type="message_received",
                    descriptor={"channel": channel, "excerpt": str(message)[:500]},
                ),
            )
        except Exception:
            pass

    @ctx.on("on_message_sent")
    def _sent(message: Any, channel: str) -> None:
        try:
            client.push_event(
                external_id=f"hermes-msg-sent-{uuid.uuid4()}",
                source="hermes-plugin",
                type="message_sent",
                descriptor=Descriptor(
                    action_type="message_sent",
                    descriptor={"channel": channel, "excerpt": str(message)[:500]},
                ),
            )
        except Exception:
            pass


def _bind_sessions(client: Client, ctx: Any) -> None:
    @ctx.on("on_session_start")
    def _start() -> None:
        try:
            client.push_event(
                external_id=f"hermes-sess-start-{uuid.uuid4()}",
                source="hermes-plugin",
                type="session_start",
                descriptor=Descriptor(action_type="session_start"),
            )
        except Exception:
            pass

    @ctx.on("on_session_end")
    def _end() -> None:
        try:
            client.push_event(
                external_id=f"hermes-sess-end-{uuid.uuid4()}",
                source="hermes-plugin",
                type="session_end",
                descriptor=Descriptor(action_type="session_end"),
            )
        except Exception:
            pass


def _bind_errors(client: Client, ctx: Any) -> None:
    @ctx.on("on_error")
    def _err(error: Exception, context: dict[str, Any] | None) -> None:
        try:
            client.push_event(
                external_id=f"hermes-err-{uuid.uuid4()}",
                source="hermes-plugin",
                type="error",
                descriptor=Descriptor(
                    action_type="error",
                    descriptor={
                        "kind": type(error).__name__,
                        "message": str(error)[:500],
                        "context": context or {},
                    },
                ),
            )
        except Exception:
            pass
