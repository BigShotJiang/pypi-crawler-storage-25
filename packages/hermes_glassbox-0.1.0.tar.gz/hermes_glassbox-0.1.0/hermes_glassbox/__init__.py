"""Adaptateur Hermes <> Glassbox.

Auto-discovered par Hermes via entry_points hermes.plugins.glassbox.

Au démarrage de Hermes, init(context) est appelé. On instancie le SDK Client
depuis l'env (GLASSBOX_API_URL, GLASSBOX_API_TOKEN, GLASSBOX_AGENT_NAME) et on
binde tous les hooks lifecycle Hermes.

Si la config est invalide (token manquant), on logge 1x un warning et on
n'enregistre AUCUN hook — le mode "désactivé" est silencieux pour ne pas casser
l'expérience utilisateur Hermes.
"""

from __future__ import annotations

import sys
from typing import Any

from hermes_glassbox.hooks import register_hooks
from hermes_glassbox.runtime import get_or_create_client

__version__ = "0.1.0"


def init(context: Any | None = None) -> None:
    """Entry point appelé par Hermes au démarrage du plugin."""
    client = get_or_create_client()
    if client is None:
        print(
            "[hermes-glassbox] WARNING : config invalide (GLASSBOX_API_URL / "
            "GLASSBOX_API_TOKEN manquants). Plugin DÉSACTIVÉ.",
            file=sys.stderr,
        )
        return
    if context is None:
        # Hermes n'a pas passé de context — fallback monkey-patch (cf. hooks.py).
        print(
            "[hermes-glassbox] WARNING : context Hermes absent. Monkey-patch "
            "à activer (cf. hooks.py).",
            file=sys.stderr,
        )
        return
    register_hooks(client, context)
    print(
        f"[hermes-glassbox] OK : connecté à {client._config.api_url} "
        f"agent={client._config.agent_name}",
        file=sys.stderr,
    )


__all__ = ["__version__", "init"]
