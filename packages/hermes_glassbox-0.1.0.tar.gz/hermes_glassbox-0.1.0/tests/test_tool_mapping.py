"""Tests du mapping built-in Hermes → Glassbox."""

from hermes_glassbox.tool_mapping import map_tool_to_descriptor


def test_write_file_to_file_write():
    desc = map_tool_to_descriptor("write_file", {"path": "x.md", "content": "hi"})
    assert desc.action_type == "file_write"
    assert desc.descriptor["path"] == "x.md"


def test_write_file_extracts_size_from_content():
    desc = map_tool_to_descriptor("write_file", {"path": "x.md", "content": "hello"})
    assert desc.descriptor["size"] == 5  # len("hello")


def test_edit_file_to_file_write():
    desc = map_tool_to_descriptor("edit_file", {"path": "x.md", "diff": "+foo"})
    assert desc.action_type == "file_write"


def test_delete_file_to_file_delete():
    desc = map_tool_to_descriptor("delete_file", {"path": "x.md"})
    assert desc.action_type == "file_delete"


def test_bash_to_shell_command():
    desc = map_tool_to_descriptor("bash", {"command": "ls -la"})
    assert desc.action_type == "shell_command"
    assert desc.descriptor["command"] == "ls -la"


def test_python_to_code_execution():
    desc = map_tool_to_descriptor("python", {"code": "print(1)"})
    assert desc.action_type == "code_execution"


def test_web_fetch_to_network_read():
    desc = map_tool_to_descriptor("web_fetch", {"url": "https://x.com"})
    assert desc.action_type == "network_read"


def test_http_request_get_to_network_read():
    desc = map_tool_to_descriptor("http_request", {"url": "https://x.com", "method": "GET"})
    assert desc.action_type == "network_read"


def test_http_request_post_to_network_write():
    desc = map_tool_to_descriptor("http_request", {"url": "https://x.com", "method": "POST"})
    assert desc.action_type == "network_write"


def test_send_telegram_to_external_message():
    desc = map_tool_to_descriptor("send_telegram", {"recipient": "@jm", "text": "Salut"})
    assert desc.action_type == "external_message"
    assert desc.descriptor["recipient"] == "@jm"
    assert desc.descriptor["excerpt"] == "Salut"


def test_unknown_tool_falls_back_to_tool_call_unknown():
    desc = map_tool_to_descriptor("stripe-pay", {"amount": 1000, "currency": "USD"})
    assert desc.action_type == "tool_call_unknown"
    assert "stripe-pay" in desc.descriptor.get("tool", "")
    # Le payload brut est conservé tronqué pour audit.
    assert "raw" in desc.descriptor


def test_truncates_raw_payload_to_500_chars():
    big = {"data": "x" * 1000}
    desc = map_tool_to_descriptor("custom-tool", big)
    assert len(desc.descriptor["raw"]) <= 500
