"""Fixtures pytest partagées pour hermes-glassbox."""
