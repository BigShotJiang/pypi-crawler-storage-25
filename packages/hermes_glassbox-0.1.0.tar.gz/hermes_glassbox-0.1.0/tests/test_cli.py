"""Tests CLI hermes-glassbox."""

from __future__ import annotations

from unittest.mock import MagicMock

from hermes_glassbox.cli import _build_parser, run_panic, run_status, run_test


def test_parser_accepts_status() -> None:
    parser = _build_parser()
    args = parser.parse_args(["status"])
    assert args.cmd == "status"


def test_parser_accepts_test() -> None:
    parser = _build_parser()
    args = parser.parse_args(["test"])
    assert args.cmd == "test"


def test_parser_accepts_panic_on() -> None:
    parser = _build_parser()
    args = parser.parse_args(["panic", "on"])
    assert args.cmd == "panic"
    assert args.action == "on"


def test_parser_accepts_panic_off() -> None:
    parser = _build_parser()
    args = parser.parse_args(["panic", "off"])
    assert args.cmd == "panic"
    assert args.action == "off"


def test_run_status_calls_fetch_config(capsys) -> None:  # type: ignore[no-untyped-def]
    client = MagicMock()
    client.fetch_config.return_value.version = "abc123"
    client.fetch_config.return_value.settings.panic_mode = False
    client.fetch_config.return_value.settings.preflight_timeout_seconds = 300
    client.fetch_config.return_value.rules = []
    client._config.api_url = "https://glassbox.test"
    client._config.agent_name = "Hermes-Test"
    client._config.fail_mode = "reject"

    run_status(client)
    out = capsys.readouterr().out
    assert "OK" in out
    assert "Hermes-Test" in out
    assert "panic_mode=False" in out


def test_run_test_pushes_event(capsys) -> None:  # type: ignore[no-untyped-def]
    client = MagicMock()
    client.push_event.return_value = "evt-1"
    run_test(client)
    out = capsys.readouterr().out
    assert "evt-1" in out
    client.push_event.assert_called_once()


def test_run_panic_on_warns_about_user_api(capsys) -> None:  # type: ignore[no-untyped-def]
    """V0 : la CLI affiche les instructions, le toggle réel passe par
    /api/organization-settings/panic (auth session user, pas Bearer agent)."""
    client = MagicMock()
    client._config.api_url = "https://glassbox.test"
    run_panic(client, "on")
    out = capsys.readouterr().out
    assert "PWA" in out or "session" in out
