"""Tests des hooks Hermes — mock du SDK Client + faux ctx Hermes."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest
from glassbox_sdk import Decision

from hermes_glassbox.hooks import register_hooks


class FakeContext:
    """Imite ctx.on(<event>) → décorateur qui stocke le handler."""

    def __init__(self) -> None:
        self.handlers: dict[str, Any] = {}
        self.tool_use_result = MagicMock()
        self.tool_use_result.allow.return_value = "ALLOW"
        self.tool_use_result.deny.return_value = "DENY"

    def on(self, event_name: str):  # type: ignore[no-untyped-def]
        def deco(fn: Any) -> Any:
            self.handlers[event_name] = fn
            return fn

        return deco


@pytest.fixture
def fake_ctx() -> FakeContext:
    return FakeContext()


@pytest.fixture
def mock_client() -> MagicMock:
    client = MagicMock()
    client.fetch_config.return_value.settings.panic_mode = False
    client.preflight.return_value = Decision(
        id="pf-1",
        status="approved",
        matched_rule_id=None,
        decided_by="user-1",
        expires_at=None,
        reason=None,
    )
    client.push_event.return_value = "evt-uuid-1"
    return client


def test_register_binds_all_lifecycle_events(mock_client: MagicMock, fake_ctx: FakeContext) -> None:
    register_hooks(mock_client, fake_ctx)
    expected = {
        "pre_tool_use",
        "post_tool_use",
        "on_message_received",
        "on_message_sent",
        "on_session_start",
        "on_session_end",
        "on_error",
    }
    assert expected.issubset(fake_ctx.handlers.keys())


def test_pre_tool_use_allow_when_approved(mock_client: MagicMock, fake_ctx: FakeContext) -> None:
    register_hooks(mock_client, fake_ctx)
    handler = fake_ctx.handlers["pre_tool_use"]
    result = handler("write_file", {"path": "x.md", "content": "hi"})
    assert result == "ALLOW"
    mock_client.preflight.assert_called_once()
    descriptor = mock_client.preflight.call_args.kwargs["descriptor"]
    assert descriptor.action_type == "file_write"
    assert descriptor.descriptor["path"] == "x.md"


def test_pre_tool_use_deny_when_rejected(mock_client: MagicMock, fake_ctx: FakeContext) -> None:
    mock_client.preflight.return_value = Decision(
        id="pf-1",
        status="rejected",
        matched_rule_id=None,
        decided_by="user-1",
        expires_at=None,
        reason="JM rejected",
    )
    register_hooks(mock_client, fake_ctx)
    handler = fake_ctx.handlers["pre_tool_use"]
    result = handler("bash", {"command": "rm -rf /"})
    assert result == "DENY"
    fake_ctx.tool_use_result.deny.assert_called_with(reason="JM rejected")


def test_post_tool_use_pushes_event_with_duration(
    mock_client: MagicMock, fake_ctx: FakeContext
) -> None:
    register_hooks(mock_client, fake_ctx)
    handler = fake_ctx.handlers["post_tool_use"]
    handler("write_file", {"path": "x.md"}, "result", 42)
    mock_client.push_event.assert_called_once()
    kwargs = mock_client.push_event.call_args.kwargs
    assert kwargs["duration_ms"] == 42
    assert kwargs["type"] == "tool_use"


def test_post_tool_use_swallows_exceptions(mock_client: MagicMock, fake_ctx: FakeContext) -> None:
    """Fire-and-forget : un ratage côté SDK ne doit JAMAIS planter Hermes."""
    mock_client.push_event.side_effect = RuntimeError("boom")
    register_hooks(mock_client, fake_ctx)
    handler = fake_ctx.handlers["post_tool_use"]
    handler("bash", {"command": "ls"}, "result", 10)  # ne lève pas


def test_on_session_start_pushes_marker(mock_client: MagicMock, fake_ctx: FakeContext) -> None:
    register_hooks(mock_client, fake_ctx)
    handler = fake_ctx.handlers["on_session_start"]
    handler()
    kwargs = mock_client.push_event.call_args.kwargs
    assert kwargs["type"] == "session_start"


def test_on_error_pushes_error_event(mock_client: MagicMock, fake_ctx: FakeContext) -> None:
    register_hooks(mock_client, fake_ctx)
    handler = fake_ctx.handlers["on_error"]
    handler(ValueError("oops"), {"step": "exec"})
    kwargs = mock_client.push_event.call_args.kwargs
    assert kwargs["type"] == "error"
    assert kwargs["descriptor"].descriptor["kind"] == "ValueError"
