"""
Tests for configsmith.
Run with: pytest tests/ -v
"""

import json
import os
import tempfile
from pathlib import Path

import pytest

from configsmith import ConfigSmith, ConfigError, Field
from configsmith.schema import ConfigValidationError


@pytest.fixture
def tmp(tmp_path):
    return tmp_path


def write(path, content):
    Path(path).write_text(content)
    return str(path)


# ── .env loading ──────────────────────────────────────────────────────────────

class TestEnvLoader:
    def test_basic_env(self, tmp):
        f = write(tmp / ".env", "PORT=8080\nDEBUG=true\n")
        c = ConfigSmith().load(f)
        assert c.get("PORT") == "8080"

    def test_ignores_comments(self, tmp):
        f = write(tmp / ".env", "# comment\nKEY=value\n")
        c = ConfigSmith().load(f)
        assert c.get("KEY") == "value"

    def test_strips_quotes(self, tmp):
        f = write(tmp / ".env", 'NAME="hello world"\n')
        c = ConfigSmith().load(f)
        assert c.get("NAME") == "hello world"

    def test_missing_file_raises(self):
        with pytest.raises(ConfigError):
            ConfigSmith().load("/nonexistent/.env")

    def test_optional_missing_file_ok(self):
        c = ConfigSmith().load("/nonexistent/.env", optional=True)
        assert c.as_dict() == {}


# ── JSON loading ──────────────────────────────────────────────────────────────

class TestJsonLoader:
    def test_basic_json(self, tmp):
        f = write(tmp / "cfg.json", '{"port": 9000, "name": "myapp"}')
        c = ConfigSmith().load(str(f))
        assert c.get("port") == 9000

    def test_invalid_json_raises(self, tmp):
        f = write(tmp / "bad.json", "{not valid json}")
        with pytest.raises(ConfigError):
            ConfigSmith().load(str(f))


# ── Dict loading ──────────────────────────────────────────────────────────────

class TestDictLoader:
    def test_load_dict(self):
        c = ConfigSmith().load_dict({"host": "localhost", "port": 5432})
        assert c.get("host") == "localhost"

    def test_dict_chaining(self):
        c = (ConfigSmith()
             .load_dict({"a": 1, "b": 2})
             .load_dict({"b": 99}))
        assert c.get("b") == 99  # later layer wins


# ── Fallback chains ───────────────────────────────────────────────────────────

class TestFallbackChain:
    def test_later_layer_wins(self):
        c = (ConfigSmith()
             .load_dict({"port": 8080})
             .load_dict({"port": 9090}))
        assert c.get("port") == 9090

    def test_fallback_to_earlier_layer(self):
        c = (ConfigSmith()
             .load_dict({"host": "localhost"})
             .load_dict({"port": 9090}))
        assert c.get("host") == "localhost"


# ── Env var overrides ─────────────────────────────────────────────────────────

class TestEnvVarOverride:
    def test_env_var_overrides_file(self, monkeypatch):
        monkeypatch.setenv("PORT", "9999")
        c = ConfigSmith(schema={"port": Field(int, default=8080)}).load_env()
        assert c.get("port") == 9999

    def test_env_prefix(self, monkeypatch):
        monkeypatch.setenv("APP_PORT", "1234")
        c = ConfigSmith(env_prefix="APP").load_env()
        assert c.get("PORT") == "1234"

    def test_field_env_var_override(self, monkeypatch):
        monkeypatch.setenv("MY_CUSTOM_PORT", "7777")
        c = ConfigSmith(schema={
            "port": Field(int, default=8080, env_var="MY_CUSTOM_PORT")
        }).load_dict({})
        assert c.get("port") == 7777


# ── Type casting ──────────────────────────────────────────────────────────────

class TestTypeCasting:
    def test_int_cast(self):
        c = ConfigSmith(schema={"port": Field(int)}).load_dict({"port": "8080"})
        assert c.get("port") == 8080
        assert isinstance(c.get("port"), int)

    def test_bool_true_values(self):
        for val in ("true", "1", "yes", "on", "True", "YES"):
            c = ConfigSmith(schema={"d": Field(bool)}).load_dict({"d": val})
            assert c.get("d") is True

    def test_bool_false_values(self):
        for val in ("false", "0", "no", "off", "False"):
            c = ConfigSmith(schema={"d": Field(bool)}).load_dict({"d": val})
            assert c.get("d") is False

    def test_list_csv(self):
        c = ConfigSmith(schema={"tags": Field(list)}).load_dict({"tags": "a,b,c"})
        assert c.get("tags") == ["a", "b", "c"]

    def test_list_json(self):
        c = ConfigSmith(schema={"tags": Field(list)}).load_dict({"tags": '["x","y"]'})
        assert c.get("tags") == ["x", "y"]

    def test_float_cast(self):
        c = ConfigSmith(schema={"rate": Field(float)}).load_dict({"rate": "3.14"})
        assert c.get("rate") == pytest.approx(3.14)


# ── Schema validation ─────────────────────────────────────────────────────────

class TestValidation:
    def test_required_field_missing_raises(self):
        c = ConfigSmith(schema={"key": Field(str)}).load_dict({})
        with pytest.raises(ConfigValidationError) as exc:
            c.validate()
        assert "key" in str(exc.value)

    def test_choices_validation(self):
        c = ConfigSmith(schema={
            "env": Field(str, choices=["dev", "prod"])
        }).load_dict({"env": "staging"})
        with pytest.raises(ConfigValidationError):
            c.validate()

    def test_choices_valid(self):
        c = ConfigSmith(schema={
            "env": Field(str, choices=["dev", "prod"])
        }).load_dict({"env": "prod"})
        c.validate()  # Should not raise

    def test_custom_validator(self):
        c = ConfigSmith(schema={
            "port": Field(int, validator=lambda v: 1024 <= v <= 65535)
        }).load_dict({"port": "80"})
        with pytest.raises(ConfigValidationError):
            c.validate()

    def test_default_applied(self):
        c = ConfigSmith(schema={"port": Field(int, default=8080)}).load_dict({})
        assert c.get("port") == 8080

    def test_multiple_errors_reported(self):
        c = ConfigSmith(schema={
            "a": Field(str),
            "b": Field(str),
        }).load_dict({})
        with pytest.raises(ConfigValidationError) as exc:
            c.validate()
        assert len(exc.value.errors) == 2


# ── Access patterns ───────────────────────────────────────────────────────────

class TestAccess:
    def test_get_with_default(self):
        c = ConfigSmith().load_dict({})
        assert c.get("missing", "fallback") == "fallback"

    def test_require_raises_on_missing(self):
        c = ConfigSmith().load_dict({})
        with pytest.raises(ConfigError):
            c.require("missing_key")

    def test_getitem(self):
        c = ConfigSmith().load_dict({"x": 1})
        assert c["x"] == 1

    def test_getitem_missing_raises(self):
        c = ConfigSmith().load_dict({})
        with pytest.raises(KeyError):
            _ = c["missing"]

    def test_contains(self):
        c = ConfigSmith().load_dict({"x": 1})
        assert "x" in c
        assert "y" not in c

    def test_as_dict(self):
        c = ConfigSmith().load_dict({"a": 1, "b": 2})
        d = c.as_dict()
        assert d == {"a": 1, "b": 2}
