"""
configsmith.core
----------------
Main ConfigSmith class — loads, merges, casts, and validates config.
"""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .loaders import (
    ConfigError, detect_and_load, load_env_vars,
    load_env_file, load_yaml_file, load_toml_file, load_json_file,
)
from .schema import Field, ConfigValidationError


class ConfigSmith:
    """
    Unified config loader with fallback chains, env overrides,
    type casting, and schema validation.

    Parameters
    ----------
    schema : dict, optional
        Mapping of key → Field(...) for validation and type casting.
    env_prefix : str, optional
        Only import env vars with this prefix (e.g. "APP" → APP_PORT).
    strict : bool
        If True, raise on unknown keys not in schema. Default: False.

    Examples
    --------
    >>> config = ConfigSmith(schema={
    ...     "port": Field(int, default=8080),
    ...     "debug": Field(bool, default=False),
    ...     "env": Field(str, choices=["dev", "prod"]),
    ... })
    >>> config.load("config.yaml").load_env()
    >>> port = config.get("port")   # 8080 (or overridden by PORT env var)
    """

    def __init__(
        self,
        schema: Optional[Dict[str, Field]] = None,
        env_prefix: str = "",
        strict: bool = False,
    ):
        self._schema: Dict[str, Field] = schema or {}
        self._env_prefix = env_prefix
        self._strict = strict
        self._layers: List[Dict[str, Any]] = []  # ordered low → high priority
        self._resolved: Optional[Dict[str, Any]] = None

    # ── Loading ───────────────────────────────────────────────────────────────

    def load(self, path: str, optional: bool = False) -> "ConfigSmith":
        """
        Load a config file (auto-detected by extension).

        Parameters
        ----------
        path : str
            Path to .env, .yaml, .yml, .toml, or .json file.
        optional : bool
            If True, silently skip missing files instead of raising.

        Returns self for chaining.
        """
        if optional and not Path(path).exists():
            return self
        try:
            data = detect_and_load(path)
            self._layers.append(data)
            self._resolved = None
        except ConfigError:
            if not optional:
                raise
        return self

    def load_env(self, prefix: str = "") -> "ConfigSmith":
        """
        Load environment variables as a high-priority layer.

        Parameters
        ----------
        prefix : str
            Override the instance-level env_prefix for this call.

        Returns self for chaining.
        """
        pfx = prefix or self._env_prefix
        data = load_env_vars(pfx)
        self._layers.append(data)
        self._resolved = None
        return self

    def load_dict(self, data: Dict[str, Any]) -> "ConfigSmith":
        """
        Load a plain dict as a config layer.

        Returns self for chaining.
        """
        self._layers.append(dict(data))
        self._resolved = None
        return self

    def chain(self, *paths: str, optional: bool = True) -> "ConfigSmith":
        """
        Load multiple files as a fallback chain (first = lowest priority).

        Example: config.chain(".env", "config.yaml", "config.local.yaml")

        Returns self for chaining.
        """
        for path in paths:
            self.load(path, optional=optional)
        return self

    # ── Resolution ────────────────────────────────────────────────────────────

    def _resolve(self) -> Dict[str, Any]:
        """Merge all layers (later layers win) and apply casting + defaults."""
        if self._resolved is not None:
            return self._resolved

        merged: Dict[str, Any] = {}
        for layer in self._layers:
            merged.update(layer)

        result: Dict[str, Any] = {}

        # Apply schema: cast types and inject defaults
        for key, field in self._schema.items():
            # Check env var override (explicit env_var name or uppercase key)
            env_key = field.env_var or key.upper()
            if env_key in os.environ:
                raw = os.environ[env_key]
            else:
                raw = merged.get(key, merged.get(key.upper()))

            if raw is None:
                if field.required:
                    continue  # Will be caught in validate()
                result[key] = field.default
            else:
                try:
                    result[key] = field.cast(raw)
                except (ValueError, TypeError) as e:
                    raise ConfigError(
                        f"Cannot cast '{key}' to {field.type_.__name__}: {e}"
                    )

        # Pass-through non-schema keys
        for key, value in merged.items():
            norm = key.lower()
            if norm not in result and key not in result:
                result[key] = value

        self._resolved = result
        return result

    # ── Validation ────────────────────────────────────────────────────────────

    def validate(self) -> "ConfigSmith":
        """
        Validate all values against the schema.
        Raises ConfigValidationError with all errors listed.

        Returns self for chaining.
        """
        data = self._resolve()
        errors: List[str] = []

        for key, field in self._schema.items():
            value = data.get(key)

            if value is None and field.required:
                desc = f" ({field.description})" if field.description else ""
                errors.append(f"'{key}' is required but missing{desc}")
                continue

            if value is not None:
                errors.extend(field.validate(key, value))

        if self._strict:
            schema_keys = {k.lower() for k in self._schema}
            for key in data:
                if key.lower() not in schema_keys:
                    errors.append(f"Unknown key '{key}' (strict mode)")

        if errors:
            raise ConfigValidationError(errors)

        return self

    # ── Access ────────────────────────────────────────────────────────────────

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value by key. Case-insensitive."""
        data = self._resolve()
        return data.get(key, data.get(key.upper(), data.get(key.lower(), default)))

    def require(self, key: str) -> Any:
        """Get a config value, raising ConfigError if missing."""
        value = self.get(key)
        if value is None:
            raise ConfigError(f"Required config key '{key}' is missing")
        return value

    def as_dict(self) -> Dict[str, Any]:
        """Return all resolved config values as a plain dict."""
        return dict(self._resolve())

    def __getitem__(self, key: str) -> Any:
        value = self.get(key)
        if value is None:
            raise KeyError(f"Config key '{key}' not found")
        return value

    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None

    def __repr__(self) -> str:
        try:
            data = self._resolve()
            keys = list(data.keys())
        except Exception:
            keys = []
        return f"<ConfigSmith layers={len(self._layers)} keys={keys}>"
