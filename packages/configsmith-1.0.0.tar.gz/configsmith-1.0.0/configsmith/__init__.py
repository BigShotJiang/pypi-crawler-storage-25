"""
configsmith — Unified config loader.
Reads .env, YAML, TOML, JSON with env overrides, type casting,
schema validation, and fallback chains.
"""

from .core import ConfigSmith, ConfigError, ConfigValidationError
from .schema import Field

__all__ = ["ConfigSmith", "ConfigError", "ConfigValidationError", "Field"]
__version__ = "1.0.0"
__author__ = "prabhay759"
