"""
configsmith.schema
------------------
Field descriptor for schema validation and type casting.
"""

import os
from typing import Any, Callable, List, Optional, Type, Union


class ConfigValidationError(Exception):
    """Raised when schema validation fails."""

    def __init__(self, errors: List[str]):
        self.errors = errors
        super().__init__("Config validation failed:\n" + "\n".join(f"  • {e}" for e in errors))


class Field:
    """
    Describes a single config key with type, default, and validation rules.

    Parameters
    ----------
    type_ : type
        Expected Python type. Supports: str, int, float, bool, list, dict.
    default : Any
        Default value if key is missing. Use Field.REQUIRED to make mandatory.
    description : str
        Human-readable description (shown in validation errors).
    choices : list, optional
        Allowed values. Raises error if value not in list.
    validator : callable, optional
        Custom callable(value) -> bool. Raises error if returns False.
    env_var : str, optional
        Override the env var name (default: uppercase key name).

    Examples
    --------
    >>> schema = {
    ...     "port": Field(int, default=8080),
    ...     "env":  Field(str, choices=["dev", "staging", "prod"]),
    ...     "tags": Field(list, default=[]),
    ...     "debug": Field(bool, default=False),
    ... }
    """

    REQUIRED = object()  # Sentinel for required fields

    def __init__(
        self,
        type_: Type = str,
        default: Any = REQUIRED,
        description: str = "",
        choices: Optional[List[Any]] = None,
        validator: Optional[Callable[[Any], bool]] = None,
        env_var: Optional[str] = None,
    ):
        self.type_ = type_
        self.default = default
        self.description = description
        self.choices = choices
        self.validator = validator
        self.env_var = env_var

    @property
    def required(self) -> bool:
        return self.default is Field.REQUIRED

    def cast(self, value: Any) -> Any:
        """Cast a raw string value to the field's type."""
        if value is None:
            return None
        if isinstance(value, self.type_):
            return value

        raw = str(value)

        if self.type_ == bool:
            return raw.lower() in ("1", "true", "yes", "on")

        if self.type_ == list:
            if raw.startswith("["):
                import json
                return json.loads(raw)
            return [item.strip() for item in raw.split(",") if item.strip()]

        if self.type_ == dict:
            import json
            return json.loads(raw)

        return self.type_(raw)

    def validate(self, key: str, value: Any) -> List[str]:
        """Return list of validation error strings (empty = valid)."""
        errors = []

        if self.choices and value not in self.choices:
            errors.append(
                f"'{key}' must be one of {self.choices}, got {value!r}"
            )

        if self.validator and not self.validator(value):
            errors.append(
                f"'{key}' failed custom validation (value={value!r})"
            )

        return errors
