"""
configsmith.loaders
-------------------
Loaders for each supported config format.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any


class ConfigError(Exception):
    """Raised for file/parse errors."""
    pass


def load_env_file(path: str) -> Dict[str, Any]:
    """Parse a .env file into a dict. Ignores comments and blank lines."""
    result = {}
    try:
        with open(path, "r") as f:
            for lineno, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                # Strip surrounding quotes
                if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                    value = value[1:-1]
                result[key] = value
    except FileNotFoundError:
        raise ConfigError(f".env file not found: {path}")
    except Exception as e:
        raise ConfigError(f"Error parsing .env file {path}: {e}")
    return result


def load_yaml_file(path: str) -> Dict[str, Any]:
    """Load a YAML file. Requires PyYAML."""
    try:
        import yaml
    except ImportError:
        raise ConfigError(
            "PyYAML is required to load YAML files. Install with: pip install pyyaml"
        )
    try:
        with open(path, "r") as f:
            data = yaml.safe_load(f) or {}
        if not isinstance(data, dict):
            raise ConfigError(f"YAML file must be a mapping at the top level: {path}")
        return data
    except FileNotFoundError:
        raise ConfigError(f"YAML file not found: {path}")
    except Exception as e:
        raise ConfigError(f"Error parsing YAML file {path}: {e}")


def load_toml_file(path: str) -> Dict[str, Any]:
    """Load a TOML file. Uses tomllib (stdlib 3.11+) or tomli."""
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib
        except ImportError:
            raise ConfigError(
                "A TOML library is required. On Python <3.11, install with: pip install tomli"
            )
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except FileNotFoundError:
        raise ConfigError(f"TOML file not found: {path}")
    except Exception as e:
        raise ConfigError(f"Error parsing TOML file {path}: {e}")


def load_json_file(path: str) -> Dict[str, Any]:
    """Load a JSON file."""
    try:
        with open(path, "r") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ConfigError(f"JSON file must be an object at the top level: {path}")
        return data
    except FileNotFoundError:
        raise ConfigError(f"JSON file not found: {path}")
    except json.JSONDecodeError as e:
        raise ConfigError(f"Error parsing JSON file {path}: {e}")


def load_env_vars(prefix: str = "") -> Dict[str, Any]:
    """Load environment variables, optionally filtered by prefix."""
    if prefix:
        result = {}
        prefix_upper = prefix.upper() + "_"
        for k, v in os.environ.items():
            if k.upper().startswith(prefix_upper):
                short_key = k[len(prefix_upper):]
                result[short_key] = v
        return result
    return dict(os.environ)


def detect_and_load(path: str) -> Dict[str, Any]:
    """Auto-detect file format from extension and load it."""
    ext = Path(path).suffix.lower()
    name = Path(path).name.lower()

    if name == ".env" or ext == ".env":
        return load_env_file(path)
    elif ext in (".yaml", ".yml"):
        return load_yaml_file(path)
    elif ext == ".toml":
        return load_toml_file(path)
    elif ext == ".json":
        return load_json_file(path)
    else:
        raise ConfigError(
            f"Unsupported file format: {path!r}. "
            "Supported: .env, .yaml, .yml, .toml, .json"
        )
