import networkx as nx
from pyvis.network import Network
import os



class NXUtils:
    @staticmethod
    def graphTransformer2nx(graph_transformer):
        """Convert a LLMGraphTransformer's graph_documents to a NetworkX graph."""
        G = nx.DiGraph()
        
        for doc in graph_transformer.graph_documents:
            for node in doc.nodes:
                G.add_node(node.id, label=node.label, type=node.type)
            for edge in doc.edges:
                G.add_edge(edge.source, edge.target, label=edge.label, type=edge.type)
        
        return G

    @staticmethod
    def graphACT2nx(act_res: dict, title_node_attrs: list = ("quote",), node_label_attr: str = None,
                    edge_label: str = None, edge_hover: list = None):
        """Convert an ACT-style result dict into a NetworkX DiGraph.

        - Uses each entry in `act_res['nodes']` as a node. The node `quote`
          field is used as the node `label`.
        - All keys from the node dict are attached as node attributes.
        - Edges are created from `act_res['edges']` using the `from` and `to`
          fields; remaining edge keys are attached as edge attributes.
        """
        G = nx.DiGraph()

        for node in act_res.get('nodes', []):
            nid = node.get('id')
            if nid is None:
                continue
            attrs = node.copy()

            # Use 'quote' as the visible label; keep 'quote' as an attribute as well
            if node_label_attr and node_label_attr in attrs:
                label = attrs[node_label_attr]
            else:
                label = attrs.get('quote') or attrs.get('label') or attrs.get('reference') or str(nid)
            
            title = ""
            for attr_key in title_node_attrs:
                if attr_key in attrs:
                    tmp = attrs[attr_key]
                    if title == "":
                        title = str(tmp)
                    else:
                        title = f"{title} | {str(tmp)}"
                    
            attrs['label'] = label
            attrs['group'] = attrs.get('type', 'default')
            attrs['title'] = title
            G.add_node(nid, **attrs)

        for edge in act_res.get('edges', []):
            src = edge.get('from')
            tgt = edge.get('to')
            if src is None or tgt is None:
                continue
            eattrs = edge.copy()
            eattrs.pop('from', None)
            eattrs.pop('to', None)
            if edge_label and edge_label in eattrs:
                eattrs['label'] = str(eattrs[edge_label])
            if edge_hover:
                parts = [str(eattrs[a]) for a in edge_hover if a in eattrs and eattrs[a] is not None]
                if parts:
                    eattrs['title'] = ' | '.join(parts)
            G.add_edge(src, tgt, **eattrs)

        return G
    
    @staticmethod
    def island_roots(G: nx.DiGraph):
        """
        For each weakly connected component (island) in the directed graph G, 
        find the "root" nodes that can reach all other nodes in that component.
        Returns:
        roots_by_island: list of dicts
            [
            {"island_nodes": {...}, "roots": [...]},
            ...
            ]
        flat_roots: all roots flattened
        """
        roots_by_island = []
        flat_roots = []

        for component in nx.weakly_connected_components(G):
            subgraph = G.subgraph(component)
            island_nodes = set(subgraph.nodes())
            roots = [node for node in subgraph.nodes() if nx.has_path(subgraph, node, list(island_nodes)[0])]
            roots_by_island.append({"island_nodes": island_nodes, "roots": roots})
            flat_roots.extend(roots)

        return roots_by_island, flat_roots
    
    @staticmethod
    def merge_graphs(graphs):
        """Merge multiple NetworkX graphs into one."""
        merged = nx.DiGraph()
        for g in graphs:
            merged = nx.compose(merged, g)
        return merged

    @staticmethod
    def visualize_graph(nxGraph, output_file: str, open_browser: bool = False, log_func=None,
                        show_legend: bool = False, legend_by: str = "group",
                        legend_mapping: dict = None, legend_position: str = "top-right",
                        legend_max_items: int = 50,
                        edge_label: str = None, edge_hover: list = None):
        """
        Visualize the NetworkX graph using pyvis.
        
        Parameters:
            nxGraph: The NetworkX graph to visualize
            output_file: Path to save the HTML visualization
            open_browser: Whether to open the visualization in a browser
        """
       
        if nxGraph is None:
            return
        
        # Create pyvis network
        net = Network(height="1200px", width="100%", directed=True,
                    notebook=False, bgcolor="#222222", font_color="white")
        
        # Compute a consistent color mapping for groups (so legend matches node colors)
        palette = [
            '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b',
            '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ]
        group_keys = []
        for _, nd in nxGraph.nodes(data=True):
            val = nd.get(legend_by) or nd.get('type') or nd.get('group')
            if val is not None and val not in group_keys:
                group_keys.append(val)

        # Build final group->color map: prefer explicit `legend_mapping`, then node `color`, then palette
        final_map = {}
        for i, k in enumerate(group_keys):
            if legend_mapping and k in legend_mapping:
                final_map[k] = legend_mapping[k]
                continue
            found_color = None
            for _, nd in nxGraph.nodes(data=True):
                val = nd.get(legend_by) or nd.get('type') or nd.get('group')
                if val == k:
                    c = nd.get('color')
                    if c:
                        # normalize dict colors to a hex string if necessary
                        if isinstance(c, dict):
                            found_color = c.get('background') or c.get('border') or str(c)
                        else:
                            found_color = str(c)
                        break
            if found_color:
                final_map[k] = found_color
            else:
                final_map[k] = palette[i % len(palette)]

        # Transfer nodes from NetworkX to pyvis
        for node_id, node_data in nxGraph.nodes(data=True):
            # Coerce title to string (pyvis expects iterable/string)
            raw_title = node_data.get('title', node_id)
            if isinstance(raw_title, str):
                safe_title = raw_title
            elif raw_title is None:
                safe_title = ""
            else:
                safe_title = str(raw_title)

            # determine group key and color (use explicit node color if provided)
            group_key = node_data.get(legend_by) or node_data.get('type') or node_data.get('group')
            raw_node_color = node_data.get('color')
            if raw_node_color:
                if isinstance(raw_node_color, dict):
                    color_hex = raw_node_color.get('background') or raw_node_color.get('border') or str(raw_node_color)
                else:
                    color_hex = str(raw_node_color)
            else:
                color_hex = final_map.get(group_key) if group_key in final_map else '#3498DB'

            # persist color on the NetworkX node so pyvis serializes it consistently
            try:
                nxGraph.nodes[node_id]['color'] = {'background': color_hex, 'border': color_hex}
                nxGraph.nodes[node_id]['color_hex'] = color_hex
            except Exception:
                pass

            node_params = {
                'label': node_data.get('label', node_id),
                'title': safe_title,
                'color': {'background': color_hex, 'border': color_hex},
                'group': node_data.get('group', 'default'),
                'size': node_data.get('size', 20)
            }
            # Only add shape if it's explicitly set (for attribute nodes)
            if 'shape' in node_data:
                node_params['shape'] = node_data['shape']
            
            net.add_node(node_id, **node_params)
        
        # Transfer edges from NetworkX to pyvis
        for source, target, edge_data in nxGraph.edges(data=True):
            label = edge_data.get(edge_label, '') if edge_label else edge_data.get('label', '')
            edge_params = {'label': label}
            if edge_hover:
                parts = [str(edge_data[a]) for a in edge_hover if a in edge_data and edge_data[a] is not None]
                if parts:
                    edge_params['title'] = ' | '.join(parts)
            elif 'title' in edge_data and edge_data['title'] is not None:
                edge_params['title'] = edge_data['title']
            net.add_edge(source, target, **edge_params)
        
        # Configure physics
        net.set_options("""
            {
                "physics": {
                    "forceAtlas2Based": {
                        "gravitationalConstant": -100,
                        "centralGravity": 0.01,
                        "springLength": 200,
                        "springConstant": 0.08
                    },
                    "minVelocity": 0.75,
                    "solver": "forceAtlas2Based"
                }
            }
            """)
        
        if output_file is not None:
            net.save_graph(f"{output_file}")

            # Optionally append JS that builds the legend client-side from vis's runtime colors
            legend_js = ""
            if show_legend:

                pos_map = {
                        'top-right': 'top:10px; right:10px;',
                        'top-left': 'top:10px; left:10px;',
                        'bottom-right': 'bottom:10px; right:10px;',
                        'bottom-left': 'bottom:10px; left:10px;'
                }
                pos_css = pos_map.get(legend_position, pos_map['top-right'])

                legend_js = f"""
                <script type="text/javascript">
                (function(){{
                    function buildLegend(){{
                        try{{
                            var nodesArr = network.body.data.nodes.get();
                            var groupMap = {{}};
                            nodesArr.forEach(function(n){{
                                var g = n.group || n.type || 'default';
                                var color = null;

                                // 1) explicit color on the serialized node
                                if(n.color){{
                                    if(typeof n.color === 'string') color = n.color;
                                    else color = n.color.background || n.color.border || null;
                                }}

                                // 2) vis runtime computed color on the internal node object
                                if(!color){{
                                    var runtime = network.body.nodes[n.id];
                                    if(runtime && runtime.options && runtime.options.color){{
                                        var rc = runtime.options.color;
                                        if(typeof rc === 'string') color = rc;
                                        else color = rc.background || rc.border || (rc.highlight && rc.highlight.background) || null;
                                    }}
                                }}

                                // 3) fallback: try to read from the data store again
                                if(!color){{
                                    var nd = network.body.data.nodes.get(n.id);
                                    if(nd && nd.color){{
                                        if(typeof nd.color === 'string') color = nd.color;
                                        else color = nd.color.background || nd.color.border || null;
                                    }}
                                }}

                                if(!groupMap[g]) groupMap[g] = color || null;
                            }});

                            var items = '';
                            Object.keys(groupMap).forEach(function(k){{
                                var c = groupMap[k] || '#888';
                                items += '<div class="nx-legend-item"><span class="nx-legend-swatch" style="background:'+c+'"></span><span class="nx-legend-label">'+k+'</span></div>';
                            }});

                            var container = document.createElement('div');
                            container.className = 'nx-legend';
                            container.innerHTML = '<style>.nx-legend{{position: fixed; {pos_css} z-index:9999; background: rgba(34,34,34,0.9); color: #fff; padding: 8px; border-radius: 6px; max-height: 40vh; overflow:auto; font-family: sans-serif; font-size: 13px;}} .nx-legend-item{{display:flex; align-items:center; margin:4px 0}} .nx-legend-swatch{{width:14px; height:14px; display:inline-block; margin-right:8px; border-radius:2px;}} .nx-legend-label{{white-space:nowrap}} .nx-legend-more{{margin-top:6px; opacity:0.8; font-size:12px}}</style>' + items;
                            document.body.appendChild(container);
                        }}catch(e){{console.error('legend build error', e);}}
                    }}
                    // delay to allow vis to compute final colors
                    setTimeout(buildLegend, 500);
                }})();
                </script>
                """

            recursive_js = """
                            <script type="text/javascript">
                            network.on("click", function (params) {
                                if (params.nodes.length > 0) {
                                    var rootNode = params.nodes[0];
                                    
                                    // Determine if we are expanding or collapsing based on the first child
                                    var children = network.getConnectedNodes(rootNode, 'to');
                                    if (children.length === 0) return;
                                    
                                    var isHidden = nodes.get(children[0]).hidden;
                                    var newState = !isHidden;

                                    // Recursive BFS to find all descendants
                                    var queue = [...children];
                                    var seen = new Set();
                                    var updates = [];

                                    while (queue.length > 0) {
                                        var curr = queue.shift();
                                        if (!seen.has(curr)) {
                                            seen.add(curr);
                                            updates.push({id: curr, hidden: newState});
                                            
                                            // Add children of current node to the queue
                                            var nextChildren = network.getConnectedNodes(curr, 'to');
                                            queue.push(...nextChildren);
                                        }
                                    }
                                    nodes.update(updates);
                                }
                            });
                            </script>
        """

            with open(output_file, 'a') as f:
                if legend_js:
                    f.write(legend_js)
                f.write(recursive_js)

            if log_func:
                log_func(f"Graph saved to {os.path.abspath(output_file)}")  
            
        
        # Try to open in browser
        if open_browser:
            try:
                import webbrowser
                if log_func:
                    log_func("Opening graph visualization in browser...")   
                tmp = f"{output_file}"
                webbrowser.open(f"file://{os.path.abspath(tmp)}")
            except:
                if log_func:
                    log_func("Could not open browser automatically", level="warning")


    @staticmethod
    def _visualize_graph(nxGraph, output_file: str, open_browser: bool = False, 
                    log_func=None, initial_collapsed_ids: list = None):
        if log_func:
            log_func(f"Generating visualization: {output_file}")

        # 1. Tag nodes that should be initially hidden
        if initial_collapsed_ids:
            for node_id in initial_collapsed_ids:
                if node_id in nxGraph:
                    # Find neighbors of the target node and hide THEM
                    for neighbor in nxGraph.neighbors(node_id):
                        nxGraph.nodes[neighbor]['hidden'] = True

        # 2. Setup Pyvis
        net = Network(height="750px", width="100%", notebook=False, directed=True)
        net.from_nx(nxGraph)
        
        # 3. Write the base HTML
        net.write_html(output_file)

        # 4. Inject JavaScript for Click-to-Expand/Collapse
        # We append a script that listens for clicks and toggles 'hidden'
        toggle_script = """
        <script type="text/javascript">
        network.on("click", function (params) {
            if (params.nodes.length > 0) {
                var nodeId = params.nodes[0];
                var connectedNodes = network.getConnectedNodes(nodeId);
                
                // Get current state of first neighbor to determine toggle direction
                var firstNeighbor = nodes.get(connectedNodes[0]);
                var isHidden = firstNeighbor ? firstNeighbor.hidden : false;
                
                // Update all neighbors to the opposite state
                var updates = connectedNodes.map(id => ({id: id, hidden: !isHidden}));
                nodes.update(updates);
            }
        });
        </script>
        """
        
        recursive_js = """
        <script type="text/javascript">
        network.on("click", function (params) {
            if (params.nodes.length > 0) {
                var rootNode = params.nodes[0];
                
                // Determine if we are expanding or collapsing based on the first child
                var children = network.getConnectedNodes(rootNode, 'to');
                if (children.length === 0) return;
                
                var isHidden = nodes.get(children[0]).hidden;
                var newState = !isHidden;

                // Recursive BFS to find all descendants
                var queue = [...children];
                var seen = new Set();
                var updates = [];

                while (queue.length > 0) {
                    var curr = queue.shift();
                    if (!seen.has(curr)) {
                        seen.add(curr);
                        updates.push({id: curr, hidden: newState});
                        
                        // Add children of current node to the queue
                        var nextChildren = network.getConnectedNodes(curr, 'to');
                        queue.push(...nextChildren);
                    }
                }
                nodes.update(updates);
            }
        });
        </script>
        """
        with open(output_file, 'a') as f:
            f.write(recursive_js)

        if open_browser:
            import webbrowser
            webbrowser.open('file://' + os.path.realpath(output_file))