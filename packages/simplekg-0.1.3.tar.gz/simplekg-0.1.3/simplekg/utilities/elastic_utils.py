import requests



class ElasticUtils():
    def __init__(self, host, user, password):
        self.host = host
        self.auth = (user, password)
        self.default_size = 20
        self.default_timeout = 20

    def get_location(self, index, location, size=None, timeout=None):
        query = {
                 "query": {
                    "match": {
                        "location": location
                            }
                        }
                }

        return self._elasticQuery(index, query, size=size, timeout=timeout)
    
    def get_categories(self, index, categories, size=None, timeout=None):
        query =  {
                "query": {
                    "match": {
                    "categories": categories
                    }
                }
                }
        
        return self._elasticQuery(index, query, size=size, timeout=timeout)


    def _elasticQuery(self, index, query, size= None, timeout=None):
        """
        a query to elasticsearch with parameters of host, auth, index, and query. 
        The query should be in the form of a dictionary that can be converted to JSON. 
        The function should return the response from the elasticsearch server.
        """

        if "size" not in query:
            if size is not None:
                query["size"] = size 
            else:
                query["size"] = self.default_size

        url = f"{self.host}/{index}/_search"
        headers = {"Content-Type": "application/json"}
        response = requests.post(url, 
                                 headers=headers, 
                                 json=query, 
                                 auth=self.auth, 
                                 timeout=timeout if timeout is not None else self.default_timeout)
        response.raise_for_status()
        return response.json()