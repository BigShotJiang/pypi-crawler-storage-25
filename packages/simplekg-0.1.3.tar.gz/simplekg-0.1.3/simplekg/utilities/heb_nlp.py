import requests
from io import StringIO
import pandas as pd


def pos_tags():

    tags ={"NNT": "Construct state Noun וועדת ,הרכבת הממשלה ,משלוח מנות",
               "NNP": "Proper noun, singular תאילנד ,צים ,דני",
               "NN": "Noun, singular וועדה ,מתנדבים",
               "JJ": "Adjective חזקים ,חכמה ,יפה",
               "JJT": "Construct state adjective חסרת רחמים",
               "VB": "Verb, base form אכלו,הלך",
               "RB": "Adverb בעוצמה ,מהר",
               "RBR":"Comparative Adverb פחות,יותר",
               "CD": "Cardinal Number עשר,231",
               "CDT": "Number in determiner position עשרות אנשים",
               "BN": " beinoni (participle)",
               "PREPOSITION": "B,CH,L,M and other words לפני ,ב",
               "DTT": "determiners and quantifiers כל",
               "CONJ": "establish a connection between two parts of a sentence ו החיבור",
               "DEF": "definition H hyedia ה",
               "AT": "Accusativity Marker את",
               "CC": "Coordinating Conjunction כי",
               "PRP": "Personal Pronoun אתם,הן,אני",
               "REL": "Relativizer אשר,ש",
               "MD": "Modal Verb אסור,רצוי ",
               "MOD": "Non-adverbialModification בדיוק,כמעט,גם",
               "IN": "Preposition לפני ,ב",
               "AUX": "Auxiliary verbs (past and future tenses) היה, תהיה",
               "AGR": " Copular-type agreement (present tense) הם,הן,היא,הוא",
               "POS": " Possessive של",
               "WDT": "Determiner Question Word כמה, איזו",
               "QW": "Question/WH Word למה,מה",
               "HAM": "The Y/N question word האם",
               "H": " H definite marker ה"
               }
    return tags


def morphological_disambiguation(text, host="localhost", port=8000, ret_format ="df"):
    '''
    Call YAP server for morphological disambiguation
    2. Send request
    3. Parse response to dataframe
    4. Return dataframe
    '''
    # Send request
    try:
        localhost_yap = "http://localhost:8000/yap/heb/joint"
    except Exception as e:
        return {"status": "error", "message": f"Error initializing YAP request: {e}"}
    data = '{{"text": "{}  "}}'.format(text).encode('utf-8')  # input string ends with two space characters
    headers = {'content-type': 'application/json'}
    max_retries = 3
    retries = 0
    while retries < max_retries:
        response = requests.get(url=localhost_yap, data=data, headers=headers)
        if response.status_code != 200:
            return {"status": "error", "message": f"YAP server error: {response.status_code}"}
        json_response = response.json()
        retries += 1
        if 'md_lattice' in json_response:
            retries = max_retries + 1

    if 'md_lattice' not in json_response:
        return {"status": "error", "message": "No 'md_lattice' in YAP response"}
   
    
   
    if ret_format == "json":
        return {"status": "success", "data": json_response}


    # Convert the results to dataframe
    
    try:
        tmp = StringIO(json_response['md_lattice'])
        tmp = StringIO(json_response['md_lattice'])
        df_tmp = pd.read_csv(tmp, sep="\t", header=None)
        df_tmp.columns = [1, 2, 'token', 'base_form', 'pos', 'pos2', 6, 'related_word']
    except Exception:
        df_tmp = ""
    return {"status": "success", "data": df_tmp}

def parse_tree(sentence:str, verbose:bool=False):
    import stanza

    # Check if "he" model is downloaded
    try:
        #stanza.download('he')
        nlp = stanza.Pipeline('he', processors='tokenize,pos,ner', logging_level='ERROR')
    except Exception as e:
        return {"status": "error", "message": f"Error initializing Stanza pipeline: {e}"}

    try:
        doc = nlp(sentence)
    except Exception as e:
        return {"status": "error", "message": f"Error processing sentence: {e}"}
    if verbose:
        #doc.sentences[0].print_dependencies()
        #print(doc.sentences[0].constituency)
        for sent in doc.sentences:
            sent.print_dependencies()

    return {"status": "success", "data": doc}