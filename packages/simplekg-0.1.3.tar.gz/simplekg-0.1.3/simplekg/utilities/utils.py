import nltk
import re, json, os
from collections import defaultdict
from openai import OpenAI
import numpy as np
from typing import List, Optional, Dict, Any, Iterable, Set
from pydantic import BaseModel

try:
    from ..models import Concept
except ImportError:
    from models import Concept



def _chunk_textOLD(text: str, max_chunk_size=500) -> list[str]:

    """
    Chunk text by sentence, respecting a maximum chunk size.
    Falls back to word-based chunking if a single sentence is too large.
    
    :param text: The text to chunk.
    :param max_chunk_size: The maximum length (in characters) of any chunk.
    :return: A list of text chunks.
    """
    # Step 1: Split text into sentences
    sentences = nltk.sent_tokenize(text)

    chunks = []
    current_chunk = ""

    for sentence in sentences:
        # If adding this sentence stays within the limit, append it.
        if len(current_chunk) + len(sentence) + 1 <= max_chunk_size:
            current_chunk += sentence + " "
        else:
            # If the current chunk has some content, push it and start a new one.
            if current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = ""

            # Check if the sentence itself is larger than the limit.
            # If yes, chunk it by words (fallback).
            if len(sentence) > max_chunk_size:
                words = sentence.split()
                temp_chunk = ""

                for word in words:
                    if len(temp_chunk) + len(word) + 1 <= max_chunk_size:
                        temp_chunk += word + " "
                    else:
                        chunks.append(temp_chunk.strip())
                        temp_chunk = word + " "

                # Add the leftover if any
                if temp_chunk:
                    chunks.append(temp_chunk.strip())
            else:
                # If the sentence is smaller than max_chunk_size, just start a new chunk with it.
                current_chunk = sentence + " "

    # If there's a leftover chunk that didn't get pushed, add it
    if current_chunk:
        chunks.append(current_chunk.strip())

    return chunks

import nltk
from typing import List

def chunk_text(text: str, max_chunk_size: int = 500, overlap_sentences: int = 2) -> List[str]:
    """
    Chunk text by sentences with a sliding window, allowing overlap between chunks.

    Parameters
    ----------
    text : str
        The text to chunk.
    max_chunk_size : int, optional
        Maximum length (in characters) of any chunk, by default 500.
    overlap_sentences : int, optional
        Number of sentences to overlap between consecutive chunks, by default 1.

    Returns
    -------
    List[str]
        A list of overlapping text chunks.
    """
    # Step 1: Split into sentences
    sentences = nltk.sent_tokenize(text)

    chunks = []
    start_idx = 0
    n = len(sentences)

    while start_idx < n:
        current_chunk = sentences[start_idx]
        end_idx = start_idx + 1

        # Grow the chunk with following sentences until we hit the size limit
        while end_idx < n:
            candidate = current_chunk + " " + sentences[end_idx]
            if len(candidate) <= max_chunk_size:
                current_chunk = candidate
                end_idx += 1
            else:
                break

        chunks.append(current_chunk.strip())

        if end_idx >= n:
            break

        # Move the window start forward, but keep some overlap
        # (ensure we don't go backwards)
        start_idx = max(end_idx - overlap_sentences, start_idx + 1)

    return chunks


def chunk_list(xs, n):
    for i in range(0, len(xs), n):
        yield xs[i:i+n]

def get_embeddings(texts: List[str], client, model="text-embedding-3-small") -> np.ndarray:
    """
    Generates embeddings for a list of sentences using OpenAI's API.
    
    Args:
        texts (List[str]): A list of (Hebrew) sentences.
        model (str): The model to use. 'text-embedding-3-small' is recommended 
                     for cost/performance balance. Use 'text-embedding-3-large' 
                     for higher precision.

    Returns:
        np.ndarray: A numpy array of embeddings (shape: [n_sentences, embedding_dim])
    """
    # Clean texts (remove newlines which can affect embeddings)
    texts = [text.replace("\n", " ") for text in texts]
    
    try:
        response = client.embeddings.create(
            input=texts,
            model=model
        )
        
        # Extract embeddings and ensure they differ by index
        # The API returns them in order, but we sort by index just to be safe
        data = sorted(response.data, key=lambda x: x.index)
        embeddings = [item.embedding for item in data]
        
        return np.array(embeddings)
        
    except Exception as e:
        print(f"An error occurred: {e}")
        return np.array([])

def compute_ontology_embeddings(ontology_relations, 
                                model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
                                filename=None):
    """
    Compute Ontology embeddings once and save them to file.
    example 
            skos_relations = {
            "skos:broader": "Indicates a more general concept",
            "skos:narrower": "Indicates a more specific concept",
            "skos:related": "Indicates an associative relationship",
            "skos:exactMatch": "Concepts are exactly equivalent",
            "skos:closeMatch": "Concepts are sufficiently similar but not identical",
            "skos:broadMatch": "Broader concept in another scheme",
            "skos:narrowMatch": "Narrower concept in another scheme",
            "skos:relatedMatch": "Associative relation in another scheme"
        }
           compute_ontology_embeddings(skos_relations, filename="full/path/skos_embeddings.npz")
    """
    import numpy as np
    from sentence_transformers import SentenceTransformer

    model = SentenceTransformer(model_name)
    skos_labels = list(ontology_relations.keys())
    skos_texts = [f"{k}: {v}" for k, v in ontology_relations.items()]

    embeddings = model.encode(skos_texts, convert_to_numpy=True, normalize_embeddings=True)

    if filename:
        np.savez(filename, embeddings=embeddings, labels=skos_labels, texts=skos_texts)
    else:
        return embeddings

def load_ontology_embeddings(filename):
    """
    Load ontology embeddings, labels, and texts from file.
    """
    import numpy as np
    data = np.load(filename, allow_pickle=True)
    embeddings = data["embeddings"]
    labels = data["labels"].tolist()
    texts = data["texts"].tolist()
    return embeddings, labels, texts

def is_english(text):
    """
    Check if the text contains English characters or numeric characters or non-alphanumeric characters.
    
    """
    import re
    # Check if the text contains any English letters (a-z, A-Z), digits (0-9), or non-alphanumeric characters
    return bool(re.search(r'[a-zA-Z0-9\W]', text))

#------ Visuzalize Clustering -----

def plot_dendrogram(model, save_path,**kwargs):
    # Create linkage matrix from sklearn model
    from scipy.cluster.hierarchy import dendrogram
    import matplotlib.pyplot as plt
    import numpy as np  

    counts = np.zeros(model.children_.shape[0])
    n_samples = len(model.labels_)

    for i, merge in enumerate(model.children_):
        current_count = 0
        for child in merge:
            if child < n_samples:
                current_count += 1
            else:
                current_count += counts[child - n_samples]
        counts[i] = current_count

    linkage_matrix = np.column_stack([
        model.children_,       # merges
        model.distances_,      # distances
        counts,                # number of samples in each merge
    ]).astype(float)

    # Plot the dendrogram
    dendrogram(linkage_matrix, **kwargs)
    plt.axhline(y=model.distance_threshold, c='red', lw=2, ls='--')
    plt.title('Hierarchical Clustering Dendrogram')
    plt.savefig(f"{save_path}/Clustering_dendrogram.png")
    


#------ Knowledge Graph To ACT Sequence/Graph------

class TanakhBQNormalizerOLD:
    """
    Normalize strings like:
        bq_leviticus_1_1
        bq_psalms_103_20
        bq_2_chronicles_36_16
        bq_Judges_13_6
    into:
        Tanakh_Torah_Leviticus__1_1
        Tanakh_Writings_Psalms__103_20
        Tanakh_Writings_II_Chronicles__36_16
        Tanakh_Prophets_Judges__13_6

    If a string does not match the expected format or the book is unknown,
    the original string is returned unchanged.
    """

    def __init__(
        self,
        *,
        books: Optional[List[str]] = None,
        sub_books: Optional[List[str]] = None,
        aliases: Optional[Dict[str, str]] = None,
    ):
        self.books = books or ['Tanakh', 'Prophets', 'Writings', 'Torah']

        self.sub_books = sub_books or [
            'Psalms', 'Genesis', 'Jeremiah', 'Isaiah', 'Numbers', 'Ezekiel', 'Exodus', 'Job',
            'Deuteronomy', 'I_Chronicles', 'Proverbs', 'Leviticus', 'II_Chronicles', 'I_Kings',
            'I_Samuel', 'II_Kings', 'II_Samuel', 'Joshua', 'Judges', 'Nehemiah', 'Daniel', 'Ezra',
            'Ecclesiastes', 'Zechariah', 'Hosea', 'Esther', 'Lamentations', 'Amos', 'Song_of_Songs',
            'Micah', 'Ruth', 'Joel', 'Habakkuk', 'Malachi', 'Zephaniah', 'Jonah', 'Nahum', 'Haggai',
            'Obadiah'
        ]

        self.torah: Set[str] = {'Genesis', 'Exodus', 'Leviticus', 'Numbers', 'Deuteronomy'}

        self.prophets: Set[str] = {
            'Joshua', 'Judges', 'I_Samuel', 'II_Samuel', 'I_Kings', 'II_Kings',
            'Isaiah', 'Jeremiah', 'Ezekiel',
            'Hosea', 'Joel', 'Amos', 'Obadiah', 'Jonah', 'Micah', 'Nahum', 'Habakkuk',
            'Zephaniah', 'Haggai', 'Zechariah', 'Malachi'
        }

        self.writings: Set[str] = {
            'Psalms', 'Proverbs', 'Job', 'Song_of_Songs', 'Ruth', 'Lamentations',
            'Ecclesiastes', 'Esther', 'Daniel', 'Ezra', 'Nehemiah', 'I_Chronicles', 'II_Chronicles'
        }

        self._canon: Dict[str, str] = {b.lower(): b for b in self.sub_books}

        default_aliases: Dict[str, str] = {
            'psalm': 'Psalms',
            'ps': 'Psalms',
            'songs': 'Song_of_Songs',
            'songofsongs': 'Song_of_Songs',
            'song_of_solomon': 'Song_of_Songs',
            'canticles': 'Song_of_Songs',
            'lamentation': 'Lamentations',

            '1_chronicles': 'I_Chronicles',
            '2_chronicles': 'II_Chronicles',
            'i_chronicles': 'I_Chronicles',
            'ii_chronicles': 'II_Chronicles',

            '1_samuel': 'I_Samuel',
            '2_samuel': 'II_Samuel',
            'i_samuel': 'I_Samuel',
            'ii_samuel': 'II_Samuel',

            '1_kings': 'I_Kings',
            '2_kings': 'II_Kings',
            'i_kings': 'I_Kings',
            'ii_kings': 'II_Kings',
        }

        if aliases:
            default_aliases.update({k.lower(): v for k, v in aliases.items()})

        self.aliases = default_aliases

        self._bq_re = re.compile(
            r"^bq_(?P<book>.+)_(?P<ch>\d+)_(?P<v>\d+)$",
            re.IGNORECASE
        )

    def canonical_book_name(self, raw_book: str) -> Optional[str]:
        s = raw_book.strip().lower()
        s = s.replace('-', '_').replace(' ', '_')
        s = re.sub(r"_+", "_", s)

        if s in self.aliases:
            return self.aliases[s]

        if s in self._canon:
            return self._canon[s]

        m = re.match(r"^(?P<num>1|2|i|ii)_(?P<base>chronicles|samuel|kings)$", s)
        if m:
            num = m.group('num')
            base = m.group('base')
            if num in ('1', 'i'):
                return {'chronicles': 'I_Chronicles', 'samuel': 'I_Samuel', 'kings': 'I_Kings'}[base]
            else:
                return {'chronicles': 'II_Chronicles', 'samuel': 'II_Samuel', 'kings': 'II_Kings'}[base]

        return None

    def section_for_book(self, canon_book: str) -> str:
        if canon_book in self.torah:
            return "Torah"
        if canon_book in self.prophets:
            return "Prophets"
        if canon_book in self.writings:
            return "Writings"
        return "Tanakh"

    # ---------------------------
    # Updated Methods (as requested)
    # ---------------------------

    def normalize_one(self, bq: str) -> str:
        """
        Normalize a single bq string.
        If it does not match pattern or book is unknown,
        return original string unchanged.
        """
        s = bq.strip()
        m = self._bq_re.match(s)
        if not m:
            return bq

        raw_book = m.group("book")
        ch = m.group("ch")
        v = m.group("v")

        canon_book = self.canonical_book_name(raw_book)
        if canon_book is None:
            return bq

        section = self.section_for_book(canon_book)
        return f"Tanakh_{section}_{canon_book}__{ch}_{v}"

    def normalize_many(self, bq_list: Iterable[str]) -> List[str]:
        """
        Normalize many bq strings.
        Always preserves original items if not normalizable.
        """
        return [self.normalize_one(item) for item in bq_list]

class NormalizeTemplate:
    

    def __init__(self):
        pass

    
    def normalize_one(self, concept: Concept, name_tokens: List[str]) -> str:
        """
        Normalize a single bq string.
        If it does not match pattern or book is unknown,
        return original string unchanged.
        """
        return "_".join(name_tokens)


class TanakhBQNormalizer(NormalizeTemplate):
    """
    Normalize strings like:
        bq_leviticus_1_1
        bq_psalms_103_20
        bq_2_chronicles_36_16
        bq_Judges_13_6
    into:
        Tanakh_Torah_Leviticus__1_1
        Tanakh_Writings_Psalms__103_20
        Tanakh_Writings_II_Chronicles__36_16
        Tanakh_Prophets_Judges__13_6

    If a string does not match the expected format or the book is unknown,
    the original string is returned unchanged.
    """

    def __init__(
        self,
        *,
        books: Optional[List[str]] = None,
        sub_books: Optional[List[str]] = None,
        aliases: Optional[Dict[str, str]] = None,
    ):
        self.books = books or ['Tanakh', 'Prophets', 'Writings', 'Torah']

        self.sub_books = sub_books or [
            'Psalms', 'Genesis', 'Jeremiah', 'Isaiah', 'Numbers', 'Ezekiel', 'Exodus', 'Job',
            'Deuteronomy', 'I_Chronicles', 'Proverbs', 'Leviticus', 'II_Chronicles', 'I_Kings',
            'I_Samuel', 'II_Kings', 'II_Samuel', 'Joshua', 'Judges', 'Nehemiah', 'Daniel', 'Ezra',
            'Ecclesiastes', 'Zechariah', 'Hosea', 'Esther', 'Lamentations', 'Amos', 'Song_of_Songs',
            'Micah', 'Ruth', 'Joel', 'Habakkuk', 'Malachi', 'Zephaniah', 'Jonah', 'Nahum', 'Haggai',
            'Obadiah'
        ]

        self.torah: Set[str] = {'Genesis', 'Exodus', 'Leviticus', 'Numbers', 'Deuteronomy'}

        self.prophets: Set[str] = {
            'Joshua', 'Judges', 'I_Samuel', 'II_Samuel', 'I_Kings', 'II_Kings',
            'Isaiah', 'Jeremiah', 'Ezekiel',
            'Hosea', 'Joel', 'Amos', 'Obadiah', 'Jonah', 'Micah', 'Nahum', 'Habakkuk',
            'Zephaniah', 'Haggai', 'Zechariah', 'Malachi'
        }

        self.writings: Set[str] = {
            'Psalms', 'Proverbs', 'Job', 'Song_of_Songs', 'Ruth', 'Lamentations',
            'Ecclesiastes', 'Esther', 'Daniel', 'Ezra', 'Nehemiah', 'I_Chronicles', 'II_Chronicles'
        }

        self._canon: Dict[str, str] = {b.lower(): b for b in self.sub_books}

        default_aliases: Dict[str, str] = {
            'psalm': 'Psalms',
            'ps': 'Psalms',
            'songs': 'Song_of_Songs',
            'songofsongs': 'Song_of_Songs',
            'song_of_solomon': 'Song_of_Songs',
            'canticles': 'Song_of_Songs',
            'lamentation': 'Lamentations',

            '1_chronicles': 'I_Chronicles',
            '2_chronicles': 'II_Chronicles',
            'i_chronicles': 'I_Chronicles',
            'ii_chronicles': 'II_Chronicles',

            '1_samuel': 'I_Samuel',
            '2_samuel': 'II_Samuel',
            'i_samuel': 'I_Samuel',
            'ii_samuel': 'II_Samuel',

            '1_kings': 'I_Kings',
            '2_kings': 'II_Kings',
            'i_kings': 'I_Kings',
            'ii_kings': 'II_Kings',
        }

        if aliases:
            default_aliases.update({k.lower(): v for k, v in aliases.items()})

        self.aliases = default_aliases

        self._bq_re = re.compile(
            r"^bq_(?P<book>.+)_(?P<ch>\d+)_(?P<v>\d+)$",
            re.IGNORECASE
        )

    def canonical_book_name(self, raw_book: str) -> Optional[str]:
        s = raw_book.strip().lower()
        s = s.replace('-', '_').replace(' ', '_')
        s = re.sub(r"_+", "_", s)

        if s in self.aliases:
            return self.aliases[s]

        if s in self._canon:
            return self._canon[s]

        m = re.match(r"^(?P<num>1|2|i|ii)_(?P<base>chronicles|samuel|kings)$", s)
        if m:
            num = m.group('num')
            base = m.group('base')
            if num in ('1', 'i'):
                return {'chronicles': 'I_Chronicles', 'samuel': 'I_Samuel', 'kings': 'I_Kings'}[base]
            else:
                return {'chronicles': 'II_Chronicles', 'samuel': 'II_Samuel', 'kings': 'II_Kings'}[base]

        return None

    def section_for_book(self, canon_book: str) -> str:
        if canon_book in self.torah:
            return "Torah"
        if canon_book in self.prophets:
            return "Prophets"
        if canon_book in self.writings:
            return "Writings"
        return "Tanakh"

    # ---------------------------
    # Updated Methods (as requested)
    # ---------------------------

    def normalize_one(self, concept: Concept, name_tokens: List[str]) -> str:
        """
        Normalize a single bq string.
        If it does not match pattern or book is unknown,
        return original string unchanged.
        """

        bq = concept.id
        
        s = bq.strip()
        m = self._bq_re.match(s)
        if not m:
            return bq

        raw_book = m.group("book")
        ch = m.group("ch")
        v = m.group("v")

        canon_book = self.canonical_book_name(raw_book)
        if canon_book is None:
            return bq

        section = self.section_for_book(canon_book)
        return f"Tanakh_{section}_{canon_book}__{ch}_{v}"


class Normalizer:
    """
    A class to canonize concept names based on their entity type using specified normalizers.
    If a normalizer for a specific entity type is not provided, it falls back to a default normalizer.
    The TanakhBQNormalizer will normalize the KG quotations to ACT format.
    New normalizers for Rabbinic names etc. will assist act to compare sequences of concepts in the KG to ACT sequences, even if the names are not exactly the same.
    """
    def __init__(self, default_normalizer= None, normalizers:Dict[str, Any]= {}):
        self.normalizers = {}
        for n in normalizers:
            self.normalizers[n] = normalizers[n]()

        if default_normalizer:
            self.normalizers["default"] = default_normalizer()
        else:
            self.normalizers["default"] = NormalizeTemplate()

    def canonize(self, concept: Concept, name_tokens: List[str])-> str:
        if concept.entity_type in self.normalizers:
            analyzer = self.normalizers[concept.entity_type]
        else:
            analyzer = self.normalizers["default"]
    
        return analyzer.normalize_one(concept, name_tokens)
        

def kg2ACT(subgraphs: List[Any], location: str, categories: Optional[List[str]] = None,
           optout_entity_type: Optional[List[str]] = None, optin_entity_type: Optional[List[str]] = None,
           clean_overlapping: bool = False, normalizers: Dict[str, Any] = None,
           additional_attrs: List[str] = None,
           additional_edge_attrs: List[str] = None) -> Dict[str, Any]:
    """
    Convert a list of subgraphs into an ACT graph format, with optional filtering and cleaning.
    Parameters
    ----------
    subgraphs : List[Any]
        A list of subgraph objects, each containing text and concepts.
    location : str
        The location identifier for the graph (e.g., document name or segment).
    categories : Optional[List[str]], optional
        A list of categories to assign to the graph, by default None.
    optout_entity_type : Optional[List[str]], optional
        A list of entity types to exclude from the graph, by default None.
    optin_entity_type : Optional[List[str]], optional
        A list of entity types to include in the graph (if specified, only these types will be included), by default None.
    clean_overlapping : bool, optional
        If True, remove nodes that have overlapping token positions (except for BiblicalQuotation), by default False.
    additional_attrs : List[str], optional
        A list of additional node attributes to copy from each concept onto its ACT node, by default None.
    additional_edge_attrs : List[str], optional
        A list of Relation attribute names (e.g. ["predicate", "evidence_text"]) to copy onto ACT edges
        when a matching KG relation exists between the two endpoint concepts, by default None.
    """
    
    def _create_nodes(subgraphs):
        import nltk
        from nltk.tokenize import word_tokenize
        import string
        
        def find_sublist_indices(sub_list, large_list):
            sub_len = len(sub_list)
            large_len = len(large_list)
            
            # Iterate through large_list, stopping where sub_list can no longer fit
            for i in range(large_len - sub_len + 1):
                # Check if the slice matches our target sub_list
                if large_list[i : i + sub_len] == sub_list:
                    # Return a list of indices from i to i + sub_len
                    return list(range(i, i + sub_len))
                    
            # Return an empty list if no match is found
            return []
        


        normalizer = Normalizer(normalizers= normalizers)

        all_tokens = []
        nodes = [{
            "id": 0,
            "tokens": [],
            "weight": 1,
            "pos": [-1],
            "completed": True,
            "quote": "start",
            "reference": "start__1_1",
            "type": "control",
            "rank": 9999,
            "valid": True,
            "calss": "Other"
        }]
        prev_sg_offset = 0
        current_id = 1
        
        for sg_id, sg in enumerate(subgraphs):
        
            sg_text_tokens = [x for x in word_tokenize(sg.text) if x not in string.punctuation]
            all_tokens += sg_text_tokens
            
            for cidx, c in enumerate(sg.concepts):
            
                if optout_entity_type and c.entity_type in optout_entity_type:
                    continue
                if optin_entity_type and c.entity_type not in optin_entity_type:
                    continue


                start_pos = c.concept_position
                end_pos = c.concept_position+len(c.prefLabel)
        
                if start_pos > 0 and sg.text[start_pos] != " ":
                    for i in range(1,3):
                        if sg.text[start_pos-i] in ["", " "]:
                            break
                        else:
                            start_pos -= 1
                # extend end_pos to the true word boundary
                while end_pos < len(sg.text) and sg.text[end_pos] not in (" ", ""):
                    end_pos += 1

                # the text of the concept adding positions to the start and end of the token
                ctext = sg.text[start_pos:end_pos]
                # the tokens of the concept as they appear in the text
                tc_tokens = [x for x in word_tokenize(ctext) if x not in string.punctuation]

                cpos = [x+prev_sg_offset for x in find_sublist_indices(tc_tokens, sg_text_tokens)]

                # fallback: if pos is still empty, use the term's surface span directly
                if not cpos and hasattr(c, 'term_id') and c.term_id is not None:
                    term = next((t for t in sg.terms if t.term_id == c.term_id), None)
                    if term:
                        span_tokens = [x for x in word_tokenize(term.span) if x not in string.punctuation]
                        span_cpos = [x+prev_sg_offset for x in find_sublist_indices(span_tokens, sg_text_tokens)]
                        if span_cpos:
                            cpos = span_cpos
                            tc_tokens = span_tokens

                #print(f"subgraph: {sg_id}, Concept: {cidx}, Tokens: {tc_tokens}, Positions: {cpos} ")

                node = {
                        "quote": c.prefLabel,
                        "tokens": tc_tokens,
                        "completed": True,
                        "pos": cpos,
                        "id": current_id,
                        "type": c.entity_type,
                        "reference": normalizer.canonize(c, tc_tokens),
                        "weight": len(tc_tokens),
                        "source_matrix": [0, 0, 0, 0, 0],
                        "rank": 20.00,
                        "boost": 0,
                        "valid": True,
                        "boost_same_quote": False,
                        "next_quote_pos": 0,
                        "calss": "Other",
                        "subgraph_id": sg_id,
                        "concept_id": c.id
                    }
                for attr in additional_attrs or []:
                    if hasattr(c, attr):
                        node[attr] = getattr(c, attr)

                # add aditional c properties to the node if they exist in the concept
                for prop in ['conceptDescription_en', 'conceptDescription', 'concept_position', 'prefLabel_en', "definition"]:
                    if hasattr(c, prop):
                        node[prop] = getattr(c, prop)
                nodes.append(node)
                current_id += 1
        
            prev_sg_offset += len(sg_text_tokens)
    
        nodes.append({
            "id": 9999,
            "tokens": [],
            "weight": 1,
            "pos": [9999],
            "completed": True,
            "quote": "end",
            "reference": "end__99_99",
            "source_matrix": [],
            "type": "control",
            "rank": 9999,
            "valid": True,
            "calss": "Plain"
        })
    
        #nodes = nodes.sort(key=lambda x: x['pos'][0])
        try:
            nodes = sorted(nodes, key=lambda x: x['pos'][0])
        except Exception as e:
            print(f"Error sorting nodes by position: {e}")
            print("Nodes with their positions:")
            for node in nodes:
                print(f"Node ID: {node['id']}, Quote: {node['quote']}, Position: {node['pos']}")
            raise e
        return nodes, all_tokens

    def _create_edges(nodes):

        def calculate_weight(from_node, to_node):
            """Calculate the gap weight between two nodes based on their positions."""
            if from_node["id"] == 0:
                # From start to first concept: weight is the pos of the first word
                return to_node["pos"][0] if to_node["pos"] else 0
            elif to_node["id"] == 9999:
                # From last concept to end: approximate weight as 1
                return 1
            else:
                # Between concepts: gap between last word of from_node and first word of to_node
                return max(0, to_node["pos"][0] - (from_node["pos"][-1] + 1))

        def _make_edge(from_node, to_node):
            edge = {"from": from_node['id'], "to": to_node['id'], "weight": calculate_weight(from_node, to_node)}
            if additional_edge_attrs:
                from_cid = from_node.get('concept_id')
                to_cid = to_node.get('concept_id')
                if from_cid and to_cid:
                    rel = relation_lookup.get((from_cid, to_cid))
                    if rel:
                        for attr in additional_edge_attrs:
                            if hasattr(rel, attr):
                                edge[attr] = getattr(rel, attr)
            return edge

        edges = [_make_edge(nodes[0], nodes[1])]

        #print(f"Edge ({nodes[0]['id']},{nodes[1]['id']})")

        prev_nodes = [nodes[0]]
        current_nodes = [nodes[1]]
        current_pos = nodes[1]['pos']
        for n in nodes[2:]:
            if n['pos'][0] > current_pos[-1]:
                for i in current_nodes:
                    #print(f"Edge ({i['id']},{n['id']})")
                    edges.append(_make_edge(i, n))
                prev_nodes = current_nodes
                current_nodes = [n]
                current_pos = n['pos']
                continue


            if n['pos'][0] <= current_pos[-1] and n['pos'][-1] >= current_pos[0]:
                has_bib_quote = len([x for x in current_nodes if x['type']=="BiblicalQuotation"]) > 0
                if has_bib_quote:
                    n['valid'] = False
                    continue
                if n['type'] == "BiblicalQuotation":
                    for x in current_nodes:
                        x['valid'] = False
                    current_nodes = [n]
                else:
                    if clean_overlapping:
                        n['valid'] = False
                    else:
                        current_nodes.append(n)
                        for i in prev_nodes:
                            edges.append(_make_edge(i, n))


                current_pos = sorted(list(set(current_pos + n['pos'])))

        return edges

    nodes, consolidated_token = nd = _create_nodes(subgraphs)

    # Build relation lookup: (subject_id, object_id) -> Relation, for edge attribute enrichment
    relation_lookup = {}
    if additional_edge_attrs:
        for sg in subgraphs:
            for rel in getattr(sg, 'relation_objects', []):
                relation_lookup[(rel.subject_id, rel.object_id)] = rel

    edges = _create_edges(nodes)
    
    # Entites sequence is the list of references of all valid nodes that have a type (excluding control nodes)
    # It should exclude opted-out entity types and include only opted-in entity types if specified.
    entites_seq = [x['reference'] for x in nodes if x['valid']==True and 'type' in x and x['type'] not in (optout_entity_type or []) and (not optin_entity_type or x['type'] in optin_entity_type)]

    output = {
            "location": location,
            "segment": 0,
            "categories": categories or [],
            "citation_seq": [x['reference'] for x in nodes if x['valid']==True and 'type' in x and x['type']=="BiblicalQuotation"],
            "entities_seq": " ".join(entites_seq) if entites_seq else "",
            "nodes": nodes,
            "edges": edges,
            "html": "",
            "gt_text": " ".join([x.text for x in subgraphs]),
            "gt_clean_text": " ".join(consolidated_token),
            "gt_citation_seq": []
        }

    return output



def OLDkg2ACT(subgraphs: List[Any], location: str, categories: Optional[List[str]] = None, 
           optout_entity_type: Optional[List[str]] = None, optin_entity_type: Optional[List[str]] = None,
           clean_overlapping: bool = False, normalizers: Dict[str, Any] = None, 
           additional_attrs: List[str] = None) -> Dict[str, Any]:
    """
    Convert a list of subgraphs into an ACT graph format, with optional filtering and cleaning.
    Parameters
    ----------
    subgraphs : List[Any]
        A list of subgraph objects, each containing text and concepts.
    location : str
        The location identifier for the graph (e.g., document name or segment).
    categories : Optional[List[str]], optional
        A list of categories to assign to the graph, by default None.
    optout_entity_type : Optional[List[str]], optional
        A list of entity types to exclude from the graph, by default None.
    optin_entity_type : Optional[List[str]], optional   
        A list of entity types to include in the graph (if specified, only these types will be included), by default None.
    clean_overlapping : bool, optional
        If True, remove nodes that have overlapping token positions (except for BiblicalQuotation), by default False.
    additional_attrs : List[str], optional
        A list of additional attributes to include in the graph, by default None.
    """
    
    def _create_nodes(subgraphs):
        import nltk
        from nltk.tokenize import word_tokenize
        import string
        
        def find_sublist_indices(sub_list, large_list):
            sub_len = len(sub_list)
            large_len = len(large_list)
            
            # Iterate through large_list, stopping where sub_list can no longer fit
            for i in range(large_len - sub_len + 1):
                # Check if the slice matches our target sub_list
                if large_list[i : i + sub_len] == sub_list:
                    # Return a list of indices from i to i + sub_len
                    return list(range(i, i + sub_len))
                    
            # Return an empty list if no match is found
            return []
        


        normalizer = Normalizer(normalizers= normalizers)

        all_tokens = []
        nodes = [{
            "id": 0,
            "tokens": [],
            "weight": 1,
            "pos": [-1],
            "completed": True,
            "quote": "start",
            "reference": "start__1_1",
            "type": "control",
            "rank": 9999,
            "valid": True,
            "calss": "Other"
        }]
        prev_sg_offset = 0
        current_id = 1
        
        for sg_id, sg in enumerate(subgraphs):
        
            sg_text_tokens = [x for x in word_tokenize(sg.text) if x not in string.punctuation]
            all_tokens += sg_text_tokens
            
            for cidx, c in enumerate(sg.concepts):
            
                if optout_entity_type and c.entity_type in optout_entity_type:
                    continue
                if optin_entity_type and c.entity_type not in optin_entity_type:
                    continue


                start_pos = c.concept_position
                end_pos = c.concept_position+len(c.prefLabel)
        
                if start_pos > 0 and sg.text[start_pos] != " ":
                    for i in range(1,3):
                        if sg.text[start_pos-i] in ["", " "]:
                            break
                        else:
                            start_pos -= 1
                # extend end_pos to the true word boundary
                while end_pos < len(sg.text) and sg.text[end_pos] not in (" ", ""):
                    end_pos += 1

                # the text of the concept adding positions to the start and end of the token
                ctext = sg.text[start_pos:end_pos]
                # the tokens of the concept as they appear in the text
                tc_tokens = [x for x in word_tokenize(ctext) if x not in string.punctuation]

                cpos = [x+prev_sg_offset for x in find_sublist_indices(tc_tokens, sg_text_tokens)]

                # fallback: if pos is still empty, use the term's surface span directly
                if not cpos and hasattr(c, 'term_id') and c.term_id is not None:
                    term = next((t for t in sg.terms if t.term_id == c.term_id), None)
                    if term:
                        span_tokens = [x for x in word_tokenize(term.span) if x not in string.punctuation]
                        span_cpos = [x+prev_sg_offset for x in find_sublist_indices(span_tokens, sg_text_tokens)]
                        if span_cpos:
                            cpos = span_cpos
                            tc_tokens = span_tokens

                #print(f"subgraph: {sg_id}, Concept: {cidx}, Tokens: {tc_tokens}, Positions: {cpos} ")

                node = {
                        "quote": c.prefLabel,
                        "tokens": tc_tokens,
                        "completed": True,
                        "pos": cpos,
                        "id": current_id,
                        "type": c.entity_type,
                        "reference": normalizer.canonize(c, tc_tokens),
                        "weight": len(tc_tokens),
                        "source_matrix": [0, 0, 0, 0, 0],
                        "rank": 20.00,
                        "boost": 0,
                        "valid": True,
                        "boost_same_quote": False,
                        "next_quote_pos": 0,
                        "calss": "Other",
                        "subgraph_id": sg_id
                    }
                for attr in additional_attrs or []:
                    if hasattr(c, attr):
                        node[attr] = getattr(c, attr)

                # add aditional c properties to the node if they exist in the concept
                for prop in ['conceptDescription_en', 'conceptDescription', 'concept_position', 'prefLabel_en', "definition"]:
                    if hasattr(c, prop):
                        node[prop] = getattr(c, prop)
                nodes.append(node)
                current_id += 1
        
            prev_sg_offset += len(sg_text_tokens)
    
        nodes.append({
            "id": 9999,
            "tokens": [],
            "weight": 1,
            "pos": [9999],
            "completed": True,
            "quote": "end",
            "reference": "end__99_99",
            "source_matrix": [],
            "type": "control",
            "rank": 9999,
            "valid": True,
            "calss": "Plain"
        })
    
        #nodes = nodes.sort(key=lambda x: x['pos'][0])
        try:
            nodes = sorted(nodes, key=lambda x: x['pos'][0])
        except Exception as e:
            print(f"Error sorting nodes by position: {e}")
            print("Nodes with their positions:")
            for node in nodes:
                print(f"Node ID: {node['id']}, Quote: {node['quote']}, Position: {node['pos']}")
            raise e
        return nodes, all_tokens

    def _create_edges(nodes):
    
        def calculate_weight(from_node, to_node):
            """Calculate the gap weight between two nodes based on their positions."""
            if from_node["id"] == 0:
                # From start to first concept: weight is the pos of the first word
                return to_node["pos"][0] if to_node["pos"] else 0
            elif to_node["id"] == 9999:
                # From last concept to end: approximate weight as 1
                return 1
            else:
                # Between concepts: gap between last word of from_node and first word of to_node
                return max(0, to_node["pos"][0] - (from_node["pos"][-1] + 1))
                  
        edges = [{"from": nodes[0]['id'],
                  "to": nodes[1]['id'],
                  "weight": calculate_weight(nodes[0], nodes[1])
                 }]
    
        #print(f"Edge ({nodes[0]['id']},{nodes[1]['id']})")
        
        prev_nodes = [nodes[0]]
        current_nodes = [nodes[1]]
        current_pos = nodes[1]['pos']
        for n in nodes[2:]:
            if n['pos'][0] > current_pos[-1]:
                for i in current_nodes:
                    #print(f"Edge ({i['id']},{n['id']})")
                    ne = {"from": i['id'], "to": n['id'], "weight": calculate_weight(i, n) }
                    edges.append(ne)
                prev_nodes = current_nodes
                current_nodes = [n]
                current_pos = n['pos']
                continue


            if n['pos'][0] <= current_pos[-1] and n['pos'][-1] >= current_pos[0]:
                has_bib_quote = len([x for x in current_nodes if x['type']=="BiblicalQuotation"]) > 0
                if has_bib_quote:
                    n['valid'] = False
                    continue
                if n['type'] == "BiblicalQuotation":
                    for x in current_nodes:
                        x['valid'] = False
                    current_nodes = [n]
                else:
                    if clean_overlapping:
                        n['valid'] = False
                    else:
                        current_nodes.append(n)
                        for i in prev_nodes:
                            edges.append({"from": i['id'], "to": n['id'], "weight": calculate_weight(i, n)})


                current_pos = sorted(list(set(current_pos + n['pos'])))
        
        return edges

    nodes, consolidated_token = nd = _create_nodes(subgraphs) 
    
    edges = _create_edges(nodes)
    
    # Entites sequence is the list of references of all valid nodes that have a type (excluding control nodes)
    # It should exclude opted-out entity types and include only opted-in entity types if specified.
    entites_seq = [x['reference'] for x in nodes if x['valid']==True and 'type' in x and x['type'] not in (optout_entity_type or []) and (not optin_entity_type or x['type'] in optin_entity_type)]

    output = {
            "location": location,
            "segment": 0,
            "categories": categories or [],
            "citation_seq": [x['reference'] for x in nodes if x['valid']==True and 'type' in x and x['type']=="BiblicalQuotation"],
            "entities_seq": " ".join(entites_seq) if entites_seq else "",
            "nodes": nodes,
            "edges": edges,
            "html": "",
            "gt_text": " ".join([x.text for x in subgraphs]),
            "gt_clean_text": " ".join(consolidated_token),
            "gt_citation_seq": []
        }

    return output






#------ Inception converted to GT Graph -----

def inception_to_graph(tsv_content: str) -> dict:
    """
    Parses a WebAnno TSV 3.3 file content and converts it into a graph format.

    Args:
        tsv_content: A string containing the full content of the TSV file.

    Returns:
        A dictionary representing the graph with 'nodes' and 'edges'.
    """
    
    # Intermediate storage for parsing entities
    entities = {}
    token_to_entity_key = {}

    # --- PASS 1: Identify all unique entities and their properties ---
    for line in tsv_content.strip().split('\n'):
        if line.startswith('#') or not line.strip():
            continue
        
        parts = line.split('\t')
        if len(parts) < 7:
            continue
            
        token_id, _, token_text, comment, entity_type_raw, entity_group, _ = parts[:7]

        if entity_type_raw != '_':
            # Generate a consistent, unique key for each entity span
            # For "Concept[1]", the key becomes "Concept_1"
            # For a single-token "Concept", key becomes "Concept_3-7"
            match = re.search(r'\[(\d+)\]', entity_type_raw)
            if match:
                entity_key = f"{entity_type_raw.split('[')[0]}_{match.group(1)}"
            else:
                entity_key = f"{entity_type_raw}_{token_id}"
            
            token_to_entity_key[token_id] = entity_key

            if entity_key not in entities:
                # Initialize a new entity if it's the first time we see it
                base_type = entity_type_raw.split('[')[0]
                entities[entity_key] = {
                    "text_parts": [],
                    "comment": comment if comment not in ['_', '*'] else "",
                    "type": base_type,
                    "first_token": token_id,
                    "entity_group": entity_group.split("[")[0] if entity_group[0] not in ['_', '*'] else ""
                }
            
            entities[entity_key]["text_parts"].append(token_text)

    # --- Process entities into the final node list ---
    nodes = []
    entity_key_to_node_id = {}
    node_id_counter = 1
    
    # Sort keys for consistent node ID assignment
    for entity_key in sorted(entities.keys()):
        entity_data = entities[entity_key]
        entity_key_to_node_id[entity_key] = node_id_counter
        
        # Clean up the comment field to remove annotation IDs like '[1]'
        clean_comment = re.split(r'\[\d+\]', entity_data["comment"])[0].strip()

        node = {
            "id": node_id_counter,
            "entity_type": entity_data["type"],
            "comment": clean_comment,
            "prefLabel": " ".join(entity_data["text_parts"]),
            "altLabels": [],
            "group": entity_data["entity_group"]
        }
        nodes.append(node)
        node_id_counter += 1

    # --- PASS 2: Identify all relationships and create edges ---
    edges = []
    for line in tsv_content.strip().split('\n'):
        if line.startswith('#') or not line.strip():
            continue

        parts = line.split('\t')
        if len(parts) < 8 or parts[6] == '_':
            continue

        source_token_id = parts[0]
        
        # Ensure the relation is defined on the first token of the source entity
        source_entity_key = token_to_entity_key.get(source_token_id)
        if not source_entity_key or source_token_id != entities[source_entity_key]["first_token"]:
            continue
        
        to_node_id = entity_key_to_node_id[source_entity_key]
        relation_types = parts[6].split('|')
        target_tokens_raw = parts[7].split('|')
        
        for i, rel_type in enumerate(relation_types):
            # Clean up target token ID (e.g., '1-1[1_2]' becomes '1-1')
            target_token_id = re.split(r'\[', target_tokens_raw[i])[0]
            
            target_entity_key = token_to_entity_key.get(target_token_id)
            if target_entity_key:
                from_node_id = entity_key_to_node_id[target_entity_key]
                edge = {
                    "from": from_node_id,
                    "to": to_node_id,
                    "relation type": rel_type
                }
                edges.append(edge)

    graph = {
        "nodes": nodes,
        "edges": edges
    }
    
    return graph

def merge_nodes_by_group(nodes: list, edges: list) -> tuple[list, list]:
    """
    Merges nodes with the same 'group' attribute and updates the corresponding edges.

    Args:
        nodes: A list of node dictionaries.
        edges: A list of edge dictionaries.

    Returns:
        A tuple containing the new list of nodes and the new list of edges.
    """
    # 1. Identify groups of nodes to merge
    groups_to_merge = defaultdict(list)
    for node in nodes:
        group = node.get('group')
        # Only consider nodes with a non-empty group for merging
        if group:
            groups_to_merge[group].append(node)

    # 2. Create a mapping from old node IDs to their new representative ID
    node_id_map = {node['id']: node['id'] for node in nodes}
    merged_node_data = {}

    for group, member_nodes in groups_to_merge.items():
        if len(member_nodes) > 1:
            # Choose the first node in the group as the representative
            representative_node = member_nodes[0]
            rep_id = representative_node['id']
            
            # Combine labels from all nodes in the group
            #combined_label = " | ".join(sorted([n['prefLabel'] for n in member_nodes]))
            
            # Store the combined data for the new node
            merged_node_data[rep_id] = representative_node.copy()
            merged_node_data[rep_id]['altLabels'] = [n['prefLabel'] for n in member_nodes]
            
            # Map all other nodes in the group to the representative
            for node in member_nodes[1:]:
                node_id_map[node['id']] = rep_id

    # 3. Create the new list of nodes
    new_nodes = []
    processed_ids = set()
    for node in nodes:
        final_id = node_id_map[node['id']]
        if final_id not in processed_ids:
            # If this is a merged node, use the combined data
            if final_id in merged_node_data:
                new_nodes.append(merged_node_data[final_id])
            # Otherwise, it's a regular node that wasn't merged
            else:
                new_nodes.append(node)
            processed_ids.add(final_id)
            
    # 4. Create the new list of edges
    new_edges = []
    # Use a set to automatically handle duplicate edges after merging
    unique_edges = set() 
    
    for edge in edges:
        new_from = node_id_map[edge['from']]
        new_to = node_id_map[edge['to']]
        
        # Avoid creating self-loops
        if new_from != new_to:
            # Create a tuple representation to check for uniqueness
            edge_tuple = (new_from, new_to, edge['relation type'])
            if edge_tuple not in unique_edges:
                new_edges.append({
                    'from': new_from,
                    'to': new_to,
                    'relation type': edge['relation type']
                })
                unique_edges.add(edge_tuple)

    return new_nodes, new_edges

def inception_extract_text(tsv_content: str) -> str:
    """
    Extracts all text lines from a TSV file string and merges them.

    Args:
        tsv_content: A string containing the full content of the TSV file.

    Returns:
        A single string containing all the text from lines starting with
        '#Text=', separated by newline characters.
    """
    text_lines = []
    # Split the input string into individual lines
    for line in tsv_content.splitlines():
        # Check if the line starts with the specified prefix
        if line.startswith('#Text='):
            # Extract the text part of the line by slicing the string
            text = line[6:]
            text_lines.append(text)
    
    # Join the collected text lines with a newline character
    return "\n".join(text_lines)

def inception2Graph(path: str) -> dict:
    """
    Converts Inception TSV content to a knowledge graph.

    Args:
        tsv_content: A string containing the full content of the TSV file.

    Returns:
       Graph object.
    """
    from simplekg.models import Graph, Concept

    with open(path, 'r', encoding='utf-8') as f:
            tsv_content = f.read()


    # Parse the TSV content into a basic graph structure
    graph = inception_to_graph(tsv_content)
    
    # Merge nodes based on their 'group' attribute
    merged_nodes, merged_edges = merge_nodes_by_group(graph['nodes'], graph['edges'])
    
    # Create Concept objects for each merged node
    concepts = [Concept(prefLabel=x['prefLabel'], prefLabel_en="", altLabels=x['altLabels'], 
                        altLabels_en=[], entity_type=x['entity_type'], conceptDescription=x['comment'],
                        conceptDescription_en="") for x in merged_nodes]
    
    # Create a mapping from node IDs to their corresponding node data
    nodes_dict = {x['id']: x for x in graph['nodes']}
    
    # Create a set of relations as (subject, predicate, object) tuples
    relations = {(nodes_dict[x['from']]['prefLabel'], x['relation type'], nodes_dict[x['to']]['prefLabel']) for x in merged_edges}
    
    # Construct the final Graph object
    kg_graph = Graph(
        entities={c.prefLabel for c in concepts}, 
        relations=relations, 
        text=inception_extract_text(tsv_content), 
        concepts=concepts
    )

    return kg_graph