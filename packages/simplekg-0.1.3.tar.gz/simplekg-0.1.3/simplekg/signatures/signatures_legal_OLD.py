"""
Legal Signature Registry: Implementation for legal document processing.

This module contains signature implementations specifically designed for
legal documents, particularly Hebrew work agreements and contracts.

All signature classes are self-contained in this module to ensure complete
independence from other signature domains.
"""

from .signature_registry import SignatureRegistry
from typing import Type, List
import dspy

# Import models
try:
    from ..models import *
except ImportError:
    from simplekg.models import *


# ============================================================================
# LEGAL SIGNATURE IMPLEMENTATIONS
# ============================================================================

class HarvestDefinitionCandidates(dspy.Signature):
    """
    ROLE:
      You are an expert Legal Knowledge Graph Engineer for Hebrew legal documents.

    Task:
      For the given text_chunk and its detected Concept list, identify which Concepts
      are being DEFINED in this chunk (i.e., appear in a legal-definition context).

    What counts as a 'definition'?
      A concept is considered a definition concept in this chunk if the text explicitly
      introduces it and attaches a meaning, scope, or role, typically via patterns like:

      1) Explicit definition lines:
         - "TERM" – definition...
         - TERM – definition...
         - TERM: definition...
         Examples:
           "עובד ארעי" – עובד החברה המצוי בתקופת הארעיות...
           עובד קבוע – עובד שסיים את תקופת הארעיות...

      2) 'להלן' patterns:
         - TERM (להלן: "ALIAS")
         - "ALIAS" (להלן – TERM)
         - (להלן: "TERM") right after a name.
         These indicate that the concept (TERM or ALIAS) is being defined
         for later use in the contract.

      3) Definition-reference phrases:
         - כהגדרתו להלן / כהגדרתם להלן / כהגדרתו בחוזה זה / כהגדרתם בפרק זה
         - לשם הגדרת TERM, לעניין TERM וכו'.
         If a sentence clearly defines what TERM means in the context of the document,
         mark TERM as a definition concept.

    Important constraints:
      - Only mark concepts that correspond to existing Concepts in the 'concepts' list.
      - Do NOT invent new concepts or new IDs.
      - You may mark multiple concepts in the same chunk as definitions.
      - Do NOT mark every mention of a concept as a definition; ONLY those in definitional contexts.

    Matching rules:
      - Match from text to Concepts using:
          * prefLabel_he
          * altLabels_he
          * obvious orthographic variants (ה/ב/ל/מ/כ/ו prefixes).
      - concept_id in the output MUST be exactly one of [c.id for c in concepts].

    Output:
      - definition_concepts: list of DefinitionMark objects. Each indicates that the
        given Concept.id is explicitly defined in this chunk, with evidence_text
        showing the definitional sentence or phrase.
    """

    text_chunk: str = dspy.InputField(desc="The Hebrew text of this chunk.")
    concepts: List["Concept"] = dspy.InputField(desc="Concepts detected in this chunk.")
    definition_concepts: List[DefinitionMark] = dspy.OutputField(
        desc="Concept IDs that are explicitly defined in this chunk, with confidence and evidence."
    )


class HarvestTerms(dspy.Signature):
    """
    You are an expert Legal Knowledge Graph Engineer for Hebrew legal texts.

    Task:
    From the given text chunk, harvest as many meaningful legal terms and entities
    as possible. Your goal is HIGH RECALL, even if some terms overlap or seem redundant.

    What to include (non-exhaustive):
    - Organizations, persons, locations, dates.
    - Types of agreements and references to specific agreements
      (e.g., 'הסכם משנת 2016', 'הסכם 68/2019', 'הסכם קיבוצי מיוחד').
    - Legal concepts and constructs (e.g., 'יחסי עבודה קיבוציים',
      'מערכת יחסי עבודה', 'זכויות העובדים', 'שמירת זכויות').
    - Clauses and headings (e.g., 'שמירת זכויות', 'תוקף ותחולה').
    - Economic / employment terms (e.g., 'השכר השעתי הקבוע', 'תנאי עבודה ראויים והוגנים').
    - References to other documents or clauses (e.g., 'סעיף 4.1 להסכם משנת 2016').

    DEFINITION LINES (VERY IMPORTANT):
    - When the text uses a pattern like:
        "TERM" – definition that includes sub-parts A, B, C...
      you must:
        1) Harvest the main TERM itself.
        2) Harvest each important sub-term inside the definition as separate candidates
           if they are legal/financial/employment concepts that may appear elsewhere.
      - Typical sub-terms inside definitions:
        • wage components (e.g., 'דמי מחלה', 'דמי חופשה שנתית', 'תוספת ותק')
        • building blocks of formulas (e.g., 'תעריף שעתי', 'שעות עבודה רגילות')
        • references to scope (e.g., 'היקף משרה מלאה').

    Guidelines:
    - Prefer short noun phrases as span (1–5 tokens).
    - A span can be harvested even if it appears only once and only inside a definition.
    - Do NOT deduplicate: if in doubt, include the term.
    - Err on the side of over-including – better too many candidates than too few.
    """

    text_chunk: str = dspy.InputField()
    candidates: List[TermCandidate] = dspy.OutputField(
        desc="High-recall list of term candidates to be later normalized into Concepts."
    )


class CandidatesToConcepts(dspy.Signature):
    """
    Normalize and consolidate raw term candidates into canonical Concept objects.

    Task:
    - Group together candidates that refer to the same underlying concept.
    - For each resulting Concept:
        - prefLabel_he: the best, most specific canonical form in Hebrew.
        - prefLabel_en: English translation in UpperCamelCase (no punctuation).
        - altLabels_he: other Hebrew variants, aliases, acronyms, or longer/shorter forms.
        - altLabels_en: English variants if obvious.
        - entity_type: choose the most specific type, e.g.,
          Organization, Person, Location, Date, LegalDocument, LegalConcept,
          Clause, Right, Obligation, Remuneration, Event, Reference.
        - conceptDescription_he: short explanation of the concept in this context.

    Merging rules (generic):
    - Merge morphological variants like 'החברה', 'בחברה', 'בחברה זו' into one Concept 'החברה'.
    - Merge explicit aliases defined with 'להלן:', parentheses, or quotes into one Concept,
      putting aliases into altLabels_he.
    - Merge references that share the same core idea (e.g., 'הסכם משנת 2016',
      'ההסכם משנת 2016').

    IMPORTANT: Sub-terms inside definitions
    - Do NOT merge away or drop sub-terms that correspond to meaningful components
      of a definition, even if they appear only once.
      Examples (generic pattern):
        • If 'שכר' is defined using 'תעריף שעתי', 'שעות עבודה רגילות', 'דמי מחלה',
          'דמי חופשה שנתית', each of these should normally become a separate Concept.
        • If 'שכר פנסיוני' is defined using 'היקף משרה מלאה' and 'תוספת ותק',
          keep 'היקף משרה מלאה' and 'תוספת ותק' as separate Concepts.
    - It is acceptable (and preferred) to have both a parent concept and its components
      as separate Concept objects, each with its own entity_type (e.g., Remuneration vs LegalConcept).


    ID Generation Rules:
    - The Concept.id MUST be deterministic.
    - The id MUST be based ONLY on prefLabel_he or prefLabel_en.
    - Use the Hebrew prefLabel_he when available.
    - Allowed characters: Hebrew letters, English letters, digits, underscores.
    - ID format: Hebrew prefLabel_he → convert:
        * remove punctuation  
        * replace spaces with underscores  
        * remove quotes  
        * remove parentheses  
        * normalize ה/ב/ל prefixes (do NOT include them in ID)  
    - Example:
        - "בית בלב בע\"מ" → בית_בלב_בעמ
        - "הסכם קיבוצי מיוחד" → הסכם_קיבוצי_מיוחד
        - "יחסי עבודה קיבוציים" → יחסי_עבודה_קיבוציים

    Goal:
    - Preserve as many semantically meaningful Concepts as possible.
    - It is acceptable if the final list is long; favor recall over aggressive pruning.
    """

    text_chunk: str = dspy.InputField()
    candidates: List[TermCandidate] = dspy.InputField()
    concepts: List[Concept] = dspy.OutputField()


class HarvestChunkRelationCandidates(dspy.Signature):
    """
    From a single legal text chunk and a list of already-detected Concepts,
    harvest HIGH-RECALL candidate relations between them (and optionally
    between them and global definition concepts).

    INPUTS:
    - text_chunk: a single Hebrew chunk from a legal document.
    - concepts: the Concept objects already extracted for THIS chunk.
    - global_definitions: Concept objects that are definitions elsewhere
      in the document (document-level), which may participate in relations
      if the text in this chunk clearly refers to them.

    GOAL:
    - Emit RelationCandidate objects that link ONLY between these Concepts
      (chunk-level concepts + relevant global definition concepts).
    - HIGH RECALL is preferred: if a relation is plausibly expressed in the text,
      you should emit it (even if some candidates are redundant).

    ----------------------------------------------------------------------
    STEP 1 – Build the mention inventory (MANDATORY)
    ----------------------------------------------------------------------
    For each Concept C in (concepts + global_definitions), construct all
    Hebrew spans that can represent it in the text:

      base_label = C.prefLabel_he

      Also consider:
        - every string in C.altLabels_he
        - obvious Hebrew prefix variants of each label, such as:
            ה + label
            ב + label
            ל + label
            מ + label
            כ + label
            ו + label
            ש + label
          (only single-letter prefixes, attached to the noun)

      Collect all these possible forms into a mention inventory:
        mention_inventory = {span_he -> Concept.id}

    You MUST treat this mention inventory as the ONLY allowed pool of
    subject_mention_he and object_mention_he spans.

    HARD CONSTRAINT ON MENTIONS:
    - subject_mention_he and object_mention_he MUST be chosen ONLY from this
      mention inventory.
    - Do NOT invent new spans that do not clearly correspond to an existing Concept.
    - If a sentence or block links a Concept to something that is NOT
      represented by any of these spans, do NOT emit a RelationCandidate
      for that link.

    ----------------------------------------------------------------------
    STEP 2 – Identify local context windows (sentence + block level)
    ----------------------------------------------------------------------
    Instead of restricting yourself to a single sentence, work with SMALL,
    LOCAL CONTEXT WINDOWS inside the chunk.

    2.1 Sentence-level:
        - Split text_chunk into sentences or clauses (roughly, by punctuation).
        - For each sentence:
            - Identify all Concepts whose mention spans occur in that sentence.
            - For each ordered pair of distinct Concepts (C1, C2) in the sentence,
              ask:
                "What legal or semantic relation is explicitly stated here
                 between C1 and C2?"
            - Emit RelationCandidates where appropriate.

    2.2 Block-level (definitions and numbered lists):
        - Many legal definitions are expressed as:
            HEAD_TERM ... : 
              12.1. item A
              12.2. item B
              12.3. item C

          or:
            HEAD_TERM (להלן: "ALIAS") ...
            followed by numbered sub-items or semicolon-separated roles.

        - In such cases, treat the entire logical block as one LOCAL CONTEXT WINDOW:
            * The head definition sentence (e.g., containing HEAD_TERM or its alias)
            * The immediately following numbered items / lines
              (e.g., "12.1.", "12.2.", "12.3.", etc.)
              until a clear section/paragraph break.

        - Inside a definition block:
            - Consider the defined concept (HEAD_TERM or its alias) as a central node.
            - For each Concept that appears in the numbered items or lines of this
              block, emit relations from the head concept to the item concept, such as:
                head hasComponent item
                head hasMember item
                head hasException item
              (choose a predicate that best reflects the semantics, using lowerCamelCase.)

        - Example (generic, not tied to specific contract):
            If the block defines "ExcludedEmployees" and then lists:
              managers and HQ employees,
              network professionals,
              doctors,
              ...
            then you SHOULD emit:
              ExcludedEmployees hasMember ManagersAndEmployeesAtCompanyHeadquarters
              ExcludedEmployees hasMember NetworkProfessionalManagers
              ExcludedEmployees hasMember Doctors
            etc., as long as those roles are present in the Concept list and
            clearly part of the enumerated block.

    Coverage requirements:
    - You MUST attempt to find relations for EVERY Concept that appears in
      the chunk (and for relevant global_definitions when they are clearly
      referenced in this chunk).
    - Consider both roles where appropriate:
        - The concept as subject.
        - The concept as object.
    - If a Concept appears:
        * together with at least one other Concept in the same sentence, OR
        * in a numbered / definitional block together with a head definition concept,
      you should normally emit at least one RelationCandidate relating them,
      unless the text is purely descriptive with no clear linking relation.

    ----------------------------------------------------------------------
    STEP 3 – Emit RelationCandidate objects
    ----------------------------------------------------------------------
    For each identified relation between two Concepts:

    - subject_mention_he:
        * Choose one span from the mention inventory that matches the subject Concept
          in the current local context (sentence or block), exactly as it appears
          in the text.
    - object_mention_he:
        * Choose one span from the mention inventory that matches the object Concept
          in the same local context, exactly as it appears in the text.
    - predicate_label_en:
        * A short English label in lowerCamelCase, such as:
            sideOfAgreement, signedAt, signedDate, effectiveFrom, expiresOn,
            hasParty, hasClause, cancelsClause, amendsClause, amendsAgreement,
            refersToAgreement, hasWageTerm, preservesRights, regulates,
            definesTerm, hasComponent, hasMember, hasException,
            grantsRight, imposesObligation.
        * You may reuse these or coin similar lowerCamelCase predicates when needed.
    - evidence_text:
        * A short Hebrew snippet (typically one sentence or the relevant
          part of the block) that clearly justifies this relation.

    Constraints:
    - All subjects and objects must correspond to Concepts in (concepts + global_definitions).
    - NO new entities may be invented.
    - Only include relations that are explicit in the text (no speculation).
    - If no relations are found for a given Concept (e.g., it appears only once
      and not in any co-occurrence or definitional block), you may emit no
      RelationCandidate for that Concept.

    Output:
    - candidates: a high-recall list of RelationCandidate objects connecting
      ONLY between the Concepts in this chunk (and any relevant global
      definition concepts that are clearly referenced in this chunk).
    """

    text_chunk: str = dspy.InputField(
        desc="A single chunk of the legal document (Hebrew)."
    )
    concepts: List["Concept"] = dspy.InputField(
        desc="List of Concept objects detected for this chunk."
    )
    global_definitions: List["Concept"] = dspy.InputField(
        desc="Concepts that are definitions anywhere in the document (may or may not appear in this chunk).",
        default=[]
    )
    candidates: List[RelationCandidate] = dspy.OutputField(
        desc="High-recall list of candidate relations connecting concepts in this chunk."
    )


class HarvestRelation(dspy.Signature):
    """
    From a single legal text chunk and a list of already-detected Concepts,
    harvest HIGH-RECALL relations between them (and optionally
    between them and global definition concepts).

    INPUTS:
    - text_chunk: a single Hebrew chunk from a legal document.
    - concepts: the Concept objects already extracted for THIS chunk.
    - global_definitions: Concept objects that are definitions elsewhere
      in the document (document-level), which may participate in relations
      if the text in this chunk clearly refers to them.
    
    GOAL:
    - Emit RelationCandidate objects that link ONLY between these Concepts
      (chunk-level concepts + relevant global definition concepts).
    - HIGH RECALL is preferred: if a relation is plausibly expressed in the text,
      you should emit it (even if some candidates are redundant).
    
    Rules:
    - subject_id and object_id MUST be chosen ONLY from the 'concepts' list.
    - Check EVERY PAIR of concepts for possible relations in the text.
    - Detect relations not only from explicit verbs, but also from possessives, appositions, and contextual mentions.
    - predicate MUST be in English, expressed in lowerCamelCase.
    - evidence_text:
        * A short Hebrew snippet that clearly justifies this relation.
    - If no valid triple exists, return [].
    
    
    """

    text_chunk: str = dspy.InputField(
        desc="A single chunk of the legal document (Hebrew)."
    )
    concepts: List["Concept"] = dspy.InputField(
        desc="List of Concept objects detected for this chunk."
    )
    global_definitions: List["Concept"] = dspy.InputField(
        desc="Concepts that are definitions anywhere in the document (may or may not appear in this chunk).",
        default=[]
    )
    relations: List[Relation] = dspy.OutputField(
        desc="High-recall list of  relations connecting concepts in this chunk."
    )


class CandidatesToRelations(dspy.Signature):
    """
    Normalize raw RelationCandidate objects into clean Relation objects
    whose subject_id and object_id refer to Concept.id.

    INPUT:
      - candidates: raw RelationCandidate objects (mentions + predicate).
      - chunk_concepts: Concepts local to this chunk.
      - global_definitions: Concepts that are definitions anywhere in the document.

    ENTITY POOL:
      - allowed_concepts = chunk_concepts ∪ global_definitions
      - Only these Concepts may be used as subjects/objects.

    Matching rules:
      - You are given the full list of allowed_concepts.
      - You MUST map subject_mention_he and object_mention_he ONLY to existing Concepts:
          * Exact match of prefLabel_he, or
          * Exact match to any altLabels_he, or
          * Very close variant (e.g. with/without ה-, ב-, ל-, ו- prefixes).
      - subject_id and object_id MUST be taken EXACTLY from one of the Concept.id values
        in allowed_concepts.
        You are NOT allowed to invent new IDs or use labels as IDs.

    If mapping fails:
      - If you cannot confidently map a mention to a Concept (no good match),
        you MUST discard that RelationCandidate (do not produce a Relation for it).

    Predicate:
      - Use the candidate.predicate_label_en as the final predicate value.
      - Do NOT invent new predicates.

    Output:
      - relations: list of Relation objects where:
          * relation.subject_id ∈ {c.id for c in allowed_concepts}
          * relation.object_id  ∈ {c.id for c in allowed_concepts}
    """

    candidates: List[RelationCandidate] = dspy.InputField()
    chunk_concepts: List["Concept"] = dspy.InputField()
    global_definitions: List["Concept"] = dspy.InputField(default=[])
    relations: List[Relation] = dspy.OutputField(
        desc="Normalized relations referencing Concept.id."
    )


class ProposeConceptMerges(dspy.Signature):
    """
    You are an expert Legal Knowledge Graph Engineer for Hebrew legal documents.

    Task:
    You receive a list of Concept objects extracted from the SAME document.
    All Concepts belong to the SAME candidate cluster
    (a small group of potentially similar concepts from the same document).
    Your job is to propose MERGES between Concepts that clearly refer to
    the same real-world entity or legal concept.

    You MUST follow these rules:

    1. Only propose a merge when you are confident that all involved Concepts
       denote the same entity/concept in this document's context.

    2. Use ALL of the following available signals:
       - prefLabel_he
       - altLabels_he
       - conceptDescription_he

    3. Prefix handling:
       - You know Hebrew prefixes (for example: ב, כ, ל, מ, ה, ו, ש) may be attached to nouns.
       - Do NOT treat differences only in these prefixes as evidence for
         different entities. Example:
           'החברה', 'בחברה', 'לחברה', 'ובחברה'
         → all may refer to the same underlying Concept.

    4. Aliases:
       - If a Concept's altLabels_he include another Concept's prefLabel_he
         (or vice versa), they almost certainly belong to the same merge group.

    5. Legal references:
       - Two Concepts may refer to the same agreement:
         e.g., 'הסכם משנת 2016', 'ההסכם משנת 2016', 'הסכם 2016'
         → likely same LegalDocument.

    6. Output format:
       - You MUST NOT invent new IDs.
       - For each merge group, choose ONE existing Concept.id as canonical_id.
       - Put ALL Concept.id values that belong to that group into merge_ids
         (including canonical_id itself).

    7. If Concepts are clearly different (different meaning, different role),
       do NOT merge them, even if they are lexically similar.
    """

    concepts: List[Concept] = dspy.InputField(
        desc="Concept objects in a single candidate cluster."
    )
    merges: List[ConceptMergeInstruction] = dspy.OutputField(
        desc="List of merge instructions. Each instruction defines one merge group."
    )


class LegalSignatureRegistry(SignatureRegistry):
    """
    Legal document signature implementations.
    
    This registry uses signatures specifically designed for Hebrew legal documents,
    focusing on work agreements, contracts, and legal definitions.
    """
    
    def get_harvest_terms_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting legal terms from Hebrew text chunks.
        
        Uses HarvestTerms which is designed to identify legal entities,
        clauses, obligations, and other legal concepts.
        """
        return HarvestTerms
    
    def get_candidates_to_concepts_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting term candidates to legal concepts.
        
        Uses CandidatesToConcepts which structures terms into legal concept
        categories with proper Hebrew/English labels and descriptions.
        """
        return CandidatesToConcepts
    
    def get_harvest_definitions_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for identifying legal definitions in contracts.
        
        Uses HarvestDefinitionCandidates which specializes in finding
        Hebrew legal definition patterns like 'להלן' and explicit definitions.
        """
        return HarvestDefinitionCandidates
    
    def get_harvest_relation_candidates_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting legal relation candidates.
        
        Uses HarvestChunkRelationCandidates which identifies relationships
        between legal entities, parties, obligations, and contract terms.
        """
        return HarvestChunkRelationCandidates
    
    def get_candidates_to_relations_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting relation candidates to final relations.
        
        Uses CandidatesToRelations which normalizes legal relationships
        and ensures proper concept ID mapping.
        """
        return CandidatesToRelations
    
    def get_harvest_relation_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for direct legal relation extraction.
        
        Uses HarvestRelation for one-step relation extraction from legal text,
        bypassing the candidate phase when appropriate.
        """
        return HarvestRelation
    
    def get_propose_concept_merges_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for proposing legal concept merges.
        
        Uses ProposeConceptMerges which identifies when different mentions
        of legal entities (parties, roles, etc.) refer to the same concept.
        """
        return ProposeConceptMerges
    
    def get_domain_name(self) -> str:
        """Returns human-readable name for this signature domain."""
        return "legal"
    
    def get_description(self) -> str:
        """Returns description of this signature domain."""
        return "Legal document processing signatures for Hebrew contracts and work agreements"