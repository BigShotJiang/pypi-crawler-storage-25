"""
Signature Registry: Abstract base class defining the interface for pluggable signature systems.

This module defines the contract that all domain-specific signature implementations
must follow to be compatible with NKGGenerator.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Type
import dspy

try:
    from ..models import Concept, Relation
except ImportError:
    from simplekg.models import Concept, Relation


class SignatureRegistry(ABC):
    """
    Base class defining the required signatures for NKGGenerator pipeline.
    
    Each domain-specific implementation (legal, rabbinic, academic, etc.) should
    inherit from this class and implement all abstract methods.
    """
    
    @abstractmethod
    def get_harvest_terms_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for term extraction from text chunks.
        
        Expected inputs: text_chunk (str)
        Expected outputs: candidates (List[TermCandidate])
        """
        pass
    
    @abstractmethod
    def get_candidates_to_concepts_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting term candidates to structured concepts.
        
        Expected inputs: text_chunk (str), candidates (List[TermCandidate])
        Expected outputs: concepts (List[Concept])
        """
        pass
    
    @abstractmethod
    def get_harvest_definitions_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for identifying definition concepts in text.
        
        Expected inputs: text_chunk (str), concepts (List[Concept])
        Expected outputs: definition_concepts (List[DefinitionMark])
        """
        pass
    
    @abstractmethod
    def get_harvest_relation_candidates_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting relation candidates from text.
        
        Expected inputs: text_chunk (str), concepts (List[Concept])
        Expected outputs: candidates (List[RelationCandidate])
        """
        pass
    
    @abstractmethod
    def get_candidates_to_relations_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting relation candidates to final relations.
        
        Expected inputs: candidates (List[RelationCandidate]), concepts (List[Concept])
        Expected outputs: relations (List[Relation])
        """
        pass
    
    @abstractmethod
    def get_harvest_relation_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for direct relation extraction (one-step approach).
        
        Expected inputs: text_chunk (str), concepts (List[Concept])
        Expected outputs: relations (List[Relation])
        """
        pass
    
    @abstractmethod
    def get_propose_concept_merges_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for proposing concept merges across subgraphs.
        
        Expected inputs: concepts (List[Concept])
        Expected outputs: merges (List[ConceptMergeInstruction])
        """
        pass

    def get_resolve_orphan_signature(self) -> Type[dspy.Signature]:
        """
        Returns a generic signature for resolving orphan concepts.

        An orphan concept was extracted from the text but has no relations to
        any other concept in the subgraph. This signature asks the LLM to find
        at least one grounded relation connecting the orphan to the others.

        Domain registries may override this method for domain-specific guidance,
        but the default implementation works across all domains.

        Expected inputs:  text_chunk (str), orphan_concept (Concept), other_concepts (List[Concept])
        Expected outputs: relations (List[Relation])
        """
        class ResolveOrphanConceptRelation(dspy.Signature):
            """
            ROLE:
              You are a Knowledge Graph expert specializing in finding missing
              relationships between concepts extracted from a text.

            TASK:
              The 'orphan_concept' was extracted from 'text_chunk' but currently
              has no relations to any other concept. Your task is to find at least
              one relation connecting it to the 'other_concepts'.

            INSTRUCTIONS:
              - Re-read the text carefully, focusing on how the orphan_concept
                is mentioned or used in context
              - Look for explicit statements, attribution frames (e.g., "as X says",
                "according to X"), implicit connections, causal links, or any
                textual evidence linking the orphan to the other concepts
              - Use camelCase English predicates
                (e.g., accordingTo, attestedBy, mentionedIn, associatedWith,
                occurredDuring, heldBy, partOf, reportedBy)
              - Prefer specific predicates over generic ones
                ('accordingTo' is better than 'relatedTo')
              - Always include evidence_text quoting the relevant span from the text
              - Use subject_id and object_id that match the 'id' fields of the
                provided Concept objects
              - If genuinely no relation can be grounded in the text, return []
                — do NOT invent relations unsupported by the text
            """
            text_chunk: str = dspy.InputField(
                desc="The source text chunk from which the concepts were extracted"
            )
            orphan_concept: Concept = dspy.InputField(
                desc="The concept that currently has no relations and needs to be connected"
            )
            other_concepts: List[Concept] = dspy.InputField(
                desc="All other concepts in this chunk, available as relation endpoints"
            )
            relations: List[Relation] = dspy.OutputField(
                desc="Relations connecting orphan_concept to one or more other_concepts, "
                     "grounded in the text"
            )

        return ResolveOrphanConceptRelation

    def get_all_signatures(self) -> Dict[str, Type[dspy.Signature]]:
        """
        Returns all signatures as a dictionary for easy access.
        
        Returns:
            Dict mapping signature names to signature classes
        """
        return {
            'harvest_terms': self.get_harvest_terms_signature(),
            'candidates_to_concepts': self.get_candidates_to_concepts_signature(),
            'harvest_definitions': self.get_harvest_definitions_signature(),
            'harvest_relation_candidates': self.get_harvest_relation_candidates_signature(),
            'candidates_to_relations': self.get_candidates_to_relations_signature(),
            'harvest_relation': self.get_harvest_relation_signature(),
            'propose_concept_merges': self.get_propose_concept_merges_signature(),
        }
    
    def get_domain_name(self) -> str:
        """
        Returns a human-readable name for this signature domain.
        
        Override in subclasses to provide domain-specific names.
        """
        return self.__class__.__name__.replace('SignatureRegistry', '').lower()
    
    def get_description(self) -> str:
        """
        Returns a description of this signature domain.

        Override in subclasses to provide domain-specific descriptions.
        """
        return f"Signature registry for {self.get_domain_name()} domain"

    def get_ontology(self) -> Optional["Ontology"]:
        """
        Returns the domain ontology for predicate and entity type normalization.

        Returns None by default — normalization is silently skipped when no
        ontology is provided. Override in domain-specific registries to enable
        ontology-based KG normalization for that domain.

        See OntologyBasedKGImplementation.md for the full design.
        """
        return None

    def get_predicate_mapping_signature(self) -> Type[dspy.Signature]:
        """
        Returns a DSPy signature for mapping free-form predicates to ontology predicates.

        Uses Option B batching: all relations sharing the same (subject_type, object_type)
        pair are sent in a single call with only the pre-filtered candidate predicates.

        The default implementation is domain-agnostic and works for any ontology.
        Domain registries may override for domain-specific prompt guidance.

        Expected inputs:
          - relations_to_map (List[str]): each formatted as
              "SubjectLabel --[free_predicate]--> ObjectLabel"
          - ontology_predicates (str): formatted predicate list from
              ontology.format_predicates_for_llm(candidates)

        Expected outputs:
          - mapped_predicate_ids (List[str]): one ontology predicate ID per input
            relation, in the same order.
        """
        class MapPredicatesToOntology(dspy.Signature):
            """
            TASK:
              Map each relation's free-form predicate to the closest ontology predicate.
              Treat each ontology predicate as a SEMANTIC CATEGORY, not an exact synonym.

            INSTRUCTIONS:
              - Read each relation as: SubjectLabel --[free_predicate]--> ObjectLabel
              - Choose the ontology predicate ID whose semantic category BEST fits,
                even if the match is approximate — "founded" maps to "ruledOver",
                "according to" maps to "referencedBy", "died in" maps to "subjectOf"
              - The "maps from" list on each predicate shows concrete raw predicates
                that belong to that category — use these as strong mapping hints
              - You MUST always choose the closest predicate; commit to a mapping
              - Use the GENERIC FALLBACK (last entry) ONLY as a last resort when the
                relation is categorically outside ALL other predicates — this should
                be rare; an imperfect match is always better than the fallback
              - Return EXACTLY one predicate ID per input relation, in the SAME ORDER
              - Output ONLY predicate IDs from the provided list — do not invent new ones
            """
            relations_to_map: List[str] = dspy.InputField(
                desc="Relations to map, each formatted as 'SubjectLabel --[free_predicate]--> ObjectLabel'"
            )
            ontology_predicates: str = dspy.InputField(
                desc="Available ontology predicates with id, description, domain/range, aliases, and examples"
            )
            mapped_predicate_ids: List[str] = dspy.OutputField(
                desc="One ontology predicate ID per input relation, in the same order as relations_to_map"
            )

        return MapPredicatesToOntology