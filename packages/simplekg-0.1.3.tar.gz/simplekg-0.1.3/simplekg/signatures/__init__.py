"""
Signature registries for NKGGenerator.

Each submodule defines a domain-specific SignatureRegistry that controls
the DSPy signatures used for that domain's KG extraction pipeline.
"""

from .signature_registry import SignatureRegistry

__all__ = ["SignatureRegistry"]
