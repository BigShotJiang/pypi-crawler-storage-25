"""
Work Agreements Signature Registry: Implementation for work agreement processing.

This module contains signature implementations specifically designed for
Hebrew work agreements and employment contracts, following the new registry structure.
"""
from __future__ import annotations
import json, re
try:
  from signature_registry import SignatureRegistry
except ImportError:
  from .signature_registry import SignatureRegistry
from pydantic import BaseModel, Field
from typing import List, Optional, Literal, Dict, Any, Type

import dspy


# Import models
try:
    from ..models import *
except ImportError:
    from simplekg.models import *


class WorkAgreementsSignatureRegistry(SignatureRegistry):
    """
    Work agreements signature implementations.
    
    This registry uses signatures specifically designed for Hebrew work agreements,
    focusing on employment contracts, legal definitions, and work-related obligations.
    """
    
    def get_harvest_terms_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting work agreement terms from Hebrew text chunks.
        """
        class HarvestWorkAgreementTerms(dspy.Signature):
            """
            You are an expert Legal Knowledge Graph Engineer for Hebrew legal texts.

            Task:
            From the given text chunk, harvest as many meaningful legal terms and entities
            as possible. Your goal is HIGH RECALL, even if some terms overlap or seem redundant.

            What to include (non-exhaustive):
            - Organizations, persons, locations, dates.
            - Types of agreements and references to specific agreements
              (e.g., 'הסכם משנת 2016', 'הסכם 68/2019', 'הסכם קיבוצי מיוחד').
            - Legal concepts and constructs (e.g., 'יחסי עבודה קיבוציים',
              'מערכת יחסי עבודה', 'זכויות העובדים', 'שמירת זכויות').
            - Clauses and headings (e.g., 'שמירת זכויות', 'תוקף ותחולה').
            - Economic / employment terms (e.g., 'השכר השעתי הקבוע', 'תנאי עבודה ראויים והוגנים').
            - References to other documents or clauses (e.g., 'סעיף 4.1 להסכם משנת 2016').

            DEFINITION LINES (VERY IMPORTANT):
            - When the text uses a pattern like:
                "TERM" – definition that includes sub-parts A, B, C...
              you must:
                1) Harvest the main TERM itself.
                2) Harvest each important sub-term inside the definition as separate candidates
                   if they are legal/financial/employment concepts that may appear elsewhere.
              - Typical sub-terms inside definitions:
                • wage components (e.g., 'דמי מחלה', 'דמי חופשה שנתית', 'תוספת ותק')
                • building blocks of formulas (e.g., 'תעריף שעתי', 'שעות עבודה רגילות')
                • references to scope (e.g., 'היקף משרה מלאה').

            Guidelines:
            - Prefer short noun phrases as span (1–5 tokens).
            - A span can be harvested even if it appears only once and only inside a definition.
            - Do NOT deduplicate: if in doubt, include the term.
            - Err on the side of over-including – better too many candidates than too few.
            """

            text_chunk: str = dspy.InputField(desc="Hebrew work agreement text segment to analyze")
            candidates: List[TermCandidate] = dspy.OutputField(
                desc="High-recall list of term candidates to be later normalized into Concepts."
            )
        
        return [HarvestWorkAgreementTerms]
    
    def get_candidates_to_concepts_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting work agreement term candidates to structured concepts.
        """
        class WorkAgreementCandidatesToConcepts(dspy.Signature):
            """
            Normalize and consolidate raw term candidates into canonical Concept objects.

            Task:
            - Group together candidates that refer to the same underlying concept.
            - For each resulting Concept:
                - prefLabel: the best, most specific canonical form in Hebrew.
                - prefLabel_en: English translation in UpperCamelCase (no punctuation).
                - altLabels: other Hebrew variants, aliases, acronyms, or longer/shorter forms.
                - altLabels_en: English variants if obvious.
                - entity_type: choose the most specific type, e.g.,
                  Organization, Person, Location, Date, LegalDocument, LegalConcept,
                  Clause, Right, Obligation, Remuneration, Event, Reference.
                - conceptDescription: short explanation of the concept in this context.

            Merging rules (generic):
            - Merge morphological variants like 'החברה', 'בחברה', 'בחברה זו' into one Concept 'החברה'.
            - Merge explicit aliases defined with 'להלן:', parentheses, or quotes into one Concept,
              putting aliases into altLabels.
            - Merge references that share the same core idea (e.g., 'הסכם משנת 2016',
              'ההסכם משנת 2016').

            IMPORTANT: Sub-terms inside definitions
            - Do NOT merge away or drop sub-terms that correspond to meaningful components
              of a definition, even if they appear only once.
              Examples (generic pattern):
                • If 'שכר' is defined using 'תעריף שעתי', 'שעות עבודה רגילות', 'דמי מחלה',
                  'דמי חופשה שנתית', each of these should normally become a separate Concept.
                • If 'שכר פנסיוני' is defined using 'היקף משרה מלאה' and 'תוספת ותק',
                  keep 'היקף משרה מלאה' and 'תוספת ותק' as separate Concepts.
            - It is acceptable (and preferred) to have both a parent concept and its components
              as separate Concept objects, each with its own entity_type (e.g., Remuneration vs LegalConcept).

            ID Generation Rules:
            - The Concept.id MUST be deterministic.
            - The id MUST be based ONLY on prefLabel or prefLabel_en.
            - Use the Hebrew prefLabel when available.
            - Allowed characters: Hebrew letters, English letters, digits, underscores.
            - ID format: Hebrew prefLabel → convert:
                * remove punctuation  
                * replace spaces with underscores  
                * remove quotes  
                * remove parentheses  
                * normalize ה/ב/ל prefixes (do NOT include them in ID)  
            - Example:
                - "בית בלב בע\"מ" → בית_בלב_בעמ
                - "הסכם קיבוצי מיוחד" → הסכם_קיבוצי_מיוחד
                - "יחסי עבודה קיבוציים" → יחסי_עבודה_קיבוציים

            Goal:
            - Preserve as many semantically meaningful Concepts as possible.
            - It is acceptable if the final list is long; favor recall over aggressive pruning.
            - Set term_id to the term_id of the primary TermCandidate this concept was derived from.
              If multiple candidates were merged, pick the most representative one.
            """

            text_chunk: str = dspy.InputField(desc="Source Hebrew work agreement text")
            candidates: List[TermCandidate] = dspy.InputField(desc="Extracted term candidates")
            concepts: List[Concept] = dspy.OutputField(
                desc="Structured work agreement concepts with Hebrew/English labels and descriptions"
            )
        
        return WorkAgreementCandidatesToConcepts
    
    def get_harvest_definitions_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for identifying definitions in work agreements.
        """
        class HarvestWorkAgreementDefinitions(dspy.Signature):
            """
            ROLE:
              You are an expert Legal Knowledge Graph Engineer for Hebrew legal documents.

            Task:
              For the given text_chunk and its detected Concept list, identify which Concepts
              are being DEFINED in this chunk (i.e., appear in a legal-definition context).

            What counts as a 'definition'?
              A concept is considered a definition concept in this chunk if the text explicitly
              introduces it and attaches a meaning, scope, or role, typically via patterns like:

              1) Explicit definition lines:
                 - "TERM" – definition...
                 - TERM – definition...
                 - TERM: definition...
                 Examples:
                   "עובד ארעי" – עובד החברה המצוי בתקופת הארעיות...
                   עובד קבוע – עובד שסיים את תקופת הארעיות...

              2) 'להלן' patterns:
                 - TERM (להלן: "ALIAS")
                 - "ALIAS" (להלן – TERM)
                 - (להלן: "TERM") right after a name.
                 These indicate that the concept (TERM or ALIAS) is being defined
                 for later use in the contract.

              3) Definition-reference phrases:
                 - כהגדרתו להלן / כהגדרתם להלן / כהגדרתו בחוזה זה / כהגדרתם בפרק זה
                 - לשם הגדרת TERM, לעניין TERM וכו'.
                 If a sentence clearly defines what TERM means in the context of the document,
                 mark TERM as a definition concept.

            Important constraints:
              - Only mark concepts that correspond to existing Concepts in the 'concepts' list.
              - Do NOT invent new concepts or new IDs.
              - You may mark multiple concepts in the same chunk as definitions.
              - Do NOT mark every mention of a concept as a definition; ONLY those in definitional contexts.

            Matching rules:
              - Match from text to Concepts using:
                  * prefLabel
                  * altLabels
                  * obvious orthographic variants (ה/ב/ל/מ/כ/ו prefixes).
              - concept_id in the output MUST be exactly one of [c.id for c in concepts].

            Output:
              - definition_concepts: list of DefinitionMark objects. Each indicates that the
                given Concept.id is explicitly defined in this chunk, with evidence_text
                showing the definitional sentence or phrase.
            """

            text_chunk: str = dspy.InputField(desc="Hebrew work agreement text to analyze")
            concepts: List[Concept] = dspy.InputField(desc="Detected concepts in this chunk")
            definition_concepts: List[DefinitionMark] = dspy.OutputField(
                desc="Concepts being defined or explained in this text"
            )
        
        return HarvestWorkAgreementDefinitions
    
    def get_harvest_relation_candidates_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting work agreement relation candidates.
        """
        class HarvestWorkAgreementRelationCandidates(dspy.Signature):
            """
            From a single legal text chunk and a list of already-detected Concepts,
            harvest HIGH-RECALL candidate relations between them (and optionally
            between them and global definition concepts).

            INPUTS:
            - text_chunk: a single Hebrew chunk from a legal document.
            - concepts: the Concept objects already extracted for THIS chunk.
            - global_definitions: Concept objects that are definitions elsewhere
              in the document (document-level), which may participate in relations
              if the text in this chunk clearly refers to them.

            GOAL:
            - Emit RelationCandidate objects that link ONLY between these Concepts
              (chunk-level concepts + relevant global definition concepts).
            - HIGH RECALL is preferred: if a relation is plausibly expressed in the text,
              you should emit it (even if some candidates are redundant).

            WORK AGREEMENT RELATIONSHIP TYPES TO IDENTIFY:
              1) **Contract Relations**:
                 - signedBy, effectiveFrom, expiresOn, amendsAgreement, cancelsClause
                 - Example: Company signed the collective agreement in 2016
              
              2) **Employment Relations**:
                 - employs, hasEmployee, governedBy, entitledTo, obligatedTo
                 - Example: Employee entitled to vacation pay under the agreement
              
              3) **Legal Structure Relations**:
                 - hasClause, definedAs, referencesDocument, hasComponent
                 - Example: Agreement has clause about wage preservation
              
              4) **Financial Relations**:
                 - paysWage, receivesPayment, calculatedUsing, basedOn
                 - Example: Wage calculated using hourly rate and seniority bonus

            GUIDELINES:
              - Use English predicate names in lowerCamelCase
              - Extract evidence text supporting each relationship
              - Focus on explicit relationships mentioned in the text
              - Handle Hebrew legal terminology and formal contract language
              - Include definitional and structural relationships
            """

            text_chunk: str = dspy.InputField(desc="Hebrew work agreement text to analyze")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts")
            candidates: List[RelationCandidate] = dspy.OutputField(
                desc="Relationship candidates between work agreement concepts"
            )
        
        return HarvestWorkAgreementRelationCandidates
    
    def get_candidates_to_relations_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting work agreement relation candidates to final relations.
        """
        class WorkAgreementCandidatesToRelations(dspy.Signature):
            """
            Normalize raw RelationCandidate objects into clean Relation objects
            whose subject_id and object_id refer to Concept.id.

            INPUT:
              - candidates: raw RelationCandidate objects (mentions + predicate).
              - concepts: Concepts local to this chunk.
              - global_definitions: Concepts that are definitions anywhere in the document.

            ENTITY POOL:
              - allowed_concepts = concepts ∪ global_definitions
              - Only these Concepts may be used as subjects/objects.

            Matching rules:
              - You are given the full list of allowed_concepts.
              - You MUST map subject_mention and object_mention ONLY to existing Concepts:
                  * Exact match of prefLabel, or
                  * Exact match to any altLabels, or
                  * Very close variant (e.g. with/without ה-, ב-, ל-, ו- prefixes).
              - subject_id and object_id MUST be taken EXACTLY from one of the Concept.id values
                in allowed_concepts.
                You are NOT allowed to invent new IDs or use labels as IDs.

            If mapping fails:
              - If you cannot confidently map a mention to a Concept (no good match),
                you MUST discard that RelationCandidate (do not produce a Relation for it).

            Predicate:
              - Use the candidate.predicate_label_en as the final predicate value.
              - Do NOT invent new predicates.

            Output:
              - relations: list of Relation objects where:
                  * relation.subject_id ∈ {c.id for c in allowed_concepts}
                  * relation.object_id  ∈ {c.id for c in allowed_concepts}
            """

            candidates: List[RelationCandidate] = dspy.InputField(desc="Relation candidates to process")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts for ID mapping")
            relations: List[Relation] = dspy.OutputField(
                desc="Final normalized relations with concept IDs"
            )
        
        return WorkAgreementCandidatesToRelations
    
    def get_harvest_relation_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for direct work agreement relation extraction.
        """
        class HarvestWorkAgreementRelation(dspy.Signature):
            """
            From a single legal text chunk and a list of already-detected Concepts,
            harvest HIGH-RECALL relations between them (and optionally
            between them and global definition concepts).

            INPUTS:
            - text_chunk: a single Hebrew chunk from a legal document.
            - concepts: the Concept objects already extracted for THIS chunk.
            - global_definitions: Concept objects that are definitions elsewhere
              in the document (document-level), which may participate in relations
              if the text in this chunk clearly refers to them.
            
            GOAL:
            - Emit Relation objects that link ONLY between these Concepts
              (chunk-level concepts + relevant global definition concepts).
            - HIGH RECALL is preferred: if a relation is plausibly expressed in the text,
              you should emit it (even if some candidates are redundant).
            
            Rules:
            - subject_id and object_id MUST be chosen ONLY from the concepts ∪ global_definitions.
            - Check EVERY PAIR of concepts for possible relations in the text.
            - Detect relations not only from explicit verbs, but also from possessives, appositions, and contextual mentions.
            - predicate MUST be in English, expressed in lowerCamelCase.
            - evidence_text:
                * A short Hebrew snippet that clearly justifies this relation.
            - If no valid triple exists, return [].
            """

            text_chunk: str = dspy.InputField(desc="Hebrew work agreement text")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts with IDs")
            relations: List[Relation] = dspy.OutputField(
                desc="Direct relationships using concept IDs"
            )
        
        return HarvestWorkAgreementRelation
    
    def get_propose_concept_merges_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for proposing work agreement concept merges.
        """
        class ProposeWorkAgreementConceptMerges(dspy.Signature):
            """
            You are an expert Legal Knowledge Graph Engineer for Hebrew legal documents.

            Task:
            You receive a list of Concept objects extracted from the SAME document.
            All Concepts belong to the SAME candidate cluster
            (a small group of potentially similar concepts from the same document).
            Your job is to propose MERGES between Concepts that clearly refer to
            the same real-world entity or legal concept.

            You MUST follow these rules:

            1. Only propose a merge when you are confident that all involved Concepts
               denote the same entity/concept in this document's context.

            2. Use ALL of the following available signals:
               - prefLabel
               - altLabels
               - conceptDescription

            3. Prefix handling:
               - You know Hebrew prefixes (for example: ב, כ, ל, מ, ה, ו, ש) may be attached to nouns.
               - Do NOT treat differences only in these prefixes as evidence for
                 different entities. Example:
                   'החברה', 'בחברה', 'לחברה', 'ובחברה'
                 → all may refer to the same underlying Concept.

            4. Aliases:
               - If a Concept's altLabels include another Concept's prefLabel
                 (or vice versa), they almost certainly belong to the same merge group.

            5. Legal references:
               - Two Concepts may refer to the same agreement:
                 e.g., 'הסכם משנת 2016', 'ההסכם משנת 2016', 'הסכם 2016'
                 → likely same LegalDocument.

            6. Output format:
               - You MUST NOT invent new IDs.
               - For each merge group, choose ONE existing Concept.id as canonical_id.
               - Put ALL Concept.id values that belong to that group into member_ids
                 (including canonical_id itself).

            7. If Concepts are clearly different (different meaning, different role),
               do NOT merge them, even if they are lexically similar.
            """

            concepts: List[Concept] = dspy.InputField(desc="All concepts to analyze for potential merges")
            merges: List[ConceptMergeInstruction] = dspy.OutputField(
                desc="Proposed concept merges with legal rationale"
            )
        
        return ProposeWorkAgreementConceptMerges
    
    def get_domain_name(self) -> str:
        """Returns human-readable name for this signature domain."""
        return "work_agreements"
    
    def get_description(self) -> str:
        """Returns description of this signature domain."""
        return "Work agreements processing signatures for Hebrew employment contracts and work-related documents"

class NormModel(BaseModel):
    # Expanded to handle nested hierarchies: Chapter > Clause > Sub-clause
    chapter_title: Optional[str] = Field(None, json_schema_extra={"e.g., 'סדרי עבודה'"})
    chapter_number: Optional[str] = Field(None, json_schema_extra={"e.g., '3'"})
    clause_number: Optional[str] = Field(None, json_schema_extra={"e.g., '14'"})
    subclause_number: Optional[str] = Field(None, json_schema_extra={"e.g., '12.1' or '1'"})
    
    # For Definitions
    term: Optional[str] = Field(None, json_schema_extra={"The defined term in Hebrew"})
    term_en: Optional[str] = Field(None, json_schema_extra={"English translation if exists"})
    
    # For Recitals (Hoils)
    recital_index: Optional[int] = Field(None, json_schema_extra={"The index of the 'והואיל' statement"})


class SignalsModel(BaseModel):
    is_hoil: bool = False  # Starts with והואיל
    is_lefikach: bool = False # The 'לפיכך' transition
    has_numbering: bool = False # e.g., 1., 1.1, (א)
    has_quoted_term: bool = False # e.g., (להלן: "החברה")
    likely_definition: bool = Field(False, json_schema_extra={"Format is 'Term' - Definition"})
    is_table_like: bool = False
    is_marginal_note: bool = Field(False, json_schema_extra={"Short heading usually above or beside a clause"})


class BlockModel(BaseModel):
    block_id: str
    type: Literal[
        "TITLE", "DATE", "PARTY", "RECITAL", "TRANSITION", # For Chapter 1
        "HEADING", "CLAUSE", "SUBCLAUSE", "DEFINITION",   # For Chapters 2-16
        "TABLE", "SIGNATURES"
    ]
    start_char: int # Relative to the chapter start or absolute? (Absolute is better for KG)
    end_char: int
    norm: NormModel # For numbers, terms, etc.
    signals: SignalsModel


class ChapterBlock(BaseModel):
    title: str = Field(..., json_schema_extra={"The Hebrew title of the section/chapter"})
    start_char: int = Field(..., json_schema_extra={"Absolute start offset in the original text"})
    end_char: int = Field(..., json_schema_extra={"Absolute end offset in the original text"})

class WADocSegmentation:
    
    def __init__(self, doc: str, model, api_key: str, temperature: float = 0.0):
        self.doc = doc
        self.init_model(model=model, temperature=temperature, api_key=api_key)
        self.doc_tree = {}

    def dump_tree(self, file_path: str):
      
        with open(file_path, "w", encoding="utf-8") as f:
          json.dump(self.doc_tree, f, ensure_ascii=False, indent=2)

    def load_tree(self, file_path: str):
        with open(file_path, "r", encoding="utf-8") as f:
          self.doc_tree = json.load(f)
    

    def init_model(self, model: str = None, temperature: float = None, api_key: str = None, max_tokens: int = 15000):
      if model is not None:
          self.model = model
      if temperature is not None:
          self.temperature = temperature
      if api_key is not None:
          self.api_key = api_key

      self.max_tokens = max_tokens
    
      if self.api_key:
          self.lm = dspy.LM(model=self.model, api_key=self.api_key, temperature=self.temperature, max_tokens=self.max_tokens)
      else:
          self.lm = dspy.LM(model=self.model, temperature=self.temperature, max_tokens=self.max_tokens)
    
      dspy.configure(lm=self.lm)


    def _complete2break(self, doc, pos, increment = 1, delimiter="line", limit=80):
        """
        increment:  1 - detect end of block, -1 - detect beggining of block
        """
        if delimiter == "line":
            break_chars = ["\n", "\r"]
        else:
            break_chars = ["\n", "\r", " ", ".", ";"]
        if doc[pos] in break_chars:
            return pos
        for i in range(1,limit):
            if doc[pos + (i*increment)] in break_chars:
                return pos + (i*increment)
        
        return pos
    
    def detect_headers(self):
        class _MapAgreementChapters(dspy.Signature):
            """
            STRICT STRUCTURAL MAPPER:
            Partition the entire document into logical chapters.
            
            HARD CONSTRAINTS:
            1. START AT ZERO: The first chapter MUST start at start_char=0 (Introduction/Parties).
            2. NO GAPS: The end_char of one chapter must be the start_char of the next.
            3. FULL COVERAGE: The final end_char must match the length of the document.
            4. TITLES: Use 'מבוא וצדדים' for the first section if it lacks a formal header.
            """
            text: str = dspy.InputField()
            chapters: List[ChapterBlock] = dspy.OutputField() 

        
        class MapAgreementChapters(dspy.Signature):
            """
            STRICT STRUCTURAL MAPPER:
            Partition the entire document into logical chapters by identifying both 
            explicit and implicit structural anchors.
        
            ANCHOR PATTERNS TO DETECT:
            1. EXPLICIT: 'חלק' (Part), 'פרק' (Chapter), or 'תוספת' (Appendix) followed by a number or Hebrew letter.
            2. IMPLICIT/ALPHANUMERIC: Lines starting with a digit OR a Hebrew letter followed by a period 
               (e.g., '1.', '2.', 'א.', 'ב.') and a short thematic title.
            3. THEMATIC: Short, standalone bolded or underlined lines that introduce a new topic.
        
            HARD CONSTRAINTS:
            1. START AT ZERO: The first block MUST start at offset 0 (Preamble/Parties).
            2. NO GAPS: Every character must be covered. end_char of Block N = start_char of Block N+1.
            3. FULL COVERAGE: The final block's end_char must equal the total text length.
            4. HEADER INCLUSION: The start_char of a chapter must be the exact beginning of its header line.
            """
            text: str = dspy.InputField(desc="The full agreement text.")
            chapters: List[ChapterBlock] = dspy.OutputField(desc="Exhaustive list of chapters with absolute offsets.")

        detector = dspy.Predict(MapAgreementChapters)
        out = detector(text=self.doc)

        self.doc_tree = {idx:{"header": x.model_dump(),
                              "content": self.doc[self._complete2break(self.doc, x.start_char, -1): self._complete2break(self.doc, x.end_char, 1)],
                              "blocks": []} for idx,x in enumerate(out.chapters)}
        

        
        # for idx,x in enumerate(out.chapters):
        #     x.start_char = self._complete2break(self.doc, x.start_char, -1) # Beggining of the line
        #     x.end_char = self._complete2break(self.doc, x.end_char, 1) # Enf of the line
        #     nh = {"header": x, "content": self.doc[x.start_char: x.end_char], blocks": []}
        #     self.doc_tree[idx] = nr
        
    def detect_legal_blocks(self, chapter: ChapterBlock ):
    
        class DetectLegalBlocks(dspy.Signature):
            """
            GRANULAR LEGAL PARSER:
            Break the provided text segment (a chapter) into its smallest indivisible legal units.
        
            CONSTRAINTS:
            1. NO FRAGMENTATION: Never split a sentence in half. A block must end at a terminal punctuation (; or .).
            2. SUB-POINTS: If a clause has sub-points (e.g., 12.1, 12.2), each sub-point is its own SUBCLAUSE block.
            3. DEFINITIONS: In the 'הגדרות' chapter, each term and its explanation is a single DEFINITION block.
            4. TABLES: If you see a list of wages or dates (like in 'תנאי עבודה'), mark the entire structure as a TABLE.
            5. RECITALS: In the first chapter, every 'והואיל' is a RECITAL.
            6. HIERARCHY: For SUBCLAUSEs, always identify the 'parent_clause' number in the metadata.
            """
            chapter_title: str = dspy.InputField(desc="Context for the current segment")
            text: str = dspy.InputField(desc="The text segment of this specific chapter")
            blocks: List[BlockModel] = dspy.OutputField()

        segment = self.doc[chapter.start_char:chapter.end_char]
        detector = dspy.ChainOfThought(DetectLegalBlocks)
        out = detector(chapter_title=chapter.title, text=segment)
        
        return  out.blocks 

    def detect_headers_internal(self):
        final_agreement_structure = []

        for ck in self.doc_tree:
            chapter_dict = self.doc_tree[ck]['header']
            # Reconstruct ChapterBlock object from dict for detect_legal_blocks
            chapter = ChapterBlock(**chapter_dict)
            blocks = self.detect_legal_blocks(chapter)

            nblocks = []
            for block in blocks:
                block.start_char += chapter.start_char
                block.end_char += chapter.start_char
            
                block_dict = block.model_dump() 
                
                block_start = self._complete2break(self.doc, block.start_char, -1)
                block_end = self._complete2break(self.doc, block.end_char, 1)
                block_dict["text"] = self.doc[block_start:block_end]
                
                nblocks.append(block_dict)
            
            self.doc_tree[ck]['blocks'] = nblocks

    def pipeline(self):
        self.detect_headers()
        self.detect_headers_internal()
        


@dataclass
class TocNode:
    node_id: str                 # "5", "5(d)", "5(d)(2)(b)"
    depth: int                   # 0,1,2...
    parent_id: Optional[str]     # None for root-level
    start_char: int
    end_char: int
    raw_heading: Optional[str] = None  # if present
    title: Optional[str] = None
    one_sentence_summary: Optional[str] = None
    function_label: Optional[str] = None  # ELIGIBILITY/DEFINITION/PROCEDURE/EXCEPTION/...

  
import re
import json
from typing import List, Optional, Dict, Any

class LegalDocSegmentation:
  
    def __init__(self, doc: str, model: str, api_key: Optional[str] = None, temperature: float = 0.0, max_tokens: int = 15000):
        self.doc = doc
        self.doc_tree: Dict[str, Any] = {}
        self.nodes: List[TocNode] = []
        self.init_model(model=model, temperature=temperature, api_key=api_key, max_tokens=max_tokens)

    def dump_tree(self, file_path: str):
        payload = {
            "nodes": [asdict(n) for n in self.nodes]
        }
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

    def load_tree(self, file_path: str):
        with open(file_path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        self.nodes = [TocNode(**n) for n in payload["nodes"]]

    def init_model(self, model: str, temperature: float, api_key: Optional[str], max_tokens: int):
        self.model = model
        self.temperature = temperature
        self.api_key = api_key
        self.max_tokens = max_tokens
        if api_key:
            self.lm = dspy.LM(model=model, api_key=api_key, temperature=temperature, max_tokens=max_tokens)
        else:
            self.lm = dspy.LM(model=model, temperature=temperature, max_tokens=max_tokens)
        dspy.configure(lm=self.lm)

    # --------------------------
    # Public pipeline entrypoint
    # --------------------------
    def detect_toc(self, annotate_with_llm: bool = True):
        """
        Build TOC in two phases:
        A) deterministic structure extraction (ids, nesting, spans)
        B) optional LLM annotation per node
        """
        self.nodes = self._extract_structure_rule_based(self.doc)
        self._compute_spans(self.doc, self.nodes)

        self._validate_tree(self.nodes)

        if annotate_with_llm:
            self._annotate_nodes_with_llm(self.nodes)

        # Optionally also build nested dict tree:
        self.doc_tree = self._nodes_to_tree(self.nodes)
        return self.doc_tree
    