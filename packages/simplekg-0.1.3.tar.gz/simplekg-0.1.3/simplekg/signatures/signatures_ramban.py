"""
Rabbinic Signature Registry: Implementation for rabbinic literature processing.

This module contains signature implementations specifically designed for
Hebrew rabbinic texts, talmudic literature, and Jewish scholarly works.
"""

from .signature_registry import SignatureRegistry
from typing import Type, List, Callable
import dspy

# Import the models we'll use
try:
    from ..models import *
except ImportError:
    from simplekg.models import *


class RabbinicSignatureRegistry(SignatureRegistry):
    """
    Rabbinic literature signature implementations.
    
    This registry uses signatures specifically designed for Hebrew rabbinic texts,
    focusing on halakhic concepts, biblical references, talmudic discussions,
    and rabbinical authorities.
    """
    
    def get_text_preprocessing_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for punctuation-only preprocessing of Hebrew rabbinic text.
        """
        class RabbinicTextPreprocessing(dspy.Signature):
            """
            ROLE:
            You are an expert in Hebrew rabbinic literature and historical text editing.

            TASK (STRICT):
            Given a raw Hebrew rabbinic text, ADD ONLY punctuation and syntactic separators
            to improve readability.

            ABSOLUTE CONSTRAINTS (MUST FOLLOW):
            - DO NOT change, remove, replace, or normalize ANY word.
            - DO NOT expand abbreviations (e.g., אמ', ר"ל, וכו').
            - DO NOT modernize spelling or grammar.
            - DO NOT reorder words.
            - DO NOT add or remove letters.
            - You MAY ONLY:
                * add punctuation marks (.,:;—?!)
                * add paragraph breaks or line breaks
                * add spaces around punctuation if needed

            INVARIANCE RULE:
            - If all punctuation marks are removed from the output,
                the remaining Hebrew letters and spaces MUST be IDENTICAL
                to the input text (character-by-character).

            GOAL:
            Improve readability ONLY through punctuation and syntactic separation,
            without altering language, content, or wording in any way.

            OUTPUT:
            - The same text, with punctuation added.
            """

            raw_text: str = dspy.InputField(
                desc="Raw Hebrew rabbinic text WITHOUT punctuation normalization."
            )

            preprocessed_text: str = dspy.OutputField(
                desc="Same Hebrew text with punctuation added ONLY (no word changes)."
            )

        return RabbinicTextPreprocessing


    def get_harvest_terms_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting rabbinic terms from Hebrew text chunks.
        """
        
        

        class HarvestBiblicalQuotationsTerms(dspy.Signature):
            """
            ROLE:
            You are an expert Tanakh scholar and a Knowledge Graph Engineer specializing
            in detecting biblical quotations (פסוקי מקרא) in Hebrew rabbinic texts.

            TASK:
            Given a Hebrew text_chunk, extract ALL spans that are direct or near-direct
            quotations from the Tanakh. Your goal is MAXIMAL RECALL.

            OUTPUT FOR EACH quotation:
            A TermCandidate with:
                - span:       exact quoted phrase as it appears in the text
                - coarse_type: "BiblicalQuotation"
                - context:   The full quotation context, including Book, Chapter, and Verse numbers

            ----------------------------------------------------------------------
            WHAT COUNTS AS A BIBLICAL QUOTATION?
            ----------------------------------------------------------------------
            A span in the text should be marked as a biblical quotation if it fits
            ANY of the following:

            1) **Direct citation of biblical wording**
            Examples:
                "וידבר ה' אל משה לאמר"
                "בראשית ברא אלהים"

            2) **Near-direct wording with minor grammatical changes**
            - small changes in prefixes/suffixes are still quotations
                e.g., "אל הארון תתן" ← quotation even without exact niqqud

            3) **Quoted verse fragments**
            - even if the whole verse is not quoted, include the fragment:
                e.g., "פורשי כנפים למעלה"
                    "מעל הכפרת מבין שני הכרובים"

            4) **Quotation followed by ellipsis**
            - If text includes:
                "ונתת אל הארון את העדות..."
                the quoted part *before* "..." is the span.

            ----------------------------------------------------------------------
            EXTRACTION GUIDELINES
            ----------------------------------------------------------------------
            - Prefer the EXACT wording in the text as span.
            - Include multi-word quotations (typically 2–8 words).
            - Do NOT include:
                • simple nouns alone (e.g., כרובים, כנפים) — unless part of a verse.
                • paraphrase without recognizable biblical syntax.
            - Overlapping quotations are allowed.
            - You may output multiple candidates if the verse appears twice.

            ----------------------------------------------------------------------
            HOW TO DETECT QUOTATIONS (you MUST use these signals):
            ----------------------------------------------------------------------
            - Biblical syntactic patterns such as:
                • ויאמר / וידבר / ויצו / ויתן / ונתת / תתן
                • אל הארון / על הארון / מבין שני הכרובים
                • למעלה / מלמעלה / מעל הכפרת
            - Direct citation markers:
                • "___"
                • פסוק appears followed by ellipsis "..."
                • prefixed with כי נאמר / שכבר נאמר / שהרי נאמר
            - Known quotation introductions:
                • "כבר אמור:"
                • "שנאמר"
                • "הכתוב אומר"

            ----------------------------------------------------------------------
            OUTPUT RULES:
            ----------------------------------------------------------------------
            For EACH identified quotation, output:

            TermCandidate(
                span = <exact Hebrew quoted phrase>,
                coarse_type = "BiblicalQuotation",
                context = The full quotation context, including Book, Chapter, and Verse numbers
            )

            - DO NOT deduplicate; repeated quotations produce multiple candidates.
            - DO NOT merge quotations with other term types.
            - Ensure the span is exactly from the original text.
            """

            text_chunk: str = dspy.InputField(
                desc="A Hebrew text chunk that may contain biblical quotations."
            )

            candidates: List[TermCandidate] = dspy.OutputField(
                desc="List of extracted biblical quotation spans as TermCandidate objects."
            )


        class HarvestRabbinicTerms(dspy.Signature):
            """
            ROLE:
            You are an expert Jewish Studies scholar and Knowledge Graph Engineer
            specializing in Hebrew rabbinic and kabbalistic literature.

            CONTEXT (OPTIONAL):
            You may be given an optional doc_context describing the broader setting of the chunk
            (e.g., "Ibn Shu‘ib commenting on Ramban on Exodus").
            - If doc_context is provided (non-empty), use it ONLY to disambiguate terms.
            - If doc_context is empty/None, rely ONLY on the text_chunk.
            - Do NOT invent or assume context that is not explicitly provided.

            TASK:
            Given a Hebrew text chunk (a commentary on Ramban on the Torah),
            harvest as many meaningful terms/concepts as possible.
            Your goal is HIGH RECALL (prefer too many candidates over missing important ones).

            FOR EACH harvested term you MUST output a TermCandidate with:
            - span: the exact Hebrew span as it appears in the text.
            - usage_count: the number of times this terms/concept appears in the text chunk.
            - coarse_type:  one of the categories below (exact spelling).
            - context: a short surrounding excerpt to help disambiguate the span.

            CATEGORIES TO IDENTIFY (coarse_type values):

            1) BiblicalFigure
                - Names of biblical characters:
                e.g., אברהם, יצחק, יעקב, משה, דוד המלך, שלמה, אסתר.

            2) RabbinicAuthority
                - Names and titles of Rabbis/sages/commentators from all periods:
                e.g., רש"י, רמב"ם, הרמב"ן, הבעש"ט, האר"י, רבי עקיבא.

            3) HalakhicConcept
                - Halakhic / legal concepts, categories, and institutions:
                e.g., כשרות, שבת, עירוב, תפילה, מוקצה, נדר, פסק הלכה.

            4) BiblicalSource
                - Names of biblical books and structured references:
                e.g., בראשית, שמות, תהילים, ישעיהו, פסוקים מצוטטים עם ציון פרק/פסוק.

            5) BiblicalQuotation
                - Verbatim (or near-verbatim) quoted biblical phrases/verses as they appear in the text.
                - The span should be the quoted phrase itself (not “כדכתיב/שנאמר”).

            6) TalmudicSource
                - Names of tractates and Talmudic units:
                e.g., בבא מציעא, ברכות, שבת דף י עמוד ב, משנה, תוספתא.

            7) MidrashicOrRabbinicWork
                - Names of midrashim and rabbinic works:
                e.g., בראשית רבה, ויקרא רבה, תנחומא, ספר החינוך, שו"ת איגרות משה.

            8) KabbalisticWork
                - Names of explicitly kabbalistic books:
                e.g., ספר הזוהר, עץ חיים, פרי עץ חיים, שער הכוונות.

            
            9) KabbalisticConcept
                - Kabbalistic ideas and structures:
                e.g., עשר ספירות, ספירת חסד, ספירת גבורה, עולמות (אצילות, בריאה, יצירה, עשיה),
                        פרצופים, צמצום, אור אין סוף, רשימו.

            10) SpiritualEntity
                - Spiritual beings or entities:
                    e.g., שכינה, מלאכים, סיטרא אחרא, כרובים (כאובייקט רוחני/מלאכי),
                        נשמה, רוח, נפש (when used as abstract entities).

            11) TheologicalConcept
                - Abstract theological/divine attributes and metaphysical notions (even if not “Kabbalah”):
                כבוד, קדושה, טומאה/טהרה (כאידיאות), השגחה, מידות (דין/רחמים),
                רצון, חטא, תיקון (כאידיאה), etc.


            12) PhysicalObject
                - Concrete ritual / sacred / cultic objects mentioned in the text:
                    e.g., בית המקדש, משכן, מנורה, מזבח, ארון הברית, תפילין, מזוזה,
                        ספר תורה (as a physical scroll), בגדי כהונה.
                - ALL physical sub-parts when they carry symbolic meaning.
                You SHOULD harvest both.

            13) ReligiousPractice
                - Rituals, ceremonies, and minhagim:
                    e.g., ברית מילה, בר מצוה, ספירת העומר, תקיעת שופר, הדלקת נרות.

            14) Place
                - Geographic locations relevant to Jewish history and tradition:
                    e.g., ירושלים, צפת, בבל, ספרד, רומי, ארץ ישראל, גלות בבל.

            15) HistoricalEventOrPeriod
                - Historical periods or events:
                    e.g., יציאת מצרים, מתן תורה, חורבן בית המקדש, גלות בבל,
                        גזירות ת"ט–ת"ט, השואה.

            16) CommentaryTypeOrMethod
                - Types of rabbinic commentary or interpretive mode:
                    e.g., פשט, דרש, רמז, סוד, פרשנות, פירוש, לשון המהר"ל על אתר.

            17) LegalReference
                - Halakhic / legal references and norms:
                    e.g., הלכה למעשה, מנהג המקום, פסק דין, תקנה, גזירה.

            18) TraditionOrAttribution
                    - Attributions to tradition/sources (when meaningful as KG nodes):
                    “אמרו חז״ל”, “קבלה בידינו”, “מסורת”, “רבותינו אמרו”, etc.
                    - Prefer naming the specific source/work when present; use this when it is generic.


            19) Book
                - General category for sefarim and works not covered by other more specific types:
                    e.g., מסילת ישרים, תניא, משנה תורה, שולחן ערוך, ספר חסידים.
                - Prefer MidrashicOrRabbinicWork or KabbalisticWork when clearly appropriate.
                    Use Book when the genre is mixed or not clearly identified.

            20) OtherConcept
                - Important concepts that do not fit above, but are clearly KG-worthy.

            EXTRACTION INSTRUCTIONS (HIGH RECALL):

            - ALLWAYS use spans as they appear in the Hebrew text (span).
            - Prefer meaningful multi-word phrases over isolated single words
                when they form a natural unit (e.g., "בית המקדש", not רק "בית"), 
                BUT do NOT skip important base forms.
            - VARIANT COVERAGE (MANDATORY):
                If a salient entity appears in multiple surface forms, you MUST extract
                EACH distinct surface span found in the text as its own TermCandidate,
                even if they refer to the same underlying concept.
                This includes:
                * with/without definite article ה־ (מפלגה / המפלגה)
                * plural/possessive (מפלגה / מפלגותיו)
                * prepositional prefixes ל־ב־כ־מ־ (למפלגה / במפלגה ...)
                * construct phrases (מפלגת העבודה, יושב המפלגה, נושאי המפלגה)
                Example: if the text contains מפלגה, המפלגה, למפלגה, יושב המפלגה,
                you must output ALL of them as separate spans.
            - Do NOT deduplicate; repeated spans may appear multiple times.
            - Always assign coarse_type using the list above.
            - context should be a short surrounding snippet that helps a human
                understand how the term is used here (one clause or sentence is enough).

            - Harvest:
                (A) Physical/concrete biblical objects + sub-parts + acting figures + locations.
                (B) Abstract/spiritual/metaphysical terms, with special attention to Kabbalah.
                (C) References to persons, books/works, traditions, midrashim, and explicit citations.
                (D) BiblicalQuotation spans (quoted phrases) when present.
           
           
            
            """

            text_chunk: str = dspy.InputField(desc="Hebrew rabbinic or kabbalistic text segment to analyze")
            doc_context: str = dspy.InputField(
                            desc="Optional broader context (source/author/work). Empty string if unavailable."
                        )
            candidates: List[TermCandidate] = dspy.OutputField(
                desc="List of important rabbinic terms and concepts with their categories and context"
            )

        # Try to split the harvesting into multiple signatures for better focus
        # 1) Physical / concrete biblical entities (HIGH RECALL for objects, parts, figures, places)
        class HarvestPhysicalBiblicalTerms(dspy.Signature):
            """
            ROLE:
            You are an expert Jewish Studies scholar and Knowledge Graph Engineer.

            CONTEXT (OPTIONAL):
            You may be given an optional doc_context describing the broader setting of the chunk
            (e.g., "Ibn Shu‘ib commenting on Ramban on Exodus").
            - If doc_context is provided (non-empty), use it ONLY to disambiguate terms.
            - If doc_context is empty/None, rely ONLY on the text_chunk.
            - Do NOT invent or assume context that is not explicitly provided.

            TASK (HIGH RECALL):
            Extract ONLY concrete / physical / narrative entities from the Hebrew text chunk:
            - biblical/cultic physical objects (and meaningful sub-parts)
            - acting figures (biblical characters)
            - places (geographic or cultic locations)
            Prefer meaningful multi-word spans.

            OUTPUT (TermCandidate schema):
            - span: exact Hebrew span from the text (copy verbatim)
            - coarse_type: MUST be one of {PhysicalObject, BiblicalFigure, Place}
            - context: short surrounding snippet (clause/sentence)

            EXTRACTION RULES:
            - Always keep spans exactly as they appear (no normalization here).
            - Include BOTH main objects and meaningful sub-parts when present:
                e.g., "הכרובים" AND "כנפים" / "פורשי כנפים" ; "הכפרת" AND "כפרת עם כרוביו".
            - Prefer noun phrases: 1–6 words (allow up to ~10 for object phrases).
            - Do NOT deduplicate; repeated spans may appear multiple times.
            - Do not output abstract ideas, methods, or citations (those are handled elsewhere).
            """
            text_chunk: str = dspy.InputField(desc="Hebrew text segment")
            doc_context: str = dspy.InputField(
                            desc="Optional broader context (source/author/work). Empty string if unavailable."
                        )
            candidates: List[TermCandidate] = dspy.OutputField(desc="Concrete entities: objects/figures/places")

        # 2) Biblical quotations only (HIGH RECALL for verse-like spans)
        
        # 3) Abstract/kabbalistic + sources/works/attributions (HIGH RECALL for metaphysics + references)
        class HarvestAbstractConceptsAndReferencesTerms(dspy.Signature):
            """
            ROLE:
            You are an expert Jewish Studies scholar focusing on abstract theology/kabbalah
            and bibliographic/source references in rabbinic texts.

            CONTEXT (OPTIONAL):
            You may be given an optional doc_context describing the broader setting of the chunk
            (e.g., "Ibn Shu‘ib commenting on Ramban on Exodus").
            - If doc_context is provided (non-empty), use it ONLY to disambiguate terms.
            - If doc_context is empty/None, rely ONLY on the text_chunk.
            - Do NOT invent or assume context that is not explicitly provided.

            TASK (HIGH RECALL):
            Extract ONLY:
                (A) Abstract / spiritual / metaphysical concepts (especially kabbalistic)
                (B) References to authorities, works, sources, traditions, and attributions

            OUTPUT (TermCandidate schema):
            - span: exact Hebrew span from the text (copy verbatim)
            - coarse_type: MUST be one of the allowed values below
            - context: short surrounding snippet (clause/sentence)

            ALLOWED coarse_type VALUES FOR THIS SIGNATURE:
            - KabbalisticConcept
            - TheologicalConcept
            - SpiritualEntity
            - RabbinicAuthority
            - MidrashicOrRabbinicWork
            - KabbalisticWork
            - TalmudicSource
            - BiblicalSource
            - TraditionOrAttribution
            - Book
            - CommentaryTypeOrMethod
            - LegalReference
            - OtherConcept  (only if clearly KG-worthy and none of the above fit)

            EXTRACTION RULES:
            - Copy spans exactly as they appear (no normalization here).
            - Abstract/metaphysical focus examples:
                שכינה, כבוד, מרכבה, דין, רחמים, תפארת, קדושה, טומאה/טהרה (as ideas), וכו'.
            - Reference focus examples:
                names like רש"י/רמב"ן, works like "בראשית רבה", source refs like "שמות", "ברכות",
                generic attributions like "אמרו חז״ל", "קבלה בידינו".
            - Prefer meaningful multi-word phrases (2–6 words), but allow longer for titles.
            - Do NOT output physical objects, places, or biblical figures (handled elsewhere).
            - Do NOT output BiblicalQuotation spans (handled elsewhere).
            - Do NOT deduplicate.
            """
            text_chunk: str = dspy.InputField(desc="Hebrew text segment")
            doc_context: str = dspy.InputField(
                            desc="Optional broader context (source/author/work). Empty string if unavailable."
                        )
            candidates: List[TermCandidate] = dspy.OutputField(desc="Abstract concepts + references")

        # return [HarvestPhysicalBiblicalTerms, HarvestBiblicalQuotationsTerms,
        #         HarvestAbstractConceptsAndReferencesTerms]

        return [HarvestRabbinicTerms, HarvestBiblicalQuotationsTerms]
    
    def get_candidates_to_concepts_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting rabbinic term candidates to structured concepts.
        """
        class RabbinicCandidatesToConcepts(dspy.Signature):
            """
            ROLE:
            You are an expert in Jewish Studies, kabbalistic, and Hebrew linguistic analysis,
            specializing in creating structured knowledge representations of rabbinic literature.

            TASK:
            Convert EACH TermCandidate into exactly ONE Concept object.
            The output list length MUST equal the input candidates length.

            OUTPUT SCHEMA (MUST FOLLOW EXACTLY):
            Each Concept MUST include these fields:
            - id, prefLabel, prefLabel_en, altLabels, altLabels_en,
                conceptDescription, conceptDescription_en, entity_type,
                source_instance_ids, concept_position, definition, term_id

            IMPORTANT:
            - Use `entity_type` (NOT `coarse_type`). Do NOT output `coarse_type` in Concepts.

            CONCEPT CREATION GUIDELINES:
            1) Standardize Names: Use canonical Hebrew forms (רמב"ם not רבי משה בן מימון)
            2) Entity Types: set Concept.entity_type exactly equal to TermCandidate.coarse_type.
            3) Hebrew Descriptions: explain the concept’s significance and its role in THIS text chunk.
            4) Alternative Labels:
                - If prefLabel != candidate.span: altLabels=[candidate.span]
                - Else: altLabels=[]
                - altLabels_en are translations of altLabels (usually []).
            5) English: prefLabel_en + conceptDescription_en must always be present.
            6) concept_position: always -1.
            7) term_id: set to the term_id of the TermCandidate this concept was derived from.


            ID RULES:

            - Generate deterministic IDs using snake_case. 
                    # For coarse_type == "BiblicalQuotation" use  the term's context (The full quotation context)
                    # Otherwise use the Hebrew prefLabel

            - For entity_type == "BiblicalQuotation":
                * Use bq_Book_Chapter_Verse ONLY if it exists in the candidate.context .
                * Otherwise use "bq_" + deterministic 12-char hash of candidate.span.
            - For all other types:
                * Generate deterministic IDs using snake_case from the Hebrew prefLabel. If snake_case would be empty/illegal, use he_ + 12-char hash.
                

            CONSTRAINTS:
            - Concepts must be distinct and non-overlapping.
            - Include only concepts that appear in or are directly referenced by the text.
            """

            text_chunk: str = dspy.InputField(desc="Source Hebrew rabbinic text")
            candidates: List[TermCandidate] = dspy.InputField(desc="Extracted term candidates")
            concepts: List[Concept] = dspy.OutputField(desc="Structured rabbinic concepts")



        return RabbinicCandidatesToConcepts
    
    def get_harvest_definitions_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for identifying definitions in rabbinic texts.
        """
        class HarvestRabbinicDefinitions(dspy.Signature):
            """
            ROLE:
              You are an expert in rabbinic literature and Jewish textual analysis.

            TASK:
              Identify concepts that are being explicitly defined or explained in this
              Hebrew rabbinic text chunk.

            WHAT COUNTS AS A RABBINIC DEFINITION:
              1) **Explicit Definitions**: 
                 - פירוש המילה... (explanation of the word...)
                 - כוונת הענין... (the meaning is...)
                 - הכוונה ב... (the intention in...)
              
              2) **Commentary Patterns**:
                 - רש"י: [explanation] (Rashi's explanation)
                 - פירוש: [definition] (commentary/interpretation)
                 - ביאור: [clarification] (clarification/explanation)
              
              3) **Halakhic Definitions**:
                 - הלכה: [legal ruling] (halakhic ruling)
                 - דין זה... (this law...)
                 - מנהג זה... (this custom...)
              
              4) **Textual Explanations**:
                 - פסוק זה אומר... (this verse says...)
                 - כוונת התלמוד... (the Talmud's intention...)

            CONSTRAINTS:
              - Only mark concepts from the provided concepts list
              - Focus on definitional/explanatory contexts, not mere mentions
              - Consider both explicit definitions and implicit explanations
            """
            
            text_chunk: str = dspy.InputField(desc="Hebrew rabbinic text to analyze")
            concepts: List[Concept] = dspy.InputField(desc="Detected concepts in this chunk")
            definition_concepts: List[DefinitionMark] = dspy.OutputField(
                desc="Concepts being defined or explained in this text"
            )
        
        return HarvestRabbinicDefinitions
    
    def get_harvest_relation_candidates_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting rabbinic relation candidates.
        """
        class HarvestRabbinicRelationCandidates(dspy.Signature):
            """
            From a single rabbinic and kabbalistic text chunk and a list of already-detected Concepts,
            harvest HIGH-RECALL candidate relations between them (and optionally
            between them and global definition concepts).

            INPUTS:
            - text_chunk: a single Hebrew chunk from a commentary on Ramban on the Torah.
            - concepts: the Concept objects already extracted for THIS chunk.
            - global_definitions: Concept objects that are definitions elsewhere
              in the document (document-level), which may participate in relations
              if the text in this chunk clearly refers to them.


            ROLE:
              You are an expert in Jewish Studies and knowledge graph construction
              for Hebrew rabbinic literature.

            TASK:
              Extract ALL relationships between concepts in this Hebrew rabbinic text.

            RELATIONSHIP TYPES TO IDENTIFY:
              1) **Commentary Relations**:
                 - commentedOn, interpretedBy, explainedBy
                 - Example: רש"י פירש את הפסוק
              
              2) **Authority Relations**:
                 - taughtBy, studentOf, citedBy, disagreedWith
                 - Example: הרמב"ם למד מהרב אלפסי
              
              3) **Textual Relations**:
                 - appearsIn, discussedIn, derivedFrom, basedOn
                 - Example: הלכה זו מופיעה בבבא מציעא
              
              4) **Conceptual Relations**:
                 - relatedTo, oppositeOf, partOf, includes
                 - Example: שבת כוללת את המלאכות האסורות
              
              5) **Historical Relations**:
                 - livedDuring, occurredAt, establishedBy
                 - Example: רבי עקיבא חי בתקופת חורבן בית שני
              
              6) **Halakhic Relations**:
                 - permits, forbids, requires, invalidates
                 - Example: הכהן מקדש את הקרבן

            GUIDELINES:
              - Use English predicate names in CamelCase
              - Extract evidence text supporting each relationship
              - Focus on explicit relationships mentioned in the text
              - Include both direct statements and implied relationships
            """
            
            text_chunk: str = dspy.InputField(desc="Hebrew rabbinic text to analyze")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts")
            candidates: List[RelationCandidate] = dspy.OutputField(
                desc="Relationship candidates between rabbinic concepts"
            )
        
        return HarvestRabbinicRelationCandidates
    
    def get_candidates_to_relations_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting rabbinic relation candidates to final relations.
        """
        class RabbinicCandidatesToRelations(dspy.Signature):
            """
            ROLE:
              You are an expert in Jewish Studies knowledge representation and
              ontology design for rabbinic literature.

            TASK:
              Convert relation candidates into final, normalized relations by mapping
              Hebrew mentions to concept IDs and standardizing predicates.

            PREDICATE STANDARDIZATION:
              - Use PascalCase English predicates (CommentedOn, TaughtBy, AppearsIn)
              - Ensure predicates are consistent across similar relationships
              - Map Hebrew relationship expressions to canonical English predicates

            VALIDATION:
              - Ensure both subject and object concepts exist in the concept list
              - Verify that the relationship makes sense in the rabbinic context
              - Include evidence text to support the relationship claim
              - Remove duplicate or conflicting relationships

            CONSTRAINTS:
              - Only create relations where both concepts are available
              - Use deterministic concept IDs that match the Concept.id field
              - Maintain evidence text for scholarly verification
            """
            
            candidates: List[RelationCandidate] = dspy.InputField(desc="Relation candidates to process")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts for ID mapping")
            
            relations: List[Relation] = dspy.OutputField(
                desc="Final normalized relations with concept IDs"
            )
        
        return RabbinicCandidatesToRelations
    
    def get_harvest_relation_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for direct rabbinic relation extraction.
        """
        class HarvestRabbinicRelation(dspy.Signature):
            """
            From a single rabbinic and kabbalistic text chunk and a list of already-detected Concepts,
            harvest HIGH-RECALL candidate relations between them (and optionally
            between them and global definition concepts).

            INPUTS:
            - text_chunk: a single Hebrew chunk from a commentary on Ramban on the Torah.
            - concepts: the Concept objects already extracted for THIS chunk.
            - global_definitions: Concept objects that are definitions elsewhere
              in the document (document-level), which may participate in relations
              if the text in this chunk clearly refers to them.

            
            ROLE:
              You are an expert in Jewish Studies and Hebrew textual analysis,
              specializing in direct relationship extraction from rabbinic texts.
              From a single rabbinic and kabbalistic text chunk and a list of already-detected Concepts,
              harvest HIGH-RECALL candidate relations between them (and optionally
              between them and global definition concepts).

            INPUTS:
                - text_chunk: a single Hebrew chunk from a legal document.
                - concepts: the Concept objects already extracted for THIS chunk.
                - global_definitions: Concept objects that are definitions elsewhere
                in the document (document-level), which may participate in relations
                if the text in this chunk clearly refers to them.
                
            GOAL:
                - Emit RelationCandidate objects that link ONLY between these Concepts
                (chunk-level concepts + relevant global definition concepts).
                - HIGH RECALL is preferred: if a relation is plausibly expressed in the text,
                you should emit it (even if some candidates are redundant).
                
            Rules:
                - subject_id and object_id MUST be chosen ONLY from the 'concepts' list.
                - Check EVERY PAIR of concepts for possible relations in the text.
                - Detect relations not only from explicit verbs, but also from possessives, appositions, and contextual mentions.
                - predicate MUST be in English, expressed in lowerCamelCase.
                - evidence_text:
                    * A short Hebrew snippet that clearly justifies this relation.
                - If no valid triple exists, return [].
                
    
            """
            
            text_chunk: str = dspy.InputField(desc="Hebrew rabbinic text")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts with IDs")
            global_definitions: List["Concept"] = dspy.InputField(
                        desc="Concepts that are definitions anywhere in the document (may or may not appear in this chunk).",
                        default=[]
                    )
            relations: List[Relation] = dspy.OutputField(
                desc="Direct relationships using concept IDs"
            )
        
        return HarvestRabbinicRelation
    
    def get_harvest_relation_functions(self) -> List[Callable]:
        """
        Returns list of functions for rabbinic relation extraction functions.
        """

        def quotation_mentions_func(subgraph) -> List[Relation]:

            new_relations = []

            # Exctract the BiblicalQuotation concepts
            bqcs = [x for x in subgraph.concepts if x.entity_type == 'BiblicalQuotation']
            for bqc in bqcs:
                # The start position and End position of the quotation
                bqc_start = bqc.concept_position
                bqc_end = bqc.concept_position+len(bqc.prefLabel)
                
                # All the concepts that was detected within the biblical quotation
                concepts_in_bq = [x for x in subgraph.concepts if x.concept_position >= bqc_start and x.concept_position <= bqc_end and x !=bqc ]
                
                for c in concepts_in_bq:
                    new_relation = Relation(
                        subject_id=bqc.id,
                        predicate="mentions",
                        object_id=c.id,
                        evidence_text=f"הציטוט {bqc.prefLabel} כולל את המונח {c.prefLabel}"
                    )
                    new_relations.append(new_relation)
                    # print(f"Create relation between BQ {bqc.id} To {c.id}")
                

            return new_relations    

        return [
            quotation_mentions_func
        ]

    def get_inter_subgraph_relations(self) -> Type[dspy.Signature]:
        class HarvestInterSentenceRabbinicRelations(dspy.Signature):
            """
            ROLE:
            You are an expert in Jewish Studies and Hebrew textual analysis specializing in
            conservative (high-precision) cross-sentence relationship extraction in rabbinic and
            kabbalistic commentaries.

            TASK:
            You are given TWO adjacent (or near-adjacent) Hebrew text chunks (typically sentences),
            and the already-extracted per-chunk Knowledge Graphs (Concepts + Relations) for each chunk.

            Your job is to extract ONLY cross-chunk relations:
                - subject_id comes from concepts_a
                - object_id comes from concepts_b
                or the reverse direction, if warranted by the text,
                Either direction is allowed. Choose the direction that matches the wording.

            You MUST output ONLY relations that can be:
                (1) directly derived from explicit wording in the text, OR
                (2) explicitly and unambiguously implied by rabbinic Hebrew coreference within the two chunks
                    (e.g., "הוא/הם/זה/זאת/אלו/הנ\"ל/וכו'" clearly referring to a concept in the other sentence).

            GOAL:
                - High precision over recall.
                - Prefer missing a relation to adding a speculative one.
                - Avoid creating "co-mention" relations without a clear textual cue.

            INPUTS:
            - text_a: Hebrew chunk A (earlier sentence).
            - concepts_a: Concepts extracted from chunk A.
            - relations_a: Intra-chunk relations extracted from chunk A.
            - text_b: Hebrew chunk B (later sentence).
            - concepts_b: Concepts extracted from chunk B.
            - relations_b: Intra-chunk relations extracted from chunk B.
            - global_definitions: (optional) document-level definition Concepts (may be referenced across sentences).

            OUTPUT:
            - inter_relations: List[Relation] where:
                * subject_id and object_id MUST be chosen ONLY from:
                    allowed_ids = concepts_a + concepts_b + global_definitions
                * At least one endpoint MUST come from concepts_a AND at least one endpoint MUST come from concepts_b
                    (i.e., truly cross-chunk).
                * predicate MUST be in English lowerCamelCase (e.g., isA, alludesTo, symbolizes).
                * evidence_text MUST be a short Hebrew snippet that includes the key cue and makes the link clear.
                    Prefer quoting the relevant portion from text_a and/or text_b.

            HARD CONSTRAINTS:
            1) No hallucinations: Do NOT introduce new concepts. Use IDs from allowed_ids only.
            2) No speculative links: If the relation is not clearly supported, DO NOT output it.
            3) Do not repeat an identical triple (same subject_id, predicate, object_id) already present in inter_relations you output.
            4) Coreference must be explicit:
                Only resolve pronouns/deictics when the antecedent is unambiguous within these two chunks.

            CROSS-SENTENCE EVIDENCE PATTERNS (use these as triggers):
            A) Coreference / anaphora:
                - הוא / היא / הם / זה / זאת / אלו / הנ"ל / וכיו"ב
                - "וכן" / "ולכן" / "וזהו" when clearly pointing back to a specific concept.

            B) Explicit linkage phrases:
                - "כמו שנאמר" / "שנאמר" / "כדכתיב" (often links a concept to a BiblicalQuotation)
                - "ולכן נקרא" / "וזה נקרא" (naming across sentences)
                - "והוא" / "שהוא" (equivalence across sentences)

            C) Structural continuation:
                - When sentence B continues describing the same entity from A (explicitly via coreference),
                extract relations such as HasPart, IsPartOf, AlludesTo, Symbolizes, IsCalled, IsA, CorrespondsTo, LocatedIn.

            D) Lexical continuation: repeated head noun/NP across A and B (e.g., , “הכרובים”, “המרכבה”) indicating the same discourse referent.
               Lexical continuation is a trigger to look for relations, not sufficient evidence by itself.

            PREDICATE INVENTORY (prefer these; otherwise do not invent):
            - isA
            - isCalled
            - alludesTo
            - symbolizes
            - refersTo
            - correspondsTo
            - hasPart
            - isPartOf
            - locatedIn
            - cites
            - isSupportedBy
            - explains
            - causes
            - enables

            If none fit, SKIP the relation (do not use vague predicates like RelatedTo).

            PROCEDURE (follow):
            1) Build allowed_ids from concepts_a, concepts_b, and global_definitions.
            2) Identify explicit coreference/linkage cues that connect the two chunks.
            3) For each cue, map the referenced entity to a Concept ID from the correct chunk.
            4) Emit only relations that have a clear cue + clear endpoints across chunks.
            5) Keep inter_relations minimal and well-justified.

            """

            # Text + per-chunk graphs
            text_a: str = dspy.InputField(desc="Hebrew chunk A (earlier sentence)")
            concepts_a: List[Concept] = dspy.InputField(desc="Concepts extracted from chunk A")
            relations_a: List[Relation] = dspy.InputField(desc="Intra-chunk relations from chunk A")

            text_b: str = dspy.InputField(desc="Hebrew chunk B (later sentence)")
            concepts_b: List[Concept] = dspy.InputField(desc="Concepts extracted from chunk B")
            relations_b: List[Relation] = dspy.InputField(desc="Intra-chunk relations from chunk B")

            # Optional document-level definitions
            global_definitions: List[Concept] = dspy.InputField(
                desc="Document-level definition concepts (optional, may be referenced explicitly).",
                default=[]
            )

            inter_relations: List[Relation] = dspy.OutputField(
                desc="Cross-sentence relations linking concepts across the two chunks using allowed IDs only"
            )

        return HarvestInterSentenceRabbinicRelations


    def get_propose_concept_merges_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for proposing rabbinic concept merges.
        """
        class ProposeRabbinicConceptMerges(dspy.Signature):
            """
            ROLE:
              You are an expert in Jewish Studies and Hebrew linguistics,
              specializing in concept normalization across rabbinic texts.

            TASK:
              Identify concepts that should be merged because they refer to the same
              rabbinic entity, despite being mentioned with different names or forms.

            MERGE SCENARIOS FOR RABBINIC TEXTS:
              1) **Name Variations**:
                 - Full names vs. abbreviations (רבי משה בן מימון vs. רמב"ם)
                 - Different honorifics (רבי עקיבא vs. עקיבא vs. ר' עקיבא)
              
              2) **Title Variations**:
                 - With/without titles (בעל שם טוב vs. ר' ישראל בעל שם טוב)
                 - Different forms of the same title
              
              3) **Source Variations**:
                 - Full tractate names vs. abbreviations (בבא מציעא vs. ב"מ)
                 - Different ways of referring to the same text
              
              4) **Concept Variations**:
                 - Related halakhic concepts that are essentially the same
                 - Different phrasings of the same religious idea

            GUIDELINES:
              - Be conservative: only merge when clearly the same entity
              - Provide Hebrew rationale explaining why concepts should merge
              - Consider historical and scholarly context
              - Preserve important distinctions between related but different concepts
              - Merge only concepts that share the same entity_type.
            """
            
            concepts: List[Concept] = dspy.InputField(desc="All concepts to analyze for potential merges")
            merges: List[ConceptMergeInstruction] = dspy.OutputField(
                desc="Proposed concept merges with Hebrew rationale"
            )
        
        return ProposeRabbinicConceptMerges
    

    def get_domain_name(self) -> str:
        """Returns human-readable name for this signature domain."""
        return "Ramban's commentary on the Torah Signature Domain"
    
    def get_description(self) -> str:
        """Returns description of this signature domain."""
        return "Rabbinic literature processing signatures for Hebrew Jewish scholarly texts"