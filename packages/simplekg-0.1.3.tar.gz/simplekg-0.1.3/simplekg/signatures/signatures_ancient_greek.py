"""
Ancient Greek Signature Registry: Implementation for ancient Greek literature processing.

This module contains signature implementations specifically designed for
ancient Greek texts, patristic literature, and classical historiography.
"""

from .signature_registry import SignatureRegistry
from typing import Type, List
import dspy

# Import the models we'll use
try:
    from ..models import *
    from ..ontologies.ancient_greek import AncientGreekOntology
except ImportError:
    from simplekg.models import *
    from simplekg.ontologies.ancient_greek import AncientGreekOntology


class AncientGreekSignatureRegistry(SignatureRegistry):
    
    """
    Ancient Greek literature signature implementations.
    
    This registry uses signatures specifically designed for ancient Greek texts,
    focusing on classical historians, Church Fathers, philosophical works,
    and Greco-Roman historical sources.
    """
    
    def get_harvest_terms_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting ancient Greek terms from text chunks.
        """
        
        class OLDHarvestAncientGreekTerms(dspy.Signature):
            """
            ROLE:
              You are an expert Classical Studies scholar and Knowledge Graph Engineer 
              specializing in ancient Greek literature, patristic texts, and classical historiography.

            TASK:
              Extract ALL important terms and concepts from the given ancient Greek text chunk.
              Focus on entities that would be valuable nodes in a knowledge graph of ancient literature.

            CATEGORIES (as guidance only - be inclusive):
              - People: Historical figures, authors, Church Fathers, philosophers, rulers
              - Places: Cities, regions, countries, geographical locations
              - Concepts: Philosophical, theological, historical, or literary ideas
              - Works: Books, treatises, chronicles, or other literary references
              - Events: Historical events, battles, councils, persecutions
              - Terms: Technical vocabulary, specialized terminology
              - Other: Any other significant entities or concepts

            INSTRUCTIONS:
              - Extract terms as they appear in the Greek text (with transliterations when helpful)
              - for span, use the EXACT text as it appears in the text_chunk
              - Include context around each term for disambiguation
              - Focus on terms that would be nodes in a knowledge graph
              - Handle both Greek text and English translations/discussions
              - Include both explicit mentions and implicit references
              - Recognize variant spellings and forms of names
              - When in doubt, include the term rather than exclude it
              - Prefer higher recall over precision - capture all potentially relevant terms
            """
            
            text_chunk: str = dspy.InputField(desc="Ancient Greek text segment or scholarly discussion to analyze")
            candidates: List[TermCandidate] = dspy.OutputField(
                desc="List of important ancient Greek terms and concepts with their categories and context"
            )
        
        
        class HarvestAncientGreekTerms(dspy.Signature):
            """
            ROLE:
              You are an expert Classical Studies scholar and Knowledge Graph Engineer
              specializing in ancient Greek literature, patristic texts, and classical historiography.

            TASK:
              Extract ALL important terms and concepts from the given ancient Greek text chunk.
              Focus on entities that would be valuable nodes in a knowledge graph of ancient literature.

            CATEGORIES (use EXACTLY one of these 11 types for coarse_type):
              - Person: Individual historical figures, authors, Church Fathers, philosophers, rulers, generals, bishops
              - Place: Cities, regions, provinces, countries, geographical/topographical locations, sanctuaries
              - Polity: Political entities — empires, kingdoms, city-states, leagues, republics, administrative units
              - Role: Offices, titles, or functions held by persons (e.g., bishop, strategos, emperor, archon)
              - Event: Discrete historical occurrences — battles, councils, persecutions, migrations, sieges, synods
              - TimePeriod: Named temporal spans — reigns, dynasties, eras, epochs (e.g., "the reign of Constantine")
              - Work: Literary or textual artifacts — histories, epistles, chronicles, treatises, commentaries
              - Abstraction: Non-concrete concepts — theological terms, philosophical ideas, doctrines (e.g., logos, homoousios)
              - Ethnonym: Collective group identifiers — peoples, nations, tribes, ethnic/cultural communities (e.g., Romans, Persians, Hebrews)
              - Practice: Recurring activities or customs — rituals, liturgical forms, philosophical methods, political procedures
              - Artifact: Concrete physical objects of cultural, religious, or political significance — royal insignia, ritual objects, sacred items, monuments, symbolic objects (e.g., diadem, altar, ark, scepter, column)

            NESTED SPAN DECOMPOSITION (important for graph connectivity):
              When a phrase of one type contains an embedded term of a different type,
              extract BOTH the full phrase AND the embedded term as separate candidates:
              - Event or TimePeriod containing a Place:
                  "Babylonian Captivity" → Event "υπό Βαβυλωνίοις δουλείας" + Place "Βαβυλωνίοις"
                  "Siege of Jerusalem"   → Event "Siege of Jerusalem" + Place "Jerusalem"
                  "Reign of Constantine" → TimePeriod "Reign of Constantine" + Person "Constantine"
              - Role containing a Place or Polity:
                  "King of Egypt"              → Role "King of Egypt" + Place "Egypt"
                  "Bishop of Constantinople"   → Role "Bishop of Constantinople" + Place "Constantinople"
                  "Strategos of Asia"          → Role "Strategos of Asia" + Place/Polity "Asia"
                  "Patriarch of Alexandria"    → Role "Patriarch of Alexandria" + Place "Alexandria"
              - Event containing a Polity or Ethnonym:
                  "Persian Wars" → Event "Persian Wars" + Polity/Ethnonym "Persians"

            INSTRUCTIONS:
              - Extract terms as they appear in the Greek text (with transliterations when helpful)
              - for span, use the EXACT text as it appears in the text_chunk
              - Include context around each term for disambiguation
              - Focus on terms that would be nodes in a knowledge graph
              - Handle both Greek text and English translations/discussions
              - Include both explicit mentions and implicit references
              - Recognize variant spellings and forms of names
              - When in doubt, include the term rather than exclude it
              - Prefer higher recall over precision - capture all potentially relevant terms
              - Assign coarse_type using ONLY the 11 types listed above — do not invent new types
            """

            text_chunk: str = dspy.InputField(desc="Ancient Greek text segment or scholarly discussion to analyze")
            candidates: List[TermCandidate] = dspy.OutputField(
                desc="List of important ancient Greek terms and concepts with their categories and context"
            )

        return [HarvestAncientGreekTerms]
    
    def get_candidates_to_concepts_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting ancient Greek term candidates to structured concepts.
        """
        
        class OLDAncientGreekCandidatesToConcepts(dspy.Signature):
            """
            ROLE:
              You are an expert in Classical Studies and patristic scholarship,
              specializing in creating structured knowledge representations of ancient Greek literature.

            TASK:
              Convert the extracted term candidates into well-structured Concept objects
              suitable for a Classical Studies knowledge graph.

            CONCEPT CREATION GUIDELINES:
              1) **Standardize Names**: Use standard scholarly transliterations 
                 (Eusebius not Εὐσέβιος in English contexts, but preserve Greek when appropriate)
              2) **Entity Types**: Assign appropriate categories:
                 - Person: For historical figures, authors, Church Fathers, philosophers
                 - Concept: For theological, philosophical, or historical concepts
                 - Location: For cities, regions, provinces of historical significance
                 - Event: For historical events, wars, councils, persecutions
                 - Reference: For books, treatises, or textual sources
                 - Practice: For religious rituals, philosophical methods, political procedures
                 - Institution: For political, religious, or academic organizations
              
              3) **Descriptions**: Write clear descriptions explaining the concept's
                 significance in classical or patristic scholarship and its context in this specific text
              
              4) **Alternative Labels**: Include common variants, Greek forms, Latin equivalents,
                 and different scholarly transliterations
              
              5) **Cross-Cultural References**: Connect to related Jewish, Roman, or Christian concepts

            CONSTRAINTS:
              - Generate deterministic IDs using snake_case from the preferred English form
              - Ensure concepts are distinct and non-overlapping
              - Focus on concepts that would be valuable in a Classical Studies knowledge graph
              - Include only concepts that appear in or are directly referenced by the text
              - Handle both Greek originals and English scholarly discussions
              - Set term_id to the term_id of the TermCandidate this concept was derived from
            """
            
            text_chunk: str = dspy.InputField(desc="Source ancient Greek or scholarly text")
            candidates: List[TermCandidate] = dspy.InputField(desc="Extracted term candidates")
            concepts: List[Concept] = dspy.OutputField(
                desc="Structured ancient Greek concepts with English/Greek labels and descriptions"
            )
        
        
        class AncientGreekCandidatesToConcepts(dspy.Signature):
            """
            ROLE:
              You are an expert in Classical Studies and patristic scholarship,
              specializing in creating structured knowledge representations of ancient Greek literature.

            TASK:
              Convert the extracted term candidates into well-structured Concept objects
              suitable for a Classical Studies knowledge graph.

            CONCEPT CREATION GUIDELINES:
              1) **Standardize Names**: Use standard scholarly transliterations
                 (Eusebius not Εὐσέβιος in English contexts, but preserve Greek when appropriate)

              2) **Entity Types** — set entity_type to EXACTLY one of these 11 values:
                 - Person: Individual historical figures, authors, Church Fathers, philosophers, rulers, generals
                 - Place: Cities, regions, provinces, countries, geographical/topographical entities, sanctuaries
                 - Polity: Political entities — empires, kingdoms, city-states, leagues, republics, administrative units
                   (NOTE: distinguish from Person — "Rome" as a state is Polity; "Julius Caesar" is Person)
                 - Role: Offices, titles, or functions associated with persons (bishop, strategos, emperor, archon)
                   (NOTE: the title itself, not the person — "episcopate" is Role; "Ignatius" is Person)
                 - Event: Discrete historical occurrences — battles, councils, persecutions, migrations, sieges, synods
                 - TimePeriod: Named temporal spans — reigns, dynasties, eras, epochs
                 - Work: Literary or textual artifacts — histories, epistles, chronicles, treatises, commentaries
                 - Abstraction: Non-concrete concepts — theological terms, philosophical ideas, doctrines, virtues
                   (e.g., logos, homoousios, oikonomia, paideia)
                   (NOTE: Abstraction is for ideas only — a physical object is Artifact, not Abstraction)
                 - Ethnonym: Collective group identifiers — peoples, nations, tribes, ethnic/cultural communities
                   (e.g., Romans, Persians, Hebrews, Galatians)
                 - Practice: Recurring activities or customs — rituals, liturgical forms, philosophical methods,
                   political procedures (e.g., baptism, the Eucharist, dialectic, census)
                   (NOTE: Practice is for activities — a ritual object is Artifact, not Practice)
                 - Artifact: Concrete physical objects of cultural, religious, or political significance —
                   royal insignia, ritual objects, sacred items, weapons, monuments, symbolic objects
                   (e.g., diadem, altar, ark, scepter, temple vessel, column, coin)

              3) **Descriptions**: Write clear descriptions explaining the concept's
                 significance in classical or patristic scholarship and its context in this specific text

              4) **Alternative Labels**: Include common variants, Greek forms, Latin equivalents,
                 and different scholarly transliterations

              5) **Cross-Cultural References**: Connect to related Jewish, Roman, or Christian concepts

            CONSTRAINTS:
              - You MUST use exactly one of the 11 entity_type values listed above — do not invent new types
              - Generate deterministic IDs using snake_case from the preferred English form
              - Ensure concepts are distinct and non-overlapping
              - Focus on concepts that would be valuable in a Classical Studies knowledge graph
              - Include only concepts that appear in or are directly referenced by the text
              - Handle both Greek originals and English scholarly discussions
              - Set term_id to the term_id of the TermCandidate this concept was derived from
            """

            text_chunk: str = dspy.InputField(desc="Source ancient Greek or scholarly text")
            candidates: List[TermCandidate] = dspy.InputField(desc="Extracted term candidates")
            concepts: List[Concept] = dspy.OutputField(
                desc="Structured ancient Greek concepts with English/Greek labels and descriptions"
            )

        return AncientGreekCandidatesToConcepts
    
    def get_harvest_definitions_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for identifying definitions in ancient Greek texts.
        """
        class HarvestAncientGreekDefinitions(dspy.Signature):
            """
            ROLE:
              You are an expert in ancient Greek literature and patristic studies.

            TASK:
              Identify concepts that are being explicitly defined or explained in this
              ancient Greek text chunk or scholarly discussion.

            WHAT COUNTS AS AN ANCIENT GREEK DEFINITION:
              1) **Explicit Definitions**: 
                 - ἔστι δέ... (it is...)
                 - λέγω δέ... (I mean/say...)
                 - τοῦτο δέ ἐστι... (this is...)
                 - καλῶ δέ... (I call...)
              
              2) **Scholarly Explanations**:
                 - "Eusebius defines..." 
                 - "By this term Josephus means..."
                 - "The concept of... refers to..."
              
              3) **Technical Definitions**:
                 - Theological terminology explanations
                 - Philosophical concept clarifications
                 - Historical term definitions
              
              4) **Comparative Definitions**:
                 - "Unlike Josephus, Eusebius understands..."
                 - "This differs from the Platonic..."
                 - "In contrast to earlier usage..."

            CONSTRAINTS:
              - Only mark concepts from the provided concepts list
              - Focus on definitional/explanatory contexts, not mere mentions
              - Consider both explicit definitions and scholarly interpretations
              - Handle both Greek originals and English scholarly discussions
            """
            
            text_chunk: str = dspy.InputField(desc="Ancient Greek text or scholarly analysis")
            concepts: List[Concept] = dspy.InputField(desc="Detected concepts in this chunk")
            definition_concepts: List[DefinitionMark] = dspy.OutputField(
                desc="Concepts being defined or explained in this text"
            )
        
        return HarvestAncientGreekDefinitions
    
    def get_harvest_relation_candidates_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for extracting ancient Greek relation candidates.
        """
        class HarvestAncientGreekRelationCandidates(dspy.Signature):
            """
            ROLE:
              You are an expert in Classical Studies and knowledge graph construction
              for ancient Greek literature and patristic texts.

            TASK:
              Extract important relationships between concepts in this ancient Greek text.
              Focus on relationships that would be valuable in a Classical Studies knowledge graph.

            RELATIONSHIP TYPES TO IDENTIFY:
              1) **Literary Relations**:
                 - wroteWork, citedBy, refutedBy, influencedBy, commentedOn
                 - Example: Eusebius cited Josephus in his Ecclesiastical History
              
              2) **Chronological Relations**:
                 - succeededBy, precededBy, contemporaryWith, livedDuring
                 - Example: Eusebius lived during the reign of Constantine
              
              3) **Theological Relations**:
                 - defendedDoctrine, opposedHeresy, developedConcept, presidedOver
                 - Example: Athanasius defended the homoousios doctrine
              
              4) **Geographic Relations**:
                 - bornIn, livedIn, traveledTo, episcopateOf, exiledTo
                 - Example: John Chrysostom was bishop of Constantinople
              
              5) **Academic Relations**:
                 - studiedUnder, taughtBy, belongedToSchool, foundedSchool
                 - Example: Origen studied under Clement of Alexandria
              
              6) **Historical Relations**:
                 - participatedIn, witnessedEvent, recordedEvent, causedBy
                 - Example: Eusebius recorded the Council of Nicaea
              
              7) **Comparative Relations**:
                 - disagreedWith, supportedView, contrastedWith, synthesizedWith
                 - Example: Josephus's account differs from Eusebius's version

            GUIDELINES:
              - Use English predicate names in camelCase
              - Extract evidence text supporting each relationship
              - Focus on explicit relationships mentioned in the text
              - Handle both Greek sources and English scholarly discussions
              - Include chronological and comparative relationships
            """
            
            text_chunk: str = dspy.InputField(desc="Ancient Greek text or scholarly analysis")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts")
            candidates: List[RelationCandidate] = dspy.OutputField(
                desc="Relationship candidates between ancient Greek concepts"
            )
        
        return HarvestAncientGreekRelationCandidates
    
    def get_candidates_to_relations_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for converting ancient Greek relation candidates to final relations.
        """
        class AncientGreekCandidatesToRelations(dspy.Signature):
            """
            ROLE:
              You are an expert in Classical Studies knowledge representation and
              ontology design for ancient Greek literature.

            TASK:
              Convert relation candidates into final, normalized relations by mapping
              mentions to concept IDs and standardizing predicates.

            PREDICATE STANDARDIZATION:
              - Use camelCase English predicates (wroteWork, citedBy, livedDuring)
              - Ensure predicates are consistent across similar relationships
              - Map Greek relationship expressions to canonical English predicates
              - Handle temporal and causal relationships appropriately

            VALIDATION:
              - Ensure both subject and object concepts exist in the concept list
              - Verify that the relationship makes sense in the classical context
              - Include evidence text to support the relationship claim
              - Remove duplicate or conflicting relationships
              - Handle both Greek originals and English scholarly discussions

            CONSTRAINTS:
              - Only create relations where both concepts are available
              - Use deterministic concept IDs that match the Concept.id field
              - Maintain evidence text for scholarly verification
              - Handle chronological relationships with appropriate directionality
            """
            
            candidates: List[RelationCandidate] = dspy.InputField(desc="Relation candidates to process")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts for ID mapping")
            relations: List[Relation] = dspy.OutputField(
                desc="Final normalized relations with concept IDs"
            )
        
        return AncientGreekCandidatesToRelations
    
    def get_harvest_relation_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for direct ancient Greek relation extraction.
        """
        class HarvestAncientGreekRelation(dspy.Signature):
            """
            ROLE:
              You are an expert in Classical Studies and ancient Greek textual analysis,
              specializing in direct relationship extraction from classical texts.

            INPUTS:
                - text_chunk: a single chunk from an ancient Greek text or scholarly work.
                - concepts: the Concept objects already extracted for THIS chunk.
                - global_definitions: Concept objects that are definitions elsewhere
                in the document (document-level), which may participate in relations
                if the text in this chunk clearly refers to them.
                
                GOAL:
                - Emit Relation objects that link ONLY between these Concepts
                (chunk-level concepts + relevant global definition concepts).
                - HIGH RECALL is preferred: if a relation is plausibly expressed in the text,
                you should emit it (even if some candidates are redundant).
                
                Rules:
                - subject_id and object_id MUST be chosen ONLY from the 'concepts' list.
                - Check EVERY PAIR of concepts for possible relations in the text.
                - Detect relations from explicit statements, implicit connections, and scholarly analysis.
                - predicate MUST be in English, expressed in camelCase.
                - evidence_text:
                    * A snippet (Greek or English) that clearly justifies this relation.
                - If no valid triple exists, return [].
                - Handle both Greek originals and English scholarly discussions.
            """
            
            text_chunk: str = dspy.InputField(desc="Ancient Greek or scholarly text")
            concepts: List[Concept] = dspy.InputField(desc="Available concepts with IDs")
            relations: List[Relation] = dspy.OutputField(
                desc="Direct relationships using concept IDs"
            )
        
        return HarvestAncientGreekRelation
    
    def get_propose_concept_merges_signature(self) -> Type[dspy.Signature]:
        """
        Returns signature for proposing ancient Greek concept merges.
        """
        class ProposeAncientGreekConceptMerges(dspy.Signature):
            """
            ROLE:
              You are an expert in Classical Studies and ancient languages,
              specializing in concept normalization across ancient Greek texts.

            TASK:
              Identify concepts that should be merged because they refer to the same
              ancient Greek entity, despite being mentioned with different names or forms.

            MERGE SCENARIOS FOR ANCIENT GREEK TEXTS:
              1) **Name Variations**:
                 - Greek vs. Latin forms (Ἰώσηπος vs. Josephus, Εὐσέβιος vs. Eusebius)
                 - Different transliterations (Constantine vs. Konstantinos vs. Κωνσταντῖνος)
              
              2) **Title Variations**:
                 - With/without titles (John Chrysostom vs. Saint John vs. Ἰωάννης)
                 - Different honorifics (Saint Athanasius vs. Athanasius the Great)
              
              3) **Work Variations**:
                 - Full titles vs. abbreviated forms
                 - Greek vs. English titles of the same work
                 - Different scholarly conventions for the same text
              
              4) **Concept Variations**:
                 - Theological concepts in Greek vs. English
                 - Same concept with different scholarly terminology
                 - Historical events with variant names

            GUIDELINES:
              - Be conservative: only merge when clearly the same entity
              - Consider linguistic and scholarly conventions
              - Provide rationale explaining why concepts should merge
              - Preserve important distinctions between related but different concepts
              - Handle cross-linguistic variations appropriately
            """
            
            concepts: List[Concept] = dspy.InputField(desc="All concepts to analyze for potential merges")
            merges: List[ConceptMergeInstruction] = dspy.OutputField(
                desc="Proposed concept merges with scholarly rationale"
            )
        
        return ProposeAncientGreekConceptMerges
    
    def get_ontology(self):
        """Returns the Ancient Greek ontology for predicate and entity type normalization."""
        return AncientGreekOntology()

    def get_domain_name(self) -> str:
        """Returns human-readable name for this signature domain."""
        return "ancient_greek"

    def get_description(self) -> str:
        """Returns description of this signature domain."""
        return "Ancient Greek literature processing signatures for classical and patristic texts"
    



