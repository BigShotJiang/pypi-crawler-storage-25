
from dotenv import load_dotenv
import numpy as np
import os, sys
from openai import OpenAI

# Load environment variables from .env file
load_dotenv() 

# Add the simplekg directory to the Python path
# sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'simplekg'))


try:
    from .models import *
    from .utilities import get_embeddings
except ImportError:
    # Fallback for when running as a script (not as a package)
    from models import *
    from utilities import get_embeddings



def main(texts, text_names, tested_section, store_path: str = None, distance_threshold=1.0):
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    text_embeddings = get_embeddings(texts=texts, client=client)
    # Store embeddings to file or process further
    text_embeddings_array = np.array(text_embeddings)
    if store_path:
        np.save(f"{store_path}/{tested_section}.npy", text_embeddings_array)
    
    # Run Agglomerative Clustering  with distance threshold
    from sklearn.cluster import AgglomerativeClustering 
    clustering_model = AgglomerativeClustering(n_clusters=None, distance_threshold=distance_threshold, metric='euclidean', linkage='ward')
    clustering_model.fit(text_embeddings_array)
    labels = clustering_model.labels_
    
    
    # Store labels to file
    # if store_path:
    #     with open(f"{store_path}/{tested_section}_labels.txt", "w", encoding="utf-8") as f:
    #         for name, label in zip(text_names, labels):
    #             f.write(f"{name}\t{label}\n")
    if store_path:
        # Get linkage matrix for distances
        from scipy.cluster.hierarchy import linkage as scipy_linkage
        linked = scipy_linkage(text_embeddings_array, 'ward')
        
        # Calculate distances between samples and their cluster centers
        # For each sample, find the distance at which it merged with its cluster
        from scipy.cluster.hierarchy import fcluster
        
        with open(f"{store_path}/{tested_section}_labels.txt", "w", encoding="utf-8") as f:
            f.write("Name\tCluster\n")  # Header
            for name, label in zip(text_names, labels):
                f.write(f"{name}\t{label}\n")
            
            # Add cluster merge information
            f.write("\n# Cluster Merge Information:\n")
            f.write("# Step\tCluster1\tCluster2\tDistance\tSize\n")
            for i, merge in enumerate(linked):
                f.write(f"{i}\t{int(merge[0])}\t{int(merge[1])}\t{merge[2]:.4f}\t{int(merge[3])}\n")
    


    
    # visualize dendrogram
    import matplotlib.pyplot as plt
    from scipy.cluster.hierarchy import dendrogram, linkage
    linked = linkage(text_embeddings_array, 'ward')
    plt.figure(figsize=(15, 10))
    dendrogram(linked, orientation='top', labels=text_names, distance_sort='descending', show_leaf_counts=True)
    plt.xticks(rotation=45, ha='right')
    plt.title(f'Dendrogram for Ramban Section: {tested_section}')
    plt.xlabel('Commentaries')
    plt.ylabel('Distance')
    plt.savefig(f"{store_path}/{tested_section}_dendrogram.png")
    # plt.show()

    

if __name__ == "__main__":
    path = "/Users/hadarmiller/Dropbox (University of Haifa)/HaifaU/15_Labs_Projects/7 shem_hagdolim_and_RAMBAN/Data Bases And Systems/Ramban"
    files = [f for f in os.listdir(f"{path}/txt") if f.find("19_2")!=-1]
    texts = []
    text_names = []
    for file in files:
        with open(f"{path}/txt/{file}", "r", encoding="utf-8") as f:
            text = f.read().strip().replace("\n", " ")
            texts.append(text) 
            name = file[:file.find("19_2")]
            text_names.append(name)
            


    print(f"Loaded {len(texts)} texts for clustering.")
    main(texts=texts, text_names=text_names, tested_section="19_2", store_path=f"{path}/clusters", distance_threshold=1.0)