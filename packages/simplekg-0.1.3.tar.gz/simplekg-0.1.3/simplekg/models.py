from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Tuple, Optional, Dict, List, Set, Literal, Any
from datetime import datetime


#-----------------------------------
# Models for Concepts
#-----------------------------------

class TermCandidate(BaseModel):
    """
    A raw term/span spotted in the text that might become a Concept.
    """
    term_id: Optional[int] = Field(
        default=None,
        description="Unique ID which identifies the specific term"
    )
    span: str = Field(..., description="Exact text span as it appears in the chunk.")
    usage_count: Optional[int] = Field(
        default=1,
        description="Number of times this terms/concept appears in the text chunk."
    )
    coarse_type: str = Field(
        ...,
        description=(
            "Coarse semantic category for the span. "
        ),
    )
    context: Optional[str] = Field(
        None,
        description="Short excerpt around the span (for later disambiguation)."
    )

class Concept(BaseModel):
    id: str = Field(..., description="Deterministic ID generated from primary label (snake_case, no spaces).")
    prefLabel: str = Field(..., description="Primary label in the source language")
    prefLabel_en: str = Field(..., description="English translation of the primary label")
    altLabels: List[str] = Field(default_factory=list, description="Alternative labels in the source language")
    altLabels_en: List[str] = Field(default_factory=list, description="English translations of alternative labels")
    conceptDescription: str = Field(..., description="Description of the concept's meaning in this specific context (source language)")
    conceptDescription_en: str = Field(..., description="English translation of the concept's description")
    entity_type: str
    entity_type_raw: Optional[str] = Field(
        default=None,
        description="Original entity_type as produced by the LLM before ontology enforcement. None if no ontology was applied."
    )
    source_instance_ids: List[str] = []
    concept_position: int = -1 # Default is -1, The position in the source text where the concept was first mentioned
    definition: bool = Field(
        default=False,
        description="True if this concept is explicitly defined (as a legal definition) in at least one chunk."
    )
    term_id: Optional[int] = Field(default=None, description="The ID of the original TermCandidate that led to this Concept.")

    @property
    def concept_text(self) -> str:
        """Serialize concept into string for Embeddings"""
        parts = [] 
        # Primary label in source language
        parts.append(self.prefLabel)
        parts += self.altLabels
        # Optional description in source language
        if self.conceptDescription:
            parts.append(self.conceptDescription)
        # English labels and description
        parts.append(self.prefLabel_en)
        parts += self.altLabels_en
        if self.conceptDescription_en:
            parts.append(self.conceptDescription_en)
        # Add entity type
        parts.append(f"type: {self.entity_type}")
        return " | ".join(parts)
    
    @property
    def concept_text_with_context(self) -> str:
        parts = []

        parts.append(f"PRIMARY LABEL (HE): {self.prefLabel}")

        if self.altLabels:
            parts.append(f"ALT LABELS (HE): {', '.join(self.altLabels)}")

        parts.append(f"ENTITY TYPE: {self.entity_type}")

        if self.conceptDescription:
            parts.append(f"DESCRIPTION (HE): {self.conceptDescription}")

        parts.append(f"PRIMARY LABEL (EN): {self.prefLabel_en}")

        if self.altLabels_en:
            parts.append(f"ALT LABELS (EN): {', '.join(self.altLabels_en)}")

        if self.conceptDescription_en:
            parts.append(f"DESCRIPTION (EN): {self.conceptDescription_en}")

        parts.append( f"CONCEPT TYPE: This is a {self.entity_type}." )
        return "\n".join(parts)


class DefinitionMark(BaseModel):
    """
    Marks a concept as being explicitly a definition.
    """
    concept_id: str = Field(..., description="ID of a Concept from the 'concepts' list that is being defined.")
    confidence: float = Field(..., description="Confidence in [0,1] that this is a definitional use.")
    evidence_text: str = Field(..., description="Short snippet showing the definitional context in the source text.")

class ConceptCluster(BaseModel):
    cluster_id: int = Field(..., description="Unique ID for the concept cluster.")
    member_concept_ids: List[str] = Field(..., description="List of Concept IDs that belong to this cluster.")
    
class ConceptMergeInstruction(BaseModel):
    canonical_id: str = Field(..., description="New canonical ID for the merged concept (document-level).")
    member_ids: List[str] = Field(..., description="List of concept.instance IDs (sgX_...) to merge.")
    rationale: Optional[str] = Field(None, description="Short explanation why these concepts belong together.")


#-----------------------------------
# Models for Relations
#-----------------------------------

class RelationCandidate(BaseModel):
    """
    Soft relation candidate as produced in the first pass.
    Uses textual mentions that will later be mapped to Concept IDs.
    """
    subject_mention: str = Field(..., description="Mention of the subject entity as it appears in the text.")
    predicate_label_en: str = Field(..., description="English predicate name, CamelCase, e.g. signedAt, sideOfAgreement, hasWageTerm.")
    object_mention: str = Field(..., description="Mention of the object entity as it appears in the text.")
    evidence_text: str = Field(..., description="Short quote from the text that evidences this relation.")

class Relation(BaseModel):
    """Final, normalized relation in the KG."""
    subject_id: str = Field(..., description="ID of the subject Concept (must match Concept.id).")
    predicate: str = Field(..., description="Canonical predicate label in English, lowerCamelCase, e.g. signedAt, hasParty, amendsAgreement.")
    predicate_raw: Optional[str] = Field(
        default=None,
        description="Original predicate as produced by the LLM before ontology mapping. None if no ontology was applied."
    )
    object_id: str = Field(..., description="ID of the object Concept (must match Concept.id).")
    evidence_text: Optional[str] = Field(
        None,
        description="Short snippet of the source text that justifies this relation."
    )

#-----------------------------------
# Models Graph and Doc level
#-----------------------------------

class BaseGraph(BaseModel):
  # Core fields 
  gid: int = Field(..., description="Unique graph ID")
  text: str = Field(..., description="The original text used to generate the graph")
  context_text: str = Field(
      default="",
      description="Optional broader context (source/author/work) associated with this text."
  )
  terms: List[TermCandidate] = Field(default_factory=list, description="List of terms extracted from the text")
  concepts: List[Concept] = Field(default_factory=list, description="List of concepts extracted from the text")
  relation_candidates: List[RelationCandidate] = Field(default_factory=list, description="List of relation candidates")
  filtered_relations: List[Relation] = Field(default_factory=list, description="Filtered relation candidates due to missing concepts")
  relation_objects: List[Relation] = Field(default_factory=list, description="List of relation objects with full metadata")
  
  @property
  def entity_labels(self) -> Set[str]:
    """Get entity labels from concepts for convenience"""
    return {c.prefLabel for c in self.concepts}
  
  @property 
  def relation_tuples(self) -> Set[Tuple[str, str, str]]:
    """Get relation tuples from relation objects for convenience"""
    return {(r.subject_id, r.predicate, r.object_id) for r in self.relation_objects}

class DocGraph(BaseModel):
    consolidated_graph: BaseGraph = Field(..., description="The consolidated knowledge graph for the entire document")
    subgraphs: Optional[List[BaseGraph]] = Field(default_factory=list, description="List of subgraphs")
    concept_clusters: Optional[List[ConceptCluster]] = Field(default_factory=list, description="List of concept clusters")
    concept_merges: Optional[List[ConceptMergeInstruction]] = Field(default_factory=list, description="List of concept merge instructions")
    global_definitions: List[str] = Field(
        default_factory=list,
        description="List of Concept IDs that serve as definition concepts in this document."
    )
    pruned_orphans: Optional[List[str]] = Field(
        default_factory=list,
        description="List of Concept IDs that were pruned as orphans during consolidation."
    )


#-----------------------------------
# Models for KnowledgeGraphGenerator
#-----------------------------------

class ConceptAttribute(BaseModel):
    """
    Represents a single property or characteristic of the concept.
    Examples: (name="age", value="45"), (name="role", value="Prime Minister")
    """
    # Subject
    concept_name: str = Field(..., description="Must match one of the provided concepts exactly.")
    # Predicate
    name: str = Field(..., description="The name of the property (e.g., 'status', 'startDate', 'role'). Keep it short and it MUST be in English. Use CamelCase if possible.")
    # Object
    value: str = Field(..., description="The value extracted from the text corresponding to this property.")


class RelationConcept(BaseModel):
    """Each object represents one relation type (e.g., is_under_investigation_for)"""
    relationLabel: str
    relationDescription: str
    domain: str  # e.g., "person"
    range: str   # e.g., "legal_concept"
    example_he: str
    example_en: str


class Predicate(BaseModel):
    """Each object represents one canonical relation (predicate)."""
    prefLabel_en: str = Field( ..., description="Canonical English label for the relation, formatted for ontology use (short, verb phrase, camelCase if appropriate)")
    altLabels_en: list[str] = Field( ..., description="List of alternative phrasings or synonyms for the relation")
    mapping_examples: list[str] = Field( ...,description="Examples of raw relation strings from the input that map to this canonical relation" )

class Token(BaseModel):
    """Each object represent a token"""
    seq_id: int = Field(..., description="The position of the token in the passage")
    value: str = Field(..., description="a string of the token")
    pos: str = Field(..., description="a part of speech (POS) of the token")


class RelationOld(BaseModel):
    """
    Used by KnowledgeGraphGenerator to represent a relation.
    Knowledge graph subject–predicate–object triple.
    """
    subject: str = Field(..., description="Must match EXACTLY a string from entities list. Do not invent or alter.")
    predicate: str = Field(..., description="Short English verb phrase in CamelCase (e.g., 'isPartOf', 'isLocatedIn').")
    object: str = Field(..., description="Must match EXACTLY a string from entities list. Do not invent or alter.")
    # We relax the description here to allow values
    #object: str = Field(..., description="Target entity name OR a specific value (date, number, string).")
    
    # We add a type flag so you know how to handle it later
    object_type: Literal["Entity", "Value"] = Field(..., description="Is the object another concept or a raw value?")


class Graph(BaseModel):
    """Used by KnowledgeGraphGenerator to represent the knowledge graph."""
    # Core fields  
    text: str = Field(..., description="The original text used to generate the graph")
    concepts: List[Concept] = Field(default_factory=list, description="List of concepts extracted from the text")
    relation_objects: List[RelationOld] = Field(default_factory=list, description="List of relation objects with full metadata")
    tokens: Optional[List[Token]] = Field(default_factory=list, description="List of tokens with their POS tags")
    
    # Processing fields
    ontologies: Optional[Dict[str, List[Predicate]]] = Field(default_factory=dict, description="Dictionary mapping ontology names to lists of predicates")
    subgraphs: Optional[List[Graph]] = Field(default_factory=list, description="List of subgraphs")
    base_graph: Optional[Graph] = Field(default=None, description="A copy of the initial graph before any processing or merging")
    
    @property
    def entity_labels(self) -> Set[str]:
        """Get entity labels from concepts for convenience"""
        return {c.prefLabel for c in self.concepts}
    
    @property 
    def relation_tuples(self) -> Set[Tuple[str, str, str]]:
        """Get relation tuples from relation objects for convenience"""
        return {(r.subject, r.predicate, r.object) for r in self.relation_objects}



class DSPyHistoryEntry(BaseModel):
    """Represents a single dspy operation history entry."""
    timestamp: str = Field(..., description="ISO timestamp when the operation occurred")
    method_name: str = Field(..., description="Name of the method that called dspy")
    signature_class: str = Field(..., description="Name of the dspy Signature class used")
    rationale: Optional[str] = Field(None, description="Chain of thought reasoning (if available)")
    #input_params: Dict[str, Any] = Field(default_factory=dict, description="Input parameters passed to the signature")
    #output_data: Optional[Dict[str, Any]] = Field(None, description="Output result from dspy call")
    #dspy_method_type: str = Field(..., description="Type of dspy method used (Predict, ChainOfThought, etc.)")

class Statement(BaseModel):
    statement_id: str = Field(description="Sequential ID")
    text: str = Field(description="A single atomic fact in the source language")



# Legacy Concept class (replaced by language-agnostic version above)
# class Concept(BaseModel):
#     """Represents a unique entity or concept found in the text."""
#     
#     prefLabel: str = Field(..., description="The clearest name for this entity in the source language.")
#     prefLabel_en: str = Field(..., description="English translation of the prefLabel.")
#     altLabels: list[str] = Field(
#         default_factory=list, 
#         description="List of alternative names used **in this text** to refer to this entity (e.g. acronyms, short names, legal definitions)."
#     )
#     altLabels_en: list[str] = Field(
#         default_factory=list, 
#         description="List of English synonyms or variants, if present in the text."
#     )
#     conceptDescription: str = Field(..., description="A description of the concept's meaning in this specific context (source language).")
#     conceptDescription_en: str = Field(..., description="English translation of the concept description.")
#     entity_type: str = Field(..., description="The high-level category (e.g. Person, Organization).")

  
# Resolve forward references
Graph.model_rebuild()
Relation.model_rebuild()