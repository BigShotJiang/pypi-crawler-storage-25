import os, math, re
from dotenv import load_dotenv
import dspy
import litellm
from html import entities
import json, sys, time, pickle, functools, inspect
import logging
from datetime import datetime
from difflib import SequenceMatcher
from dataclasses import dataclass
from typing import Any, List, Literal,  Tuple, Optional, Set, Dict, TypeVar, Callable, Iterable
import networkx as nx
import pandas as pd

from pydantic import BaseModel, Field

from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
try:
    from .models import *
    from .utilities import load_ontology_embeddings, is_english, chunk_list, get_embeddings
except ImportError:
    # Fallback for when running as a script (not as a package)
    from models import *
    from utilities import load_ontology_embeddings, is_english, chunk_list, get_embeddings




def dspy_track(func=None, *, dspy_type: str = "auto"):
    """
    Decorator to automatically track DSPy operations in method calls.
    
    Args:
        func: The function to decorate (when used as @dspy_track)
        dspy_type: DSPy method type - "ChainOfThought", "Predict", or "auto" to detect
        
    Usage:
        @dspy_track
        def some_method(self): ...
        
        @dspy_track(dspy_type="Predict") 
        def some_method(self): ...
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            # Check if tracking is enabled
            if not hasattr(self, 'dspy_history_track') or not self.dspy_history_track:
                return func(self, *args, **kwargs)
            
            # Store original dspy methods to intercept calls
            original_chain_of_thought = dspy.ChainOfThought
            original_predict = dspy.Predict
            
            # Track DSPy calls made within this method
            dspy_calls = []
            
            def track_chain_of_thought(signature_class):
                instance = original_chain_of_thought(signature_class)
                original_call = instance.__call__
                
                def tracked_call(*call_args, **call_kwargs):
                    result = original_call(*call_args, **call_kwargs)
                    dspy_calls.append({
                        'signature_class': signature_class,
                        'method_type': 'ChainOfThought',
                        'result': result,
                        'args': call_args,
                        'kwargs': call_kwargs
                    })
                    return result
                
                instance.__call__ = tracked_call
                return instance
            
            def track_predict(signature_class):
                instance = original_predict(signature_class)
                original_call = instance.__call__
                
                def tracked_call(*call_args, **call_kwargs):
                    result = original_call(*call_args, **call_kwargs)
                    dspy_calls.append({
                        'signature_class': signature_class,
                        'method_type': 'Predict',
                        'result': result,
                        'args': call_args,
                        'kwargs': call_kwargs
                    })
                    return result
                
                instance.__call__ = tracked_call
                return instance
            
            # Monkey patch DSPy methods to track calls
            dspy.ChainOfThought = track_chain_of_thought
            dspy.Predict = track_predict
            
            try:
                # Execute the original method
                result = func(self, *args, **kwargs)
                
                # Process tracked DSPy calls
                for call_info in dspy_calls:
                    try:
                        # Get rationale if available (from ChainOfThought)
                        rationale = getattr(call_info['result'], 'rationale', None)
                        
                        # Get full history
                        full_history = dspy.inspect_history(n=1)
                        
                        # Prepare output data (safely convert to dict)
                        output_data = None
                        if hasattr(call_info['result'], 'model_dump'):
                            output_data = call_info['result'].model_dump()
                        elif hasattr(call_info['result'], '__dict__'):
                            output_data = dict(call_info['result'].__dict__)
                        
                        # Create history entry
                        history_entry = DSPyHistoryEntry(
                            timestamp=datetime.now().isoformat(),
                            method_name=func.__name__,
                            signature_class=call_info['signature_class'].__name__,
                            rationale=rationale,
                            full_history=full_history,
                            input_params=call_info['kwargs'],
                            output_data=output_data,
                            dspy_method_type=call_info['method_type']
                        )
                        
                        self.dspy_history.append(history_entry)
                        
                    except Exception as e:
                        # Silently handle history tracking errors
                        pass
                
            finally:
                # Restore original DSPy methods
                dspy.ChainOfThought = original_chain_of_thought
                dspy.Predict = original_predict
            
            return result
        
        return wrapper
    
    # Handle both @dspy_track and @dspy_track(...) syntax
    if func is None:
        return decorator
    else:
        return decorator(func)

def dspy_clean_cache_wrapper(func):
    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if hasattr(self, 'clear_dspy_cache') and self.clear_dspy_cache:
            self.clear_cache()
        return func(self, *args, **kwargs)
    return wrapper

class KnowledgeGraphGenerator:
    
    def __init__(self, model: str , api_key: str , temperature: float = 0.0, api_base: str = None, 
                 chunk_size: int = 0, init_entity_types: List[str] = None, extract_entities_mode: str = None, persona: str = ""):
        """Initialize the Knowledge Graph Generator with model configuration."""
        self.max_workers = 1
        self.dspy = dspy
        self.model = model
        self.temperature = temperature
        self.api_key = api_key
        self.api_base = api_base
        self.graph = None
        self.init_entity_types = ["Person", "Role", "Organization", "Concept", "Location", "Polities (ancient and modern)","Event", "Biblical Quotation"]
        
        # History tracking
        self.dspy_history_track = False
        self.dspy_history: List[DSPyHistoryEntry] = []

        self.clear_dspy_cache = False  #  Clear DSPy cache before execution
        self.dspy_cache_path = None # The path where dspy store its cache


        self.set_params(init_entity_types, extract_entities_mode, persona, chunk_size)
        self.init_model(model, temperature, api_key, api_base)


    # Helpers to set parameters

    def set_params(self, init_entity_types: List[str] = None, extract_entities_mode: str = None, persona: str = "", chunk_size: int = 0, dspy_history_track=None, clear_dspy_cache: bool = None):
        '''
        parameters:
            Reset all parameters to their default values and empty graph.
            init_entity_types: List of initial entity types to consider during extraction.
            extract_entities_mode: Mode for entity extraction (e.g., "token", "fixed", "dynamic").
                tokens - first extract tokens+ POS, then extract entities from tokens
                fixed - use a fixed set of patterns to extract entities
                dynamic - dynamically determine entity types based on context
            persona: The persona to use for the extraction 
                    - "You are a a Jewish History scholar and an Kabalisctic expert"
                    - "You are a Hebrew linguestic scholar and an Ontology expert"
        '''

        if clear_dspy_cache:
            # Check if the cache path exists
            tmp = self.get_cache_info()
            if tmp:
                self.clear_dspy_cache = True
            
        
        


        if persona == "":
            self.persona = persona

        if chunk_size is not None:
            self.chunk_size = chunk_size

        if dspy_history_track is not None:
            self.dspy_history_track = dspy_history_track

        if init_entity_types is not None:
            self.init_entity_types = init_entity_types
        
        self.entity_types = self.init_entity_types

        if extract_entities_mode is not None and extract_entities_mode in ["token", "fixed", "dynamic", "none"]:
            self.extract_entities_mode = extract_entities_mode
        else:
            self.extract_entities_mode = "token" # "token" , "fixed", "dynamic"

    def init_model(self, model: str = None, temperature: float = None, api_key: str = None, max_tokens: int = 30000):
        """Initialize or reinitialize the model with new parameters."""
        if model is not None:
            self.model = model
        if temperature is not None:
            self.temperature = temperature
        if api_key is not None:
            self.api_key = api_key
        
        self.max_tokens = max_tokens
        litellm.drop_params = True
        if self.api_key:
            self.lm = dspy.LM(model=self.model, api_key=self.api_key, temperature=self.temperature,  max_tokens=self.max_tokens)
        else:
            self.lm = dspy.LM(model=self.model, temperature=self.temperature,  max_tokens=self.max_tokens)

        dspy.configure(lm=self.lm)

    def get_dspy_history(self, file_path: Optional[str] = None):
        """
        Get or save the dspy operation history.
        
        Args:
            file_path: If None, returns the history list. If provided, saves to file.
            
        Returns:
            List of DSPyHistoryEntry if file_path is None, otherwise None
        """
        if file_path is None:
            return self.dspy_history
        else:
            # Save to file
            history_data = [entry.model_dump() for entry in self.dspy_history]
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(history_data, f, indent=2, ensure_ascii=False)
            return None

    def get_cache_info(self):
        """
        Get information about DSPy cache location and size.
        
        Returns:
            dict: Information about cache locations and their status
        """
        import os
        from pathlib import Path
        
        if self.dspy_cache_path:
            return self.dspy_cache_path

        possible_cache_paths = [
            Path.home() / ".dspy_cache",
            Path.home() / ".cache" / "dspy", 
            Path("/tmp/dspy_cache"),
            Path("/var/cache/dspy"),
            Path(os.environ.get("DSPY_CACHE_DIR", "")) if os.environ.get("DSPY_CACHE_DIR") else None
        ]
        
        cache_info = {}
        
        for cache_path in possible_cache_paths:
            if cache_path is None:
                continue
            
            if cache_path.exists() and cache_path.is_dir():
                try:
                    cache_files = list(cache_path.glob("**/*"))
                    
                    # Calculate total size
                    total_size = sum(f.stat().st_size for f in cache_files if f.is_file())
                    self.dspy_cache_path = str(cache_path)
                    return {"path": str(cache_path),
                            "file_count": len(cache_files),
                            "size_mb": total_size/(1024*1024)}
                    
                except Exception as e:
                    return None
            

        return None

    def clear_cache(self):
        """
        Clear the DSPy cache directory to force fresh LLM calls.
        
        """
        import shutil
        from pathlib import Path
        
        if self.clear_dspy_cache is False or self.dspy_cache_path is None:
            return False

        try:
            shutil.rmtree(self.dspy_cache_path)
        except Exception as e:
            return False

        return True


    # Knowledge graph Generation methods

    def init_graph(self, text: str = "", path: str = None):
        """Initialize an empty graph.
           If text is provided, initialize the graph with the text.
           If path is provided, load the graph from the file.
         """
        if path is None and text == "":
            raise ValueError("Either text or path must be provided to initialize the graph.")

        self.relation_embeddings = None
        
        if path is None:
            if self.chunk_size > 0:
                try:
                    from .utilities import chunk_text
                except ImportError:
                    from utilities import chunk_text
                texts = chunk_text(text, self.chunk_size)
                subgraphs = []
                for t in texts:
                    subgraphs.append(Graph(text=t, concepts=[], relation_objects=[]))
            else:
                subgraphs = [Graph(text=text, concepts=[], relation_objects=[])]
            self.graph = Graph(text=text, concepts=[], relation_objects=[], subgraphs=subgraphs)
        else:
            def custom_decoder(data):
                # This function is called for every object in the JSON data
                # We can check if it's a list that needs to be a tuple
                if isinstance(data, list) and len(data) == 3 and all(isinstance(i, str) for i in data):
                    # A simple check to see if this list should be a tuple
                    return tuple(data)
                return data
            
            with open(path, 'r') as f:
                cgraph_dict = json.load(f, object_hook=custom_decoder)

            self.graph = Graph(**cgraph_dict)
    
    def load_inception(self, path: str):
        """Load graph from Inception TSV file."""
        try:
            from .utilities.utils import inception2Graph, inception_to_graph, merge_nodes_by_group, inception_extract_text
        except ImportError:
            from utilities.utils import inception2Graph, inception_to_graph, merge_nodes_by_group, inception_extract_text
        
        self.graph = inception2Graph(path)
                    

    def dump_graph(self, file_path: str):
        """Dump the graph to a file."""
        
        def set_encoder(obj):
            if isinstance(obj, set):
                return list(obj)
            raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

        with open(file_path, 'w') as f:
            json.dump(self.graph.model_dump(), f, indent=2, ensure_ascii=False, default=set_encoder)


    #@dspy_track(dspy_type="Predict")
    def extractTokens(self, text: str):
        class ExtractTokens(dspy.Signature):
            """
            You are a tokenizer. Your task is to split the Hebrew source text into tokens. 
            Then, try to add part of speech for each token.
            Rules:
            - Each token must be represented as a JSON object with at least two fields: 
            "id" (incremental integer starting from 1) and "text" (the token string).
            - Multi‑word concepts (e.g., "ארץ ישראל", "ראש הממשלה נתניהו", "תורה שבע\"פ", "כסא כבוד","דוד בן גוריון") 
            must remain as a single token.
            - Preserve the original order of tokens.
            - Output only valid JSON: an array of objects.

            Output format example:
            [
            { "seq_id": 1, "value": "הרב מרדכי אליהו", "pos": "NNP" },
            { "seq_id": 2, "value": "אמר", "pos": "VB" },
            { "seq_id": 3, "value": "כי" , "pos": "CC"},
            { "seq_id": 4, "value": "יגיע", "pos": "VB" },
            { "seq_id": 5, "value": "לתפילה", "pos": "NN" },
            { "seq_id": 6, "value": "בתל אביב יפو", "pos": "NNP" }
            ]
            """

            source_text: str = dspy.InputField(desc="The text to extract tokens from.")
            tokens: List[Token] = dspy.OutputField(desc="List of valid tokens.")

        extract = dspy.Predict(ExtractTokens)
        tokens_result = extract(source_text=text)

        return tokens_result.tokens

    #@dspy_track
    def extractConcepts(self, text: str = None, verbose: bool = False):
        """Extract concepts from text.
           the text is chuncked into smaller parts (subgraphs) if chunk_size is provided.
           Concepts are extracted from each subgraph.
           Finally all subgraphs are merged into the main graph.        
         """
        
        def deDupConcepts(concepts: List[Concept]):
            # Remove duplicates
            ret = []
            ret_labels = []
            for c in concepts:
                if c.prefLabel not in ret_labels:
                    ret.append(c)
                    ret_labels.append(c.prefLabel)

            return ret
            

        def process_graph(lg: Graph):

            """Process a single graph to extract entities from the subgraphs in the self.graph."""
            
            if self.extract_entities_mode == "token": # First extract tokens+ POS, then extract entities from tokens
                lg.tokens = self.extractTokens(text=lg.text)

                class TokensToEntities(dspy.Signature):
                    """
                    Extract ALL individual concepts and entities from the tokens list.

                    Requirements:
                    - Extract every entity explicitly mentioned, including fine-grained subcomponents and broader categories.
                    - Use the part of speech in the tokens list to detect entity and concept.
                    - Use the source text to verify that it is a valid entity or concept.
                    - Each extracted entity MUST appear in the output as `prefLabel`.
                    - `altLabels` must always be an empty list [].
                    - `altLabels_en` must always be an empty list [].
                    - Provide SKOS-compatible Concept objects with source language/English labels and descriptions.
                    - For each entity, assign an entity_type.
                        * First, try to find an appropriate type from available_types.
                        * If multiple types in available_types are possible, choose the most specific one.
                        * If no type from available_types fits well, you MUST create a new short English type label (one or two words).
                        * IMPORTANT: Do not force every entity into available_types. Some entities may use new types.
                    - Be thorough and faithful to the reference text.
                    """

                    source_text: str = dspy.InputField(desc="Full source text for entity extraction.")
                    tokens_list: list[Token] = dspy.InputField(desc="A list of tokens, a part ofspeech is assigned for each token")
                    available_types: list[str] = dspy.InputField(desc="Example of high-level entity types. Use one of these types if applicable, but you can also create new types as needed.")
                    concepts: list[Concept] = dspy.OutputField(
                        desc="List of Concept objects. Each entity from the text appears as prefLabel. altLabels must remain empty. entity_type must remain empty."
                    )

                extract = dspy.Predict(TokensToEntities)
                result = extract(source_text=lg.text, tokens_list=lg.tokens, available_types=self.entity_types)
                                           
            elif self.extract_entities_mode == "fixed":
                class FixedTypeTextEntities(dspy.Signature):
                    """
                    Extract ALL individual concepts and entities from the source text.

                    Requirements:
                    - Extract every entity explicitly mentioned, including fine-grained subcomponents and broader categories.
                    - Do not merge distinct entities.
                    - Each extracted entity MUST appear in the output as `prefLabel`.
                    - `altLabels` must always be an empty list [].
                    - `altLabels_en` must always be an empty list [].
                    - Provide SKOS-compatible Concept objects with source language/English labels and descriptions.
                    - Entity_type must be one of the values from allowed_types.
                    - Be thorough and faithful to the reference text.
                    """

                    source_text: str = dspy.InputField(desc="Full source text for entity extraction.")
                    allowed_types: list[str] = dspy.InputField(desc="List of allowed high-level entity types.")
                    concepts: list[Concept] = dspy.OutputField(
                        desc="List of Concept objects. Each entity from the text appears as prefLabel. altLabels must remain empty. Each concept must include entity_type."
                    )
                
                extract = dspy.ChainOfThought(FixedTypeTextEntities)
                result = extract(source_text=lg.text, allowed_types=self.entity_types)
            elif self.extract_entities_mode == "dynamic":

                class DynamicTypeAndConsolidateTextEntities(dspy.Signature):
                    f"""
                    {self.persona}
                    
                    [TASK]
                    Extract a Knowledge Graph. Your most critical task is **Entity Resolution** (Merging synonyms).

                    [GENERIC MERGING RULES - APPLY TO ALL DOMAINS]
                    1. **Explicit Definitions:** Scan the text for *any* pattern where the author explicitly defines a short name for an entity.
                    - Legal Context: Parentheses like "(hereinafter: X)" or "(X)".
                    - News Context: Titles like "Prime Minister Netanyahu (Bibi)".
                    - Theology Context: Epithets like "The Almighty (God)".
                    
                    2. **The Merging Action:** When you find such a definition:
                    - **Subject:** The full/formal name (e.g., "Beit Balev Ltd").
                    - **Synonym:** The short name/alias (e.g., "The Company").
                    - **Output:** Create ONE Concept object. Put the alias in `altLabels`. Do NOT create a separate concept for the alias.

                    [OUTPUT REQUIREMENTS]
                    - `prefLabel`: The most specific, formal name.
                    - `altLabels`: All synonyms, nicknames, and defined aliases found in the text.
                    """

                    source_text: str = dspy.InputField(desc="Full source text for entity extraction.")
                    available_types: list[str] = dspy.InputField(desc="Examples of common high-level entity types.")
                    
                    concepts: list[Concept] = dspy.OutputField(
                        desc="List of unique Concept objects. Synonyms must be grouped into altLabels."
                    )

                class DynamicTypeTextEntities(dspy.Signature):
                    f"""
                    {self.persona}
                    Your task:
                    Extract ALL individual concepts and entities from the source text.

                    Requirements:
                    - Extract every entity explicitly mentioned.
                    - Each extracted entity MUST appear in the output as `prefLabel`.
                    - `altLabels` and `altLabels_en` must always be empty lists [].
                    - Provide SKOS-compatible Concept objects with source language/English labels and descriptions.
                    - Be thorough: Extract explicit entities and concepts.
                    
                    Entity Typing Logic:
                    1. Check if the entity fits into one of the `available_types`.
                    2. If it fits, use that type exactly.
                    3. If NO provided type fits, generate a new, specific English type label (PascalCase, e.g., 'ScientificTheory', 'SoftwareTool').
                    4. Do not force an entity into an available type if it clearly doesn't fit.
                    """

                    source_text: str = dspy.InputField(desc="Full source text for entity extraction.")
                    available_types: list[str] = dspy.InputField(desc="Examples of common high-level entity types. Prefer these if appropriate, but you may also propose new ones.")
                    concepts: list[Concept] = dspy.OutputField(
                        desc="List of Concept objects. Each entity from the text appears as prefLabel. altLabels must remain empty. Each concept must include entity_type."
                    )


                extract = dspy.ChainOfThought(DynamicTypeAndConsolidateTextEntities)
                result = extract(source_text=lg.text, available_types=self.entity_types)
            else:
                class NoTypeTextEntities(dspy.Signature):
                    """
                    Extract ALL individual concepts and entities from the source text.

                    Requirements:
                    - Extract every entity explicitly mentioned, including fine-grained subcomponents and broader categories.
                    - Do not merge distinct entities.
                    - Each extracted entity MUST appear in the output as `prefLabel`.
                    - `altLabels` must always be an empty list [].
                    - `altLabels_en` must always be an empty list [].
                    - Provide SKOS-compatible Concept objects with source language/English labels and descriptions.
                    - Be thorough and faithful to the reference text.
                    """

                    source_text: str = dspy.InputField(desc="Full source text for entity extraction.")
                    #available_types: list[str] = dspy.InputField(desc="Example of high-level entity types. Use one of these types if applicable, but you can also create new types as needed.")
                    concepts: list[Concept] = dspy.OutputField(
                        desc="List of Concept objects. Each entity from the text appears as prefLabel. altLabels must remain empty. entity_type must remain empty."
                    )

                extract = dspy.Predict(NoTypeTextEntities)
                result = extract(source_text=lg.text)


            #self.entity_types += [c.entity_type for c in result.concepts if c.entity_type not in self.entity_types]

            return result.concepts

        if text:
            self.init_graph(text=text)
        
        if self.graph.text is None:
            raise ValueError("Text must be provided for entity extraction.")

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            entity_sets = list(executor.map(process_graph, self.graph.subgraphs))

        for subgraph, concepts in zip(self.graph.subgraphs, entity_sets):
            subgraph.concepts = deDupConcepts(concepts)

        #merge subgraphs concepts to main graph
        graph_concept_labels = {c.prefLabel_he for c in self.graph.concepts}
        for subgraph in self.graph.subgraphs:
            # Merge only new concepts, that are concepts with new prefLabels_he
            # This ensures that we do not duplicate concepts already present in the main graph
            for c in subgraph.concepts:
                if c.prefLabel_he not in graph_concept_labels:
                    self.graph.concepts.append(c)
                    graph_concept_labels.add(c.prefLabel_he)
                else:
                    # Merge the description of the two concepts.
                    existing_concept = next((x for x in self.graph.concepts if x.prefLabel_he == c.prefLabel_he), None)
                    if existing_concept:
                        existing_concept.conceptDescription_he += f". {c.conceptDescription_he}"
                
        self.graph.concepts = deDupConcepts(self.graph.concepts)

        if verbose:
            print(f"Number of subgraphs: {len(self.graph.subgraphs)}")
            print(f"Number of concepts: {len(self.graph.concepts)}")
            print(f"concepts: " + ", ".join(self.graph.entity_labels))

    #@dspy_track(dspy_type="ChainOfThought")
    def extractAttributeRelations(self, verbose: bool = False):
        """Extract attribute relations (concept-to-datatype relations) for previously identified concepts."""
        
        if not self.graph.concepts:
            raise ValueError("No concepts found. Please run extractConcepts() first.")
        
        class ExtractAttributeRelations(dspy.Signature):
            """
            Given a text and a list of concepts, extract attribute relations (concept-to-datatype relations).
            Verify that 'subject' matches one of the concept names exactly.
            
            For each concept mentioned in the text, identify datatype properties like:
            - Descriptive properties (e.g., "tall", "ancient", "important")
            - Categorical attributes (e.g., "type", "role", "status")  
            - Quantitative measures (e.g., "age", "size", "duration")
            - Temporal attributes (e.g., "birth date", "founding year")
            
            Convert each attribute to a proper relation:
            - subject: The concept name (must match input concepts exactly)
            - predicate: English verb phrase in CamelCase (e.g., "hasAge", "hasRole", "hasStatus")
            - object: The attribute value (string, number, or description)
            - object_type: Always "Value" (since these are datatype properties)
            
            Only extract attributes that are explicitly mentioned or strongly implied in the text.
            """
            
            source_text: str = dspy.InputField(desc="Text to analyze for concept attributes")
            concepts: List[str] = dspy.InputField(desc="List of concept names to find attributes for")
            attribute_relations: List[RelationOld] = dspy.OutputField(desc="Attribute relations with object_type='Value'")
        
        def process_subgraph(subgraph: Graph):
            """Extract attribute relations for concepts in a single subgraph."""
            if not subgraph.concepts:
                return []
            concept_names = [c.prefLabel_he for c in subgraph.concepts]
            
            extract = dspy.ChainOfThought(ExtractAttributeRelations)
            result = extract(source_text=subgraph.text, concepts=concept_names)
            
            return result.attribute_relations
        
        # Process all subgraphs in parallel
        with ThreadPoolExecutor() as executor:
            attribute_relation_sets = list(executor.map(process_subgraph, self.graph.subgraphs))
        
        # Attach attribute relations back to subgraphs
        for subgraph, attr_rel_set in zip(self.graph.subgraphs, attribute_relation_sets):
            subgraph.relation_objects.extend(attr_rel_set)
        
        # Collect all attribute relations from subgraphs
        all_attribute_relations = []
        for attr_rel_set in attribute_relation_sets:
            all_attribute_relations.extend(attr_rel_set)
        
        # Add attribute relations to the main graph's relation objects
        self.graph.relation_objects.extend(all_attribute_relations)
        
        if verbose:
            print(f"Extracted {len(all_attribute_relations)} attribute relations")
            value_relations = [r for r in all_attribute_relations if r.object_type == "Value"]
            print(f"Added {len(value_relations)} Value-type relations to the graph")

        return all_attribute_relations

    #@dspy_track(dspy_type="ChainOfThought") 
    def extractRelations(self, text: str = None, context: str = "", verbose: bool = False):
        """Extract relations from text, robust to schema errors and rate limits."""

        
        class ExtractTextRelations(dspy.Signature):
            """
            Extract subject–predicate–object triples from the source text.

            Rules:
            - Subject and object MUST be chosen verbatim from the 'entities' list.
            - Check every pair of entities for possible relations in the text.
            - Detect relations not only from explicit verbs, but also from possessives, appositions, and contextual mentions.
                For example:
                * "יועץ השרה" → (X, "hasAdvisor", advisor)
                * "ראש הלשכה שלה" → (Person, "hasChiefOfStaff", Role)
            - Predicate MUST be in English, expressed as a short verb phrase and in CamelCase.
            - If no valid triple exists, return [].
            - object_type is always "Entity"
            - Do not output commentary, only structured JSON.

            Output format example:
            [
            {"subject": "Entity1", "predicate": "isLocatedIn", "object": "Entity2", "object_type": "Entity"},
            {"subject": "Entity3", "predicate": "isPartOf", "object": "Entity4", "object_type": "Entity"}
            ]
            """

            source_text: str = dspy.InputField(desc="The text to extract relations from.")
            entities: List[str] = dspy.InputField(desc="List of valid entities. Subjects/objects MUST come from this list.")
            relations: List[RelationOld] = dspy.OutputField(desc="List of subject–predicate–object triples.")



        def process_graph(lg) -> List[RelationOld]:
            """Extract relations for a single subgraph, with retry on rate-limit."""

            retries = 0
            while True:
                try:
                    extract = dspy.ChainOfThought(ExtractTextRelations)
                    result = extract(source_text=lg.text, entities=list(lg.entity_labels))
                    break
                except Exception as e:
                    if "RateLimitError" in str(e) and retries < 5:
                        wait_time = 2 ** retries
                        if verbose:
                            print(f"Rate limit hit. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                        retries += 1
                    else:
                        raise

            valid_entities = lg.entity_labels
            res_relations = []

            for r in result.relations:
                subj = r.subject.strip()
                obj = r.object.strip()
                pred = r.predicate.strip()
                obj_type = r.object_type.strip()

                # Filter subject/object
                if subj not in valid_entities or obj not in valid_entities:
                    continue

                # Validate predicate is English
                if not is_english(pred):
                    if verbose:
                        print(f"Dropped non-English predicate: {pred}")
                    continue

                # Create and store full Relation object
                relation_obj = Relation(
                    subject=subj,
                    predicate=pred,
                    object=obj,
                    object_type=obj_type
                )
                res_relations.append(relation_obj)

            return res_relations


        # If text is provided, update graph text
        if text:
            self.graph.text = text

        if self.graph.text is None:
            raise ValueError("Text must be provided for relation extraction.")

        if len(self.graph.concepts) == 0:
            raise ValueError("Concepts must be extracted before relations can be extracted.")

        # Concurrency control to respect rate limits
        with ThreadPoolExecutor(max_workers=2) as executor:
            relation_sets = list(executor.map(process_graph, self.graph.subgraphs))

        # Attach relations back to subgraphs
        for subgraph, relation_objects in zip(self.graph.subgraphs, relation_sets):
            subgraph.relation_objects += relation_objects

        # Merge subgraph relations into main graph
        all_relation_objects = []
        for subgraph in self.graph.subgraphs:
            all_relation_objects.extend(subgraph.relation_objects)

        # Store relation objects
        self.graph.relation_objects = all_relation_objects

        if verbose:
            print(f"Number of RDF relations: {len(self.graph.relation_objects)}")

        # Store baseline graph
        base_graph = Graph(
            text=self.graph.text,
            concepts=[c for c in self.graph.concepts],  # Copy concepts
            relation_objects=[r for r in self.graph.relation_objects],  # Copy relation objects
        )
        self.graph.base_graph = base_graph


    #@dspy_track(dspy_type="ChainOfThought")
    def groupConcepts(self, op_mode = "merge", chunk_size: int = 50, threshold: int = 100, max_iterations=2, verbose: bool = False):
        '''
        Convert (merge/connect) entities to concepts using a dspy signature.
        '''

        def alignNodesEdges():
            # convert entity labels to the concept prefLabel_he using altLabels mapping
            label2concept = {
                                label: concept.prefLabel_he
                                for concept in self.graph.concepts
                                for label in concept.altLabels_he
                            }
            
            # Update relation objects with new canonical labels
            for relation in self.graph.relation_objects:
                relation.subject = label2concept.get(relation.subject, relation.subject)
                relation.object = label2concept.get(relation.object, relation.object) 

        def groupConceptsLargeLLM(chunk_size= chunk_size, threshold= threshold, max_iterations= max_iterations,verbose: bool = verbose):
            """
            Scalable concept grouping using LLM with parallel batching.
            
            Args:
                chunk_size (int): Number of concepts per batch (to fit LLM context).
                threshold (int): When the number of concepts drops below this, 
                                run a final global merge in one pass.
                max_iterations (int): Maximum number of iterations to prevent infinite loops.
                verbose (bool): Print progress info.
            """

            class GroupConcepts(dspy.Signature):
                """
                You are an expert in ontology engineering and Hebrew linguistic normalization.

                You receive:
                - A list of Concept objects, each with canonical labels, alternate labels, and a Hebrew description.

                The concepts may contain duplicates due to:
                - Relating the same concept in different ways, for example "Benjamin Netanyahu" and "Israeli Prime Minister".
                - Synonyms, for example "רכב" and "מכונית".
                - Spelling variations, for example "ירושלים" and "ירושליים". 
                - Typographical errors, for example "דמותו" and "רמותו". 
                - Plural vs. singular forms, for example "מלאכים" and "מלאך".
                - Morphological forms
                - Presence or absence of diacritics

                Your task:
                1. Analyze the concepts (prefLabel, altLabels, conceptDescription, attributes).
                2. Detect groups of concepts that clearly refer to the same underlying meaning.
                3. For each group:
                    - Select ONE canonical concept to keep.
                    - Populate its 'altLabels' with prefLabel values of all grouped concepts.
                    - Populate its 'altLabels_en' with English translations of all grouped concepts.
                    - Rewrite or extend the conceptDescription to reflect the merged group.
                4. Do not omit any required field, even if you must use a minimal placeholder like 'No description provided.'”
                5. Ensure every input concept is accounted for in exactly one output group (no omissions).
                6. Do not invent new concepts — only reorganize the provided ones.
                
                Output MUST be a JSON object with exactly one top-level field: 'grouped_concepts',
                which is a list of Concept objects.

                Example:
                {
                "grouped_concepts": [
                    {
                    "prefLabel": "אידיאות חדשות",
                    "prefLabel_en": "New Ideas",
                    "altLabels": ["אידיאות חדשות"],
                    "altLabels_en": ["New Ideas"],
                    "conceptDescription": "רעיונות חדשים המתפתחים...",
                    "conceptDescription_en": "New developing ideas...",
                    }
                ]
                }
                            
                """

                concepts: List[Concept] = dspy.InputField(
                    desc="List of Concept objects extracted from the text, with labels and descriptions."
                )
                grouped_concepts: List[Concept] = dspy.OutputField(
                    desc="List of merged Concept objects, Each object MUST include prefLabel, prefLabel_en, altLabels, altLabels_en, conceptDescription, conceptDescription_en (non-empty strings)"
                )

            def process_chunk(chunk):
                """Process one chunk of concepts with the LLM."""
                extract = dspy.ChainOfThought(GroupConcepts)
                result = extract(concepts=chunk)
                return result.grouped_concepts

            current_concepts = self.graph.concepts

            round_no = 1
            while len(current_concepts) > threshold:
                if verbose:
                    print(f"[Round {round_no}] Grouping {len(current_concepts)} concepts in parallel batches...")

                # Split into chunks
                chunks = [current_concepts[i:i + chunk_size] for i in range(0, len(current_concepts), chunk_size)]

                # Process chunks in parallel
                with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                    results = list(executor.map(process_chunk, chunks))

                # Flatten results
                current_concepts = [c for group in results for c in group]

                if verbose:
                    print(f"[Round {round_no}] Reduced to {len(current_concepts)} concepts.")
                round_no += 1

                if round_no > max_iterations:
                    print(f"Reached maximum iterations ({max_iterations}). Stopping early.")
                    break

            # Final consolidation pass
            if len(current_concepts) <= threshold:
                if verbose:
                    print(f"[Final Round] Consolidating {len(current_concepts)} concepts in a single pass.")
                extract = dspy.ChainOfThought(GroupConcepts)
                result = extract(concepts=current_concepts)
                current_concepts = result.grouped_concepts
            
            return current_concepts


        #self.graph.concepts = mergeConceptsLLM()
        self.graph.concepts =  groupConceptsLargeLLM(chunk_size = chunk_size, threshold = threshold, max_iterations=max_iterations,verbose= verbose)
        if verbose:
            print(f"Number of concepts after grouping: {len(self.graph.concepts)}")
        
        alignNodesEdges()
        
        base_graph = Graph(
            text=self.graph.text,
            concepts=[c for c in self.graph.concepts],  # Copy concepts 
            relation_objects=[r for r in self.graph.relation_objects],  # Copy relation objects
        )
        self.graph.base_graph = base_graph  # Store the initial graph before any processing or merging


    #@dspy_track(dspy_type="Predict")
    def ontologyRecommendation(self):
        if self.graph.base_graph is None:
            return "No base graph available. Please run extract_entities and extract_relations first."
        
        class OntologySelector(dspy.Signature):
            """
            Given:
                - A set of candidate ontologies with their relations and descriptions.
                - A list of target relations (in natural language, possibly multilingual).
            Task:
                - Select the ontology that best covers the given relations.
                - Justify the choice with reference to ontology focus (events, places, names, metadata).
            Output:
                - primary_ontology: str (name of the ontology that best fits)
                - mapping_strategy: str (how relations map to the ontology concepts)
                - rationale: str (explanation of why this ontology is the best fit)
            """

            candidate_ontologies = dspy.InputField(type=str, desc="Ontology descriptions and relation sets, as text")
            target_relations = dspy.InputField(type=list, desc="List of relations to be modeled")
            primary_ontology = dspy.OutputField(type=str, desc="Name of best ontology")
            mapping_strategy = dspy.OutputField(type=str, desc="How to map input relations to ontology properties")
            rationale = dspy.OutputField(type=str, desc="Explanation of the decision")

        # Get the path to the ontologies.txt file relative to this module
        import os
        current_dir = os.path.dirname(os.path.abspath(__file__))
        ontologies_file = os.path.join(current_dir, "ontologies.txt")
        
        with open(ontologies_file, "r") as f:
            ontologies_text = f.read()

        extract = dspy.Predict(OntologySelector)
        result = extract(candidate_ontologies=ontologies_text, target_relations=list(self.graph.base_graph.relations))
        respond = f"Based on the relations extracted, The Primary Ontology: {result.primary_ontology}\nThe mapping strategy: {result.mapping_strategy}\nRationale: {result.rationale}"
        return respond


    #@dspy_track(dspy_type="Predict")
    def relations2ontology(self, ontologies: list[str] = ["SKOS"], granularity: str = "MEDIUM"):
        """
        Convert (merge/connect) relations to predicates using a dspy signature.
        This function uses a dspy signature to normalize relations into predicates.
        The granularity parameter controls how aggressively relations are merged:
        - HIGH: Merge broadly, combining many near-synonyms.
        - MEDIUM: Merge clear synonyms but keep distinct semantic categories.
        - LOW: Keep relations as distinct as possible, only merge exact or trivial variants.
        """

        def load_precomputed_ontologies_embeddings(ontology_embedding_files: list[str]):
            """
            Load precomputed ontology embeddings from ALL ontology files and combine them.
            
            Args:
                ontology_embedding_files: List of paths to ontology embedding files
                
            Returns:
                tuple: (combined_ontology_embeddings, all_ontology_labels)
            """
            all_ontology_embeddings = []
            all_ontology_labels = []
            
            for ontology_file in ontology_embedding_files:
                ontology_embeddings, ontology_labels, _ = load_ontology_embeddings(ontology_file)
                all_ontology_embeddings.append(ontology_embeddings)
                all_ontology_labels.extend(ontology_labels)
            
            # Concatenate all embeddings into a single matrix
            combined_ontology_embeddings = np.vstack(all_ontology_embeddings)
            
            return combined_ontology_embeddings, all_ontology_labels

        def getPredicateByCosineOntology(combined_ontology_embeddings, all_ontology_labels, 
                     model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"):
            """
            Use Ontology relations to map raw relations to preferred labels,
            and return them as a list of Predicate objects.
            
            Args:
                combined_ontology_embeddings: Combined embeddings matrix from all ontologies
                all_ontology_labels: List of all ontology labels corresponding to embeddings
                model_name: Name of the sentence transformer model to use
            """
            from sentence_transformers import SentenceTransformer
            from sklearn.metrics.pairwise import cosine_similarity
            from collections import defaultdict
            try:
                from .models import Predicate
            except ImportError:
                from models import Predicate

            # 1. Collect raw relations (predicates from relation objects)
            raw_relations = [r.predicate for r in self.graph.base_graph.relation_objects]

            # 2. Check if relation embeddings are already loaded, if not create them
            # This is done to avoid recomputing embeddings for the same relations.
            if self.relation_embeddings is None:
                model = SentenceTransformer(model_name)
                self.relation_embeddings = model.encode(raw_relations, convert_to_numpy=True, normalize_embeddings=True)

            # 3. Map each raw relation to the closest ontology label across ALL ontologies
            cluster_map = defaultdict(list)

            for rel, emb in zip(raw_relations, self.relation_embeddings):
                sims = cosine_similarity([emb], combined_ontology_embeddings)[0]
                best_idx = int(np.argmax(sims))
                best_ontology = all_ontology_labels[best_idx]
                cluster_map[best_ontology].append(rel)

            # 4. Build Predicate objects
            predicates = []
            for ontology_label, variants in cluster_map.items():
                pred = Predicate(
                    prefLabel_en=ontology_label,
                    altLabels_en=sorted(set(variants)),
                    mapping_examples=variants  # here you keep all, or sample if too many
                )
                predicates.append(pred)
            
            class Predicates(BaseModel):
                """List of predicates extracted from the ontology."""
                predicates: List[Predicate] = Field(..., description="List of predicates with preferred and alternate labels.")

            # 5. Return as Predicates model
            predicates_model = Predicates(predicates=predicates)
            return predicates_model

        def createLLMOntology(granularity: str = "MEDIUM"):
            """Use LLM to propose merge of entities into higher level concepts."""
            
            try:
                from .models import Predicate
            except ImportError:
                from models import Predicate
            
            class RelationsNormalization(dspy.Signature):
                """
                You are an expert in ontology engineering, SKOS design, and relation normalization.

                You receive:
                - A list of subject–predicate–object triplets, where the predicate (middle element) is the relation to normalize.

                The predicates may contain duplicates or variants due to:
                - Synonyms
                - Morphological or tense variation
                - Different phrasings of the same underlying relation

                Your task:
                1. Extract all unique relation labels from the middle element of each triplet.
                2. Group semantically equivalent relations together.
                3. Merge according to the specified granularity level:
                   - HIGH: Merge broadly, combining many near-synonyms.
                   - MEDIUM: Merge clear synonyms but keep distinct semantic categories.
                   - LOW: Keep relations as distinct as possible, only merge exact or trivial variants.
                4. For each group:
                    a. Choose ONE canonical English label (short, ontology-ready form, e.g., 'isPartOf', 'contains').
                    b. List all other variants as alternate labels.
                    c. Provide representative examples from the input triplets that demonstrate usage of the relation.

                Structure the output as a list of relation groups:
                - "prefLabel_en": canonical predicate
                - "altLabels_en": synonyms/variants
                - "mapping_examples": original forms drawn from the triplets
                """

                triplets: list[tuple[str, str, str]] = dspy.InputField(
                    desc="List of subject–predicate–object triplets; normalize only the middle element (relation)"
                )
                granularity: str = dspy.InputField(
                    desc="Granularity of merging: HIGH (broad merges), MEDIUM (moderate merges), LOW (fine-grained distinctions)"
                )
                predicates: list[Predicate] = dspy.OutputField(
                    desc="Normalized relations grouped under canonical labels"
                )

            # Use relation objects to create triplets data
            triplets_data = [(r.subject, r.predicate, r.object) for r in self.graph.relation_objects]
                
            extract = dspy.Predict(RelationsNormalization)
            predicates = extract(triplets=triplets_data, granularity=granularity)
            return predicates


        if "LLM" in ontologies:
            new_predicates = createLLMOntology(granularity=granularity)
        else:
            # Check available ontology embedding files
            ontology_embedding_files = []
            for o in ontologies:
                of = os.getenv(o, None)
                if of is None:
                    raise ValueError(f"Ontology embedding file not found for mode {o}. Please set the environment variable.")
                ontology_embedding_files.append(of)

            # Load precomputed ontology embeddings
            combined_ontology_embeddings, all_ontology_labels = load_precomputed_ontologies_embeddings(ontology_embedding_files)
            
            # Get predicates using the loaded embeddings
            new_predicates = getPredicateByCosineOntology(combined_ontology_embeddings, all_ontology_labels)

        if len(ontologies) == 1:
            self.graph.ontologies[ontologies[0]] = new_predicates.predicates
        else:
            self.graph.ontologies["MIX"] = new_predicates.predicates


    def graph2Ontology(self, ontology = "SKOS"):
        """
        
        """

        def checkRelation(relation: RelationOld, relation2predicate: dict) -> RelationOld:
            """Check if the relation predicate needs to be changed to a preferred label."""
            if relation.predicate in relation2predicate:
                # Create new relation with updated predicate
                return RelationOld(
                    subject=relation.subject,
                    predicate=relation2predicate[relation.predicate],
                    object=relation.object,
                    object_type=relation.object_type
                )
            return relation

        
        if ontology not in self.graph.ontologies:
            return

        # Restore Base Graph
        if self.graph.base_graph is not None:
            self.graph.concepts = [c for c in self.graph.base_graph.concepts]
            self.graph.relation_objects = [r for r in self.graph.base_graph.relation_objects]
            self.graph.text = self.graph.base_graph.text

        #mergePredicates(self.graph.ontologies[ontology])
        
        # relation to predicate dictionary
        rel2pred = {}
        for predicate in self.graph.ontologies[ontology]:
            for alt_label in predicate.altLabels_en:
                rel2pred[alt_label] = predicate.prefLabel_en

        # Update relation objects with ontology predicates
        new_relation_objects = [checkRelation(rel, rel2pred) for rel in self.graph.relation_objects]
        self.graph.relation_objects = new_relation_objects


    def generateKG(self, text_path: str, text_file_name: str, ontologies: list, viz_path: str = None, chunk_size: int = 0, verbose: bool = False, save_graph_path: str = None, init_entity_types: list = None, extract_entities_mode: str = None):
        try:
            with open(f"{text_path}{text_file_name}", "r", encoding="utf-8") as file:
                text = file.read()
                text = text.strip().replace("\n", " ")
        except FileNotFoundError:
            raise ValueError(f"File not found: {text_path}")
        except Exception as e:
            raise ValueError(f"Error reading file {text_path}: {e}")
        
        # Reset the mode to extract concepts and the available entity types.
        self.set_params(init_entity_types, extract_entities_mode)

        # Extract concepts
        try:
            self.extractConcepts(text=text, chunk_size=chunk_size)
            if verbose:
                print(f"Number of subgraphs: {len(self.graph.subgraphs)}")
                print(f"Number of Concepts: {len(self.graph.concepts)}")
                print(f"Concepts list: " + ", ".join(self.graph.entity_labels))
        except ValueError as e:
            print(f"Error processing concepts: {e}")
            return
        
        try:
            self.extractAttributeRelations(verbose=verbose)
            if verbose:
                value_relations = [r for r in self.graph.relation_objects if r.object_type == "Value"]
                print(f"Total attribute relations extracted: {len(value_relations)}")
        except ValueError as e:
            print(f"Error processing attribute relations: {e}")
            return

        try:
            self.extractRelations()
            if verbose:
                print(f"Number of subgraphs: {len(self.graph.subgraphs)}")
                print(f"Number of RDF relations: {len(self.graph.relation_objects)}")
        except ValueError as e:
            print(f"Error processing relations: {e}")
            return
                
        try:
            self.groupConcepts()
            if verbose:
                print(f"Number of concepts: {len(self.graph.concepts)}")
                print(f"Concepts list: " + ", ".join([c.prefLabel_he for c in self.graph.concepts]))
        except ValueError as e:
            print(f"Error processing concepts: {e}")
            return
        

        for ontology in ontologies:
            try:
                self.relations2ontology(ontologies=[ontology], granularity="MEDIUM")
                if verbose:
                    print(f"Ontology {ontology}: prepared")
            except ValueError as e:
                print(f"Error processing ontology {ontology}: {e}")
                continue

        if save_graph_path:
            try:
                self.graph.save_graph(f"{save_graph_path}{text_file_name.split('.')[0]}_c{chunk_size}_graph.json")
                if verbose:
                    print(f"Graph saved to {save_graph_path}{text_file_name.split('.')[0]}_c{chunk_size}_graph.json")
            except Exception as e:
                print(f"Error saving graph: {e}")

        if viz_path:
            file_name = text_file_name.split(".")[0]
            for ontology in ontologies:
                try:
                    self.graph2Ontology(ontology=ontology)
                    if verbose:
                        print(f"Ontology {ontology}: converted to graph relations")
                    viz = self.visualize(f"{viz_path}{file_name}_c{chunk_size}_ontology_{ontology}.html")
                except ValueError as e:
                    print(f"Error converting ontology {ontology} to graph: {e}")
                    continue

                
    def visualize(self, output_path=None):
        from pyvis.network import Network
        from collections import defaultdict
        import math
        import random

        def random_color():
            """Generate a random pastel color in hex."""
            # Generate slightly lighter pastel colors
            r = int(127 + random.random() * 128)
            g = int(127 + random.random() * 128)
            b = int(127 + random.random() * 128)
            return f"#{r:02x}{g:02x}{b:02x}"

        def graph_to_pyvis_data():
            """Convert a Graph object into pyvis-compatible node and edge lists."""
            nodes = []  # list of dicts: {id, label, title, color, size, ...}
            edges = []  # list of dicts: {source, target, label, title, color, ...}

            default_entity_node_color = "#ADD8E6"  # Light blue for entities
            default_value_node_color = "#90EE90"   # Light green for values
            default_edge_color = "#A9A9A9"  # Dark gray
            cluster_colors = {}
            edge_cluster_colors = {}
            node_degrees = defaultdict(int)  # To calculate node sizes
            created_nodes = set()  # Track which nodes we've already created

            # Pre-calculate degrees from relation objects
            for rel in self.graph.relation_objects:
                node_degrees[rel.subject] += 1
                node_degrees[rel.object] += 1

            # Use concepts for entity nodes (richer information than plain entities)
            for concept in self.graph.concepts:
                entity = concept.prefLabel_he
                degree = node_degrees.get(entity, 0)

                size = min(max(10 + 5 * math.log(1 + degree), 10), 40)
                # Limit label to 15 characters
                display_label = entity[:15] + "..." if len(entity) > 15 else entity
                # Use simple text for title instead of HTML (pyvis sometimes has issues with HTML)
                title = f"Full Name: {entity} | Type: {concept.entity_type} | Description: {concept.conceptDescription_he}"
                nodes.append(
                    {
                        "id": entity,
                        "label": display_label,
                        "title": title,
                        "color": default_entity_node_color,
                        "size": size,
                        "shape": "dot",
                    }
                )
                created_nodes.add(entity)

            # Create nodes for Value-type relation objects (attributes)
            for rel in self.graph.relation_objects:
                if rel.object_type == "Value" and rel.object not in created_nodes:
                    degree = node_degrees.get(rel.object, 0)
                    size = min(max(8 + 3 * math.log(1 + degree), 8), 30)  # Slightly smaller for values
                    # Limit label to 15 characters
                    display_label = rel.object[:15] + "..." if len(rel.object) > 15 else rel.object
                    # Use simple text for title instead of HTML
                    title = f"Full Value: {rel.object} | Predicate: {rel.predicate} | Subject: {rel.subject}"
                    nodes.append(
                        {
                            "id": rel.object,
                            "label": display_label,
                            "title": title,
                            "color": default_value_node_color,
                            "size": size,
                            "shape": "square",  # Square shape for values
                        }
                    )
                    created_nodes.add(rel.object)

            # Use relation objects for edges
            unique_preds = {rel.predicate for rel in self.graph.relation_objects}
            pred_colors = {pred: random_color() for pred in unique_preds}
            
            for rel in self.graph.relation_objects:
                # Use different colors for Value vs Entity relations
                if rel.object_type == "Value":
                    color = "#228B22"  # Forest green for value relations
                else:
                    color = pred_colors.get(rel.predicate, default_edge_color)
                
                # Use simple text for title instead of HTML
                title = f"Relation: {rel.predicate} | Type: {rel.object_type} | From: {rel.subject} | To: {rel.object}"
                edges.append(
                    {
                        "source": rel.subject,
                        "target": rel.object,
                        "label": rel.predicate,
                        "title": title,
                        "color": color,
                    }
                )

            return nodes, edges



        """Render the graph object to an interactive HTML file using pyvis."""
        # Check if graph has concepts and relations
        has_data = (self.graph and self.graph.concepts and self.graph.relation_objects)
        if not has_data:
            raise ValueError("Error: Cannot visualize empty or invalid graph\n")

        nodes, edges = graph_to_pyvis_data()

        try:
            net = Network(
                height="800px",
                width="100%",
                directed=True,
                notebook=output_path is None,
                cdn_resources="remote",
                
            )
        except Exception as e:
            raise ValueError(f"Error initializing Network: {e}\n")
            
        # Enhanced aesthetics and physics options - Removed comments for JSON compatibility
        net.set_options(
            """
            var options = {
            "nodes": {
                "font": {"size": 14, "face": "tahoma"},
                "borderWidth": 1,
                "borderWidthSelected": 2
            },
            "edges": {
                "arrows": {"to": {"enabled": true, "scaleFactor": 0.6}},
                "color": {"inherit": false},
                "smooth": {"type": "dynamic", "roundness": 0.2},
                "font": {"size": 11, "face": "tahoma", "align": "middle", "strokeWidth": 2, "strokeColor": "#ffffff"},
                "width": 1.5,
                "hoverWidth": 0.5,
                "selectionWidth": 1
            },
            "physics": {
                "enabled": true,
                "barnesHut": {
                "gravitationalConstant": -25000,
                "centralGravity": 0.1,
                "springLength": 120,
                "springConstant": 0.05,
                "damping": 0.15,
                "avoidOverlap": 0.5
                },
                "maxVelocity": 50,
                "minVelocity": 0.5,
                "solver": "barnesHut",
                "stabilization": {
                "enabled": true,
                "iterations": 1000,
                "updateInterval": 50,
                "onlyDynamicEdges": false,
                "fit": true
                },
                "timestep": 0.5,
                "adaptiveTimestep": true
            },
            "interaction": {
                "dragNodes": true,
                "dragView": true,
                "hideEdgesOnDrag": false,
                "hideNodesOnDrag": false,
                "hover": true,
                "hoverConnectedEdges": true,
                "keyboard": {"enabled": true},
                "multiselect": true,
                "navigationButtons": true,
                "selectable": true,
                "selectConnectedEdges": true,
                "tooltipDelay": 200,
                "zoomView": true
            },
            "manipulation": {
                "enabled": false
            }
            }
            """
        )

        # Add nodes and edges with specific properties
        try:
            for n in nodes:
                net.add_node(
                    n["id"],
                    label=n["label"],
                    title=n.get("title"),  # HTML title for hover tooltip
                    color=n.get("color"),
                    size=n.get("size"),
                    shape=n.get("shape", "dot"),  # Use shape if defined
                )

            for e in edges:
                net.add_edge(
                    e["source"],
                    e["target"],
                    label=e.get("label"),
                    title=e.get("title"),  # HTML title for hover tooltip
                    color=e.get("color"),
                )

            if output_path is None:
                return net
            else:
                net.write_html(output_path)
            #print(f"Successfully generated visualization: {output_path}")
        except Exception as e:
            #print(f"edge: {e}\nnodes: {nodes}\n edges: {edges}")
            raise ValueError(f"Error generating HTML file with pyvis: {e}")


    @dspy_clean_cache_wrapper
    def extractStatements(self, text: str = None):
        
        class ExtractStatements(dspy.Signature):
            f"""
            {self.persona}
            ROLE: Extract GRANULAR atomic statements for a Knowledge Graph.
            
            DECOMPOSITION RULES:
            1. ONE FACT PER STATEMENT: Do not combine location and date. Do not combine entity name and ID.
            2. SEPARATE ALIASES: "Hereinafter defined as X" must be its own separate statement.
            3. SEPARATE IDs: Company IDs (H.P.) must be their own statement linking the ID to the entity.
            4. NO COMPOUND SENTENCES: Break "Signed in X on Y" into "Signed in X" and "Signed on Y".
            
            INPUT:
            Hebrew legal text chunk.
            
            OUTPUT:
            List of distinct, atomic Hebrew statements.
            """
            source_text: str = dspy.InputField(desc="Raw Hebrew text chunk")
            # Using ChainOfThought usually helps the model plan the decomposition
            statements: List[Statement] = dspy.OutputField(desc="List of atomic statements in Hebrew")
        extract = dspy.ChainOfThought(ExtractStatements)
        result = extract(source_text=text)
        
        return result.statements


class NKGGenerator:
    
    def __init__(self, model: str , api_key: str , temperature: float = 0.0, api_base: str = None, 
                 chunk_size: int = 0, init_entity_types: List[str] = None, 
                 persona: str = "", signature_module: str = "signatures_legal",
                 chunk_overlap_sentences: int = 2, pipeline: dict = None,
                 log_level: str = "INFO", log_to_file: bool = False, log_file_path: str = None,
                 clustering_distance_threshold: float = 1.5, chunk_by_sentences: bool = False,
                 normalize_text_for_matching=None):
        """
        Initialize the Knowledge Graph Generator with model configuration.
        
        Args:
            model: LLM model name (e.g., "gpt-4", "claude-3")
            api_key: API key for the model
            temperature: Model temperature (0.0-1.0)
            api_base: Custom API base URL (optional)
            chunk_size: Text chunking size (0 for no chunking)
            init_entity_types: Initial entity types to consider
            persona: Extraction persona/role
            signature_module: Python module containing signature registry 
                            (e.g., "signatures_legal", "signatures_rabbinic")
            log_level: Logging level ("DEBUG", "INFO", "WARNING", "ERROR")
            log_to_file: Whether to log to file instead of console
            log_file_path: Path to log file (auto-generated if None)
        """

        self.model = model
        self.api_key = api_key

        self.max_workers = 1
        self.dspy = dspy
        
        self.temperature = temperature
        
        self.api_base = api_base
        self.graph = None
        
        # Setup logging
        self._setup_logging(log_level, log_to_file, log_file_path)
        
        # Load signature registry
        self.signature_registry = self._load_signature_registry(signature_module)

        self.set_params(init_entity_types, persona, chunk_size, chunk_overlap_sentences=chunk_overlap_sentences,
                        pipeline=pipeline, clustering_distance_threshold=clustering_distance_threshold,
                        chunk_by_sentences=chunk_by_sentences, normalize_text_for_matching=normalize_text_for_matching)
        
        if model is not None and api_key is not None:
            self.init_model(model, temperature, api_key, api_base)

    def _setup_logging(self, log_level: str, log_to_file: bool, log_file_path: str = None):
        """Setup logging configuration for the NKGGenerator instance."""
        # Create a unique logger for this instance
        logger_name = f"NKGGenerator_{id(self)}"
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(getattr(logging, log_level.upper()))
        
        # Clear any existing handlers
        self.logger.handlers.clear()
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        if log_to_file:
            if log_file_path is None:
                # Auto-generate log file path
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                domain = self.signature_registry.get_domain_name() if hasattr(self, 'signature_registry') else "unknown"
                log_file_path = f"nkgGenerator_{domain}_{timestamp}.log"
            
            # Ensure log directory exists
            log_dir = os.path.dirname(log_file_path)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)
            
            # File handler
            file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            
            self.logger.info(f"Logging initialized. Log file: {log_file_path}")
        else:
            # Console handler
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)

    def _log(self, message: str, level: str = "INFO", verbose_override: bool = None):
        """
        Unified logging method that respects verbose flags.
        
        Args:
            message: Message to log
            level: Log level ("DEBUG", "INFO", "WARNING", "ERROR")
            verbose_override: If provided, overrides method's verbose parameter
        """
        if verbose_override is not None:
            should_log = verbose_override
        else:
            # For backward compatibility, you might want to add a global verbose flag
            should_log = getattr(self, '_global_verbose', True)
        
        if should_log:
            log_method = getattr(self.logger, level.lower())
            log_method(message)

    def _load_signature_registry(self, module_name: str):
        """
        Dynamically load signature registry from specified module.

        Args:
            module_name: Python module name (e.g., "signatures_legal", "signatures_rabbinic")

        Returns:
            SignatureRegistry instance

        Raises:
            ValueError: If module can't be imported or doesn't contain a valid registry
        """
        import importlib

        # Resolve the bare module name (e.g. "signatures_legal") to a full path.
        # Try the new canonical location first: simplekg.signatures.<name>
        # Fall back to bare name for backward compatibility with scripts that
        # pass fully-qualified names like "simplekg.signatures_ancient_greek".
        bare = module_name.split(".")[-1]  # strip any existing package prefix
        candidates = [
            f"simplekg.signatures.{bare}",
            module_name,
        ]

        module = None
        last_error = None
        for candidate in candidates:
            try:
                module = importlib.import_module(candidate)
                break
            except ImportError as e:
                last_error = e

        if module is None:
            raise ValueError(
                f"Failed to import signature module '{module_name}' "
                f"(tried: {candidates}): {last_error}"
            )

        try:
            # Find the registry class (convention: ends with 'SignatureRegistry')
            registry_class = None
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and
                        hasattr(attr, '__bases__') and
                        any('SignatureRegistry' in base.__name__ for base in attr.__bases__)):
                    registry_class = attr
                    break

            if registry_class is None:
                raise ValueError(f"No SignatureRegistry subclass found in {module_name}")

            registry_instance = registry_class()
            self._log(f"Loaded signature registry: {registry_instance.get_domain_name()} - {registry_instance.get_description()}", "INFO")
            return registry_instance

        except Exception as e:
            raise ValueError(f"Error loading signature registry from '{module_name}': {e}")

    # Helpers to set parameters
    # ----------------------------------

    def set_params(self, init_entity_types: List[str] = None, persona: str =  None, chunk_size: int = None, chunk_overlap_sentences: int = None, pipeline: dict = None, verbose: bool = False, clustering_distance_threshold: float = None, chunk_by_sentences=None, normalize_text_for_matching=None):
        '''
        parameters:
            Reset all parameters to their default values and empty graph.
            init_entity_types: List of initial entity types to consider during extraction.
            persona: The persona to use for the extraction 
                    - "You are a a Jewish History scholar and an Kabalisctic expert"
                    - "You are a Hebrew linguestic scholar and an Ontology expert"
        '''

        if normalize_text_for_matching is not None:
            # A function input which is used to normalized the terms returned from the LLM to detect them in the original text.
            # Mainly used for Greak since we preprocessed the text into a non normal Greek form, so we need to normalize the LLM output to match the original text.
            self.normalize_text_for_matching = normalize_text_for_matching
        elif not hasattr(self, 'normalize_text_for_matching'):
            self.normalize_text_for_matching = None
        
        if init_entity_types is not None:
            self.init_entity_types = init_entity_types
        elif not hasattr(self, 'init_entity_types'):
            self.init_entity_types = ["Person", "Role", "Organization", "Concept", "Location", "Polities (ancient and modern)","Event", "Biblical Quotation"]
            self.init_entity_types = []
        self.entity_types = self.init_entity_types

        if clustering_distance_threshold is not None:
            self.clustering_distance_threshold = clustering_distance_threshold

        if persona is not None:
            self.persona = persona

        
        if chunk_by_sentences is not None and chunk_by_sentences is True:
            self.chunk_size = -1  # Indicate chunking by sentences
            self.chunk_by_sentences = True
        elif chunk_size is not None:
            self.chunk_by_sentences = False
            self.chunk_size = chunk_size

        if chunk_overlap_sentences is not None:
            self.chunk_overlap_sentences = chunk_overlap_sentences

        
        if pipeline is not None:
            # Check if pipeline variable exists
            if not hasattr(self, 'pipeline'):
                self.pipeline = pipeline
            else:
                self.pipeline.update(pipeline)
        else:
            if not hasattr(self, 'pipeline'):
                self.pipeline = {"processSubGraphs": True,
                                "tagDefinitions": True, # Tag definitions in text, These concepts will be injected to all subgraphs
                                "twoStepRelations": True, # two steps means: First step candidates, Second step Relations
                                "forceOrphanRelation": False, # If True, make a focused LLM call for each orphan concept after relation extraction
                                "consolidateSubGraphs": True,
                                "mergeConcepts": True,
                                "pruneConcepts": True,
                                "normalizeOntology": False,

                                "storeGraph": False,
                                "storeEmbeddings": False,
                                "storeVisualization": False,
                                "storeGraphSteps": False,
                                "outputPath": None}


        if verbose:
            self._log(f"Parameters set: \n - init_entity_types: {self.init_entity_types}\n - persona: {self.persona}\n - chunk_size: {self.chunk_size}\n - chunk_overlap_sentences: {self.chunk_overlap_sentences}", "INFO", verbose)
            self._log(f" - chunk_by_sentences: {self.chunk_by_sentences}", "INFO", verbose)
            self._log(f" - clustering_distance_threshold: {self.clustering_distance_threshold}", "INFO", verbose)
            self._log("Pipeline configuration:", "INFO", verbose)
            for k, v in self.pipeline.items():
                self._log(f"  {k}: {v}", "INFO", verbose)


    def init_model(self, model: str = None, temperature: float = None, api_key: str = None, max_tokens: int = 30000):
        """Initialize or reinitialize the model with new parameters."""
        if model is not None:
            self.model = model
        if temperature is not None:
            self.temperature = temperature
        if api_key is not None:
            self.api_key = api_key
        
        self.max_tokens = max_tokens
        litellm.drop_params = True
        if self.api_key:
            self.lm = dspy.LM(model=self.model, api_key=self.api_key, temperature=self.temperature,  max_tokens=self.max_tokens)
        else:
            self.lm = dspy.LM(model=self.model, temperature=self.temperature,  max_tokens=self.max_tokens)

        dspy.configure(lm=self.lm)

    def dump_graph(self, file_path: str):
        """Dump the graph to a file."""
        
        def set_encoder(obj):
            if isinstance(obj, set):
                return list(obj)
            raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

        with open(file_path, 'w') as f:
            json.dump(self.graph.model_dump(), f, indent=2, ensure_ascii=False, default=set_encoder)

    def examine_subgraph(self,sub_graph_id, text=False, term_list=False, concept_list=False, relation_list=False, orphens_list=False):
        '''
        Examine (print) a specific subgraph by its ID.
        It assist in debugging and understanding the content of subgraphs.
        Parameters:
            sub_graph_id: ID of the subgraph to examine. 0 for the consolidated graph
            text: If True, print the text of the subgraph.
            concept_list: If True, print the list of concepts in the subgraph.
            relation_list: If True, print the list of relations in the subgraph.
            orphens_list: If True, print the list of orphan concepts in the subgraph.
        '''
        if sub_graph_id == 0:
            graph = self.graph.consolidated_graph
        else:
            graph = self.graph.subgraphs[sub_graph_id-1]

        concepts = graph.concepts
        relations = graph.relation_objects
        
        dconcepts = {x.id:x for x in concepts }
        connected_concepts = [x.subject_id for x in relations] + [x.object_id for x in relations]
        orphans = [x.id for x in concepts if x.id not in connected_concepts]
        print(f"Graph Id: {graph.gid}, Concepts: {len(concepts)}, Orphans: {len(orphans)}")
        if text is True:
            print(f"\nText:\n{graph.text}")
        
        if term_list==True:
            term_list = "\n".join([f"Span: {x.span}, Type: {x.coarse_type}" for x in graph.terms])
            #print(f"\nConcepts:\n{concept_list}")
            #concept_list = "\nConcept List:\n".join([x.concept_text for x in graph.concepts])

            print(f"\nTerms:\n")
            for t in graph.terms:
                print(f"\n{t}")
                
        if concept_list==True:
            concept_list = "\n".join([f"cid: {x.id}, Definition: {x.definition}" for x in graph.concepts])
            #print(f"\nConcepts:\n{concept_list}")
            #concept_list = "\nConcept List:\n".join([x.concept_text for x in graph.concepts])

            print(f"\nConcepts:\n")
            for c in concepts:
                print(f"\n{c}")
            
        if relation_list:
            #print(f"\nRelations:\n{relations}")
            print(f"\nRelations:\n")
            for r in relations:
                print(f"\n{r}")

        if orphens_list:
            print(f"\nOrphens:\n{orphans}")


    # Knowledge graph Generation methods
    # ----------------------------------

    def _preprocess_text(self, text: str) -> str:
        """Preprocess the input text before graph initialization."""
        
        # If self.signature_registry has get_text_preprocessing_signature method, use it
        TextPreprocessing = self.signature_registry.get_text_preprocessing_signature()
        if TextPreprocessing is not None:
            preprocess = dspy.ChainOfThought(TextPreprocessing)
            text = preprocess(raw_text=text).preprocessed_text
        
        return text.strip()

    def init_graph(self, text: str = "", path: str = None, verbose: bool = False, doc_context: str = ""):
        """Initialize an empty graph.
           If text is provided, initialize the graph with the text.
           If path is provided, load the graph from the file.
         """
        if doc_context is None:
            doc_context = ""
        
        if path is None and text == "":
            raise ValueError("Either text or path must be provided to initialize the graph.")

        self.relation_embeddings = None
        if self.pipeline.get("preProcessText", False):
            text = self._preprocess_text(text)
        if path is None:
            if self.chunk_by_sentences:
                texts = [x for x in text.split('. ') if x.strip() != '']

            elif self.chunk_size > 0:
                try:
                    from .utilities import chunk_text
                except ImportError:
                    from utilities import chunk_text
                
                # Split text into chunks by sentences of chunk_size
                texts = chunk_text(text, self.chunk_size, overlap_sentences=self.chunk_overlap_sentences)
                  
            else:
                texts = [text] 
            
            subgraphs = []
            for idx,t in enumerate(texts):
                subgraphs.append(BaseGraph(gid=idx+1, text=t, concepts=[], relation_objects=[]))

            self.graph = DocGraph(consolidated_graph=BaseGraph(gid=0, text=text, context_text=doc_context, concepts=[], relation_objects=[]), 
                                  subgraphs=subgraphs)
            self._log(f"Initiated graph with {len(subgraphs)} subgraphs.\nThe text is of size {len(text.split(' '))}", "INFO", verbose)
        else:
            def custom_decoder(data):
                # This function is called for every object in the JSON data
                # We can check if it's a list that needs to be a tuple
                if isinstance(data, list) and len(data) == 3 and all(isinstance(i, str) for i in data):
                    # A simple check to see if this list should be a tuple
                    return tuple(data)
                return data
            
            with open(path, 'r') as f:
                cgraph_dict = json.load(f, object_hook=custom_decoder)

            self.graph = DocGraph(**cgraph_dict)               

    def _extractChunkConcepts(self, subgraph: BaseGraph, verbose = False):
        # Get signatures from registry
        # Allow multiple signatures for flexibility
        listHarvestTerms = self.signature_registry.get_harvest_terms_signature()
        self._log(f"Using {len(listHarvestTerms)} HarvestTerms signatures for concept extraction.", "INFO", verbose)
        all_candidates = []
        for HarvestTerms in listHarvestTerms:
            extract = dspy.ChainOfThought(HarvestTerms)
            terms = extract(text_chunk=subgraph.text, doc_context="")
            all_candidates.extend(terms.candidates)

            self._log(f"Signature: {HarvestTerms.__name__}, Extracted {len(terms.candidates)} term candidates for {subgraph.gid}.", "INFO", verbose)

        # Assign globally unique sequential IDs to candidates.
        # IDs are derived from subgraph.gid to avoid overlap across parallel subgraph processing.
        for i, candidate in enumerate(all_candidates):
            candidate.term_id = subgraph.gid * 10000 + i

        subgraph.terms = all_candidates

        # Build lookup dict for fast term_id → TermCandidate access during position assignment
        candidates_by_id = {c.term_id: c for c in all_candidates}

        CandidatesToConcepts = self.signature_registry.get_candidates_to_concepts_signature()
        extract = dspy.ChainOfThought(CandidatesToConcepts)
        concepts = extract(text_chunk=subgraph.text, candidates=all_candidates)
        self._log(f"Extracted {len(concepts.concepts)} concepts from term candidates for {subgraph.gid}.", "INFO", verbose)

        # Assign concept positions
        for concept in concepts.concepts:
            # Build search terms: span from source TermCandidate first, then prefLabel + altLabels
            source_span = []
            if concept.term_id is not None and concept.term_id in candidates_by_id:
                source_span = [candidates_by_id[concept.term_id].span]

            for x in source_span + [concept.prefLabel] + concept.altLabels:

                # normalize the text before searching (e.g., remove extra spaces, normalize punctuation)
                if self.normalize_text_for_matching:
                    clean_x = self.normalize_text_for_matching(x)
                else:
                    clean_x = x

                tmp = subgraph.text.find(clean_x)
                if tmp != -1:
                    concept.concept_position = tmp
                    break
            # If still not found, use SequenceMatcher to find best match
            if concept.concept_position==-1:
                s = SequenceMatcher(None, subgraph.text, concept.prefLabel)
                match = s.find_longest_match(0, len(subgraph.text), 0, len(concept.prefLabel))
                if match.size > 0:
                    concept.concept_position = match.a
                    
        subgraph.concepts = concepts.concepts

    def _tag_definitions_in_subgraph(self, subgraph: BaseGraph, verbose: bool = False):
        '''
        Tag concepts in the subgraph that are a definition.
        The definition concepts are also collected at the DocGraph level and used to inject to the following chunks.
        '''
        # Get signature from registry
        HarvestDefinitionCandidates = self.signature_registry.get_harvest_definitions_signature()

        extract = dspy.ChainOfThought(HarvestDefinitionCandidates)
        result = extract(text_chunk=subgraph.text, concepts=subgraph.concepts)

        definition_marks = result.definition_concepts or []

        # Mark concepts in the subgraph
        concept_by_id = {c.id: c for c in subgraph.concepts}
        for mark in definition_marks:
            cid = mark.concept_id
            if cid in concept_by_id:
                concept_by_id[cid].definition = True

        self._log(
                f"Subgraph {subgraph.gid}: "
                f"{len(definition_marks)} concepts marked as definitions.", "INFO", verbose)

        # Optionally: also collect them at DocGraph level (by ID for now)
        doc_definitions = set(self.graph.global_definitions)
        for mark in definition_marks:
            doc_definitions.add(mark.concept_id)
        self.graph.global_definitions = list(doc_definitions)


    def _extractChunkRelations(self, subgraph: BaseGraph, verbose = False):
        '''
        Extract relations for the given subgraph.
        1. Use LLM signatures to extract relation candidates and then relations.
        2. Use additional relation functions from the signature registry.
        3. Use LLM signature to extract relations to directly preceeding subgraph (if any).
        4. Filter relations to only those linking existing concepts in the subgraph or global definitions
        '''
        
        def filter_relations_to_existing_concepts( relations: List[Relation], concepts: List[Concept] ) -> List[Relation]:
            '''
            Filter relations to only include those where both subject and object are in the provided concepts.
            '''
            concept_ids = {c.id for c in concepts}
            cleaned = []
            filtered_out = []
            for r in relations:
                if r.subject_id in concept_ids and r.object_id in concept_ids:
                    cleaned.append(r)
                else:
                    filtered_out.append(r)
                    

            return cleaned, filtered_out

        
        # Build list of global definition concepts (for now using IDs; after merge, remap)
        all_concepts = self.graph.consolidated_graph.concepts
        def_by_id = {c.id: c for c in all_concepts}
        global_def_concepts = [
            def_by_id[cid] for cid in self.graph.global_definitions
            if cid in def_by_id
        ]

        # Harvest relations using LLM signatures
        if self.pipeline.get("twoStepRelations", False):
            HarvestChunkRelationCandidates = self.signature_registry.get_harvest_relation_candidates_signature()
            CandidatesToRelations = self.signature_registry.get_candidates_to_relations_signature()
            extract = dspy.ChainOfThought(HarvestChunkRelationCandidates)
            cand_pred = extract(text_chunk=subgraph.text, concepts=subgraph.concepts, global_definitions=global_def_concepts)
            
            subgraph.relation_candidates = cand_pred.candidates
            self._log(f"Extracted {len(cand_pred.candidates)} relation candidates for {subgraph.gid}.", "INFO", verbose)

            extract = dspy.ChainOfThought(CandidatesToRelations)
            relation_objects = extract(candidates=subgraph.relation_candidates, concepts=subgraph.concepts,
                                    global_definitions=global_def_concepts)
        else:
            HarvestRelation = self.signature_registry.get_harvest_relation_signature()
            extract = dspy.ChainOfThought(HarvestRelation)
            relation_objects = extract(text_chunk=subgraph.text, concepts=subgraph.concepts,
                                    global_definitions=global_def_concepts)
            

        # Harvest relations using all relation functions
        if hasattr(self.signature_registry, 'get_harvest_relation_functions'):
            relation_functions = self.signature_registry.get_harvest_relation_functions()
        else:
            relation_functions = []
        for func in relation_functions:
            new_relations = func(subgraph)
            try:
                relation_objects.relations += (new_relations or [])
                #self._log(f"Subgraph {subgraph.gid} Extended with {len(new_relations)} relations from Biblical quotations", "INFO", verbose)
            except Exception as e:
                raise ValueError(f"Error adding relations from function {func.__name__} to subgraph {subgraph.gid}: {e}")
                
        # Harvest relations to previous subgraph
        if subgraph.gid > 1:
            # check if get_inter_subgraph_relations is defined
            prev_sg = self.graph.subgraphs[subgraph.gid - 2]  # zero-based index
            if hasattr(self.signature_registry, 'get_inter_subgraph_relations'):
                PrevSubGraphRelations = self.signature_registry.get_inter_subgraph_relations()
                extract = dspy.ChainOfThought(PrevSubGraphRelations)
                
                prev_relations = extract(text_a=prev_sg.text,
                                        text_b=subgraph.text,
                                        concepts_a=prev_sg.concepts,
                                        concepts_b=subgraph.concepts,
                                        relations_a=prev_sg.relation_objects,
                                        relations_b=relation_objects.relations,
                                        global_definitions=global_def_concepts
                                        )
                relation_objects.relations += prev_relations.inter_relations
                self._log(f"Extracted {len(prev_relations.inter_relations)} relations to previous subgraph for {subgraph.gid}.", "INFO", verbose)

        # Filter relations to only those linking existing concepts
        if subgraph.gid > 1:
            allowed_concepts = subgraph.concepts + global_def_concepts + prev_sg.concepts
        else:
            allowed_concepts = subgraph.concepts + global_def_concepts
         
        # print(f"Allowed Concepts: {len(allowed_concepts)}, Subgraph Concepts: {len(subgraph.concepts)}, Global Definitions: {len(global_def_concepts)}, Previous Subgraph Concepts: {len(prev_sg.concepts) if subgraph.gid > 1 else 0}")
        cleaned_relations, filtered_out = filter_relations_to_existing_concepts(relation_objects.relations, allowed_concepts)

        subgraph.relation_objects = cleaned_relations
        subgraph.filtered_relations = filtered_out
        self._log(f"Extracted {len(relation_objects.relations)} relations from candidates for {subgraph.gid}.", "INFO", verbose)


    def _resolveOrphanRelations(self, subgraph: BaseGraph, verbose=False):
        """
        For each concept in the subgraph that has no relations (orphan),
        make a focused LLM call to find how it connects to the other concepts.
        Uses the generic ResolveOrphanConceptRelation signature from the registry
        (domain registries may override it for domain-specific guidance).
        New valid relations are appended to subgraph.relation_objects.
        """
        # 1. Identify orphaned concepts
        used_ids = {r.subject_id for r in subgraph.relation_objects} | \
                   {r.object_id   for r in subgraph.relation_objects}
        orphans = [c for c in subgraph.concepts if c.id not in used_ids]

        if not orphans:
            self._log(f"No orphans in subgraph {subgraph.gid}.", "DEBUG", verbose)
            return

        self._log(
            f"Found {len(orphans)} orphan(s) in subgraph {subgraph.gid}: "
            f"{[c.id for c in orphans]}",
            "INFO", verbose
        )

        ResolveOrphan = self.signature_registry.get_resolve_orphan_signature()
        resolve = dspy.ChainOfThought(ResolveOrphan)
        concept_ids = {c.id for c in subgraph.concepts}
        new_relations = []

        for orphan in orphans:
            other_concepts = [c for c in subgraph.concepts if c.id != orphan.id]
            if not other_concepts:
                self._log(f"  Orphan '{orphan.id}': skipped — no other concepts in subgraph.", "DEBUG", verbose)
                continue
            try:
                result = resolve(
                    text_chunk=subgraph.text,
                    orphan_concept=orphan,
                    other_concepts=other_concepts
                )
                # Filter: both endpoints must exist in this subgraph
                valid = [
                    r for r in result.relations
                    if r.subject_id in concept_ids and r.object_id in concept_ids
                ]
                new_relations.extend(valid)
                self._log(f"  Orphan '{orphan.id}': {len(valid)} relation(s) resolved.", "INFO", verbose)
            except Exception as e:
                self._log(f"  Error resolving orphan '{orphan.id}': {e}", "WARNING", verbose)

        subgraph.relation_objects.extend(new_relations)
        self._log(
            f"Orphan resolution added {len(new_relations)} relation(s) to subgraph {subgraph.gid}.",
            "INFO", verbose
        )


    def _normalize_predicates(self, subgraph: BaseGraph, verbose=False):
        """
        Normalize relation predicates in a subgraph against the domain ontology.

        For each relation:
          - Pre-filter ontology predicates by subject/object entity type (domain/range)
          - 0 candidates  → assign generic_predicate directly (no LLM call)
          - 1 candidate   → assign directly (no LLM call)
          - N candidates  → LLM batch call (all relations sharing the same type pair
                            are sent together — Option B batching)
          - Post-validate → if LLM returns an unknown id, fall back to generic_predicate

        The original predicate is always preserved in relation.predicate_raw.
        Skipped entirely if no ontology is provided by the signature registry.
        See OntologyBasedKGImplementation.md — Stage 5.
        """
        ontology = self.signature_registry.get_ontology()
        if ontology is None:
            return

        # Build lookups from this subgraph's concepts
        concept_type  = {c.id: c.entity_type   for c in subgraph.concepts}
        concept_label = {c.id: c.prefLabel_en   for c in subgraph.concepts}

        # Group relations by (subject_entity_type, object_entity_type) so every
        # relation in a group shares the same pre-filtered candidate set.
        from collections import defaultdict
        groups = defaultdict(list)
        for r in subgraph.relation_objects:
            subj_type = concept_type.get(r.subject_id, "")
            obj_type  = concept_type.get(r.object_id,  "")
            groups[(subj_type, obj_type)].append(r)

        MapPredicates = self.signature_registry.get_predicate_mapping_signature()
        mapper = dspy.ChainOfThought(MapPredicates)

        total_shortcircuit = 0
        total_llm_mapped   = 0
        total_fallback     = 0

        for (subj_type, obj_type), relations in groups.items():
            candidates = ontology.filter_predicates(subj_type, obj_type)
            valid_ids  = {p.id for p in candidates} | {ontology.generic_predicate}

            # --- Short-circuit: no candidates ---
            if len(candidates) == 0:
                for r in relations:
                    r.predicate_raw = r.predicate
                    r.predicate = ontology.generic_predicate
                total_shortcircuit += len(relations)
                continue

            # --- Short-circuit: exactly one candidate ---
            if len(candidates) == 1:
                for r in relations:
                    r.predicate_raw = r.predicate
                    r.predicate = candidates[0].id
                total_shortcircuit += len(relations)
                continue

            # --- LLM mapping: batch all relations in this group ---
            relations_to_map = [
                f"{concept_label.get(r.subject_id, r.subject_id)}"
                f" --[{r.predicate}]--> "
                f"{concept_label.get(r.object_id, r.object_id)}"
                for r in relations
            ]
            ontology_text = ontology.format_predicates_for_llm(candidates)

            try:
                result = mapper(
                    relations_to_map=relations_to_map,
                    ontology_predicates=ontology_text,
                )
                mapped_ids = result.mapped_predicate_ids

                # Guard against wrong-length LLM output
                if len(mapped_ids) != len(relations):
                    raise ValueError(
                        f"Expected {len(relations)} mapped ids, got {len(mapped_ids)}"
                    )

                for r, mapped_id in zip(relations, mapped_ids):
                    r.predicate_raw = r.predicate
                    if mapped_id in valid_ids:
                        r.predicate = mapped_id
                    else:
                        r.predicate = ontology.generic_predicate
                        total_fallback += 1
                total_llm_mapped += len(relations)

            except Exception as e:
                self._log(
                    f"Subgraph {subgraph.gid}: predicate mapping error "
                    f"({subj_type}→{obj_type}): {e} — falling back to generic.",
                    "WARNING", verbose,
                )
                for r in relations:
                    r.predicate_raw = r.predicate
                    r.predicate = ontology.generic_predicate
                total_fallback += len(relations)

        self._log(
            f"Subgraph {subgraph.gid}: predicate normalization — "
            f"{total_shortcircuit} short-circuited, "
            f"{total_llm_mapped} LLM-mapped "
            f"({total_fallback} fell back to generic).",
            "INFO", verbose,
        )

    def _enforce_entity_types(self, subgraph: BaseGraph, verbose=False):
        """
        Enforce ontology entity types on all concepts in a subgraph.

        For each concept whose entity_type is not in the ontology's allowed list,
        the original value is preserved in entity_type_raw and replaced silently
        with the ontology's generic_entity_type fallback.

        Skipped entirely if no ontology is provided by the signature registry.
        See OntologyBasedKGImplementation.md — Stage 4.
        """
        ontology = self.signature_registry.get_ontology()
        if ontology is None:
            return

        replaced = 0
        for concept in subgraph.concepts:
            if not ontology.is_valid_entity_type(concept.entity_type):
                concept.entity_type_raw = concept.entity_type
                concept.entity_type = ontology.generic_entity_type
                replaced += 1

        if replaced:
            self._log(
                f"Subgraph {subgraph.gid}: enforced entity types — "
                f"{replaced} concept(s) replaced with '{ontology.generic_entity_type}'.",
                "INFO", verbose,
            )

    def _process_subgraph(self, sg: BaseGraph, verbose=False):
        self._extractChunkConcepts(subgraph=sg, verbose=verbose)
        if self.pipeline.get("normalizeOntology", False):
            self._enforce_entity_types(subgraph=sg, verbose=verbose)
        if self.pipeline.get("tagDefinitions", True):
            self._tag_definitions_in_subgraph(subgraph=sg, verbose=verbose)
        self._extractChunkRelations(subgraph=sg, verbose=verbose)
        if self.pipeline.get("forceOrphanRelation", False):
            self._resolveOrphanRelations(subgraph=sg, verbose=verbose)
        if self.pipeline.get("normalizeOntology", False):
            self._normalize_predicates(subgraph=sg, verbose=verbose)

        return sg

    def processSubGraphs(self, verbose = False):
        """
          Convert all into graphs.
        """
        blocks = self.graph.subgraphs

        with ThreadPoolExecutor(max_workers=self.max_workers) as ex:
            futures = {ex.submit(self._process_subgraph, sg, verbose): sg.gid for sg in blocks}
            for fut in as_completed(futures):
                gid = futures[fut]
                _ = fut.result()
                self._log(f"Finished processing chunk {gid}", "INFO", verbose)

    def consolidateSubGraphs(self, clear_clusters=True, verbose = False):
        '''
            Consolidate all subgraphs into the main consolidated graph.
        '''
        self.graph.consolidated_graph.concepts.clear()
        self.graph.consolidated_graph.relation_objects.clear()
        if clear_clusters:
            self.graph.concept_clusters.clear()

        for sg in self.graph.subgraphs:
            # Remap concept IDs to include subgraph ID prefix
            nc = [Concept(id=f"sg{sg.gid}_{x.id}",
                          prefLabel=x.prefLabel,
                          prefLabel_en=x.prefLabel_en,
                          altLabels=x.altLabels,
                          altLabels_en=x.altLabels_en,
                          entity_type=x.entity_type,
                          entity_type_raw=x.entity_type_raw,
                          conceptDescription=x.conceptDescription,
                          conceptDescription_en=x.conceptDescription_en) for x in sg.concepts]
            self.graph.consolidated_graph.concepts.extend(nc)

            # Remap relation IDs to include subgraph ID prefix
            prev_subgraph = self.graph.subgraphs[sg.gid - 2] if sg.gid > 1 else None
            subgraph_ids = {c.id for c in sg.concepts}
            nr = []
            for r in sg.relation_objects:
                # If it is intra-subgraph relation, remap directly
                if r.subject_id in subgraph_ids and r.object_id in subgraph_ids:
                    nr.append(Relation(
                        subject_id=f"sg{sg.gid}_{r.subject_id}",
                        predicate=r.predicate,
                        predicate_raw=r.predicate_raw,
                        object_id=f"sg{sg.gid}_{r.object_id}",
                        evidence_text=r.evidence_text,
                    ))
                else:
                    if prev_subgraph is not None:
                        prev_subgraph_ids = {c.id for c in prev_subgraph.concepts}
                        # If it is inter-subgraph relation to previous subgraph, remap accordingly
                        if r.subject_id in subgraph_ids and r.object_id in prev_subgraph_ids:
                            nr.append(Relation(
                                subject_id=f"sg{sg.gid}_{r.subject_id}",
                                predicate=r.predicate,
                                predicate_raw=r.predicate_raw,
                                object_id=f"sg{prev_subgraph.gid}_{r.object_id}",
                                evidence_text=r.evidence_text,
                            ))
                        elif r.subject_id in prev_subgraph_ids and r.object_id in subgraph_ids:
                            nr.append(Relation(
                                subject_id=f"sg{prev_subgraph.gid}_{r.subject_id}",
                                predicate=r.predicate,
                                predicate_raw=r.predicate_raw,
                                object_id=f"sg{sg.gid}_{r.object_id}",
                                evidence_text=r.evidence_text,
                            ))
                        else:
                            # Relation does not connect concepts in current or previous subgraph
                            pass
                    else:
                        pass

            # nr = [Relation(
            #         subject_id=f"sg{sg.gid}_{r.subject_id}",
            #         predicate=r.predicate,
            #         object_id=f"sg{sg.gid}_{r.object_id}",
            #         evidence_text=r.evidence_text,
            #     ) for r in sg.relation_objects]
            self.graph.consolidated_graph.relation_objects.extend(nr)

    def _conceptClustering(self, save_embeddings_path: str = None, restore_embeddings_path: str = None, verbose: bool = False):

        def _save_concept_embeddings(self, path: str):
            import pandas as pd

            df_concept_embeddings = pd.DataFrame({
                'text': concepts,
                'embedding': list(concept_embeddings)  # Convert numpy matrix to a list of arrays
            })
            df_concept_embeddings.to_parquet(path)

        def _load_concept_embeddings(self, path: str):
            import pandas as pd
            import numpy as np
            
            df = pd.read_parquet(path)
            return np.array(df['embedding'].tolist())

        # Check if there are concepts to cluster
        if not self.graph.consolidated_graph.concepts:
            self._log("No concepts found in consolidated graph. Skipping clustering.", "WARNING", verbose)
            self.graph.concept_clusters = []
            return

        concepts = [x.concept_text for x in self.graph.consolidated_graph.concepts]
        
        if restore_embeddings_path:
            concept_embeddings = _load_concept_embeddings(self, restore_embeddings_path)
        else:
            from openai import OpenAI
            client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

            concept_embeddings = get_embeddings(texts=concepts, client=client)
            if save_embeddings_path:
                _save_concept_embeddings(self, save_embeddings_path)
            if self.pipeline.get("storeEmbeddings", False):
                save_embeddings_path = self.pipeline.get("outputPath", "./") + "concept_embeddings.parquet"
                _save_concept_embeddings(self, save_embeddings_path)
                if verbose:
                    self._log(f"Saved concept embeddings to {save_embeddings_path}", "INFO", verbose)
        
        # Validate embeddings
        if concept_embeddings.size == 0:
            self._log("Failed to generate concept embeddings or embeddings are empty. Skipping clustering.", "ERROR", verbose)
            self.graph.concept_clusters = []
            return
        
        # Ensure embeddings are 2D array
        if concept_embeddings.ndim == 1:
            if len(concepts) == 1:
                # Single concept - create a single cluster
                self._log("Only one concept found. Creating single cluster.", "INFO", verbose)
                cluster = ConceptCluster(cluster_id=0, member_concept_ids=[self.graph.consolidated_graph.concepts[0].id])
                self.graph.concept_clusters = [cluster]
                return
            else:
                self._log(f"Embeddings array is 1D but expected 2D for {len(concepts)} concepts. Skipping clustering.", "ERROR", verbose)
                self.graph.concept_clusters = []
                return
        
        # Check if we have at least 2 concepts for clustering
        if len(concepts) < 2:
            self._log("Less than 2 concepts found. Creating single cluster.", "INFO", verbose)
            cluster = ConceptCluster(cluster_id=0, member_concept_ids=[c.id for c in self.graph.consolidated_graph.concepts])
            self.graph.concept_clusters = [cluster]
            return
        
        from sklearn.cluster import AgglomerativeClustering

        clustering = AgglomerativeClustering(
                                                n_clusters=None, 
                                                distance_threshold=self.clustering_distance_threshold,  # Adjust this value based on your data spread
                                                metric='euclidean',
                                                linkage='ward'
                                            )
        
        clustering.fit(concept_embeddings)

        concept_clusters = {}
        for i, sentence in enumerate(concepts):
            tmp  = concept_clusters.get(clustering.labels_[i], ConceptCluster(cluster_id=clustering.labels_[i], member_concept_ids=[]))
            tmp.member_concept_ids.append(self.graph.consolidated_graph.concepts[i].id)
            concept_clusters[clustering.labels_[i]] = tmp

        self.graph.concept_clusters = list(concept_clusters.values())

    def _build_global_remap(self, merges: List[ConceptMergeInstruction]) -> dict:
        """
        Take all ConceptMergeInstruction objects and compute a global
        mapping: old_id -> canonical_id.
        Overlapping merge instructions are unified via connectivity.

        Returns:
            The consolidateSubGraphs generate a prefix of the original graph id for each concept in the consolidated graph.
            The result will be something like:
            {
                "sg1_ישראל": "ישראל",
                "sg7_ישראל": "ישראל",
                "sg12_מדינת_ישראל": "ישראל",
                ...
            }
        """
        from collections import defaultdict, deque

        if not merges:
            return {}

        # 1) Build an undirected graph over concept IDs
        neighbors = defaultdict(set)
        all_ids = set()

        for m in merges:
            member_ids = list(dict.fromkeys(m.member_ids))  # dedupe, preserve order
            if not member_ids:
                continue
            # ensure canonical_id is included
            if m.canonical_id not in member_ids:
                member_ids.append(m.canonical_id)

            for mid in member_ids:
                all_ids.add(mid)

            # connect all members in this group
            for i in range(len(member_ids)):
                for j in range(i + 1, len(member_ids)):
                    a, b = member_ids[i], member_ids[j]
                    neighbors[a].add(b)
                    neighbors[b].add(a)

        # 2) Find connected components
        remap = {}
        visited = set()

        def choose_canonical_id(component_ids: List[str]) -> str:
            # deterministic rule: choose shortest ID, then lexicographically
            return sorted(component_ids, key=lambda x: (len(x), x))[0]

        for cid in all_ids:
            if cid in visited:
                continue
            # BFS/DFS to get the whole component
            queue = deque([cid])
            component = []
            visited.add(cid)
            while queue:
                cur = queue.popleft()
                component.append(cur)
                for nb in neighbors[cur]:
                    if nb not in visited:
                        visited.add(nb)
                        queue.append(nb)

            canonical_id = choose_canonical_id(component)
            for mid in component:
                remap[mid] = canonical_id

        return remap

    def _apply_concept_merges_global(self, remap: dict, verbose: bool = False):
        """
        Build a new concept list where all concepts that map to the same
        canonical_id are merged into a single Concept.
        """
        if not remap:
            self._log("No merges to apply (remap is empty).", "INFO", verbose)
            return

        all_concepts = self.graph.consolidated_graph.concepts
        id2concept = {c.id: c for c in all_concepts}

        # 1) Group concepts by canonical_id
        from collections import defaultdict
        groups = defaultdict(list)

        for cid, c in id2concept.items():
            canonical_id = remap.get(cid, cid)
            groups[canonical_id].append(c)

        new_concepts = []

        for canonical_id, members in groups.items():
            if len(members) == 1 and canonical_id == members[0].id:
                # no merge needed, keep as is
                new_concepts.append(members[0])
                continue

            # pick a base concept (you can improve this rule if you want)
            base = members[0]

            alt_source = set(base.altLabels)
            alt_en = set(base.altLabels_en)

            # include all other prefLabels as altLabels
            for m in members[1:]:
                if m.prefLabel != base.prefLabel:
                    alt_source.add(m.prefLabel)
                alt_source.update(m.altLabels)
                alt_en.update(m.altLabels_en)
            source_ids = [m.id for m in members]
            merged = Concept(
                id=canonical_id,
                prefLabel=base.prefLabel,
                prefLabel_en=base.prefLabel_en,
                altLabels=sorted(alt_source),
                altLabels_en=sorted(alt_en),
                conceptDescription=base.conceptDescription,
                conceptDescription_en=base.conceptDescription_en,
                entity_type=base.entity_type,
                source_instance_ids=source_ids,
            )
            new_concepts.append(merged)

        self._log(f"Applied global merges: {len(all_concepts)} → {len(new_concepts)} concepts.", "INFO", verbose)

        self.graph.consolidated_graph.concepts = new_concepts

    def _remap_relations_global(self, remap: dict, verbose: bool = False):
        """
        Remap relation subject/object IDs according to the global remap.
        Deduplicate relations that become identical after remapping.
        """
        if not remap:
            self._log("No relation remap needed (remap is empty).", "INFO", verbose)
            return

        relations = self.graph.consolidated_graph.relation_objects
        new_relations = []
        seen = set()

        for r in relations:
            sid = remap.get(r.subject_id, r.subject_id)
            oid = remap.get(r.object_id, r.object_id)
            key = (sid, r.predicate, oid, r.evidence_text)

            if key in seen:
                continue
            seen.add(key)

            new_relations.append(
                Relation(
                    subject_id=sid,
                    predicate=r.predicate,
                    object_id=oid,
                    evidence_text=r.evidence_text,
                )
            )

        self._log(f"Remapped relations: {len(relations)} → {len(new_relations)} relations.", "INFO", verbose)

        self.graph.consolidated_graph.relation_objects = new_relations

    def mergeConcepts(self, auto_clustering=True, verbose: bool = False):
        """
        1. Create concept clusters (if not already present) using AgglomerativeClustering
        1. For each concept cluster, ask the LLM (ProposeConceptMerges) which
        concepts to merge.
        2. Aggregate ALL merge instructions across clusters.
        3. Build a global remap and apply merges + relation remapping ONCE.
        """
        # Get signature from registry
        

        if auto_clustering and (not self.graph.concept_clusters or len(self.graph.concept_clusters) == 0):
            self._conceptClustering(verbose=verbose)

        all_concepts = self.graph.consolidated_graph.concepts
        id2concept = {c.id: c for c in all_concepts}

        self._log(f"Starting concept merge. Initial concept count: {len(all_concepts)}", "INFO", verbose)
        self._log(f"Number of clusters: {len(self.graph.concept_clusters)}", "INFO", verbose)

        all_merges: List[ConceptMergeInstruction] = []

        ProposeConceptMerges = self.signature_registry.get_propose_concept_merges_signature()
        for idx, cluster in enumerate(self.graph.concept_clusters):
            # collect Concept objects for this cluster
            cluster_concepts = [
                id2concept[cid] for cid in cluster.member_concept_ids
                if cid in id2concept
            ]

            # nothing to do for singletons
            if len(cluster_concepts) < 2:
                continue

            extract = dspy.ChainOfThought(ProposeConceptMerges)
            result = extract(concepts=cluster_concepts)
            merges = result.merges or []

            self._log(f"Cluster {idx+1}/{len(self.graph.concept_clusters)} "
                    f"(id={cluster.cluster_id}) → {len(merges)} proposed merges.", "INFO", verbose)

            all_merges.extend(merges)

        # store raw merge instructions (optional)
        self.graph.concept_merges = all_merges

        self._log(f"Total raw merge instructions across all clusters: {len(all_merges)}", "INFO", verbose)

        # Build global remap (union-find or connectivity over merge instructions)
        remap = self._build_global_remap(all_merges)

        # Apply merges and remap relations ONCE
        self._apply_concept_merges_global(remap, verbose=verbose)
        self._remap_relations_global(remap, verbose=verbose)

    def pruneOrphanConcepts(self, verbose: bool = False):
        """
        Remove orphan concepts from the consolidated graph,
        but NEVER prune concepts that are marked as definitions.

        Definition:
        - A concept is an orphan if its id does NOT appear as subject_id or object_id
            in ANY relation in consolidated_graph.relation_objects.

        Rules:
        - If concept.definition == True → ALWAYS keep (even if orphan).
        - Otherwise, prune (remove) if it is an orphan.
        """

        graph = self.graph.consolidated_graph
        all_concepts = graph.concepts
        all_relations = graph.relation_objects

        # 1) Collect all concept IDs that participate in at least one relation
        used_ids = set()
        for r in all_relations:
            used_ids.add(r.subject_id)
            used_ids.add(r.object_id)

        # 2) Optionally: treat global_definitions as "keep" even if definition flag is missing
        #    (You can comment this block out if you don't use global_definitions yet.)
        global_def_ids = set()
        if hasattr(self.graph, "global_definitions") and self.graph.global_definitions:
            global_def_ids = set(self.graph.global_definitions)

        kept_concepts = []
        pruned_concepts = []

        for c in all_concepts:
            is_used = c.id in used_ids
            is_definition = getattr(c, "definition", False)  # default False if field missing
            is_global_def = c.id in global_def_ids

            # Keep if:
            #  - it participates in at least one relation, OR
            #  - it is marked as definition, OR
            #  - it is part of global_definitions (if you use that)
            if is_used or is_definition or is_global_def:
                kept_concepts.append(c)
            else:
                pruned_concepts.append(c)

        total = len(all_concepts)
        self._log(f"Pruning orphans (non-definition only):", "INFO", verbose)
        self._log(f"  Total concepts before: {total}", "INFO", verbose)
        self._log(f"  Used in relations: {len(used_ids)}", "INFO", verbose)
        self._log(f"  Kept concepts: {len(kept_concepts)}", "INFO", verbose)
        self._log(f"  Pruned orphans (non-definitions): {len(pruned_concepts)}", "INFO", verbose)

        # Optional: show a small sample of pruned IDs/labels
        for c in pruned_concepts[:10]:
            self._log(f"    - PRUNED orphan: id={c.id}, label={c.prefLabel_he}", "DEBUG", verbose)

        # 3) Apply pruning
        graph.concepts = kept_concepts

        # Optional: if you want to store the pruned ones for debugging:
        if hasattr(self.graph, "pruned_orphans"):
            self.graph.pruned_orphans.extend(pruned_concepts)
        else:
            # or attach dynamically
            self.graph.pruned_orphans = pruned_concepts

    def execute_pipeline(self, text: str=None, verbose: bool = False, chunk_size: int = None, pipeline: dict = None, chunk_by_sentences=None, doc_context: str="", chunk_overlap_sentences=0):
        """
        Execute the full pipeline:
        1. Process subgraphs to extract concepts and relations.
        2. Consolidate subgraphs into the main graph.
        3. Merge concepts based on clustering and LLM suggestions.
        4. Prune orphan concepts.
        """
        

        self.set_params(chunk_size=chunk_size, pipeline=pipeline, chunk_by_sentences=chunk_by_sentences, verbose=verbose, chunk_overlap_sentences=chunk_overlap_sentences)

        if self.pipeline.get("normalizeOntology", False) and self.signature_registry.get_ontology() is None:
            self._log(
                "Pipeline flag 'normalizeOntology' is True but the signature registry "
                "provides no ontology — normalization will be skipped. "
                "Override get_ontology() in your SignatureRegistry to enable it.",
                "WARNING",
            )

        if (self.pipeline.get("outputPath", None) is None) and (self.pipeline.get("storeGraph", True) or
                                                           self.pipeline.get("storeVisualization", True) or
                                                           self.pipeline.get("storeGraphSteps", True)):
            raise ValueError("outputPath must be specified in the pipeline configuration when storing outputs.")

        out_path = self.pipeline.get("outputPath", None)
        if out_path is not None:
            if self.pipeline.get("twoStepRelations", False):
                relation_dir = "twoStepRelations/"
            else:
                relation_dir = "singleStepRelations/"
            out_path = f"{out_path}C{self.chunk_size}_O{self.chunk_overlap_sentences}/{relation_dir}"
            self.set_params(pipeline={"outputPath": out_path}, verbose=verbose)
            os.makedirs(out_path, exist_ok=True)

        if text:
            self.init_graph(text=text, verbose=verbose, doc_context=doc_context)
            if self.pipeline.get("storeGraphSteps", False):
                step_path = os.path.join(self.pipeline.get("outputPath", "."), "step_0_initial_graph.json")
                self.dump_graph(step_path)
                self._log(f"Stored initial graph to {step_path}", "INFO", verbose)
                self._log(f"Number of SubGraphs: {len(self.graph.subgraphs)}", "INFO", verbose)
        else:
            # check if graph is initialized
            if self.graph is None:
                raise ValueError("Graph is not initialized. Please provide text to initialize the graph.")


        if self.pipeline.get("processSubGraphs", False):
            self._log("Starting processing of subgraphs...", "INFO", verbose)
            self.processSubGraphs(verbose=verbose)
            if self.pipeline.get("storeGraphSteps", False):
                step_path = os.path.join(self.pipeline.get("outputPath", "."), "step_1_processed_subgraphs.json")
                self.dump_graph(step_path)
                self._log(f"Stored processed subgraphs to {step_path}", "INFO", verbose)

        if self.pipeline.get("consolidateSubGraphs", False):
            self._log("Consolidating subgraphs into main graph...", "INFO", verbose)
            self.consolidateSubGraphs(verbose=verbose)
            if self.pipeline.get("storeGraphSteps", False):
                step_path = os.path.join(self.pipeline.get("outputPath", "."), "step_2_consolidated_graph.json")
                self.dump_graph(step_path)
                self._log(f"Stored consolidated graph to {step_path}", "INFO", verbose)

        if self.pipeline.get("mergeConcepts", False):
            self._log("Merging concepts...", "INFO", verbose)
            self.mergeConcepts(verbose=verbose)
            if self.pipeline.get("storeGraphSteps", False):
                step_path = os.path.join(self.pipeline.get("outputPath", "."), "step_3_merged_concepts.json")
                self.dump_graph(step_path)
                self._log(f"Stored graph after concept merging to {step_path}", "INFO", verbose)

        if self.pipeline.get("pruneConcepts", False):
            self._log("Pruning orphan concepts...", "INFO", verbose)
            self.pruneOrphanConcepts(verbose=verbose)
            if self.pipeline.get("storeGraphSteps", False):
                step_path = os.path.join(self.pipeline.get("outputPath", "."), "step_4_pruned_concepts.json")
                self.dump_graph(step_path)
                self._log(f"Stored graph after pruning to {step_path}", "INFO", verbose)

        self._log("Pipeline execution completed.", "INFO", verbose)

        if self.pipeline.get("storeGraph", False):
            output_path = os.path.join(self.pipeline.get("outputPath", "."), "final_knowledge_graph.json")
            self.dump_graph(output_path)
            self._log(f"Stored final knowledge graph to {output_path}", "INFO", verbose)
        
        if self.pipeline.get("storeVisualization", False):
            try:
                vis_path = os.path.join(self.pipeline.get("outputPath", "."), "knowledge_graph_visualization.html")
                #self.visualize(output_path=vis_path)
                self.visualize(output_path=vis_path, show_legend=True, legend_position="top-right")

                self._log(f"Stored graph visualization to {vis_path}", "INFO", verbose)
            except Exception as e:
                self._log(f"Error during visualization: {e}")


    def visualize(self, output_path=None, graph_to_visualize: BaseGraph = None,
                  show_legend: bool = False, legend_position: str = "top-right"):
        from pyvis.network import Network
        from collections import defaultdict
        import math
        import random

        # Use provided graph or default to self.graph.consolidated_graph
        if graph_to_visualize is None:
            target_graph = self.graph.consolidated_graph
        else:
            target_graph = graph_to_visualize

        def random_color():
            """Generate a random pastel color in hex."""
            # Generate slightly lighter pastel colors
            r = int(127 + random.random() * 128)
            g = int(127 + random.random() * 128)
            b = int(127 + random.random() * 128)
            return f"#{r:02x}{g:02x}{b:02x}"

        # Build a deterministic palette-based color map keyed by entity_type
        palette = [
            '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ]
        entity_types = list({c.entity_type for c in target_graph.concepts})
        type_color_map = {et: palette[i % len(palette)] for i, et in enumerate(entity_types)}

        def graph_to_pyvis_data():
            """Convert a BaseGraph object into pyvis-compatible node and edge lists."""
            nodes = []  # list of dicts: {id, label, title, color, size, ...}
            edges = []  # list of dicts: {source, target, label, title, color, ...}

            default_entity_node_color = "#ADD8E6"  # Light blue for entities (fallback)
            default_edge_color = "#A9A9A9"  # Dark gray
            node_degrees = defaultdict(int)  # To calculate node sizes
            created_nodes = set()  # Track which nodes we've already created

            # Pre-calculate degrees from relation objects
            for rel in target_graph.relation_objects:
                node_degrees[rel.subject_id] += 1
                node_degrees[rel.object_id] += 1

            # Use concepts for entity nodes (richer information than plain entities)
            for concept in target_graph.concepts:
                entity = concept.id
                degree = node_degrees.get(entity, 0)

                size = min(max(10 + 5 * math.log(1 + degree), 10), 40)
                # Limit label to 15 characters
                display_label = concept.prefLabel[:15] + "..." if len(concept.prefLabel) > 15 else concept.prefLabel
                # Use simple text for title instead of HTML (pyvis sometimes has issues with HTML)
                title = f"Full Name: {concept.prefLabel} | Type: {concept.entity_type} | AltNames: {concept.altLabels}"
                nodes.append(
                    {
                        "id": entity,
                        "label": display_label,
                        "title": title,
                        "color": type_color_map.get(concept.entity_type, default_entity_node_color),
                        "size": size,
                        "shape": "dot",
                    }
                )
                created_nodes.add(entity)

            
            # Use relation objects for edges
            unique_preds = {rel.predicate for rel in target_graph.relation_objects}
            pred_colors = {pred: random_color() for pred in unique_preds}

            for rel in target_graph.relation_objects:
                # Use different colors based on predicate
                color = pred_colors.get(rel.predicate, default_edge_color)
                
                # Use simple text for title instead of HTML
                title = f"Relation: {rel.predicate} | From: {rel.subject_id} | To: {rel.object_id}"
                if hasattr(rel, 'evidence_text') and rel.evidence_text:
                    title += f" | Evidence: {rel.evidence_text[:50]}..."
                    
                edges.append(
                    {
                        "source": rel.subject_id,
                        "target": rel.object_id,
                        "label": rel.predicate,
                        "title": title,
                        "color": color,
                    }
                )

            return nodes, edges



        """Render the graph object to an interactive HTML file using pyvis."""
        # Check if graph has concepts and relations
        has_data = (target_graph and target_graph.concepts and target_graph.relation_objects)
        if not has_data:
            raise ValueError("Error: Cannot visualize empty or invalid graph\n")

        nodes, edges = graph_to_pyvis_data()

        try:
            net = Network(
                height="800px",
                width="100%",
                directed=True,
                notebook=output_path is None,
                cdn_resources="remote",
                
            )
        except Exception as e:
            raise ValueError(f"Error initializing Network: {e}\n")
            
        # Enhanced aesthetics and physics options - Removed comments for JSON compatibility
        net.set_options(
            """
            var options = {
            "nodes": {
                "font": {"size": 14, "face": "tahoma"},
                "borderWidth": 1,
                "borderWidthSelected": 2
            },
            "edges": {
                "arrows": {"to": {"enabled": true, "scaleFactor": 0.6}},
                "color": {"inherit": false},
                "smooth": {"type": "dynamic", "roundness": 0.2},
                "font": {"size": 11, "face": "tahoma", "align": "middle", "strokeWidth": 2, "strokeColor": "#ffffff"},
                "width": 1.5,
                "hoverWidth": 0.5,
                "selectionWidth": 1
            },
            "physics": {
                "enabled": true,
                "barnesHut": {
                "gravitationalConstant": -25000,
                "centralGravity": 0.1,
                "springLength": 120,
                "springConstant": 0.05,
                "damping": 0.15,
                "avoidOverlap": 0.5
                },
                "maxVelocity": 50,
                "minVelocity": 0.5,
                "solver": "barnesHut",
                "stabilization": {
                "enabled": true,
                "iterations": 1000,
                "updateInterval": 50,
                "onlyDynamicEdges": false,
                "fit": true
                },
                "timestep": 0.5,
                "adaptiveTimestep": true
            },
            "interaction": {
                "dragNodes": true,
                "dragView": true,
                "hideEdgesOnDrag": false,
                "hideNodesOnDrag": false,
                "hover": true,
                "hoverConnectedEdges": true,
                "keyboard": {"enabled": true},
                "multiselect": true,
                "navigationButtons": true,
                "selectable": true,
                "selectConnectedEdges": true,
                "tooltipDelay": 200,
                "zoomView": true
            },
            "manipulation": {
                "enabled": false
            }
            }
            """
        )

        # Add nodes and edges with specific properties
        try:
            for n in nodes:
                net.add_node(
                    n["id"],
                    label=n["label"],
                    title=n.get("title"),  # HTML title for hover tooltip
                    color=n.get("color"),
                    size=n.get("size"),
                    shape=n.get("shape", "dot"),  # Use shape if defined
                )

            for e in edges:
                net.add_edge(
                    e["source"],
                    e["target"],
                    label=e.get("label"),
                    title=e.get("title"),  # HTML title for hover tooltip
                    color=e.get("color"),
                )

            if output_path is None:
                return net
            else:
                net.write_html(output_path)
                if show_legend:
                    pos_map = {
                        'top-right':    'top:10px; right:10px;',
                        'top-left':     'top:10px; left:10px;',
                        'bottom-right': 'bottom:10px; right:10px;',
                        'bottom-left':  'bottom:10px; left:10px;'
                    }
                    pos_css = pos_map.get(legend_position, pos_map['top-right'])
                    items = ''.join(
                        f'<div class="nkg-legend-item">'
                        f'<span class="nkg-legend-swatch" style="background:{color}"></span>'
                        f'<span class="nkg-legend-label">{et}</span></div>'
                        for et, color in type_color_map.items()
                    )
                    legend_html = (
                        f'<style>'
                        f'.nkg-legend{{position:fixed;{pos_css}z-index:9999;'
                        f'background:rgba(34,34,34,0.9);color:#fff;padding:8px;'
                        f'border-radius:6px;max-height:40vh;overflow:auto;'
                        f'font-family:sans-serif;font-size:13px;}}'
                        f'.nkg-legend-item{{display:flex;align-items:center;margin:4px 0}}'
                        f'.nkg-legend-swatch{{width:14px;height:14px;display:inline-block;'
                        f'margin-right:8px;border-radius:2px;}}'
                        f'.nkg-legend-label{{white-space:nowrap}}'
                        f'</style>'
                        f'<div class="nkg-legend">{items}</div>'
                    )
                    with open(output_path, 'a') as f:
                        f.write(legend_html)
            #print(f"Successfully generated visualization: {output_path}")
        except Exception as e:
            #print(f"edge: {e}\nnodes: {nodes}\n edges: {edges}")
            raise ValueError(f"Error generating HTML file with pyvis: {e}")

    def OLDvisualize(self, output_path=None, graph_to_visualize: BaseGraph = None):
        from pyvis.network import Network
        from collections import defaultdict
        import math
        import random

        # Use provided graph or default to self.graph.consolidated_graph
        if graph_to_visualize is None:
            target_graph = self.graph.consolidated_graph
        else:
            target_graph = graph_to_visualize

        def random_color():
            """Generate a random pastel color in hex."""
            # Generate slightly lighter pastel colors
            r = int(127 + random.random() * 128)
            g = int(127 + random.random() * 128)
            b = int(127 + random.random() * 128)
            return f"#{r:02x}{g:02x}{b:02x}"

        def graph_to_pyvis_data():
            """Convert a BaseGraph object into pyvis-compatible node and edge lists."""
            nodes = []  # list of dicts: {id, label, title, color, size, ...}
            edges = []  # list of dicts: {source, target, label, title, color, ...}

            default_entity_node_color = "#ADD8E6"  # Light blue for entities
            default_value_node_color = "#90EE90"   # Light green for values
            default_edge_color = "#A9A9A9"  # Dark gray
            cluster_colors = {}
            edge_cluster_colors = {}
            node_degrees = defaultdict(int)  # To calculate node sizes
            created_nodes = set()  # Track which nodes we've already created

            # Pre-calculate degrees from relation objects
            for rel in target_graph.relation_objects:
                node_degrees[rel.subject_id] += 1
                node_degrees[rel.object_id] += 1

            # Use concepts for entity nodes (richer information than plain entities)
            for concept in target_graph.concepts:
                entity = concept.id
                degree = node_degrees.get(entity, 0)

                size = min(max(10 + 5 * math.log(1 + degree), 10), 40)
                # Limit label to 15 characters
                display_label = concept.prefLabel[:15] + "..." if len(concept.prefLabel) > 15 else concept.prefLabel
                # Use simple text for title instead of HTML (pyvis sometimes has issues with HTML)
                title = f"Full Name: {concept.prefLabel} | Type: {concept.entity_type} | AltNames: {concept.altLabels}"
                nodes.append(
                    {
                        "id": entity,
                        "label": display_label,
                        "title": title,
                        "color": default_entity_node_color,
                        "size": size,
                        "shape": "dot",
                    }
                )
                created_nodes.add(entity)

            
            # Use relation objects for edges
            unique_preds = {rel.predicate for rel in target_graph.relation_objects}
            pred_colors = {pred: random_color() for pred in unique_preds}

            for rel in target_graph.relation_objects:
                # Use different colors based on predicate
                color = pred_colors.get(rel.predicate, default_edge_color)
                
                # Use simple text for title instead of HTML
                title = f"Relation: {rel.predicate} | From: {rel.subject_id} | To: {rel.object_id}"
                if hasattr(rel, 'evidence_text') and rel.evidence_text:
                    title += f" | Evidence: {rel.evidence_text[:50]}..."
                    
                edges.append(
                    {
                        "source": rel.subject_id,
                        "target": rel.object_id,
                        "label": rel.predicate,
                        "title": title,
                        "color": color,
                    }
                )

            return nodes, edges



        """Render the graph object to an interactive HTML file using pyvis."""
        # Check if graph has concepts and relations
        has_data = (target_graph and target_graph.concepts and target_graph.relation_objects)
        if not has_data:
            raise ValueError("Error: Cannot visualize empty or invalid graph\n")

        nodes, edges = graph_to_pyvis_data()

        try:
            net = Network(
                height="800px",
                width="100%",
                directed=True,
                notebook=output_path is None,
                cdn_resources="remote",
                
            )
        except Exception as e:
            raise ValueError(f"Error initializing Network: {e}\n")
            
        # Enhanced aesthetics and physics options - Removed comments for JSON compatibility
        net.set_options(
            """
            var options = {
            "nodes": {
                "font": {"size": 14, "face": "tahoma"},
                "borderWidth": 1,
                "borderWidthSelected": 2
            },
            "edges": {
                "arrows": {"to": {"enabled": true, "scaleFactor": 0.6}},
                "color": {"inherit": false},
                "smooth": {"type": "dynamic", "roundness": 0.2},
                "font": {"size": 11, "face": "tahoma", "align": "middle", "strokeWidth": 2, "strokeColor": "#ffffff"},
                "width": 1.5,
                "hoverWidth": 0.5,
                "selectionWidth": 1
            },
            "physics": {
                "enabled": true,
                "barnesHut": {
                "gravitationalConstant": -25000,
                "centralGravity": 0.1,
                "springLength": 120,
                "springConstant": 0.05,
                "damping": 0.15,
                "avoidOverlap": 0.5
                },
                "maxVelocity": 50,
                "minVelocity": 0.5,
                "solver": "barnesHut",
                "stabilization": {
                "enabled": true,
                "iterations": 1000,
                "updateInterval": 50,
                "onlyDynamicEdges": false,
                "fit": true
                },
                "timestep": 0.5,
                "adaptiveTimestep": true
            },
            "interaction": {
                "dragNodes": true,
                "dragView": true,
                "hideEdgesOnDrag": false,
                "hideNodesOnDrag": false,
                "hover": true,
                "hoverConnectedEdges": true,
                "keyboard": {"enabled": true},
                "multiselect": true,
                "navigationButtons": true,
                "selectable": true,
                "selectConnectedEdges": true,
                "tooltipDelay": 200,
                "zoomView": true
            },
            "manipulation": {
                "enabled": false
            }
            }
            """
        )

        # Add nodes and edges with specific properties
        try:
            for n in nodes:
                net.add_node(
                    n["id"],
                    label=n["label"],
                    title=n.get("title"),  # HTML title for hover tooltip
                    color=n.get("color"),
                    size=n.get("size"),
                    shape=n.get("shape", "dot"),  # Use shape if defined
                )

            for e in edges:
                net.add_edge(
                    e["source"],
                    e["target"],
                    label=e.get("label"),
                    title=e.get("title"),  # HTML title for hover tooltip
                    color=e.get("color"),
                )

            if output_path is None:
                return net
            else:
                net.write_html(output_path)
            #print(f"Successfully generated visualization: {output_path}")
        except Exception as e:
            #print(f"edge: {e}\nnodes: {nodes}\n edges: {edges}")
            raise ValueError(f"Error generating HTML file with pyvis: {e}")

    
#----------------------------------------------------------------------------------------------------------
# Grapg Analysis ans comapre 
#----------------------------------------------------------------------------------------------------------


@dataclass
class ConceptB:
    obj: "Concept"
    vec: np.ndarray
    he_keys: Set[str]
    en_keys: Set[str]

@dataclass

class PreparedB:
    b_ids: List[str]          # index -> concept id
    B: np.ndarray             # shape (N, d)
    B_norms: np.ndarray       # shape (N,)


class GraphSimilarity:
    '''
        1. Detect nodes similarity between two graphs using a hybrid approach of Jaccard soft-overlap on Hebrew labels and cosine similarity on embeddings.
        2. Use LLM to verify these similarities. 

        please print the readme method for full documentation
    '''

    def __init__(self, concepts_g1=None, concept_embeddings_g1=None, concepts_g2=None, concept_embeddings_g2=None, n_embed=50, topk=5, min_cos=0.55, strict_type=True, w_sim=0.70, w_he=0.15, w_en=0.10):
        self.HE_NIQQUD_RE = re.compile(r"[\u0591-\u05C7]")  # Hebrew cantillation + niqqud
        self.PUNCT_RE = re.compile(r"[^\w\u0590-\u05FF]+", re.UNICODE)
        self.n_embed=n_embed
        self.topk=topk
        self.min_cos=min_cos
        self.strict_type=strict_type
        self.w_sim = w_sim
        self.w_he = w_he
        self.w_en = w_en

        if concepts_g1 is not None and concept_embeddings_g1 is not None and concepts_g2 is not None and concept_embeddings_g2 is not None:
            self.nodes_similarity(concepts_g1, concept_embeddings_g1, concepts_g2, concept_embeddings_g2)
    
    def readme(self) -> str:
        """
        Return a comprehensive README for the GraphSimilarity pipeline.
        Reflects Jaccard Soft-Overlap and Batch Node Similarity.
        """
        return f"""
        # GraphSimilarity — Hybrid Alignment Pipeline (Jaccard + Embeddings)

        ## 1. Overview
        AlignGraphNodes is designed to align concepts between two Knowledge Graphs (Graph A and Graph B). 
        It uses a **Hybrid Scoring Strategy** that balances semantic meaning (Embeddings) with 
        orthographic similarity (Jaccard Character N-Grams) to handle Hebrew spelling variations 
        and prefixes.

        ---

        ## 2. Core Logic & Scoring
        The matching engine generates a score based on three components:
        
        1. **Semantic Similarity (70%)**: Cosine similarity between Graph A and Graph B embeddings.
        2. **Hebrew Soft Match (15%)**: A Jaccard similarity score based on character 3-grams of normalized Hebrew labels.
           - This handles variants like "הכפורת" vs "כפורת" better than exact matching.
        3. **English Lexical Match (10%)**: A binary hit (0 or 1) based on exact normalized English labels.

        **Formula:** `Score = (w_sim * Cosine) + (w_he * Jaccard_He) + (w_en * English_Hit)`

        ---

        ## 3. Class Methods Documentation

        ### Initialization & Setup
        - `__init__()`: Sets up Hebrew niqqud and punctuation regex filters.
        - `nodes_similarity(...)`: The main entry point for batch processing.
          - Coordinates dictionary mapping, index building, and candidate generation.

        ### Normalization & Strings
        - `norm_he(text)` / `norm_en(text)`: Standardizes text by removing niqqud, unifying whitespace, and stripping specific Hebrew punctuation (geresh/gershayim).
        - `char_ngrams(text, n=3)`: Breaks Hebrew strings into overlapping character sets for fuzzy matching.
        - `he_soft_overlap(concept_a, concept_b)`: Calculates the Jaccard similarity between the n-gram sets of two concepts.

        ### Indexing & Search
        - `build_b_indices(...)`: Creates reverse lookup maps for Graph B to allow O(1) lexical seeding.
        - `prepare_b_matrix(...)`: Converts Graph B vectors into a stacked NumPy matrix for high-speed batch cosine calculations.
        - `neighbors_from_prepared(...)`: Uses matrix multiplication to find top semantic neighbors.

        ---

        ## 4. How To Use

        ### Step 1: Instantiate
        ```python
        gs = GraphSimilarity()
        ```

        ### Step 2: Run Batch Alignment
        Pass your concept lists and their corresponding embedding lists:
        ```python
        results = gs.nodes_similarity(
            concepts_g1=list_of_a_concepts,
            concept_embeddings_g1=list_of_a_vectors,
            concepts_g2=list_of_b_concepts,
            concept_embeddings_g2=list_of_b_vectors,
            topk=5, 
            min_cos=0.55
        )
        ```

        ### Step 3: Access Results
        `gs.candidates` will be populated with a dictionary where keys are Graph A IDs and values 
        are lists of ranked Graph B candidates including their scores and gating notes.
        """
    
    # ----------------------------
    # Normalization helpers
    # ----------------------------
    
    def norm_he(self,s: str) -> str:
        if not s:
            return ""
        s = self.HE_NIQQUD_RE.sub("", s)
        s = s.strip()
        s = self.PUNCT_RE.sub(" ", s)
        s = re.sub(r"\s+", " ", s)
        s = s.replace("׳", "'").replace("״", '"')   # unify Hebrew punctuation
        s = s.replace("'", "")                      # drop geresh for matching
        s = s.replace('"', "")                      # drop gershayim

        return s

    def norm_en(self,s: str) -> str:
            if not s:
                return ""
            s = s.lower().strip()
            s = re.sub(r"[^a-z0-9]+", " ", s)
            s = re.sub(r"\s+", " ", s)
            return s

    # ----------------------------
    # Embedding math
    # ----------------------------
    
    def cosine(self,u: List[float], v: List[float]) -> float:
        # Safe cosine with explicit norms
        dot = 0.0
        nu = 0.0
        nv = 0.0
        for a, b in zip(u, v):
            dot += a * b
            nu += a * a
            nv += b * b
        if nu <= 0.0 or nv <= 0.0:
            return 0.0
        return dot / math.sqrt(nu * nv)


    # ----------------------------
    # Indexing + candidate generation
    # ----------------------------

    def he_label_text(self, c: Any) -> str:
        parts = [getattr(c, "prefLabel", "") or ""]
        parts += list(getattr(c, "altLabels", []) or [])
        return self.norm_he(" ".join(parts))

    def char_ngrams(self, s: str, n: int = 3) -> Set[str]:
        s = s.replace(" ", "")
        if len(s) < n:
            return {s} if s else set()
        return {s[i:i+n] for i in range(len(s) - n + 1)}
    
    def jaccard(self, a: Set[str], b: Set[str]) -> float:
        if not a and not b:
            return 1.0
        if not a or not b:
            return 0.0
        inter = len(a & b)
        union = len(a | b)
        return inter / union if union else 0.0
    
    def he_soft_overlap(self, a: Any, b: Any, n: int = 3) -> float:
        ta = self.he_label_text(a)
        tb = self.he_label_text(b)
        return self.jaccard(self.char_ngrams(ta, n), self.char_ngrams(tb, n))

    
    def he_keys(self,c: Dict[str, Any]) -> Set[str]:
        keys = set()
        pl = self.norm_he(c.prefLabel or "")
        if pl:
            keys.add(pl)
        for alt in c.altLabels or []:
            a = self.norm_he(alt)
            if a:
                keys.add(a)
        return keys
    
    def en_keys(self,c: Dict[str, Any]) -> Set[str]:
        keys = set()
        pl = self.norm_en(c.prefLabel_en or "")
        if pl:
            keys.add(pl)
        for alt in c.altLabels_en or []:
            a = self.norm_en(alt)
            if a:
                keys.add(a)
        return keys


    
    def build_b_indices(self,
        concepts_b: List["Concept"],
        embeddings_b: Dict[str, np.ndarray],  # concept.id -> np.ndarray
    ) -> Tuple[
        Dict[str, Set[str]],   # index_he
        Dict[str, Set[str]],   # index_en
        Dict[str, List[str]],  # by_type
        Dict[str, ConceptB],   # b_map
        List[str],             # b_ids
    ]:
        index_he: Dict[str, Set[str]] = {}
        index_en: Dict[str, Set[str]] = {}
        by_type: Dict[str, List[str]] = {}
        b_map: Dict[str, ConceptB] = {}
        b_ids: List[str] = []
    
        for c in concepts_b:
            cid = c.id
            vec = embeddings_b.get(cid)
    
            # accept numpy arrays (or anything array-like)
            if vec is None:
                continue
            vec = np.asarray(vec, dtype=np.float32)
            if vec.size == 0:
                continue
    
            hk = self.he_keys(c)
            ek = self.en_keys(c)
    
            b_map[cid] = ConceptB(obj=c, vec=vec, he_keys=hk, en_keys=ek)
            b_ids.append(cid)
    
            for k in hk:
                index_he.setdefault(k, set()).add(cid)
            for k in ek:
                index_en.setdefault(k, set()).add(cid)
    
            et = c.entity_type or ""
            by_type.setdefault(et, []).append(cid)
    
        return index_he, index_en, by_type, b_map, b_ids

    def prepare_b_matrix(self,
        b_ids: List[str],
        b_map: Dict[str, "ConceptB"],
    ) -> PreparedB:
        """
        Precompute B matrix and norms for fast cosine neighbor search.
        """
        B = np.vstack([b_map[bid].vec for bid in b_ids]).astype(np.float32)
        B_norms = np.linalg.norm(B, axis=1).astype(np.float32)
        # Avoid zero norms
        B_norms[B_norms == 0.0] = 1e-12
        return PreparedB(b_ids=b_ids, B=B, B_norms=B_norms)


    def neighbors_from_prepared(self,
        vec_a: np.ndarray,
        prepared: PreparedB,
        top_n: int = 50,
    ) -> List[Tuple[str, float]]:
        """
        Fast cosine nearest neighbors with precomputed B.
        Returns List[(b_id, cosine)] sorted desc.
        """
        vec_a = np.asarray(vec_a, dtype=np.float32).reshape(-1)
        if vec_a.size == 0:
            return []
    
        a_norm = np.linalg.norm(vec_a)
        if a_norm == 0.0:
            return []
    
        sims = (prepared.B @ vec_a) / (prepared.B_norms * a_norm)
    
        n = min(top_n, sims.shape[0])
        top_idx = np.argpartition(-sims, n - 1)[:n]
        top_idx = top_idx[np.argsort(-sims[top_idx])]
    
        return [(prepared.b_ids[i], float(sims[i])) for i in top_idx]


    
    def generate_candidates_for_a(self,
        a: "Concept",
        embeddings_a: Dict[str, np.ndarray],
        index_he: Dict[str, Set[str]],
        index_en: Dict[str, Set[str]],
        b_map: Dict[str, ConceptB],
        prepared_b: PreparedB,
        *,
        n_embed: int = 50,     # how many embedding neighbors to add to pool
        topk: int = 8,         # how many candidates to output
        min_cos: float = 0.55, # cosine threshold after gating
        strict_type: bool = True,
        # scoring weights
        w_sim: float = 0.70,
        w_he: float = 0.15,
        w_en: float = 0.10,
    ) -> Dict[str, Any]:
        """
        Generate ranked candidate matches in Graph B for a single concept A.
    
        Returns dict:
          {
            "a_id": ...,
            "a_prefLabel": ...,
            "a_entity_type": ...,
            "gating_notes": [...],
            "candidates": [
                {
                  "b_id": ...,
                  "score": ...,
                  "cos": ...,
                  "he_hit": 0/1,
                  "en_hit": 0/1,
                  "b_prefLabel": ...,
                  "b_entity_type": ...
                }, ...
            ]
          }
        """
        out: Dict[str, Any] = {
            "a_id": a.id,
            "a_prefLabel": a.prefLabel,
            "a_entity_type": a.entity_type,
            "gating_notes": [],
            "candidates": [],
        }
    
        vec_a = embeddings_a.get(a.id)
        if vec_a is None:
            out["gating_notes"].append("no_embedding_for_a")
            return out
    
        vec_a = np.asarray(vec_a, dtype=np.float32).reshape(-1)
        if vec_a.size == 0:
            out["gating_notes"].append("empty_embedding_for_a")
            return out
    
        # Skip BiblicalQuotation if you're handling separately
        if a.entity_type == "BiblicalQuotation":
            out["gating_notes"].append("skipped_biblicalquotation")
            return out
    
        # ---- Step 1: label-overlap seed pool
        cand: Set[str] = set()
        a_hk = self.he_keys(a)
        a_ek = self.en_keys(a)
    
        for k in a_hk:
            cand |= index_he.get(k, set())
        for k in a_ek:
            cand |= index_en.get(k, set())
    
        if cand:
            out["gating_notes"].append(f"seeded_by_label_overlap:{len(cand)}")
        else:
            out["gating_notes"].append("seeded_by_label_overlap:0")
    
        # ---- Step 2: add embedding neighbors (high recall)
        nn = self.neighbors_from_prepared(vec_a, prepared_b, top_n=n_embed)
        cand |= {bid for bid, _ in nn}
        out["gating_notes"].append(f"added_embedding_neighbors:{min(n_embed, len(prepared_b.b_ids))}")
    
        # ---- Step 3: type gate
        if strict_type:
            before = len(cand)
            cand = {bid for bid in cand if b_map[bid].obj.entity_type == a.entity_type}
            out["gating_notes"].append(f"type_gate_strict:{before}->{len(cand)}")
    
        # ---- Step 4: score + threshold
        scored: List[Dict[str, Any]] = []
        for bid in cand:
            b = b_map[bid]
            cosv = float((b.vec @ vec_a) / (np.linalg.norm(b.vec) * np.linalg.norm(vec_a) + 1e-12))
    
            if cosv < min_cos:
                continue
    
            #he_hit = 1 if (a_hk & b.he_keys) else 0
            he_soft = self.he_soft_overlap(a, b.obj, n=3)   # 0..1
            en_hit = 1 if (a_ek & b.en_keys) else 0
    
            #score = (w_sim * cosv) + (w_he * he_hit) + (w_en * en_hit)
            score = (w_sim * cosv) + (w_he * he_soft) + (w_en * en_hit)
            
            scored.append({
                "b_id": bid,
                "score": round(score, 6),
                "cos": round(cosv, 6),
                #"he_hit": he_hit,
                "he_soft": round(he_soft, 3),
                "en_hit": en_hit,
                "b_prefLabel": b.obj.prefLabel,
                "b_entity_type": b.obj.entity_type,
            })
    
        scored.sort(key=lambda x: x["score"], reverse=True)
        out["candidates"] = scored[:topk]
        out["gating_notes"].append(f"min_cos_applied:{min_cos}")
        out["gating_notes"].append(f"topk:{topk}")
    
        return out
    

    def nodes_similarity(self, concepts_g1, concept_embeddings_g1, concepts_g2, concept_embeddings_g2):
        
        self.concpts_g1 = concepts_g1
        self.concept_embeddings_g1 = concept_embeddings_g1
        self.concepts_g2 = concepts_g2
        self.concept_embeddings_g2 = concept_embeddings_g2

        # Ensure we are working with numpy arrays
        emb_a = {c.id: np.asarray(e) for c, e in zip(concepts_g1, concept_embeddings_g1)}
        emb_b = {c.id: np.asarray(e) for c, e in zip(concepts_g2, concept_embeddings_g2)}

        # Build B indices
        index_he, index_en, by_type, b_map, b_ids = self.build_b_indices(concepts_g2, emb_b)
        
        # --- FIX: Check if b_ids is empty before proceeding ---
        if not b_ids:
            print("Warning: No valid concepts with embeddings found in Graph 2. Alignment aborted.")
            self.candidates = {}
            return self.candidates

        prepared_b = self.prepare_b_matrix(b_ids, b_map)

        self.candidates = {}
        # Note: Using concepts_g1 directly is safer than cg.kg1_free_concepts 
        # unless that global is specifically what you intend to align.
        for a0 in concepts_g1: 
            res = self.generate_candidates_for_a(
                a=a0, 
                embeddings_a=emb_a, 
                index_he=index_he,
                index_en=index_en, 
                b_map=b_map, 
                prepared_b=prepared_b,
                n_embed=self.n_embed,
                topk=self.topk,
                min_cos=self.min_cos,
                strict_type=self.strict_type,
                w_sim=self.w_sim,
                w_he=self.w_he,
                w_en=self.w_en,
            )
            self.candidates[a0.id] = res
        
        
class KGNetworkStructureAnalysis:
    '''
    This class provides methods to analyze the structure of a knowledge graph using NetworkX.
    It includes functionalities to detect components, communities, centrality measures, density, and shortest paths.
    It is used by CompareKG to analyze the structure of the two knowledge graphs.
    input: a BaseGraph object (or any graph object with .concepts and .relation_objects that can be converted to a NetworkX graph)


    '''
    def __init__(self, graph=None, verbose= False):
        self.verbose = verbose
        if graph:
            self.measure_graph(graph)
        else:
            self._reset()

    def _reset(self):
        self.G = None
        self.components = None
        self.giant_component_graph = None
        self.degree = None
        self.betweenness = None
        self.eigenvector = None
        self.df_centrality = None
        self.density = None
        self.shortest_path = None
        
        
    def init_graph(self, graph, directed=False):
        # Initialize a directed or undirected graph
        # Components are usually calculated on undirected versions
        
        self._reset()
        
        if directed:
            self.G= nx.DiGraph()
        else:
            self.G = nx.Graph()
    
        # Add nodes from concepts
        for concept in graph.concepts:
            tmp = {"prefLabel": concept.prefLabel, "entity_type":concept.entity_type, "prefLabel_en":concept.prefLabel_en}
            self.G.add_node(concept.id, **tmp)
    
        # Add edges from relation_objects
        for relation in graph.relation_objects:
            self.G.add_edge(relation.subject_id, relation.object_id, 
                       predicate=relation.predicate, 
                       evidence=relation.evidence_text)
    
        return self.G

    def detect_components(self):
        if self.G is None:
            return
        if self.components:
            return self.components
    
        # Find all connected components and sort by size (descending)
        self.components = sorted(nx.connected_components(self.G), key=len, reverse=True)

        if self.components:
            largest_component_nodes = self.components[0]
            # Create a new graph containing only the giant component
            self.giant_component_graph = self.G.subgraph(largest_component_nodes).copy()

            if self.verbose:
                print(f"Original nodes: {self.G.number_of_nodes()}")
                print(f"Giant component nodes: {self.giant_component_graph.number_of_nodes()}")

                # Get all separate groups (islands) in the graph
                print(f"All Components")
                for idx,c in enumerate(self.components):
                    print(f"Cluster {idx+1}, Members: {c}")
            
    def detect_communities(self):
        if self.G is None:
            return
        
        from networkx.algorithms import community

        self.communities = community.louvain_communities(self.G)

        if self.verbose:
            # This returns a list of sets, where each set is a cluster
            for i, comm in enumerate(self.communities):
                print(f"Comunity {i} has {len(comm)} nodes.")
            
            print(f"Detected {len(self.communities)} communities:\n")
            for i, comm in enumerate(self.communities, 1):
                print(f"--- Community {i} (Size: {len(comm)}) ---")
                for node_id in sorted(comm):
                    # Retrieve the label we stored earlier
                    label = self.G.nodes[node_id].get('prefLabel', 'No Label')
                    print(f"  • {node_id}: {label}")
                print()

    def centrality_measurements(self):
        if self.G is None:
            return

        # Calculate centralities
        self.degree = nx.degree_centrality(self.G)
        self.betweenness = nx.betweenness_centrality(self.G)
        self.eigenvector = nx.eigenvector_centrality(self.G, max_iter=1000)
        
        # Create a summary table for analysis
        analysis_results = []
        for node_id in self.G.nodes():
            analysis_results.append({
                "ID": node_id,
                "Label": self.G.nodes[node_id].get('prefLabel', 'N/A'),
                "Degree": round(self.degree[node_id], 3),
                "Betweenness": round(self.betweenness[node_id], 3),
                "Influence": round(self.eigenvector[node_id], 3)
            })
        
        # Convert to a DataFrame and sort by Betweenness
        self.df_centrality = pd.DataFrame(analysis_results).sort_values(by="Betweenness", ascending=False)

        if self.verbose:
            print(self.df_centrality)
        
    def detect_density(self):
        '''
        Density: The ratio of actual edges to possible edges. 
                 A low density suggests a sparse text with distinct, isolated ideas; 
                 a high density suggests a highly integrated commentary.
        '''
        self.density = nx.density(self.G)
        if self.verbose:
            print(f"The Density is: {self.density}")

    def detect_shortest_path(self):
        if self.giant_component_graph is None:
            return
        self.shortest_path = nx.average_shortest_path_length(self.giant_component_graph)
        if self.verbose:
            print(f"The graph avarage shortest path is: {self.shortest_path}")
            
    def measure_graph(self, graph, directed=False):
        self.init_graph(graph)
        self.detect_components()
        self.detect_communities()
        self.centrality_measurements()
        self.detect_density()
        self.detect_shortest_path()


class CompareKG:
    '''
    A class to compare two knowledge graphs and identify differences in concepts and relations.
    '''
    def __init__(self, path1: str = None, path2: str = None, name1: str="", name2: str="", 
                 embedding_store_path=None,  embedding_restore_path=None, verbose=False):

        self.signature_module = "signatures_ramban"
        self.embedding_model = "text-embedding-3-small" # "text-embedding-3-large" / "text-embedding-3-small"
        self.verbose = verbose
        if path1 and path2:
            self.load_and_compare(path1, path2, name1, name2, embedding_store_path, embedding_restore_path)
        else:
            self._reset()

    def readme(self, lverbose=False) -> str:
        documentation = """
        # CompareKG — Knowledge Graph Comparison and Analysis

        ## Overview
        CompareKG is a comprehensive tool designed to compare two knowledge graphs (KGs) and analyze their structural and conceptual differences. 
        It provides functionalities to load KGs, split concepts into anchor and free categories, generate embeddings, and perform detailed graph analysis using NetworkX.

        ## Key Features
        1. **Graph Loading**: Load two KGs from specified paths and initialize them for comparison.
        2. **Concept Splitting**: Distinguish between anchor concepts (e.g., biblical quotations) and free concepts (other entities) in each KG.
        3. **Embedding Generation**: Create vector embeddings for free concepts using a specified embedding model, with options to restore from or save to disk.
        4. **Graph Analysis**: Analyze the structure of each KG using NetworkX, including component detection, community detection, centrality measures, density calculation, and shortest path analysis.

        ## Usage
        To use CompareKG, instantiate the class with the paths to your KGs:
        ```python
        compare_kg = CompareKG(path1="path/to/kg1.json", path2="path/to/kg2.json", name1="KG1", name2="KG2")
        ```

        You can also specify paths for embedding storage and restoration:
        ```python
        compare_kg = CompareKG(path1="path/to/kg1.json", path2="path/to/kg2.json", 
                                name1="KG1", name2="KG2",
                                embedding_store_path="path/to/store/embeddings",
                                embedding_restore_path="path/to/restore/embeddings")
        ```

        After loading and comparing the KGs, you can access various attributes such as `compare_kg.candidates` for concept matches or `compare_kg.kg1nx` and `compare_kg.kg2nx` for NetworkX graph objects.

        ## Conclusion
        CompareKG offers a robust framework for comparing knowledge graphs, making it easier to identify similarities and differences in their structures and concepts. 
        Whether you're analyzing textual commentaries or any other domain-specific KGs, CompareKG provides valuable insights through its comprehensive analysis tools.
        
        """
        if lverbose:
            print(documentation)

    def init_model(self, model: str = None, temperature: float = None, api_key: str = None, max_tokens: int = 30000):
        """Initialize or reinitialize the model with new parameters."""
        if model is not None:
            self.model = model
        if temperature is not None:
            self.temperature = temperature
        if api_key is not None:
            self.api_key = api_key
        
        self.max_tokens = max_tokens
        litellm.drop_params = True
        if self.api_key:
            self.lm = dspy.LM(model=self.model, api_key=self.api_key, temperature=self.temperature,  max_tokens=self.max_tokens)
        else:
            self.lm = dspy.LM(model=self.model, temperature=self.temperature,  max_tokens=self.max_tokens)

        dspy.configure(lm=self.lm)

    def _reset(self):
        self.kg1 = None
        self.kg2 = None
        self.kg1_anchor_concepts = []
        self.kg1_free_concepts = []
        self.kg1_concept_embeddings = []
        
        self.kg2_anchor_concepts = []
        self.kg2_free_concepts = []
        self.kg2_concept_embeddings = []
        self.anchor_concept_matches = []
        self.shared_anchor_ratio = 0.0
        self.kg1nx = None
        self.kg2nx = None
        self.free_similar_candidates = None
        self.gs = None
        self.lm = None
        self.LLM_checked_candidates = None
        self.graphs_overlap = None
        self.candidates = None


    def normalize_predicates(self,relations: List[Relation], inline=True) -> List[Relation]:
        """
        Returns a new list of Relation objects with predicates normalized 
        according to the provided mapping (Ontology).
        """

        # The mapping dictionary based on the recommended ontology
        PREDICATE_MAP: Dict[str, str] = {
            # Spatial & Structural
            "partOf": "isPartOf", "housedIn": "isPartOf", "contains": "isPartOf", 
            "madeFrom": "isPartOf", "madeOf": "isPartOf", "patternOf": "isPartOf", 
            "involvesPlacingInto": "isPartOf", "containsQuotation": "isPartOf",
            
            "locatedIn": "isLocatedAt", "locatedOn": "isLocatedAt", "dwellsOn": "isLocatedAt", 
            "placedOn": "isLocatedAt", "occursAbove": "isLocatedAt", "below": "isLocatedAt", 
            "under": "isLocatedAt", "attained": "isLocatedAt", "isLocationOf": "isLocatedAt", 
            "isDwellingPlaceOf": "isLocatedAt", "isUnder": "isLocatedAt", "occursBetween": "isLocatedAt",
            
            "cover": "covers", "coverWithWings": "covers", "coversWithWings": "covers", 
            "coverWithWings": "covers", "separates": "covers",

            # Semantic & Symbolic
            "represents": "symbolizes", "represent": "symbolizes", "isRepresentedBy": "symbolizes", 
            "symbolizedBy": "symbolizes", "isIdentifiedAs": "symbolizes", "hintAt": "symbolizes", 
            "alludesTo": "symbolizes", "alludeTo": "symbolizes", "symbolize": "symbolizes", 
            "isIdentifiedIn": "symbolizes", "isAbout": "symbolizes", "specialSignificanceFor": "symbolizes",
            
            "isLike": "correspondsTo", "comparedTo": "correspondsTo", "relatedTo": "correspondsTo", 
            "associatedWith": "correspondsTo", "connectedTo": "correspondsTo", "isLinkedTo": "correspondsTo", 
            "tracesBackTo": "correspondsTo", "are": "correspondsTo", "identifies": "correspondsTo",

            "isExplainedBy": "interprets", "explains": "interprets", "leadsToUnderstandingOf": "interprets", 
            "impliesUnderstandingOf": "interprets", "interpreted": "interprets", "isA": "interprets",

            # Action & Experience
            "saw": "perceives", "sawVisionOf": "perceives", "seenBy": "perceives", 
            "perceivedThrough": "perceives", "isPerceivedThrough": "perceives", 
            "sawVisionAt": "perceives", "sawIn": "perceives", "isPartOfVisionOf": "perceives", 
            "isChariotSeenBy": "perceives",

            "isReceivedFrom": "communicates", "communicatedAt": "communicates", 
            "transmitsWisdomTo": "communicates", "reveals": "communicates", 
            "communicatedWith": "communicates", "communicatesWith": "communicates", 
            "revealsWisdomTo": "communicates", "flowsTo": "communicates", "impartsInfluenceTo": "communicates",

            "offersIncenseOn": "performsAction", "performsRitualIn": "performsAction", 
            "carry": "performsAction", "bearersOf": "performsAction", "ride": "performsAction", 
            "roleAs": "performsAction", "designedFor": "performsAction", "servesAs": "performsAction", 
            "serveAs": "performsAction", "facilitatesReceptionOf": "performsAction",

            # Textual & Evidentiary
            "mentions": "cites", "isReferencedIn": "cites", "bringsEvidenceFrom": "cites", 
            "mentionedIn": "cites", "refersTo": "cites",
            
            "isDescribedBy": "describes", "describesVisionOf": "describes", "describesMaterial": "describes", 
            "describesLocationOf": "describes", "describesActionOf": "describes", "isDescribedAs": "describes", 
            "describesObject": "describes", "describedBy": "describes", "describedAs": "describes", 
            "describesCommunication": "describes", "hasSecrets": "describes"
        }


        normalized_list = []
        
        for rel in relations:
            # Fetch the target predicate name
            new_predicate = PREDICATE_MAP.get(rel.predicate, rel.predicate)
            
            if inline:
                # Update the existing object directly
                rel.predicate = new_predicate
            else:
                # Create a new Relation instance for the new list
                normalized_rel = Relation(
                    subject_id=rel.subject_id,
                    predicate=new_predicate,
                    object_id=rel.object_id,
                    evidence_text=rel.evidence_text
                )
                normalized_list.append(normalized_rel)
        
        return None if inline else normalized_list

    def load_graphs(self, path1: str, path2: str, name1: str="", name2: str=""):
        self._reset()
        self.name1 = name1
        self.name2 = name2
        self.kg1=  NKGGenerator(model = None, api_key=None, signature_module=self.signature_module)
        self.kg1.init_graph(path=path1)
        self.kg2=  NKGGenerator(model = None, api_key=None, signature_module=self.signature_module)
        self.kg2.init_graph(path=path2)
        
    def _split_free_anchor_concepts(self):
        '''
        1. Split concepts that have free text anchors into separate concepts.
            anchors concepts are biblical quotations that are not part of the controlled vocabulary.
            free concepts are the rest of the concepts. 
        2. Detect parallel concepts in the anchor concepts.
        '''
        self.kg1_anchor_concepts = [c for c in self.kg1.graph.consolidated_graph.concepts if c.entity_type == 'BiblicalQuotation']
        self.kg1_free_concepts = [c for c in self.kg1.graph.consolidated_graph.concepts if c.entity_type != 'BiblicalQuotation']
        self.kg2_anchor_concepts = [c for c in self.kg2.graph.consolidated_graph.concepts if c.entity_type == 'BiblicalQuotation']
        self.kg2_free_concepts = [c for c in self.kg2.graph.consolidated_graph.concepts if c.entity_type != 'BiblicalQuotation']

        d1 = {x.id:x.id.split("bq")[-1][1:].lower() for x in self.kg1_anchor_concepts}
        d2 = {x.id:x.id.split("bq")[-1][1:].lower() for x in self.kg2_anchor_concepts}

        self.anchor_concept_matches = [(k1, k2) for k1, v1 in d1.items() for k2, v2 in d2.items() if v1 == v2]
        self.shared_anchor_ratio = len(self.anchor_concept_matches) / max(len(self.kg1_anchor_concepts), len(self.kg2_anchor_concepts)) if max(len(self.kg1_anchor_concepts), len(self.kg2_anchor_concepts)) >0 else 0

    def _free_concept_embeddings(self, restore_path: str = None, store_path: str = None):
        '''
        1. Create embeddings for the free concepts using the specified embedding model.
        2. If restore_path is provided, attempt to load embeddings from that path before computing them. 
           If the files are not found, compute the embeddings and optionally save them to store_path. 
        3. If store_path is provided, save the computed embeddings to that path for future use.
        4. If store_path isprovided and restore_path is not provided, It will override stored embeddings with newly computed ones.

        '''

        def _save_concept_embeddings(concepts, concept_embeddings, path: str):
            import pandas as pd

            df_concept_embeddings = pd.DataFrame({
                'text': concepts,
                'embedding': list(concept_embeddings)  # Convert numpy matrix to a list of arrays
            })
            df_concept_embeddings.to_parquet(path)

        def _load_concept_embeddings(path: str):
            import pandas as pd
            import numpy as np
            
            df = pd.read_parquet(path)
            return np.array(df['embedding'].tolist())

        def create_embeddings(client, concepts):
            
            concept_texts = [c.concept_text_with_context for c in concepts]
            concept_embeddings = get_embeddings(texts=concept_texts, client=client, model=self.embedding_model)
            return concept_embeddings, concept_texts
            
            

        from openai import OpenAI
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        
        concept_texts1 = None
        concept_texts2 = None

        if restore_path:
            if os.path.exists(os.path.join(restore_path, f"{self.name1}_free_concept_embeddings.parquet")):
                #self.kg1_concept_embeddings = _load_concept_embeddings(os.path.join(restore_path, f"kg1_{self.name1}_free_concept_embeddings.parquet"))
                self.kg1_concept_embeddings = _load_concept_embeddings(os.path.join(restore_path, f"{self.name1}_free_concept_embeddings.parquet"))
            else:
                if self.verbose:
                    print("Warning: Embedding file for KG1 not found in restore path. Computing embeddings from scratch.")
                store_path = restore_path
                self.kg1_concept_embeddings, concept_texts1 = create_embeddings(client, self.kg1_free_concepts)
            if os.path.exists(os.path.join(restore_path, f"{self.name2}_free_concept_embeddings.parquet")):
                #self.kg2_concept_embeddings = _load_concept_embeddings(os.path.join(restore_path, f"kg2_{self.name2}_free_concept_embeddings.parquet"))
                self.kg2_concept_embeddings = _load_concept_embeddings(os.path.join(restore_path, f"{self.name2}_free_concept_embeddings.parquet"))
            else:
                if self.verbose:
                    print("Warning: Embedding file for KG2 not found in restore path. Computing embeddings from scratch.")
                store_path = restore_path
                self.kg2_concept_embeddings, concept_texts2 = create_embeddings(client, self.kg2_free_concepts)
        else:    
            self.kg1_concept_embeddings, concept_texts1 = create_embeddings(client, self.kg1_free_concepts)
            self.kg2_concept_embeddings, concept_texts2 = create_embeddings(client, self.kg2_free_concepts)
        if store_path:
            if concept_texts1 is not None:
                #_save_concept_embeddings(concept_texts1, self.kg1_concept_embeddings, os.path.join(store_path, f"kg1_{self.name1}_free_concept_embeddings.parquet"))
                _save_concept_embeddings(concept_texts1, self.kg1_concept_embeddings, os.path.join(store_path, f"{self.name1}_free_concept_embeddings.parquet"))
            if concept_texts2 is not None:
                #_save_concept_embeddings(concept_texts2, self.kg2_concept_embeddings, os.path.join(store_path, f"kg2_{self.name2}_free_concept_embeddings.parquet"))
                _save_concept_embeddings(concept_texts2, self.kg2_concept_embeddings, os.path.join(store_path, f"{self.name2}_free_concept_embeddings.parquet"))    

    def print_graph_structure_summary(self):
        print(f"=== Structural Comparison: {self.name1} vs {self.name2} ===\n")
        # 1. Scale and Integration
        print(f"--- Scale & Integration ---")
        print(f"Nodes: {self.kg1nx.G.number_of_nodes()} vs {self.kg2nx.G.number_of_nodes()}")
        print(f"Edges: {self.kg1nx.G.number_of_edges()} vs {self.kg2nx.G.number_of_edges()}")
        print(f"Density: {self.kg1nx.density:.4f} vs {self.kg2nx.density:.4f}")

        integration_desc = "similar integration levels" if self.diff_density < 0.05 else "differently integrated"
        print(f"Insight: Graphs are {integration_desc}.\n")

        print(f"--- Connectivity & Topology ---")
        print(f"Connected Components: {self.comp1} vs {self.comp2}")
        print(f"{self.name1} Giant Component Size: {self.kg1nx.giant_component_graph.number_of_nodes() if self.kg1nx.giant_component_graph else 'N/A'}")
        print(f"{self.name2} Giant Component Size: {self.kg2nx.giant_component_graph.number_of_nodes() if self.kg2nx.giant_component_graph else 'N/A'}")
        if self.kg1nx.shortest_path and self.kg2nx.shortest_path:
            print(f"Avg Shortest Path (Giant Component): {self.kg1nx.shortest_path:.2f} vs {self.kg2nx.shortest_path:.2f}")

        print(f"\n--- Community Structure ---")
        print(f"Thematic Clusters: {self.community1} vs {self.community2}")

        print(f"\n--- Top 5 Narrative Anchors (By Betweenness) ---")
        print(f"{self.name1} Top Concepts: {list(self.top_a_centrality['Label'])}")
        print(f"{self.name2} Top Concepts: {list(self.top_b_centrality['Label'])}")
        print(f"Shared Key Anchors: {self.shared_anchors if self.shared_anchors else 'None'}")

    def compare_graph_structures(self, name1="Graph A", name2="Graph B"):
        """
        Compares two instances of KGNetworkStructureAnalysis to find 
        structural similarities and differences.
        """
        
        if self.name1 is None:
            self.name1 = name1
        if self.name2 is None:
            self.name2 = name2

        self.kg1nx = KGNetworkStructureAnalysis(self.kg1.graph.consolidated_graph, verbose=False)
        self.kg2nx = KGNetworkStructureAnalysis(self.kg2.graph.consolidated_graph, verbose=False)

        
        self.diff_density = abs(self.kg1nx.density - self.kg2nx.density)
        
        
        # 2. Connectivity & Topology
        
        self.comp1 = len(self.kg1nx.components) if self.kg1nx.components else 0
        self.comp2 = len(self.kg2nx.components) if self.kg2nx.components else 0
        
        
        # 3. Community Structure
        self.community1 = len(self.kg1nx.communities) if self.kg1nx.communities else 0
        self.community2 = len(self.kg2nx.communities) if self.kg2nx.communities else 0
        larges_comm_diff = abs(len(self.kg1nx.communities[0]) if self.kg1nx.communities else 0 - len(self.kg2nx.communities[0]) if self.kg2nx.communities else 0)        
       
  
        self.top_a_centrality = self.kg1nx.df_centrality.head(5)[['Label', 'Betweenness']]
        self.top_b_centrality = self.kg2nx.df_centrality.head(5)[['Label', 'Betweenness']]
        
        self.shared_anchors = set(self.top_a_centrality['Label']).intersection(set(self.top_b_centrality['Label']))
        
        
        if self.verbose:
            self.print_graph_structure_summary()
    
    def detect_nodes_similarities(self, embedding_path = None, n_embed=50, topk=5, min_cos=0.55, strict_type=True):
        if  self.kg1_free_concepts is None or self.kg2_free_concepts is None:
            print("No free concepts to compare.")
            return
        
        if embedding_path:
            self._free_concept_embeddings(restore_path=embedding_path)
        
        if self.kg1_concept_embeddings is None or self.kg2_concept_embeddings is None:
            print("Concept embeddings not available. Run _free_concept_embeddings() first.")
            return
        
        self.gs = GraphSimilarity(self.kg1_free_concepts, self.kg1_concept_embeddings, self.kg2_free_concepts, self.kg2_concept_embeddings,
                    n_embed=n_embed, topk=topk, min_cos=min_cos, strict_type=strict_type)

        self.free_similar_candidates = self.gs.candidates

    def filter_nodes_similarities_candidates(self):
        '''
        When checking a graph to itself for merge nodes candidates, the "detect_nodes_similarities" method
        will detect the identical node as similat to itself. This function will filter it out
        '''
        cleaned_free_similar_candidates = {}
        for x in self.free_similar_candidates:
            #print(self.free_similar_candidates[x])
            tmp = self.free_similar_candidates[x].copy()
            new_candidates = [x for x in tmp['candidates'] if tmp['a_id'] != x['b_id']]
            if len(new_candidates) > 0:
                tmp['candidates'] = new_candidates
                cleaned_free_similar_candidates[x] = tmp
        self.free_similar_candidates = cleaned_free_similar_candidates


    def _LLM_verify_concept_candidate(self, concept_a: Concept, candidates: List[Concept], context: str = None) -> Dict[str, Any]:
        """
        Use a language model to check if a concept is aligned with any of the candidate concepts.
        """

        source_json = concept_a.model_dump_json(indent=2)
        candidates_json = [c.model_dump_json(indent=2) for c in candidates]

        if context is None:
            class ConceptAlignmentSignature(dspy.Signature):
                """
                Evaluate if a source concept matches any of the provided candidates from a different graph.
                Analyze labels, entity types, and descriptions to determine if they refer to the same entity.
                """
                source_concept: Concept = dspy.InputField(desc="The concept from Graph A we are trying to align.")
                candidates: List[Concept] = dspy.InputField(desc="Top 5 potential matches from Graph B.")
                
                match_id = dspy.OutputField(desc="The ID of the matching concept from candidates, or 'None' if no match exists.")
                confidence_level = dspy.OutputField(desc="Scale: Certain, Highly Likely, Possible, Unlikely, No Match.")
                explanation = dspy.OutputField(desc="Brief reasoning for the decision, citing specific label or description overlaps.")



            extract = dspy.ChainOfThought(ConceptAlignmentSignature)
            res = extract(source_concept=source_json, candidates=candidates_json)
            result = {"match_id": res.match_id, "confidence_level": res.confidence_level, "explanation": res.explanation}
        else:
            class ConceptAlignmentWithContextSignature(dspy.Signature):
                """
                Evaluate if a source concept matches any of the provided candidates from a different graph.
                1. Analyze labels, entity types, and descriptions to determine if they refer to the same entity.
                2. Read carefully the Hebrew rabbinic context text for additional context to reinforce the alignment decision.
                """
                source_concept: Concept = dspy.InputField(desc="The concept from Graph A we are trying to align.")
                candidates: List[Concept] = dspy.InputField(desc="Top 5 potential matches from Graph B.")
                context_text: str = dspy.InputField(desc="Source Hebrew rabbinic text from which the concept is extracted, providing additional context for alignment.")
                
                match_id = dspy.OutputField(desc="The ID of the matching concept from candidates, or 'None' if no match exists.")
                confidence_level = dspy.OutputField(desc="Scale: Certain, Highly Likely, Possible, Unlikely, No Match.")
                explanation = dspy.OutputField(desc="Brief reasoning for the decision, citing specific label or description overlaps.")



            extract = dspy.ChainOfThought(ConceptAlignmentWithContextSignature)
            res = extract(source_concept=source_json, candidates=candidates_json, context_text=context)
            result = {"match_id": res.match_id, "confidence_level": res.confidence_level, "explanation": res.explanation}
        

        
        
        return result

    def LLM_verify_all_concepts(self, LLM_restore_path = None, context: str = None):
        import json

        if self.free_similar_candidates is None:
            if self.verbose:
                print("No candidates to check. Run detect_nodes_similarities() first.")
            return
        
        if LLM_restore_path:
            if os.path.exists(os.path.join(LLM_restore_path, f"LLM_checked_nodes_alignment_{self.name1}_to_{self.name2}.json")):
                with open(os.path.join(LLM_restore_path, f"LLM_checked_nodes_alignment_{self.name1}_to_{self.name2}.json"), "r") as f:
                    self.LLM_checked_candidates = json.load(f)
                if self.verbose:
                    print("LLM-checked candidates loaded from restore path.")
                return
            
        if self.lm is None:
            self.init_model(model = "openai/gpt-4o", api_key=os.getenv("OPENAI_API_KEY"), temperature=0.0, max_tokens=15000)  
        
        self.LLM_checked_candidates = {}
        kg2_map = {c.id: c for c in self.kg2_free_concepts}
        kg1_map = {c.id: c for c in self.kg1_free_concepts}
        for a_id, res in self.free_similar_candidates.items():
            concept_a = kg1_map.get(a_id)
            if concept_a is None:
                continue
            candidate_concepts = [kg2_map[cand["b_id"]] for cand in res["candidates"] 
                              if cand["b_id"] in kg2_map]
            if len(candidate_concepts) == 0:
                continue
            
            llm_result = self._LLM_verify_concept_candidate(concept_a, candidate_concepts[:5], context=context)  # Check top 5 candidates
            self.LLM_checked_candidates[a_id] = llm_result
        if LLM_restore_path:
            
            with open(os.path.join(LLM_restore_path, f"LLM_checked_nodes_alignment_{self.name1}_to_{self.name2}.json"), "w") as f:
                json.dump(self.LLM_checked_candidates, f, indent=2, ensure_ascii=False)


    def visualize_overlap_OLD(self, output_path):
        """
        Renders a unified visualization of two Knowledge Graphs.
        Nodes: Square = BiblicalQuotation, Circle = Other.
        Colors: Green = Shared, Red = KG1 Unique, Blue = KG2 Unique.
        Edges: Green = Shared direction, Red = KG1 Unique, Blue = KG2 Unique.
        """
        from pyvis.network import Network
        from collections import defaultdict

        # 1. Build the Match Map (KG2_ID -> KG1_ID)
        match_map = {}
        for k1, k2 in self.anchor_concept_matches:
            match_map[k2] = k1
        if self.LLM_checked_candidates:
            for a_id, decision in self.LLM_checked_candidates.items():
                if decision['confidence_level'] in ["Certain", "Highly Likely"]:
                    match_map[decision['match_id']] = a_id

        # 2. Setup Pyvis and data maps
        net = Network(height="800px", width="100%", directed=True, cdn_resources="remote")
        kg1_concepts = {c.id: c for c in self.kg1.graph.consolidated_graph.concepts}
        kg2_concepts = {c.id: c for c in self.kg2.graph.consolidated_graph.concepts}
        
        # 3. Process Nodes (Green/Red/Blue + Square/Circle)
        added_node_ids = set()
        
        # Process KG1 Nodes (Shared or unique to KG1)
        for cid_a, concept_a in kg1_concepts.items():
            k2_id = next((k for k, v in match_map.items() if v == cid_a), None)
            
            # Determine Color
            is_shared = k2_id is not None and k2_id in kg2_concepts
            color = "#90EE90" if is_shared else "#FF7F7F" # Green or Red
            
            # Determine Shape (BiblicalQuotation as square/box)
            shape = "box" if concept_a.entity_type == "BiblicalQuotation" else "dot"
            
            # Enriched Tooltip
            if is_shared:
                concept_b = kg2_concepts[k2_id]
                llm_info = self.LLM_checked_candidates.get(cid_a, {})
                title = (f"SHARED CONCEPT\n【{self.name1}】: {concept_a.prefLabel}\n"
                        f"【{self.name2}】: {concept_b.prefLabel}\n"
                        f"Reason: {llm_info.get('explanation', 'Anchor match')}")
            else:
                title = f"UNIQUE TO {self.name1}\nLabel: {concept_a.prefLabel}\nType: {concept_a.entity_type}"

            net.add_node(cid_a, label=concept_a.prefLabel[:15], title=title, 
                        color=color, shape=shape, size=20)
            added_node_ids.add(cid_a)

        # Process KG2 Unique Nodes
        for cid_b, concept_b in kg2_concepts.items():
            if cid_b not in match_map:
                shape = "box" if concept_b.entity_type == "BiblicalQuotation" else "dot"
                title = f"UNIQUE TO {self.name2}\nLabel: {concept_b.prefLabel}\nType: {concept_b.entity_type}"
                net.add_node(cid_b, label=concept_b.prefLabel[:15], title=title, 
                            color="#87CEFA", shape=shape, size=20) # Blue
                added_node_ids.add(cid_b)

        # 4. Process Edges (Green/Red/Blue)
        edges_kg1 = {(rel.subject_id, rel.object_id): rel.predicate 
                    for rel in self.kg1.graph.consolidated_graph.relation_objects}
        
        edges_kg2_mapped = {}
        for rel in self.kg2.graph.consolidated_graph.relation_objects:
            src = match_map.get(rel.subject_id, rel.subject_id)
            tgt = match_map.get(rel.object_id, rel.object_id)
            edges_kg2_mapped[(src, tgt)] = rel.predicate

        # Union of all directed edge pairs
        all_edge_keys = set(edges_kg1.keys()) | set(edges_kg2_mapped.keys())

        for (src, tgt) in all_edge_keys:
            if src not in added_node_ids or tgt not in added_node_ids:
                continue
                
            in_kg1 = (src, tgt) in edges_kg1
            in_kg2 = (src, tgt) in edges_kg2_mapped

            if in_kg1 and in_kg2:
                # Shared Relation (Green)
                color = "#228B22" 
                label = edges_kg1[(src, tgt)]
                title = f"Shared Relation: {label}"
            elif in_kg1:
                # Unique to KG1 (Red)
                color = "#FF7F7F"
                label = edges_kg1[(src, tgt)]
                title = f"Unique to {self.name1}: {label}"
            else:
                # Unique to KG2 (Blue)
                color = "#87CEFA"
                label = edges_kg2_mapped[(src, tgt)]
                title = f"Unique to {self.name2}: {label}"

            net.add_edge(src, tgt, label=label, title=title, color=color)

        # 5. Physics Options
        net.set_options('{"physics": {"enabled": true, "barnesHut": {"gravitationalConstant": -30000}}}')
        net.write_html(f"{output_path}Overlap_{self.name1}_{self.name2}_graph.html")


    def visualize_overlap(self, output_path):
        """
        Renders a unified visualization of two Knowledge Graphs.
        Nodes: Square = BiblicalQuotation, Circle = Other.
        Colors: Green = Shared, Red = KG1 Unique, Blue = KG2 Unique.
        Edges: Green = Shared direction, Red = KG1 Unique, Blue = KG2 Unique.
        
        Saves both HTML visualization and JSON data export.
        """
        from pyvis.network import Network
        from collections import defaultdict
        from datetime import datetime
        import json

        # 1. Build the Match Map (KG2_ID -> KG1_ID)
        match_map = {}
        for k1, k2 in self.anchor_concept_matches:
            match_map[k2] = k1
        if self.LLM_checked_candidates:
            for a_id, decision in self.LLM_checked_candidates.items():
                if decision['confidence_level'] in ["Certain", "Highly Likely"]:
                    match_map[decision['match_id']] = a_id

        # 2. Setup Pyvis and data maps
        net = Network(height="800px", width="100%", directed=True, cdn_resources="remote")
        kg1_concepts = {c.id: c for c in self.kg1.graph.consolidated_graph.concepts}
        kg2_concepts = {c.id: c for c in self.kg2.graph.consolidated_graph.concepts}
        
        # Initialize JSON data structures
        nodes_json = []
        edges_json = []
        metadata = {
            "graph1_name": self.name1,
            "graph2_name": self.name2,
            "creation_date": datetime.now().isoformat()
        }
        
        # 3. Process Nodes (Green/Red/Blue + Square/Circle)
        added_node_ids = set()
        
        # Process KG1 Nodes (Shared or unique to KG1)
        for cid_a, concept_a in kg1_concepts.items():
            k2_id = next((k for k, v in match_map.items() if v == cid_a), None)
            
            # Determine Color
            is_shared = k2_id is not None and k2_id in kg2_concepts
            color = "#90EE90" if is_shared else "#FF7F7F" # Green or Red
            
            # Determine Shape (BiblicalQuotation as square/box)
            shape = "box" if concept_a.entity_type == "BiblicalQuotation" else "dot"
            
            # Enriched Tooltip
            if is_shared:
                concept_b = kg2_concepts[k2_id]
                llm_info = self.LLM_checked_candidates.get(cid_a, {})
                title = (f"SHARED CONCEPT\n【{self.name1}】: {concept_a.prefLabel}\n"
                        f"【{self.name2}】: {concept_b.prefLabel}\n"
                        f"Reason: {llm_info.get('explanation', 'Anchor match')}")
            else:
                title = f"UNIQUE TO {self.name1}\nLabel: {concept_a.prefLabel}\nType: {concept_a.entity_type}"

            net.add_node(cid_a, label=concept_a.prefLabel[:15], title=title, 
                        color=color, shape=shape, size=20)
            added_node_ids.add(cid_a)
            
            # Add to JSON data
            nodes_json.append({
                "id": cid_a,
                "label": concept_a.prefLabel[:15],
                "full_label": concept_a.prefLabel,
                "entity_type": concept_a.entity_type,
                "status": "shared" if is_shared else "kg1_unique",
                "color": color,
                "shape": shape,
                "title": title,
                "matched_with": k2_id if is_shared else None
            })

        # Process KG2 Unique Nodes
        for cid_b, concept_b in kg2_concepts.items():
            if cid_b not in match_map:
                shape = "box" if concept_b.entity_type == "BiblicalQuotation" else "dot"
                title = f"UNIQUE TO {self.name2}\nLabel: {concept_b.prefLabel}\nType: {concept_b.entity_type}"
                net.add_node(cid_b, label=concept_b.prefLabel[:15], title=title, 
                            color="#87CEFA", shape=shape, size=20) # Blue
                added_node_ids.add(cid_b)
                
                # Add to JSON data
                nodes_json.append({
                    "id": cid_b,
                    "label": concept_b.prefLabel[:15],
                    "full_label": concept_b.prefLabel,
                    "entity_type": concept_b.entity_type,
                    "status": "kg2_unique",
                    "color": "#87CEFA",
                    "shape": shape,
                    "title": title,
                    "matched_with": None
                })

        # 4. Process Edges (Green/Red/Blue)
        edges_kg1 = {(rel.subject_id, rel.object_id): rel.predicate 
                    for rel in self.kg1.graph.consolidated_graph.relation_objects}
        
        edges_kg2_mapped = {}
        for rel in self.kg2.graph.consolidated_graph.relation_objects:
            src = match_map.get(rel.subject_id, rel.subject_id)
            tgt = match_map.get(rel.object_id, rel.object_id)
            edges_kg2_mapped[(src, tgt)] = rel.predicate

        # Union of all directed edge pairs
        all_edge_keys = set(edges_kg1.keys()) | set(edges_kg2_mapped.keys())

        for (src, tgt) in all_edge_keys:
            if src not in added_node_ids or tgt not in added_node_ids:
                continue
                
            in_kg1 = (src, tgt) in edges_kg1
            in_kg2 = (src, tgt) in edges_kg2_mapped

            if in_kg1 and in_kg2:
                # Shared Relation (Green)
                color = "#228B22" 
                label = edges_kg1[(src, tgt)]
                title = f"Shared Relation: {label}"
                status = "shared"
            elif in_kg1:
                # Unique to KG1 (Red)
                color = "#FF7F7F"
                label = edges_kg1[(src, tgt)]
                title = f"Unique to {self.name1}: {label}"
                status = "kg1_unique"
            else:
                # Unique to KG2 (Blue)
                color = "#87CEFA"
                label = edges_kg2_mapped[(src, tgt)]
                title = f"Unique to {self.name2}: {label}"
                status = "kg2_unique"

            net.add_edge(src, tgt, label=label, title=title, color=color)
            
            # Add to JSON data
            edges_json.append({
                "source": src,
                "target": tgt,
                "predicate": label,
                "status": status,
                "color": color,
                "title": title
            })

        # 5. Physics Options and save HTML
        net.set_options('{"physics": {"enabled": true, "barnesHut": {"gravitationalConstant": -30000}}}')
        net.write_html(f"{output_path}Overlap_{self.name1}_{self.name2}_graph.html")
        
        # 6. Calculate metadata statistics and save JSON
        metadata["total_nodes"] = len(nodes_json)
        metadata["total_edges"] = len(edges_json)
        metadata["shared_nodes"] = sum(1 for n in nodes_json if n["status"] == "shared")
        metadata["kg1_unique_nodes"] = sum(1 for n in nodes_json if n["status"] == "kg1_unique")
        metadata["kg2_unique_nodes"] = sum(1 for n in nodes_json if n["status"] == "kg2_unique")
        metadata["shared_edges"] = sum(1 for e in edges_json if e["status"] == "shared")
        metadata["kg1_unique_edges"] = sum(1 for e in edges_json if e["status"] == "kg1_unique")
        metadata["kg2_unique_edges"] = sum(1 for e in edges_json if e["status"] == "kg2_unique")
        
        self.graphs_overlap = {
            "metadata": metadata,
            "nodes": nodes_json,
            "edges": edges_json
        }
        
        json_file_name = f"{output_path}Overlap_{self.name1}_{self.name2}_graph.json"
        with open(json_file_name, 'w', encoding='utf-8') as f:
            json.dump(self.graphs_overlap, f, indent=2, ensure_ascii=False)

    def analyze_merged_graph_overlap(self):
        """
        Analyzes structural overlap and 'Modularity of Sources' to evaluate 
        how well Graph 1 and Graph 2 are integrated.
        - Anchor Centrality Ratio: Calculate what percentage of the top 10% most central nodes (by Degree or Betweenness) are Shared (Green) nodes.
             If this is high, the two authors agree on the "core" of the discourse.

            - Bridge Strength (Inter-Graph Density): Measure the density of edges that connect a KG1-unique (Red) 
              node directly to a KG2-unique (Blue) node through a Shared (Green) node.

            - Modularity of Sources: If a community detection algorithm (like Louvain) keeps all Red nodes in one cluster 
              and all Blue nodes in another, the graphs are topologically distinct despite shared nodes. If clusters are "multi-colored," the knowledge is well-integrated.

            - Path Connectivity: The average shortest path length between a random Red node and a random Blue node. 
              Shorter paths indicate a high degree of conceptual "translation" between the two sources.
        """
        import networkx as nx
        import pandas as pd
        from networkx.algorithms import community

        # 1. Construct the Merged Graph
        M = nx.Graph()
        match_map = {}
        for k1, k2 in self.anchor_concept_matches:
            match_map[k2] = k1
        if self.LLM_checked_candidates:
            for a_id, decision in self.LLM_checked_candidates.items():
                if decision['confidence_level'] in ["Certain", "Highly Likely"]:
                    match_map[decision['match_id']] = a_id

        shared_nodes = set(match_map.values())
        
        # Populate nodes with status
        for c in self.kg1.graph.consolidated_graph.concepts:
            status = "shared" if c.id in shared_nodes else "kg1_unique"
            M.add_node(c.id, status=status, label=c.prefLabel)
            
        for c in self.kg2.graph.consolidated_graph.concepts:
            if c.id not in match_map:
                M.add_node(c.id, status="kg2_unique", label=c.prefLabel)

        # Populate edges (Mapped)
        for rel in self.kg1.graph.consolidated_graph.relation_objects:
            M.add_edge(rel.subject_id, rel.object_id)
        for rel in self.kg2.graph.consolidated_graph.relation_objects:
            src = match_map.get(rel.subject_id, rel.subject_id)
            tgt = match_map.get(rel.object_id, rel.object_id)
            M.add_edge(src, tgt)

        # 2. Modularity of Sources (Community Check)
        # Using Louvain to detect communities in the merged structure
        communities = community.louvain_communities(M)
        
        community_stats = []
        integrated_clusters = 0
        
        for i, comm in enumerate(communities):
            # Count the "colors" in this community
            nodes_data = [M.nodes[n]['status'] for n in comm]
            red_count = nodes_data.count("kg1_unique")
            blue_count = nodes_data.count("kg2_unique")
            shared_count = nodes_data.count("shared")
            total = len(comm)
            
            # Calculate integration: A cluster is 'integrated' if it's not dominated (>80%) by one unique source
            is_integrated = False
            if total > 2: # Ignore tiny clusters
                if (red_count / total < 0.8) and (blue_count / total < 0.8):
                    is_integrated = True
                    integrated_clusters += 1
            
            community_stats.append({
                "community_id": i,
                "size": total,
                "kg1_pct": round(red_count / total, 2),
                "kg2_pct": round(blue_count / total, 2),
                "shared_pct": round(shared_count / total, 2),
                "is_integrated": is_integrated
            })

        # 3. Centrality Measurements
        between_cent = nx.betweenness_centrality(M)
        df_centrality = pd.DataFrame([
            {"id": n, "status": M.nodes[n]['status'], "betweenness": bc} 
            for n, bc in between_cent.items()
        ])

        # 4. Summary Output
        print(f"=== Merged Graph Analysis: {self.name1} & {self.name2} ===")
        print(f"Total Merged Nodes: {len(M)}")
        print(f"Integration Score: {integrated_clusters}/{len(communities)} clusters are multi-source.")
        
        # Calculate top shared node influence
        top_10_count = max(1, int(len(M) * 0.1))
        top_nodes = df_centrality.sort_values("betweenness", ascending=False).head(top_10_count)
        shared_influence = (top_nodes['status'] == 'shared').sum() / top_10_count
        print(f"Shared Node Influence: {shared_influence*100:.1f}% of top central nodes are shared.")

        return pd.DataFrame(community_stats)

    def comparative_report(self, output_path: str = None, target_lang: str = "Hebrew"):
        '''
        Generates a comparative report of the two graphs based on the JSON data from the visualization step.
        
        Args:
            output_path: Directory path where the report file will be saved. 
                        If None, report is only returned without saving.
            target_lang: Language for the report output (default: "Hebrew")
        
        Returns:
            The generated report as a string
        '''

        class DivergenceAnalysisSignature(dspy.Signature):
            """
            Perform a professional comparative analysis between two rabbinic commentaries 
            based on a merged Knowledge Graph. 
            The report must detail:
            1. Shared Foundation: Concepts agreed upon by both authors.
            2. Extensions: How the commentator (Graph 1) expands on the Ramban (Graph 2).
            3. Divergence: Unique theological or structural relations introduced.
            4. Textual Anchors: Differences in biblical citations used to support claims.
            """
            metadata = dspy.InputField(desc="Statistical overlap metrics (shared vs unique counts)")
            shared_elements = dspy.InputField(desc="List of concepts and relations found in both graphs")
            unique_elements = dspy.InputField(desc="Concepts and relations unique to the commentary (Graph 1)")
            language = dspy.InputField(desc="The output language for the report (e.g., Hebrew or English)")
            
            report = dspy.OutputField(desc="A comprehensive, academic comparative report")


        if self.graphs_overlap is None:
            print("No overlap data available. Run visualize_overlap() first.")
            return

        if self.lm is None:
            self.init_model(model = "openai/gpt-4o", api_key=os.getenv("OPENAI_API_KEY"), temperature=0.2, max_tokens=15000)  
       

        # Extract Metadata
        meta = self.graphs_overlap.get("metadata", {})
        
        # Extract Shared Foundation
        shared_nodes = [n['full_label'] for n in self.graphs_overlap["nodes"] if n["status"] == "shared"]
        shared_edges = [e for e in self.graphs_overlap["edges"] if e["status"] == "shared"]
        
        # Extract Unique Extensions from Graph 1 (Ibn Shuib)
        unique_nodes = [n for n in self.graphs_overlap["nodes"] if n["status"] == "kg1_unique"]
        unique_edges = [e for e in self.graphs_overlap["edges"] if e["status"] == "kg1_unique"]
        
        # Format strings for the prompt
        shared_str = f"Nodes: {shared_nodes}\nRelations: {[(e['source'], e['predicate'], e['target']) for e in shared_edges]}"
        
        unique_str = f"Unique Nodes: {[n['full_label'] for n in unique_nodes]}\n"
        unique_str += f"Unique Relations: {[(e['source'], e['predicate'], e['target']) for e in unique_edges]}"
        
        # Call the LLM
        generate_report = dspy.ChainOfThought(DivergenceAnalysisSignature)
        prediction = generate_report(
            metadata=str(meta),
            shared_elements=shared_str,
            unique_elements=unique_str,
            language=target_lang
        )
        
        report_text = prediction.report
        
        # Save report to file if output_path is provided
        if output_path:
            report_file_name = f"{output_path}Overlap_{self.name1}_{self.name2}_report.txt"
            with open(report_file_name, 'w', encoding='utf-8') as f:
                # Add header with metadata
                f.write(f"=" * 80 + "\n")
                f.write(f"COMPARATIVE ANALYSIS REPORT\n")
                f.write(f"Graph 1: {self.name1}\n")
                f.write(f"Graph 2: {self.name2}\n")
                f.write(f"Generated: {meta.get('creation_date', 'N/A')}\n")
                f.write(f"=" * 80 + "\n\n")
                
                # Add summary statistics
                f.write("SUMMARY STATISTICS\n")
                f.write("-" * 80 + "\n")
                f.write(f"Total Nodes: {meta.get('total_nodes', 0)}\n")
                f.write(f"  - Shared: {meta.get('shared_nodes', 0)}\n")
                f.write(f"  - Unique to {self.name1}: {meta.get('kg1_unique_nodes', 0)}\n")
                f.write(f"  - Unique to {self.name2}: {meta.get('kg2_unique_nodes', 0)}\n\n")
                f.write(f"Total Edges: {meta.get('total_edges', 0)}\n")
                f.write(f"  - Shared: {meta.get('shared_edges', 0)}\n")
                f.write(f"  - Unique to {self.name1}: {meta.get('kg1_unique_edges', 0)}\n")
                f.write(f"  - Unique to {self.name2}: {meta.get('kg2_unique_edges', 0)}\n")
                f.write("-" * 80 + "\n\n")
                
                # Add the LLM-generated analysis
                f.write("DETAILED ANALYSIS\n")
                f.write("=" * 80 + "\n\n")
                f.write(report_text)
                f.write("\n\n" + "=" * 80 + "\n")
            
            if self.verbose:
                print(f"Report saved to: {report_file_name}")
        
        return report_text

        
    def calculate_alignment_score(self, 
                              w_anchor=0.20, 
                              w_semantic=0.30, 
                              w_relational=0.30, 
                              w_structural=0.20, lverbose=False):
        """
        Synthesizes structural and semantic metrics into a single Alignment Score.
        
        Args:
            w_anchor (float): Weight for Biblical Quotation overlap.
            w_semantic (float): Weight for LLM-verified concept similarity.
            w_relational (float): Weight for shared directed edges.
            w_structural (float): Weight for community-level source integration.
        """
        import networkx as nx
        
        # 1. Anchor Overlap (Biblical Quotations)
        # Uses the ratio calculated during the initial split
        s1 = self.shared_anchor_ratio

        # 2. Semantic Overlap (LLM Verified Free Concepts)
        # Ratio of verified matches to the total free concepts in KG1
        llm_matches = 0
        if self.LLM_checked_candidates:
            llm_matches = sum(1 for d in self.LLM_checked_candidates.values() 
                            if d['confidence_level'] in ["Certain", "Highly Likely"])
        s2 = llm_matches / len(self.kg1_free_concepts) if self.kg1_free_concepts else 0

        # 3. Relational Parity (Edge Agreement)
        # Maps KG2 edges to KG1 space and finds the intersection
        edges1 = {(rel.subject_id, rel.object_id) for rel in self.kg1.graph.consolidated_graph.relation_objects}
        
        match_map = {k2: k1 for k1, k2 in self.anchor_concept_matches}
        if self.LLM_checked_candidates:
            for a_id, d in self.LLM_checked_candidates.items():
                if d['confidence_level'] in ["Certain", "Highly Likely"]:
                    match_map[d['match_id']] = a_id
                    
        edges2_mapped = set()
        for rel in self.kg2.graph.consolidated_graph.relation_objects:
            src = match_map.get(rel.subject_id, rel.subject_id)
            tgt = match_map.get(rel.object_id, rel.object_id)
            edges2_mapped.add((src, tgt))
            
        shared_edges = edges1.intersection(edges2_mapped)
        s3 = len(shared_edges) / len(edges1) if edges1 else 0

        # 4. Structural Integration (Modularity Mix)
        # This requires running the modularity analysis first
        # Percentage of clusters that are 'Integrated' (not source-dominated)
        if not hasattr(self, 'integrated_cluster_ratio'):
            # Fallback to a basic component-based integration if modularity isn't run
            s4 = 0.5 
        else:
            s4 = self.integrated_cluster_ratio

        # Weighted Calculation
        # Normalizing weights to ensure they sum to 1.0 if the user changes them
        total_w = w_anchor + w_semantic + w_relational + w_structural
        final_score = (
            (s1 * w_anchor) + 
            (s2 * w_semantic) + 
            (s3 * w_relational) + 
            (s4 * w_structural)
        ) / total_w

        if self.verbose or lverbose:
            print(f"\n--- Alignment Profile: {self.name1} vs {self.name2} ---")
            print(f"Anchor Alignment:      {s1:.2f} (Weight: {w_anchor})")
            print(f"Semantic Alignment:    {s2:.2f} (Weight: {w_semantic})")
            print(f"Relational Alignment:  {s3:.2f} (Weight: {w_relational})")
            print(f"Structural Integration: {s4:.2f} (Weight: {w_structural})")
            print(f"FINAL ALIGNMENT SCORE: {final_score:.4f}")
            interpertation = """
        Interpreting the Rank
        ---------------------
            0.85 - 1.00 (Harmonious): The texts are conceptually identical. 
                                    They use the same anchors and draw the same logical conclusions.

            0.60 - 0.84 (Convergent): The texts agree on the main "pillars" (anchors) 
                                    but have unique secondary interpretations or 
                                    different levels of detail.

            0.20 - 0.59 (Divergent): The texts share the same subject matter (anchors) 
                                    but build very different knowledge structures around them.

            < 0.20 (Unrelated): Even if they mention the same biblical verses, 
                                the conceptual world they build is entirely distinct.
                    """
            print(f"\nInterpretation Guide:\n{interpertation}")
        return final_score

    def load_and_compare(self, path1: str, path2: str, name1="Graph A", name2="Graph B", embedding_store_path=None, embedding_restore_path=None,
                         n_embed=10, topk=5, min_cos=0.80, strict_type=True):
        self.load_graphs(path1, path2, name1, name2)
        self._split_free_anchor_concepts()
        self.compare_graph_structures(name1, name2)
        if embedding_restore_path:
            self._free_concept_embeddings(restore_path=embedding_restore_path)
        else:
            self._free_concept_embeddings(store_path=embedding_store_path)
        self.detect_nodes_similarities(embedding_path=embedding_restore_path, n_embed=n_embed, topk=topk, min_cos=min_cos, strict_type=strict_type)
        self.LLM_verify_all_concepts(LLM_restore_path=embedding_restore_path)
        self.visualize_overlap(embedding_restore_path)
        self.comparative_report(target_lang="Hebrew", output_path=embedding_restore_path)
        
    
    

#----------------------------------------------------------------------------------------------------------
# Grapg Serialization ( Graph to ACT ) 
#----------------------------------------------------------------------------------------------------------

