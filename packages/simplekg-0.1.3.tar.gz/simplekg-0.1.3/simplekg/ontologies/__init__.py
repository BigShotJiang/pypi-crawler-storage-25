from .base import OntologyEntityType, OntologyPredicate, Ontology
