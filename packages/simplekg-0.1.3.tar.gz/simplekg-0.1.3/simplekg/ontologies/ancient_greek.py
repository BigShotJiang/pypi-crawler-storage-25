"""
Ancient Greek Ontology for NKGGenerator.

Defines the fixed vocabulary of entity types and predicates for KGs extracted
from ancient Greek texts (classical historians, Church Fathers, patristic literature).

Entity types mirror the 11 types enforced in AncientGreekSignatureRegistry so that
the ontology is the single source of truth for both extraction guidance and normalization.

Predicate aliases serve as explicit mapping hints for the LLM — raw predicates listed
in aliases are concrete examples that belong to this semantic category and should
map here during normalization.
"""

from .base import Ontology, OntologyEntityType, OntologyPredicate


class AncientGreekOntology(Ontology):

    def __init__(self):
        super().__init__(
            id="ancient-greek-v1",
            description=(
                "Ontology for knowledge graphs extracted from ancient Greek historical, "
                "patristic, and classical literary texts."
            ),
            generic_entity_type="Entity",
            generic_predicate="relatedTo",
            entity_types=_ENTITY_TYPES,
            predicates=_PREDICATES,
        )


# ---------------------------------------------------------------------------
# Entity types — must stay in sync with the 11 types in
# AncientGreekSignatureRegistry (HarvestAncientGreekTerms and
# AncientGreekCandidatesToConcepts)
# ---------------------------------------------------------------------------

_ENTITY_TYPES = [
    OntologyEntityType(
        id="Person",
        description="Individual historical figures, authors, Church Fathers, philosophers, rulers, generals, bishops.",
        examples=["Eusebius", "Josephus", "Constantine", "Athanasius"],
        aliases=["Individual", "Historical figure", "Author", "Bishop", "Emperor"],
    ),
    OntologyEntityType(
        id="Place",
        description="Cities, regions, provinces, countries, geographical or topographical locations, sanctuaries.",
        examples=["Constantinople", "Alexandria", "Jerusalem", "Asia Minor"],
        aliases=["Location", "City", "Region", "Country", "Geography"],
    ),
    OntologyEntityType(
        id="Polity",
        description="Political entities — empires, kingdoms, city-states, leagues, republics, administrative units. Distinct from Person.",
        examples=["Roman Empire", "Babylon", "Athens", "Hasmonean Kingdom"],
        aliases=["Empire", "Kingdom", "State", "Republic", "Political entity"],
    ),
    OntologyEntityType(
        id="Role",
        description="Offices, titles, or functions associated with persons — the title itself, not the person who holds it.",
        examples=["Bishop", "Emperor", "Strategos", "High Priest", "Archon"],
        aliases=["Title", "Office", "Position", "Function", "Rank"],
    ),
    OntologyEntityType(
        id="Event",
        description="Discrete historical occurrences — battles, councils, persecutions, migrations, sieges, synods.",
        examples=["Council of Nicaea", "Persian Wars", "Return from Babylon", "Siege of Jerusalem"],
        aliases=["Occurrence", "Battle", "Council", "Persecution", "Synod"],
    ),
    OntologyEntityType(
        id="TimePeriod",
        description="Named temporal spans — reigns, dynasties, eras, epochs. Not a specific event but a duration.",
        examples=["Reign of Constantine", "Hellenistic Period", "425 Years", "Second Temple Era"],
        aliases=["Era", "Epoch", "Dynasty", "Reign", "Period"],
    ),
    OntologyEntityType(
        id="Work",
        description="Literary or textual artifacts — histories, epistles, chronicles, treatises, commentaries.",
        examples=["Ecclesiastical History", "Jewish Antiquities", "Chronographia", "Against Apion"],
        aliases=["Book", "Treatise", "Chronicle", "Epistle", "Commentary", "Text"],
    ),
    OntologyEntityType(
        id="Abstraction",
        description="Non-concrete concepts — theological terms, philosophical ideas, doctrines, virtues. Not physical objects.",
        examples=["homoousios", "logos", "oikonomia", "paideia", "messianism"],
        aliases=["Doctrine", "Concept", "Idea", "Theology", "Philosophy", "Term"],
    ),
    OntologyEntityType(
        id="Ethnonym",
        description="Collective group identifiers — peoples, nations, tribes, ethnic or cultural communities.",
        examples=["Romans", "Persians", "Hebrews", "Galatians", "Jews"],
        aliases=["People", "Nation", "Tribe", "Community", "Ethnic group"],
    ),
    OntologyEntityType(
        id="Practice",
        description="Recurring activities or customs — rituals, liturgical forms, philosophical methods, political procedures.",
        examples=["Baptism", "Eucharist", "Dialectic", "Census", "Passover"],
        aliases=["Ritual", "Custom", "Procedure", "Method", "Ceremony"],
    ),
    OntologyEntityType(
        id="Artifact",
        description="Concrete physical objects of cultural, religious, or political significance. Not ideas or activities.",
        examples=["Royal Diadem", "Altar", "Ark", "Scepter", "Temple vessel", "Column"],
        aliases=["Object", "Relic", "Insignia", "Symbol", "Monument"],
    ),
]


# ---------------------------------------------------------------------------
# Predicates with domain/range constraints.
# aliases = explicit raw predicates that belong to this semantic category
# and should map here during LLM normalization.
# ---------------------------------------------------------------------------

_PREDICATES = [

    # --- Authorship & textual ---
    OntologyPredicate(
        id="wroteWork",
        label="wrote work",
        description="A person or group authored a literary or textual work.",
        domain=["Person", "Ethnonym"],
        range=["Work"],
        examples=["Eusebius wroteWork Ecclesiastical History"],
        aliases=["authored", "composed", "wrote", "produced", "penned", "created"],
    ),
    OntologyPredicate(
        id="citedWork",
        label="cited work",
        description="A person or work referenced or quoted another work as a source.",
        domain=["Person", "Work"],
        range=["Work"],
        examples=["Eusebius citedWork Jewish Antiquities"],
        aliases=["cited", "referenced", "quoted", "used as source", "drew from", "relied on", "consulted"],
    ),
    OntologyPredicate(
        id="commentedOn",
        label="commented on",
        description="A person or work wrote an interpretation or commentary on another work.",
        domain=["Person", "Work"],
        range=["Work"],
        examples=["Origen commentedOn Gospel of John"],
        aliases=["interpreted", "annotated", "glossed", "wrote commentary on", "expounded"],
    ),
    OntologyPredicate(
        id="influencedBy",
        label="influenced by",
        description="A person or work was intellectually shaped by another person or work.",
        domain=["Person", "Work"],
        range=["Person", "Work"],
        examples=["Eusebius influencedBy Origen"],
        aliases=["inspired by", "derived from", "shaped by", "indebted to", "based on"],
    ),

    # --- Citation / attribution (NEW) ---
    OntologyPredicate(
        id="referencedBy",
        label="referenced by",
        description=(
            "A person, event, or work is cited, quoted, attributed, or mentioned as a source "
            "by another person or work. Passive voice: the subject IS referenced BY the object."
        ),
        domain=["Person", "Work", "Event"],
        range=["Person", "Work"],
        examples=["Jonathan referencedBy Josephus", "Council of Nicaea referencedBy Eusebius"],
        aliases=[
            "accordingTo", "citedBy", "mentionedBy", "attributedTo", "reportedBy",
            "attestedBy", "asStatedBy", "asReportedBy", "asSaidBy", "quotedBy",
            "referencedIn", "appearsIn", "namedBy",
        ],
    ),

    # --- Subject of a work (NEW) ---
    OntologyPredicate(
        id="subjectOf",
        label="subject of",
        description=(
            "A person, event, or group is depicted, described, or documented as a primary "
            "subject in a literary work — they appear in it as the topic, not as its author."
        ),
        domain=["Person", "Event", "Ethnonym"],
        range=["Work"],
        examples=["Simon the High Priest subjectOf Maccabean Writings",
                  "Return from Babylon subjectOf Chronographia"],
        aliases=[
            "describedIn", "recordedIn", "narratedIn", "documentedIn",
            "appearsIn", "featuredIn", "portraitIn", "died", "death recorded in",
        ],
    ),

    # --- Social / succession ---
    OntologyPredicate(
        id="assumesRole",
        label="assumes role",
        description="A person takes on a specific office, title, or function.",
        domain=["Person"],
        range=["Role"],
        examples=["Simon assumesRole High Priest", "Aristobulus assumesRole King"],
        aliases=[
            "holds", "serves as", "acts as", "takes on role", "appointed to",
            "became", "was appointed", "took on", "assumed", "elected as",
            "ordained as", "installed as", "succeededTo",
        ],
    ),
    OntologyPredicate(
        id="succeedsTo",
        label="succeeds to",
        description="A person replaces another person in a role or position.",
        domain=["Person"],
        range=["Person"],
        examples=["Aristobulus succeedsTo Simon"],
        aliases=["succeeded", "replaced", "followed", "took over from", "came after", "heir of"],
    ),
    OntologyPredicate(
        id="isFirstTo",
        label="is first to",
        description="A person is the first to hold a role or achieve something, often after a significant event.",
        domain=["Person"],
        range=["Role"],
        examples=["Aristobulus isFirstTo King after Return from Babylon"],
        aliases=["first to hold", "inaugural", "pioneered", "first to be", "first ever"],
    ),
    OntologyPredicate(
        id="studiedUnder",
        label="studied under",
        description="A person was a student or disciple of another person.",
        domain=["Person"],
        range=["Person"],
        examples=["Origen studiedUnder Clement of Alexandria"],
        aliases=["was student of", "learned from", "disciple of", "pupil of", "trained under"],
    ),
    OntologyPredicate(
        id="contemporaryWith",
        label="contemporary with",
        description="A person lived or was active at the same time as another person.",
        domain=["Person"],
        range=["Person"],
        examples=["Josephus contemporaryWith Vespasian"],
        aliases=["lived at same time as", "coeval with", "contemporary of", "same era as"],
    ),
    OntologyPredicate(
        id="memberOf",
        label="member of",
        description="A person or group belongs to a larger political, ethnic, or social body.",
        domain=["Person", "Ethnonym"],
        range=["Polity", "Ethnonym"],
        examples=["Josephus memberOf Jewish community"],
        aliases=["part of", "belongs to", "affiliated with", "citizen of", "subject of"],
    ),
    OntologyPredicate(
        id="advocated",
        label="advocated",
        description="A person actively defended or promoted a doctrine, idea, or position.",
        domain=["Person"],
        range=["Abstraction"],
        examples=["Athanasius advocated homoousios"],
        aliases=[
            "defended", "promoted", "championed", "supported doctrine",
            "taught", "believed in", "espoused", "argued for", "preached",
        ],
    ),
    OntologyPredicate(
        id="opposed",
        label="opposed",
        description="A person or group actively resisted or refuted a doctrine, idea, or another person.",
        domain=["Person", "Ethnonym"],
        range=["Abstraction", "Person"],
        examples=["Athanasius opposed Arianism"],
        aliases=[
            "refuted", "rejected", "fought against", "disagreed with",
            "condemned", "argued against", "denounced", "contested",
        ],
    ),

    # --- Geographic ---
    OntologyPredicate(
        id="bornIn",
        label="born in",
        description="A person's place of birth.",
        domain=["Person"],
        range=["Place"],
        examples=["Eusebius bornIn Caesarea"],
        aliases=["native of", "birthplace", "from", "born at", "originated from"],
    ),
    OntologyPredicate(
        id="livedIn",
        label="lived in",
        description="A person resided or was based in a place.",
        domain=["Person"],
        range=["Place"],
        examples=["Josephus livedIn Rome"],
        aliases=["resided in", "based in", "settled in", "dwelled in", "stayed in", "moved to"],
    ),
    OntologyPredicate(
        id="exiledTo",
        label="exiled to",
        description="A person was forcibly sent to a place against their will.",
        domain=["Person"],
        range=["Place"],
        examples=["John Chrysostom exiledTo Cucusus"],
        aliases=["banished to", "deported to", "sent into exile", "expelled to", "driven to"],
    ),
    OntologyPredicate(
        id="locatedIn",
        label="located in",
        description="A person, event, polity, or artifact is spatially situated in a place.",
        domain=["Person", "Event", "Polity", "Artifact"],
        range=["Place"],
        examples=["Council of Nicaea locatedIn Nicaea"],
        aliases=[
            "situated in", "found in", "based at", "held in", "at", "in",
            "within", "set in", "took place in", "centered in",
        ],
    ),
    OntologyPredicate(
        id="ruledOver",
        label="ruled over",
        description=(
            "A person or polity exercised political authority over a place or another polity. "
            "This category covers all forms of political control and establishment of authority."
        ),
        domain=["Person", "Polity"],
        range=["Place", "Polity"],
        examples=["Constantine ruledOver Roman Empire", "Cyrus ruledOver Persian Empire"],
        aliases=[
            "governed", "controlled", "reigned over", "held power over",
            "founded", "established", "created", "led", "commanded",
            "conquered", "dominated", "administered",
        ],
    ),
    OntologyPredicate(
        id="originatesFrom",
        label="originates from",
        description="A person, group, or practice has its origins in a place or polity.",
        domain=["Person", "Ethnonym", "Practice"],
        range=["Place", "Polity"],
        examples=["Jews originatesFrom Babylon"],
        aliases=["comes from", "originated in", "native to", "descended from", "hails from"],
    ),

    # --- Temporal ---
    OntologyPredicate(
        id="precedes",
        label="precedes",
        description="An event or time period chronologically comes before another.",
        domain=["Event", "TimePeriod"],
        range=["Event", "TimePeriod"],
        examples=["Return from Babylon precedes 425 Years"],
        aliases=[
            "before", "prior to", "came before", "earlier than",
            "preceded", "antedates", "followed by",
        ],
    ),
    OntologyPredicate(
        id="livedDuring",
        label="lived during",
        description="A person was alive and active during a given time period or event.",
        domain=["Person"],
        range=["TimePeriod", "Event"],
        examples=["Eusebius livedDuring Reign of Constantine"],
        aliases=[
            "active during", "contemporary with period", "existed during",
            "lived in time of", "during the reign of", "flourished during",
            "afterReturnFrom", "in the time of",
        ],
    ),
    OntologyPredicate(
        id="associatedWith",
        label="associated with",
        description="A time period or event is historically linked to a person, group, or other event.",
        domain=["TimePeriod", "Event"],
        range=["Person", "Ethnonym", "Event"],
        examples=["481 Years associatedWith Return from Babylon"],
        aliases=["linked to", "connected to", "corresponds to", "relates to", "preceded"],
    ),

    # --- Event participation ---
    OntologyPredicate(
        id="participatedIn",
        label="participated in",
        description="A person or group took an active part in an event.",
        domain=["Person", "Ethnonym"],
        range=["Event"],
        examples=["Eusebius participatedIn Council of Nicaea"],
        aliases=[
            "took part in", "involved in", "attended", "engaged in",
            "joined", "fought in", "present at", "took part",
        ],
    ),
    OntologyPredicate(
        id="documentedEvent",
        label="documented event",
        description="A person or work recorded, described, or reported on an event.",
        domain=["Person", "Work"],
        range=["Event"],
        examples=["Eusebius documentedEvent Council of Nicaea"],
        aliases=[
            "recorded", "reported", "described", "chronicled", "narrated",
            "wrote about", "documented", "accounts for",
        ],
    ),

    # --- Object / symbol ---
    OntologyPredicate(
        id="wearsSymbol",
        label="wears symbol",
        description="A person bears or wears an artifact that carries symbolic, political, or religious significance.",
        domain=["Person"],
        range=["Artifact"],
        examples=["Aristobulus wearsSymbol Royal Diadem"],
        aliases=["bears", "wears", "carries", "holds insignia", "wore", "donned", "displayed"],
    ),

    # --- Liberation / displacement ---
    OntologyPredicate(
        id="freedFrom",
        label="freed from",
        description="A person or group was liberated from captivity, servitude, or domination by a polity or place.",
        domain=["Person", "Ethnonym"],
        range=["Place", "Polity"],
        examples=["Jews freedFrom Babylon"],
        aliases=["liberated from", "released from", "escaped from", "delivered from", "emancipated from"],
    ),
    OntologyPredicate(
        id="returnsTo",
        label="returns to",
        description="A person or group moves back to a homeland or previous location.",
        domain=["Person", "Ethnonym"],
        range=["Place"],
        examples=["Jews returnsTo Homeland"],
        aliases=["returned to", "went back to", "came back to", "restored to", "repatriated to"],
    ),
]
