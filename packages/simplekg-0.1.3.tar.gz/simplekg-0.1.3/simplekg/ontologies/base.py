"""
Ontology base classes for the NKGGenerator pipeline.

These classes define the structure of a domain-specific ontology that can be
injected into signature registries to enable ontology-based KG normalization.
See OntologyBasedKGImplementation.md for the full design rationale.
"""

from typing import List, Optional
from pydantic import BaseModel, Field


class OntologyEntityType(BaseModel):
    """
    Represents a single entity/concept type in the ontology.

    Used both as LLM guidance (injected into extraction signatures) and as
    the enforced vocabulary for concept entity_type fields.
    """
    id: str = Field(..., description="Canonical identifier, e.g. 'Person'. Used for matching against concept.entity_type.")
    description: str = Field(..., description="What this type means. Injected into LLM prompts for guidance.")
    examples: List[str] = Field(default_factory=list, description="Representative instances, e.g. ['Julius Caesar', 'Eusebius'].")
    aliases: List[str] = Field(default_factory=list, description="Alternative labels the LLM might produce, e.g. ['Individual', 'Historical figure'].")


class OntologyPredicate(BaseModel):
    """
    Represents a single relation type (predicate) in the ontology.

    domain and range constrain which entity type pairs this predicate applies to.
    An empty list means unconstrained (valid for any type).
    """
    id: str = Field(..., description="Canonical predicate identifier, camelCase, e.g. 'ruledOver'.")
    label: str = Field(..., description="Human-readable label, e.g. 'ruled over'.")
    description: str = Field(..., description="What this relation means. Injected into LLM prompts for guidance and stored for KG explainability.")
    domain: List[str] = Field(default_factory=list, description="Valid subject entity type ids. Empty = unconstrained.")
    range: List[str] = Field(default_factory=list, description="Valid object entity type ids. Empty = unconstrained.")
    examples: List[str] = Field(default_factory=list, description="Example triples, e.g. ['Caesar ruledOver Rome'].")
    aliases: List[str] = Field(default_factory=list, description="Alternative phrasings the LLM might extract, e.g. ['governed', 'controlled'].")
    parent_id: Optional[str] = Field(default=None, description="Parent predicate id for intra-ontology hierarchy, e.g. 'relatedTo'.")


class Ontology:
    """
    A domain-specific ontology defining the allowed entity types and predicates
    for a KG normalization step.

    Subclass this to define a domain ontology and override get_ontology() in
    the corresponding SignatureRegistry. The pipeline checks for None — if no
    ontology is provided, normalization is silently skipped.

    Example:
        class AncientGreekOntology(Ontology):
            def __init__(self):
                super().__init__(
                    id="ancient-greek-v1",
                    description="Ontology for ancient Greek historical texts.",
                    entity_types=[...],
                    generic_entity_type="Entity",
                    predicates=[...],
                    generic_predicate="relatedTo",
                )
    """

    def __init__(
        self,
        id: str,
        description: str,
        entity_types: List[OntologyEntityType],
        generic_entity_type: str,
        predicates: List[OntologyPredicate],
        generic_predicate: str,
    ):
        self.id = id
        self.description = description
        self.entity_types = entity_types
        self.generic_entity_type = generic_entity_type
        self.predicates = predicates
        self.generic_predicate = generic_predicate

        # Build lookup sets for fast validation
        self._entity_type_ids = {et.id for et in entity_types}
        self._predicate_ids = {p.id for p in predicates}

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def is_valid_entity_type(self, entity_type_id: str) -> bool:
        """Return True if entity_type_id is in the ontology (or is the generic fallback)."""
        return entity_type_id in self._entity_type_ids or entity_type_id == self.generic_entity_type

    def is_valid_predicate(self, predicate_id: str) -> bool:
        """Return True if predicate_id is in the ontology (or is the generic fallback)."""
        return predicate_id in self._predicate_ids or predicate_id == self.generic_predicate

    # ------------------------------------------------------------------
    # Pre-filtering for predicate mapping
    # ------------------------------------------------------------------

    def filter_predicates(self, subject_type: str, object_type: str) -> List[OntologyPredicate]:
        """
        Return predicates whose domain/range constraints are satisfied by the
        given subject and object entity types.

        An empty domain or range list means unconstrained (always matches).
        The generic_predicate is never included — it is applied as a fallback
        after this list is evaluated.
        """
        return [
            p for p in self.predicates
            if (not p.domain or subject_type in p.domain)
            and (not p.range or object_type in p.range)
        ]

    # ------------------------------------------------------------------
    # LLM prompt rendering
    # ------------------------------------------------------------------

    def format_entity_types_for_llm(self) -> str:
        """
        Render the entity type list as a prompt block for injection into
        extraction signatures.
        """
        lines = []
        for et in self.entity_types:
            line = f"  - {et.id}: {et.description}"
            if et.examples:
                line += f" (e.g. {', '.join(et.examples[:3])})"
            lines.append(line)
        return "\n".join(lines)

    def format_predicates_for_llm(self, predicates: Optional[List[OntologyPredicate]] = None) -> str:
        """
        Render a predicate list as a prompt block for injection into the
        mapping signature. If predicates is None, renders all predicates.
        """
        if predicates is None:
            predicates = self.predicates

        lines = []
        for p in predicates:
            line = f"  - {p.id} ({p.label}): {p.description}"
            if p.domain or p.range:
                domain_str = ", ".join(p.domain) if p.domain else "any"
                range_str = ", ".join(p.range) if p.range else "any"
                line += f" [domain: {domain_str} → range: {range_str}]"
            if p.aliases:
                line += f" | maps from: {', '.join(p.aliases)}"
            if p.examples:
                line += f" | e.g. \"{p.examples[0]}\""
            lines.append(line)

        # Generic fallback — described as last resort
        lines.append(
            f"  - {self.generic_predicate}: LAST RESORT ONLY — use only when the relation "
            f"is categorically outside all other predicates above. "
            f"Prefer any imperfect match over this fallback."
        )
        return "\n".join(lines)

    def format_for_llm(self) -> str:
        """
        Render the full ontology (entity types + predicates) as a prompt block.
        """
        return (
            f"ONTOLOGY: {self.id}\n"
            f"{self.description}\n\n"
            f"ENTITY TYPES:\n{self.format_entity_types_for_llm()}\n\n"
            f"PREDICATES:\n{self.format_predicates_for_llm()}"
        )
