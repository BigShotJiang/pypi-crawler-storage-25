import os, time
from dotenv import load_dotenv
from kg import KnowledgeGraphGenerator

load_dotenv("../.env")

def main():
    # Example usage
    print("SimpleKG CLI Tool")
    print("Testing KnowledgeGraphGenerator import...")
    
    # Test basic functionality
    try:
        kggen = KnowledgeGraphGenerator(model = "openai/gpt-4o",
                                      api_key=os.getenv("OPENAI_API_KEY"))

        
        
        # Load sample text
        file_name = "20190257"
        file_name = "news_a_sharaa"
        path = "../../Ramban/"
        chunk_size = 1000
        with open(f"{path}txt/{file_name}.txt", "r", encoding="utf-8") as file:
            text = file.read()
        text = text.strip().replace("\n", " ")
        text = " ".join(text.split(' ')[:500])
        print(f"The sample text size: {len(text.split(' '))}")

        
        # start = time.time()
        # stmt = kg.extractStatements(text+" ")
        # norm_text = "\n".join([x.text for x in stmt ])
        # print(f"Extracted {len(stmt)} statements in {time.time() - start:.2f} seconds:")
        # for s in stmt:
        #     print(f" - {s.text}")

        persona_news = '''You are Hebrew linguistics expert and Knowledge Graph Engineer specializing in Moden Hebrew.'''

        kggen.set_params(extract_entities_mode="dynamic",
                         init_entity_types=[], 
                         chunk_size=chunk_size, 
                 
                         persona=persona_news, 
                 
                         clear_dspy_cache=True)

        start = time.time()
        kggen.extractConcepts(text=text, verbose=True)
        print(f"Extracted concepts in {time.time() - start:.2f} seconds.")


    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    main()