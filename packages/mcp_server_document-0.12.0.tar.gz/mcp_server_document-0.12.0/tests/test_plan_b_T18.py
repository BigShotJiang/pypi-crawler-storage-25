"""Tests for Plan B T18: grant_writing_paragraph_length_distribution.

5 cases covering: clean short paragraphs / single long paragraph /
mixed / no separator / \\par (LaTeX) separated.
Assertions focus on `comments` substrings and `observations` structure.
Do NOT assert exact numeric score beyond coarse bounds.
"""
from mcp_server_document.grant_writing.plan_b_T18 import (
    grant_writing_paragraph_length_distribution,
)


# ------------------------------------------------------------------
# Case 1: Clean — 3 short paragraphs separated by \n\n → score = 10
# ------------------------------------------------------------------
def test_clean_short_paragraphs_score_full():
    text = (
        "第一段落は短く、主張が明確である。"
        "\n\n"
        "第二段落も短い。論理展開は次の段落へ。"
        "\n\n"
        "第三段落で結論を述べる。読みやすい構成。"
    )
    r = grant_writing_paragraph_length_distribution(text)

    # 構造
    assert r["score_max"] == 10
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5
    assert "source" in r
    assert "skill.md" in r["source"]

    # observations
    obs = r["observations"]
    assert obs["total_paragraphs"] == 3
    assert obs["long_paragraphs_count"] == 0
    assert obs["paragraph_separator_detected"] == "\n\n"
    for p in obs["paragraphs"]:
        assert p["status"] == "OK"
        assert "idx" in p and "char_count" in p and "line_count" in p
        assert "head_text" in p

    # 全 OK → score 10
    assert r["score"] == 10.0

    # 肯定コメントが入る
    joined = "\n".join(r["comments"])
    assert "閾値内" in joined


# ------------------------------------------------------------------
# Case 2: Single long paragraph (> 500 chars) → flagged
# ------------------------------------------------------------------
def test_single_long_paragraph_flagged():
    # 1 段落 600 字以上
    long_body = "本研究は極めて重要な課題に取り組む。" * 30  # ~600 字
    text = long_body  # 区切りマーカー無し、1 段落

    r = grant_writing_paragraph_length_distribution(text)

    obs = r["observations"]
    assert obs["total_paragraphs"] == 1
    assert obs["long_paragraphs_count"] == 1

    # status は TOO_LONG_CHARS または BOTH_OVER
    p = obs["paragraphs"][0]
    assert p["status"] in ("TOO_LONG_CHARS", "BOTH_OVER")
    assert p["char_count"] > 500

    # comment が idx を名指ししている
    joined = "\n".join(r["comments"])
    assert "段落 1" in joined
    assert "長い" in joined
    assert "分割" in joined or "圧縮" in joined

    # 全て NG → score 0
    assert r["score"] == 0.0


# ------------------------------------------------------------------
# Case 3: Mixed — 2 OK + 1 over → partial score, comment names offender
# ------------------------------------------------------------------
def test_mixed_partial_score_and_named_offender():
    short_a = "短い段落その 1。主張は明確である。"
    short_b = "短い段落その 2。論理は続く。"
    # 500 字超の段落
    long_c = "この段落は非常に長く、申請書として不適切な長さである。" * 25

    text = f"{short_a}\n\n{short_b}\n\n{long_c}"

    r = grant_writing_paragraph_length_distribution(text)

    obs = r["observations"]
    assert obs["total_paragraphs"] == 3
    assert obs["long_paragraphs_count"] == 1
    assert obs["paragraph_separator_detected"] == "\n\n"

    # 段落 3 が offender
    statuses = [p["status"] for p in obs["paragraphs"]]
    assert statuses[0] == "OK"
    assert statuses[1] == "OK"
    assert statuses[2] in ("TOO_LONG_CHARS", "TOO_LONG_LINES", "BOTH_OVER")

    # 部分点 (2/3 OK → 約 6.7)
    assert 5.0 < r["score"] < 10.0

    # comment で段落 3 を名指し
    joined = "\n".join(r["comments"])
    assert "段落 3" in joined
    # 先頭 40 字の head_text が含まれる (一部でもよい)
    assert "この段落は" in joined


# ------------------------------------------------------------------
# Case 4: No separator — full text as single paragraph
# ------------------------------------------------------------------
def test_no_separator_advises_adding_separators():
    # 適度な短さでも区切り無し
    text = "これは区切りマーカーを含まない短めの本文です。段落分割が無い状態を再現します。"

    r = grant_writing_paragraph_length_distribution(text)

    obs = r["observations"]
    assert obs["total_paragraphs"] == 1
    assert obs["paragraph_separator_detected"] == "<single_line>"

    # 助言コメント: マーカー不在
    joined = "\n".join(r["comments"])
    assert "段落分割マーカー" in joined or "1 塊" in joined
    assert "\\par" in joined or "空行" in joined


# ------------------------------------------------------------------
# Case 5: \par (LaTeX) separated
# ------------------------------------------------------------------
def test_par_latex_separator_splits_correctly():
    text = (
        r"第一段落は短く主張が明確である。"
        r"\par"
        r"第二段落は続きの論理を展開する。"
        r"\par"
        r"第三段落で結論を述べる。"
    )
    r = grant_writing_paragraph_length_distribution(text)

    obs = r["observations"]
    assert obs["total_paragraphs"] == 3
    assert obs["paragraph_separator_detected"] == r"\par"
    for p in obs["paragraphs"]:
        assert p["status"] == "OK"

    # 全 OK → score 10
    assert r["score"] == 10.0


# ------------------------------------------------------------------
# Edge: empty text → score 0, comment "段落が検出されない"
# ------------------------------------------------------------------
def test_empty_text_no_crash():
    r = grant_writing_paragraph_length_distribution("")
    assert r["score"] == 0.0
    assert r["observations"]["total_paragraphs"] == 0
    joined = "\n".join(r["comments"])
    assert "段落が検出されない" in joined
