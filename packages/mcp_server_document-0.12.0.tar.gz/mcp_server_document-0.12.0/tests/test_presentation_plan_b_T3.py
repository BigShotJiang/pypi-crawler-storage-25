"""Tests for Plan B T3: presentation_check_pie_3d_charts.

4 cases:
1. Bar chart only       — ok_count >= 1, ng_count == 0, score 10
2. Pie chart present    — ng_count >= 1, score < 10, comment names slide idx
3. 3D chart present     — detected as NG
4. No charts            — total_charts == 0, score 10
"""
from __future__ import annotations

import pytest

pytest.importorskip("pptx")

from pptx import Presentation  # noqa: E402
from pptx.chart.data import CategoryChartData  # noqa: E402
from pptx.enum.chart import XL_CHART_TYPE  # noqa: E402
from pptx.util import Inches  # noqa: E402

from mcp_server_document.presentation.plan_b_T3 import (  # noqa: E402
    presentation_check_pie_3d_charts,
)


# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------
def _blank_layout(prs):
    # layout index 6 is normally "Blank" in the default template
    return prs.slide_layouts[6]


def _add_chart(prs, chart_type):
    slide = prs.slides.add_slide(_blank_layout(prs))
    data = CategoryChartData()
    data.categories = ["A", "B", "C"]
    data.add_series("S1", (1, 2, 3))
    slide.shapes.add_chart(
        chart_type, Inches(1), Inches(1), Inches(5), Inches(4), data
    )
    return slide


def _add_3d_area_chart(prs):
    """Add an AREA chart and then rename its XML tag to area3DChart.

    python-pptx cannot write most 3D chart types directly (NotImplementedError),
    but it CAN read and round-trip area3DChart. We therefore construct an
    AREA chart and patch the underlying XML element tag to `area3DChart`,
    which `PlotTypeInspector` maps to `XL_CHART_TYPE.THREE_D_AREA`.
    """
    slide = prs.slides.add_slide(_blank_layout(prs))
    data = CategoryChartData()
    data.categories = ["A", "B"]
    data.add_series("S", (1, 2))
    gf = slide.shapes.add_chart(
        XL_CHART_TYPE.AREA, Inches(1), Inches(1), Inches(5), Inches(4), data
    )
    chart = gf.chart
    nsmap = {"c": "http://schemas.openxmlformats.org/drawingml/2006/chart"}
    plot_elem = chart._chartSpace.find(".//c:areaChart", nsmap)
    plot_elem.tag = "{http://schemas.openxmlformats.org/drawingml/2006/chart}area3DChart"
    return slide


def _add_blank_slide(prs):
    return prs.slides.add_slide(_blank_layout(prs))


# ------------------------------------------------------------------
# Case 1: Bar chart only
# ------------------------------------------------------------------
def test_bar_chart_only_scores_max(tmp_path):
    prs = Presentation()
    _add_chart(prs, XL_CHART_TYPE.BAR_CLUSTERED)
    path = tmp_path / "bar_only.pptx"
    prs.save(str(path))

    r = presentation_check_pie_3d_charts(str(path))

    # 構造
    assert r["score_max"] == 10
    assert "comments" in r
    assert "observations" in r
    assert "hint" in r
    assert "source" in r

    obs = r["observations"]
    assert obs["total_charts"] == 1
    assert obs["ok_count"] == 1
    assert obs["ng_count"] == 0
    assert obs["ng_charts"] == []
    assert len(obs["ok_charts"]) == 1
    assert obs["ok_charts"][0]["chart_type"] == "BAR_CLUSTERED"
    assert obs["ok_charts"][0]["slide_idx"] == 0

    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "宮野 S8 基準を満たす" in joined


# ------------------------------------------------------------------
# Case 2: Pie chart present
# ------------------------------------------------------------------
def test_pie_chart_detected_as_ng(tmp_path):
    prs = Presentation()
    _add_blank_slide(prs)           # slide 0 (no chart)
    _add_chart(prs, XL_CHART_TYPE.BAR_CLUSTERED)  # slide 1 (ok)
    _add_chart(prs, XL_CHART_TYPE.PIE)            # slide 2 (ng)
    path = tmp_path / "pie.pptx"
    prs.save(str(path))

    r = presentation_check_pie_3d_charts(str(path))

    obs = r["observations"]
    assert obs["total_charts"] == 2
    assert obs["ng_count"] >= 1
    assert obs["ok_count"] == 1

    # NG chart の中身
    ng_types = [c["chart_type"] for c in obs["ng_charts"]]
    assert "PIE" in ng_types

    ng_slides = [c["slide_idx"] for c in obs["ng_charts"]]
    assert 2 in ng_slides

    # score < 10
    assert r["score"] < 10

    # comment が該当スライド番号 (1-origin で "3") を明示
    joined = "\n".join(r["comments"])
    assert "スライド 3" in joined
    assert "PIE" in joined
    assert "宮野 S8" in joined


# ------------------------------------------------------------------
# Case 3: 3D chart detected as NG
#
# NOTE: python-pptx cannot write most XL_CHART_TYPE.THREE_D_* values directly
# (only area3DChart round-trips). We therefore construct a patched area3DChart
# to represent the 3D chart family in integration tests, and also test
# `_is_ng_chart_type` against the full set of 3D enum NAMES at the unit layer.
# ------------------------------------------------------------------
def test_3d_chart_detected_as_ng(tmp_path):
    prs = Presentation()
    _add_3d_area_chart(prs)
    path = tmp_path / "threed.pptx"
    prs.save(str(path))

    r = presentation_check_pie_3d_charts(str(path))

    obs = r["observations"]
    assert obs["total_charts"] == 1
    assert obs["ng_count"] == 1
    assert obs["ok_count"] == 0

    ng_types = [c["chart_type"] for c in obs["ng_charts"]]
    assert any("THREE_D" in t for t in ng_types)
    assert "THREE_D_AREA" in ng_types

    # 全 chart が NG → score は 0
    assert r["score"] == 0.0

    joined = "\n".join(r["comments"])
    assert "THREE_D" in joined
    assert "宮野 S8" in joined


def test_is_ng_chart_type_unit_covers_full_3d_and_pie_family():
    """`_is_ng_chart_type` が pie / doughnut / 3D 系の名前全てを NG と判定。"""
    from mcp_server_document.presentation.plan_b_T3 import _is_ng_chart_type

    ng_names = [
        "PIE",
        "PIE_EXPLODED",
        "PIE_OF_PIE",
        "BAR_OF_PIE",
        "DOUGHNUT",
        "DOUGHNUT_EXPLODED",
        "THREE_D_AREA",
        "THREE_D_AREA_STACKED",
        "THREE_D_BAR_CLUSTERED",
        "THREE_D_COLUMN",
        "THREE_D_COLUMN_CLUSTERED",
        "THREE_D_LINE",
        "THREE_D_PIE",
        "THREE_D_PIE_EXPLODED",
    ]
    for name in ng_names:
        assert _is_ng_chart_type(name), f"{name} should be NG"

    ok_names = [
        "BAR_CLUSTERED",
        "BAR_STACKED",
        "COLUMN_CLUSTERED",
        "LINE",
        "LINE_MARKERS",
        "XY_SCATTER",
        "AREA",
        "RADAR",
    ]
    for name in ok_names:
        assert not _is_ng_chart_type(name), f"{name} should be OK"


def test_doughnut_chart_detected_as_ng(tmp_path):
    """DOUGHNUT 系も S8 により NG (pie と同系統)。"""
    prs = Presentation()
    _add_chart(prs, XL_CHART_TYPE.DOUGHNUT)
    path = tmp_path / "doughnut.pptx"
    prs.save(str(path))

    r = presentation_check_pie_3d_charts(str(path))
    assert r["observations"]["ng_count"] == 1
    assert r["observations"]["ng_charts"][0]["chart_type"] == "DOUGHNUT"


# ------------------------------------------------------------------
# Case 4: No charts
# ------------------------------------------------------------------
def test_no_charts(tmp_path):
    prs = Presentation()
    _add_blank_slide(prs)
    _add_blank_slide(prs)
    path = tmp_path / "empty.pptx"
    prs.save(str(path))

    r = presentation_check_pie_3d_charts(str(path))

    obs = r["observations"]
    assert obs["total_charts"] == 0
    assert obs["ng_count"] == 0
    assert obs["ok_count"] == 0
    assert obs["ng_charts"] == []
    assert obs["ok_charts"] == []

    # 不在時は score 10
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "chart 未使用" in joined or "chart 不在" in joined


# ------------------------------------------------------------------
# Additional: hint / source fixed content
# ------------------------------------------------------------------
def test_hint_and_source_content(tmp_path):
    prs = Presentation()
    path = tmp_path / "minimal.pptx"
    prs.save(str(path))

    r = presentation_check_pie_3d_charts(str(path))
    assert "chart_type 列挙" in r["hint"]
    assert "slopegraph" in r["hint"] or "bar" in r["hint"]
    assert "宮野" in r["source"]
    assert "S8" in r["source"]


# ------------------------------------------------------------------
# Structural: comments count in [2, 6]
# ------------------------------------------------------------------
def test_comments_count_bounds(tmp_path):
    prs = Presentation()
    _add_chart(prs, XL_CHART_TYPE.PIE)
    _add_chart(prs, XL_CHART_TYPE.BAR_CLUSTERED)
    path = tmp_path / "mix.pptx"
    prs.save(str(path))

    r = presentation_check_pie_3d_charts(str(path))
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 6
