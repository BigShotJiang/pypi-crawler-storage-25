"""Tests for Plan B T13 — grant_writing_budget_logic_check."""

from __future__ import annotations

from mcp_server_document.grant_writing.plan_b_T13 import (
    grant_writing_budget_logic_check,
)


def test_consistent_budget():
    """整合した予算: 合計と積み上げが一致、費目揃い → score >= 8."""
    text = (
        "物品費: 100万円\n"
        "旅費: 50万円\n"
        "人件費: 30万円\n"
        "その他: 20万円\n"
        "合計: 200万円"
    )
    result = grant_writing_budget_logic_check(text)

    assert result["score_max"] == 10
    assert result["score"] >= 8
    obs = result["observations"]
    assert obs["sum_matches_stated"] is True
    assert obs["stated_total"] == 2_000_000
    assert obs["computed_sum"] == 2_000_000
    assert obs["missing_major_categories"] == []
    # 一致コメント
    assert any("一致" in c for c in result["comments"])
    # source
    assert "grant-writing" in result["source"]


def test_inconsistent_total():
    """合計額と積み上げが不一致 → sum_matches_stated False, 差異コメント."""
    text = (
        "物品費: 100万円\n"
        "旅費: 50万円\n"
        "合計: 200万円"
    )
    result = grant_writing_budget_logic_check(text)

    obs = result["observations"]
    assert obs["sum_matches_stated"] is False
    assert obs["stated_total"] == 2_000_000
    assert obs["computed_sum"] == 1_500_000
    # 差異を指摘するコメント
    assert any(
        ("一致しない" in c) or ("差" in c) for c in result["comments"]
    )
    # スコアはペナルティ分下がる
    assert result["score"] < 8


def test_missing_categories():
    """物品費しか記載なし → 旅費/人件費/その他 欠損を指摘."""
    text = (
        "物品費: 150万円\n"
        "電磁界解析用ワークステーションおよび計測プローブ一式を導入する。"
    )
    result = grant_writing_budget_logic_check(text)

    obs = result["observations"]
    # 物品費は検出
    assert "物品費" in obs["categories_present"]
    # 他 3 つは欠損
    missing = obs["missing_major_categories"]
    assert "旅費" in missing
    assert "人件費" in missing
    assert "その他" in missing
    # それぞれを指摘するコメントが少なくとも 2 つ (comments 上限 5 による)
    missing_comments = [
        c for c in result["comments"]
        if ("旅費" in c) or ("人件費" in c) or ("その他" in c)
    ]
    assert len(missing_comments) >= 2


def test_no_amounts_plain_text():
    """金額表記が全くない → score 低、明示的コメント."""
    text = (
        "本研究では電磁界解析の新手法を提案する。"
        "従来法では困難であった大規模問題に対応可能である。"
    )
    result = grant_writing_budget_logic_check(text)

    obs = result["observations"]
    assert obs["amounts"] == []
    assert obs["stated_total"] is None
    assert obs["computed_sum"] == 0
    assert result["score"] == 0
    # 金額なしの明示コメント
    assert any(
        ("金額表記" in c) or ("予算セクション" in c) for c in result["comments"]
    )


# ------------------------------------------------------------------
# 2026-04-23 hardening: LaTeX tabular の金額解析
# ------------------------------------------------------------------
def test_latex_tabular_amounts_extracted():
    """\\begin{tabular}...\\end{tabular} 内のセル金額を拾えること。"""
    text = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"項目 & 金額 \\" + "\n"
        r"\hline" + "\n"
        r"物品費 & 100万円 \\" + "\n"
        r"旅費 & 50万円 \\" + "\n"
        r"人件費 & 30万円 \\" + "\n"
        r"その他 & 20万円 \\" + "\n"
        r"合計 & 200万円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(text)
    # 4 件 + stated_total 1 件 が抽出される
    assert len(r["observations"]["amounts"]) >= 4
    # 合計 200万円 と積み上げ 100+50+30+20 が一致
    assert r["observations"]["sum_matches_stated"] is True
    assert r["score"] >= 8


def test_latex_tabular_inconsistent_total():
    """\\begin{tabular} 内で合計が合わない場合、flag する。"""
    text = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"物品費 & 100万円 \\" + "\n"
        r"旅費 & 50万円 \\" + "\n"
        r"合計 & 200万円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(text)
    assert r["observations"]["sum_matches_stated"] is False
    joined = "\n".join(r["comments"])
    assert "一致しない" in joined or "差" in joined


def test_latex_tabular_with_multicolumn():
    """\\multicolumn があっても中身を拾えること。"""
    text = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"\multicolumn{2}{|c|}{経費内訳} \\" + "\n"
        r"\hline" + "\n"
        r"物品費 & 100万円 \\" + "\n"
        r"合計 & 100万円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(text)
    assert len(r["observations"]["amounts"]) >= 1
    assert r["observations"]["sum_matches_stated"] is True
