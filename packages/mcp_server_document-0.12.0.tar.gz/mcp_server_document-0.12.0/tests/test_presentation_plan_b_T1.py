"""Tests for presentation Plan B T1: presentation_opening_hook_strength.

Source: 宮野『研究発表のためのスライドデザイン』S1 / Reynolds Zen /
木下 原則 2 (重点先行)
"""
from __future__ import annotations

import pathlib

import pytest


def _make_pptx(
    tmp_path: pathlib.Path,
    slides: list[tuple[str, str]],
    filename: str = "deck.pptx",
) -> pathlib.Path:
    """Build a pptx with (title, body) per slide using Title+Content layout."""
    pytest.importorskip("pptx")
    from pptx import Presentation

    prs = Presentation()
    for title_text, body_text in slides:
        # Layout 1 = "Title and Content" — has a body placeholder.
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        for ph in slide.placeholders:
            try:
                idx = ph.placeholder_format.idx
            except Exception:
                continue
            if idx == 0:
                ph.text = title_text
            else:
                ph.text = body_text
    out = tmp_path / filename
    prs.save(str(out))
    return out


def test_T1_strong_hook(tmp_path):
    """Slide 1 title has 500 kHz, slide 2 body has 従来: score >= 6."""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T1 import (
        presentation_opening_hook_strength,
    )
    p = _make_pptx(tmp_path, [
        ("500 kHz 帯で動作する新方式", "我々の研究室で実証した。"),
        ("比較", "従来方式では 100 kHz が上限。"),
    ])
    r = presentation_opening_hook_strength(str(p))
    assert "error" not in r.get("observations", {}), r
    assert r["observations"]["slides_analyzed"] == 2
    assert r["observations"]["has_digit_in_opening"] is True
    assert r["observations"]["has_contrast_word"] is True
    assert r["observations"]["has_scene_noun"] is True
    assert r["score"] >= 6, r


def test_T1_generic_opener(tmp_path):
    """Generic '本日は〜発表します' opener should set flag and lower score."""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T1 import (
        presentation_opening_hook_strength,
    )
    p = _make_pptx(tmp_path, [
        ("タイトル", "本日は新方式について発表します。"),
        ("概要", "研究の背景と目的を説明する。"),
    ])
    r = presentation_opening_hook_strength(str(p))
    assert r["observations"]["has_generic_opener"] is True
    # generic opener の直撃 -3。他に強い signal が無ければ低スコアに。
    assert r["score"] <= 4, r
    # コメントに教科書的弱 opening の指摘があること
    joined = " ".join(r["comments"])
    assert "本日は" in joined or "発表します" in joined


def test_T1_all_elements_present(tmp_path):
    """All hook elements present (digits/contrast/scene/question): score >= 8."""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T1 import (
        presentation_opening_hook_strength,
    )
    p = _make_pptx(tmp_path, [
        ("年間 120 億円を救えるか?",
         "工場の現場で 14 年運用してきた商用 CAE。"),
        ("しかし制約がある",
         "従来手法では patient データを扱えず、研究室の教授も頭を抱えた。"),
    ])
    r = presentation_opening_hook_strength(str(p))
    obs = r["observations"]
    assert obs["has_digit_in_opening"] is True
    assert obs["has_contrast_word"] is True
    assert obs["has_scene_noun"] is True
    assert obs["has_question_opener"] is True
    assert obs["has_generic_opener"] is False
    assert r["score"] >= 8, r


def test_T1_missing_pptx():
    """Missing file: observations should carry an error, score 0."""
    from mcp_server_document.presentation.plan_b_T1 import (
        presentation_opening_hook_strength,
    )
    r = presentation_opening_hook_strength("/nonexistent/no_such_deck.pptx")
    assert "error" in r["observations"]
    assert r["score"] == 0
