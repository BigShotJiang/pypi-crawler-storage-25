"""Tests for Plan B T2: presentation_takehome_strength.

Covers 4 cases:
1. Strong take-home (concise, number, action verb)
2. Long take-home (> 6 lines)
3. No take-home (last slide is Q&A only, no content before)
4. Take-home with number but no action verb (partial)

Assertions focus on `comments` content (substrings) and key
`observations` booleans. Do NOT assert exact numeric score values.
"""
from __future__ import annotations

import pytest

pytest.importorskip("pptx")

from pptx import Presentation  # noqa: E402

from mcp_server_document.presentation.plan_b_T2 import (  # noqa: E402
    presentation_takehome_strength,
)


def _fill_title_and_body(slide, title: str, body: str):
    """Populate title + body placeholders on a 'Title and Content' slide."""
    for ph in slide.placeholders:
        try:
            idx = ph.placeholder_format.idx
        except Exception:
            continue
        if idx == 0:
            ph.text = title
        else:
            ph.text = body


# ------------------------------------------------------------------
# Case 1: Strong take-home — concise, number, action verb
# ------------------------------------------------------------------
def test_strong_takehome_scores_high(tmp_path):
    prs = Presentation()
    # Intro slide
    s1 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s1, "Introduction", "Context here.")
    # Middle slide
    s2 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s2, "Method", "Some method text.")
    # Take-home slide (last)
    s3 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s3, "Take-home",
                          "12% 改善を実証。提案手法で達成。")
    out = tmp_path / "strong.pptx"
    prs.save(str(out))

    r = presentation_takehome_strength(str(out))

    # 構造チェック
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5
    assert "木下" in r["source"]
    assert "宮野" in r["source"]

    obs = r["observations"]
    assert obs["takehome_slide_idx"] >= 0
    assert "Take-home" in obs["takehome_title"]
    assert obs["has_key_number"] is True
    assert obs["has_action_verb"] is True
    assert obs["body_line_count"] <= 3
    assert obs["slides_scanned"] == 3

    # 強い take-home → score は高め
    assert r["score"] >= 7


# ------------------------------------------------------------------
# Case 2: Long take-home — body > 6 lines (多すぎ)
# ------------------------------------------------------------------
def test_long_takehome_flags_warning(tmp_path):
    prs = Presentation()
    s1 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s1, "Intro", "context")
    s2 = prs.slides.add_slide(prs.slide_layouts[1])
    long_body = "\n".join([
        "手法を提案した",
        "評価を行った",
        "結果が出た",
        "考察を行った",
        "限界が見えた",
        "今後の課題がある",
        "謝意を表する",
        "参考文献を示す",
    ])
    _fill_title_and_body(s2, "Summary", long_body)
    out = tmp_path / "long.pptx"
    prs.save(str(out))

    r = presentation_takehome_strength(str(out))

    obs = r["observations"]
    assert obs["takehome_slide_idx"] >= 0
    assert obs["body_line_count"] > 6

    # score 減点。詰め込みすぎ警告が comments に含まれる。
    joined = "\n".join(r["comments"])
    assert "1 枚 1 メッセージ" in joined or "3 行以内" in joined
    # 行数の数字が comment 内に埋め込まれる
    assert str(obs["body_line_count"]) in joined


# ------------------------------------------------------------------
# Case 3: No take-home — last slide is Q&A only, no content before
# ------------------------------------------------------------------
def test_no_takehome_last_slide_is_qa_only(tmp_path):
    prs = Presentation()
    # Only a Q&A slide (no content, no body). Should yield idx == -1.
    s1 = prs.slides.add_slide(prs.slide_layouts[1])
    # Q&A title + empty body — walked-back search must skip this slide
    # AND find nothing before it.
    _fill_title_and_body(s1, "Q&A", "")
    out = tmp_path / "qa_only.pptx"
    prs.save(str(out))

    r = presentation_takehome_strength(str(out))

    obs = r["observations"]
    assert obs["takehome_slide_idx"] == -1
    assert obs["has_qa_or_questions_title"] is True

    # 強い警告コメント: 「Take-home スライドが見当たらない」
    joined = "\n".join(r["comments"])
    assert "見当たらない" in joined or "Take-home" in joined
    # score は低め (take-home 不在の -3 ペナルティ)
    assert r["score"] <= 5


# ------------------------------------------------------------------
# Case 4: Take-home with number but no action verb
# ------------------------------------------------------------------
def test_takehome_number_only_partial_score(tmp_path):
    prs = Presentation()
    s1 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s1, "Context", "背景")
    s2 = prs.slides.add_slide(prs.slide_layouts[1])
    # Body: 数値はあるが action verb なし (名詞句のみ)。
    _fill_title_and_body(s2, "結果のまとめ", "12% 改善")
    out = tmp_path / "number_only.pptx"
    prs.save(str(out))

    r = presentation_takehome_strength(str(out))

    obs = r["observations"]
    assert obs["takehome_slide_idx"] >= 0
    assert obs["has_key_number"] is True
    assert obs["has_action_verb"] is False

    # action verb 不在の助言が含まれる
    joined = "\n".join(r["comments"])
    assert "action verb" in joined or "提案" in joined

    # 全 OK の肯定コメントは出ない
    assert "要件を満たす" not in joined


# ------------------------------------------------------------------
# Additional smoke: error handling for missing file
# ------------------------------------------------------------------
def test_missing_file_returns_error(tmp_path):
    r = presentation_takehome_strength(str(tmp_path / "nope.pptx"))
    assert "error" in r


# ------------------------------------------------------------------
# Additional: Q&A on last slide + take-home before it
# ------------------------------------------------------------------
def test_qa_last_with_takehome_before(tmp_path):
    """最終スライドが Q&A だが、その直前に take-home がある場合。"""
    prs = Presentation()
    s1 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s1, "Intro", "context")
    s2 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s2, "Take-home",
                          "3 倍高速化を実現。提案手法で達成。")
    s3 = prs.slides.add_slide(prs.slide_layouts[1])
    _fill_title_and_body(s3, "ご清聴ありがとうございました", "")
    out = tmp_path / "qa_last.pptx"
    prs.save(str(out))

    r = presentation_takehome_strength(str(out))
    obs = r["observations"]

    # Q&A slide をスキップして一つ前の take-home を拾う
    assert obs["takehome_slide_idx"] == 1
    assert "Take-home" in obs["takehome_title"]
    assert obs["has_qa_or_questions_title"] is True
    # Q&A 肯定コメントが入る
    joined = "\n".join(r["comments"])
    assert "question-handling" in joined or "準備あり" in joined
