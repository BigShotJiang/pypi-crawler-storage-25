"""Tool functions for the paper-writing domain of mcp-server-document.

All functions are plain callables; they get wrapped by @mcp.tool()
in the top-level server.py. No FastMCP import here (that would
accidentally register a second MCP server).
"""

from __future__ import annotations

import pathlib
import re

# Plan B Tier 1 (v0.12.0) — composite score + human-advisor comments
from .plan_b_T1 import paper_writing_abstract_strength  # noqa: F401
from .plan_b_T2 import paper_writing_contribution_clarity_score  # noqa: F401


_HERE = pathlib.Path(__file__).resolve().parent
KNOWLEDGE = _HERE


def _load_skill() -> str:
    return (KNOWLEDGE / "skill.md").read_text(encoding="utf-8")


# ------------------------------------------------------------------
# Knowledge loader
# ------------------------------------------------------------------
def paper_writing_usage() -> str:
    """Journal 論文 (IEEE / IEEJ / APS / Elsevier 等) の作文技術ガイド全体。

    IMRAD 構造 (Abstract/Intro/Method/Result/Discussion/Conclusion) の
    書き方、contribution 明示、reviewer 2 対策、citation pattern、
    figure placement、abstract 字数、英文 red-flag 検出、cover letter
    テンプレート等の総合ガイド。

    呼び出しタイミング:
    - Journal paper ドラフトのレビュー依頼
    - 「contribution が不明瞭」feedback 対応
    - Reviewer コメントへの response letter 作成
    - Abstract / Introduction の書き直し
    - 英文チェック (冠詞抜け、時制不統一、自動詞/他動詞)
    - 投稿前の最終チェックリスト

    活動ツール (実測) は以下を併用:
    - paper_writing_count_underlines(tex_path)         — 下線/強調の密度
    - paper_writing_validate_pdf_pages(pdf_path, limit) — 投稿ページ制限
    - paper_writing_check_overfull_hbox(log_path)       — 組版警告
    - paper_writing_analyze_sentences(text, max_len)    — 文長統計
    - paper_writing_count_weak_expressions(text)        — 弱気修飾語
    - paper_writing_validate_abstract_length(text, max) — abstract 字数
    - paper_writing_check_citation_usage(tex, bib)      — 引用/文献整合
    """
    return _load_skill()


# ------------------------------------------------------------------
# Active diagnostic tools (shared across writing MCPs)
# ------------------------------------------------------------------
def paper_writing_count_underlines(tex_path: str) -> dict:
    """TeX/LaTeX 内の下線コマンドを実測。論文では原則ゼロを目指す。

    目標: 0 (journal paper では strong/em で十分、下線は稀)
    警告: >=5 per page
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"file not found: {tex_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    macros = ["uline", "underline", "uwave", "uuline",
              "sout", "dashuline", "dotuline"]
    by_macro: dict[str, int] = {}
    total = 0
    for m in macros:
        n = len(re.findall(r"\\" + m + r"\{", text))
        if n:
            by_macro[m] = n
            total += n
    return {
        "file": str(p),
        "total_underlines": total,
        "by_macro": by_macro,
        "target_range": "0 (journal paper では 強調は \\emph / \\textbf)",
        "warning_threshold": ">=5 per page",
    }


def paper_writing_validate_pdf_pages(pdf_path: str, page_limit: int) -> dict:
    """PDF のページ数が投稿制限内か検証。pymupdf が必要。

    参考:
        IEEE Transactions: 規定なし (extended)、letter形式は 4 page
        IEEJ Transactions: 原著論文 8 pages 推奨、10 pages 上限
        APS PRL: 4 pages (本文+refs+fig)
        APS PRB: 制限なし (ページ課金あり)
        Elsevier JMMM: 制限なし
    """
    try:
        import pymupdf  # type: ignore
    except ImportError:
        return {"error": "pymupdf not installed. `pip install pymupdf`"}
    p = pathlib.Path(pdf_path)
    if not p.exists():
        return {"error": f"file not found: {pdf_path}"}
    doc = pymupdf.open(pdf_path)
    n = doc.page_count
    doc.close()
    return {
        "file": str(p),
        "page_count": n,
        "page_limit": page_limit,
        "within_limit": n <= page_limit,
        "pages_over": max(0, n - page_limit),
    }


def paper_writing_check_overfull_hbox(log_path: str) -> dict:
    """LaTeX ログ中の Overfull \\hbox 警告をカウント。journal では許容ゼロ。"""
    p = pathlib.Path(log_path)
    if not p.exists():
        return {"error": f"file not found: {log_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    matches = re.findall(
        r"Overfull \\hbox \(([^)]+)\) in paragraph at lines (\d+)(?:--(\d+))?",
        text,
    )
    details = [
        {"severity": m[0], "lines": m[1] + (f"-{m[2]}" if m[2] else "")}
        for m in matches[:20]
    ]
    return {
        "file": str(p),
        "overfull_count": len(matches),
        "overfull_details": details,
        "target": "0 (journal は許容なし)",
    }


def paper_writing_analyze_sentences(text: str, max_len: int = 80) -> dict:
    """文長分析 (和文)。journal では長文を避けて読みやすさ重視。

    目標: 平均 <= 60 字 / 文 (journal は grant 申請書より厳しめ)
    警告: 個別で >= 100 字 / 文

    引数:
        text: 解析対象の日本語テキスト
        max_len: 1 文の上限 (既定 80)
    """
    sentences = [s.strip() for s in re.split(r"[。．]", text) if s.strip()]
    if not sentences:
        return {"error": "no sentences found (no 。 or ．)"}
    lengths = [len(s) for s in sentences]
    avg = sum(lengths) / len(lengths)
    long_ones = [
        {"index": i, "length": ln, "head": s[:40] + ("..." if len(s) > 40 else "")}
        for i, (s, ln) in enumerate(zip(sentences, lengths))
        if ln > max_len
    ]
    return {
        "total_sentences": len(sentences),
        "avg_length": round(avg, 1),
        "max_length": max(lengths),
        "threshold": max_len,
        "over_threshold_count": len(long_ones),
        "over_threshold_examples": long_ones[:5],
        "target": f"avg <= 60 (journal), or avg <= {max_len}",
        "warning": "any sentence >= 100",
    }


def paper_writing_count_weak_expressions(text: str) -> dict:
    """弱気修飾語の出現数。journal 論文では conclusion / contribution で
    使うと査読で突っ込まれる (Reviewer 2 trigger)。

    目標: ゼロ (特に Abstract / Contribution 文)
    警告: >= 3 / ページ
    """
    patterns = {
        "と考えられる": r"と考えられ(る|ます)",
        "と思われる": r"と思われ(る|ます)",
        "ではないかと": r"ではないかと",
        "可能性がある": r"可能性が(ある|あります)",
        "示唆される": r"示唆され(る|ます)",
        "期待される": r"期待され(る|ます)",
        "ように思う": r"ように思(う|います|われる)",
        # English weak hedges (ACS / IEEE にも適用)
        "it seems": r"\bit seems\b",
        "might be": r"\bmight be\b",
        "could be": r"\bcould be\b",
        "tends to": r"\btends to\b",
    }
    by_pat: dict[str, int] = {}
    total = 0
    for name, pat in patterns.items():
        n = len(re.findall(pat, text, re.IGNORECASE))
        if n:
            by_pat[name] = n
            total += n
    return {
        "total_weak_expressions": total,
        "by_pattern": by_pat,
        "target": "0 in Abstract/Contribution, <=2 per page elsewhere",
        "warning": ">=3 per page (Reviewer 2 trigger)",
    }


# ------------------------------------------------------------------
# Paper-specific diagnostic tools
# ------------------------------------------------------------------
def paper_writing_validate_abstract_length(text: str,
                                            max_words: int = 250,
                                            max_chars_ja: int = 400) -> dict:
    """Abstract 字数 / 語数が制限内か検証。言語を自動判定。

    参考制限:
        IEEE Transactions: 200 words (structured abstract は 250)
        IEEJ 和文: 400 字
        APS: 250 words
        Elsevier: 200-300 words
    """
    # Crude language detection: if >30% of chars are CJK, treat as Japanese
    cjk = sum(1 for c in text if "぀" <= c <= "ヿ"
              or "一" <= c <= "鿿")
    ja_ratio = cjk / max(1, len(text))
    is_japanese = ja_ratio > 0.3

    if is_japanese:
        n = len(text.replace(" ", "").replace("\n", ""))
        limit = max_chars_ja
        unit = "chars (ja)"
    else:
        n = len(text.split())
        limit = max_words
        unit = "words (en)"

    return {
        "detected_language": "ja" if is_japanese else "en",
        "count": n,
        "unit": unit,
        "limit": limit,
        "within_limit": n <= limit,
        "excess": max(0, n - limit),
        "recommendation": (
            "Abstract は問題提起→手法→結果→意義 の 4 要素で構成。"
            "5-7 文が目安 (IEEE 200 words / IEEJ 400 字)。"
        ),
    }


def paper_writing_check_citation_usage(tex_path: str,
                                        bib_path: str = "") -> dict:
    """TeX 本文中の \\cite{} キーと bib file の entries を突合。
    未使用文献 / 未定義 cite を検出。

    引数:
        tex_path: 論文本体の .tex (メインファイル)
        bib_path: .bib ファイル (省略時は tex_path と同ディレクトリの *.bib)
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"tex file not found: {tex_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")

    # Collect all \cite{...} keys (multiple keys in one \cite separated by ,)
    cite_keys: set[str] = set()
    for m in re.finditer(r"\\(?:cite|citep|citet|autocite|parencite)\*?"
                         r"(?:\[[^\]]*\])?\{([^}]+)\}", text):
        for k in m.group(1).split(","):
            k = k.strip()
            if k:
                cite_keys.add(k)

    # Find bib file
    if bib_path:
        bibs = [pathlib.Path(bib_path)]
    else:
        bibs = list(p.parent.glob("*.bib"))
    if not bibs:
        return {
            "error": "no .bib file found (pass bib_path= or place *.bib next to tex)"
        }

    bib_entries: set[str] = set()
    for bp in bibs:
        btext = bp.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r"@\w+\s*\{\s*([^,\s]+)", btext):
            bib_entries.add(m.group(1))

    missing_in_bib = cite_keys - bib_entries  # cited but not in bib
    unused_in_tex = bib_entries - cite_keys   # in bib but not cited

    return {
        "tex_file": str(p),
        "bib_files": [str(b) for b in bibs],
        "total_citations": len(cite_keys),
        "total_bib_entries": len(bib_entries),
        "missing_in_bib_count": len(missing_in_bib),
        "missing_in_bib": sorted(missing_in_bib)[:20],
        "unused_in_tex_count": len(unused_in_tex),
        "unused_in_tex": sorted(unused_in_tex)[:20],
        "recommendation": (
            "missing_in_bib があれば .bib に追加。"
            "unused_in_tex が 5 件以上ある場合は refs を整理 "
            "(実際に論じていない文献の引用は査読者に嫌われる)。"
        ),
    }


def paper_writing_check_english_redflags(text: str) -> dict:
    """英文論文の典型的 red flag を検出 (冠詞、時制、自動詞/他動詞 の混同)。

    NOTE: 網羅的ではなく高頻度パターンのみ。通った後も native proof は
          推奨。
    """
    issues: list[dict] = []

    # Definite/indefinite article mis-use signals (limited heuristics)
    if re.search(r"\bIn the (paper|study|work)\b", text):
        issues.append({
            "pattern": "In the paper/study/work (without first reference)",
            "hint": "初出は 'In this paper/study/work'。'the' は既知物に限る。",
        })
    # Tense consistency (past result + present claim is fine, but all-past in
    # discussion is weak)
    # "will be" in future-work without section header
    if re.search(r"\bwe will\b", text, re.IGNORECASE):
        count = len(re.findall(r"\bwe will\b", text, re.IGNORECASE))
        issues.append({
            "pattern": f"'we will' appears {count} times",
            "hint": "Future work 以外では使わない。Method は過去形または現在形 で記述。",
        })
    # "Please refer to"
    if re.search(r"\bPlease refer to\b", text, re.IGNORECASE):
        issues.append({
            "pattern": "Please refer to",
            "hint": "論文調ではない。'See Section X' or 'Fig. Y shows ...' に置換。",
        })
    # "In order to" (can almost always be just "to")
    n_io = len(re.findall(r"\bIn order to\b", text, re.IGNORECASE))
    if n_io >= 3:
        issues.append({
            "pattern": f"'In order to' appears {n_io} times",
            "hint": "almost always replaceable with just 'to'. 冗長表現。",
        })
    # Capital after semicolon (subtle bug)
    if re.search(r";\s+[A-Z][a-z]", text):
        issues.append({
            "pattern": "Capital letter after semicolon",
            "hint": "セミコロン後は小文字が標準。'; However, ...' は '. However, ...' へ。",
        })
    # "which is" / "that is" redundancy
    n_wi = len(re.findall(r"\bwhich is\b", text, re.IGNORECASE))
    if n_wi >= 5:
        issues.append({
            "pattern": f"'which is' appears {n_wi} times",
            "hint": "'the coil, which is made of copper' -> 'the copper coil' が簡潔。",
        })
    # Passive voice over-use
    passive_count = len(re.findall(
        r"\b(is|are|was|were|been|being)\s+\w+ed\b", text))
    total_verbs_est = len(re.findall(r"\b\w+ed\b", text)) + 1
    passive_ratio = passive_count / total_verbs_est
    if passive_ratio > 0.4:
        issues.append({
            "pattern": f"High passive voice ratio ({passive_ratio:.0%})",
            "hint": "Method は passive 可だが Discussion/Contribution は active 推奨。",
        })

    return {
        "total_issues": len(issues),
        "issues": issues,
        "note": (
            "Heuristic のみ。最終的には native proof (IEEE Author Tools / "
            "DeepL Write / Grammarly Pro) を併用。"
        ),
    }


# ------------------------------------------------------------------
# Deep-learning diagnostic tools (from アクセプト術 2026-04-21 upgrade)
# ------------------------------------------------------------------

_BANNED_INTRO_OPENERS = [
    r"^\s*In this (paper|section|study|work|chapter)",
    r"^\s*This (paper|section|study|work) (presents|describes|deals)",
    r"^\s*Recent advances in",
    r"^\s*The last few years (have seen|has seen)",
    r"^\s*It is (well[- ]known|often said)",
    r"^\s*There (is|are) (many|several|a number)",
    r"^\s*First(ly)?\s*,",
    r"^\s*Several studies",
    r"^\s*Many (authors|researchers)",
]


def paper_writing_check_paragraph_opener(text: str) -> dict:
    """Introduction/Abstract の段落冒頭が禁断フレーズで始まるか検出。

    Wallwork §13.15, §14.11 のブラックリスト:
    - "In this paper, ..."
    - "Recent advances in ..."
    - "The last few years ..."
    - "It is well-known that ..."
    - "Several studies ..."

    目標: 0 (特に Abstract + Introduction の最初の段落)
    警告: >=2 / section
    """
    # Split paragraphs by blank lines
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    flagged: list[dict] = []
    for i, para in enumerate(paragraphs, start=1):
        first_line = para.split("\n", 1)[0]
        for pat in _BANNED_INTRO_OPENERS:
            if re.match(pat, first_line, re.IGNORECASE):
                flagged.append({
                    "paragraph_index": i,
                    "pattern": pat,
                    "head": first_line[:80],
                })
                break
    return {
        "total_paragraphs": len(paragraphs),
        "weak_opener_count": len(flagged),
        "flagged": flagged[:10],
        "target": "0 in Abstract/Intro opening paragraphs",
        "warning": ">=2 in a single section",
        "source": "Wallwork §13.15, §14.11",
    }


def paper_writing_check_paragraph_length(text: str,
                                          min_chars_ja: int = 150,
                                          max_chars_ja: int = 400,
                                          min_words_en: int = 75,
                                          max_words_en: int = 175,
                                          ) -> dict:
    """段落の字数/語数が適正範囲内か検出。

    目標:
        EN: 75-175 words/段落 (Wallwork §14.9)
        JP: 150-400 字/段落
    警告: >200 words / >500 字
    致命: >300 words / >800 字、または Introduction が 1 段落のみ

    引数:
        text: 複数段落の本文 (空行で区切る)
    """
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]

    def _is_japanese(s):
        cjk = sum(1 for c in s if "一" <= c <= "鿿" or "぀" <= c <= "ヿ")
        return cjk / max(1, len(s)) > 0.3

    lang_ja = _is_japanese(text)
    vmin = min_chars_ja if lang_ja else min_words_en
    vmax = max_chars_ja if lang_ja else max_words_en
    unit = "chars (ja)" if lang_ja else "words (en)"

    stats = []
    for i, para in enumerate(paragraphs, start=1):
        if lang_ja:
            n = len(para.replace(" ", "").replace("\n", ""))
        else:
            n = len(para.split())
        stats.append({"paragraph": i, "count": n,
                      "within": vmin <= n <= vmax})
    over_count = sum(1 for s in stats if s["count"] > vmax)
    way_over = sum(1 for s in stats if s["count"] > vmax * 1.5)
    under_count = sum(1 for s in stats if s["count"] < vmin)

    too_few_paragraphs = len(paragraphs) == 1 and sum(
        s["count"] for s in stats
    ) > vmin * 2

    return {
        "total_paragraphs": len(paragraphs),
        "language": "ja" if lang_ja else "en",
        "unit": unit,
        "target_range": f"{vmin}-{vmax} {unit}",
        "over_warn": over_count,
        "over_fatal": way_over,
        "under": under_count,
        "single_giant_paragraph": too_few_paragraphs,
        "per_paragraph": stats[:20],
        "source": "Wallwork §14.9",
    }


def paper_writing_check_abstract_background_ratio(abstract: str) -> dict:
    """Abstract 内で background (導入文) が占める割合を推定。

    Wallwork §13.16: >25% background は日本型 abstract で editor が reject。

    推定法: 第 1 文から順に、動詞に 'we'/'our' が無く数値結果が無い文を
    "background" として分類。数値 or 能動的動詞 (we propose/show/
    demonstrate/find/report) が出現した文から "content" に切替。

    Args:
        abstract: Abstract 本文のみ。
    """
    if not abstract.strip():
        return {"error": "abstract is empty"}
    # Split sentences: handle both .  and 。
    sentences = re.split(r"(?<=[.。])\s+", abstract.strip())
    sentences = [s for s in sentences if s.strip()]
    if not sentences:
        return {"error": "no sentences found"}

    background_chars = 0
    total_chars = 0
    break_index = None
    for i, s in enumerate(sentences):
        total_chars += len(s)
        has_digit = bool(re.search(r"\d", s))
        has_agent = bool(re.search(
            r"\b(we|our|I)\s+(propose|show|demonstrate|find|"
            r"report|present|develop|derive|measure|compare|"
            r"introduce)\b", s, re.IGNORECASE))
        if break_index is None:
            if has_digit or has_agent:
                break_index = i
            else:
                background_chars += len(s)

    ratio = background_chars / max(1, total_chars)
    return {
        "total_sentences": len(sentences),
        "background_break_index": break_index,
        "background_chars": background_chars,
        "total_chars": total_chars,
        "background_ratio": round(ratio, 3),
        "target": "<= 0.25 (Wallwork §13.16)",
        "warning": "> 0.25 (Japanese-style abstract)",
        "fatal": "> 0.40 (near-certain reject)",
    }


def paper_writing_check_figure_caption_showing(caption: str) -> dict:
    """Figure caption が showing (describe) 形か telling (claim) 形か判定。

    Wallwork §17.9: "Figure 4 shows X" (NG) より "X was observed (Fig. 4)"
    (OK)。caption の主語が figure ではなく主張動詞。

    Args:
        caption: 1 つの figure caption テキスト (Fig. 番号から末尾まで)
    """
    cap = caption.strip()
    if not cap:
        return {"error": "caption is empty"}

    # Detect "Fig. N shows/illustrates/presents ..." pattern
    tells = re.search(
        r"^(?:Fig(?:ure)?\.?\s*\d+)?\.?\s*"
        r"(shows|illustrates|presents|depicts|gives|describes)",
        cap, re.IGNORECASE
    )

    return {
        "caption_head": cap[:80],
        "is_showing_form": bool(tells),
        "recommendation": (
            "Convert to 'claim + (Fig. N)' form. "
            "NG: 'Figure 4 shows the relationship between A and B.' "
            "OK: 'The abundances of A and B were inversely related (Fig. 4).'"
        ) if tells else "OK: caption opens with a claim, not a describe verb.",
        "source": "Wallwork §17.9",
    }


def paper_writing_check_strong_adjective_budget(text: str) -> dict:
    """強調副詞/形容詞の過剰使用を検出。

    Wallwork §8.12: 2 個超で "hype" 判定、reader が信頼感を失う。

    目標: 全体で 2 個以内 (Abstract + Intro で 1-2 個 max)
    警告: 5 個超
    """
    patterns = {
        "remarkably": r"\bremarkably\b",
        "notably": r"\bnotably\b",
        "importantly": r"\bimportantly\b",
        "interestingly": r"\binterestingly\b",
        "novel": r"\bnovel\b",
        "innovative": r"\binnovative\b",
        "cutting-edge": r"\bcutting[- ]edge\b",
        "state-of-the-art": r"\bstate[- ]of[- ]the[- ]art\b",
        "crucial": r"\bcrucial\b",
        "groundbreaking": r"\bgroundbreaking\b",
        "significantly": r"\bsignificantly\b",
        "substantially": r"\bsubstantially\b",
    }
    by_pat = {}
    total = 0
    for name, pat in patterns.items():
        n = len(re.findall(pat, text, re.IGNORECASE))
        if n:
            by_pat[name] = n
            total += n
    return {
        "total_strong_adjectives": total,
        "by_adjective": by_pat,
        "target": "<=2 overall (Wallwork §8.12)",
        "warning": ">=5 overall",
        "note": (
            "Strong modifiers above threshold signal hype. Replace with "
            "quantitative claims: 'substantially faster' -> '3.2x faster "
            "(Table II)'."
        ),
    }


# ------------------------------------------------------------------
# v0.4.0: 即戦力 5 tools (IMRAD / tense / self-cite / forward-ref / eq-numbering)
# ------------------------------------------------------------------

_IMRAD_TARGETS = {
    "Abstract":    (0.04, 0.08),   # 4-8% (target ~5%)
    "Introduction":(0.12, 0.20),   # 12-20% (target ~15%)
    "Method":      (0.20, 0.30),   # 20-30% (target ~25%)
    "Result":      (0.25, 0.35),   # 25-35% (target ~30%)
    "Discussion":  (0.15, 0.25),   # 15-25% (target ~20%)
    "Conclusion":  (0.03, 0.08),   # 3-8% (target ~5%)
}


def paper_writing_check_imrad_balance(text: str) -> dict:
    """IMRAD 各セクションの字数バランスを検証する。

    Wallwork §14 の推奨: Intro 15% / Method 25% / Result 30% / Discussion 20%
    / Conclusion 5% / Abstract 5%。Japanese section headers (序論/方法/結果/
    考察/結論/Abstract) も English (Introduction/Methods/Results/Discussion/
    Conclusion/Abstract) も検出。

    Args:
        text: tex/md 本文全体。section header は `\\section{...}`, `## ...`,
              or bare 「序論」「1. 序論」等を検出。

    Returns:
        dict: section_lengths (chars/words), ratios, deviations from target.
    """
    # Section boundary patterns (bilingual)
    section_markers = {
        "Abstract":     r"(?:\\section\*?\{.*?(?:Abstract|要旨|概要)\}|^#+\s*(?:Abstract|要旨|概要))",
        "Introduction": r"(?:\\section\*?\{.*?(?:Introduction|序論|はじめに|緒言)\}|^#+\s*(?:Introduction|序論|はじめに))",
        "Method":       r"(?:\\section\*?\{.*?(?:Method|Methods|手法|方法|実験方法)\}|^#+\s*(?:Method|手法|方法))",
        "Result":       r"(?:\\section\*?\{.*?(?:Result|Results|結果|実験結果)\}|^#+\s*(?:Result|結果))",
        "Discussion":   r"(?:\\section\*?\{.*?(?:Discussion|考察|議論)\}|^#+\s*(?:Discussion|考察))",
        "Conclusion":   r"(?:\\section\*?\{.*?(?:Conclusion|結論|結言|まとめ)\}|^#+\s*(?:Conclusion|結論|まとめ))",
    }
    # Find positions
    positions = {}
    for name, pat in section_markers.items():
        m = re.search(pat, text, re.MULTILINE | re.IGNORECASE)
        if m:
            positions[name] = m.start()
    if len(positions) < 3:
        return {
            "error": "Could not identify IMRAD sections (need >=3)",
            "sections_found": list(positions.keys()),
            "hint": "Use standard section headers (\\section{...} or ## ...)",
        }

    # Sort by position
    ordered = sorted(positions.items(), key=lambda kv: kv[1])
    section_lengths = {}
    for i, (name, start) in enumerate(ordered):
        end = ordered[i+1][1] if i + 1 < len(ordered) else len(text)
        section_lengths[name] = end - start

    total = sum(section_lengths.values())
    ratios = {name: (ln / total) for name, ln in section_lengths.items()}

    deviations = []
    for name, ratio in ratios.items():
        lo, hi = _IMRAD_TARGETS.get(name, (0.0, 1.0))
        if ratio < lo:
            deviations.append({"section": name, "ratio": round(ratio, 3),
                               "target_range": [lo, hi],
                               "verdict": f"{name} too short ({ratio:.1%} < {lo:.0%})"})
        elif ratio > hi:
            deviations.append({"section": name, "ratio": round(ratio, 3),
                               "target_range": [lo, hi],
                               "verdict": f"{name} too long ({ratio:.1%} > {hi:.0%})"})
    return {
        "sections_found": [name for name, _ in ordered],
        "section_lengths_chars": section_lengths,
        "section_ratios": {k: round(v, 3) for k, v in ratios.items()},
        "deviations": deviations,
        "target": "Intro 15%, Method 25%, Result 30%, Discussion 20%, Concl 5%",
        "source": "Wallwork §14 + IMRAD conventions",
    }


def paper_writing_check_tense_consistency(text: str,
                                            section: str = "Discussion") -> dict:
    """Discussion の 3-part tense (hypothesis=現在, result=過去, background=現在完了) 混在検出。

    佐藤 Q32 + Wallwork §14.8 の標準:
      - Hypothesis: present tense ("X *is* a stimulant")
      - Your result: past tense ("the distance *was* associated")
      - Established background: present perfect ("X *has been shown* to ...")

    Args:
        text: 検査対象の英語 discussion 本文
        section: "Discussion" (default), "Method", "Result" 等。Methodの場合は
                 過去形チェックのみ。

    Returns:
        dict: mismatched sentences count + examples.
    """
    # English sentences
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    if not sents:
        return {"error": "no sentences found"}

    issues = []
    # Hypothesis markers (should be present)
    hypothesis_pat = re.compile(r"\bhypothesi[sz]\w*\b|\b(?:our|the) hypothesis\b", re.I)
    # Result reference markers (Fig. N, Table N, we found/observed) → past
    result_pat = re.compile(r"\b(?:Fig\.?|Figure|Table)\s*\d+|\bwe (?:found|observed|measured|showed|demonstrated)\b", re.I)
    # Background markers
    bg_pat = re.compile(r"\b(?:has been|have been|it is (?:well[- ]known|known))\b", re.I)

    past_tense_pat = re.compile(r"\b(?:was|were|had|had been)\b", re.I)
    present_tense_pat = re.compile(r"\b(?:is|are|has|have)\b(?! been)", re.I)

    for i, s in enumerate(sents):
        has_hyp = bool(hypothesis_pat.search(s))
        has_res = bool(result_pat.search(s))
        has_past = bool(past_tense_pat.search(s))
        has_pres = bool(present_tense_pat.search(s))

        if has_hyp and has_past and not has_pres:
            issues.append({
                "index": i, "type": "hypothesis_in_past",
                "sentence": s[:120],
                "hint": "Hypothesis should be present tense.",
            })
        elif has_res and has_pres and not has_past:
            issues.append({
                "index": i, "type": "result_in_present",
                "sentence": s[:120],
                "hint": "Your specific result should be past tense.",
            })
    return {
        "section": section,
        "total_sentences": len(sents),
        "issues": issues[:15],
        "issue_count": len(issues),
        "source": "佐藤 Q32 + Wallwork §14.8",
    }


def paper_writing_check_self_citation_ratio(tex_path: str,
                                              bib_path: str = "",
                                              author_last_names: str = "") -> dict:
    """自己引用率を算出。Wallwork: <20% 推奨。

    Args:
        tex_path: .tex ファイル
        bib_path: .bib ファイル (省略時は同ディレクトリの *.bib)
        author_last_names: 自著と判定する著者の姓 (カンマ区切り、
                            例: "Sugahara,Hane,Hollaus")

    Returns:
        dict: total_citations, self_citations, ratio, flagged.
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"tex file not found: {tex_path}"}
    tex = p.read_text(encoding="utf-8", errors="replace")
    if bib_path:
        bibs = [pathlib.Path(bib_path)]
    else:
        bibs = list(p.parent.glob("*.bib"))
    if not bibs:
        return {"error": "no .bib file found"}

    authors = {a.strip() for a in author_last_names.split(",") if a.strip()}
    if not authors:
        return {"error": "provide author_last_names (comma-separated)"}

    # Parse bib entries with a brace-balanced scanner.
    # Naive regex like r"@\w+\s*\{([^@]*)" breaks on stray '@' inside fields
    # (e.g. url = {...@doi.org/...}, email = {foo@bar}), and on nested braces
    # inside author fields (e.g. {Sugahara, K. and Hane, {M.}}).
    def _extract_balanced(text: str, start: int) -> tuple[int, str]:
        """Given text[start] == '{', return (end_index_after_closing_brace, inner).
        Tracks brace depth, ignoring braces in comments is not needed for .bib.
        Returns (-1, "") if no matching close brace is found."""
        assert text[start] == "{"
        depth = 0
        i = start
        n = len(text)
        while i < n:
            c = text[i]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    return i + 1, text[start + 1 : i]
            i += 1
        return -1, ""

    bib_entries = {}
    for bp in bibs:
        btxt = bp.read_text(encoding="utf-8", errors="replace")
        # Find each @type{ header.
        for hdr in re.finditer(r"@\w+\s*\{", btxt):
            brace_start = hdr.end() - 1  # position of '{'
            entry_end, entry_body = _extract_balanced(btxt, brace_start)
            if entry_end < 0:
                continue
            # The entry body starts with:  <whitespace><cite_key>,<fields...>
            key_match = re.match(r"\s*([^,\s]+)\s*,", entry_body)
            if not key_match:
                continue
            key = key_match.group(1)
            fields_region = entry_body[key_match.end():]
            # Find author = { ... } with brace balancing (value may contain
            # nested braces like {Sugahara, K. and Hane, {M.}}).
            author_value = ""
            for am in re.finditer(r"author\s*=\s*", fields_region, re.IGNORECASE):
                vstart = am.end()
                if vstart >= len(fields_region):
                    break
                vc = fields_region[vstart]
                if vc == "{":
                    _, inner = _extract_balanced(fields_region, vstart)
                    author_value = inner
                    break
                if vc == '"':
                    # Quoted value: up to the next unescaped ".
                    end_q = fields_region.find('"', vstart + 1)
                    if end_q > 0:
                        author_value = fields_region[vstart + 1 : end_q]
                    break
                # Bare value (unusual): up to comma or end of entry.
                end_bare = re.search(r"[,\n]", fields_region[vstart:])
                author_value = (
                    fields_region[vstart : vstart + end_bare.start()]
                    if end_bare
                    else fields_region[vstart:]
                )
                break
            bib_entries[key] = author_value

    # Find all \cite{...} keys
    cite_keys = set()
    for m in re.finditer(r"\\(?:cite|citep|citet|parencite|autocite)\*?(?:\[[^\]]*\])?\{([^}]+)\}", tex):
        for k in m.group(1).split(","):
            if k.strip():
                cite_keys.add(k.strip())

    total = len(cite_keys)
    self_cites = []
    for key in cite_keys:
        author_field = bib_entries.get(key, "")
        if any(a in author_field for a in authors):
            self_cites.append(key)

    ratio = len(self_cites) / max(1, total)
    return {
        "total_citations": total,
        "self_citation_count": len(self_cites),
        "self_citation_ratio": round(ratio, 3),
        "self_citation_keys": self_cites[:20],
        "authors_checked": sorted(authors),
        "target": "<=0.20 (Wallwork §)",
        "warning": ">=0.30",
        "verdict": "OK" if ratio <= 0.20 else "WARN" if ratio < 0.30 else "HIGH",
    }


def paper_writing_check_figure_forward_reference(tex_path: str) -> dict:
    """図/表の \\label と \\ref の整合チェック (孤立ラベル / 未解決参照)。

    NOTE: ソース上での順序 (\\ref が \\label より前にあるか) は LaTeX の
    forward-reference 違反ではない。\\begin{figure}[htbp] は float なので、
    組版後の物理ページ位置はソース順序と無関係に決まる。むしろ
    「本文で先に導入 → \\begin{figure} は近くの任意位置」が推奨パターン。
    ソース順序の判定が必要なら PDF レベル (\\pageref や pdftotext) で行う。

    この関数は次の2点のみを検査する:
    - orphan_labels: \\label{fig:...}/\\label{tab:...} あるが \\ref されない
    - dangling_refs: \\ref{fig:...} あるが該当 \\label が存在しない

    Args:
        tex_path: .tex ファイル

    Returns:
        dict: labels_defined, refs_used, orphan_labels, dangling_refs.
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"tex file not found: {tex_path}"}
    tex = p.read_text(encoding="utf-8", errors="replace")

    # Collect figure/table labels and references.
    labels_defined = set()
    for m in re.finditer(r"\\label\{((?:fig|tab|table):[^}]+)\}", tex):
        labels_defined.add(m.group(1))
    refs_used = set()
    for m in re.finditer(
        r"\\(?:ref|autoref|Cref|cref|vref)\*?\{((?:fig|tab|table):[^}]+)\}",
        tex,
    ):
        refs_used.add(m.group(1))

    orphan_labels = sorted(labels_defined - refs_used)
    dangling_refs = sorted(refs_used - labels_defined)
    return {
        "labels_defined": sorted(labels_defined),
        "refs_used": sorted(refs_used),
        "orphan_labels": orphan_labels,
        "dangling_refs": dangling_refs,
        "orphan_label_count": len(orphan_labels),
        "dangling_ref_count": len(dangling_refs),
        "verdict": "OK" if not orphan_labels and not dangling_refs else "CHECK",
        "hint": (
            "ソース順序は LaTeX の float 仕様上違反ではない (PDF レベルで確認を)。"
            "ここでは orphan ラベル (定義したが参照なし) と "
            "dangling 参照 (未定義ラベルへの \\ref) のみ検出する。"
        ),
    }


def paper_writing_check_equation_numbering(tex_path: str) -> dict:
    """方程式番号 (1), (2), ... の連番欠落 / 重複をチェック。

    LaTeX の `\\begin{equation}` / `\\begin{align}` は自動採番だが、
    \\tag{} 手動指定や引用 (\\ref{eq:foo}) の欠落・不一致を検出。

    Args:
        tex_path: .tex ファイル
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"tex file not found: {tex_path}"}
    tex = p.read_text(encoding="utf-8", errors="replace")

    # Count display-math environments (approximate sequential number).
    # Includes starred (un-numbered) variants — we count them so counts reflect
    # actual math density; \eqref detection below still only matches numbered
    # \label targets so starred envs naturally drop out of cross-ref checks.
    equation_envs = len(
        re.findall(
            r"\\begin\{(?:equation|align|gather|multline|eqnarray|flalign)\*?\}"
            r"|\\\[",
            tex,
        )
    )
    # Find equation labels
    eq_labels = set()
    for m in re.finditer(r"\\label\{(eq:[^}]+)\}", tex):
        eq_labels.add(m.group(1))
    # Find equation references
    eq_refs = {}
    for m in re.finditer(r"\\(?:ref|eqref|autoref|Cref)\*?\{(eq:[^}]+)\}", tex):
        key = m.group(1)
        eq_refs[key] = eq_refs.get(key, 0) + 1

    # Dangling refs (referenced but not labeled)
    dangling = [k for k in eq_refs if k not in eq_labels]
    # Unused labels (labeled but not referenced)
    unused = [k for k in eq_labels if k not in eq_refs]

    return {
        "equation_environments": equation_envs,
        "labeled_equations": len(eq_labels),
        "unique_references": len(eq_refs),
        "total_ref_usage": sum(eq_refs.values()),
        "dangling_refs": dangling[:10],
        "unused_labels": unused[:10],
        "verdict": (
            "OK" if not dangling and not unused else "CHECK"
        ),
    }


# ------------------------------------------------------------------
# v0.4.0: 中期 5 tools (cover letter / response / classifier / passive / ref-fmt)
# ------------------------------------------------------------------

def paper_writing_generate_cover_letter(journal: str,
                                          title: str,
                                          abstract: str,
                                          contribution: str = "",
                                          corresponding_author: str = "",
                                          ) -> str:
    """投稿 cover letter の skeleton を生成。

    journal の特徴に触れ、why this journal / what's new / why now の
    3 点を押さえたテンプレを返す。ユーザーが細部を埋める前提。

    Args:
        journal: 投稿先 (例: "IEEE Transactions on Magnetics")
        title: 論文タイトル
        abstract: abstract 本文 (200-250 words)
        contribution: 箇条書きした貢献 (任意、改行区切り)
        corresponding_author: 対応著者名

    Returns:
        cover letter テンプレ (plain text)
    """
    corr = corresponding_author or "Kengo Sugahara"
    contrib_lines = ""
    if contribution:
        lines = [f"  - {c.strip()}" for c in contribution.split("\n") if c.strip()]
        contrib_lines = "\n".join(lines)

    return f"""[Date: YYYY-MM-DD]

To the Editor-in-Chief,
{journal}

Dear Editor,

We are pleased to submit our manuscript titled

  "{title}"

for consideration for publication in {journal}.

**Why this journal**
[1-2 sentences on fit between paper scope and journal's 対象分野.
Reference specific journal sections or past influential papers if relevant.]

**What is new**
{abstract[:400]}{"..." if len(abstract) > 400 else ""}

{f"**Contributions**{chr(10)}{contrib_lines}" if contribution else ""}

**Why now**
[1-2 sentences on timeliness. Why is this problem acute *now*?
Recent paradigm shifts, new measurement capabilities, recent
competing but incomplete works, policy/industry drivers.]

All authors have approved the manuscript and consent to its
submission. The work has not been published elsewhere and is not
under consideration by any other journal. We have no conflicts of
interest to declare.

Sincerely,
{corr}
(corresponding author)
[Affiliation / email / phone]
"""


def paper_writing_generate_response_letter(reviewer_comment: str,
                                             agreement_stance: str = "agree",
                                             response_draft: str = "",
                                             page_line_ref: str = "") -> str:
    """Reviewer コメントへの応答文テンプレ (佐藤 Q40 "agree first, pivot")。

    Args:
        reviewer_comment: 査読者コメント本文
        agreement_stance: "agree" (素直に受入), "partial" (一部受入+代替),
                           "disagree" (根拠を示して丁寧に不同意)
        response_draft: ユーザーが用意した応答の核 (任意)
        page_line_ref: 修正箇所 (例: "P11, L21-L25")

    Returns:
        response letter fragment (plain text)
    """
    stem = f"> {reviewer_comment.strip()}\n\n"
    if agreement_stance == "agree":
        return stem + f"""**Response**: We thank the reviewer for this valuable comment. We fully agree, and have revised the manuscript accordingly.

{response_draft}

The change has been incorporated at {page_line_ref or "[P__, L__]"}.
"""
    elif agreement_stance == "partial":
        return stem + f"""**Response**: We agree with the reviewer in that [reviewer の懸念を寛容に restate]. Unfortunately, [技術的制約 or scope 制限] makes the exact requested change infeasible in the current manuscript. Instead, we have introduced [代替 approach], which addresses the spirit of the reviewer's concern.

{response_draft}

The revised text is at {page_line_ref or "[P__, L__]"}, and Fig./Table N has been updated accordingly.
"""
    else:  # disagree
        return stem + f"""**Response**: We appreciate the reviewer's careful reading. We respectfully disagree with this point because [理由を具体データ + 引用で]. To clarify this in the manuscript, we have revised the text at {page_line_ref or "[P__, L__]"} to make our reasoning explicit.

{response_draft}

We hope this clarification addresses the reviewer's concern.
"""


def paper_writing_classify_reviewer_comment(comment: str) -> dict:
    """Reviewer コメントを佐藤 Q40 の 4-tier に自動分類。

    Difficulty:
      A: typo / 明確提案 (行動: そのまま直す)
      B: 書き直し or 引用追加要求 (行動: 同意 → 根拠 → 改訂文)
      C: 追加実験 / 追加解析要求 (行動: 範囲判定、editor に延長申請)
      D: 技術的に不可能 (行動: agree-first → 理由 → 代替提案)

    Args:
        comment: reviewer コメント 1 件

    Returns:
        dict: difficulty, confidence, triggers, suggested_stance.
    """
    c = comment.lower()
    # D-level: "impossible", "fundamental flaw", "reject" strong
    if any(k in c for k in ("fundamental flaw", "completely wrong",
                             "unable to be fixed", "intractable")):
        return {"difficulty": "D", "confidence": "medium",
                "suggested_stance": "partial-or-disagree",
                "hint": "技術的に不可能な要求。agree first で受け止め、代替提案を用意。"}
    # C-level: demands experiment/data
    if any(k in c for k in ("additional experiment", "new dataset",
                             "please measure", "please compare with",
                             "追加実験", "追加データ", "比較実験")):
        return {"difficulty": "C", "confidence": "high",
                "suggested_stance": "assess feasibility",
                "hint": ("追加実験 / 追加解析要求。実行可能性と期限を "
                          "editor に相談。"),
                "triggers": ["additional experiment / data request"]}
    # B-level: rewrite / citation
    if any(k in c for k in ("unclear", "please clarify", "please cite",
                             "missing reference", "more detail",
                             "明確に", "根拠を示", "引用", "不明瞭")):
        return {"difficulty": "B", "confidence": "high",
                "suggested_stance": "agree",
                "hint": "書き直し + 引用追加。同意して改訂版をインラインで提示。",
                "triggers": ["rewrite / citation request"]}
    # A-level: typo / simple
    if any(k in c for k in ("typo", "grammar", "spelling", "missing comma",
                             "fig.\\s*\\d+ caption", "誤植", "スペル")):
        return {"difficulty": "A", "confidence": "high",
                "suggested_stance": "agree",
                "hint": "Typo / 軽微な指摘。すぐ直して "
                         "'This has been corrected' で応答。",
                "triggers": ["typo / minor"]}
    # Default: B-level (safest)
    return {"difficulty": "B?", "confidence": "low",
            "suggested_stance": "agree-and-rewrite",
            "hint": ("明示的な keyword が無いため B-level 想定で初期応答。"
                      "内容を再読して C (実験要求) や D (不可能) に escalate "
                      "する可能性を確認。"),
            "triggers": []}


def paper_writing_check_passive_voice_ratio(text: str) -> dict:
    """英文の受動態比率を推定。Wallwork §8: Methods は passive 可、
    Discussion / Contribution は active 推奨 (ratio <= 0.40 目安)。

    Args:
        text: 検査対象の英文

    Returns:
        dict: passive_count, active_est, ratio, verdict.
    """
    # Crude heuristic: "be verb + past participle (ed|en)"
    passive_pat = re.compile(
        r"\b(?:am|is|are|was|were|be|been|being|get|gets|got|gotten)\s+\w+(?:ed|en)\b",
        re.IGNORECASE,
    )
    # Total verbs approximate: past tense verbs + "is/are" etc.
    verb_approx_pat = re.compile(
        r"\b\w+(?:ed|ing|s)\b|\b(?:is|are|was|were|be|have|has|had)\b",
        re.IGNORECASE,
    )
    passives = len(passive_pat.findall(text))
    verbs = len(verb_approx_pat.findall(text))
    ratio = passives / max(1, verbs)
    return {
        "passive_count": passives,
        "verb_count_approx": verbs,
        "passive_ratio": round(ratio, 3),
        "target": "<= 0.40 in Discussion/Contribution",
        "verdict": "OK" if ratio <= 0.40 else "HIGH",
        "hint": "Passive 多用は行為者不明でドラマ性を失う。Discussion は "
                "'We demonstrate', 'Our results show' 等 active に置換推奨。",
        "source": "Wallwork §8 + 木下 p.140",
    }


def paper_writing_lint_reference_format(bib_path: str) -> dict:
    """.bib の reference エントリーの完全性と形式を検証。

    チェック項目:
      - year フィールド欠落
      - DOI 欠落 (publisher が DOI 付ける era で重要)
      - pages 欠落 (journal 記事)
      - author フィールド形式 (lastname, firstname or firstname lastname)

    Args:
        bib_path: .bib ファイル

    Returns:
        dict: per-entry missing fields.
    """
    p = pathlib.Path(bib_path)
    if not p.exists():
        return {"error": f"bib not found: {bib_path}"}
    txt = p.read_text(encoding="utf-8", errors="replace")

    entries = []
    # Parse each @article{...} block
    for m in re.finditer(r"@(\w+)\s*\{\s*([^,\s]+)\s*,([^@]*)(?=@|\Z)",
                          txt + "@END", re.DOTALL):
        entry_type = m.group(1).lower()
        key = m.group(2)
        if entry_type == "end":
            continue
        body = m.group(3)
        fields = {}
        for fm in re.finditer(
            r"(\w+)\s*=\s*[{\"]([^}\"]*)[}\"]",
            body,
        ):
            fields[fm.group(1).lower()] = fm.group(2)
        missing = []
        if not fields.get("year"):
            missing.append("year")
        if not fields.get("author"):
            missing.append("author")
        if entry_type in ("article", "inproceedings"):
            if not fields.get("title"):
                missing.append("title")
            if entry_type == "article" and not fields.get("journal"):
                missing.append("journal")
            if entry_type == "inproceedings" and not fields.get("booktitle"):
                missing.append("booktitle")
            if not fields.get("pages"):
                missing.append("pages (optional but recommended)")
            if not fields.get("doi"):
                missing.append("doi (recommended)")
        entries.append({"key": key, "type": entry_type,
                         "missing_fields": missing})

    total = len(entries)
    with_missing = [e for e in entries if e["missing_fields"]]
    return {
        "total_entries": total,
        "entries_with_missing_fields": len(with_missing),
        "problems": with_missing[:20],
        "hint": "year/author/title は必須。IEEE 系は DOI 推奨、pages は journal で必要。",
    }


# ---------------------------------------------------------------------------
# v0.8.0 — 中島・塚本『知的な科学・技術文章の書き方』由来の 2 tools
# ---------------------------------------------------------------------------

_REPETITION_STOP_WORDS = {
    # 頻出で意味の薄い語は除外 (助動詞的)
    "こと", "これ", "それ", "この", "その", "ため", "ところ",
    "とき", "もの", "など", "ほど", "まま", "ただ", "ただし",
    "および", "または", "ならびに", "さらに", "しかし", "しかも",
    "研究", "本研究", "本稿", "本論文", "論文", "結果", "方法",
    "実験", "解析", "評価", "検討", "考察", "目的",
    "図", "表", "式", "Fig", "Table", "Eq",
}


def paper_writing_check_word_repetition(
    text: str,
    window_chars: int = 40,
    min_len: int = 2,
    max_findings: int = 40,
) -> dict:
    """同一単語の近接障害を検出する (中島・塚本『知的な科学・技術文章の書き方』§1.3.5)。

    **問題**: 同じ単語が狭い窓内で繰り返されると "幼稚な印象" を与える。
    本家の例: 「大きく変化し...影響は大きく...大きく進展している」→
    「急速に / 絶大 / 大規模」等、類語で書き換えるべき。

    **検出ロジック**:
    1. テキストから **漢字 2 字以上 / カタカナ 3 字以上 / 英単語** を token として抽出
       (ひらがな・助詞は対象外 — 繰り返し自然なため)
    2. 各 token について `window_chars` 以内で再登場があれば findings に追加
    3. `_REPETITION_STOP_WORDS` (論文特有の頻出語) は除外

    Args:
        text: 検査対象テキスト。
        window_chars: 近接とみなす最大距離 (既定 40 字、中島・塚本の例に合わせる)。
        min_len: 検出対象 token の最小長 (既定 2)。
        max_findings: 返却する findings の上限 (既定 40)。

    Returns:
        {total_findings, unique_repeated_words, findings: [{word, distance,
          first_pos, second_pos, context}, ...], hint, source}

    **注意**: 数値は hint として使う。技術用語 (ESIM 等) の反復は避け
    られないケースもあるので、全件修正は推奨しない。
    """
    import re as _re
    # Kanji / Katakana / English word tokens
    # Hiragana-only sequences are excluded (particles / conjugation endings)
    token_re = _re.compile(
        r"[一-龥]{" + str(min_len) + r",}"       # Kanji run
        r"|[ァ-ヴー]{3,}"                         # Katakana run (3+)
        r"|[A-Za-z][A-Za-z0-9\-]{1,}"             # English word
    )

    tokens: list[tuple[str, int]] = []
    for m in token_re.finditer(text):
        w = m.group(0)
        if w in _REPETITION_STOP_WORDS:
            continue
        tokens.append((w, m.start()))

    findings = []
    seen_pairs: set[tuple[str, int, int]] = set()
    for i, (w, pos) in enumerate(tokens):
        for j in range(i + 1, len(tokens)):
            w2, pos2 = tokens[j]
            if pos2 - pos > window_chars:
                break
            if w == w2:
                key = (w, pos, pos2)
                if key in seen_pairs:
                    continue
                seen_pairs.add(key)
                cs = max(0, pos - 15)
                ce = min(len(text), pos2 + len(w2) + 15)
                findings.append({
                    "word": w,
                    "distance": pos2 - pos,
                    "first_pos": pos,
                    "second_pos": pos2,
                    "context": text[cs:ce].replace("\n", " "),
                })

    unique_words = sorted({f["word"] for f in findings})
    findings.sort(key=lambda f: f["distance"])

    return {
        "total_findings": len(findings),
        "unique_repeated_words": unique_words,
        "findings": findings[:max_findings],
        "window_chars": window_chars,
        "hint": (
            "同一単語の近接障害 (中島・塚本 §1.3.5) を検出。類語辞書で "
            "書き換え推奨。ただし **技術用語** (固有名詞・データ名) は "
            "反復が避けられないので全件修正は不要、hint として使うこと。"
        ),
        "source": "中島利勝・塚本真也『知的な科学・技術文章の書き方』"
                  "コロナ社 1996, §1.3.5 同一単語の近接障害",
    }


_SENTENCE_END_PATTERNS = [
    # (label, regex of ending — matches last few chars before the punctuation)
    ("である", r"である$"),
    ("だ",       r"だ$"),
    ("ある",     r"(?<!で)ある$"),
    ("ない",     r"ない$"),
    ("した",     r"した$"),
    ("された",   r"された$"),
    ("する",     r"する$"),
    ("される",   r"される$"),
    ("られる",   r"られる$"),
    ("考えられる", r"考えられる$"),
    ("思われる", r"思われる$"),
    ("示す",     r"示す$"),
    ("示した",   r"示した$"),
    ("得た",     r"得た$"),
    ("得る",     r"得る$"),
]


def paper_writing_check_sentence_ending_variety(
    text: str,
    consecutive_threshold: int = 3,
) -> dict:
    """文末表現の単調さ / 連続を検出 (中島・塚本 §1.3.2)。

    **問題**: 文末が「...である。...である。...である。」「...した。...した。」
    と続くと単調で幼稚。本家の例:
      「...である。...がある。...報告がある。...でもある。...代替フロンである。...」
    → 「...と考えられる / ...を示す / ...が報告されている」等で変化をつける。

    **ロジック**:
    1. 句点 (。．.) で文分割
    2. 各文の末尾 (句点直前 15 字) を `_SENTENCE_END_PATTERNS` で分類
    3. 同一 ending が `consecutive_threshold` 連続で発生したら "critical" に
    4. 全文末の histogram + entropy + 連続区間を返す

    Args:
        text: 検査対象テキスト。
        consecutive_threshold: 同一 ending がこの回数連続したら critical (既定 3)。

    Returns:
        {total_sentences, ending_histogram, shannon_entropy_bits,
         critical_runs: [{ending, start_index, length}], hint, source}
    """
    import math as _math
    import re as _re
    sentences = [s.strip() for s in _re.split(r"[。．\.!?！？]", text) if s.strip()]
    if not sentences:
        return {
            "total_sentences": 0,
            "ending_histogram": {},
            "shannon_entropy_bits": 0.0,
            "critical_runs": [],
            "hint": "no sentences found",
            "source": "中島・塚本 §1.3.2",
        }

    labels: list[str] = []
    for s in sentences:
        tail = s[-12:] if len(s) > 12 else s
        hit = "other"
        for lbl, pat in _SENTENCE_END_PATTERNS:
            if _re.search(pat, tail):
                hit = lbl
                break
        labels.append(hit)

    # Histogram
    hist: dict[str, int] = {}
    for lbl in labels:
        hist[lbl] = hist.get(lbl, 0) + 1

    # Shannon entropy (bits) — higher = more varied
    total = sum(hist.values())
    entropy = 0.0
    if total > 0:
        for v in hist.values():
            p = v / total
            if p > 0:
                entropy -= p * _math.log2(p)

    # Critical consecutive runs
    critical: list[dict] = []
    i = 0
    while i < len(labels):
        j = i
        while j + 1 < len(labels) and labels[j + 1] == labels[i]:
            j += 1
        run_len = j - i + 1
        if run_len >= consecutive_threshold and labels[i] != "other":
            critical.append({
                "ending": labels[i],
                "start_sentence_index": i,
                "length": run_len,
                "sample": sentences[i][-40:] if len(sentences[i]) > 40
                           else sentences[i],
            })
        i = j + 1

    return {
        "total_sentences": len(sentences),
        "ending_histogram": dict(sorted(hist.items(), key=lambda kv: -kv[1])),
        "shannon_entropy_bits": round(entropy, 3),
        "critical_runs": critical,
        "consecutive_threshold": consecutive_threshold,
        "hint": (
            "文末が `である` / `した` / `ある` 等で単調に続くと幼稚な印象。"
            "hint として使い、全件機械置換は NG — 論理的に同じ形が "
            "必要な文もある。3 連続以上の critical_runs に注目。"
        ),
        "source": "中島利勝・塚本真也『知的な科学・技術文章の書き方』"
                  "コロナ社 1996, §1.3.2 変化に富む場所へ落とす文末表現",
    }
