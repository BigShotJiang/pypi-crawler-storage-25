"""Plan B T13 — 予算・経費記述の論理整合検査.

申請書中の金額トークンを regex で抽出し、費目の平衡 (JSPS 経費区分: 物品費・
旅費・人件費・その他)、合計額と積み上げ和の整合、単価×個数の算数を
検査する粗い lint。

設計方針:
- score は 0-10 の粗い温度計。
- PRIMARY OUTPUT は comments (転記ミス / 計算式ミスの指摘を人間風に)。
- observations は raw measurement。
- regex ベースのため表組みや LaTeX tabular の中身は unreliable。
"""

from __future__ import annotations

import re


_SOURCE = (
    "grant-writing tool (2026-04-23 新規) — "
    "申請書予算論理整合 / JSPS 経費区分"
)

_HINT = (
    "regex ベースの粗い検証。LaTeX tabular 内のセル金額は事前に平坦化して"
    "解析しているが、マクロ経由の数値 (\\price{...} 等) は拾えない。"
    "comments を起点に原典 (申請書 PDF or xlsx) で再確認。"
    "特に合計差異は転記ミスより計算式ミスの方が多いので単価をまず疑う。"
)


# -------------------------------------------------------------------
# LaTeX tabular 前処理
#
# 申請書の経費表は LaTeX の \\begin{tabular}{...}...\\end{tabular} で
# 組まれることが多く、セルは & 区切り、行末は \\\\、水平線は \\hline などで
# 構成されている。regex で金額を拾うために、これらを空白・改行に平坦化する。
# -------------------------------------------------------------------
_RE_TABULAR_BEGIN = re.compile(r"\\begin\{tabular\}\{[^}]*\}")
_RE_TABULAR_END = re.compile(r"\\end\{tabular\}")
_RE_RULE_CMDS = re.compile(
    r"\\(?:hline|toprule|midrule|bottomrule|cmidrule(?:\[[^\]]*\])?"
    r"(?:\{[^}]*\})?|cline\{[^}]*\})"
)
_RE_MULTICOL = re.compile(r"\\multicolumn\{\d+\}\{[^}]*\}\{([^}]*)\}")
_RE_MULTIROW = re.compile(r"\\multirow\{\d+\}\{[^}]*\}\{([^}]*)\}")
_RE_CELL_SEP = re.compile(r"(?<!\\)&")  # 素の & (エスケープされていない)
_RE_ROW_SEP = re.compile(r"\\\\")       # 行末 \\\\


def _normalize_latex_tabular(text: str) -> str:
    """tabular 環境・行/列区切り・hline を平文に置換し、金額 regex が
    セル内の数値を拾えるようにする。"""
    text = _RE_TABULAR_BEGIN.sub(" ", text)
    text = _RE_TABULAR_END.sub(" ", text)
    text = _RE_RULE_CMDS.sub(" ", text)
    text = _RE_MULTICOL.sub(r" \1 ", text)
    text = _RE_MULTIROW.sub(r" \1 ", text)
    text = _RE_CELL_SEP.sub(" ", text)
    text = _RE_ROW_SEP.sub("\n", text)
    return text

# -------------------------------------------------------------------
# 金額トークン regex
# 例: 100万円 / 1,234,567円 / 0.5億円 / 50千円 / 12.3万円
# -------------------------------------------------------------------
_AMOUNT_RE = re.compile(
    r"(\d+(?:,\d{3})*(?:\.\d+)?)\s*(億円|万円|千円|円)"
)

# 「合計 XX 万円」「総額 XX 円」「計 XX 円」形式
_TOTAL_KEYWORD_RE = re.compile(
    r"(?:合計|総額|総計|計)\s*[:：]?\s*"
    r"(\d+(?:,\d{3})*(?:\.\d+)?)\s*(億円|万円|千円|円)"
)

# 単価×個数 行
#   例: "10,000 円 × 5", "5万円 * 3", "2000円x10"
_UNIT_PRICE_RE = re.compile(
    r"(\d+(?:,\d{3})*(?:\.\d+)?)\s*(億円|万円|千円|円)"
    r"\s*[×xX*]\s*"
    r"(\d+(?:,\d{3})*(?:\.\d+)?)"
)

# -------------------------------------------------------------------
# JSPS 経費区分キーワード
# -------------------------------------------------------------------
_CATEGORY_KEYWORDS = {
    "物品費": r"物品費",
    "物品": r"(?<![費品])物品(?!費)",  # 物品費の部分一致を避ける
    "機器": r"機器",
    "旅費": r"旅費",
    "出張": r"出張",
    "人件費": r"人件費",
    "謝金": r"謝金",
    "委託": r"委託",
    "リース": r"リース",
    "その他": r"その他",
    "消耗品": r"消耗品",
}

# JSPS/科研費で通常明示区分される 4 つの大枠
_MAJOR_CATEGORIES = ("物品費", "旅費", "人件費", "その他")

# 経費区分判定: 各大枠は次のキーワード群の 1 つ以上で検出とみなす
_CATEGORY_GROUPS = {
    "物品費": ("物品費", "物品", "機器", "消耗品"),
    "旅費": ("旅費", "出張"),
    "人件費": ("人件費", "謝金"),
    "その他": ("その他", "委託", "リース"),
}


def _to_yen(value_str: str, unit: str) -> int:
    """金額文字列と単位を円に換算。"""
    v = float(value_str.replace(",", ""))
    if unit == "億円":
        return int(round(v * 100_000_000))
    if unit == "万円":
        return int(round(v * 10_000))
    if unit == "千円":
        return int(round(v * 1_000))
    return int(round(v))  # 円


def grant_writing_budget_logic_check(text: str) -> dict:
    """申請書の予算・経費記述の論理整合を検査。

    金額トークンの合計、費目の平衡、単価×個数の算数チェック。

    Args:
        text: 申請書本文 (予算セクション推奨)。

    Returns:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""

    # LaTeX tabular が含まれていたら平文に平坦化してから解析する
    if "\\begin{tabular}" in text or "\\hline" in text:
        text = _normalize_latex_tabular(text)

    # -------------------------------------------------------------
    # 1. 金額トークン抽出
    # -------------------------------------------------------------
    amounts: list[dict] = []
    for m in _AMOUNT_RE.finditer(text):
        amounts.append({
            "text": m.group(0),
            "value_yen": _to_yen(m.group(1), m.group(2)),
            "pos": m.start(),
        })

    # -------------------------------------------------------------
    # 2. stated_total の特定 (最後に出現する 合計/総額 パターン)
    # -------------------------------------------------------------
    stated_total: int | None = None
    stated_total_pos: int | None = None
    total_matches = list(_TOTAL_KEYWORD_RE.finditer(text))
    if total_matches:
        last = total_matches[-1]
        stated_total = _to_yen(last.group(1), last.group(2))
        # 「合計 100 万円」の数値部分の開始位置 = amounts の pos と突合
        stated_total_pos = last.start(1)

    # -------------------------------------------------------------
    # 3. computed_sum = amounts の合計 (stated_total に相当する項目を除外)
    # -------------------------------------------------------------
    computed_sum = 0
    for a in amounts:
        # stated_total に相当する金額 entry は除外
        # (pos が合計キーワードの金額位置と同じ、または近い場合)
        if stated_total is not None and stated_total_pos is not None:
            # amount の pos と stated_total_pos の差が 0-5 (空白・コロン) なら除外
            if abs(a["pos"] - stated_total_pos) <= 5:
                continue
        computed_sum += a["value_yen"]

    # -------------------------------------------------------------
    # 4. sum_matches_stated (±1% tolerance)
    # -------------------------------------------------------------
    sum_matches_stated: bool | None
    if stated_total is None:
        sum_matches_stated = None
    else:
        denom = max(stated_total, 1)
        diff_ratio = abs(computed_sum - stated_total) / denom
        sum_matches_stated = diff_ratio <= 0.01

    # -------------------------------------------------------------
    # 5. 費目キーワード検出
    # -------------------------------------------------------------
    category_keywords_found: dict[str, int] = {}
    for name, pat in _CATEGORY_KEYWORDS.items():
        n = len(re.findall(pat, text))
        if n:
            category_keywords_found[name] = n

    categories_present: list[str] = []
    for major, group_keys in _CATEGORY_GROUPS.items():
        if any(k in category_keywords_found for k in group_keys):
            categories_present.append(major)

    missing_major_categories = [
        c for c in _MAJOR_CATEGORIES if c not in categories_present
    ]

    # -------------------------------------------------------------
    # 6. 単価×個数行
    # -------------------------------------------------------------
    unit_price_lines: list[dict] = []
    for m in _UNIT_PRICE_RE.finditer(text):
        unit_yen = _to_yen(m.group(1), m.group(2))
        qty = float(m.group(3).replace(",", ""))
        expected = int(round(unit_yen * qty))
        # 近傍 (±80 字) に結果金額が書いてあるか確認
        window_start = m.end()
        window_end = min(len(text), window_start + 80)
        tail = text[window_start:window_end]
        checked: bool | None = None
        found_result: int | None = None
        for am in _AMOUNT_RE.finditer(tail):
            candidate = _to_yen(am.group(1), am.group(2))
            # expected と 1% 以内なら pass
            if candidate == 0 and expected == 0:
                continue
            denom = max(expected, 1)
            if abs(candidate - expected) / denom <= 0.01:
                checked = True
                found_result = candidate
                break
            # 最も近い候補を保持 (fail 判定用)
            if found_result is None:
                found_result = candidate
                checked = False
        unit_price_lines.append({
            "text": m.group(0),
            "pos": m.start(),
            "unit_yen": unit_yen,
            "quantity": qty,
            "expected_yen": expected,
            "found_result_yen": found_result,
            "arithmetic_ok": checked,
        })

    # -------------------------------------------------------------
    # 7. Scoring
    # -------------------------------------------------------------
    comments: list[str] = []

    if not amounts:
        # 金額が全くない場合
        score: float = 0.0
        comments.append(
            "金額表記が検出されない。"
            "『〜万円』『〜円』形式で書かれているか確認。"
        )
        comments.append(
            "予算セクションが検出されなかった or 金額表記が非標準。"
        )
    else:
        score = 5.0
        if stated_total is not None and sum_matches_stated:
            score += 3.0
        if len(missing_major_categories) == 0:
            score += 1.0
        if (len(unit_price_lines) >= 1
                and all(u["arithmetic_ok"] for u in unit_price_lines)):
            score += 1.0
        if sum_matches_stated is False:
            score -= 3.0
        # 欠損費目ペナルティ (最大 -2)
        score -= min(len(missing_major_categories), 2)
        score = max(0.0, min(10.0, score))

        # -------------------------------------------------------------
        # 8. Comments
        # -------------------------------------------------------------
        if sum_matches_stated is False:
            diff = computed_sum - stated_total  # type: ignore[operator]
            comments.append(
                f"合計記述 ({stated_total:,} 円) と積み上げ和 "  # type: ignore[str-format]
                f"({computed_sum:,} 円) が一致しない (差 {diff:,} 円)。"
                "費目の列挙漏れ or 転記ミスを確認。"
            )
        elif sum_matches_stated is True:
            comments.append(
                f"合計と積み上げが一致 ({computed_sum:,} 円)。"
            )

        for cat in missing_major_categories:
            comments.append(
                f"費目「{cat}」の記述が検出されない。"
                "JSPS/科研費は通常 物品費/旅費/人件費/その他 を"
                "明示的に区分する。"
            )

        for u in unit_price_lines:
            if u["arithmetic_ok"] is False:
                comments.append(
                    f"単価計算の整合性が疑わしい: 「{u['text']}」。"
                    "電卓で再検算を。"
                )

    # 最低 2 件 - 最大 5 件の comments に収める
    if len(comments) == 0:
        comments.append(f"参考: {_SOURCE}")
    # source 参照が comments に無い場合、skill.md/木下/JSPS いずれの語も
    # 入っていない純粋な整合 OK ケースでは 1 件付与
    has_src_ref = any(
        ("JSPS" in c) or ("skill.md" in c) or ("木下" in c)
        or ("一致" in c) or ("検出されない" in c)
        for c in comments
    )
    if not has_src_ref:
        comments.append(f"参考: {_SOURCE}")

    # 上限 5 件
    comments = comments[:5]

    observations = {
        "amounts": amounts,
        "stated_total": stated_total,
        "computed_sum": computed_sum,
        "sum_matches_stated": sum_matches_stated,
        "category_keywords_found": category_keywords_found,
        "categories_present": categories_present,
        "missing_major_categories": missing_major_categories,
        "unit_price_lines": unit_price_lines,
    }

    return {
        "score": score,
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": _HINT,
        "source": _SOURCE,
    }
