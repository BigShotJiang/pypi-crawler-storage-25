"""Plan B T12 — 共同研究者の役割チェック (skill.md T2 実測化).

skill.md T2 (`check_character_list`) と完成検証チェックリスト
「共同研究者の役割が明確」を正規表現で実装したもの。

登場する共同研究者・協力者 (教授/博士/氏 等の敬称を伴う人物名) に対し、
近傍 ±50 字以内に役割動詞 (担当/実施/分担/主導/支援 等) が出現するかを
チェックする。
"""

from __future__ import annotations

import re
from typing import Optional


_SOURCE = (
    "skill.md T2 (check_character_list) / "
    "完成検証チェックリスト「共同研究者の役割が明確」"
)

_HINT = (
    "正規表現ベースの粗い検出。敬称なしの人名 (「山田は〜」のような形) は取りこぼす。"
    "comments の人物リストを手で吟味し、役割動詞の近接度が自然か確認。"
    "2026-04-23 から カタカナ名 (「アダム・ジョン博士」) と "
    "自己参照 (「申請者」「筆者」「研究代表者」等) も検出対象。"
)

# 人物検出: 漢字 1-6 字 + ひらがな 0-2 字 + 敬称
_RE_PERSON_KANJI = re.compile(
    r"([一-鿿々]{1,6}(?:[ぁ-ん一-鿿]{0,2})?)"
    r"(教授|准教授|助教|博士|氏|先生|様|医師|所長|室長|研究員|主任研究員|特任教授)"
)

# カタカナ名 + 敬称 (中点・長音も許容、e.g. アダム・ジョン博士 / マリー=キュリー先生)
_RE_PERSON_KATAKANA = re.compile(
    r"([ァ-ヴー・＝=\-]{3,15})"
    r"(教授|准教授|助教|博士|氏|先生|様|医師|所長|室長|研究員|主任研究員|特任教授)"
)

# 自己参照語 (敬称なしでも暗黙的に「人」として扱う)
_RE_SELF_REFERENCE = re.compile(
    r"(申請者|筆者|研究代表者|研究分担者|研究協力者|本研究者|本人)"
)

# 役割動詞
_RE_ROLE_VERB = re.compile(
    r"(担当|実施|分担|主導|支援|協力|提供|管理|運営|指導|執筆|推進|設計|"
    r"開発|測定|解析|検証|評価)(?:する|している|した|を行う|を担う)"
)

_NEAR_WINDOW = 50  # 役割動詞探索の近傍 (±50 字)
_CONTEXT_WINDOW = 30  # スニペット抽出 (±30 字)


def grant_writing_collaborator_roles_check(
    text: str,
    applicant_name: str = "",
) -> dict:
    """登場する共同研究者・協力者について役割動詞の近接記述を検査。

    skill.md T2 の実測化。敬称付き人物名を検出し、±50 字以内に
    役割動詞 (担当/実施/分担/主導/支援 等) が書かれているかを判定する。

    Args:
        text: 申請書本文。
        applicant_name: 申請者名 (例: 「山田太郎」)。一致検出時に
            is_applicant フラグを立てる。

    Returns:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""
    if applicant_name is None:
        applicant_name = ""

    text_len = len(text)
    role_verbs_overall: list[str] = []
    _seen_verbs: set[str] = set()

    # 人物検出: 3 種類のパターンをマージ
    # (1) 漢字名 + 敬称、(2) カタカナ名 + 敬称、(3) 自己参照語 (申請者等)
    raw_people: list[dict] = []
    seen_spans: set[tuple[int, int]] = set()  # 重複マッチ防止

    def _register(name: str, pos: int, end: int, kind: str) -> None:
        span = (pos, end)
        if span in seen_spans:
            return
        seen_spans.add(span)
        raw_people.append({"name": name, "pos": pos, "end": end, "kind": kind})

    for m in _RE_PERSON_KANJI.finditer(text):
        _register(m.group(1) + m.group(2), m.start(), m.end(), "kanji_honorific")
    for m in _RE_PERSON_KATAKANA.finditer(text):
        _register(m.group(1) + m.group(2), m.start(), m.end(), "katakana_honorific")
    for m in _RE_SELF_REFERENCE.finditer(text):
        _register(m.group(1), m.start(), m.end(), "self_reference")

    # 位置順にソート (文中の出現順)
    raw_people.sort(key=lambda p: p["pos"])

    # 役割動詞を先に全列挙し、各動詞を「直前の人物」に割り当てる。
    # 日本語の語順 (subject ... verb) に従い、動詞は直前の人物に属すと見なす。
    # 近傍制約は ±50 字以内のみ。前方に候補が無い場合のみ、直後 50 字以内の
    # 人物へフォールバック。
    assigned_verbs: dict[int, str] = {}  # person_index -> role_verb
    for vm in _RE_ROLE_VERB.finditer(text):
        v_pos = vm.start()
        # 直前の人物を探す (end <= v_pos)
        best_idx: Optional[int] = None
        best_dist: Optional[int] = None
        for i, p in enumerate(raw_people):
            if p["end"] <= v_pos:
                dist = v_pos - p["end"]
                if dist <= _NEAR_WINDOW and (
                    best_dist is None or dist < best_dist
                ):
                    best_dist = dist
                    best_idx = i
        # 前方に人物が無ければ、直後 ±50 内の人物へフォールバック
        if best_idx is None:
            for i, p in enumerate(raw_people):
                if p["pos"] > v_pos:
                    dist = p["pos"] - vm.end()
                    if dist <= _NEAR_WINDOW:
                        best_idx = i
                    break
        if best_idx is not None and best_idx not in assigned_verbs:
            assigned_verbs[best_idx] = vm.group(1)

    people: list[dict] = []
    for i, p in enumerate(raw_people):
        name = p["name"]
        pos = p["pos"]
        end = p["end"]

        role_verb: Optional[str] = assigned_verbs.get(i)
        if role_verb is not None and role_verb not in _seen_verbs:
            _seen_verbs.add(role_verb)
            role_verbs_overall.append(role_verb)

        # pos±30 字のスニペット
        ctx_start = max(0, pos - _CONTEXT_WINDOW)
        ctx_end = min(text_len, end + _CONTEXT_WINDOW)
        context = text[ctx_start:ctx_end]

        is_applicant = bool(applicant_name) and applicant_name in name

        people.append(
            {
                "name": name,
                "pos": pos,
                "kind": p["kind"],
                "role_verb": role_verb,
                "context": context,
                "is_applicant": is_applicant,
            }
        )

    # 出現回数ベースの raw 数と、名前単位 (dedupe) の unique 数を両方出す。
    # Scoring は unique 名ベース (同じ人が 10 回出て 1 回だけ役割が近接して
    # いる場合にスコアが不当に低くなるのを防ぐ)。
    total_people = len(people)  # occurrences (後方互換)
    unique_names: dict[str, list[dict]] = {}
    for p in people:
        unique_names.setdefault(p["name"], []).append(p)
    unique_count = len(unique_names)
    unique_with_role = sum(
        1 for occs in unique_names.values()
        if any(o["role_verb"] is not None for o in occs)
    )
    without_role = unique_count - unique_with_role  # unique ベース

    # Scoring
    if unique_count == 0:
        score: float = 5.0
    else:
        score = round((unique_with_role / unique_count) * 10, 1)

    # Comments
    comments: list[str] = []

    if total_people == 0:
        comments.append(
            "登場人物 (教授/博士/氏 等) が検出されなかった。"
            "共同研究者セクションを書いているか確認。"
        )
        comments.append(
            "人物が検出されなかった。共同研究者の記載が必須のフォーマット "
            "(JSPS/科研費) なら必ず追加する。"
        )
    else:
        # role 未記述の unique 名を列挙 (最大 3 名)
        missing_names = [
            name for name, occs in unique_names.items()
            if not any(o["role_verb"] is not None for o in occs)
        ]
        for name in missing_names[:3]:
            comments.append(
                f"「{name}」の役割が未記述。"
                "担当/実施/分担/支援 等の動詞を近傍に明記。"
            )

        # 申請者が検出されているが役割動詞が無い場合
        if applicant_name:
            applicant_people = [p for p in people if p["is_applicant"]]
            applicant_with_role = any(
                p["role_verb"] is not None for p in applicant_people
            )
            if applicant_people and not applicant_with_role:
                comments.append(
                    f"申請者 {applicant_name} の役割が本文に動詞で明示されていない。"
                    "研究総括/PI としての動詞を足す。"
                )

        # 全員に役割動詞がある場合の肯定コメント
        if unique_with_role == unique_count and unique_count >= 2:
            comments.append(
                f"検出された {unique_count} 名全員に役割動詞が対応。"
                "共同研究者記述として十分。"
            )

    # 最低 2 コメント、最大 5 コメント
    if len(comments) < 2:
        comments.append(f"参考: {_SOURCE}")
    if len(comments) < 2:
        comments.append(
            "敬称付き人物と役割動詞の近接配置を継続して確認する。"
        )
    comments = comments[:5]

    observations = {
        "people": people,
        "total_people": total_people,
        "unique_names_count": unique_count,
        "with_role": unique_with_role,
        "without_role": without_role,
        "role_verbs_found_overall": role_verbs_overall,
    }

    return {
        "score": score,
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": _HINT,
        "source": _SOURCE,
    }
