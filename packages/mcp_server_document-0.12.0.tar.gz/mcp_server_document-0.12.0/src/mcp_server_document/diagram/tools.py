"""Tool functions for the diagram sub-module of mcp-server-document.

Exposes the `separate_layers` and `compose_layers` pipeline from the
sibling `excalidraw/src/trace/` directory as MCP tools. The two scripts
are imported lazily so users without opencv/skimage still get the rest
of mcp-server-document's tools without ImportError at server start.
"""
from __future__ import annotations

import json
import pathlib


def _load_skill() -> str:
    """Return the sub-module's skill.md if present, else a short blurb."""
    p = pathlib.Path(__file__).resolve().parent / "skill.md"
    if p.exists():
        return p.read_text(encoding="utf-8")
    return (
        "diagram sub-module: raster-to-Excalidraw pipeline.\n\n"
        "Two main tools:\n"
        "- diagram_separate_layers(image_path, out_dir, k)\n"
        "- diagram_compose_layers(layers_dir, out_path, config_json)\n"
    )


def _locate_trace_scripts() -> pathlib.Path | None:
    """Find the sibling excalidraw/src/trace/ dir (outside the pip package).

    The scripts live in the parent repo alongside the Python package,
    not inside the pip-installed tree. When installed from PyPI, they
    may not be present; in that case the tools return a descriptive
    error.
    """
    # mcp_server_document/diagram/tools.py
    pkg_dir = pathlib.Path(__file__).resolve().parent.parent
    # Try: repo layout = .../01_GitHub/src/mcp_server_document/
    candidates = [
        pkg_dir.parent.parent / "excalidraw" / "src" / "trace",  # editable install in 01_GitHub
        pathlib.Path.cwd() / "excalidraw" / "src" / "trace",
        pathlib.Path.home() / "mcp-server-document" / "excalidraw" / "src" / "trace",
    ]
    for c in candidates:
        if c.is_dir() and (c / "separate_layers.py").is_file():
            return c
    return None


def diagram_usage() -> str:
    """raster→Excalidraw pipeline の使い方と設計思想を返す。

    呼び出しタイミング:
    - 画像 (ロゴ / 手描き図 / 研究イラスト) を Excalidraw のベクター要素に
      変換したい場合
    - 「どのレイヤーがどう分離されるか」を確認したい場合
    - trace 性能が悪く diagnosis したい場合
    """
    return _load_skill()


def diagram_separate_layers(image_path: str,
                             out_dir: str = "",
                             k: int = 5,
                             min_fill_area: int = 500) -> dict:
    """画像を意味的レイヤー PNG に分離する (Step 1 of trace pipeline)。

    入力画像を解析して以下の層を独立 PNG として保存:
      - quantized_k{k}.png: k-means 色量子化版
      - layer_color{0..k-1}_rgb*.png: 色クラスタ毎 (+ white-bg flat 版)
      - layer_bg.png: 近白背景 (マスク)
      - layer_foreground.png: 非背景 全部 (反転、黒FG on 白BG)
      - layer_edges_canny.png: Canny エッジ
      - layer_thin_lines_all.png / _short.png / _long.png: 細線 (短/長分割)
      - layer_thick_fills.png: 大きい塗り潰し領域
      - layer_circles.png: Hough 検出円
      - layer_text_mser.png: MSER text 候補領域
      - layers_overview.png: タイル状まとめビュー (人間確認用)

    Args:
        image_path: 入力ラスター画像 (PNG/JPG)。日本語パス可 (内部で ASCII 化)。
        out_dir: 出力 dir。未指定時は <image_parent>/<stem>_layers/。
        k: 色クラスタ数 (3-10 推奨、既定 5)。
        min_fill_area: thick_fills のピクセル閾値 (既定 500)。

    Returns:
        dict with 'out_dir', 'color_layers' (list), 'binary_layers'.
    """
    trace_dir = _locate_trace_scripts()
    if trace_dir is None:
        return {
            "error": (
                "separate_layers.py not found. Clone "
                "https://github.com/ksugahar/mcp-server-document and "
                "run the tool from within the repo, or set the "
                "`excalidraw/` sibling directory next to the cwd."
            )
        }
    import sys
    sys.path.insert(0, str(trace_dir))
    try:
        # Force fresh load in case of multiple invocations
        if "separate_layers" in sys.modules:
            del sys.modules["separate_layers"]
        from separate_layers import separate  # type: ignore
    except ImportError as exc:
        return {
            "error": f"failed to import separate_layers: {exc}. "
                     "Missing opencv-python / scikit-image?"
        }
    finally:
        sys.path.remove(str(trace_dir))

    src = pathlib.Path(image_path).expanduser()
    if not src.exists():
        return {"error": f"image not found: {src}"}
    if out_dir:
        out = pathlib.Path(out_dir).expanduser()
    else:
        out = src.parent / f"{src.stem}_layers"

    try:
        result = separate(src, out, k=k, min_fill_area=min_fill_area)
    except Exception as exc:
        return {"error": f"{type(exc).__name__}: {exc}"}
    return result


def diagram_compose_layers(layers_dir: str,
                            out_path: str,
                            config_json: str = "",
                            scale: float = 2.0,
                            offset_x: float = 50.0,
                            offset_y: float = 50.0,
                            seed: int = 42) -> dict:
    """レイヤー PNG 群から Excalidraw JSON を合成する (Step 2)。

    separate_layers で生成した dir を入力に取り、各 PNG に対して
    戦略 (fill_contour / skeleton_lines / circles_fit / points ...)
    を適用して .excalidraw 形式に組み立てる。

    Args:
        layers_dir: diagram_separate_layers の出力 dir。
        out_path: 書き出す .excalidraw JSON パス。
        config_json: 戦略設定 JSON 文字列。省略時は default_config_for で
                     自動設定 (thick_fills→fill_contour, thin_long→
                     skeleton_lines, circles→circles_fit 等)。
                     形式:
                       {"layers": [
                         {"filename": "layer_thick_fills.png",
                          "strategy": "fill_contour",
                          "stroke": "#1e3a6a", "fill": "#3388a0",
                          "group": "brain", "min_area": 150},
                         ...
                       ]}
        scale: 座標スケール (既定 2.0)
        offset_x, offset_y: 原点オフセット (既定 50, 50)
        seed: ランダム種 (既定 42、element ID の再現性用)

    Returns:
        dict with 'total_elements', 'per_layer' counts, 'out_path'.
    """
    trace_dir = _locate_trace_scripts()
    if trace_dir is None:
        return {"error": "compose_layers.py not found (see diagram_separate_layers error)"}
    import sys
    sys.path.insert(0, str(trace_dir))
    try:
        for m in ("compose_layers", "separate_layers", "trace_image"):
            if m in sys.modules:
                del sys.modules[m]
        from compose_layers import (  # type: ignore
            compose, default_config_for, to_excalidraw_json,
        )
    except ImportError as exc:
        return {
            "error": f"failed to import compose_layers: {exc}. "
                     "Missing opencv-python / scikit-image?"
        }
    finally:
        sys.path.remove(str(trace_dir))

    ld = pathlib.Path(layers_dir).expanduser()
    if not ld.is_dir():
        return {"error": f"layers_dir not found: {ld}"}

    if config_json.strip():
        try:
            cfg = json.loads(config_json)
        except json.JSONDecodeError as exc:
            return {"error": f"config_json parse error: {exc}"}
    else:
        cfg = default_config_for(ld)

    try:
        elements, summary = compose(
            ld, cfg,
            scale=scale, offset=(offset_x, offset_y), seed=seed,
        )
    except Exception as exc:
        return {"error": f"compose failed: {type(exc).__name__}: {exc}"}

    doc = to_excalidraw_json(elements)
    out_p = pathlib.Path(out_path).expanduser()
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")

    return {
        "out_path": str(out_p),
        "total_elements": summary["total_elements"],
        "per_layer": summary["layers"],
        "config_used": cfg,
    }


def diagram_list_strategies() -> dict:
    """compose_layers で使用可能な戦略 6 種の一覧と用途を返す。"""
    return {
        "strategies": {
            "fill_contour": {
                "description": "External contour → solid-filled polygon",
                "best_for": "brain silhouette, logo glyphs, filled text",
                "params": ["stroke", "fill", "group", "min_area", "epsilon"],
            },
            "outline": {
                "description": "Each contour → closed polyline (no fill)",
                "best_for": "coils, rings, outline-only shapes",
                "params": ["stroke", "group", "min_area", "epsilon", "width"],
            },
            "skeleton_lines": {
                "description": "Skeletonize + trace → polylines",
                "best_for": "thin field lines, hand-drawn strokes",
                "params": ["stroke", "group", "min_length", "simplify",
                           "width", "max_lines"],
            },
            "circles_fit": {
                "description": "HoughCircles → ellipses",
                "best_for": "concentric field rings, circular logos",
                "params": ["stroke", "fill", "group", "min_radius",
                           "max_radius", "max_circles"],
            },
            "text_placeholder": {
                "description": "MSER regions → empty text-element stubs",
                "best_for": "text areas needing later manual fill-in",
                "params": ["stroke", "group", "min_area", "min_height"],
            },
            "points": {
                "description": "Small components → tiny filled circles",
                "best_for": "glow nodes, bullet-point dots",
                "params": ["stroke", "fill", "group", "max_area", "min_area"],
            },
        },
        "usage_hint": (
            "Pass a config_json to diagram_compose_layers with a 'layers' "
            "array, each entry specifying filename + strategy + params. "
            "Omit config_json for sensible defaults."
        ),
    }


# ---------------------------------------------------------------------------
# v0.4.0 additions — HTTP bridge (4) + advanced (4)
# ---------------------------------------------------------------------------

_EXCALIDRAW_BRIDGE_URL = "http://localhost:3000"


def _http_json(method: str, url: str, payload: dict | None = None,
                timeout: float = 15.0) -> dict:
    """Thin urllib wrapper. Avoids adding a dependency on requests."""
    import urllib.request
    import urllib.error
    data = None
    headers = {"Content-Type": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
            if not body:
                return {"ok": True, "status": r.status}
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"ok": True, "raw": body.decode("utf-8", errors="replace")}
    except urllib.error.URLError as exc:
        return {"error": f"HTTP {method} {url} failed: {exc}"}


def diagram_push_to_canvas(excalidraw_path: str,
                             bridge_url: str = "") -> dict:
    """Excalidraw JSON を canvas server (Node sibling, localhost:3000) に送信する。

    `diagram_compose_layers` の出力をローカル Excalidraw canvas に投影して
    visual confirmation したい場合に使う。

    Args:
        excalidraw_path: .excalidraw JSON file path (compose_layers 等の出力)。
        bridge_url: canvas server URL (default http://localhost:3000)。

    Returns:
        {ok, pushed_elements, status} または {error}.
    """
    p = pathlib.Path(excalidraw_path).expanduser()
    if not p.exists():
        return {"error": f"file not found: {p}"}
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return {"error": f"parse error: {exc}"}
    url = (bridge_url or _EXCALIDRAW_BRIDGE_URL).rstrip("/") + "/import"
    result = _http_json("POST", url, payload=doc)
    if "error" in result:
        return {
            **result,
            "hint": "Start the Node bridge: cd excalidraw && npm run dev",
        }
    result["pushed_elements"] = len(doc.get("elements", []))
    return result


def diagram_clear_canvas(bridge_url: str = "") -> dict:
    """Canvas server の現在 scene を空にする。"""
    url = (bridge_url or _EXCALIDRAW_BRIDGE_URL).rstrip("/") + "/clear"
    return _http_json("POST", url, payload={})


def diagram_export_canvas_png(out_path: str,
                                bridge_url: str = "",
                                background: str = "transparent") -> dict:
    """Canvas server の現在 scene を PNG として保存する。

    Args:
        out_path: 書き出す PNG path。
        bridge_url: canvas server URL。
        background: "transparent" | "white" | hex ("#ffeecc")。
    """
    url = (bridge_url or _EXCALIDRAW_BRIDGE_URL).rstrip("/") + "/export_png"
    out = pathlib.Path(out_path).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = {"background": background}
    import urllib.request
    import urllib.error
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30.0) as r:
            out.write_bytes(r.read())
    except urllib.error.URLError as exc:
        return {"error": f"export failed: {exc}",
                "hint": "Is the Node canvas server running on port 3000?"}
    return {"ok": True, "out_path": str(out), "bytes": out.stat().st_size}


def diagram_load_excalidraw_file(excalidraw_path: str) -> dict:
    """Excalidraw JSON を読み込み、element 統計を返す (push なしの local inspect)。

    Returns:
        {element_count, type_histogram, canvas_bounds}.
    """
    p = pathlib.Path(excalidraw_path).expanduser()
    if not p.exists():
        return {"error": f"file not found: {p}"}
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return {"error": f"parse error: {exc}"}
    els = doc.get("elements", [])
    hist: dict[str, int] = {}
    x_min = y_min = float("inf")
    x_max = y_max = float("-inf")
    for el in els:
        hist[el.get("type", "unknown")] = hist.get(el.get("type", "unknown"), 0) + 1
        x = el.get("x", 0.0)
        y = el.get("y", 0.0)
        w = el.get("width", 0.0)
        h = el.get("height", 0.0)
        x_min = min(x_min, x)
        y_min = min(y_min, y)
        x_max = max(x_max, x + w)
        y_max = max(y_max, y + h)
    bounds = None
    if els:
        bounds = {"x_min": x_min, "y_min": y_min, "x_max": x_max, "y_max": y_max,
                  "width": x_max - x_min, "height": y_max - y_min}
    return {
        "element_count": len(els),
        "type_histogram": hist,
        "canvas_bounds": bounds,
        "app_state_keys": list(doc.get("appState", {}).keys()),
    }


def diagram_ocr_text_layer(image_path: str,
                             lang: str = "eng+jpn",
                             out_json: str = "") -> dict:
    """画像中の文字領域を OCR し bounding box + text を返す。

    Tesseract (pytesseract) が必要 (pip install pytesseract + Tesseract binary)。
    compose_layers の text_placeholder strategy の後処理として、MSER で
    抽出した text 領域に実テキストを当てる目的で使用。

    Args:
        image_path: 入力画像 path。
        lang: Tesseract language code (例: "eng", "jpn", "eng+jpn")。
        out_json: 書き出す JSON path (省略時は返却のみ)。

    Returns:
        {blocks: [{text, x, y, w, h, conf}], total_blocks}
    """
    try:
        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore
    except ImportError as exc:
        return {"error": f"pytesseract/Pillow not installed: {exc}. "
                         "pip install pytesseract pillow + Tesseract binary"}
    p = pathlib.Path(image_path).expanduser()
    if not p.exists():
        return {"error": f"image not found: {p}"}
    try:
        img = Image.open(p)
        data = pytesseract.image_to_data(img, lang=lang,
                                           output_type=pytesseract.Output.DICT)
    except Exception as exc:
        return {"error": f"OCR failed: {type(exc).__name__}: {exc}"}
    blocks = []
    n = len(data.get("text", []))
    for i in range(n):
        txt = (data["text"][i] or "").strip()
        if not txt:
            continue
        conf_raw = data.get("conf", ["-1"])[i]
        try:
            conf = float(conf_raw)
        except (ValueError, TypeError):
            conf = -1.0
        if conf < 0:
            continue
        blocks.append({
            "text": txt,
            "x": int(data["left"][i]),
            "y": int(data["top"][i]),
            "w": int(data["width"][i]),
            "h": int(data["height"][i]),
            "conf": round(conf, 1),
        })
    result = {"total_blocks": len(blocks), "blocks": blocks, "lang": lang}
    if out_json:
        outp = pathlib.Path(out_json).expanduser()
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(json.dumps(result, ensure_ascii=False, indent=2),
                         encoding="utf-8")
        result["out_json"] = str(outp)
    return result


def diagram_mermaid_to_excalidraw(mermaid_src: str,
                                    out_path: str = "",
                                    bridge_url: str = "") -> dict:
    """Mermaid diagram 記述を canvas server 経由で Excalidraw JSON に変換する。

    bridge の `/mermaid` endpoint を使う。ローカルで変換できない場合、
    簡易 fallback として node-shape list を返す。

    Args:
        mermaid_src: Mermaid syntax (graph LR ... 等)。
        out_path: 保存先 .excalidraw path (省略時は返却のみ)。
        bridge_url: canvas server URL。

    Returns:
        {elements or error, out_path}
    """
    if not mermaid_src.strip():
        return {"error": "empty mermaid_src"}
    url = (bridge_url or _EXCALIDRAW_BRIDGE_URL).rstrip("/") + "/mermaid"
    result = _http_json("POST", url, payload={"mermaid": mermaid_src})
    if "error" in result:
        return {
            **result,
            "hint": "The Node bridge must expose POST /mermaid (Excalidraw mermaid-to-excalidraw pkg).",
        }
    if out_path:
        doc = result.get("excalidraw") or result
        outp = pathlib.Path(out_path).expanduser()
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(json.dumps(doc, ensure_ascii=False, indent=2),
                         encoding="utf-8")
        result["out_path"] = str(outp)
    return result


def diagram_academic_template(kind: str = "",
                                out_path: str = "") -> dict:
    """学術プレゼン向け定型 Excalidraw テンプレを返す。

    Args:
        kind: "workflow" | "three_box" | "before_after" | "imrad_flow" | "timeline"
              空文字列で一覧を返す。
        out_path: 保存先 (省略時は返却のみ)。
    """
    templates = {
        "workflow": {
            "desc": "Input → Method → Output の 3-stage 横フロー",
            "elements": [
                {"type": "rectangle", "x": 100, "y": 200, "width": 160, "height": 80,
                 "label": "Input"},
                {"type": "arrow", "x": 260, "y": 240, "width": 80, "height": 0},
                {"type": "rectangle", "x": 340, "y": 200, "width": 160, "height": 80,
                 "label": "Method"},
                {"type": "arrow", "x": 500, "y": 240, "width": 80, "height": 0},
                {"type": "rectangle", "x": 580, "y": 200, "width": 160, "height": 80,
                 "label": "Output"},
            ],
        },
        "three_box": {
            "desc": "Problem / Approach / Result の 3-box 縦組み",
            "elements": [
                {"type": "rectangle", "x": 100, "y": 100, "width": 300, "height": 100,
                 "label": "Problem"},
                {"type": "rectangle", "x": 100, "y": 240, "width": 300, "height": 100,
                 "label": "Approach"},
                {"type": "rectangle", "x": 100, "y": 380, "width": 300, "height": 100,
                 "label": "Result"},
            ],
        },
        "before_after": {
            "desc": "Before / After の 2-column 対比",
            "elements": [
                {"type": "text", "x": 100, "y": 60, "text": "Before"},
                {"type": "rectangle", "x": 100, "y": 100, "width": 300, "height": 300},
                {"type": "text", "x": 500, "y": 60, "text": "After"},
                {"type": "rectangle", "x": 500, "y": 100, "width": 300, "height": 300},
            ],
        },
        "imrad_flow": {
            "desc": "IMRAD の論旨フロー (Intro→Method→Result→Discussion)",
            "elements": [
                {"type": "rectangle", "x": 80, "y": 180, "width": 120, "height": 70,
                 "label": "Intro\n(Q)"},
                {"type": "rectangle", "x": 240, "y": 180, "width": 120, "height": 70,
                 "label": "Method"},
                {"type": "rectangle", "x": 400, "y": 180, "width": 120, "height": 70,
                 "label": "Result"},
                {"type": "rectangle", "x": 560, "y": 180, "width": 120, "height": 70,
                 "label": "Discuss\n(A)"},
                {"type": "arrow", "x": 200, "y": 215, "width": 40, "height": 0},
                {"type": "arrow", "x": 360, "y": 215, "width": 40, "height": 0},
                {"type": "arrow", "x": 520, "y": 215, "width": 40, "height": 0},
            ],
        },
        "timeline": {
            "desc": "研究計画 D1/M1/Y1 markers の年表",
            "elements": [
                {"type": "line", "x": 80, "y": 300, "width": 720, "height": 0},
                {"type": "text", "x": 100, "y": 260, "text": "M1"},
                {"type": "text", "x": 300, "y": 260, "text": "M6"},
                {"type": "text", "x": 500, "y": 260, "text": "M12"},
                {"type": "text", "x": 700, "y": 260, "text": "M18"},
            ],
        },
    }
    if not kind:
        return {
            "available": list(templates.keys()),
            "usage": "diagram_academic_template(kind='workflow', out_path='...')",
        }
    if kind not in templates:
        return {"error": f"unknown kind={kind!r}", "available": list(templates.keys())}
    tpl = templates[kind]
    doc = {
        "type": "excalidraw",
        "version": 2,
        "source": "mcp-server-document:diagram_academic_template",
        "elements": tpl["elements"],
        "appState": {"viewBackgroundColor": "#ffffff"},
    }
    if out_path:
        outp = pathlib.Path(out_path).expanduser()
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(json.dumps(doc, ensure_ascii=False, indent=2),
                         encoding="utf-8")
        return {"kind": kind, "description": tpl["desc"], "out_path": str(outp),
                "element_count": len(tpl["elements"])}
    return {"kind": kind, "description": tpl["desc"], "document": doc,
            "element_count": len(tpl["elements"])}


# ---------------------------------------------------------------------------
# v0.5.0 additions — pixel-perfect exact trace + verify + OCR fill + smooth
# ---------------------------------------------------------------------------


def diagram_trace_exact(image_path: str,
                          out_path: str,
                          max_colors: int = 16,
                          simplify_tolerance: float = 0.0,
                          min_area: int = 4,
                          bg_detect: bool = True,
                          scale: float = 1.0,
                          offset_x: float = 0.0,
                          offset_y: float = 0.0) -> dict:
    """ラスターを色忠実にベクトル化して Excalidraw JSON に書き出す (v0.5.0)。

    **用途**: 単純な図 (ロゴ / フラット色の schematic / 手描き line art) を
    「ほぼ pixel-perfect に再現」するベクター形式が欲しい場合。
    既存の `diagram_separate_layers` + `diagram_compose_layers`
    パイプラインが "smart approximation" なのに対し、こちらは
    **色忠実な境界 pixel trace** を行う。

    **アルゴリズム**:
    1. k-means 色量子化 (adaptive k, 2 <= k <= max_colors)
    2. 背景色クラスタ auto-detect (border >50% 占有するなら BG とみなし除外)
    3. 色ごとに connected component → `cv2.findContours(RETR_EXTERNAL, CHAIN_APPROX_NONE)`
       で境界 pixel を全取得 (simplify_tolerance>0 なら RDP 近似)
    4. Excalidraw `line` element (closed polygon, `roughness=0`, `strokeWidth=0`,
       `fillStyle=solid`, `backgroundColor=<exact hex>`) に変換

    **品質の確認** は `diagram_verify_pixel_match` で行う (PSNR/MSE/max-delta)。

    Args:
        image_path: 入力 raster (PNG/JPG)。日本語パス可。
        out_path: 書き出す .excalidraw JSON パス。
        max_colors: 色量子化の上限クラスタ数 (既定 16)。
        simplify_tolerance: RDP 近似の epsilon (0 で pixel-exact、
            >0 で頂点削減 — pixel-perfect 保証は外れる)。
        min_area: 書き出す連結成分の最小面積 pixel (既定 4、ノイズ除去)。
        bg_detect: True なら背景色クラスタを書き出さず appState に流し込む。
        scale: 座標スケール (既定 1.0 = 1 pixel = 1 unit)。
        offset_x, offset_y: 原点オフセット (既定 0, 0 で pixel-perfect。
            Excalidraw canvas 上で余白が欲しい場合 50 等に設定)。

    Returns:
        {out_path, image_size, palette_size, bg_color, total_elements,
         per_color: [{label, fill, components, total_vertices}, ...]}
    """
    try:
        from . import exact_trace
    except ImportError as exc:  # pragma: no cover
        return {"error": f"exact_trace import failed: {exc}"}
    try:
        return exact_trace.trace_exact_impl(
            image_path=image_path, out_path=out_path,
            max_colors=max_colors, simplify_tolerance=simplify_tolerance,
            min_area=min_area, bg_detect=bg_detect,
            scale=scale, offset_x=offset_x, offset_y=offset_y,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_verify_pixel_match(excalidraw_path: str,
                                 original_image_path: str,
                                 out_diff_png: str = "",
                                 metric: str = "all") -> dict:
    """Excalidraw を局所ラスタライズ → 原画と diff、PSNR/MSE/max-delta を返す。

    **用途**: `diagram_trace_exact` が本当に pixel-perfect になっているかを
    数値で検証。`exact_match=True` なら最大チャネル差分 <= 1 gray level。

    **制限**: このツールは `line` / `polygon` 要素 (closed, `fillStyle=solid`,
    `roughness=0`) のみを忠実にラスタライズする。rough.js や freedraw の
    sketchy rendering は再現しないため、`diagram_trace_exact` 以外の
    Excalidraw (例: `compose_layers` approximate 出力) に対しては
    metric が悲観的に出る場合がある。

    Args:
        excalidraw_path: 検証対象 .excalidraw JSON。
        original_image_path: 比較元のラスター。
        out_diff_png: 差分可視化 PNG の書き出し先 (空文字列で skip)。
        metric: "all" | "psnr" | "mse" (予約、現在は常に all)。

    Returns:
        {image_size, element_count, mse, psnr_db, max_delta,
         mismatch_pixels_pct, exact_match, verdict}
    """
    try:
        from . import exact_trace
    except ImportError as exc:  # pragma: no cover
        return {"error": f"exact_trace import failed: {exc}"}
    try:
        return exact_trace.verify_pixel_match_impl(
            excalidraw_path=excalidraw_path,
            original_image_path=original_image_path,
            out_diff_png=out_diff_png,
            metric=metric,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_text_fill_from_ocr(excalidraw_path: str,
                                 original_image_path: str,
                                 out_path: str,
                                 lang: str = "eng+jpn",
                                 min_confidence: float = 40.0,
                                 replace_placeholders: bool = True) -> dict:
    """`compose_layers` が生成した text_placeholder 空 stub を OCR 文字列で埋める。

    **用途**: `compose_layers` の `text_placeholder` 戦略は MSER 検出した
    文字領域を空の `text` element として残すが、それでは可読性がない。
    このツールは元ラスターに OCR を走らせ、IoU >0.1 の placeholder bbox に
    OCR 結果を書き込む。

    **placeholder 検出ルール**:
    - `type=='text'` かつ `text` が空文字列
    - `id` が `text_placeholder_` で始まる
    - `groupIds` に "text" が含まれる

    Args:
        excalidraw_path: compose_layers 出力 .excalidraw。
        original_image_path: OCR をかける元ラスター。
        out_path: 埋め込み後の書き出し先。
        lang: Tesseract lang code (例 "eng+jpn")。
        min_confidence: 信頼度閾値 (0-100、既定 40)。
        replace_placeholders: True なら OCR ヒットしない placeholder を
            削除、False なら空のまま残す。

    Returns:
        {out_path, total_elements_before/after, text_placeholders_replaced,
         ocr_blocks_found, sample_filled_texts, lang}
    """
    try:
        from . import exact_trace
    except ImportError as exc:  # pragma: no cover
        return {"error": f"exact_trace import failed: {exc}"}
    try:
        return exact_trace.ocr_text_fill_impl(
            excalidraw_path=excalidraw_path,
            original_image_path=original_image_path,
            out_path=out_path, lang=lang,
            min_confidence=min_confidence,
            replace_placeholders=replace_placeholders,
        )
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_smooth_polylines(excalidraw_path: str,
                               out_path: str,
                               epsilon: float = 1.5,
                               chaikin_iterations: int = 2,
                               only_types: str = "",
                               min_points: int = 5) -> dict:
    """Excalidraw 内の polyline 系 element を RDP 圧縮 + Chaikin 平滑化する。

    **用途**: `compose_layers` の `skeleton_lines` 戦略は pixel 単位の
    ジグザグ polyline を生成しがちで 250-360 elements のうち殆どを占める。
    このツールで頂点数を数分の一に圧縮し、視覚的にも丸みのある curve に変換。

    **アルゴリズム**:
    1. Ramer–Douglas–Peucker で epsilon 未満の寄与 vertex を除去
    2. Chaikin corner-cutting を `chaikin_iterations` 回適用
       (既定 2 回で 1 edge → 4 edges に分割、丸くなる)

    Args:
        excalidraw_path: 入力 .excalidraw。
        out_path: 書き出し先。
        epsilon: RDP tolerance (pixel 単位、既定 1.5)。
        chaikin_iterations: Chaikin 反復回数 (0 で smoothing skip、既定 2)。
        only_types: 対象 element type を CSV で指定 (例 "line,freedraw")。
            空文字列で line + freedraw 両方。
        min_points: これ未満の頂点数の element は skip (既定 5)。

    Returns:
        {out_path, elements_modified, points_before, points_after,
         compression_pct, epsilon, chaikin_iterations}
    """
    try:
        from . import exact_trace
    except ImportError as exc:  # pragma: no cover
        return {"error": f"exact_trace import failed: {exc}"}
    types_list = [t.strip() for t in only_types.split(",")
                   if t.strip()] if only_types else None
    try:
        return exact_trace.smooth_polylines_impl(
            excalidraw_path=excalidraw_path,
            out_path=out_path,
            epsilon=epsilon,
            chaikin_iterations=chaikin_iterations,
            only_types=types_list,
            min_points=min_points,
        )
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


# ---------------------------------------------------------------------------
# v0.6.0 additions — OCR-inspired per-CC classification + auto pipeline
# ---------------------------------------------------------------------------


def diagram_classify_components(image_path: str,
                                  mask_path: str = "",
                                  min_area: int = 20,
                                  use_ocr: bool = False,
                                  ocr_lang: str = "eng+jpn",
                                  out_json: str = "") -> dict:
    """画像を connected component に分解し、各 CC の形状特徴量で分類する (v0.6.0)。

    **思想**: OCR が per-block confidence を返すように、trace も per-CC で
    意味ラベルを付ける。compose_layers の "fixed strategy per layer" から
    "per-CC strategy" への土台。

    **ラベル**:
    - `text_like` — 小さめ、密度あり、uniform stroke width (MSER/OCR hit)
    - `line` — 細長い、密度低、stroke 細い
    - `circle` — 円形 (circularity > 0.7)
    - `fill` — 大きめ、密度高い、solid 領域
    - `noise` — min_area 未満
    - `other` — 上記いずれにも当てはまらない

    **特徴量** (per CC): area, bbox, aspect, density, elongation, perimeter,
    circularity (4π·A/P²), solidity (A / convex_hull_area), stroke_width
    (2·mean distance-transform inside mask).

    Args:
        image_path: 入力ラスター (color or grayscale)。
        mask_path: 既存の前景マスク (空ならコアで Otsu 二値化)。
        min_area: noise 判定閾値 pixel (既定 20)。
        use_ocr: True なら Tesseract で OCR し、hit した CC の label を
            text_like に upgrade。`[ocr]` extra 必須。
        ocr_lang: Tesseract 言語 (既定 "eng+jpn")。
        out_json: 診断レポート JSON の書き出し先 (省略可)。

    Returns:
        {total_cc, class_histogram, stroke_width_stats, components: [...]}
    """
    try:
        from . import classify as _cls
    except ImportError as exc:  # pragma: no cover
        return {"error": f"classify import failed: {exc}"}
    try:
        return _cls.classify_components_impl(
            image_path=image_path, mask_path=mask_path,
            min_area=min_area, use_ocr=use_ocr, ocr_lang=ocr_lang,
            out_json=out_json,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_analyze_layers(layers_dir: str,
                             min_area: int = 20,
                             use_ocr: bool = False,
                             ocr_lang: str = "eng+jpn") -> dict:
    """separate_layers 出力 dir を走査し、layer ごと推奨 strategy を診断する。

    各 `layer_*.png` を `classify_components` にかけ dominant class を判定、
    class → strategy mapping で `compose_layers` / `compose_auto` 用の
    推奨設定を返す。

    **mapping**:
    - text_like → text_placeholder (+ OCR 結線推奨)
    - line → skeleton_lines
    - circle → circles_fit
    - fill → fill_contour
    - other → outline
    - noise → skip

    Args:
        layers_dir: diagram_separate_layers の出力 dir。
        min_area: classify の noise 判定閾値。
        use_ocr: True なら classify 段階で OCR hint を使う。
        ocr_lang: Tesseract lang。

    Returns:
        {layers_analyzed, aggregate_class_histogram,
         layers: [{filename, total_cc, class_histogram,
                    stroke_width_stats, dominant_class,
                    recommended_strategy, note}, ...]}
    """
    try:
        from . import classify as _cls
    except ImportError as exc:  # pragma: no cover
        return {"error": f"classify import failed: {exc}"}
    try:
        return _cls.analyze_layers_impl(
            layers_dir=layers_dir, min_area=min_area,
            use_ocr=use_ocr, ocr_lang=ocr_lang,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_compose_auto(image_path: str,
                           out_path: str,
                           min_area: int = 20,
                           use_ocr: bool = False,
                           ocr_lang: str = "eng+jpn",
                           scale: float = 1.0,
                           offset_x: float = 0.0,
                           offset_y: float = 0.0,
                           simplify_tolerance: float = 1.0,
                           bg_color: str = "#ffffff") -> dict:
    """CC ごとに strategy を自動選択して Excalidraw を生成する (compose の上位版)。

    **compose_layers との違い**:
    - compose_layers: **layer 単位** で strategy 固定 (ユーザが config 指定)
    - compose_auto: **CC 単位** で classify → strategy 自動選択

    **CC → 要素タイプ**:
    - text_like (+OCR) → `text` (OCR テキスト埋め込み)
    - text_like (-OCR) → `text` stub (id=text_placeholder_*)
    - circle → `ellipse` (bbox 比率)
    - line → skeletonize + RDP → `line` (開曲線)
    - fill → exterior contour + RDP → `line` (閉曲線、solid fill)
    - other → exterior contour → `line` (closed outline)
    - noise → skip

    **groupIds** に class label を自動付与 (編集時の選択が簡単)。

    Args:
        image_path: 入力画像。
        out_path: .excalidraw 書き出し先。
        min_area: noise 閾値。
        use_ocr: True なら OCR hit を text element に流用。
        ocr_lang: Tesseract lang。
        scale: 座標スケール (既定 1.0)。
        offset_x, offset_y: 原点オフセット (既定 0, 0)。
        simplify_tolerance: RDP epsilon (既定 1.0)。
        bg_color: appState.viewBackgroundColor (既定 #ffffff)。

    Returns:
        {out_path, image_size, total_cc, per_label_counts, total_elements, ocr_used}
    """
    try:
        from . import classify as _cls
    except ImportError as exc:  # pragma: no cover
        return {"error": f"classify import failed: {exc}"}
    try:
        return _cls.compose_auto_impl(
            image_path=image_path, out_path=out_path,
            min_area=min_area, use_ocr=use_ocr, ocr_lang=ocr_lang,
            scale=scale, offset_x=offset_x, offset_y=offset_y,
            simplify_tolerance=simplify_tolerance, bg_color=bg_color,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_trace_iterative(image_path: str,
                              out_path: str,
                              target_psnr: float = 40.0,
                              max_iterations: int = 5,
                              start_max_colors: int = 8,
                              start_simplify: float = 0.0,
                              min_area: int = 4,
                              bg_detect: bool = True) -> dict:
    """`trace_exact` + `verify_pixel_match` を組み合わせた refinement ループ。

    **戦略**: 毎 iteration で trace → verify。PSNR が target_psnr 未満なら
    params を強める (max_colors ↑ → simplify ↓ → min_area ↓ の優先順)。
    target 到達で stop、最高 PSNR の output を out_path に残す。

    **用途**: 複雑な図で `trace_exact` の default params では PSNR が足りない
    時に、手動でパラメータを探索する代わり自動収束させる。

    Args:
        image_path: 入力画像。
        out_path: 最高品質の .excalidraw 書き出し先。
        target_psnr: 収束目標 dB (既定 40、pixel_perfect=∞ より緩め)。
        max_iterations: 最大試行回数 (既定 5)。
        start_max_colors: 初期色数 (既定 8)。
        start_simplify: 初期 RDP epsilon (既定 0.0、pixel-exact)。
        min_area: ノイズ除去閾値 (既定 4)。
        bg_detect: 背景 auto-detect (既定 True)。

    Returns:
        {out_path, target_psnr, best_psnr, converged, iterations_run,
         best_params, best_metrics, attempts: [...]}
    """
    try:
        from . import classify as _cls
    except ImportError as exc:  # pragma: no cover
        return {"error": f"classify import failed: {exc}"}
    try:
        return _cls.trace_iterative_impl(
            image_path=image_path, out_path=out_path,
            target_psnr=target_psnr, max_iterations=max_iterations,
            start_max_colors=start_max_colors,
            start_simplify=start_simplify,
            min_area=min_area, bg_detect=bg_detect,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


# ---------------------------------------------------------------------------
# v0.7.0 additions — preprocess + shape detect + bezier/group/export
# ---------------------------------------------------------------------------


def diagram_preprocess(image_path: str,
                         out_path: str,
                         deskew: bool = True,
                         denoise: bool = True,
                         enhance_contrast: bool = True,
                         binarize: str = "",
                         max_skew_deg: float = 15.0) -> dict:
    """OCR 式の前処理 (deskew + bilateral denoise + CLAHE + 二値化) を走らせる (v0.7.0)。

    **目的**: 生 raster をそのまま trace すると、傾き・ノイズ・低コントラストで
    classifier / tracer が迷う。OCR エンジンが文字認識前に走らせる標準前処理を
    当てることで、下流の trace 品質を底上げする。

    **ステップ**:
    1. deskew: Canny + HoughLines で skew 角度推定 (median)、回転補正
    2. denoise: bilateralFilter (エッジ保持ノイズ除去)
    3. enhance_contrast: CLAHE (tileGridSize=8, clipLimit=2.0)
    4. binarize: "otsu" | "adaptive" | "sauvola" | "" (skip)

    Args:
        image_path: 入力 raster。
        out_path: 前処理後の書き出し先 (PNG)。
        deskew: 傾き補正するか (既定 True)。
        denoise: ノイズ除去するか (既定 True)。
        enhance_contrast: CLAHE (既定 True)。
        binarize: 二値化手法 ("otsu"/"adaptive"/"sauvola"/"")。sauvola は
            scikit-image 必須。
        max_skew_deg: 許容 skew 角度上限 (既定 15°、超えたら検出打ち切り)。

    Returns:
        {out_path, image_size, skew_angle_deg, deskew_applied, ..., output_is_binary}
    """
    try:
        from . import preprocess as _pre
    except ImportError as exc:  # pragma: no cover
        return {"error": f"preprocess import failed: {exc}"}
    try:
        return _pre.preprocess_impl(
            image_path=image_path, out_path=out_path,
            deskew=deskew, denoise=denoise,
            enhance_contrast=enhance_contrast,
            binarize=binarize, max_skew_deg=max_skew_deg,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_detect_shapes(image_path: str,
                            out_path: str,
                            min_rect_area: int = 400,
                            hough_min_line_length: int = 40,
                            hough_max_line_gap: int = 10,
                            detect_arrows: bool = True,
                            detect_circles: bool = True,
                            bg_color: str = "#ffffff") -> dict:
    """axis-aligned rectangle / line / arrow / circle を検出して Excalidraw 出力。

    **compose_auto との差**: compose_auto は CC を polygon/ellipse に寄せるだけ。
    このツールは Hough 検出で得た primitive を **Excalidraw native type**
    (`rectangle`, `line`, `arrow`, `ellipse`) で書き出すので編集性が劇的に向上。

    **用途**: schematic / block diagram / flow chart / UML 風の図。

    Args:
        image_path: 入力 raster。
        out_path: .excalidraw 書き出し先。
        min_rect_area: rectangle 候補の最小面積 pixel (既定 400)。
        hough_min_line_length: HoughLinesP 最小 line 長 pixel (既定 40)。
        hough_max_line_gap: HoughLinesP 最大 gap pixel (既定 10)。
        detect_arrows: True なら line の終端 付近の pixel 分布から arrowhead を
            推定し `arrow` element に格上げ (既定 True)。
        detect_circles: HoughCircles で円検出 (既定 True)。
        bg_color: 背景色 hex (既定 "#ffffff")。

    Returns:
        {out_path, image_size, counts: {rectangle, line, arrow, ellipse},
         total_elements}
    """
    try:
        from . import preprocess as _pre
    except ImportError as exc:  # pragma: no cover
        return {"error": f"preprocess import failed: {exc}"}
    try:
        return _pre.detect_shapes_impl(
            image_path=image_path, out_path=out_path,
            min_rect_area=min_rect_area,
            hough_min_line_length=hough_min_line_length,
            hough_max_line_gap=hough_max_line_gap,
            detect_arrows=detect_arrows,
            detect_circles=detect_circles,
            bg_color=bg_color,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_detect_text_regions(image_path: str,
                                  out_json: str = "",
                                  min_area: int = 60,
                                  max_area: int = 14400,
                                  dbscan_eps_frac: float = 0.02,
                                  dbscan_min_samples: int = 2) -> dict:
    """MSER + DBSCAN で text candidate を word/line level に集約する (v0.7.0)。

    **compose_layers の text_placeholder (MSER のみ) との差**:
    - 単純な MSER は character-level で出るため word/line に集約できない
    - DBSCAN で近接する MSER 領域を word にまとめ、さらに縦方向 proximity で
      line 単位の bbox も返す
    - OCR 前段として大変扱いやすい (tesseract の word/line と対応)

    Args:
        image_path: 入力 raster。
        out_json: 結果 JSON の書き出し先 (省略可)。
        min_area: MSER 最小面積 (既定 60、小さいノイズ除去)。
        max_area: MSER 最大面積 (既定 14400、大きすぎる BG を除外)。
        dbscan_eps_frac: DBSCAN eps を canvas 対角の分数で指定 (既定 0.02)。
        dbscan_min_samples: word DBSCAN の最小点数 (既定 2)。

    Returns:
        {image_size, mser_candidates, words, lines, word_count, line_count}
    """
    try:
        from . import preprocess as _pre
    except ImportError as exc:  # pragma: no cover
        return {"error": f"preprocess import failed: {exc}"}
    try:
        return _pre.detect_text_regions_impl(
            image_path=image_path, out_json=out_json,
            min_area=min_area, max_area=max_area,
            dbscan_eps_frac=dbscan_eps_frac,
            dbscan_min_samples=dbscan_min_samples,
        )
    except RuntimeError as exc:
        return {"error": str(exc)}
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_fit_bezier(excalidraw_path: str,
                         out_path: str,
                         min_points: int = 8,
                         samples_per_segment: int = 12,
                         corner_angle_deg: float = 40.0,
                         only_types: str = "") -> dict:
    """polyline element を corner-aware cubic Bezier で近似し、滑らかに再サンプルする。

    **アルゴリズム**:
    1. 各 polyline を corner_angle_deg 超える turn で segment に分割
       (sharp corner は保持、smooth run だけ curve fit)
    2. 各 segment を 1 本の cubic Bezier で近似 (endpoint 固定 + tangent
       estimate で control point を chord の 1/3 距離に配置)
    3. Bezier を samples_per_segment 個の uniform-t 点で resample
    4. segment を連結し、element の points を置換

    **用途**: skeleton_lines strategy が吐く 50-200 points の zig-zag を
    10-30 points の滑らかな curve に圧縮。

    Args:
        excalidraw_path: 入力 .excalidraw。
        out_path: 書き出し先。
        min_points: これ未満の point 数の element は skip (既定 8)。
        samples_per_segment: segment あたり再サンプル点数 (既定 12)。
        corner_angle_deg: 超えたら corner として分割 (既定 40°)。
        only_types: 対象 type CSV (空で line + freedraw)。

    Returns:
        {out_path, elements_modified, points_before/after, compression_pct,
         samples_per_segment, corner_angle_deg}
    """
    try:
        from . import vectorize as _vec
    except ImportError as exc:  # pragma: no cover
        return {"error": f"vectorize import failed: {exc}"}
    types_list = [t.strip() for t in only_types.split(",")
                   if t.strip()] if only_types else None
    try:
        return _vec.fit_bezier_impl(
            excalidraw_path=excalidraw_path, out_path=out_path,
            min_points=min_points,
            samples_per_segment=samples_per_segment,
            corner_angle_deg=corner_angle_deg,
            only_types=types_list,
        )
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_semantic_group(excalidraw_path: str,
                             out_path: str,
                             eps: float = 0.0,
                             min_samples: int = 2,
                             preserve_existing: bool = True) -> dict:
    """DBSCAN で element 位置をクラスタ化し semantic groupIds を自動付与する。

    **目的**: compose_auto が生成した多数の element を Excalidraw 編集時に
    一度に選択したい (icon + wordmark を「ロゴ」として扱う 等)。DBSCAN の
    cluster ID を groupIds に入れることで `Ctrl+Shift+G` で group 化される。

    Args:
        excalidraw_path: 入力 .excalidraw。
        out_path: 書き出し先。
        eps: DBSCAN 半径 (pixel)。0 で auto (canvas 対角の 5%)。
        min_samples: cluster の最小 element 数 (既定 2)。
        preserve_existing: 既存の groupIds を温存するか (既定 True)。

    Returns:
        {out_path, eps, min_samples, total_elements, clusters, cluster_sizes,
         noise_elements}
    """
    try:
        from . import vectorize as _vec
    except ImportError as exc:  # pragma: no cover
        return {"error": f"vectorize import failed: {exc}"}
    try:
        return _vec.semantic_group_impl(
            excalidraw_path=excalidraw_path, out_path=out_path,
            eps=eps, min_samples=min_samples,
            preserve_existing=preserve_existing,
        )
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_stroke_width_normalize(excalidraw_path: str,
                                     out_path: str,
                                     buckets: str = "",
                                     tolerance: float = 1.0) -> dict:
    """element の strokeWidth を dominant value に snap して視覚的一貫性を回復。

    **問題**: raster tracer は CC ごとに少しずつ違う stroke_width を計算し、
    結果として Excalidraw 上で "線ごと太さが違う" 見た目になる。

    **解**: buckets 未指定なら現 widths を 0.5 単位で丸めたヒストグラムの
    上位 3 モードを自動抽出、tolerance 以内なら最近値に snap。
    buckets 指定 ("1,2,4") なら完全手動。

    Args:
        excalidraw_path: 入力 .excalidraw。
        out_path: 書き出し先。
        buckets: 許容 width 値を CSV で指定 ("1,2,4")。空で auto-detect。
        tolerance: snap 許容差 (既定 1.0 pixel)。

    Returns:
        {out_path, modified, buckets, tolerance, unique_widths_before/after}
    """
    try:
        from . import vectorize as _vec
    except ImportError as exc:  # pragma: no cover
        return {"error": f"vectorize import failed: {exc}"}
    buckets_list: list[float] | None = None
    if buckets.strip():
        try:
            buckets_list = [float(b.strip()) for b in buckets.split(",")
                              if b.strip()]
        except ValueError as exc:
            return {"error": f"bad buckets CSV: {exc}"}
    try:
        return _vec.stroke_width_normalize_impl(
            excalidraw_path=excalidraw_path, out_path=out_path,
            buckets=buckets_list, tolerance=tolerance,
        )
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_excalidraw_to_svg(excalidraw_path: str,
                                out_path: str,
                                margin: float = 10.0,
                                bg_override: str = "") -> dict:
    """Excalidraw JSON を SVG に書き出す (論文 `\\includegraphics` / HTML 埋め込み用)。

    **対応**: rectangle, ellipse, line (open/closed), arrow, text, freedraw。
    rough.js sketchy 表現は solid stroke に近似 (論文品質優先)。

    Args:
        excalidraw_path: 入力 .excalidraw。
        out_path: .svg 書き出し先。
        margin: 余白 (既定 10 pt)。
        bg_override: 背景色上書き (空で viewBackgroundColor を尊重)。

    Returns:
        {out_path, viewbox, exported_elements, skipped_by_type}
    """
    try:
        from . import export as _exp
    except ImportError as exc:  # pragma: no cover
        return {"error": f"export import failed: {exc}"}
    try:
        return _exp.excalidraw_to_svg_impl(
            excalidraw_path=excalidraw_path, out_path=out_path,
            margin=margin, bg_override=bg_override,
        )
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagram_excalidraw_to_tikz(excalidraw_path: str,
                                 out_path: str,
                                 scale: float = 0.75,
                                 y_flip: bool = True) -> dict:
    """Excalidraw を TikZ ``\\draw`` 命令列に変換し .tex として書き出す。

    **用途**: LaTeX 論文への直挿入 (raster 中間不要)。出力は
    `\\begin{tikzpicture}...\\end{tikzpicture}` の完結形で、
    `\\input{file.tex}` 可。

    **対応**: rectangle, ellipse, line, arrow (->), text (→ `\\node`), freedraw。
    **座標系**: Excalidraw は Y 軸が下向き、TikZ は上向き。`y_flip=True`
    で自動反転 (既定)。

    Args:
        excalidraw_path: 入力 .excalidraw。
        out_path: .tex 書き出し先。
        scale: pixel → TikZ unit スケール (既定 0.75、pt 前提で 100px ≒ 7.5cm)。
        y_flip: Y 軸反転 (既定 True)。

    Returns:
        {out_path, canvas_size_pt, exported_elements, skipped_by_type, scale, y_flip}
    """
    try:
        from . import export as _exp
    except ImportError as exc:  # pragma: no cover
        return {"error": f"export import failed: {exc}"}
    try:
        return _exp.excalidraw_to_tikz_impl(
            excalidraw_path=excalidraw_path, out_path=out_path,
            scale=scale, y_flip=y_flip,
        )
    except Exception as exc:  # pragma: no cover
        return {"error": f"{type(exc).__name__}: {exc}"}


# ---------------------------------------------------------------------------
# v0.8.0 — 塚本『作図力学』由来の 線図 lint
# ---------------------------------------------------------------------------


def diagram_lint_line_plot(excalidraw_path: str,
                             min_axis_labels: int = 2,
                             caption_required: bool = True) -> dict:
    """Excalidraw の線図に対し、塚本『作図力学』§4.3.2 式の anti-pattern を検出。

    **対象**: data-series 線 + 軸 + ラベル + キャプション で構成される線図を想定。
    詳細な (プロット点の形・曲線の貫通・スケール数字の桁) のチェックは画像
    レベルでないと困難なので、Excalidraw 構造レベルで見える問題のみ検査する。

    **チェック項目** (塚本 §4.3.2 / 4.3):
    1. **軸ラベル text 要素の有無** (x 軸用と y 軸用の少なくとも 2 つ)
    2. **キャプション text 要素の有無** (plot area の下方に text)
    3. **データ系列 line 要素の有無** (≥ 1 本)
    4. **プロット点と曲線の衝突** は本 tool では判定不可 (画像要)
    5. **座標軸線への矢印** (arrow 要素が plot の原点近くで座標軸として
       使われている → 塚本原則で NG: 特殊線図以外は矢印をつけない)
    6. **outlier 要素** (plot bounds から大きく外れた漂流要素)

    Args:
        excalidraw_path: 入力 .excalidraw path。
        min_axis_labels: 軸ラベル text 要素の最少要求数 (既定 2)。
        caption_required: キャプション必須とするか (既定 True)。

    Returns:
        {total_elements, text_count, line_count, arrow_count, findings: [...],
         verdict, hint, source}
    """
    import json as _json
    import pathlib as _pl

    p = _pl.Path(excalidraw_path).expanduser()
    if not p.exists():
        return {"error": f"file not found: {p}"}
    try:
        doc = _json.loads(p.read_text(encoding="utf-8"))
    except (_json.JSONDecodeError, UnicodeDecodeError) as exc:
        return {"error": f"parse error: {exc}"}

    elements = [el for el in doc.get("elements", []) if not el.get("isDeleted")]
    if not elements:
        return {
            "total_elements": 0,
            "verdict": "empty",
            "hint": "no elements — nothing to lint",
        }

    texts = [el for el in elements if el.get("type") == "text"]
    lines = [el for el in elements if el.get("type") == "line"]
    arrows = [el for el in elements if el.get("type") == "arrow"]

    findings: list[dict] = []

    # 1. axis label count
    if len(texts) < min_axis_labels:
        findings.append({
            "rule": "axis_labels",
            "severity": "error",
            "message": f"text 要素 {len(texts)} 個 < {min_axis_labels}; "
                       "軸ラベル (x 軸・y 軸) が不足している可能性",
        })

    # 2. caption detection: find text elements below the centroid of line elements
    if caption_required and texts and lines:
        line_centers = [
            (el.get("x", 0.0) + el.get("width", 0.0) / 2.0,
             el.get("y", 0.0) + el.get("height", 0.0) / 2.0)
            for el in lines
        ]
        line_cy = sum(c[1] for c in line_centers) / max(1, len(line_centers))
        # Caption candidates: text elements whose y > line_cy + offset (below the plot)
        captions_below = [
            t for t in texts
            if t.get("y", 0.0) > line_cy + 20.0
        ]
        if not captions_below:
            findings.append({
                "rule": "caption_below",
                "severity": "warning",
                "message": "plot area 下に text 要素が無い — キャプション "
                           "(図 N. タイトル) が配置されていない可能性",
            })

    # 3. data series lines
    if len(lines) == 0:
        findings.append({
            "rule": "no_data_series",
            "severity": "error",
            "message": "line 要素がゼロ — 線図ではない可能性",
        })

    # 4. arrows used as axes (anti-pattern: 塚本 "特殊な線図以外、座標軸線には矢印をつけない")
    #    Heuristic: arrows whose start/end is at a bounding-box corner + orthogonal
    if arrows and lines:
        # Compute overall plot bbox
        xs = [el.get("x", 0.0) for el in lines]
        ys = [el.get("y", 0.0) for el in lines]
        x2s = [el.get("x", 0.0) + el.get("width", 0.0) for el in lines]
        y2s = [el.get("y", 0.0) + el.get("height", 0.0) for el in lines]
        bx0, by0 = min(xs), min(ys)
        bx1, by1 = max(x2s), max(y2s)
        for a in arrows:
            ax0 = a.get("x", 0.0); ay0 = a.get("y", 0.0)
            aw = a.get("width", 0.0); ah = a.get("height", 0.0)
            if aw == 0 or ah == 0:
                # Pure horizontal or vertical arrow — could be axis
                # Check proximity to plot bbox corner (within 30 px)
                near_origin = (
                    abs(ax0 - bx0) < 30 and abs(ay0 + ah - by1) < 30
                )
                if near_origin:
                    findings.append({
                        "rule": "arrow_as_axis",
                        "severity": "warning",
                        "message": "座標軸線に矢印が付いている可能性 "
                                    "(塚本『作図力学』§4.3.2: 特殊線図以外は矢印 NG)",
                        "arrow_id": a.get("id"),
                    })

    # 5. outlier elements far from plot
    if len(lines) >= 2:
        xs = [el.get("x", 0.0) for el in lines]
        ys = [el.get("y", 0.0) for el in lines]
        x2s = [el.get("x", 0.0) + el.get("width", 0.0) for el in lines]
        y2s = [el.get("y", 0.0) + el.get("height", 0.0) for el in lines]
        plot_bbox = (min(xs), min(ys), max(x2s), max(y2s))
        pw = plot_bbox[2] - plot_bbox[0]
        ph = plot_bbox[3] - plot_bbox[1]
        tolerance = max(pw, ph) * 0.3  # 30% of plot dimension
        outliers = []
        for el in elements:
            ex = el.get("x", 0.0)
            ey = el.get("y", 0.0)
            if (ex < plot_bbox[0] - tolerance or ex > plot_bbox[2] + tolerance
                or ey < plot_bbox[1] - tolerance or ey > plot_bbox[3] + tolerance):
                outliers.append({"id": el.get("id"),
                                   "type": el.get("type"),
                                   "x": ex, "y": ey})
        if outliers:
            findings.append({
                "rule": "floating_elements",
                "severity": "info",
                "message": f"plot 領域から大きく離れた要素が {len(outliers)} 個 "
                            "(凡例・タイトル・メモ書きなら許容)",
                "outliers": outliers[:5],
            })

    errors = sum(1 for f in findings if f["severity"] == "error")
    warnings = sum(1 for f in findings if f["severity"] == "warning")
    if errors:
        verdict = "needs_fix"
    elif warnings:
        verdict = "minor_issues"
    else:
        verdict = "ok"

    return {
        "total_elements": len(elements),
        "text_count": len(texts),
        "line_count": len(lines),
        "arrow_count": len(arrows),
        "findings": findings,
        "verdict": verdict,
        "hint": (
            "Excalidraw 構造レベルの軽量 lint。塚本『作図力学』§4.3.2 の "
            "詳細項目 (プロット点形状 / 曲線貫通 / スケール有効桁数 等) は "
            "画像側でないと判定不可。全体のレイアウト整合性のみ hint として使う。"
        ),
        "source": "塚本真也『作図力学』§4.3.2 線図の間違い",
    }


def diagram_diff_excalidraw(path_a: str, path_b: str) -> dict:
    """2 つの Excalidraw JSON の element-level 差分を返す。

    Use case: compose_layers を paramter tweak で再生成した際、
    どの element が追加/削除/移動されたかを要約する。

    Returns:
        {added, removed, moved, count_a, count_b}
    """
    def _load(p: str) -> dict | None:
        pp = pathlib.Path(p).expanduser()
        if not pp.exists():
            return None
        try:
            return json.loads(pp.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None
    a = _load(path_a)
    b = _load(path_b)
    if a is None:
        return {"error": f"could not load path_a={path_a!r}"}
    if b is None:
        return {"error": f"could not load path_b={path_b!r}"}
    els_a = {el.get("id"): el for el in a.get("elements", []) if el.get("id")}
    els_b = {el.get("id"): el for el in b.get("elements", []) if el.get("id")}
    added = [eid for eid in els_b if eid not in els_a]
    removed = [eid for eid in els_a if eid not in els_b]
    moved = []
    for eid in set(els_a) & set(els_b):
        a_el = els_a[eid]
        b_el = els_b[eid]
        dx = (b_el.get("x", 0.0) - a_el.get("x", 0.0))
        dy = (b_el.get("y", 0.0) - a_el.get("y", 0.0))
        if abs(dx) > 0.5 or abs(dy) > 0.5:
            moved.append({"id": eid, "dx": round(dx, 1), "dy": round(dy, 1)})
    return {
        "count_a": len(els_a),
        "count_b": len(els_b),
        "added_count": len(added),
        "removed_count": len(removed),
        "moved_count": len(moved),
        "added_sample": added[:10],
        "removed_sample": removed[:10],
        "moved_sample": moved[:10],
    }
