//! JSON-RPC protocol support for Spikard HTTP
//!
//! This module provides JSON-RPC 2.0 protocol support including method registration,
//! handler lookup, and metadata management.

pub(crate) mod http_handler;
pub(crate) mod method_registry;
pub(crate) mod openrpc;
pub(crate) mod protocol;
pub(crate) mod router;

use serde::{Deserialize, Serialize};

#[cfg(not(target_arch = "wasm32"))]
pub(crate) use http_handler::{JsonRpcState, handle_jsonrpc};
pub(crate) use method_registry::{JsonRpcMethodRegistry, MethodMetadata};
#[cfg(not(target_arch = "wasm32"))]
pub(crate) use openrpc::generate_openrpc_spec;
#[cfg(not(target_arch = "wasm32"))]
pub(crate) use router::JsonRpcRouter;

/// JSON-RPC server configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JsonRpcConfig {
    /// Enable JSON-RPC endpoint
    #[serde(default)]
    pub enabled: bool,
    /// HTTP endpoint path for JSON-RPC requests (default: "/rpc")
    #[serde(default = "default_endpoint_path")]
    pub endpoint_path: String,
    /// Enable batch request processing (default: true)
    #[serde(default = "default_true")]
    pub enable_batch: bool,
    /// Maximum number of requests in a batch (default: 100)
    #[serde(default = "default_max_batch_size")]
    pub max_batch_size: usize,
}

fn default_endpoint_path() -> String {
    "/rpc".to_string()
}

fn default_true() -> bool {
    true
}

fn default_max_batch_size() -> usize {
    100
}

impl Default for JsonRpcConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            endpoint_path: default_endpoint_path(),
            enable_batch: default_true(),
            max_batch_size: default_max_batch_size(),
        }
    }
}
