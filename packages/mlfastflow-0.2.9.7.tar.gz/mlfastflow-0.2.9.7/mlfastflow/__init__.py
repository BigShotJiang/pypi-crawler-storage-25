"""MLFastFlow - packages for fast dataflow and workflow processing."""

__version__ = "0.2.9.7"

# Import core components
from mlfastflow.core import Flow


# Import fastKNN functionality  
import mlfastflow.FastKNN as FastKNN
from mlfastflow.FastKNN import FastKNN
 
# Import BigQueryClient
import mlfastflow.bigqueryclient as bigqueryclient
from mlfastflow.bigqueryclient import BigQueryClient

# Import utils module (functions accessible via utils.function_name)
import mlfastflow.utils as utils

# Import utility functions directly
from mlfastflow.utils import (
    configure_logging,
    timer_decorator,
    concat_files,
    profile,
    csv2parquet,
    parquet2csv,
    get_info,
)

# Make these classes and modules available at the package level
__all__ = [
    'Flow',
    'bigqueryclient',  # module
    'BigQueryClient',  # class
    'FastKNN',         # class (also shadows the module of the same name)
    'utils',           # module
    'configure_logging', # function
    'timer_decorator',   # function
    'concat_files',      # function
    'profile',           # function
    'csv2parquet',       # function
    'parquet2csv',       # function
    'get_info',          # function
]
