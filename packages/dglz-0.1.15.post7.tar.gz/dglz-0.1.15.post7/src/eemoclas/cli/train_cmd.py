"""``eemo train`` -- train classifier models.

Uses the unified training config (``train_full.yaml``) to train one or more
CNN-Transformer classifier models.
"""

from __future__ import annotations

from typing import List, Optional

import typer

app = typer.Typer(help="训练分类器模型")


@app.callback(invoke_without_command=True)
def train(
    config: str = typer.Option(..., "--config", help="统一训练配置 YAML 文件路径"),
    models: Optional[str] = typer.Option(
        None, "--models", "-m",
        help="逗号分隔的模型名称（留空则使用配置文件中所有模型）",
    ),
    mode: str = typer.Option(
        "sequential", "--mode",
        help="训练模式: sequential, parallel, mixed",
    ),
    parallel_models: Optional[str] = typer.Option(
        None, "--parallel-models",
        help="mixed 模式下并行训练的模型（逗号分隔）",
    ),
    override: Optional[List[str]] = typer.Option(
        None, "--override", "-o",
        help="点分键值覆盖（可重复），例如 experiment.name=exp002",
    ),
    experiment_name: Optional[str] = typer.Option(
        None, "--experiment-name", help="实验名称（用于日志和检查点目录）",
    ),
    verbose: bool = typer.Option(False, "--verbose", help="启用详细输出模式"),
    resume: Optional[str] = typer.Option(
        None, "--resume",
        help="从指定检查点路径恢复训练（留空则自动检测最新检查点）",
    ),
    fresh: bool = typer.Option(
        False, "--fresh",
        help="强制从头开始训练，跳过自动恢复",
    ),
    init_weight: Optional[str] = typer.Option(
        None, "--init-weight",
        help="预训练权重 .ckpt 路径（对所有分类器统一覆盖），与 --resume 互斥",
    ),
    init_weight_strict: Optional[str] = typer.Option(
        None, "--init-weight-strict",
        help="权重加载模式: true（严格匹配）/ false（宽松匹配）",
    ),
) -> None:
    """训练一个或全部分类器模型。"""
    # Parse comma-separated model lists
    model_names: list[str] | None = None
    if models:
        model_names = [m.strip() for m in models.split(",") if m.strip()]

    par_models: list[str] | None = None
    if parallel_models:
        par_models = [m.strip() for m in parallel_models.split(",") if m.strip()]

    from eemoclas.cli.train_impl import run_training

    run_training(
        config_path=config,
        model_names=model_names,
        mode=mode,
        parallel_models=par_models,
        overrides=list(override) if override else None,
        experiment_name=experiment_name,
        verbose=verbose,
        resume=resume,
        fresh=fresh,
        init_weight=init_weight,
        init_weight_strict=init_weight_strict,
    )
